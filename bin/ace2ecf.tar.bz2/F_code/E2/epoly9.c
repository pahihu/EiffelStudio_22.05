#include "epoly9.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R6635[263])();
void R6635_init () {
	R6635[0] = (char *(*)()) F1052_7886;
	{long i; for (i = 1; i < 3; i++) R6635[i] = (char *(*)()) F1053_7979;}
	R6635[5] = (char *(*)()) F1057_8056;
	R6635[6] = (char *(*)()) F1058_8149;
	R6635[262] = (char *(*)()) F1053_7979;
}

char *(*R6646[262])();
void R6646_init () {
	{long i; for (i = 0; i < 2; i++) R6646[i] = (char *(*)()) F1053_7977;}
	R6646[5] = (char *(*)()) F1058_8148;
	R6646[261] = (char *(*)()) F1053_7977;
}

char *(*R6649[262])();
void R6649_init () {
	{long i; for (i = 0; i < 2; i++) R6649[i] = (char *(*)()) F1053_7916;}
	R6649[5] = (char *(*)()) F1058_8087;
	R6649[261] = (char *(*)()) F1314_13201;
}

char *(*R6650[262])();
void R6650_init () {
	{long i; for (i = 0; i < 2; i++) R6650[i] = (char *(*)()) F1050_7785;}
	R6650[5] = (char *(*)()) F1050_7785;
	R6650[261] = (char *(*)()) F1314_13202;
}

char *(*R6661[262])();
void R6661_init () {
	{long i; for (i = 0; i < 2; i++) R6661[i] = (char *(*)()) F1053_7927;}
	R6661[5] = (char *(*)()) F1058_8098;
	R6661[261] = (char *(*)()) F1314_13124;
}

char *(*R6669[262])();
void R6669_init () {
	{long i; for (i = 0; i < 2; i++) R6669[i] = (char *(*)()) F1053_7910;}
	R6669[5] = (char *(*)()) F1058_8081;
	R6669[261] = (char *(*)()) F1314_13148;
}

char *(*R6670[262])();
void R6670_init () {
	{long i; for (i = 0; i < 2; i++) R6670[i] = (char *(*)()) F1053_7911;}
	R6670[5] = (char *(*)()) F1058_8082;
	R6670[261] = (char *(*)()) F1314_13149;
}

char *(*R6671[262])();
void R6671_init () {
	{long i; for (i = 0; i < 2; i++) R6671[i] = (char *(*)()) F1053_7912;}
	R6671[5] = (char *(*)()) F1058_8083;
	R6671[261] = (char *(*)()) F1314_13197;
}

char *(*R6672[262])();
void R6672_init () {
	{long i; for (i = 0; i < 2; i++) R6672[i] = (char *(*)()) F1053_7913;}
	R6672[5] = (char *(*)()) F1058_8084;
	R6672[261] = (char *(*)()) F1314_13198;
}

char *(*R6675[262])();
void R6675_init () {
	{long i; for (i = 0; i < 2; i++) R6675[i] = (char *(*)()) F1053_7950;}
	R6675[5] = (char *(*)()) F1058_8121;
	R6675[261] = (char *(*)()) F1314_13150;
}

char *(*R6677[262])();
void R6677_init () {
	{long i; for (i = 0; i < 2; i++) R6677[i] = (char *(*)()) F1053_7952;}
	R6677[5] = (char *(*)()) F1058_8123;
	R6677[261] = (char *(*)()) F1314_13151;
}

char *(*R6678[262])();
void R6678_init () {
	{long i; for (i = 0; i < 2; i++) R6678[i] = (char *(*)()) F1053_7957;}
	R6678[5] = (char *(*)()) F1058_8128;
	R6678[261] = (char *(*)()) F1314_13195;
}

char *(*R6679[262])();
void R6679_init () {
	{long i; for (i = 0; i < 2; i++) R6679[i] = (char *(*)()) F1053_7960;}
	R6679[5] = (char *(*)()) F1058_8131;
	R6679[261] = (char *(*)()) F1053_7960;
}

char *(*R6689[262])();
void R6689_init () {
	{long i; for (i = 0; i < 2; i++) R6689[i] = (char *(*)()) F1053_7898;}
	R6689[261] = (char *(*)()) F1314_13085;
}

char *(*R6691[263])();
void R6691_init () {
	{long i; for (i = 0; i < 3; i++) R6691[i] = (char *(*)()) F1051_7828;}
	R6691[262] = (char *(*)()) F1314_13096;
}

char *(*R6693[263])();
void R6693_init () {
	{long i; for (i = 0; i < 3; i++) R6693[i] = (char *(*)()) F1051_7831;}
	R6693[262] = (char *(*)()) F1314_13091;
}

char *(*R6698[263])();
void R6698_init () {
	{long i; for (i = 0; i < 3; i++) R6698[i] = (char *(*)()) F1051_7843;}
	R6698[262] = (char *(*)()) F1314_13114;
}

char *(*R6703[263])();
void R6703_init () {
	R6703[0] = (char *(*)()) F1052_7877;
	{long i; for (i = 1; i < 3; i++) R6703[i] = (char *(*)()) F1053_7947;}
	R6703[262] = (char *(*)()) F1314_13092;
}

char *(*R6711[263])();
void R6711_init () {
	R6711[0] = (char *(*)()) F1052_7888;
	{long i; for (i = 1; i < 3; i++) R6711[i] = (char *(*)()) F1051_7867;}
	R6711[262] = (char *(*)()) F1051_7867;
}

char *(*R6726[262])();
void R6726_init () {
	{long i; for (i = 0; i < 2; i++) R6726[i] = (char *(*)()) F1053_7905;}
	R6726[261] = (char *(*)()) F1314_13147;
}

char *(*R6734[262])();
void R6734_init () {
	{long i; for (i = 0; i < 2; i++) R6734[i] = (char *(*)()) F1053_7920;}
	R6734[261] = (char *(*)()) F1314_13122;
}

char *(*R6737[262])();
void R6737_init () {
	{long i; for (i = 0; i < 2; i++) R6737[i] = (char *(*)()) F1053_7928;}
	R6737[261] = (char *(*)()) F1314_13130;
}

char *(*R6739[262])();
void R6739_init () {
	{long i; for (i = 0; i < 2; i++) R6739[i] = (char *(*)()) F1053_7930;}
	R6739[261] = (char *(*)()) F1314_13128;
}

char *(*R6741[262])();
void R6741_init () {
	{long i; for (i = 0; i < 2; i++) R6741[i] = (char *(*)()) F1053_7941;}
	R6741[261] = (char *(*)()) F1314_13127;
}

char *(*R6743[262])();
void R6743_init () {
	{long i; for (i = 0; i < 2; i++) R6743[i] = (char *(*)()) F1053_7945;}
	R6743[261] = (char *(*)()) F1314_13144;
}

char *(*R6744[262])();
void R6744_init () {
	{long i; for (i = 0; i < 2; i++) R6744[i] = (char *(*)()) F1053_7946;}
	R6744[261] = (char *(*)()) F1314_13142;
}

char *(*R6753[262])();
void R6753_init () {
	{long i; for (i = 0; i < 2; i++) R6753[i] = (char *(*)()) F1053_7969;}
	R6753[261] = (char *(*)()) F1314_13161;
}

char *(*R6754[262])();
void R6754_init () {
	{long i; for (i = 0; i < 2; i++) R6754[i] = (char *(*)()) F1053_7970;}
	R6754[261] = (char *(*)()) F1314_13162;
}

char *(*R6781[2])();
void R6781_init () {
	R6781[0] = (char *(*)()) F1057_8047;
	R6781[1] = (char *(*)()) F1058_8118;
}

char *(*R6789[2])();
void R6789_init () {
	R6789[0] = (char *(*)()) F1057_8058;
	R6789[1] = (char *(*)()) F1056_8035;
}

char *(*R7322[34])();
void R7322_init () {
	R7322[0] = (char *(*)()) F1074_8687;
	R7322[1] = (char *(*)()) F1075_8687;
	R7322[2] = (char *(*)()) F1076_8687;
	R7322[3] = (char *(*)()) F1077_8687;
	R7322[4] = (char *(*)()) F1078_8687;
	R7322[5] = (char *(*)()) F1079_8687;
	R7322[6] = (char *(*)()) F1080_8687;
	R7322[7] = (char *(*)()) F1081_8687;
	R7322[8] = (char *(*)()) F1082_8687;
	R7322[9] = (char *(*)()) F1083_8687;
	R7322[10] = (char *(*)()) F1084_8687;
	R7322[11] = (char *(*)()) F1085_8687;
	R7322[12] = (char *(*)()) F1086_8687;
	R7322[13] = (char *(*)()) F1087_8687;
	R7322[14] = (char *(*)()) F1088_8687;
	R7322[15] = (char *(*)()) F1089_8687;
	R7322[16] = (char *(*)()) F1090_8687;
	R7322[17] = (char *(*)()) F1091_8687;
	R7322[18] = (char *(*)()) F1092_8687;
	R7322[19] = (char *(*)()) F1093_8687;
	R7322[20] = (char *(*)()) F1094_8687;
	R7322[21] = (char *(*)()) F1095_8687;
	R7322[22] = (char *(*)()) F1096_8687;
	R7322[23] = (char *(*)()) F1097_8687;
	R7322[24] = (char *(*)()) F1098_8687;
	R7322[25] = (char *(*)()) F1099_8687;
	R7322[26] = (char *(*)()) F1100_8687;
	R7322[27] = (char *(*)()) F1101_8687;
	R7322[28] = (char *(*)()) F1102_8687;
	R7322[29] = (char *(*)()) F1103_8687;
	R7322[30] = (char *(*)()) F1104_8687;
	R7322[31] = (char *(*)()) F1105_8687;
	R7322[32] = (char *(*)()) F1106_8687;
	R7322[33] = (char *(*)()) F1107_8687;
}

char *(*R7323[34])();
void R7323_init () {
	R7323[0] = (char *(*)()) F1074_8688;
	R7323[1] = (char *(*)()) F1075_8688;
	R7323[2] = (char *(*)()) F1076_8688;
	R7323[3] = (char *(*)()) F1077_8688;
	R7323[4] = (char *(*)()) F1078_8688;
	R7323[5] = (char *(*)()) F1079_8688;
	R7323[6] = (char *(*)()) F1080_8688;
	R7323[7] = (char *(*)()) F1081_8688;
	R7323[8] = (char *(*)()) F1082_8688;
	R7323[9] = (char *(*)()) F1083_8688;
	R7323[10] = (char *(*)()) F1084_8688;
	R7323[11] = (char *(*)()) F1085_8688;
	R7323[12] = (char *(*)()) F1086_8688;
	R7323[13] = (char *(*)()) F1087_8688;
	R7323[14] = (char *(*)()) F1088_8688;
	R7323[15] = (char *(*)()) F1089_8688;
	R7323[16] = (char *(*)()) F1090_8688;
	R7323[17] = (char *(*)()) F1091_8688;
	R7323[18] = (char *(*)()) F1092_8688;
	R7323[19] = (char *(*)()) F1093_8688;
	R7323[20] = (char *(*)()) F1094_8688;
	R7323[21] = (char *(*)()) F1095_8688;
	R7323[22] = (char *(*)()) F1096_8688;
	R7323[23] = (char *(*)()) F1097_8688;
	R7323[24] = (char *(*)()) F1098_8688;
	R7323[25] = (char *(*)()) F1099_8688;
	R7323[26] = (char *(*)()) F1100_8688;
	R7323[27] = (char *(*)()) F1101_8688;
	R7323[28] = (char *(*)()) F1102_8688;
	R7323[29] = (char *(*)()) F1103_8688;
	R7323[30] = (char *(*)()) F1104_8688;
	R7323[31] = (char *(*)()) F1105_8688;
	R7323[32] = (char *(*)()) F1106_8688;
	R7323[33] = (char *(*)()) F1107_8688;
}

char *(*R7325[34])();
void R7325_init () {
	R7325[0] = (char *(*)()) F1074_8690;
	R7325[1] = (char *(*)()) F1075_8690;
	R7325[2] = (char *(*)()) F1076_8690;
	R7325[3] = (char *(*)()) F1077_8690;
	R7325[4] = (char *(*)()) F1078_8690;
	R7325[5] = (char *(*)()) F1079_8690;
	R7325[6] = (char *(*)()) F1080_8690;
	R7325[7] = (char *(*)()) F1081_8690;
	R7325[8] = (char *(*)()) F1082_8690;
	R7325[9] = (char *(*)()) F1083_8690;
	R7325[10] = (char *(*)()) F1084_8690;
	R7325[11] = (char *(*)()) F1085_8690;
	R7325[12] = (char *(*)()) F1086_8690;
	R7325[13] = (char *(*)()) F1087_8690;
	R7325[14] = (char *(*)()) F1088_8690;
	R7325[15] = (char *(*)()) F1089_8690;
	R7325[16] = (char *(*)()) F1090_8690;
	R7325[17] = (char *(*)()) F1091_8690;
	R7325[18] = (char *(*)()) F1092_8690;
	R7325[19] = (char *(*)()) F1093_8690;
	R7325[20] = (char *(*)()) F1094_8690;
	R7325[21] = (char *(*)()) F1095_8690;
	R7325[22] = (char *(*)()) F1096_8690;
	R7325[23] = (char *(*)()) F1097_8690;
	R7325[24] = (char *(*)()) F1098_8690;
	R7325[25] = (char *(*)()) F1099_8690;
	R7325[26] = (char *(*)()) F1100_8690;
	R7325[27] = (char *(*)()) F1101_8690;
	R7325[28] = (char *(*)()) F1102_8690;
	R7325[29] = (char *(*)()) F1103_8690;
	R7325[30] = (char *(*)()) F1104_8690;
	R7325[31] = (char *(*)()) F1105_8690;
	R7325[32] = (char *(*)()) F1106_8690;
	R7325[33] = (char *(*)()) F1107_8690;
}

char *(*R7330[34])();
void R7330_init () {
	R7330[0] = (char *(*)()) F1074_8696;
	R7330[1] = (char *(*)()) F1075_8696;
	R7330[2] = (char *(*)()) F1076_8696;
	R7330[3] = (char *(*)()) F1077_8696;
	R7330[4] = (char *(*)()) F1078_8696;
	R7330[5] = (char *(*)()) F1079_8696;
	R7330[6] = (char *(*)()) F1080_8696;
	R7330[7] = (char *(*)()) F1081_8696;
	R7330[8] = (char *(*)()) F1082_8696;
	R7330[9] = (char *(*)()) F1083_8696;
	R7330[10] = (char *(*)()) F1084_8696;
	R7330[11] = (char *(*)()) F1085_8696;
	R7330[12] = (char *(*)()) F1086_8696;
	R7330[13] = (char *(*)()) F1087_8696;
	R7330[14] = (char *(*)()) F1088_8696;
	R7330[15] = (char *(*)()) F1089_8696;
	R7330[16] = (char *(*)()) F1090_8696;
	R7330[17] = (char *(*)()) F1091_8696;
	R7330[18] = (char *(*)()) F1092_8696;
	R7330[19] = (char *(*)()) F1093_8696;
	R7330[20] = (char *(*)()) F1094_8696;
	R7330[21] = (char *(*)()) F1095_8696;
	R7330[22] = (char *(*)()) F1096_8696;
	R7330[23] = (char *(*)()) F1097_8696;
	R7330[24] = (char *(*)()) F1098_8696;
	R7330[25] = (char *(*)()) F1099_8696;
	R7330[26] = (char *(*)()) F1100_8696;
	R7330[27] = (char *(*)()) F1101_8696;
	R7330[28] = (char *(*)()) F1102_8696;
	R7330[29] = (char *(*)()) F1103_8696;
	R7330[30] = (char *(*)()) F1104_8696;
	R7330[31] = (char *(*)()) F1105_8696;
	R7330[32] = (char *(*)()) F1106_8696;
	R7330[33] = (char *(*)()) F1107_8696;
}

char *(*R7335[34])();
void R7335_init () {
	R7335[0] = (char *(*)()) F1074_8704;
	R7335[1] = (char *(*)()) F1075_8704_7335_1;
	R7335[2] = (char *(*)()) F1076_8704_7335_1;
	R7335[3] = (char *(*)()) F1077_8704_7335_1;
	R7335[4] = (char *(*)()) F1078_8704_7335_1;
	R7335[5] = (char *(*)()) F1079_8704_7335_1;
	R7335[6] = (char *(*)()) F1080_8704_7335_1;
	R7335[7] = (char *(*)()) F1081_8704_7335_1;
	R7335[8] = (char *(*)()) F1082_8704_7335_1;
	R7335[9] = (char *(*)()) F1083_8704_7335_1;
	R7335[10] = (char *(*)()) F1084_8704_7335_1;
	R7335[11] = (char *(*)()) F1085_8704_7335_1;
	R7335[12] = (char *(*)()) F1086_8704_7335_1;
	R7335[13] = (char *(*)()) F1087_8704_7335_1;
	R7335[14] = (char *(*)()) F1088_8704_7335_1;
	R7335[15] = (char *(*)()) F1089_8704_7335_1;
	R7335[16] = (char *(*)()) F1090_8704_7335_1;
	R7335[17] = (char *(*)()) F1091_8704;
	R7335[18] = (char *(*)()) F1092_8704;
	R7335[19] = (char *(*)()) F1093_8704;
	R7335[20] = (char *(*)()) F1094_8704_7335_1;
	R7335[21] = (char *(*)()) F1095_8704_7335_1;
	R7335[22] = (char *(*)()) F1096_8704_7335_1;
	R7335[23] = (char *(*)()) F1097_8704;
	R7335[24] = (char *(*)()) F1098_8704_7335_1;
	R7335[25] = (char *(*)()) F1099_8704_7335_1;
	R7335[26] = (char *(*)()) F1100_8704_7335_1;
	R7335[27] = (char *(*)()) F1101_8704_7335_1;
	R7335[28] = (char *(*)()) F1102_8704_7335_1;
	R7335[29] = (char *(*)()) F1103_8704_7335_1;
	R7335[30] = (char *(*)()) F1104_8704_7335_1;
	R7335[31] = (char *(*)()) F1105_8704_7335_1;
	R7335[32] = (char *(*)()) F1106_8704_7335_1;
	R7335[33] = (char *(*)()) F1107_8704_7335_1;
}
static EIF_REFERENCE F1075_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1075_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1076_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F1076_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1010,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1010, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1077_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1077_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1078_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1078_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1079_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1079_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1080_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1080_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1081_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1081_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1082_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1082_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1083_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1083_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1196, 0x00).id, 1196, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1084_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1084_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1193, 0x00).id, 1193, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1085_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1085_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1086_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1086_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1184, 0x00).id, 1184, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1087_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1087_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1088_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1088_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1089_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1089_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1090_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F1090_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1012,1208,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1012, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1094_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F1094_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1014,1205,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1014, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1095_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F1095_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1016,1199,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1016, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1096_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F1096_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1018,1004,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1018, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1098_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F1098_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1020,1040,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1020, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1099_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F1099_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1022,1211,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1022, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1100_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F1100_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1024,1202,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1024, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1101_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F1101_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1026,1190,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1026, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1102_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F1102_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1028,1187,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1028, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1103_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F1103_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1030,1196,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1030, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1104_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F1104_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1032,1193,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1032, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1105_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F1105_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1034,1001,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1034, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1106_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F1106_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1036,1007,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1036, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1107_8704_7335_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F1107_8704(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1038,1184,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}

char *(*R7345[34])();
void R7345_init () {
	R7345[0] = (char *(*)()) F1074_8716;
	R7345[1] = (char *(*)()) F1075_8716;
	R7345[2] = (char *(*)()) F1076_8716;
	R7345[3] = (char *(*)()) F1077_8716;
	R7345[4] = (char *(*)()) F1078_8716;
	R7345[5] = (char *(*)()) F1079_8716;
	R7345[6] = (char *(*)()) F1080_8716;
	R7345[7] = (char *(*)()) F1081_8716;
	R7345[8] = (char *(*)()) F1082_8716;
	R7345[9] = (char *(*)()) F1083_8716;
	R7345[10] = (char *(*)()) F1084_8716;
	R7345[11] = (char *(*)()) F1085_8716;
	R7345[12] = (char *(*)()) F1086_8716;
	R7345[13] = (char *(*)()) F1087_8716;
	R7345[14] = (char *(*)()) F1088_8716;
	R7345[15] = (char *(*)()) F1089_8716;
	R7345[16] = (char *(*)()) F1090_8716;
	R7345[17] = (char *(*)()) F1091_8716;
	R7345[18] = (char *(*)()) F1092_8716;
	R7345[19] = (char *(*)()) F1093_8716;
	R7345[20] = (char *(*)()) F1094_8716;
	R7345[21] = (char *(*)()) F1095_8716;
	R7345[22] = (char *(*)()) F1096_8716;
	R7345[23] = (char *(*)()) F1097_8716;
	R7345[24] = (char *(*)()) F1098_8716;
	R7345[25] = (char *(*)()) F1099_8716;
	R7345[26] = (char *(*)()) F1100_8716;
	R7345[27] = (char *(*)()) F1101_8716;
	R7345[28] = (char *(*)()) F1102_8716;
	R7345[29] = (char *(*)()) F1103_8716;
	R7345[30] = (char *(*)()) F1104_8716;
	R7345[31] = (char *(*)()) F1105_8716;
	R7345[32] = (char *(*)()) F1106_8716;
	R7345[33] = (char *(*)()) F1107_8716;
}

char *(*R7347[12])();
void R7347_init () {
	R7347[0] = (char *(*)()) F1109_8734;
	R7347[1] = (char *(*)()) F1110_8734;
	R7347[2] = (char *(*)()) F1111_8734;
	R7347[3] = (char *(*)()) F1112_8734;
	R7347[4] = (char *(*)()) F1113_8734;
	R7347[5] = (char *(*)()) F1114_8734;
	R7347[6] = (char *(*)()) F1115_8734;
	R7347[7] = (char *(*)()) F1116_8734;
	R7347[8] = (char *(*)()) F1117_8734;
	R7347[9] = (char *(*)()) F1118_8734;
	R7347[10] = (char *(*)()) F1119_8734;
	R7347[11] = (char *(*)()) F1120_8734;
}

char *(*R7348[12])();
void R7348_init () {
	R7348[0] = (char *(*)()) F1109_8735;
	R7348[1] = (char *(*)()) F1110_8735;
	R7348[2] = (char *(*)()) F1111_8735;
	R7348[3] = (char *(*)()) F1112_8735;
	R7348[4] = (char *(*)()) F1113_8735;
	R7348[5] = (char *(*)()) F1114_8735;
	R7348[6] = (char *(*)()) F1115_8735;
	R7348[7] = (char *(*)()) F1116_8735;
	R7348[8] = (char *(*)()) F1117_8735;
	R7348[9] = (char *(*)()) F1118_8735;
	R7348[10] = (char *(*)()) F1119_8735;
	R7348[11] = (char *(*)()) F1120_8735;
}

char *(*R7350[12])();
void R7350_init () {
	R7350[0] = (char *(*)()) F1109_8721;
	R7350[1] = (char *(*)()) F1110_8721;
	R7350[2] = (char *(*)()) F1111_8721;
	R7350[3] = (char *(*)()) F1112_8721;
	R7350[4] = (char *(*)()) F1113_8721;
	R7350[5] = (char *(*)()) F1114_8721;
	R7350[6] = (char *(*)()) F1115_8721;
	R7350[7] = (char *(*)()) F1116_8721;
	R7350[8] = (char *(*)()) F1117_8721;
	R7350[9] = (char *(*)()) F1118_8721;
	R7350[10] = (char *(*)()) F1119_8721;
	R7350[11] = (char *(*)()) F1120_8721;
}

char *(*R7351[12])();
void R7351_init () {
	R7351[0] = (char *(*)()) F1109_8722;
	R7351[1] = (char *(*)()) F1110_8722_7351_142;
	R7351[2] = (char *(*)()) F1111_8722_7351_142;
	R7351[3] = (char *(*)()) F1112_8722_7351_142;
	R7351[4] = (char *(*)()) F1113_8722_7351_142;
	R7351[5] = (char *(*)()) F1114_8722_7351_142;
	R7351[6] = (char *(*)()) F1115_8722_7351_142;
	R7351[7] = (char *(*)()) F1116_8722_7351_142;
	R7351[8] = (char *(*)()) F1117_8722_7351_142;
	R7351[9] = (char *(*)()) F1118_8722_7351_142;
	R7351[10] = (char *(*)()) F1119_8722_7351_142;
	R7351[11] = (char *(*)()) F1120_8722_7351_142;
}
static void F1110_8722_7351_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1110_8722(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1111_8722_7351_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1111_8722(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1112_8722_7351_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1112_8722(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1113_8722_7351_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1113_8722(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1114_8722_7351_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1114_8722(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1115_8722_7351_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1115_8722(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1116_8722_7351_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1116_8722(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1117_8722_7351_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1117_8722(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1118_8722_7351_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1118_8722(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1119_8722_7351_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1119_8722(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1120_8722_7351_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1120_8722(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7360[12])();
void R7360_init () {
	R7360[0] = (char *(*)()) F1109_8737;
	R7360[1] = (char *(*)()) F1110_8737;
	R7360[2] = (char *(*)()) F1111_8737;
	R7360[3] = (char *(*)()) F1112_8737;
	R7360[4] = (char *(*)()) F1113_8737;
	R7360[5] = (char *(*)()) F1114_8737;
	R7360[6] = (char *(*)()) F1115_8737;
	R7360[7] = (char *(*)()) F1116_8737;
	R7360[8] = (char *(*)()) F1117_8737;
	R7360[9] = (char *(*)()) F1118_8737;
	R7360[10] = (char *(*)()) F1119_8737;
	R7360[11] = (char *(*)()) F1120_8737;
}

char *(*R7361[12])();
void R7361_init () {
	R7361[0] = (char *(*)()) F1109_8739;
	R7361[1] = (char *(*)()) F1110_8739_7361_142;
	R7361[2] = (char *(*)()) F1111_8739_7361_142;
	R7361[3] = (char *(*)()) F1112_8739_7361_142;
	R7361[4] = (char *(*)()) F1113_8739_7361_142;
	R7361[5] = (char *(*)()) F1114_8739_7361_142;
	R7361[6] = (char *(*)()) F1115_8739_7361_142;
	R7361[7] = (char *(*)()) F1116_8739_7361_142;
	R7361[8] = (char *(*)()) F1117_8739_7361_142;
	R7361[9] = (char *(*)()) F1118_8739_7361_142;
	R7361[10] = (char *(*)()) F1119_8739_7361_142;
	R7361[11] = (char *(*)()) F1120_8739_7361_142;
}
static void F1110_8739_7361_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1110_8739(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1111_8739_7361_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1111_8739(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1112_8739_7361_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1112_8739(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1113_8739_7361_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1113_8739(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1114_8739_7361_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1114_8739(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1115_8739_7361_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1115_8739(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1116_8739_7361_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1116_8739(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1117_8739_7361_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1117_8739(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1118_8739_7361_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1118_8739(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1119_8739_7361_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1119_8739(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1120_8739_7361_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1120_8739(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7362[12])();
void R7362_init () {
	R7362[0] = (char *(*)()) F1109_8740;
	R7362[1] = (char *(*)()) F1110_8740_7362_142;
	R7362[2] = (char *(*)()) F1111_8740_7362_142;
	R7362[3] = (char *(*)()) F1112_8740_7362_142;
	R7362[4] = (char *(*)()) F1113_8740_7362_142;
	R7362[5] = (char *(*)()) F1114_8740_7362_142;
	R7362[6] = (char *(*)()) F1115_8740_7362_142;
	R7362[7] = (char *(*)()) F1116_8740_7362_142;
	R7362[8] = (char *(*)()) F1117_8740_7362_142;
	R7362[9] = (char *(*)()) F1118_8740_7362_142;
	R7362[10] = (char *(*)()) F1119_8740_7362_142;
	R7362[11] = (char *(*)()) F1120_8740_7362_142;
}
static void F1110_8740_7362_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1110_8740(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1111_8740_7362_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1111_8740(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1112_8740_7362_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1112_8740(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1113_8740_7362_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1113_8740(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1114_8740_7362_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1114_8740(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1115_8740_7362_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1115_8740(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1116_8740_7362_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1116_8740(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1117_8740_7362_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1117_8740(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1118_8740_7362_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1118_8740(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1119_8740_7362_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1119_8740(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1120_8740_7362_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1120_8740(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7363[12])();
void R7363_init () {
	R7363[0] = (char *(*)()) F1109_8741;
	R7363[1] = (char *(*)()) F1110_8741_7363_4;
	R7363[2] = (char *(*)()) F1111_8741_7363_4;
	R7363[3] = (char *(*)()) F1112_8741_7363_4;
	R7363[4] = (char *(*)()) F1113_8741_7363_4;
	R7363[5] = (char *(*)()) F1114_8741_7363_4;
	R7363[6] = (char *(*)()) F1115_8741_7363_4;
	R7363[7] = (char *(*)()) F1116_8741_7363_4;
	R7363[8] = (char *(*)()) F1117_8741_7363_4;
	R7363[9] = (char *(*)()) F1118_8741_7363_4;
	R7363[10] = (char *(*)()) F1119_8741_7363_4;
	R7363[11] = (char *(*)()) F1120_8741_7363_4;
}
static void F1110_8741_7363_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1110_8741(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1111_8741_7363_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1111_8741(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1112_8741_7363_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1112_8741(Current, *(EIF_POINTER *)arg1);
}
static void F1113_8741_7363_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1113_8741(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1114_8741_7363_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1114_8741(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F1115_8741_7363_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1115_8741(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1116_8741_7363_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1116_8741(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1117_8741_7363_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1117_8741(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F1118_8741_7363_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1118_8741(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F1119_8741_7363_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1119_8741(Current, *(EIF_REAL_32 *)arg1);
}
static void F1120_8741_7363_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1120_8741(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R7365[12])();
void R7365_init () {
	R7365[0] = (char *(*)()) F1109_8743;
	R7365[1] = (char *(*)()) F1110_8743_7365_56;
	R7365[2] = (char *(*)()) F1111_8743_7365_56;
	R7365[3] = (char *(*)()) F1112_8743_7365_56;
	R7365[4] = (char *(*)()) F1113_8743_7365_56;
	R7365[5] = (char *(*)()) F1114_8743_7365_56;
	R7365[6] = (char *(*)()) F1115_8743_7365_56;
	R7365[7] = (char *(*)()) F1116_8743_7365_56;
	R7365[8] = (char *(*)()) F1117_8743_7365_56;
	R7365[9] = (char *(*)()) F1118_8743_7365_56;
	R7365[10] = (char *(*)()) F1119_8743_7365_56;
	R7365[11] = (char *(*)()) F1120_8743_7365_56;
}
static void F1110_8743_7365_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1110_8743(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F1111_8743_7365_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1111_8743(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F1112_8743_7365_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1112_8743(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F1113_8743_7365_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1113_8743(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F1114_8743_7365_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1114_8743(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F1115_8743_7365_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1115_8743(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F1116_8743_7365_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1116_8743(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F1117_8743_7365_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1117_8743(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F1118_8743_7365_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1118_8743(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F1119_8743_7365_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1119_8743(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F1120_8743_7365_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1120_8743(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R7366[12])();
void R7366_init () {
	R7366[0] = (char *(*)()) F1109_8744;
	R7366[1] = (char *(*)()) F1110_8744;
	R7366[2] = (char *(*)()) F1111_8744;
	R7366[3] = (char *(*)()) F1112_8744;
	R7366[4] = (char *(*)()) F1113_8744;
	R7366[5] = (char *(*)()) F1114_8744;
	R7366[6] = (char *(*)()) F1115_8744;
	R7366[7] = (char *(*)()) F1116_8744;
	R7366[8] = (char *(*)()) F1117_8744;
	R7366[9] = (char *(*)()) F1118_8744;
	R7366[10] = (char *(*)()) F1119_8744;
	R7366[11] = (char *(*)()) F1120_8744;
}

char *(*R7368[12])();
void R7368_init () {
	R7368[0] = (char *(*)()) F1109_8746;
	R7368[1] = (char *(*)()) F1110_8746;
	R7368[2] = (char *(*)()) F1111_8746;
	R7368[3] = (char *(*)()) F1112_8746;
	R7368[4] = (char *(*)()) F1113_8746;
	R7368[5] = (char *(*)()) F1114_8746;
	R7368[6] = (char *(*)()) F1115_8746;
	R7368[7] = (char *(*)()) F1116_8746;
	R7368[8] = (char *(*)()) F1117_8746;
	R7368[9] = (char *(*)()) F1118_8746;
	R7368[10] = (char *(*)()) F1119_8746;
	R7368[11] = (char *(*)()) F1120_8746;
}

char *(*R7369[12])();
void R7369_init () {
	R7369[0] = (char *(*)()) F1109_8747;
	R7369[1] = (char *(*)()) F1110_8747;
	R7369[2] = (char *(*)()) F1111_8747;
	R7369[3] = (char *(*)()) F1112_8747;
	R7369[4] = (char *(*)()) F1113_8747;
	R7369[5] = (char *(*)()) F1114_8747;
	R7369[6] = (char *(*)()) F1115_8747;
	R7369[7] = (char *(*)()) F1116_8747;
	R7369[8] = (char *(*)()) F1117_8747;
	R7369[9] = (char *(*)()) F1118_8747;
	R7369[10] = (char *(*)()) F1119_8747;
	R7369[11] = (char *(*)()) F1120_8747;
}

char *(*R7370[12])();
void R7370_init () {
	R7370[0] = (char *(*)()) F1109_8748;
	R7370[1] = (char *(*)()) F1110_8748;
	R7370[2] = (char *(*)()) F1111_8748;
	R7370[3] = (char *(*)()) F1112_8748;
	R7370[4] = (char *(*)()) F1113_8748;
	R7370[5] = (char *(*)()) F1114_8748;
	R7370[6] = (char *(*)()) F1115_8748;
	R7370[7] = (char *(*)()) F1116_8748;
	R7370[8] = (char *(*)()) F1117_8748;
	R7370[9] = (char *(*)()) F1118_8748;
	R7370[10] = (char *(*)()) F1119_8748;
	R7370[11] = (char *(*)()) F1120_8748;
}

char *(*R7371[12])();
void R7371_init () {
	R7371[0] = (char *(*)()) F1109_8749;
	R7371[1] = (char *(*)()) F1110_8749;
	R7371[2] = (char *(*)()) F1111_8749;
	R7371[3] = (char *(*)()) F1112_8749;
	R7371[4] = (char *(*)()) F1113_8749;
	R7371[5] = (char *(*)()) F1114_8749;
	R7371[6] = (char *(*)()) F1115_8749;
	R7371[7] = (char *(*)()) F1116_8749;
	R7371[8] = (char *(*)()) F1117_8749;
	R7371[9] = (char *(*)()) F1118_8749;
	R7371[10] = (char *(*)()) F1119_8749;
	R7371[11] = (char *(*)()) F1120_8749;
}

char *(*R7372[12])();
void R7372_init () {
	R7372[0] = (char *(*)()) F1109_8750;
	R7372[1] = (char *(*)()) F1110_8750;
	R7372[2] = (char *(*)()) F1111_8750;
	R7372[3] = (char *(*)()) F1112_8750;
	R7372[4] = (char *(*)()) F1113_8750;
	R7372[5] = (char *(*)()) F1114_8750;
	R7372[6] = (char *(*)()) F1115_8750;
	R7372[7] = (char *(*)()) F1116_8750;
	R7372[8] = (char *(*)()) F1117_8750;
	R7372[9] = (char *(*)()) F1118_8750;
	R7372[10] = (char *(*)()) F1119_8750;
	R7372[11] = (char *(*)()) F1120_8750;
}

char *(*R7375[12])();
void R7375_init () {
	R7375[0] = (char *(*)()) F1109_8753;
	R7375[1] = (char *(*)()) F1110_8753;
	R7375[2] = (char *(*)()) F1111_8753;
	R7375[3] = (char *(*)()) F1112_8753;
	R7375[4] = (char *(*)()) F1113_8753;
	R7375[5] = (char *(*)()) F1114_8753;
	R7375[6] = (char *(*)()) F1115_8753;
	R7375[7] = (char *(*)()) F1116_8753;
	R7375[8] = (char *(*)()) F1117_8753;
	R7375[9] = (char *(*)()) F1118_8753;
	R7375[10] = (char *(*)()) F1119_8753;
	R7375[11] = (char *(*)()) F1120_8753;
}

char *(*R7378[12])();
void R7378_init () {
	R7378[0] = (char *(*)()) F1109_8756;
	R7378[1] = (char *(*)()) F1110_8756;
	R7378[2] = (char *(*)()) F1111_8756;
	R7378[3] = (char *(*)()) F1112_8756;
	R7378[4] = (char *(*)()) F1113_8756;
	R7378[5] = (char *(*)()) F1114_8756;
	R7378[6] = (char *(*)()) F1115_8756;
	R7378[7] = (char *(*)()) F1116_8756;
	R7378[8] = (char *(*)()) F1117_8756;
	R7378[9] = (char *(*)()) F1118_8756;
	R7378[10] = (char *(*)()) F1119_8756;
	R7378[11] = (char *(*)()) F1120_8756;
}

char *(*R7379[12])();
void R7379_init () {
	R7379[0] = (char *(*)()) F1109_8757;
	R7379[1] = (char *(*)()) F1110_8757_7379_8;
	R7379[2] = (char *(*)()) F1111_8757_7379_8;
	R7379[3] = (char *(*)()) F1112_8757_7379_8;
	R7379[4] = (char *(*)()) F1113_8757_7379_8;
	R7379[5] = (char *(*)()) F1114_8757_7379_8;
	R7379[6] = (char *(*)()) F1115_8757_7379_8;
	R7379[7] = (char *(*)()) F1116_8757_7379_8;
	R7379[8] = (char *(*)()) F1117_8757_7379_8;
	R7379[9] = (char *(*)()) F1118_8757_7379_8;
	R7379[10] = (char *(*)()) F1119_8757_7379_8;
	R7379[11] = (char *(*)()) F1120_8757_7379_8;
}
static EIF_REFERENCE F1110_8757_7379_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1110_8757(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F1111_8757_7379_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1111_8757(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F1112_8757_7379_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1112_8757(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F1113_8757_7379_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1113_8757(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F1114_8757_7379_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1114_8757(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F1115_8757_7379_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1115_8757(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F1116_8757_7379_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1116_8757(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F1117_8757_7379_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1117_8757(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F1118_8757_7379_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1118_8757(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F1119_8757_7379_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1119_8757(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F1120_8757_7379_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1120_8757(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7381[12])();
void R7381_init () {
	R7381[0] = (char *(*)()) F1109_8759;
	R7381[1] = (char *(*)()) F1110_8759;
	R7381[2] = (char *(*)()) F1111_8759;
	R7381[3] = (char *(*)()) F1112_8759;
	R7381[4] = (char *(*)()) F1113_8759;
	R7381[5] = (char *(*)()) F1114_8759;
	R7381[6] = (char *(*)()) F1115_8759;
	R7381[7] = (char *(*)()) F1116_8759;
	R7381[8] = (char *(*)()) F1117_8759;
	R7381[9] = (char *(*)()) F1118_8759;
	R7381[10] = (char *(*)()) F1119_8759;
	R7381[11] = (char *(*)()) F1120_8759;
}

char *(*R7383[12])();
void R7383_init () {
	R7383[0] = (char *(*)()) F1109_8761;
	R7383[1] = (char *(*)()) F1110_8761;
	R7383[2] = (char *(*)()) F1111_8761;
	R7383[3] = (char *(*)()) F1112_8761;
	R7383[4] = (char *(*)()) F1113_8761;
	R7383[5] = (char *(*)()) F1114_8761;
	R7383[6] = (char *(*)()) F1115_8761;
	R7383[7] = (char *(*)()) F1116_8761;
	R7383[8] = (char *(*)()) F1117_8761;
	R7383[9] = (char *(*)()) F1118_8761;
	R7383[10] = (char *(*)()) F1119_8761;
	R7383[11] = (char *(*)()) F1120_8761;
}

char *(*R7386[12])();
void R7386_init () {
	R7386[0] = (char *(*)()) F1109_8764;
	R7386[1] = (char *(*)()) F1110_8764;
	R7386[2] = (char *(*)()) F1111_8764;
	R7386[3] = (char *(*)()) F1112_8764;
	R7386[4] = (char *(*)()) F1113_8764;
	R7386[5] = (char *(*)()) F1114_8764;
	R7386[6] = (char *(*)()) F1115_8764;
	R7386[7] = (char *(*)()) F1116_8764;
	R7386[8] = (char *(*)()) F1117_8764;
	R7386[9] = (char *(*)()) F1118_8764;
	R7386[10] = (char *(*)()) F1119_8764;
	R7386[11] = (char *(*)()) F1120_8764;
}

char *(*R7390[12])();
void R7390_init () {
	R7390[0] = (char *(*)()) F1109_8769;
	R7390[1] = (char *(*)()) F1110_8769;
	R7390[2] = (char *(*)()) F1111_8769;
	R7390[3] = (char *(*)()) F1112_8769;
	R7390[4] = (char *(*)()) F1113_8769;
	R7390[5] = (char *(*)()) F1114_8769;
	R7390[6] = (char *(*)()) F1115_8769;
	R7390[7] = (char *(*)()) F1116_8769;
	R7390[8] = (char *(*)()) F1117_8769;
	R7390[9] = (char *(*)()) F1118_8769;
	R7390[10] = (char *(*)()) F1119_8769;
	R7390[11] = (char *(*)()) F1120_8769;
}

char *(*R7394[7])();
void R7394_init () {
	{long i; for (i = 0; i < 3; i++) R7394[i] = (char *(*)()) F1121_8773;}
	R7394[4] = (char *(*)()) F1128_8909;
	{long i; for (i = 5; i < 7; i++) R7394[i] = (char *(*)()) F1121_8773;}
}

char *(*R7396[7])();
void R7396_init () {
	{long i; for (i = 0; i < 3; i++) R7396[i] = (char *(*)()) F1121_8775;}
	R7396[4] = (char *(*)()) F1121_8775;
	{long i; for (i = 5; i < 7; i++) R7396[i] = (char *(*)()) F1129_8937;}
}

char *(*R7398[7])();
void R7398_init () {
	{long i; for (i = 0; i < 3; i++) R7398[i] = (char *(*)()) F1121_8777;}
	R7398[4] = (char *(*)()) F1128_8910;
	{long i; for (i = 5; i < 7; i++) R7398[i] = (char *(*)()) F1121_8777;}
}

char *(*R7401[7])();
void R7401_init () {
	R7401[0] = (char *(*)()) F1121_8780;
	R7401[1] = (char *(*)()) F1125_8891;
	R7401[2] = (char *(*)()) F1121_8780;
	{long i; for (i = 4; i < 7; i++) R7401[i] = (char *(*)()) F1121_8780;}
}

char *(*R7409[7])();
void R7409_init () {
	{long i; for (i = 0; i < 3; i++) R7409[i] = (char *(*)()) F1124_8867;}
	R7409[4] = (char *(*)()) F1128_8913;
	{long i; for (i = 5; i < 7; i++) R7409[i] = (char *(*)()) F1129_8938;}
}

char *(*R7421[7])();
void R7421_init () {
	{long i; for (i = 0; i < 3; i++) R7421[i] = (char *(*)()) F1124_8863;}
	R7421[4] = (char *(*)()) F1128_8922;
	{long i; for (i = 5; i < 7; i++) R7421[i] = (char *(*)()) F1129_8943;}
}

char *(*R7422[7])();
void R7422_init () {
	{long i; for (i = 0; i < 3; i++) R7422[i] = (char *(*)()) F1124_8864;}
	R7422[4] = (char *(*)()) F1128_8923;
	{long i; for (i = 5; i < 7; i++) R7422[i] = (char *(*)()) F1121_8802;}
}

char *(*R7568[37])();
void R7568_init () {
	R7568[0] = (char *(*)()) F1178_9037;
	R7568[1] = (char *(*)()) F1179_9042;
	R7568[2] = (char *(*)()) F1180_9056;
	R7568[3] = (char *(*)()) F1181_9086;
	R7568[35] = (char *(*)()) F1213_10023;
	R7568[36] = (char *(*)()) F1214_10066;
}

char *(*R7646[2])();
void R7646_init () {
	R7646[0] = (char *(*)()) F1184_9194;
	R7646[1] = (char *(*)()) F1185_9194;
}

char *(*R7647[2])();
void R7647_init () {
	R7647[0] = (char *(*)()) F1184_9195;
	R7647[1] = (char *(*)()) F1185_9195;
}

char *(*R7650[2])();
void R7650_init () {
	R7650[0] = (char *(*)()) F1184_9198;
	R7650[1] = (char *(*)()) F1185_9198;
}

char *(*R7700[2])();
void R7700_init () {
	R7700[0] = (char *(*)()) F1187_9291;
	R7700[1] = (char *(*)()) F1188_9291;
}

char *(*R7702[2])();
void R7702_init () {
	R7702[0] = (char *(*)()) F1187_9293;
	R7702[1] = (char *(*)()) F1188_9293;
}

char *(*R7703[2])();
void R7703_init () {
	R7703[0] = (char *(*)()) F1187_9294;
	R7703[1] = (char *(*)()) F1188_9294;
}

char *(*R7707[2])();
void R7707_init () {
	R7707[0] = (char *(*)()) F1187_9298;
	R7707[1] = (char *(*)()) F1188_9298;
}

char *(*R7759[2])();
void R7759_init () {
	R7759[0] = (char *(*)()) F1190_9393;
	R7759[1] = (char *(*)()) F1191_9393;
}

char *(*R7762[2])();
void R7762_init () {
	R7762[0] = (char *(*)()) F1190_9396;
	R7762[1] = (char *(*)()) F1191_9396;
}

char *(*R7812[2])();
void R7812_init () {
	R7812[0] = (char *(*)()) F1193_9489;
	R7812[1] = (char *(*)()) F1194_9489;
}

char *(*R7815[2])();
void R7815_init () {
	R7815[0] = (char *(*)()) F1193_9492;
	R7815[1] = (char *(*)()) F1194_9492;
}

char *(*R7818[2])();
void R7818_init () {
	R7818[0] = (char *(*)()) F1193_9495;
	R7818[1] = (char *(*)()) F1194_9495;
}

char *(*R7872[2])();
void R7872_init () {
	R7872[0] = (char *(*)()) F1196_9589;
	R7872[1] = (char *(*)()) F1197_9589;
}

char *(*R7918[2])();
void R7918_init () {
	R7918[0] = (char *(*)()) F1199_9677;
	R7918[1] = (char *(*)()) F1200_9677;
}

char *(*R7919[2])();
void R7919_init () {
	R7919[0] = (char *(*)()) F1199_9678;
	R7919[1] = (char *(*)()) F1200_9678;
}

char *(*R7921[2])();
void R7921_init () {
	R7921[0] = (char *(*)()) F1199_9680;
	R7921[1] = (char *(*)()) F1200_9680;
}

char *(*R7924[2])();
void R7924_init () {
	R7924[0] = (char *(*)()) F1199_9683;
	R7924[1] = (char *(*)()) F1200_9683;
}

char *(*R7925[2])();
void R7925_init () {
	R7925[0] = (char *(*)()) F1199_9684;
	R7925[1] = (char *(*)()) F1200_9684;
}

char *(*R7973[2])();
void R7973_init () {
	R7973[0] = (char *(*)()) F1202_9774;
	R7973[1] = (char *(*)()) F1203_9774;
}

char *(*R7974[2])();
void R7974_init () {
	R7974[0] = (char *(*)()) F1202_9775;
	R7974[1] = (char *(*)()) F1203_9775;
}

char *(*R7977[2])();
void R7977_init () {
	R7977[0] = (char *(*)()) F1202_9778;
	R7977[1] = (char *(*)()) F1203_9778;
}

char *(*R8025[2])();
void R8025_init () {
	R8025[0] = (char *(*)()) F1205_9868;
	R8025[1] = (char *(*)()) F1206_9868;
}

char *(*R8026[2])();
void R8026_init () {
	R8026[0] = (char *(*)()) F1205_9869;
	R8026[1] = (char *(*)()) F1206_9869;
}

char *(*R8027[2])();
void R8027_init () {
	R8027[0] = (char *(*)()) F1205_9870;
	R8027[1] = (char *(*)()) F1206_9870;
}

char *(*R8028[2])();
void R8028_init () {
	R8028[0] = (char *(*)()) F1205_9871;
	R8028[1] = (char *(*)()) F1206_9871;
}

char *(*R8030[2])();
void R8030_init () {
	R8030[0] = (char *(*)()) F1205_9873;
	R8030[1] = (char *(*)()) F1206_9873;
}

char *(*R8076[2])();
void R8076_init () {
	R8076[0] = (char *(*)()) F1208_9931;
	R8076[1] = (char *(*)()) F1209_9931;
}

char *(*R8110[2])();
void R8110_init () {
	R8110[0] = (char *(*)()) F1211_9997;
	R8110[1] = (char *(*)()) F1212_9997;
}

char *(*R8275[3])();
void R8275_init () {
	R8275[0] = (char *(*)()) F1227_10225;
	R8275[1] = (char *(*)()) F1228_10225;
	R8275[2] = (char *(*)()) F1229_10225;
}

char *(*R8277[3])();
void R8277_init () {
	R8277[0] = (char *(*)()) F1227_10227;
	R8277[1] = (char *(*)()) F1228_10227_8277_2;
	R8277[2] = (char *(*)()) F1229_10227_8277_2;
}
static EIF_BOOLEAN F1228_10227_8277_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1228_10227(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1229_10227_8277_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1229_10227(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R8282[3])();
void R8282_init () {
	R8282[0] = (char *(*)()) F1227_10232;
	R8282[1] = (char *(*)()) F1228_10232_8282_1;
	R8282[2] = (char *(*)()) F1229_10232_8282_1;
}
static EIF_REFERENCE F1228_10232_8282_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1228_10232(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1229_10232_8282_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1229_10232(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R8286[3])();
void R8286_init () {
	R8286[0] = (char *(*)()) F1227_10238;
	R8286[1] = (char *(*)()) F1228_10238_8286_3;
	R8286[2] = (char *(*)()) F1229_10238_8286_3;
}
static EIF_BOOLEAN F1228_10238_8286_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F1228_10238(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_CHARACTER_32 *)arg2);
}
static EIF_BOOLEAN F1229_10238_8286_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F1229_10238(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R8287[3])();
void R8287_init () {
	R8287[0] = (char *(*)()) F1227_10239;
	R8287[1] = (char *(*)()) F1228_10239_8287_4;
	R8287[2] = (char *(*)()) F1229_10239_8287_4;
}
static void F1228_10239_8287_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1228_10239(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1229_10239_8287_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1229_10239(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R8295[3])();
void R8295_init () {
	R8295[0] = (char *(*)()) F1227_10247;
	R8295[1] = (char *(*)()) F1228_10247;
	R8295[2] = (char *(*)()) F1229_10247;
}

char *(*R8297[3])();
void R8297_init () {
	R8297[0] = (char *(*)()) F1227_10250;
	R8297[1] = (char *(*)()) F1228_10250;
	R8297[2] = (char *(*)()) F1229_10250;
}

char *(*R8300[3])();
void R8300_init () {
	R8300[0] = (char *(*)()) F1227_10253;
	R8300[1] = (char *(*)()) F1228_10253_8300_4;
	R8300[2] = (char *(*)()) F1229_10253_8300_4;
}
static void F1228_10253_8300_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1228_10253(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1229_10253_8300_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1229_10253(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R8301[3])();
void R8301_init () {
	R8301[0] = (char *(*)()) F1227_10254;
	R8301[1] = (char *(*)()) F1228_10254;
	R8301[2] = (char *(*)()) F1229_10254;
}

char *(*R8303[3])();
void R8303_init () {
	R8303[0] = (char *(*)()) F1227_10256;
	R8303[1] = (char *(*)()) F1228_10256;
	R8303[2] = (char *(*)()) F1229_10256;
}

char *(*R8304[3])();
void R8304_init () {
	R8304[0] = (char *(*)()) F1227_10257;
	R8304[1] = (char *(*)()) F1228_10257_8304_2;
	R8304[2] = (char *(*)()) F1229_10257_8304_2;
}
static EIF_BOOLEAN F1228_10257_8304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1228_10257(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1229_10257_8304_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1229_10257(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R8318[3])();
void R8318_init () {
	R8318[0] = (char *(*)()) F1227_10271;
	R8318[1] = (char *(*)()) F1228_10271;
	R8318[2] = (char *(*)()) F1229_10271;
}

char *(*R8319[3])();
void R8319_init () {
	R8319[0] = (char *(*)()) F1227_10272;
	R8319[1] = (char *(*)()) F1228_10272;
	R8319[2] = (char *(*)()) F1229_10272;
}

char *(*R8739[3])();
void R8739_init () {
	R8739[0] = (char *(*)()) F1251_10786;
	{long i; for (i = 1; i < 3; i++) R8739[i] = (char *(*)()) F1252_10814;}
}

char *(*R8744[3])();
void R8744_init () {
	R8744[0] = (char *(*)()) F1251_10787;
	{long i; for (i = 1; i < 3; i++) R8744[i] = (char *(*)()) F1252_10809;}
}

char *(*R8746[3])();
void R8746_init () {
	R8746[0] = (char *(*)()) F1251_10788;
	{long i; for (i = 1; i < 3; i++) R8746[i] = (char *(*)()) F1252_10810;}
}

char *(*R10029[3])();
void R10029_init () {
	{long i; for (i = 0; i < 2; i++) R10029[i] = (char *(*)()) F1299_12268;}
	R10029[2] = (char *(*)()) F1301_12336;
}
char *(*R2[1315])();
void R2_init () {}
char *(*R6[1315])();
void R6_init () {}

char *(*R3[1315])();
void R3_init () {
	R3[336] = (char *(*)()) F337_3892;
	R3[394] = (char *(*)()) F395_4854;
	R3[424] = (char *(*)()) F425_5220;
	{long i; for (i = 772; i < 774; i++) R3[i] = (char *(*)()) F411_5145;}
	R3[1224] = (char *(*)()) F1225_10129;
	R3[1276] = (char *(*)()) F411_5145;
}

char *(*R4[1315])();
void R4_init () {
	{long i; for (i = 1; i < 4; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 5; i < 14; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 15; i < 18; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 19; i < 26; i++) R4[i] = (char *(*)()) F1_15;}
	R4[27] = (char *(*)()) F1_15;
	{long i; for (i = 30; i < 38; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 39; i < 41; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 42; i < 56; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 57; i < 63; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 65; i < 68; i++) R4[i] = (char *(*)()) F1_15;}
	R4[80] = (char *(*)()) F1_15;
	R4[85] = (char *(*)()) F1_15;
	R4[99] = (char *(*)()) F1_15;
	R4[103] = (char *(*)()) F1_15;
	R4[110] = (char *(*)()) F1_15;
	R4[124] = (char *(*)()) F1_15;
	R4[126] = (char *(*)()) F1_15;
	R4[134] = (char *(*)()) F1_15;
	R4[140] = (char *(*)()) F1_15;
	{long i; for (i = 142; i < 144; i++) R4[i] = (char *(*)()) F1_15;}
	R4[146] = (char *(*)()) F1_15;
	R4[148] = (char *(*)()) F1_15;
	R4[158] = (char *(*)()) F1_15;
	R4[161] = (char *(*)()) F1_15;
	{long i; for (i = 165; i < 167; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 169; i < 179; i++) R4[i] = (char *(*)()) F1_15;}
	R4[180] = (char *(*)()) F1_15;
	{long i; for (i = 183; i < 185; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 186; i < 188; i++) R4[i] = (char *(*)()) F1_15;}
	R4[194] = (char *(*)()) F1_15;
	R4[205] = (char *(*)()) F1_15;
	{long i; for (i = 207; i < 209; i++) R4[i] = (char *(*)()) F1_15;}
	R4[215] = (char *(*)()) F1_15;
	R4[222] = (char *(*)()) F1_15;
	R4[224] = (char *(*)()) F1_15;
	{long i; for (i = 229; i < 231; i++) R4[i] = (char *(*)()) F1_15;}
	R4[234] = (char *(*)()) F1_15;
	{long i; for (i = 236; i < 238; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 244; i < 248; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 249; i < 252; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 253; i < 256; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 259; i < 261; i++) R4[i] = (char *(*)()) F1_15;}
	R4[263] = (char *(*)()) F1_15;
	R4[270] = (char *(*)()) F1_15;
	{long i; for (i = 272; i < 274; i++) R4[i] = (char *(*)()) F1_15;}
	R4[277] = (char *(*)()) F1_15;
	{long i; for (i = 281; i < 283; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 284; i < 286; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 288; i < 290; i++) R4[i] = (char *(*)()) F1_15;}
	R4[292] = (char *(*)()) F1_15;
	{long i; for (i = 294; i < 300; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 301; i < 304; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 305; i < 307; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 309; i < 311; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 312; i < 315; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 316; i < 320; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 321; i < 323; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 324; i < 330; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 331; i < 335; i++) R4[i] = (char *(*)()) F1_15;}
	R4[336] = (char *(*)()) F337_3811;
	R4[340] = (char *(*)()) F1_15;
	R4[348] = (char *(*)()) F1_15;
	R4[354] = (char *(*)()) F1_15;
	{long i; for (i = 359; i < 361; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 368; i < 370; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 371; i < 378; i++) R4[i] = (char *(*)()) F1_15;}
	R4[391] = (char *(*)()) F1_15;
	R4[392] = (char *(*)()) F393_4804;
	{long i; for (i = 394; i < 397; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 400; i < 402; i++) R4[i] = (char *(*)()) F1_15;}
	R4[403] = (char *(*)()) F1_15;
	{long i; for (i = 408; i < 410; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 423; i < 428; i++) R4[i] = (char *(*)()) F1_15;}
	R4[452] = (char *(*)()) F1_15;
	{long i; for (i = 478; i < 500; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 512; i < 550; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 703; i < 705; i++) R4[i] = (char *(*)()) F1_15;}
	R4[744] = (char *(*)()) F745_5618;
	{long i; for (i = 772; i < 774; i++) R4[i] = (char *(*)()) F1_15;}
	R4[782] = (char *(*)()) F1_15;
	R4[795] = (char *(*)()) F796_6069;
	R4[796] = (char *(*)()) F797_6069;
	R4[797] = (char *(*)()) F798_6069;
	R4[798] = (char *(*)()) F799_6069;
	R4[799] = (char *(*)()) F800_6069;
	R4[800] = (char *(*)()) F801_6069;
	R4[801] = (char *(*)()) F802_6069;
	R4[802] = (char *(*)()) F803_6069;
	{long i; for (i = 803; i < 805; i++) R4[i] = (char *(*)()) F796_6069;}
	R4[805] = (char *(*)()) F800_6069;
	R4[806] = (char *(*)()) F799_6069;
	R4[807] = (char *(*)()) F801_6069;
	R4[808] = (char *(*)()) F803_6069;
	R4[821] = (char *(*)()) F822_6171;
	R4[822] = (char *(*)()) F823_6236;
	R4[823] = (char *(*)()) F824_6236;
	R4[824] = (char *(*)()) F825_6236;
	R4[825] = (char *(*)()) F826_6236;
	R4[826] = (char *(*)()) F827_6236;
	R4[827] = (char *(*)()) F828_6236;
	R4[828] = (char *(*)()) F829_6236;
	R4[829] = (char *(*)()) F830_6236;
	R4[830] = (char *(*)()) F831_6236;
	R4[831] = (char *(*)()) F832_6236;
	R4[832] = (char *(*)()) F833_6236;
	R4[833] = (char *(*)()) F834_6236;
	R4[887] = (char *(*)()) F888_6329;
	R4[888] = (char *(*)()) F889_6329;
	R4[889] = (char *(*)()) F888_6329;
	R4[890] = (char *(*)()) F889_6329;
	R4[891] = (char *(*)()) F888_6329;
	R4[892] = (char *(*)()) F893_6413;
	R4[893] = (char *(*)()) F894_6413;
	R4[894] = (char *(*)()) F895_6413;
	R4[895] = (char *(*)()) F896_6413;
	R4[896] = (char *(*)()) F897_6413;
	R4[897] = (char *(*)()) F898_6413;
	R4[898] = (char *(*)()) F899_6413;
	R4[899] = (char *(*)()) F900_6413;
	R4[900] = (char *(*)()) F901_6413;
	R4[901] = (char *(*)()) F902_6413;
	R4[902] = (char *(*)()) F903_6413;
	R4[903] = (char *(*)()) F904_6413;
	{long i; for (i = 904; i < 906; i++) R4[i] = (char *(*)()) F893_6413;}
	R4[906] = (char *(*)()) F894_6413;
	{long i; for (i = 907; i < 909; i++) R4[i] = (char *(*)()) F893_6413;}
	R4[910] = (char *(*)()) F1_15;
	{long i; for (i = 912; i < 914; i++) R4[i] = (char *(*)()) F1_15;}
	R4[914] = (char *(*)()) F915_6727;
	R4[915] = (char *(*)()) F916_6763;
	{long i; for (i = 924; i < 931; i++) R4[i] = (char *(*)()) F1_15;}
	R4[932] = (char *(*)()) F1_15;
	{long i; for (i = 934; i < 936; i++) R4[i] = (char *(*)()) F1_15;}
	R4[944] = (char *(*)()) F1_15;
	{long i; for (i = 950; i < 958; i++) R4[i] = (char *(*)()) F1_15;}
	R4[959] = (char *(*)()) F1_15;
	{long i; for (i = 964; i < 966; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 968; i < 979; i++) R4[i] = (char *(*)()) F1_15;}
	R4[979] = (char *(*)()) F893_6413;
	R4[980] = (char *(*)()) F1_15;
	{long i; for (i = 982; i < 987; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 988; i < 994; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 996; i < 998; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1000; i < 1002; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1003; i < 1005; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1006; i < 1008; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1009; i < 1041; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1042] = (char *(*)()) F1042_7647;
	R4[1043] = (char *(*)()) F1044_7679;
	R4[1044] = (char *(*)()) F1045_7679;
	R4[1045] = (char *(*)()) F1046_7679;
	R4[1046] = (char *(*)()) F1045_7679;
	R4[1051] = (char *(*)()) F1052_7871;
	{long i; for (i = 1052; i < 1054; i++) R4[i] = (char *(*)()) F1051_7855;}
	R4[1056] = (char *(*)()) F1057_8042;
	R4[1057] = (char *(*)()) F1056_8023;
	{long i; for (i = 1060; i < 1067; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1069; i < 1072; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1072] = (char *(*)()) F1073_8663;
	{long i; for (i = 1073; i < 1107; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1108; i < 1120; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1123; i < 1126; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1127; i < 1130; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1177; i < 1181; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1183; i < 1185; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1186; i < 1188; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1189; i < 1191; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1192; i < 1194; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1195; i < 1197; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1198; i < 1200; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1201; i < 1203; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1204; i < 1206; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1207; i < 1209; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1210; i < 1226; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1226] = (char *(*)()) F1227_10249;
	R4[1227] = (char *(*)()) F1228_10249;
	R4[1228] = (char *(*)()) F1229_10249;
	R4[1246] = (char *(*)()) F1_15;
	{long i; for (i = 1250; i < 1253; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1254; i < 1256; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1258] = (char *(*)()) F1_15;
	{long i; for (i = 1260; i < 1262; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1263] = (char *(*)()) F1_15;
	R4[1276] = (char *(*)()) F1_15;
	{long i; for (i = 1278; i < 1282; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1289; i < 1291; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1298; i < 1302; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1303] = (char *(*)()) F1_15;
	R4[1310] = (char *(*)()) F1_15;
	R4[1313] = (char *(*)()) F1314_13155;
}

char *(*R5[1315])();
void R5_init () {
	{long i; for (i = 1; i < 4; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 5; i < 14; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 15; i < 18; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 19; i < 26; i++) R5[i] = (char *(*)()) F1_8;}
	R5[27] = (char *(*)()) F1_8;
	{long i; for (i = 30; i < 38; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 39; i < 41; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 42; i < 56; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 57; i < 61; i++) R5[i] = (char *(*)()) F1_8;}
	R5[61] = (char *(*)()) F62_955;
	R5[62] = (char *(*)()) F1_8;
	{long i; for (i = 65; i < 68; i++) R5[i] = (char *(*)()) F1_8;}
	R5[80] = (char *(*)()) F1_8;
	R5[85] = (char *(*)()) F1_8;
	R5[99] = (char *(*)()) F1_8;
	R5[103] = (char *(*)()) F1_8;
	R5[110] = (char *(*)()) F1_8;
	R5[124] = (char *(*)()) F1_8;
	R5[126] = (char *(*)()) F1_8;
	R5[134] = (char *(*)()) F1_8;
	R5[140] = (char *(*)()) F1_8;
	{long i; for (i = 142; i < 144; i++) R5[i] = (char *(*)()) F1_8;}
	R5[146] = (char *(*)()) F1_8;
	R5[148] = (char *(*)()) F1_8;
	R5[158] = (char *(*)()) F1_8;
	R5[161] = (char *(*)()) F1_8;
	{long i; for (i = 165; i < 167; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 169; i < 179; i++) R5[i] = (char *(*)()) F1_8;}
	R5[180] = (char *(*)()) F1_8;
	{long i; for (i = 183; i < 185; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 186; i < 188; i++) R5[i] = (char *(*)()) F1_8;}
	R5[194] = (char *(*)()) F1_8;
	R5[205] = (char *(*)()) F1_8;
	{long i; for (i = 207; i < 209; i++) R5[i] = (char *(*)()) F1_8;}
	R5[215] = (char *(*)()) F1_8;
	R5[222] = (char *(*)()) F1_8;
	R5[224] = (char *(*)()) F1_8;
	{long i; for (i = 229; i < 231; i++) R5[i] = (char *(*)()) F1_8;}
	R5[234] = (char *(*)()) F1_8;
	{long i; for (i = 236; i < 238; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 244; i < 248; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 249; i < 252; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 253; i < 256; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 259; i < 261; i++) R5[i] = (char *(*)()) F1_8;}
	R5[263] = (char *(*)()) F1_8;
	R5[270] = (char *(*)()) F1_8;
	{long i; for (i = 272; i < 274; i++) R5[i] = (char *(*)()) F1_8;}
	R5[277] = (char *(*)()) F1_8;
	{long i; for (i = 281; i < 283; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 284; i < 286; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 288; i < 290; i++) R5[i] = (char *(*)()) F1_8;}
	R5[292] = (char *(*)()) F1_8;
	{long i; for (i = 294; i < 300; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 301; i < 304; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 305; i < 307; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 309; i < 311; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 312; i < 315; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 316; i < 320; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 321; i < 323; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 324; i < 330; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 331; i < 335; i++) R5[i] = (char *(*)()) F1_8;}
	R5[336] = (char *(*)()) F337_3810;
	R5[340] = (char *(*)()) F1_8;
	R5[348] = (char *(*)()) F348_4193;
	R5[354] = (char *(*)()) F1_8;
	{long i; for (i = 359; i < 361; i++) R5[i] = (char *(*)()) F1_8;}
	R5[368] = (char *(*)()) F1_8;
	R5[369] = (char *(*)()) F370_4696;
	{long i; for (i = 371; i < 378; i++) R5[i] = (char *(*)()) F1_8;}
	R5[391] = (char *(*)()) F392_4754;
	R5[392] = (char *(*)()) F393_4803;
	{long i; for (i = 394; i < 397; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 400; i < 402; i++) R5[i] = (char *(*)()) F1_8;}
	R5[403] = (char *(*)()) F1_8;
	{long i; for (i = 408; i < 410; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 423; i < 428; i++) R5[i] = (char *(*)()) F1_8;}
	R5[452] = (char *(*)()) F1_8;
	{long i; for (i = 478; i < 500; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 512; i < 550; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 703; i < 705; i++) R5[i] = (char *(*)()) F1_8;}
	R5[744] = (char *(*)()) F745_5605;
	{long i; for (i = 772; i < 774; i++) R5[i] = (char *(*)()) F1_8;}
	R5[782] = (char *(*)()) F1_8;
	R5[795] = (char *(*)()) F796_6035;
	R5[796] = (char *(*)()) F797_6035;
	R5[797] = (char *(*)()) F798_6035;
	R5[798] = (char *(*)()) F799_6035;
	R5[799] = (char *(*)()) F800_6035;
	R5[800] = (char *(*)()) F801_6035;
	R5[801] = (char *(*)()) F802_6035;
	R5[802] = (char *(*)()) F803_6035;
	R5[803] = (char *(*)()) F796_6035;
	R5[804] = (char *(*)()) F805_6141;
	R5[805] = (char *(*)()) F806_6141;
	R5[806] = (char *(*)()) F807_6141;
	R5[807] = (char *(*)()) F808_6141;
	R5[808] = (char *(*)()) F809_6141;
	R5[821] = (char *(*)()) F822_6157;
	R5[822] = (char *(*)()) F823_6198;
	R5[823] = (char *(*)()) F824_6198;
	R5[824] = (char *(*)()) F825_6198;
	R5[825] = (char *(*)()) F826_6198;
	R5[826] = (char *(*)()) F827_6198;
	R5[827] = (char *(*)()) F828_6198;
	R5[828] = (char *(*)()) F829_6198;
	R5[829] = (char *(*)()) F830_6198;
	R5[830] = (char *(*)()) F831_6198;
	R5[831] = (char *(*)()) F832_6198;
	R5[832] = (char *(*)()) F833_6198;
	R5[833] = (char *(*)()) F834_6198;
	R5[887] = (char *(*)()) F864_6280;
	R5[888] = (char *(*)()) F865_6280;
	R5[889] = (char *(*)()) F864_6280;
	R5[890] = (char *(*)()) F865_6280;
	R5[891] = (char *(*)()) F864_6280;
	R5[892] = (char *(*)()) F893_6386;
	R5[893] = (char *(*)()) F894_6386;
	R5[894] = (char *(*)()) F895_6386;
	R5[895] = (char *(*)()) F896_6386;
	R5[896] = (char *(*)()) F897_6386;
	R5[897] = (char *(*)()) F898_6386;
	R5[898] = (char *(*)()) F899_6386;
	R5[899] = (char *(*)()) F900_6386;
	R5[900] = (char *(*)()) F901_6386;
	R5[901] = (char *(*)()) F902_6386;
	R5[902] = (char *(*)()) F903_6386;
	R5[903] = (char *(*)()) F904_6386;
	{long i; for (i = 904; i < 906; i++) R5[i] = (char *(*)()) F893_6386;}
	R5[906] = (char *(*)()) F894_6386;
	{long i; for (i = 907; i < 909; i++) R5[i] = (char *(*)()) F893_6386;}
	R5[910] = (char *(*)()) F1_8;
	{long i; for (i = 912; i < 914; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 914; i < 916; i++) R5[i] = (char *(*)()) F915_6728;}
	{long i; for (i = 924; i < 931; i++) R5[i] = (char *(*)()) F1_8;}
	R5[932] = (char *(*)()) F1_8;
	{long i; for (i = 934; i < 936; i++) R5[i] = (char *(*)()) F1_8;}
	R5[944] = (char *(*)()) F1_8;
	{long i; for (i = 950; i < 958; i++) R5[i] = (char *(*)()) F1_8;}
	R5[959] = (char *(*)()) F1_8;
	{long i; for (i = 964; i < 966; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 968; i < 979; i++) R5[i] = (char *(*)()) F1_8;}
	R5[979] = (char *(*)()) F893_6386;
	R5[980] = (char *(*)()) F1_8;
	{long i; for (i = 982; i < 987; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 988; i < 994; i++) R5[i] = (char *(*)()) F1_8;}
	R5[996] = (char *(*)()) F997_7352;
	R5[997] = (char *(*)()) F1_8;
	{long i; for (i = 1000; i < 1002; i++) R5[i] = (char *(*)()) F1000_7497;}
	{long i; for (i = 1003; i < 1005; i++) R5[i] = (char *(*)()) F1003_7537;}
	{long i; for (i = 1006; i < 1008; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1009; i < 1041; i++) R5[i] = (char *(*)()) F1009_7603;}
	R5[1042] = (char *(*)()) F1042_7640;
	R5[1043] = (char *(*)()) F1044_7678;
	R5[1044] = (char *(*)()) F1045_7678;
	R5[1045] = (char *(*)()) F1046_7678;
	R5[1046] = (char *(*)()) F1045_7678;
	{long i; for (i = 1051; i < 1054; i++) R5[i] = (char *(*)()) F1051_7840;}
	{long i; for (i = 1056; i < 1058; i++) R5[i] = (char *(*)()) F1056_8008;}
	R5[1060] = (char *(*)()) F1_8;
	R5[1061] = (char *(*)()) F1062_8208;
	{long i; for (i = 1062; i < 1065; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1065] = (char *(*)()) F1066_8312;
	R5[1066] = (char *(*)()) F1_8;
	{long i; for (i = 1069; i < 1072; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1072] = (char *(*)()) F1073_8660;
	R5[1073] = (char *(*)()) F1074_8697;
	R5[1074] = (char *(*)()) F1075_8697;
	R5[1075] = (char *(*)()) F1076_8697;
	R5[1076] = (char *(*)()) F1077_8697;
	R5[1077] = (char *(*)()) F1078_8697;
	R5[1078] = (char *(*)()) F1079_8697;
	R5[1079] = (char *(*)()) F1080_8697;
	R5[1080] = (char *(*)()) F1081_8697;
	R5[1081] = (char *(*)()) F1082_8697;
	R5[1082] = (char *(*)()) F1083_8697;
	R5[1083] = (char *(*)()) F1084_8697;
	R5[1084] = (char *(*)()) F1085_8697;
	R5[1085] = (char *(*)()) F1086_8697;
	R5[1086] = (char *(*)()) F1087_8697;
	R5[1087] = (char *(*)()) F1088_8697;
	R5[1088] = (char *(*)()) F1089_8697;
	R5[1089] = (char *(*)()) F1090_8697;
	R5[1090] = (char *(*)()) F1091_8697;
	R5[1091] = (char *(*)()) F1092_8697;
	R5[1092] = (char *(*)()) F1093_8697;
	R5[1093] = (char *(*)()) F1094_8697;
	R5[1094] = (char *(*)()) F1095_8697;
	R5[1095] = (char *(*)()) F1096_8697;
	R5[1096] = (char *(*)()) F1097_8697;
	R5[1097] = (char *(*)()) F1098_8697;
	R5[1098] = (char *(*)()) F1099_8697;
	R5[1099] = (char *(*)()) F1100_8697;
	R5[1100] = (char *(*)()) F1101_8697;
	R5[1101] = (char *(*)()) F1102_8697;
	R5[1102] = (char *(*)()) F1103_8697;
	R5[1103] = (char *(*)()) F1104_8697;
	R5[1104] = (char *(*)()) F1105_8697;
	R5[1105] = (char *(*)()) F1106_8697;
	R5[1106] = (char *(*)()) F1107_8697;
	{long i; for (i = 1108; i < 1120; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1123; i < 1126; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1127; i < 1130; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1177; i < 1179; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1179] = (char *(*)()) F1180_9066;
	R5[1180] = (char *(*)()) F1181_9090;
	{long i; for (i = 1183; i < 1185; i++) R5[i] = (char *(*)()) F1183_9121;}
	{long i; for (i = 1186; i < 1188; i++) R5[i] = (char *(*)()) F1186_9219;}
	{long i; for (i = 1189; i < 1191; i++) R5[i] = (char *(*)()) F1189_9318;}
	{long i; for (i = 1192; i < 1194; i++) R5[i] = (char *(*)()) F1192_9417;}
	{long i; for (i = 1195; i < 1197; i++) R5[i] = (char *(*)()) F1195_9516;}
	{long i; for (i = 1198; i < 1200; i++) R5[i] = (char *(*)()) F1198_9610;}
	{long i; for (i = 1201; i < 1203; i++) R5[i] = (char *(*)()) F1201_9704;}
	{long i; for (i = 1204; i < 1206; i++) R5[i] = (char *(*)()) F1204_9799;}
	{long i; for (i = 1207; i < 1209; i++) R5[i] = (char *(*)()) F1207_9898;}
	{long i; for (i = 1210; i < 1212; i++) R5[i] = (char *(*)()) F1210_9964;}
	{long i; for (i = 1212; i < 1214; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1214] = (char *(*)()) F1215_10077;
	{long i; for (i = 1215; i < 1222; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1222] = (char *(*)()) F1223_10108;
	{long i; for (i = 1223; i < 1226; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1226] = (char *(*)()) F1227_10236;
	R5[1227] = (char *(*)()) F1228_10236;
	R5[1228] = (char *(*)()) F1229_10236;
	R5[1246] = (char *(*)()) F1_8;
	{long i; for (i = 1250; i < 1253; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1254; i < 1256; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1258] = (char *(*)()) F1_8;
	R5[1260] = (char *(*)()) F1_8;
	R5[1261] = (char *(*)()) F1262_11556;
	R5[1263] = (char *(*)()) F1_8;
	R5[1276] = (char *(*)()) F1_8;
	{long i; for (i = 1278; i < 1280; i++) R5[i] = (char *(*)()) F1278_11708;}
	{long i; for (i = 1280; i < 1282; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1289; i < 1291; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1298; i < 1302; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1303] = (char *(*)()) F1_8;
	R5[1310] = (char *(*)()) F1_8;
	R5[1313] = (char *(*)()) F1314_13112;
}


#ifdef __cplusplus
}
#endif
