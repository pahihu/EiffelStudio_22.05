#include "epoly4.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4891[611])();
void R4891_init () {
	{long i; for (i = 0; i < 2; i++) R4891[i] = (char *(*)()) F701_5528;}
	R4891[41] = (char *(*)()) F745_5610;
	{long i; for (i = 69; i < 71; i++) R4891[i] = (char *(*)()) F710_5583;}
	{long i; for (i = 92; i < 94; i++) R4891[i] = (char *(*)()) F706_5583;}
	R4891[94] = (char *(*)()) F711_5583;
	R4891[95] = (char *(*)()) F707_5583;
	R4891[96] = (char *(*)()) F713_5583;
	R4891[97] = (char *(*)()) F708_5583;
	R4891[98] = (char *(*)()) F707_5583;
	R4891[99] = (char *(*)()) F714_5583;
	{long i; for (i = 100; i < 102; i++) R4891[i] = (char *(*)()) F706_5583;}
	R4891[102] = (char *(*)()) F713_5583;
	R4891[103] = (char *(*)()) F707_5583;
	R4891[104] = (char *(*)()) F708_5583;
	R4891[105] = (char *(*)()) F714_5583;
	R4891[118] = (char *(*)()) F707_5583;
	R4891[119] = (char *(*)()) F706_5583;
	R4891[120] = (char *(*)()) F707_5583;
	R4891[121] = (char *(*)()) F708_5583;
	R4891[122] = (char *(*)()) F711_5583;
	R4891[123] = (char *(*)()) F710_5583;
	R4891[124] = (char *(*)()) F712_5583;
	R4891[125] = (char *(*)()) F713_5583;
	R4891[126] = (char *(*)()) F709_5583;
	R4891[127] = (char *(*)()) F714_5583;
	R4891[128] = (char *(*)()) F715_5583;
	R4891[129] = (char *(*)()) F716_5583;
	R4891[130] = (char *(*)()) F717_5583;
	R4891[184] = (char *(*)()) F706_5583;
	R4891[185] = (char *(*)()) F707_5583;
	R4891[186] = (char *(*)()) F706_5583;
	R4891[187] = (char *(*)()) F707_5583;
	{long i; for (i = 188; i < 190; i++) R4891[i] = (char *(*)()) F706_5583;}
	R4891[190] = (char *(*)()) F707_5583;
	R4891[191] = (char *(*)()) F708_5583;
	R4891[192] = (char *(*)()) F711_5583;
	R4891[193] = (char *(*)()) F710_5583;
	R4891[194] = (char *(*)()) F712_5583;
	R4891[195] = (char *(*)()) F713_5583;
	R4891[196] = (char *(*)()) F709_5583;
	R4891[197] = (char *(*)()) F714_5583;
	R4891[198] = (char *(*)()) F715_5583;
	R4891[199] = (char *(*)()) F716_5583;
	R4891[200] = (char *(*)()) F717_5583;
	{long i; for (i = 201; i < 203; i++) R4891[i] = (char *(*)()) F706_5583;}
	R4891[203] = (char *(*)()) F707_5583;
	{long i; for (i = 204; i < 206; i++) R4891[i] = (char *(*)()) F706_5583;}
	R4891[276] = (char *(*)()) F706_5583;
	{long i; for (i = 349; i < 351; i++) R4891[i] = (char *(*)()) F710_5583;}
	R4891[354] = (char *(*)()) F709_5583;
	R4891[521] = (char *(*)()) F1225_10160;
	R4891[573] = (char *(*)()) F710_5583;
	R4891[610] = (char *(*)()) F710_5583;
}

char *(*R4895[611])();
void R4895_init () {
	{long i; for (i = 0; i < 2; i++) R4895[i] = (char *(*)()) F553_5431;}
	R4895[41] = (char *(*)()) F552_5431;
	{long i; for (i = 69; i < 71; i++) R4895[i] = (char *(*)()) F556_5431;}
	{long i; for (i = 92; i < 94; i++) R4895[i] = (char *(*)()) F552_5431;}
	R4895[94] = (char *(*)()) F557_5431;
	R4895[95] = (char *(*)()) F553_5431;
	R4895[96] = (char *(*)()) F559_5431;
	R4895[97] = (char *(*)()) F554_5431;
	R4895[98] = (char *(*)()) F553_5431;
	R4895[99] = (char *(*)()) F560_5431;
	{long i; for (i = 100; i < 102; i++) R4895[i] = (char *(*)()) F552_5431;}
	R4895[102] = (char *(*)()) F559_5431;
	R4895[103] = (char *(*)()) F553_5431;
	R4895[104] = (char *(*)()) F554_5431;
	R4895[105] = (char *(*)()) F560_5431;
	R4895[118] = (char *(*)()) F553_5431;
	R4895[119] = (char *(*)()) F552_5431;
	R4895[120] = (char *(*)()) F553_5431;
	R4895[121] = (char *(*)()) F554_5431;
	R4895[122] = (char *(*)()) F557_5431;
	R4895[123] = (char *(*)()) F556_5431;
	R4895[124] = (char *(*)()) F558_5431;
	R4895[125] = (char *(*)()) F559_5431;
	R4895[126] = (char *(*)()) F555_5431;
	R4895[127] = (char *(*)()) F560_5431;
	R4895[128] = (char *(*)()) F561_5431;
	R4895[129] = (char *(*)()) F562_5431;
	R4895[130] = (char *(*)()) F563_5431;
	R4895[184] = (char *(*)()) F552_5431;
	R4895[185] = (char *(*)()) F553_5431;
	R4895[186] = (char *(*)()) F552_5431;
	R4895[187] = (char *(*)()) F553_5431;
	{long i; for (i = 188; i < 190; i++) R4895[i] = (char *(*)()) F552_5431;}
	R4895[190] = (char *(*)()) F553_5431;
	R4895[191] = (char *(*)()) F554_5431;
	R4895[192] = (char *(*)()) F557_5431;
	R4895[193] = (char *(*)()) F556_5431;
	R4895[194] = (char *(*)()) F558_5431;
	R4895[195] = (char *(*)()) F559_5431;
	R4895[196] = (char *(*)()) F555_5431;
	R4895[197] = (char *(*)()) F560_5431;
	R4895[198] = (char *(*)()) F561_5431;
	R4895[199] = (char *(*)()) F562_5431;
	R4895[200] = (char *(*)()) F563_5431;
	{long i; for (i = 201; i < 203; i++) R4895[i] = (char *(*)()) F552_5431;}
	R4895[203] = (char *(*)()) F553_5431;
	{long i; for (i = 204; i < 206; i++) R4895[i] = (char *(*)()) F552_5431;}
	R4895[276] = (char *(*)()) F552_5431;
	{long i; for (i = 349; i < 351; i++) R4895[i] = (char *(*)()) F556_5431;}
	R4895[354] = (char *(*)()) F555_5431;
	R4895[521] = (char *(*)()) F556_5431;
	R4895[573] = (char *(*)()) F556_5431;
	R4895[610] = (char *(*)()) F556_5431;
}

char *(*R4897[611])();
void R4897_init () {
	{long i; for (i = 0; i < 2; i++) R4897[i] = (char *(*)()) F703_5543;}
	R4897[41] = (char *(*)()) F745_5624;
	{long i; for (i = 69; i < 71; i++) R4897[i] = (char *(*)()) F580_5457;}
	R4897[92] = (char *(*)()) F796_6068;
	R4897[93] = (char *(*)()) F797_6068;
	R4897[94] = (char *(*)()) F798_6068;
	R4897[95] = (char *(*)()) F799_6068;
	R4897[96] = (char *(*)()) F800_6068;
	R4897[97] = (char *(*)()) F801_6068;
	R4897[98] = (char *(*)()) F802_6068;
	R4897[99] = (char *(*)()) F803_6068;
	{long i; for (i = 100; i < 102; i++) R4897[i] = (char *(*)()) F796_6068;}
	R4897[102] = (char *(*)()) F800_6068;
	R4897[103] = (char *(*)()) F799_6068;
	R4897[104] = (char *(*)()) F801_6068;
	R4897[105] = (char *(*)()) F803_6068;
	R4897[118] = (char *(*)()) F822_6170;
	R4897[119] = (char *(*)()) F823_6235;
	R4897[120] = (char *(*)()) F824_6235;
	R4897[121] = (char *(*)()) F825_6235;
	R4897[122] = (char *(*)()) F826_6235;
	R4897[123] = (char *(*)()) F827_6235;
	R4897[124] = (char *(*)()) F828_6235;
	R4897[125] = (char *(*)()) F829_6235;
	R4897[126] = (char *(*)()) F830_6235;
	R4897[127] = (char *(*)()) F831_6235;
	R4897[128] = (char *(*)()) F832_6235;
	R4897[129] = (char *(*)()) F833_6235;
	R4897[130] = (char *(*)()) F834_6235;
	R4897[184] = (char *(*)()) F576_5457;
	R4897[185] = (char *(*)()) F577_5457;
	R4897[186] = (char *(*)()) F890_6344;
	R4897[187] = (char *(*)()) F891_6344;
	{long i; for (i = 188; i < 190; i++) R4897[i] = (char *(*)()) F576_5457;}
	R4897[190] = (char *(*)()) F577_5457;
	R4897[191] = (char *(*)()) F578_5457;
	R4897[192] = (char *(*)()) F581_5457;
	R4897[193] = (char *(*)()) F580_5457;
	R4897[194] = (char *(*)()) F582_5457;
	R4897[195] = (char *(*)()) F583_5457;
	R4897[196] = (char *(*)()) F579_5457;
	R4897[197] = (char *(*)()) F584_5457;
	R4897[198] = (char *(*)()) F585_5457;
	R4897[199] = (char *(*)()) F586_5457;
	R4897[200] = (char *(*)()) F587_5457;
	R4897[201] = (char *(*)()) F576_5457;
	R4897[202] = (char *(*)()) F906_6443;
	R4897[203] = (char *(*)()) F907_6443;
	{long i; for (i = 204; i < 206; i++) R4897[i] = (char *(*)()) F576_5457;}
	R4897[276] = (char *(*)()) F576_5457;
	{long i; for (i = 349; i < 351; i++) R4897[i] = (char *(*)()) F1053_7971;}
	R4897[354] = (char *(*)()) F1058_8142;
	R4897[521] = (char *(*)()) F580_5457;
	R4897[573] = (char *(*)()) F580_5457;
	R4897[610] = (char *(*)()) F1053_7971;
}

char *(*R4898[611])();
void R4898_init () {
	{long i; for (i = 0; i < 2; i++) R4898[i] = (char *(*)()) F553_5434;}
	R4898[41] = (char *(*)()) F552_5434;
	{long i; for (i = 69; i < 71; i++) R4898[i] = (char *(*)()) F556_5434;}
	{long i; for (i = 92; i < 94; i++) R4898[i] = (char *(*)()) F552_5434;}
	R4898[94] = (char *(*)()) F557_5434;
	R4898[95] = (char *(*)()) F553_5434;
	R4898[96] = (char *(*)()) F559_5434;
	R4898[97] = (char *(*)()) F554_5434;
	R4898[98] = (char *(*)()) F553_5434;
	R4898[99] = (char *(*)()) F560_5434;
	{long i; for (i = 100; i < 102; i++) R4898[i] = (char *(*)()) F552_5434;}
	R4898[102] = (char *(*)()) F559_5434;
	R4898[103] = (char *(*)()) F553_5434;
	R4898[104] = (char *(*)()) F554_5434;
	R4898[105] = (char *(*)()) F560_5434;
	R4898[118] = (char *(*)()) F553_5434;
	R4898[119] = (char *(*)()) F552_5434;
	R4898[120] = (char *(*)()) F553_5434;
	R4898[121] = (char *(*)()) F554_5434;
	R4898[122] = (char *(*)()) F557_5434;
	R4898[123] = (char *(*)()) F556_5434;
	R4898[124] = (char *(*)()) F558_5434;
	R4898[125] = (char *(*)()) F559_5434;
	R4898[126] = (char *(*)()) F555_5434;
	R4898[127] = (char *(*)()) F560_5434;
	R4898[128] = (char *(*)()) F561_5434;
	R4898[129] = (char *(*)()) F562_5434;
	R4898[130] = (char *(*)()) F563_5434;
	R4898[184] = (char *(*)()) F552_5434;
	R4898[185] = (char *(*)()) F553_5434;
	R4898[186] = (char *(*)()) F552_5434;
	R4898[187] = (char *(*)()) F553_5434;
	{long i; for (i = 188; i < 190; i++) R4898[i] = (char *(*)()) F552_5434;}
	R4898[190] = (char *(*)()) F553_5434;
	R4898[191] = (char *(*)()) F554_5434;
	R4898[192] = (char *(*)()) F557_5434;
	R4898[193] = (char *(*)()) F556_5434;
	R4898[194] = (char *(*)()) F558_5434;
	R4898[195] = (char *(*)()) F559_5434;
	R4898[196] = (char *(*)()) F555_5434;
	R4898[197] = (char *(*)()) F560_5434;
	R4898[198] = (char *(*)()) F561_5434;
	R4898[199] = (char *(*)()) F562_5434;
	R4898[200] = (char *(*)()) F563_5434;
	{long i; for (i = 201; i < 203; i++) R4898[i] = (char *(*)()) F552_5434;}
	R4898[203] = (char *(*)()) F553_5434;
	{long i; for (i = 204; i < 206; i++) R4898[i] = (char *(*)()) F552_5434;}
	R4898[276] = (char *(*)()) F552_5434;
	{long i; for (i = 349; i < 351; i++) R4898[i] = (char *(*)()) F556_5434;}
	R4898[354] = (char *(*)()) F555_5434;
	R4898[521] = (char *(*)()) F556_5434;
	R4898[573] = (char *(*)()) F556_5434;
	R4898[610] = (char *(*)()) F556_5434;
}

char *(*R4899[574])();
void R4899_init () {
	{long i; for (i = 0; i < 2; i++) R4899[i] = (char *(*)()) F703_5532_4899_1;}
	{long i; for (i = 69; i < 71; i++) R4899[i] = (char *(*)()) F772_5658_4899_1;}
	R4899[184] = (char *(*)()) F888_6294;
	R4899[185] = (char *(*)()) F889_6294_4899_1;
	R4899[186] = (char *(*)()) F888_6294;
	R4899[187] = (char *(*)()) F889_6294_4899_1;
	R4899[188] = (char *(*)()) F888_6294;
	R4899[189] = (char *(*)()) F893_6367;
	R4899[190] = (char *(*)()) F894_6367_4899_1;
	R4899[191] = (char *(*)()) F895_6367_4899_1;
	R4899[192] = (char *(*)()) F896_6367_4899_1;
	R4899[193] = (char *(*)()) F897_6367_4899_1;
	R4899[194] = (char *(*)()) F898_6367_4899_1;
	R4899[195] = (char *(*)()) F899_6367_4899_1;
	R4899[196] = (char *(*)()) F900_6367_4899_1;
	R4899[197] = (char *(*)()) F901_6367_4899_1;
	R4899[198] = (char *(*)()) F902_6367_4899_1;
	R4899[199] = (char *(*)()) F903_6367_4899_1;
	R4899[200] = (char *(*)()) F904_6367_4899_1;
	{long i; for (i = 201; i < 203; i++) R4899[i] = (char *(*)()) F893_6367;}
	R4899[203] = (char *(*)()) F894_6367_4899_1;
	{long i; for (i = 204; i < 206; i++) R4899[i] = (char *(*)()) F893_6367;}
	R4899[276] = (char *(*)()) F893_6367;
	R4899[521] = (char *(*)()) F772_5658_4899_1;
	R4899[573] = (char *(*)()) F772_5658_4899_1;
}
static EIF_REFERENCE F703_5532_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F703_5532(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F772_5658_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F772_5658(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F889_6294_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F889_6294(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_6367_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F894_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_6367_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F895_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_6367_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F896_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F897_6367_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F897_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_6367_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F898_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1196, 0x00).id, 1196, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F899_6367_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F899_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F900_6367_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F900_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F901_6367_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F901_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F902_6367_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F902_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F903_6367_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F903_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F904_6367_4899_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F904_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R4900[574])();
void R4900_init () {
	{long i; for (i = 0; i < 2; i++) R4900[i] = (char *(*)()) F577_5450;}
	{long i; for (i = 69; i < 71; i++) R4900[i] = (char *(*)()) F772_5679;}
	R4900[184] = (char *(*)()) F888_6305;
	R4900[185] = (char *(*)()) F889_6305;
	R4900[186] = (char *(*)()) F888_6305;
	R4900[187] = (char *(*)()) F889_6305;
	R4900[188] = (char *(*)()) F888_6305;
	R4900[189] = (char *(*)()) F840_6257;
	R4900[190] = (char *(*)()) F841_6257;
	R4900[191] = (char *(*)()) F842_6257;
	R4900[192] = (char *(*)()) F843_6257;
	R4900[193] = (char *(*)()) F844_6257;
	R4900[194] = (char *(*)()) F845_6257;
	R4900[195] = (char *(*)()) F846_6257;
	R4900[196] = (char *(*)()) F847_6257;
	R4900[197] = (char *(*)()) F848_6257;
	R4900[198] = (char *(*)()) F849_6257;
	R4900[199] = (char *(*)()) F850_6257;
	R4900[200] = (char *(*)()) F851_6257;
	{long i; for (i = 201; i < 203; i++) R4900[i] = (char *(*)()) F840_6257;}
	R4900[203] = (char *(*)()) F841_6257;
	{long i; for (i = 204; i < 206; i++) R4900[i] = (char *(*)()) F840_6257;}
	R4900[276] = (char *(*)()) F840_6257;
	R4900[521] = (char *(*)()) F772_5679;
	R4900[573] = (char *(*)()) F772_5679;
}

char *(*R4901[574])();
void R4901_init () {
	{long i; for (i = 0; i < 2; i++) R4901[i] = (char *(*)()) F703_5540;}
	{long i; for (i = 69; i < 71; i++) R4901[i] = (char *(*)()) F772_5734;}
	R4901[184] = (char *(*)()) F888_6311;
	R4901[185] = (char *(*)()) F889_6311;
	R4901[186] = (char *(*)()) F888_6311;
	R4901[187] = (char *(*)()) F889_6311;
	R4901[188] = (char *(*)()) F888_6311;
	R4901[189] = (char *(*)()) F893_6393;
	R4901[190] = (char *(*)()) F894_6393;
	R4901[191] = (char *(*)()) F895_6393;
	R4901[192] = (char *(*)()) F896_6393;
	R4901[193] = (char *(*)()) F897_6393;
	R4901[194] = (char *(*)()) F898_6393;
	R4901[195] = (char *(*)()) F899_6393;
	R4901[196] = (char *(*)()) F900_6393;
	R4901[197] = (char *(*)()) F901_6393;
	R4901[198] = (char *(*)()) F902_6393;
	R4901[199] = (char *(*)()) F903_6393;
	R4901[200] = (char *(*)()) F904_6393;
	{long i; for (i = 201; i < 203; i++) R4901[i] = (char *(*)()) F893_6393;}
	R4901[203] = (char *(*)()) F894_6393;
	{long i; for (i = 204; i < 206; i++) R4901[i] = (char *(*)()) F893_6393;}
	R4901[276] = (char *(*)()) F893_6393;
	R4901[521] = (char *(*)()) F772_5734;
	R4901[573] = (char *(*)()) F772_5734;
}

char *(*R4907[574])();
void R4907_init () {
	{long i; for (i = 0; i < 2; i++) R4907[i] = (char *(*)()) F577_5444_4907_4;}
	{long i; for (i = 69; i < 71; i++) R4907[i] = (char *(*)()) F592_5461_4907_4;}
	R4907[184] = (char *(*)()) F588_5461;
	R4907[185] = (char *(*)()) F589_5461_4907_4;
	R4907[186] = (char *(*)()) F588_5461;
	R4907[187] = (char *(*)()) F589_5461_4907_4;
	R4907[188] = (char *(*)()) F588_5461;
	R4907[189] = (char *(*)()) F893_6399;
	R4907[190] = (char *(*)()) F894_6399_4907_4;
	R4907[191] = (char *(*)()) F895_6399_4907_4;
	R4907[192] = (char *(*)()) F896_6399_4907_4;
	R4907[193] = (char *(*)()) F897_6399_4907_4;
	R4907[194] = (char *(*)()) F898_6399_4907_4;
	R4907[195] = (char *(*)()) F899_6399_4907_4;
	R4907[196] = (char *(*)()) F900_6399_4907_4;
	R4907[197] = (char *(*)()) F901_6399_4907_4;
	R4907[198] = (char *(*)()) F902_6399_4907_4;
	R4907[199] = (char *(*)()) F903_6399_4907_4;
	R4907[200] = (char *(*)()) F904_6399_4907_4;
	{long i; for (i = 201; i < 203; i++) R4907[i] = (char *(*)()) F893_6399;}
	R4907[203] = (char *(*)()) F894_6399_4907_4;
	{long i; for (i = 204; i < 206; i++) R4907[i] = (char *(*)()) F893_6399;}
	R4907[276] = (char *(*)()) F893_6399;
	R4907[521] = (char *(*)()) F592_5461_4907_4;
	R4907[573] = (char *(*)()) F592_5461_4907_4;
}
static void F577_5444_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F577_5444(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F592_5461_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F592_5461(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F589_5461_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F589_5461(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F894_6399_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F894_6399(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F895_6399_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F895_6399(Current, *(EIF_BOOLEAN *)arg1);
}
static void F896_6399_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F896_6399(Current, *(EIF_POINTER *)arg1);
}
static void F897_6399_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F897_6399(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F898_6399_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F898_6399(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F899_6399_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F899_6399(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F900_6399_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F900_6399(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F901_6399_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F901_6399(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F902_6399_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F902_6399(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F903_6399_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F903_6399(Current, *(EIF_REAL_32 *)arg1);
}
static void F904_6399_4907_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F904_6399(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R4908[277])();
void R4908_init () {
	{long i; for (i = 0; i < 2; i++) R4908[i] = (char *(*)()) F703_5531;}
	R4908[184] = (char *(*)()) F888_6297;
	R4908[185] = (char *(*)()) F889_6297;
	R4908[186] = (char *(*)()) F888_6297;
	R4908[187] = (char *(*)()) F889_6297;
	R4908[188] = (char *(*)()) F888_6297;
	R4908[189] = (char *(*)()) F893_6372;
	R4908[190] = (char *(*)()) F894_6372;
	R4908[191] = (char *(*)()) F895_6372;
	R4908[192] = (char *(*)()) F896_6372;
	R4908[193] = (char *(*)()) F897_6372;
	R4908[194] = (char *(*)()) F898_6372;
	R4908[195] = (char *(*)()) F899_6372;
	R4908[196] = (char *(*)()) F900_6372;
	R4908[197] = (char *(*)()) F901_6372;
	R4908[198] = (char *(*)()) F902_6372;
	R4908[199] = (char *(*)()) F903_6372;
	R4908[200] = (char *(*)()) F904_6372;
	{long i; for (i = 201; i < 203; i++) R4908[i] = (char *(*)()) F893_6372;}
	R4908[203] = (char *(*)()) F894_6372;
	{long i; for (i = 204; i < 206; i++) R4908[i] = (char *(*)()) F893_6372;}
	R4908[276] = (char *(*)()) F893_6372;
}

char *(*R4911[574])();
void R4911_init () {
	{long i; for (i = 0; i < 2; i++) R4911[i] = (char *(*)()) F577_5448;}
	{long i; for (i = 69; i < 71; i++) R4911[i] = (char *(*)()) F580_5448;}
	R4911[184] = (char *(*)()) F576_5448;
	R4911[185] = (char *(*)()) F577_5448;
	R4911[186] = (char *(*)()) F576_5448;
	R4911[187] = (char *(*)()) F577_5448;
	{long i; for (i = 188; i < 190; i++) R4911[i] = (char *(*)()) F576_5448;}
	R4911[190] = (char *(*)()) F577_5448;
	R4911[191] = (char *(*)()) F578_5448;
	R4911[192] = (char *(*)()) F581_5448;
	R4911[193] = (char *(*)()) F580_5448;
	R4911[194] = (char *(*)()) F582_5448;
	R4911[195] = (char *(*)()) F583_5448;
	R4911[196] = (char *(*)()) F579_5448;
	R4911[197] = (char *(*)()) F584_5448;
	R4911[198] = (char *(*)()) F585_5448;
	R4911[199] = (char *(*)()) F586_5448;
	R4911[200] = (char *(*)()) F587_5448;
	{long i; for (i = 201; i < 203; i++) R4911[i] = (char *(*)()) F576_5448;}
	R4911[203] = (char *(*)()) F577_5448;
	{long i; for (i = 204; i < 206; i++) R4911[i] = (char *(*)()) F576_5448;}
	R4911[276] = (char *(*)()) F576_5448;
	R4911[521] = (char *(*)()) F580_5448;
	R4911[573] = (char *(*)()) F580_5448;
}

char *(*R4912[574])();
void R4912_init () {
	{long i; for (i = 0; i < 2; i++) R4912[i] = (char *(*)()) F703_5533;}
	{long i; for (i = 69; i < 71; i++) R4912[i] = (char *(*)()) F772_5677;}
	R4912[184] = (char *(*)()) F888_6303;
	R4912[185] = (char *(*)()) F889_6303;
	R4912[186] = (char *(*)()) F888_6303;
	R4912[187] = (char *(*)()) F889_6303;
	R4912[188] = (char *(*)()) F888_6303;
	R4912[189] = (char *(*)()) F864_6281;
	R4912[190] = (char *(*)()) F865_6281;
	R4912[191] = (char *(*)()) F866_6281;
	R4912[192] = (char *(*)()) F867_6281;
	R4912[193] = (char *(*)()) F868_6281;
	R4912[194] = (char *(*)()) F869_6281;
	R4912[195] = (char *(*)()) F870_6281;
	R4912[196] = (char *(*)()) F871_6281;
	R4912[197] = (char *(*)()) F872_6281;
	R4912[198] = (char *(*)()) F873_6281;
	R4912[199] = (char *(*)()) F874_6281;
	R4912[200] = (char *(*)()) F875_6281;
	{long i; for (i = 201; i < 203; i++) R4912[i] = (char *(*)()) F864_6281;}
	R4912[203] = (char *(*)()) F865_6281;
	{long i; for (i = 204; i < 206; i++) R4912[i] = (char *(*)()) F864_6281;}
	R4912[276] = (char *(*)()) F864_6281;
	R4912[521] = (char *(*)()) F772_5677;
	R4912[573] = (char *(*)()) F772_5677;
}

char *(*R4913[93])();
void R4913_init () {
	R4913[0] = (char *(*)()) F888_6312;
	R4913[1] = (char *(*)()) F889_6312;
	R4913[2] = (char *(*)()) F888_6312;
	R4913[3] = (char *(*)()) F889_6312;
	R4913[4] = (char *(*)()) F888_6312;
	R4913[5] = (char *(*)()) F893_6394;
	R4913[6] = (char *(*)()) F894_6394;
	R4913[7] = (char *(*)()) F895_6394;
	R4913[8] = (char *(*)()) F896_6394;
	R4913[9] = (char *(*)()) F897_6394;
	R4913[10] = (char *(*)()) F898_6394;
	R4913[11] = (char *(*)()) F899_6394;
	R4913[12] = (char *(*)()) F900_6394;
	R4913[13] = (char *(*)()) F901_6394;
	R4913[14] = (char *(*)()) F902_6394;
	R4913[15] = (char *(*)()) F903_6394;
	R4913[16] = (char *(*)()) F904_6394;
	{long i; for (i = 17; i < 19; i++) R4913[i] = (char *(*)()) F893_6394;}
	R4913[19] = (char *(*)()) F894_6394;
	{long i; for (i = 20; i < 22; i++) R4913[i] = (char *(*)()) F893_6394;}
	R4913[92] = (char *(*)()) F893_6394;
}

char *(*R4914[574])();
void R4914_init () {
	{long i; for (i = 0; i < 2; i++) R4914[i] = (char *(*)()) F703_5539;}
	{long i; for (i = 69; i < 71; i++) R4914[i] = (char *(*)()) F772_5736;}
	R4914[184] = (char *(*)()) F888_6313;
	R4914[185] = (char *(*)()) F889_6313;
	R4914[186] = (char *(*)()) F888_6313;
	R4914[187] = (char *(*)()) F889_6313;
	R4914[188] = (char *(*)()) F888_6313;
	R4914[189] = (char *(*)()) F893_6395;
	R4914[190] = (char *(*)()) F894_6395;
	R4914[191] = (char *(*)()) F895_6395;
	R4914[192] = (char *(*)()) F896_6395;
	R4914[193] = (char *(*)()) F897_6395;
	R4914[194] = (char *(*)()) F898_6395;
	R4914[195] = (char *(*)()) F899_6395;
	R4914[196] = (char *(*)()) F900_6395;
	R4914[197] = (char *(*)()) F901_6395;
	R4914[198] = (char *(*)()) F902_6395;
	R4914[199] = (char *(*)()) F903_6395;
	R4914[200] = (char *(*)()) F904_6395;
	{long i; for (i = 201; i < 203; i++) R4914[i] = (char *(*)()) F893_6395;}
	R4914[203] = (char *(*)()) F894_6395;
	{long i; for (i = 204; i < 206; i++) R4914[i] = (char *(*)()) F893_6395;}
	R4914[276] = (char *(*)()) F893_6395;
	R4914[521] = (char *(*)()) F772_5736;
	R4914[573] = (char *(*)()) F772_5736;
}

char *(*R4915[505])();
void R4915_init () {
	{long i; for (i = 0; i < 2; i++) R4915[i] = (char *(*)()) F772_5678;}
	R4915[115] = (char *(*)()) F888_6304;
	R4915[116] = (char *(*)()) F889_6304;
	R4915[117] = (char *(*)()) F888_6304;
	R4915[118] = (char *(*)()) F889_6304;
	R4915[119] = (char *(*)()) F888_6304;
	R4915[120] = (char *(*)()) F864_6282;
	R4915[121] = (char *(*)()) F865_6282;
	R4915[122] = (char *(*)()) F866_6282;
	R4915[123] = (char *(*)()) F867_6282;
	R4915[124] = (char *(*)()) F868_6282;
	R4915[125] = (char *(*)()) F869_6282;
	R4915[126] = (char *(*)()) F870_6282;
	R4915[127] = (char *(*)()) F871_6282;
	R4915[128] = (char *(*)()) F872_6282;
	R4915[129] = (char *(*)()) F873_6282;
	R4915[130] = (char *(*)()) F874_6282;
	R4915[131] = (char *(*)()) F875_6282;
	{long i; for (i = 132; i < 134; i++) R4915[i] = (char *(*)()) F864_6282;}
	R4915[134] = (char *(*)()) F865_6282;
	{long i; for (i = 135; i < 137; i++) R4915[i] = (char *(*)()) F864_6282;}
	R4915[207] = (char *(*)()) F864_6282;
	R4915[452] = (char *(*)()) F772_5678;
	R4915[504] = (char *(*)()) F772_5678;
}

char *(*R4916[505])();
void R4916_init () {
	{long i; for (i = 0; i < 2; i++) R4916[i] = (char *(*)()) F772_5737;}
	R4916[120] = (char *(*)()) F893_6396;
	R4916[121] = (char *(*)()) F894_6396;
	R4916[122] = (char *(*)()) F895_6396;
	R4916[123] = (char *(*)()) F896_6396;
	R4916[124] = (char *(*)()) F897_6396;
	R4916[125] = (char *(*)()) F898_6396;
	R4916[126] = (char *(*)()) F899_6396;
	R4916[127] = (char *(*)()) F900_6396;
	R4916[128] = (char *(*)()) F901_6396;
	R4916[129] = (char *(*)()) F902_6396;
	R4916[130] = (char *(*)()) F903_6396;
	R4916[131] = (char *(*)()) F904_6396;
	{long i; for (i = 132; i < 134; i++) R4916[i] = (char *(*)()) F893_6396;}
	R4916[134] = (char *(*)()) F894_6396;
	{long i; for (i = 135; i < 137; i++) R4916[i] = (char *(*)()) F893_6396;}
	R4916[207] = (char *(*)()) F893_6396;
	R4916[452] = (char *(*)()) F1225_10130;
	R4916[504] = (char *(*)()) F772_5737;
}

char *(*R4917[611])();
void R4917_init () {
	{long i; for (i = 0; i < 2; i++) R4917[i] = (char *(*)()) F703_5534;}
	R4917[41] = (char *(*)()) F745_5612;
	{long i; for (i = 69; i < 71; i++) R4917[i] = (char *(*)()) F772_5710;}
	R4917[92] = (char *(*)()) F796_6039;
	R4917[93] = (char *(*)()) F797_6039;
	R4917[94] = (char *(*)()) F798_6039;
	R4917[95] = (char *(*)()) F799_6039;
	R4917[96] = (char *(*)()) F800_6039;
	R4917[97] = (char *(*)()) F801_6039;
	R4917[98] = (char *(*)()) F802_6039;
	R4917[99] = (char *(*)()) F803_6039;
	{long i; for (i = 100; i < 102; i++) R4917[i] = (char *(*)()) F796_6039;}
	R4917[102] = (char *(*)()) F800_6039;
	R4917[103] = (char *(*)()) F799_6039;
	R4917[104] = (char *(*)()) F801_6039;
	R4917[105] = (char *(*)()) F803_6039;
	R4917[118] = (char *(*)()) F822_6159;
	R4917[119] = (char *(*)()) F823_6204;
	R4917[120] = (char *(*)()) F824_6204;
	R4917[121] = (char *(*)()) F825_6204;
	R4917[122] = (char *(*)()) F826_6204;
	R4917[123] = (char *(*)()) F827_6204;
	R4917[124] = (char *(*)()) F828_6204;
	R4917[125] = (char *(*)()) F829_6204;
	R4917[126] = (char *(*)()) F830_6204;
	R4917[127] = (char *(*)()) F831_6204;
	R4917[128] = (char *(*)()) F832_6204;
	R4917[129] = (char *(*)()) F833_6204;
	R4917[130] = (char *(*)()) F834_6204;
	R4917[184] = (char *(*)()) F852_6266;
	R4917[185] = (char *(*)()) F853_6266;
	R4917[186] = (char *(*)()) F852_6266;
	R4917[187] = (char *(*)()) F853_6266;
	{long i; for (i = 188; i < 190; i++) R4917[i] = (char *(*)()) F852_6266;}
	R4917[190] = (char *(*)()) F853_6266;
	R4917[191] = (char *(*)()) F854_6266;
	R4917[192] = (char *(*)()) F855_6266;
	R4917[193] = (char *(*)()) F856_6266;
	R4917[194] = (char *(*)()) F857_6266;
	R4917[195] = (char *(*)()) F858_6266;
	R4917[196] = (char *(*)()) F859_6266;
	R4917[197] = (char *(*)()) F860_6266;
	R4917[198] = (char *(*)()) F861_6266;
	R4917[199] = (char *(*)()) F862_6266;
	R4917[200] = (char *(*)()) F863_6266;
	{long i; for (i = 201; i < 203; i++) R4917[i] = (char *(*)()) F852_6266;}
	R4917[203] = (char *(*)()) F853_6266;
	{long i; for (i = 204; i < 206; i++) R4917[i] = (char *(*)()) F852_6266;}
	R4917[276] = (char *(*)()) F852_6266;
	{long i; for (i = 349; i < 351; i++) R4917[i] = (char *(*)()) F1053_7900;}
	R4917[354] = (char *(*)()) F1058_8071;
	R4917[521] = (char *(*)()) F772_5710;
	R4917[573] = (char *(*)()) F772_5710;
	R4917[610] = (char *(*)()) F1053_7900;
}

char *(*R4921[611])();
void R4921_init () {
	{long i; for (i = 0; i < 2; i++) R4921[i] = (char *(*)()) F703_5541_4921_4;}
	R4921[41] = (char *(*)()) F745_5614;
	{long i; for (i = 69; i < 71; i++) R4921[i] = (char *(*)()) F772_5743_4921_4;}
	R4921[92] = (char *(*)()) F796_6123;
	R4921[93] = (char *(*)()) F797_6123;
	R4921[94] = (char *(*)()) F798_6123_4921_4;
	R4921[95] = (char *(*)()) F799_6123_4921_4;
	R4921[96] = (char *(*)()) F800_6123_4921_4;
	R4921[97] = (char *(*)()) F801_6123_4921_4;
	R4921[98] = (char *(*)()) F802_6123_4921_4;
	R4921[99] = (char *(*)()) F803_6123_4921_4;
	{long i; for (i = 100; i < 102; i++) R4921[i] = (char *(*)()) F796_6123;}
	R4921[102] = (char *(*)()) F800_6123_4921_4;
	R4921[103] = (char *(*)()) F799_6123_4921_4;
	R4921[104] = (char *(*)()) F801_6123_4921_4;
	R4921[105] = (char *(*)()) F803_6123_4921_4;
	R4921[118] = (char *(*)()) F822_6161_4921_4;
	R4921[119] = (char *(*)()) F823_6239;
	R4921[120] = (char *(*)()) F824_6239_4921_4;
	R4921[121] = (char *(*)()) F825_6239_4921_4;
	R4921[122] = (char *(*)()) F826_6239_4921_4;
	R4921[123] = (char *(*)()) F827_6239_4921_4;
	R4921[124] = (char *(*)()) F828_6239_4921_4;
	R4921[125] = (char *(*)()) F829_6239_4921_4;
	R4921[126] = (char *(*)()) F830_6239_4921_4;
	R4921[127] = (char *(*)()) F831_6239_4921_4;
	R4921[128] = (char *(*)()) F832_6239_4921_4;
	R4921[129] = (char *(*)()) F833_6239_4921_4;
	R4921[130] = (char *(*)()) F834_6239_4921_4;
	R4921[184] = (char *(*)()) F888_6319;
	R4921[185] = (char *(*)()) F889_6319_4921_4;
	R4921[186] = (char *(*)()) F890_6341;
	R4921[187] = (char *(*)()) F891_6341_4921_4;
	R4921[188] = (char *(*)()) F892_6354;
	R4921[189] = (char *(*)()) F893_6403;
	R4921[190] = (char *(*)()) F894_6403_4921_4;
	R4921[191] = (char *(*)()) F895_6403_4921_4;
	R4921[192] = (char *(*)()) F896_6403_4921_4;
	R4921[193] = (char *(*)()) F897_6403_4921_4;
	R4921[194] = (char *(*)()) F898_6403_4921_4;
	R4921[195] = (char *(*)()) F899_6403_4921_4;
	R4921[196] = (char *(*)()) F900_6403_4921_4;
	R4921[197] = (char *(*)()) F901_6403_4921_4;
	R4921[198] = (char *(*)()) F902_6403_4921_4;
	R4921[199] = (char *(*)()) F903_6403_4921_4;
	R4921[200] = (char *(*)()) F904_6403_4921_4;
	R4921[201] = (char *(*)()) F905_6430;
	R4921[202] = (char *(*)()) F906_6439;
	R4921[203] = (char *(*)()) F907_6439_4921_4;
	{long i; for (i = 204; i < 206; i++) R4921[i] = (char *(*)()) F893_6403;}
	R4921[276] = (char *(*)()) F893_6403;
	{long i; for (i = 349; i < 351; i++) R4921[i] = (char *(*)()) F1053_7942_4921_4;}
	R4921[354] = (char *(*)()) F1058_8113_4921_4;
	R4921[521] = (char *(*)()) F772_5743_4921_4;
	R4921[573] = (char *(*)()) F772_5743_4921_4;
	R4921[610] = (char *(*)()) F1053_7942_4921_4;
}
static void F703_5541_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F703_5541(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F772_5743_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F772_5743(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F798_6123_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F798_6123(Current, *(EIF_POINTER *)arg1);
}
static void F799_6123_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F799_6123(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F800_6123_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F800_6123(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F801_6123_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F801_6123(Current, *(EIF_BOOLEAN *)arg1);
}
static void F802_6123_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F802_6123(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F803_6123_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F803_6123(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F822_6161_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F822_6161(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F824_6239_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F824_6239(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F825_6239_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F825_6239(Current, *(EIF_BOOLEAN *)arg1);
}
static void F826_6239_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F826_6239(Current, *(EIF_POINTER *)arg1);
}
static void F827_6239_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F827_6239(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F828_6239_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F828_6239(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F829_6239_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F829_6239(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F830_6239_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F830_6239(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F831_6239_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F831_6239(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F832_6239_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F832_6239(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F833_6239_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F833_6239(Current, *(EIF_REAL_32 *)arg1);
}
static void F834_6239_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F834_6239(Current, *(EIF_REAL_64 *)arg1);
}
static void F889_6319_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F889_6319(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F891_6341_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F891_6341(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F894_6403_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F894_6403(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F895_6403_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F895_6403(Current, *(EIF_BOOLEAN *)arg1);
}
static void F896_6403_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F896_6403(Current, *(EIF_POINTER *)arg1);
}
static void F897_6403_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F897_6403(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F898_6403_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F898_6403(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F899_6403_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F899_6403(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F900_6403_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F900_6403(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F901_6403_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F901_6403(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F902_6403_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F902_6403(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F903_6403_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F903_6403(Current, *(EIF_REAL_32 *)arg1);
}
static void F904_6403_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F904_6403(Current, *(EIF_REAL_64 *)arg1);
}
static void F907_6439_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F907_6439(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1053_7942_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1053_7942(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1058_8113_4921_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1058_8113(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R4922[611])();
void R4922_init () {
	{long i; for (i = 0; i < 2; i++) R4922[i] = (char *(*)()) F601_5467;}
	R4922[41] = (char *(*)()) F600_5467;
	{long i; for (i = 69; i < 71; i++) R4922[i] = (char *(*)()) F604_5467;}
	{long i; for (i = 92; i < 94; i++) R4922[i] = (char *(*)()) F600_5467;}
	R4922[94] = (char *(*)()) F605_5467;
	R4922[95] = (char *(*)()) F601_5467;
	R4922[96] = (char *(*)()) F607_5467;
	R4922[97] = (char *(*)()) F602_5467;
	R4922[98] = (char *(*)()) F601_5467;
	R4922[99] = (char *(*)()) F608_5467;
	{long i; for (i = 100; i < 102; i++) R4922[i] = (char *(*)()) F600_5467;}
	R4922[102] = (char *(*)()) F607_5467;
	R4922[103] = (char *(*)()) F601_5467;
	R4922[104] = (char *(*)()) F602_5467;
	R4922[105] = (char *(*)()) F608_5467;
	R4922[118] = (char *(*)()) F601_5467;
	R4922[119] = (char *(*)()) F600_5467;
	R4922[120] = (char *(*)()) F601_5467;
	R4922[121] = (char *(*)()) F602_5467;
	R4922[122] = (char *(*)()) F605_5467;
	R4922[123] = (char *(*)()) F604_5467;
	R4922[124] = (char *(*)()) F606_5467;
	R4922[125] = (char *(*)()) F607_5467;
	R4922[126] = (char *(*)()) F603_5467;
	R4922[127] = (char *(*)()) F608_5467;
	R4922[128] = (char *(*)()) F609_5467;
	R4922[129] = (char *(*)()) F610_5467;
	R4922[130] = (char *(*)()) F611_5467;
	R4922[186] = (char *(*)()) F746_5637;
	R4922[187] = (char *(*)()) F747_5637;
	R4922[202] = (char *(*)()) F746_5637;
	R4922[203] = (char *(*)()) F747_5637;
	{long i; for (i = 349; i < 351; i++) R4922[i] = (char *(*)()) F604_5467;}
	R4922[354] = (char *(*)()) F603_5467;
	R4922[521] = (char *(*)()) F604_5467;
	R4922[573] = (char *(*)()) F604_5467;
	R4922[610] = (char *(*)()) F604_5467;
}

char *(*R4927[493])();
void R4927_init () {
	R4927[0] = (char *(*)()) F822_6149_4927_5;
	R4927[1] = (char *(*)()) F823_6188_4927_5;
	R4927[2] = (char *(*)()) F824_6188_4927_5;
	R4927[3] = (char *(*)()) F825_6188_4927_5;
	R4927[4] = (char *(*)()) F826_6188_4927_5;
	R4927[5] = (char *(*)()) F827_6188_4927_5;
	R4927[6] = (char *(*)()) F828_6188_4927_5;
	R4927[7] = (char *(*)()) F829_6188_4927_5;
	R4927[8] = (char *(*)()) F830_6188_4927_5;
	R4927[9] = (char *(*)()) F831_6188_4927_5;
	R4927[10] = (char *(*)()) F832_6188_4927_5;
	R4927[11] = (char *(*)()) F833_6188_4927_5;
	R4927[12] = (char *(*)()) F834_6188_4927_5;
	R4927[66] = (char *(*)()) F840_6246_4927_5;
	R4927[67] = (char *(*)()) F841_6246_4927_5;
	R4927[68] = (char *(*)()) F840_6246_4927_5;
	R4927[69] = (char *(*)()) F841_6246_4927_5;
	R4927[70] = (char *(*)()) F840_6246_4927_5;
	R4927[71] = (char *(*)()) F893_6368_4927_5;
	R4927[72] = (char *(*)()) F894_6368_4927_5;
	R4927[73] = (char *(*)()) F895_6368_4927_5;
	R4927[74] = (char *(*)()) F896_6368_4927_5;
	R4927[75] = (char *(*)()) F897_6368_4927_5;
	R4927[76] = (char *(*)()) F898_6368_4927_5;
	R4927[77] = (char *(*)()) F899_6368_4927_5;
	R4927[78] = (char *(*)()) F900_6368_4927_5;
	R4927[79] = (char *(*)()) F901_6368_4927_5;
	R4927[80] = (char *(*)()) F902_6368_4927_5;
	R4927[81] = (char *(*)()) F903_6368_4927_5;
	R4927[82] = (char *(*)()) F904_6368_4927_5;
	{long i; for (i = 83; i < 85; i++) R4927[i] = (char *(*)()) F893_6368_4927_5;}
	R4927[85] = (char *(*)()) F894_6368_4927_5;
	{long i; for (i = 86; i < 88; i++) R4927[i] = (char *(*)()) F893_6368_4927_5;}
	R4927[158] = (char *(*)()) F893_6368_4927_5;
	{long i; for (i = 231; i < 233; i++) R4927[i] = (char *(*)()) F1053_7894_4927_5;}
	R4927[236] = (char *(*)()) F1058_8066_4927_5;
	R4927[492] = (char *(*)()) F1314_13086_4927_5;
}
static EIF_REFERENCE F822_6149_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F822_6149(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F823_6188_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F823_6188(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F824_6188_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F824_6188(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F825_6188_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F825_6188(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F826_6188_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F826_6188(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F827_6188_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F827_6188(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F828_6188_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F828_6188(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1196, 0x00).id, 1196, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F829_6188_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F829_6188(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F830_6188_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F830_6188(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F831_6188_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F831_6188(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F832_6188_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F832_6188(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F833_6188_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F833_6188(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F834_6188_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F834_6188(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F840_6246_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F840_6246(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F841_6246_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F841_6246(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F893_6368_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F893_6368(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F894_6368_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F894_6368(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_6368_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F895_6368(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_6368_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F896_6368(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F897_6368_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F897_6368(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_6368_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F898_6368(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1196, 0x00).id, 1196, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F899_6368_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F899_6368(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F900_6368_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F900_6368(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F901_6368_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F901_6368(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F902_6368_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F902_6368(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F903_6368_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F903_6368(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F904_6368_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F904_6368(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1053_7894_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1053_7894(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1058_8066_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1058_8066(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1314_13086_4927_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1314_13086(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}


#ifdef __cplusplus
}
#endif
