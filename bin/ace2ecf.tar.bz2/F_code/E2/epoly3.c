#include "epoly3.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

static EIF_TYPE_INDEX Y4330_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype12[] = {1205,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype13[] = {1205,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype46[] = {1261,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype47[] = {908,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype49[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype50[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype51[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype52[] = {1001,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype53[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4330_pgtype54[] = {1004,0xFFFF};
EIF_TYPE_INDEX *Y4330_gen_type [937];
EIF_TYPE_INDEX Y4330 [937];
void Y4330_init (void)
{
	egc_routines_types [4330] = Y4330;
	egc_routines_gen_types [4330] = Y4330_gen_type;
	egc_routines_offset [4330] = 378;
	Y4330_gen_type [0] = Y4330_pgtype0;
	Y4330_gen_type [1] = Y4330_pgtype1;
	Y4330_gen_type [2] = Y4330_pgtype2;
	Y4330_gen_type [3] = Y4330_pgtype3;
	Y4330_gen_type [4] = Y4330_pgtype4;
	Y4330_gen_type [5] = Y4330_pgtype5;
	Y4330_gen_type [6] = Y4330_pgtype6;
	Y4330_gen_type [7] = Y4330_pgtype7;
	Y4330_gen_type [8] = Y4330_pgtype8;
	Y4330_gen_type [9] = Y4330_pgtype9;
	Y4330_gen_type [10] = Y4330_pgtype10;
	Y4330_gen_type [11] = Y4330_pgtype11;
	Y4330_gen_type [14] = Y4330_pgtype12;
	Y4330_gen_type [15] = Y4330_pgtype13;
	Y4330_gen_type [444] = Y4330_pgtype14;
	Y4330_gen_type [445] = Y4330_pgtype15;
	Y4330_gen_type [446] = Y4330_pgtype16;
	Y4330_gen_type [447] = Y4330_pgtype17;
	Y4330_gen_type [448] = Y4330_pgtype18;
	Y4330_gen_type [449] = Y4330_pgtype19;
	Y4330_gen_type [450] = Y4330_pgtype20;
	Y4330_gen_type [451] = Y4330_pgtype21;
	Y4330_gen_type [452] = Y4330_pgtype22;
	Y4330_gen_type [453] = Y4330_pgtype23;
	Y4330_gen_type [454] = Y4330_pgtype24;
	Y4330_gen_type [455] = Y4330_pgtype25;
	Y4330_gen_type [456] = Y4330_pgtype26;
	Y4330_gen_type [457] = Y4330_pgtype27;
	Y4330_gen_type [458] = Y4330_pgtype28;
	Y4330_gen_type [459] = Y4330_pgtype29;
	Y4330_gen_type [460] = Y4330_pgtype30;
	Y4330_gen_type [514] = Y4330_pgtype31;
	Y4330_gen_type [515] = Y4330_pgtype32;
	Y4330_gen_type [516] = Y4330_pgtype33;
	Y4330_gen_type [517] = Y4330_pgtype34;
	Y4330_gen_type [518] = Y4330_pgtype35;
	Y4330_gen_type [519] = Y4330_pgtype36;
	Y4330_gen_type [520] = Y4330_pgtype37;
	Y4330_gen_type [521] = Y4330_pgtype38;
	Y4330_gen_type [522] = Y4330_pgtype39;
	Y4330_gen_type [523] = Y4330_pgtype40;
	Y4330_gen_type [524] = Y4330_pgtype41;
	Y4330_gen_type [525] = Y4330_pgtype42;
	Y4330_gen_type [526] = Y4330_pgtype43;
	Y4330_gen_type [527] = Y4330_pgtype44;
	Y4330_gen_type [528] = Y4330_pgtype45;
	Y4330_gen_type [529] = Y4330_pgtype46;
	Y4330_gen_type [530] = Y4330_pgtype47;
	Y4330_gen_type [601] = Y4330_pgtype48;
	Y4330_gen_type [674] = Y4330_pgtype49;
	Y4330_gen_type [675] = Y4330_pgtype50;
	Y4330_gen_type [676] = Y4330_pgtype51;
	Y4330_gen_type [679] = Y4330_pgtype52;
	Y4330_gen_type [935] = Y4330_pgtype53;
	Y4330_gen_type [936] = Y4330_pgtype54;
	{long i; for (i = 14; i < 16; i++) Y4330[i] = 1205;};
	Y4330[529] = 1261;
	Y4330[530] = 908;
	{long i; for (i = 674; i < 677; i++) Y4330[i] = 1004;};
	Y4330[679] = 1001;
	{long i; for (i = 935; i < 937; i++) Y4330[i] = 1004;};
}

char *(*R4682[505])();
void R4682_init () {
	{long i; for (i = 0; i < 2; i++) R4682[i] = (char *(*)()) F772_5681;}
	R4682[452] = (char *(*)()) F1225_10127;
	R4682[504] = (char *(*)()) F772_5681;
}

char *(*R4693[505])();
void R4693_init () {
	{long i; for (i = 0; i < 2; i++) R4693[i] = (char *(*)()) F772_5760;}
	R4693[452] = (char *(*)()) F1225_10158;
	R4693[504] = (char *(*)()) F772_5760;
}

char *(*R4694[505])();
void R4694_init () {
	{long i; for (i = 0; i < 2; i++) R4694[i] = (char *(*)()) F772_5761;}
	R4694[452] = (char *(*)()) F1225_10159;
	R4694[504] = (char *(*)()) F772_5761;
}

char *(*R4695[505])();
void R4695_init () {
	{long i; for (i = 0; i < 2; i++) R4695[i] = (char *(*)()) F772_5755;}
	R4695[452] = (char *(*)()) F1225_10150;
	R4695[504] = (char *(*)()) F772_5755;
}

char *(*R4697[505])();
void R4697_init () {
	{long i; for (i = 0; i < 2; i++) R4697[i] = (char *(*)()) F772_5758;}
	R4697[452] = (char *(*)()) F1225_10148;
	R4697[504] = (char *(*)()) F772_5758;
}

char *(*R4725[505])();
void R4725_init () {
	{long i; for (i = 0; i < 2; i++) R4725[i] = (char *(*)()) F772_5788;}
	R4725[452] = (char *(*)()) F1225_10145;
	R4725[504] = (char *(*)()) F772_5788;
}

char *(*R4727[505])();
void R4727_init () {
	R4727[0] = (char *(*)()) F773_5895;
	R4727[1] = (char *(*)()) F774_5953;
	R4727[452] = (char *(*)()) F774_5953;
	R4727[504] = (char *(*)()) F773_5895;
}

char *(*R4733[505])();
void R4733_init () {
	R4733[0] = (char *(*)()) F773_5901;
	R4733[1] = (char *(*)()) F774_5962;
	R4733[452] = (char *(*)()) F774_5962;
	R4733[504] = (char *(*)()) F773_5901;
}

char *(*R4738[505])();
void R4738_init () {
	{long i; for (i = 0; i < 2; i++) R4738[i] = (char *(*)()) F772_5795;}
	R4738[452] = (char *(*)()) F1225_10139;
	R4738[504] = (char *(*)()) F772_5795;
}

char *(*R4741[505])();
void R4741_init () {
	{long i; for (i = 0; i < 2; i++) R4741[i] = (char *(*)()) F772_5792;}
	R4741[452] = (char *(*)()) F1225_10136;
	R4741[504] = (char *(*)()) F772_5792;
}

char *(*R4750[282])();
void R4750_init () {
	R4750[0] = (char *(*)()) F424_5207;
	R4750[1] = (char *(*)()) F425_5216_4750_1;
	R4750[2] = (char *(*)()) F426_5223;
	R4750[3] = (char *(*)()) F427_5223_4750_1;
	R4750[4] = (char *(*)()) F428_5223_4750_1;
	R4750[55] = (char *(*)()) F467_5323;
	R4750[56] = (char *(*)()) F468_5323_4750_1;
	R4750[57] = (char *(*)()) F469_5323_4750_1;
	R4750[58] = (char *(*)()) F470_5323_4750_1;
	R4750[59] = (char *(*)()) F471_5323_4750_1;
	R4750[60] = (char *(*)()) F472_5323_4750_1;
	R4750[61] = (char *(*)()) F473_5323_4750_1;
	R4750[62] = (char *(*)()) F474_5323_4750_1;
	R4750[63] = (char *(*)()) F475_5323_4750_1;
	R4750[64] = (char *(*)()) F476_5323_4750_1;
	R4750[65] = (char *(*)()) F477_5323_4750_1;
	R4750[66] = (char *(*)()) F478_5323_4750_1;
	R4750[67] = (char *(*)()) F491_5351;
	R4750[68] = (char *(*)()) F492_5351_4750_1;
	R4750[69] = (char *(*)()) F493_5357;
	R4750[70] = (char *(*)()) F494_5357;
	R4750[71] = (char *(*)()) F495_5357_4750_1;
	R4750[72] = (char *(*)()) F496_5357_4750_1;
	R4750[73] = (char *(*)()) F497_5357_4750_1;
	R4750[74] = (char *(*)()) F498_5357_4750_1;
	R4750[75] = (char *(*)()) F499_5357_4750_1;
	R4750[76] = (char *(*)()) F500_5357_4750_1;
	R4750[89] = (char *(*)()) F501_5363;
	R4750[90] = (char *(*)()) F502_5363_4750_1;
	R4750[91] = (char *(*)()) F503_5363_4750_1;
	R4750[92] = (char *(*)()) F504_5363_4750_1;
	R4750[93] = (char *(*)()) F505_5363_4750_1;
	R4750[94] = (char *(*)()) F506_5363_4750_1;
	R4750[95] = (char *(*)()) F507_5363_4750_1;
	R4750[96] = (char *(*)()) F508_5363_4750_1;
	R4750[97] = (char *(*)()) F509_5363_4750_1;
	R4750[98] = (char *(*)()) F510_5363_4750_1;
	R4750[99] = (char *(*)()) F511_5363_4750_1;
	R4750[100] = (char *(*)()) F512_5363_4750_1;
	R4750[101] = (char *(*)()) F505_5363_4750_1;
	R4750[102] = (char *(*)()) F508_5363_4750_1;
	R4750[103] = (char *(*)()) F501_5363;
	R4750[104] = (char *(*)()) F502_5363_4750_1;
	R4750[105] = (char *(*)()) F503_5363_4750_1;
	R4750[106] = (char *(*)()) F504_5363_4750_1;
	R4750[107] = (char *(*)()) F505_5363_4750_1;
	R4750[108] = (char *(*)()) F506_5363_4750_1;
	R4750[109] = (char *(*)()) F507_5363_4750_1;
	R4750[110] = (char *(*)()) F508_5363_4750_1;
	R4750[111] = (char *(*)()) F509_5363_4750_1;
	R4750[112] = (char *(*)()) F510_5363_4750_1;
	R4750[113] = (char *(*)()) F511_5363_4750_1;
	R4750[114] = (char *(*)()) F512_5363_4750_1;
	R4750[115] = (char *(*)()) F501_5363;
	R4750[116] = (char *(*)()) F502_5363_4750_1;
	R4750[117] = (char *(*)()) F503_5363_4750_1;
	R4750[118] = (char *(*)()) F504_5363_4750_1;
	R4750[119] = (char *(*)()) F505_5363_4750_1;
	R4750[120] = (char *(*)()) F506_5363_4750_1;
	R4750[121] = (char *(*)()) F507_5363_4750_1;
	R4750[122] = (char *(*)()) F508_5363_4750_1;
	R4750[123] = (char *(*)()) F509_5363_4750_1;
	R4750[124] = (char *(*)()) F510_5363_4750_1;
	R4750[125] = (char *(*)()) F511_5363_4750_1;
	R4750[126] = (char *(*)()) F512_5363_4750_1;
	{long i; for (i = 280; i < 282; i++) R4750[i] = (char *(*)()) F703_5532_4750_1;}
}
static EIF_REFERENCE F425_5216_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F425_5216(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F427_5223_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F427_5223(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F428_5223_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F428_5223(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F468_5323_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F468_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F469_5323_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F469_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F470_5323_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F470_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F471_5323_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F471_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F472_5323_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F472_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F473_5323_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F473_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1196, 0x00).id, 1196, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F474_5323_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F474_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F475_5323_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F475_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F476_5323_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F476_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F477_5323_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F477_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F478_5323_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F478_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F492_5351_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F492_5351(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F495_5357_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F495_5357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F496_5357_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F496_5357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F497_5357_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F497_5357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F498_5357_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F498_5357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F499_5357_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F499_5357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F500_5357_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F500_5357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F502_5363_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F502_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F503_5363_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F503_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F504_5363_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F504_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F505_5363_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F505_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F506_5363_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F506_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1196, 0x00).id, 1196, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F507_5363_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F507_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F508_5363_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F508_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F509_5363_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F509_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F510_5363_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F510_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F511_5363_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F511_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F512_5363_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F512_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F703_5532_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F703_5532(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4751[282])();
void R4751_init () {
	R4751[0] = (char *(*)()) F424_5208;
	R4751[1] = (char *(*)()) F425_5218;
	R4751[2] = (char *(*)()) F426_5224;
	R4751[3] = (char *(*)()) F427_5224;
	R4751[4] = (char *(*)()) F428_5224;
	R4751[55] = (char *(*)()) F479_5341;
	R4751[56] = (char *(*)()) F480_5341;
	R4751[57] = (char *(*)()) F481_5341;
	R4751[58] = (char *(*)()) F482_5341;
	R4751[59] = (char *(*)()) F483_5341;
	R4751[60] = (char *(*)()) F484_5341;
	R4751[61] = (char *(*)()) F485_5341;
	R4751[62] = (char *(*)()) F486_5341;
	R4751[63] = (char *(*)()) F487_5341;
	R4751[64] = (char *(*)()) F488_5341;
	R4751[65] = (char *(*)()) F489_5341;
	R4751[66] = (char *(*)()) F490_5341;
	R4751[67] = (char *(*)()) F491_5352;
	R4751[68] = (char *(*)()) F492_5352;
	R4751[69] = (char *(*)()) F493_5360;
	R4751[70] = (char *(*)()) F494_5360;
	R4751[71] = (char *(*)()) F495_5360;
	R4751[72] = (char *(*)()) F496_5360;
	R4751[73] = (char *(*)()) F497_5360;
	R4751[74] = (char *(*)()) F498_5360;
	R4751[75] = (char *(*)()) F499_5360;
	R4751[76] = (char *(*)()) F500_5360;
	R4751[89] = (char *(*)()) F501_5372;
	R4751[90] = (char *(*)()) F502_5372;
	R4751[91] = (char *(*)()) F503_5372;
	R4751[92] = (char *(*)()) F504_5372;
	R4751[93] = (char *(*)()) F505_5372;
	R4751[94] = (char *(*)()) F506_5372;
	R4751[95] = (char *(*)()) F507_5372;
	R4751[96] = (char *(*)()) F508_5372;
	R4751[97] = (char *(*)()) F509_5372;
	R4751[98] = (char *(*)()) F510_5372;
	R4751[99] = (char *(*)()) F511_5372;
	R4751[100] = (char *(*)()) F512_5372;
	R4751[101] = (char *(*)()) F505_5372;
	R4751[102] = (char *(*)()) F508_5372;
	R4751[103] = (char *(*)()) F501_5372;
	R4751[104] = (char *(*)()) F502_5372;
	R4751[105] = (char *(*)()) F503_5372;
	R4751[106] = (char *(*)()) F504_5372;
	R4751[107] = (char *(*)()) F505_5372;
	R4751[108] = (char *(*)()) F506_5372;
	R4751[109] = (char *(*)()) F507_5372;
	R4751[110] = (char *(*)()) F508_5372;
	R4751[111] = (char *(*)()) F509_5372;
	R4751[112] = (char *(*)()) F510_5372;
	R4751[113] = (char *(*)()) F511_5372;
	R4751[114] = (char *(*)()) F512_5372;
	R4751[115] = (char *(*)()) F501_5372;
	R4751[116] = (char *(*)()) F502_5372;
	R4751[117] = (char *(*)()) F503_5372;
	R4751[118] = (char *(*)()) F504_5372;
	R4751[119] = (char *(*)()) F505_5372;
	R4751[120] = (char *(*)()) F506_5372;
	R4751[121] = (char *(*)()) F507_5372;
	R4751[122] = (char *(*)()) F508_5372;
	R4751[123] = (char *(*)()) F509_5372;
	R4751[124] = (char *(*)()) F510_5372;
	R4751[125] = (char *(*)()) F511_5372;
	R4751[126] = (char *(*)()) F512_5372;
	{long i; for (i = 280; i < 282; i++) R4751[i] = (char *(*)()) F703_5533;}
}

char *(*R4752[282])();
void R4752_init () {
	R4752[0] = (char *(*)()) F424_5209;
	R4752[1] = (char *(*)()) F425_5219;
	R4752[2] = (char *(*)()) F426_5225;
	R4752[3] = (char *(*)()) F427_5225;
	R4752[4] = (char *(*)()) F428_5225;
	R4752[55] = (char *(*)()) F479_5349;
	R4752[56] = (char *(*)()) F480_5349;
	R4752[57] = (char *(*)()) F481_5349;
	R4752[58] = (char *(*)()) F482_5349;
	R4752[59] = (char *(*)()) F483_5349;
	R4752[60] = (char *(*)()) F484_5349;
	R4752[61] = (char *(*)()) F485_5349;
	R4752[62] = (char *(*)()) F486_5349;
	R4752[63] = (char *(*)()) F487_5349;
	R4752[64] = (char *(*)()) F488_5349;
	R4752[65] = (char *(*)()) F489_5349;
	R4752[66] = (char *(*)()) F490_5349;
	R4752[67] = (char *(*)()) F491_5354;
	R4752[68] = (char *(*)()) F492_5354;
	R4752[69] = (char *(*)()) F493_5361;
	R4752[70] = (char *(*)()) F494_5361;
	R4752[71] = (char *(*)()) F495_5361;
	R4752[72] = (char *(*)()) F496_5361;
	R4752[73] = (char *(*)()) F497_5361;
	R4752[74] = (char *(*)()) F498_5361;
	R4752[75] = (char *(*)()) F499_5361;
	R4752[76] = (char *(*)()) F500_5361;
	R4752[89] = (char *(*)()) F501_5378;
	R4752[90] = (char *(*)()) F502_5378;
	R4752[91] = (char *(*)()) F503_5378;
	R4752[92] = (char *(*)()) F504_5378;
	R4752[93] = (char *(*)()) F505_5378;
	R4752[94] = (char *(*)()) F506_5378;
	R4752[95] = (char *(*)()) F507_5378;
	R4752[96] = (char *(*)()) F508_5378;
	R4752[97] = (char *(*)()) F509_5378;
	R4752[98] = (char *(*)()) F510_5378;
	R4752[99] = (char *(*)()) F511_5378;
	R4752[100] = (char *(*)()) F512_5378;
	R4752[101] = (char *(*)()) F505_5378;
	R4752[102] = (char *(*)()) F508_5378;
	R4752[103] = (char *(*)()) F501_5378;
	R4752[104] = (char *(*)()) F502_5378;
	R4752[105] = (char *(*)()) F503_5378;
	R4752[106] = (char *(*)()) F504_5378;
	R4752[107] = (char *(*)()) F505_5378;
	R4752[108] = (char *(*)()) F506_5378;
	R4752[109] = (char *(*)()) F507_5378;
	R4752[110] = (char *(*)()) F508_5378;
	R4752[111] = (char *(*)()) F509_5378;
	R4752[112] = (char *(*)()) F510_5378;
	R4752[113] = (char *(*)()) F511_5378;
	R4752[114] = (char *(*)()) F512_5378;
	R4752[115] = (char *(*)()) F501_5378;
	R4752[116] = (char *(*)()) F502_5378;
	R4752[117] = (char *(*)()) F503_5378;
	R4752[118] = (char *(*)()) F504_5378;
	R4752[119] = (char *(*)()) F505_5378;
	R4752[120] = (char *(*)()) F506_5378;
	R4752[121] = (char *(*)()) F507_5378;
	R4752[122] = (char *(*)()) F508_5378;
	R4752[123] = (char *(*)()) F509_5378;
	R4752[124] = (char *(*)()) F510_5378;
	R4752[125] = (char *(*)()) F511_5378;
	R4752[126] = (char *(*)()) F512_5378;
	{long i; for (i = 280; i < 282; i++) R4752[i] = (char *(*)()) F703_5539;}
}

static EIF_TYPE_INDEX Y4753_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype13[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype25[] = {1001,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype96[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype97[] = {1001,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype122[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4753_pgtype123[] = {1187,0xFFFF};
EIF_TYPE_INDEX *Y4753_gen_type [294];
EIF_TYPE_INDEX Y4753 [294];
void Y4753_init (void)
{
	egc_routines_types [4753] = Y4753;
	egc_routines_gen_types [4753] = Y4753_gen_type;
	egc_routines_offset [4753] = 411;
	Y4753_gen_type [0] = Y4753_pgtype0;
	Y4753_gen_type [1] = Y4753_pgtype1;
	Y4753_gen_type [2] = Y4753_pgtype2;
	Y4753_gen_type [3] = Y4753_pgtype3;
	Y4753_gen_type [4] = Y4753_pgtype4;
	Y4753_gen_type [5] = Y4753_pgtype5;
	Y4753_gen_type [6] = Y4753_pgtype6;
	Y4753_gen_type [7] = Y4753_pgtype7;
	Y4753_gen_type [8] = Y4753_pgtype8;
	Y4753_gen_type [9] = Y4753_pgtype9;
	Y4753_gen_type [10] = Y4753_pgtype10;
	Y4753_gen_type [11] = Y4753_pgtype11;
	Y4753_gen_type [12] = Y4753_pgtype12;
	Y4753_gen_type [13] = Y4753_pgtype13;
	Y4753_gen_type [14] = Y4753_pgtype14;
	Y4753_gen_type [15] = Y4753_pgtype15;
	Y4753_gen_type [16] = Y4753_pgtype16;
	Y4753_gen_type [17] = Y4753_pgtype17;
	Y4753_gen_type [18] = Y4753_pgtype18;
	Y4753_gen_type [19] = Y4753_pgtype19;
	Y4753_gen_type [20] = Y4753_pgtype20;
	Y4753_gen_type [21] = Y4753_pgtype21;
	Y4753_gen_type [22] = Y4753_pgtype22;
	Y4753_gen_type [23] = Y4753_pgtype23;
	Y4753_gen_type [24] = Y4753_pgtype24;
	Y4753_gen_type [42] = Y4753_pgtype25;
	Y4753_gen_type [43] = Y4753_pgtype26;
	Y4753_gen_type [44] = Y4753_pgtype27;
	Y4753_gen_type [45] = Y4753_pgtype28;
	Y4753_gen_type [46] = Y4753_pgtype29;
	Y4753_gen_type [47] = Y4753_pgtype30;
	Y4753_gen_type [48] = Y4753_pgtype31;
	Y4753_gen_type [49] = Y4753_pgtype32;
	Y4753_gen_type [50] = Y4753_pgtype33;
	Y4753_gen_type [51] = Y4753_pgtype34;
	Y4753_gen_type [52] = Y4753_pgtype35;
	Y4753_gen_type [53] = Y4753_pgtype36;
	Y4753_gen_type [54] = Y4753_pgtype37;
	Y4753_gen_type [55] = Y4753_pgtype38;
	Y4753_gen_type [56] = Y4753_pgtype39;
	Y4753_gen_type [57] = Y4753_pgtype40;
	Y4753_gen_type [58] = Y4753_pgtype41;
	Y4753_gen_type [59] = Y4753_pgtype42;
	Y4753_gen_type [60] = Y4753_pgtype43;
	Y4753_gen_type [61] = Y4753_pgtype44;
	Y4753_gen_type [62] = Y4753_pgtype45;
	Y4753_gen_type [63] = Y4753_pgtype46;
	Y4753_gen_type [64] = Y4753_pgtype47;
	Y4753_gen_type [65] = Y4753_pgtype48;
	Y4753_gen_type [66] = Y4753_pgtype49;
	Y4753_gen_type [67] = Y4753_pgtype50;
	Y4753_gen_type [68] = Y4753_pgtype51;
	Y4753_gen_type [69] = Y4753_pgtype52;
	Y4753_gen_type [70] = Y4753_pgtype53;
	Y4753_gen_type [71] = Y4753_pgtype54;
	Y4753_gen_type [72] = Y4753_pgtype55;
	Y4753_gen_type [73] = Y4753_pgtype56;
	Y4753_gen_type [74] = Y4753_pgtype57;
	Y4753_gen_type [75] = Y4753_pgtype58;
	Y4753_gen_type [76] = Y4753_pgtype59;
	Y4753_gen_type [77] = Y4753_pgtype60;
	Y4753_gen_type [78] = Y4753_pgtype61;
	Y4753_gen_type [79] = Y4753_pgtype62;
	Y4753_gen_type [80] = Y4753_pgtype63;
	Y4753_gen_type [81] = Y4753_pgtype64;
	Y4753_gen_type [82] = Y4753_pgtype65;
	Y4753_gen_type [83] = Y4753_pgtype66;
	Y4753_gen_type [84] = Y4753_pgtype67;
	Y4753_gen_type [85] = Y4753_pgtype68;
	Y4753_gen_type [86] = Y4753_pgtype69;
	Y4753_gen_type [87] = Y4753_pgtype70;
	Y4753_gen_type [88] = Y4753_pgtype71;
	Y4753_gen_type [89] = Y4753_pgtype72;
	Y4753_gen_type [90] = Y4753_pgtype73;
	Y4753_gen_type [91] = Y4753_pgtype74;
	Y4753_gen_type [92] = Y4753_pgtype75;
	Y4753_gen_type [93] = Y4753_pgtype76;
	Y4753_gen_type [94] = Y4753_pgtype77;
	Y4753_gen_type [95] = Y4753_pgtype78;
	Y4753_gen_type [96] = Y4753_pgtype79;
	Y4753_gen_type [97] = Y4753_pgtype80;
	Y4753_gen_type [98] = Y4753_pgtype81;
	Y4753_gen_type [99] = Y4753_pgtype82;
	Y4753_gen_type [100] = Y4753_pgtype83;
	Y4753_gen_type [101] = Y4753_pgtype84;
	Y4753_gen_type [102] = Y4753_pgtype85;
	Y4753_gen_type [103] = Y4753_pgtype86;
	Y4753_gen_type [104] = Y4753_pgtype87;
	Y4753_gen_type [105] = Y4753_pgtype88;
	Y4753_gen_type [106] = Y4753_pgtype89;
	Y4753_gen_type [107] = Y4753_pgtype90;
	Y4753_gen_type [108] = Y4753_pgtype91;
	Y4753_gen_type [109] = Y4753_pgtype92;
	Y4753_gen_type [110] = Y4753_pgtype93;
	Y4753_gen_type [111] = Y4753_pgtype94;
	Y4753_gen_type [112] = Y4753_pgtype95;
	Y4753_gen_type [113] = Y4753_pgtype96;
	Y4753_gen_type [114] = Y4753_pgtype97;
	Y4753_gen_type [115] = Y4753_pgtype98;
	Y4753_gen_type [116] = Y4753_pgtype99;
	Y4753_gen_type [117] = Y4753_pgtype100;
	Y4753_gen_type [118] = Y4753_pgtype101;
	Y4753_gen_type [119] = Y4753_pgtype102;
	Y4753_gen_type [120] = Y4753_pgtype103;
	Y4753_gen_type [121] = Y4753_pgtype104;
	Y4753_gen_type [122] = Y4753_pgtype105;
	Y4753_gen_type [123] = Y4753_pgtype106;
	Y4753_gen_type [124] = Y4753_pgtype107;
	Y4753_gen_type [125] = Y4753_pgtype108;
	Y4753_gen_type [126] = Y4753_pgtype109;
	Y4753_gen_type [127] = Y4753_pgtype110;
	Y4753_gen_type [128] = Y4753_pgtype111;
	Y4753_gen_type [129] = Y4753_pgtype112;
	Y4753_gen_type [130] = Y4753_pgtype113;
	Y4753_gen_type [131] = Y4753_pgtype114;
	Y4753_gen_type [132] = Y4753_pgtype115;
	Y4753_gen_type [133] = Y4753_pgtype116;
	Y4753_gen_type [134] = Y4753_pgtype117;
	Y4753_gen_type [135] = Y4753_pgtype118;
	Y4753_gen_type [136] = Y4753_pgtype119;
	Y4753_gen_type [137] = Y4753_pgtype120;
	Y4753_gen_type [138] = Y4753_pgtype121;
	Y4753_gen_type [292] = Y4753_pgtype122;
	Y4753_gen_type [293] = Y4753_pgtype123;
	Y4753[13] = 1004;
	Y4753[42] = 1001;
	Y4753[113] = 1004;
	Y4753[114] = 1001;
	{long i; for (i = 292; i < 294; i++) Y4753[i] = 1187;};
}

char *(*R4763[3])();
void R4763_init () {
	R4763[0] = (char *(*)()) F426_5222;
	R4763[1] = (char *(*)()) F427_5222;
	R4763[2] = (char *(*)()) F428_5222;
}

char *(*R4766[8])();
void R4766_init () {
	R4766[0] = (char *(*)()) F493_5358;
	R4766[1] = (char *(*)()) F494_5358_4766_1;
	R4766[2] = (char *(*)()) F495_5358;
	R4766[3] = (char *(*)()) F496_5358;
	R4766[4] = (char *(*)()) F497_5358;
	R4766[5] = (char *(*)()) F498_5358;
	R4766[6] = (char *(*)()) F499_5358_4766_1;
	R4766[7] = (char *(*)()) F500_5358;
}
static EIF_REFERENCE F494_5358_4766_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F494_5358(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F499_5358_4766_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F499_5358(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4768[570])();
void R4768_init () {
	R4768[0] = (char *(*)()) F745_5625;
	R4768[51] = (char *(*)()) F796_6071;
	R4768[52] = (char *(*)()) F797_6071;
	R4768[53] = (char *(*)()) F798_6071;
	R4768[54] = (char *(*)()) F799_6071;
	R4768[55] = (char *(*)()) F800_6071;
	R4768[56] = (char *(*)()) F801_6071;
	R4768[57] = (char *(*)()) F802_6071;
	R4768[58] = (char *(*)()) F803_6071;
	{long i; for (i = 59; i < 61; i++) R4768[i] = (char *(*)()) F796_6071;}
	R4768[61] = (char *(*)()) F800_6071;
	R4768[62] = (char *(*)()) F799_6071;
	R4768[63] = (char *(*)()) F801_6071;
	R4768[64] = (char *(*)()) F803_6071;
	R4768[148] = (char *(*)()) F893_6423;
	R4768[149] = (char *(*)()) F894_6423;
	R4768[150] = (char *(*)()) F895_6423;
	R4768[151] = (char *(*)()) F896_6423;
	R4768[152] = (char *(*)()) F897_6423;
	R4768[153] = (char *(*)()) F898_6423;
	R4768[154] = (char *(*)()) F899_6423;
	R4768[155] = (char *(*)()) F900_6423;
	R4768[156] = (char *(*)()) F901_6423;
	R4768[157] = (char *(*)()) F902_6423;
	R4768[158] = (char *(*)()) F903_6423;
	R4768[159] = (char *(*)()) F904_6423;
	{long i; for (i = 160; i < 162; i++) R4768[i] = (char *(*)()) F893_6423;}
	R4768[162] = (char *(*)()) F894_6423;
	{long i; for (i = 163; i < 165; i++) R4768[i] = (char *(*)()) F893_6423;}
	R4768[235] = (char *(*)()) F893_6423;
	R4768[252] = (char *(*)()) F997_7437;
	{long i; for (i = 298; i < 303; i++) R4768[i] = (char *(*)()) F1042_7651;}
	{long i; for (i = 308; i < 310; i++) R4768[i] = (char *(*)()) F1053_7978;}
	R4768[312] = (char *(*)()) F1057_8059;
	R4768[313] = (char *(*)()) F1058_8150;
	R4768[569] = (char *(*)()) F1053_7978;
}

char *(*R4781[862])();
void R4781_init () {
	R4781[0] = (char *(*)()) F453_5279;
	R4781[26] = (char *(*)()) F479_5335;
	R4781[27] = (char *(*)()) F480_5335;
	R4781[28] = (char *(*)()) F481_5335;
	R4781[29] = (char *(*)()) F482_5335;
	R4781[30] = (char *(*)()) F483_5335;
	R4781[31] = (char *(*)()) F484_5335;
	R4781[32] = (char *(*)()) F485_5335;
	R4781[33] = (char *(*)()) F486_5335;
	R4781[34] = (char *(*)()) F487_5335;
	R4781[35] = (char *(*)()) F488_5335;
	R4781[36] = (char *(*)()) F489_5335;
	R4781[37] = (char *(*)()) F490_5335;
	R4781[38] = (char *(*)()) F479_5335;
	R4781[39] = (char *(*)()) F480_5335;
	{long i; for (i = 40; i < 42; i++) R4781[i] = (char *(*)()) F479_5335;}
	R4781[42] = (char *(*)()) F484_5335;
	R4781[43] = (char *(*)()) F480_5335;
	R4781[44] = (char *(*)()) F486_5335;
	R4781[45] = (char *(*)()) F481_5335;
	R4781[46] = (char *(*)()) F480_5335;
	R4781[47] = (char *(*)()) F487_5335;
	R4781[60] = (char *(*)()) F513_5385;
	R4781[61] = (char *(*)()) F514_5385;
	R4781[62] = (char *(*)()) F515_5385;
	R4781[63] = (char *(*)()) F516_5385;
	R4781[64] = (char *(*)()) F517_5385;
	R4781[65] = (char *(*)()) F518_5385;
	R4781[66] = (char *(*)()) F519_5385;
	R4781[67] = (char *(*)()) F520_5385;
	R4781[68] = (char *(*)()) F521_5385;
	R4781[69] = (char *(*)()) F522_5385;
	R4781[70] = (char *(*)()) F523_5385;
	R4781[71] = (char *(*)()) F524_5385;
	R4781[72] = (char *(*)()) F525_5391;
	R4781[73] = (char *(*)()) F526_5397;
	R4781[74] = (char *(*)()) F527_5403;
	R4781[75] = (char *(*)()) F528_5403;
	R4781[76] = (char *(*)()) F529_5403;
	R4781[77] = (char *(*)()) F530_5403;
	R4781[78] = (char *(*)()) F531_5403;
	R4781[79] = (char *(*)()) F532_5403;
	R4781[80] = (char *(*)()) F533_5403;
	R4781[81] = (char *(*)()) F534_5403;
	R4781[82] = (char *(*)()) F535_5403;
	R4781[83] = (char *(*)()) F536_5403;
	R4781[84] = (char *(*)()) F537_5403;
	R4781[85] = (char *(*)()) F538_5403;
	R4781[86] = (char *(*)()) F539_5409;
	R4781[87] = (char *(*)()) F540_5409;
	R4781[88] = (char *(*)()) F541_5409;
	R4781[89] = (char *(*)()) F542_5409;
	R4781[90] = (char *(*)()) F543_5409;
	R4781[91] = (char *(*)()) F544_5409;
	R4781[92] = (char *(*)()) F545_5409;
	R4781[93] = (char *(*)()) F546_5409;
	R4781[94] = (char *(*)()) F547_5409;
	R4781[95] = (char *(*)()) F548_5409;
	R4781[96] = (char *(*)()) F549_5409;
	R4781[97] = (char *(*)()) F550_5409;
	R4781[251] = (char *(*)()) F704_5563;
	R4781[252] = (char *(*)()) F705_5578;
	R4781[292] = (char *(*)()) F745_5604;
	{long i; for (i = 320; i < 322; i++) R4781[i] = (char *(*)()) F772_5742;}
	R4781[330] = (char *(*)()) F783_5998;
	R4781[343] = (char *(*)()) F796_6027;
	R4781[344] = (char *(*)()) F797_6027;
	R4781[345] = (char *(*)()) F798_6027;
	R4781[346] = (char *(*)()) F799_6027;
	R4781[347] = (char *(*)()) F800_6027;
	R4781[348] = (char *(*)()) F801_6027;
	R4781[349] = (char *(*)()) F802_6027;
	R4781[350] = (char *(*)()) F803_6027;
	{long i; for (i = 351; i < 353; i++) R4781[i] = (char *(*)()) F796_6027;}
	R4781[353] = (char *(*)()) F800_6027;
	R4781[354] = (char *(*)()) F799_6027;
	R4781[355] = (char *(*)()) F801_6027;
	R4781[356] = (char *(*)()) F803_6027;
	R4781[369] = (char *(*)()) F785_6007;
	R4781[370] = (char *(*)()) F823_6192;
	R4781[371] = (char *(*)()) F824_6192;
	R4781[372] = (char *(*)()) F825_6192;
	R4781[373] = (char *(*)()) F826_6192;
	R4781[374] = (char *(*)()) F827_6192;
	R4781[375] = (char *(*)()) F828_6192;
	R4781[376] = (char *(*)()) F829_6192;
	R4781[377] = (char *(*)()) F830_6192;
	R4781[378] = (char *(*)()) F831_6192;
	R4781[379] = (char *(*)()) F832_6192;
	R4781[380] = (char *(*)()) F833_6192;
	R4781[381] = (char *(*)()) F834_6192;
	R4781[435] = (char *(*)()) F888_6299;
	R4781[436] = (char *(*)()) F889_6299;
	R4781[437] = (char *(*)()) F888_6299;
	R4781[438] = (char *(*)()) F889_6299;
	R4781[439] = (char *(*)()) F888_6299;
	R4781[440] = (char *(*)()) F893_6376;
	R4781[441] = (char *(*)()) F894_6376;
	R4781[442] = (char *(*)()) F895_6376;
	R4781[443] = (char *(*)()) F896_6376;
	R4781[444] = (char *(*)()) F897_6376;
	R4781[445] = (char *(*)()) F898_6376;
	R4781[446] = (char *(*)()) F899_6376;
	R4781[447] = (char *(*)()) F900_6376;
	R4781[448] = (char *(*)()) F901_6376;
	R4781[449] = (char *(*)()) F902_6376;
	R4781[450] = (char *(*)()) F903_6376;
	R4781[451] = (char *(*)()) F904_6376;
	{long i; for (i = 452; i < 454; i++) R4781[i] = (char *(*)()) F893_6376;}
	R4781[454] = (char *(*)()) F894_6376;
	{long i; for (i = 455; i < 457; i++) R4781[i] = (char *(*)()) F893_6376;}
	R4781[527] = (char *(*)()) F893_6376;
	R4781[544] = (char *(*)()) F784_6007;
	{long i; for (i = 599; i < 602; i++) R4781[i] = (char *(*)()) F1051_7835;}
	{long i; for (i = 604; i < 606; i++) R4781[i] = (char *(*)()) F1056_8003;}
	R4781[608] = (char *(*)()) F551_5417;
	R4781[610] = (char *(*)()) F551_5417;
	R4781[656] = (char *(*)()) F1109_8731;
	R4781[657] = (char *(*)()) F1110_8731;
	R4781[658] = (char *(*)()) F1111_8731;
	R4781[659] = (char *(*)()) F1112_8731;
	R4781[660] = (char *(*)()) F1113_8731;
	R4781[661] = (char *(*)()) F1114_8731;
	R4781[662] = (char *(*)()) F1115_8731;
	R4781[663] = (char *(*)()) F1116_8731;
	R4781[664] = (char *(*)()) F1117_8731;
	R4781[665] = (char *(*)()) F1118_8731;
	R4781[666] = (char *(*)()) F1119_8731;
	R4781[667] = (char *(*)()) F1120_8731;
	R4781[760] = (char *(*)()) F1213_10025;
	R4781[761] = (char *(*)()) F1214_10068;
	R4781[772] = (char *(*)()) F1225_10131;
	R4781[774] = (char *(*)()) F1227_10235;
	R4781[775] = (char *(*)()) F1228_10235;
	R4781[776] = (char *(*)()) F1229_10235;
	R4781[824] = (char *(*)()) F772_5742;
	R4781[861] = (char *(*)()) F1051_7835;
}

static EIF_TYPE_INDEX Y4782_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype12[] = {1052,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype13[] = {1056,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype14[] = {1001,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype85[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype86[] = {1001,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype111[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype264[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype265[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype332[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype333[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype334[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype343[] = {1055,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype364[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype365[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype382[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype451[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype452[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype453[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype454[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype455[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype456[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype457[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype466[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype467[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype468[] = {1261,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype469[] = {908,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype470[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype471[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype472[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype473[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype474[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype475[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype476[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype477[] = {1001,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype478[] = {1001,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype479[] = {1001,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype480[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype481[] = {1061,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype482[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype483[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype484[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype485[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype486[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype487[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype488[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype489[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype490[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype491[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype492[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype493[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype494[] = {1176,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype495[] = {1176,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype496[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype497[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype498[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype499[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype500[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype501[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype502[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype503[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype504[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype505[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype506[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype507[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype508[] = {1004,0xFFFF};
static EIF_TYPE_INDEX Y4782_pgtype509[] = {1004,0xFFFF};
EIF_TYPE_INDEX *Y4782_gen_type [876];
EIF_TYPE_INDEX Y4782 [876];
void Y4782_init (void)
{
	egc_routines_types [4782] = Y4782;
	egc_routines_gen_types [4782] = Y4782_gen_type;
	egc_routines_offset [4782] = 439;
	Y4782_gen_type [0] = Y4782_pgtype0;
	Y4782_gen_type [1] = Y4782_pgtype1;
	Y4782_gen_type [2] = Y4782_pgtype2;
	Y4782_gen_type [3] = Y4782_pgtype3;
	Y4782_gen_type [4] = Y4782_pgtype4;
	Y4782_gen_type [5] = Y4782_pgtype5;
	Y4782_gen_type [6] = Y4782_pgtype6;
	Y4782_gen_type [7] = Y4782_pgtype7;
	Y4782_gen_type [8] = Y4782_pgtype8;
	Y4782_gen_type [9] = Y4782_pgtype9;
	Y4782_gen_type [10] = Y4782_pgtype10;
	Y4782_gen_type [11] = Y4782_pgtype11;
	Y4782_gen_type [12] = Y4782_pgtype12;
	Y4782_gen_type [13] = Y4782_pgtype13;
	Y4782_gen_type [14] = Y4782_pgtype14;
	Y4782_gen_type [15] = Y4782_pgtype15;
	Y4782_gen_type [16] = Y4782_pgtype16;
	Y4782_gen_type [17] = Y4782_pgtype17;
	Y4782_gen_type [18] = Y4782_pgtype18;
	Y4782_gen_type [19] = Y4782_pgtype19;
	Y4782_gen_type [20] = Y4782_pgtype20;
	Y4782_gen_type [21] = Y4782_pgtype21;
	Y4782_gen_type [22] = Y4782_pgtype22;
	Y4782_gen_type [23] = Y4782_pgtype23;
	Y4782_gen_type [24] = Y4782_pgtype24;
	Y4782_gen_type [25] = Y4782_pgtype25;
	Y4782_gen_type [26] = Y4782_pgtype26;
	Y4782_gen_type [27] = Y4782_pgtype27;
	Y4782_gen_type [28] = Y4782_pgtype28;
	Y4782_gen_type [29] = Y4782_pgtype29;
	Y4782_gen_type [30] = Y4782_pgtype30;
	Y4782_gen_type [31] = Y4782_pgtype31;
	Y4782_gen_type [32] = Y4782_pgtype32;
	Y4782_gen_type [33] = Y4782_pgtype33;
	Y4782_gen_type [34] = Y4782_pgtype34;
	Y4782_gen_type [35] = Y4782_pgtype35;
	Y4782_gen_type [36] = Y4782_pgtype36;
	Y4782_gen_type [37] = Y4782_pgtype37;
	Y4782_gen_type [38] = Y4782_pgtype38;
	Y4782_gen_type [39] = Y4782_pgtype39;
	Y4782_gen_type [40] = Y4782_pgtype40;
	Y4782_gen_type [41] = Y4782_pgtype41;
	Y4782_gen_type [42] = Y4782_pgtype42;
	Y4782_gen_type [43] = Y4782_pgtype43;
	Y4782_gen_type [44] = Y4782_pgtype44;
	Y4782_gen_type [45] = Y4782_pgtype45;
	Y4782_gen_type [46] = Y4782_pgtype46;
	Y4782_gen_type [47] = Y4782_pgtype47;
	Y4782_gen_type [48] = Y4782_pgtype48;
	Y4782_gen_type [49] = Y4782_pgtype49;
	Y4782_gen_type [50] = Y4782_pgtype50;
	Y4782_gen_type [51] = Y4782_pgtype51;
	Y4782_gen_type [52] = Y4782_pgtype52;
	Y4782_gen_type [53] = Y4782_pgtype53;
	Y4782_gen_type [54] = Y4782_pgtype54;
	Y4782_gen_type [55] = Y4782_pgtype55;
	Y4782_gen_type [56] = Y4782_pgtype56;
	Y4782_gen_type [57] = Y4782_pgtype57;
	Y4782_gen_type [58] = Y4782_pgtype58;
	Y4782_gen_type [59] = Y4782_pgtype59;
	Y4782_gen_type [60] = Y4782_pgtype60;
	Y4782_gen_type [61] = Y4782_pgtype61;
	Y4782_gen_type [62] = Y4782_pgtype62;
	Y4782_gen_type [63] = Y4782_pgtype63;
	Y4782_gen_type [64] = Y4782_pgtype64;
	Y4782_gen_type [65] = Y4782_pgtype65;
	Y4782_gen_type [66] = Y4782_pgtype66;
	Y4782_gen_type [67] = Y4782_pgtype67;
	Y4782_gen_type [68] = Y4782_pgtype68;
	Y4782_gen_type [69] = Y4782_pgtype69;
	Y4782_gen_type [70] = Y4782_pgtype70;
	Y4782_gen_type [71] = Y4782_pgtype71;
	Y4782_gen_type [72] = Y4782_pgtype72;
	Y4782_gen_type [73] = Y4782_pgtype73;
	Y4782_gen_type [74] = Y4782_pgtype74;
	Y4782_gen_type [75] = Y4782_pgtype75;
	Y4782_gen_type [76] = Y4782_pgtype76;
	Y4782_gen_type [77] = Y4782_pgtype77;
	Y4782_gen_type [78] = Y4782_pgtype78;
	Y4782_gen_type [79] = Y4782_pgtype79;
	Y4782_gen_type [80] = Y4782_pgtype80;
	Y4782_gen_type [81] = Y4782_pgtype81;
	Y4782_gen_type [82] = Y4782_pgtype82;
	Y4782_gen_type [83] = Y4782_pgtype83;
	Y4782_gen_type [84] = Y4782_pgtype84;
	Y4782_gen_type [85] = Y4782_pgtype85;
	Y4782_gen_type [86] = Y4782_pgtype86;
	Y4782_gen_type [87] = Y4782_pgtype87;
	Y4782_gen_type [88] = Y4782_pgtype88;
	Y4782_gen_type [89] = Y4782_pgtype89;
	Y4782_gen_type [90] = Y4782_pgtype90;
	Y4782_gen_type [91] = Y4782_pgtype91;
	Y4782_gen_type [92] = Y4782_pgtype92;
	Y4782_gen_type [93] = Y4782_pgtype93;
	Y4782_gen_type [94] = Y4782_pgtype94;
	Y4782_gen_type [95] = Y4782_pgtype95;
	Y4782_gen_type [96] = Y4782_pgtype96;
	Y4782_gen_type [97] = Y4782_pgtype97;
	Y4782_gen_type [98] = Y4782_pgtype98;
	Y4782_gen_type [99] = Y4782_pgtype99;
	Y4782_gen_type [100] = Y4782_pgtype100;
	Y4782_gen_type [101] = Y4782_pgtype101;
	Y4782_gen_type [102] = Y4782_pgtype102;
	Y4782_gen_type [103] = Y4782_pgtype103;
	Y4782_gen_type [104] = Y4782_pgtype104;
	Y4782_gen_type [105] = Y4782_pgtype105;
	Y4782_gen_type [106] = Y4782_pgtype106;
	Y4782_gen_type [107] = Y4782_pgtype107;
	Y4782_gen_type [108] = Y4782_pgtype108;
	Y4782_gen_type [109] = Y4782_pgtype109;
	Y4782_gen_type [110] = Y4782_pgtype110;
	Y4782_gen_type [111] = Y4782_pgtype111;
	Y4782_gen_type [112] = Y4782_pgtype112;
	Y4782_gen_type [113] = Y4782_pgtype113;
	Y4782_gen_type [114] = Y4782_pgtype114;
	Y4782_gen_type [115] = Y4782_pgtype115;
	Y4782_gen_type [116] = Y4782_pgtype116;
	Y4782_gen_type [117] = Y4782_pgtype117;
	Y4782_gen_type [118] = Y4782_pgtype118;
	Y4782_gen_type [119] = Y4782_pgtype119;
	Y4782_gen_type [120] = Y4782_pgtype120;
	Y4782_gen_type [121] = Y4782_pgtype121;
	Y4782_gen_type [122] = Y4782_pgtype122;
	Y4782_gen_type [123] = Y4782_pgtype123;
	Y4782_gen_type [124] = Y4782_pgtype124;
	Y4782_gen_type [125] = Y4782_pgtype125;
	Y4782_gen_type [126] = Y4782_pgtype126;
	Y4782_gen_type [127] = Y4782_pgtype127;
	Y4782_gen_type [128] = Y4782_pgtype128;
	Y4782_gen_type [129] = Y4782_pgtype129;
	Y4782_gen_type [130] = Y4782_pgtype130;
	Y4782_gen_type [131] = Y4782_pgtype131;
	Y4782_gen_type [132] = Y4782_pgtype132;
	Y4782_gen_type [133] = Y4782_pgtype133;
	Y4782_gen_type [134] = Y4782_pgtype134;
	Y4782_gen_type [135] = Y4782_pgtype135;
	Y4782_gen_type [136] = Y4782_pgtype136;
	Y4782_gen_type [137] = Y4782_pgtype137;
	Y4782_gen_type [138] = Y4782_pgtype138;
	Y4782_gen_type [139] = Y4782_pgtype139;
	Y4782_gen_type [140] = Y4782_pgtype140;
	Y4782_gen_type [141] = Y4782_pgtype141;
	Y4782_gen_type [142] = Y4782_pgtype142;
	Y4782_gen_type [143] = Y4782_pgtype143;
	Y4782_gen_type [144] = Y4782_pgtype144;
	Y4782_gen_type [145] = Y4782_pgtype145;
	Y4782_gen_type [146] = Y4782_pgtype146;
	Y4782_gen_type [147] = Y4782_pgtype147;
	Y4782_gen_type [148] = Y4782_pgtype148;
	Y4782_gen_type [149] = Y4782_pgtype149;
	Y4782_gen_type [150] = Y4782_pgtype150;
	Y4782_gen_type [151] = Y4782_pgtype151;
	Y4782_gen_type [152] = Y4782_pgtype152;
	Y4782_gen_type [153] = Y4782_pgtype153;
	Y4782_gen_type [154] = Y4782_pgtype154;
	Y4782_gen_type [155] = Y4782_pgtype155;
	Y4782_gen_type [156] = Y4782_pgtype156;
	Y4782_gen_type [157] = Y4782_pgtype157;
	Y4782_gen_type [158] = Y4782_pgtype158;
	Y4782_gen_type [159] = Y4782_pgtype159;
	Y4782_gen_type [160] = Y4782_pgtype160;
	Y4782_gen_type [161] = Y4782_pgtype161;
	Y4782_gen_type [162] = Y4782_pgtype162;
	Y4782_gen_type [163] = Y4782_pgtype163;
	Y4782_gen_type [164] = Y4782_pgtype164;
	Y4782_gen_type [165] = Y4782_pgtype165;
	Y4782_gen_type [166] = Y4782_pgtype166;
	Y4782_gen_type [167] = Y4782_pgtype167;
	Y4782_gen_type [168] = Y4782_pgtype168;
	Y4782_gen_type [169] = Y4782_pgtype169;
	Y4782_gen_type [170] = Y4782_pgtype170;
	Y4782_gen_type [171] = Y4782_pgtype171;
	Y4782_gen_type [172] = Y4782_pgtype172;
	Y4782_gen_type [173] = Y4782_pgtype173;
	Y4782_gen_type [174] = Y4782_pgtype174;
	Y4782_gen_type [175] = Y4782_pgtype175;
	Y4782_gen_type [176] = Y4782_pgtype176;
	Y4782_gen_type [177] = Y4782_pgtype177;
	Y4782_gen_type [178] = Y4782_pgtype178;
	Y4782_gen_type [179] = Y4782_pgtype179;
	Y4782_gen_type [180] = Y4782_pgtype180;
	Y4782_gen_type [181] = Y4782_pgtype181;
	Y4782_gen_type [182] = Y4782_pgtype182;
	Y4782_gen_type [183] = Y4782_pgtype183;
	Y4782_gen_type [184] = Y4782_pgtype184;
	Y4782_gen_type [185] = Y4782_pgtype185;
	Y4782_gen_type [186] = Y4782_pgtype186;
	Y4782_gen_type [187] = Y4782_pgtype187;
	Y4782_gen_type [188] = Y4782_pgtype188;
	Y4782_gen_type [189] = Y4782_pgtype189;
	Y4782_gen_type [190] = Y4782_pgtype190;
	Y4782_gen_type [191] = Y4782_pgtype191;
	Y4782_gen_type [192] = Y4782_pgtype192;
	Y4782_gen_type [193] = Y4782_pgtype193;
	Y4782_gen_type [194] = Y4782_pgtype194;
	Y4782_gen_type [195] = Y4782_pgtype195;
	Y4782_gen_type [196] = Y4782_pgtype196;
	Y4782_gen_type [197] = Y4782_pgtype197;
	Y4782_gen_type [198] = Y4782_pgtype198;
	Y4782_gen_type [199] = Y4782_pgtype199;
	Y4782_gen_type [200] = Y4782_pgtype200;
	Y4782_gen_type [201] = Y4782_pgtype201;
	Y4782_gen_type [202] = Y4782_pgtype202;
	Y4782_gen_type [203] = Y4782_pgtype203;
	Y4782_gen_type [204] = Y4782_pgtype204;
	Y4782_gen_type [205] = Y4782_pgtype205;
	Y4782_gen_type [206] = Y4782_pgtype206;
	Y4782_gen_type [207] = Y4782_pgtype207;
	Y4782_gen_type [208] = Y4782_pgtype208;
	Y4782_gen_type [209] = Y4782_pgtype209;
	Y4782_gen_type [210] = Y4782_pgtype210;
	Y4782_gen_type [211] = Y4782_pgtype211;
	Y4782_gen_type [212] = Y4782_pgtype212;
	Y4782_gen_type [213] = Y4782_pgtype213;
	Y4782_gen_type [214] = Y4782_pgtype214;
	Y4782_gen_type [215] = Y4782_pgtype215;
	Y4782_gen_type [216] = Y4782_pgtype216;
	Y4782_gen_type [217] = Y4782_pgtype217;
	Y4782_gen_type [218] = Y4782_pgtype218;
	Y4782_gen_type [219] = Y4782_pgtype219;
	Y4782_gen_type [220] = Y4782_pgtype220;
	Y4782_gen_type [221] = Y4782_pgtype221;
	Y4782_gen_type [222] = Y4782_pgtype222;
	Y4782_gen_type [223] = Y4782_pgtype223;
	Y4782_gen_type [224] = Y4782_pgtype224;
	Y4782_gen_type [225] = Y4782_pgtype225;
	Y4782_gen_type [226] = Y4782_pgtype226;
	Y4782_gen_type [227] = Y4782_pgtype227;
	Y4782_gen_type [228] = Y4782_pgtype228;
	Y4782_gen_type [229] = Y4782_pgtype229;
	Y4782_gen_type [230] = Y4782_pgtype230;
	Y4782_gen_type [231] = Y4782_pgtype231;
	Y4782_gen_type [232] = Y4782_pgtype232;
	Y4782_gen_type [233] = Y4782_pgtype233;
	Y4782_gen_type [234] = Y4782_pgtype234;
	Y4782_gen_type [235] = Y4782_pgtype235;
	Y4782_gen_type [236] = Y4782_pgtype236;
	Y4782_gen_type [237] = Y4782_pgtype237;
	Y4782_gen_type [238] = Y4782_pgtype238;
	Y4782_gen_type [239] = Y4782_pgtype239;
	Y4782_gen_type [240] = Y4782_pgtype240;
	Y4782_gen_type [241] = Y4782_pgtype241;
	Y4782_gen_type [242] = Y4782_pgtype242;
	Y4782_gen_type [243] = Y4782_pgtype243;
	Y4782_gen_type [244] = Y4782_pgtype244;
	Y4782_gen_type [245] = Y4782_pgtype245;
	Y4782_gen_type [246] = Y4782_pgtype246;
	Y4782_gen_type [247] = Y4782_pgtype247;
	Y4782_gen_type [248] = Y4782_pgtype248;
	Y4782_gen_type [249] = Y4782_pgtype249;
	Y4782_gen_type [250] = Y4782_pgtype250;
	Y4782_gen_type [251] = Y4782_pgtype251;
	Y4782_gen_type [252] = Y4782_pgtype252;
	Y4782_gen_type [253] = Y4782_pgtype253;
	Y4782_gen_type [254] = Y4782_pgtype254;
	Y4782_gen_type [255] = Y4782_pgtype255;
	Y4782_gen_type [256] = Y4782_pgtype256;
	Y4782_gen_type [257] = Y4782_pgtype257;
	Y4782_gen_type [258] = Y4782_pgtype258;
	Y4782_gen_type [259] = Y4782_pgtype259;
	Y4782_gen_type [260] = Y4782_pgtype260;
	Y4782_gen_type [261] = Y4782_pgtype261;
	Y4782_gen_type [262] = Y4782_pgtype262;
	Y4782_gen_type [263] = Y4782_pgtype263;
	Y4782_gen_type [264] = Y4782_pgtype264;
	Y4782_gen_type [265] = Y4782_pgtype265;
	Y4782_gen_type [266] = Y4782_pgtype266;
	Y4782_gen_type [267] = Y4782_pgtype267;
	Y4782_gen_type [268] = Y4782_pgtype268;
	Y4782_gen_type [269] = Y4782_pgtype269;
	Y4782_gen_type [270] = Y4782_pgtype270;
	Y4782_gen_type [271] = Y4782_pgtype271;
	Y4782_gen_type [272] = Y4782_pgtype272;
	Y4782_gen_type [273] = Y4782_pgtype273;
	Y4782_gen_type [274] = Y4782_pgtype274;
	Y4782_gen_type [275] = Y4782_pgtype275;
	Y4782_gen_type [276] = Y4782_pgtype276;
	Y4782_gen_type [277] = Y4782_pgtype277;
	Y4782_gen_type [278] = Y4782_pgtype278;
	Y4782_gen_type [279] = Y4782_pgtype279;
	Y4782_gen_type [280] = Y4782_pgtype280;
	Y4782_gen_type [281] = Y4782_pgtype281;
	Y4782_gen_type [282] = Y4782_pgtype282;
	Y4782_gen_type [283] = Y4782_pgtype283;
	Y4782_gen_type [284] = Y4782_pgtype284;
	Y4782_gen_type [285] = Y4782_pgtype285;
	Y4782_gen_type [286] = Y4782_pgtype286;
	Y4782_gen_type [287] = Y4782_pgtype287;
	Y4782_gen_type [288] = Y4782_pgtype288;
	Y4782_gen_type [289] = Y4782_pgtype289;
	Y4782_gen_type [290] = Y4782_pgtype290;
	Y4782_gen_type [291] = Y4782_pgtype291;
	Y4782_gen_type [292] = Y4782_pgtype292;
	Y4782_gen_type [293] = Y4782_pgtype293;
	Y4782_gen_type [294] = Y4782_pgtype294;
	Y4782_gen_type [295] = Y4782_pgtype295;
	Y4782_gen_type [296] = Y4782_pgtype296;
	Y4782_gen_type [297] = Y4782_pgtype297;
	Y4782_gen_type [298] = Y4782_pgtype298;
	Y4782_gen_type [299] = Y4782_pgtype299;
	Y4782_gen_type [300] = Y4782_pgtype300;
	Y4782_gen_type [301] = Y4782_pgtype301;
	Y4782_gen_type [302] = Y4782_pgtype302;
	Y4782_gen_type [303] = Y4782_pgtype303;
	Y4782_gen_type [304] = Y4782_pgtype304;
	Y4782_gen_type [305] = Y4782_pgtype305;
	Y4782_gen_type [306] = Y4782_pgtype306;
	Y4782_gen_type [307] = Y4782_pgtype307;
	Y4782_gen_type [308] = Y4782_pgtype308;
	Y4782_gen_type [309] = Y4782_pgtype309;
	Y4782_gen_type [310] = Y4782_pgtype310;
	Y4782_gen_type [311] = Y4782_pgtype311;
	Y4782_gen_type [312] = Y4782_pgtype312;
	Y4782_gen_type [313] = Y4782_pgtype313;
	Y4782_gen_type [314] = Y4782_pgtype314;
	Y4782_gen_type [315] = Y4782_pgtype315;
	Y4782_gen_type [316] = Y4782_pgtype316;
	Y4782_gen_type [317] = Y4782_pgtype317;
	Y4782_gen_type [318] = Y4782_pgtype318;
	Y4782_gen_type [319] = Y4782_pgtype319;
	Y4782_gen_type [320] = Y4782_pgtype320;
	Y4782_gen_type [321] = Y4782_pgtype321;
	Y4782_gen_type [322] = Y4782_pgtype322;
	Y4782_gen_type [323] = Y4782_pgtype323;
	Y4782_gen_type [324] = Y4782_pgtype324;
	Y4782_gen_type [325] = Y4782_pgtype325;
	Y4782_gen_type [326] = Y4782_pgtype326;
	Y4782_gen_type [327] = Y4782_pgtype327;
	Y4782_gen_type [328] = Y4782_pgtype328;
	Y4782_gen_type [329] = Y4782_pgtype329;
	Y4782_gen_type [330] = Y4782_pgtype330;
	Y4782_gen_type [331] = Y4782_pgtype331;
	Y4782_gen_type [332] = Y4782_pgtype332;
	Y4782_gen_type [333] = Y4782_pgtype333;
	Y4782_gen_type [334] = Y4782_pgtype334;
	Y4782_gen_type [335] = Y4782_pgtype335;
	Y4782_gen_type [336] = Y4782_pgtype336;
	Y4782_gen_type [337] = Y4782_pgtype337;
	Y4782_gen_type [338] = Y4782_pgtype338;
	Y4782_gen_type [339] = Y4782_pgtype339;
	Y4782_gen_type [340] = Y4782_pgtype340;
	Y4782_gen_type [341] = Y4782_pgtype341;
	Y4782_gen_type [342] = Y4782_pgtype342;
	Y4782_gen_type [343] = Y4782_pgtype343;
	Y4782_gen_type [344] = Y4782_pgtype344;
	Y4782_gen_type [345] = Y4782_pgtype345;
	Y4782_gen_type [346] = Y4782_pgtype346;
	Y4782_gen_type [347] = Y4782_pgtype347;
	Y4782_gen_type [348] = Y4782_pgtype348;
	Y4782_gen_type [349] = Y4782_pgtype349;
	Y4782_gen_type [350] = Y4782_pgtype350;
	Y4782_gen_type [351] = Y4782_pgtype351;
	Y4782_gen_type [352] = Y4782_pgtype352;
	Y4782_gen_type [353] = Y4782_pgtype353;
	Y4782_gen_type [354] = Y4782_pgtype354;
	Y4782_gen_type [355] = Y4782_pgtype355;
	Y4782_gen_type [356] = Y4782_pgtype356;
	Y4782_gen_type [357] = Y4782_pgtype357;
	Y4782_gen_type [358] = Y4782_pgtype358;
	Y4782_gen_type [359] = Y4782_pgtype359;
	Y4782_gen_type [360] = Y4782_pgtype360;
	Y4782_gen_type [361] = Y4782_pgtype361;
	Y4782_gen_type [362] = Y4782_pgtype362;
	Y4782_gen_type [363] = Y4782_pgtype363;
	Y4782_gen_type [364] = Y4782_pgtype364;
	Y4782_gen_type [365] = Y4782_pgtype365;
	Y4782_gen_type [366] = Y4782_pgtype366;
	Y4782_gen_type [367] = Y4782_pgtype367;
	Y4782_gen_type [368] = Y4782_pgtype368;
	Y4782_gen_type [369] = Y4782_pgtype369;
	Y4782_gen_type [370] = Y4782_pgtype370;
	Y4782_gen_type [371] = Y4782_pgtype371;
	Y4782_gen_type [372] = Y4782_pgtype372;
	Y4782_gen_type [373] = Y4782_pgtype373;
	Y4782_gen_type [374] = Y4782_pgtype374;
	Y4782_gen_type [375] = Y4782_pgtype375;
	Y4782_gen_type [376] = Y4782_pgtype376;
	Y4782_gen_type [377] = Y4782_pgtype377;
	Y4782_gen_type [378] = Y4782_pgtype378;
	Y4782_gen_type [379] = Y4782_pgtype379;
	Y4782_gen_type [380] = Y4782_pgtype380;
	Y4782_gen_type [381] = Y4782_pgtype381;
	Y4782_gen_type [382] = Y4782_pgtype382;
	Y4782_gen_type [383] = Y4782_pgtype383;
	Y4782_gen_type [384] = Y4782_pgtype384;
	Y4782_gen_type [385] = Y4782_pgtype385;
	Y4782_gen_type [386] = Y4782_pgtype386;
	Y4782_gen_type [387] = Y4782_pgtype387;
	Y4782_gen_type [388] = Y4782_pgtype388;
	Y4782_gen_type [389] = Y4782_pgtype389;
	Y4782_gen_type [390] = Y4782_pgtype390;
	Y4782_gen_type [391] = Y4782_pgtype391;
	Y4782_gen_type [392] = Y4782_pgtype392;
	Y4782_gen_type [393] = Y4782_pgtype393;
	Y4782_gen_type [394] = Y4782_pgtype394;
	Y4782_gen_type [395] = Y4782_pgtype395;
	Y4782_gen_type [396] = Y4782_pgtype396;
	Y4782_gen_type [397] = Y4782_pgtype397;
	Y4782_gen_type [398] = Y4782_pgtype398;
	Y4782_gen_type [399] = Y4782_pgtype399;
	Y4782_gen_type [400] = Y4782_pgtype400;
	Y4782_gen_type [401] = Y4782_pgtype401;
	Y4782_gen_type [402] = Y4782_pgtype402;
	Y4782_gen_type [403] = Y4782_pgtype403;
	Y4782_gen_type [404] = Y4782_pgtype404;
	Y4782_gen_type [405] = Y4782_pgtype405;
	Y4782_gen_type [406] = Y4782_pgtype406;
	Y4782_gen_type [407] = Y4782_pgtype407;
	Y4782_gen_type [408] = Y4782_pgtype408;
	Y4782_gen_type [409] = Y4782_pgtype409;
	Y4782_gen_type [410] = Y4782_pgtype410;
	Y4782_gen_type [411] = Y4782_pgtype411;
	Y4782_gen_type [412] = Y4782_pgtype412;
	Y4782_gen_type [413] = Y4782_pgtype413;
	Y4782_gen_type [414] = Y4782_pgtype414;
	Y4782_gen_type [415] = Y4782_pgtype415;
	Y4782_gen_type [416] = Y4782_pgtype416;
	Y4782_gen_type [417] = Y4782_pgtype417;
	Y4782_gen_type [418] = Y4782_pgtype418;
	Y4782_gen_type [419] = Y4782_pgtype419;
	Y4782_gen_type [420] = Y4782_pgtype420;
	Y4782_gen_type [421] = Y4782_pgtype421;
	Y4782_gen_type [422] = Y4782_pgtype422;
	Y4782_gen_type [423] = Y4782_pgtype423;
	Y4782_gen_type [424] = Y4782_pgtype424;
	Y4782_gen_type [425] = Y4782_pgtype425;
	Y4782_gen_type [426] = Y4782_pgtype426;
	Y4782_gen_type [427] = Y4782_pgtype427;
	Y4782_gen_type [428] = Y4782_pgtype428;
	Y4782_gen_type [429] = Y4782_pgtype429;
	Y4782_gen_type [430] = Y4782_pgtype430;
	Y4782_gen_type [431] = Y4782_pgtype431;
	Y4782_gen_type [432] = Y4782_pgtype432;
	Y4782_gen_type [433] = Y4782_pgtype433;
	Y4782_gen_type [434] = Y4782_pgtype434;
	Y4782_gen_type [435] = Y4782_pgtype435;
	Y4782_gen_type [436] = Y4782_pgtype436;
	Y4782_gen_type [437] = Y4782_pgtype437;
	Y4782_gen_type [438] = Y4782_pgtype438;
	Y4782_gen_type [439] = Y4782_pgtype439;
	Y4782_gen_type [440] = Y4782_pgtype440;
	Y4782_gen_type [441] = Y4782_pgtype441;
	Y4782_gen_type [442] = Y4782_pgtype442;
	Y4782_gen_type [443] = Y4782_pgtype443;
	Y4782_gen_type [444] = Y4782_pgtype444;
	Y4782_gen_type [445] = Y4782_pgtype445;
	Y4782_gen_type [446] = Y4782_pgtype446;
	Y4782_gen_type [447] = Y4782_pgtype447;
	Y4782_gen_type [448] = Y4782_pgtype448;
	Y4782_gen_type [449] = Y4782_pgtype449;
	Y4782_gen_type [450] = Y4782_pgtype450;
	Y4782_gen_type [451] = Y4782_pgtype451;
	Y4782_gen_type [452] = Y4782_pgtype452;
	Y4782_gen_type [453] = Y4782_pgtype453;
	Y4782_gen_type [454] = Y4782_pgtype454;
	Y4782_gen_type [455] = Y4782_pgtype455;
	Y4782_gen_type [456] = Y4782_pgtype456;
	Y4782_gen_type [457] = Y4782_pgtype457;
	Y4782_gen_type [458] = Y4782_pgtype458;
	Y4782_gen_type [459] = Y4782_pgtype459;
	Y4782_gen_type [460] = Y4782_pgtype460;
	Y4782_gen_type [461] = Y4782_pgtype461;
	Y4782_gen_type [462] = Y4782_pgtype462;
	Y4782_gen_type [463] = Y4782_pgtype463;
	Y4782_gen_type [464] = Y4782_pgtype464;
	Y4782_gen_type [465] = Y4782_pgtype465;
	Y4782_gen_type [466] = Y4782_pgtype466;
	Y4782_gen_type [467] = Y4782_pgtype467;
	Y4782_gen_type [468] = Y4782_pgtype468;
	Y4782_gen_type [469] = Y4782_pgtype469;
	Y4782_gen_type [540] = Y4782_pgtype470;
	Y4782_gen_type [557] = Y4782_pgtype471;
	Y4782_gen_type [611] = Y4782_pgtype472;
	Y4782_gen_type [612] = Y4782_pgtype473;
	Y4782_gen_type [613] = Y4782_pgtype474;
	Y4782_gen_type [614] = Y4782_pgtype475;
	Y4782_gen_type [615] = Y4782_pgtype476;
	Y4782_gen_type [616] = Y4782_pgtype477;
	Y4782_gen_type [617] = Y4782_pgtype478;
	Y4782_gen_type [618] = Y4782_pgtype479;
	Y4782_gen_type [621] = Y4782_pgtype480;
	Y4782_gen_type [623] = Y4782_pgtype481;
	Y4782_gen_type [669] = Y4782_pgtype482;
	Y4782_gen_type [670] = Y4782_pgtype483;
	Y4782_gen_type [671] = Y4782_pgtype484;
	Y4782_gen_type [672] = Y4782_pgtype485;
	Y4782_gen_type [673] = Y4782_pgtype486;
	Y4782_gen_type [674] = Y4782_pgtype487;
	Y4782_gen_type [675] = Y4782_pgtype488;
	Y4782_gen_type [676] = Y4782_pgtype489;
	Y4782_gen_type [677] = Y4782_pgtype490;
	Y4782_gen_type [678] = Y4782_pgtype491;
	Y4782_gen_type [679] = Y4782_pgtype492;
	Y4782_gen_type [680] = Y4782_pgtype493;
	Y4782_gen_type [773] = Y4782_pgtype494;
	Y4782_gen_type [774] = Y4782_pgtype495;
	Y4782_gen_type [785] = Y4782_pgtype496;
	Y4782_gen_type [787] = Y4782_pgtype497;
	Y4782_gen_type [788] = Y4782_pgtype498;
	Y4782_gen_type [789] = Y4782_pgtype499;
	Y4782_gen_type [829] = Y4782_pgtype500;
	Y4782_gen_type [830] = Y4782_pgtype501;
	Y4782_gen_type [831] = Y4782_pgtype502;
	Y4782_gen_type [833] = Y4782_pgtype503;
	Y4782_gen_type [834] = Y4782_pgtype504;
	Y4782_gen_type [835] = Y4782_pgtype505;
	Y4782_gen_type [836] = Y4782_pgtype506;
	Y4782_gen_type [837] = Y4782_pgtype507;
	Y4782_gen_type [874] = Y4782_pgtype508;
	Y4782_gen_type [875] = Y4782_pgtype509;
	Y4782[12] = 1052;
	Y4782[13] = 1056;
	Y4782[14] = 1001;
	Y4782[85] = 1004;
	Y4782[86] = 1001;
	Y4782[111] = 1061;
	{long i; for (i = 264; i < 266; i++) Y4782[i] = 1187;};
	{long i; for (i = 332; i < 335; i++) Y4782[i] = 1004;};
	Y4782[343] = 1055;
	Y4782[364] = 0;
	Y4782[382] = 1187;
	Y4782[468] = 1261;
	Y4782[469] = 908;
	Y4782[557] = 0;
	{long i; for (i = 611; i < 616; i++) Y4782[i] = 1004;};
	{long i; for (i = 616; i < 619; i++) Y4782[i] = 1001;};
	Y4782[621] = 1061;
	Y4782[623] = 1061;
	{long i; for (i = 773; i < 775; i++) Y4782[i] = 1176;};
	Y4782[785] = 1004;
	{long i; for (i = 829; i < 832; i++) Y4782[i] = 1004;};
	{long i; for (i = 833; i < 838; i++) Y4782[i] = 1004;};
	{long i; for (i = 874; i < 876; i++) Y4782[i] = 1004;};
}

char *(*R4834[72])();
void R4834_init () {
	R4834[0] = (char *(*)()) F479_5331;
	R4834[1] = (char *(*)()) F480_5331;
	R4834[2] = (char *(*)()) F481_5331;
	R4834[3] = (char *(*)()) F482_5331;
	R4834[4] = (char *(*)()) F483_5331;
	R4834[5] = (char *(*)()) F484_5331;
	R4834[6] = (char *(*)()) F485_5331;
	R4834[7] = (char *(*)()) F486_5331;
	R4834[8] = (char *(*)()) F487_5331;
	R4834[9] = (char *(*)()) F488_5331;
	R4834[10] = (char *(*)()) F489_5331;
	R4834[11] = (char *(*)()) F490_5331;
	R4834[12] = (char *(*)()) F479_5331;
	R4834[13] = (char *(*)()) F480_5331;
	{long i; for (i = 14; i < 16; i++) R4834[i] = (char *(*)()) F479_5331;}
	R4834[16] = (char *(*)()) F484_5331;
	R4834[17] = (char *(*)()) F480_5331;
	R4834[18] = (char *(*)()) F486_5331;
	R4834[19] = (char *(*)()) F481_5331;
	R4834[20] = (char *(*)()) F480_5331;
	R4834[21] = (char *(*)()) F487_5331;
	R4834[34] = (char *(*)()) F501_5365;
	R4834[35] = (char *(*)()) F502_5365;
	R4834[36] = (char *(*)()) F503_5365;
	R4834[37] = (char *(*)()) F504_5365;
	R4834[38] = (char *(*)()) F505_5365;
	R4834[39] = (char *(*)()) F506_5365;
	R4834[40] = (char *(*)()) F507_5365;
	R4834[41] = (char *(*)()) F508_5365;
	R4834[42] = (char *(*)()) F509_5365;
	R4834[43] = (char *(*)()) F510_5365;
	R4834[44] = (char *(*)()) F511_5365;
	R4834[45] = (char *(*)()) F512_5365;
	R4834[46] = (char *(*)()) F505_5365;
	R4834[47] = (char *(*)()) F508_5365;
	R4834[48] = (char *(*)()) F501_5365;
	R4834[49] = (char *(*)()) F502_5365;
	R4834[50] = (char *(*)()) F503_5365;
	R4834[51] = (char *(*)()) F504_5365;
	R4834[52] = (char *(*)()) F505_5365;
	R4834[53] = (char *(*)()) F506_5365;
	R4834[54] = (char *(*)()) F507_5365;
	R4834[55] = (char *(*)()) F508_5365;
	R4834[56] = (char *(*)()) F509_5365;
	R4834[57] = (char *(*)()) F510_5365;
	R4834[58] = (char *(*)()) F511_5365;
	R4834[59] = (char *(*)()) F512_5365;
	R4834[60] = (char *(*)()) F501_5365;
	R4834[61] = (char *(*)()) F502_5365;
	R4834[62] = (char *(*)()) F503_5365;
	R4834[63] = (char *(*)()) F504_5365;
	R4834[64] = (char *(*)()) F505_5365;
	R4834[65] = (char *(*)()) F506_5365;
	R4834[66] = (char *(*)()) F507_5365;
	R4834[67] = (char *(*)()) F508_5365;
	R4834[68] = (char *(*)()) F509_5365;
	R4834[69] = (char *(*)()) F510_5365;
	R4834[70] = (char *(*)()) F511_5365;
	R4834[71] = (char *(*)()) F512_5365;
}

char *(*R4835[72])();
void R4835_init () {
	R4835[0] = (char *(*)()) F479_5332;
	R4835[1] = (char *(*)()) F480_5332;
	R4835[2] = (char *(*)()) F481_5332;
	R4835[3] = (char *(*)()) F482_5332;
	R4835[4] = (char *(*)()) F483_5332;
	R4835[5] = (char *(*)()) F484_5332;
	R4835[6] = (char *(*)()) F485_5332;
	R4835[7] = (char *(*)()) F486_5332;
	R4835[8] = (char *(*)()) F487_5332;
	R4835[9] = (char *(*)()) F488_5332;
	R4835[10] = (char *(*)()) F489_5332;
	R4835[11] = (char *(*)()) F490_5332;
	R4835[12] = (char *(*)()) F479_5332;
	R4835[13] = (char *(*)()) F480_5332;
	{long i; for (i = 14; i < 16; i++) R4835[i] = (char *(*)()) F479_5332;}
	R4835[16] = (char *(*)()) F484_5332;
	R4835[17] = (char *(*)()) F480_5332;
	R4835[18] = (char *(*)()) F486_5332;
	R4835[19] = (char *(*)()) F481_5332;
	R4835[20] = (char *(*)()) F480_5332;
	R4835[21] = (char *(*)()) F487_5332;
	R4835[34] = (char *(*)()) F513_5384;
	R4835[35] = (char *(*)()) F514_5384;
	R4835[36] = (char *(*)()) F515_5384;
	R4835[37] = (char *(*)()) F516_5384;
	R4835[38] = (char *(*)()) F517_5384;
	R4835[39] = (char *(*)()) F518_5384;
	R4835[40] = (char *(*)()) F519_5384;
	R4835[41] = (char *(*)()) F520_5384;
	R4835[42] = (char *(*)()) F521_5384;
	R4835[43] = (char *(*)()) F522_5384;
	R4835[44] = (char *(*)()) F523_5384;
	R4835[45] = (char *(*)()) F524_5384;
	R4835[46] = (char *(*)()) F525_5390;
	R4835[47] = (char *(*)()) F526_5396;
	R4835[48] = (char *(*)()) F527_5402;
	R4835[49] = (char *(*)()) F528_5402;
	R4835[50] = (char *(*)()) F529_5402;
	R4835[51] = (char *(*)()) F530_5402;
	R4835[52] = (char *(*)()) F531_5402;
	R4835[53] = (char *(*)()) F532_5402;
	R4835[54] = (char *(*)()) F533_5402;
	R4835[55] = (char *(*)()) F534_5402;
	R4835[56] = (char *(*)()) F535_5402;
	R4835[57] = (char *(*)()) F536_5402;
	R4835[58] = (char *(*)()) F537_5402;
	R4835[59] = (char *(*)()) F538_5402;
	R4835[60] = (char *(*)()) F539_5408;
	R4835[61] = (char *(*)()) F540_5408;
	R4835[62] = (char *(*)()) F541_5408;
	R4835[63] = (char *(*)()) F542_5408;
	R4835[64] = (char *(*)()) F543_5408;
	R4835[65] = (char *(*)()) F544_5408;
	R4835[66] = (char *(*)()) F545_5408;
	R4835[67] = (char *(*)()) F546_5408;
	R4835[68] = (char *(*)()) F547_5408;
	R4835[69] = (char *(*)()) F548_5408;
	R4835[70] = (char *(*)()) F549_5408;
	R4835[71] = (char *(*)()) F550_5408;
}

char *(*R4843[22])();
void R4843_init () {
	R4843[0] = (char *(*)()) F479_5343;
	R4843[1] = (char *(*)()) F480_5343;
	R4843[2] = (char *(*)()) F481_5343;
	R4843[3] = (char *(*)()) F482_5343;
	R4843[4] = (char *(*)()) F483_5343;
	R4843[5] = (char *(*)()) F484_5343;
	R4843[6] = (char *(*)()) F485_5343;
	R4843[7] = (char *(*)()) F486_5343;
	R4843[8] = (char *(*)()) F487_5343;
	R4843[9] = (char *(*)()) F488_5343;
	R4843[10] = (char *(*)()) F489_5343;
	R4843[11] = (char *(*)()) F490_5343;
	R4843[12] = (char *(*)()) F479_5343;
	R4843[13] = (char *(*)()) F480_5343;
	{long i; for (i = 14; i < 16; i++) R4843[i] = (char *(*)()) F479_5343;}
	R4843[16] = (char *(*)()) F484_5343;
	R4843[17] = (char *(*)()) F480_5343;
	R4843[18] = (char *(*)()) F486_5343;
	R4843[19] = (char *(*)()) F481_5343;
	R4843[20] = (char *(*)()) F480_5343;
	R4843[21] = (char *(*)()) F487_5343;
}

char *(*R4845[72])();
void R4845_init () {
	R4845[0] = (char *(*)()) F479_5345;
	R4845[1] = (char *(*)()) F480_5345;
	R4845[2] = (char *(*)()) F481_5345;
	R4845[3] = (char *(*)()) F482_5345;
	R4845[4] = (char *(*)()) F483_5345;
	R4845[5] = (char *(*)()) F484_5345;
	R4845[6] = (char *(*)()) F485_5345;
	R4845[7] = (char *(*)()) F486_5345;
	R4845[8] = (char *(*)()) F487_5345;
	R4845[9] = (char *(*)()) F488_5345;
	R4845[10] = (char *(*)()) F489_5345;
	R4845[11] = (char *(*)()) F490_5345;
	R4845[12] = (char *(*)()) F479_5345;
	R4845[13] = (char *(*)()) F480_5345;
	{long i; for (i = 14; i < 16; i++) R4845[i] = (char *(*)()) F479_5345;}
	R4845[16] = (char *(*)()) F484_5345;
	R4845[17] = (char *(*)()) F480_5345;
	R4845[18] = (char *(*)()) F486_5345;
	R4845[19] = (char *(*)()) F481_5345;
	R4845[20] = (char *(*)()) F480_5345;
	R4845[21] = (char *(*)()) F487_5345;
	R4845[34] = (char *(*)()) F501_5376;
	R4845[35] = (char *(*)()) F502_5376;
	R4845[36] = (char *(*)()) F503_5376;
	R4845[37] = (char *(*)()) F504_5376;
	R4845[38] = (char *(*)()) F505_5376;
	R4845[39] = (char *(*)()) F506_5376;
	R4845[40] = (char *(*)()) F507_5376;
	R4845[41] = (char *(*)()) F508_5376;
	R4845[42] = (char *(*)()) F509_5376;
	R4845[43] = (char *(*)()) F510_5376;
	R4845[44] = (char *(*)()) F511_5376;
	R4845[45] = (char *(*)()) F512_5376;
	R4845[46] = (char *(*)()) F505_5376;
	R4845[47] = (char *(*)()) F508_5376;
	R4845[48] = (char *(*)()) F501_5376;
	R4845[49] = (char *(*)()) F502_5376;
	R4845[50] = (char *(*)()) F503_5376;
	R4845[51] = (char *(*)()) F504_5376;
	R4845[52] = (char *(*)()) F505_5376;
	R4845[53] = (char *(*)()) F506_5376;
	R4845[54] = (char *(*)()) F507_5376;
	R4845[55] = (char *(*)()) F508_5376;
	R4845[56] = (char *(*)()) F509_5376;
	R4845[57] = (char *(*)()) F510_5376;
	R4845[58] = (char *(*)()) F511_5376;
	R4845[59] = (char *(*)()) F512_5376;
	R4845[60] = (char *(*)()) F501_5376;
	R4845[61] = (char *(*)()) F502_5376;
	R4845[62] = (char *(*)()) F503_5376;
	R4845[63] = (char *(*)()) F504_5376;
	R4845[64] = (char *(*)()) F505_5376;
	R4845[65] = (char *(*)()) F506_5376;
	R4845[66] = (char *(*)()) F507_5376;
	R4845[67] = (char *(*)()) F508_5376;
	R4845[68] = (char *(*)()) F509_5376;
	R4845[69] = (char *(*)()) F510_5376;
	R4845[70] = (char *(*)()) F511_5376;
	R4845[71] = (char *(*)()) F512_5376;
}

char *(*R4846[72])();
void R4846_init () {
	R4846[0] = (char *(*)()) F479_5348;
	R4846[1] = (char *(*)()) F480_5348;
	R4846[2] = (char *(*)()) F481_5348;
	R4846[3] = (char *(*)()) F482_5348;
	R4846[4] = (char *(*)()) F483_5348;
	R4846[5] = (char *(*)()) F484_5348;
	R4846[6] = (char *(*)()) F485_5348;
	R4846[7] = (char *(*)()) F486_5348;
	R4846[8] = (char *(*)()) F487_5348;
	R4846[9] = (char *(*)()) F488_5348;
	R4846[10] = (char *(*)()) F489_5348;
	R4846[11] = (char *(*)()) F490_5348;
	R4846[12] = (char *(*)()) F491_5353;
	R4846[13] = (char *(*)()) F492_5353;
	{long i; for (i = 14; i < 16; i++) R4846[i] = (char *(*)()) F479_5348;}
	R4846[16] = (char *(*)()) F484_5348;
	R4846[17] = (char *(*)()) F480_5348;
	R4846[18] = (char *(*)()) F486_5348;
	R4846[19] = (char *(*)()) F481_5348;
	R4846[20] = (char *(*)()) F480_5348;
	R4846[21] = (char *(*)()) F487_5348;
	R4846[34] = (char *(*)()) F501_5377;
	R4846[35] = (char *(*)()) F502_5377;
	R4846[36] = (char *(*)()) F503_5377;
	R4846[37] = (char *(*)()) F504_5377;
	R4846[38] = (char *(*)()) F505_5377;
	R4846[39] = (char *(*)()) F506_5377;
	R4846[40] = (char *(*)()) F507_5377;
	R4846[41] = (char *(*)()) F508_5377;
	R4846[42] = (char *(*)()) F509_5377;
	R4846[43] = (char *(*)()) F510_5377;
	R4846[44] = (char *(*)()) F511_5377;
	R4846[45] = (char *(*)()) F512_5377;
	R4846[46] = (char *(*)()) F505_5377;
	R4846[47] = (char *(*)()) F508_5377;
	R4846[48] = (char *(*)()) F501_5377;
	R4846[49] = (char *(*)()) F502_5377;
	R4846[50] = (char *(*)()) F503_5377;
	R4846[51] = (char *(*)()) F504_5377;
	R4846[52] = (char *(*)()) F505_5377;
	R4846[53] = (char *(*)()) F506_5377;
	R4846[54] = (char *(*)()) F507_5377;
	R4846[55] = (char *(*)()) F508_5377;
	R4846[56] = (char *(*)()) F509_5377;
	R4846[57] = (char *(*)()) F510_5377;
	R4846[58] = (char *(*)()) F511_5377;
	R4846[59] = (char *(*)()) F512_5377;
	R4846[60] = (char *(*)()) F501_5377;
	R4846[61] = (char *(*)()) F502_5377;
	R4846[62] = (char *(*)()) F503_5377;
	R4846[63] = (char *(*)()) F504_5377;
	R4846[64] = (char *(*)()) F505_5377;
	R4846[65] = (char *(*)()) F506_5377;
	R4846[66] = (char *(*)()) F507_5377;
	R4846[67] = (char *(*)()) F508_5377;
	R4846[68] = (char *(*)()) F509_5377;
	R4846[69] = (char *(*)()) F510_5377;
	R4846[70] = (char *(*)()) F511_5377;
	R4846[71] = (char *(*)()) F512_5377;
}

char *(*R4847[72])();
void R4847_init () {
	R4847[0] = (char *(*)()) F479_5350;
	R4847[1] = (char *(*)()) F480_5350;
	R4847[2] = (char *(*)()) F481_5350;
	R4847[3] = (char *(*)()) F482_5350;
	R4847[4] = (char *(*)()) F483_5350;
	R4847[5] = (char *(*)()) F484_5350;
	R4847[6] = (char *(*)()) F485_5350;
	R4847[7] = (char *(*)()) F486_5350;
	R4847[8] = (char *(*)()) F487_5350;
	R4847[9] = (char *(*)()) F488_5350;
	R4847[10] = (char *(*)()) F489_5350;
	R4847[11] = (char *(*)()) F490_5350;
	R4847[12] = (char *(*)()) F491_5355;
	R4847[13] = (char *(*)()) F492_5355;
	R4847[14] = (char *(*)()) F493_5362;
	R4847[15] = (char *(*)()) F494_5362;
	R4847[16] = (char *(*)()) F495_5362;
	R4847[17] = (char *(*)()) F496_5362;
	R4847[18] = (char *(*)()) F497_5362;
	R4847[19] = (char *(*)()) F498_5362;
	R4847[20] = (char *(*)()) F499_5362;
	R4847[21] = (char *(*)()) F500_5362;
	R4847[34] = (char *(*)()) F513_5387;
	R4847[35] = (char *(*)()) F514_5387;
	R4847[36] = (char *(*)()) F515_5387;
	R4847[37] = (char *(*)()) F516_5387;
	R4847[38] = (char *(*)()) F517_5387;
	R4847[39] = (char *(*)()) F518_5387;
	R4847[40] = (char *(*)()) F519_5387;
	R4847[41] = (char *(*)()) F520_5387;
	R4847[42] = (char *(*)()) F521_5387;
	R4847[43] = (char *(*)()) F522_5387;
	R4847[44] = (char *(*)()) F523_5387;
	R4847[45] = (char *(*)()) F524_5387;
	R4847[46] = (char *(*)()) F525_5393;
	R4847[47] = (char *(*)()) F526_5399;
	R4847[48] = (char *(*)()) F527_5405;
	R4847[49] = (char *(*)()) F528_5405;
	R4847[50] = (char *(*)()) F529_5405;
	R4847[51] = (char *(*)()) F530_5405;
	R4847[52] = (char *(*)()) F531_5405;
	R4847[53] = (char *(*)()) F532_5405;
	R4847[54] = (char *(*)()) F533_5405;
	R4847[55] = (char *(*)()) F534_5405;
	R4847[56] = (char *(*)()) F535_5405;
	R4847[57] = (char *(*)()) F536_5405;
	R4847[58] = (char *(*)()) F537_5405;
	R4847[59] = (char *(*)()) F538_5405;
	R4847[60] = (char *(*)()) F501_5379;
	R4847[61] = (char *(*)()) F502_5379;
	R4847[62] = (char *(*)()) F503_5379;
	R4847[63] = (char *(*)()) F504_5379;
	R4847[64] = (char *(*)()) F505_5379;
	R4847[65] = (char *(*)()) F506_5379;
	R4847[66] = (char *(*)()) F507_5379;
	R4847[67] = (char *(*)()) F508_5379;
	R4847[68] = (char *(*)()) F509_5379;
	R4847[69] = (char *(*)()) F510_5379;
	R4847[70] = (char *(*)()) F511_5379;
	R4847[71] = (char *(*)()) F512_5379;
}

char *(*R4849[22])();
void R4849_init () {
	R4849[0] = (char *(*)()) F479_5329;
	R4849[1] = (char *(*)()) F480_5329;
	R4849[2] = (char *(*)()) F481_5329;
	R4849[3] = (char *(*)()) F482_5329;
	R4849[4] = (char *(*)()) F483_5329;
	R4849[5] = (char *(*)()) F484_5329;
	R4849[6] = (char *(*)()) F485_5329;
	R4849[7] = (char *(*)()) F486_5329;
	R4849[8] = (char *(*)()) F487_5329;
	R4849[9] = (char *(*)()) F488_5329;
	R4849[10] = (char *(*)()) F489_5329;
	R4849[11] = (char *(*)()) F490_5329;
	R4849[12] = (char *(*)()) F479_5329;
	R4849[13] = (char *(*)()) F480_5329;
	{long i; for (i = 14; i < 16; i++) R4849[i] = (char *(*)()) F479_5329;}
	R4849[16] = (char *(*)()) F484_5329;
	R4849[17] = (char *(*)()) F480_5329;
	R4849[18] = (char *(*)()) F486_5329;
	R4849[19] = (char *(*)()) F481_5329;
	R4849[20] = (char *(*)()) F480_5329;
	R4849[21] = (char *(*)()) F487_5329;
}

char *(*R4862[38])();
void R4862_init () {
	R4862[0] = (char *(*)()) F513_5388;
	R4862[1] = (char *(*)()) F514_5388;
	R4862[2] = (char *(*)()) F515_5388;
	R4862[3] = (char *(*)()) F516_5388;
	R4862[4] = (char *(*)()) F517_5388;
	R4862[5] = (char *(*)()) F518_5388;
	R4862[6] = (char *(*)()) F519_5388;
	R4862[7] = (char *(*)()) F520_5388;
	R4862[8] = (char *(*)()) F521_5388;
	R4862[9] = (char *(*)()) F522_5388;
	R4862[10] = (char *(*)()) F523_5388;
	R4862[11] = (char *(*)()) F524_5388;
	R4862[12] = (char *(*)()) F525_5394;
	R4862[13] = (char *(*)()) F526_5400;
	R4862[14] = (char *(*)()) F527_5406;
	R4862[15] = (char *(*)()) F528_5406;
	R4862[16] = (char *(*)()) F529_5406;
	R4862[17] = (char *(*)()) F530_5406;
	R4862[18] = (char *(*)()) F531_5406;
	R4862[19] = (char *(*)()) F532_5406;
	R4862[20] = (char *(*)()) F533_5406;
	R4862[21] = (char *(*)()) F534_5406;
	R4862[22] = (char *(*)()) F535_5406;
	R4862[23] = (char *(*)()) F536_5406;
	R4862[24] = (char *(*)()) F537_5406;
	R4862[25] = (char *(*)()) F538_5406;
	R4862[26] = (char *(*)()) F539_5410;
	R4862[27] = (char *(*)()) F540_5410;
	R4862[28] = (char *(*)()) F541_5410;
	R4862[29] = (char *(*)()) F542_5410;
	R4862[30] = (char *(*)()) F543_5410;
	R4862[31] = (char *(*)()) F544_5410;
	R4862[32] = (char *(*)()) F545_5410;
	R4862[33] = (char *(*)()) F546_5410;
	R4862[34] = (char *(*)()) F547_5410;
	R4862[35] = (char *(*)()) F548_5410;
	R4862[36] = (char *(*)()) F549_5410;
	R4862[37] = (char *(*)()) F550_5410;
}

char *(*R4864[12])();
void R4864_init () {
	R4864[0] = (char *(*)()) F513_5383;
	R4864[1] = (char *(*)()) F514_5383;
	R4864[2] = (char *(*)()) F515_5383;
	R4864[3] = (char *(*)()) F516_5383;
	R4864[4] = (char *(*)()) F517_5383;
	R4864[5] = (char *(*)()) F518_5383;
	R4864[6] = (char *(*)()) F519_5383;
	R4864[7] = (char *(*)()) F520_5383;
	R4864[8] = (char *(*)()) F521_5383;
	R4864[9] = (char *(*)()) F522_5383;
	R4864[10] = (char *(*)()) F523_5383;
	R4864[11] = (char *(*)()) F524_5383;
}

char *(*R4872[12])();
void R4872_init () {
	R4872[0] = (char *(*)()) F527_5401;
	R4872[1] = (char *(*)()) F528_5401;
	R4872[2] = (char *(*)()) F529_5401;
	R4872[3] = (char *(*)()) F530_5401;
	R4872[4] = (char *(*)()) F531_5401;
	R4872[5] = (char *(*)()) F532_5401;
	R4872[6] = (char *(*)()) F533_5401;
	R4872[7] = (char *(*)()) F534_5401;
	R4872[8] = (char *(*)()) F535_5401;
	R4872[9] = (char *(*)()) F536_5401;
	R4872[10] = (char *(*)()) F537_5401;
	R4872[11] = (char *(*)()) F538_5401;
}

char *(*R4875[12])();
void R4875_init () {
	R4875[0] = (char *(*)()) F539_5407;
	R4875[1] = (char *(*)()) F540_5407;
	R4875[2] = (char *(*)()) F541_5407;
	R4875[3] = (char *(*)()) F542_5407;
	R4875[4] = (char *(*)()) F543_5407;
	R4875[5] = (char *(*)()) F544_5407;
	R4875[6] = (char *(*)()) F545_5407;
	R4875[7] = (char *(*)()) F546_5407;
	R4875[8] = (char *(*)()) F547_5407;
	R4875[9] = (char *(*)()) F548_5407;
	R4875[10] = (char *(*)()) F549_5407;
	R4875[11] = (char *(*)()) F550_5407;
}

char *(*R4877[3])();
void R4877_init () {
	R4877[0] = (char *(*)()) F1061_8191;
	R4877[2] = (char *(*)()) F1063_8250;
}

char *(*R4881[3])();
void R4881_init () {
	R4881[0] = (char *(*)()) F1061_8192;
	R4881[2] = (char *(*)()) F1063_8252;
}

char *(*R4886[3])();
void R4886_init () {
	R4886[0] = (char *(*)()) F1061_8197;
	R4886[2] = (char *(*)()) F1063_8255;
}

char *(*R4890[611])();
void R4890_init () {
	R4890[0] = (char *(*)()) F704_5557_4890_2;
	R4890[1] = (char *(*)()) F705_5576_4890_2;
	{long i; for (i = 69; i < 71; i++) R4890[i] = (char *(*)()) F580_5442_4890_2;}
	R4890[119] = (char *(*)()) F823_6191;
	R4890[120] = (char *(*)()) F824_6191_4890_2;
	R4890[121] = (char *(*)()) F825_6191_4890_2;
	R4890[122] = (char *(*)()) F826_6191_4890_2;
	R4890[123] = (char *(*)()) F827_6191_4890_2;
	R4890[124] = (char *(*)()) F828_6191_4890_2;
	R4890[125] = (char *(*)()) F829_6191_4890_2;
	R4890[126] = (char *(*)()) F830_6191_4890_2;
	R4890[127] = (char *(*)()) F831_6191_4890_2;
	R4890[128] = (char *(*)()) F832_6191_4890_2;
	R4890[129] = (char *(*)()) F833_6191_4890_2;
	R4890[130] = (char *(*)()) F834_6191_4890_2;
	R4890[184] = (char *(*)()) F840_6244;
	R4890[185] = (char *(*)()) F841_6244_4890_2;
	R4890[186] = (char *(*)()) F840_6244;
	R4890[187] = (char *(*)()) F841_6244_4890_2;
	R4890[188] = (char *(*)()) F840_6244;
	R4890[189] = (char *(*)()) F893_6374;
	R4890[190] = (char *(*)()) F894_6374_4890_2;
	R4890[191] = (char *(*)()) F895_6374_4890_2;
	R4890[192] = (char *(*)()) F896_6374_4890_2;
	R4890[193] = (char *(*)()) F897_6374_4890_2;
	R4890[194] = (char *(*)()) F898_6374_4890_2;
	R4890[195] = (char *(*)()) F899_6374_4890_2;
	R4890[196] = (char *(*)()) F900_6374_4890_2;
	R4890[197] = (char *(*)()) F901_6374_4890_2;
	R4890[198] = (char *(*)()) F902_6374_4890_2;
	R4890[199] = (char *(*)()) F903_6374_4890_2;
	R4890[200] = (char *(*)()) F904_6374_4890_2;
	{long i; for (i = 201; i < 203; i++) R4890[i] = (char *(*)()) F893_6374;}
	R4890[203] = (char *(*)()) F894_6374_4890_2;
	{long i; for (i = 204; i < 206; i++) R4890[i] = (char *(*)()) F893_6374;}
	R4890[276] = (char *(*)()) F893_6374;
	{long i; for (i = 349; i < 351; i++) R4890[i] = (char *(*)()) F1051_7850_4890_2;}
	R4890[354] = (char *(*)()) F1056_8018_4890_2;
	R4890[521] = (char *(*)()) F580_5442_4890_2;
	R4890[573] = (char *(*)()) F580_5442_4890_2;
	R4890[610] = (char *(*)()) F1314_13107_4890_2;
}
static EIF_BOOLEAN F704_5557_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F704_5557(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F705_5576_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F705_5576(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F580_5442_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F580_5442(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F824_6191_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F824_6191(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F825_6191_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F825_6191(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F826_6191_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F826_6191(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F827_6191_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F827_6191(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F828_6191_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F828_6191(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F829_6191_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F829_6191(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F830_6191_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F830_6191(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F831_6191_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F831_6191(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F832_6191_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F832_6191(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F833_6191_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F833_6191(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F834_6191_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F834_6191(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F841_6244_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F841_6244(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F894_6374_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F894_6374(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F895_6374_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F895_6374(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F896_6374_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F896_6374(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F897_6374_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F897_6374(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F898_6374_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F898_6374(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F899_6374_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F899_6374(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F900_6374_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F900_6374(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F901_6374_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F901_6374(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F902_6374_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F902_6374(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F903_6374_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F903_6374(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F904_6374_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F904_6374(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1051_7850_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1051_7850(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1056_8018_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1056_8018(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1314_13107_4890_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1314_13107(Current, *(EIF_CHARACTER_8 *)arg1);
}


#ifdef __cplusplus
}
#endif
