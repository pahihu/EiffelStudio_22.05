#include "epoly7.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5209[452])();
void R5209_init () {
	R5209[0] = (char *(*)()) F774_5983;
	R5209[451] = (char *(*)()) F1225_10163;
}

char *(*R5231[519])();
void R5231_init () {
	R5231[0] = (char *(*)()) F796_6028;
	R5231[1] = (char *(*)()) F797_6028;
	R5231[2] = (char *(*)()) F798_6028_5231_27;
	R5231[3] = (char *(*)()) F799_6028_5231_27;
	R5231[4] = (char *(*)()) F800_6028_5231_27;
	R5231[5] = (char *(*)()) F801_6028_5231_27;
	R5231[6] = (char *(*)()) F802_6028_5231_27;
	R5231[7] = (char *(*)()) F803_6028_5231_27;
	{long i; for (i = 8; i < 10; i++) R5231[i] = (char *(*)()) F796_6028;}
	R5231[10] = (char *(*)()) F800_6028_5231_27;
	R5231[11] = (char *(*)()) F799_6028_5231_27;
	R5231[12] = (char *(*)()) F801_6028_5231_27;
	R5231[13] = (char *(*)()) F803_6028_5231_27;
	R5231[26] = (char *(*)()) F822_6149_5231_27;
	R5231[27] = (char *(*)()) F823_6188;
	R5231[28] = (char *(*)()) F824_6188_5231_27;
	R5231[29] = (char *(*)()) F825_6188_5231_27;
	R5231[30] = (char *(*)()) F826_6188_5231_27;
	R5231[31] = (char *(*)()) F827_6188_5231_27;
	R5231[32] = (char *(*)()) F828_6188_5231_27;
	R5231[33] = (char *(*)()) F829_6188_5231_27;
	R5231[34] = (char *(*)()) F830_6188_5231_27;
	R5231[35] = (char *(*)()) F831_6188_5231_27;
	R5231[36] = (char *(*)()) F832_6188_5231_27;
	R5231[37] = (char *(*)()) F833_6188_5231_27;
	R5231[38] = (char *(*)()) F834_6188_5231_27;
	R5231[92] = (char *(*)()) F840_6246;
	R5231[93] = (char *(*)()) F841_6246_5231_27;
	R5231[94] = (char *(*)()) F840_6246;
	R5231[95] = (char *(*)()) F841_6246_5231_27;
	R5231[96] = (char *(*)()) F840_6246;
	R5231[97] = (char *(*)()) F893_6368;
	R5231[98] = (char *(*)()) F894_6368_5231_27;
	R5231[99] = (char *(*)()) F895_6368_5231_27;
	R5231[100] = (char *(*)()) F896_6368_5231_27;
	R5231[101] = (char *(*)()) F897_6368_5231_27;
	R5231[102] = (char *(*)()) F898_6368_5231_27;
	R5231[103] = (char *(*)()) F899_6368_5231_27;
	R5231[104] = (char *(*)()) F900_6368_5231_27;
	R5231[105] = (char *(*)()) F901_6368_5231_27;
	R5231[106] = (char *(*)()) F902_6368_5231_27;
	R5231[107] = (char *(*)()) F903_6368_5231_27;
	R5231[108] = (char *(*)()) F904_6368_5231_27;
	{long i; for (i = 109; i < 111; i++) R5231[i] = (char *(*)()) F893_6368;}
	R5231[111] = (char *(*)()) F894_6368_5231_27;
	{long i; for (i = 112; i < 114; i++) R5231[i] = (char *(*)()) F893_6368;}
	R5231[184] = (char *(*)()) F893_6368;
	R5231[201] = (char *(*)()) F997_7329;
	R5231[256] = (char *(*)()) F1052_7872_5231_27;
	{long i; for (i = 257; i < 259; i++) R5231[i] = (char *(*)()) F1053_7894_5231_27;}
	R5231[261] = (char *(*)()) F1057_8043_5231_27;
	R5231[262] = (char *(*)()) F1058_8066_5231_27;
	R5231[313] = (char *(*)()) F1109_8724;
	R5231[314] = (char *(*)()) F1110_8724_5231_27;
	R5231[315] = (char *(*)()) F1111_8724_5231_27;
	R5231[316] = (char *(*)()) F1112_8724_5231_27;
	R5231[317] = (char *(*)()) F1113_8724_5231_27;
	R5231[318] = (char *(*)()) F1114_8724_5231_27;
	R5231[319] = (char *(*)()) F1115_8724_5231_27;
	R5231[320] = (char *(*)()) F1116_8724_5231_27;
	R5231[321] = (char *(*)()) F1117_8724_5231_27;
	R5231[322] = (char *(*)()) F1118_8724_5231_27;
	R5231[323] = (char *(*)()) F1119_8724_5231_27;
	R5231[324] = (char *(*)()) F1120_8724_5231_27;
	R5231[518] = (char *(*)()) F1314_13086_5231_27;
}
static EIF_REFERENCE F798_6028_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F798_6028(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F799_6028_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F799_6028(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_6028_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F800_6028(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_6028_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F801_6028(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_6028_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F802_6028(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F803_6028_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F803_6028(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F822_6149_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F822_6149(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F824_6188_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F824_6188(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F825_6188_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F825_6188(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F826_6188_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F826_6188(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F827_6188_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F827_6188(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F828_6188_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F828_6188(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1196, 0x00).id, 1196, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F829_6188_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F829_6188(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F830_6188_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F830_6188(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F831_6188_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F831_6188(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F832_6188_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F832_6188(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F833_6188_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F833_6188(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F834_6188_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F834_6188(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F841_6246_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F841_6246(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_6368_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F894_6368(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_6368_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F895_6368(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_6368_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F896_6368(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F897_6368_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F897_6368(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_6368_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F898_6368(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1196, 0x00).id, 1196, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F899_6368_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F899_6368(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F900_6368_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F900_6368(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F901_6368_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F901_6368(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F902_6368_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F902_6368(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F903_6368_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F903_6368(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F904_6368_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F904_6368(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1052_7872_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1052_7872(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1053_7894_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1053_7894(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1057_8043_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1057_8043(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1058_8066_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1058_8066(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1110_8724_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1110_8724(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1111_8724_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1111_8724(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1112_8724_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1112_8724(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1113_8724_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1113_8724(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1114_8724_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1114_8724(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1196, 0x00).id, 1196, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1115_8724_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1115_8724(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1116_8724_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1116_8724(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1117_8724_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1117_8724(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1118_8724_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1118_8724(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1119_8724_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1119_8724(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1120_8724_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1120_8724(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1314_13086_5231_27 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1314_13086(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R5232[519])();
void R5232_init () {
	R5232[0] = (char *(*)()) F796_6033;
	R5232[1] = (char *(*)()) F797_6033;
	R5232[2] = (char *(*)()) F798_6033;
	R5232[3] = (char *(*)()) F799_6033;
	R5232[4] = (char *(*)()) F800_6033;
	R5232[5] = (char *(*)()) F801_6033;
	R5232[6] = (char *(*)()) F802_6033;
	R5232[7] = (char *(*)()) F803_6033;
	{long i; for (i = 8; i < 10; i++) R5232[i] = (char *(*)()) F796_6033;}
	R5232[10] = (char *(*)()) F800_6033;
	R5232[11] = (char *(*)()) F799_6033;
	R5232[12] = (char *(*)()) F801_6033;
	R5232[13] = (char *(*)()) F803_6033;
	R5232[26] = (char *(*)()) F822_6146;
	R5232[27] = (char *(*)()) F823_6193;
	R5232[28] = (char *(*)()) F824_6193;
	R5232[29] = (char *(*)()) F825_6193;
	R5232[30] = (char *(*)()) F826_6193;
	R5232[31] = (char *(*)()) F827_6193;
	R5232[32] = (char *(*)()) F828_6193;
	R5232[33] = (char *(*)()) F829_6193;
	R5232[34] = (char *(*)()) F830_6193;
	R5232[35] = (char *(*)()) F831_6193;
	R5232[36] = (char *(*)()) F832_6193;
	R5232[37] = (char *(*)()) F833_6193;
	R5232[38] = (char *(*)()) F834_6193;
	R5232[92] = (char *(*)()) F840_6249;
	R5232[93] = (char *(*)()) F841_6249;
	R5232[94] = (char *(*)()) F840_6249;
	R5232[95] = (char *(*)()) F841_6249;
	{long i; for (i = 96; i < 98; i++) R5232[i] = (char *(*)()) F840_6249;}
	R5232[98] = (char *(*)()) F841_6249;
	R5232[99] = (char *(*)()) F842_6249;
	R5232[100] = (char *(*)()) F843_6249;
	R5232[101] = (char *(*)()) F844_6249;
	R5232[102] = (char *(*)()) F845_6249;
	R5232[103] = (char *(*)()) F846_6249;
	R5232[104] = (char *(*)()) F847_6249;
	R5232[105] = (char *(*)()) F848_6249;
	R5232[106] = (char *(*)()) F849_6249;
	R5232[107] = (char *(*)()) F850_6249;
	R5232[108] = (char *(*)()) F851_6249;
	{long i; for (i = 109; i < 111; i++) R5232[i] = (char *(*)()) F840_6249;}
	R5232[111] = (char *(*)()) F841_6249;
	{long i; for (i = 112; i < 114; i++) R5232[i] = (char *(*)()) F840_6249;}
	R5232[184] = (char *(*)()) F840_6249;
	R5232[201] = (char *(*)()) F997_7359;
	{long i; for (i = 256; i < 259; i++) R5232[i] = (char *(*)()) F1051_7839;}
	{long i; for (i = 261; i < 263; i++) R5232[i] = (char *(*)()) F1056_8007;}
	R5232[313] = (char *(*)()) F1109_8732;
	R5232[314] = (char *(*)()) F1110_8732;
	R5232[315] = (char *(*)()) F1111_8732;
	R5232[316] = (char *(*)()) F1112_8732;
	R5232[317] = (char *(*)()) F1113_8732;
	R5232[318] = (char *(*)()) F1114_8732;
	R5232[319] = (char *(*)()) F1115_8732;
	R5232[320] = (char *(*)()) F1116_8732;
	R5232[321] = (char *(*)()) F1117_8732;
	R5232[322] = (char *(*)()) F1118_8732;
	R5232[323] = (char *(*)()) F1119_8732;
	R5232[324] = (char *(*)()) F1120_8732;
	R5232[518] = (char *(*)()) F1051_7839;
}

EIF_TYPE_INDEX *Y5232_gen_type [532];
EIF_TYPE_INDEX Y5232 [532];
void Y5232_init (void)
{
	egc_routines_types [5232] = Y5232;
	egc_routines_gen_types [5232] = Y5232_gen_type;
	egc_routines_offset [5232] = 783;
	{long i; for (i = 0; i < 126; i++) Y5232[i] = 1187;};
	Y5232[196] = 1187;
	Y5232[213] = 1187;
	{long i; for (i = 267; i < 275; i++) Y5232[i] = 1187;};
	{long i; for (i = 325; i < 337; i++) Y5232[i] = 1187;};
	{long i; for (i = 530; i < 532; i++) Y5232[i] = 1187;};
}

char *(*R5233[519])();
void R5233_init () {
	R5233[0] = (char *(*)()) F796_6034;
	R5233[1] = (char *(*)()) F797_6034;
	R5233[2] = (char *(*)()) F798_6034;
	R5233[3] = (char *(*)()) F799_6034;
	R5233[4] = (char *(*)()) F800_6034;
	R5233[5] = (char *(*)()) F801_6034;
	R5233[6] = (char *(*)()) F802_6034;
	R5233[7] = (char *(*)()) F803_6034;
	{long i; for (i = 8; i < 10; i++) R5233[i] = (char *(*)()) F796_6034;}
	R5233[10] = (char *(*)()) F800_6034;
	R5233[11] = (char *(*)()) F799_6034;
	R5233[12] = (char *(*)()) F801_6034;
	R5233[13] = (char *(*)()) F803_6034;
	R5233[26] = (char *(*)()) F822_6148;
	R5233[27] = (char *(*)()) F823_6194;
	R5233[28] = (char *(*)()) F824_6194;
	R5233[29] = (char *(*)()) F825_6194;
	R5233[30] = (char *(*)()) F826_6194;
	R5233[31] = (char *(*)()) F827_6194;
	R5233[32] = (char *(*)()) F828_6194;
	R5233[33] = (char *(*)()) F829_6194;
	R5233[34] = (char *(*)()) F830_6194;
	R5233[35] = (char *(*)()) F831_6194;
	R5233[36] = (char *(*)()) F832_6194;
	R5233[37] = (char *(*)()) F833_6194;
	R5233[38] = (char *(*)()) F834_6194;
	R5233[92] = (char *(*)()) F888_6301;
	R5233[93] = (char *(*)()) F889_6301;
	R5233[94] = (char *(*)()) F888_6301;
	R5233[95] = (char *(*)()) F889_6301;
	R5233[96] = (char *(*)()) F888_6301;
	R5233[97] = (char *(*)()) F893_6383;
	R5233[98] = (char *(*)()) F894_6383;
	R5233[99] = (char *(*)()) F895_6383;
	R5233[100] = (char *(*)()) F896_6383;
	R5233[101] = (char *(*)()) F897_6383;
	R5233[102] = (char *(*)()) F898_6383;
	R5233[103] = (char *(*)()) F899_6383;
	R5233[104] = (char *(*)()) F900_6383;
	R5233[105] = (char *(*)()) F901_6383;
	R5233[106] = (char *(*)()) F902_6383;
	R5233[107] = (char *(*)()) F903_6383;
	R5233[108] = (char *(*)()) F904_6383;
	{long i; for (i = 109; i < 111; i++) R5233[i] = (char *(*)()) F893_6383;}
	R5233[111] = (char *(*)()) F894_6383;
	{long i; for (i = 112; i < 114; i++) R5233[i] = (char *(*)()) F893_6383;}
	R5233[184] = (char *(*)()) F893_6383;
	R5233[201] = (char *(*)()) F997_7358;
	{long i; for (i = 256; i < 259; i++) R5233[i] = (char *(*)()) F1051_7837;}
	{long i; for (i = 261; i < 263; i++) R5233[i] = (char *(*)()) F1056_8005;}
	R5233[313] = (char *(*)()) F1109_8733;
	R5233[314] = (char *(*)()) F1110_8733;
	R5233[315] = (char *(*)()) F1111_8733;
	R5233[316] = (char *(*)()) F1112_8733;
	R5233[317] = (char *(*)()) F1113_8733;
	R5233[318] = (char *(*)()) F1114_8733;
	R5233[319] = (char *(*)()) F1115_8733;
	R5233[320] = (char *(*)()) F1116_8733;
	R5233[321] = (char *(*)()) F1117_8733;
	R5233[322] = (char *(*)()) F1118_8733;
	R5233[323] = (char *(*)()) F1119_8733;
	R5233[324] = (char *(*)()) F1120_8733;
	R5233[518] = (char *(*)()) F1314_13102;
}

char *(*R5235[519])();
void R5235_init () {
	R5235[0] = (char *(*)()) F796_6050;
	R5235[1] = (char *(*)()) F797_6050;
	R5235[2] = (char *(*)()) F798_6050;
	R5235[3] = (char *(*)()) F799_6050;
	R5235[4] = (char *(*)()) F800_6050;
	R5235[5] = (char *(*)()) F801_6050;
	R5235[6] = (char *(*)()) F802_6050;
	R5235[7] = (char *(*)()) F803_6050;
	{long i; for (i = 8; i < 10; i++) R5235[i] = (char *(*)()) F796_6050;}
	R5235[10] = (char *(*)()) F800_6050;
	R5235[11] = (char *(*)()) F799_6050;
	R5235[12] = (char *(*)()) F801_6050;
	R5235[13] = (char *(*)()) F803_6050;
	R5235[26] = (char *(*)()) F822_6152;
	R5235[27] = (char *(*)()) F823_6203;
	R5235[28] = (char *(*)()) F824_6203;
	R5235[29] = (char *(*)()) F825_6203;
	R5235[30] = (char *(*)()) F826_6203;
	R5235[31] = (char *(*)()) F827_6203;
	R5235[32] = (char *(*)()) F828_6203;
	R5235[33] = (char *(*)()) F829_6203;
	R5235[34] = (char *(*)()) F830_6203;
	R5235[35] = (char *(*)()) F831_6203;
	R5235[36] = (char *(*)()) F832_6203;
	R5235[37] = (char *(*)()) F833_6203;
	R5235[38] = (char *(*)()) F834_6203;
	R5235[92] = (char *(*)()) F840_6254;
	R5235[93] = (char *(*)()) F841_6254;
	R5235[94] = (char *(*)()) F840_6254;
	R5235[95] = (char *(*)()) F841_6254;
	R5235[96] = (char *(*)()) F840_6254;
	R5235[97] = (char *(*)()) F893_6389;
	R5235[98] = (char *(*)()) F894_6389;
	R5235[99] = (char *(*)()) F895_6389;
	R5235[100] = (char *(*)()) F896_6389;
	R5235[101] = (char *(*)()) F897_6389;
	R5235[102] = (char *(*)()) F898_6389;
	R5235[103] = (char *(*)()) F899_6389;
	R5235[104] = (char *(*)()) F900_6389;
	R5235[105] = (char *(*)()) F901_6389;
	R5235[106] = (char *(*)()) F902_6389;
	R5235[107] = (char *(*)()) F903_6389;
	R5235[108] = (char *(*)()) F904_6389;
	{long i; for (i = 109; i < 111; i++) R5235[i] = (char *(*)()) F893_6389;}
	R5235[111] = (char *(*)()) F894_6389;
	{long i; for (i = 112; i < 114; i++) R5235[i] = (char *(*)()) F893_6389;}
	R5235[184] = (char *(*)()) F893_6389;
	R5235[201] = (char *(*)()) F997_7356;
	{long i; for (i = 256; i < 259; i++) R5235[i] = (char *(*)()) F1048_7697;}
	{long i; for (i = 261; i < 263; i++) R5235[i] = (char *(*)()) F1048_7697;}
	R5235[313] = (char *(*)()) F1109_8738;
	R5235[314] = (char *(*)()) F1110_8738;
	R5235[315] = (char *(*)()) F1111_8738;
	R5235[316] = (char *(*)()) F1112_8738;
	R5235[317] = (char *(*)()) F1113_8738;
	R5235[318] = (char *(*)()) F1114_8738;
	R5235[319] = (char *(*)()) F1115_8738;
	R5235[320] = (char *(*)()) F1116_8738;
	R5235[321] = (char *(*)()) F1117_8738;
	R5235[322] = (char *(*)()) F1118_8738;
	R5235[323] = (char *(*)()) F1119_8738;
	R5235[324] = (char *(*)()) F1120_8738;
	R5235[518] = (char *(*)()) F1048_7697;
}

char *(*R5236[14])();
void R5236_init () {
	R5236[0] = (char *(*)()) F796_6012;
	R5236[1] = (char *(*)()) F797_6012;
	R5236[2] = (char *(*)()) F798_6012;
	R5236[3] = (char *(*)()) F799_6012;
	R5236[4] = (char *(*)()) F800_6012;
	R5236[5] = (char *(*)()) F801_6012;
	R5236[6] = (char *(*)()) F802_6012;
	R5236[7] = (char *(*)()) F803_6012;
	{long i; for (i = 8; i < 10; i++) R5236[i] = (char *(*)()) F796_6012;}
	R5236[10] = (char *(*)()) F800_6012;
	R5236[11] = (char *(*)()) F799_6012;
	R5236[12] = (char *(*)()) F801_6012;
	R5236[13] = (char *(*)()) F803_6012;
}

char *(*R5237[14])();
void R5237_init () {
	R5237[0] = (char *(*)()) F796_6013;
	R5237[1] = (char *(*)()) F797_6013;
	R5237[2] = (char *(*)()) F798_6013;
	R5237[3] = (char *(*)()) F799_6013;
	R5237[4] = (char *(*)()) F800_6013;
	R5237[5] = (char *(*)()) F801_6013;
	R5237[6] = (char *(*)()) F802_6013;
	R5237[7] = (char *(*)()) F803_6013;
	{long i; for (i = 8; i < 10; i++) R5237[i] = (char *(*)()) F796_6013;}
	R5237[10] = (char *(*)()) F800_6013;
	R5237[11] = (char *(*)()) F799_6013;
	R5237[12] = (char *(*)()) F801_6013;
	R5237[13] = (char *(*)()) F803_6013;
}

char *(*R5239[14])();
void R5239_init () {
	R5239[0] = (char *(*)()) F796_6015;
	R5239[1] = (char *(*)()) F797_6015;
	R5239[2] = (char *(*)()) F798_6015;
	R5239[3] = (char *(*)()) F799_6015;
	R5239[4] = (char *(*)()) F800_6015;
	R5239[5] = (char *(*)()) F801_6015;
	R5239[6] = (char *(*)()) F802_6015;
	R5239[7] = (char *(*)()) F803_6015;
	{long i; for (i = 8; i < 10; i++) R5239[i] = (char *(*)()) F796_6015;}
	R5239[10] = (char *(*)()) F800_6015;
	R5239[11] = (char *(*)()) F799_6015;
	R5239[12] = (char *(*)()) F801_6015;
	R5239[13] = (char *(*)()) F803_6015;
}

char *(*R5240[14])();
void R5240_init () {
	R5240[0] = (char *(*)()) F796_6016;
	R5240[1] = (char *(*)()) F797_6016;
	R5240[2] = (char *(*)()) F798_6016_5240_1;
	R5240[3] = (char *(*)()) F799_6016_5240_1;
	R5240[4] = (char *(*)()) F800_6016_5240_1;
	R5240[5] = (char *(*)()) F801_6016_5240_1;
	R5240[6] = (char *(*)()) F802_6016_5240_1;
	R5240[7] = (char *(*)()) F803_6016_5240_1;
	{long i; for (i = 8; i < 10; i++) R5240[i] = (char *(*)()) F796_6016;}
	R5240[10] = (char *(*)()) F800_6016_5240_1;
	R5240[11] = (char *(*)()) F799_6016_5240_1;
	R5240[12] = (char *(*)()) F801_6016_5240_1;
	R5240[13] = (char *(*)()) F803_6016_5240_1;
}
static EIF_REFERENCE F798_6016_5240_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F798_6016(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F799_6016_5240_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F799_6016(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_6016_5240_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F800_6016(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_6016_5240_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F801_6016(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_6016_5240_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F802_6016(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F803_6016_5240_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F803_6016(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y5241_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5241_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5241_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5241_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5241_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5241_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5241_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5241_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5241_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5241_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5241_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5241_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5241_pgtype12[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5241_gen_type [14];
EIF_TYPE_INDEX Y5241 [14];
void Y5241_init (void)
{
	egc_routines_types [5241] = Y5241;
	egc_routines_gen_types [5241] = Y5241_gen_type;
	egc_routines_offset [5241] = 795;
	Y5241_gen_type [0] = Y5241_pgtype0;
	Y5241_gen_type [1] = Y5241_pgtype1;
	Y5241_gen_type [2] = Y5241_pgtype2;
	Y5241_gen_type [3] = Y5241_pgtype3;
	Y5241_gen_type [4] = Y5241_pgtype4;
	Y5241_gen_type [5] = Y5241_pgtype5;
	Y5241_gen_type [6] = Y5241_pgtype6;
	Y5241_gen_type [7] = Y5241_pgtype7;
	Y5241_gen_type [9] = Y5241_pgtype8;
	Y5241_gen_type [10] = Y5241_pgtype9;
	Y5241_gen_type [11] = Y5241_pgtype10;
	Y5241_gen_type [12] = Y5241_pgtype11;
	Y5241_gen_type [13] = Y5241_pgtype12;
	Y5241[8] = 0;
}

char *(*R5245[14])();
void R5245_init () {
	R5245[0] = (char *(*)()) F796_6024;
	R5245[1] = (char *(*)()) F797_6024;
	R5245[2] = (char *(*)()) F798_6024_5245_1;
	R5245[3] = (char *(*)()) F799_6024_5245_1;
	R5245[4] = (char *(*)()) F800_6024_5245_1;
	R5245[5] = (char *(*)()) F801_6024_5245_1;
	R5245[6] = (char *(*)()) F802_6024_5245_1;
	R5245[7] = (char *(*)()) F803_6024_5245_1;
	{long i; for (i = 8; i < 10; i++) R5245[i] = (char *(*)()) F796_6024;}
	R5245[10] = (char *(*)()) F800_6024_5245_1;
	R5245[11] = (char *(*)()) F799_6024_5245_1;
	R5245[12] = (char *(*)()) F801_6024_5245_1;
	R5245[13] = (char *(*)()) F803_6024_5245_1;
}
static EIF_REFERENCE F798_6024_5245_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F798_6024(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F799_6024_5245_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F799_6024(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_6024_5245_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F800_6024(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_6024_5245_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F801_6024(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_6024_5245_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F802_6024(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F803_6024_5245_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F803_6024(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y5245_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5245_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5245_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5245_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5245_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5245_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5245_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5245_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5245_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5245_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5245_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5245_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5245_pgtype12[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5245_gen_type [14];
EIF_TYPE_INDEX Y5245 [14];
void Y5245_init (void)
{
	egc_routines_types [5245] = Y5245;
	egc_routines_gen_types [5245] = Y5245_gen_type;
	egc_routines_offset [5245] = 795;
	Y5245_gen_type [0] = Y5245_pgtype0;
	Y5245_gen_type [1] = Y5245_pgtype1;
	Y5245_gen_type [2] = Y5245_pgtype2;
	Y5245_gen_type [3] = Y5245_pgtype3;
	Y5245_gen_type [4] = Y5245_pgtype4;
	Y5245_gen_type [5] = Y5245_pgtype5;
	Y5245_gen_type [6] = Y5245_pgtype6;
	Y5245_gen_type [7] = Y5245_pgtype7;
	Y5245_gen_type [9] = Y5245_pgtype8;
	Y5245_gen_type [10] = Y5245_pgtype9;
	Y5245_gen_type [11] = Y5245_pgtype10;
	Y5245_gen_type [12] = Y5245_pgtype11;
	Y5245_gen_type [13] = Y5245_pgtype12;
	Y5245[8] = 0;
}

char *(*R5246[14])();
void R5246_init () {
	R5246[0] = (char *(*)()) F796_6025;
	R5246[1] = (char *(*)()) F797_6025_5246_1;
	R5246[2] = (char *(*)()) F798_6025;
	R5246[3] = (char *(*)()) F799_6025;
	R5246[4] = (char *(*)()) F800_6025;
	R5246[5] = (char *(*)()) F801_6025;
	R5246[6] = (char *(*)()) F802_6025_5246_1;
	R5246[7] = (char *(*)()) F803_6025;
	{long i; for (i = 8; i < 10; i++) R5246[i] = (char *(*)()) F796_6025;}
	R5246[10] = (char *(*)()) F800_6025;
	R5246[11] = (char *(*)()) F799_6025;
	R5246[12] = (char *(*)()) F801_6025;
	R5246[13] = (char *(*)()) F803_6025;
}
static EIF_REFERENCE F797_6025_5246_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F797_6025(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_6025_5246_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F802_6025(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5248[14])();
void R5248_init () {
	R5248[0] = (char *(*)()) F796_6029;
	R5248[1] = (char *(*)()) F797_6029_5248_31;
	R5248[2] = (char *(*)()) F798_6029;
	R5248[3] = (char *(*)()) F799_6029;
	R5248[4] = (char *(*)()) F800_6029;
	R5248[5] = (char *(*)()) F801_6029;
	R5248[6] = (char *(*)()) F802_6029_5248_31;
	R5248[7] = (char *(*)()) F803_6029;
	R5248[8] = (char *(*)()) F796_6029;
	R5248[9] = (char *(*)()) F805_6138;
	R5248[10] = (char *(*)()) F806_6138;
	R5248[11] = (char *(*)()) F807_6138;
	R5248[12] = (char *(*)()) F808_6138;
	R5248[13] = (char *(*)()) F809_6138;
}
static EIF_INTEGER_32 F797_6029_5248_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F797_6029(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F802_6029_5248_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F802_6029(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5250[14])();
void R5250_init () {
	R5250[0] = (char *(*)()) F796_6036;
	R5250[1] = (char *(*)()) F797_6036_5250_3;
	R5250[2] = (char *(*)()) F798_6036;
	R5250[3] = (char *(*)()) F799_6036;
	R5250[4] = (char *(*)()) F800_6036;
	R5250[5] = (char *(*)()) F801_6036;
	R5250[6] = (char *(*)()) F802_6036_5250_3;
	R5250[7] = (char *(*)()) F803_6036;
	R5250[8] = (char *(*)()) F796_6036;
	R5250[9] = (char *(*)()) F805_6140;
	R5250[10] = (char *(*)()) F806_6140;
	R5250[11] = (char *(*)()) F807_6140;
	R5250[12] = (char *(*)()) F808_6140;
	R5250[13] = (char *(*)()) F809_6140;
}
static EIF_BOOLEAN F797_6036_5250_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F797_6036(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F802_6036_5250_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F802_6036(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R5256[14])();
void R5256_init () {
	R5256[0] = (char *(*)()) F796_6044;
	R5256[1] = (char *(*)()) F797_6044;
	R5256[2] = (char *(*)()) F798_6044;
	R5256[3] = (char *(*)()) F799_6044;
	R5256[4] = (char *(*)()) F800_6044;
	R5256[5] = (char *(*)()) F801_6044;
	R5256[6] = (char *(*)()) F802_6044;
	R5256[7] = (char *(*)()) F803_6044;
	{long i; for (i = 8; i < 10; i++) R5256[i] = (char *(*)()) F796_6044;}
	R5256[10] = (char *(*)()) F800_6044;
	R5256[11] = (char *(*)()) F799_6044;
	R5256[12] = (char *(*)()) F801_6044;
	R5256[13] = (char *(*)()) F803_6044;
}

char *(*R5257[14])();
void R5257_init () {
	R5257[0] = (char *(*)()) F796_6045;
	R5257[1] = (char *(*)()) F797_6045;
	R5257[2] = (char *(*)()) F798_6045;
	R5257[3] = (char *(*)()) F799_6045;
	R5257[4] = (char *(*)()) F800_6045;
	R5257[5] = (char *(*)()) F801_6045;
	R5257[6] = (char *(*)()) F802_6045;
	R5257[7] = (char *(*)()) F803_6045;
	{long i; for (i = 8; i < 10; i++) R5257[i] = (char *(*)()) F796_6045;}
	R5257[10] = (char *(*)()) F800_6045;
	R5257[11] = (char *(*)()) F799_6045;
	R5257[12] = (char *(*)()) F801_6045;
	R5257[13] = (char *(*)()) F803_6045;
}

char *(*R5259[14])();
void R5259_init () {
	R5259[0] = (char *(*)()) F796_6047;
	R5259[1] = (char *(*)()) F797_6047;
	R5259[2] = (char *(*)()) F798_6047;
	R5259[3] = (char *(*)()) F799_6047;
	R5259[4] = (char *(*)()) F800_6047;
	R5259[5] = (char *(*)()) F801_6047;
	R5259[6] = (char *(*)()) F802_6047;
	R5259[7] = (char *(*)()) F803_6047;
	{long i; for (i = 8; i < 10; i++) R5259[i] = (char *(*)()) F796_6047;}
	R5259[10] = (char *(*)()) F800_6047;
	R5259[11] = (char *(*)()) F799_6047;
	R5259[12] = (char *(*)()) F801_6047;
	R5259[13] = (char *(*)()) F803_6047;
}

char *(*R5262[14])();
void R5262_init () {
	R5262[0] = (char *(*)()) F796_6051;
	R5262[1] = (char *(*)()) F797_6051;
	R5262[2] = (char *(*)()) F798_6051;
	R5262[3] = (char *(*)()) F799_6051;
	R5262[4] = (char *(*)()) F800_6051;
	R5262[5] = (char *(*)()) F801_6051;
	R5262[6] = (char *(*)()) F802_6051;
	R5262[7] = (char *(*)()) F803_6051;
	{long i; for (i = 8; i < 10; i++) R5262[i] = (char *(*)()) F796_6051;}
	R5262[10] = (char *(*)()) F800_6051;
	R5262[11] = (char *(*)()) F799_6051;
	R5262[12] = (char *(*)()) F801_6051;
	R5262[13] = (char *(*)()) F803_6051;
}

char *(*R5263[14])();
void R5263_init () {
	R5263[0] = (char *(*)()) F796_6052;
	R5263[1] = (char *(*)()) F797_6052;
	R5263[2] = (char *(*)()) F798_6052;
	R5263[3] = (char *(*)()) F799_6052;
	R5263[4] = (char *(*)()) F800_6052;
	R5263[5] = (char *(*)()) F801_6052;
	R5263[6] = (char *(*)()) F802_6052;
	R5263[7] = (char *(*)()) F803_6052;
	{long i; for (i = 8; i < 10; i++) R5263[i] = (char *(*)()) F796_6052;}
	R5263[10] = (char *(*)()) F800_6052;
	R5263[11] = (char *(*)()) F799_6052;
	R5263[12] = (char *(*)()) F801_6052;
	R5263[13] = (char *(*)()) F803_6052;
}

char *(*R5265[14])();
void R5265_init () {
	R5265[0] = (char *(*)()) F796_6054;
	R5265[1] = (char *(*)()) F797_6054_5265_4;
	R5265[2] = (char *(*)()) F798_6054;
	R5265[3] = (char *(*)()) F799_6054;
	R5265[4] = (char *(*)()) F800_6054;
	R5265[5] = (char *(*)()) F801_6054;
	R5265[6] = (char *(*)()) F802_6054_5265_4;
	R5265[7] = (char *(*)()) F803_6054;
	{long i; for (i = 8; i < 10; i++) R5265[i] = (char *(*)()) F796_6054;}
	R5265[10] = (char *(*)()) F800_6054;
	R5265[11] = (char *(*)()) F799_6054;
	R5265[12] = (char *(*)()) F801_6054;
	R5265[13] = (char *(*)()) F803_6054;
}
static void F797_6054_5265_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F797_6054(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F802_6054_5265_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F802_6054(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5267[14])();
void R5267_init () {
	R5267[0] = (char *(*)()) F796_6056;
	R5267[1] = (char *(*)()) F797_6056;
	R5267[2] = (char *(*)()) F798_6056;
	R5267[3] = (char *(*)()) F799_6056;
	R5267[4] = (char *(*)()) F800_6056;
	R5267[5] = (char *(*)()) F801_6056;
	R5267[6] = (char *(*)()) F802_6056;
	R5267[7] = (char *(*)()) F803_6056;
	{long i; for (i = 8; i < 10; i++) R5267[i] = (char *(*)()) F796_6056;}
	R5267[10] = (char *(*)()) F800_6056;
	R5267[11] = (char *(*)()) F799_6056;
	R5267[12] = (char *(*)()) F801_6056;
	R5267[13] = (char *(*)()) F803_6056;
}

char *(*R5268[14])();
void R5268_init () {
	R5268[0] = (char *(*)()) F796_6057;
	R5268[1] = (char *(*)()) F797_6057;
	R5268[2] = (char *(*)()) F798_6057;
	R5268[3] = (char *(*)()) F799_6057;
	R5268[4] = (char *(*)()) F800_6057;
	R5268[5] = (char *(*)()) F801_6057;
	R5268[6] = (char *(*)()) F802_6057;
	R5268[7] = (char *(*)()) F803_6057;
	{long i; for (i = 8; i < 10; i++) R5268[i] = (char *(*)()) F796_6057;}
	R5268[10] = (char *(*)()) F800_6057;
	R5268[11] = (char *(*)()) F799_6057;
	R5268[12] = (char *(*)()) F801_6057;
	R5268[13] = (char *(*)()) F803_6057;
}

char *(*R5274[14])();
void R5274_init () {
	R5274[0] = (char *(*)()) F796_6070;
	R5274[1] = (char *(*)()) F797_6070;
	R5274[2] = (char *(*)()) F798_6070;
	R5274[3] = (char *(*)()) F799_6070;
	R5274[4] = (char *(*)()) F800_6070;
	R5274[5] = (char *(*)()) F801_6070;
	R5274[6] = (char *(*)()) F802_6070;
	R5274[7] = (char *(*)()) F803_6070;
	R5274[8] = (char *(*)()) F796_6070;
	R5274[9] = (char *(*)()) F805_6142;
	R5274[10] = (char *(*)()) F806_6142;
	R5274[11] = (char *(*)()) F807_6142;
	R5274[12] = (char *(*)()) F808_6142;
	R5274[13] = (char *(*)()) F809_6142;
}

char *(*R5283[14])();
void R5283_init () {
	R5283[0] = (char *(*)()) F796_6080;
	R5283[1] = (char *(*)()) F797_6080;
	R5283[2] = (char *(*)()) F798_6080;
	R5283[3] = (char *(*)()) F799_6080;
	R5283[4] = (char *(*)()) F800_6080;
	R5283[5] = (char *(*)()) F801_6080;
	R5283[6] = (char *(*)()) F802_6080;
	R5283[7] = (char *(*)()) F803_6080;
	{long i; for (i = 8; i < 10; i++) R5283[i] = (char *(*)()) F796_6080;}
	R5283[10] = (char *(*)()) F800_6080;
	R5283[11] = (char *(*)()) F799_6080;
	R5283[12] = (char *(*)()) F801_6080;
	R5283[13] = (char *(*)()) F803_6080;
}

char *(*R5284[14])();
void R5284_init () {
	R5284[0] = (char *(*)()) F796_6081;
	R5284[1] = (char *(*)()) F797_6081;
	R5284[2] = (char *(*)()) F798_6081;
	R5284[3] = (char *(*)()) F799_6081;
	R5284[4] = (char *(*)()) F800_6081;
	R5284[5] = (char *(*)()) F801_6081;
	R5284[6] = (char *(*)()) F802_6081;
	R5284[7] = (char *(*)()) F803_6081;
	{long i; for (i = 8; i < 10; i++) R5284[i] = (char *(*)()) F796_6081;}
	R5284[10] = (char *(*)()) F800_6081;
	R5284[11] = (char *(*)()) F799_6081;
	R5284[12] = (char *(*)()) F801_6081;
	R5284[13] = (char *(*)()) F803_6081;
}

char *(*R5291[14])();
void R5291_init () {
	R5291[0] = (char *(*)()) F796_6088;
	R5291[1] = (char *(*)()) F797_6088;
	R5291[2] = (char *(*)()) F798_6088_5291_1;
	R5291[3] = (char *(*)()) F799_6088_5291_1;
	R5291[4] = (char *(*)()) F800_6088_5291_1;
	R5291[5] = (char *(*)()) F801_6088_5291_1;
	R5291[6] = (char *(*)()) F802_6088_5291_1;
	R5291[7] = (char *(*)()) F803_6088_5291_1;
	{long i; for (i = 8; i < 10; i++) R5291[i] = (char *(*)()) F796_6088;}
	R5291[10] = (char *(*)()) F800_6088_5291_1;
	R5291[11] = (char *(*)()) F799_6088_5291_1;
	R5291[12] = (char *(*)()) F801_6088_5291_1;
	R5291[13] = (char *(*)()) F803_6088_5291_1;
}
static EIF_REFERENCE F798_6088_5291_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F798_6088(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F799_6088_5291_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F799_6088(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_6088_5291_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F800_6088(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_6088_5291_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F801_6088(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_6088_5291_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F802_6088(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F803_6088_5291_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F803_6088(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}

char *(*R5292[14])();
void R5292_init () {
	R5292[0] = (char *(*)()) F796_6089;
	R5292[1] = (char *(*)()) F797_6089_5292_1;
	R5292[2] = (char *(*)()) F798_6089;
	R5292[3] = (char *(*)()) F799_6089;
	R5292[4] = (char *(*)()) F800_6089;
	R5292[5] = (char *(*)()) F801_6089;
	R5292[6] = (char *(*)()) F802_6089_5292_1;
	R5292[7] = (char *(*)()) F803_6089;
	{long i; for (i = 8; i < 10; i++) R5292[i] = (char *(*)()) F796_6089;}
	R5292[10] = (char *(*)()) F800_6089;
	R5292[11] = (char *(*)()) F799_6089;
	R5292[12] = (char *(*)()) F801_6089;
	R5292[13] = (char *(*)()) F803_6089;
}
static EIF_REFERENCE F797_6089_5292_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F797_6089(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_6089_5292_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F802_6089(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5293[14])();
void R5293_init () {
	R5293[0] = (char *(*)()) F796_6090;
	R5293[1] = (char *(*)()) F797_6090;
	R5293[2] = (char *(*)()) F798_6090;
	R5293[3] = (char *(*)()) F799_6090;
	R5293[4] = (char *(*)()) F800_6090;
	R5293[5] = (char *(*)()) F801_6090;
	R5293[6] = (char *(*)()) F802_6090;
	R5293[7] = (char *(*)()) F803_6090;
	{long i; for (i = 8; i < 10; i++) R5293[i] = (char *(*)()) F796_6090;}
	R5293[10] = (char *(*)()) F800_6090;
	R5293[11] = (char *(*)()) F799_6090;
	R5293[12] = (char *(*)()) F801_6090;
	R5293[13] = (char *(*)()) F803_6090;
}

char *(*R5294[14])();
void R5294_init () {
	R5294[0] = (char *(*)()) F796_6091;
	R5294[1] = (char *(*)()) F797_6091;
	R5294[2] = (char *(*)()) F798_6091;
	R5294[3] = (char *(*)()) F799_6091;
	R5294[4] = (char *(*)()) F800_6091;
	R5294[5] = (char *(*)()) F801_6091;
	R5294[6] = (char *(*)()) F802_6091;
	R5294[7] = (char *(*)()) F803_6091;
	{long i; for (i = 8; i < 10; i++) R5294[i] = (char *(*)()) F796_6091;}
	R5294[10] = (char *(*)()) F800_6091;
	R5294[11] = (char *(*)()) F799_6091;
	R5294[12] = (char *(*)()) F801_6091;
	R5294[13] = (char *(*)()) F803_6091;
}

char *(*R5295[14])();
void R5295_init () {
	R5295[0] = (char *(*)()) F796_6092;
	R5295[1] = (char *(*)()) F797_6092;
	R5295[2] = (char *(*)()) F798_6092;
	R5295[3] = (char *(*)()) F799_6092;
	R5295[4] = (char *(*)()) F800_6092;
	R5295[5] = (char *(*)()) F801_6092;
	R5295[6] = (char *(*)()) F802_6092;
	R5295[7] = (char *(*)()) F803_6092;
	{long i; for (i = 8; i < 10; i++) R5295[i] = (char *(*)()) F796_6092;}
	R5295[10] = (char *(*)()) F800_6092;
	R5295[11] = (char *(*)()) F799_6092;
	R5295[12] = (char *(*)()) F801_6092;
	R5295[13] = (char *(*)()) F803_6092;
}

char *(*R5296[14])();
void R5296_init () {
	R5296[0] = (char *(*)()) F796_6093;
	R5296[1] = (char *(*)()) F797_6093;
	R5296[2] = (char *(*)()) F798_6093;
	R5296[3] = (char *(*)()) F799_6093;
	R5296[4] = (char *(*)()) F800_6093;
	R5296[5] = (char *(*)()) F801_6093;
	R5296[6] = (char *(*)()) F802_6093;
	R5296[7] = (char *(*)()) F803_6093;
	{long i; for (i = 8; i < 10; i++) R5296[i] = (char *(*)()) F796_6093;}
	R5296[10] = (char *(*)()) F800_6093;
	R5296[11] = (char *(*)()) F799_6093;
	R5296[12] = (char *(*)()) F801_6093;
	R5296[13] = (char *(*)()) F803_6093;
}

char *(*R5297[14])();
void R5297_init () {
	R5297[0] = (char *(*)()) F796_6094;
	R5297[1] = (char *(*)()) F797_6094;
	R5297[2] = (char *(*)()) F798_6094;
	R5297[3] = (char *(*)()) F799_6094;
	R5297[4] = (char *(*)()) F800_6094;
	R5297[5] = (char *(*)()) F801_6094;
	R5297[6] = (char *(*)()) F802_6094;
	R5297[7] = (char *(*)()) F803_6094;
	{long i; for (i = 8; i < 10; i++) R5297[i] = (char *(*)()) F796_6094;}
	R5297[10] = (char *(*)()) F800_6094;
	R5297[11] = (char *(*)()) F799_6094;
	R5297[12] = (char *(*)()) F801_6094;
	R5297[13] = (char *(*)()) F803_6094;
}

char *(*R5299[14])();
void R5299_init () {
	R5299[0] = (char *(*)()) F796_6096;
	R5299[1] = (char *(*)()) F797_6096;
	R5299[2] = (char *(*)()) F798_6096;
	R5299[3] = (char *(*)()) F799_6096;
	R5299[4] = (char *(*)()) F800_6096;
	R5299[5] = (char *(*)()) F801_6096;
	R5299[6] = (char *(*)()) F802_6096;
	R5299[7] = (char *(*)()) F803_6096;
	{long i; for (i = 8; i < 10; i++) R5299[i] = (char *(*)()) F796_6096;}
	R5299[10] = (char *(*)()) F800_6096;
	R5299[11] = (char *(*)()) F799_6096;
	R5299[12] = (char *(*)()) F801_6096;
	R5299[13] = (char *(*)()) F803_6096;
}

char *(*R5300[14])();
void R5300_init () {
	R5300[0] = (char *(*)()) F796_6097;
	R5300[1] = (char *(*)()) F797_6097;
	R5300[2] = (char *(*)()) F798_6097;
	R5300[3] = (char *(*)()) F799_6097;
	R5300[4] = (char *(*)()) F800_6097;
	R5300[5] = (char *(*)()) F801_6097;
	R5300[6] = (char *(*)()) F802_6097;
	R5300[7] = (char *(*)()) F803_6097;
	{long i; for (i = 8; i < 10; i++) R5300[i] = (char *(*)()) F796_6097;}
	R5300[10] = (char *(*)()) F800_6097;
	R5300[11] = (char *(*)()) F799_6097;
	R5300[12] = (char *(*)()) F801_6097;
	R5300[13] = (char *(*)()) F803_6097;
}

char *(*R5301[14])();
void R5301_init () {
	R5301[0] = (char *(*)()) F796_6098;
	R5301[1] = (char *(*)()) F797_6098;
	R5301[2] = (char *(*)()) F798_6098;
	R5301[3] = (char *(*)()) F799_6098;
	R5301[4] = (char *(*)()) F800_6098;
	R5301[5] = (char *(*)()) F801_6098;
	R5301[6] = (char *(*)()) F802_6098;
	R5301[7] = (char *(*)()) F803_6098;
	{long i; for (i = 8; i < 10; i++) R5301[i] = (char *(*)()) F796_6098;}
	R5301[10] = (char *(*)()) F800_6098;
	R5301[11] = (char *(*)()) F799_6098;
	R5301[12] = (char *(*)()) F801_6098;
	R5301[13] = (char *(*)()) F803_6098;
}

char *(*R5305[14])();
void R5305_init () {
	R5305[0] = (char *(*)()) F796_6102;
	R5305[1] = (char *(*)()) F797_6102_5305_4;
	R5305[2] = (char *(*)()) F798_6102;
	R5305[3] = (char *(*)()) F799_6102;
	R5305[4] = (char *(*)()) F800_6102;
	R5305[5] = (char *(*)()) F801_6102;
	R5305[6] = (char *(*)()) F802_6102_5305_4;
	R5305[7] = (char *(*)()) F803_6102;
	{long i; for (i = 8; i < 10; i++) R5305[i] = (char *(*)()) F796_6102;}
	R5305[10] = (char *(*)()) F800_6102;
	R5305[11] = (char *(*)()) F799_6102;
	R5305[12] = (char *(*)()) F801_6102;
	R5305[13] = (char *(*)()) F803_6102;
}
static void F797_6102_5305_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F797_6102(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F802_6102_5305_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F802_6102(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5306[14])();
void R5306_init () {
	R5306[0] = (char *(*)()) F796_6103;
	R5306[1] = (char *(*)()) F797_6103_5306_4;
	R5306[2] = (char *(*)()) F798_6103;
	R5306[3] = (char *(*)()) F799_6103;
	R5306[4] = (char *(*)()) F800_6103;
	R5306[5] = (char *(*)()) F801_6103;
	R5306[6] = (char *(*)()) F802_6103_5306_4;
	R5306[7] = (char *(*)()) F803_6103;
	{long i; for (i = 8; i < 10; i++) R5306[i] = (char *(*)()) F796_6103;}
	R5306[10] = (char *(*)()) F800_6103;
	R5306[11] = (char *(*)()) F799_6103;
	R5306[12] = (char *(*)()) F801_6103;
	R5306[13] = (char *(*)()) F803_6103;
}
static void F797_6103_5306_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F797_6103(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F802_6103_5306_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F802_6103(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5311[14])();
void R5311_init () {
	R5311[0] = (char *(*)()) F796_6108;
	R5311[1] = (char *(*)()) F797_6108;
	R5311[2] = (char *(*)()) F798_6108;
	R5311[3] = (char *(*)()) F799_6108;
	R5311[4] = (char *(*)()) F800_6108;
	R5311[5] = (char *(*)()) F801_6108;
	R5311[6] = (char *(*)()) F802_6108;
	R5311[7] = (char *(*)()) F803_6108;
	{long i; for (i = 8; i < 10; i++) R5311[i] = (char *(*)()) F796_6108;}
	R5311[10] = (char *(*)()) F800_6108;
	R5311[11] = (char *(*)()) F799_6108;
	R5311[12] = (char *(*)()) F801_6108;
	R5311[13] = (char *(*)()) F803_6108;
}

char *(*R5324[14])();
void R5324_init () {
	R5324[0] = (char *(*)()) F796_6121;
	R5324[1] = (char *(*)()) F797_6121;
	R5324[2] = (char *(*)()) F798_6121;
	R5324[3] = (char *(*)()) F799_6121;
	R5324[4] = (char *(*)()) F800_6121;
	R5324[5] = (char *(*)()) F801_6121;
	R5324[6] = (char *(*)()) F802_6121;
	R5324[7] = (char *(*)()) F803_6121;
	{long i; for (i = 8; i < 10; i++) R5324[i] = (char *(*)()) F796_6121;}
	R5324[10] = (char *(*)()) F800_6121;
	R5324[11] = (char *(*)()) F799_6121;
	R5324[12] = (char *(*)()) F801_6121;
	R5324[13] = (char *(*)()) F803_6121;
}

char *(*R5337[5])();
void R5337_init () {
	R5337[0] = (char *(*)()) F805_6136;
	R5337[1] = (char *(*)()) F806_6136;
	R5337[2] = (char *(*)()) F807_6136;
	R5337[3] = (char *(*)()) F808_6136;
	R5337[4] = (char *(*)()) F809_6136;
}

char *(*R5359[12])();
void R5359_init () {
	R5359[0] = (char *(*)()) F823_6182;
	R5359[1] = (char *(*)()) F824_6182;
	R5359[2] = (char *(*)()) F825_6182;
	R5359[3] = (char *(*)()) F826_6182;
	R5359[4] = (char *(*)()) F827_6182;
	R5359[5] = (char *(*)()) F828_6182;
	R5359[6] = (char *(*)()) F829_6182;
	R5359[7] = (char *(*)()) F830_6182;
	R5359[8] = (char *(*)()) F831_6182;
	R5359[9] = (char *(*)()) F832_6182;
	R5359[10] = (char *(*)()) F833_6182;
	R5359[11] = (char *(*)()) F834_6182;
}

char *(*R5360[12])();
void R5360_init () {
	R5360[0] = (char *(*)()) F823_6183;
	R5360[1] = (char *(*)()) F824_6183_5360_56;
	R5360[2] = (char *(*)()) F825_6183_5360_56;
	R5360[3] = (char *(*)()) F826_6183_5360_56;
	R5360[4] = (char *(*)()) F827_6183_5360_56;
	R5360[5] = (char *(*)()) F828_6183_5360_56;
	R5360[6] = (char *(*)()) F829_6183_5360_56;
	R5360[7] = (char *(*)()) F830_6183_5360_56;
	R5360[8] = (char *(*)()) F831_6183_5360_56;
	R5360[9] = (char *(*)()) F832_6183_5360_56;
	R5360[10] = (char *(*)()) F833_6183_5360_56;
	R5360[11] = (char *(*)()) F834_6183_5360_56;
}
static void F824_6183_5360_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F824_6183(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F825_6183_5360_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F825_6183(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F826_6183_5360_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F826_6183(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F827_6183_5360_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F827_6183(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F828_6183_5360_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F828_6183(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F829_6183_5360_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F829_6183(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F830_6183_5360_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F830_6183(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F831_6183_5360_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F831_6183(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F832_6183_5360_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F832_6183(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F833_6183_5360_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F833_6183(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F834_6183_5360_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F834_6183(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R5363[12])();
void R5363_init () {
	R5363[0] = (char *(*)()) F823_6186;
	R5363[1] = (char *(*)()) F824_6186;
	R5363[2] = (char *(*)()) F825_6186;
	R5363[3] = (char *(*)()) F826_6186;
	R5363[4] = (char *(*)()) F827_6186;
	R5363[5] = (char *(*)()) F828_6186;
	R5363[6] = (char *(*)()) F829_6186;
	R5363[7] = (char *(*)()) F830_6186;
	R5363[8] = (char *(*)()) F831_6186;
	R5363[9] = (char *(*)()) F832_6186;
	R5363[10] = (char *(*)()) F833_6186;
	R5363[11] = (char *(*)()) F834_6186;
}

char *(*R5373[12])();
void R5373_init () {
	R5373[0] = (char *(*)()) F823_6212;
	R5373[1] = (char *(*)()) F824_6212;
	R5373[2] = (char *(*)()) F825_6212;
	R5373[3] = (char *(*)()) F826_6212;
	R5373[4] = (char *(*)()) F827_6212;
	R5373[5] = (char *(*)()) F828_6212;
	R5373[6] = (char *(*)()) F829_6212;
	R5373[7] = (char *(*)()) F830_6212;
	R5373[8] = (char *(*)()) F831_6212;
	R5373[9] = (char *(*)()) F832_6212;
	R5373[10] = (char *(*)()) F833_6212;
	R5373[11] = (char *(*)()) F834_6212;
}

char *(*R5387[12])();
void R5387_init () {
	R5387[0] = (char *(*)()) F823_6228;
	R5387[1] = (char *(*)()) F824_6228_5387_56;
	R5387[2] = (char *(*)()) F825_6228_5387_56;
	R5387[3] = (char *(*)()) F826_6228_5387_56;
	R5387[4] = (char *(*)()) F827_6228_5387_56;
	R5387[5] = (char *(*)()) F828_6228_5387_56;
	R5387[6] = (char *(*)()) F829_6228_5387_56;
	R5387[7] = (char *(*)()) F830_6228_5387_56;
	R5387[8] = (char *(*)()) F831_6228_5387_56;
	R5387[9] = (char *(*)()) F832_6228_5387_56;
	R5387[10] = (char *(*)()) F833_6228_5387_56;
	R5387[11] = (char *(*)()) F834_6228_5387_56;
}
static void F824_6228_5387_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F824_6228(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F825_6228_5387_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F825_6228(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F826_6228_5387_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F826_6228(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F827_6228_5387_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F827_6228(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F828_6228_5387_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F828_6228(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F829_6228_5387_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F829_6228(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F830_6228_5387_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F830_6228(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F831_6228_5387_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F831_6228(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F832_6228_5387_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F832_6228(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F833_6228_5387_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F833_6228(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F834_6228_5387_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F834_6228(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R5394[12])();
void R5394_init () {
	R5394[0] = (char *(*)()) F823_6240;
	R5394[1] = (char *(*)()) F824_6240;
	R5394[2] = (char *(*)()) F825_6240;
	R5394[3] = (char *(*)()) F826_6240;
	R5394[4] = (char *(*)()) F827_6240;
	R5394[5] = (char *(*)()) F828_6240;
	R5394[6] = (char *(*)()) F829_6240;
	R5394[7] = (char *(*)()) F830_6240;
	R5394[8] = (char *(*)()) F831_6240;
	R5394[9] = (char *(*)()) F832_6240;
	R5394[10] = (char *(*)()) F833_6240;
	R5394[11] = (char *(*)()) F834_6240;
}

char *(*R5399[93])();
void R5399_init () {
	R5399[0] = (char *(*)()) F888_6296;
	R5399[1] = (char *(*)()) F889_6296_5399_1;
	R5399[2] = (char *(*)()) F888_6296;
	R5399[3] = (char *(*)()) F889_6296_5399_1;
	R5399[4] = (char *(*)()) F888_6296;
	R5399[5] = (char *(*)()) F893_6371;
	R5399[6] = (char *(*)()) F894_6371_5399_1;
	R5399[7] = (char *(*)()) F895_6371_5399_1;
	R5399[8] = (char *(*)()) F896_6371_5399_1;
	R5399[9] = (char *(*)()) F897_6371_5399_1;
	R5399[10] = (char *(*)()) F898_6371_5399_1;
	R5399[11] = (char *(*)()) F899_6371_5399_1;
	R5399[12] = (char *(*)()) F900_6371_5399_1;
	R5399[13] = (char *(*)()) F901_6371_5399_1;
	R5399[14] = (char *(*)()) F902_6371_5399_1;
	R5399[15] = (char *(*)()) F903_6371_5399_1;
	R5399[16] = (char *(*)()) F904_6371_5399_1;
	{long i; for (i = 17; i < 19; i++) R5399[i] = (char *(*)()) F893_6371;}
	R5399[19] = (char *(*)()) F894_6371_5399_1;
	{long i; for (i = 20; i < 22; i++) R5399[i] = (char *(*)()) F893_6371;}
	R5399[92] = (char *(*)()) F893_6371;
}
static EIF_REFERENCE F889_6296_5399_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F889_6296(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_6371_5399_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F894_6371(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_6371_5399_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F895_6371(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_6371_5399_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F896_6371(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F897_6371_5399_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F897_6371(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_6371_5399_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F898_6371(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1196, 0x00).id, 1196, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F899_6371_5399_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F899_6371(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F900_6371_5399_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F900_6371(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F901_6371_5399_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F901_6371(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F902_6371_5399_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F902_6371(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F903_6371_5399_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F903_6371(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F904_6371_5399_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F904_6371(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5400[5])();
void R5400_init () {
	R5400[0] = (char *(*)()) F888_6315;
	R5400[1] = (char *(*)()) F889_6315;
	R5400[2] = (char *(*)()) F888_6315;
	R5400[3] = (char *(*)()) F889_6315;
	R5400[4] = (char *(*)()) F888_6315;
}

char *(*R5401[93])();
void R5401_init () {
	R5401[0] = (char *(*)()) F888_6316;
	R5401[1] = (char *(*)()) F889_6316;
	R5401[2] = (char *(*)()) F888_6316;
	R5401[3] = (char *(*)()) F889_6316;
	R5401[4] = (char *(*)()) F888_6316;
	R5401[5] = (char *(*)()) F893_6397;
	R5401[6] = (char *(*)()) F894_6397;
	R5401[7] = (char *(*)()) F895_6397;
	R5401[8] = (char *(*)()) F896_6397;
	R5401[9] = (char *(*)()) F897_6397;
	R5401[10] = (char *(*)()) F898_6397;
	R5401[11] = (char *(*)()) F899_6397;
	R5401[12] = (char *(*)()) F900_6397;
	R5401[13] = (char *(*)()) F901_6397;
	R5401[14] = (char *(*)()) F902_6397;
	R5401[15] = (char *(*)()) F903_6397;
	R5401[16] = (char *(*)()) F904_6397;
	{long i; for (i = 17; i < 19; i++) R5401[i] = (char *(*)()) F893_6397;}
	R5401[19] = (char *(*)()) F894_6397;
	{long i; for (i = 20; i < 22; i++) R5401[i] = (char *(*)()) F893_6397;}
	R5401[92] = (char *(*)()) F893_6397;
}

char *(*R5402[93])();
void R5402_init () {
	R5402[0] = (char *(*)()) F888_6306;
	R5402[1] = (char *(*)()) F889_6306;
	R5402[2] = (char *(*)()) F888_6306;
	R5402[3] = (char *(*)()) F889_6306;
	R5402[4] = (char *(*)()) F888_6306;
	R5402[5] = (char *(*)()) F840_6255;
	R5402[6] = (char *(*)()) F841_6255;
	R5402[7] = (char *(*)()) F842_6255;
	R5402[8] = (char *(*)()) F843_6255;
	R5402[9] = (char *(*)()) F844_6255;
	R5402[10] = (char *(*)()) F845_6255;
	R5402[11] = (char *(*)()) F846_6255;
	R5402[12] = (char *(*)()) F847_6255;
	R5402[13] = (char *(*)()) F848_6255;
	R5402[14] = (char *(*)()) F849_6255;
	R5402[15] = (char *(*)()) F850_6255;
	R5402[16] = (char *(*)()) F851_6255;
	{long i; for (i = 17; i < 19; i++) R5402[i] = (char *(*)()) F840_6255;}
	R5402[19] = (char *(*)()) F841_6255;
	{long i; for (i = 20; i < 22; i++) R5402[i] = (char *(*)()) F840_6255;}
	R5402[92] = (char *(*)()) F840_6255;
}

char *(*R5403[93])();
void R5403_init () {
	R5403[0] = (char *(*)()) F888_6307;
	R5403[1] = (char *(*)()) F889_6307;
	R5403[2] = (char *(*)()) F888_6307;
	R5403[3] = (char *(*)()) F889_6307;
	R5403[4] = (char *(*)()) F888_6307;
	R5403[5] = (char *(*)()) F840_6256;
	R5403[6] = (char *(*)()) F841_6256;
	R5403[7] = (char *(*)()) F842_6256;
	R5403[8] = (char *(*)()) F843_6256;
	R5403[9] = (char *(*)()) F844_6256;
	R5403[10] = (char *(*)()) F845_6256;
	R5403[11] = (char *(*)()) F846_6256;
	R5403[12] = (char *(*)()) F847_6256;
	R5403[13] = (char *(*)()) F848_6256;
	R5403[14] = (char *(*)()) F849_6256;
	R5403[15] = (char *(*)()) F850_6256;
	R5403[16] = (char *(*)()) F851_6256;
	{long i; for (i = 17; i < 19; i++) R5403[i] = (char *(*)()) F840_6256;}
	R5403[19] = (char *(*)()) F841_6256;
	{long i; for (i = 20; i < 22; i++) R5403[i] = (char *(*)()) F840_6256;}
	R5403[92] = (char *(*)()) F840_6256;
}

char *(*R5408[5])();
void R5408_init () {
	R5408[0] = (char *(*)()) F888_6318;
	R5408[1] = (char *(*)()) F889_6318_5408_4;
	R5408[2] = (char *(*)()) F888_6318;
	R5408[3] = (char *(*)()) F889_6318_5408_4;
	R5408[4] = (char *(*)()) F888_6318;
}
static void F889_6318_5408_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F889_6318(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5419[5])();
void R5419_init () {
	R5419[0] = (char *(*)()) F888_6331;
	R5419[1] = (char *(*)()) F889_6331_5419_5;
	R5419[2] = (char *(*)()) F888_6331;
	R5419[3] = (char *(*)()) F889_6331_5419_5;
	R5419[4] = (char *(*)()) F888_6331;
}
static EIF_REFERENCE F889_6331_5419_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F889_6331(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5420[5])();
void R5420_init () {
	R5420[0] = (char *(*)()) F888_6332;
	R5420[1] = (char *(*)()) F889_6332;
	R5420[2] = (char *(*)()) F888_6332;
	R5420[3] = (char *(*)()) F889_6332;
	R5420[4] = (char *(*)()) F888_6332;
}

char *(*R5423[5])();
void R5423_init () {
	R5423[0] = (char *(*)()) F888_6335;
	R5423[1] = (char *(*)()) F889_6335;
	R5423[2] = (char *(*)()) F888_6335;
	R5423[3] = (char *(*)()) F889_6335;
	R5423[4] = (char *(*)()) F888_6335;
}

char *(*R5424[5])();
void R5424_init () {
	R5424[0] = (char *(*)()) F888_6336;
	R5424[1] = (char *(*)()) F889_6336;
	R5424[2] = (char *(*)()) F888_6336;
	R5424[3] = (char *(*)()) F889_6336;
	R5424[4] = (char *(*)()) F888_6336;
}

char *(*R5425[5])();
void R5425_init () {
	R5425[0] = (char *(*)()) F888_6337;
	R5425[1] = (char *(*)()) F889_6337;
	R5425[2] = (char *(*)()) F888_6337;
	R5425[3] = (char *(*)()) F889_6337;
	R5425[4] = (char *(*)()) F888_6337;
}

char *(*R5430[2])();
void R5430_init () {
	R5430[0] = (char *(*)()) F888_6294;
	R5430[1] = (char *(*)()) F889_6294_5430_1;
}
static EIF_REFERENCE F889_6294_5430_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F889_6294(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5431[2])();
void R5431_init () {
	R5431[0] = (char *(*)()) F888_6325;
	R5431[1] = (char *(*)()) F889_6325;
}

char *(*R5435[88])();
void R5435_init () {
	R5435[0] = (char *(*)()) F893_6362;
	R5435[1] = (char *(*)()) F894_6362;
	R5435[2] = (char *(*)()) F895_6362;
	R5435[3] = (char *(*)()) F896_6362;
	R5435[4] = (char *(*)()) F897_6362;
	R5435[5] = (char *(*)()) F898_6362;
	R5435[6] = (char *(*)()) F899_6362;
	R5435[7] = (char *(*)()) F900_6362;
	R5435[8] = (char *(*)()) F901_6362;
	R5435[9] = (char *(*)()) F902_6362;
	R5435[10] = (char *(*)()) F903_6362;
	R5435[11] = (char *(*)()) F904_6362;
	{long i; for (i = 12; i < 14; i++) R5435[i] = (char *(*)()) F893_6362;}
	R5435[14] = (char *(*)()) F894_6362;
	R5435[15] = (char *(*)()) F908_6450;
	R5435[16] = (char *(*)()) F909_6453;
	R5435[87] = (char *(*)()) F893_6362;
}

char *(*R5439[88])();
void R5439_init () {
	R5439[0] = (char *(*)()) F893_6366;
	R5439[1] = (char *(*)()) F894_6366;
	R5439[2] = (char *(*)()) F895_6366;
	R5439[3] = (char *(*)()) F896_6366;
	R5439[4] = (char *(*)()) F897_6366;
	R5439[5] = (char *(*)()) F898_6366;
	R5439[6] = (char *(*)()) F899_6366;
	R5439[7] = (char *(*)()) F900_6366;
	R5439[8] = (char *(*)()) F901_6366;
	R5439[9] = (char *(*)()) F902_6366;
	R5439[10] = (char *(*)()) F903_6366;
	R5439[11] = (char *(*)()) F904_6366;
	{long i; for (i = 12; i < 14; i++) R5439[i] = (char *(*)()) F893_6366;}
	R5439[14] = (char *(*)()) F894_6366;
	{long i; for (i = 15; i < 17; i++) R5439[i] = (char *(*)()) F893_6366;}
	R5439[87] = (char *(*)()) F893_6366;
}

char *(*R5443[88])();
void R5443_init () {
	R5443[0] = (char *(*)()) F893_6385;
	R5443[1] = (char *(*)()) F894_6385;
	R5443[2] = (char *(*)()) F895_6385;
	R5443[3] = (char *(*)()) F896_6385;
	R5443[4] = (char *(*)()) F897_6385;
	R5443[5] = (char *(*)()) F898_6385;
	R5443[6] = (char *(*)()) F899_6385;
	R5443[7] = (char *(*)()) F900_6385;
	R5443[8] = (char *(*)()) F901_6385;
	R5443[9] = (char *(*)()) F902_6385;
	R5443[10] = (char *(*)()) F903_6385;
	R5443[11] = (char *(*)()) F904_6385;
	{long i; for (i = 12; i < 14; i++) R5443[i] = (char *(*)()) F893_6385;}
	R5443[14] = (char *(*)()) F894_6385;
	{long i; for (i = 15; i < 17; i++) R5443[i] = (char *(*)()) F893_6385;}
	R5443[87] = (char *(*)()) F893_6385;
}

char *(*R5454[2])();
void R5454_init () {
	R5454[0] = (char *(*)()) F893_6403;
	R5454[1] = (char *(*)()) F894_6403_5454_4;
}
static void F894_6403_5454_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F894_6403(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5455[2])();
void R5455_init () {
	R5455[0] = (char *(*)()) F893_6416;
	R5455[1] = (char *(*)()) F894_6416;
}

char *(*R5628[2])();
void R5628_init () {
	R5628[0] = (char *(*)()) F915_6630;
	R5628[1] = (char *(*)()) F916_6735;
}

char *(*R5634[2])();
void R5634_init () {
	R5634[0] = (char *(*)()) F915_6636;
	R5634[1] = (char *(*)()) F916_6736;
}

char *(*R5636[2])();
void R5636_init () {
	R5636[0] = (char *(*)()) F915_6638;
	R5636[1] = (char *(*)()) F916_6737;
}

char *(*R5729[2])();
void R5729_init () {
	R5729[0] = (char *(*)()) F915_6733;
	R5729[1] = (char *(*)()) F916_6762;
}

char *(*R5765[12])();
void R5765_init () {
	R5765[0] = (char *(*)()) F925_6796;
	R5765[1] = (char *(*)()) F926_6802;
	R5765[2] = (char *(*)()) F927_6806;
	R5765[3] = (char *(*)()) F928_6813;
	{long i; for (i = 4; i < 7; i++) R5765[i] = (char *(*)()) F929_6822;}
	R5765[8] = (char *(*)()) F929_6822;
	R5765[10] = (char *(*)()) F929_6822;
	R5765[11] = (char *(*)()) F936_6842;
}

char *(*R5822[370])();
void R5822_init () {
	R5822[0] = (char *(*)()) F945_6882;
	R5822[369] = (char *(*)()) F1314_13129;
}

char *(*R5842[370])();
void R5842_init () {
	R5842[0] = (char *(*)()) F945_6879;
	R5842[369] = (char *(*)()) F1314_13170;
}

char *(*R6027[313])();
void R6027_init () {
	R6027[0] = (char *(*)()) F961_7071;
	R6027[1] = (char *(*)()) F966_7109;
	R6027[312] = (char *(*)()) F1272_11667;
}

char *(*R6162[6])();
void R6162_init () {
	R6162[0] = (char *(*)()) F989_7242;
	R6162[1] = (char *(*)()) F990_7244;
	R6162[2] = (char *(*)()) F991_7246;
	R6162[3] = (char *(*)()) F992_7249;
	R6162[4] = (char *(*)()) F993_7254;
	R6162[5] = (char *(*)()) F994_7312;
}

char *(*R6164[6])();
void R6164_init () {
	R6164[0] = (char *(*)()) F989_7243;
	{long i; for (i = 1; i < 6; i++) R6164[i] = (char *(*)()) F988_7234;}
}

char *(*R6165[6])();
void R6165_init () {
	{long i; for (i = 0; i < 3; i++) R6165[i] = (char *(*)()) F988_7235;}
	R6165[3] = (char *(*)()) F992_7250;
	{long i; for (i = 4; i < 6; i++) R6165[i] = (char *(*)()) F988_7235;}
}

char *(*R6166[6])();
void R6166_init () {
	R6166[0] = (char *(*)()) F988_7236;
	R6166[1] = (char *(*)()) F990_7245;
	{long i; for (i = 2; i < 6; i++) R6166[i] = (char *(*)()) F988_7236;}
}

char *(*R6167[6])();
void R6167_init () {
	{long i; for (i = 0; i < 4; i++) R6167[i] = (char *(*)()) F988_7237;}
	R6167[4] = (char *(*)()) F993_7256;
	R6167[5] = (char *(*)()) F988_7237;
}

char *(*R6168[6])();
void R6168_init () {
	{long i; for (i = 0; i < 4; i++) R6168[i] = (char *(*)()) F988_7238;}
	R6168[4] = (char *(*)()) F993_7253;
	R6168[5] = (char *(*)()) F988_7238;
}

char *(*R6171[6])();
void R6171_init () {
	{long i; for (i = 0; i < 2; i++) R6171[i] = (char *(*)()) F988_7241;}
	R6171[2] = (char *(*)()) F991_7247;
	{long i; for (i = 3; i < 6; i++) R6171[i] = (char *(*)()) F988_7241;}
}

char *(*R6231[318])();
void R6231_init () {
	R6231[0] = (char *(*)()) F997_7355;
	R6231[1] = (char *(*)()) F998_7468;
	{long i; for (i = 4; i < 6; i++) R6231[i] = (char *(*)()) F1000_7491;}
	{long i; for (i = 7; i < 9; i++) R6231[i] = (char *(*)()) F1003_7532;}
	{long i; for (i = 10; i < 12; i++) R6231[i] = (char *(*)()) F1006_7580;}
	{long i; for (i = 13; i < 43; i++) R6231[i] = (char *(*)()) F1009_7601;}
	R6231[43] = (char *(*)()) F1040_7627;
	R6231[44] = (char *(*)()) F1041_7627;
	{long i; for (i = 46; i < 51; i++) R6231[i] = (char *(*)()) F1042_7635;}
	{long i; for (i = 55; i < 58; i++) R6231[i] = (char *(*)()) F1048_7694;}
	{long i; for (i = 60; i < 62; i++) R6231[i] = (char *(*)()) F1048_7694;}
	R6231[74] = (char *(*)()) F1071_8469;
	R6231[75] = (char *(*)()) F1072_8602;
	R6231[76] = (char *(*)()) F1073_8649;
	R6231[77] = (char *(*)()) F1074_8691;
	R6231[78] = (char *(*)()) F1075_8691;
	R6231[79] = (char *(*)()) F1076_8691;
	R6231[80] = (char *(*)()) F1077_8691;
	R6231[81] = (char *(*)()) F1078_8691;
	R6231[82] = (char *(*)()) F1079_8691;
	R6231[83] = (char *(*)()) F1080_8691;
	R6231[84] = (char *(*)()) F1081_8691;
	R6231[85] = (char *(*)()) F1082_8691;
	R6231[86] = (char *(*)()) F1083_8691;
	R6231[87] = (char *(*)()) F1084_8691;
	R6231[88] = (char *(*)()) F1085_8691;
	R6231[89] = (char *(*)()) F1086_8691;
	R6231[90] = (char *(*)()) F1087_8691;
	R6231[91] = (char *(*)()) F1088_8691;
	R6231[92] = (char *(*)()) F1089_8691;
	R6231[93] = (char *(*)()) F1090_8691;
	R6231[94] = (char *(*)()) F1091_8691;
	R6231[95] = (char *(*)()) F1092_8691;
	R6231[96] = (char *(*)()) F1093_8691;
	R6231[97] = (char *(*)()) F1094_8691;
	R6231[98] = (char *(*)()) F1095_8691;
	R6231[99] = (char *(*)()) F1096_8691;
	R6231[100] = (char *(*)()) F1097_8691;
	R6231[101] = (char *(*)()) F1098_8691;
	R6231[102] = (char *(*)()) F1099_8691;
	R6231[103] = (char *(*)()) F1100_8691;
	R6231[104] = (char *(*)()) F1101_8691;
	R6231[105] = (char *(*)()) F1102_8691;
	R6231[106] = (char *(*)()) F1103_8691;
	R6231[107] = (char *(*)()) F1104_8691;
	R6231[108] = (char *(*)()) F1105_8691;
	R6231[109] = (char *(*)()) F1106_8691;
	R6231[110] = (char *(*)()) F1107_8691;
	{long i; for (i = 127; i < 130; i++) R6231[i] = (char *(*)()) F1121_8792;}
	{long i; for (i = 131; i < 134; i++) R6231[i] = (char *(*)()) F1121_8792;}
	R6231[181] = (char *(*)()) F1178_9036;
	R6231[182] = (char *(*)()) F1179_9041;
	R6231[183] = (char *(*)()) F1180_9055;
	R6231[184] = (char *(*)()) F1181_9096;
	{long i; for (i = 187; i < 189; i++) R6231[i] = (char *(*)()) F1183_9113;}
	{long i; for (i = 190; i < 192; i++) R6231[i] = (char *(*)()) F1186_9211;}
	{long i; for (i = 193; i < 195; i++) R6231[i] = (char *(*)()) F1189_9310;}
	{long i; for (i = 196; i < 198; i++) R6231[i] = (char *(*)()) F1192_9409;}
	{long i; for (i = 199; i < 201; i++) R6231[i] = (char *(*)()) F1195_9508;}
	{long i; for (i = 202; i < 204; i++) R6231[i] = (char *(*)()) F1198_9602;}
	{long i; for (i = 205; i < 207; i++) R6231[i] = (char *(*)()) F1201_9696;}
	{long i; for (i = 208; i < 210; i++) R6231[i] = (char *(*)()) F1204_9791;}
	{long i; for (i = 211; i < 213; i++) R6231[i] = (char *(*)()) F1207_9886;}
	{long i; for (i = 214; i < 216; i++) R6231[i] = (char *(*)()) F1210_9952;}
	R6231[216] = (char *(*)()) F1213_10034;
	R6231[217] = (char *(*)()) F1214_10072;
	R6231[218] = (char *(*)()) F1215_10078;
	R6231[226] = (char *(*)()) F1223_10107;
	R6231[317] = (char *(*)()) F1314_13097;
}

char *(*R6396[2])();
void R6396_init () {
	R6396[0] = (char *(*)()) F1001_7527;
	R6396[1] = (char *(*)()) F1002_7527;
}

char *(*R6544[4])();
void R6544_init () {
	R6544[0] = (char *(*)()) F1044_7674;
	R6544[1] = (char *(*)()) F1045_7674_6544_1;
	R6544[2] = (char *(*)()) F1046_7674_6544_1;
	R6544[3] = (char *(*)()) F1045_7674_6544_1;
}
static EIF_REFERENCE F1045_7674_6544_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1045_7674(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1046_7674_6544_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1046_7674(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6549[4])();
void R6549_init () {
	R6549[0] = (char *(*)()) F1044_7683;
	R6549[1] = (char *(*)()) F1045_7683_6549_376;
	R6549[2] = (char *(*)()) F1046_7683_6549_376;
	R6549[3] = (char *(*)()) F1045_7683_6549_376;
}
static EIF_REFERENCE F1045_7683_6549_376 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1045_7683(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1046_7683_6549_376 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1046_7683(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y6550_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6550_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6550_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6550_pgtype3[] = {1007,0xFFFF};
EIF_TYPE_INDEX *Y6550_gen_type [4];
EIF_TYPE_INDEX Y6550 [4];
void Y6550_init (void)
{
	egc_routines_types [6550] = Y6550;
	egc_routines_gen_types [6550] = Y6550_gen_type;
	egc_routines_offset [6550] = 1043;
	Y6550_gen_type [0] = Y6550_pgtype0;
	Y6550_gen_type [1] = Y6550_pgtype1;
	Y6550_gen_type [2] = Y6550_pgtype2;
	Y6550_gen_type [3] = Y6550_pgtype3;
	Y6550[3] = 1007;
}

char *(*R6551[263])();
void R6551_init () {
	{long i; for (i = 0; i < 3; i++) R6551[i] = (char *(*)()) F1051_7815;}
	{long i; for (i = 5; i < 7; i++) R6551[i] = (char *(*)()) F1056_7984;}
	R6551[262] = (char *(*)()) F1314_13071;
}

char *(*R6553[263])();
void R6553_init () {
	R6553[0] = (char *(*)()) F1052_7875;
	{long i; for (i = 1; i < 3; i++) R6553[i] = (char *(*)()) F1053_7897;}
	R6553[5] = (char *(*)()) F1057_8045;
	R6553[6] = (char *(*)()) F1058_8068;
	R6553[262] = (char *(*)()) F1314_13199;
}

char *(*R6554[263])();
void R6554_init () {
	R6554[0] = (char *(*)()) F1052_7874;
	{long i; for (i = 1; i < 3; i++) R6554[i] = (char *(*)()) F1053_7896;}
	R6554[5] = (char *(*)()) F1057_8043;
	R6554[6] = (char *(*)()) F1058_8066;
	R6554[262] = (char *(*)()) F1053_7896;
}

char *(*R6555[263])();
void R6555_init () {
	{long i; for (i = 0; i < 3; i++) R6555[i] = (char *(*)()) F1048_7688;}
	{long i; for (i = 5; i < 7; i++) R6555[i] = (char *(*)()) F1056_7996;}
	R6555[262] = (char *(*)()) F1048_7688;
}

char *(*R6565[263])();
void R6565_init () {
	{long i; for (i = 0; i < 3; i++) R6565[i] = (char *(*)()) F1051_7846;}
	{long i; for (i = 5; i < 7; i++) R6565[i] = (char *(*)()) F1056_8014;}
	R6565[262] = (char *(*)()) F1051_7846;
}

char *(*R6567[263])();
void R6567_init () {
	{long i; for (i = 0; i < 3; i++) R6567[i] = (char *(*)()) F1051_7848;}
	{long i; for (i = 5; i < 7; i++) R6567[i] = (char *(*)()) F1056_8016;}
	R6567[262] = (char *(*)()) F1051_7848;
}

char *(*R6568[263])();
void R6568_init () {
	R6568[0] = (char *(*)()) F1052_7884;
	{long i; for (i = 1; i < 3; i++) R6568[i] = (char *(*)()) F710_5583;}
	R6568[5] = (char *(*)()) F1057_8055;
	R6568[6] = (char *(*)()) F709_5583;
	R6568[262] = (char *(*)()) F710_5583;
}

char *(*R6570[263])();
void R6570_init () {
	{long i; for (i = 0; i < 3; i++) R6570[i] = (char *(*)()) F1051_7849;}
	{long i; for (i = 5; i < 7; i++) R6570[i] = (char *(*)()) F1056_8017;}
	R6570[262] = (char *(*)()) F1051_7849;
}

char *(*R6571[263])();
void R6571_init () {
	{long i; for (i = 0; i < 3; i++) R6571[i] = (char *(*)()) F1048_7705;}
	{long i; for (i = 5; i < 7; i++) R6571[i] = (char *(*)()) F1056_8018;}
	R6571[262] = (char *(*)()) F1048_7705;
}

char *(*R6590[263])();
void R6590_init () {
	{long i; for (i = 0; i < 3; i++) R6590[i] = (char *(*)()) F1051_7837;}
	{long i; for (i = 5; i < 7; i++) R6590[i] = (char *(*)()) F1056_8005;}
	R6590[262] = (char *(*)()) F1314_13102;
}

char *(*R6591[263])();
void R6591_init () {
	{long i; for (i = 0; i < 3; i++) R6591[i] = (char *(*)()) F1051_7836;}
	{long i; for (i = 5; i < 7; i++) R6591[i] = (char *(*)()) F1056_8004;}
	R6591[262] = (char *(*)()) F1314_13104;
}

char *(*R6595[263])();
void R6595_init () {
	{long i; for (i = 0; i < 3; i++) R6595[i] = (char *(*)()) F1048_7729;}
	{long i; for (i = 5; i < 7; i++) R6595[i] = (char *(*)()) F1048_7729;}
	R6595[262] = (char *(*)()) F1314_13109;
}

char *(*R6596[263])();
void R6596_init () {
	{long i; for (i = 0; i < 3; i++) R6596[i] = (char *(*)()) F1048_7730;}
	{long i; for (i = 5; i < 7; i++) R6596[i] = (char *(*)()) F1048_7730;}
	R6596[262] = (char *(*)()) F1314_13115;
}

char *(*R6601[263])();
void R6601_init () {
	{long i; for (i = 0; i < 3; i++) R6601[i] = (char *(*)()) F1051_7833;}
	{long i; for (i = 5; i < 7; i++) R6601[i] = (char *(*)()) F1056_8001;}
	R6601[262] = (char *(*)()) F1314_13090;
}

char *(*R6612[263])();
void R6612_init () {
	R6612[0] = (char *(*)()) F1052_7880;
	{long i; for (i = 1; i < 3; i++) R6612[i] = (char *(*)()) F1053_7963;}
	R6612[5] = (char *(*)()) F1057_8050;
	R6612[6] = (char *(*)()) F1058_8134;
	R6612[262] = (char *(*)()) F1314_13159;
}

char *(*R6613[263])();
void R6613_init () {
	R6613[0] = (char *(*)()) F1052_7881;
	{long i; for (i = 1; i < 3; i++) R6613[i] = (char *(*)()) F1053_7964;}
	R6613[5] = (char *(*)()) F1057_8051;
	R6613[6] = (char *(*)()) F1058_8135;
	R6613[262] = (char *(*)()) F1314_13160;
}

char *(*R6631[263])();
void R6631_init () {
	R6631[0] = (char *(*)()) F1052_7882;
	{long i; for (i = 1; i < 3; i++) R6631[i] = (char *(*)()) F1053_7975;}
	R6631[5] = (char *(*)()) F1057_8052;
	R6631[6] = (char *(*)()) F1058_8146;
	R6631[262] = (char *(*)()) F1314_13088;
}


#ifdef __cplusplus
}
#endif
