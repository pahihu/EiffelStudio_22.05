#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R3105[652])();
void R3105_init () {
	R3105[0] = (char *(*)()) F260_3308;
	R3105[13] = (char *(*)()) F268_3398;
	R3105[14] = (char *(*)()) F274_3561;
	R3105[651] = (char *(*)()) F911_6470;
}

char *(*R3131[4])();
void R3131_init () {
	R3131[0] = (char *(*)()) F261_3327;
	R3131[3] = (char *(*)()) F264_3355;
}

char *(*R3317[788])();
void R3317_init () {
	R3317[0] = (char *(*)()) F277_3600;
	R3317[786] = (char *(*)()) F1064_8266;
	R3317[787] = (char *(*)()) F1065_8294;
}

char *(*R3318[788])();
void R3318_init () {
	R3318[0] = (char *(*)()) F277_3601;
	R3318[786] = (char *(*)()) F1064_8270;
	R3318[787] = (char *(*)()) F1065_8296;
}

char *(*R3320[788])();
void R3320_init () {
	R3320[0] = (char *(*)()) F277_3603;
	R3320[786] = (char *(*)()) F1064_8272;
	R3320[787] = (char *(*)()) F1065_8298;
}

char *(*R3321[788])();
void R3321_init () {
	R3321[0] = (char *(*)()) F277_3604;
	R3321[786] = (char *(*)()) F1064_8273;
	R3321[787] = (char *(*)()) F1065_8299;
}

char *(*R3322[788])();
void R3322_init () {
	R3322[0] = (char *(*)()) F277_3605;
	R3322[786] = (char *(*)()) F1064_8274;
	R3322[787] = (char *(*)()) F1065_8300;
}

char *(*R3323[788])();
void R3323_init () {
	R3323[0] = (char *(*)()) F278_3609;
	{long i; for (i = 786; i < 788; i++) R3323[i] = (char *(*)()) F279_3612;}
}

char *(*R3324[788])();
void R3324_init () {
	R3324[0] = (char *(*)()) F278_3610;
	{long i; for (i = 786; i < 788; i++) R3324[i] = (char *(*)()) F279_3614;}
}

char *(*R3342[2])();
void R3342_init () {
	R3342[0] = (char *(*)()) F1064_8275;
	R3342[1] = (char *(*)()) F1065_8301;
}

char *(*R3343[2])();
void R3343_init () {
	R3343[0] = (char *(*)()) F1064_8281;
	R3343[1] = (char *(*)()) F1065_8303;
}

char *(*R3345[2])();
void R3345_init () {
	R3345[0] = (char *(*)()) F282_3617;
	R3345[1] = (char *(*)()) F283_3617;
}

char *(*R3400[41])();
void R3400_init () {
	R3400[0] = (char *(*)()) F290_3671;
	R3400[3] = (char *(*)()) F293_3695;
	R3400[5] = (char *(*)()) F295_3697;
	R3400[6] = (char *(*)()) F296_3701;
	R3400[7] = (char *(*)()) F297_3707;
	{long i; for (i = 8; i < 11; i++) R3400[i] = (char *(*)()) F298_3724;}
	R3400[12] = (char *(*)()) F302_3728;
	R3400[13] = (char *(*)()) F303_3730;
	R3400[14] = (char *(*)()) F304_3732;
	R3400[16] = (char *(*)()) F306_3734;
	R3400[17] = (char *(*)()) F307_3738;
	R3400[20] = (char *(*)()) F310_3740;
	R3400[21] = (char *(*)()) F311_3742;
	R3400[23] = (char *(*)()) F313_3746;
	R3400[24] = (char *(*)()) F314_3748;
	R3400[25] = (char *(*)()) F315_3754;
	R3400[27] = (char *(*)()) F317_3756;
	R3400[28] = (char *(*)()) F318_3758;
	R3400[29] = (char *(*)()) F319_3762;
	R3400[30] = (char *(*)()) F320_3766;
	R3400[32] = (char *(*)()) F322_3768;
	R3400[33] = (char *(*)()) F323_3770;
	R3400[35] = (char *(*)()) F325_3772;
	R3400[36] = (char *(*)()) F326_3774;
	R3400[37] = (char *(*)()) F327_3776;
	R3400[38] = (char *(*)()) F328_3778;
	R3400[39] = (char *(*)()) F329_3782;
	R3400[40] = (char *(*)()) F330_3784;
}

char *(*R3567[185])();
void R3567_init () {
	R3567[0] = (char *(*)()) F1072_8603;
	R3567[52] = (char *(*)()) F1124_8883;
	R3567[53] = (char *(*)()) F1125_8892;
	R3567[54] = (char *(*)()) F1126_8901;
	R3567[56] = (char *(*)()) F1128_8935;
	R3567[57] = (char *(*)()) F1129_8951;
	R3567[58] = (char *(*)()) F1130_8958;
	R3567[184] = (char *(*)()) F1256_10929;
}

char *(*R3725[966])();
void R3725_init () {
	R3725[0] = (char *(*)()) F349_4207;
	{long i; for (i = 652; i < 654; i++) R3725[i] = (char *(*)()) F1000_7496;}
	{long i; for (i = 655; i < 657; i++) R3725[i] = (char *(*)()) F1003_7536;}
	{long i; for (i = 703; i < 706; i++) R3725[i] = (char *(*)()) F1051_7845;}
	{long i; for (i = 708; i < 710; i++) R3725[i] = (char *(*)()) F1056_8013;}
	R3725[722] = (char *(*)()) F1071_8472;
	R3725[724] = (char *(*)()) F1073_8659;
	{long i; for (i = 775; i < 778; i++) R3725[i] = (char *(*)()) F1121_8808;}
	{long i; for (i = 779; i < 782; i++) R3725[i] = (char *(*)()) F1121_8808;}
	R3725[835] = (char *(*)()) F1184_9182_3725_2;
	R3725[836] = (char *(*)()) F1185_9182_3725_2;
	R3725[838] = (char *(*)()) F1187_9281_3725_2;
	R3725[839] = (char *(*)()) F1188_9281_3725_2;
	R3725[841] = (char *(*)()) F1190_9380_3725_2;
	R3725[842] = (char *(*)()) F1191_9380_3725_2;
	R3725[844] = (char *(*)()) F1193_9479_3725_2;
	R3725[845] = (char *(*)()) F1194_9479_3725_2;
	R3725[847] = (char *(*)()) F1196_9574_3725_2;
	R3725[848] = (char *(*)()) F1197_9574_3725_2;
	R3725[850] = (char *(*)()) F1199_9668_3725_2;
	R3725[851] = (char *(*)()) F1200_9668_3725_2;
	R3725[853] = (char *(*)()) F1202_9763_3725_2;
	R3725[854] = (char *(*)()) F1203_9763_3725_2;
	R3725[856] = (char *(*)()) F1205_9858_3725_2;
	R3725[857] = (char *(*)()) F1206_9858_3725_2;
	R3725[859] = (char *(*)()) F1208_9927_3725_2;
	R3725[860] = (char *(*)()) F1209_9927_3725_2;
	R3725[862] = (char *(*)()) F1211_9993_3725_2;
	R3725[863] = (char *(*)()) F1212_9993_3725_2;
	R3725[877] = (char *(*)()) F1226_10220;
	R3725[965] = (char *(*)()) F1314_13113;
}
static EIF_BOOLEAN F1184_9182_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1184_9182(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1185_9182_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1185_9182(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1187_9281_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1187_9281(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1188_9281_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1188_9281(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1190_9380_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1190_9380(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1191_9380_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1191_9380(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1193_9479_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1193_9479(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1194_9479_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1194_9479(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1196_9574_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1196_9574(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1197_9574_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1197_9574(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1199_9668_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1199_9668(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1200_9668_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1200_9668(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1202_9763_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1202_9763(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1203_9763_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1203_9763(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1205_9858_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1205_9858(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1206_9858_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1206_9858(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1208_9927_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1208_9927(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1209_9927_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1209_9927(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1211_9993_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1211_9993(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1212_9993_3725_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1212_9993(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R4309[7])();
void R4309_init () {
	{long i; for (i = 0; i < 6; i++) R4309[i] = (char *(*)()) F371_4708;}
	R4309[6] = (char *(*)()) F378_4729;
}

char *(*R4322[922])();
void R4322_init () {
	R4322[0] = (char *(*)()) F387_4730;
	R4322[430] = (char *(*)()) F379_4730;
	R4322[431] = (char *(*)()) F380_4730;
	R4322[432] = (char *(*)()) F381_4730;
	R4322[433] = (char *(*)()) F382_4730;
	R4322[434] = (char *(*)()) F383_4730;
	R4322[435] = (char *(*)()) F384_4730;
	R4322[436] = (char *(*)()) F385_4730;
	R4322[437] = (char *(*)()) F386_4730;
	R4322[438] = (char *(*)()) F387_4730;
	R4322[439] = (char *(*)()) F388_4730;
	R4322[440] = (char *(*)()) F389_4730;
	R4322[441] = (char *(*)()) F390_4730;
	R4322[500] = (char *(*)()) F379_4730;
	R4322[501] = (char *(*)()) F380_4730;
	R4322[502] = (char *(*)()) F381_4730;
	R4322[503] = (char *(*)()) F382_4730;
	R4322[504] = (char *(*)()) F383_4730;
	R4322[505] = (char *(*)()) F384_4730;
	R4322[506] = (char *(*)()) F385_4730;
	R4322[507] = (char *(*)()) F386_4730;
	R4322[508] = (char *(*)()) F387_4730;
	R4322[509] = (char *(*)()) F388_4730;
	R4322[510] = (char *(*)()) F389_4730;
	R4322[511] = (char *(*)()) F390_4730;
	{long i; for (i = 512; i < 514; i++) R4322[i] = (char *(*)()) F379_4730;}
	R4322[514] = (char *(*)()) F380_4730;
	{long i; for (i = 515; i < 517; i++) R4322[i] = (char *(*)()) F379_4730;}
	R4322[587] = (char *(*)()) F379_4730;
	{long i; for (i = 660; i < 662; i++) R4322[i] = (char *(*)()) F383_4730;}
	R4322[665] = (char *(*)()) F386_4730;
	R4322[921] = (char *(*)()) F383_4730;
}

char *(*R4323[922])();
void R4323_init () {
	R4323[0] = (char *(*)()) F387_4731_4323_142;
	R4323[430] = (char *(*)()) F379_4731;
	R4323[431] = (char *(*)()) F380_4731_4323_142;
	R4323[432] = (char *(*)()) F381_4731_4323_142;
	R4323[433] = (char *(*)()) F382_4731_4323_142;
	R4323[434] = (char *(*)()) F383_4731_4323_142;
	R4323[435] = (char *(*)()) F384_4731_4323_142;
	R4323[436] = (char *(*)()) F385_4731_4323_142;
	R4323[437] = (char *(*)()) F386_4731_4323_142;
	R4323[438] = (char *(*)()) F387_4731_4323_142;
	R4323[439] = (char *(*)()) F388_4731_4323_142;
	R4323[440] = (char *(*)()) F389_4731_4323_142;
	R4323[441] = (char *(*)()) F390_4731_4323_142;
	R4323[500] = (char *(*)()) F379_4731;
	R4323[501] = (char *(*)()) F380_4731_4323_142;
	R4323[502] = (char *(*)()) F381_4731_4323_142;
	R4323[503] = (char *(*)()) F382_4731_4323_142;
	R4323[504] = (char *(*)()) F383_4731_4323_142;
	R4323[505] = (char *(*)()) F384_4731_4323_142;
	R4323[506] = (char *(*)()) F385_4731_4323_142;
	R4323[507] = (char *(*)()) F386_4731_4323_142;
	R4323[508] = (char *(*)()) F387_4731_4323_142;
	R4323[509] = (char *(*)()) F388_4731_4323_142;
	R4323[510] = (char *(*)()) F389_4731_4323_142;
	R4323[511] = (char *(*)()) F390_4731_4323_142;
	{long i; for (i = 512; i < 514; i++) R4323[i] = (char *(*)()) F379_4731;}
	R4323[514] = (char *(*)()) F380_4731_4323_142;
	{long i; for (i = 515; i < 517; i++) R4323[i] = (char *(*)()) F379_4731;}
	R4323[587] = (char *(*)()) F379_4731;
	{long i; for (i = 660; i < 662; i++) R4323[i] = (char *(*)()) F383_4731_4323_142;}
	R4323[665] = (char *(*)()) F386_4731_4323_142;
	R4323[921] = (char *(*)()) F383_4731_4323_142;
}
static void F387_4731_4323_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F387_4731(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F380_4731_4323_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F380_4731(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F381_4731_4323_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F381_4731(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F382_4731_4323_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F382_4731(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F383_4731_4323_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F383_4731(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F384_4731_4323_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F384_4731(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F385_4731_4323_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F385_4731(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F386_4731_4323_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F386_4731(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F388_4731_4323_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F388_4731(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F389_4731_4323_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F389_4731(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F390_4731_4323_142 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F390_4731(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4329[922])();
void R4329_init () {
	R4329[0] = (char *(*)()) F387_4737;
	R4329[430] = (char *(*)()) F379_4737;
	R4329[431] = (char *(*)()) F380_4737;
	R4329[432] = (char *(*)()) F381_4737;
	R4329[433] = (char *(*)()) F382_4737;
	R4329[434] = (char *(*)()) F383_4737;
	R4329[435] = (char *(*)()) F384_4737;
	R4329[436] = (char *(*)()) F385_4737;
	R4329[437] = (char *(*)()) F386_4737;
	R4329[438] = (char *(*)()) F387_4737;
	R4329[439] = (char *(*)()) F388_4737;
	R4329[440] = (char *(*)()) F389_4737;
	R4329[441] = (char *(*)()) F390_4737;
	R4329[500] = (char *(*)()) F379_4737;
	R4329[501] = (char *(*)()) F380_4737;
	R4329[502] = (char *(*)()) F381_4737;
	R4329[503] = (char *(*)()) F382_4737;
	R4329[504] = (char *(*)()) F383_4737;
	R4329[505] = (char *(*)()) F384_4737;
	R4329[506] = (char *(*)()) F385_4737;
	R4329[507] = (char *(*)()) F386_4737;
	R4329[508] = (char *(*)()) F387_4737;
	R4329[509] = (char *(*)()) F388_4737;
	R4329[510] = (char *(*)()) F389_4737;
	R4329[511] = (char *(*)()) F390_4737;
	{long i; for (i = 512; i < 514; i++) R4329[i] = (char *(*)()) F379_4737;}
	R4329[514] = (char *(*)()) F380_4737;
	{long i; for (i = 515; i < 517; i++) R4329[i] = (char *(*)()) F379_4737;}
	R4329[587] = (char *(*)()) F379_4737;
	{long i; for (i = 660; i < 662; i++) R4329[i] = (char *(*)()) F383_4737;}
	R4329[665] = (char *(*)()) F386_4737;
	R4329[921] = (char *(*)()) F383_4737;
}


#ifdef __cplusplus
}
#endif
