#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4930[519])();
void R4930_init () {
	R4930[0] = (char *(*)()) F796_6058;
	R4930[1] = (char *(*)()) F797_6058_4930_9;
	R4930[2] = (char *(*)()) F798_6058_4930_9;
	R4930[3] = (char *(*)()) F799_6058_4930_9;
	R4930[4] = (char *(*)()) F800_6058_4930_9;
	R4930[5] = (char *(*)()) F801_6058_4930_9;
	R4930[6] = (char *(*)()) F802_6058_4930_9;
	R4930[7] = (char *(*)()) F803_6058_4930_9;
	{long i; for (i = 8; i < 10; i++) R4930[i] = (char *(*)()) F796_6058;}
	R4930[10] = (char *(*)()) F800_6058_4930_9;
	R4930[11] = (char *(*)()) F799_6058_4930_9;
	R4930[12] = (char *(*)()) F801_6058_4930_9;
	R4930[13] = (char *(*)()) F803_6058_4930_9;
	R4930[26] = (char *(*)()) F822_6179_4930_9;
	R4930[27] = (char *(*)()) F823_6207_4930_9;
	R4930[28] = (char *(*)()) F824_6207_4930_9;
	R4930[29] = (char *(*)()) F825_6207_4930_9;
	R4930[30] = (char *(*)()) F826_6207_4930_9;
	R4930[31] = (char *(*)()) F827_6207_4930_9;
	R4930[32] = (char *(*)()) F828_6207_4930_9;
	R4930[33] = (char *(*)()) F829_6207_4930_9;
	R4930[34] = (char *(*)()) F830_6207_4930_9;
	R4930[35] = (char *(*)()) F831_6207_4930_9;
	R4930[36] = (char *(*)()) F832_6207_4930_9;
	R4930[37] = (char *(*)()) F833_6207_4930_9;
	R4930[38] = (char *(*)()) F834_6207_4930_9;
	R4930[92] = (char *(*)()) F840_6260_4930_9;
	R4930[93] = (char *(*)()) F841_6260_4930_9;
	R4930[94] = (char *(*)()) F840_6260_4930_9;
	R4930[95] = (char *(*)()) F841_6260_4930_9;
	R4930[96] = (char *(*)()) F840_6260_4930_9;
	R4930[97] = (char *(*)()) F893_6401_4930_9;
	R4930[98] = (char *(*)()) F894_6401_4930_9;
	R4930[99] = (char *(*)()) F895_6401_4930_9;
	R4930[100] = (char *(*)()) F896_6401_4930_9;
	R4930[101] = (char *(*)()) F897_6401_4930_9;
	R4930[102] = (char *(*)()) F898_6401_4930_9;
	R4930[103] = (char *(*)()) F899_6401_4930_9;
	R4930[104] = (char *(*)()) F900_6401_4930_9;
	R4930[105] = (char *(*)()) F901_6401_4930_9;
	R4930[106] = (char *(*)()) F902_6401_4930_9;
	R4930[107] = (char *(*)()) F903_6401_4930_9;
	R4930[108] = (char *(*)()) F904_6401_4930_9;
	{long i; for (i = 109; i < 111; i++) R4930[i] = (char *(*)()) F893_6401_4930_9;}
	R4930[111] = (char *(*)()) F894_6401_4930_9;
	{long i; for (i = 112; i < 114; i++) R4930[i] = (char *(*)()) F893_6401_4930_9;}
	R4930[184] = (char *(*)()) F893_6401_4930_9;
	{long i; for (i = 257; i < 259; i++) R4930[i] = (char *(*)()) F1053_7915_4930_9;}
	R4930[262] = (char *(*)()) F1058_8086_4930_9;
	R4930[518] = (char *(*)()) F1314_13121_4930_9;
}
static void F797_6058_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F797_6058(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F798_6058_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F798_6058(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F799_6058_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F799_6058(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F800_6058_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F800_6058(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F801_6058_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F801_6058(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F802_6058_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F802_6058(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F803_6058_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F803_6058(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F822_6179_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F822_6179(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F823_6207_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F823_6207(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F824_6207_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F824_6207(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F825_6207_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F825_6207(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F826_6207_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F826_6207(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F827_6207_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F827_6207(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F828_6207_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F828_6207(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F829_6207_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F829_6207(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F830_6207_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F830_6207(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F831_6207_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F831_6207(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F832_6207_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F832_6207(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F833_6207_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F833_6207(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F834_6207_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F834_6207(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F840_6260_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F840_6260(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F841_6260_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F841_6260(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F893_6401_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F893_6401(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F894_6401_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F894_6401(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F895_6401_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F895_6401(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F896_6401_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F896_6401(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F897_6401_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F897_6401(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F898_6401_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F898_6401(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F899_6401_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F899_6401(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F900_6401_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F900_6401(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F901_6401_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F901_6401(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F902_6401_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F902_6401(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F903_6401_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F903_6401(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F904_6401_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F904_6401(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1053_7915_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1053_7915(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1058_8086_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1058_8086(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1314_13121_4930_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1314_13121(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R4931[519])();
void R4931_init () {
	R4931[0] = (char *(*)()) F796_6059;
	R4931[1] = (char *(*)()) F797_6059_4931_9;
	R4931[2] = (char *(*)()) F798_6059_4931_9;
	R4931[3] = (char *(*)()) F799_6059_4931_9;
	R4931[4] = (char *(*)()) F800_6059_4931_9;
	R4931[5] = (char *(*)()) F801_6059_4931_9;
	R4931[6] = (char *(*)()) F802_6059_4931_9;
	R4931[7] = (char *(*)()) F803_6059_4931_9;
	{long i; for (i = 8; i < 10; i++) R4931[i] = (char *(*)()) F796_6059;}
	R4931[10] = (char *(*)()) F800_6059_4931_9;
	R4931[11] = (char *(*)()) F799_6059_4931_9;
	R4931[12] = (char *(*)()) F801_6059_4931_9;
	R4931[13] = (char *(*)()) F803_6059_4931_9;
	R4931[26] = (char *(*)()) F822_6179_4931_9;
	R4931[27] = (char *(*)()) F823_6207_4931_9;
	R4931[28] = (char *(*)()) F824_6207_4931_9;
	R4931[29] = (char *(*)()) F825_6207_4931_9;
	R4931[30] = (char *(*)()) F826_6207_4931_9;
	R4931[31] = (char *(*)()) F827_6207_4931_9;
	R4931[32] = (char *(*)()) F828_6207_4931_9;
	R4931[33] = (char *(*)()) F829_6207_4931_9;
	R4931[34] = (char *(*)()) F830_6207_4931_9;
	R4931[35] = (char *(*)()) F831_6207_4931_9;
	R4931[36] = (char *(*)()) F832_6207_4931_9;
	R4931[37] = (char *(*)()) F833_6207_4931_9;
	R4931[38] = (char *(*)()) F834_6207_4931_9;
	R4931[92] = (char *(*)()) F840_6260_4931_9;
	R4931[93] = (char *(*)()) F841_6260_4931_9;
	R4931[94] = (char *(*)()) F840_6260_4931_9;
	R4931[95] = (char *(*)()) F841_6260_4931_9;
	R4931[96] = (char *(*)()) F840_6260_4931_9;
	R4931[97] = (char *(*)()) F893_6401_4931_9;
	R4931[98] = (char *(*)()) F894_6401_4931_9;
	R4931[99] = (char *(*)()) F895_6401_4931_9;
	R4931[100] = (char *(*)()) F896_6401_4931_9;
	R4931[101] = (char *(*)()) F897_6401_4931_9;
	R4931[102] = (char *(*)()) F898_6401_4931_9;
	R4931[103] = (char *(*)()) F899_6401_4931_9;
	R4931[104] = (char *(*)()) F900_6401_4931_9;
	R4931[105] = (char *(*)()) F901_6401_4931_9;
	R4931[106] = (char *(*)()) F902_6401_4931_9;
	R4931[107] = (char *(*)()) F903_6401_4931_9;
	R4931[108] = (char *(*)()) F904_6401_4931_9;
	{long i; for (i = 109; i < 111; i++) R4931[i] = (char *(*)()) F893_6401_4931_9;}
	R4931[111] = (char *(*)()) F894_6401_4931_9;
	{long i; for (i = 112; i < 114; i++) R4931[i] = (char *(*)()) F893_6401_4931_9;}
	R4931[184] = (char *(*)()) F893_6401_4931_9;
	{long i; for (i = 257; i < 259; i++) R4931[i] = (char *(*)()) F1053_7915_4931_9;}
	R4931[262] = (char *(*)()) F1058_8086_4931_9;
	R4931[518] = (char *(*)()) F1314_13121_4931_9;
}
static void F797_6059_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F797_6059(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F798_6059_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F798_6059(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F799_6059_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F799_6059(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F800_6059_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F800_6059(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F801_6059_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F801_6059(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F802_6059_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F802_6059(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F803_6059_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F803_6059(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F822_6179_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F822_6179(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F823_6207_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F823_6207(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F824_6207_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F824_6207(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F825_6207_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F825_6207(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F826_6207_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F826_6207(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F827_6207_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F827_6207(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F828_6207_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F828_6207(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F829_6207_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F829_6207(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F830_6207_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F830_6207(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F831_6207_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F831_6207(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F832_6207_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F832_6207(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F833_6207_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F833_6207(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F834_6207_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F834_6207(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F840_6260_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F840_6260(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F841_6260_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F841_6260(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F893_6401_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F893_6401(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F894_6401_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F894_6401(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F895_6401_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F895_6401(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F896_6401_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F896_6401(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F897_6401_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F897_6401(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F898_6401_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F898_6401(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F899_6401_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F899_6401(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F900_6401_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F900_6401(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F901_6401_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F901_6401(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F902_6401_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F902_6401(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F903_6401_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F903_6401(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F904_6401_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F904_6401(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1053_7915_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1053_7915(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1058_8086_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1058_8086(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1314_13121_4931_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1314_13121(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y4932_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype32[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype33[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype34[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype35[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype36[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype37[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype38[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype39[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype40[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype41[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype42[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype43[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype44[] = {1052,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype45[] = {1047,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype46[] = {1047,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype47[] = {1047,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype48[] = {1047,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype49[] = {1047,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype50[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype51[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype52[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype53[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype54[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype55[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype56[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype57[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype58[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype59[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype60[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype61[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype62[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype63[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype64[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype65[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype66[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype67[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype68[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype69[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype70[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype71[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype72[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype73[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype74[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype75[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype76[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype77[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype78[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype79[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype80[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype81[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype82[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype83[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype84[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype85[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype86[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype87[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype88[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype89[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype90[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype91[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype92[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype93[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype94[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype95[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype96[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype97[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype98[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype99[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype100[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype101[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype102[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype103[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype104[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype105[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype106[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype107[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype108[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype109[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype110[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype111[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype112[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype113[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype114[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype115[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype116[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype117[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype118[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype119[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype120[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype121[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype122[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype123[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype124[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype125[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype126[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype127[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype128[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype129[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype130[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype131[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype132[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype133[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype134[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype135[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype136[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype137[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype138[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype139[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype140[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype141[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype142[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype143[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype144[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype145[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype146[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype147[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype148[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype149[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype150[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype151[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype152[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype153[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype154[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype155[] = {1187,0xFFFF};
static EIF_TYPE_INDEX Y4932_pgtype156[] = {1187,0xFFFF};
EIF_TYPE_INDEX *Y4932_gen_type [692];
EIF_TYPE_INDEX Y4932 [692];
void Y4932_init (void)
{
	egc_routines_types [4932] = Y4932;
	egc_routines_gen_types [4932] = Y4932_gen_type;
	egc_routines_offset [4932] = 623;
	Y4932_gen_type [0] = Y4932_pgtype0;
	Y4932_gen_type [1] = Y4932_pgtype1;
	Y4932_gen_type [2] = Y4932_pgtype2;
	Y4932_gen_type [3] = Y4932_pgtype3;
	Y4932_gen_type [4] = Y4932_pgtype4;
	Y4932_gen_type [5] = Y4932_pgtype5;
	Y4932_gen_type [6] = Y4932_pgtype6;
	Y4932_gen_type [7] = Y4932_pgtype7;
	Y4932_gen_type [8] = Y4932_pgtype8;
	Y4932_gen_type [9] = Y4932_pgtype9;
	Y4932_gen_type [10] = Y4932_pgtype10;
	Y4932_gen_type [11] = Y4932_pgtype11;
	Y4932_gen_type [12] = Y4932_pgtype12;
	Y4932_gen_type [13] = Y4932_pgtype13;
	Y4932_gen_type [14] = Y4932_pgtype14;
	Y4932_gen_type [15] = Y4932_pgtype15;
	Y4932_gen_type [16] = Y4932_pgtype16;
	Y4932_gen_type [17] = Y4932_pgtype17;
	Y4932_gen_type [18] = Y4932_pgtype18;
	Y4932_gen_type [19] = Y4932_pgtype19;
	Y4932_gen_type [20] = Y4932_pgtype20;
	Y4932_gen_type [21] = Y4932_pgtype21;
	Y4932_gen_type [22] = Y4932_pgtype22;
	Y4932_gen_type [23] = Y4932_pgtype23;
	Y4932_gen_type [24] = Y4932_pgtype24;
	Y4932_gen_type [25] = Y4932_pgtype25;
	Y4932_gen_type [26] = Y4932_pgtype26;
	Y4932_gen_type [27] = Y4932_pgtype27;
	Y4932_gen_type [28] = Y4932_pgtype28;
	Y4932_gen_type [29] = Y4932_pgtype29;
	Y4932_gen_type [30] = Y4932_pgtype30;
	Y4932_gen_type [31] = Y4932_pgtype31;
	Y4932_gen_type [32] = Y4932_pgtype32;
	Y4932_gen_type [33] = Y4932_pgtype33;
	Y4932_gen_type [34] = Y4932_pgtype34;
	Y4932_gen_type [35] = Y4932_pgtype35;
	Y4932_gen_type [172] = Y4932_pgtype36;
	Y4932_gen_type [173] = Y4932_pgtype37;
	Y4932_gen_type [174] = Y4932_pgtype38;
	Y4932_gen_type [175] = Y4932_pgtype39;
	Y4932_gen_type [176] = Y4932_pgtype40;
	Y4932_gen_type [177] = Y4932_pgtype41;
	Y4932_gen_type [178] = Y4932_pgtype42;
	Y4932_gen_type [179] = Y4932_pgtype43;
	Y4932_gen_type [180] = Y4932_pgtype44;
	Y4932_gen_type [181] = Y4932_pgtype45;
	Y4932_gen_type [182] = Y4932_pgtype46;
	Y4932_gen_type [183] = Y4932_pgtype47;
	Y4932_gen_type [184] = Y4932_pgtype48;
	Y4932_gen_type [185] = Y4932_pgtype49;
	Y4932_gen_type [186] = Y4932_pgtype50;
	Y4932_gen_type [187] = Y4932_pgtype51;
	Y4932_gen_type [188] = Y4932_pgtype52;
	Y4932_gen_type [189] = Y4932_pgtype53;
	Y4932_gen_type [190] = Y4932_pgtype54;
	Y4932_gen_type [191] = Y4932_pgtype55;
	Y4932_gen_type [192] = Y4932_pgtype56;
	Y4932_gen_type [193] = Y4932_pgtype57;
	Y4932_gen_type [194] = Y4932_pgtype58;
	Y4932_gen_type [195] = Y4932_pgtype59;
	Y4932_gen_type [196] = Y4932_pgtype60;
	Y4932_gen_type [197] = Y4932_pgtype61;
	Y4932_gen_type [198] = Y4932_pgtype62;
	Y4932_gen_type [199] = Y4932_pgtype63;
	Y4932_gen_type [200] = Y4932_pgtype64;
	Y4932_gen_type [201] = Y4932_pgtype65;
	Y4932_gen_type [202] = Y4932_pgtype66;
	Y4932_gen_type [203] = Y4932_pgtype67;
	Y4932_gen_type [204] = Y4932_pgtype68;
	Y4932_gen_type [205] = Y4932_pgtype69;
	Y4932_gen_type [206] = Y4932_pgtype70;
	Y4932_gen_type [207] = Y4932_pgtype71;
	Y4932_gen_type [208] = Y4932_pgtype72;
	Y4932_gen_type [209] = Y4932_pgtype73;
	Y4932_gen_type [210] = Y4932_pgtype74;
	Y4932_gen_type [211] = Y4932_pgtype75;
	Y4932_gen_type [212] = Y4932_pgtype76;
	Y4932_gen_type [213] = Y4932_pgtype77;
	Y4932_gen_type [214] = Y4932_pgtype78;
	Y4932_gen_type [215] = Y4932_pgtype79;
	Y4932_gen_type [216] = Y4932_pgtype80;
	Y4932_gen_type [217] = Y4932_pgtype81;
	Y4932_gen_type [218] = Y4932_pgtype82;
	Y4932_gen_type [219] = Y4932_pgtype83;
	Y4932_gen_type [220] = Y4932_pgtype84;
	Y4932_gen_type [221] = Y4932_pgtype85;
	Y4932_gen_type [222] = Y4932_pgtype86;
	Y4932_gen_type [223] = Y4932_pgtype87;
	Y4932_gen_type [224] = Y4932_pgtype88;
	Y4932_gen_type [225] = Y4932_pgtype89;
	Y4932_gen_type [226] = Y4932_pgtype90;
	Y4932_gen_type [227] = Y4932_pgtype91;
	Y4932_gen_type [228] = Y4932_pgtype92;
	Y4932_gen_type [229] = Y4932_pgtype93;
	Y4932_gen_type [230] = Y4932_pgtype94;
	Y4932_gen_type [231] = Y4932_pgtype95;
	Y4932_gen_type [232] = Y4932_pgtype96;
	Y4932_gen_type [233] = Y4932_pgtype97;
	Y4932_gen_type [234] = Y4932_pgtype98;
	Y4932_gen_type [235] = Y4932_pgtype99;
	Y4932_gen_type [236] = Y4932_pgtype100;
	Y4932_gen_type [237] = Y4932_pgtype101;
	Y4932_gen_type [238] = Y4932_pgtype102;
	Y4932_gen_type [239] = Y4932_pgtype103;
	Y4932_gen_type [240] = Y4932_pgtype104;
	Y4932_gen_type [241] = Y4932_pgtype105;
	Y4932_gen_type [242] = Y4932_pgtype106;
	Y4932_gen_type [243] = Y4932_pgtype107;
	Y4932_gen_type [244] = Y4932_pgtype108;
	Y4932_gen_type [245] = Y4932_pgtype109;
	Y4932_gen_type [246] = Y4932_pgtype110;
	Y4932_gen_type [247] = Y4932_pgtype111;
	Y4932_gen_type [248] = Y4932_pgtype112;
	Y4932_gen_type [249] = Y4932_pgtype113;
	Y4932_gen_type [250] = Y4932_pgtype114;
	Y4932_gen_type [251] = Y4932_pgtype115;
	Y4932_gen_type [252] = Y4932_pgtype116;
	Y4932_gen_type [253] = Y4932_pgtype117;
	Y4932_gen_type [254] = Y4932_pgtype118;
	Y4932_gen_type [255] = Y4932_pgtype119;
	Y4932_gen_type [256] = Y4932_pgtype120;
	Y4932_gen_type [257] = Y4932_pgtype121;
	Y4932_gen_type [258] = Y4932_pgtype122;
	Y4932_gen_type [259] = Y4932_pgtype123;
	Y4932_gen_type [260] = Y4932_pgtype124;
	Y4932_gen_type [261] = Y4932_pgtype125;
	Y4932_gen_type [262] = Y4932_pgtype126;
	Y4932_gen_type [263] = Y4932_pgtype127;
	Y4932_gen_type [264] = Y4932_pgtype128;
	Y4932_gen_type [265] = Y4932_pgtype129;
	Y4932_gen_type [266] = Y4932_pgtype130;
	Y4932_gen_type [267] = Y4932_pgtype131;
	Y4932_gen_type [268] = Y4932_pgtype132;
	Y4932_gen_type [269] = Y4932_pgtype133;
	Y4932_gen_type [270] = Y4932_pgtype134;
	Y4932_gen_type [271] = Y4932_pgtype135;
	Y4932_gen_type [272] = Y4932_pgtype136;
	Y4932_gen_type [273] = Y4932_pgtype137;
	Y4932_gen_type [274] = Y4932_pgtype138;
	Y4932_gen_type [275] = Y4932_pgtype139;
	Y4932_gen_type [276] = Y4932_pgtype140;
	Y4932_gen_type [277] = Y4932_pgtype141;
	Y4932_gen_type [278] = Y4932_pgtype142;
	Y4932_gen_type [279] = Y4932_pgtype143;
	Y4932_gen_type [280] = Y4932_pgtype144;
	Y4932_gen_type [281] = Y4932_pgtype145;
	Y4932_gen_type [282] = Y4932_pgtype146;
	Y4932_gen_type [283] = Y4932_pgtype147;
	Y4932_gen_type [284] = Y4932_pgtype148;
	Y4932_gen_type [285] = Y4932_pgtype149;
	Y4932_gen_type [356] = Y4932_pgtype150;
	Y4932_gen_type [429] = Y4932_pgtype151;
	Y4932_gen_type [430] = Y4932_pgtype152;
	Y4932_gen_type [431] = Y4932_pgtype153;
	Y4932_gen_type [434] = Y4932_pgtype154;
	Y4932_gen_type [690] = Y4932_pgtype155;
	Y4932_gen_type [691] = Y4932_pgtype156;
	Y4932[180] = 1052;
	{long i; for (i = 181; i < 186; i++) Y4932[i] = 1047;};
	{long i; for (i = 186; i < 286; i++) Y4932[i] = 1187;};
	Y4932[356] = 1187;
	{long i; for (i = 429; i < 432; i++) Y4932[i] = 1187;};
	Y4932[434] = 1187;
	{long i; for (i = 690; i < 692; i++) Y4932[i] = 1187;};
}

char *(*R4934[574])();
void R4934_init () {
	{long i; for (i = 0; i < 2; i++) R4934[i] = (char *(*)()) F703_5532_4934_1;}
	R4934[41] = (char *(*)()) F745_5602;
	{long i; for (i = 69; i < 71; i++) R4934[i] = (char *(*)()) F772_5658_4934_1;}
	R4934[184] = (char *(*)()) F888_6294;
	R4934[185] = (char *(*)()) F889_6294_4934_1;
	R4934[186] = (char *(*)()) F890_6339;
	R4934[187] = (char *(*)()) F891_6339_4934_1;
	R4934[188] = (char *(*)()) F888_6294;
	R4934[189] = (char *(*)()) F893_6367;
	R4934[190] = (char *(*)()) F894_6367_4934_1;
	R4934[191] = (char *(*)()) F895_6367_4934_1;
	R4934[192] = (char *(*)()) F896_6367_4934_1;
	R4934[193] = (char *(*)()) F897_6367_4934_1;
	R4934[194] = (char *(*)()) F898_6367_4934_1;
	R4934[195] = (char *(*)()) F899_6367_4934_1;
	R4934[196] = (char *(*)()) F900_6367_4934_1;
	R4934[197] = (char *(*)()) F901_6367_4934_1;
	R4934[198] = (char *(*)()) F902_6367_4934_1;
	R4934[199] = (char *(*)()) F903_6367_4934_1;
	R4934[200] = (char *(*)()) F904_6367_4934_1;
	{long i; for (i = 201; i < 203; i++) R4934[i] = (char *(*)()) F893_6367;}
	R4934[203] = (char *(*)()) F894_6367_4934_1;
	{long i; for (i = 204; i < 206; i++) R4934[i] = (char *(*)()) F893_6367;}
	R4934[276] = (char *(*)()) F893_6367;
	R4934[521] = (char *(*)()) F772_5658_4934_1;
	R4934[573] = (char *(*)()) F772_5658_4934_1;
}
static EIF_REFERENCE F703_5532_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F703_5532(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F772_5658_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F772_5658(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F889_6294_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F889_6294(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F891_6339_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F891_6339(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_6367_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F894_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_6367_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F895_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1007, 0x00).id, 1007, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_6367_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F896_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1040, 0x00).id, 1040, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F897_6367_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F897_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_6367_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F898_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1196, 0x00).id, 1196, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F899_6367_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F899_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F900_6367_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F900_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1001, 0x00).id, 1001, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F901_6367_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F901_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F902_6367_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F902_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F903_6367_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F903_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F904_6367_4934_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F904_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y4934_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4934_pgtype111[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y4934_gen_type [618];
EIF_TYPE_INDEX Y4934 [618];
void Y4934_init (void)
{
	egc_routines_types [4934] = Y4934;
	egc_routines_gen_types [4934] = Y4934_gen_type;
	egc_routines_offset [4934] = 659;
	Y4934_gen_type [0] = Y4934_pgtype0;
	Y4934_gen_type [1] = Y4934_pgtype1;
	Y4934_gen_type [2] = Y4934_pgtype2;
	Y4934_gen_type [3] = Y4934_pgtype3;
	Y4934_gen_type [4] = Y4934_pgtype4;
	Y4934_gen_type [5] = Y4934_pgtype5;
	Y4934_gen_type [6] = Y4934_pgtype6;
	Y4934_gen_type [7] = Y4934_pgtype7;
	Y4934_gen_type [8] = Y4934_pgtype8;
	Y4934_gen_type [9] = Y4934_pgtype9;
	Y4934_gen_type [10] = Y4934_pgtype10;
	Y4934_gen_type [11] = Y4934_pgtype11;
	Y4934_gen_type [12] = Y4934_pgtype12;
	Y4934_gen_type [13] = Y4934_pgtype13;
	Y4934_gen_type [14] = Y4934_pgtype14;
	Y4934_gen_type [15] = Y4934_pgtype15;
	Y4934_gen_type [16] = Y4934_pgtype16;
	Y4934_gen_type [17] = Y4934_pgtype17;
	Y4934_gen_type [18] = Y4934_pgtype18;
	Y4934_gen_type [19] = Y4934_pgtype19;
	Y4934_gen_type [20] = Y4934_pgtype20;
	Y4934_gen_type [21] = Y4934_pgtype21;
	Y4934_gen_type [22] = Y4934_pgtype22;
	Y4934_gen_type [23] = Y4934_pgtype23;
	Y4934_gen_type [43] = Y4934_pgtype24;
	Y4934_gen_type [82] = Y4934_pgtype25;
	Y4934_gen_type [83] = Y4934_pgtype26;
	Y4934_gen_type [84] = Y4934_pgtype27;
	Y4934_gen_type [85] = Y4934_pgtype28;
	Y4934_gen_type [86] = Y4934_pgtype29;
	Y4934_gen_type [87] = Y4934_pgtype30;
	Y4934_gen_type [88] = Y4934_pgtype31;
	Y4934_gen_type [89] = Y4934_pgtype32;
	Y4934_gen_type [90] = Y4934_pgtype33;
	Y4934_gen_type [91] = Y4934_pgtype34;
	Y4934_gen_type [92] = Y4934_pgtype35;
	Y4934_gen_type [93] = Y4934_pgtype36;
	Y4934_gen_type [94] = Y4934_pgtype37;
	Y4934_gen_type [95] = Y4934_pgtype38;
	Y4934_gen_type [96] = Y4934_pgtype39;
	Y4934_gen_type [97] = Y4934_pgtype40;
	Y4934_gen_type [98] = Y4934_pgtype41;
	Y4934_gen_type [99] = Y4934_pgtype42;
	Y4934_gen_type [180] = Y4934_pgtype43;
	Y4934_gen_type [181] = Y4934_pgtype44;
	Y4934_gen_type [182] = Y4934_pgtype45;
	Y4934_gen_type [183] = Y4934_pgtype46;
	Y4934_gen_type [184] = Y4934_pgtype47;
	Y4934_gen_type [185] = Y4934_pgtype48;
	Y4934_gen_type [186] = Y4934_pgtype49;
	Y4934_gen_type [187] = Y4934_pgtype50;
	Y4934_gen_type [188] = Y4934_pgtype51;
	Y4934_gen_type [189] = Y4934_pgtype52;
	Y4934_gen_type [190] = Y4934_pgtype53;
	Y4934_gen_type [191] = Y4934_pgtype54;
	Y4934_gen_type [192] = Y4934_pgtype55;
	Y4934_gen_type [193] = Y4934_pgtype56;
	Y4934_gen_type [194] = Y4934_pgtype57;
	Y4934_gen_type [195] = Y4934_pgtype58;
	Y4934_gen_type [196] = Y4934_pgtype59;
	Y4934_gen_type [197] = Y4934_pgtype60;
	Y4934_gen_type [198] = Y4934_pgtype61;
	Y4934_gen_type [199] = Y4934_pgtype62;
	Y4934_gen_type [200] = Y4934_pgtype63;
	Y4934_gen_type [201] = Y4934_pgtype64;
	Y4934_gen_type [202] = Y4934_pgtype65;
	Y4934_gen_type [203] = Y4934_pgtype66;
	Y4934_gen_type [204] = Y4934_pgtype67;
	Y4934_gen_type [205] = Y4934_pgtype68;
	Y4934_gen_type [206] = Y4934_pgtype69;
	Y4934_gen_type [207] = Y4934_pgtype70;
	Y4934_gen_type [208] = Y4934_pgtype71;
	Y4934_gen_type [209] = Y4934_pgtype72;
	Y4934_gen_type [210] = Y4934_pgtype73;
	Y4934_gen_type [211] = Y4934_pgtype74;
	Y4934_gen_type [212] = Y4934_pgtype75;
	Y4934_gen_type [213] = Y4934_pgtype76;
	Y4934_gen_type [214] = Y4934_pgtype77;
	Y4934_gen_type [215] = Y4934_pgtype78;
	Y4934_gen_type [216] = Y4934_pgtype79;
	Y4934_gen_type [217] = Y4934_pgtype80;
	Y4934_gen_type [218] = Y4934_pgtype81;
	Y4934_gen_type [219] = Y4934_pgtype82;
	Y4934_gen_type [220] = Y4934_pgtype83;
	Y4934_gen_type [221] = Y4934_pgtype84;
	Y4934_gen_type [222] = Y4934_pgtype85;
	Y4934_gen_type [223] = Y4934_pgtype86;
	Y4934_gen_type [224] = Y4934_pgtype87;
	Y4934_gen_type [225] = Y4934_pgtype88;
	Y4934_gen_type [226] = Y4934_pgtype89;
	Y4934_gen_type [227] = Y4934_pgtype90;
	Y4934_gen_type [228] = Y4934_pgtype91;
	Y4934_gen_type [229] = Y4934_pgtype92;
	Y4934_gen_type [230] = Y4934_pgtype93;
	Y4934_gen_type [231] = Y4934_pgtype94;
	Y4934_gen_type [232] = Y4934_pgtype95;
	Y4934_gen_type [233] = Y4934_pgtype96;
	Y4934_gen_type [234] = Y4934_pgtype97;
	Y4934_gen_type [235] = Y4934_pgtype98;
	Y4934_gen_type [236] = Y4934_pgtype99;
	Y4934_gen_type [237] = Y4934_pgtype100;
	Y4934_gen_type [238] = Y4934_pgtype101;
	Y4934_gen_type [239] = Y4934_pgtype102;
	Y4934_gen_type [240] = Y4934_pgtype103;
	Y4934_gen_type [241] = Y4934_pgtype104;
	Y4934_gen_type [242] = Y4934_pgtype105;
	Y4934_gen_type [243] = Y4934_pgtype106;
	Y4934_gen_type [244] = Y4934_pgtype107;
	Y4934_gen_type [245] = Y4934_pgtype108;
	Y4934_gen_type [246] = Y4934_pgtype109;
	Y4934_gen_type [247] = Y4934_pgtype110;
	Y4934_gen_type [320] = Y4934_pgtype111;
	{long i; for (i = 44; i < 46; i++) Y4934[i] = 1187;};
	{long i; for (i = 112; i < 115; i++) Y4934[i] = 1004;};
	Y4934[248] = 1261;
	Y4934[249] = 908;
	Y4934[565] = 1004;
	{long i; for (i = 609; i < 612; i++) Y4934[i] = 1004;};
	{long i; for (i = 613; i < 618; i++) Y4934[i] = 1004;};
}

char *(*R4938[93])();
void R4938_init () {
	R4938[0] = (char *(*)()) F888_6322;
	R4938[1] = (char *(*)()) F889_6322_4938_4;
	R4938[2] = (char *(*)()) F888_6322;
	R4938[3] = (char *(*)()) F889_6322_4938_4;
	R4938[4] = (char *(*)()) F888_6322;
	R4938[5] = (char *(*)()) F893_6406;
	R4938[6] = (char *(*)()) F894_6406_4938_4;
	R4938[7] = (char *(*)()) F895_6406_4938_4;
	R4938[8] = (char *(*)()) F896_6406_4938_4;
	R4938[9] = (char *(*)()) F897_6406_4938_4;
	R4938[10] = (char *(*)()) F898_6406_4938_4;
	R4938[11] = (char *(*)()) F899_6406_4938_4;
	R4938[12] = (char *(*)()) F900_6406_4938_4;
	R4938[13] = (char *(*)()) F901_6406_4938_4;
	R4938[14] = (char *(*)()) F902_6406_4938_4;
	R4938[15] = (char *(*)()) F903_6406_4938_4;
	R4938[16] = (char *(*)()) F904_6406_4938_4;
	{long i; for (i = 17; i < 19; i++) R4938[i] = (char *(*)()) F893_6406;}
	R4938[19] = (char *(*)()) F894_6406_4938_4;
	{long i; for (i = 20; i < 22; i++) R4938[i] = (char *(*)()) F893_6406;}
	R4938[92] = (char *(*)()) F893_6406;
}
static void F889_6322_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F889_6322(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F894_6406_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F894_6406(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F895_6406_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F895_6406(Current, *(EIF_BOOLEAN *)arg1);
}
static void F896_6406_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F896_6406(Current, *(EIF_POINTER *)arg1);
}
static void F897_6406_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F897_6406(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F898_6406_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F898_6406(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F899_6406_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F899_6406(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F900_6406_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F900_6406(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F901_6406_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F901_6406(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F902_6406_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F902_6406(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F903_6406_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F903_6406(Current, *(EIF_REAL_32 *)arg1);
}
static void F904_6406_4938_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F904_6406(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R4939[236])();
void R4939_init () {
	R4939[0] = (char *(*)()) F745_5619;
	R4939[143] = (char *(*)()) F888_6325;
	R4939[144] = (char *(*)()) F889_6325;
	R4939[145] = (char *(*)()) F890_6343;
	R4939[146] = (char *(*)()) F891_6343;
	R4939[147] = (char *(*)()) F888_6325;
	R4939[148] = (char *(*)()) F893_6416;
	R4939[149] = (char *(*)()) F894_6416;
	R4939[150] = (char *(*)()) F895_6416;
	R4939[151] = (char *(*)()) F896_6416;
	R4939[152] = (char *(*)()) F897_6416;
	R4939[153] = (char *(*)()) F898_6416;
	R4939[154] = (char *(*)()) F899_6416;
	R4939[155] = (char *(*)()) F900_6416;
	R4939[156] = (char *(*)()) F901_6416;
	R4939[157] = (char *(*)()) F902_6416;
	R4939[158] = (char *(*)()) F903_6416;
	R4939[159] = (char *(*)()) F904_6416;
	R4939[160] = (char *(*)()) F893_6416;
	R4939[161] = (char *(*)()) F906_6442;
	R4939[162] = (char *(*)()) F907_6442;
	{long i; for (i = 163; i < 165; i++) R4939[i] = (char *(*)()) F893_6416;}
	R4939[235] = (char *(*)()) F893_6416;
}

char *(*R4940[93])();
void R4940_init () {
	R4940[0] = (char *(*)()) F888_6298;
	R4940[1] = (char *(*)()) F889_6298;
	R4940[2] = (char *(*)()) F888_6298;
	R4940[3] = (char *(*)()) F889_6298;
	R4940[4] = (char *(*)()) F888_6298;
	R4940[5] = (char *(*)()) F893_6373;
	R4940[6] = (char *(*)()) F894_6373;
	R4940[7] = (char *(*)()) F895_6373;
	R4940[8] = (char *(*)()) F896_6373;
	R4940[9] = (char *(*)()) F897_6373;
	R4940[10] = (char *(*)()) F898_6373;
	R4940[11] = (char *(*)()) F899_6373;
	R4940[12] = (char *(*)()) F900_6373;
	R4940[13] = (char *(*)()) F901_6373;
	R4940[14] = (char *(*)()) F902_6373;
	R4940[15] = (char *(*)()) F903_6373;
	R4940[16] = (char *(*)()) F904_6373;
	{long i; for (i = 17; i < 19; i++) R4940[i] = (char *(*)()) F893_6373;}
	R4940[19] = (char *(*)()) F894_6373;
	{long i; for (i = 20; i < 22; i++) R4940[i] = (char *(*)()) F893_6373;}
	R4940[92] = (char *(*)()) F893_6373;
}

static EIF_TYPE_INDEX Y4940_pgtype0[] = {281,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4940_pgtype1[] = {282,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4940_pgtype2[] = {281,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4940_pgtype3[] = {282,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4940_pgtype4[] = {281,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y4940_gen_type [309];
EIF_TYPE_INDEX Y4940 [309];
void Y4940_init (void)
{
	egc_routines_types [4940] = Y4940;
	egc_routines_gen_types [4940] = Y4940_gen_type;
	egc_routines_offset [4940] = 671;
	Y4940_gen_type [216] = Y4940_pgtype0;
	Y4940_gen_type [217] = Y4940_pgtype1;
	Y4940_gen_type [218] = Y4940_pgtype2;
	Y4940_gen_type [219] = Y4940_pgtype3;
	Y4940_gen_type [220] = Y4940_pgtype4;
	{long i; for (i = 0; i < 12; i++) Y4940[i] = 280;};
	{long i; for (i = 168; i < 216; i++) Y4940[i] = 280;};
	Y4940[216] = 281;
	Y4940[217] = 282;
	Y4940[218] = 281;
	Y4940[219] = 282;
	Y4940[220] = 281;
	{long i; for (i = 221; i < 238; i++) Y4940[i] = 284;};
	Y4940[308] = 284;
}

char *(*R4942[93])();
void R4942_init () {
	R4942[0] = (char *(*)()) F888_6317;
	R4942[1] = (char *(*)()) F889_6317;
	R4942[2] = (char *(*)()) F888_6317;
	R4942[3] = (char *(*)()) F889_6317;
	R4942[4] = (char *(*)()) F888_6317;
	R4942[5] = (char *(*)()) F893_6398;
	R4942[6] = (char *(*)()) F894_6398;
	R4942[7] = (char *(*)()) F895_6398;
	R4942[8] = (char *(*)()) F896_6398;
	R4942[9] = (char *(*)()) F897_6398;
	R4942[10] = (char *(*)()) F898_6398;
	R4942[11] = (char *(*)()) F899_6398;
	R4942[12] = (char *(*)()) F900_6398;
	R4942[13] = (char *(*)()) F901_6398;
	R4942[14] = (char *(*)()) F902_6398;
	R4942[15] = (char *(*)()) F903_6398;
	R4942[16] = (char *(*)()) F904_6398;
	{long i; for (i = 17; i < 19; i++) R4942[i] = (char *(*)()) F893_6398;}
	R4942[19] = (char *(*)()) F894_6398;
	{long i; for (i = 20; i < 22; i++) R4942[i] = (char *(*)()) F893_6398;}
	R4942[92] = (char *(*)()) F893_6398;
}

char *(*R4968[2])();
void R4968_init () {
	R4968[0] = (char *(*)()) F704_5558;
	R4968[1] = (char *(*)()) F705_5577;
}

char *(*R4997[570])();
void R4997_init () {
	R4997[0] = (char *(*)()) F745_5606;
	{long i; for (i = 28; i < 30; i++) R4997[i] = (char *(*)()) F772_5676;}
	R4997[51] = (char *(*)()) F796_6030;
	R4997[52] = (char *(*)()) F797_6030;
	R4997[53] = (char *(*)()) F798_6030;
	R4997[54] = (char *(*)()) F799_6030;
	R4997[55] = (char *(*)()) F800_6030;
	R4997[56] = (char *(*)()) F801_6030;
	R4997[57] = (char *(*)()) F802_6030;
	R4997[58] = (char *(*)()) F803_6030;
	{long i; for (i = 59; i < 61; i++) R4997[i] = (char *(*)()) F796_6030;}
	R4997[61] = (char *(*)()) F800_6030;
	R4997[62] = (char *(*)()) F799_6030;
	R4997[63] = (char *(*)()) F801_6030;
	R4997[64] = (char *(*)()) F803_6030;
	R4997[77] = (char *(*)()) F822_6155;
	R4997[78] = (char *(*)()) F823_6195;
	R4997[79] = (char *(*)()) F824_6195;
	R4997[80] = (char *(*)()) F825_6195;
	R4997[81] = (char *(*)()) F826_6195;
	R4997[82] = (char *(*)()) F827_6195;
	R4997[83] = (char *(*)()) F828_6195;
	R4997[84] = (char *(*)()) F829_6195;
	R4997[85] = (char *(*)()) F830_6195;
	R4997[86] = (char *(*)()) F831_6195;
	R4997[87] = (char *(*)()) F832_6195;
	R4997[88] = (char *(*)()) F833_6195;
	R4997[89] = (char *(*)()) F834_6195;
	R4997[143] = (char *(*)()) F888_6301;
	R4997[144] = (char *(*)()) F889_6301;
	R4997[145] = (char *(*)()) F888_6301;
	R4997[146] = (char *(*)()) F889_6301;
	R4997[147] = (char *(*)()) F888_6301;
	R4997[148] = (char *(*)()) F893_6383;
	R4997[149] = (char *(*)()) F894_6383;
	R4997[150] = (char *(*)()) F895_6383;
	R4997[151] = (char *(*)()) F896_6383;
	R4997[152] = (char *(*)()) F897_6383;
	R4997[153] = (char *(*)()) F898_6383;
	R4997[154] = (char *(*)()) F899_6383;
	R4997[155] = (char *(*)()) F900_6383;
	R4997[156] = (char *(*)()) F901_6383;
	R4997[157] = (char *(*)()) F902_6383;
	R4997[158] = (char *(*)()) F903_6383;
	R4997[159] = (char *(*)()) F904_6383;
	{long i; for (i = 160; i < 162; i++) R4997[i] = (char *(*)()) F893_6383;}
	R4997[162] = (char *(*)()) F894_6383;
	{long i; for (i = 163; i < 165; i++) R4997[i] = (char *(*)()) F893_6383;}
	R4997[235] = (char *(*)()) F893_6383;
	{long i; for (i = 308; i < 310; i++) R4997[i] = (char *(*)()) F1051_7837;}
	R4997[313] = (char *(*)()) F1056_8005;
	R4997[480] = (char *(*)()) F1225_10128;
	R4997[532] = (char *(*)()) F772_5676;
	R4997[569] = (char *(*)()) F1314_13102;
}

char *(*R4998[570])();
void R4998_init () {
	R4998[0] = (char *(*)()) F745_5607;
	R4998[77] = (char *(*)()) F822_6154;
	R4998[78] = (char *(*)()) F823_6196;
	R4998[79] = (char *(*)()) F824_6196;
	R4998[80] = (char *(*)()) F825_6196;
	R4998[81] = (char *(*)()) F826_6196;
	R4998[82] = (char *(*)()) F827_6196;
	R4998[83] = (char *(*)()) F828_6196;
	R4998[84] = (char *(*)()) F829_6196;
	R4998[85] = (char *(*)()) F830_6196;
	R4998[86] = (char *(*)()) F831_6196;
	R4998[87] = (char *(*)()) F832_6196;
	R4998[88] = (char *(*)()) F833_6196;
	R4998[89] = (char *(*)()) F834_6196;
	R4998[148] = (char *(*)()) F893_6384;
	R4998[149] = (char *(*)()) F894_6384;
	R4998[150] = (char *(*)()) F895_6384;
	R4998[151] = (char *(*)()) F896_6384;
	R4998[152] = (char *(*)()) F897_6384;
	R4998[153] = (char *(*)()) F898_6384;
	R4998[154] = (char *(*)()) F899_6384;
	R4998[155] = (char *(*)()) F900_6384;
	R4998[156] = (char *(*)()) F901_6384;
	R4998[157] = (char *(*)()) F902_6384;
	R4998[158] = (char *(*)()) F903_6384;
	R4998[159] = (char *(*)()) F904_6384;
	{long i; for (i = 160; i < 162; i++) R4998[i] = (char *(*)()) F893_6384;}
	R4998[162] = (char *(*)()) F894_6384;
	{long i; for (i = 163; i < 165; i++) R4998[i] = (char *(*)()) F893_6384;}
	R4998[235] = (char *(*)()) F893_6384;
	{long i; for (i = 308; i < 310; i++) R4998[i] = (char *(*)()) F1051_7836;}
	R4998[313] = (char *(*)()) F1056_8004;
	R4998[569] = (char *(*)()) F1314_13104;
}

char *(*R5002[570])();
void R5002_init () {
	R5002[0] = (char *(*)()) F730_5589;
	R5002[77] = (char *(*)()) F731_5589;
	R5002[78] = (char *(*)()) F730_5589;
	R5002[79] = (char *(*)()) F731_5589;
	R5002[80] = (char *(*)()) F732_5589;
	R5002[81] = (char *(*)()) F733_5589;
	R5002[82] = (char *(*)()) F734_5589;
	R5002[83] = (char *(*)()) F735_5589;
	R5002[84] = (char *(*)()) F736_5589;
	R5002[85] = (char *(*)()) F737_5589;
	R5002[86] = (char *(*)()) F738_5589;
	R5002[87] = (char *(*)()) F739_5589;
	R5002[88] = (char *(*)()) F740_5589;
	R5002[89] = (char *(*)()) F741_5589;
	R5002[148] = (char *(*)()) F730_5589;
	R5002[149] = (char *(*)()) F731_5589;
	R5002[150] = (char *(*)()) F732_5589;
	R5002[151] = (char *(*)()) F733_5589;
	R5002[152] = (char *(*)()) F734_5589;
	R5002[153] = (char *(*)()) F735_5589;
	R5002[154] = (char *(*)()) F736_5589;
	R5002[155] = (char *(*)()) F737_5589;
	R5002[156] = (char *(*)()) F738_5589;
	R5002[157] = (char *(*)()) F739_5589;
	R5002[158] = (char *(*)()) F740_5589;
	R5002[159] = (char *(*)()) F741_5589;
	{long i; for (i = 160; i < 162; i++) R5002[i] = (char *(*)()) F730_5589;}
	R5002[162] = (char *(*)()) F731_5589;
	{long i; for (i = 163; i < 165; i++) R5002[i] = (char *(*)()) F730_5589;}
	R5002[235] = (char *(*)()) F730_5589;
	{long i; for (i = 308; i < 310; i++) R5002[i] = (char *(*)()) F734_5589;}
	R5002[313] = (char *(*)()) F737_5589;
	R5002[569] = (char *(*)()) F734_5589;
}

char *(*R5004[570])();
void R5004_init () {
	R5004[0] = (char *(*)()) F745_5629;
	R5004[77] = (char *(*)()) F822_6165;
	R5004[78] = (char *(*)()) F823_6226;
	R5004[79] = (char *(*)()) F824_6226;
	R5004[80] = (char *(*)()) F825_6226;
	R5004[81] = (char *(*)()) F826_6226;
	R5004[82] = (char *(*)()) F827_6226;
	R5004[83] = (char *(*)()) F828_6226;
	R5004[84] = (char *(*)()) F829_6226;
	R5004[85] = (char *(*)()) F830_6226;
	R5004[86] = (char *(*)()) F831_6226;
	R5004[87] = (char *(*)()) F832_6226;
	R5004[88] = (char *(*)()) F833_6226;
	R5004[89] = (char *(*)()) F834_6226;
	R5004[148] = (char *(*)()) F893_6410;
	R5004[149] = (char *(*)()) F894_6410;
	R5004[150] = (char *(*)()) F895_6410;
	R5004[151] = (char *(*)()) F896_6410;
	R5004[152] = (char *(*)()) F897_6410;
	R5004[153] = (char *(*)()) F898_6410;
	R5004[154] = (char *(*)()) F899_6410;
	R5004[155] = (char *(*)()) F900_6410;
	R5004[156] = (char *(*)()) F901_6410;
	R5004[157] = (char *(*)()) F902_6410;
	R5004[158] = (char *(*)()) F903_6410;
	R5004[159] = (char *(*)()) F904_6410;
	{long i; for (i = 160; i < 162; i++) R5004[i] = (char *(*)()) F893_6410;}
	R5004[162] = (char *(*)()) F894_6410;
	{long i; for (i = 163; i < 165; i++) R5004[i] = (char *(*)()) F893_6410;}
	R5004[235] = (char *(*)()) F893_6410;
	{long i; for (i = 308; i < 310; i++) R5004[i] = (char *(*)()) F1053_7961;}
	R5004[313] = (char *(*)()) F1058_8132;
	R5004[569] = (char *(*)()) F1053_7961;
}

char *(*R5018[505])();
void R5018_init () {
	{long i; for (i = 0; i < 2; i++) R5018[i] = (char *(*)()) F752_5640_5018_4;}
	R5018[115] = (char *(*)()) F748_5640;
	R5018[116] = (char *(*)()) F749_5640_5018_4;
	R5018[117] = (char *(*)()) F890_6340;
	R5018[118] = (char *(*)()) F891_6340_5018_4;
	R5018[119] = (char *(*)()) F748_5640;
	R5018[120] = (char *(*)()) F893_6402;
	R5018[121] = (char *(*)()) F894_6402_5018_4;
	R5018[122] = (char *(*)()) F895_6402_5018_4;
	R5018[123] = (char *(*)()) F896_6402_5018_4;
	R5018[124] = (char *(*)()) F897_6402_5018_4;
	R5018[125] = (char *(*)()) F898_6402_5018_4;
	R5018[126] = (char *(*)()) F899_6402_5018_4;
	R5018[127] = (char *(*)()) F900_6402_5018_4;
	R5018[128] = (char *(*)()) F901_6402_5018_4;
	R5018[129] = (char *(*)()) F902_6402_5018_4;
	R5018[130] = (char *(*)()) F903_6402_5018_4;
	R5018[131] = (char *(*)()) F904_6402_5018_4;
	{long i; for (i = 132; i < 134; i++) R5018[i] = (char *(*)()) F893_6402;}
	R5018[134] = (char *(*)()) F894_6402_5018_4;
	{long i; for (i = 135; i < 137; i++) R5018[i] = (char *(*)()) F893_6402;}
	R5018[207] = (char *(*)()) F893_6402;
	R5018[452] = (char *(*)()) F752_5640_5018_4;
	R5018[504] = (char *(*)()) F752_5640_5018_4;
}
static void F752_5640_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F752_5640(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F749_5640_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F749_5640(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F891_6340_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F891_6340(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F894_6402_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F894_6402(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F895_6402_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F895_6402(Current, *(EIF_BOOLEAN *)arg1);
}
static void F896_6402_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F896_6402(Current, *(EIF_POINTER *)arg1);
}
static void F897_6402_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F897_6402(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F898_6402_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F898_6402(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F899_6402_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F899_6402(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F900_6402_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F900_6402(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F901_6402_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F901_6402(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F902_6402_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F902_6402(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F903_6402_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F903_6402(Current, *(EIF_REAL_32 *)arg1);
}
static void F904_6402_5018_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F904_6402(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R5019[93])();
void R5019_init () {
	R5019[0] = (char *(*)()) F840_6261;
	R5019[1] = (char *(*)()) F841_6261;
	R5019[2] = (char *(*)()) F742_5596;
	R5019[3] = (char *(*)()) F743_5596;
	R5019[4] = (char *(*)()) F840_6261;
	R5019[5] = (char *(*)()) F893_6409;
	R5019[6] = (char *(*)()) F894_6409;
	R5019[7] = (char *(*)()) F895_6409;
	R5019[8] = (char *(*)()) F896_6409;
	R5019[9] = (char *(*)()) F897_6409;
	R5019[10] = (char *(*)()) F898_6409;
	R5019[11] = (char *(*)()) F899_6409;
	R5019[12] = (char *(*)()) F900_6409;
	R5019[13] = (char *(*)()) F901_6409;
	R5019[14] = (char *(*)()) F902_6409;
	R5019[15] = (char *(*)()) F903_6409;
	R5019[16] = (char *(*)()) F904_6409;
	R5019[17] = (char *(*)()) F893_6409;
	R5019[18] = (char *(*)()) F742_5596;
	R5019[19] = (char *(*)()) F743_5596;
	{long i; for (i = 20; i < 22; i++) R5019[i] = (char *(*)()) F893_6409;}
	R5019[92] = (char *(*)()) F893_6409;
}

char *(*R5046[505])();
void R5046_init () {
	{long i; for (i = 0; i < 2; i++) R5046[i] = (char *(*)()) F772_5680;}
	R5046[452] = (char *(*)()) F1225_10126;
	R5046[504] = (char *(*)()) F772_5680;
}

char *(*R5066[505])();
void R5066_init () {
	{long i; for (i = 0; i < 2; i++) R5066[i] = (char *(*)()) F772_5704;}
	R5066[452] = (char *(*)()) F772_5704;
	R5066[504] = (char *(*)()) F1272_11672;
}

char *(*R5071[505])();
void R5071_init () {
	{long i; for (i = 0; i < 2; i++) R5071[i] = (char *(*)()) F772_5716;}
	R5071[452] = (char *(*)()) F772_5716;
	R5071[504] = (char *(*)()) F1274_11689;
}

char *(*R5115[505])();
void R5115_init () {
	R5115[0] = (char *(*)()) F773_5921;
	R5115[1] = (char *(*)()) F772_5804;
	R5115[452] = (char *(*)()) F772_5804;
	R5115[504] = (char *(*)()) F773_5921;
}

char *(*R5116[505])();
void R5116_init () {
	{long i; for (i = 0; i < 2; i++) R5116[i] = (char *(*)()) F772_5805;}
	R5116[452] = (char *(*)()) F1225_10182;
	R5116[504] = (char *(*)()) F772_5805;
}

char *(*R5199[452])();
void R5199_init () {
	R5199[0] = (char *(*)()) F774_5973;
	R5199[451] = (char *(*)()) F1225_10124;
}

char *(*R5205[452])();
void R5205_init () {
	R5205[0] = (char *(*)()) F774_5979;
	R5205[451] = (char *(*)()) F1225_10162;
}


#ifdef __cplusplus
}
#endif
