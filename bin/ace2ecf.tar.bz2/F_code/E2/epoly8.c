#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

EIF_TYPE_INDEX *Y5017_gen_type [1];
EIF_TYPE_INDEX Y5017 [1];
void Y5017_init (void)
{
	egc_routines_types [5017] = Y5017;
	egc_routines_gen_types [5017] = Y5017_gen_type;
	egc_routines_offset [5017] = 744;
	Y5017[0] = 1187;
}

long O5034[506];
void O5034_init () {
	O5034[0] = + _PTROFF_3_6_2_4_1_0_;
	O5034[1] = + _PTROFF_4_6_2_4_1_0_;
	O5034[2] = + _PTROFF_5_7_2_4_1_0_;
	O5034[453] = + _PTROFF_5_7_2_4_1_0_;
	{long i; for (i = 497; i < 500; i++) O5034[i] = + _PTROFF_5_6_2_4_1_0_;}
	O5034[501] = + _PTROFF_7_8_2_4_1_0_;
	{long i; for (i = 502; i < 506; i++) O5034[i] = + _PTROFF_6_7_2_4_1_0_;}
}

long O5117[506];
void O5117_init () {
	{long i; for (i = 0; i < 3; i++) O5117[i] =  + _REFACS_1_;}
	O5117[453] =  + _REFACS_1_;
	{long i; for (i = 497; i < 500; i++) O5117[i] =  + _REFACS_1_;}
	{long i; for (i = 501; i < 506; i++) O5117[i] = 0;}
}

long O5119[506];
void O5119_init () {
	{long i; for (i = 0; i < 3; i++) O5119[i] =  + _REFACS_2_;}
	O5119[453] =  + _REFACS_2_;
	{long i; for (i = 497; i < 500; i++) O5119[i] =  + _REFACS_2_;}
	{long i; for (i = 501; i < 506; i++) O5119[i] =  + _REFACS_1_;}
}

long O5173[506];
void O5173_init () {
	O5173[0] = + _LNGOFF_3_6_2_3_;
	O5173[1] = + _LNGOFF_4_6_2_3_;
	O5173[2] = + _LNGOFF_5_7_2_3_;
	O5173[453] = + _LNGOFF_5_7_2_3_;
	{long i; for (i = 497; i < 500; i++) O5173[i] = + _LNGOFF_5_6_2_3_;}
	O5173[501] = + _LNGOFF_7_8_2_3_;
	{long i; for (i = 502; i < 506; i++) O5173[i] = + _LNGOFF_6_7_2_3_;}
}

long O5182[506];
void O5182_init () {
	O5182[0] = + _CHROFF_3_3_;
	O5182[1] = + _CHROFF_4_3_;
	O5182[2] = + _CHROFF_5_3_;
	O5182[453] = + _CHROFF_5_3_;
	{long i; for (i = 497; i < 500; i++) O5182[i] = + _CHROFF_5_3_;}
	O5182[501] = + _CHROFF_7_3_;
	{long i; for (i = 502; i < 506; i++) O5182[i] = + _CHROFF_6_3_;}
}

long O5187[505];
void O5187_init () {
	O5187[0] =  + _REFACS_3_;
	{long i; for (i = 496; i < 499; i++) O5187[i] =  + _REFACS_3_;}
	{long i; for (i = 501; i < 505; i++) O5187[i] =  + _REFACS_2_;}
}

long O5240[14];
void O5240_init () {
	{long i; for (i = 0; i < 2; i++) O5240[i] = 0;}
	O5240[2] = + _PTROFF_5_3_0_7_0_0_;
	{long i; for (i = 3; i < 5; i++) O5240[i] = + _LNGOFF_5_3_0_0_;}
	O5240[5] = + _CHROFF_5_1_;
	O5240[6] = + _LNGOFF_4_3_0_0_;
	O5240[7] = + _CHROFF_5_3_;
	{long i; for (i = 8; i < 10; i++) O5240[i] = 0;}
	{long i; for (i = 10; i < 12; i++) O5240[i] = + _LNGOFF_5_4_0_0_;}
	O5240[12] = + _CHROFF_5_1_;
	O5240[13] = + _CHROFF_5_4_;
}

long O5249[14];
void O5249_init () {
	O5249[0] = + _LNGOFF_7_3_0_0_;
	O5249[1] = + _LNGOFF_6_3_0_0_;
	O5249[2] = + _LNGOFF_5_3_0_0_;
	O5249[3] = + _LNGOFF_5_3_0_1_;
	O5249[4] = + _LNGOFF_5_3_0_2_;
	O5249[5] = + _LNGOFF_5_5_0_0_;
	O5249[6] = + _LNGOFF_4_3_0_1_;
	O5249[7] = + _LNGOFF_5_5_0_0_;
	O5249[8] = + _LNGOFF_9_3_0_0_;
	O5249[9] = + _LNGOFF_7_4_0_0_;
	O5249[10] = + _LNGOFF_5_4_0_2_;
	O5249[11] = + _LNGOFF_5_4_0_1_;
	{long i; for (i = 12; i < 14; i++) O5249[i] = + _LNGOFF_5_6_0_0_;}
}

long O5276[14];
void O5276_init () {
	{long i; for (i = 0; i < 2; i++) O5276[i] =  + _REFACS_1_;}
	{long i; for (i = 2; i < 8; i++) O5276[i] = 0;}
	{long i; for (i = 8; i < 10; i++) O5276[i] =  + _REFACS_1_;}
	{long i; for (i = 10; i < 14; i++) O5276[i] = 0;}
}

static EIF_TYPE_INDEX Y5276_pgtype0[] = {1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5276_pgtype1[] = {1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5276_pgtype2[] = {1111,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5276_pgtype3[] = {1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5276_pgtype4[] = {1114,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5276_pgtype5[] = {1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5276_pgtype6[] = {1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5276_pgtype7[] = {1116,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5276_pgtype8[] = {1108,0,0xFFFF};
static EIF_TYPE_INDEX Y5276_pgtype9[] = {1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5276_pgtype10[] = {1114,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5276_pgtype11[] = {1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5276_pgtype12[] = {1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5276_pgtype13[] = {1116,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5276_gen_type [14];
EIF_TYPE_INDEX Y5276 [14];
void Y5276_init (void)
{
	egc_routines_types [5276] = Y5276;
	egc_routines_gen_types [5276] = Y5276_gen_type;
	egc_routines_offset [5276] = 795;
	Y5276_gen_type [0] = Y5276_pgtype0;
	Y5276_gen_type [1] = Y5276_pgtype1;
	Y5276_gen_type [2] = Y5276_pgtype2;
	Y5276_gen_type [3] = Y5276_pgtype3;
	Y5276_gen_type [4] = Y5276_pgtype4;
	Y5276_gen_type [5] = Y5276_pgtype5;
	Y5276_gen_type [6] = Y5276_pgtype6;
	Y5276_gen_type [7] = Y5276_pgtype7;
	Y5276_gen_type [8] = Y5276_pgtype8;
	Y5276_gen_type [9] = Y5276_pgtype9;
	Y5276_gen_type [10] = Y5276_pgtype10;
	Y5276_gen_type [11] = Y5276_pgtype11;
	Y5276_gen_type [12] = Y5276_pgtype12;
	Y5276_gen_type [13] = Y5276_pgtype13;
	{long i; for (i = 0; i < 2; i++) Y5276[i] = 1108;};
	Y5276[2] = 1111;
	Y5276[3] = 1109;
	Y5276[4] = 1114;
	Y5276[5] = 1110;
	Y5276[6] = 1109;
	Y5276[7] = 1116;
	{long i; for (i = 8; i < 10; i++) Y5276[i] = 1108;};
	Y5276[10] = 1114;
	Y5276[11] = 1109;
	Y5276[12] = 1110;
	Y5276[13] = 1116;
}

long O5277[14];
void O5277_init () {
	{long i; for (i = 0; i < 2; i++) O5277[i] =  + _REFACS_2_;}
	{long i; for (i = 2; i < 8; i++) O5277[i] =  + _REFACS_1_;}
	{long i; for (i = 8; i < 10; i++) O5277[i] =  + _REFACS_2_;}
	{long i; for (i = 10; i < 14; i++) O5277[i] =  + _REFACS_1_;}
}

static EIF_TYPE_INDEX Y5277_pgtype0[] = {1108,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5277_pgtype1[] = {1109,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5277_pgtype2[] = {1108,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5277_pgtype3[] = {1108,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5277_pgtype4[] = {1108,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5277_pgtype5[] = {1108,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5277_pgtype6[] = {1109,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5277_pgtype7[] = {1108,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5277_pgtype8[] = {1108,1052,0xFFFF};
static EIF_TYPE_INDEX Y5277_pgtype9[] = {1108,1047,0xFFFF};
static EIF_TYPE_INDEX Y5277_pgtype10[] = {1108,1047,0xFFFF};
static EIF_TYPE_INDEX Y5277_pgtype11[] = {1108,1047,0xFFFF};
static EIF_TYPE_INDEX Y5277_pgtype12[] = {1108,1047,0xFFFF};
static EIF_TYPE_INDEX Y5277_pgtype13[] = {1108,1047,0xFFFF};
EIF_TYPE_INDEX *Y5277_gen_type [14];
EIF_TYPE_INDEX Y5277 [14];
void Y5277_init (void)
{
	egc_routines_types [5277] = Y5277;
	egc_routines_gen_types [5277] = Y5277_gen_type;
	egc_routines_offset [5277] = 795;
	Y5277_gen_type [0] = Y5277_pgtype0;
	Y5277_gen_type [1] = Y5277_pgtype1;
	Y5277_gen_type [2] = Y5277_pgtype2;
	Y5277_gen_type [3] = Y5277_pgtype3;
	Y5277_gen_type [4] = Y5277_pgtype4;
	Y5277_gen_type [5] = Y5277_pgtype5;
	Y5277_gen_type [6] = Y5277_pgtype6;
	Y5277_gen_type [7] = Y5277_pgtype7;
	Y5277_gen_type [8] = Y5277_pgtype8;
	Y5277_gen_type [9] = Y5277_pgtype9;
	Y5277_gen_type [10] = Y5277_pgtype10;
	Y5277_gen_type [11] = Y5277_pgtype11;
	Y5277_gen_type [12] = Y5277_pgtype12;
	Y5277_gen_type [13] = Y5277_pgtype13;
	Y5277[0] = 1108;
	Y5277[1] = 1109;
	{long i; for (i = 2; i < 6; i++) Y5277[i] = 1108;};
	Y5277[6] = 1109;
	{long i; for (i = 7; i < 14; i++) Y5277[i] = 1108;};
}

long O5278[14];
void O5278_init () {
	{long i; for (i = 0; i < 2; i++) O5278[i] =  + _REFACS_3_;}
	{long i; for (i = 2; i < 8; i++) O5278[i] =  + _REFACS_2_;}
	{long i; for (i = 8; i < 10; i++) O5278[i] =  + _REFACS_3_;}
	{long i; for (i = 10; i < 14; i++) O5278[i] =  + _REFACS_2_;}
}

long O5279[14];
void O5279_init () {
	{long i; for (i = 0; i < 2; i++) O5279[i] =  + _REFACS_4_;}
	{long i; for (i = 2; i < 8; i++) O5279[i] =  + _REFACS_3_;}
	{long i; for (i = 8; i < 10; i++) O5279[i] =  + _REFACS_4_;}
	{long i; for (i = 10; i < 14; i++) O5279[i] =  + _REFACS_3_;}
}

long O5280[14];
void O5280_init () {
	O5280[0] = + _LNGOFF_7_3_0_1_;
	O5280[1] = + _LNGOFF_6_3_0_1_;
	O5280[2] = + _LNGOFF_5_3_0_1_;
	O5280[3] = + _LNGOFF_5_3_0_2_;
	O5280[4] = + _LNGOFF_5_3_0_3_;
	O5280[5] = + _LNGOFF_5_5_0_1_;
	O5280[6] = + _LNGOFF_4_3_0_2_;
	O5280[7] = + _LNGOFF_5_5_0_1_;
	O5280[8] = + _LNGOFF_9_3_0_1_;
	O5280[9] = + _LNGOFF_7_4_0_1_;
	O5280[10] = + _LNGOFF_5_4_0_3_;
	O5280[11] = + _LNGOFF_5_4_0_2_;
	{long i; for (i = 12; i < 14; i++) O5280[i] = + _LNGOFF_5_6_0_1_;}
}

long O5281[14];
void O5281_init () {
	O5281[0] = + _CHROFF_7_2_;
	O5281[1] = + _CHROFF_6_2_;
	{long i; for (i = 2; i < 5; i++) O5281[i] = + _CHROFF_5_2_;}
	O5281[5] = + _CHROFF_5_3_;
	O5281[6] = + _CHROFF_4_2_;
	O5281[7] = + _CHROFF_5_2_;
	O5281[8] = + _CHROFF_9_2_;
	O5281[9] = + _CHROFF_7_2_;
	{long i; for (i = 10; i < 12; i++) O5281[i] = + _CHROFF_5_2_;}
	O5281[12] = + _CHROFF_5_3_;
	O5281[13] = + _CHROFF_5_2_;
}

long O5282[14];
void O5282_init () {
	O5282[0] = + _LNGOFF_7_3_0_2_;
	O5282[1] = + _LNGOFF_6_3_0_2_;
	O5282[2] = + _LNGOFF_5_3_0_2_;
	O5282[3] = + _LNGOFF_5_3_0_3_;
	O5282[4] = + _LNGOFF_5_3_0_4_;
	O5282[5] = + _LNGOFF_5_5_0_2_;
	O5282[6] = + _LNGOFF_4_3_0_3_;
	O5282[7] = + _LNGOFF_5_5_0_2_;
	O5282[8] = + _LNGOFF_9_3_0_2_;
	O5282[9] = + _LNGOFF_7_4_0_2_;
	O5282[10] = + _LNGOFF_5_4_0_4_;
	O5282[11] = + _LNGOFF_5_4_0_3_;
	{long i; for (i = 12; i < 14; i++) O5282[i] = + _LNGOFF_5_6_0_2_;}
}

long O5285[14];
void O5285_init () {
	O5285[0] = + _LNGOFF_7_3_0_3_;
	O5285[1] = + _LNGOFF_6_3_0_3_;
	O5285[2] = + _LNGOFF_5_3_0_3_;
	O5285[3] = + _LNGOFF_5_3_0_4_;
	O5285[4] = + _LNGOFF_5_3_0_5_;
	O5285[5] = + _LNGOFF_5_5_0_3_;
	O5285[6] = + _LNGOFF_4_3_0_4_;
	O5285[7] = + _LNGOFF_5_5_0_3_;
	O5285[8] = + _LNGOFF_9_3_0_3_;
	O5285[9] = + _LNGOFF_7_4_0_3_;
	O5285[10] = + _LNGOFF_5_4_0_5_;
	O5285[11] = + _LNGOFF_5_4_0_4_;
	{long i; for (i = 12; i < 14; i++) O5285[i] = + _LNGOFF_5_6_0_3_;}
}

long O5286[14];
void O5286_init () {
	O5286[0] = + _LNGOFF_7_3_0_4_;
	O5286[1] = + _LNGOFF_6_3_0_4_;
	O5286[2] = + _LNGOFF_5_3_0_4_;
	O5286[3] = + _LNGOFF_5_3_0_5_;
	O5286[4] = + _LNGOFF_5_3_0_6_;
	O5286[5] = + _LNGOFF_5_5_0_4_;
	O5286[6] = + _LNGOFF_4_3_0_5_;
	O5286[7] = + _LNGOFF_5_5_0_4_;
	O5286[8] = + _LNGOFF_9_3_0_4_;
	O5286[9] = + _LNGOFF_7_4_0_4_;
	O5286[10] = + _LNGOFF_5_4_0_6_;
	O5286[11] = + _LNGOFF_5_4_0_5_;
	{long i; for (i = 12; i < 14; i++) O5286[i] = + _LNGOFF_5_6_0_4_;}
}

long O5290[14];
void O5290_init () {
	O5290[0] = + _LNGOFF_7_3_0_5_;
	O5290[1] = + _LNGOFF_6_3_0_5_;
	O5290[2] = + _LNGOFF_5_3_0_5_;
	O5290[3] = + _LNGOFF_5_3_0_6_;
	O5290[4] = + _LNGOFF_5_3_0_7_;
	O5290[5] = + _LNGOFF_5_5_0_5_;
	O5290[6] = + _LNGOFF_4_3_0_6_;
	O5290[7] = + _LNGOFF_5_5_0_5_;
	O5290[8] = + _LNGOFF_9_3_0_5_;
	O5290[9] = + _LNGOFF_7_4_0_5_;
	O5290[10] = + _LNGOFF_5_4_0_7_;
	O5290[11] = + _LNGOFF_5_4_0_6_;
	{long i; for (i = 12; i < 14; i++) O5290[i] = + _LNGOFF_5_6_0_5_;}
}

long O5291[14];
void O5291_init () {
	{long i; for (i = 0; i < 2; i++) O5291[i] =  + _REFACS_5_;}
	O5291[2] = + _PTROFF_5_3_0_7_0_1_;
	O5291[3] = + _LNGOFF_5_3_0_7_;
	O5291[4] = + _LNGOFF_5_3_0_1_;
	O5291[5] = + _CHROFF_5_4_;
	O5291[6] = + _LNGOFF_4_3_0_7_;
	O5291[7] = + _CHROFF_5_4_;
	{long i; for (i = 8; i < 10; i++) O5291[i] =  + _REFACS_5_;}
	O5291[10] = + _LNGOFF_5_4_0_1_;
	O5291[11] = + _LNGOFF_5_4_0_7_;
	O5291[12] = + _CHROFF_5_4_;
	O5291[13] = + _CHROFF_5_5_;
}

long O5292[14];
void O5292_init () {
	O5292[0] =  + _REFACS_6_;
	O5292[1] = + _LNGOFF_6_3_0_6_;
	{long i; for (i = 2; i < 6; i++) O5292[i] =  + _REFACS_4_;}
	O5292[6] = + _LNGOFF_4_3_0_8_;
	O5292[7] =  + _REFACS_4_;
	{long i; for (i = 8; i < 10; i++) O5292[i] =  + _REFACS_6_;}
	{long i; for (i = 10; i < 14; i++) O5292[i] =  + _REFACS_4_;}
}

long O5326[14];
void O5326_init () {
	O5326[0] = + _LNGOFF_7_3_0_6_;
	O5326[1] = + _LNGOFF_6_3_0_7_;
	O5326[2] = + _LNGOFF_5_3_0_6_;
	{long i; for (i = 3; i < 5; i++) O5326[i] = + _LNGOFF_5_3_0_8_;}
	O5326[5] = + _LNGOFF_5_5_0_6_;
	O5326[6] = + _LNGOFF_4_3_0_9_;
	O5326[7] = + _LNGOFF_5_5_0_6_;
	O5326[8] = + _LNGOFF_9_3_0_6_;
	O5326[9] = + _LNGOFF_7_4_0_6_;
	{long i; for (i = 10; i < 12; i++) O5326[i] = + _LNGOFF_5_4_0_8_;}
	{long i; for (i = 12; i < 14; i++) O5326[i] = + _LNGOFF_5_6_0_6_;}
}

long O5339[5];
void O5339_init () {
	O5339[0] = + _CHROFF_7_3_;
	{long i; for (i = 1; i < 3; i++) O5339[i] = + _CHROFF_5_3_;}
	O5339[3] = + _CHROFF_5_5_;
	O5339[4] = + _CHROFF_5_3_;
}

long O5449[88];
void O5449_init () {
	{long i; for (i = 0; i < 16; i++) O5449[i] = + _LNGOFF_1_1_0_0_;}
	O5449[16] = + _LNGOFF_5_1_0_0_;
	O5449[87] = + _LNGOFF_1_1_0_0_;
}

long O5639[2];
void O5639_init () {
	O5639[0] = + _CHROFF_12_0_;
	O5639[1] = + _CHROFF_18_0_;
}

long O5640[2];
void O5640_init () {
	O5640[0] = + _CHROFF_12_1_;
	O5640[1] = + _CHROFF_18_1_;
}

long O5641[2];
void O5641_init () {
	O5641[0] = + _CHROFF_12_2_;
	O5641[1] = + _CHROFF_18_2_;
}

long O5642[2];
void O5642_init () {
	O5642[0] = + _CHROFF_12_3_;
	O5642[1] = + _CHROFF_18_3_;
}

long O5643[2];
void O5643_init () {
	O5643[0] = + _CHROFF_12_4_;
	O5643[1] = + _CHROFF_18_4_;
}

long O5644[2];
void O5644_init () {
	O5644[0] = + _CHROFF_12_5_;
	O5644[1] = + _CHROFF_18_5_;
}

long O5645[2];
void O5645_init () {
	O5645[0] = + _CHROFF_12_6_;
	O5645[1] = + _CHROFF_18_6_;
}

long O5646[2];
void O5646_init () {
	O5646[0] = + _CHROFF_12_7_;
	O5646[1] = + _CHROFF_18_7_;
}

long O5647[2];
void O5647_init () {
	O5647[0] = + _CHROFF_12_8_;
	O5647[1] = + _CHROFF_18_8_;
}

long O5662[2];
void O5662_init () {
	O5662[0] = + _CHROFF_12_9_;
	O5662[1] = + _CHROFF_18_9_;
}

long O5663[2];
void O5663_init () {
	O5663[0] = + _CHROFF_12_10_;
	O5663[1] = + _CHROFF_18_10_;
}

long O5664[2];
void O5664_init () {
	O5664[0] = + _CHROFF_12_11_;
	O5664[1] = + _CHROFF_18_11_;
}

long O5665[2];
void O5665_init () {
	O5665[0] = + _CHROFF_12_12_;
	O5665[1] = + _CHROFF_18_12_;
}

long O5666[2];
void O5666_init () {
	O5666[0] = + _CHROFF_12_13_;
	O5666[1] = + _CHROFF_18_13_;
}

long O5667[2];
void O5667_init () {
	O5667[0] = + _CHROFF_12_14_;
	O5667[1] = + _CHROFF_18_14_;
}

long O5668[2];
void O5668_init () {
	O5668[0] = + _CHROFF_12_15_;
	O5668[1] = + _CHROFF_18_15_;
}

long O5669[2];
void O5669_init () {
	O5669[0] = + _CHROFF_12_16_;
	O5669[1] = + _CHROFF_18_16_;
}

long O5670[2];
void O5670_init () {
	O5670[0] = + _CHROFF_12_17_;
	O5670[1] = + _CHROFF_18_17_;
}

long O5803[8];
void O5803_init () {
	{long i; for (i = 0; i < 3; i++) O5803[i] = + _LNGOFF_2_0_0_0_;}
	O5803[3] = + _LNGOFF_3_0_0_0_;
	O5803[4] = + _LNGOFF_2_0_0_0_;
	O5803[5] = + _LNGOFF_3_0_0_0_;
	O5803[6] = + _LNGOFF_2_0_0_0_;
	O5803[7] = + _LNGOFF_3_0_0_0_;
}

long O5804[8];
void O5804_init () {
	{long i; for (i = 0; i < 3; i++) O5804[i] = + _LNGOFF_2_0_0_1_;}
	O5804[3] = + _LNGOFF_3_0_0_1_;
	O5804[4] = + _LNGOFF_2_0_0_1_;
	O5804[5] = + _LNGOFF_3_0_0_1_;
	O5804[6] = + _LNGOFF_2_0_0_1_;
	O5804[7] = + _LNGOFF_3_0_0_1_;
}

long O5805[8];
void O5805_init () {
	{long i; for (i = 0; i < 3; i++) O5805[i] = + _LNGOFF_2_0_0_2_;}
	O5805[3] = + _LNGOFF_3_0_0_2_;
	O5805[4] = + _LNGOFF_2_0_0_2_;
	O5805[5] = + _LNGOFF_3_0_0_2_;
	O5805[6] = + _LNGOFF_2_0_0_2_;
	O5805[7] = + _LNGOFF_3_0_0_2_;
}

long O6516[6];
void O6516_init () {
	{long i; for (i = 0; i < 2; i++) O6516[i] = + _CHROFF_4_0_;}
	O6516[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 6; i++) O6516[i] = + _CHROFF_4_0_;}
}

long O6517[6];
void O6517_init () {
	{long i; for (i = 0; i < 2; i++) O6517[i] = + _LNGOFF_4_2_0_0_;}
	O6517[2] = + _LNGOFF_5_2_0_0_;
	O6517[3] = + _LNGOFF_4_3_0_0_;
	O6517[4] = + _LNGOFF_4_2_0_0_;
	O6517[5] = + _LNGOFF_4_3_0_0_;
}

long O6525[6];
void O6525_init () {
	{long i; for (i = 0; i < 2; i++) O6525[i] = + _PTROFF_4_2_0_3_0_0_;}
	O6525[2] = + _PTROFF_5_2_0_3_0_0_;
	O6525[3] = + _PTROFF_4_3_0_3_0_0_;
	O6525[4] = + _PTROFF_4_2_0_4_0_0_;
	O6525[5] = + _PTROFF_4_3_0_3_0_0_;
}

long O6526[6];
void O6526_init () {
	{long i; for (i = 0; i < 2; i++) O6526[i] = + _PTROFF_4_2_0_3_0_1_;}
	O6526[2] = + _PTROFF_5_2_0_3_0_1_;
	O6526[3] = + _PTROFF_4_3_0_3_0_1_;
	O6526[4] = + _PTROFF_4_2_0_4_0_1_;
	O6526[5] = + _PTROFF_4_3_0_3_0_1_;
}

long O6528[6];
void O6528_init () {
	{long i; for (i = 0; i < 2; i++) O6528[i] = + _PTROFF_4_2_0_3_0_2_;}
	O6528[2] = + _PTROFF_5_2_0_3_0_2_;
	O6528[3] = + _PTROFF_4_3_0_3_0_2_;
	O6528[4] = + _PTROFF_4_2_0_4_0_2_;
	O6528[5] = + _PTROFF_4_3_0_3_0_2_;
}

long O6529[6];
void O6529_init () {
	{long i; for (i = 0; i < 2; i++) O6529[i] = + _LNGOFF_4_2_0_1_;}
	O6529[2] = + _LNGOFF_5_2_0_1_;
	O6529[3] = + _LNGOFF_4_3_0_1_;
	O6529[4] = + _LNGOFF_4_2_0_1_;
	O6529[5] = + _LNGOFF_4_3_0_1_;
}

long O6530[6];
void O6530_init () {
	{long i; for (i = 0; i < 2; i++) O6530[i] = + _CHROFF_4_1_;}
	O6530[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 6; i++) O6530[i] = + _CHROFF_4_1_;}
}

long O6531[6];
void O6531_init () {
	{long i; for (i = 0; i < 2; i++) O6531[i] = + _LNGOFF_4_2_0_2_;}
	O6531[2] = + _LNGOFF_5_2_0_2_;
	O6531[3] = + _LNGOFF_4_3_0_2_;
	O6531[4] = + _LNGOFF_4_2_0_2_;
	O6531[5] = + _LNGOFF_4_3_0_2_;
}

long O6544[4];
void O6544_init () {
	O6544[0] =  + _REFACS_4_;
	O6544[1] = + _CHROFF_4_2_;
	O6544[2] = + _LNGOFF_4_2_0_3_;
	O6544[3] = + _CHROFF_4_2_;
}

long O6643[268];
void O6643_init () {
	{long i; for (i = 0; i < 3; i++) O6643[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O6643[i] = + _LNGOFF_1_0_0_0_;}
	O6643[5] = + _LNGOFF_1_1_0_0_;
	O6643[6] = + _LNGOFF_1_2_0_0_;
	O6643[7] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 8; i < 10; i++) O6643[i] = + _LNGOFF_1_0_0_0_;}
	O6643[10] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 266; i < 268; i++) O6643[i] = + _LNGOFF_1_1_0_0_;}
}

long O6644[268];
void O6644_init () {
	{long i; for (i = 0; i < 3; i++) O6644[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O6644[i] = + _LNGOFF_1_0_0_1_;}
	O6644[5] = + _LNGOFF_1_1_0_1_;
	O6644[6] = + _LNGOFF_1_2_0_1_;
	O6644[7] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 8; i < 10; i++) O6644[i] = + _LNGOFF_1_0_0_1_;}
	O6644[10] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 266; i < 268; i++) O6644[i] = + _LNGOFF_1_1_0_1_;}
}

long O6713[265];
void O6713_init () {
	{long i; for (i = 0; i < 2; i++) O6713[i] = + _LNGOFF_1_0_0_2_;}
	O6713[2] = + _LNGOFF_1_1_0_2_;
	O6713[3] = + _LNGOFF_1_2_0_2_;
	O6713[4] = + _LNGOFF_1_1_0_2_;
	{long i; for (i = 263; i < 265; i++) O6713[i] = + _LNGOFF_1_1_0_2_;}
}

long O6791[3];
void O6791_init () {
	{long i; for (i = 0; i < 2; i++) O6791[i] = + _LNGOFF_1_0_0_2_;}
	O6791[2] = + _LNGOFF_1_1_0_2_;
}

long O7395[10];
void O7395_init () {
	{long i; for (i = 0; i < 2; i++) O7395[i] = + _CHROFF_16_0_;}
	O7395[2] = + _CHROFF_18_0_;
	{long i; for (i = 3; i < 5; i++) O7395[i] = + _CHROFF_27_0_;}
	O7395[5] = + _CHROFF_29_0_;
	O7395[6] = + _CHROFF_18_0_;
	O7395[7] = + _CHROFF_23_0_;
	O7395[8] = + _CHROFF_21_0_;
	O7395[9] = + _CHROFF_22_0_;
}

long O7406[10];
void O7406_init () {
	{long i; for (i = 0; i < 3; i++) O7406[i] =  + _REFACS_3_;}
	{long i; for (i = 3; i < 6; i++) O7406[i] =  + _REFACS_5_;}
	{long i; for (i = 6; i < 8; i++) O7406[i] =  + _REFACS_3_;}
	{long i; for (i = 8; i < 10; i++) O7406[i] =  + _REFACS_5_;}
}

EIF_TYPE_INDEX *Y7406_gen_type [10];
EIF_TYPE_INDEX Y7406 [10];
void Y7406_init (void)
{
	egc_routines_types [7406] = Y7406;
	egc_routines_gen_types [7406] = Y7406_gen_type;
	egc_routines_offset [7406] = 1120;
	{long i; for (i = 0; i < 10; i++) Y7406[i] = 1055;};
}

long O7407[10];
void O7407_init () {
	{long i; for (i = 0; i < 3; i++) O7407[i] =  + _REFACS_4_;}
	{long i; for (i = 3; i < 6; i++) O7407[i] =  + _REFACS_6_;}
	{long i; for (i = 6; i < 8; i++) O7407[i] =  + _REFACS_4_;}
	{long i; for (i = 8; i < 10; i++) O7407[i] =  + _REFACS_6_;}
}

long O7408[10];
void O7408_init () {
	{long i; for (i = 0; i < 3; i++) O7408[i] =  + _REFACS_5_;}
	{long i; for (i = 3; i < 6; i++) O7408[i] =  + _REFACS_7_;}
	{long i; for (i = 6; i < 8; i++) O7408[i] =  + _REFACS_5_;}
	{long i; for (i = 8; i < 10; i++) O7408[i] =  + _REFACS_7_;}
}

EIF_TYPE_INDEX *Y7408_gen_type [10];
EIF_TYPE_INDEX Y7408 [10];
void Y7408_init (void)
{
	egc_routines_types [7408] = Y7408;
	egc_routines_gen_types [7408] = Y7408_gen_type;
	egc_routines_offset [7408] = 1120;
	{long i; for (i = 0; i < 3; i++) Y7408[i] = 1277;};
	{long i; for (i = 3; i < 6; i++) Y7408[i] = 1279;};
	Y7408[6] = 1277;
	Y7408[7] = 1278;
	{long i; for (i = 8; i < 10; i++) Y7408[i] = 1277;};
}

long O7410[10];
void O7410_init () {
	{long i; for (i = 0; i < 3; i++) O7410[i] =  + _REFACS_6_;}
	{long i; for (i = 3; i < 6; i++) O7410[i] =  + _REFACS_8_;}
	{long i; for (i = 6; i < 8; i++) O7410[i] =  + _REFACS_6_;}
	{long i; for (i = 8; i < 10; i++) O7410[i] =  + _REFACS_8_;}
}

long O7412[10];
void O7412_init () {
	{long i; for (i = 0; i < 3; i++) O7412[i] =  + _REFACS_8_;}
	{long i; for (i = 3; i < 6; i++) O7412[i] =  + _REFACS_10_;}
	{long i; for (i = 6; i < 8; i++) O7412[i] =  + _REFACS_8_;}
	{long i; for (i = 8; i < 10; i++) O7412[i] =  + _REFACS_10_;}
}

long O7443[10];
void O7443_init () {
	{long i; for (i = 0; i < 2; i++) O7443[i] = + _CHROFF_16_1_;}
	O7443[2] = + _CHROFF_18_1_;
	{long i; for (i = 3; i < 5; i++) O7443[i] = + _CHROFF_27_1_;}
	O7443[5] = + _CHROFF_29_1_;
	O7443[6] = + _CHROFF_18_1_;
	O7443[7] = + _CHROFF_23_1_;
	O7443[8] = + _CHROFF_21_1_;
	O7443[9] = + _CHROFF_22_1_;
}

long O7444[10];
void O7444_init () {
	{long i; for (i = 0; i < 3; i++) O7444[i] =  + _REFACS_9_;}
	{long i; for (i = 3; i < 6; i++) O7444[i] =  + _REFACS_11_;}
	{long i; for (i = 6; i < 8; i++) O7444[i] =  + _REFACS_9_;}
	{long i; for (i = 8; i < 10; i++) O7444[i] =  + _REFACS_11_;}
}

long O7446[10];
void O7446_init () {
	{long i; for (i = 0; i < 3; i++) O7446[i] =  + _REFACS_11_;}
	{long i; for (i = 3; i < 6; i++) O7446[i] =  + _REFACS_13_;}
	{long i; for (i = 6; i < 8; i++) O7446[i] =  + _REFACS_11_;}
	{long i; for (i = 8; i < 10; i++) O7446[i] =  + _REFACS_13_;}
}

long O7454[10];
void O7454_init () {
	{long i; for (i = 0; i < 2; i++) O7454[i] = + _LNGOFF_16_3_0_0_;}
	O7454[2] = + _LNGOFF_18_3_0_0_;
	{long i; for (i = 3; i < 5; i++) O7454[i] = + _LNGOFF_27_5_0_0_;}
	O7454[5] = + _LNGOFF_29_5_0_0_;
	O7454[6] = + _LNGOFF_18_3_0_0_;
	O7454[7] = + _LNGOFF_23_4_0_0_;
	O7454[8] = + _LNGOFF_21_4_0_0_;
	O7454[9] = + _LNGOFF_22_4_0_0_;
}

long O7455[10];
void O7455_init () {
	{long i; for (i = 0; i < 3; i++) O7455[i] =  + _REFACS_14_;}
	{long i; for (i = 3; i < 6; i++) O7455[i] =  + _REFACS_16_;}
	{long i; for (i = 6; i < 8; i++) O7455[i] =  + _REFACS_14_;}
	{long i; for (i = 8; i < 10; i++) O7455[i] =  + _REFACS_16_;}
}

long O7457[10];
void O7457_init () {
	{long i; for (i = 0; i < 2; i++) O7457[i] = + _CHROFF_16_2_;}
	O7457[2] = + _CHROFF_18_2_;
	{long i; for (i = 3; i < 5; i++) O7457[i] = + _CHROFF_27_2_;}
	O7457[5] = + _CHROFF_29_2_;
	O7457[6] = + _CHROFF_18_2_;
	O7457[7] = + _CHROFF_23_2_;
	O7457[8] = + _CHROFF_21_2_;
	O7457[9] = + _CHROFF_22_2_;
}

long O7462[3];
void O7462_init () {
	{long i; for (i = 0; i < 2; i++) O7462[i] = + _CHROFF_27_3_;}
	O7462[2] = + _CHROFF_29_3_;
}

long O7463[3];
void O7463_init () {
	{long i; for (i = 0; i < 2; i++) O7463[i] = + _CHROFF_27_4_;}
	O7463[2] = + _CHROFF_29_4_;
}

static EIF_TYPE_INDEX Y7465_pgtype0[] = {892,1123,0xFFFF};
static EIF_TYPE_INDEX Y7465_pgtype1[] = {892,1124,0xFFFF};
static EIF_TYPE_INDEX Y7465_pgtype2[] = {892,1125,0xFFFF};
EIF_TYPE_INDEX *Y7465_gen_type [3];
EIF_TYPE_INDEX Y7465 [3];
void Y7465_init (void)
{
	egc_routines_types [7465] = Y7465;
	egc_routines_gen_types [7465] = Y7465_gen_type;
	egc_routines_offset [7465] = 1123;
	Y7465_gen_type [0] = Y7465_pgtype0;
	Y7465_gen_type [1] = Y7465_pgtype1;
	Y7465_gen_type [2] = Y7465_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y7465[i] = 892;};
}

long O7497[4];
void O7497_init () {
	{long i; for (i = 0; i < 2; i++) O7497[i] =  + _REFACS_16_;}
	{long i; for (i = 2; i < 4; i++) O7497[i] =  + _REFACS_18_;}
}

long O7498[4];
void O7498_init () {
	{long i; for (i = 0; i < 2; i++) O7498[i] =  + _REFACS_17_;}
	{long i; for (i = 2; i < 4; i++) O7498[i] =  + _REFACS_19_;}
}

long O7514[2];
void O7514_init () {
	O7514[0] = + _CHROFF_21_3_;
	O7514[1] = + _CHROFF_22_3_;
}

long O8282[3];
void O8282_init () {
	O8282[0] = 0;
	{long i; for (i = 1; i < 3; i++) O8282[i] = + _LNGOFF_3_1_0_0_;}
}

long O8284[3];
void O8284_init () {
	O8284[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O8284[i] = 0;}
}

long O8296[3];
void O8296_init () {
	O8296[0] = + _LNGOFF_4_1_0_0_;
	{long i; for (i = 1; i < 3; i++) O8296[i] = + _LNGOFF_3_1_0_1_;}
}

long O8299[3];
void O8299_init () {
	O8299[0] = + _LNGOFF_4_1_0_1_;
	{long i; for (i = 1; i < 3; i++) O8299[i] = + _LNGOFF_3_1_0_2_;}
}

long O8306[3];
void O8306_init () {
	O8306[0] = + _LNGOFF_4_1_0_2_;
	{long i; for (i = 1; i < 3; i++) O8306[i] = + _LNGOFF_3_1_0_3_;}
}

long O8313[3];
void O8313_init () {
	O8313[0] = + _CHROFF_4_0_;
	{long i; for (i = 1; i < 3; i++) O8313[i] = + _CHROFF_3_0_;}
}

long O8314[3];
void O8314_init () {
	O8314[0] = + _LNGOFF_4_1_0_3_;
	{long i; for (i = 1; i < 3; i++) O8314[i] = + _LNGOFF_3_1_0_4_;}
}

long O8315[3];
void O8315_init () {
	O8315[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 3; i++) O8315[i] =  + _REFACS_1_;}
}

long O8316[3];
void O8316_init () {
	O8316[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 3; i++) O8316[i] =  + _REFACS_2_;}
}

long O8325[3];
void O8325_init () {
	O8325[0] = + _LNGOFF_4_1_0_4_;
	{long i; for (i = 1; i < 3; i++) O8325[i] = + _LNGOFF_3_1_0_5_;}
}

long O8814[3];
void O8814_init () {
	O8814[0] = + _CHROFF_2_1_;
	O8814[1] = + _CHROFF_5_1_;
	O8814[2] = + _CHROFF_16_1_;
}

long O8816[3];
void O8816_init () {
	{long i; for (i = 0; i < 2; i++) O8816[i] = 0;}
	O8816[2] =  + _REFACS_1_;
}

long O8817[3];
void O8817_init () {
	{long i; for (i = 0; i < 2; i++) O8817[i] =  + _REFACS_1_;}
	O8817[2] =  + _REFACS_2_;
}

long O8819[3];
void O8819_init () {
	O8819[0] = + _LNGOFF_2_2_0_0_;
	O8819[1] = + _LNGOFF_5_2_0_0_;
	O8819[2] = + _LNGOFF_16_4_0_1_;
}

long O10005[3];
void O10005_init () {
	{long i; for (i = 0; i < 2; i++) O10005[i] = + _CHROFF_6_0_;}
	O10005[2] = + _CHROFF_7_0_;
}

long O10006[3];
void O10006_init () {
	{long i; for (i = 0; i < 2; i++) O10006[i] = + _CHROFF_6_1_;}
	O10006[2] = + _CHROFF_7_1_;
}

long O10016[3];
void O10016_init () {
	{long i; for (i = 0; i < 2; i++) O10016[i] = + _LNGOFF_6_2_0_0_;}
	O10016[2] = + _LNGOFF_7_3_0_0_;
}


#ifdef __cplusplus
}
#endif
