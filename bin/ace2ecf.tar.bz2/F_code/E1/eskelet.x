#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif
extern const char *names3[];
static const uint32 types3 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags3 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype3_0 [] = {81,0xFFFF};
static const EIF_TYPE_INDEX g_atype3_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype3_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype3_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype3_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes3 [] = {
g_atype3_0,
g_atype3_1,
g_atype3_2,
g_atype3_3,
g_atype3_4,
};

static const long offsets3 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names8[];
static const uint32 types8 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags8 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype8_0 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype8_1 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype8_2 [] = {1298,0xFFFF};
static const EIF_TYPE_INDEX g_atype8_3 [] = {1061,0xFFFF};

static const EIF_TYPE_INDEX *gtypes8 [] = {
g_atype8_0,
g_atype8_1,
g_atype8_2,
g_atype8_3,
};

static const long offsets8 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names9[];
static const uint32 types9 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags9 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype9_0 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_1 [] = {1214,0xFFFF};

static const EIF_TYPE_INDEX *gtypes9 [] = {
g_atype9_0,
g_atype9_1,
};

static const long offsets9 [] =
{
0,
 + @REFACS(1),
};

extern const char *names13[];
static const uint32 types13 [] =
{
SK_REF,
};

static const uint16 attr_flags13 [] =
{0,};

static const EIF_TYPE_INDEX g_atype13_0 [] = {400,0xFFFF};

static const EIF_TYPE_INDEX *gtypes13 [] = {
g_atype13_0,
};

static const long offsets13 [] =
{
0,
};

extern const char *names19[];
static const uint32 types19 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags19 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype19_0 [] = {133,0xFFFF};
static const EIF_TYPE_INDEX g_atype19_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype19_2 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype19_3 [] = {804,1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes19 [] = {
g_atype19_0,
g_atype19_1,
g_atype19_2,
g_atype19_3,
};

static const long offsets19 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names21[];
static const uint32 types21 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags21 [] =
{0,};

static const EIF_TYPE_INDEX g_atype21_0 [] = {1004,0xFFFF};

static const EIF_TYPE_INDEX *gtypes21 [] = {
g_atype21_0,
};

static const long offsets21 [] =
{
+ @CHROFF(0,0),
};

extern const char *names22[];
static const uint32 types22 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags22 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype22_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype22_1 [] = {143,0xFFFF};
static const EIF_TYPE_INDEX g_atype22_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes22 [] = {
g_atype22_0,
g_atype22_1,
g_atype22_2,
};

static const long offsets22 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names23[];
static const uint32 types23 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags23 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype23_0 [] = {334,0xFFFF};
static const EIF_TYPE_INDEX g_atype23_1 [] = {334,0xFFFF};
static const EIF_TYPE_INDEX g_atype23_2 [] = {334,0xFFFF};

static const EIF_TYPE_INDEX *gtypes23 [] = {
g_atype23_0,
g_atype23_1,
g_atype23_2,
};

static const long offsets23 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names24[];
static const uint32 types24 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags24 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype24_0 [] = {797,1040,1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype24_1 [] = {795,1050,1050,0xFFFF};

static const EIF_TYPE_INDEX *gtypes24 [] = {
g_atype24_0,
g_atype24_1,
};

static const long offsets24 [] =
{
0,
 + @REFACS(1),
};

extern const char *names26[];
static const uint32 types26 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags26 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype26_0 [] = {904,997,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes26 [] = {
g_atype26_0,
g_atype26_1,
g_atype26_2,
};

static const long offsets26 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names27[];
static const uint32 types27 [] =
{
SK_UINT32,
};

static const uint16 attr_flags27 [] =
{0,};

static const EIF_TYPE_INDEX g_atype27_0 [] = {1199,0xFFFF};

static const EIF_TYPE_INDEX *gtypes27 [] = {
g_atype27_0,
};

static const long offsets27 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names28[];
static const uint32 types28 [] =
{
SK_REF,
};

static const uint16 attr_flags28 [] =
{0,};

static const EIF_TYPE_INDEX g_atype28_0 [] = {887,795,1055,1057,0xFFFF};

static const EIF_TYPE_INDEX *gtypes28 [] = {
g_atype28_0,
};

static const long offsets28 [] =
{
0,
};

extern const char *names32[];
static const uint32 types32 [] =
{
SK_REF,
};

static const uint16 attr_flags32 [] =
{0,};

static const EIF_TYPE_INDEX g_atype32_0 [] = {1110,1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes32 [] = {
g_atype32_0,
};

static const long offsets32 [] =
{
0,
};

extern const char *names33[];
static const uint32 types33 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags33 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype33_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype33_1 [] = {1109,1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes33 [] = {
g_atype33_0,
g_atype33_1,
};

static const long offsets33 [] =
{
0,
 + @REFACS(1),
};

extern const char *names35[];
static const uint32 types35 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags35 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype35_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_1 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes35 [] = {
g_atype35_0,
g_atype35_1,
g_atype35_2,
g_atype35_3,
g_atype35_4,
g_atype35_5,
};

static const long offsets35 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names37[];
static const uint32 types37 [] =
{
SK_REF,
};

static const uint16 attr_flags37 [] =
{0,};

static const EIF_TYPE_INDEX g_atype37_0 [] = {892,133,0xFFFF};

static const EIF_TYPE_INDEX *gtypes37 [] = {
g_atype37_0,
};

static const long offsets37 [] =
{
0,
};

extern const char *names39[];
static const uint32 types39 [] =
{
SK_UINT32,
};

static const uint16 attr_flags39 [] =
{1,};

static const EIF_TYPE_INDEX g_atype39_0 [] = {1199,0xFFFF};

static const EIF_TYPE_INDEX *gtypes39 [] = {
g_atype39_0,
};

static const long offsets39 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names40[];
static const uint32 types40 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags40 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype40_0 [] = {126,0xFFFF};
static const EIF_TYPE_INDEX g_atype40_1 [] = {22,0xFFFF};
static const EIF_TYPE_INDEX g_atype40_2 [] = {142,0xFFFF};
static const EIF_TYPE_INDEX g_atype40_3 [] = {21,0xFFFF};
static const EIF_TYPE_INDEX g_atype40_4 [] = {20,0xFFFF};
static const EIF_TYPE_INDEX g_atype40_5 [] = {206,0xFFFF};

static const EIF_TYPE_INDEX *gtypes40 [] = {
g_atype40_0,
g_atype40_1,
g_atype40_2,
g_atype40_3,
g_atype40_4,
g_atype40_5,
};

static const long offsets40 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names41[];
static const uint32 types41 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags41 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype41_0 [] = {997,0xFFFF};
static const EIF_TYPE_INDEX g_atype41_1 [] = {1056,0xFFFF};

static const EIF_TYPE_INDEX *gtypes41 [] = {
g_atype41_0,
g_atype41_1,
};

static const long offsets41 [] =
{
0,
 + @REFACS(1),
};

extern const char *names45[];
static const uint32 types45 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags45 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype45_0 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes45 [] = {
g_atype45_0,
g_atype45_1,
g_atype45_2,
};

static const long offsets45 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names46[];
static const uint32 types46 [] =
{
SK_REF,
};

static const uint16 attr_flags46 [] =
{0,};

static const EIF_TYPE_INDEX g_atype46_0 [] = {892,1072,0xFFFF};

static const EIF_TYPE_INDEX *gtypes46 [] = {
g_atype46_0,
};

static const long offsets46 [] =
{
0,
};

extern const char *names59[];
static const uint32 types59 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags59 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype59_0 [] = {1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_1 [] = {1249,0xFFFF};

static const EIF_TYPE_INDEX *gtypes59 [] = {
g_atype59_0,
g_atype59_1,
};

static const long offsets59 [] =
{
0,
 + @REFACS(1),
};

extern const char *names60[];
static const uint32 types60 [] =
{
SK_BOOL,
SK_UINT8,
};

static const uint16 attr_flags60 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype60_0 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_1 [] = {1205,0xFFFF};

static const EIF_TYPE_INDEX *gtypes60 [] = {
g_atype60_0,
g_atype60_1,
};

static const long offsets60 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
};

extern const char *names62[];
static const uint32 types62 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags62 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype62_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_2 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_3 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes62 [] = {
g_atype62_0,
g_atype62_1,
g_atype62_2,
g_atype62_3,
};

static const long offsets62 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
};

extern const char *names63[];
static const uint32 types63 [] =
{
SK_INT32,
};

static const uint16 attr_flags63 [] =
{0,};

static const EIF_TYPE_INDEX g_atype63_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes63 [] = {
g_atype63_0,
};

static const long offsets63 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names65[];
static const uint32 types65 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags65 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype65_0 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes65 [] = {
g_atype65_0,
g_atype65_1,
g_atype65_2,
g_atype65_3,
};

static const long offsets65 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @LNGOFF(0,3,0,0),
};

extern const char *names81[];
static const uint32 types81 [] =
{
SK_REF,
};

static const uint16 attr_flags81 [] =
{0,};

static const EIF_TYPE_INDEX g_atype81_0 [] = {773,0xFFFF};

static const EIF_TYPE_INDEX *gtypes81 [] = {
g_atype81_0,
};

static const long offsets81 [] =
{
0,
};

extern const char *names86[];
static const uint32 types86 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags86 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype86_0 [] = {863,1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype86_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes86 [] = {
g_atype86_0,
g_atype86_1,
};

static const long offsets86 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names87[];
static const uint32 types87 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags87 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype87_0 [] = {892,1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype87_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype87_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes87 [] = {
g_atype87_0,
g_atype87_1,
g_atype87_2,
};

static const long offsets87 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names89[];
static const uint32 types89 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags89 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype89_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes89 [] = {
g_atype89_0,
g_atype89_1,
};

static const long offsets89 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names97[];
static const uint32 types97 [] =
{
SK_UINT64,
};

static const uint16 attr_flags97 [] =
{0,};

static const EIF_TYPE_INDEX g_atype97_0 [] = {1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes97 [] = {
g_atype97_0,
};

static const long offsets97 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names98[];
static const uint32 types98 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags98 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype98_0 [] = {1116,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_1 [] = {1114,1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_3 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_4 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_5 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_6 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_7 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_8 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_9 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_10 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_11 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_13 [] = {1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes98 [] = {
g_atype98_0,
g_atype98_1,
g_atype98_2,
g_atype98_3,
g_atype98_4,
g_atype98_5,
g_atype98_6,
g_atype98_7,
g_atype98_8,
g_atype98_9,
g_atype98_10,
g_atype98_11,
g_atype98_12,
g_atype98_13,
};

static const long offsets98 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
+ @LNGOFF(2,0,0,9),
+ @LNGOFF(2,0,0,10),
+ @I64OFF(2,0,0,11,0,0,0),
};

extern const char *names99[];
static const uint32 types99 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags99 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype99_0 [] = {98,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_1 [] = {204,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes99 [] = {
g_atype99_0,
g_atype99_1,
g_atype99_2,
};

static const long offsets99 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names100[];
static const uint32 types100 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags100 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype100_0 [] = {98,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_1 [] = {205,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes100 [] = {
g_atype100_0,
g_atype100_1,
g_atype100_2,
};

static const long offsets100 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names107[];
static const uint32 types107 [] =
{
SK_REF,
};

static const uint16 attr_flags107 [] =
{0,};

static const EIF_TYPE_INDEX g_atype107_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes107 [] = {
g_atype107_0,
};

static const long offsets107 [] =
{
0,
};

extern const char *names108[];
static const uint32 types108 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags108 [] =
{0,};

static const EIF_TYPE_INDEX g_atype108_0 [] = {1004,0xFFFF};

static const EIF_TYPE_INDEX *gtypes108 [] = {
g_atype108_0,
};

static const long offsets108 [] =
{
+ @CHROFF(0,0),
};

extern const char *names109[];
static const uint32 types109 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags109 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype109_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_1 [] = {108,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes109 [] = {
g_atype109_0,
g_atype109_1,
};

static const long offsets109 [] =
{
0,
 + @REFACS(1),
};

extern const char *names110[];
static const uint32 types110 [] =
{
SK_REF,
SK_CHAR8,
};

static const uint16 attr_flags110 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype110_0 [] = {109,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_1 [] = {1004,0xFFFF};

static const EIF_TYPE_INDEX *gtypes110 [] = {
g_atype110_0,
g_atype110_1,
};

static const long offsets110 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names123[];
static const uint32 types123 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags123 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype123_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_2 [] = {1052,0xFFFF};

static const EIF_TYPE_INDEX *gtypes123 [] = {
g_atype123_0,
g_atype123_1,
g_atype123_2,
};

static const long offsets123 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names124[];
static const uint32 types124 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags124 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype124_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_2 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_3 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_4 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_5 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_6 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_7 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_8 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_9 [] = {822,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_10 [] = {822,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_11 [] = {822,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_12 [] = {822,1057,0xFFFF};

static const EIF_TYPE_INDEX *gtypes124 [] = {
g_atype124_0,
g_atype124_1,
g_atype124_2,
g_atype124_3,
g_atype124_4,
g_atype124_5,
g_atype124_6,
g_atype124_7,
g_atype124_8,
g_atype124_9,
g_atype124_10,
g_atype124_11,
g_atype124_12,
};

static const long offsets124 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
};

extern const char *names125[];
static const uint32 types125 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags125 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype125_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_2 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_3 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_4 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_5 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_6 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_7 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_8 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_9 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_10 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_11 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_15 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes125 [] = {
g_atype125_0,
g_atype125_1,
g_atype125_2,
g_atype125_3,
g_atype125_4,
g_atype125_5,
g_atype125_6,
g_atype125_7,
g_atype125_8,
g_atype125_9,
g_atype125_10,
g_atype125_11,
g_atype125_12,
g_atype125_13,
g_atype125_14,
g_atype125_15,
};

static const long offsets125 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @LNGOFF(12,0,0,0),
+ @LNGOFF(12,0,0,1),
+ @LNGOFF(12,0,0,2),
+ @LNGOFF(12,0,0,3),
};

extern const char *names126[];
static const uint32 types126 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags126 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype126_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_2 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_3 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_4 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_5 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes126 [] = {
g_atype126_0,
g_atype126_1,
g_atype126_2,
g_atype126_3,
g_atype126_4,
g_atype126_5,
g_atype126_6,
};

static const long offsets126 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names127[];
static const uint32 types127 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags127 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype127_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_2 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_3 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_4 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_5 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_6 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_7 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_8 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_9 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_10 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_11 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_12 [] = {822,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_13 [] = {822,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_14 [] = {822,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_15 [] = {822,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_16 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_17 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_18 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_19 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_20 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_21 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_22 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_23 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_24 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_25 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_26 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_27 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_28 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_29 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_30 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_31 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_32 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_33 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_34 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_35 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_36 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_37 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_38 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_39 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes127 [] = {
g_atype127_0,
g_atype127_1,
g_atype127_2,
g_atype127_3,
g_atype127_4,
g_atype127_5,
g_atype127_6,
g_atype127_7,
g_atype127_8,
g_atype127_9,
g_atype127_10,
g_atype127_11,
g_atype127_12,
g_atype127_13,
g_atype127_14,
g_atype127_15,
g_atype127_16,
g_atype127_17,
g_atype127_18,
g_atype127_19,
g_atype127_20,
g_atype127_21,
g_atype127_22,
g_atype127_23,
g_atype127_24,
g_atype127_25,
g_atype127_26,
g_atype127_27,
g_atype127_28,
g_atype127_29,
g_atype127_30,
g_atype127_31,
g_atype127_32,
g_atype127_33,
g_atype127_34,
g_atype127_35,
g_atype127_36,
g_atype127_37,
g_atype127_38,
g_atype127_39,
};

static const long offsets127 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
+ @LNGOFF(35,0,0,0),
+ @LNGOFF(35,0,0,1),
+ @LNGOFF(35,0,0,2),
+ @LNGOFF(35,0,0,3),
+ @LNGOFF(35,0,0,4),
};

extern const char *names128[];
static const uint32 types128 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags128 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype128_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes128 [] = {
g_atype128_0,
g_atype128_1,
g_atype128_2,
g_atype128_3,
};

static const long offsets128 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names129[];
static const uint32 types129 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags129 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype129_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_2 [] = {893,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_3 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes129 [] = {
g_atype129_0,
g_atype129_1,
g_atype129_2,
g_atype129_3,
g_atype129_4,
g_atype129_5,
g_atype129_6,
};

static const long offsets129 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
};

extern const char *names130[];
static const uint32 types130 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags130 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype130_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_2 [] = {893,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_3 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_4 [] = {887,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_5 [] = {893,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_8 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_9 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_12 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes130 [] = {
g_atype130_0,
g_atype130_1,
g_atype130_2,
g_atype130_3,
g_atype130_4,
g_atype130_5,
g_atype130_6,
g_atype130_7,
g_atype130_8,
g_atype130_9,
g_atype130_10,
g_atype130_11,
g_atype130_12,
};

static const long offsets130 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @LNGOFF(6,2,0,1),
+ @LNGOFF(6,2,0,2),
+ @LNGOFF(6,2,0,3),
+ @LNGOFF(6,2,0,4),
};

extern const char *names135[];
static const uint32 types135 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags135 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype135_0 [] = {400,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_1 [] = {19,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_2 [] = {403,0xFFFF};

static const EIF_TYPE_INDEX *gtypes135 [] = {
g_atype135_0,
g_atype135_1,
g_atype135_2,
};

static const long offsets135 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names136[];
static const uint32 types136 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags136 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype136_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_1 [] = {1042,0xFFF9,1,996,353,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_2 [] = {1042,0xFFF9,2,996,353,353,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_3 [] = {1042,0xFFF9,1,996,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_4 [] = {892,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_5 [] = {801,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_11 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes136 [] = {
g_atype136_0,
g_atype136_1,
g_atype136_2,
g_atype136_3,
g_atype136_4,
g_atype136_5,
g_atype136_6,
g_atype136_7,
g_atype136_8,
g_atype136_9,
g_atype136_10,
g_atype136_11,
};

static const long offsets136 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names137[];
static const uint32 types137 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags137 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype137_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_1 [] = {1042,0xFFF9,1,996,353,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_2 [] = {1042,0xFFF9,2,996,353,353,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_3 [] = {1042,0xFFF9,1,996,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_4 [] = {892,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_5 [] = {801,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_11 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes137 [] = {
g_atype137_0,
g_atype137_1,
g_atype137_2,
g_atype137_3,
g_atype137_4,
g_atype137_5,
g_atype137_6,
g_atype137_7,
g_atype137_8,
g_atype137_9,
g_atype137_10,
g_atype137_11,
};

static const long offsets137 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names140[];
static const uint32 types140 [] =
{
SK_REF,
};

static const uint16 attr_flags140 [] =
{0,};

static const EIF_TYPE_INDEX g_atype140_0 [] = {1057,0xFFFF};

static const EIF_TYPE_INDEX *gtypes140 [] = {
g_atype140_0,
};

static const long offsets140 [] =
{
0,
};

extern const char *names141[];
static const uint32 types141 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags141 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype141_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_1 [] = {795,1047,1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_2 [] = {892,1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_3 [] = {795,1047,1214,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_4 [] = {892,1214,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_5 [] = {394,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_6 [] = {98,0xFFFF};

static const EIF_TYPE_INDEX *gtypes141 [] = {
g_atype141_0,
g_atype141_1,
g_atype141_2,
g_atype141_3,
g_atype141_4,
g_atype141_5,
g_atype141_6,
};

static const long offsets141 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
};

extern const char *names143[];
static const uint32 types143 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags143 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype143_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_2 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_3 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_4 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes143 [] = {
g_atype143_0,
g_atype143_1,
g_atype143_2,
g_atype143_3,
g_atype143_4,
g_atype143_5,
};

static const long offsets143 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names144[];
static const uint32 types144 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags144 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype144_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_2 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_3 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_4 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes144 [] = {
g_atype144_0,
g_atype144_1,
g_atype144_2,
g_atype144_3,
g_atype144_4,
g_atype144_5,
};

static const long offsets144 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names146[];
static const uint32 types146 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags146 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype146_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes146 [] = {
g_atype146_0,
g_atype146_1,
g_atype146_2,
};

static const long offsets146 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names147[];
static const uint32 types147 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags147 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype147_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes147 [] = {
g_atype147_0,
g_atype147_1,
g_atype147_2,
};

static const long offsets147 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names151[];
static const uint32 types151 [] =
{
SK_BOOL,
};

static const uint16 attr_flags151 [] =
{0,};

static const EIF_TYPE_INDEX g_atype151_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes151 [] = {
g_atype151_0,
};

static const long offsets151 [] =
{
+ @CHROFF(0,0),
};

extern const char *names155[];
static const uint32 types155 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags155 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype155_0 [] = {967,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_1 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes155 [] = {
g_atype155_0,
g_atype155_1,
};

static const long offsets155 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names161[];
static const uint32 types161 [] =
{
SK_REF,
};

static const uint16 attr_flags161 [] =
{0,};

static const EIF_TYPE_INDEX g_atype161_0 [] = {216,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes161 [] = {
g_atype161_0,
};

static const long offsets161 [] =
{
0,
};

extern const char *names162[];
static const uint32 types162 [] =
{
SK_REF,
};

static const uint16 attr_flags162 [] =
{0,};

static const EIF_TYPE_INDEX g_atype162_0 [] = {216,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes162 [] = {
g_atype162_0,
};

static const long offsets162 [] =
{
0,
};

extern const char *names172[];
static const uint32 types172 [] =
{
SK_REF,
};

static const uint16 attr_flags172 [] =
{0,};

static const EIF_TYPE_INDEX g_atype172_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes172 [] = {
g_atype172_0,
};

static const long offsets172 [] =
{
0,
};

extern const char *names173[];
static const uint32 types173 [] =
{
SK_INT32,
};

static const uint16 attr_flags173 [] =
{0,};

static const EIF_TYPE_INDEX g_atype173_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes173 [] = {
g_atype173_0,
};

static const long offsets173 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names174[];
static const uint32 types174 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags174 [] =
{0,};

static const EIF_TYPE_INDEX g_atype174_0 [] = {1001,0xFFFF};

static const EIF_TYPE_INDEX *gtypes174 [] = {
g_atype174_0,
};

static const long offsets174 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names175[];
static const uint32 types175 [] =
{
SK_BOOL,
};

static const uint16 attr_flags175 [] =
{0,};

static const EIF_TYPE_INDEX g_atype175_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes175 [] = {
g_atype175_0,
};

static const long offsets175 [] =
{
+ @CHROFF(0,0),
};

extern const char *names176[];
static const uint32 types176 [] =
{
SK_UINT64,
};

static const uint16 attr_flags176 [] =
{0,};

static const EIF_TYPE_INDEX g_atype176_0 [] = {1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes176 [] = {
g_atype176_0,
};

static const long offsets176 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names177[];
static const uint32 types177 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags177 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype177_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_1 [] = {176,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes177 [] = {
g_atype177_0,
g_atype177_1,
};

static const long offsets177 [] =
{
0,
 + @REFACS(1),
};

extern const char *names178[];
static const uint32 types178 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags178 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype178_0 [] = {177,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes178 [] = {
g_atype178_0,
g_atype178_1,
};

static const long offsets178 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names180[];
static const uint32 types180 [] =
{
SK_REF,
};

static const uint16 attr_flags180 [] =
{0,};

static const EIF_TYPE_INDEX g_atype180_0 [] = {1056,0xFFFF};

static const EIF_TYPE_INDEX *gtypes180 [] = {
g_atype180_0,
};

static const long offsets180 [] =
{
0,
};

extern const char *names184[];
static const uint32 types184 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags184 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype184_0 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_1 [] = {892,550,0xFFFF};

static const EIF_TYPE_INDEX *gtypes184 [] = {
g_atype184_0,
g_atype184_1,
};

static const long offsets184 [] =
{
0,
 + @REFACS(1),
};

extern const char *names186[];
static const uint32 types186 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags186 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype186_0 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_1 [] = {892,0xFFF9,2,996,1047,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_2 [] = {892,0xFFF9,2,996,1047,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_4 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes186 [] = {
g_atype186_0,
g_atype186_1,
g_atype186_2,
g_atype186_3,
g_atype186_4,
};

static const long offsets186 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names187[];
static const uint32 types187 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags187 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype187_0 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_1 [] = {892,0xFFF9,2,996,1047,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_2 [] = {892,0xFFF9,2,996,1047,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_3 [] = {782,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_5 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes187 [] = {
g_atype187_0,
g_atype187_1,
g_atype187_2,
g_atype187_3,
g_atype187_4,
g_atype187_5,
};

static const long offsets187 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
};

extern const char *names188[];
static const uint32 types188 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags188 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype188_0 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_1 [] = {892,0xFFF9,2,996,1047,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_2 [] = {892,0xFFF9,2,996,1047,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_3 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_4 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_6 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes188 [] = {
g_atype188_0,
g_atype188_1,
g_atype188_2,
g_atype188_3,
g_atype188_4,
g_atype188_5,
g_atype188_6,
};

static const long offsets188 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
};

extern const char *names194[];
static const uint32 types194 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags194 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype194_0 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_1 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes194 [] = {
g_atype194_0,
g_atype194_1,
};

static const long offsets194 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names197[];
static const uint32 types197 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags197 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype197_0 [] = {193,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_1 [] = {437,0xFFFF};

static const EIF_TYPE_INDEX *gtypes197 [] = {
g_atype197_0,
g_atype197_1,
};

static const long offsets197 [] =
{
0,
 + @REFACS(1),
};

extern const char *names205[];
static const uint32 types205 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags205 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype205_0 [] = {771,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes205 [] = {
g_atype205_0,
g_atype205_1,
g_atype205_2,
g_atype205_3,
};

static const long offsets205 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names206[];
static const uint32 types206 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags206 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype206_0 [] = {771,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_1 [] = {0xFFF9,2,996,1187,863,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_2 [] = {0xFFF9,2,996,1187,863,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_14 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes206 [] = {
g_atype206_0,
g_atype206_1,
g_atype206_2,
g_atype206_3,
g_atype206_4,
g_atype206_5,
g_atype206_6,
g_atype206_7,
g_atype206_8,
g_atype206_9,
g_atype206_10,
g_atype206_11,
g_atype206_12,
g_atype206_13,
g_atype206_14,
};

static const long offsets206 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @LNGOFF(3,5,0,0),
+ @LNGOFF(3,5,0,1),
+ @LNGOFF(3,5,0,2),
+ @LNGOFF(3,5,0,3),
+ @LNGOFF(3,5,0,4),
+ @LNGOFF(3,5,0,5),
+ @LNGOFF(3,5,0,6),
};

extern const char *names207[];
static const uint32 types207 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags207 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype207_0 [] = {1045,0xFFF9,1,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes207 [] = {
g_atype207_0,
g_atype207_1,
g_atype207_2,
};

static const long offsets207 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names208[];
static const uint32 types208 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags208 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype208_0 [] = {1045,0xFFF9,1,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_1 [] = {822,348,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes208 [] = {
g_atype208_0,
g_atype208_1,
g_atype208_2,
g_atype208_3,
g_atype208_4,
};

static const long offsets208 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names209[];
static const uint32 types209 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags209 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype209_0 [] = {1045,0xFFF9,1,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes209 [] = {
g_atype209_0,
g_atype209_1,
g_atype209_2,
};

static const long offsets209 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names218[];
static const uint32 types218 [] =
{
SK_REF,
};

static const uint16 attr_flags218 [] =
{0,};

static const EIF_TYPE_INDEX g_atype218_0 [] = {216,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes218 [] = {
g_atype218_0,
};

static const long offsets218 [] =
{
0,
};

extern const char *names220[];
static const uint32 types220 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags220 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype220_0 [] = {145,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_1 [] = {892,40,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_2 [] = {892,1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_3 [] = {147,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_11 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_12 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_13 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_14 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_15 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes220 [] = {
g_atype220_0,
g_atype220_1,
g_atype220_2,
g_atype220_3,
g_atype220_4,
g_atype220_5,
g_atype220_6,
g_atype220_7,
g_atype220_8,
g_atype220_9,
g_atype220_10,
g_atype220_11,
g_atype220_12,
g_atype220_13,
g_atype220_14,
g_atype220_15,
};

static const long offsets220 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @CHROFF(4,7),
+ @CHROFF(4,8),
+ @CHROFF(4,9),
+ @CHROFF(4,10),
+ @CHROFF(4,11),
};

extern const char *names221[];
static const uint32 types221 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags221 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype221_0 [] = {145,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_1 [] = {892,40,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_2 [] = {892,1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_3 [] = {147,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_11 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_12 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_13 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_14 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_15 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes221 [] = {
g_atype221_0,
g_atype221_1,
g_atype221_2,
g_atype221_3,
g_atype221_4,
g_atype221_5,
g_atype221_6,
g_atype221_7,
g_atype221_8,
g_atype221_9,
g_atype221_10,
g_atype221_11,
g_atype221_12,
g_atype221_13,
g_atype221_14,
g_atype221_15,
};

static const long offsets221 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @CHROFF(4,7),
+ @CHROFF(4,8),
+ @CHROFF(4,9),
+ @CHROFF(4,10),
+ @CHROFF(4,11),
};

extern const char *names222[];
static const uint32 types222 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags222 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype222_0 [] = {145,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_1 [] = {892,40,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_2 [] = {892,1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_3 [] = {147,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_11 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_12 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_13 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_14 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_15 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes222 [] = {
g_atype222_0,
g_atype222_1,
g_atype222_2,
g_atype222_3,
g_atype222_4,
g_atype222_5,
g_atype222_6,
g_atype222_7,
g_atype222_8,
g_atype222_9,
g_atype222_10,
g_atype222_11,
g_atype222_12,
g_atype222_13,
g_atype222_14,
g_atype222_15,
};

static const long offsets222 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @CHROFF(4,7),
+ @CHROFF(4,8),
+ @CHROFF(4,9),
+ @CHROFF(4,10),
+ @CHROFF(4,11),
};

extern const char *names223[];
static const uint32 types223 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags223 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype223_0 [] = {145,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_1 [] = {892,40,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_2 [] = {892,1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_3 [] = {147,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_11 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_12 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_13 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_14 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_15 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes223 [] = {
g_atype223_0,
g_atype223_1,
g_atype223_2,
g_atype223_3,
g_atype223_4,
g_atype223_5,
g_atype223_6,
g_atype223_7,
g_atype223_8,
g_atype223_9,
g_atype223_10,
g_atype223_11,
g_atype223_12,
g_atype223_13,
g_atype223_14,
g_atype223_15,
};

static const long offsets223 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @CHROFF(4,7),
+ @CHROFF(4,8),
+ @CHROFF(4,9),
+ @CHROFF(4,10),
+ @CHROFF(4,11),
};

extern const char *names225[];
static const uint32 types225 [] =
{
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags225 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype225_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_1 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes225 [] = {
g_atype225_0,
g_atype225_1,
g_atype225_2,
g_atype225_3,
};

static const long offsets225 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names227[];
static const uint32 types227 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_UINT32,
};

static const uint16 attr_flags227 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype227_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_1 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_3 [] = {1199,0xFFFF};

static const EIF_TYPE_INDEX *gtypes227 [] = {
g_atype227_0,
g_atype227_1,
g_atype227_2,
g_atype227_3,
};

static const long offsets227 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names228[];
static const uint32 types228 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_UINT32,
};

static const uint16 attr_flags228 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype228_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_1 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_3 [] = {1199,0xFFFF};

static const EIF_TYPE_INDEX *gtypes228 [] = {
g_atype228_0,
g_atype228_1,
g_atype228_2,
g_atype228_3,
};

static const long offsets228 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names230[];
static const uint32 types230 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags230 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype230_0 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_1 [] = {917,0xFFFF};

static const EIF_TYPE_INDEX *gtypes230 [] = {
g_atype230_0,
g_atype230_1,
};

static const long offsets230 [] =
{
0,
 + @REFACS(1),
};

extern const char *names231[];
static const uint32 types231 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags231 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype231_0 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_2 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_3 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes231 [] = {
g_atype231_0,
g_atype231_1,
g_atype231_2,
g_atype231_3,
};

static const long offsets231 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
};

extern const char *names235[];
static const uint32 types235 [] =
{
SK_BOOL,
};

static const uint16 attr_flags235 [] =
{0,};

static const EIF_TYPE_INDEX g_atype235_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes235 [] = {
g_atype235_0,
};

static const long offsets235 [] =
{
+ @CHROFF(0,0),
};

extern const char *names238[];
static const uint32 types238 [] =
{
SK_BOOL,
};

static const uint16 attr_flags238 [] =
{0,};

static const EIF_TYPE_INDEX g_atype238_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes238 [] = {
g_atype238_0,
};

static const long offsets238 [] =
{
+ @CHROFF(0,0),
};

extern const char *names244[];
static const uint32 types244 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags244 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype244_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_1 [] = {1108,1109,1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes244 [] = {
g_atype244_0,
g_atype244_1,
};

static const long offsets244 [] =
{
0,
 + @REFACS(1),
};

extern const char *names245[];
static const uint32 types245 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags245 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype245_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_1 [] = {1108,1109,1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes245 [] = {
g_atype245_0,
g_atype245_1,
};

static const long offsets245 [] =
{
0,
 + @REFACS(1),
};

extern const char *names246[];
static const uint32 types246 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags246 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype246_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_1 [] = {1108,1109,1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes246 [] = {
g_atype246_0,
g_atype246_1,
};

static const long offsets246 [] =
{
0,
 + @REFACS(1),
};

extern const char *names248[];
static const uint32 types248 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags248 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype248_0 [] = {1113,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_1 [] = {1113,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_2 [] = {1113,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_3 [] = {1113,1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes248 [] = {
g_atype248_0,
g_atype248_1,
g_atype248_2,
g_atype248_3,
};

static const long offsets248 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names249[];
static const uint32 types249 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags249 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype249_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes249 [] = {
g_atype249_0,
g_atype249_1,
g_atype249_2,
g_atype249_3,
g_atype249_4,
g_atype249_5,
g_atype249_6,
};

static const long offsets249 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
};

extern const char *names250[];
static const uint32 types250 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags250 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype250_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_2 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_9 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_10 [] = {1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes250 [] = {
g_atype250_0,
g_atype250_1,
g_atype250_2,
g_atype250_3,
g_atype250_4,
g_atype250_5,
g_atype250_6,
g_atype250_7,
g_atype250_8,
g_atype250_9,
g_atype250_10,
};

static const long offsets250 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @I64OFF(2,4,0,3,0,0,0),
+ @I64OFF(2,4,0,3,0,0,1),
};

extern const char *names251[];
static const uint32 types251 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags251 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype251_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_12 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_13 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_14 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes251 [] = {
g_atype251_0,
g_atype251_1,
g_atype251_2,
g_atype251_3,
g_atype251_4,
g_atype251_5,
g_atype251_6,
g_atype251_7,
g_atype251_8,
g_atype251_9,
g_atype251_10,
g_atype251_11,
g_atype251_12,
g_atype251_13,
g_atype251_14,
};

static const long offsets251 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @R64OFF(2,6,0,4,0,0,0,0),
+ @R64OFF(2,6,0,4,0,0,0,1),
+ @R64OFF(2,6,0,4,0,0,0,2),
};

extern const char *names252[];
static const uint32 types252 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags252 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype252_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_8 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_9 [] = {1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes252 [] = {
g_atype252_0,
g_atype252_1,
g_atype252_2,
g_atype252_3,
g_atype252_4,
g_atype252_5,
g_atype252_6,
g_atype252_7,
g_atype252_8,
g_atype252_9,
};

static const long offsets252 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
+ @LNGOFF(2,3,0,1),
+ @LNGOFF(2,3,0,2),
+ @I64OFF(2,3,0,3,0,0,0),
+ @I64OFF(2,3,0,3,0,0,1),
};

extern const char *names259[];
static const uint32 types259 [] =
{
SK_REF,
};

static const uint16 attr_flags259 [] =
{0,};

static const EIF_TYPE_INDEX g_atype259_0 [] = {268,0xFFFF};

static const EIF_TYPE_INDEX *gtypes259 [] = {
g_atype259_0,
};

static const long offsets259 [] =
{
0,
};

extern const char *names260[];
static const uint32 types260 [] =
{
SK_REF,
};

static const uint16 attr_flags260 [] =
{0,};

static const EIF_TYPE_INDEX g_atype260_0 [] = {268,0xFFFF};

static const EIF_TYPE_INDEX *gtypes260 [] = {
g_atype260_0,
};

static const long offsets260 [] =
{
0,
};

extern const char *names261[];
static const uint32 types261 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags261 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype261_0 [] = {116,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_9 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes261 [] = {
g_atype261_0,
g_atype261_1,
g_atype261_2,
g_atype261_3,
g_atype261_4,
g_atype261_5,
g_atype261_6,
g_atype261_7,
g_atype261_8,
g_atype261_9,
};

static const long offsets261 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names262[];
static const uint32 types262 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags262 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype262_0 [] = {116,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_9 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes262 [] = {
g_atype262_0,
g_atype262_1,
g_atype262_2,
g_atype262_3,
g_atype262_4,
g_atype262_5,
g_atype262_6,
g_atype262_7,
g_atype262_8,
g_atype262_9,
};

static const long offsets262 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names263[];
static const uint32 types263 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags263 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype263_0 [] = {407,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_9 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes263 [] = {
g_atype263_0,
g_atype263_1,
g_atype263_2,
g_atype263_3,
g_atype263_4,
g_atype263_5,
g_atype263_6,
g_atype263_7,
g_atype263_8,
g_atype263_9,
};

static const long offsets263 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names264[];
static const uint32 types264 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags264 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype264_0 [] = {116,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_1 [] = {960,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_11 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes264 [] = {
g_atype264_0,
g_atype264_1,
g_atype264_2,
g_atype264_3,
g_atype264_4,
g_atype264_5,
g_atype264_6,
g_atype264_7,
g_atype264_8,
g_atype264_9,
g_atype264_10,
g_atype264_11,
};

static const long offsets264 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
};

extern const char *names265[];
static const uint32 types265 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags265 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype265_0 [] = {116,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_1 [] = {960,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_13 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes265 [] = {
g_atype265_0,
g_atype265_1,
g_atype265_2,
g_atype265_3,
g_atype265_4,
g_atype265_5,
g_atype265_6,
g_atype265_7,
g_atype265_8,
g_atype265_9,
g_atype265_10,
g_atype265_11,
g_atype265_12,
g_atype265_13,
};

static const long offsets265 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
+ @LNGOFF(2,4,0,6),
+ @LNGOFF(2,4,0,7),
};

extern const char *names266[];
static const uint32 types266 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags266 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype266_0 [] = {407,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_1 [] = {960,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_14 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes266 [] = {
g_atype266_0,
g_atype266_1,
g_atype266_2,
g_atype266_3,
g_atype266_4,
g_atype266_5,
g_atype266_6,
g_atype266_7,
g_atype266_8,
g_atype266_9,
g_atype266_10,
g_atype266_11,
g_atype266_12,
g_atype266_13,
g_atype266_14,
};

static const long offsets266 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @LNGOFF(2,5,0,0),
+ @LNGOFF(2,5,0,1),
+ @LNGOFF(2,5,0,2),
+ @LNGOFF(2,5,0,3),
+ @LNGOFF(2,5,0,4),
+ @LNGOFF(2,5,0,5),
+ @LNGOFF(2,5,0,6),
+ @LNGOFF(2,5,0,7),
};

extern const char *names268[];
static const uint32 types268 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags268 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype268_0 [] = {268,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_1 [] = {258,0xFFFF};

static const EIF_TYPE_INDEX *gtypes268 [] = {
g_atype268_0,
g_atype268_1,
};

static const long offsets268 [] =
{
0,
 + @REFACS(1),
};

extern const char *names270[];
static const uint32 types270 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
};

static const uint16 attr_flags270 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype270_0 [] = {258,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_2 [] = {274,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_3 [] = {1066,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_4 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_8 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_9 [] = {1001,0xFFFF};

static const EIF_TYPE_INDEX *gtypes270 [] = {
g_atype270_0,
g_atype270_1,
g_atype270_2,
g_atype270_3,
g_atype270_4,
g_atype270_5,
g_atype270_6,
g_atype270_7,
g_atype270_8,
g_atype270_9,
};

static const long offsets270 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
};

extern const char *names271[];
static const uint32 types271 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags271 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype271_0 [] = {258,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_2 [] = {274,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_3 [] = {1066,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_4 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_10 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_11 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_14 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes271 [] = {
g_atype271_0,
g_atype271_1,
g_atype271_2,
g_atype271_3,
g_atype271_4,
g_atype271_5,
g_atype271_6,
g_atype271_7,
g_atype271_8,
g_atype271_9,
g_atype271_10,
g_atype271_11,
g_atype271_12,
g_atype271_13,
g_atype271_14,
};

static const long offsets271 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
+ @LNGOFF(5,5,0,1),
+ @LNGOFF(5,5,0,2),
+ @LNGOFF(5,5,0,3),
+ @LNGOFF(5,5,0,4),
};

extern const char *names272[];
static const uint32 types272 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags272 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype272_0 [] = {268,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_1 [] = {258,0xFFFF};

static const EIF_TYPE_INDEX *gtypes272 [] = {
g_atype272_0,
g_atype272_1,
};

static const long offsets272 [] =
{
0,
 + @REFACS(1),
};

extern const char *names273[];
static const uint32 types273 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags273 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype273_0 [] = {268,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_1 [] = {258,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_2 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_3 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_4 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_5 [] = {744,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_6 [] = {744,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_7 [] = {744,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_8 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes273 [] = {
g_atype273_0,
g_atype273_1,
g_atype273_2,
g_atype273_3,
g_atype273_4,
g_atype273_5,
g_atype273_6,
g_atype273_7,
g_atype273_8,
};

static const long offsets273 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
};

extern const char *names274[];
static const uint32 types274 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags274 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype274_0 [] = {268,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_1 [] = {258,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_2 [] = {905,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_3 [] = {905,1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes274 [] = {
g_atype274_0,
g_atype274_1,
g_atype274_2,
g_atype274_3,
};

static const long offsets274 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names276[];
static const uint32 types276 [] =
{
SK_REF,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags276 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype276_0 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_2 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes276 [] = {
g_atype276_0,
g_atype276_1,
g_atype276_2,
g_atype276_3,
g_atype276_4,
g_atype276_5,
g_atype276_6,
};

static const long offsets276 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names277[];
static const uint32 types277 [] =
{
SK_REF,
};

static const uint16 attr_flags277 [] =
{0,};

static const EIF_TYPE_INDEX g_atype277_0 [] = {278,0xFFFF};

static const EIF_TYPE_INDEX *gtypes277 [] = {
g_atype277_0,
};

static const long offsets277 [] =
{
0,
};

extern const char *names278[];
static const uint32 types278 [] =
{
SK_REF,
SK_UINT32,
};

static const uint16 attr_flags278 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype278_0 [] = {278,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_1 [] = {1199,0xFFFF};

static const EIF_TYPE_INDEX *gtypes278 [] = {
g_atype278_0,
g_atype278_1,
};

static const long offsets278 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names282[];
static const uint32 types282 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags282 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype282_0 [] = {176,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes282 [] = {
g_atype282_0,
g_atype282_1,
g_atype282_2,
};

static const long offsets282 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names283[];
static const uint32 types283 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags283 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype283_0 [] = {177,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes283 [] = {
g_atype283_0,
g_atype283_1,
g_atype283_2,
};

static const long offsets283 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names284[];
static const uint32 types284 [] =
{
SK_INT32,
};

static const uint16 attr_flags284 [] =
{0,};

static const EIF_TYPE_INDEX g_atype284_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes284 [] = {
g_atype284_0,
};

static const long offsets284 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names285[];
static const uint32 types285 [] =
{
SK_INT32,
};

static const uint16 attr_flags285 [] =
{0,};

static const EIF_TYPE_INDEX g_atype285_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes285 [] = {
g_atype285_0,
};

static const long offsets285 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names287[];
static const uint32 types287 [] =
{
SK_REF,
};

static const uint16 attr_flags287 [] =
{0,};

static const EIF_TYPE_INDEX g_atype287_0 [] = {908,0xFFFF};

static const EIF_TYPE_INDEX *gtypes287 [] = {
g_atype287_0,
};

static const long offsets287 [] =
{
0,
};

extern const char *names290[];
static const uint32 types290 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags290 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype290_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes290 [] = {
g_atype290_0,
g_atype290_1,
g_atype290_2,
g_atype290_3,
g_atype290_4,
g_atype290_5,
g_atype290_6,
};

static const long offsets290 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names291[];
static const uint32 types291 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags291 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype291_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes291 [] = {
g_atype291_0,
g_atype291_1,
g_atype291_2,
g_atype291_3,
g_atype291_4,
g_atype291_5,
g_atype291_6,
};

static const long offsets291 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names292[];
static const uint32 types292 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags292 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype292_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes292 [] = {
g_atype292_0,
g_atype292_1,
g_atype292_2,
g_atype292_3,
g_atype292_4,
g_atype292_5,
g_atype292_6,
};

static const long offsets292 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names293[];
static const uint32 types293 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags293 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype293_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes293 [] = {
g_atype293_0,
g_atype293_1,
g_atype293_2,
g_atype293_3,
g_atype293_4,
g_atype293_5,
g_atype293_6,
};

static const long offsets293 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names294[];
static const uint32 types294 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags294 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype294_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes294 [] = {
g_atype294_0,
g_atype294_1,
g_atype294_2,
g_atype294_3,
g_atype294_4,
g_atype294_5,
g_atype294_6,
};

static const long offsets294 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names295[];
static const uint32 types295 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags295 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype295_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_7 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes295 [] = {
g_atype295_0,
g_atype295_1,
g_atype295_2,
g_atype295_3,
g_atype295_4,
g_atype295_5,
g_atype295_6,
g_atype295_7,
};

static const long offsets295 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names296[];
static const uint32 types296 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags296 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype296_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_7 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes296 [] = {
g_atype296_0,
g_atype296_1,
g_atype296_2,
g_atype296_3,
g_atype296_4,
g_atype296_5,
g_atype296_6,
g_atype296_7,
};

static const long offsets296 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names297[];
static const uint32 types297 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags297 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype297_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_5 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_9 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes297 [] = {
g_atype297_0,
g_atype297_1,
g_atype297_2,
g_atype297_3,
g_atype297_4,
g_atype297_5,
g_atype297_6,
g_atype297_7,
g_atype297_8,
g_atype297_9,
};

static const long offsets297 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
+ @LNGOFF(6,1,0,2),
};

extern const char *names298[];
static const uint32 types298 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags298 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype298_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes298 [] = {
g_atype298_0,
g_atype298_1,
g_atype298_2,
g_atype298_3,
g_atype298_4,
g_atype298_5,
g_atype298_6,
};

static const long offsets298 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names299[];
static const uint32 types299 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags299 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype299_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes299 [] = {
g_atype299_0,
g_atype299_1,
g_atype299_2,
g_atype299_3,
g_atype299_4,
g_atype299_5,
g_atype299_6,
};

static const long offsets299 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names300[];
static const uint32 types300 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags300 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype300_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes300 [] = {
g_atype300_0,
g_atype300_1,
g_atype300_2,
g_atype300_3,
g_atype300_4,
g_atype300_5,
g_atype300_6,
};

static const long offsets300 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names301[];
static const uint32 types301 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags301 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype301_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes301 [] = {
g_atype301_0,
g_atype301_1,
g_atype301_2,
g_atype301_3,
g_atype301_4,
g_atype301_5,
g_atype301_6,
};

static const long offsets301 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names302[];
static const uint32 types302 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags302 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype302_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes302 [] = {
g_atype302_0,
g_atype302_1,
g_atype302_2,
g_atype302_3,
g_atype302_4,
g_atype302_5,
g_atype302_6,
};

static const long offsets302 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names303[];
static const uint32 types303 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags303 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype303_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes303 [] = {
g_atype303_0,
g_atype303_1,
g_atype303_2,
g_atype303_3,
g_atype303_4,
g_atype303_5,
g_atype303_6,
};

static const long offsets303 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names304[];
static const uint32 types304 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags304 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype304_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes304 [] = {
g_atype304_0,
g_atype304_1,
g_atype304_2,
g_atype304_3,
g_atype304_4,
g_atype304_5,
g_atype304_6,
};

static const long offsets304 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names305[];
static const uint32 types305 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags305 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype305_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes305 [] = {
g_atype305_0,
g_atype305_1,
g_atype305_2,
g_atype305_3,
g_atype305_4,
g_atype305_5,
g_atype305_6,
};

static const long offsets305 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names306[];
static const uint32 types306 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags306 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype306_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_7 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes306 [] = {
g_atype306_0,
g_atype306_1,
g_atype306_2,
g_atype306_3,
g_atype306_4,
g_atype306_5,
g_atype306_6,
g_atype306_7,
};

static const long offsets306 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names307[];
static const uint32 types307 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags307 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype307_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes307 [] = {
g_atype307_0,
g_atype307_1,
g_atype307_2,
g_atype307_3,
g_atype307_4,
g_atype307_5,
g_atype307_6,
};

static const long offsets307 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names308[];
static const uint32 types308 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags308 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype308_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes308 [] = {
g_atype308_0,
g_atype308_1,
g_atype308_2,
g_atype308_3,
g_atype308_4,
g_atype308_5,
g_atype308_6,
};

static const long offsets308 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names309[];
static const uint32 types309 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags309 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype309_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes309 [] = {
g_atype309_0,
g_atype309_1,
g_atype309_2,
g_atype309_3,
g_atype309_4,
g_atype309_5,
g_atype309_6,
};

static const long offsets309 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names310[];
static const uint32 types310 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags310 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype310_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes310 [] = {
g_atype310_0,
g_atype310_1,
g_atype310_2,
g_atype310_3,
g_atype310_4,
g_atype310_5,
g_atype310_6,
};

static const long offsets310 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names311[];
static const uint32 types311 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags311 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype311_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_7 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes311 [] = {
g_atype311_0,
g_atype311_1,
g_atype311_2,
g_atype311_3,
g_atype311_4,
g_atype311_5,
g_atype311_6,
g_atype311_7,
};

static const long offsets311 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names312[];
static const uint32 types312 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags312 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype312_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes312 [] = {
g_atype312_0,
g_atype312_1,
g_atype312_2,
g_atype312_3,
g_atype312_4,
g_atype312_5,
g_atype312_6,
};

static const long offsets312 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names313[];
static const uint32 types313 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags313 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype313_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes313 [] = {
g_atype313_0,
g_atype313_1,
g_atype313_2,
g_atype313_3,
g_atype313_4,
g_atype313_5,
g_atype313_6,
};

static const long offsets313 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names314[];
static const uint32 types314 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags314 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype314_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_8 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes314 [] = {
g_atype314_0,
g_atype314_1,
g_atype314_2,
g_atype314_3,
g_atype314_4,
g_atype314_5,
g_atype314_6,
g_atype314_7,
g_atype314_8,
};

static const long offsets314 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
};

extern const char *names315[];
static const uint32 types315 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags315 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype315_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes315 [] = {
g_atype315_0,
g_atype315_1,
g_atype315_2,
g_atype315_3,
g_atype315_4,
g_atype315_5,
g_atype315_6,
};

static const long offsets315 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names316[];
static const uint32 types316 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags316 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype316_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes316 [] = {
g_atype316_0,
g_atype316_1,
g_atype316_2,
g_atype316_3,
g_atype316_4,
g_atype316_5,
g_atype316_6,
};

static const long offsets316 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names317[];
static const uint32 types317 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags317 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype317_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes317 [] = {
g_atype317_0,
g_atype317_1,
g_atype317_2,
g_atype317_3,
g_atype317_4,
g_atype317_5,
g_atype317_6,
};

static const long offsets317 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names318[];
static const uint32 types318 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags318 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype318_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes318 [] = {
g_atype318_0,
g_atype318_1,
g_atype318_2,
g_atype318_3,
g_atype318_4,
g_atype318_5,
g_atype318_6,
};

static const long offsets318 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names319[];
static const uint32 types319 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags319 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype319_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_5 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_6 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_8 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes319 [] = {
g_atype319_0,
g_atype319_1,
g_atype319_2,
g_atype319_3,
g_atype319_4,
g_atype319_5,
g_atype319_6,
g_atype319_7,
g_atype319_8,
};

static const long offsets319 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names320[];
static const uint32 types320 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags320 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype320_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes320 [] = {
g_atype320_0,
g_atype320_1,
g_atype320_2,
g_atype320_3,
g_atype320_4,
g_atype320_5,
g_atype320_6,
};

static const long offsets320 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names321[];
static const uint32 types321 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags321 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype321_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes321 [] = {
g_atype321_0,
g_atype321_1,
g_atype321_2,
g_atype321_3,
g_atype321_4,
g_atype321_5,
g_atype321_6,
};

static const long offsets321 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names322[];
static const uint32 types322 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags322 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype322_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes322 [] = {
g_atype322_0,
g_atype322_1,
g_atype322_2,
g_atype322_3,
g_atype322_4,
g_atype322_5,
g_atype322_6,
};

static const long offsets322 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names323[];
static const uint32 types323 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags323 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype323_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes323 [] = {
g_atype323_0,
g_atype323_1,
g_atype323_2,
g_atype323_3,
g_atype323_4,
g_atype323_5,
g_atype323_6,
};

static const long offsets323 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names324[];
static const uint32 types324 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags324 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype324_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes324 [] = {
g_atype324_0,
g_atype324_1,
g_atype324_2,
g_atype324_3,
g_atype324_4,
g_atype324_5,
g_atype324_6,
};

static const long offsets324 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names325[];
static const uint32 types325 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags325 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype325_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes325 [] = {
g_atype325_0,
g_atype325_1,
g_atype325_2,
g_atype325_3,
g_atype325_4,
g_atype325_5,
g_atype325_6,
};

static const long offsets325 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names326[];
static const uint32 types326 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags326 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype326_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes326 [] = {
g_atype326_0,
g_atype326_1,
g_atype326_2,
g_atype326_3,
g_atype326_4,
g_atype326_5,
g_atype326_6,
};

static const long offsets326 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names327[];
static const uint32 types327 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags327 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype327_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes327 [] = {
g_atype327_0,
g_atype327_1,
g_atype327_2,
g_atype327_3,
g_atype327_4,
g_atype327_5,
g_atype327_6,
};

static const long offsets327 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names328[];
static const uint32 types328 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags328 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype328_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_7 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes328 [] = {
g_atype328_0,
g_atype328_1,
g_atype328_2,
g_atype328_3,
g_atype328_4,
g_atype328_5,
g_atype328_6,
g_atype328_7,
};

static const long offsets328 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names329[];
static const uint32 types329 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags329 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype329_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes329 [] = {
g_atype329_0,
g_atype329_1,
g_atype329_2,
g_atype329_3,
g_atype329_4,
g_atype329_5,
g_atype329_6,
};

static const long offsets329 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names330[];
static const uint32 types330 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags330 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype330_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_2 [] = {289,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_3 [] = {409,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes330 [] = {
g_atype330_0,
g_atype330_1,
g_atype330_2,
g_atype330_3,
g_atype330_4,
g_atype330_5,
g_atype330_6,
};

static const long offsets330 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names332[];
static const uint32 types332 [] =
{
SK_REF,
};

static const uint16 attr_flags332 [] =
{0,};

static const EIF_TYPE_INDEX g_atype332_0 [] = {1043,0xFFF9,1,996,1294,1057,0xFFFF};

static const EIF_TYPE_INDEX *gtypes332 [] = {
g_atype332_0,
};

static const long offsets332 [] =
{
0,
};

extern const char *names333[];
static const uint32 types333 [] =
{
SK_REF,
};

static const uint16 attr_flags333 [] =
{0,};

static const EIF_TYPE_INDEX g_atype333_0 [] = {1057,0xFFFF};

static const EIF_TYPE_INDEX *gtypes333 [] = {
g_atype333_0,
};

static const long offsets333 [] =
{
0,
};

extern const char *names334[];
static const uint32 types334 [] =
{
SK_REF,
};

static const uint16 attr_flags334 [] =
{0,};

static const EIF_TYPE_INDEX g_atype334_0 [] = {1043,0xFFF9,1,996,1292,1057,0xFFFF};

static const EIF_TYPE_INDEX *gtypes334 [] = {
g_atype334_0,
};

static const long offsets334 [] =
{
0,
};

extern const char *names335[];
static const uint32 types335 [] =
{
SK_REF,
};

static const uint16 attr_flags335 [] =
{0,};

static const EIF_TYPE_INDEX g_atype335_0 [] = {887,330,0xFFFF};

static const EIF_TYPE_INDEX *gtypes335 [] = {
g_atype335_0,
};

static const long offsets335 [] =
{
0,
};

extern const char *names337[];
static const uint32 types337 [] =
{
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_UINT64,
};

static const uint16 attr_flags337 [] =
{0,0,1,1,};

static const EIF_TYPE_INDEX g_atype337_0 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_2 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_3 [] = {1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes337 [] = {
g_atype337_0,
g_atype337_1,
g_atype337_2,
g_atype337_3,
};

static const long offsets337 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @PTROFF(0,1,0,1,0,0),
+ @I64OFF(0,1,0,1,0,1,0),
};

extern const char *names343[];
static const uint32 types343 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags343 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype343_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_1 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes343 [] = {
g_atype343_0,
g_atype343_1,
};

static const long offsets343 [] =
{
0,
 + @REFACS(1),
};

extern const char *names345[];
static const uint32 types345 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags345 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype345_0 [] = {1297,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_1 [] = {345,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_2 [] = {346,0xFFFF};

static const EIF_TYPE_INDEX *gtypes345 [] = {
g_atype345_0,
g_atype345_1,
g_atype345_2,
};

static const long offsets345 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names346[];
static const uint32 types346 [] =
{
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags346 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype346_0 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_2 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes346 [] = {
g_atype346_0,
g_atype346_1,
g_atype346_2,
};

static const long offsets346 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @R64OFF(0,0,0,2,0,0,0,0),
};

extern const char *names347[];
static const uint32 types347 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags347 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype347_0 [] = {1294,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes347 [] = {
g_atype347_0,
g_atype347_1,
g_atype347_2,
g_atype347_3,
};

static const long offsets347 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names349[];
static const uint32 types349 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags349 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype349_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_2 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_3 [] = {822,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_4 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_5 [] = {1057,0xFFFF};

static const EIF_TYPE_INDEX *gtypes349 [] = {
g_atype349_0,
g_atype349_1,
g_atype349_2,
g_atype349_3,
g_atype349_4,
g_atype349_5,
};

static const long offsets349 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names354[];
static const uint32 types354 [] =
{
SK_INT32,
};

static const uint16 attr_flags354 [] =
{0,};

static const EIF_TYPE_INDEX g_atype354_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes354 [] = {
g_atype354_0,
};

static const long offsets354 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names358[];
static const uint32 types358 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags358 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype358_0 [] = {353,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes358 [] = {
g_atype358_0,
g_atype358_1,
g_atype358_2,
g_atype358_3,
};

static const long offsets358 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names359[];
static const uint32 types359 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags359 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype359_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes359 [] = {
g_atype359_0,
g_atype359_1,
g_atype359_2,
};

static const long offsets359 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names362[];
static const uint32 types362 [] =
{
SK_REF,
};

static const uint16 attr_flags362 [] =
{0,};

static const EIF_TYPE_INDEX g_atype362_0 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes362 [] = {
g_atype362_0,
};

static const long offsets362 [] =
{
0,
};

extern const char *names363[];
static const uint32 types363 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags363 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype363_0 [] = {268,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_2 [] = {928,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_3 [] = {892,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_6 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes363 [] = {
g_atype363_0,
g_atype363_1,
g_atype363_2,
g_atype363_3,
g_atype363_4,
g_atype363_5,
g_atype363_6,
};

static const long offsets363 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
};

extern const char *names364[];
static const uint32 types364 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags364 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype364_0 [] = {268,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_2 [] = {928,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_3 [] = {892,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_4 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_5 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_6 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_11 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes364 [] = {
g_atype364_0,
g_atype364_1,
g_atype364_2,
g_atype364_3,
g_atype364_4,
g_atype364_5,
g_atype364_6,
g_atype364_7,
g_atype364_8,
g_atype364_9,
g_atype364_10,
g_atype364_11,
};

static const long offsets364 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
};

extern const char *names366[];
static const uint32 types366 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags366 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype366_0 [] = {804,1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_1 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_7 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes366 [] = {
g_atype366_0,
g_atype366_1,
g_atype366_2,
g_atype366_3,
g_atype366_4,
g_atype366_5,
g_atype366_6,
g_atype366_7,
};

static const long offsets366 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
+ @LNGOFF(2,2,0,3),
};

extern const char *names367[];
static const uint32 types367 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags367 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype367_0 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_1 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_2 [] = {804,1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes367 [] = {
g_atype367_0,
g_atype367_1,
g_atype367_2,
};

static const long offsets367 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names368[];
static const uint32 types368 [] =
{
SK_REF,
};

static const uint16 attr_flags368 [] =
{0,};

static const EIF_TYPE_INDEX g_atype368_0 [] = {907,0xFFFF};

static const EIF_TYPE_INDEX *gtypes368 [] = {
g_atype368_0,
};

static const long offsets368 [] =
{
0,
};

extern const char *names369[];
static const uint32 types369 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags369 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype369_0 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_2 [] = {1279,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_3 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_4 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes369 [] = {
g_atype369_0,
g_atype369_1,
g_atype369_2,
g_atype369_3,
g_atype369_4,
};

static const long offsets369 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
};

extern const char *names370[];
static const uint32 types370 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags370 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype370_0 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_1 [] = {1226,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_2 [] = {1226,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_3 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_4 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_5 [] = {1289,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_6 [] = {1289,0xFFFF};

static const EIF_TYPE_INDEX *gtypes370 [] = {
g_atype370_0,
g_atype370_1,
g_atype370_2,
g_atype370_3,
g_atype370_4,
g_atype370_5,
g_atype370_6,
};

static const long offsets370 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
};

extern const char *names371[];
static const uint32 types371 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags371 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype371_0 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_2 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_3 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes371 [] = {
g_atype371_0,
g_atype371_1,
g_atype371_2,
g_atype371_3,
};

static const long offsets371 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names372[];
static const uint32 types372 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags372 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype372_0 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_2 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_3 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes372 [] = {
g_atype372_0,
g_atype372_1,
g_atype372_2,
g_atype372_3,
};

static const long offsets372 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names373[];
static const uint32 types373 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags373 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype373_0 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_2 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_3 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes373 [] = {
g_atype373_0,
g_atype373_1,
g_atype373_2,
g_atype373_3,
};

static const long offsets373 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names374[];
static const uint32 types374 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags374 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype374_0 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_2 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_3 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes374 [] = {
g_atype374_0,
g_atype374_1,
g_atype374_2,
g_atype374_3,
};

static const long offsets374 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names375[];
static const uint32 types375 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags375 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype375_0 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_2 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_3 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes375 [] = {
g_atype375_0,
g_atype375_1,
g_atype375_2,
g_atype375_3,
};

static const long offsets375 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names376[];
static const uint32 types376 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags376 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype376_0 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_2 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_3 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes376 [] = {
g_atype376_0,
g_atype376_1,
g_atype376_2,
g_atype376_3,
};

static const long offsets376 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names377[];
static const uint32 types377 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags377 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype377_0 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_2 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_3 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes377 [] = {
g_atype377_0,
g_atype377_1,
g_atype377_2,
g_atype377_3,
};

static const long offsets377 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names378[];
static const uint32 types378 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags378 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype378_0 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_2 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_3 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes378 [] = {
g_atype378_0,
g_atype378_1,
g_atype378_2,
g_atype378_3,
};

static const long offsets378 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names379[];
static const uint32 types379 [] =
{
SK_REF,
};

static const uint16 attr_flags379 [] =
{0,};

static const EIF_TYPE_INDEX g_atype379_0 [] = {1108,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes379 [] = {
g_atype379_0,
};

static const long offsets379 [] =
{
0,
};

extern const char *names380[];
static const uint32 types380 [] =
{
SK_REF,
};

static const uint16 attr_flags380 [] =
{0,};

static const EIF_TYPE_INDEX g_atype380_0 [] = {1109,1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes380 [] = {
g_atype380_0,
};

static const long offsets380 [] =
{
0,
};

extern const char *names381[];
static const uint32 types381 [] =
{
SK_REF,
};

static const uint16 attr_flags381 [] =
{0,};

static const EIF_TYPE_INDEX g_atype381_0 [] = {1110,1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes381 [] = {
g_atype381_0,
};

static const long offsets381 [] =
{
0,
};

extern const char *names382[];
static const uint32 types382 [] =
{
SK_REF,
};

static const uint16 attr_flags382 [] =
{0,};

static const EIF_TYPE_INDEX g_atype382_0 [] = {1111,1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes382 [] = {
g_atype382_0,
};

static const long offsets382 [] =
{
0,
};

extern const char *names383[];
static const uint32 types383 [] =
{
SK_REF,
};

static const uint16 attr_flags383 [] =
{0,};

static const EIF_TYPE_INDEX g_atype383_0 [] = {1112,1004,0xFFFF};

static const EIF_TYPE_INDEX *gtypes383 [] = {
g_atype383_0,
};

static const long offsets383 [] =
{
0,
};

extern const char *names384[];
static const uint32 types384 [] =
{
SK_REF,
};

static const uint16 attr_flags384 [] =
{0,};

static const EIF_TYPE_INDEX g_atype384_0 [] = {1113,1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes384 [] = {
g_atype384_0,
};

static const long offsets384 [] =
{
0,
};

extern const char *names385[];
static const uint32 types385 [] =
{
SK_REF,
};

static const uint16 attr_flags385 [] =
{0,};

static const EIF_TYPE_INDEX g_atype385_0 [] = {1114,1199,0xFFFF};

static const EIF_TYPE_INDEX *gtypes385 [] = {
g_atype385_0,
};

static const long offsets385 [] =
{
0,
};

extern const char *names386[];
static const uint32 types386 [] =
{
SK_REF,
};

static const uint16 attr_flags386 [] =
{0,};

static const EIF_TYPE_INDEX g_atype386_0 [] = {1115,1001,0xFFFF};

static const EIF_TYPE_INDEX *gtypes386 [] = {
g_atype386_0,
};

static const long offsets386 [] =
{
0,
};

extern const char *names387[];
static const uint32 types387 [] =
{
SK_REF,
};

static const uint16 attr_flags387 [] =
{0,};

static const EIF_TYPE_INDEX g_atype387_0 [] = {1116,1205,0xFFFF};

static const EIF_TYPE_INDEX *gtypes387 [] = {
g_atype387_0,
};

static const long offsets387 [] =
{
0,
};

extern const char *names388[];
static const uint32 types388 [] =
{
SK_REF,
};

static const uint16 attr_flags388 [] =
{0,};

static const EIF_TYPE_INDEX g_atype388_0 [] = {1117,1202,0xFFFF};

static const EIF_TYPE_INDEX *gtypes388 [] = {
g_atype388_0,
};

static const long offsets388 [] =
{
0,
};

extern const char *names389[];
static const uint32 types389 [] =
{
SK_REF,
};

static const uint16 attr_flags389 [] =
{0,};

static const EIF_TYPE_INDEX g_atype389_0 [] = {1118,1208,0xFFFF};

static const EIF_TYPE_INDEX *gtypes389 [] = {
g_atype389_0,
};

static const long offsets389 [] =
{
0,
};

extern const char *names390[];
static const uint32 types390 [] =
{
SK_REF,
};

static const uint16 attr_flags390 [] =
{0,};

static const EIF_TYPE_INDEX g_atype390_0 [] = {1119,1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes390 [] = {
g_atype390_0,
};

static const long offsets390 [] =
{
0,
};

extern const char *names392[];
static const uint32 types392 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags392 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype392_0 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes392 [] = {
g_atype392_0,
g_atype392_1,
};

static const long offsets392 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names393[];
static const uint32 types393 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags393 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype393_0 [] = {1116,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_1 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_4 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes393 [] = {
g_atype393_0,
g_atype393_1,
g_atype393_2,
g_atype393_3,
g_atype393_4,
};

static const long offsets393 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names394[];
static const uint32 types394 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags394 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype394_0 [] = {1116,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_1 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_4 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes394 [] = {
g_atype394_0,
g_atype394_1,
g_atype394_2,
g_atype394_3,
g_atype394_4,
};

static const long offsets394 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names395[];
static const uint32 types395 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags395 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype395_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_1 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_4 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_5 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes395 [] = {
g_atype395_0,
g_atype395_1,
g_atype395_2,
g_atype395_3,
g_atype395_4,
g_atype395_5,
};

static const long offsets395 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @PTROFF(3,0,0,1,0,0),
+ @PTROFF(3,0,0,1,0,1),
};

extern const char *names396[];
static const uint32 types396 [] =
{
SK_INT32,
};

static const uint16 attr_flags396 [] =
{0,};

static const EIF_TYPE_INDEX g_atype396_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes396 [] = {
g_atype396_0,
};

static const long offsets396 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names397[];
static const uint32 types397 [] =
{
SK_INT32,
};

static const uint16 attr_flags397 [] =
{0,};

static const EIF_TYPE_INDEX g_atype397_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes397 [] = {
g_atype397_0,
};

static const long offsets397 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names401[];
static const uint32 types401 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags401 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype401_0 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_1 [] = {1072,0xFFFF};

static const EIF_TYPE_INDEX *gtypes401 [] = {
g_atype401_0,
g_atype401_1,
};

static const long offsets401 [] =
{
0,
 + @REFACS(1),
};

extern const char *names403[];
static const uint32 types403 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags403 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype403_0 [] = {400,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_1 [] = {19,0xFFFF};

static const EIF_TYPE_INDEX *gtypes403 [] = {
g_atype403_0,
g_atype403_1,
};

static const long offsets403 [] =
{
0,
 + @REFACS(1),
};

extern const char *names404[];
static const uint32 types404 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags404 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype404_0 [] = {400,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_1 [] = {19,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_2 [] = {12,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_3 [] = {863,1061,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_4 [] = {863,1061,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes404 [] = {
g_atype404_0,
g_atype404_1,
g_atype404_2,
g_atype404_3,
g_atype404_4,
g_atype404_5,
};

static const long offsets404 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names405[];
static const uint32 types405 [] =
{
SK_REF,
};

static const uint16 attr_flags405 [] =
{0,};

static const EIF_TYPE_INDEX g_atype405_0 [] = {892,1056,0xFFFF};

static const EIF_TYPE_INDEX *gtypes405 [] = {
g_atype405_0,
};

static const long offsets405 [] =
{
0,
};

extern const char *names406[];
static const uint32 types406 [] =
{
SK_REF,
};

static const uint16 attr_flags406 [] =
{0,};

static const EIF_TYPE_INDEX g_atype406_0 [] = {892,1056,0xFFFF};

static const EIF_TYPE_INDEX *gtypes406 [] = {
g_atype406_0,
};

static const long offsets406 [] =
{
0,
};

extern const char *names408[];
static const uint32 types408 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR32,
};

static const uint16 attr_flags408 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype408_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_2 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_3 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_4 [] = {1001,0xFFFF};

static const EIF_TYPE_INDEX *gtypes408 [] = {
g_atype408_0,
g_atype408_1,
g_atype408_2,
g_atype408_3,
g_atype408_4,
};

static const long offsets408 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names409[];
static const uint32 types409 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags409 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype409_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_1 [] = {1112,1004,0xFFFF};

static const EIF_TYPE_INDEX *gtypes409 [] = {
g_atype409_0,
g_atype409_1,
};

static const long offsets409 [] =
{
0,
 + @REFACS(1),
};

extern const char *names410[];
static const uint32 types410 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags410 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype410_0 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes410 [] = {
g_atype410_0,
g_atype410_1,
};

static const long offsets410 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names411[];
static const uint32 types411 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags411 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype411_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_1 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_2 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_3 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_4 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_5 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_6 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_9 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_10 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_11 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_12 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes411 [] = {
g_atype411_0,
g_atype411_1,
g_atype411_2,
g_atype411_3,
g_atype411_4,
g_atype411_5,
g_atype411_6,
g_atype411_7,
g_atype411_8,
g_atype411_9,
g_atype411_10,
g_atype411_11,
g_atype411_12,
};

static const long offsets411 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I16OFF(1,3,0),
+ @I16OFF(1,3,1),
+ @LNGOFF(1,3,2,0),
+ @LNGOFF(1,3,2,1),
+ @LNGOFF(1,3,2,2),
+ @R32OFF(1,3,2,3,0),
+ @I64OFF(1,3,2,3,1,0,0),
+ @I64OFF(1,3,2,3,1,0,1),
+ @R64OFF(1,3,2,3,1,0,2,0),
};

extern const char *names424[];
static const uint32 types424 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags424 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype424_0 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_1 [] = {0xFFF5,1,1108,0xFFF8,1,5232,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_2 [] = {0xFFF5,1,744,0xFFF8,1,5017,0xFFFF};

static const EIF_TYPE_INDEX *gtypes424 [] = {
g_atype424_0,
g_atype424_1,
g_atype424_2,
};

static const long offsets424 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names425[];
static const uint32 types425 [] =
{
SK_UINT8,
SK_POINTER,
};

static const uint16 attr_flags425 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype425_0 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_1 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes425 [] = {
g_atype425_0,
g_atype425_1,
};

static const long offsets425 [] =
{
+ @CHROFF(0,0),
+ @PTROFF(0,1,0,0,0,0),
};

extern const char *names426[];
static const uint32 types426 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags426 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype426_0 [] = {1226,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes426 [] = {
g_atype426_0,
g_atype426_1,
};

static const long offsets426 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names427[];
static const uint32 types427 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags427 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype427_0 [] = {1227,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes427 [] = {
g_atype427_0,
g_atype427_1,
};

static const long offsets427 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names428[];
static const uint32 types428 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags428 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype428_0 [] = {1228,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes428 [] = {
g_atype428_0,
g_atype428_1,
};

static const long offsets428 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names438[];
static const uint32 types438 [] =
{
SK_INT32,
};

static const uint16 attr_flags438 [] =
{0,};

static const EIF_TYPE_INDEX g_atype438_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes438 [] = {
g_atype438_0,
};

static const long offsets438 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names454[];
static const uint32 types454 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags454 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype454_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes454 [] = {
g_atype454_0,
g_atype454_1,
g_atype454_2,
g_atype454_3,
};

static const long offsets454 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names479[];
static const uint32 types479 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags479 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype479_0 [] = {783,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype479_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype479_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype479_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype479_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype479_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype479_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes479 [] = {
g_atype479_0,
g_atype479_1,
g_atype479_2,
g_atype479_3,
g_atype479_4,
g_atype479_5,
g_atype479_6,
};

static const long offsets479 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names480[];
static const uint32 types480 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags480 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype480_0 [] = {784,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes480 [] = {
g_atype480_0,
g_atype480_1,
g_atype480_2,
g_atype480_3,
g_atype480_4,
g_atype480_5,
g_atype480_6,
};

static const long offsets480 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names481[];
static const uint32 types481 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags481 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype481_0 [] = {785,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype481_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype481_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype481_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype481_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype481_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype481_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes481 [] = {
g_atype481_0,
g_atype481_1,
g_atype481_2,
g_atype481_3,
g_atype481_4,
g_atype481_5,
g_atype481_6,
};

static const long offsets481 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names482[];
static const uint32 types482 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags482 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype482_0 [] = {786,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype482_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype482_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype482_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype482_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype482_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype482_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes482 [] = {
g_atype482_0,
g_atype482_1,
g_atype482_2,
g_atype482_3,
g_atype482_4,
g_atype482_5,
g_atype482_6,
};

static const long offsets482 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names483[];
static const uint32 types483 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags483 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype483_0 [] = {787,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes483 [] = {
g_atype483_0,
g_atype483_1,
g_atype483_2,
g_atype483_3,
g_atype483_4,
g_atype483_5,
g_atype483_6,
};

static const long offsets483 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names484[];
static const uint32 types484 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags484 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype484_0 [] = {788,1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype484_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype484_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype484_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype484_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype484_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype484_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes484 [] = {
g_atype484_0,
g_atype484_1,
g_atype484_2,
g_atype484_3,
g_atype484_4,
g_atype484_5,
g_atype484_6,
};

static const long offsets484 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names485[];
static const uint32 types485 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags485 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype485_0 [] = {789,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes485 [] = {
g_atype485_0,
g_atype485_1,
g_atype485_2,
g_atype485_3,
g_atype485_4,
g_atype485_5,
g_atype485_6,
};

static const long offsets485 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names486[];
static const uint32 types486 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags486 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype486_0 [] = {790,1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype486_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype486_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype486_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype486_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype486_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype486_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes486 [] = {
g_atype486_0,
g_atype486_1,
g_atype486_2,
g_atype486_3,
g_atype486_4,
g_atype486_5,
g_atype486_6,
};

static const long offsets486 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names487[];
static const uint32 types487 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags487 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype487_0 [] = {791,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes487 [] = {
g_atype487_0,
g_atype487_1,
g_atype487_2,
g_atype487_3,
g_atype487_4,
g_atype487_5,
g_atype487_6,
};

static const long offsets487 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names488[];
static const uint32 types488 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags488 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype488_0 [] = {792,1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype488_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype488_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype488_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype488_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype488_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype488_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes488 [] = {
g_atype488_0,
g_atype488_1,
g_atype488_2,
g_atype488_3,
g_atype488_4,
g_atype488_5,
g_atype488_6,
};

static const long offsets488 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names489[];
static const uint32 types489 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags489 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype489_0 [] = {793,1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes489 [] = {
g_atype489_0,
g_atype489_1,
g_atype489_2,
g_atype489_3,
g_atype489_4,
g_atype489_5,
g_atype489_6,
};

static const long offsets489 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names490[];
static const uint32 types490 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags490 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype490_0 [] = {794,1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype490_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype490_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype490_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype490_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype490_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype490_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes490 [] = {
g_atype490_0,
g_atype490_1,
g_atype490_2,
g_atype490_3,
g_atype490_4,
g_atype490_5,
g_atype490_6,
};

static const long offsets490 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names491[];
static const uint32 types491 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags491 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype491_0 [] = {887,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_1 [] = {176,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_3 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_7 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes491 [] = {
g_atype491_0,
g_atype491_1,
g_atype491_2,
g_atype491_3,
g_atype491_4,
g_atype491_5,
g_atype491_6,
g_atype491_7,
};

static const long offsets491 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names492[];
static const uint32 types492 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags492 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype492_0 [] = {888,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype492_1 [] = {177,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype492_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype492_3 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype492_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype492_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype492_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype492_7 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes492 [] = {
g_atype492_0,
g_atype492_1,
g_atype492_2,
g_atype492_3,
g_atype492_4,
g_atype492_5,
g_atype492_6,
g_atype492_7,
};

static const long offsets492 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names493[];
static const uint32 types493 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags493 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype493_0 [] = {795,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes493 [] = {
g_atype493_0,
g_atype493_1,
g_atype493_2,
g_atype493_3,
g_atype493_4,
g_atype493_5,
g_atype493_6,
};

static const long offsets493 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names494[];
static const uint32 types494 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags494 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype494_0 [] = {796,0xFFF8,1,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype494_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype494_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype494_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype494_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype494_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype494_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes494 [] = {
g_atype494_0,
g_atype494_1,
g_atype494_2,
g_atype494_3,
g_atype494_4,
g_atype494_5,
g_atype494_6,
};

static const long offsets494 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names495[];
static const uint32 types495 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags495 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype495_0 [] = {797,1040,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes495 [] = {
g_atype495_0,
g_atype495_1,
g_atype495_2,
g_atype495_3,
g_atype495_4,
g_atype495_5,
g_atype495_6,
};

static const long offsets495 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names496[];
static const uint32 types496 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags496 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype496_0 [] = {798,1187,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype496_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype496_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype496_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype496_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype496_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype496_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes496 [] = {
g_atype496_0,
g_atype496_1,
g_atype496_2,
g_atype496_3,
g_atype496_4,
g_atype496_5,
g_atype496_6,
};

static const long offsets496 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names497[];
static const uint32 types497 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags497 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype497_0 [] = {799,1199,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype497_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype497_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype497_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype497_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype497_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype497_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes497 [] = {
g_atype497_0,
g_atype497_1,
g_atype497_2,
g_atype497_3,
g_atype497_4,
g_atype497_5,
g_atype497_6,
};

static const long offsets497 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names498[];
static const uint32 types498 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags498 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype498_0 [] = {800,1007,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes498 [] = {
g_atype498_0,
g_atype498_1,
g_atype498_2,
g_atype498_3,
g_atype498_4,
g_atype498_5,
g_atype498_6,
};

static const long offsets498 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names499[];
static const uint32 types499 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags499 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype499_0 [] = {801,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes499 [] = {
g_atype499_0,
g_atype499_1,
g_atype499_2,
g_atype499_3,
g_atype499_4,
g_atype499_5,
g_atype499_6,
};

static const long offsets499 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names500[];
static const uint32 types500 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags500 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype500_0 [] = {802,1205,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype500_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype500_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype500_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype500_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype500_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype500_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes500 [] = {
g_atype500_0,
g_atype500_1,
g_atype500_2,
g_atype500_3,
g_atype500_4,
g_atype500_5,
g_atype500_6,
};

static const long offsets500 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names501[];
static const uint32 types501 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags501 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype501_0 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype501_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype501_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes501 [] = {
g_atype501_0,
g_atype501_1,
g_atype501_2,
};

static const long offsets501 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names502[];
static const uint32 types502 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags502 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype502_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype502_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype502_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes502 [] = {
g_atype502_0,
g_atype502_1,
g_atype502_2,
};

static const long offsets502 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names503[];
static const uint32 types503 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags503 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype503_0 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype503_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype503_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes503 [] = {
g_atype503_0,
g_atype503_1,
g_atype503_2,
};

static const long offsets503 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names504[];
static const uint32 types504 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags504 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype504_0 [] = {1111,1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype504_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype504_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes504 [] = {
g_atype504_0,
g_atype504_1,
g_atype504_2,
};

static const long offsets504 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names505[];
static const uint32 types505 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags505 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype505_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype505_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype505_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes505 [] = {
g_atype505_0,
g_atype505_1,
g_atype505_2,
};

static const long offsets505 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names506[];
static const uint32 types506 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags506 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype506_0 [] = {1113,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype506_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype506_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes506 [] = {
g_atype506_0,
g_atype506_1,
g_atype506_2,
};

static const long offsets506 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names507[];
static const uint32 types507 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags507 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype507_0 [] = {1114,1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype507_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype507_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes507 [] = {
g_atype507_0,
g_atype507_1,
g_atype507_2,
};

static const long offsets507 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names508[];
static const uint32 types508 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags508 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype508_0 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype508_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype508_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes508 [] = {
g_atype508_0,
g_atype508_1,
g_atype508_2,
};

static const long offsets508 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names509[];
static const uint32 types509 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags509 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype509_0 [] = {1116,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype509_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype509_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes509 [] = {
g_atype509_0,
g_atype509_1,
g_atype509_2,
};

static const long offsets509 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names510[];
static const uint32 types510 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags510 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype510_0 [] = {1117,1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype510_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype510_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes510 [] = {
g_atype510_0,
g_atype510_1,
g_atype510_2,
};

static const long offsets510 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names511[];
static const uint32 types511 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags511 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype511_0 [] = {1118,1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype511_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype511_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes511 [] = {
g_atype511_0,
g_atype511_1,
g_atype511_2,
};

static const long offsets511 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names512[];
static const uint32 types512 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags512 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype512_0 [] = {1119,1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype512_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype512_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes512 [] = {
g_atype512_0,
g_atype512_1,
g_atype512_2,
};

static const long offsets512 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names513[];
static const uint32 types513 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags513 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype513_0 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype513_1 [] = {892,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype513_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype513_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes513 [] = {
g_atype513_0,
g_atype513_1,
g_atype513_2,
g_atype513_3,
};

static const long offsets513 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names514[];
static const uint32 types514 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags514 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype514_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype514_1 [] = {893,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype514_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype514_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes514 [] = {
g_atype514_0,
g_atype514_1,
g_atype514_2,
g_atype514_3,
};

static const long offsets514 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names515[];
static const uint32 types515 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags515 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype515_0 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype515_1 [] = {894,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype515_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype515_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes515 [] = {
g_atype515_0,
g_atype515_1,
g_atype515_2,
g_atype515_3,
};

static const long offsets515 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names516[];
static const uint32 types516 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags516 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype516_0 [] = {1111,1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype516_1 [] = {895,1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype516_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype516_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes516 [] = {
g_atype516_0,
g_atype516_1,
g_atype516_2,
g_atype516_3,
};

static const long offsets516 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names517[];
static const uint32 types517 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags517 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype517_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype517_1 [] = {896,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype517_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype517_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes517 [] = {
g_atype517_0,
g_atype517_1,
g_atype517_2,
g_atype517_3,
};

static const long offsets517 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names518[];
static const uint32 types518 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags518 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype518_0 [] = {1113,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype518_1 [] = {897,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype518_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype518_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes518 [] = {
g_atype518_0,
g_atype518_1,
g_atype518_2,
g_atype518_3,
};

static const long offsets518 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names519[];
static const uint32 types519 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags519 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype519_0 [] = {1114,1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype519_1 [] = {898,1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype519_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype519_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes519 [] = {
g_atype519_0,
g_atype519_1,
g_atype519_2,
g_atype519_3,
};

static const long offsets519 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names520[];
static const uint32 types520 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags520 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype520_0 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype520_1 [] = {899,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype520_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype520_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes520 [] = {
g_atype520_0,
g_atype520_1,
g_atype520_2,
g_atype520_3,
};

static const long offsets520 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names521[];
static const uint32 types521 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags521 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype521_0 [] = {1116,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype521_1 [] = {900,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype521_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype521_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes521 [] = {
g_atype521_0,
g_atype521_1,
g_atype521_2,
g_atype521_3,
};

static const long offsets521 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names522[];
static const uint32 types522 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags522 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype522_0 [] = {1117,1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype522_1 [] = {901,1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype522_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype522_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes522 [] = {
g_atype522_0,
g_atype522_1,
g_atype522_2,
g_atype522_3,
};

static const long offsets522 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names523[];
static const uint32 types523 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags523 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype523_0 [] = {1118,1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype523_1 [] = {902,1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype523_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype523_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes523 [] = {
g_atype523_0,
g_atype523_1,
g_atype523_2,
g_atype523_3,
};

static const long offsets523 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names524[];
static const uint32 types524 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags524 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype524_0 [] = {1119,1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype524_1 [] = {903,1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype524_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype524_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes524 [] = {
g_atype524_0,
g_atype524_1,
g_atype524_2,
g_atype524_3,
};

static const long offsets524 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names525[];
static const uint32 types525 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags525 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype525_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype525_1 [] = {1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype525_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype525_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype525_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes525 [] = {
g_atype525_0,
g_atype525_1,
g_atype525_2,
g_atype525_3,
g_atype525_4,
};

static const long offsets525 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names526[];
static const uint32 types526 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags526 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype526_0 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype526_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype526_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype526_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype526_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes526 [] = {
g_atype526_0,
g_atype526_1,
g_atype526_2,
g_atype526_3,
g_atype526_4,
};

static const long offsets526 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names527[];
static const uint32 types527 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags527 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype527_0 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype527_1 [] = {822,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype527_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype527_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype527_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes527 [] = {
g_atype527_0,
g_atype527_1,
g_atype527_2,
g_atype527_3,
g_atype527_4,
};

static const long offsets527 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names528[];
static const uint32 types528 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags528 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype528_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype528_1 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype528_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype528_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype528_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes528 [] = {
g_atype528_0,
g_atype528_1,
g_atype528_2,
g_atype528_3,
g_atype528_4,
};

static const long offsets528 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names529[];
static const uint32 types529 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags529 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype529_0 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype529_1 [] = {824,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype529_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype529_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype529_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes529 [] = {
g_atype529_0,
g_atype529_1,
g_atype529_2,
g_atype529_3,
g_atype529_4,
};

static const long offsets529 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names530[];
static const uint32 types530 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags530 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype530_0 [] = {1111,1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_1 [] = {825,1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes530 [] = {
g_atype530_0,
g_atype530_1,
g_atype530_2,
g_atype530_3,
g_atype530_4,
};

static const long offsets530 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names531[];
static const uint32 types531 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags531 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype531_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_1 [] = {826,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes531 [] = {
g_atype531_0,
g_atype531_1,
g_atype531_2,
g_atype531_3,
g_atype531_4,
};

static const long offsets531 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names532[];
static const uint32 types532 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags532 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype532_0 [] = {1113,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_1 [] = {827,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes532 [] = {
g_atype532_0,
g_atype532_1,
g_atype532_2,
g_atype532_3,
g_atype532_4,
};

static const long offsets532 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names533[];
static const uint32 types533 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags533 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype533_0 [] = {1114,1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_1 [] = {828,1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes533 [] = {
g_atype533_0,
g_atype533_1,
g_atype533_2,
g_atype533_3,
g_atype533_4,
};

static const long offsets533 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names534[];
static const uint32 types534 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags534 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype534_0 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype534_1 [] = {829,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype534_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype534_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype534_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes534 [] = {
g_atype534_0,
g_atype534_1,
g_atype534_2,
g_atype534_3,
g_atype534_4,
};

static const long offsets534 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names535[];
static const uint32 types535 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags535 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype535_0 [] = {1116,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype535_1 [] = {830,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype535_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype535_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype535_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes535 [] = {
g_atype535_0,
g_atype535_1,
g_atype535_2,
g_atype535_3,
g_atype535_4,
};

static const long offsets535 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names536[];
static const uint32 types536 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags536 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype536_0 [] = {1117,1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype536_1 [] = {831,1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype536_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype536_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype536_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes536 [] = {
g_atype536_0,
g_atype536_1,
g_atype536_2,
g_atype536_3,
g_atype536_4,
};

static const long offsets536 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names537[];
static const uint32 types537 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags537 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype537_0 [] = {1118,1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype537_1 [] = {832,1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype537_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype537_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype537_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes537 [] = {
g_atype537_0,
g_atype537_1,
g_atype537_2,
g_atype537_3,
g_atype537_4,
};

static const long offsets537 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names538[];
static const uint32 types538 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags538 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype538_0 [] = {1119,1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype538_1 [] = {833,1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype538_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype538_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype538_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes538 [] = {
g_atype538_0,
g_atype538_1,
g_atype538_2,
g_atype538_3,
g_atype538_4,
};

static const long offsets538 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names539[];
static const uint32 types539 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags539 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype539_0 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype539_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype539_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes539 [] = {
g_atype539_0,
g_atype539_1,
g_atype539_2,
};

static const long offsets539 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names540[];
static const uint32 types540 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags540 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype540_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype540_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype540_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes540 [] = {
g_atype540_0,
g_atype540_1,
g_atype540_2,
};

static const long offsets540 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names541[];
static const uint32 types541 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags541 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype541_0 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype541_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype541_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes541 [] = {
g_atype541_0,
g_atype541_1,
g_atype541_2,
};

static const long offsets541 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names542[];
static const uint32 types542 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags542 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype542_0 [] = {1111,1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype542_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype542_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes542 [] = {
g_atype542_0,
g_atype542_1,
g_atype542_2,
};

static const long offsets542 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names543[];
static const uint32 types543 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags543 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype543_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype543_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype543_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes543 [] = {
g_atype543_0,
g_atype543_1,
g_atype543_2,
};

static const long offsets543 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names544[];
static const uint32 types544 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags544 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype544_0 [] = {1113,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype544_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype544_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes544 [] = {
g_atype544_0,
g_atype544_1,
g_atype544_2,
};

static const long offsets544 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names545[];
static const uint32 types545 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags545 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype545_0 [] = {1114,1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype545_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype545_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes545 [] = {
g_atype545_0,
g_atype545_1,
g_atype545_2,
};

static const long offsets545 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names546[];
static const uint32 types546 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags546 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype546_0 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype546_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype546_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes546 [] = {
g_atype546_0,
g_atype546_1,
g_atype546_2,
};

static const long offsets546 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names547[];
static const uint32 types547 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags547 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype547_0 [] = {1116,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype547_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype547_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes547 [] = {
g_atype547_0,
g_atype547_1,
g_atype547_2,
};

static const long offsets547 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names548[];
static const uint32 types548 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags548 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype548_0 [] = {1117,1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype548_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype548_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes548 [] = {
g_atype548_0,
g_atype548_1,
g_atype548_2,
};

static const long offsets548 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names549[];
static const uint32 types549 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags549 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype549_0 [] = {1118,1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype549_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype549_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes549 [] = {
g_atype549_0,
g_atype549_1,
g_atype549_2,
};

static const long offsets549 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names550[];
static const uint32 types550 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags550 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype550_0 [] = {1119,1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype550_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype550_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes550 [] = {
g_atype550_0,
g_atype550_1,
g_atype550_2,
};

static const long offsets550 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names551[];
static const uint32 types551 [] =
{
SK_REF,
};

static const uint16 attr_flags551 [] =
{0,};

static const EIF_TYPE_INDEX g_atype551_0 [] = {439,1061,0xFFFF};

static const EIF_TYPE_INDEX *gtypes551 [] = {
g_atype551_0,
};

static const long offsets551 [] =
{
0,
};

extern const char *names552[];
static const uint32 types552 [] =
{
SK_BOOL,
};

static const uint16 attr_flags552 [] =
{0,};

static const EIF_TYPE_INDEX g_atype552_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes552 [] = {
g_atype552_0,
};

static const long offsets552 [] =
{
+ @CHROFF(0,0),
};

extern const char *names553[];
static const uint32 types553 [] =
{
SK_BOOL,
};

static const uint16 attr_flags553 [] =
{0,};

static const EIF_TYPE_INDEX g_atype553_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes553 [] = {
g_atype553_0,
};

static const long offsets553 [] =
{
+ @CHROFF(0,0),
};

extern const char *names554[];
static const uint32 types554 [] =
{
SK_BOOL,
};

static const uint16 attr_flags554 [] =
{0,};

static const EIF_TYPE_INDEX g_atype554_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes554 [] = {
g_atype554_0,
};

static const long offsets554 [] =
{
+ @CHROFF(0,0),
};

extern const char *names555[];
static const uint32 types555 [] =
{
SK_BOOL,
};

static const uint16 attr_flags555 [] =
{0,};

static const EIF_TYPE_INDEX g_atype555_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes555 [] = {
g_atype555_0,
};

static const long offsets555 [] =
{
+ @CHROFF(0,0),
};

extern const char *names556[];
static const uint32 types556 [] =
{
SK_BOOL,
};

static const uint16 attr_flags556 [] =
{0,};

static const EIF_TYPE_INDEX g_atype556_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes556 [] = {
g_atype556_0,
};

static const long offsets556 [] =
{
+ @CHROFF(0,0),
};

extern const char *names557[];
static const uint32 types557 [] =
{
SK_BOOL,
};

static const uint16 attr_flags557 [] =
{0,};

static const EIF_TYPE_INDEX g_atype557_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes557 [] = {
g_atype557_0,
};

static const long offsets557 [] =
{
+ @CHROFF(0,0),
};

extern const char *names558[];
static const uint32 types558 [] =
{
SK_BOOL,
};

static const uint16 attr_flags558 [] =
{0,};

static const EIF_TYPE_INDEX g_atype558_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes558 [] = {
g_atype558_0,
};

static const long offsets558 [] =
{
+ @CHROFF(0,0),
};

extern const char *names559[];
static const uint32 types559 [] =
{
SK_BOOL,
};

static const uint16 attr_flags559 [] =
{0,};

static const EIF_TYPE_INDEX g_atype559_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes559 [] = {
g_atype559_0,
};

static const long offsets559 [] =
{
+ @CHROFF(0,0),
};

extern const char *names560[];
static const uint32 types560 [] =
{
SK_BOOL,
};

static const uint16 attr_flags560 [] =
{0,};

static const EIF_TYPE_INDEX g_atype560_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes560 [] = {
g_atype560_0,
};

static const long offsets560 [] =
{
+ @CHROFF(0,0),
};

extern const char *names561[];
static const uint32 types561 [] =
{
SK_BOOL,
};

static const uint16 attr_flags561 [] =
{0,};

static const EIF_TYPE_INDEX g_atype561_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes561 [] = {
g_atype561_0,
};

static const long offsets561 [] =
{
+ @CHROFF(0,0),
};

extern const char *names562[];
static const uint32 types562 [] =
{
SK_BOOL,
};

static const uint16 attr_flags562 [] =
{0,};

static const EIF_TYPE_INDEX g_atype562_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes562 [] = {
g_atype562_0,
};

static const long offsets562 [] =
{
+ @CHROFF(0,0),
};

extern const char *names563[];
static const uint32 types563 [] =
{
SK_BOOL,
};

static const uint16 attr_flags563 [] =
{0,};

static const EIF_TYPE_INDEX g_atype563_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes563 [] = {
g_atype563_0,
};

static const long offsets563 [] =
{
+ @CHROFF(0,0),
};

extern const char *names564[];
static const uint32 types564 [] =
{
SK_BOOL,
};

static const uint16 attr_flags564 [] =
{0,};

static const EIF_TYPE_INDEX g_atype564_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes564 [] = {
g_atype564_0,
};

static const long offsets564 [] =
{
+ @CHROFF(0,0),
};

extern const char *names565[];
static const uint32 types565 [] =
{
SK_BOOL,
};

static const uint16 attr_flags565 [] =
{0,};

static const EIF_TYPE_INDEX g_atype565_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes565 [] = {
g_atype565_0,
};

static const long offsets565 [] =
{
+ @CHROFF(0,0),
};

extern const char *names566[];
static const uint32 types566 [] =
{
SK_BOOL,
};

static const uint16 attr_flags566 [] =
{0,};

static const EIF_TYPE_INDEX g_atype566_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes566 [] = {
g_atype566_0,
};

static const long offsets566 [] =
{
+ @CHROFF(0,0),
};

extern const char *names567[];
static const uint32 types567 [] =
{
SK_BOOL,
};

static const uint16 attr_flags567 [] =
{0,};

static const EIF_TYPE_INDEX g_atype567_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes567 [] = {
g_atype567_0,
};

static const long offsets567 [] =
{
+ @CHROFF(0,0),
};

extern const char *names568[];
static const uint32 types568 [] =
{
SK_BOOL,
};

static const uint16 attr_flags568 [] =
{0,};

static const EIF_TYPE_INDEX g_atype568_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes568 [] = {
g_atype568_0,
};

static const long offsets568 [] =
{
+ @CHROFF(0,0),
};

extern const char *names569[];
static const uint32 types569 [] =
{
SK_BOOL,
};

static const uint16 attr_flags569 [] =
{0,};

static const EIF_TYPE_INDEX g_atype569_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes569 [] = {
g_atype569_0,
};

static const long offsets569 [] =
{
+ @CHROFF(0,0),
};

extern const char *names570[];
static const uint32 types570 [] =
{
SK_BOOL,
};

static const uint16 attr_flags570 [] =
{0,};

static const EIF_TYPE_INDEX g_atype570_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes570 [] = {
g_atype570_0,
};

static const long offsets570 [] =
{
+ @CHROFF(0,0),
};

extern const char *names571[];
static const uint32 types571 [] =
{
SK_BOOL,
};

static const uint16 attr_flags571 [] =
{0,};

static const EIF_TYPE_INDEX g_atype571_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes571 [] = {
g_atype571_0,
};

static const long offsets571 [] =
{
+ @CHROFF(0,0),
};

extern const char *names572[];
static const uint32 types572 [] =
{
SK_BOOL,
};

static const uint16 attr_flags572 [] =
{0,};

static const EIF_TYPE_INDEX g_atype572_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes572 [] = {
g_atype572_0,
};

static const long offsets572 [] =
{
+ @CHROFF(0,0),
};

extern const char *names573[];
static const uint32 types573 [] =
{
SK_BOOL,
};

static const uint16 attr_flags573 [] =
{0,};

static const EIF_TYPE_INDEX g_atype573_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes573 [] = {
g_atype573_0,
};

static const long offsets573 [] =
{
+ @CHROFF(0,0),
};

extern const char *names574[];
static const uint32 types574 [] =
{
SK_BOOL,
};

static const uint16 attr_flags574 [] =
{0,};

static const EIF_TYPE_INDEX g_atype574_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes574 [] = {
g_atype574_0,
};

static const long offsets574 [] =
{
+ @CHROFF(0,0),
};

extern const char *names575[];
static const uint32 types575 [] =
{
SK_BOOL,
};

static const uint16 attr_flags575 [] =
{0,};

static const EIF_TYPE_INDEX g_atype575_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes575 [] = {
g_atype575_0,
};

static const long offsets575 [] =
{
+ @CHROFF(0,0),
};

extern const char *names576[];
static const uint32 types576 [] =
{
SK_BOOL,
};

static const uint16 attr_flags576 [] =
{0,};

static const EIF_TYPE_INDEX g_atype576_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes576 [] = {
g_atype576_0,
};

static const long offsets576 [] =
{
+ @CHROFF(0,0),
};

extern const char *names577[];
static const uint32 types577 [] =
{
SK_BOOL,
};

static const uint16 attr_flags577 [] =
{0,};

static const EIF_TYPE_INDEX g_atype577_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes577 [] = {
g_atype577_0,
};

static const long offsets577 [] =
{
+ @CHROFF(0,0),
};

extern const char *names578[];
static const uint32 types578 [] =
{
SK_BOOL,
};

static const uint16 attr_flags578 [] =
{0,};

static const EIF_TYPE_INDEX g_atype578_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes578 [] = {
g_atype578_0,
};

static const long offsets578 [] =
{
+ @CHROFF(0,0),
};

extern const char *names579[];
static const uint32 types579 [] =
{
SK_BOOL,
};

static const uint16 attr_flags579 [] =
{0,};

static const EIF_TYPE_INDEX g_atype579_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes579 [] = {
g_atype579_0,
};

static const long offsets579 [] =
{
+ @CHROFF(0,0),
};

extern const char *names580[];
static const uint32 types580 [] =
{
SK_BOOL,
};

static const uint16 attr_flags580 [] =
{0,};

static const EIF_TYPE_INDEX g_atype580_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes580 [] = {
g_atype580_0,
};

static const long offsets580 [] =
{
+ @CHROFF(0,0),
};

extern const char *names581[];
static const uint32 types581 [] =
{
SK_BOOL,
};

static const uint16 attr_flags581 [] =
{0,};

static const EIF_TYPE_INDEX g_atype581_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes581 [] = {
g_atype581_0,
};

static const long offsets581 [] =
{
+ @CHROFF(0,0),
};

extern const char *names582[];
static const uint32 types582 [] =
{
SK_BOOL,
};

static const uint16 attr_flags582 [] =
{0,};

static const EIF_TYPE_INDEX g_atype582_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes582 [] = {
g_atype582_0,
};

static const long offsets582 [] =
{
+ @CHROFF(0,0),
};

extern const char *names583[];
static const uint32 types583 [] =
{
SK_BOOL,
};

static const uint16 attr_flags583 [] =
{0,};

static const EIF_TYPE_INDEX g_atype583_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes583 [] = {
g_atype583_0,
};

static const long offsets583 [] =
{
+ @CHROFF(0,0),
};

extern const char *names584[];
static const uint32 types584 [] =
{
SK_BOOL,
};

static const uint16 attr_flags584 [] =
{0,};

static const EIF_TYPE_INDEX g_atype584_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes584 [] = {
g_atype584_0,
};

static const long offsets584 [] =
{
+ @CHROFF(0,0),
};

extern const char *names585[];
static const uint32 types585 [] =
{
SK_BOOL,
};

static const uint16 attr_flags585 [] =
{0,};

static const EIF_TYPE_INDEX g_atype585_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes585 [] = {
g_atype585_0,
};

static const long offsets585 [] =
{
+ @CHROFF(0,0),
};

extern const char *names586[];
static const uint32 types586 [] =
{
SK_BOOL,
};

static const uint16 attr_flags586 [] =
{0,};

static const EIF_TYPE_INDEX g_atype586_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes586 [] = {
g_atype586_0,
};

static const long offsets586 [] =
{
+ @CHROFF(0,0),
};

extern const char *names587[];
static const uint32 types587 [] =
{
SK_BOOL,
};

static const uint16 attr_flags587 [] =
{0,};

static const EIF_TYPE_INDEX g_atype587_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes587 [] = {
g_atype587_0,
};

static const long offsets587 [] =
{
+ @CHROFF(0,0),
};

extern const char *names588[];
static const uint32 types588 [] =
{
SK_BOOL,
};

static const uint16 attr_flags588 [] =
{0,};

static const EIF_TYPE_INDEX g_atype588_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes588 [] = {
g_atype588_0,
};

static const long offsets588 [] =
{
+ @CHROFF(0,0),
};

extern const char *names589[];
static const uint32 types589 [] =
{
SK_BOOL,
};

static const uint16 attr_flags589 [] =
{0,};

static const EIF_TYPE_INDEX g_atype589_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes589 [] = {
g_atype589_0,
};

static const long offsets589 [] =
{
+ @CHROFF(0,0),
};

extern const char *names590[];
static const uint32 types590 [] =
{
SK_BOOL,
};

static const uint16 attr_flags590 [] =
{0,};

static const EIF_TYPE_INDEX g_atype590_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes590 [] = {
g_atype590_0,
};

static const long offsets590 [] =
{
+ @CHROFF(0,0),
};

extern const char *names591[];
static const uint32 types591 [] =
{
SK_BOOL,
};

static const uint16 attr_flags591 [] =
{0,};

static const EIF_TYPE_INDEX g_atype591_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes591 [] = {
g_atype591_0,
};

static const long offsets591 [] =
{
+ @CHROFF(0,0),
};

extern const char *names592[];
static const uint32 types592 [] =
{
SK_BOOL,
};

static const uint16 attr_flags592 [] =
{0,};

static const EIF_TYPE_INDEX g_atype592_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes592 [] = {
g_atype592_0,
};

static const long offsets592 [] =
{
+ @CHROFF(0,0),
};

extern const char *names593[];
static const uint32 types593 [] =
{
SK_BOOL,
};

static const uint16 attr_flags593 [] =
{0,};

static const EIF_TYPE_INDEX g_atype593_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes593 [] = {
g_atype593_0,
};

static const long offsets593 [] =
{
+ @CHROFF(0,0),
};

extern const char *names594[];
static const uint32 types594 [] =
{
SK_BOOL,
};

static const uint16 attr_flags594 [] =
{0,};

static const EIF_TYPE_INDEX g_atype594_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes594 [] = {
g_atype594_0,
};

static const long offsets594 [] =
{
+ @CHROFF(0,0),
};

extern const char *names595[];
static const uint32 types595 [] =
{
SK_BOOL,
};

static const uint16 attr_flags595 [] =
{0,};

static const EIF_TYPE_INDEX g_atype595_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes595 [] = {
g_atype595_0,
};

static const long offsets595 [] =
{
+ @CHROFF(0,0),
};

extern const char *names596[];
static const uint32 types596 [] =
{
SK_BOOL,
};

static const uint16 attr_flags596 [] =
{0,};

static const EIF_TYPE_INDEX g_atype596_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes596 [] = {
g_atype596_0,
};

static const long offsets596 [] =
{
+ @CHROFF(0,0),
};

extern const char *names597[];
static const uint32 types597 [] =
{
SK_BOOL,
};

static const uint16 attr_flags597 [] =
{0,};

static const EIF_TYPE_INDEX g_atype597_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes597 [] = {
g_atype597_0,
};

static const long offsets597 [] =
{
+ @CHROFF(0,0),
};

extern const char *names598[];
static const uint32 types598 [] =
{
SK_BOOL,
};

static const uint16 attr_flags598 [] =
{0,};

static const EIF_TYPE_INDEX g_atype598_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes598 [] = {
g_atype598_0,
};

static const long offsets598 [] =
{
+ @CHROFF(0,0),
};

extern const char *names599[];
static const uint32 types599 [] =
{
SK_BOOL,
};

static const uint16 attr_flags599 [] =
{0,};

static const EIF_TYPE_INDEX g_atype599_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes599 [] = {
g_atype599_0,
};

static const long offsets599 [] =
{
+ @CHROFF(0,0),
};

extern const char *names600[];
static const uint32 types600 [] =
{
SK_BOOL,
};

static const uint16 attr_flags600 [] =
{0,};

static const EIF_TYPE_INDEX g_atype600_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes600 [] = {
g_atype600_0,
};

static const long offsets600 [] =
{
+ @CHROFF(0,0),
};

extern const char *names601[];
static const uint32 types601 [] =
{
SK_BOOL,
};

static const uint16 attr_flags601 [] =
{0,};

static const EIF_TYPE_INDEX g_atype601_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes601 [] = {
g_atype601_0,
};

static const long offsets601 [] =
{
+ @CHROFF(0,0),
};

extern const char *names602[];
static const uint32 types602 [] =
{
SK_BOOL,
};

static const uint16 attr_flags602 [] =
{0,};

static const EIF_TYPE_INDEX g_atype602_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes602 [] = {
g_atype602_0,
};

static const long offsets602 [] =
{
+ @CHROFF(0,0),
};

extern const char *names603[];
static const uint32 types603 [] =
{
SK_BOOL,
};

static const uint16 attr_flags603 [] =
{0,};

static const EIF_TYPE_INDEX g_atype603_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes603 [] = {
g_atype603_0,
};

static const long offsets603 [] =
{
+ @CHROFF(0,0),
};

extern const char *names604[];
static const uint32 types604 [] =
{
SK_BOOL,
};

static const uint16 attr_flags604 [] =
{0,};

static const EIF_TYPE_INDEX g_atype604_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes604 [] = {
g_atype604_0,
};

static const long offsets604 [] =
{
+ @CHROFF(0,0),
};

extern const char *names605[];
static const uint32 types605 [] =
{
SK_BOOL,
};

static const uint16 attr_flags605 [] =
{0,};

static const EIF_TYPE_INDEX g_atype605_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes605 [] = {
g_atype605_0,
};

static const long offsets605 [] =
{
+ @CHROFF(0,0),
};

extern const char *names606[];
static const uint32 types606 [] =
{
SK_BOOL,
};

static const uint16 attr_flags606 [] =
{0,};

static const EIF_TYPE_INDEX g_atype606_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes606 [] = {
g_atype606_0,
};

static const long offsets606 [] =
{
+ @CHROFF(0,0),
};

extern const char *names607[];
static const uint32 types607 [] =
{
SK_BOOL,
};

static const uint16 attr_flags607 [] =
{0,};

static const EIF_TYPE_INDEX g_atype607_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes607 [] = {
g_atype607_0,
};

static const long offsets607 [] =
{
+ @CHROFF(0,0),
};

extern const char *names608[];
static const uint32 types608 [] =
{
SK_BOOL,
};

static const uint16 attr_flags608 [] =
{0,};

static const EIF_TYPE_INDEX g_atype608_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes608 [] = {
g_atype608_0,
};

static const long offsets608 [] =
{
+ @CHROFF(0,0),
};

extern const char *names609[];
static const uint32 types609 [] =
{
SK_BOOL,
};

static const uint16 attr_flags609 [] =
{0,};

static const EIF_TYPE_INDEX g_atype609_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes609 [] = {
g_atype609_0,
};

static const long offsets609 [] =
{
+ @CHROFF(0,0),
};

extern const char *names610[];
static const uint32 types610 [] =
{
SK_BOOL,
};

static const uint16 attr_flags610 [] =
{0,};

static const EIF_TYPE_INDEX g_atype610_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes610 [] = {
g_atype610_0,
};

static const long offsets610 [] =
{
+ @CHROFF(0,0),
};

extern const char *names611[];
static const uint32 types611 [] =
{
SK_BOOL,
};

static const uint16 attr_flags611 [] =
{0,};

static const EIF_TYPE_INDEX g_atype611_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes611 [] = {
g_atype611_0,
};

static const long offsets611 [] =
{
+ @CHROFF(0,0),
};

extern const char *names612[];
static const uint32 types612 [] =
{
SK_BOOL,
};

static const uint16 attr_flags612 [] =
{0,};

static const EIF_TYPE_INDEX g_atype612_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes612 [] = {
g_atype612_0,
};

static const long offsets612 [] =
{
+ @CHROFF(0,0),
};

extern const char *names613[];
static const uint32 types613 [] =
{
SK_BOOL,
};

static const uint16 attr_flags613 [] =
{0,};

static const EIF_TYPE_INDEX g_atype613_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes613 [] = {
g_atype613_0,
};

static const long offsets613 [] =
{
+ @CHROFF(0,0),
};

extern const char *names614[];
static const uint32 types614 [] =
{
SK_BOOL,
};

static const uint16 attr_flags614 [] =
{0,};

static const EIF_TYPE_INDEX g_atype614_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes614 [] = {
g_atype614_0,
};

static const long offsets614 [] =
{
+ @CHROFF(0,0),
};

extern const char *names615[];
static const uint32 types615 [] =
{
SK_BOOL,
};

static const uint16 attr_flags615 [] =
{0,};

static const EIF_TYPE_INDEX g_atype615_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes615 [] = {
g_atype615_0,
};

static const long offsets615 [] =
{
+ @CHROFF(0,0),
};

extern const char *names616[];
static const uint32 types616 [] =
{
SK_BOOL,
};

static const uint16 attr_flags616 [] =
{0,};

static const EIF_TYPE_INDEX g_atype616_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes616 [] = {
g_atype616_0,
};

static const long offsets616 [] =
{
+ @CHROFF(0,0),
};

extern const char *names617[];
static const uint32 types617 [] =
{
SK_BOOL,
};

static const uint16 attr_flags617 [] =
{0,};

static const EIF_TYPE_INDEX g_atype617_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes617 [] = {
g_atype617_0,
};

static const long offsets617 [] =
{
+ @CHROFF(0,0),
};

extern const char *names618[];
static const uint32 types618 [] =
{
SK_BOOL,
};

static const uint16 attr_flags618 [] =
{0,};

static const EIF_TYPE_INDEX g_atype618_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes618 [] = {
g_atype618_0,
};

static const long offsets618 [] =
{
+ @CHROFF(0,0),
};

extern const char *names619[];
static const uint32 types619 [] =
{
SK_BOOL,
};

static const uint16 attr_flags619 [] =
{0,};

static const EIF_TYPE_INDEX g_atype619_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes619 [] = {
g_atype619_0,
};

static const long offsets619 [] =
{
+ @CHROFF(0,0),
};

extern const char *names620[];
static const uint32 types620 [] =
{
SK_BOOL,
};

static const uint16 attr_flags620 [] =
{0,};

static const EIF_TYPE_INDEX g_atype620_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes620 [] = {
g_atype620_0,
};

static const long offsets620 [] =
{
+ @CHROFF(0,0),
};

extern const char *names621[];
static const uint32 types621 [] =
{
SK_BOOL,
};

static const uint16 attr_flags621 [] =
{0,};

static const EIF_TYPE_INDEX g_atype621_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes621 [] = {
g_atype621_0,
};

static const long offsets621 [] =
{
+ @CHROFF(0,0),
};

extern const char *names622[];
static const uint32 types622 [] =
{
SK_BOOL,
};

static const uint16 attr_flags622 [] =
{0,};

static const EIF_TYPE_INDEX g_atype622_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes622 [] = {
g_atype622_0,
};

static const long offsets622 [] =
{
+ @CHROFF(0,0),
};

extern const char *names623[];
static const uint32 types623 [] =
{
SK_BOOL,
};

static const uint16 attr_flags623 [] =
{0,};

static const EIF_TYPE_INDEX g_atype623_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes623 [] = {
g_atype623_0,
};

static const long offsets623 [] =
{
+ @CHROFF(0,0),
};

extern const char *names624[];
static const uint32 types624 [] =
{
SK_BOOL,
};

static const uint16 attr_flags624 [] =
{0,};

static const EIF_TYPE_INDEX g_atype624_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes624 [] = {
g_atype624_0,
};

static const long offsets624 [] =
{
+ @CHROFF(0,0),
};

extern const char *names625[];
static const uint32 types625 [] =
{
SK_BOOL,
};

static const uint16 attr_flags625 [] =
{0,};

static const EIF_TYPE_INDEX g_atype625_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes625 [] = {
g_atype625_0,
};

static const long offsets625 [] =
{
+ @CHROFF(0,0),
};

extern const char *names626[];
static const uint32 types626 [] =
{
SK_BOOL,
};

static const uint16 attr_flags626 [] =
{0,};

static const EIF_TYPE_INDEX g_atype626_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes626 [] = {
g_atype626_0,
};

static const long offsets626 [] =
{
+ @CHROFF(0,0),
};

extern const char *names627[];
static const uint32 types627 [] =
{
SK_BOOL,
};

static const uint16 attr_flags627 [] =
{0,};

static const EIF_TYPE_INDEX g_atype627_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes627 [] = {
g_atype627_0,
};

static const long offsets627 [] =
{
+ @CHROFF(0,0),
};

extern const char *names628[];
static const uint32 types628 [] =
{
SK_BOOL,
};

static const uint16 attr_flags628 [] =
{0,};

static const EIF_TYPE_INDEX g_atype628_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes628 [] = {
g_atype628_0,
};

static const long offsets628 [] =
{
+ @CHROFF(0,0),
};

extern const char *names629[];
static const uint32 types629 [] =
{
SK_BOOL,
};

static const uint16 attr_flags629 [] =
{0,};

static const EIF_TYPE_INDEX g_atype629_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes629 [] = {
g_atype629_0,
};

static const long offsets629 [] =
{
+ @CHROFF(0,0),
};

extern const char *names630[];
static const uint32 types630 [] =
{
SK_BOOL,
};

static const uint16 attr_flags630 [] =
{0,};

static const EIF_TYPE_INDEX g_atype630_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes630 [] = {
g_atype630_0,
};

static const long offsets630 [] =
{
+ @CHROFF(0,0),
};

extern const char *names631[];
static const uint32 types631 [] =
{
SK_BOOL,
};

static const uint16 attr_flags631 [] =
{0,};

static const EIF_TYPE_INDEX g_atype631_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes631 [] = {
g_atype631_0,
};

static const long offsets631 [] =
{
+ @CHROFF(0,0),
};

extern const char *names632[];
static const uint32 types632 [] =
{
SK_BOOL,
};

static const uint16 attr_flags632 [] =
{0,};

static const EIF_TYPE_INDEX g_atype632_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes632 [] = {
g_atype632_0,
};

static const long offsets632 [] =
{
+ @CHROFF(0,0),
};

extern const char *names633[];
static const uint32 types633 [] =
{
SK_BOOL,
};

static const uint16 attr_flags633 [] =
{0,};

static const EIF_TYPE_INDEX g_atype633_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes633 [] = {
g_atype633_0,
};

static const long offsets633 [] =
{
+ @CHROFF(0,0),
};

extern const char *names634[];
static const uint32 types634 [] =
{
SK_BOOL,
};

static const uint16 attr_flags634 [] =
{0,};

static const EIF_TYPE_INDEX g_atype634_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes634 [] = {
g_atype634_0,
};

static const long offsets634 [] =
{
+ @CHROFF(0,0),
};

extern const char *names635[];
static const uint32 types635 [] =
{
SK_BOOL,
};

static const uint16 attr_flags635 [] =
{0,};

static const EIF_TYPE_INDEX g_atype635_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes635 [] = {
g_atype635_0,
};

static const long offsets635 [] =
{
+ @CHROFF(0,0),
};

extern const char *names636[];
static const uint32 types636 [] =
{
SK_BOOL,
};

static const uint16 attr_flags636 [] =
{0,};

static const EIF_TYPE_INDEX g_atype636_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes636 [] = {
g_atype636_0,
};

static const long offsets636 [] =
{
+ @CHROFF(0,0),
};

extern const char *names637[];
static const uint32 types637 [] =
{
SK_BOOL,
};

static const uint16 attr_flags637 [] =
{0,};

static const EIF_TYPE_INDEX g_atype637_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes637 [] = {
g_atype637_0,
};

static const long offsets637 [] =
{
+ @CHROFF(0,0),
};

extern const char *names638[];
static const uint32 types638 [] =
{
SK_BOOL,
};

static const uint16 attr_flags638 [] =
{0,};

static const EIF_TYPE_INDEX g_atype638_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes638 [] = {
g_atype638_0,
};

static const long offsets638 [] =
{
+ @CHROFF(0,0),
};

extern const char *names639[];
static const uint32 types639 [] =
{
SK_BOOL,
};

static const uint16 attr_flags639 [] =
{0,};

static const EIF_TYPE_INDEX g_atype639_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes639 [] = {
g_atype639_0,
};

static const long offsets639 [] =
{
+ @CHROFF(0,0),
};

extern const char *names640[];
static const uint32 types640 [] =
{
SK_BOOL,
};

static const uint16 attr_flags640 [] =
{0,};

static const EIF_TYPE_INDEX g_atype640_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes640 [] = {
g_atype640_0,
};

static const long offsets640 [] =
{
+ @CHROFF(0,0),
};

extern const char *names641[];
static const uint32 types641 [] =
{
SK_BOOL,
};

static const uint16 attr_flags641 [] =
{0,};

static const EIF_TYPE_INDEX g_atype641_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes641 [] = {
g_atype641_0,
};

static const long offsets641 [] =
{
+ @CHROFF(0,0),
};

extern const char *names642[];
static const uint32 types642 [] =
{
SK_BOOL,
};

static const uint16 attr_flags642 [] =
{0,};

static const EIF_TYPE_INDEX g_atype642_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes642 [] = {
g_atype642_0,
};

static const long offsets642 [] =
{
+ @CHROFF(0,0),
};

extern const char *names643[];
static const uint32 types643 [] =
{
SK_BOOL,
};

static const uint16 attr_flags643 [] =
{0,};

static const EIF_TYPE_INDEX g_atype643_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes643 [] = {
g_atype643_0,
};

static const long offsets643 [] =
{
+ @CHROFF(0,0),
};

extern const char *names644[];
static const uint32 types644 [] =
{
SK_BOOL,
};

static const uint16 attr_flags644 [] =
{0,};

static const EIF_TYPE_INDEX g_atype644_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes644 [] = {
g_atype644_0,
};

static const long offsets644 [] =
{
+ @CHROFF(0,0),
};

extern const char *names645[];
static const uint32 types645 [] =
{
SK_BOOL,
};

static const uint16 attr_flags645 [] =
{0,};

static const EIF_TYPE_INDEX g_atype645_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes645 [] = {
g_atype645_0,
};

static const long offsets645 [] =
{
+ @CHROFF(0,0),
};

extern const char *names646[];
static const uint32 types646 [] =
{
SK_BOOL,
};

static const uint16 attr_flags646 [] =
{0,};

static const EIF_TYPE_INDEX g_atype646_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes646 [] = {
g_atype646_0,
};

static const long offsets646 [] =
{
+ @CHROFF(0,0),
};

extern const char *names647[];
static const uint32 types647 [] =
{
SK_BOOL,
};

static const uint16 attr_flags647 [] =
{0,};

static const EIF_TYPE_INDEX g_atype647_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes647 [] = {
g_atype647_0,
};

static const long offsets647 [] =
{
+ @CHROFF(0,0),
};

extern const char *names648[];
static const uint32 types648 [] =
{
SK_BOOL,
};

static const uint16 attr_flags648 [] =
{0,};

static const EIF_TYPE_INDEX g_atype648_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes648 [] = {
g_atype648_0,
};

static const long offsets648 [] =
{
+ @CHROFF(0,0),
};

extern const char *names649[];
static const uint32 types649 [] =
{
SK_BOOL,
};

static const uint16 attr_flags649 [] =
{0,};

static const EIF_TYPE_INDEX g_atype649_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes649 [] = {
g_atype649_0,
};

static const long offsets649 [] =
{
+ @CHROFF(0,0),
};

extern const char *names650[];
static const uint32 types650 [] =
{
SK_BOOL,
};

static const uint16 attr_flags650 [] =
{0,};

static const EIF_TYPE_INDEX g_atype650_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes650 [] = {
g_atype650_0,
};

static const long offsets650 [] =
{
+ @CHROFF(0,0),
};

extern const char *names651[];
static const uint32 types651 [] =
{
SK_BOOL,
};

static const uint16 attr_flags651 [] =
{0,};

static const EIF_TYPE_INDEX g_atype651_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes651 [] = {
g_atype651_0,
};

static const long offsets651 [] =
{
+ @CHROFF(0,0),
};

extern const char *names652[];
static const uint32 types652 [] =
{
SK_BOOL,
};

static const uint16 attr_flags652 [] =
{0,};

static const EIF_TYPE_INDEX g_atype652_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes652 [] = {
g_atype652_0,
};

static const long offsets652 [] =
{
+ @CHROFF(0,0),
};

extern const char *names653[];
static const uint32 types653 [] =
{
SK_BOOL,
};

static const uint16 attr_flags653 [] =
{0,};

static const EIF_TYPE_INDEX g_atype653_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes653 [] = {
g_atype653_0,
};

static const long offsets653 [] =
{
+ @CHROFF(0,0),
};

extern const char *names654[];
static const uint32 types654 [] =
{
SK_BOOL,
};

static const uint16 attr_flags654 [] =
{0,};

static const EIF_TYPE_INDEX g_atype654_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes654 [] = {
g_atype654_0,
};

static const long offsets654 [] =
{
+ @CHROFF(0,0),
};

extern const char *names655[];
static const uint32 types655 [] =
{
SK_BOOL,
};

static const uint16 attr_flags655 [] =
{0,};

static const EIF_TYPE_INDEX g_atype655_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes655 [] = {
g_atype655_0,
};

static const long offsets655 [] =
{
+ @CHROFF(0,0),
};

extern const char *names656[];
static const uint32 types656 [] =
{
SK_BOOL,
};

static const uint16 attr_flags656 [] =
{0,};

static const EIF_TYPE_INDEX g_atype656_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes656 [] = {
g_atype656_0,
};

static const long offsets656 [] =
{
+ @CHROFF(0,0),
};

extern const char *names657[];
static const uint32 types657 [] =
{
SK_BOOL,
};

static const uint16 attr_flags657 [] =
{0,};

static const EIF_TYPE_INDEX g_atype657_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes657 [] = {
g_atype657_0,
};

static const long offsets657 [] =
{
+ @CHROFF(0,0),
};

extern const char *names658[];
static const uint32 types658 [] =
{
SK_BOOL,
};

static const uint16 attr_flags658 [] =
{0,};

static const EIF_TYPE_INDEX g_atype658_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes658 [] = {
g_atype658_0,
};

static const long offsets658 [] =
{
+ @CHROFF(0,0),
};

extern const char *names659[];
static const uint32 types659 [] =
{
SK_BOOL,
};

static const uint16 attr_flags659 [] =
{0,};

static const EIF_TYPE_INDEX g_atype659_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes659 [] = {
g_atype659_0,
};

static const long offsets659 [] =
{
+ @CHROFF(0,0),
};

extern const char *names660[];
static const uint32 types660 [] =
{
SK_BOOL,
};

static const uint16 attr_flags660 [] =
{0,};

static const EIF_TYPE_INDEX g_atype660_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes660 [] = {
g_atype660_0,
};

static const long offsets660 [] =
{
+ @CHROFF(0,0),
};

extern const char *names661[];
static const uint32 types661 [] =
{
SK_BOOL,
};

static const uint16 attr_flags661 [] =
{0,};

static const EIF_TYPE_INDEX g_atype661_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes661 [] = {
g_atype661_0,
};

static const long offsets661 [] =
{
+ @CHROFF(0,0),
};

extern const char *names662[];
static const uint32 types662 [] =
{
SK_BOOL,
};

static const uint16 attr_flags662 [] =
{0,};

static const EIF_TYPE_INDEX g_atype662_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes662 [] = {
g_atype662_0,
};

static const long offsets662 [] =
{
+ @CHROFF(0,0),
};

extern const char *names663[];
static const uint32 types663 [] =
{
SK_BOOL,
};

static const uint16 attr_flags663 [] =
{0,};

static const EIF_TYPE_INDEX g_atype663_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes663 [] = {
g_atype663_0,
};

static const long offsets663 [] =
{
+ @CHROFF(0,0),
};

extern const char *names664[];
static const uint32 types664 [] =
{
SK_BOOL,
};

static const uint16 attr_flags664 [] =
{0,};

static const EIF_TYPE_INDEX g_atype664_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes664 [] = {
g_atype664_0,
};

static const long offsets664 [] =
{
+ @CHROFF(0,0),
};

extern const char *names665[];
static const uint32 types665 [] =
{
SK_BOOL,
};

static const uint16 attr_flags665 [] =
{0,};

static const EIF_TYPE_INDEX g_atype665_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes665 [] = {
g_atype665_0,
};

static const long offsets665 [] =
{
+ @CHROFF(0,0),
};

extern const char *names666[];
static const uint32 types666 [] =
{
SK_BOOL,
};

static const uint16 attr_flags666 [] =
{0,};

static const EIF_TYPE_INDEX g_atype666_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes666 [] = {
g_atype666_0,
};

static const long offsets666 [] =
{
+ @CHROFF(0,0),
};

extern const char *names667[];
static const uint32 types667 [] =
{
SK_BOOL,
};

static const uint16 attr_flags667 [] =
{0,};

static const EIF_TYPE_INDEX g_atype667_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes667 [] = {
g_atype667_0,
};

static const long offsets667 [] =
{
+ @CHROFF(0,0),
};

extern const char *names668[];
static const uint32 types668 [] =
{
SK_BOOL,
};

static const uint16 attr_flags668 [] =
{0,};

static const EIF_TYPE_INDEX g_atype668_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes668 [] = {
g_atype668_0,
};

static const long offsets668 [] =
{
+ @CHROFF(0,0),
};

extern const char *names669[];
static const uint32 types669 [] =
{
SK_BOOL,
};

static const uint16 attr_flags669 [] =
{0,};

static const EIF_TYPE_INDEX g_atype669_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes669 [] = {
g_atype669_0,
};

static const long offsets669 [] =
{
+ @CHROFF(0,0),
};

extern const char *names670[];
static const uint32 types670 [] =
{
SK_BOOL,
};

static const uint16 attr_flags670 [] =
{0,};

static const EIF_TYPE_INDEX g_atype670_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes670 [] = {
g_atype670_0,
};

static const long offsets670 [] =
{
+ @CHROFF(0,0),
};

extern const char *names671[];
static const uint32 types671 [] =
{
SK_BOOL,
};

static const uint16 attr_flags671 [] =
{0,};

static const EIF_TYPE_INDEX g_atype671_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes671 [] = {
g_atype671_0,
};

static const long offsets671 [] =
{
+ @CHROFF(0,0),
};

extern const char *names672[];
static const uint32 types672 [] =
{
SK_BOOL,
};

static const uint16 attr_flags672 [] =
{0,};

static const EIF_TYPE_INDEX g_atype672_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes672 [] = {
g_atype672_0,
};

static const long offsets672 [] =
{
+ @CHROFF(0,0),
};

extern const char *names673[];
static const uint32 types673 [] =
{
SK_BOOL,
};

static const uint16 attr_flags673 [] =
{0,};

static const EIF_TYPE_INDEX g_atype673_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes673 [] = {
g_atype673_0,
};

static const long offsets673 [] =
{
+ @CHROFF(0,0),
};

extern const char *names674[];
static const uint32 types674 [] =
{
SK_BOOL,
};

static const uint16 attr_flags674 [] =
{0,};

static const EIF_TYPE_INDEX g_atype674_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes674 [] = {
g_atype674_0,
};

static const long offsets674 [] =
{
+ @CHROFF(0,0),
};

extern const char *names675[];
static const uint32 types675 [] =
{
SK_BOOL,
};

static const uint16 attr_flags675 [] =
{0,};

static const EIF_TYPE_INDEX g_atype675_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes675 [] = {
g_atype675_0,
};

static const long offsets675 [] =
{
+ @CHROFF(0,0),
};

extern const char *names676[];
static const uint32 types676 [] =
{
SK_BOOL,
};

static const uint16 attr_flags676 [] =
{0,};

static const EIF_TYPE_INDEX g_atype676_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes676 [] = {
g_atype676_0,
};

static const long offsets676 [] =
{
+ @CHROFF(0,0),
};

extern const char *names677[];
static const uint32 types677 [] =
{
SK_BOOL,
};

static const uint16 attr_flags677 [] =
{0,};

static const EIF_TYPE_INDEX g_atype677_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes677 [] = {
g_atype677_0,
};

static const long offsets677 [] =
{
+ @CHROFF(0,0),
};

extern const char *names678[];
static const uint32 types678 [] =
{
SK_BOOL,
};

static const uint16 attr_flags678 [] =
{0,};

static const EIF_TYPE_INDEX g_atype678_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes678 [] = {
g_atype678_0,
};

static const long offsets678 [] =
{
+ @CHROFF(0,0),
};

extern const char *names679[];
static const uint32 types679 [] =
{
SK_BOOL,
};

static const uint16 attr_flags679 [] =
{0,};

static const EIF_TYPE_INDEX g_atype679_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes679 [] = {
g_atype679_0,
};

static const long offsets679 [] =
{
+ @CHROFF(0,0),
};

extern const char *names680[];
static const uint32 types680 [] =
{
SK_BOOL,
};

static const uint16 attr_flags680 [] =
{0,};

static const EIF_TYPE_INDEX g_atype680_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes680 [] = {
g_atype680_0,
};

static const long offsets680 [] =
{
+ @CHROFF(0,0),
};

extern const char *names681[];
static const uint32 types681 [] =
{
SK_BOOL,
};

static const uint16 attr_flags681 [] =
{0,};

static const EIF_TYPE_INDEX g_atype681_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes681 [] = {
g_atype681_0,
};

static const long offsets681 [] =
{
+ @CHROFF(0,0),
};

extern const char *names682[];
static const uint32 types682 [] =
{
SK_BOOL,
};

static const uint16 attr_flags682 [] =
{0,};

static const EIF_TYPE_INDEX g_atype682_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes682 [] = {
g_atype682_0,
};

static const long offsets682 [] =
{
+ @CHROFF(0,0),
};

extern const char *names683[];
static const uint32 types683 [] =
{
SK_BOOL,
};

static const uint16 attr_flags683 [] =
{0,};

static const EIF_TYPE_INDEX g_atype683_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes683 [] = {
g_atype683_0,
};

static const long offsets683 [] =
{
+ @CHROFF(0,0),
};

extern const char *names684[];
static const uint32 types684 [] =
{
SK_BOOL,
};

static const uint16 attr_flags684 [] =
{0,};

static const EIF_TYPE_INDEX g_atype684_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes684 [] = {
g_atype684_0,
};

static const long offsets684 [] =
{
+ @CHROFF(0,0),
};

extern const char *names685[];
static const uint32 types685 [] =
{
SK_BOOL,
};

static const uint16 attr_flags685 [] =
{0,};

static const EIF_TYPE_INDEX g_atype685_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes685 [] = {
g_atype685_0,
};

static const long offsets685 [] =
{
+ @CHROFF(0,0),
};

extern const char *names686[];
static const uint32 types686 [] =
{
SK_BOOL,
};

static const uint16 attr_flags686 [] =
{0,};

static const EIF_TYPE_INDEX g_atype686_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes686 [] = {
g_atype686_0,
};

static const long offsets686 [] =
{
+ @CHROFF(0,0),
};

extern const char *names687[];
static const uint32 types687 [] =
{
SK_BOOL,
};

static const uint16 attr_flags687 [] =
{0,};

static const EIF_TYPE_INDEX g_atype687_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes687 [] = {
g_atype687_0,
};

static const long offsets687 [] =
{
+ @CHROFF(0,0),
};

extern const char *names688[];
static const uint32 types688 [] =
{
SK_BOOL,
};

static const uint16 attr_flags688 [] =
{0,};

static const EIF_TYPE_INDEX g_atype688_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes688 [] = {
g_atype688_0,
};

static const long offsets688 [] =
{
+ @CHROFF(0,0),
};

extern const char *names689[];
static const uint32 types689 [] =
{
SK_BOOL,
};

static const uint16 attr_flags689 [] =
{0,};

static const EIF_TYPE_INDEX g_atype689_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes689 [] = {
g_atype689_0,
};

static const long offsets689 [] =
{
+ @CHROFF(0,0),
};

extern const char *names690[];
static const uint32 types690 [] =
{
SK_BOOL,
};

static const uint16 attr_flags690 [] =
{0,};

static const EIF_TYPE_INDEX g_atype690_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes690 [] = {
g_atype690_0,
};

static const long offsets690 [] =
{
+ @CHROFF(0,0),
};

extern const char *names691[];
static const uint32 types691 [] =
{
SK_BOOL,
};

static const uint16 attr_flags691 [] =
{0,};

static const EIF_TYPE_INDEX g_atype691_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes691 [] = {
g_atype691_0,
};

static const long offsets691 [] =
{
+ @CHROFF(0,0),
};

extern const char *names692[];
static const uint32 types692 [] =
{
SK_BOOL,
};

static const uint16 attr_flags692 [] =
{0,};

static const EIF_TYPE_INDEX g_atype692_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes692 [] = {
g_atype692_0,
};

static const long offsets692 [] =
{
+ @CHROFF(0,0),
};

extern const char *names693[];
static const uint32 types693 [] =
{
SK_BOOL,
};

static const uint16 attr_flags693 [] =
{0,};

static const EIF_TYPE_INDEX g_atype693_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes693 [] = {
g_atype693_0,
};

static const long offsets693 [] =
{
+ @CHROFF(0,0),
};

extern const char *names694[];
static const uint32 types694 [] =
{
SK_BOOL,
};

static const uint16 attr_flags694 [] =
{0,};

static const EIF_TYPE_INDEX g_atype694_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes694 [] = {
g_atype694_0,
};

static const long offsets694 [] =
{
+ @CHROFF(0,0),
};

extern const char *names695[];
static const uint32 types695 [] =
{
SK_BOOL,
};

static const uint16 attr_flags695 [] =
{0,};

static const EIF_TYPE_INDEX g_atype695_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes695 [] = {
g_atype695_0,
};

static const long offsets695 [] =
{
+ @CHROFF(0,0),
};

extern const char *names696[];
static const uint32 types696 [] =
{
SK_BOOL,
};

static const uint16 attr_flags696 [] =
{0,};

static const EIF_TYPE_INDEX g_atype696_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes696 [] = {
g_atype696_0,
};

static const long offsets696 [] =
{
+ @CHROFF(0,0),
};

extern const char *names697[];
static const uint32 types697 [] =
{
SK_BOOL,
};

static const uint16 attr_flags697 [] =
{0,};

static const EIF_TYPE_INDEX g_atype697_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes697 [] = {
g_atype697_0,
};

static const long offsets697 [] =
{
+ @CHROFF(0,0),
};

extern const char *names698[];
static const uint32 types698 [] =
{
SK_BOOL,
};

static const uint16 attr_flags698 [] =
{0,};

static const EIF_TYPE_INDEX g_atype698_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes698 [] = {
g_atype698_0,
};

static const long offsets698 [] =
{
+ @CHROFF(0,0),
};

extern const char *names699[];
static const uint32 types699 [] =
{
SK_BOOL,
};

static const uint16 attr_flags699 [] =
{0,};

static const EIF_TYPE_INDEX g_atype699_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes699 [] = {
g_atype699_0,
};

static const long offsets699 [] =
{
+ @CHROFF(0,0),
};

extern const char *names700[];
static const uint32 types700 [] =
{
SK_BOOL,
};

static const uint16 attr_flags700 [] =
{0,};

static const EIF_TYPE_INDEX g_atype700_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes700 [] = {
g_atype700_0,
};

static const long offsets700 [] =
{
+ @CHROFF(0,0),
};

extern const char *names701[];
static const uint32 types701 [] =
{
SK_BOOL,
};

static const uint16 attr_flags701 [] =
{0,};

static const EIF_TYPE_INDEX g_atype701_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes701 [] = {
g_atype701_0,
};

static const long offsets701 [] =
{
+ @CHROFF(0,0),
};

extern const char *names702[];
static const uint32 types702 [] =
{
SK_BOOL,
};

static const uint16 attr_flags702 [] =
{0,};

static const EIF_TYPE_INDEX g_atype702_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes702 [] = {
g_atype702_0,
};

static const long offsets702 [] =
{
+ @CHROFF(0,0),
};

extern const char *names703[];
static const uint32 types703 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags703 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype703_0 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes703 [] = {
g_atype703_0,
g_atype703_1,
};

static const long offsets703 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names704[];
static const uint32 types704 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags704 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype704_0 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes704 [] = {
g_atype704_0,
g_atype704_1,
g_atype704_2,
g_atype704_3,
g_atype704_4,
};

static const long offsets704 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
+ @LNGOFF(0,1,0,2),
+ @LNGOFF(0,1,0,3),
};

extern const char *names705[];
static const uint32 types705 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags705 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype705_0 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes705 [] = {
g_atype705_0,
g_atype705_1,
};

static const long offsets705 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names706[];
static const uint32 types706 [] =
{
SK_BOOL,
};

static const uint16 attr_flags706 [] =
{0,};

static const EIF_TYPE_INDEX g_atype706_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes706 [] = {
g_atype706_0,
};

static const long offsets706 [] =
{
+ @CHROFF(0,0),
};

extern const char *names707[];
static const uint32 types707 [] =
{
SK_BOOL,
};

static const uint16 attr_flags707 [] =
{0,};

static const EIF_TYPE_INDEX g_atype707_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes707 [] = {
g_atype707_0,
};

static const long offsets707 [] =
{
+ @CHROFF(0,0),
};

extern const char *names708[];
static const uint32 types708 [] =
{
SK_BOOL,
};

static const uint16 attr_flags708 [] =
{0,};

static const EIF_TYPE_INDEX g_atype708_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes708 [] = {
g_atype708_0,
};

static const long offsets708 [] =
{
+ @CHROFF(0,0),
};

extern const char *names709[];
static const uint32 types709 [] =
{
SK_BOOL,
};

static const uint16 attr_flags709 [] =
{0,};

static const EIF_TYPE_INDEX g_atype709_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes709 [] = {
g_atype709_0,
};

static const long offsets709 [] =
{
+ @CHROFF(0,0),
};

extern const char *names710[];
static const uint32 types710 [] =
{
SK_BOOL,
};

static const uint16 attr_flags710 [] =
{0,};

static const EIF_TYPE_INDEX g_atype710_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes710 [] = {
g_atype710_0,
};

static const long offsets710 [] =
{
+ @CHROFF(0,0),
};

extern const char *names711[];
static const uint32 types711 [] =
{
SK_BOOL,
};

static const uint16 attr_flags711 [] =
{0,};

static const EIF_TYPE_INDEX g_atype711_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes711 [] = {
g_atype711_0,
};

static const long offsets711 [] =
{
+ @CHROFF(0,0),
};

extern const char *names712[];
static const uint32 types712 [] =
{
SK_BOOL,
};

static const uint16 attr_flags712 [] =
{0,};

static const EIF_TYPE_INDEX g_atype712_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes712 [] = {
g_atype712_0,
};

static const long offsets712 [] =
{
+ @CHROFF(0,0),
};

extern const char *names713[];
static const uint32 types713 [] =
{
SK_BOOL,
};

static const uint16 attr_flags713 [] =
{0,};

static const EIF_TYPE_INDEX g_atype713_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes713 [] = {
g_atype713_0,
};

static const long offsets713 [] =
{
+ @CHROFF(0,0),
};

extern const char *names714[];
static const uint32 types714 [] =
{
SK_BOOL,
};

static const uint16 attr_flags714 [] =
{0,};

static const EIF_TYPE_INDEX g_atype714_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes714 [] = {
g_atype714_0,
};

static const long offsets714 [] =
{
+ @CHROFF(0,0),
};

extern const char *names715[];
static const uint32 types715 [] =
{
SK_BOOL,
};

static const uint16 attr_flags715 [] =
{0,};

static const EIF_TYPE_INDEX g_atype715_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes715 [] = {
g_atype715_0,
};

static const long offsets715 [] =
{
+ @CHROFF(0,0),
};

extern const char *names716[];
static const uint32 types716 [] =
{
SK_BOOL,
};

static const uint16 attr_flags716 [] =
{0,};

static const EIF_TYPE_INDEX g_atype716_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes716 [] = {
g_atype716_0,
};

static const long offsets716 [] =
{
+ @CHROFF(0,0),
};

extern const char *names717[];
static const uint32 types717 [] =
{
SK_BOOL,
};

static const uint16 attr_flags717 [] =
{0,};

static const EIF_TYPE_INDEX g_atype717_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes717 [] = {
g_atype717_0,
};

static const long offsets717 [] =
{
+ @CHROFF(0,0),
};

extern const char *names718[];
static const uint32 types718 [] =
{
SK_BOOL,
};

static const uint16 attr_flags718 [] =
{0,};

static const EIF_TYPE_INDEX g_atype718_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes718 [] = {
g_atype718_0,
};

static const long offsets718 [] =
{
+ @CHROFF(0,0),
};

extern const char *names719[];
static const uint32 types719 [] =
{
SK_BOOL,
};

static const uint16 attr_flags719 [] =
{0,};

static const EIF_TYPE_INDEX g_atype719_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes719 [] = {
g_atype719_0,
};

static const long offsets719 [] =
{
+ @CHROFF(0,0),
};

extern const char *names720[];
static const uint32 types720 [] =
{
SK_BOOL,
};

static const uint16 attr_flags720 [] =
{0,};

static const EIF_TYPE_INDEX g_atype720_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes720 [] = {
g_atype720_0,
};

static const long offsets720 [] =
{
+ @CHROFF(0,0),
};

extern const char *names721[];
static const uint32 types721 [] =
{
SK_BOOL,
};

static const uint16 attr_flags721 [] =
{0,};

static const EIF_TYPE_INDEX g_atype721_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes721 [] = {
g_atype721_0,
};

static const long offsets721 [] =
{
+ @CHROFF(0,0),
};

extern const char *names722[];
static const uint32 types722 [] =
{
SK_BOOL,
};

static const uint16 attr_flags722 [] =
{0,};

static const EIF_TYPE_INDEX g_atype722_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes722 [] = {
g_atype722_0,
};

static const long offsets722 [] =
{
+ @CHROFF(0,0),
};

extern const char *names723[];
static const uint32 types723 [] =
{
SK_BOOL,
};

static const uint16 attr_flags723 [] =
{0,};

static const EIF_TYPE_INDEX g_atype723_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes723 [] = {
g_atype723_0,
};

static const long offsets723 [] =
{
+ @CHROFF(0,0),
};

extern const char *names724[];
static const uint32 types724 [] =
{
SK_BOOL,
};

static const uint16 attr_flags724 [] =
{0,};

static const EIF_TYPE_INDEX g_atype724_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes724 [] = {
g_atype724_0,
};

static const long offsets724 [] =
{
+ @CHROFF(0,0),
};

extern const char *names725[];
static const uint32 types725 [] =
{
SK_BOOL,
};

static const uint16 attr_flags725 [] =
{0,};

static const EIF_TYPE_INDEX g_atype725_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes725 [] = {
g_atype725_0,
};

static const long offsets725 [] =
{
+ @CHROFF(0,0),
};

extern const char *names726[];
static const uint32 types726 [] =
{
SK_BOOL,
};

static const uint16 attr_flags726 [] =
{0,};

static const EIF_TYPE_INDEX g_atype726_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes726 [] = {
g_atype726_0,
};

static const long offsets726 [] =
{
+ @CHROFF(0,0),
};

extern const char *names727[];
static const uint32 types727 [] =
{
SK_BOOL,
};

static const uint16 attr_flags727 [] =
{0,};

static const EIF_TYPE_INDEX g_atype727_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes727 [] = {
g_atype727_0,
};

static const long offsets727 [] =
{
+ @CHROFF(0,0),
};

extern const char *names728[];
static const uint32 types728 [] =
{
SK_BOOL,
};

static const uint16 attr_flags728 [] =
{0,};

static const EIF_TYPE_INDEX g_atype728_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes728 [] = {
g_atype728_0,
};

static const long offsets728 [] =
{
+ @CHROFF(0,0),
};

extern const char *names729[];
static const uint32 types729 [] =
{
SK_BOOL,
};

static const uint16 attr_flags729 [] =
{0,};

static const EIF_TYPE_INDEX g_atype729_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes729 [] = {
g_atype729_0,
};

static const long offsets729 [] =
{
+ @CHROFF(0,0),
};

extern const char *names730[];
static const uint32 types730 [] =
{
SK_BOOL,
};

static const uint16 attr_flags730 [] =
{0,};

static const EIF_TYPE_INDEX g_atype730_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes730 [] = {
g_atype730_0,
};

static const long offsets730 [] =
{
+ @CHROFF(0,0),
};

extern const char *names731[];
static const uint32 types731 [] =
{
SK_BOOL,
};

static const uint16 attr_flags731 [] =
{0,};

static const EIF_TYPE_INDEX g_atype731_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes731 [] = {
g_atype731_0,
};

static const long offsets731 [] =
{
+ @CHROFF(0,0),
};

extern const char *names732[];
static const uint32 types732 [] =
{
SK_BOOL,
};

static const uint16 attr_flags732 [] =
{0,};

static const EIF_TYPE_INDEX g_atype732_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes732 [] = {
g_atype732_0,
};

static const long offsets732 [] =
{
+ @CHROFF(0,0),
};

extern const char *names733[];
static const uint32 types733 [] =
{
SK_BOOL,
};

static const uint16 attr_flags733 [] =
{0,};

static const EIF_TYPE_INDEX g_atype733_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes733 [] = {
g_atype733_0,
};

static const long offsets733 [] =
{
+ @CHROFF(0,0),
};

extern const char *names734[];
static const uint32 types734 [] =
{
SK_BOOL,
};

static const uint16 attr_flags734 [] =
{0,};

static const EIF_TYPE_INDEX g_atype734_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes734 [] = {
g_atype734_0,
};

static const long offsets734 [] =
{
+ @CHROFF(0,0),
};

extern const char *names735[];
static const uint32 types735 [] =
{
SK_BOOL,
};

static const uint16 attr_flags735 [] =
{0,};

static const EIF_TYPE_INDEX g_atype735_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes735 [] = {
g_atype735_0,
};

static const long offsets735 [] =
{
+ @CHROFF(0,0),
};

extern const char *names736[];
static const uint32 types736 [] =
{
SK_BOOL,
};

static const uint16 attr_flags736 [] =
{0,};

static const EIF_TYPE_INDEX g_atype736_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes736 [] = {
g_atype736_0,
};

static const long offsets736 [] =
{
+ @CHROFF(0,0),
};

extern const char *names737[];
static const uint32 types737 [] =
{
SK_BOOL,
};

static const uint16 attr_flags737 [] =
{0,};

static const EIF_TYPE_INDEX g_atype737_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes737 [] = {
g_atype737_0,
};

static const long offsets737 [] =
{
+ @CHROFF(0,0),
};

extern const char *names738[];
static const uint32 types738 [] =
{
SK_BOOL,
};

static const uint16 attr_flags738 [] =
{0,};

static const EIF_TYPE_INDEX g_atype738_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes738 [] = {
g_atype738_0,
};

static const long offsets738 [] =
{
+ @CHROFF(0,0),
};

extern const char *names739[];
static const uint32 types739 [] =
{
SK_BOOL,
};

static const uint16 attr_flags739 [] =
{0,};

static const EIF_TYPE_INDEX g_atype739_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes739 [] = {
g_atype739_0,
};

static const long offsets739 [] =
{
+ @CHROFF(0,0),
};

extern const char *names740[];
static const uint32 types740 [] =
{
SK_BOOL,
};

static const uint16 attr_flags740 [] =
{0,};

static const EIF_TYPE_INDEX g_atype740_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes740 [] = {
g_atype740_0,
};

static const long offsets740 [] =
{
+ @CHROFF(0,0),
};

extern const char *names741[];
static const uint32 types741 [] =
{
SK_BOOL,
};

static const uint16 attr_flags741 [] =
{0,};

static const EIF_TYPE_INDEX g_atype741_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes741 [] = {
g_atype741_0,
};

static const long offsets741 [] =
{
+ @CHROFF(0,0),
};

extern const char *names742[];
static const uint32 types742 [] =
{
SK_BOOL,
};

static const uint16 attr_flags742 [] =
{0,};

static const EIF_TYPE_INDEX g_atype742_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes742 [] = {
g_atype742_0,
};

static const long offsets742 [] =
{
+ @CHROFF(0,0),
};

extern const char *names743[];
static const uint32 types743 [] =
{
SK_BOOL,
};

static const uint16 attr_flags743 [] =
{0,};

static const EIF_TYPE_INDEX g_atype743_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes743 [] = {
g_atype743_0,
};

static const long offsets743 [] =
{
+ @CHROFF(0,0),
};

extern const char *names744[];
static const uint32 types744 [] =
{
SK_BOOL,
};

static const uint16 attr_flags744 [] =
{0,};

static const EIF_TYPE_INDEX g_atype744_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes744 [] = {
g_atype744_0,
};

static const long offsets744 [] =
{
+ @CHROFF(0,0),
};

extern const char *names745[];
static const uint32 types745 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags745 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype745_0 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype745_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype745_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype745_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes745 [] = {
g_atype745_0,
g_atype745_1,
g_atype745_2,
g_atype745_3,
};

static const long offsets745 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names746[];
static const uint32 types746 [] =
{
SK_BOOL,
};

static const uint16 attr_flags746 [] =
{0,};

static const EIF_TYPE_INDEX g_atype746_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes746 [] = {
g_atype746_0,
};

static const long offsets746 [] =
{
+ @CHROFF(0,0),
};

extern const char *names747[];
static const uint32 types747 [] =
{
SK_BOOL,
};

static const uint16 attr_flags747 [] =
{0,};

static const EIF_TYPE_INDEX g_atype747_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes747 [] = {
g_atype747_0,
};

static const long offsets747 [] =
{
+ @CHROFF(0,0),
};

extern const char *names748[];
static const uint32 types748 [] =
{
SK_BOOL,
};

static const uint16 attr_flags748 [] =
{0,};

static const EIF_TYPE_INDEX g_atype748_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes748 [] = {
g_atype748_0,
};

static const long offsets748 [] =
{
+ @CHROFF(0,0),
};

extern const char *names749[];
static const uint32 types749 [] =
{
SK_BOOL,
};

static const uint16 attr_flags749 [] =
{0,};

static const EIF_TYPE_INDEX g_atype749_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes749 [] = {
g_atype749_0,
};

static const long offsets749 [] =
{
+ @CHROFF(0,0),
};

extern const char *names750[];
static const uint32 types750 [] =
{
SK_BOOL,
};

static const uint16 attr_flags750 [] =
{0,};

static const EIF_TYPE_INDEX g_atype750_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes750 [] = {
g_atype750_0,
};

static const long offsets750 [] =
{
+ @CHROFF(0,0),
};

extern const char *names751[];
static const uint32 types751 [] =
{
SK_BOOL,
};

static const uint16 attr_flags751 [] =
{0,};

static const EIF_TYPE_INDEX g_atype751_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes751 [] = {
g_atype751_0,
};

static const long offsets751 [] =
{
+ @CHROFF(0,0),
};

extern const char *names752[];
static const uint32 types752 [] =
{
SK_BOOL,
};

static const uint16 attr_flags752 [] =
{0,};

static const EIF_TYPE_INDEX g_atype752_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes752 [] = {
g_atype752_0,
};

static const long offsets752 [] =
{
+ @CHROFF(0,0),
};

extern const char *names753[];
static const uint32 types753 [] =
{
SK_BOOL,
};

static const uint16 attr_flags753 [] =
{0,};

static const EIF_TYPE_INDEX g_atype753_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes753 [] = {
g_atype753_0,
};

static const long offsets753 [] =
{
+ @CHROFF(0,0),
};

extern const char *names754[];
static const uint32 types754 [] =
{
SK_BOOL,
};

static const uint16 attr_flags754 [] =
{0,};

static const EIF_TYPE_INDEX g_atype754_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes754 [] = {
g_atype754_0,
};

static const long offsets754 [] =
{
+ @CHROFF(0,0),
};

extern const char *names755[];
static const uint32 types755 [] =
{
SK_BOOL,
};

static const uint16 attr_flags755 [] =
{0,};

static const EIF_TYPE_INDEX g_atype755_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes755 [] = {
g_atype755_0,
};

static const long offsets755 [] =
{
+ @CHROFF(0,0),
};

extern const char *names756[];
static const uint32 types756 [] =
{
SK_BOOL,
};

static const uint16 attr_flags756 [] =
{0,};

static const EIF_TYPE_INDEX g_atype756_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes756 [] = {
g_atype756_0,
};

static const long offsets756 [] =
{
+ @CHROFF(0,0),
};

extern const char *names757[];
static const uint32 types757 [] =
{
SK_BOOL,
};

static const uint16 attr_flags757 [] =
{0,};

static const EIF_TYPE_INDEX g_atype757_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes757 [] = {
g_atype757_0,
};

static const long offsets757 [] =
{
+ @CHROFF(0,0),
};

extern const char *names758[];
static const uint32 types758 [] =
{
SK_BOOL,
};

static const uint16 attr_flags758 [] =
{0,};

static const EIF_TYPE_INDEX g_atype758_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes758 [] = {
g_atype758_0,
};

static const long offsets758 [] =
{
+ @CHROFF(0,0),
};

extern const char *names759[];
static const uint32 types759 [] =
{
SK_BOOL,
};

static const uint16 attr_flags759 [] =
{0,};

static const EIF_TYPE_INDEX g_atype759_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes759 [] = {
g_atype759_0,
};

static const long offsets759 [] =
{
+ @CHROFF(0,0),
};

extern const char *names760[];
static const uint32 types760 [] =
{
SK_BOOL,
};

static const uint16 attr_flags760 [] =
{0,};

static const EIF_TYPE_INDEX g_atype760_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes760 [] = {
g_atype760_0,
};

static const long offsets760 [] =
{
+ @CHROFF(0,0),
};

extern const char *names761[];
static const uint32 types761 [] =
{
SK_BOOL,
};

static const uint16 attr_flags761 [] =
{0,};

static const EIF_TYPE_INDEX g_atype761_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes761 [] = {
g_atype761_0,
};

static const long offsets761 [] =
{
+ @CHROFF(0,0),
};

extern const char *names762[];
static const uint32 types762 [] =
{
SK_BOOL,
};

static const uint16 attr_flags762 [] =
{0,};

static const EIF_TYPE_INDEX g_atype762_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes762 [] = {
g_atype762_0,
};

static const long offsets762 [] =
{
+ @CHROFF(0,0),
};

extern const char *names763[];
static const uint32 types763 [] =
{
SK_BOOL,
};

static const uint16 attr_flags763 [] =
{0,};

static const EIF_TYPE_INDEX g_atype763_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes763 [] = {
g_atype763_0,
};

static const long offsets763 [] =
{
+ @CHROFF(0,0),
};

extern const char *names764[];
static const uint32 types764 [] =
{
SK_BOOL,
};

static const uint16 attr_flags764 [] =
{0,};

static const EIF_TYPE_INDEX g_atype764_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes764 [] = {
g_atype764_0,
};

static const long offsets764 [] =
{
+ @CHROFF(0,0),
};

extern const char *names765[];
static const uint32 types765 [] =
{
SK_BOOL,
};

static const uint16 attr_flags765 [] =
{0,};

static const EIF_TYPE_INDEX g_atype765_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes765 [] = {
g_atype765_0,
};

static const long offsets765 [] =
{
+ @CHROFF(0,0),
};

extern const char *names766[];
static const uint32 types766 [] =
{
SK_BOOL,
};

static const uint16 attr_flags766 [] =
{0,};

static const EIF_TYPE_INDEX g_atype766_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes766 [] = {
g_atype766_0,
};

static const long offsets766 [] =
{
+ @CHROFF(0,0),
};

extern const char *names767[];
static const uint32 types767 [] =
{
SK_BOOL,
};

static const uint16 attr_flags767 [] =
{0,};

static const EIF_TYPE_INDEX g_atype767_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes767 [] = {
g_atype767_0,
};

static const long offsets767 [] =
{
+ @CHROFF(0,0),
};

extern const char *names768[];
static const uint32 types768 [] =
{
SK_BOOL,
};

static const uint16 attr_flags768 [] =
{0,};

static const EIF_TYPE_INDEX g_atype768_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes768 [] = {
g_atype768_0,
};

static const long offsets768 [] =
{
+ @CHROFF(0,0),
};

extern const char *names769[];
static const uint32 types769 [] =
{
SK_BOOL,
};

static const uint16 attr_flags769 [] =
{0,};

static const EIF_TYPE_INDEX g_atype769_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes769 [] = {
g_atype769_0,
};

static const long offsets769 [] =
{
+ @CHROFF(0,0),
};

extern const char *names770[];
static const uint32 types770 [] =
{
SK_BOOL,
};

static const uint16 attr_flags770 [] =
{0,};

static const EIF_TYPE_INDEX g_atype770_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes770 [] = {
g_atype770_0,
};

static const long offsets770 [] =
{
+ @CHROFF(0,0),
};

extern const char *names771[];
static const uint32 types771 [] =
{
SK_BOOL,
};

static const uint16 attr_flags771 [] =
{0,};

static const EIF_TYPE_INDEX g_atype771_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes771 [] = {
g_atype771_0,
};

static const long offsets771 [] =
{
+ @CHROFF(0,0),
};

extern const char *names772[];
static const uint32 types772 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags772 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype772_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_1 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_3 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_4 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_7 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_8 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_9 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_10 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_11 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_15 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_16 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_17 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_18 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_19 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes772 [] = {
g_atype772_0,
g_atype772_1,
g_atype772_2,
g_atype772_3,
g_atype772_4,
g_atype772_5,
g_atype772_6,
g_atype772_7,
g_atype772_8,
g_atype772_9,
g_atype772_10,
g_atype772_11,
g_atype772_12,
g_atype772_13,
g_atype772_14,
g_atype772_15,
g_atype772_16,
g_atype772_17,
g_atype772_18,
g_atype772_19,
};

static const long offsets772 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @I16OFF(3,6,0),
+ @I16OFF(3,6,1),
+ @LNGOFF(3,6,2,0),
+ @LNGOFF(3,6,2,1),
+ @LNGOFF(3,6,2,2),
+ @LNGOFF(3,6,2,3),
+ @R32OFF(3,6,2,4,0),
+ @PTROFF(3,6,2,4,1,0),
+ @I64OFF(3,6,2,4,1,1,0),
+ @I64OFF(3,6,2,4,1,1,1),
+ @R64OFF(3,6,2,4,1,1,2,0),
};

extern const char *names773[];
static const uint32 types773 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags773 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype773_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_1 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_4 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_5 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_8 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_9 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_10 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_11 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_12 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_16 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_17 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_18 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_19 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_20 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes773 [] = {
g_atype773_0,
g_atype773_1,
g_atype773_2,
g_atype773_3,
g_atype773_4,
g_atype773_5,
g_atype773_6,
g_atype773_7,
g_atype773_8,
g_atype773_9,
g_atype773_10,
g_atype773_11,
g_atype773_12,
g_atype773_13,
g_atype773_14,
g_atype773_15,
g_atype773_16,
g_atype773_17,
g_atype773_18,
g_atype773_19,
g_atype773_20,
};

static const long offsets773 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @I16OFF(4,6,0),
+ @I16OFF(4,6,1),
+ @LNGOFF(4,6,2,0),
+ @LNGOFF(4,6,2,1),
+ @LNGOFF(4,6,2,2),
+ @LNGOFF(4,6,2,3),
+ @R32OFF(4,6,2,4,0),
+ @PTROFF(4,6,2,4,1,0),
+ @I64OFF(4,6,2,4,1,1,0),
+ @I64OFF(4,6,2,4,1,1,1),
+ @R64OFF(4,6,2,4,1,1,2,0),
};

extern const char *names774[];
static const uint32 types774 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags774 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype774_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_1 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_3 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_4 [] = {58,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_5 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_6 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_10 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_11 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_12 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_13 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_14 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_17 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_18 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_19 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_20 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_21 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_22 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes774 [] = {
g_atype774_0,
g_atype774_1,
g_atype774_2,
g_atype774_3,
g_atype774_4,
g_atype774_5,
g_atype774_6,
g_atype774_7,
g_atype774_8,
g_atype774_9,
g_atype774_10,
g_atype774_11,
g_atype774_12,
g_atype774_13,
g_atype774_14,
g_atype774_15,
g_atype774_16,
g_atype774_17,
g_atype774_18,
g_atype774_19,
g_atype774_20,
g_atype774_21,
g_atype774_22,
};

static const long offsets774 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names783[];
static const uint32 types783 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags783 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype783_0 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype783_1 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes783 [] = {
g_atype783_0,
g_atype783_1,
};

static const long offsets783 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names796[];
static const uint32 types796 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags796 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype796_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_1 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_2 [] = {1108,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_3 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_4 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_5 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_6 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_16 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes796 [] = {
g_atype796_0,
g_atype796_1,
g_atype796_2,
g_atype796_3,
g_atype796_4,
g_atype796_5,
g_atype796_6,
g_atype796_7,
g_atype796_8,
g_atype796_9,
g_atype796_10,
g_atype796_11,
g_atype796_12,
g_atype796_13,
g_atype796_14,
g_atype796_15,
g_atype796_16,
};

static const long offsets796 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
+ @LNGOFF(7,3,0,1),
+ @LNGOFF(7,3,0,2),
+ @LNGOFF(7,3,0,3),
+ @LNGOFF(7,3,0,4),
+ @LNGOFF(7,3,0,5),
+ @LNGOFF(7,3,0,6),
};

extern const char *names797[];
static const uint32 types797 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags797 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype797_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_1 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_2 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_3 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_4 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_5 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_16 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes797 [] = {
g_atype797_0,
g_atype797_1,
g_atype797_2,
g_atype797_3,
g_atype797_4,
g_atype797_5,
g_atype797_6,
g_atype797_7,
g_atype797_8,
g_atype797_9,
g_atype797_10,
g_atype797_11,
g_atype797_12,
g_atype797_13,
g_atype797_14,
g_atype797_15,
g_atype797_16,
};

static const long offsets797 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
+ @LNGOFF(6,3,0,5),
+ @LNGOFF(6,3,0,6),
+ @LNGOFF(6,3,0,7),
};

extern const char *names798[];
static const uint32 types798 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags798 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype798_0 [] = {1111,1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_1 [] = {1108,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_2 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_3 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_4 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_15 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_16 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes798 [] = {
g_atype798_0,
g_atype798_1,
g_atype798_2,
g_atype798_3,
g_atype798_4,
g_atype798_5,
g_atype798_6,
g_atype798_7,
g_atype798_8,
g_atype798_9,
g_atype798_10,
g_atype798_11,
g_atype798_12,
g_atype798_13,
g_atype798_14,
g_atype798_15,
g_atype798_16,
};

static const long offsets798 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @PTROFF(5,3,0,7,0,0),
+ @PTROFF(5,3,0,7,0,1),
};

extern const char *names799[];
static const uint32 types799 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags799 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype799_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_1 [] = {1108,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_2 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_3 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_4 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_16 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes799 [] = {
g_atype799_0,
g_atype799_1,
g_atype799_2,
g_atype799_3,
g_atype799_4,
g_atype799_5,
g_atype799_6,
g_atype799_7,
g_atype799_8,
g_atype799_9,
g_atype799_10,
g_atype799_11,
g_atype799_12,
g_atype799_13,
g_atype799_14,
g_atype799_15,
g_atype799_16,
};

static const long offsets799 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names800[];
static const uint32 types800 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags800 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype800_0 [] = {1114,1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_1 [] = {1108,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_2 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_3 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_4 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_8 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_9 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_16 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes800 [] = {
g_atype800_0,
g_atype800_1,
g_atype800_2,
g_atype800_3,
g_atype800_4,
g_atype800_5,
g_atype800_6,
g_atype800_7,
g_atype800_8,
g_atype800_9,
g_atype800_10,
g_atype800_11,
g_atype800_12,
g_atype800_13,
g_atype800_14,
g_atype800_15,
g_atype800_16,
};

static const long offsets800 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names801[];
static const uint32 types801 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags801 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype801_0 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_1 [] = {1108,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_2 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_3 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_4 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_16 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes801 [] = {
g_atype801_0,
g_atype801_1,
g_atype801_2,
g_atype801_3,
g_atype801_4,
g_atype801_5,
g_atype801_6,
g_atype801_7,
g_atype801_8,
g_atype801_9,
g_atype801_10,
g_atype801_11,
g_atype801_12,
g_atype801_13,
g_atype801_14,
g_atype801_15,
g_atype801_16,
};

static const long offsets801 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
+ @LNGOFF(5,5,0,1),
+ @LNGOFF(5,5,0,2),
+ @LNGOFF(5,5,0,3),
+ @LNGOFF(5,5,0,4),
+ @LNGOFF(5,5,0,5),
+ @LNGOFF(5,5,0,6),
};

extern const char *names802[];
static const uint32 types802 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags802 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype802_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_1 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_2 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_3 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_16 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes802 [] = {
g_atype802_0,
g_atype802_1,
g_atype802_2,
g_atype802_3,
g_atype802_4,
g_atype802_5,
g_atype802_6,
g_atype802_7,
g_atype802_8,
g_atype802_9,
g_atype802_10,
g_atype802_11,
g_atype802_12,
g_atype802_13,
g_atype802_14,
g_atype802_15,
g_atype802_16,
};

static const long offsets802 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @LNGOFF(4,3,0,3),
+ @LNGOFF(4,3,0,4),
+ @LNGOFF(4,3,0,5),
+ @LNGOFF(4,3,0,6),
+ @LNGOFF(4,3,0,7),
+ @LNGOFF(4,3,0,8),
+ @LNGOFF(4,3,0,9),
};

extern const char *names803[];
static const uint32 types803 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_UINT8,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags803 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype803_0 [] = {1116,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_1 [] = {1108,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_2 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_3 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_4 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_8 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_9 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_16 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes803 [] = {
g_atype803_0,
g_atype803_1,
g_atype803_2,
g_atype803_3,
g_atype803_4,
g_atype803_5,
g_atype803_6,
g_atype803_7,
g_atype803_8,
g_atype803_9,
g_atype803_10,
g_atype803_11,
g_atype803_12,
g_atype803_13,
g_atype803_14,
g_atype803_15,
g_atype803_16,
};

static const long offsets803 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
+ @LNGOFF(5,5,0,1),
+ @LNGOFF(5,5,0,2),
+ @LNGOFF(5,5,0,3),
+ @LNGOFF(5,5,0,4),
+ @LNGOFF(5,5,0,5),
+ @LNGOFF(5,5,0,6),
};

extern const char *names804[];
static const uint32 types804 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags804 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype804_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_1 [] = {1108,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_2 [] = {1108,1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_3 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_4 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_5 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_6 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_7 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_8 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_11 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_17 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_18 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes804 [] = {
g_atype804_0,
g_atype804_1,
g_atype804_2,
g_atype804_3,
g_atype804_4,
g_atype804_5,
g_atype804_6,
g_atype804_7,
g_atype804_8,
g_atype804_9,
g_atype804_10,
g_atype804_11,
g_atype804_12,
g_atype804_13,
g_atype804_14,
g_atype804_15,
g_atype804_16,
g_atype804_17,
g_atype804_18,
};

static const long offsets804 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @LNGOFF(9,3,0,0),
+ @LNGOFF(9,3,0,1),
+ @LNGOFF(9,3,0,2),
+ @LNGOFF(9,3,0,3),
+ @LNGOFF(9,3,0,4),
+ @LNGOFF(9,3,0,5),
+ @LNGOFF(9,3,0,6),
};

extern const char *names805[];
static const uint32 types805 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags805 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype805_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_1 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_2 [] = {1108,1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_3 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_4 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_5 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_6 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_17 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes805 [] = {
g_atype805_0,
g_atype805_1,
g_atype805_2,
g_atype805_3,
g_atype805_4,
g_atype805_5,
g_atype805_6,
g_atype805_7,
g_atype805_8,
g_atype805_9,
g_atype805_10,
g_atype805_11,
g_atype805_12,
g_atype805_13,
g_atype805_14,
g_atype805_15,
g_atype805_16,
g_atype805_17,
};

static const long offsets805 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @LNGOFF(7,4,0,0),
+ @LNGOFF(7,4,0,1),
+ @LNGOFF(7,4,0,2),
+ @LNGOFF(7,4,0,3),
+ @LNGOFF(7,4,0,4),
+ @LNGOFF(7,4,0,5),
+ @LNGOFF(7,4,0,6),
};

extern const char *names806[];
static const uint32 types806 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags806 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype806_0 [] = {1114,1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_1 [] = {1108,1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_2 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_3 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_4 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_9 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_10 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_17 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes806 [] = {
g_atype806_0,
g_atype806_1,
g_atype806_2,
g_atype806_3,
g_atype806_4,
g_atype806_5,
g_atype806_6,
g_atype806_7,
g_atype806_8,
g_atype806_9,
g_atype806_10,
g_atype806_11,
g_atype806_12,
g_atype806_13,
g_atype806_14,
g_atype806_15,
g_atype806_16,
g_atype806_17,
};

static const long offsets806 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names807[];
static const uint32 types807 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags807 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype807_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_1 [] = {1108,1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_2 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_3 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_4 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_17 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes807 [] = {
g_atype807_0,
g_atype807_1,
g_atype807_2,
g_atype807_3,
g_atype807_4,
g_atype807_5,
g_atype807_6,
g_atype807_7,
g_atype807_8,
g_atype807_9,
g_atype807_10,
g_atype807_11,
g_atype807_12,
g_atype807_13,
g_atype807_14,
g_atype807_15,
g_atype807_16,
g_atype807_17,
};

static const long offsets807 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names808[];
static const uint32 types808 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags808 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype808_0 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_1 [] = {1108,1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_2 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_3 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_4 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_17 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes808 [] = {
g_atype808_0,
g_atype808_1,
g_atype808_2,
g_atype808_3,
g_atype808_4,
g_atype808_5,
g_atype808_6,
g_atype808_7,
g_atype808_8,
g_atype808_9,
g_atype808_10,
g_atype808_11,
g_atype808_12,
g_atype808_13,
g_atype808_14,
g_atype808_15,
g_atype808_16,
g_atype808_17,
};

static const long offsets808 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @LNGOFF(5,6,0,0),
+ @LNGOFF(5,6,0,1),
+ @LNGOFF(5,6,0,2),
+ @LNGOFF(5,6,0,3),
+ @LNGOFF(5,6,0,4),
+ @LNGOFF(5,6,0,5),
+ @LNGOFF(5,6,0,6),
};

extern const char *names809[];
static const uint32 types809 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_UINT8,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags809 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype809_0 [] = {1116,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_1 [] = {1108,1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_2 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_3 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_4 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_9 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_10 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_17 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes809 [] = {
g_atype809_0,
g_atype809_1,
g_atype809_2,
g_atype809_3,
g_atype809_4,
g_atype809_5,
g_atype809_6,
g_atype809_7,
g_atype809_8,
g_atype809_9,
g_atype809_10,
g_atype809_11,
g_atype809_12,
g_atype809_13,
g_atype809_14,
g_atype809_15,
g_atype809_16,
g_atype809_17,
};

static const long offsets809 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @LNGOFF(5,6,0,0),
+ @LNGOFF(5,6,0,1),
+ @LNGOFF(5,6,0,2),
+ @LNGOFF(5,6,0,3),
+ @LNGOFF(5,6,0,4),
+ @LNGOFF(5,6,0,5),
+ @LNGOFF(5,6,0,6),
};

extern const char *names810[];
static const uint32 types810 [] =
{
SK_BOOL,
};

static const uint16 attr_flags810 [] =
{0,};

static const EIF_TYPE_INDEX g_atype810_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes810 [] = {
g_atype810_0,
};

static const long offsets810 [] =
{
+ @CHROFF(0,0),
};

extern const char *names811[];
static const uint32 types811 [] =
{
SK_BOOL,
};

static const uint16 attr_flags811 [] =
{0,};

static const EIF_TYPE_INDEX g_atype811_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes811 [] = {
g_atype811_0,
};

static const long offsets811 [] =
{
+ @CHROFF(0,0),
};

extern const char *names812[];
static const uint32 types812 [] =
{
SK_BOOL,
};

static const uint16 attr_flags812 [] =
{0,};

static const EIF_TYPE_INDEX g_atype812_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes812 [] = {
g_atype812_0,
};

static const long offsets812 [] =
{
+ @CHROFF(0,0),
};

extern const char *names813[];
static const uint32 types813 [] =
{
SK_BOOL,
};

static const uint16 attr_flags813 [] =
{0,};

static const EIF_TYPE_INDEX g_atype813_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes813 [] = {
g_atype813_0,
};

static const long offsets813 [] =
{
+ @CHROFF(0,0),
};

extern const char *names814[];
static const uint32 types814 [] =
{
SK_BOOL,
};

static const uint16 attr_flags814 [] =
{0,};

static const EIF_TYPE_INDEX g_atype814_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes814 [] = {
g_atype814_0,
};

static const long offsets814 [] =
{
+ @CHROFF(0,0),
};

extern const char *names815[];
static const uint32 types815 [] =
{
SK_BOOL,
};

static const uint16 attr_flags815 [] =
{0,};

static const EIF_TYPE_INDEX g_atype815_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes815 [] = {
g_atype815_0,
};

static const long offsets815 [] =
{
+ @CHROFF(0,0),
};

extern const char *names816[];
static const uint32 types816 [] =
{
SK_BOOL,
};

static const uint16 attr_flags816 [] =
{0,};

static const EIF_TYPE_INDEX g_atype816_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes816 [] = {
g_atype816_0,
};

static const long offsets816 [] =
{
+ @CHROFF(0,0),
};

extern const char *names817[];
static const uint32 types817 [] =
{
SK_BOOL,
};

static const uint16 attr_flags817 [] =
{0,};

static const EIF_TYPE_INDEX g_atype817_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes817 [] = {
g_atype817_0,
};

static const long offsets817 [] =
{
+ @CHROFF(0,0),
};

extern const char *names818[];
static const uint32 types818 [] =
{
SK_BOOL,
};

static const uint16 attr_flags818 [] =
{0,};

static const EIF_TYPE_INDEX g_atype818_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes818 [] = {
g_atype818_0,
};

static const long offsets818 [] =
{
+ @CHROFF(0,0),
};

extern const char *names819[];
static const uint32 types819 [] =
{
SK_BOOL,
};

static const uint16 attr_flags819 [] =
{0,};

static const EIF_TYPE_INDEX g_atype819_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes819 [] = {
g_atype819_0,
};

static const long offsets819 [] =
{
+ @CHROFF(0,0),
};

extern const char *names820[];
static const uint32 types820 [] =
{
SK_BOOL,
};

static const uint16 attr_flags820 [] =
{0,};

static const EIF_TYPE_INDEX g_atype820_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes820 [] = {
g_atype820_0,
};

static const long offsets820 [] =
{
+ @CHROFF(0,0),
};

extern const char *names821[];
static const uint32 types821 [] =
{
SK_BOOL,
};

static const uint16 attr_flags821 [] =
{0,};

static const EIF_TYPE_INDEX g_atype821_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes821 [] = {
g_atype821_0,
};

static const long offsets821 [] =
{
+ @CHROFF(0,0),
};

extern const char *names822[];
static const uint32 types822 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags822 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype822_0 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes822 [] = {
g_atype822_0,
g_atype822_1,
g_atype822_2,
};

static const long offsets822 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
};

extern const char *names823[];
static const uint32 types823 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags823 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype823_0 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes823 [] = {
g_atype823_0,
g_atype823_1,
g_atype823_2,
g_atype823_3,
};

static const long offsets823 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names824[];
static const uint32 types824 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags824 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype824_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes824 [] = {
g_atype824_0,
g_atype824_1,
g_atype824_2,
g_atype824_3,
};

static const long offsets824 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names825[];
static const uint32 types825 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags825 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype825_0 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes825 [] = {
g_atype825_0,
g_atype825_1,
g_atype825_2,
g_atype825_3,
};

static const long offsets825 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names826[];
static const uint32 types826 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags826 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype826_0 [] = {1111,1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes826 [] = {
g_atype826_0,
g_atype826_1,
g_atype826_2,
g_atype826_3,
};

static const long offsets826 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names827[];
static const uint32 types827 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags827 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype827_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes827 [] = {
g_atype827_0,
g_atype827_1,
g_atype827_2,
g_atype827_3,
};

static const long offsets827 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names828[];
static const uint32 types828 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags828 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype828_0 [] = {1113,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes828 [] = {
g_atype828_0,
g_atype828_1,
g_atype828_2,
g_atype828_3,
};

static const long offsets828 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names829[];
static const uint32 types829 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags829 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype829_0 [] = {1114,1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes829 [] = {
g_atype829_0,
g_atype829_1,
g_atype829_2,
g_atype829_3,
};

static const long offsets829 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names830[];
static const uint32 types830 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags830 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype830_0 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes830 [] = {
g_atype830_0,
g_atype830_1,
g_atype830_2,
g_atype830_3,
};

static const long offsets830 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names831[];
static const uint32 types831 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags831 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype831_0 [] = {1116,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype831_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype831_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype831_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes831 [] = {
g_atype831_0,
g_atype831_1,
g_atype831_2,
g_atype831_3,
};

static const long offsets831 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names832[];
static const uint32 types832 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags832 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype832_0 [] = {1117,1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype832_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype832_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype832_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes832 [] = {
g_atype832_0,
g_atype832_1,
g_atype832_2,
g_atype832_3,
};

static const long offsets832 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names833[];
static const uint32 types833 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags833 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype833_0 [] = {1118,1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype833_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype833_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype833_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes833 [] = {
g_atype833_0,
g_atype833_1,
g_atype833_2,
g_atype833_3,
};

static const long offsets833 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names834[];
static const uint32 types834 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags834 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype834_0 [] = {1119,1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype834_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype834_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype834_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes834 [] = {
g_atype834_0,
g_atype834_1,
g_atype834_2,
g_atype834_3,
};

static const long offsets834 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names835[];
static const uint32 types835 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags835 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype835_0 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype835_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype835_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype835_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes835 [] = {
g_atype835_0,
g_atype835_1,
g_atype835_2,
g_atype835_3,
};

static const long offsets835 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names836[];
static const uint32 types836 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags836 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype836_0 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype836_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype836_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype836_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes836 [] = {
g_atype836_0,
g_atype836_1,
g_atype836_2,
g_atype836_3,
};

static const long offsets836 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names837[];
static const uint32 types837 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags837 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype837_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype837_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype837_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype837_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes837 [] = {
g_atype837_0,
g_atype837_1,
g_atype837_2,
g_atype837_3,
};

static const long offsets837 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names838[];
static const uint32 types838 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags838 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype838_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes838 [] = {
g_atype838_0,
g_atype838_1,
g_atype838_2,
g_atype838_3,
};

static const long offsets838 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names839[];
static const uint32 types839 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags839 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype839_0 [] = {1114,1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype839_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype839_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype839_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes839 [] = {
g_atype839_0,
g_atype839_1,
g_atype839_2,
g_atype839_3,
};

static const long offsets839 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names840[];
static const uint32 types840 [] =
{
SK_BOOL,
};

static const uint16 attr_flags840 [] =
{0,};

static const EIF_TYPE_INDEX g_atype840_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes840 [] = {
g_atype840_0,
};

static const long offsets840 [] =
{
+ @CHROFF(0,0),
};

extern const char *names841[];
static const uint32 types841 [] =
{
SK_BOOL,
};

static const uint16 attr_flags841 [] =
{0,};

static const EIF_TYPE_INDEX g_atype841_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes841 [] = {
g_atype841_0,
};

static const long offsets841 [] =
{
+ @CHROFF(0,0),
};

extern const char *names842[];
static const uint32 types842 [] =
{
SK_BOOL,
};

static const uint16 attr_flags842 [] =
{0,};

static const EIF_TYPE_INDEX g_atype842_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes842 [] = {
g_atype842_0,
};

static const long offsets842 [] =
{
+ @CHROFF(0,0),
};

extern const char *names843[];
static const uint32 types843 [] =
{
SK_BOOL,
};

static const uint16 attr_flags843 [] =
{0,};

static const EIF_TYPE_INDEX g_atype843_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes843 [] = {
g_atype843_0,
};

static const long offsets843 [] =
{
+ @CHROFF(0,0),
};

extern const char *names844[];
static const uint32 types844 [] =
{
SK_BOOL,
};

static const uint16 attr_flags844 [] =
{0,};

static const EIF_TYPE_INDEX g_atype844_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes844 [] = {
g_atype844_0,
};

static const long offsets844 [] =
{
+ @CHROFF(0,0),
};

extern const char *names845[];
static const uint32 types845 [] =
{
SK_BOOL,
};

static const uint16 attr_flags845 [] =
{0,};

static const EIF_TYPE_INDEX g_atype845_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes845 [] = {
g_atype845_0,
};

static const long offsets845 [] =
{
+ @CHROFF(0,0),
};

extern const char *names846[];
static const uint32 types846 [] =
{
SK_BOOL,
};

static const uint16 attr_flags846 [] =
{0,};

static const EIF_TYPE_INDEX g_atype846_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes846 [] = {
g_atype846_0,
};

static const long offsets846 [] =
{
+ @CHROFF(0,0),
};

extern const char *names847[];
static const uint32 types847 [] =
{
SK_BOOL,
};

static const uint16 attr_flags847 [] =
{0,};

static const EIF_TYPE_INDEX g_atype847_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes847 [] = {
g_atype847_0,
};

static const long offsets847 [] =
{
+ @CHROFF(0,0),
};

extern const char *names848[];
static const uint32 types848 [] =
{
SK_BOOL,
};

static const uint16 attr_flags848 [] =
{0,};

static const EIF_TYPE_INDEX g_atype848_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes848 [] = {
g_atype848_0,
};

static const long offsets848 [] =
{
+ @CHROFF(0,0),
};

extern const char *names849[];
static const uint32 types849 [] =
{
SK_BOOL,
};

static const uint16 attr_flags849 [] =
{0,};

static const EIF_TYPE_INDEX g_atype849_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes849 [] = {
g_atype849_0,
};

static const long offsets849 [] =
{
+ @CHROFF(0,0),
};

extern const char *names850[];
static const uint32 types850 [] =
{
SK_BOOL,
};

static const uint16 attr_flags850 [] =
{0,};

static const EIF_TYPE_INDEX g_atype850_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes850 [] = {
g_atype850_0,
};

static const long offsets850 [] =
{
+ @CHROFF(0,0),
};

extern const char *names851[];
static const uint32 types851 [] =
{
SK_BOOL,
};

static const uint16 attr_flags851 [] =
{0,};

static const EIF_TYPE_INDEX g_atype851_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes851 [] = {
g_atype851_0,
};

static const long offsets851 [] =
{
+ @CHROFF(0,0),
};

extern const char *names852[];
static const uint32 types852 [] =
{
SK_BOOL,
};

static const uint16 attr_flags852 [] =
{0,};

static const EIF_TYPE_INDEX g_atype852_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes852 [] = {
g_atype852_0,
};

static const long offsets852 [] =
{
+ @CHROFF(0,0),
};

extern const char *names853[];
static const uint32 types853 [] =
{
SK_BOOL,
};

static const uint16 attr_flags853 [] =
{0,};

static const EIF_TYPE_INDEX g_atype853_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes853 [] = {
g_atype853_0,
};

static const long offsets853 [] =
{
+ @CHROFF(0,0),
};

extern const char *names854[];
static const uint32 types854 [] =
{
SK_BOOL,
};

static const uint16 attr_flags854 [] =
{0,};

static const EIF_TYPE_INDEX g_atype854_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes854 [] = {
g_atype854_0,
};

static const long offsets854 [] =
{
+ @CHROFF(0,0),
};

extern const char *names855[];
static const uint32 types855 [] =
{
SK_BOOL,
};

static const uint16 attr_flags855 [] =
{0,};

static const EIF_TYPE_INDEX g_atype855_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes855 [] = {
g_atype855_0,
};

static const long offsets855 [] =
{
+ @CHROFF(0,0),
};

extern const char *names856[];
static const uint32 types856 [] =
{
SK_BOOL,
};

static const uint16 attr_flags856 [] =
{0,};

static const EIF_TYPE_INDEX g_atype856_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes856 [] = {
g_atype856_0,
};

static const long offsets856 [] =
{
+ @CHROFF(0,0),
};

extern const char *names857[];
static const uint32 types857 [] =
{
SK_BOOL,
};

static const uint16 attr_flags857 [] =
{0,};

static const EIF_TYPE_INDEX g_atype857_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes857 [] = {
g_atype857_0,
};

static const long offsets857 [] =
{
+ @CHROFF(0,0),
};

extern const char *names858[];
static const uint32 types858 [] =
{
SK_BOOL,
};

static const uint16 attr_flags858 [] =
{0,};

static const EIF_TYPE_INDEX g_atype858_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes858 [] = {
g_atype858_0,
};

static const long offsets858 [] =
{
+ @CHROFF(0,0),
};

extern const char *names859[];
static const uint32 types859 [] =
{
SK_BOOL,
};

static const uint16 attr_flags859 [] =
{0,};

static const EIF_TYPE_INDEX g_atype859_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes859 [] = {
g_atype859_0,
};

static const long offsets859 [] =
{
+ @CHROFF(0,0),
};

extern const char *names860[];
static const uint32 types860 [] =
{
SK_BOOL,
};

static const uint16 attr_flags860 [] =
{0,};

static const EIF_TYPE_INDEX g_atype860_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes860 [] = {
g_atype860_0,
};

static const long offsets860 [] =
{
+ @CHROFF(0,0),
};

extern const char *names861[];
static const uint32 types861 [] =
{
SK_BOOL,
};

static const uint16 attr_flags861 [] =
{0,};

static const EIF_TYPE_INDEX g_atype861_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes861 [] = {
g_atype861_0,
};

static const long offsets861 [] =
{
+ @CHROFF(0,0),
};

extern const char *names862[];
static const uint32 types862 [] =
{
SK_BOOL,
};

static const uint16 attr_flags862 [] =
{0,};

static const EIF_TYPE_INDEX g_atype862_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes862 [] = {
g_atype862_0,
};

static const long offsets862 [] =
{
+ @CHROFF(0,0),
};

extern const char *names863[];
static const uint32 types863 [] =
{
SK_BOOL,
};

static const uint16 attr_flags863 [] =
{0,};

static const EIF_TYPE_INDEX g_atype863_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes863 [] = {
g_atype863_0,
};

static const long offsets863 [] =
{
+ @CHROFF(0,0),
};

extern const char *names864[];
static const uint32 types864 [] =
{
SK_BOOL,
};

static const uint16 attr_flags864 [] =
{0,};

static const EIF_TYPE_INDEX g_atype864_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes864 [] = {
g_atype864_0,
};

static const long offsets864 [] =
{
+ @CHROFF(0,0),
};

extern const char *names865[];
static const uint32 types865 [] =
{
SK_BOOL,
};

static const uint16 attr_flags865 [] =
{0,};

static const EIF_TYPE_INDEX g_atype865_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes865 [] = {
g_atype865_0,
};

static const long offsets865 [] =
{
+ @CHROFF(0,0),
};

extern const char *names866[];
static const uint32 types866 [] =
{
SK_BOOL,
};

static const uint16 attr_flags866 [] =
{0,};

static const EIF_TYPE_INDEX g_atype866_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes866 [] = {
g_atype866_0,
};

static const long offsets866 [] =
{
+ @CHROFF(0,0),
};

extern const char *names867[];
static const uint32 types867 [] =
{
SK_BOOL,
};

static const uint16 attr_flags867 [] =
{0,};

static const EIF_TYPE_INDEX g_atype867_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes867 [] = {
g_atype867_0,
};

static const long offsets867 [] =
{
+ @CHROFF(0,0),
};

extern const char *names868[];
static const uint32 types868 [] =
{
SK_BOOL,
};

static const uint16 attr_flags868 [] =
{0,};

static const EIF_TYPE_INDEX g_atype868_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes868 [] = {
g_atype868_0,
};

static const long offsets868 [] =
{
+ @CHROFF(0,0),
};

extern const char *names869[];
static const uint32 types869 [] =
{
SK_BOOL,
};

static const uint16 attr_flags869 [] =
{0,};

static const EIF_TYPE_INDEX g_atype869_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes869 [] = {
g_atype869_0,
};

static const long offsets869 [] =
{
+ @CHROFF(0,0),
};

extern const char *names870[];
static const uint32 types870 [] =
{
SK_BOOL,
};

static const uint16 attr_flags870 [] =
{0,};

static const EIF_TYPE_INDEX g_atype870_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes870 [] = {
g_atype870_0,
};

static const long offsets870 [] =
{
+ @CHROFF(0,0),
};

extern const char *names871[];
static const uint32 types871 [] =
{
SK_BOOL,
};

static const uint16 attr_flags871 [] =
{0,};

static const EIF_TYPE_INDEX g_atype871_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes871 [] = {
g_atype871_0,
};

static const long offsets871 [] =
{
+ @CHROFF(0,0),
};

extern const char *names872[];
static const uint32 types872 [] =
{
SK_BOOL,
};

static const uint16 attr_flags872 [] =
{0,};

static const EIF_TYPE_INDEX g_atype872_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes872 [] = {
g_atype872_0,
};

static const long offsets872 [] =
{
+ @CHROFF(0,0),
};

extern const char *names873[];
static const uint32 types873 [] =
{
SK_BOOL,
};

static const uint16 attr_flags873 [] =
{0,};

static const EIF_TYPE_INDEX g_atype873_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes873 [] = {
g_atype873_0,
};

static const long offsets873 [] =
{
+ @CHROFF(0,0),
};

extern const char *names874[];
static const uint32 types874 [] =
{
SK_BOOL,
};

static const uint16 attr_flags874 [] =
{0,};

static const EIF_TYPE_INDEX g_atype874_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes874 [] = {
g_atype874_0,
};

static const long offsets874 [] =
{
+ @CHROFF(0,0),
};

extern const char *names875[];
static const uint32 types875 [] =
{
SK_BOOL,
};

static const uint16 attr_flags875 [] =
{0,};

static const EIF_TYPE_INDEX g_atype875_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes875 [] = {
g_atype875_0,
};

static const long offsets875 [] =
{
+ @CHROFF(0,0),
};

extern const char *names876[];
static const uint32 types876 [] =
{
SK_BOOL,
};

static const uint16 attr_flags876 [] =
{0,};

static const EIF_TYPE_INDEX g_atype876_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes876 [] = {
g_atype876_0,
};

static const long offsets876 [] =
{
+ @CHROFF(0,0),
};

extern const char *names877[];
static const uint32 types877 [] =
{
SK_BOOL,
};

static const uint16 attr_flags877 [] =
{0,};

static const EIF_TYPE_INDEX g_atype877_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes877 [] = {
g_atype877_0,
};

static const long offsets877 [] =
{
+ @CHROFF(0,0),
};

extern const char *names878[];
static const uint32 types878 [] =
{
SK_BOOL,
};

static const uint16 attr_flags878 [] =
{0,};

static const EIF_TYPE_INDEX g_atype878_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes878 [] = {
g_atype878_0,
};

static const long offsets878 [] =
{
+ @CHROFF(0,0),
};

extern const char *names879[];
static const uint32 types879 [] =
{
SK_BOOL,
};

static const uint16 attr_flags879 [] =
{0,};

static const EIF_TYPE_INDEX g_atype879_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes879 [] = {
g_atype879_0,
};

static const long offsets879 [] =
{
+ @CHROFF(0,0),
};

extern const char *names880[];
static const uint32 types880 [] =
{
SK_BOOL,
};

static const uint16 attr_flags880 [] =
{0,};

static const EIF_TYPE_INDEX g_atype880_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes880 [] = {
g_atype880_0,
};

static const long offsets880 [] =
{
+ @CHROFF(0,0),
};

extern const char *names881[];
static const uint32 types881 [] =
{
SK_BOOL,
};

static const uint16 attr_flags881 [] =
{0,};

static const EIF_TYPE_INDEX g_atype881_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes881 [] = {
g_atype881_0,
};

static const long offsets881 [] =
{
+ @CHROFF(0,0),
};

extern const char *names882[];
static const uint32 types882 [] =
{
SK_BOOL,
};

static const uint16 attr_flags882 [] =
{0,};

static const EIF_TYPE_INDEX g_atype882_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes882 [] = {
g_atype882_0,
};

static const long offsets882 [] =
{
+ @CHROFF(0,0),
};

extern const char *names883[];
static const uint32 types883 [] =
{
SK_BOOL,
};

static const uint16 attr_flags883 [] =
{0,};

static const EIF_TYPE_INDEX g_atype883_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes883 [] = {
g_atype883_0,
};

static const long offsets883 [] =
{
+ @CHROFF(0,0),
};

extern const char *names884[];
static const uint32 types884 [] =
{
SK_BOOL,
};

static const uint16 attr_flags884 [] =
{0,};

static const EIF_TYPE_INDEX g_atype884_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes884 [] = {
g_atype884_0,
};

static const long offsets884 [] =
{
+ @CHROFF(0,0),
};

extern const char *names885[];
static const uint32 types885 [] =
{
SK_BOOL,
};

static const uint16 attr_flags885 [] =
{0,};

static const EIF_TYPE_INDEX g_atype885_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes885 [] = {
g_atype885_0,
};

static const long offsets885 [] =
{
+ @CHROFF(0,0),
};

extern const char *names886[];
static const uint32 types886 [] =
{
SK_BOOL,
};

static const uint16 attr_flags886 [] =
{0,};

static const EIF_TYPE_INDEX g_atype886_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes886 [] = {
g_atype886_0,
};

static const long offsets886 [] =
{
+ @CHROFF(0,0),
};

extern const char *names887[];
static const uint32 types887 [] =
{
SK_BOOL,
};

static const uint16 attr_flags887 [] =
{0,};

static const EIF_TYPE_INDEX g_atype887_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes887 [] = {
g_atype887_0,
};

static const long offsets887 [] =
{
+ @CHROFF(0,0),
};

extern const char *names888[];
static const uint32 types888 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags888 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype888_0 [] = {176,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_1 [] = {176,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes888 [] = {
g_atype888_0,
g_atype888_1,
g_atype888_2,
g_atype888_3,
g_atype888_4,
g_atype888_5,
};

static const long offsets888 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names889[];
static const uint32 types889 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags889 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype889_0 [] = {177,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_1 [] = {177,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes889 [] = {
g_atype889_0,
g_atype889_1,
g_atype889_2,
g_atype889_3,
g_atype889_4,
g_atype889_5,
};

static const long offsets889 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names890[];
static const uint32 types890 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags890 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype890_0 [] = {176,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_1 [] = {176,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes890 [] = {
g_atype890_0,
g_atype890_1,
g_atype890_2,
g_atype890_3,
g_atype890_4,
g_atype890_5,
};

static const long offsets890 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names891[];
static const uint32 types891 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags891 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype891_0 [] = {177,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_1 [] = {177,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes891 [] = {
g_atype891_0,
g_atype891_1,
g_atype891_2,
g_atype891_3,
g_atype891_4,
g_atype891_5,
};

static const long offsets891 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names892[];
static const uint32 types892 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags892 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype892_0 [] = {176,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_1 [] = {176,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes892 [] = {
g_atype892_0,
g_atype892_1,
g_atype892_2,
g_atype892_3,
g_atype892_4,
g_atype892_5,
};

static const long offsets892 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names893[];
static const uint32 types893 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags893 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype893_0 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes893 [] = {
g_atype893_0,
g_atype893_1,
g_atype893_2,
};

static const long offsets893 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names894[];
static const uint32 types894 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags894 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype894_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes894 [] = {
g_atype894_0,
g_atype894_1,
g_atype894_2,
};

static const long offsets894 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names895[];
static const uint32 types895 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags895 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype895_0 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes895 [] = {
g_atype895_0,
g_atype895_1,
g_atype895_2,
};

static const long offsets895 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names896[];
static const uint32 types896 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags896 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype896_0 [] = {1111,1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes896 [] = {
g_atype896_0,
g_atype896_1,
g_atype896_2,
};

static const long offsets896 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names897[];
static const uint32 types897 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags897 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype897_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype897_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype897_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes897 [] = {
g_atype897_0,
g_atype897_1,
g_atype897_2,
};

static const long offsets897 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names898[];
static const uint32 types898 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags898 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype898_0 [] = {1113,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype898_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype898_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes898 [] = {
g_atype898_0,
g_atype898_1,
g_atype898_2,
};

static const long offsets898 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names899[];
static const uint32 types899 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags899 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype899_0 [] = {1114,1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype899_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype899_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes899 [] = {
g_atype899_0,
g_atype899_1,
g_atype899_2,
};

static const long offsets899 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names900[];
static const uint32 types900 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags900 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype900_0 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes900 [] = {
g_atype900_0,
g_atype900_1,
g_atype900_2,
};

static const long offsets900 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names901[];
static const uint32 types901 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags901 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype901_0 [] = {1116,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes901 [] = {
g_atype901_0,
g_atype901_1,
g_atype901_2,
};

static const long offsets901 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names902[];
static const uint32 types902 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags902 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype902_0 [] = {1117,1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes902 [] = {
g_atype902_0,
g_atype902_1,
g_atype902_2,
};

static const long offsets902 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names903[];
static const uint32 types903 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags903 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype903_0 [] = {1118,1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes903 [] = {
g_atype903_0,
g_atype903_1,
g_atype903_2,
};

static const long offsets903 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names904[];
static const uint32 types904 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags904 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype904_0 [] = {1119,1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes904 [] = {
g_atype904_0,
g_atype904_1,
g_atype904_2,
};

static const long offsets904 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names905[];
static const uint32 types905 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags905 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype905_0 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes905 [] = {
g_atype905_0,
g_atype905_1,
g_atype905_2,
};

static const long offsets905 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names906[];
static const uint32 types906 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags906 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype906_0 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes906 [] = {
g_atype906_0,
g_atype906_1,
g_atype906_2,
};

static const long offsets906 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names907[];
static const uint32 types907 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags907 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype907_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes907 [] = {
g_atype907_0,
g_atype907_1,
g_atype907_2,
};

static const long offsets907 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names908[];
static const uint32 types908 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags908 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype908_0 [] = {1108,1261,0xFFFF};
static const EIF_TYPE_INDEX g_atype908_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype908_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes908 [] = {
g_atype908_0,
g_atype908_1,
g_atype908_2,
};

static const long offsets908 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names909[];
static const uint32 types909 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags909 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype909_0 [] = {1108,908,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_2 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_3 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_4 [] = {908,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes909 [] = {
g_atype909_0,
g_atype909_1,
g_atype909_2,
g_atype909_3,
g_atype909_4,
g_atype909_5,
g_atype909_6,
};

static const long offsets909 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names911[];
static const uint32 types911 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags911 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype911_0 [] = {268,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_2 [] = {928,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_3 [] = {892,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_4 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_5 [] = {1255,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_6 [] = {1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_7 [] = {360,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_8 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_9 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_10 [] = {1123,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_11 [] = {1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_12 [] = {1128,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_13 [] = {1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_14 [] = {1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_15 [] = {369,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_16 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_17 [] = {370,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_18 [] = {368,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_19 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_20 [] = {1261,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_21 [] = {890,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_22 [] = {796,1057,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_23 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_24 [] = {889,908,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_25 [] = {798,1187,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_26 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_27 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_28 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_29 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes911 [] = {
g_atype911_0,
g_atype911_1,
g_atype911_2,
g_atype911_3,
g_atype911_4,
g_atype911_5,
g_atype911_6,
g_atype911_7,
g_atype911_8,
g_atype911_9,
g_atype911_10,
g_atype911_11,
g_atype911_12,
g_atype911_13,
g_atype911_14,
g_atype911_15,
g_atype911_16,
g_atype911_17,
g_atype911_18,
g_atype911_19,
g_atype911_20,
g_atype911_21,
g_atype911_22,
g_atype911_23,
g_atype911_24,
g_atype911_25,
g_atype911_26,
g_atype911_27,
g_atype911_28,
g_atype911_29,
};

static const long offsets911 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
+ @CHROFF(26,0),
+ @CHROFF(26,1),
+ @CHROFF(26,2),
+ @LNGOFF(26,3,0,0),
};

extern const char *names912[];
static const uint32 types912 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags912 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype912_0 [] = {360,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_1 [] = {29,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_2 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_3 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_4 [] = {892,1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_5 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes912 [] = {
g_atype912_0,
g_atype912_1,
g_atype912_2,
g_atype912_3,
g_atype912_4,
g_atype912_5,
};

static const long offsets912 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
};

extern const char *names913[];
static const uint32 types913 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags913 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype913_0 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_1 [] = {892,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_2 [] = {1255,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_3 [] = {1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_4 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_5 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_6 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_7 [] = {360,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_11 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes913 [] = {
g_atype913_0,
g_atype913_1,
g_atype913_2,
g_atype913_3,
g_atype913_4,
g_atype913_5,
g_atype913_6,
g_atype913_7,
g_atype913_8,
g_atype913_9,
g_atype913_10,
g_atype913_11,
};

static const long offsets913 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
};

extern const char *names914[];
static const uint32 types914 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags914 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype914_0 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_1 [] = {892,1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_2 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_3 [] = {1255,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_4 [] = {360,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_5 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_6 [] = {1123,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_7 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_8 [] = {1226,1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_9 [] = {1226,1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_11 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_12 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_13 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_14 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes914 [] = {
g_atype914_0,
g_atype914_1,
g_atype914_2,
g_atype914_3,
g_atype914_4,
g_atype914_5,
g_atype914_6,
g_atype914_7,
g_atype914_8,
g_atype914_9,
g_atype914_10,
g_atype914_11,
g_atype914_12,
g_atype914_13,
g_atype914_14,
};

static const long offsets914 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @CHROFF(10,0),
+ @CHROFF(10,1),
+ @CHROFF(10,2),
+ @CHROFF(10,3),
+ @CHROFF(10,4),
};

extern const char *names915[];
static const uint32 types915 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags915 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype915_0 [] = {62,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_2 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_3 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_4 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_5 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_6 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_7 [] = {807,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_8 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_9 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_10 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_11 [] = {807,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_12 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_13 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_14 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_15 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_16 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_17 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_18 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_19 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_20 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_21 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_22 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_23 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_24 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_25 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_26 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_27 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_28 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_29 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes915 [] = {
g_atype915_0,
g_atype915_1,
g_atype915_2,
g_atype915_3,
g_atype915_4,
g_atype915_5,
g_atype915_6,
g_atype915_7,
g_atype915_8,
g_atype915_9,
g_atype915_10,
g_atype915_11,
g_atype915_12,
g_atype915_13,
g_atype915_14,
g_atype915_15,
g_atype915_16,
g_atype915_17,
g_atype915_18,
g_atype915_19,
g_atype915_20,
g_atype915_21,
g_atype915_22,
g_atype915_23,
g_atype915_24,
g_atype915_25,
g_atype915_26,
g_atype915_27,
g_atype915_28,
g_atype915_29,
};

static const long offsets915 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @CHROFF(12,16),
+ @CHROFF(12,17),
};

extern const char *names916[];
static const uint32 types916 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags916 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype916_0 [] = {62,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_2 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_3 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_4 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_5 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_6 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_7 [] = {807,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_8 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_9 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_10 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_11 [] = {807,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_12 [] = {1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_13 [] = {1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_14 [] = {1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_15 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_16 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_17 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_18 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_19 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_20 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_21 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_22 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_23 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_24 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_25 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_26 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_27 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_28 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_29 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_30 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_31 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_32 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_33 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_34 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_35 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes916 [] = {
g_atype916_0,
g_atype916_1,
g_atype916_2,
g_atype916_3,
g_atype916_4,
g_atype916_5,
g_atype916_6,
g_atype916_7,
g_atype916_8,
g_atype916_9,
g_atype916_10,
g_atype916_11,
g_atype916_12,
g_atype916_13,
g_atype916_14,
g_atype916_15,
g_atype916_16,
g_atype916_17,
g_atype916_18,
g_atype916_19,
g_atype916_20,
g_atype916_21,
g_atype916_22,
g_atype916_23,
g_atype916_24,
g_atype916_25,
g_atype916_26,
g_atype916_27,
g_atype916_28,
g_atype916_29,
g_atype916_30,
g_atype916_31,
g_atype916_32,
g_atype916_33,
g_atype916_34,
g_atype916_35,
};

static const long offsets916 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
+ @CHROFF(18,0),
+ @CHROFF(18,1),
+ @CHROFF(18,2),
+ @CHROFF(18,3),
+ @CHROFF(18,4),
+ @CHROFF(18,5),
+ @CHROFF(18,6),
+ @CHROFF(18,7),
+ @CHROFF(18,8),
+ @CHROFF(18,9),
+ @CHROFF(18,10),
+ @CHROFF(18,11),
+ @CHROFF(18,12),
+ @CHROFF(18,13),
+ @CHROFF(18,14),
+ @CHROFF(18,15),
+ @CHROFF(18,16),
+ @CHROFF(18,17),
};

extern const char *names917[];
static const uint32 types917 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags917 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype917_0 [] = {887,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_1 [] = {804,0xFFF9,2,996,1055,804,1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes917 [] = {
g_atype917_0,
g_atype917_1,
};

static const long offsets917 [] =
{
0,
 + @REFACS(1),
};

extern const char *names919[];
static const uint32 types919 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags919 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype919_0 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype919_1 [] = {863,1071,0xFFFF};

static const EIF_TYPE_INDEX *gtypes919 [] = {
g_atype919_0,
g_atype919_1,
};

static const long offsets919 [] =
{
0,
 + @REFACS(1),
};

extern const char *names920[];
static const uint32 types920 [] =
{
SK_REF,
};

static const uint16 attr_flags920 [] =
{0,};

static const EIF_TYPE_INDEX g_atype920_0 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes920 [] = {
g_atype920_0,
};

static const long offsets920 [] =
{
0,
};

extern const char *names921[];
static const uint32 types921 [] =
{
SK_REF,
};

static const uint16 attr_flags921 [] =
{0,};

static const EIF_TYPE_INDEX g_atype921_0 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes921 [] = {
g_atype921_0,
};

static const long offsets921 [] =
{
0,
};

extern const char *names922[];
static const uint32 types922 [] =
{
SK_REF,
};

static const uint16 attr_flags922 [] =
{0,};

static const EIF_TYPE_INDEX g_atype922_0 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes922 [] = {
g_atype922_0,
};

static const long offsets922 [] =
{
0,
};

extern const char *names923[];
static const uint32 types923 [] =
{
SK_REF,
};

static const uint16 attr_flags923 [] =
{0,};

static const EIF_TYPE_INDEX g_atype923_0 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes923 [] = {
g_atype923_0,
};

static const long offsets923 [] =
{
0,
};

extern const char *names924[];
static const uint32 types924 [] =
{
SK_REF,
};

static const uint16 attr_flags924 [] =
{0,};

static const EIF_TYPE_INDEX g_atype924_0 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes924 [] = {
g_atype924_0,
};

static const long offsets924 [] =
{
0,
};

extern const char *names925[];
static const uint32 types925 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags925 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype925_0 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype925_1 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype925_2 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype925_3 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes925 [] = {
g_atype925_0,
g_atype925_1,
g_atype925_2,
g_atype925_3,
};

static const long offsets925 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names926[];
static const uint32 types926 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags926 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype926_0 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_1 [] = {892,1072,0xFFFF};

static const EIF_TYPE_INDEX *gtypes926 [] = {
g_atype926_0,
g_atype926_1,
};

static const long offsets926 [] =
{
0,
 + @REFACS(1),
};

extern const char *names927[];
static const uint32 types927 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags927 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype927_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype927_1 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype927_2 [] = {1047,0xFFFF};

static const EIF_TYPE_INDEX *gtypes927 [] = {
g_atype927_0,
g_atype927_1,
g_atype927_2,
};

static const long offsets927 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names928[];
static const uint32 types928 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags928 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype928_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype928_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype928_2 [] = {1057,0xFFFF};

static const EIF_TYPE_INDEX *gtypes928 [] = {
g_atype928_0,
g_atype928_1,
g_atype928_2,
};

static const long offsets928 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names929[];
static const uint32 types929 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags929 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype929_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype929_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype929_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype929_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype929_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes929 [] = {
g_atype929_0,
g_atype929_1,
g_atype929_2,
g_atype929_3,
g_atype929_4,
};

static const long offsets929 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names930[];
static const uint32 types930 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags930 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype930_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype930_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype930_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype930_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype930_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes930 [] = {
g_atype930_0,
g_atype930_1,
g_atype930_2,
g_atype930_3,
g_atype930_4,
};

static const long offsets930 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names931[];
static const uint32 types931 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags931 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype931_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype931_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype931_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype931_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype931_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes931 [] = {
g_atype931_0,
g_atype931_1,
g_atype931_2,
g_atype931_3,
g_atype931_4,
};

static const long offsets931 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names932[];
static const uint32 types932 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags932 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype932_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype932_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype932_2 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype932_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype932_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype932_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes932 [] = {
g_atype932_0,
g_atype932_1,
g_atype932_2,
g_atype932_3,
g_atype932_4,
g_atype932_5,
};

static const long offsets932 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names933[];
static const uint32 types933 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags933 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype933_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype933_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype933_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype933_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype933_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes933 [] = {
g_atype933_0,
g_atype933_1,
g_atype933_2,
g_atype933_3,
g_atype933_4,
};

static const long offsets933 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names934[];
static const uint32 types934 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags934 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype934_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype934_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype934_2 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype934_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype934_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype934_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes934 [] = {
g_atype934_0,
g_atype934_1,
g_atype934_2,
g_atype934_3,
g_atype934_4,
g_atype934_5,
};

static const long offsets934 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names935[];
static const uint32 types935 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags935 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype935_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype935_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype935_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype935_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype935_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes935 [] = {
g_atype935_0,
g_atype935_1,
g_atype935_2,
g_atype935_3,
g_atype935_4,
};

static const long offsets935 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names936[];
static const uint32 types936 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags936 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype936_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_2 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes936 [] = {
g_atype936_0,
g_atype936_1,
g_atype936_2,
g_atype936_3,
g_atype936_4,
g_atype936_5,
g_atype936_6,
};

static const long offsets936 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
+ @LNGOFF(3,0,0,3),
};

extern const char *names944[];
static const uint32 types944 [] =
{
SK_REF,
};

static const uint16 attr_flags944 [] =
{0,};

static const EIF_TYPE_INDEX g_atype944_0 [] = {1052,0xFFFF};

static const EIF_TYPE_INDEX *gtypes944 [] = {
g_atype944_0,
};

static const long offsets944 [] =
{
0,
};

extern const char *names965[];
static const uint32 types965 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags965 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype965_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_2 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes965 [] = {
g_atype965_0,
g_atype965_1,
g_atype965_2,
g_atype965_3,
g_atype965_4,
};

static const long offsets965 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names966[];
static const uint32 types966 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags966 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype966_0 [] = {109,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_2 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_3 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes966 [] = {
g_atype966_0,
g_atype966_1,
g_atype966_2,
g_atype966_3,
};

static const long offsets966 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
};

extern const char *names969[];
static const uint32 types969 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags969 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype969_0 [] = {979,1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_1 [] = {1053,0xFFFF};

static const EIF_TYPE_INDEX *gtypes969 [] = {
g_atype969_0,
g_atype969_1,
};

static const long offsets969 [] =
{
0,
 + @REFACS(1),
};

extern const char *names970[];
static const uint32 types970 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags970 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype970_0 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_1 [] = {1053,0xFFFF};

static const EIF_TYPE_INDEX *gtypes970 [] = {
g_atype970_0,
g_atype970_1,
};

static const long offsets970 [] =
{
0,
 + @REFACS(1),
};

extern const char *names971[];
static const uint32 types971 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags971 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype971_0 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_1 [] = {979,1053,0xFFFF};

static const EIF_TYPE_INDEX *gtypes971 [] = {
g_atype971_0,
g_atype971_1,
};

static const long offsets971 [] =
{
0,
 + @REFACS(1),
};

extern const char *names972[];
static const uint32 types972 [] =
{
SK_REF,
};

static const uint16 attr_flags972 [] =
{0,};

static const EIF_TYPE_INDEX g_atype972_0 [] = {1053,0xFFFF};

static const EIF_TYPE_INDEX *gtypes972 [] = {
g_atype972_0,
};

static const long offsets972 [] =
{
0,
};

extern const char *names973[];
static const uint32 types973 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags973 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype973_0 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_1 [] = {973,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_2 [] = {979,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_3 [] = {979,975,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_4 [] = {979,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_5 [] = {979,970,0xFFFF};

static const EIF_TYPE_INDEX *gtypes973 [] = {
g_atype973_0,
g_atype973_1,
g_atype973_2,
g_atype973_3,
g_atype973_4,
g_atype973_5,
};

static const long offsets973 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names974[];
static const uint32 types974 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags974 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype974_0 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_1 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_2 [] = {1053,0xFFFF};

static const EIF_TYPE_INDEX *gtypes974 [] = {
g_atype974_0,
g_atype974_1,
g_atype974_2,
};

static const long offsets974 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names975[];
static const uint32 types975 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags975 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype975_0 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes975 [] = {
g_atype975_0,
g_atype975_1,
};

static const long offsets975 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names976[];
static const uint32 types976 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags976 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype976_0 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_1 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_2 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_3 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_5 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes976 [] = {
g_atype976_0,
g_atype976_1,
g_atype976_2,
g_atype976_3,
g_atype976_4,
g_atype976_5,
};

static const long offsets976 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
};

extern const char *names977[];
static const uint32 types977 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags977 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype977_0 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_1 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_2 [] = {979,1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_3 [] = {979,1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_4 [] = {979,969,0xFFFF};

static const EIF_TYPE_INDEX *gtypes977 [] = {
g_atype977_0,
g_atype977_1,
g_atype977_2,
g_atype977_3,
g_atype977_4,
};

static const long offsets977 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names978[];
static const uint32 types978 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags978 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype978_0 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_1 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_2 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_3 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_4 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_5 [] = {1053,0xFFFF};

static const EIF_TYPE_INDEX *gtypes978 [] = {
g_atype978_0,
g_atype978_1,
g_atype978_2,
g_atype978_3,
g_atype978_4,
g_atype978_5,
};

static const long offsets978 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names979[];
static const uint32 types979 [] =
{
SK_REF,
};

static const uint16 attr_flags979 [] =
{0,};

static const EIF_TYPE_INDEX g_atype979_0 [] = {1053,0xFFFF};

static const EIF_TYPE_INDEX *gtypes979 [] = {
g_atype979_0,
};

static const long offsets979 [] =
{
0,
};

extern const char *names980[];
static const uint32 types980 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags980 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype980_0 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype980_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype980_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes980 [] = {
g_atype980_0,
g_atype980_1,
g_atype980_2,
};

static const long offsets980 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names981[];
static const uint32 types981 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags981 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype981_0 [] = {979,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype981_1 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype981_2 [] = {979,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype981_3 [] = {979,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype981_4 [] = {979,981,0xFFFF};
static const EIF_TYPE_INDEX g_atype981_5 [] = {979,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype981_6 [] = {979,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype981_7 [] = {979,976,0xFFFF};

static const EIF_TYPE_INDEX *gtypes981 [] = {
g_atype981_0,
g_atype981_1,
g_atype981_2,
g_atype981_3,
g_atype981_4,
g_atype981_5,
g_atype981_6,
g_atype981_7,
};

static const long offsets981 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
};

extern const char *names982[];
static const uint32 types982 [] =
{
SK_REF,
};

static const uint16 attr_flags982 [] =
{0,};

static const EIF_TYPE_INDEX g_atype982_0 [] = {1053,0xFFFF};

static const EIF_TYPE_INDEX *gtypes982 [] = {
g_atype982_0,
};

static const long offsets982 [] =
{
0,
};

extern const char *names983[];
static const uint32 types983 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags983 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype983_0 [] = {1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype983_1 [] = {979,969,0xFFFF};

static const EIF_TYPE_INDEX *gtypes983 [] = {
g_atype983_0,
g_atype983_1,
};

static const long offsets983 [] =
{
0,
 + @REFACS(1),
};

extern const char *names984[];
static const uint32 types984 [] =
{
SK_REF,
};

static const uint16 attr_flags984 [] =
{0,};

static const EIF_TYPE_INDEX g_atype984_0 [] = {1053,0xFFFF};

static const EIF_TYPE_INDEX *gtypes984 [] = {
g_atype984_0,
};

static const long offsets984 [] =
{
0,
};

extern const char *names985[];
static const uint32 types985 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags985 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype985_0 [] = {987,0xFFFF};
static const EIF_TYPE_INDEX g_atype985_1 [] = {974,0xFFFF};

static const EIF_TYPE_INDEX *gtypes985 [] = {
g_atype985_0,
g_atype985_1,
};

static const long offsets985 [] =
{
0,
 + @REFACS(1),
};

extern const char *names986[];
static const uint32 types986 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags986 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype986_0 [] = {987,0xFFFF};
static const EIF_TYPE_INDEX g_atype986_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype986_2 [] = {979,969,0xFFFF};

static const EIF_TYPE_INDEX *gtypes986 [] = {
g_atype986_0,
g_atype986_1,
g_atype986_2,
};

static const long offsets986 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names987[];
static const uint32 types987 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags987 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype987_0 [] = {987,0xFFFF};
static const EIF_TYPE_INDEX g_atype987_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype987_2 [] = {979,1053,0xFFFF};

static const EIF_TYPE_INDEX *gtypes987 [] = {
g_atype987_0,
g_atype987_1,
g_atype987_2,
};

static const long offsets987 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names993[];
static const uint32 types993 [] =
{
SK_INT32,
};

static const uint16 attr_flags993 [] =
{0,};

static const EIF_TYPE_INDEX g_atype993_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes993 [] = {
g_atype993_0,
};

static const long offsets993 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names994[];
static const uint32 types994 [] =
{
SK_BOOL,
};

static const uint16 attr_flags994 [] =
{0,};

static const EIF_TYPE_INDEX g_atype994_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes994 [] = {
g_atype994_0,
};

static const long offsets994 [] =
{
+ @CHROFF(0,0),
};

extern const char *names996[];
static const uint32 types996 [] =
{
SK_INT32,
};

static const uint16 attr_flags996 [] =
{0,};

static const EIF_TYPE_INDEX g_atype996_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes996 [] = {
g_atype996_0,
};

static const long offsets996 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names998[];
static const uint32 types998 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
};

static const uint16 attr_flags998 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype998_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_1 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_2 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_7 [] = {1001,0xFFFF};

static const EIF_TYPE_INDEX *gtypes998 [] = {
g_atype998_0,
g_atype998_1,
g_atype998_2,
g_atype998_3,
g_atype998_4,
g_atype998_5,
g_atype998_6,
g_atype998_7,
};

static const long offsets998 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @LNGOFF(3,4,0,0),
};

extern const char *names999[];
static const uint32 types999 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
};

static const uint16 attr_flags999 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype999_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_1 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_2 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_3 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_4 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype999_10 [] = {1001,0xFFFF};

static const EIF_TYPE_INDEX *gtypes999 [] = {
g_atype999_0,
g_atype999_1,
g_atype999_2,
g_atype999_3,
g_atype999_4,
g_atype999_5,
g_atype999_6,
g_atype999_7,
g_atype999_8,
g_atype999_9,
g_atype999_10,
};

static const long offsets999 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
};

extern const char *names1000[];
static const uint32 types1000 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags1000 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1000_0 [] = {1001,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1000 [] = {
g_atype1000_0,
};

static const long offsets1000 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1001[];
static const uint32 types1001 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags1001 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1001_0 [] = {1001,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1001 [] = {
g_atype1001_0,
};

static const long offsets1001 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1002[];
static const uint32 types1002 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags1002 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1002_0 [] = {1001,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1002 [] = {
g_atype1002_0,
};

static const long offsets1002 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1003[];
static const uint32 types1003 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags1003 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1003_0 [] = {1004,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1003 [] = {
g_atype1003_0,
};

static const long offsets1003 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1004[];
static const uint32 types1004 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags1004 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1004_0 [] = {1004,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1004 [] = {
g_atype1004_0,
};

static const long offsets1004 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1005[];
static const uint32 types1005 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags1005 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1005_0 [] = {1004,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1005 [] = {
g_atype1005_0,
};

static const long offsets1005 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1006[];
static const uint32 types1006 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1006 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1006_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1006 [] = {
g_atype1006_0,
};

static const long offsets1006 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1007[];
static const uint32 types1007 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1007 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1007_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1007 [] = {
g_atype1007_0,
};

static const long offsets1007 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1008[];
static const uint32 types1008 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1008 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1008_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1008 [] = {
g_atype1008_0,
};

static const long offsets1008 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1009[];
static const uint32 types1009 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1009 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1009_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1009 [] = {
g_atype1009_0,
};

static const long offsets1009 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1010[];
static const uint32 types1010 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1010 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1010_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1010 [] = {
g_atype1010_0,
};

static const long offsets1010 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1011[];
static const uint32 types1011 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1011 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1011_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1011 [] = {
g_atype1011_0,
};

static const long offsets1011 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1012[];
static const uint32 types1012 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1012 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1012_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1012 [] = {
g_atype1012_0,
};

static const long offsets1012 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1013[];
static const uint32 types1013 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1013 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1013_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1013 [] = {
g_atype1013_0,
};

static const long offsets1013 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1014[];
static const uint32 types1014 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1014 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1014_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1014 [] = {
g_atype1014_0,
};

static const long offsets1014 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1015[];
static const uint32 types1015 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1015 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1015_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1015 [] = {
g_atype1015_0,
};

static const long offsets1015 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1016[];
static const uint32 types1016 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1016 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1016_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1016 [] = {
g_atype1016_0,
};

static const long offsets1016 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1017[];
static const uint32 types1017 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1017 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1017_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1017 [] = {
g_atype1017_0,
};

static const long offsets1017 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1018[];
static const uint32 types1018 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1018 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1018_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1018 [] = {
g_atype1018_0,
};

static const long offsets1018 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1019[];
static const uint32 types1019 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1019 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1019_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1019 [] = {
g_atype1019_0,
};

static const long offsets1019 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1020[];
static const uint32 types1020 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1020 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1020_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1020 [] = {
g_atype1020_0,
};

static const long offsets1020 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1021[];
static const uint32 types1021 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1021 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1021_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1021 [] = {
g_atype1021_0,
};

static const long offsets1021 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1022[];
static const uint32 types1022 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1022 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1022_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1022 [] = {
g_atype1022_0,
};

static const long offsets1022 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1023[];
static const uint32 types1023 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1023 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1023_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1023 [] = {
g_atype1023_0,
};

static const long offsets1023 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1024[];
static const uint32 types1024 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1024 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1024_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1024 [] = {
g_atype1024_0,
};

static const long offsets1024 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1025[];
static const uint32 types1025 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1025 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1025_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1025 [] = {
g_atype1025_0,
};

static const long offsets1025 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1026[];
static const uint32 types1026 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1026 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1026_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1026 [] = {
g_atype1026_0,
};

static const long offsets1026 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1027[];
static const uint32 types1027 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1027 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1027_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1027 [] = {
g_atype1027_0,
};

static const long offsets1027 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1028[];
static const uint32 types1028 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1028 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1028_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1028 [] = {
g_atype1028_0,
};

static const long offsets1028 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1029[];
static const uint32 types1029 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1029 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1029_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1029 [] = {
g_atype1029_0,
};

static const long offsets1029 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1030[];
static const uint32 types1030 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1030 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1030_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1030 [] = {
g_atype1030_0,
};

static const long offsets1030 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1031[];
static const uint32 types1031 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1031 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1031_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1031 [] = {
g_atype1031_0,
};

static const long offsets1031 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1032[];
static const uint32 types1032 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1032 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1032_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1032 [] = {
g_atype1032_0,
};

static const long offsets1032 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1033[];
static const uint32 types1033 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1033 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1033_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1033 [] = {
g_atype1033_0,
};

static const long offsets1033 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1034[];
static const uint32 types1034 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1034 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1034_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1034 [] = {
g_atype1034_0,
};

static const long offsets1034 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1035[];
static const uint32 types1035 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1035 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1035_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1035 [] = {
g_atype1035_0,
};

static const long offsets1035 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1036[];
static const uint32 types1036 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1036 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1036_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1036 [] = {
g_atype1036_0,
};

static const long offsets1036 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1037[];
static const uint32 types1037 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1037 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1037_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1037 [] = {
g_atype1037_0,
};

static const long offsets1037 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1038[];
static const uint32 types1038 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1038 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1038_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1038 [] = {
g_atype1038_0,
};

static const long offsets1038 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1039[];
static const uint32 types1039 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1039 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1039_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1039 [] = {
g_atype1039_0,
};

static const long offsets1039 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1040[];
static const uint32 types1040 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1040 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1040_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1040 [] = {
g_atype1040_0,
};

static const long offsets1040 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1041[];
static const uint32 types1041 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1041 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1041_0 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1041 [] = {
g_atype1041_0,
};

static const long offsets1041 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1042[];
static const uint32 types1042 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1042 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1042_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_1 [] = {0xFFF9,0,996,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_2 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_3 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_9 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_10 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_11 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1042 [] = {
g_atype1042_0,
g_atype1042_1,
g_atype1042_2,
g_atype1042_3,
g_atype1042_4,
g_atype1042_5,
g_atype1042_6,
g_atype1042_7,
g_atype1042_8,
g_atype1042_9,
g_atype1042_10,
g_atype1042_11,
};

static const long offsets1042 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names1043[];
static const uint32 types1043 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1043 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1043_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_1 [] = {0xFFF9,0,996,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_2 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_3 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_9 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_10 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_11 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1043 [] = {
g_atype1043_0,
g_atype1043_1,
g_atype1043_2,
g_atype1043_3,
g_atype1043_4,
g_atype1043_5,
g_atype1043_6,
g_atype1043_7,
g_atype1043_8,
g_atype1043_9,
g_atype1043_10,
g_atype1043_11,
};

static const long offsets1043 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names1044[];
static const uint32 types1044 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1044 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1044_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_1 [] = {0xFFF9,0,996,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_2 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_3 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_4 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_10 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_11 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_12 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1044 [] = {
g_atype1044_0,
g_atype1044_1,
g_atype1044_2,
g_atype1044_3,
g_atype1044_4,
g_atype1044_5,
g_atype1044_6,
g_atype1044_7,
g_atype1044_8,
g_atype1044_9,
g_atype1044_10,
g_atype1044_11,
g_atype1044_12,
};

static const long offsets1044 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @PTROFF(5,2,0,3,0,0),
+ @PTROFF(5,2,0,3,0,1),
+ @PTROFF(5,2,0,3,0,2),
};

extern const char *names1045[];
static const uint32 types1045 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1045 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1045_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_1 [] = {0xFFF9,0,996,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_2 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_3 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_10 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_11 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_12 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1045 [] = {
g_atype1045_0,
g_atype1045_1,
g_atype1045_2,
g_atype1045_3,
g_atype1045_4,
g_atype1045_5,
g_atype1045_6,
g_atype1045_7,
g_atype1045_8,
g_atype1045_9,
g_atype1045_10,
g_atype1045_11,
g_atype1045_12,
};

static const long offsets1045 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names1046[];
static const uint32 types1046 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1046 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1046_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_1 [] = {0xFFF9,0,996,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_2 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_3 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_10 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_11 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_12 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1046 [] = {
g_atype1046_0,
g_atype1046_1,
g_atype1046_2,
g_atype1046_3,
g_atype1046_4,
g_atype1046_5,
g_atype1046_6,
g_atype1046_7,
g_atype1046_8,
g_atype1046_9,
g_atype1046_10,
g_atype1046_11,
g_atype1046_12,
};

static const long offsets1046 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @LNGOFF(4,2,0,3),
+ @PTROFF(4,2,0,4,0,0),
+ @PTROFF(4,2,0,4,0,1),
+ @PTROFF(4,2,0,4,0,2),
};

extern const char *names1047[];
static const uint32 types1047 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1047 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1047_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_1 [] = {0xFFF9,0,996,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_2 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_3 [] = {823,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_10 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_11 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_12 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1047 [] = {
g_atype1047_0,
g_atype1047_1,
g_atype1047_2,
g_atype1047_3,
g_atype1047_4,
g_atype1047_5,
g_atype1047_6,
g_atype1047_7,
g_atype1047_8,
g_atype1047_9,
g_atype1047_10,
g_atype1047_11,
g_atype1047_12,
};

static const long offsets1047 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names1048[];
static const uint32 types1048 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1048 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1048_0 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1048 [] = {
g_atype1048_0,
g_atype1048_1,
};

static const long offsets1048 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names1049[];
static const uint32 types1049 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1049 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1049_0 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1049_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1049 [] = {
g_atype1049_0,
g_atype1049_1,
};

static const long offsets1049 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names1050[];
static const uint32 types1050 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1050 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1050_0 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1050_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1050 [] = {
g_atype1050_0,
g_atype1050_1,
};

static const long offsets1050 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names1051[];
static const uint32 types1051 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1051 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1051_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1051 [] = {
g_atype1051_0,
g_atype1051_1,
g_atype1051_2,
g_atype1051_3,
};

static const long offsets1051 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1052[];
static const uint32 types1052 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1052 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1052_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1052 [] = {
g_atype1052_0,
g_atype1052_1,
g_atype1052_2,
g_atype1052_3,
g_atype1052_4,
};

static const long offsets1052 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names1053[];
static const uint32 types1053 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1053 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1053_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1053 [] = {
g_atype1053_0,
g_atype1053_1,
g_atype1053_2,
g_atype1053_3,
g_atype1053_4,
};

static const long offsets1053 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names1054[];
static const uint32 types1054 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1054 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1054_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1054 [] = {
g_atype1054_0,
g_atype1054_1,
g_atype1054_2,
g_atype1054_3,
g_atype1054_4,
g_atype1054_5,
};

static const long offsets1054 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @LNGOFF(1,2,0,0),
+ @LNGOFF(1,2,0,1),
+ @LNGOFF(1,2,0,2),
};

extern const char *names1055[];
static const uint32 types1055 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1055 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1055_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1055 [] = {
g_atype1055_0,
g_atype1055_1,
g_atype1055_2,
g_atype1055_3,
g_atype1055_4,
};

static const long offsets1055 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names1056[];
static const uint32 types1056 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1056 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1056_0 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1056 [] = {
g_atype1056_0,
g_atype1056_1,
g_atype1056_2,
g_atype1056_3,
};

static const long offsets1056 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1057[];
static const uint32 types1057 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1057 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1057_0 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1057 [] = {
g_atype1057_0,
g_atype1057_1,
g_atype1057_2,
g_atype1057_3,
g_atype1057_4,
};

static const long offsets1057 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names1058[];
static const uint32 types1058 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1058 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1058_0 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1058 [] = {
g_atype1058_0,
g_atype1058_1,
g_atype1058_2,
g_atype1058_3,
g_atype1058_4,
};

static const long offsets1058 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names1060[];
static const uint32 types1060 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1060 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1060_0 [] = {1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_8 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1060 [] = {
g_atype1060_0,
g_atype1060_1,
g_atype1060_2,
g_atype1060_3,
g_atype1060_4,
g_atype1060_5,
g_atype1060_6,
g_atype1060_7,
g_atype1060_8,
};

static const long offsets1060 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
+ @LNGOFF(2,2,0,3),
+ @LNGOFF(2,2,0,4),
};

extern const char *names1061[];
static const uint32 types1061 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1061 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1061_0 [] = {892,1061,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_1 [] = {1298,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_2 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_3 [] = {1298,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1061 [] = {
g_atype1061_0,
g_atype1061_1,
g_atype1061_2,
g_atype1061_3,
};

static const long offsets1061 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1062[];
static const uint32 types1062 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
};

static const uint16 attr_flags1062 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1062_0 [] = {550,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_1 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_2 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_3 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_4 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_5 [] = {892,1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_6 [] = {892,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_7 [] = {1298,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_8 [] = {1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_9 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_10 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_11 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1062 [] = {
g_atype1062_0,
g_atype1062_1,
g_atype1062_2,
g_atype1062_3,
g_atype1062_4,
g_atype1062_5,
g_atype1062_6,
g_atype1062_7,
g_atype1062_8,
g_atype1062_9,
g_atype1062_10,
g_atype1062_11,
};

static const long offsets1062 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
};

extern const char *names1063[];
static const uint32 types1063 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1063 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1063_0 [] = {892,1061,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_1 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_2 [] = {1298,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1063 [] = {
g_atype1063_0,
g_atype1063_1,
g_atype1063_2,
};

static const long offsets1063 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1064[];
static const uint32 types1064 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1064 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1064_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_1 [] = {771,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_2 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_3 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_12 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1064 [] = {
g_atype1064_0,
g_atype1064_1,
g_atype1064_2,
g_atype1064_3,
g_atype1064_4,
g_atype1064_5,
g_atype1064_6,
g_atype1064_7,
g_atype1064_8,
g_atype1064_9,
g_atype1064_10,
g_atype1064_11,
g_atype1064_12,
};

static const long offsets1064 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @LNGOFF(3,3,0,0),
+ @LNGOFF(3,3,0,1),
+ @LNGOFF(3,3,0,2),
+ @LNGOFF(3,3,0,3),
+ @LNGOFF(3,3,0,4),
+ @LNGOFF(3,3,0,5),
+ @LNGOFF(3,3,0,6),
};

extern const char *names1065[];
static const uint32 types1065 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1065 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1065_0 [] = {1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_2 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_7 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1065 [] = {
g_atype1065_0,
g_atype1065_1,
g_atype1065_2,
g_atype1065_3,
g_atype1065_4,
g_atype1065_5,
g_atype1065_6,
g_atype1065_7,
};

static const long offsets1065 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
+ @LNGOFF(2,2,0,3),
};

extern const char *names1066[];
static const uint32 types1066 [] =
{
SK_REF,
SK_BOOL,
SK_UINT8,
SK_UINT8,
};

static const uint16 attr_flags1066 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1066_0 [] = {822,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_2 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_3 [] = {1205,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1066 [] = {
g_atype1066_0,
g_atype1066_1,
g_atype1066_2,
g_atype1066_3,
};

static const long offsets1066 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
};

extern const char *names1067[];
static const uint32 types1067 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1067 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1067_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1067 [] = {
g_atype1067_0,
g_atype1067_1,
g_atype1067_2,
g_atype1067_3,
};

static const long offsets1067 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1068[];
static const uint32 types1068 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1068 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1068_0 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_2 [] = {0xFFF9,2,996,1055,804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_3 [] = {1121,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_4 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_5 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_6 [] = {1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_7 [] = {892,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_8 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_9 [] = {360,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_10 [] = {1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_11 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_12 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_13 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_14 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_15 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_16 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_17 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_18 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1068 [] = {
g_atype1068_0,
g_atype1068_1,
g_atype1068_2,
g_atype1068_3,
g_atype1068_4,
g_atype1068_5,
g_atype1068_6,
g_atype1068_7,
g_atype1068_8,
g_atype1068_9,
g_atype1068_10,
g_atype1068_11,
g_atype1068_12,
g_atype1068_13,
g_atype1068_14,
g_atype1068_15,
g_atype1068_16,
g_atype1068_17,
g_atype1068_18,
};

static const long offsets1068 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @CHROFF(11,1),
+ @CHROFF(11,2),
+ @CHROFF(11,3),
+ @CHROFF(11,4),
+ @CHROFF(11,5),
+ @LNGOFF(11,6,0,0),
+ @LNGOFF(11,6,0,1),
};

extern const char *names1069[];
static const uint32 types1069 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1069 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1069_0 [] = {1282,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_2 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_3 [] = {1068,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_4 [] = {894,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_5 [] = {892,1068,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_6 [] = {892,1130,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_7 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_11 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_14 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1069 [] = {
g_atype1069_0,
g_atype1069_1,
g_atype1069_2,
g_atype1069_3,
g_atype1069_4,
g_atype1069_5,
g_atype1069_6,
g_atype1069_7,
g_atype1069_8,
g_atype1069_9,
g_atype1069_10,
g_atype1069_11,
g_atype1069_12,
g_atype1069_13,
g_atype1069_14,
};

static const long offsets1069 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @LNGOFF(8,4,0,0),
+ @LNGOFF(8,4,0,1),
+ @LNGOFF(8,4,0,2),
};

extern const char *names1070[];
static const uint32 types1070 [] =
{
SK_REF,
SK_UINT8,
};

static const uint16 attr_flags1070 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1070_0 [] = {1065,0xFFFF};
static const EIF_TYPE_INDEX g_atype1070_1 [] = {1205,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1070 [] = {
g_atype1070_0,
g_atype1070_1,
};

static const long offsets1070 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names1071[];
static const uint32 types1071 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_UINT64,
};

static const uint16 attr_flags1071 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1071_0 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1071_1 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1071_2 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1071_3 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1071_4 [] = {1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1071 [] = {
g_atype1071_0,
g_atype1071_1,
g_atype1071_2,
g_atype1071_3,
g_atype1071_4,
};

static const long offsets1071 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @I64OFF(0,0,3,1,0,0,0),
};

extern const char *names1072[];
static const uint32 types1072 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1072 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1072_0 [] = {908,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_1 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_2 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_3 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_4 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_5 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_6 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_7 [] = {228,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_8 [] = {1255,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_9 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_10 [] = {61,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_11 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_12 [] = {1129,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_13 [] = {804,1128,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_14 [] = {804,1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_15 [] = {804,1123,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_16 [] = {804,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_17 [] = {892,369,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_18 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_19 [] = {892,377,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_20 [] = {892,376,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_21 [] = {892,375,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_22 [] = {892,374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_23 [] = {892,373,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_24 [] = {892,372,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_25 [] = {892,371,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_26 [] = {892,368,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_27 [] = {892,368,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_28 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_29 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1072 [] = {
g_atype1072_0,
g_atype1072_1,
g_atype1072_2,
g_atype1072_3,
g_atype1072_4,
g_atype1072_5,
g_atype1072_6,
g_atype1072_7,
g_atype1072_8,
g_atype1072_9,
g_atype1072_10,
g_atype1072_11,
g_atype1072_12,
g_atype1072_13,
g_atype1072_14,
g_atype1072_15,
g_atype1072_16,
g_atype1072_17,
g_atype1072_18,
g_atype1072_19,
g_atype1072_20,
g_atype1072_21,
g_atype1072_22,
g_atype1072_23,
g_atype1072_24,
g_atype1072_25,
g_atype1072_26,
g_atype1072_27,
g_atype1072_28,
g_atype1072_29,
};

static const long offsets1072 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
+ @CHROFF(29,0),
};

extern const char *names1073[];
static const uint32 types1073 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1073 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1073_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_1 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1073 [] = {
g_atype1073_0,
g_atype1073_1,
g_atype1073_2,
};

static const long offsets1073 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names1074[];
static const uint32 types1074 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1074 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1074_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1074 [] = {
g_atype1074_0,
g_atype1074_1,
};

static const long offsets1074 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1075[];
static const uint32 types1075 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1075 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1075_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1075 [] = {
g_atype1075_0,
g_atype1075_1,
};

static const long offsets1075 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1076[];
static const uint32 types1076 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1076 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1076_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1076 [] = {
g_atype1076_0,
g_atype1076_1,
};

static const long offsets1076 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1077[];
static const uint32 types1077 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1077 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1077_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1077 [] = {
g_atype1077_0,
g_atype1077_1,
};

static const long offsets1077 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1078[];
static const uint32 types1078 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1078 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1078_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1078 [] = {
g_atype1078_0,
g_atype1078_1,
};

static const long offsets1078 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1079[];
static const uint32 types1079 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1079 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1079_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1079 [] = {
g_atype1079_0,
g_atype1079_1,
};

static const long offsets1079 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1080[];
static const uint32 types1080 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1080 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1080_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1080 [] = {
g_atype1080_0,
g_atype1080_1,
};

static const long offsets1080 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1081[];
static const uint32 types1081 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1081 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1081_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1081 [] = {
g_atype1081_0,
g_atype1081_1,
};

static const long offsets1081 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1082[];
static const uint32 types1082 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1082 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1082_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1082 [] = {
g_atype1082_0,
g_atype1082_1,
};

static const long offsets1082 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1083[];
static const uint32 types1083 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1083 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1083_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1083 [] = {
g_atype1083_0,
g_atype1083_1,
};

static const long offsets1083 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1084[];
static const uint32 types1084 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1084 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1084_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1084 [] = {
g_atype1084_0,
g_atype1084_1,
};

static const long offsets1084 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1085[];
static const uint32 types1085 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1085 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1085_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1085 [] = {
g_atype1085_0,
g_atype1085_1,
};

static const long offsets1085 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1086[];
static const uint32 types1086 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1086 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1086_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1086 [] = {
g_atype1086_0,
g_atype1086_1,
};

static const long offsets1086 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1087[];
static const uint32 types1087 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1087 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1087_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1087 [] = {
g_atype1087_0,
g_atype1087_1,
};

static const long offsets1087 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1088[];
static const uint32 types1088 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1088 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1088_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1088 [] = {
g_atype1088_0,
g_atype1088_1,
};

static const long offsets1088 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1089[];
static const uint32 types1089 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1089 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1089_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1089 [] = {
g_atype1089_0,
g_atype1089_1,
};

static const long offsets1089 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1090[];
static const uint32 types1090 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1090 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1090_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1090 [] = {
g_atype1090_0,
g_atype1090_1,
};

static const long offsets1090 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1091[];
static const uint32 types1091 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1091 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1091_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1091 [] = {
g_atype1091_0,
g_atype1091_1,
};

static const long offsets1091 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1092[];
static const uint32 types1092 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1092 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1092_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1092 [] = {
g_atype1092_0,
g_atype1092_1,
};

static const long offsets1092 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1093[];
static const uint32 types1093 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1093 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1093_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1093 [] = {
g_atype1093_0,
g_atype1093_1,
};

static const long offsets1093 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1094[];
static const uint32 types1094 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1094 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1094_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1094 [] = {
g_atype1094_0,
g_atype1094_1,
};

static const long offsets1094 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1095[];
static const uint32 types1095 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1095 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1095_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1095 [] = {
g_atype1095_0,
g_atype1095_1,
};

static const long offsets1095 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1096[];
static const uint32 types1096 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1096 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1096_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1096 [] = {
g_atype1096_0,
g_atype1096_1,
};

static const long offsets1096 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1097[];
static const uint32 types1097 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1097 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1097_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1097 [] = {
g_atype1097_0,
g_atype1097_1,
};

static const long offsets1097 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1098[];
static const uint32 types1098 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1098 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1098_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1098 [] = {
g_atype1098_0,
g_atype1098_1,
};

static const long offsets1098 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1099[];
static const uint32 types1099 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1099 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1099_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1099 [] = {
g_atype1099_0,
g_atype1099_1,
};

static const long offsets1099 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1100[];
static const uint32 types1100 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1100 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1100_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1100 [] = {
g_atype1100_0,
g_atype1100_1,
};

static const long offsets1100 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1101[];
static const uint32 types1101 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1101 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1101_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1101 [] = {
g_atype1101_0,
g_atype1101_1,
};

static const long offsets1101 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1102[];
static const uint32 types1102 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1102 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1102_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1102 [] = {
g_atype1102_0,
g_atype1102_1,
};

static const long offsets1102 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1103[];
static const uint32 types1103 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1103 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1103_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1103 [] = {
g_atype1103_0,
g_atype1103_1,
};

static const long offsets1103 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1104[];
static const uint32 types1104 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1104 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1104_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1104 [] = {
g_atype1104_0,
g_atype1104_1,
};

static const long offsets1104 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1105[];
static const uint32 types1105 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1105 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1105_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1105 [] = {
g_atype1105_0,
g_atype1105_1,
};

static const long offsets1105 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1106[];
static const uint32 types1106 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1106 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1106_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1106 [] = {
g_atype1106_0,
g_atype1106_1,
};

static const long offsets1106 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1107[];
static const uint32 types1107 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1107 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1107_0 [] = {1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_1 [] = {1051,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1107 [] = {
g_atype1107_0,
g_atype1107_1,
};

static const long offsets1107 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1121[];
static const uint32 types1121 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1121 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1121_0 [] = {908,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_1 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_2 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_3 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_4 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_5 [] = {1277,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_6 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_7 [] = {892,1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_8 [] = {804,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_9 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_10 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_11 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_12 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_13 [] = {795,1067,1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_14 [] = {795,1047,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_15 [] = {1226,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_16 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_17 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_18 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_19 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1121 [] = {
g_atype1121_0,
g_atype1121_1,
g_atype1121_2,
g_atype1121_3,
g_atype1121_4,
g_atype1121_5,
g_atype1121_6,
g_atype1121_7,
g_atype1121_8,
g_atype1121_9,
g_atype1121_10,
g_atype1121_11,
g_atype1121_12,
g_atype1121_13,
g_atype1121_14,
g_atype1121_15,
g_atype1121_16,
g_atype1121_17,
g_atype1121_18,
g_atype1121_19,
};

static const long offsets1121 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @LNGOFF(16,3,0,0),
};

extern const char *names1122[];
static const uint32 types1122 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1122 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1122_0 [] = {908,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_1 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_2 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_3 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_4 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_5 [] = {1277,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_6 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_7 [] = {892,1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_8 [] = {804,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_9 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_10 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_11 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_12 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_13 [] = {795,1067,1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_14 [] = {795,1047,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_15 [] = {1226,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_16 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_17 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_18 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_19 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1122 [] = {
g_atype1122_0,
g_atype1122_1,
g_atype1122_2,
g_atype1122_3,
g_atype1122_4,
g_atype1122_5,
g_atype1122_6,
g_atype1122_7,
g_atype1122_8,
g_atype1122_9,
g_atype1122_10,
g_atype1122_11,
g_atype1122_12,
g_atype1122_13,
g_atype1122_14,
g_atype1122_15,
g_atype1122_16,
g_atype1122_17,
g_atype1122_18,
g_atype1122_19,
};

static const long offsets1122 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @LNGOFF(16,3,0,0),
};

extern const char *names1123[];
static const uint32 types1123 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1123 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1123_0 [] = {908,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_1 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_2 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_3 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_4 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_5 [] = {1277,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_6 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_7 [] = {892,1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_8 [] = {804,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_9 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_10 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_11 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_12 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_13 [] = {795,1067,1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_14 [] = {795,1047,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_15 [] = {1226,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_16 [] = {892,1127,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_17 [] = {796,1122,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_18 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_19 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_20 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_21 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1123 [] = {
g_atype1123_0,
g_atype1123_1,
g_atype1123_2,
g_atype1123_3,
g_atype1123_4,
g_atype1123_5,
g_atype1123_6,
g_atype1123_7,
g_atype1123_8,
g_atype1123_9,
g_atype1123_10,
g_atype1123_11,
g_atype1123_12,
g_atype1123_13,
g_atype1123_14,
g_atype1123_15,
g_atype1123_16,
g_atype1123_17,
g_atype1123_18,
g_atype1123_19,
g_atype1123_20,
g_atype1123_21,
};

static const long offsets1123 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
+ @CHROFF(18,0),
+ @CHROFF(18,1),
+ @CHROFF(18,2),
+ @LNGOFF(18,3,0,0),
};

extern const char *names1124[];
static const uint32 types1124 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1124 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1124_0 [] = {908,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_1 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_2 [] = {887,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_3 [] = {804,0xFFF9,2,996,1055,804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_4 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_5 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_6 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_7 [] = {1279,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_8 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_9 [] = {892,1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_10 [] = {804,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_11 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_12 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_13 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_14 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_15 [] = {795,1067,1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_16 [] = {795,1047,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_17 [] = {1226,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_18 [] = {1123,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_19 [] = {892,1123,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_20 [] = {1226,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_21 [] = {892,0xFFF5,1,1120,7406,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_22 [] = {892,369,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_23 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_24 [] = {804,891,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_25 [] = {795,891,1047,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_26 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_27 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_28 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_29 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_30 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_31 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_32 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1124 [] = {
g_atype1124_0,
g_atype1124_1,
g_atype1124_2,
g_atype1124_3,
g_atype1124_4,
g_atype1124_5,
g_atype1124_6,
g_atype1124_7,
g_atype1124_8,
g_atype1124_9,
g_atype1124_10,
g_atype1124_11,
g_atype1124_12,
g_atype1124_13,
g_atype1124_14,
g_atype1124_15,
g_atype1124_16,
g_atype1124_17,
g_atype1124_18,
g_atype1124_19,
g_atype1124_20,
g_atype1124_21,
g_atype1124_22,
g_atype1124_23,
g_atype1124_24,
g_atype1124_25,
g_atype1124_26,
g_atype1124_27,
g_atype1124_28,
g_atype1124_29,
g_atype1124_30,
g_atype1124_31,
g_atype1124_32,
};

static const long offsets1124 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
+ @CHROFF(27,0),
+ @CHROFF(27,1),
+ @CHROFF(27,2),
+ @CHROFF(27,3),
+ @CHROFF(27,4),
+ @LNGOFF(27,5,0,0),
};

extern const char *names1125[];
static const uint32 types1125 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1125 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1125_0 [] = {908,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_1 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_2 [] = {887,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_3 [] = {804,0xFFF9,2,996,1055,804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_4 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_5 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_6 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_7 [] = {1279,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_8 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_9 [] = {892,1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_10 [] = {804,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_11 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_12 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_13 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_14 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_15 [] = {795,1067,1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_16 [] = {795,1047,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_17 [] = {1226,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_18 [] = {1123,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_19 [] = {892,1124,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_20 [] = {1226,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_21 [] = {892,0xFFF5,1,1120,7406,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_22 [] = {892,369,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_23 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_24 [] = {804,891,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_25 [] = {795,891,1047,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_26 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_27 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_28 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_29 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_30 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_31 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_32 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1125 [] = {
g_atype1125_0,
g_atype1125_1,
g_atype1125_2,
g_atype1125_3,
g_atype1125_4,
g_atype1125_5,
g_atype1125_6,
g_atype1125_7,
g_atype1125_8,
g_atype1125_9,
g_atype1125_10,
g_atype1125_11,
g_atype1125_12,
g_atype1125_13,
g_atype1125_14,
g_atype1125_15,
g_atype1125_16,
g_atype1125_17,
g_atype1125_18,
g_atype1125_19,
g_atype1125_20,
g_atype1125_21,
g_atype1125_22,
g_atype1125_23,
g_atype1125_24,
g_atype1125_25,
g_atype1125_26,
g_atype1125_27,
g_atype1125_28,
g_atype1125_29,
g_atype1125_30,
g_atype1125_31,
g_atype1125_32,
};

static const long offsets1125 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
+ @CHROFF(27,0),
+ @CHROFF(27,1),
+ @CHROFF(27,2),
+ @CHROFF(27,3),
+ @CHROFF(27,4),
+ @LNGOFF(27,5,0,0),
};

extern const char *names1126[];
static const uint32 types1126 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1126 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1126_0 [] = {908,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_1 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_2 [] = {887,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_3 [] = {804,0xFFF9,2,996,1055,804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_4 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_5 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_6 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_7 [] = {1279,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_8 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_9 [] = {892,1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_10 [] = {804,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_11 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_12 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_13 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_14 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_15 [] = {795,1067,1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_16 [] = {795,1047,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_17 [] = {1226,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_18 [] = {1123,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_19 [] = {892,1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_20 [] = {1226,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_21 [] = {892,0xFFF5,1,1120,7406,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_22 [] = {892,369,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_23 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_24 [] = {804,891,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_25 [] = {795,891,1047,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_26 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_27 [] = {892,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_28 [] = {892,0xFFF5,1,1120,7406,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_29 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_30 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_31 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_32 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_33 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_34 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1126 [] = {
g_atype1126_0,
g_atype1126_1,
g_atype1126_2,
g_atype1126_3,
g_atype1126_4,
g_atype1126_5,
g_atype1126_6,
g_atype1126_7,
g_atype1126_8,
g_atype1126_9,
g_atype1126_10,
g_atype1126_11,
g_atype1126_12,
g_atype1126_13,
g_atype1126_14,
g_atype1126_15,
g_atype1126_16,
g_atype1126_17,
g_atype1126_18,
g_atype1126_19,
g_atype1126_20,
g_atype1126_21,
g_atype1126_22,
g_atype1126_23,
g_atype1126_24,
g_atype1126_25,
g_atype1126_26,
g_atype1126_27,
g_atype1126_28,
g_atype1126_29,
g_atype1126_30,
g_atype1126_31,
g_atype1126_32,
g_atype1126_33,
g_atype1126_34,
};

static const long offsets1126 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
+ @CHROFF(29,0),
+ @CHROFF(29,1),
+ @CHROFF(29,2),
+ @CHROFF(29,3),
+ @CHROFF(29,4),
+ @LNGOFF(29,5,0,0),
};

extern const char *names1127[];
static const uint32 types1127 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1127 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1127_0 [] = {908,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_1 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_2 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_3 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_4 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_5 [] = {1277,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_6 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_7 [] = {892,1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_8 [] = {804,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_9 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_10 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_11 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_12 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_13 [] = {795,1067,1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_14 [] = {795,1047,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_15 [] = {1226,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_16 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_17 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_18 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_19 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_20 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_21 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1127 [] = {
g_atype1127_0,
g_atype1127_1,
g_atype1127_2,
g_atype1127_3,
g_atype1127_4,
g_atype1127_5,
g_atype1127_6,
g_atype1127_7,
g_atype1127_8,
g_atype1127_9,
g_atype1127_10,
g_atype1127_11,
g_atype1127_12,
g_atype1127_13,
g_atype1127_14,
g_atype1127_15,
g_atype1127_16,
g_atype1127_17,
g_atype1127_18,
g_atype1127_19,
g_atype1127_20,
g_atype1127_21,
};

static const long offsets1127 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
+ @CHROFF(18,0),
+ @CHROFF(18,1),
+ @CHROFF(18,2),
+ @LNGOFF(18,3,0,0),
};

extern const char *names1128[];
static const uint32 types1128 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1128 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1128_0 [] = {908,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_1 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_2 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_3 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_4 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_5 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_6 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_7 [] = {892,1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_8 [] = {804,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_9 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_10 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_11 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_12 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_13 [] = {795,1067,1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_14 [] = {795,1047,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_15 [] = {1226,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_16 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_17 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_18 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_19 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_20 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_21 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_22 [] = {1122,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_23 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_24 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_25 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_26 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_27 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1128 [] = {
g_atype1128_0,
g_atype1128_1,
g_atype1128_2,
g_atype1128_3,
g_atype1128_4,
g_atype1128_5,
g_atype1128_6,
g_atype1128_7,
g_atype1128_8,
g_atype1128_9,
g_atype1128_10,
g_atype1128_11,
g_atype1128_12,
g_atype1128_13,
g_atype1128_14,
g_atype1128_15,
g_atype1128_16,
g_atype1128_17,
g_atype1128_18,
g_atype1128_19,
g_atype1128_20,
g_atype1128_21,
g_atype1128_22,
g_atype1128_23,
g_atype1128_24,
g_atype1128_25,
g_atype1128_26,
g_atype1128_27,
};

static const long offsets1128 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
+ @CHROFF(23,0),
+ @CHROFF(23,1),
+ @CHROFF(23,2),
+ @CHROFF(23,3),
+ @LNGOFF(23,4,0,0),
};

extern const char *names1129[];
static const uint32 types1129 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1129 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1129_0 [] = {908,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_1 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_2 [] = {887,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_3 [] = {804,0xFFF9,2,996,1055,804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_4 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_5 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_6 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_7 [] = {1277,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_8 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_9 [] = {892,1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_10 [] = {804,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_11 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_12 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_13 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_14 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_15 [] = {795,1067,1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_16 [] = {795,1047,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_17 [] = {1226,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_18 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_19 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_20 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_21 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_22 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_23 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_24 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_25 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1129 [] = {
g_atype1129_0,
g_atype1129_1,
g_atype1129_2,
g_atype1129_3,
g_atype1129_4,
g_atype1129_5,
g_atype1129_6,
g_atype1129_7,
g_atype1129_8,
g_atype1129_9,
g_atype1129_10,
g_atype1129_11,
g_atype1129_12,
g_atype1129_13,
g_atype1129_14,
g_atype1129_15,
g_atype1129_16,
g_atype1129_17,
g_atype1129_18,
g_atype1129_19,
g_atype1129_20,
g_atype1129_21,
g_atype1129_22,
g_atype1129_23,
g_atype1129_24,
g_atype1129_25,
};

static const long offsets1129 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
+ @CHROFF(21,0),
+ @CHROFF(21,1),
+ @CHROFF(21,2),
+ @CHROFF(21,3),
+ @LNGOFF(21,4,0,0),
};

extern const char *names1130[];
static const uint32 types1130 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1130 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1130_0 [] = {908,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_1 [] = {907,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_2 [] = {887,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_3 [] = {804,0xFFF9,2,996,1055,804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_4 [] = {917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_5 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_6 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_7 [] = {1277,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_8 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_9 [] = {892,1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_10 [] = {804,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_11 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_12 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_13 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_14 [] = {804,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_15 [] = {795,1067,1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_16 [] = {795,1047,1067,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_17 [] = {1226,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_18 [] = {804,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_19 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_20 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_21 [] = {1279,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_22 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_23 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_24 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_25 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_26 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1130 [] = {
g_atype1130_0,
g_atype1130_1,
g_atype1130_2,
g_atype1130_3,
g_atype1130_4,
g_atype1130_5,
g_atype1130_6,
g_atype1130_7,
g_atype1130_8,
g_atype1130_9,
g_atype1130_10,
g_atype1130_11,
g_atype1130_12,
g_atype1130_13,
g_atype1130_14,
g_atype1130_15,
g_atype1130_16,
g_atype1130_17,
g_atype1130_18,
g_atype1130_19,
g_atype1130_20,
g_atype1130_21,
g_atype1130_22,
g_atype1130_23,
g_atype1130_24,
g_atype1130_25,
g_atype1130_26,
};

static const long offsets1130 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
+ @CHROFF(22,0),
+ @CHROFF(22,1),
+ @CHROFF(22,2),
+ @CHROFF(22,3),
+ @LNGOFF(22,4,0,0),
};

extern const char *names1131[];
static const uint32 types1131 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1131 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1131_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1131_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1131_2 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1131 [] = {
g_atype1131_0,
g_atype1131_1,
g_atype1131_2,
};

static const long offsets1131 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names1132[];
static const uint32 types1132 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1132 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1132_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1132_1 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1132_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1132_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1132_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1132_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1132 [] = {
g_atype1132_0,
g_atype1132_1,
g_atype1132_2,
g_atype1132_3,
g_atype1132_4,
g_atype1132_5,
};

static const long offsets1132 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1133[];
static const uint32 types1133 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1133 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1133_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1133_1 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1133_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1133_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1133_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1133_5 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1133 [] = {
g_atype1133_0,
g_atype1133_1,
g_atype1133_2,
g_atype1133_3,
g_atype1133_4,
g_atype1133_5,
};

static const long offsets1133 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @PTROFF(1,0,0,4,0,0),
};

extern const char *names1134[];
static const uint32 types1134 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1134 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1134_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1134_1 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1134_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1134_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1134_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1134_5 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1134 [] = {
g_atype1134_0,
g_atype1134_1,
g_atype1134_2,
g_atype1134_3,
g_atype1134_4,
g_atype1134_5,
};

static const long offsets1134 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R64OFF(1,0,0,4,0,0,0,0),
};

extern const char *names1135[];
static const uint32 types1135 [] =
{
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1135 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1135_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1135_1 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1135_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1135_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1135_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1135_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1135 [] = {
g_atype1135_0,
g_atype1135_1,
g_atype1135_2,
g_atype1135_3,
g_atype1135_4,
g_atype1135_5,
};

static const long offsets1135 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names1136[];
static const uint32 types1136 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1136 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1136_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1136_1 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1136_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1136_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1136_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1136_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1136 [] = {
g_atype1136_0,
g_atype1136_1,
g_atype1136_2,
g_atype1136_3,
g_atype1136_4,
g_atype1136_5,
};

static const long offsets1136 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names1137[];
static const uint32 types1137 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags1137 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1137_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1137_1 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1137_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1137_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1137_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1137_5 [] = {1208,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1137 [] = {
g_atype1137_0,
g_atype1137_1,
g_atype1137_2,
g_atype1137_3,
g_atype1137_4,
g_atype1137_5,
};

static const long offsets1137 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R32OFF(1,0,0,4,0),
};

extern const char *names1138[];
static const uint32 types1138 [] =
{
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1138 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1138_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1138_1 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1138_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1138_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1138_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1138_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1138 [] = {
g_atype1138_0,
g_atype1138_1,
g_atype1138_2,
g_atype1138_3,
g_atype1138_4,
g_atype1138_5,
};

static const long offsets1138 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names1139[];
static const uint32 types1139 [] =
{
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1139 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1139_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1139_1 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1139_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1139_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1139_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1139_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1139 [] = {
g_atype1139_0,
g_atype1139_1,
g_atype1139_2,
g_atype1139_3,
g_atype1139_4,
g_atype1139_5,
};

static const long offsets1139 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names1140[];
static const uint32 types1140 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1140 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1140_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1140_1 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1140_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1140_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1140_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1140_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1140 [] = {
g_atype1140_0,
g_atype1140_1,
g_atype1140_2,
g_atype1140_3,
g_atype1140_4,
g_atype1140_5,
};

static const long offsets1140 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names1141[];
static const uint32 types1141 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags1141 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1141_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1141_1 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1141_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1141_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1141_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1141_5 [] = {1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1141 [] = {
g_atype1141_0,
g_atype1141_1,
g_atype1141_2,
g_atype1141_3,
g_atype1141_4,
g_atype1141_5,
};

static const long offsets1141 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names1142[];
static const uint32 types1142 [] =
{
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1142 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1142_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1142_1 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1142_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1142_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1142_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1142_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1142 [] = {
g_atype1142_0,
g_atype1142_1,
g_atype1142_2,
g_atype1142_3,
g_atype1142_4,
g_atype1142_5,
};

static const long offsets1142 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names1143[];
static const uint32 types1143 [] =
{
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1143 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1143_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1143_1 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1143_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1143_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1143_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1143_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1143 [] = {
g_atype1143_0,
g_atype1143_1,
g_atype1143_2,
g_atype1143_3,
g_atype1143_4,
g_atype1143_5,
};

static const long offsets1143 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names1144[];
static const uint32 types1144 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1144 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1144_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1144 [] = {
g_atype1144_0,
g_atype1144_1,
g_atype1144_2,
g_atype1144_3,
g_atype1144_4,
g_atype1144_5,
};

static const long offsets1144 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names1145[];
static const uint32 types1145 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags1145 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1145_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_1 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_5 [] = {1184,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1145 [] = {
g_atype1145_0,
g_atype1145_1,
g_atype1145_2,
g_atype1145_3,
g_atype1145_4,
g_atype1145_5,
};

static const long offsets1145 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names1146[];
static const uint32 types1146 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1146 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1146_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_1 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1146 [] = {
g_atype1146_0,
g_atype1146_1,
g_atype1146_2,
g_atype1146_3,
g_atype1146_4,
g_atype1146_5,
};

static const long offsets1146 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names1147[];
static const uint32 types1147 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1147 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1147_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1147_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1147_2 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1147_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1147_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1147 [] = {
g_atype1147_0,
g_atype1147_1,
g_atype1147_2,
g_atype1147_3,
g_atype1147_4,
};

static const long offsets1147 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names1148[];
static const uint32 types1148 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1148 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1148_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1148_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1148_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1148_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1148_4 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1148 [] = {
g_atype1148_0,
g_atype1148_1,
g_atype1148_2,
g_atype1148_3,
g_atype1148_4,
};

static const long offsets1148 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @PTROFF(2,0,0,2,0,0),
};

extern const char *names1149[];
static const uint32 types1149 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1149 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1149_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1149_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1149_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1149_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1149_4 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1149 [] = {
g_atype1149_0,
g_atype1149_1,
g_atype1149_2,
g_atype1149_3,
g_atype1149_4,
};

static const long offsets1149 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names1150[];
static const uint32 types1150 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1150 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1150_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1150_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1150_2 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1150_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1150_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1150 [] = {
g_atype1150_0,
g_atype1150_1,
g_atype1150_2,
g_atype1150_3,
g_atype1150_4,
};

static const long offsets1150 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names1151[];
static const uint32 types1151 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1151 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1151_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1151_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1151_2 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1151_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1151_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1151 [] = {
g_atype1151_0,
g_atype1151_1,
g_atype1151_2,
g_atype1151_3,
g_atype1151_4,
};

static const long offsets1151 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1152[];
static const uint32 types1152 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags1152 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1152_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_4 [] = {1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1152 [] = {
g_atype1152_0,
g_atype1152_1,
g_atype1152_2,
g_atype1152_3,
g_atype1152_4,
};

static const long offsets1152 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names1153[];
static const uint32 types1153 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1153 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1153_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1153 [] = {
g_atype1153_0,
g_atype1153_1,
g_atype1153_2,
g_atype1153_3,
g_atype1153_4,
};

static const long offsets1153 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1154[];
static const uint32 types1154 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1154 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1154_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_2 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1154 [] = {
g_atype1154_0,
g_atype1154_1,
g_atype1154_2,
g_atype1154_3,
g_atype1154_4,
};

static const long offsets1154 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names1155[];
static const uint32 types1155 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1155 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1155_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_2 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1155 [] = {
g_atype1155_0,
g_atype1155_1,
g_atype1155_2,
g_atype1155_3,
g_atype1155_4,
};

static const long offsets1155 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1156[];
static const uint32 types1156 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags1156 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1156_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_4 [] = {1184,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1156 [] = {
g_atype1156_0,
g_atype1156_1,
g_atype1156_2,
g_atype1156_3,
g_atype1156_4,
};

static const long offsets1156 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names1157[];
static const uint32 types1157 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1157 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1157_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1157 [] = {
g_atype1157_0,
g_atype1157_1,
g_atype1157_2,
g_atype1157_3,
g_atype1157_4,
};

static const long offsets1157 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1158[];
static const uint32 types1158 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1158 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1158_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_2 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1158 [] = {
g_atype1158_0,
g_atype1158_1,
g_atype1158_2,
g_atype1158_3,
g_atype1158_4,
};

static const long offsets1158 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1159[];
static const uint32 types1159 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1159 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1159_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_2 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1159 [] = {
g_atype1159_0,
g_atype1159_1,
g_atype1159_2,
g_atype1159_3,
g_atype1159_4,
};

static const long offsets1159 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1160[];
static const uint32 types1160 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags1160 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1160_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_4 [] = {1208,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1160 [] = {
g_atype1160_0,
g_atype1160_1,
g_atype1160_2,
g_atype1160_3,
g_atype1160_4,
};

static const long offsets1160 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R32OFF(2,0,0,2,0),
};

extern const char *names1161[];
static const uint32 types1161 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1161 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1161_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1161 [] = {
g_atype1161_0,
g_atype1161_1,
g_atype1161_2,
g_atype1161_3,
g_atype1161_4,
};

static const long offsets1161 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1162[];
static const uint32 types1162 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1162 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1162_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_2 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_3 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1162 [] = {
g_atype1162_0,
g_atype1162_1,
g_atype1162_2,
g_atype1162_3,
g_atype1162_4,
g_atype1162_5,
};

static const long offsets1162 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1163[];
static const uint32 types1163 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1163 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1163_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_2 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_3 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1163 [] = {
g_atype1163_0,
g_atype1163_1,
g_atype1163_2,
g_atype1163_3,
g_atype1163_4,
g_atype1163_5,
};

static const long offsets1163 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names1164[];
static const uint32 types1164 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1164 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1164_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_5 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1164 [] = {
g_atype1164_0,
g_atype1164_1,
g_atype1164_2,
g_atype1164_3,
g_atype1164_4,
g_atype1164_5,
};

static const long offsets1164 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @PTROFF(2,0,0,3,0,0),
};

extern const char *names1165[];
static const uint32 types1165 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1165 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1165_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_5 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1165 [] = {
g_atype1165_0,
g_atype1165_1,
g_atype1165_2,
g_atype1165_3,
g_atype1165_4,
g_atype1165_5,
};

static const long offsets1165 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R64OFF(2,0,0,3,0,0,0,0),
};

extern const char *names1166[];
static const uint32 types1166 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1166 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1166_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_2 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_3 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1166 [] = {
g_atype1166_0,
g_atype1166_1,
g_atype1166_2,
g_atype1166_3,
g_atype1166_4,
g_atype1166_5,
};

static const long offsets1166 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1167[];
static const uint32 types1167 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1167 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1167_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_3 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1167 [] = {
g_atype1167_0,
g_atype1167_1,
g_atype1167_2,
g_atype1167_3,
g_atype1167_4,
g_atype1167_5,
};

static const long offsets1167 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1168[];
static const uint32 types1168 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags1168 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1168_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_5 [] = {1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1168 [] = {
g_atype1168_0,
g_atype1168_1,
g_atype1168_2,
g_atype1168_3,
g_atype1168_4,
g_atype1168_5,
};

static const long offsets1168 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names1169[];
static const uint32 types1169 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1169 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1169_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_2 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_3 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1169 [] = {
g_atype1169_0,
g_atype1169_1,
g_atype1169_2,
g_atype1169_3,
g_atype1169_4,
g_atype1169_5,
};

static const long offsets1169 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1170[];
static const uint32 types1170 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1170 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1170_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1170 [] = {
g_atype1170_0,
g_atype1170_1,
g_atype1170_2,
g_atype1170_3,
g_atype1170_4,
g_atype1170_5,
};

static const long offsets1170 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1171[];
static const uint32 types1171 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags1171 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1171_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_5 [] = {1184,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1171 [] = {
g_atype1171_0,
g_atype1171_1,
g_atype1171_2,
g_atype1171_3,
g_atype1171_4,
g_atype1171_5,
};

static const long offsets1171 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names1172[];
static const uint32 types1172 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1172 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1172_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_2 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_3 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1172 [] = {
g_atype1172_0,
g_atype1172_1,
g_atype1172_2,
g_atype1172_3,
g_atype1172_4,
g_atype1172_5,
};

static const long offsets1172 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1173[];
static const uint32 types1173 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1173 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1173_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_2 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_3 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1173 [] = {
g_atype1173_0,
g_atype1173_1,
g_atype1173_2,
g_atype1173_3,
g_atype1173_4,
g_atype1173_5,
};

static const long offsets1173 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1174[];
static const uint32 types1174 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1174 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1174_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_3 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1174 [] = {
g_atype1174_0,
g_atype1174_1,
g_atype1174_2,
g_atype1174_3,
g_atype1174_4,
g_atype1174_5,
};

static const long offsets1174 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1175[];
static const uint32 types1175 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1175 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1175_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_2 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_3 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1175 [] = {
g_atype1175_0,
g_atype1175_1,
g_atype1175_2,
g_atype1175_3,
g_atype1175_4,
g_atype1175_5,
};

static const long offsets1175 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names1176[];
static const uint32 types1176 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags1176 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1176_0 [] = {0xFFF9,2,996,1187,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_2 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_5 [] = {1208,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1176 [] = {
g_atype1176_0,
g_atype1176_1,
g_atype1176_2,
g_atype1176_3,
g_atype1176_4,
g_atype1176_5,
};

static const long offsets1176 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R32OFF(2,0,0,3,0),
};

extern const char *names1178[];
static const uint32 types1178 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1178 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1178_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1178 [] = {
g_atype1178_0,
};

static const long offsets1178 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1180[];
static const uint32 types1180 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1180 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1180_0 [] = {1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_1 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1180 [] = {
g_atype1180_0,
g_atype1180_1,
};

static const long offsets1180 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1181[];
static const uint32 types1181 [] =
{
SK_REF,
};

static const uint16 attr_flags1181 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1181_0 [] = {1052,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1181 [] = {
g_atype1181_0,
};

static const long offsets1181 [] =
{
0,
};

extern const char *names1183[];
static const uint32 types1183 [] =
{
SK_INT64,
};

static const uint16 attr_flags1183 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1183_0 [] = {1184,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1183 [] = {
g_atype1183_0,
};

static const long offsets1183 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1184[];
static const uint32 types1184 [] =
{
SK_INT64,
};

static const uint16 attr_flags1184 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1184_0 [] = {1184,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1184 [] = {
g_atype1184_0,
};

static const long offsets1184 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1185[];
static const uint32 types1185 [] =
{
SK_INT64,
};

static const uint16 attr_flags1185 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1185_0 [] = {1184,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1185 [] = {
g_atype1185_0,
};

static const long offsets1185 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1186[];
static const uint32 types1186 [] =
{
SK_INT32,
};

static const uint16 attr_flags1186 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1186_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1186 [] = {
g_atype1186_0,
};

static const long offsets1186 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1187[];
static const uint32 types1187 [] =
{
SK_INT32,
};

static const uint16 attr_flags1187 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1187_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1187 [] = {
g_atype1187_0,
};

static const long offsets1187 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1188[];
static const uint32 types1188 [] =
{
SK_INT32,
};

static const uint16 attr_flags1188 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1188_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1188 [] = {
g_atype1188_0,
};

static const long offsets1188 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1189[];
static const uint32 types1189 [] =
{
SK_INT16,
};

static const uint16 attr_flags1189 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1189_0 [] = {1190,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1189 [] = {
g_atype1189_0,
};

static const long offsets1189 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1190[];
static const uint32 types1190 [] =
{
SK_INT16,
};

static const uint16 attr_flags1190 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1190_0 [] = {1190,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1190 [] = {
g_atype1190_0,
};

static const long offsets1190 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1191[];
static const uint32 types1191 [] =
{
SK_INT16,
};

static const uint16 attr_flags1191 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1191_0 [] = {1190,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1191 [] = {
g_atype1191_0,
};

static const long offsets1191 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1192[];
static const uint32 types1192 [] =
{
SK_INT8,
};

static const uint16 attr_flags1192 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1192_0 [] = {1193,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1192 [] = {
g_atype1192_0,
};

static const long offsets1192 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1193[];
static const uint32 types1193 [] =
{
SK_INT8,
};

static const uint16 attr_flags1193 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1193_0 [] = {1193,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1193 [] = {
g_atype1193_0,
};

static const long offsets1193 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1194[];
static const uint32 types1194 [] =
{
SK_INT8,
};

static const uint16 attr_flags1194 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1194_0 [] = {1193,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1194 [] = {
g_atype1194_0,
};

static const long offsets1194 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1195[];
static const uint32 types1195 [] =
{
SK_UINT64,
};

static const uint16 attr_flags1195 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1195_0 [] = {1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1195 [] = {
g_atype1195_0,
};

static const long offsets1195 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1196[];
static const uint32 types1196 [] =
{
SK_UINT64,
};

static const uint16 attr_flags1196 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1196_0 [] = {1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1196 [] = {
g_atype1196_0,
};

static const long offsets1196 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1197[];
static const uint32 types1197 [] =
{
SK_UINT64,
};

static const uint16 attr_flags1197 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1197_0 [] = {1196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1197 [] = {
g_atype1197_0,
};

static const long offsets1197 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1198[];
static const uint32 types1198 [] =
{
SK_UINT32,
};

static const uint16 attr_flags1198 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1198_0 [] = {1199,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1198 [] = {
g_atype1198_0,
};

static const long offsets1198 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1199[];
static const uint32 types1199 [] =
{
SK_UINT32,
};

static const uint16 attr_flags1199 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1199_0 [] = {1199,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1199 [] = {
g_atype1199_0,
};

static const long offsets1199 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1200[];
static const uint32 types1200 [] =
{
SK_UINT32,
};

static const uint16 attr_flags1200 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1200_0 [] = {1199,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1200 [] = {
g_atype1200_0,
};

static const long offsets1200 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1201[];
static const uint32 types1201 [] =
{
SK_UINT16,
};

static const uint16 attr_flags1201 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1201_0 [] = {1202,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1201 [] = {
g_atype1201_0,
};

static const long offsets1201 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1202[];
static const uint32 types1202 [] =
{
SK_UINT16,
};

static const uint16 attr_flags1202 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1202_0 [] = {1202,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1202 [] = {
g_atype1202_0,
};

static const long offsets1202 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1203[];
static const uint32 types1203 [] =
{
SK_UINT16,
};

static const uint16 attr_flags1203 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1203_0 [] = {1202,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1203 [] = {
g_atype1203_0,
};

static const long offsets1203 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1204[];
static const uint32 types1204 [] =
{
SK_UINT8,
};

static const uint16 attr_flags1204 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1204_0 [] = {1205,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1204 [] = {
g_atype1204_0,
};

static const long offsets1204 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1205[];
static const uint32 types1205 [] =
{
SK_UINT8,
};

static const uint16 attr_flags1205 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1205_0 [] = {1205,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1205 [] = {
g_atype1205_0,
};

static const long offsets1205 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1206[];
static const uint32 types1206 [] =
{
SK_UINT8,
};

static const uint16 attr_flags1206 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1206_0 [] = {1205,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1206 [] = {
g_atype1206_0,
};

static const long offsets1206 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1207[];
static const uint32 types1207 [] =
{
SK_REAL32,
};

static const uint16 attr_flags1207 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1207_0 [] = {1208,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1207 [] = {
g_atype1207_0,
};

static const long offsets1207 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names1208[];
static const uint32 types1208 [] =
{
SK_REAL32,
};

static const uint16 attr_flags1208 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1208_0 [] = {1208,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1208 [] = {
g_atype1208_0,
};

static const long offsets1208 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names1209[];
static const uint32 types1209 [] =
{
SK_REAL32,
};

static const uint16 attr_flags1209 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1209_0 [] = {1208,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1209 [] = {
g_atype1209_0,
};

static const long offsets1209 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names1210[];
static const uint32 types1210 [] =
{
SK_REAL64,
};

static const uint16 attr_flags1210 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1210_0 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1210 [] = {
g_atype1210_0,
};

static const long offsets1210 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names1211[];
static const uint32 types1211 [] =
{
SK_REAL64,
};

static const uint16 attr_flags1211 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1211_0 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1211 [] = {
g_atype1211_0,
};

static const long offsets1211 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names1212[];
static const uint32 types1212 [] =
{
SK_REAL64,
};

static const uint16 attr_flags1212 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1212_0 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1212 [] = {
g_atype1212_0,
};

static const long offsets1212 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names1213[];
static const uint32 types1213 [] =
{
SK_REF,
};

static const uint16 attr_flags1213 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1213_0 [] = {892,1176,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1213 [] = {
g_atype1213_0,
};

static const long offsets1213 [] =
{
0,
};

extern const char *names1214[];
static const uint32 types1214 [] =
{
SK_REF,
};

static const uint16 attr_flags1214 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1214_0 [] = {795,1176,1180,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1214 [] = {
g_atype1214_0,
};

static const long offsets1214 [] =
{
0,
};

extern const char *names1215[];
static const uint32 types1215 [] =
{
SK_REF,
};

static const uint16 attr_flags1215 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1215_0 [] = {1057,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1215 [] = {
g_atype1215_0,
};

static const long offsets1215 [] =
{
0,
};

extern const char *names1222[];
static const uint32 types1222 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1222 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1222_0 [] = {36,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_3 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1222 [] = {
g_atype1222_0,
g_atype1222_1,
g_atype1222_2,
g_atype1222_3,
};

static const long offsets1222 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
};

extern const char *names1223[];
static const uint32 types1223 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1223 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1223_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_2 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_3 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_4 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_5 [] = {1057,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1223 [] = {
g_atype1223_0,
g_atype1223_1,
g_atype1223_2,
g_atype1223_3,
g_atype1223_4,
g_atype1223_5,
};

static const long offsets1223 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names1224[];
static const uint32 types1224 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1224 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1224_0 [] = {139,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_1 [] = {141,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1224 [] = {
g_atype1224_0,
g_atype1224_1,
};

static const long offsets1224 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1225[];
static const uint32 types1225 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1225 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1225_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_1 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_3 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_4 [] = {58,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_5 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_6 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_10 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_11 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_12 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_13 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_14 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_17 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_18 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_19 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_20 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_21 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_22 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1225 [] = {
g_atype1225_0,
g_atype1225_1,
g_atype1225_2,
g_atype1225_3,
g_atype1225_4,
g_atype1225_5,
g_atype1225_6,
g_atype1225_7,
g_atype1225_8,
g_atype1225_9,
g_atype1225_10,
g_atype1225_11,
g_atype1225_12,
g_atype1225_13,
g_atype1225_14,
g_atype1225_15,
g_atype1225_16,
g_atype1225_17,
g_atype1225_18,
g_atype1225_19,
g_atype1225_20,
g_atype1225_21,
g_atype1225_22,
};

static const long offsets1225 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names1226[];
static const uint32 types1226 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT8,
SK_UINT8,
SK_UINT8,
SK_UINT8,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT16,
};

static const uint16 attr_flags1226 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1226_0 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_2 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_3 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_5 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_6 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_7 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_8 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_9 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_10 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_11 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_12 [] = {1202,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1226 [] = {
g_atype1226_0,
g_atype1226_1,
g_atype1226_2,
g_atype1226_3,
g_atype1226_4,
g_atype1226_5,
g_atype1226_6,
g_atype1226_7,
g_atype1226_8,
g_atype1226_9,
g_atype1226_10,
g_atype1226_11,
g_atype1226_12,
};

static const long offsets1226 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @I16OFF(4,5,0),
+ @I16OFF(4,5,1),
+ @I16OFF(4,5,2),
+ @I16OFF(4,5,3),
};

extern const char *names1227[];
static const uint32 types1227 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1227 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1227_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_1 [] = {231,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_2 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_3 [] = {1108,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_9 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1227 [] = {
g_atype1227_0,
g_atype1227_1,
g_atype1227_2,
g_atype1227_3,
g_atype1227_4,
g_atype1227_5,
g_atype1227_6,
g_atype1227_7,
g_atype1227_8,
g_atype1227_9,
};

static const long offsets1227 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
+ @LNGOFF(4,1,0,2),
+ @LNGOFF(4,1,0,3),
+ @LNGOFF(4,1,0,4),
};

extern const char *names1228[];
static const uint32 types1228 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1228 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1228_0 [] = {232,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_1 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_2 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_4 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_9 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1228 [] = {
g_atype1228_0,
g_atype1228_1,
g_atype1228_2,
g_atype1228_3,
g_atype1228_4,
g_atype1228_5,
g_atype1228_6,
g_atype1228_7,
g_atype1228_8,
g_atype1228_9,
};

static const long offsets1228 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
+ @LNGOFF(3,1,0,3),
+ @LNGOFF(3,1,0,4),
+ @LNGOFF(3,1,0,5),
};

extern const char *names1229[];
static const uint32 types1229 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1229 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1229_0 [] = {233,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_1 [] = {1110,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_2 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_9 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1229 [] = {
g_atype1229_0,
g_atype1229_1,
g_atype1229_2,
g_atype1229_3,
g_atype1229_4,
g_atype1229_5,
g_atype1229_6,
g_atype1229_7,
g_atype1229_8,
g_atype1229_9,
};

static const long offsets1229 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
+ @LNGOFF(3,1,0,3),
+ @LNGOFF(3,1,0,4),
+ @LNGOFF(3,1,0,5),
};

extern const char *names1235[];
static const uint32 types1235 [] =
{
SK_REF,
SK_CHAR8,
SK_CHAR32,
SK_INT32,
};

static const uint16 attr_flags1235 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1235_0 [] = {260,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_1 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_2 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1235 [] = {
g_atype1235_0,
g_atype1235_1,
g_atype1235_2,
g_atype1235_3,
};

static const long offsets1235 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names1236[];
static const uint32 types1236 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1236 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1236_0 [] = {260,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_1 [] = {116,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_2 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_3 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_4 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_5 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_7 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_17 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_18 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_19 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_20 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_21 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1236 [] = {
g_atype1236_0,
g_atype1236_1,
g_atype1236_2,
g_atype1236_3,
g_atype1236_4,
g_atype1236_5,
g_atype1236_6,
g_atype1236_7,
g_atype1236_8,
g_atype1236_9,
g_atype1236_10,
g_atype1236_11,
g_atype1236_12,
g_atype1236_13,
g_atype1236_14,
g_atype1236_15,
g_atype1236_16,
g_atype1236_17,
g_atype1236_18,
g_atype1236_19,
g_atype1236_20,
g_atype1236_21,
};

static const long offsets1236 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @LNGOFF(5,2,0,3),
+ @LNGOFF(5,2,0,4),
+ @LNGOFF(5,2,0,5),
+ @LNGOFF(5,2,0,6),
+ @LNGOFF(5,2,0,7),
+ @LNGOFF(5,2,0,8),
+ @LNGOFF(5,2,0,9),
+ @LNGOFF(5,2,0,10),
+ @LNGOFF(5,2,0,11),
+ @LNGOFF(5,2,0,12),
+ @LNGOFF(5,2,0,13),
+ @LNGOFF(5,2,0,14),
};

extern const char *names1237[];
static const uint32 types1237 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1237 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1237_0 [] = {260,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_1 [] = {116,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_2 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_3 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_4 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_5 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_6 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_7 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_8 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_9 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_10 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_11 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_12 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_13 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_14 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_15 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_16 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_17 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_18 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_19 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_20 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_21 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_22 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_23 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_24 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_25 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_26 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_27 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_28 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_29 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_30 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_31 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_32 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_33 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_34 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_35 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_36 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_37 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1237 [] = {
g_atype1237_0,
g_atype1237_1,
g_atype1237_2,
g_atype1237_3,
g_atype1237_4,
g_atype1237_5,
g_atype1237_6,
g_atype1237_7,
g_atype1237_8,
g_atype1237_9,
g_atype1237_10,
g_atype1237_11,
g_atype1237_12,
g_atype1237_13,
g_atype1237_14,
g_atype1237_15,
g_atype1237_16,
g_atype1237_17,
g_atype1237_18,
g_atype1237_19,
g_atype1237_20,
g_atype1237_21,
g_atype1237_22,
g_atype1237_23,
g_atype1237_24,
g_atype1237_25,
g_atype1237_26,
g_atype1237_27,
g_atype1237_28,
g_atype1237_29,
g_atype1237_30,
g_atype1237_31,
g_atype1237_32,
g_atype1237_33,
g_atype1237_34,
g_atype1237_35,
g_atype1237_36,
g_atype1237_37,
};

static const long offsets1237 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @CHROFF(14,1),
+ @CHROFF(14,2),
+ @LNGOFF(14,3,0,0),
+ @LNGOFF(14,3,0,1),
+ @LNGOFF(14,3,0,2),
+ @LNGOFF(14,3,0,3),
+ @LNGOFF(14,3,0,4),
+ @LNGOFF(14,3,0,5),
+ @LNGOFF(14,3,0,6),
+ @LNGOFF(14,3,0,7),
+ @LNGOFF(14,3,0,8),
+ @LNGOFF(14,3,0,9),
+ @LNGOFF(14,3,0,10),
+ @LNGOFF(14,3,0,11),
+ @LNGOFF(14,3,0,12),
+ @LNGOFF(14,3,0,13),
+ @LNGOFF(14,3,0,14),
+ @LNGOFF(14,3,0,15),
+ @LNGOFF(14,3,0,16),
+ @LNGOFF(14,3,0,17),
+ @LNGOFF(14,3,0,18),
+ @LNGOFF(14,3,0,19),
+ @LNGOFF(14,3,0,20),
};

extern const char *names1238[];
static const uint32 types1238 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1238 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1238_0 [] = {260,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_1 [] = {116,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_2 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_3 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_4 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_5 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_6 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_7 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_8 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_9 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_10 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_11 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_12 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_13 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_14 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_15 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_16 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_17 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_18 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_19 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_20 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_21 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_22 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_23 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_24 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_25 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_26 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_27 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_28 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_29 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_30 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_31 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_32 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_33 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_34 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_35 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_36 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_37 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_38 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_39 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_40 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_41 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1238 [] = {
g_atype1238_0,
g_atype1238_1,
g_atype1238_2,
g_atype1238_3,
g_atype1238_4,
g_atype1238_5,
g_atype1238_6,
g_atype1238_7,
g_atype1238_8,
g_atype1238_9,
g_atype1238_10,
g_atype1238_11,
g_atype1238_12,
g_atype1238_13,
g_atype1238_14,
g_atype1238_15,
g_atype1238_16,
g_atype1238_17,
g_atype1238_18,
g_atype1238_19,
g_atype1238_20,
g_atype1238_21,
g_atype1238_22,
g_atype1238_23,
g_atype1238_24,
g_atype1238_25,
g_atype1238_26,
g_atype1238_27,
g_atype1238_28,
g_atype1238_29,
g_atype1238_30,
g_atype1238_31,
g_atype1238_32,
g_atype1238_33,
g_atype1238_34,
g_atype1238_35,
g_atype1238_36,
g_atype1238_37,
g_atype1238_38,
g_atype1238_39,
g_atype1238_40,
g_atype1238_41,
};

static const long offsets1238 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @CHROFF(16,3),
+ @LNGOFF(16,4,0,0),
+ @LNGOFF(16,4,0,1),
+ @LNGOFF(16,4,0,2),
+ @LNGOFF(16,4,0,3),
+ @LNGOFF(16,4,0,4),
+ @LNGOFF(16,4,0,5),
+ @LNGOFF(16,4,0,6),
+ @LNGOFF(16,4,0,7),
+ @LNGOFF(16,4,0,8),
+ @LNGOFF(16,4,0,9),
+ @LNGOFF(16,4,0,10),
+ @LNGOFF(16,4,0,11),
+ @LNGOFF(16,4,0,12),
+ @LNGOFF(16,4,0,13),
+ @LNGOFF(16,4,0,14),
+ @LNGOFF(16,4,0,15),
+ @LNGOFF(16,4,0,16),
+ @LNGOFF(16,4,0,17),
+ @LNGOFF(16,4,0,18),
+ @LNGOFF(16,4,0,19),
+ @LNGOFF(16,4,0,20),
+ @LNGOFF(16,4,0,21),
};

extern const char *names1239[];
static const uint32 types1239 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1239 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1239_0 [] = {260,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_1 [] = {116,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_2 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_3 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_4 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_5 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_6 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_7 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_8 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_9 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_10 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_11 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_12 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_13 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_14 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_15 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_16 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_17 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_18 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_19 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_20 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_21 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_22 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_23 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_24 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_25 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_26 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_27 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_28 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_29 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_30 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_31 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_32 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_33 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_34 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_35 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_36 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_37 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_38 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_39 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_40 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_41 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1239 [] = {
g_atype1239_0,
g_atype1239_1,
g_atype1239_2,
g_atype1239_3,
g_atype1239_4,
g_atype1239_5,
g_atype1239_6,
g_atype1239_7,
g_atype1239_8,
g_atype1239_9,
g_atype1239_10,
g_atype1239_11,
g_atype1239_12,
g_atype1239_13,
g_atype1239_14,
g_atype1239_15,
g_atype1239_16,
g_atype1239_17,
g_atype1239_18,
g_atype1239_19,
g_atype1239_20,
g_atype1239_21,
g_atype1239_22,
g_atype1239_23,
g_atype1239_24,
g_atype1239_25,
g_atype1239_26,
g_atype1239_27,
g_atype1239_28,
g_atype1239_29,
g_atype1239_30,
g_atype1239_31,
g_atype1239_32,
g_atype1239_33,
g_atype1239_34,
g_atype1239_35,
g_atype1239_36,
g_atype1239_37,
g_atype1239_38,
g_atype1239_39,
g_atype1239_40,
g_atype1239_41,
};

static const long offsets1239 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @CHROFF(16,3),
+ @LNGOFF(16,4,0,0),
+ @LNGOFF(16,4,0,1),
+ @LNGOFF(16,4,0,2),
+ @LNGOFF(16,4,0,3),
+ @LNGOFF(16,4,0,4),
+ @LNGOFF(16,4,0,5),
+ @LNGOFF(16,4,0,6),
+ @LNGOFF(16,4,0,7),
+ @LNGOFF(16,4,0,8),
+ @LNGOFF(16,4,0,9),
+ @LNGOFF(16,4,0,10),
+ @LNGOFF(16,4,0,11),
+ @LNGOFF(16,4,0,12),
+ @LNGOFF(16,4,0,13),
+ @LNGOFF(16,4,0,14),
+ @LNGOFF(16,4,0,15),
+ @LNGOFF(16,4,0,16),
+ @LNGOFF(16,4,0,17),
+ @LNGOFF(16,4,0,18),
+ @LNGOFF(16,4,0,19),
+ @LNGOFF(16,4,0,20),
+ @LNGOFF(16,4,0,21),
};

extern const char *names1242[];
static const uint32 types1242 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1242 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1242_0 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1242 [] = {
g_atype1242_0,
};

static const long offsets1242 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1243[];
static const uint32 types1243 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1243 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1243_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1243_1 [] = {58,0xFFFF};
static const EIF_TYPE_INDEX g_atype1243_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1243_3 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1243 [] = {
g_atype1243_0,
g_atype1243_1,
g_atype1243_2,
g_atype1243_3,
};

static const long offsets1243 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names1244[];
static const uint32 types1244 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1244 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1244_0 [] = {892,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_1 [] = {892,917,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1244 [] = {
g_atype1244_0,
g_atype1244_1,
};

static const long offsets1244 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1245[];
static const uint32 types1245 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1245 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1245_0 [] = {892,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_1 [] = {892,917,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1245 [] = {
g_atype1245_0,
g_atype1245_1,
};

static const long offsets1245 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1246[];
static const uint32 types1246 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1246 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1246_0 [] = {892,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_1 [] = {892,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_2 [] = {1128,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_3 [] = {1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_4 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_5 [] = {892,1123,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_6 [] = {892,1125,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_7 [] = {804,1120,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_8 [] = {29,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_9 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1246 [] = {
g_atype1246_0,
g_atype1246_1,
g_atype1246_2,
g_atype1246_3,
g_atype1246_4,
g_atype1246_5,
g_atype1246_6,
g_atype1246_7,
g_atype1246_8,
g_atype1246_9,
};

static const long offsets1246 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
};

extern const char *names1247[];
static const uint32 types1247 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1247 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1247_0 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_1 [] = {892,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_2 [] = {892,917,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_3 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_4 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_5 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_8 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1247 [] = {
g_atype1247_0,
g_atype1247_1,
g_atype1247_2,
g_atype1247_3,
g_atype1247_4,
g_atype1247_5,
g_atype1247_6,
g_atype1247_7,
g_atype1247_8,
};

static const long offsets1247 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
};

extern const char *names1249[];
static const uint32 types1249 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1249 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1249_0 [] = {796,1059,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_1 [] = {822,1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_2 [] = {822,1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_3 [] = {1296,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_6 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1249 [] = {
g_atype1249_0,
g_atype1249_1,
g_atype1249_2,
g_atype1249_3,
g_atype1249_4,
g_atype1249_5,
g_atype1249_6,
};

static const long offsets1249 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
};

extern const char *names1250[];
static const uint32 types1250 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1250 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1250_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1250 [] = {
g_atype1250_0,
g_atype1250_1,
g_atype1250_2,
};

static const long offsets1250 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1251[];
static const uint32 types1251 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1251 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1251_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1251 [] = {
g_atype1251_0,
g_atype1251_1,
g_atype1251_2,
};

static const long offsets1251 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1252[];
static const uint32 types1252 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1252 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1252_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1252 [] = {
g_atype1252_0,
g_atype1252_1,
g_atype1252_2,
};

static const long offsets1252 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1253[];
static const uint32 types1253 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1253 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1253_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1253 [] = {
g_atype1253_0,
g_atype1253_1,
g_atype1253_2,
};

static const long offsets1253 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1254[];
static const uint32 types1254 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1254 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1254_0 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_2 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_3 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_4 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1254 [] = {
g_atype1254_0,
g_atype1254_1,
g_atype1254_2,
g_atype1254_3,
g_atype1254_4,
};

static const long offsets1254 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names1255[];
static const uint32 types1255 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1255 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1255_0 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_1 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_2 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_3 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_4 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_7 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1255 [] = {
g_atype1255_0,
g_atype1255_1,
g_atype1255_2,
g_atype1255_3,
g_atype1255_4,
g_atype1255_5,
g_atype1255_6,
g_atype1255_7,
};

static const long offsets1255 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names1256[];
static const uint32 types1256 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
};

static const uint16 attr_flags1256 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1256_0 [] = {908,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_1 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_2 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_3 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_4 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_5 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_6 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_7 [] = {804,1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_8 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_9 [] = {1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_10 [] = {795,1071,1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_11 [] = {804,1122,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_12 [] = {892,1128,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_13 [] = {1128,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_14 [] = {1128,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_15 [] = {892,1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_16 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_17 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_18 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_19 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_20 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_21 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1256 [] = {
g_atype1256_0,
g_atype1256_1,
g_atype1256_2,
g_atype1256_3,
g_atype1256_4,
g_atype1256_5,
g_atype1256_6,
g_atype1256_7,
g_atype1256_8,
g_atype1256_9,
g_atype1256_10,
g_atype1256_11,
g_atype1256_12,
g_atype1256_13,
g_atype1256_14,
g_atype1256_15,
g_atype1256_16,
g_atype1256_17,
g_atype1256_18,
g_atype1256_19,
g_atype1256_20,
g_atype1256_21,
};

static const long offsets1256 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @CHROFF(16,3),
+ @LNGOFF(16,4,0,0),
+ @LNGOFF(16,4,0,1),
};

extern const char *names1260[];
static const uint32 types1260 [] =
{
SK_REF,
};

static const uint16 attr_flags1260 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1260_0 [] = {1055,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1260 [] = {
g_atype1260_0,
};

static const long offsets1260 [] =
{
0,
};

extern const char *names1262[];
static const uint32 types1262 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1262 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1262_0 [] = {0xFFF9,2,996,893,1187,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_1 [] = {0xFFF9,2,996,893,1187,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_2 [] = {0xFFF9,2,996,893,1187,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_3 [] = {0xFFF9,2,996,893,1187,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_4 [] = {174,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_5 [] = {174,1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_6 [] = {804,0xFFF9,2,996,1225,1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_7 [] = {804,804,59,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_8 [] = {1071,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1262 [] = {
g_atype1262_0,
g_atype1262_1,
g_atype1262_2,
g_atype1262_3,
g_atype1262_4,
g_atype1262_5,
g_atype1262_6,
g_atype1262_7,
g_atype1262_8,
};

static const long offsets1262 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
};

extern const char *names1264[];
static const uint32 types1264 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1264 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1264_0 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_1 [] = {222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1264 [] = {
g_atype1264_0,
g_atype1264_1,
g_atype1264_2,
};

static const long offsets1264 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names1266[];
static const uint32 types1266 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1266 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1266_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_1 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_3 [] = {108,1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_5 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_9 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_10 [] = {1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1266 [] = {
g_atype1266_0,
g_atype1266_1,
g_atype1266_2,
g_atype1266_3,
g_atype1266_4,
g_atype1266_5,
g_atype1266_6,
g_atype1266_7,
g_atype1266_8,
g_atype1266_9,
g_atype1266_10,
};

static const long offsets1266 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @PTROFF(6,2,0,1,0,0),
+ @PTROFF(6,2,0,1,0,1),
};

extern const char *names1267[];
static const uint32 types1267 [] =
{
SK_REF,
};

static const uint16 attr_flags1267 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1267_0 [] = {1052,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1267 [] = {
g_atype1267_0,
};

static const long offsets1267 [] =
{
0,
};

extern const char *names1268[];
static const uint32 types1268 [] =
{
SK_REF,
};

static const uint16 attr_flags1268 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1268_0 [] = {1052,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1268 [] = {
g_atype1268_0,
};

static const long offsets1268 [] =
{
0,
};

extern const char *names1269[];
static const uint32 types1269 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1269 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1269_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_1 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_5 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_6 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_9 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_10 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_11 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_12 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_13 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_17 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_18 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_19 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_20 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_21 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1269 [] = {
g_atype1269_0,
g_atype1269_1,
g_atype1269_2,
g_atype1269_3,
g_atype1269_4,
g_atype1269_5,
g_atype1269_6,
g_atype1269_7,
g_atype1269_8,
g_atype1269_9,
g_atype1269_10,
g_atype1269_11,
g_atype1269_12,
g_atype1269_13,
g_atype1269_14,
g_atype1269_15,
g_atype1269_16,
g_atype1269_17,
g_atype1269_18,
g_atype1269_19,
g_atype1269_20,
g_atype1269_21,
};

static const long offsets1269 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1270[];
static const uint32 types1270 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1270 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1270_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_1 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_5 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_6 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_9 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_10 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_11 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_12 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_13 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_17 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_18 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_19 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_20 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_21 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1270 [] = {
g_atype1270_0,
g_atype1270_1,
g_atype1270_2,
g_atype1270_3,
g_atype1270_4,
g_atype1270_5,
g_atype1270_6,
g_atype1270_7,
g_atype1270_8,
g_atype1270_9,
g_atype1270_10,
g_atype1270_11,
g_atype1270_12,
g_atype1270_13,
g_atype1270_14,
g_atype1270_15,
g_atype1270_16,
g_atype1270_17,
g_atype1270_18,
g_atype1270_19,
g_atype1270_20,
g_atype1270_21,
};

static const long offsets1270 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1271[];
static const uint32 types1271 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1271 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1271_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_1 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_5 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_6 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_9 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_10 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_11 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_12 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_13 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_17 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_18 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_19 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_20 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_21 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1271 [] = {
g_atype1271_0,
g_atype1271_1,
g_atype1271_2,
g_atype1271_3,
g_atype1271_4,
g_atype1271_5,
g_atype1271_6,
g_atype1271_7,
g_atype1271_8,
g_atype1271_9,
g_atype1271_10,
g_atype1271_11,
g_atype1271_12,
g_atype1271_13,
g_atype1271_14,
g_atype1271_15,
g_atype1271_16,
g_atype1271_17,
g_atype1271_18,
g_atype1271_19,
g_atype1271_20,
g_atype1271_21,
};

static const long offsets1271 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1272[];
static const uint32 types1272 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1272 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1272_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_1 [] = {109,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_2 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_3 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_4 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1272 [] = {
g_atype1272_0,
g_atype1272_1,
g_atype1272_2,
g_atype1272_3,
g_atype1272_4,
};

static const long offsets1272 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1273[];
static const uint32 types1273 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1273 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1273_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_1 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_2 [] = {1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_3 [] = {58,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_5 [] = {109,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_6 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_7 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_8 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_11 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_12 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_13 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_14 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_15 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_16 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_17 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_18 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_19 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_20 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_21 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_22 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_23 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_24 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_25 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1273 [] = {
g_atype1273_0,
g_atype1273_1,
g_atype1273_2,
g_atype1273_3,
g_atype1273_4,
g_atype1273_5,
g_atype1273_6,
g_atype1273_7,
g_atype1273_8,
g_atype1273_9,
g_atype1273_10,
g_atype1273_11,
g_atype1273_12,
g_atype1273_13,
g_atype1273_14,
g_atype1273_15,
g_atype1273_16,
g_atype1273_17,
g_atype1273_18,
g_atype1273_19,
g_atype1273_20,
g_atype1273_21,
g_atype1273_22,
g_atype1273_23,
g_atype1273_24,
g_atype1273_25,
};

static const long offsets1273 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @I16OFF(7,8,0),
+ @I16OFF(7,8,1),
+ @LNGOFF(7,8,2,0),
+ @LNGOFF(7,8,2,1),
+ @LNGOFF(7,8,2,2),
+ @LNGOFF(7,8,2,3),
+ @R32OFF(7,8,2,4,0),
+ @PTROFF(7,8,2,4,1,0),
+ @I64OFF(7,8,2,4,1,1,0),
+ @I64OFF(7,8,2,4,1,1,1),
+ @R64OFF(7,8,2,4,1,1,2,0),
};

extern const char *names1274[];
static const uint32 types1274 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1274 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1274_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_1 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_3 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_4 [] = {109,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_5 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_6 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_7 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_11 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_12 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_13 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_14 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_15 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_17 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_18 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_19 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_20 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_21 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_22 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_23 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1274 [] = {
g_atype1274_0,
g_atype1274_1,
g_atype1274_2,
g_atype1274_3,
g_atype1274_4,
g_atype1274_5,
g_atype1274_6,
g_atype1274_7,
g_atype1274_8,
g_atype1274_9,
g_atype1274_10,
g_atype1274_11,
g_atype1274_12,
g_atype1274_13,
g_atype1274_14,
g_atype1274_15,
g_atype1274_16,
g_atype1274_17,
g_atype1274_18,
g_atype1274_19,
g_atype1274_20,
g_atype1274_21,
g_atype1274_22,
g_atype1274_23,
};

static const long offsets1274 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1275[];
static const uint32 types1275 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1275 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1275_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_1 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_3 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_4 [] = {109,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_5 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_6 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_7 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_11 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_12 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_13 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_14 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_15 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_17 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_18 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_19 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_20 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_21 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_22 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_23 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1275 [] = {
g_atype1275_0,
g_atype1275_1,
g_atype1275_2,
g_atype1275_3,
g_atype1275_4,
g_atype1275_5,
g_atype1275_6,
g_atype1275_7,
g_atype1275_8,
g_atype1275_9,
g_atype1275_10,
g_atype1275_11,
g_atype1275_12,
g_atype1275_13,
g_atype1275_14,
g_atype1275_15,
g_atype1275_16,
g_atype1275_17,
g_atype1275_18,
g_atype1275_19,
g_atype1275_20,
g_atype1275_21,
g_atype1275_22,
g_atype1275_23,
};

static const long offsets1275 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1276[];
static const uint32 types1276 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1276 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1276_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_1 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_3 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_4 [] = {109,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_5 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_6 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_7 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_11 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_12 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_13 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_14 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_15 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_17 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_18 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_19 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_20 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_21 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_22 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_23 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1276 [] = {
g_atype1276_0,
g_atype1276_1,
g_atype1276_2,
g_atype1276_3,
g_atype1276_4,
g_atype1276_5,
g_atype1276_6,
g_atype1276_7,
g_atype1276_8,
g_atype1276_9,
g_atype1276_10,
g_atype1276_11,
g_atype1276_12,
g_atype1276_13,
g_atype1276_14,
g_atype1276_15,
g_atype1276_16,
g_atype1276_17,
g_atype1276_18,
g_atype1276_19,
g_atype1276_20,
g_atype1276_21,
g_atype1276_22,
g_atype1276_23,
};

static const long offsets1276 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1277[];
static const uint32 types1277 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1277 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1277_0 [] = {1047,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_1 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_2 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_3 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_4 [] = {109,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_5 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_6 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_7 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_11 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_12 [] = {1193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_13 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_14 [] = {1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_15 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_17 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_18 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_19 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_20 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_21 [] = {1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_22 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_23 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1277 [] = {
g_atype1277_0,
g_atype1277_1,
g_atype1277_2,
g_atype1277_3,
g_atype1277_4,
g_atype1277_5,
g_atype1277_6,
g_atype1277_7,
g_atype1277_8,
g_atype1277_9,
g_atype1277_10,
g_atype1277_11,
g_atype1277_12,
g_atype1277_13,
g_atype1277_14,
g_atype1277_15,
g_atype1277_16,
g_atype1277_17,
g_atype1277_18,
g_atype1277_19,
g_atype1277_20,
g_atype1277_21,
g_atype1277_22,
g_atype1277_23,
};

static const long offsets1277 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1278[];
static const uint32 types1278 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1278 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1278_0 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_1 [] = {1277,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_2 [] = {1071,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1278 [] = {
g_atype1278_0,
g_atype1278_1,
g_atype1278_2,
};

static const long offsets1278 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1279[];
static const uint32 types1279 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1279 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1279_0 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_1 [] = {1277,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_2 [] = {1071,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1279 [] = {
g_atype1279_0,
g_atype1279_1,
g_atype1279_2,
};

static const long offsets1279 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1280[];
static const uint32 types1280 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1280 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1280_0 [] = {1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_1 [] = {1277,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_2 [] = {1071,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1280 [] = {
g_atype1280_0,
g_atype1280_1,
g_atype1280_2,
};

static const long offsets1280 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1281[];
static const uint32 types1281 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1281 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1281_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_1 [] = {887,1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_2 [] = {1176,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_3 [] = {1177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_4 [] = {1177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_5 [] = {1178,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_6 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_7 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_8 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_13 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1281 [] = {
g_atype1281_0,
g_atype1281_1,
g_atype1281_2,
g_atype1281_3,
g_atype1281_4,
g_atype1281_5,
g_atype1281_6,
g_atype1281_7,
g_atype1281_8,
g_atype1281_9,
g_atype1281_10,
g_atype1281_11,
g_atype1281_12,
g_atype1281_13,
};

static const long offsets1281 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
+ @LNGOFF(9,2,0,1),
+ @LNGOFF(9,2,0,2),
};

extern const char *names1282[];
static const uint32 types1282 [] =
{
SK_REF,
};

static const uint16 attr_flags1282 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1282_0 [] = {126,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1282 [] = {
g_atype1282_0,
};

static const long offsets1282 [] =
{
0,
};

extern const char *names1283[];
static const uint32 types1283 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1283 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1283_0 [] = {1068,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_1 [] = {1068,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_2 [] = {1068,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_3 [] = {887,0xFFF9,2,996,1068,892,0xFFF9,2,996,1130,1130,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_10 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1283 [] = {
g_atype1283_0,
g_atype1283_1,
g_atype1283_2,
g_atype1283_3,
g_atype1283_4,
g_atype1283_5,
g_atype1283_6,
g_atype1283_7,
g_atype1283_8,
g_atype1283_9,
g_atype1283_10,
};

static const long offsets1283 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @LNGOFF(4,5,0,0),
+ @LNGOFF(4,5,0,1),
};

extern const char *names1289[];
static const uint32 types1289 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1289 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1289_0 [] = {34,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_1 [] = {32,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_2 [] = {31,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_3 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_5 [] = {31,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_6 [] = {31,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_10 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_11 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_12 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_13 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_14 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_15 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_16 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_17 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_18 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_19 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_20 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_21 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_22 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_23 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_24 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_25 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_26 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_27 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_28 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_29 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_30 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1289 [] = {
g_atype1289_0,
g_atype1289_1,
g_atype1289_2,
g_atype1289_3,
g_atype1289_4,
g_atype1289_5,
g_atype1289_6,
g_atype1289_7,
g_atype1289_8,
g_atype1289_9,
g_atype1289_10,
g_atype1289_11,
g_atype1289_12,
g_atype1289_13,
g_atype1289_14,
g_atype1289_15,
g_atype1289_16,
g_atype1289_17,
g_atype1289_18,
g_atype1289_19,
g_atype1289_20,
g_atype1289_21,
g_atype1289_22,
g_atype1289_23,
g_atype1289_24,
g_atype1289_25,
g_atype1289_26,
g_atype1289_27,
g_atype1289_28,
g_atype1289_29,
g_atype1289_30,
};

static const long offsets1289 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @CHROFF(7,8),
+ @CHROFF(7,9),
+ @CHROFF(7,10),
+ @CHROFF(7,11),
+ @CHROFF(7,12),
+ @LNGOFF(7,13,0,0),
+ @LNGOFF(7,13,0,1),
+ @LNGOFF(7,13,0,2),
+ @LNGOFF(7,13,0,3),
+ @LNGOFF(7,13,0,4),
+ @LNGOFF(7,13,0,5),
+ @LNGOFF(7,13,0,6),
+ @LNGOFF(7,13,0,7),
+ @LNGOFF(7,13,0,8),
+ @LNGOFF(7,13,0,9),
+ @LNGOFF(7,13,0,10),
};

extern const char *names1290[];
static const uint32 types1290 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1290 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1290_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_1 [] = {34,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_2 [] = {32,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_3 [] = {31,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_5 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_6 [] = {31,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_7 [] = {31,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_8 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_9 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_10 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_11 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_12 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_13 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_14 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_15 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_16 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_17 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_18 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_19 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_20 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_21 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_22 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_23 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_24 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_25 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_26 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_27 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_28 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_29 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_30 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_31 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_32 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_33 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_34 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_35 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_36 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_37 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_38 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_39 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_40 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_41 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_42 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_43 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_44 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_45 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_46 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_47 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_48 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_49 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_50 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_51 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1290 [] = {
g_atype1290_0,
g_atype1290_1,
g_atype1290_2,
g_atype1290_3,
g_atype1290_4,
g_atype1290_5,
g_atype1290_6,
g_atype1290_7,
g_atype1290_8,
g_atype1290_9,
g_atype1290_10,
g_atype1290_11,
g_atype1290_12,
g_atype1290_13,
g_atype1290_14,
g_atype1290_15,
g_atype1290_16,
g_atype1290_17,
g_atype1290_18,
g_atype1290_19,
g_atype1290_20,
g_atype1290_21,
g_atype1290_22,
g_atype1290_23,
g_atype1290_24,
g_atype1290_25,
g_atype1290_26,
g_atype1290_27,
g_atype1290_28,
g_atype1290_29,
g_atype1290_30,
g_atype1290_31,
g_atype1290_32,
g_atype1290_33,
g_atype1290_34,
g_atype1290_35,
g_atype1290_36,
g_atype1290_37,
g_atype1290_38,
g_atype1290_39,
g_atype1290_40,
g_atype1290_41,
g_atype1290_42,
g_atype1290_43,
g_atype1290_44,
g_atype1290_45,
g_atype1290_46,
g_atype1290_47,
g_atype1290_48,
g_atype1290_49,
g_atype1290_50,
g_atype1290_51,
};

static const long offsets1290 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @CHROFF(11,1),
+ @CHROFF(11,2),
+ @CHROFF(11,3),
+ @CHROFF(11,4),
+ @CHROFF(11,5),
+ @CHROFF(11,6),
+ @CHROFF(11,7),
+ @CHROFF(11,8),
+ @CHROFF(11,9),
+ @CHROFF(11,10),
+ @CHROFF(11,11),
+ @CHROFF(11,12),
+ @CHROFF(11,13),
+ @CHROFF(11,14),
+ @CHROFF(11,15),
+ @LNGOFF(11,16,0,0),
+ @LNGOFF(11,16,0,1),
+ @LNGOFF(11,16,0,2),
+ @LNGOFF(11,16,0,3),
+ @LNGOFF(11,16,0,4),
+ @LNGOFF(11,16,0,5),
+ @LNGOFF(11,16,0,6),
+ @LNGOFF(11,16,0,7),
+ @LNGOFF(11,16,0,8),
+ @LNGOFF(11,16,0,9),
+ @LNGOFF(11,16,0,10),
+ @LNGOFF(11,16,0,11),
+ @LNGOFF(11,16,0,12),
+ @LNGOFF(11,16,0,13),
+ @LNGOFF(11,16,0,14),
+ @LNGOFF(11,16,0,15),
+ @LNGOFF(11,16,0,16),
+ @LNGOFF(11,16,0,17),
+ @LNGOFF(11,16,0,18),
+ @LNGOFF(11,16,0,19),
+ @LNGOFF(11,16,0,20),
+ @LNGOFF(11,16,0,21),
+ @LNGOFF(11,16,0,22),
+ @LNGOFF(11,16,0,23),
+ @LNGOFF(11,16,0,24),
};

extern const char *names1291[];
static const uint32 types1291 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1291 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1291_0 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_1 [] = {34,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_2 [] = {32,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_3 [] = {31,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_4 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_5 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_6 [] = {31,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_7 [] = {31,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_8 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_9 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_10 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_11 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_12 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_13 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_14 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_15 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_16 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_17 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_18 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_19 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_20 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_21 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_22 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_23 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_24 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_25 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_26 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_27 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_28 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_29 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_30 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_31 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_32 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_33 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_34 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_35 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_36 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_37 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_38 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_39 [] = {1199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_40 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_41 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_42 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_43 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_44 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_45 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_46 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_47 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_48 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_49 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_50 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_51 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1291 [] = {
g_atype1291_0,
g_atype1291_1,
g_atype1291_2,
g_atype1291_3,
g_atype1291_4,
g_atype1291_5,
g_atype1291_6,
g_atype1291_7,
g_atype1291_8,
g_atype1291_9,
g_atype1291_10,
g_atype1291_11,
g_atype1291_12,
g_atype1291_13,
g_atype1291_14,
g_atype1291_15,
g_atype1291_16,
g_atype1291_17,
g_atype1291_18,
g_atype1291_19,
g_atype1291_20,
g_atype1291_21,
g_atype1291_22,
g_atype1291_23,
g_atype1291_24,
g_atype1291_25,
g_atype1291_26,
g_atype1291_27,
g_atype1291_28,
g_atype1291_29,
g_atype1291_30,
g_atype1291_31,
g_atype1291_32,
g_atype1291_33,
g_atype1291_34,
g_atype1291_35,
g_atype1291_36,
g_atype1291_37,
g_atype1291_38,
g_atype1291_39,
g_atype1291_40,
g_atype1291_41,
g_atype1291_42,
g_atype1291_43,
g_atype1291_44,
g_atype1291_45,
g_atype1291_46,
g_atype1291_47,
g_atype1291_48,
g_atype1291_49,
g_atype1291_50,
g_atype1291_51,
};

static const long offsets1291 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @CHROFF(11,1),
+ @CHROFF(11,2),
+ @CHROFF(11,3),
+ @CHROFF(11,4),
+ @CHROFF(11,5),
+ @CHROFF(11,6),
+ @CHROFF(11,7),
+ @CHROFF(11,8),
+ @CHROFF(11,9),
+ @CHROFF(11,10),
+ @CHROFF(11,11),
+ @CHROFF(11,12),
+ @CHROFF(11,13),
+ @CHROFF(11,14),
+ @CHROFF(11,15),
+ @LNGOFF(11,16,0,0),
+ @LNGOFF(11,16,0,1),
+ @LNGOFF(11,16,0,2),
+ @LNGOFF(11,16,0,3),
+ @LNGOFF(11,16,0,4),
+ @LNGOFF(11,16,0,5),
+ @LNGOFF(11,16,0,6),
+ @LNGOFF(11,16,0,7),
+ @LNGOFF(11,16,0,8),
+ @LNGOFF(11,16,0,9),
+ @LNGOFF(11,16,0,10),
+ @LNGOFF(11,16,0,11),
+ @LNGOFF(11,16,0,12),
+ @LNGOFF(11,16,0,13),
+ @LNGOFF(11,16,0,14),
+ @LNGOFF(11,16,0,15),
+ @LNGOFF(11,16,0,16),
+ @LNGOFF(11,16,0,17),
+ @LNGOFF(11,16,0,18),
+ @LNGOFF(11,16,0,19),
+ @LNGOFF(11,16,0,20),
+ @LNGOFF(11,16,0,21),
+ @LNGOFF(11,16,0,22),
+ @LNGOFF(11,16,0,23),
+ @LNGOFF(11,16,0,24),
};

extern const char *names1292[];
static const uint32 types1292 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1292 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1292_0 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_1 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1292 [] = {
g_atype1292_0,
g_atype1292_1,
};

static const long offsets1292 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names1293[];
static const uint32 types1293 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1293 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1293_0 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_1 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1293 [] = {
g_atype1293_0,
g_atype1293_1,
};

static const long offsets1293 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names1294[];
static const uint32 types1294 [] =
{
SK_INT32,
};

static const uint16 attr_flags1294 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1294_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1294 [] = {
g_atype1294_0,
};

static const long offsets1294 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1295[];
static const uint32 types1295 [] =
{
SK_INT32,
};

static const uint16 attr_flags1295 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1295_0 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1295 [] = {
g_atype1295_0,
};

static const long offsets1295 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1296[];
static const uint32 types1296 [] =
{
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1296 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1296_0 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1296_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1296_2 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1296 [] = {
g_atype1296_0,
g_atype1296_1,
g_atype1296_2,
};

static const long offsets1296 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @R64OFF(0,0,0,2,0,0,0,0),
};

extern const char *names1297[];
static const uint32 types1297 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags1297 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1297_0 [] = {1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_1 [] = {1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_2 [] = {796,1059,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_3 [] = {822,1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_4 [] = {822,1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_5 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_7 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_8 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_9 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_10 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_11 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_14 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_15 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1297 [] = {
g_atype1297_0,
g_atype1297_1,
g_atype1297_2,
g_atype1297_3,
g_atype1297_4,
g_atype1297_5,
g_atype1297_6,
g_atype1297_7,
g_atype1297_8,
g_atype1297_9,
g_atype1297_10,
g_atype1297_11,
g_atype1297_12,
g_atype1297_13,
g_atype1297_14,
g_atype1297_15,
};

static const long offsets1297 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
+ @LNGOFF(5,1,0,3),
+ @LNGOFF(5,1,0,4),
+ @LNGOFF(5,1,0,5),
+ @LNGOFF(5,1,0,6),
+ @LNGOFF(5,1,0,7),
+ @R64OFF(5,1,0,8,0,0,0,0),
+ @R64OFF(5,1,0,8,0,0,0,1),
};

extern const char *names1298[];
static const uint32 types1298 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1298 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1298_0 [] = {1292,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_1 [] = {1294,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_4 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1298 [] = {
g_atype1298_0,
g_atype1298_1,
g_atype1298_2,
g_atype1298_3,
g_atype1298_4,
};

static const long offsets1298 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names1299[];
static const uint32 types1299 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1299 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1299_0 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_1 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_2 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_3 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_4 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_5 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_8 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1299 [] = {
g_atype1299_0,
g_atype1299_1,
g_atype1299_2,
g_atype1299_3,
g_atype1299_4,
g_atype1299_5,
g_atype1299_6,
g_atype1299_7,
g_atype1299_8,
};

static const long offsets1299 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
};

extern const char *names1300[];
static const uint32 types1300 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1300 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1300_0 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_1 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_2 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_3 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_4 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_5 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_6 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_8 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1300 [] = {
g_atype1300_0,
g_atype1300_1,
g_atype1300_2,
g_atype1300_3,
g_atype1300_4,
g_atype1300_5,
g_atype1300_6,
g_atype1300_7,
g_atype1300_8,
};

static const long offsets1300 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
};

extern const char *names1301[];
static const uint32 types1301 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1301 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1301_0 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_1 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_2 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_3 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_4 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_5 [] = {1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_6 [] = {1072,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_7 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_8 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_9 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_10 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1301 [] = {
g_atype1301_0,
g_atype1301_1,
g_atype1301_2,
g_atype1301_3,
g_atype1301_4,
g_atype1301_5,
g_atype1301_6,
g_atype1301_7,
g_atype1301_8,
g_atype1301_9,
g_atype1301_10,
};

static const long offsets1301 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
};

extern const char *names1303[];
static const uint32 types1303 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1303 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1303_0 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1303 [] = {
g_atype1303_0,
g_atype1303_1,
g_atype1303_2,
};

static const long offsets1303 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
};

extern const char *names1304[];
static const uint32 types1304 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1304 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1304_0 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_2 [] = {1007,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1304 [] = {
g_atype1304_0,
g_atype1304_1,
g_atype1304_2,
};

static const long offsets1304 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
};

extern const char *names1306[];
static const uint32 types1306 [] =
{
SK_REF,
};

static const uint16 attr_flags1306 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1306_0 [] = {0,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1306 [] = {
g_atype1306_0,
};

static const long offsets1306 [] =
{
0,
};

extern const char *names1307[];
static const uint32 types1307 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1307 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1307_0 [] = {260,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_1 [] = {116,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_2 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_3 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_4 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_5 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_6 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_7 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_8 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_9 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_10 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_11 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_12 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_13 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_15 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_16 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_17 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_18 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_19 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_20 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_21 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_22 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_23 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_24 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_25 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_26 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_27 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_28 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_29 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_30 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_31 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_32 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_33 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_34 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_35 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_36 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_37 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_38 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_39 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_40 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_41 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_42 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1307 [] = {
g_atype1307_0,
g_atype1307_1,
g_atype1307_2,
g_atype1307_3,
g_atype1307_4,
g_atype1307_5,
g_atype1307_6,
g_atype1307_7,
g_atype1307_8,
g_atype1307_9,
g_atype1307_10,
g_atype1307_11,
g_atype1307_12,
g_atype1307_13,
g_atype1307_14,
g_atype1307_15,
g_atype1307_16,
g_atype1307_17,
g_atype1307_18,
g_atype1307_19,
g_atype1307_20,
g_atype1307_21,
g_atype1307_22,
g_atype1307_23,
g_atype1307_24,
g_atype1307_25,
g_atype1307_26,
g_atype1307_27,
g_atype1307_28,
g_atype1307_29,
g_atype1307_30,
g_atype1307_31,
g_atype1307_32,
g_atype1307_33,
g_atype1307_34,
g_atype1307_35,
g_atype1307_36,
g_atype1307_37,
g_atype1307_38,
g_atype1307_39,
g_atype1307_40,
g_atype1307_41,
g_atype1307_42,
};

static const long offsets1307 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
+ @CHROFF(19,0),
+ @CHROFF(19,1),
+ @CHROFF(19,2),
+ @LNGOFF(19,3,0,0),
+ @LNGOFF(19,3,0,1),
+ @LNGOFF(19,3,0,2),
+ @LNGOFF(19,3,0,3),
+ @LNGOFF(19,3,0,4),
+ @LNGOFF(19,3,0,5),
+ @LNGOFF(19,3,0,6),
+ @LNGOFF(19,3,0,7),
+ @LNGOFF(19,3,0,8),
+ @LNGOFF(19,3,0,9),
+ @LNGOFF(19,3,0,10),
+ @LNGOFF(19,3,0,11),
+ @LNGOFF(19,3,0,12),
+ @LNGOFF(19,3,0,13),
+ @LNGOFF(19,3,0,14),
+ @LNGOFF(19,3,0,15),
+ @LNGOFF(19,3,0,16),
+ @LNGOFF(19,3,0,17),
+ @LNGOFF(19,3,0,18),
+ @LNGOFF(19,3,0,19),
+ @LNGOFF(19,3,0,20),
};

extern const char *names1308[];
static const uint32 types1308 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1308 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1308_0 [] = {260,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_1 [] = {116,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_2 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_3 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_4 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_5 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_6 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_7 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_8 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_9 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_10 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_11 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_12 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_13 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_15 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_16 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_17 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_18 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_19 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_20 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_21 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_22 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_23 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_24 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_25 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_26 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_27 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_28 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_29 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_30 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_31 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_32 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_33 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_34 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_35 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_36 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_37 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_38 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_39 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_40 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_41 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_42 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1308 [] = {
g_atype1308_0,
g_atype1308_1,
g_atype1308_2,
g_atype1308_3,
g_atype1308_4,
g_atype1308_5,
g_atype1308_6,
g_atype1308_7,
g_atype1308_8,
g_atype1308_9,
g_atype1308_10,
g_atype1308_11,
g_atype1308_12,
g_atype1308_13,
g_atype1308_14,
g_atype1308_15,
g_atype1308_16,
g_atype1308_17,
g_atype1308_18,
g_atype1308_19,
g_atype1308_20,
g_atype1308_21,
g_atype1308_22,
g_atype1308_23,
g_atype1308_24,
g_atype1308_25,
g_atype1308_26,
g_atype1308_27,
g_atype1308_28,
g_atype1308_29,
g_atype1308_30,
g_atype1308_31,
g_atype1308_32,
g_atype1308_33,
g_atype1308_34,
g_atype1308_35,
g_atype1308_36,
g_atype1308_37,
g_atype1308_38,
g_atype1308_39,
g_atype1308_40,
g_atype1308_41,
g_atype1308_42,
};

static const long offsets1308 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
+ @CHROFF(19,0),
+ @CHROFF(19,1),
+ @CHROFF(19,2),
+ @LNGOFF(19,3,0,0),
+ @LNGOFF(19,3,0,1),
+ @LNGOFF(19,3,0,2),
+ @LNGOFF(19,3,0,3),
+ @LNGOFF(19,3,0,4),
+ @LNGOFF(19,3,0,5),
+ @LNGOFF(19,3,0,6),
+ @LNGOFF(19,3,0,7),
+ @LNGOFF(19,3,0,8),
+ @LNGOFF(19,3,0,9),
+ @LNGOFF(19,3,0,10),
+ @LNGOFF(19,3,0,11),
+ @LNGOFF(19,3,0,12),
+ @LNGOFF(19,3,0,13),
+ @LNGOFF(19,3,0,14),
+ @LNGOFF(19,3,0,15),
+ @LNGOFF(19,3,0,16),
+ @LNGOFF(19,3,0,17),
+ @LNGOFF(19,3,0,18),
+ @LNGOFF(19,3,0,19),
+ @LNGOFF(19,3,0,20),
};

extern const char *names1309[];
static const uint32 types1309 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1309 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1309_0 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_1 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_2 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_3 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_4 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_5 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_6 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_7 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_8 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_9 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_10 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_11 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_12 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_13 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_14 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_15 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_16 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_17 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_18 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_19 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_20 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_21 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_22 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1309 [] = {
g_atype1309_0,
g_atype1309_1,
g_atype1309_2,
g_atype1309_3,
g_atype1309_4,
g_atype1309_5,
g_atype1309_6,
g_atype1309_7,
g_atype1309_8,
g_atype1309_9,
g_atype1309_10,
g_atype1309_11,
g_atype1309_12,
g_atype1309_13,
g_atype1309_14,
g_atype1309_15,
g_atype1309_16,
g_atype1309_17,
g_atype1309_18,
g_atype1309_19,
g_atype1309_20,
g_atype1309_21,
g_atype1309_22,
};

static const long offsets1309 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @LNGOFF(11,1,0,0),
+ @LNGOFF(11,1,0,1),
+ @LNGOFF(11,1,0,2),
+ @LNGOFF(11,1,0,3),
+ @LNGOFF(11,1,0,4),
+ @LNGOFF(11,1,0,5),
+ @LNGOFF(11,1,0,6),
+ @LNGOFF(11,1,0,7),
+ @LNGOFF(11,1,0,8),
+ @LNGOFF(11,1,0,9),
+ @LNGOFF(11,1,0,10),
};

extern const char *names1310[];
static const uint32 types1310 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1310 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1310_0 [] = {967,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_1 [] = {260,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_2 [] = {116,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_3 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_4 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_5 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_6 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_7 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_8 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_9 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_10 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_11 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_12 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_13 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_14 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_15 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_16 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_17 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_18 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_19 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_20 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_21 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_22 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_23 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_24 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_25 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_26 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_27 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_28 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_29 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_30 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_31 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_32 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_33 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_34 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_35 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_36 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_37 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_38 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_39 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_40 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_41 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_42 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_43 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_44 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_45 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_46 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_47 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_48 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_49 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_50 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_51 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_52 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_53 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_54 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_55 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_56 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_57 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_58 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_59 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_60 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_61 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_62 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_63 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_64 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_65 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_66 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_67 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1310 [] = {
g_atype1310_0,
g_atype1310_1,
g_atype1310_2,
g_atype1310_3,
g_atype1310_4,
g_atype1310_5,
g_atype1310_6,
g_atype1310_7,
g_atype1310_8,
g_atype1310_9,
g_atype1310_10,
g_atype1310_11,
g_atype1310_12,
g_atype1310_13,
g_atype1310_14,
g_atype1310_15,
g_atype1310_16,
g_atype1310_17,
g_atype1310_18,
g_atype1310_19,
g_atype1310_20,
g_atype1310_21,
g_atype1310_22,
g_atype1310_23,
g_atype1310_24,
g_atype1310_25,
g_atype1310_26,
g_atype1310_27,
g_atype1310_28,
g_atype1310_29,
g_atype1310_30,
g_atype1310_31,
g_atype1310_32,
g_atype1310_33,
g_atype1310_34,
g_atype1310_35,
g_atype1310_36,
g_atype1310_37,
g_atype1310_38,
g_atype1310_39,
g_atype1310_40,
g_atype1310_41,
g_atype1310_42,
g_atype1310_43,
g_atype1310_44,
g_atype1310_45,
g_atype1310_46,
g_atype1310_47,
g_atype1310_48,
g_atype1310_49,
g_atype1310_50,
g_atype1310_51,
g_atype1310_52,
g_atype1310_53,
g_atype1310_54,
g_atype1310_55,
g_atype1310_56,
g_atype1310_57,
g_atype1310_58,
g_atype1310_59,
g_atype1310_60,
g_atype1310_61,
g_atype1310_62,
g_atype1310_63,
g_atype1310_64,
g_atype1310_65,
g_atype1310_66,
g_atype1310_67,
};

static const long offsets1310 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
+ @CHROFF(31,0),
+ @CHROFF(31,1),
+ @CHROFF(31,2),
+ @CHROFF(31,3),
+ @CHROFF(31,4),
+ @LNGOFF(31,5,0,0),
+ @LNGOFF(31,5,0,1),
+ @LNGOFF(31,5,0,2),
+ @LNGOFF(31,5,0,3),
+ @LNGOFF(31,5,0,4),
+ @LNGOFF(31,5,0,5),
+ @LNGOFF(31,5,0,6),
+ @LNGOFF(31,5,0,7),
+ @LNGOFF(31,5,0,8),
+ @LNGOFF(31,5,0,9),
+ @LNGOFF(31,5,0,10),
+ @LNGOFF(31,5,0,11),
+ @LNGOFF(31,5,0,12),
+ @LNGOFF(31,5,0,13),
+ @LNGOFF(31,5,0,14),
+ @LNGOFF(31,5,0,15),
+ @LNGOFF(31,5,0,16),
+ @LNGOFF(31,5,0,17),
+ @LNGOFF(31,5,0,18),
+ @LNGOFF(31,5,0,19),
+ @LNGOFF(31,5,0,20),
+ @LNGOFF(31,5,0,21),
+ @LNGOFF(31,5,0,22),
+ @LNGOFF(31,5,0,23),
+ @LNGOFF(31,5,0,24),
+ @LNGOFF(31,5,0,25),
+ @LNGOFF(31,5,0,26),
+ @LNGOFF(31,5,0,27),
+ @LNGOFF(31,5,0,28),
+ @LNGOFF(31,5,0,29),
+ @LNGOFF(31,5,0,30),
+ @LNGOFF(31,5,0,31),
};

extern const char *names1311[];
static const uint32 types1311 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1311 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1311_0 [] = {967,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_1 [] = {260,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_2 [] = {116,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_3 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_4 [] = {1115,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_5 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_6 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_7 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_8 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_9 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_10 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_11 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_12 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_13 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_14 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_15 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_16 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_17 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_18 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_19 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_20 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_21 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_22 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_23 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_24 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_25 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_26 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_27 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_28 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_29 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_30 [] = {1109,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_31 [] = {1108,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_32 [] = {49,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_33 [] = {1108,972,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_34 [] = {49,972,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_35 [] = {1108,976,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_36 [] = {49,976,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_37 [] = {1108,980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_38 [] = {49,980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_39 [] = {1108,981,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_40 [] = {49,981,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_41 [] = {1108,975,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_42 [] = {49,975,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_43 [] = {1108,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_44 [] = {49,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_45 [] = {1108,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_46 [] = {49,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_47 [] = {1108,1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_48 [] = {49,1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_49 [] = {1108,970,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_50 [] = {49,970,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_51 [] = {1108,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_52 [] = {49,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_53 [] = {1108,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_54 [] = {49,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_55 [] = {1108,974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_56 [] = {49,974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_57 [] = {1108,987,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_58 [] = {49,987,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_59 [] = {1108,973,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_60 [] = {49,973,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_61 [] = {1108,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_62 [] = {49,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_63 [] = {1108,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_64 [] = {49,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_65 [] = {1108,979,976,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_66 [] = {49,979,976,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_67 [] = {1108,979,981,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_68 [] = {49,979,981,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_69 [] = {1108,979,975,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_70 [] = {49,979,975,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_71 [] = {1108,979,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_72 [] = {49,979,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_73 [] = {1108,979,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_74 [] = {49,979,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_75 [] = {1108,979,1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_76 [] = {49,979,1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_77 [] = {1108,979,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_78 [] = {49,979,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_79 [] = {1108,979,970,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_80 [] = {49,979,970,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_81 [] = {1108,979,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_82 [] = {49,979,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_83 [] = {1108,979,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_84 [] = {49,979,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_85 [] = {1108,979,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_86 [] = {49,979,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_87 [] = {1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_88 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_89 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_90 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_91 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_92 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_93 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_94 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_95 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_96 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_97 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_98 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_99 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_100 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_101 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_102 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_103 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_104 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_105 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_106 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_107 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_108 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_109 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_110 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_111 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_112 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_113 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_114 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_115 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_116 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_117 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_118 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_119 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_120 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_121 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_122 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_123 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_124 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_125 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_126 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_127 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_128 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_129 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_130 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_131 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_132 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_133 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_134 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_135 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_136 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_137 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_138 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_139 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_140 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_141 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_142 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_143 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_144 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_145 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_146 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_147 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_148 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_149 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_150 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_151 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_152 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_153 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_154 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_155 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_156 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_157 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_158 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_159 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_160 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_161 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_162 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_163 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_164 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_165 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_166 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_167 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_168 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_169 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_170 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_171 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_172 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_173 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_174 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_175 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_176 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_177 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_178 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_179 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1311 [] = {
g_atype1311_0,
g_atype1311_1,
g_atype1311_2,
g_atype1311_3,
g_atype1311_4,
g_atype1311_5,
g_atype1311_6,
g_atype1311_7,
g_atype1311_8,
g_atype1311_9,
g_atype1311_10,
g_atype1311_11,
g_atype1311_12,
g_atype1311_13,
g_atype1311_14,
g_atype1311_15,
g_atype1311_16,
g_atype1311_17,
g_atype1311_18,
g_atype1311_19,
g_atype1311_20,
g_atype1311_21,
g_atype1311_22,
g_atype1311_23,
g_atype1311_24,
g_atype1311_25,
g_atype1311_26,
g_atype1311_27,
g_atype1311_28,
g_atype1311_29,
g_atype1311_30,
g_atype1311_31,
g_atype1311_32,
g_atype1311_33,
g_atype1311_34,
g_atype1311_35,
g_atype1311_36,
g_atype1311_37,
g_atype1311_38,
g_atype1311_39,
g_atype1311_40,
g_atype1311_41,
g_atype1311_42,
g_atype1311_43,
g_atype1311_44,
g_atype1311_45,
g_atype1311_46,
g_atype1311_47,
g_atype1311_48,
g_atype1311_49,
g_atype1311_50,
g_atype1311_51,
g_atype1311_52,
g_atype1311_53,
g_atype1311_54,
g_atype1311_55,
g_atype1311_56,
g_atype1311_57,
g_atype1311_58,
g_atype1311_59,
g_atype1311_60,
g_atype1311_61,
g_atype1311_62,
g_atype1311_63,
g_atype1311_64,
g_atype1311_65,
g_atype1311_66,
g_atype1311_67,
g_atype1311_68,
g_atype1311_69,
g_atype1311_70,
g_atype1311_71,
g_atype1311_72,
g_atype1311_73,
g_atype1311_74,
g_atype1311_75,
g_atype1311_76,
g_atype1311_77,
g_atype1311_78,
g_atype1311_79,
g_atype1311_80,
g_atype1311_81,
g_atype1311_82,
g_atype1311_83,
g_atype1311_84,
g_atype1311_85,
g_atype1311_86,
g_atype1311_87,
g_atype1311_88,
g_atype1311_89,
g_atype1311_90,
g_atype1311_91,
g_atype1311_92,
g_atype1311_93,
g_atype1311_94,
g_atype1311_95,
g_atype1311_96,
g_atype1311_97,
g_atype1311_98,
g_atype1311_99,
g_atype1311_100,
g_atype1311_101,
g_atype1311_102,
g_atype1311_103,
g_atype1311_104,
g_atype1311_105,
g_atype1311_106,
g_atype1311_107,
g_atype1311_108,
g_atype1311_109,
g_atype1311_110,
g_atype1311_111,
g_atype1311_112,
g_atype1311_113,
g_atype1311_114,
g_atype1311_115,
g_atype1311_116,
g_atype1311_117,
g_atype1311_118,
g_atype1311_119,
g_atype1311_120,
g_atype1311_121,
g_atype1311_122,
g_atype1311_123,
g_atype1311_124,
g_atype1311_125,
g_atype1311_126,
g_atype1311_127,
g_atype1311_128,
g_atype1311_129,
g_atype1311_130,
g_atype1311_131,
g_atype1311_132,
g_atype1311_133,
g_atype1311_134,
g_atype1311_135,
g_atype1311_136,
g_atype1311_137,
g_atype1311_138,
g_atype1311_139,
g_atype1311_140,
g_atype1311_141,
g_atype1311_142,
g_atype1311_143,
g_atype1311_144,
g_atype1311_145,
g_atype1311_146,
g_atype1311_147,
g_atype1311_148,
g_atype1311_149,
g_atype1311_150,
g_atype1311_151,
g_atype1311_152,
g_atype1311_153,
g_atype1311_154,
g_atype1311_155,
g_atype1311_156,
g_atype1311_157,
g_atype1311_158,
g_atype1311_159,
g_atype1311_160,
g_atype1311_161,
g_atype1311_162,
g_atype1311_163,
g_atype1311_164,
g_atype1311_165,
g_atype1311_166,
g_atype1311_167,
g_atype1311_168,
g_atype1311_169,
g_atype1311_170,
g_atype1311_171,
g_atype1311_172,
g_atype1311_173,
g_atype1311_174,
g_atype1311_175,
g_atype1311_176,
g_atype1311_177,
g_atype1311_178,
g_atype1311_179,
};

static const long offsets1311 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
 + @REFACS(41),
 + @REFACS(42),
 + @REFACS(43),
 + @REFACS(44),
 + @REFACS(45),
 + @REFACS(46),
 + @REFACS(47),
 + @REFACS(48),
 + @REFACS(49),
 + @REFACS(50),
 + @REFACS(51),
 + @REFACS(52),
 + @REFACS(53),
 + @REFACS(54),
 + @REFACS(55),
 + @REFACS(56),
 + @REFACS(57),
 + @REFACS(58),
 + @REFACS(59),
 + @REFACS(60),
 + @REFACS(61),
 + @REFACS(62),
 + @REFACS(63),
 + @REFACS(64),
 + @REFACS(65),
 + @REFACS(66),
 + @REFACS(67),
 + @REFACS(68),
 + @REFACS(69),
 + @REFACS(70),
 + @REFACS(71),
 + @REFACS(72),
 + @REFACS(73),
 + @REFACS(74),
 + @REFACS(75),
 + @REFACS(76),
 + @REFACS(77),
 + @REFACS(78),
 + @REFACS(79),
 + @REFACS(80),
 + @REFACS(81),
 + @REFACS(82),
 + @REFACS(83),
 + @REFACS(84),
 + @REFACS(85),
 + @REFACS(86),
+ @CHROFF(87,0),
+ @CHROFF(87,1),
+ @CHROFF(87,2),
+ @CHROFF(87,3),
+ @CHROFF(87,4),
+ @LNGOFF(87,5,0,0),
+ @LNGOFF(87,5,0,1),
+ @LNGOFF(87,5,0,2),
+ @LNGOFF(87,5,0,3),
+ @LNGOFF(87,5,0,4),
+ @LNGOFF(87,5,0,5),
+ @LNGOFF(87,5,0,6),
+ @LNGOFF(87,5,0,7),
+ @LNGOFF(87,5,0,8),
+ @LNGOFF(87,5,0,9),
+ @LNGOFF(87,5,0,10),
+ @LNGOFF(87,5,0,11),
+ @LNGOFF(87,5,0,12),
+ @LNGOFF(87,5,0,13),
+ @LNGOFF(87,5,0,14),
+ @LNGOFF(87,5,0,15),
+ @LNGOFF(87,5,0,16),
+ @LNGOFF(87,5,0,17),
+ @LNGOFF(87,5,0,18),
+ @LNGOFF(87,5,0,19),
+ @LNGOFF(87,5,0,20),
+ @LNGOFF(87,5,0,21),
+ @LNGOFF(87,5,0,22),
+ @LNGOFF(87,5,0,23),
+ @LNGOFF(87,5,0,24),
+ @LNGOFF(87,5,0,25),
+ @LNGOFF(87,5,0,26),
+ @LNGOFF(87,5,0,27),
+ @LNGOFF(87,5,0,28),
+ @LNGOFF(87,5,0,29),
+ @LNGOFF(87,5,0,30),
+ @LNGOFF(87,5,0,31),
+ @LNGOFF(87,5,0,32),
+ @LNGOFF(87,5,0,33),
+ @LNGOFF(87,5,0,34),
+ @LNGOFF(87,5,0,35),
+ @LNGOFF(87,5,0,36),
+ @LNGOFF(87,5,0,37),
+ @LNGOFF(87,5,0,38),
+ @LNGOFF(87,5,0,39),
+ @LNGOFF(87,5,0,40),
+ @LNGOFF(87,5,0,41),
+ @LNGOFF(87,5,0,42),
+ @LNGOFF(87,5,0,43),
+ @LNGOFF(87,5,0,44),
+ @LNGOFF(87,5,0,45),
+ @LNGOFF(87,5,0,46),
+ @LNGOFF(87,5,0,47),
+ @LNGOFF(87,5,0,48),
+ @LNGOFF(87,5,0,49),
+ @LNGOFF(87,5,0,50),
+ @LNGOFF(87,5,0,51),
+ @LNGOFF(87,5,0,52),
+ @LNGOFF(87,5,0,53),
+ @LNGOFF(87,5,0,54),
+ @LNGOFF(87,5,0,55),
+ @LNGOFF(87,5,0,56),
+ @LNGOFF(87,5,0,57),
+ @LNGOFF(87,5,0,58),
+ @LNGOFF(87,5,0,59),
+ @LNGOFF(87,5,0,60),
+ @LNGOFF(87,5,0,61),
+ @LNGOFF(87,5,0,62),
+ @LNGOFF(87,5,0,63),
+ @LNGOFF(87,5,0,64),
+ @LNGOFF(87,5,0,65),
+ @LNGOFF(87,5,0,66),
+ @LNGOFF(87,5,0,67),
+ @LNGOFF(87,5,0,68),
+ @LNGOFF(87,5,0,69),
+ @LNGOFF(87,5,0,70),
+ @LNGOFF(87,5,0,71),
+ @LNGOFF(87,5,0,72),
+ @LNGOFF(87,5,0,73),
+ @LNGOFF(87,5,0,74),
+ @LNGOFF(87,5,0,75),
+ @LNGOFF(87,5,0,76),
+ @LNGOFF(87,5,0,77),
+ @LNGOFF(87,5,0,78),
+ @LNGOFF(87,5,0,79),
+ @LNGOFF(87,5,0,80),
+ @LNGOFF(87,5,0,81),
+ @LNGOFF(87,5,0,82),
+ @LNGOFF(87,5,0,83),
+ @LNGOFF(87,5,0,84),
+ @LNGOFF(87,5,0,85),
+ @LNGOFF(87,5,0,86),
+ @LNGOFF(87,5,0,87),
};

extern const char *names1313[];
static const uint32 types1313 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1313 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1313_0 [] = {822,1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_1 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_2 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_3 [] = {1052,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_4 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_5 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1313 [] = {
g_atype1313_0,
g_atype1313_1,
g_atype1313_2,
g_atype1313_3,
g_atype1313_4,
g_atype1313_5,
};

static const long offsets1313 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
};

extern const char *names1314[];
static const uint32 types1314 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1314 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1314_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_7 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1314 [] = {
g_atype1314_0,
g_atype1314_1,
g_atype1314_2,
g_atype1314_3,
g_atype1314_4,
g_atype1314_5,
g_atype1314_6,
g_atype1314_7,
};

static const long offsets1314 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

extern const char *names1315[];
static const uint32 types1315 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1315 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1315_0 [] = {1112,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_1 [] = {1007,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_2 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_3 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_4 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_6 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_7 [] = {1187,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1315 [] = {
g_atype1315_0,
g_atype1315_1,
g_atype1315_2,
g_atype1315_3,
g_atype1315_4,
g_atype1315_5,
g_atype1315_6,
g_atype1315_7,
};

static const long offsets1315 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

const struct cnode egc_fsystem_init[] = {
{
	(long) 0,
	(long) 0,
	"ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF8_READER_WRITER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IRON_PACKAGE_INFO_FILE_PARSER",
	names3,
	types3,
	attr_flags3,
	gtypes3,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets3,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_VISITOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_REPOSITORY_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_PACKAGE_FILE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"IRON_PACKAGE_INSTALLATION_INFO",
	names8,
	types8,
	attr_flags8,
	gtypes8,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets8,
	NULL
},
{
	(long) 2,
	(long) 2,
	"I18N_FILE_SCOPE_INFORMATION",
	names9,
	types9,
	attr_flags9,
	gtypes9,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets9,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PUNYCODE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_STRING_VARIABLE_EXPANSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_STRING_VARIABLE_EXPANSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_CLIENT_DB",
	names13,
	types13,
	attr_flags13,
	gtypes13,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets13,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_PLURAL_TOOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_API_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_IRON_INSTALLATION_API_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_URI_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_LOCATION_MAPPER_ACTION",
	names19,
	types19,
	attr_flags19,
	gtypes19,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets19,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_URL_BUILDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_STRING_FORMATTER",
	names21,
	types21,
	attr_flags21,
	gtypes21,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets21,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_CURRENCY_FORMATTER",
	names22,
	types22,
	attr_flags22,
	gtypes22,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets22,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_DATE_FORMATTER",
	names23,
	types23,
	attr_flags23,
	gtypes23,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets23,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DESCRIPTOR_CACHE",
	names24,
	types24,
	attr_flags24,
	gtypes24,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets24,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENT_EXTERNALS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARGUMENT_GROUP",
	names26,
	types26,
	attr_flags26,
	gtypes26,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets26,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COMPILER_PROFILE",
	names27,
	types27,
	attr_flags27,
	gtypes27,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets27,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XML_NAMESPACE_RESOLVER_CONTEXT",
	names28,
	types28,
	attr_flags28,
	gtypes28,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets28,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_ERROR_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_ERROR_OBSERVER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ESCAPE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PCRE_CHARACTER_SET",
	names32,
	types32,
	attr_flags32,
	gtypes32,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets32,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CASE_MAPPING",
	names33,
	types33,
	attr_flags33,
	gtypes33,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets33,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ERROR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"PCRE_BYTE_CODE",
	names35,
	types35,
	attr_flags35,
	gtypes35,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets35,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_LOCATION_MAPPER",
	names37,
	types37,
	attr_flags37,
	gtypes37,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets37,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 0,
	"VERSIONABLE",
	names39,
	types39,
	attr_flags39,
	gtypes39,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets39,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_LOCALE",
	names40,
	types40,
	attr_flags40,
	gtypes40,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets40,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ARGUMENT_OPTION",
	names41,
	types41,
	attr_flags41,
	gtypes41,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets41,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PRODUCT_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FILE_UTILITIES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FILE_UTILITIES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"C_DATE",
	names45,
	types45,
	attr_flags45,
	gtypes45,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets45,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_LOAD_CONTEXT",
	names46,
	types46,
	attr_flags46,
	gtypes46,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets46,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ASCII",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BYTE_CODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BYTE_CODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_PARSER_CONTROLLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CHARACTER_PROPERTY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_PAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ENCODING",
	names59,
	types59,
	attr_flags59,
	gtypes59,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets59,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_CONDITION_CUSTOM_ATTRIBUTES",
	names60,
	types60,
	attr_flags60,
	gtypes60,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets60,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UUID_GENERATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_ROOT",
	names62,
	types62,
	attr_flags62,
	gtypes62,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets62,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ASSERTIONS",
	names63,
	types63,
	attr_flags63,
	gtypes63,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets63,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RT_DBG_EXECUTION_PARAMETERS",
	names65,
	types65,
	attr_flags65,
	gtypes65,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets65,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_RUNTIME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STD_FILES",
	names81,
	types81,
	attr_flags81,
	gtypes81,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets81,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IMPORTED_UTF8_READER_WRITER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DIRECTORY_VISITOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DIRECTORY_ITERATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IRON_FS_PACKAGE_INFO_DIRECTORY_ITERATOR",
	names86,
	types86,
	attr_flags86,
	gtypes86,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets86,
	NULL
},
{
	(long) 3,
	(long) 3,
	"IRON_ECF_SCANNER",
	names87,
	types87,
	attr_flags87,
	gtypes87,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets87,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_TOKENS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"JSON_READER",
	names89,
	types89,
	attr_flags89,
	gtypes89,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets89,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_LANGUAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_TOOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"GROUP_ELEMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_I18N_FORMATTING_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"MESSAGE_DIGEST",
	names97,
	types97,
	attr_flags97,
	gtypes97,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets97,
	NULL
},
{
	(long) 14,
	(long) 14,
	"SHA1",
	names98,
	types98,
	attr_flags98,
	gtypes98,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets98,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_FILE_HANDLER",
	names99,
	types99,
	attr_flags99,
	gtypes99,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets99,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_MO_HANDLER",
	names100,
	types100,
	attr_flags100,
	gtypes100,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets100,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"URI_PERCENT_ENCODER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names107,
	types107,
	attr_flags107,
	gtypes107,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets107,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names108,
	types108,
	attr_flags108,
	gtypes108,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets108,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names109,
	types109,
	attr_flags109,
	gtypes109,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets109,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names110,
	types110,
	attr_flags110,
	gtypes110,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets110,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_CHARACTERS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BASIC_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_LOCALE_CONV",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_UNIX_C_FUNCTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_POSIX_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_CODE_PAGE_INFO",
	names123,
	types123,
	attr_flags123,
	gtypes123,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets123,
	NULL
},
{
	(long) 13,
	(long) 13,
	"I18N_DATE_TIME_INFO",
	names124,
	types124,
	attr_flags124,
	gtypes124,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets124,
	NULL
},
{
	(long) 16,
	(long) 16,
	"I18N_CURRENCY_INFO",
	names125,
	types125,
	attr_flags125,
	gtypes125,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets125,
	NULL
},
{
	(long) 7,
	(long) 7,
	"I18N_NUMERIC_INFO",
	names126,
	types126,
	attr_flags126,
	gtypes126,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets126,
	NULL
},
{
	(long) 40,
	(long) 40,
	"I18N_LOCALE_INFO",
	names127,
	types127,
	attr_flags127,
	gtypes127,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets127,
	NULL
},
{
	(long) 4,
	(long) 4,
	"MATCHER",
	names128,
	types128,
	attr_flags128,
	gtypes128,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets128,
	NULL
},
{
	(long) 7,
	(long) 7,
	"KMP_MATCHER",
	names129,
	types129,
	attr_flags129,
	gtypes129,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets129,
	NULL
},
{
	(long) 13,
	(long) 13,
	"KMP_WILD",
	names130,
	types130,
	attr_flags130,
	gtypes130,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets130,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STREAMS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_LOCATION_MAPPING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_LOCATION_IRON_MAPPING",
	names135,
	types135,
	attr_flags135,
	gtypes135,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets135,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_TRAVERSABLE",
	names136,
	types136,
	attr_flags136,
	gtypes136,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets136,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE",
	names137,
	types137,
	attr_flags137,
	gtypes137,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets137,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BOM_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_I18N_URI_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_DATASOURCE_MANAGER",
	names140,
	types140,
	attr_flags140,
	gtypes140,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets140,
	NULL
},
{
	(long) 7,
	(long) 7,
	"I18N_FILE_MANAGER",
	names141,
	types141,
	attr_flags141,
	gtypes141,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets141,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_HOST_LOCALE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_VALUE_FORMATTER",
	names143,
	types143,
	attr_flags143,
	gtypes143,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets143,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_CURRENCY_VALUE_FORMATTER",
	names144,
	types144,
	attr_flags144,
	gtypes144,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets144,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARGUMENT_VALUE_VALIDATOR",
	names146,
	types146,
	attr_flags146,
	gtypes146,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets146,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARGUMENT_DEFAULT_VALIDATOR",
	names147,
	types147,
	attr_flags147,
	gtypes147,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets147,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENT_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENT_TERMINAL_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_EXPANDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_VALUE",
	names151,
	types151,
	attr_flags151,
	gtypes151,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets151,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_CHARACTER_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPTION_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LACE_AST_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LACE_PARSER_ROUTINES",
	names155,
	types155,
	attr_flags155,
	gtypes155,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets155,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_CLASSNAME_FINDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OBJECT_GRAPH_MARKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MATH_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DOUBLE_MATH",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SORTER",
	names161,
	types161,
	attr_flags161,
	gtypes161,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets161,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUICK_SORTER",
	names162,
	types162,
	attr_flags162,
	gtypes162,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets162,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_COMPILER_PROFILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_XMLNS_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_MARKUP_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_EXECUTION_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEP_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names172,
	types172,
	attr_flags172,
	gtypes172,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets172,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names173,
	types173,
	attr_flags173,
	gtypes173,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets173,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names174,
	types174,
	attr_flags174,
	gtypes174,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets174,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names175,
	types175,
	attr_flags175,
	gtypes175,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets175,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names176,
	types176,
	attr_flags176,
	gtypes176,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets176,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names177,
	types177,
	attr_flags177,
	gtypes177,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets177,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names178,
	types178,
	attr_flags178,
	gtypes178,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets178,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPERATING_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IL_ENVIRONMENT",
	names180,
	types180,
	attr_flags180,
	gtypes180,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets180,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EIFFEL_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_VALIDITY_CHECKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_EXPORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IRON_REPOSITORY_CONFIGURATION_FILE",
	names184,
	types184,
	attr_flags184,
	gtypes184,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets184,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_TO_IRON_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IRON_PACKAGE_FILE",
	names186,
	types186,
	attr_flags186,
	gtypes186,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets186,
	NULL
},
{
	(long) 6,
	(long) 6,
	"IRON_PACKAGE_INI_FILE",
	names187,
	types187,
	attr_flags187,
	gtypes187,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets187,
	NULL
},
{
	(long) 7,
	(long) 7,
	"IRON_PACKAGE_INFO_FILE",
	names188,
	types188,
	attr_flags188,
	gtypes188,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets188,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM_ENTRY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME_VALUE",
	names194,
	types194,
	attr_flags194,
	gtypes194,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets194,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DATE_TIME_VALUE",
	names197,
	types197,
	attr_flags197,
	gtypes197,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets197,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_DICTIONARY_ID_BUILDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_I18N_PLURAL_TOOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"I18N_FILE",
	names205,
	types205,
	attr_flags205,
	gtypes205,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets205,
	NULL
},
{
	(long) 15,
	(long) 15,
	"I18N_MO_FILE",
	names206,
	types206,
	attr_flags206,
	gtypes206,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets206,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_DICTIONARY",
	names207,
	types207,
	attr_flags207,
	gtypes207,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets207,
	NULL
},
{
	(long) 5,
	(long) 5,
	"I18N_BINARY_SEARCH_ARRAY_DICTIONARY",
	names208,
	types208,
	attr_flags208,
	gtypes208,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets208,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_DUMMY_DICTIONARY",
	names209,
	types209,
	attr_flags209,
	gtypes209,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets209,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SUBSET_STRATEGY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SUBSET_STRATEGY_HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SUBSET_STRATEGY_GENERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENCODING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_IMP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REVERSE_PART_COMPARATOR",
	names218,
	types218,
	attr_flags218,
	gtypes218,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets218,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_FILE_DATE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ARGUMENT_BASE_PARSER",
	names220,
	types220,
	attr_flags220,
	gtypes220,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets220,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ARGUMENT_MULTI_PARSER",
	names221,
	types221,
	attr_flags221,
	gtypes221,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets221,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ARGUMENT_SINGLE_PARSER",
	names222,
	types222,
	attr_flags222,
	gtypes222,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets222,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ARGUMENT_PARSER",
	names223,
	types223,
	attr_flags223,
	gtypes223,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets223,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYNTAX_STRINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CLASS_TYPE_NAME_SYNTAX_CHECKER",
	names225,
	types225,
	attr_flags225,
	gtypes225,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets225,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EIFFEL_SYNTAX_CHECKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"PATTERN_MATCHER",
	names227,
	types227,
	attr_flags227,
	gtypes227,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets227,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REGULAR_EXPRESSION_STRING_FACILITIES",
	names228,
	types228,
	attr_flags228,
	gtypes228,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets228,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_TARGET_REFERENCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_LOCAL_TARGET_REFERENCE",
	names230,
	types230,
	attr_flags230,
	gtypes230,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets230,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_REMOTE_TARGET_REFERENCE",
	names231,
	types231,
	attr_flags231,
	gtypes231,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets231,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STRING_EQUALITY_TESTER",
	names235,
	types235,
	attr_flags235,
	gtypes235,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets235,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STRING_COMPARATOR",
	names238,
	types238,
	attr_flags238,
	gtypes238,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets238,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_CONF_SETTING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_GENERAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_SEARCHER",
	names244,
	types244,
	attr_flags244,
	gtypes244,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets244,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_8_SEARCHER",
	names245,
	types245,
	attr_flags245,
	gtypes245,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets245,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_32_SEARCHER",
	names246,
	types246,
	attr_flags246,
	gtypes246,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets246,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC_INFORMATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INTEGER_OVERFLOW_CHECKER",
	names248,
	types248,
	attr_flags248,
	gtypes248,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets248,
	NULL
},
{
	(long) 7,
	(long) 7,
	"STRING_TO_NUMERIC_CONVERTOR",
	names249,
	types249,
	attr_flags249,
	gtypes249,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets249,
	NULL
},
{
	(long) 11,
	(long) 11,
	"HEXADECIMAL_STRING_TO_INTEGER_CONVERTER",
	names250,
	types250,
	attr_flags250,
	gtypes250,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets250,
	NULL
},
{
	(long) 15,
	(long) 15,
	"STRING_TO_REAL_CONVERTOR",
	names251,
	types251,
	attr_flags251,
	gtypes251,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets251,
	NULL
},
{
	(long) 10,
	(long) 10,
	"STRING_TO_INTEGER_CONVERTOR",
	names252,
	types252,
	attr_flags252,
	gtypes252,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets252,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_LOAD_PARSE_CALLBACKS_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFACTORING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XML_CALLBACKS",
	names259,
	types259,
	attr_flags259,
	gtypes259,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets259,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XML_CALLBACKS_NULL",
	names260,
	types260,
	attr_flags260,
	gtypes260,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets260,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_BUFFER",
	names261,
	types261,
	attr_flags261,
	gtypes261,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets261,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UTF8_BUFFER",
	names262,
	types262,
	attr_flags262,
	gtypes262,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets262,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UNICODE_BUFFER",
	names263,
	types263,
	attr_flags263,
	gtypes263,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets263,
	NULL
},
{
	(long) 12,
	(long) 12,
	"YY_FILE_BUFFER",
	names264,
	types264,
	attr_flags264,
	gtypes264,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets264,
	NULL
},
{
	(long) 14,
	(long) 14,
	"YY_UTF8_FILE_BUFFER",
	names265,
	types265,
	attr_flags265,
	gtypes265,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets265,
	NULL
},
{
	(long) 15,
	(long) 15,
	"YY_UNICODE_FILE_BUFFER",
	names266,
	types266,
	attr_flags266,
	gtypes266,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets266,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_CALLBACKS_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XML_FORWARD_CALLBACKS",
	names268,
	types268,
	attr_flags268,
	gtypes268,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets268,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 10,
	(long) 10,
	"XML_STANDARD_PARSER",
	names270,
	types270,
	attr_flags270,
	gtypes270,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets270,
	NULL
},
{
	(long) 15,
	(long) 15,
	"XML_STOPPABLE_PARSER",
	names271,
	types271,
	attr_flags271,
	gtypes271,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets271,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XML_CALLBACKS_FILTER",
	names272,
	types272,
	attr_flags272,
	gtypes272,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets272,
	NULL
},
{
	(long) 9,
	(long) 9,
	"XML_NAMESPACE_RESOLVER",
	names273,
	types273,
	attr_flags273,
	gtypes273,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets273,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XML_END_TAG_CHECKER",
	names274,
	types274,
	attr_flags274,
	gtypes274,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets274,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"XML_STRING_32_INPUT_STREAM",
	names276,
	types276,
	attr_flags276,
	gtypes276,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets276,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XML_CHARACTER_8_INPUT_STREAM_FILTER",
	names277,
	types277,
	attr_flags277,
	gtypes277,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets277,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XML_CHARACTER_8_INPUT_STREAM_UTF8_FILTER",
	names278,
	types278,
	attr_flags278,
	gtypes278,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets278,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_CHARACTER_8_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names282,
	types282,
	attr_flags282,
	gtypes282,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets282,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names283,
	types283,
	attr_flags283,
	gtypes283,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets283,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HASH_TABLE_CURSOR",
	names284,
	types284,
	attr_flags284,
	gtypes284,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets284,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ARRAYED_LIST_CURSOR",
	names285,
	types285,
	attr_flags285,
	gtypes285,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets285,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_NOTABLE",
	names287,
	types287,
	attr_flags287,
	gtypes287,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets287,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION",
	names290,
	types290,
	attr_flags290,
	gtypes290,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets290,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MACHINE_EXCEPTION",
	names291,
	types291,
	attr_flags291,
	gtypes291,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets291,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HARDWARE_EXCEPTION",
	names292,
	types292,
	attr_flags292,
	gtypes292,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets292,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FLOATING_POINT_FAILURE",
	names293,
	types293,
	attr_flags293,
	gtypes293,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets293,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OPERATING_SYSTEM_EXCEPTION",
	names294,
	types294,
	attr_flags294,
	gtypes294,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets294,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_FAILURE",
	names295,
	types295,
	attr_flags295,
	gtypes295,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets295,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_SIGNAL_FAILURE",
	names296,
	types296,
	attr_flags296,
	gtypes296,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets296,
	NULL
},
{
	(long) 10,
	(long) 10,
	"COM_FAILURE",
	names297,
	types297,
	attr_flags297,
	gtypes297,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets297,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DEVELOPER_EXCEPTION",
	names298,
	types298,
	attr_flags298,
	gtypes298,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets298,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONVERSION_FAILURE",
	names299,
	types299,
	attr_flags299,
	gtypes299,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets299,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_EXCEPTION",
	names300,
	types300,
	attr_flags300,
	gtypes300,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets300,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OBSOLETE_EXCEPTION",
	names301,
	types301,
	attr_flags301,
	gtypes301,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets301,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION_IN_SIGNAL_HANDLER_FAILURE",
	names302,
	types302,
	attr_flags302,
	gtypes302,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets302,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESUMPTION_FAILURE",
	names303,
	types303,
	attr_flags303,
	gtypes303,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets303,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESCUE_FAILURE",
	names304,
	types304,
	attr_flags304,
	gtypes304,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets304,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SYS_EXCEPTION",
	names305,
	types305,
	attr_flags305,
	gtypes305,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets305,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EIFFEL_RUNTIME_PANIC",
	names306,
	types306,
	attr_flags306,
	gtypes306,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets306,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OLD_VIOLATION",
	names307,
	types307,
	attr_flags307,
	gtypes307,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets307,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIF_EXCEPTION",
	names308,
	types308,
	attr_flags308,
	gtypes308,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets308,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFEL_RUNTIME_EXCEPTION",
	names309,
	types309,
	attr_flags309,
	gtypes309,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets309,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXTERNAL_FAILURE",
	names310,
	types310,
	attr_flags310,
	gtypes310,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets310,
	NULL
},
{
	(long) 8,
	(long) 8,
	"NO_MORE_MEMORY",
	names311,
	types311,
	attr_flags311,
	gtypes311,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets311,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATA_EXCEPTION",
	names312,
	types312,
	attr_flags312,
	gtypes312,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets312,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MISMATCH_FAILURE",
	names313,
	types313,
	attr_flags313,
	gtypes313,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets313,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IO_FAILURE",
	names314,
	types314,
	attr_flags314,
	gtypes314,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets314,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SERIALIZATION_FAILURE",
	names315,
	types315,
	attr_flags315,
	gtypes315,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets315,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LANGUAGE_EXCEPTION",
	names316,
	types316,
	attr_flags316,
	gtypes316,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets316,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_ASSIGNED_TO_EXPANDED",
	names317,
	types317,
	attr_flags317,
	gtypes317,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets317,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BAD_INSPECT_VALUE",
	names318,
	types318,
	attr_flags318,
	gtypes318,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets318,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ROUTINE_FAILURE",
	names319,
	types319,
	attr_flags319,
	gtypes319,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets319,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_TARGET",
	names320,
	types320,
	attr_flags320,
	gtypes320,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets320,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION",
	names321,
	types321,
	attr_flags321,
	gtypes321,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets321,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ADDRESS_APPLIED_TO_MELTED_FEATURE",
	names322,
	types322,
	attr_flags322,
	gtypes322,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets322,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CREATE_ON_DEFERRED",
	names323,
	types323,
	attr_flags323,
	gtypes323,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets323,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ASSERTION_VIOLATION",
	names324,
	types324,
	attr_flags324,
	gtypes324,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets324,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LOOP_INVARIANT_VIOLATION",
	names325,
	types325,
	attr_flags325,
	gtypes325,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets325,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VARIANT_VIOLATION",
	names326,
	types326,
	attr_flags326,
	gtypes326,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets326,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CHECK_VIOLATION",
	names327,
	types327,
	attr_flags327,
	gtypes327,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets327,
	NULL
},
{
	(long) 8,
	(long) 8,
	"INVARIANT_VIOLATION",
	names328,
	types328,
	attr_flags328,
	gtypes328,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets328,
	NULL
},
{
	(long) 7,
	(long) 7,
	"POSTCONDITION_VIOLATION",
	names329,
	types329,
	attr_flags329,
	gtypes329,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets329,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PRECONDITION_VIOLATION",
	names330,
	types330,
	attr_flags330,
	gtypes330,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets330,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_ELEMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_DATE_ELEMENT",
	names332,
	types332,
	attr_flags332,
	gtypes332,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets332,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_USERSTRING_ELEMENT",
	names333,
	types333,
	attr_flags333,
	gtypes333,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets333,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_TIME_ELEMENT",
	names334,
	types334,
	attr_flags334,
	gtypes334,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets334,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_FORMAT_STRING",
	names335,
	types335,
	attr_flags335,
	gtypes335,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets335,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DISPOSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 2,
	"MANAGED_POINTER",
	names337,
	types337,
	attr_flags337,
	gtypes337,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets337,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_INTERFACE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EIFFEL_LAYOUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_VISITABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INTERVAL",
	names343,
	types343,
	attr_flags343,
	gtypes343,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets343,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DURATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DATE_TIME_DURATION",
	names345,
	types345,
	attr_flags345,
	gtypes345,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets345,
	NULL
},
{
	(long) 3,
	(long) 3,
	"TIME_DURATION",
	names346,
	types346,
	attr_flags346,
	gtypes346,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets346,
	NULL
},
{
	(long) 4,
	(long) 4,
	"DATE_DURATION",
	names347,
	types347,
	attr_flags347,
	gtypes347,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets347,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_DICTIONARY_ENTRY",
	names349,
	types349,
	attr_flags349,
	gtypes349,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets349,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSOLUTE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REFLECTED_OBJECT",
	names354,
	types354,
	attr_flags354,
	gtypes354,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets354,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REFLECTED_COPY_SEMANTICS_OBJECT",
	names358,
	types358,
	attr_flags358,
	gtypes358,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets358,
	NULL
},
{
	(long) 3,
	(long) 3,
	"REFLECTED_REFERENCE_OBJECT",
	names359,
	types359,
	attr_flags359,
	gtypes359,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets359,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_FILE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_PARSE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_NAMESPACE_TESTER",
	names362,
	types362,
	attr_flags362,
	gtypes362,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets362,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_LOAD_CALLBACKS",
	names363,
	types363,
	attr_flags363,
	gtypes363,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets363,
	NULL
},
{
	(long) 12,
	(long) 12,
	"CONF_LOAD_UUID_CALLBACKS",
	names364,
	types364,
	attr_flags364,
	gtypes364,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets364,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_VALIDITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"CONF_STATE",
	names366,
	types366,
	attr_flags366,
	gtypes366,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets366,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_TARGET_SETTINGS",
	names367,
	types367,
	attr_flags367,
	gtypes367,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets367,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_CONDITIONED",
	names368,
	types368,
	attr_flags368,
	gtypes368,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets368,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ACTION",
	names369,
	types369,
	attr_flags369,
	gtypes369,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets369,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_FILE_RULE",
	names370,
	types370,
	attr_flags370,
	gtypes370,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets370,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL",
	names371,
	types371,
	attr_flags371,
	gtypes371,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets371,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_MAKE",
	names372,
	types372,
	attr_flags372,
	gtypes372,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets372,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_LINKER_FLAG",
	names373,
	types373,
	attr_flags373,
	gtypes373,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets373,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_RESOURCE",
	names374,
	types374,
	attr_flags374,
	gtypes374,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets374,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_LIBRARY",
	names375,
	types375,
	attr_flags375,
	gtypes375,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets375,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_OBJECT",
	names376,
	types376,
	attr_flags376,
	gtypes376,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets376,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_CFLAG",
	names377,
	types377,
	attr_flags377,
	gtypes377,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets377,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_INCLUDE",
	names378,
	types378,
	attr_flags378,
	gtypes378,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets378,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names379,
	types379,
	attr_flags379,
	gtypes379,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets379,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names380,
	types380,
	attr_flags380,
	gtypes380,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets380,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names381,
	types381,
	attr_flags381,
	gtypes381,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets381,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names382,
	types382,
	attr_flags382,
	gtypes382,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets382,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names383,
	types383,
	attr_flags383,
	gtypes383,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets383,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names384,
	types384,
	attr_flags384,
	gtypes384,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets384,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names385,
	types385,
	attr_flags385,
	gtypes385,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets385,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names386,
	types386,
	attr_flags386,
	gtypes386,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets386,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names387,
	types387,
	attr_flags387,
	gtypes387,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets387,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names388,
	types388,
	attr_flags388,
	gtypes388,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets388,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names389,
	types389,
	attr_flags389,
	gtypes389,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets389,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names390,
	types390,
	attr_flags390,
	gtypes390,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets390,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"NATIVE_STRING",
	names392,
	types392,
	attr_flags392,
	gtypes392,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets392,
	NULL
},
{
	(long) 5,
	(long) 5,
	"FILE_INFO",
	names393,
	types393,
	attr_flags393,
	gtypes393,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets393,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UNIX_FILE_INFO",
	names394,
	types394,
	attr_flags394,
	gtypes394,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets394,
	NULL
},
{
	(long) 6,
	(long) 6,
	"DIRECTORY",
	names395,
	types395,
	attr_flags395,
	gtypes395,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets395,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXECUTION_ENVIRONMENT",
	names396,
	types396,
	attr_flags396,
	gtypes396,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets396,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ENVIRONMENT_ACCESS",
	names397,
	types397,
	attr_flags397,
	gtypes397,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets397,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_DIRECTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_EXECUTION_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IRON_LAYOUT",
	names401,
	types401,
	attr_flags401,
	gtypes401,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets401,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_ENVIRONMENT_EXPANDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IRON_API",
	names403,
	types403,
	attr_flags403,
	gtypes403,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets403,
	NULL
},
{
	(long) 6,
	(long) 6,
	"IRON_INSTALLATION_API",
	names404,
	types404,
	attr_flags404,
	gtypes404,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets404,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ENVIRONMENT_ARGUMENTS",
	names405,
	types405,
	attr_flags405,
	gtypes405,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets405,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ES_ARGUMENTS",
	names406,
	types406,
	attr_flags406,
	gtypes406,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets406,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_UNICODE_CHARACTER_BUFFER",
	names408,
	types408,
	attr_flags408,
	gtypes408,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets408,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_CHARACTER_BUFFER",
	names409,
	types409,
	attr_flags409,
	gtypes409,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets409,
	NULL
},
{
	(long) 2,
	(long) 2,
	"C_STRING",
	names410,
	types410,
	attr_flags410,
	gtypes410,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets410,
	NULL
},
{
	(long) 13,
	(long) 13,
	"IO_MEDIUM",
	names411,
	types411,
	attr_flags411,
	gtypes411,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets411,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_QUEUE_ITERATION_CURSOR",
	names424,
	types424,
	attr_flags424,
	gtypes424,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets424,
	NULL
},
{
	(long) 2,
	(long) 2,
	"FILE_ITERATION_CURSOR",
	names425,
	types425,
	attr_flags425,
	gtypes425,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets425,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SEARCH_TABLE_ITERATION_CURSOR",
	names426,
	types426,
	attr_flags426,
	gtypes426,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets426,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SEARCH_TABLE_ITERATION_CURSOR",
	names427,
	types427,
	attr_flags427,
	gtypes427,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets427,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SEARCH_TABLE_ITERATION_CURSOR",
	names428,
	types428,
	attr_flags428,
	gtypes428,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets428,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MISMATCH_CORRECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE_VALUE",
	names438,
	types438,
	attr_flags438,
	gtypes438,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets438,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS_32",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"STRING_ITERATION_CURSOR",
	names454,
	types454,
	attr_flags454,
	gtypes454,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets454,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names479,
	types479,
	attr_flags479,
	gtypes479,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets479,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names480,
	types480,
	attr_flags480,
	gtypes480,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets480,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names481,
	types481,
	attr_flags481,
	gtypes481,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets481,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names482,
	types482,
	attr_flags482,
	gtypes482,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets482,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names483,
	types483,
	attr_flags483,
	gtypes483,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets483,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names484,
	types484,
	attr_flags484,
	gtypes484,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets484,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names485,
	types485,
	attr_flags485,
	gtypes485,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets485,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names486,
	types486,
	attr_flags486,
	gtypes486,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets486,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names487,
	types487,
	attr_flags487,
	gtypes487,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets487,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names488,
	types488,
	attr_flags488,
	gtypes488,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets488,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names489,
	types489,
	attr_flags489,
	gtypes489,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets489,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names490,
	types490,
	attr_flags490,
	gtypes490,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets490,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names491,
	types491,
	attr_flags491,
	gtypes491,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets491,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names492,
	types492,
	attr_flags492,
	gtypes492,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets492,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names493,
	types493,
	attr_flags493,
	gtypes493,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets493,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names494,
	types494,
	attr_flags494,
	gtypes494,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets494,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names495,
	types495,
	attr_flags495,
	gtypes495,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets495,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names496,
	types496,
	attr_flags496,
	gtypes496,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets496,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names497,
	types497,
	attr_flags497,
	gtypes497,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets497,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names498,
	types498,
	attr_flags498,
	gtypes498,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets498,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names499,
	types499,
	attr_flags499,
	gtypes499,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets499,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names500,
	types500,
	attr_flags500,
	gtypes500,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets500,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names501,
	types501,
	attr_flags501,
	gtypes501,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets501,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names502,
	types502,
	attr_flags502,
	gtypes502,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets502,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names503,
	types503,
	attr_flags503,
	gtypes503,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets503,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names504,
	types504,
	attr_flags504,
	gtypes504,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets504,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names505,
	types505,
	attr_flags505,
	gtypes505,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets505,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names506,
	types506,
	attr_flags506,
	gtypes506,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets506,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names507,
	types507,
	attr_flags507,
	gtypes507,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets507,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names508,
	types508,
	attr_flags508,
	gtypes508,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets508,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names509,
	types509,
	attr_flags509,
	gtypes509,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets509,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names510,
	types510,
	attr_flags510,
	gtypes510,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets510,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names511,
	types511,
	attr_flags511,
	gtypes511,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets511,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names512,
	types512,
	attr_flags512,
	gtypes512,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets512,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names513,
	types513,
	attr_flags513,
	gtypes513,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets513,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names514,
	types514,
	attr_flags514,
	gtypes514,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets514,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names515,
	types515,
	attr_flags515,
	gtypes515,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets515,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names516,
	types516,
	attr_flags516,
	gtypes516,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets516,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names517,
	types517,
	attr_flags517,
	gtypes517,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets517,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names518,
	types518,
	attr_flags518,
	gtypes518,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets518,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names519,
	types519,
	attr_flags519,
	gtypes519,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets519,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names520,
	types520,
	attr_flags520,
	gtypes520,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets520,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names521,
	types521,
	attr_flags521,
	gtypes521,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets521,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names522,
	types522,
	attr_flags522,
	gtypes522,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets522,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names523,
	types523,
	attr_flags523,
	gtypes523,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets523,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names524,
	types524,
	attr_flags524,
	gtypes524,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets524,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8_ITERATION_CURSOR",
	names525,
	types525,
	attr_flags525,
	gtypes525,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets525,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32_ITERATION_CURSOR",
	names526,
	types526,
	attr_flags526,
	gtypes526,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets526,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names527,
	types527,
	attr_flags527,
	gtypes527,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets527,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names528,
	types528,
	attr_flags528,
	gtypes528,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets528,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names529,
	types529,
	attr_flags529,
	gtypes529,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets529,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names530,
	types530,
	attr_flags530,
	gtypes530,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets530,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names531,
	types531,
	attr_flags531,
	gtypes531,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets531,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names532,
	types532,
	attr_flags532,
	gtypes532,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets532,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names533,
	types533,
	attr_flags533,
	gtypes533,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets533,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names534,
	types534,
	attr_flags534,
	gtypes534,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets534,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names535,
	types535,
	attr_flags535,
	gtypes535,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets535,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names536,
	types536,
	attr_flags536,
	gtypes536,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets536,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names537,
	types537,
	attr_flags537,
	gtypes537,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets537,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names538,
	types538,
	attr_flags538,
	gtypes538,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets538,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names539,
	types539,
	attr_flags539,
	gtypes539,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets539,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names540,
	types540,
	attr_flags540,
	gtypes540,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets540,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names541,
	types541,
	attr_flags541,
	gtypes541,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets541,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names542,
	types542,
	attr_flags542,
	gtypes542,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets542,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names543,
	types543,
	attr_flags543,
	gtypes543,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets543,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names544,
	types544,
	attr_flags544,
	gtypes544,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets544,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names545,
	types545,
	attr_flags545,
	gtypes545,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets545,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names546,
	types546,
	attr_flags546,
	gtypes546,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets546,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names547,
	types547,
	attr_flags547,
	gtypes547,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets547,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names548,
	types548,
	attr_flags548,
	gtypes548,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets548,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names549,
	types549,
	attr_flags549,
	gtypes549,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets549,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names550,
	types550,
	attr_flags550,
	gtypes550,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets550,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_REPOSITORY",
	names551,
	types551,
	attr_flags551,
	gtypes551,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets551,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names552,
	types552,
	attr_flags552,
	gtypes552,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets552,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names553,
	types553,
	attr_flags553,
	gtypes553,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets553,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names554,
	types554,
	attr_flags554,
	gtypes554,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets554,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names555,
	types555,
	attr_flags555,
	gtypes555,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets555,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names556,
	types556,
	attr_flags556,
	gtypes556,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets556,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names557,
	types557,
	attr_flags557,
	gtypes557,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets557,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names558,
	types558,
	attr_flags558,
	gtypes558,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets558,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names559,
	types559,
	attr_flags559,
	gtypes559,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets559,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names560,
	types560,
	attr_flags560,
	gtypes560,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets560,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names561,
	types561,
	attr_flags561,
	gtypes561,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets561,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names562,
	types562,
	attr_flags562,
	gtypes562,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets562,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names563,
	types563,
	attr_flags563,
	gtypes563,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets563,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names564,
	types564,
	attr_flags564,
	gtypes564,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets564,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names565,
	types565,
	attr_flags565,
	gtypes565,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets565,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names566,
	types566,
	attr_flags566,
	gtypes566,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets566,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names567,
	types567,
	attr_flags567,
	gtypes567,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets567,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names568,
	types568,
	attr_flags568,
	gtypes568,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets568,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names569,
	types569,
	attr_flags569,
	gtypes569,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets569,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names570,
	types570,
	attr_flags570,
	gtypes570,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets570,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names571,
	types571,
	attr_flags571,
	gtypes571,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets571,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names572,
	types572,
	attr_flags572,
	gtypes572,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets572,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names573,
	types573,
	attr_flags573,
	gtypes573,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets573,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names574,
	types574,
	attr_flags574,
	gtypes574,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets574,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names575,
	types575,
	attr_flags575,
	gtypes575,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets575,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names576,
	types576,
	attr_flags576,
	gtypes576,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets576,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names577,
	types577,
	attr_flags577,
	gtypes577,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets577,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names578,
	types578,
	attr_flags578,
	gtypes578,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets578,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names579,
	types579,
	attr_flags579,
	gtypes579,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets579,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names580,
	types580,
	attr_flags580,
	gtypes580,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets580,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names581,
	types581,
	attr_flags581,
	gtypes581,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets581,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names582,
	types582,
	attr_flags582,
	gtypes582,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets582,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names583,
	types583,
	attr_flags583,
	gtypes583,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets583,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names584,
	types584,
	attr_flags584,
	gtypes584,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets584,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names585,
	types585,
	attr_flags585,
	gtypes585,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets585,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names586,
	types586,
	attr_flags586,
	gtypes586,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets586,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names587,
	types587,
	attr_flags587,
	gtypes587,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets587,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names588,
	types588,
	attr_flags588,
	gtypes588,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets588,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names589,
	types589,
	attr_flags589,
	gtypes589,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets589,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names590,
	types590,
	attr_flags590,
	gtypes590,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets590,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names591,
	types591,
	attr_flags591,
	gtypes591,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets591,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names592,
	types592,
	attr_flags592,
	gtypes592,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets592,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names593,
	types593,
	attr_flags593,
	gtypes593,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets593,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names594,
	types594,
	attr_flags594,
	gtypes594,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets594,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names595,
	types595,
	attr_flags595,
	gtypes595,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets595,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names596,
	types596,
	attr_flags596,
	gtypes596,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets596,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names597,
	types597,
	attr_flags597,
	gtypes597,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets597,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names598,
	types598,
	attr_flags598,
	gtypes598,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets598,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names599,
	types599,
	attr_flags599,
	gtypes599,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets599,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names600,
	types600,
	attr_flags600,
	gtypes600,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets600,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names601,
	types601,
	attr_flags601,
	gtypes601,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets601,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names602,
	types602,
	attr_flags602,
	gtypes602,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets602,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names603,
	types603,
	attr_flags603,
	gtypes603,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets603,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names604,
	types604,
	attr_flags604,
	gtypes604,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets604,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names605,
	types605,
	attr_flags605,
	gtypes605,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets605,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names606,
	types606,
	attr_flags606,
	gtypes606,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets606,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names607,
	types607,
	attr_flags607,
	gtypes607,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets607,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names608,
	types608,
	attr_flags608,
	gtypes608,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets608,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names609,
	types609,
	attr_flags609,
	gtypes609,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets609,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names610,
	types610,
	attr_flags610,
	gtypes610,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets610,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names611,
	types611,
	attr_flags611,
	gtypes611,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets611,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names612,
	types612,
	attr_flags612,
	gtypes612,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets612,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names613,
	types613,
	attr_flags613,
	gtypes613,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets613,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names614,
	types614,
	attr_flags614,
	gtypes614,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets614,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names615,
	types615,
	attr_flags615,
	gtypes615,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets615,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names616,
	types616,
	attr_flags616,
	gtypes616,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets616,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names617,
	types617,
	attr_flags617,
	gtypes617,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets617,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names618,
	types618,
	attr_flags618,
	gtypes618,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets618,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names619,
	types619,
	attr_flags619,
	gtypes619,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets619,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names620,
	types620,
	attr_flags620,
	gtypes620,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets620,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names621,
	types621,
	attr_flags621,
	gtypes621,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets621,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names622,
	types622,
	attr_flags622,
	gtypes622,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets622,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names623,
	types623,
	attr_flags623,
	gtypes623,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets623,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names624,
	types624,
	attr_flags624,
	gtypes624,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets624,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names625,
	types625,
	attr_flags625,
	gtypes625,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets625,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names626,
	types626,
	attr_flags626,
	gtypes626,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets626,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names627,
	types627,
	attr_flags627,
	gtypes627,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets627,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names628,
	types628,
	attr_flags628,
	gtypes628,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets628,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names629,
	types629,
	attr_flags629,
	gtypes629,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets629,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names630,
	types630,
	attr_flags630,
	gtypes630,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets630,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names631,
	types631,
	attr_flags631,
	gtypes631,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets631,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names632,
	types632,
	attr_flags632,
	gtypes632,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets632,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names633,
	types633,
	attr_flags633,
	gtypes633,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets633,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names634,
	types634,
	attr_flags634,
	gtypes634,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets634,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names635,
	types635,
	attr_flags635,
	gtypes635,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets635,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names636,
	types636,
	attr_flags636,
	gtypes636,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets636,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names637,
	types637,
	attr_flags637,
	gtypes637,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets637,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names638,
	types638,
	attr_flags638,
	gtypes638,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets638,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names639,
	types639,
	attr_flags639,
	gtypes639,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets639,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names640,
	types640,
	attr_flags640,
	gtypes640,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets640,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names641,
	types641,
	attr_flags641,
	gtypes641,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets641,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names642,
	types642,
	attr_flags642,
	gtypes642,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets642,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names643,
	types643,
	attr_flags643,
	gtypes643,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets643,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names644,
	types644,
	attr_flags644,
	gtypes644,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets644,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names645,
	types645,
	attr_flags645,
	gtypes645,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets645,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names646,
	types646,
	attr_flags646,
	gtypes646,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets646,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names647,
	types647,
	attr_flags647,
	gtypes647,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets647,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names648,
	types648,
	attr_flags648,
	gtypes648,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets648,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names649,
	types649,
	attr_flags649,
	gtypes649,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets649,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names650,
	types650,
	attr_flags650,
	gtypes650,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets650,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names651,
	types651,
	attr_flags651,
	gtypes651,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets651,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names652,
	types652,
	attr_flags652,
	gtypes652,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets652,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names653,
	types653,
	attr_flags653,
	gtypes653,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets653,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names654,
	types654,
	attr_flags654,
	gtypes654,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets654,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names655,
	types655,
	attr_flags655,
	gtypes655,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets655,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names656,
	types656,
	attr_flags656,
	gtypes656,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets656,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names657,
	types657,
	attr_flags657,
	gtypes657,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets657,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names658,
	types658,
	attr_flags658,
	gtypes658,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets658,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names659,
	types659,
	attr_flags659,
	gtypes659,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets659,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names660,
	types660,
	attr_flags660,
	gtypes660,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets660,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names661,
	types661,
	attr_flags661,
	gtypes661,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets661,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names662,
	types662,
	attr_flags662,
	gtypes662,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets662,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names663,
	types663,
	attr_flags663,
	gtypes663,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets663,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names664,
	types664,
	attr_flags664,
	gtypes664,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets664,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names665,
	types665,
	attr_flags665,
	gtypes665,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets665,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names666,
	types666,
	attr_flags666,
	gtypes666,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets666,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names667,
	types667,
	attr_flags667,
	gtypes667,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets667,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names668,
	types668,
	attr_flags668,
	gtypes668,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets668,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names669,
	types669,
	attr_flags669,
	gtypes669,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets669,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names670,
	types670,
	attr_flags670,
	gtypes670,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets670,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names671,
	types671,
	attr_flags671,
	gtypes671,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets671,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names672,
	types672,
	attr_flags672,
	gtypes672,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets672,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names673,
	types673,
	attr_flags673,
	gtypes673,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets673,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names674,
	types674,
	attr_flags674,
	gtypes674,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets674,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names675,
	types675,
	attr_flags675,
	gtypes675,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets675,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names676,
	types676,
	attr_flags676,
	gtypes676,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets676,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names677,
	types677,
	attr_flags677,
	gtypes677,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets677,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names678,
	types678,
	attr_flags678,
	gtypes678,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets678,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names679,
	types679,
	attr_flags679,
	gtypes679,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets679,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names680,
	types680,
	attr_flags680,
	gtypes680,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets680,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names681,
	types681,
	attr_flags681,
	gtypes681,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets681,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names682,
	types682,
	attr_flags682,
	gtypes682,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets682,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names683,
	types683,
	attr_flags683,
	gtypes683,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets683,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names684,
	types684,
	attr_flags684,
	gtypes684,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets684,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names685,
	types685,
	attr_flags685,
	gtypes685,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets685,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SUBSET",
	names686,
	types686,
	attr_flags686,
	gtypes686,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets686,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE_SUBSET",
	names687,
	types687,
	attr_flags687,
	gtypes687,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets687,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR_SUBSET",
	names688,
	types688,
	attr_flags688,
	gtypes688,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets688,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names689,
	types689,
	attr_flags689,
	gtypes689,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets689,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names690,
	types690,
	attr_flags690,
	gtypes690,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets690,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names691,
	types691,
	attr_flags691,
	gtypes691,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets691,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names692,
	types692,
	attr_flags692,
	gtypes692,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets692,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names693,
	types693,
	attr_flags693,
	gtypes693,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets693,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names694,
	types694,
	attr_flags694,
	gtypes694,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets694,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names695,
	types695,
	attr_flags695,
	gtypes695,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets695,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names696,
	types696,
	attr_flags696,
	gtypes696,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets696,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names697,
	types697,
	attr_flags697,
	gtypes697,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets697,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names698,
	types698,
	attr_flags698,
	gtypes698,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets698,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names699,
	types699,
	attr_flags699,
	gtypes699,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets699,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names700,
	types700,
	attr_flags700,
	gtypes700,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets700,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INFINITE",
	names701,
	types701,
	attr_flags701,
	gtypes701,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets701,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COUNTABLE",
	names702,
	types702,
	attr_flags702,
	gtypes702,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets702,
	NULL
},
{
	(long) 2,
	(long) 2,
	"COUNTABLE_SEQUENCE",
	names703,
	types703,
	attr_flags703,
	gtypes703,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets703,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RANDOM",
	names704,
	types704,
	attr_flags704,
	gtypes704,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets704,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PRIMES",
	names705,
	types705,
	attr_flags705,
	gtypes705,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets705,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names706,
	types706,
	attr_flags706,
	gtypes706,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets706,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names707,
	types707,
	attr_flags707,
	gtypes707,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets707,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names708,
	types708,
	attr_flags708,
	gtypes708,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets708,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names709,
	types709,
	attr_flags709,
	gtypes709,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets709,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names710,
	types710,
	attr_flags710,
	gtypes710,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets710,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names711,
	types711,
	attr_flags711,
	gtypes711,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets711,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names712,
	types712,
	attr_flags712,
	gtypes712,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets712,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names713,
	types713,
	attr_flags713,
	gtypes713,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets713,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names714,
	types714,
	attr_flags714,
	gtypes714,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets714,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names715,
	types715,
	attr_flags715,
	gtypes715,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets715,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names716,
	types716,
	attr_flags716,
	gtypes716,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets716,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names717,
	types717,
	attr_flags717,
	gtypes717,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets717,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names718,
	types718,
	attr_flags718,
	gtypes718,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets718,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names719,
	types719,
	attr_flags719,
	gtypes719,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets719,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names720,
	types720,
	attr_flags720,
	gtypes720,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets720,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names721,
	types721,
	attr_flags721,
	gtypes721,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets721,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names722,
	types722,
	attr_flags722,
	gtypes722,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets722,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names723,
	types723,
	attr_flags723,
	gtypes723,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets723,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names724,
	types724,
	attr_flags724,
	gtypes724,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets724,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names725,
	types725,
	attr_flags725,
	gtypes725,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets725,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names726,
	types726,
	attr_flags726,
	gtypes726,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets726,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names727,
	types727,
	attr_flags727,
	gtypes727,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets727,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names728,
	types728,
	attr_flags728,
	gtypes728,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets728,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names729,
	types729,
	attr_flags729,
	gtypes729,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets729,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names730,
	types730,
	attr_flags730,
	gtypes730,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets730,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names731,
	types731,
	attr_flags731,
	gtypes731,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets731,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names732,
	types732,
	attr_flags732,
	gtypes732,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets732,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names733,
	types733,
	attr_flags733,
	gtypes733,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets733,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names734,
	types734,
	attr_flags734,
	gtypes734,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets734,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names735,
	types735,
	attr_flags735,
	gtypes735,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets735,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names736,
	types736,
	attr_flags736,
	gtypes736,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets736,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names737,
	types737,
	attr_flags737,
	gtypes737,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets737,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names738,
	types738,
	attr_flags738,
	gtypes738,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets738,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names739,
	types739,
	attr_flags739,
	gtypes739,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets739,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names740,
	types740,
	attr_flags740,
	gtypes740,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets740,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names741,
	types741,
	attr_flags741,
	gtypes741,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets741,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names742,
	types742,
	attr_flags742,
	gtypes742,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets742,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names743,
	types743,
	attr_flags743,
	gtypes743,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets743,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUEUE",
	names744,
	types744,
	attr_flags744,
	gtypes744,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets744,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_QUEUE",
	names745,
	types745,
	attr_flags745,
	gtypes745,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets745,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STACK",
	names746,
	types746,
	attr_flags746,
	gtypes746,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets746,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STACK",
	names747,
	types747,
	attr_flags747,
	gtypes747,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets747,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names748,
	types748,
	attr_flags748,
	gtypes748,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets748,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names749,
	types749,
	attr_flags749,
	gtypes749,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets749,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names750,
	types750,
	attr_flags750,
	gtypes750,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets750,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names751,
	types751,
	attr_flags751,
	gtypes751,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets751,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names752,
	types752,
	attr_flags752,
	gtypes752,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets752,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names753,
	types753,
	attr_flags753,
	gtypes753,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets753,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names754,
	types754,
	attr_flags754,
	gtypes754,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets754,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names755,
	types755,
	attr_flags755,
	gtypes755,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets755,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names756,
	types756,
	attr_flags756,
	gtypes756,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets756,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names757,
	types757,
	attr_flags757,
	gtypes757,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets757,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names758,
	types758,
	attr_flags758,
	gtypes758,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets758,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names759,
	types759,
	attr_flags759,
	gtypes759,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets759,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names760,
	types760,
	attr_flags760,
	gtypes760,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets760,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names761,
	types761,
	attr_flags761,
	gtypes761,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets761,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names762,
	types762,
	attr_flags762,
	gtypes762,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets762,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names763,
	types763,
	attr_flags763,
	gtypes763,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets763,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names764,
	types764,
	attr_flags764,
	gtypes764,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets764,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names765,
	types765,
	attr_flags765,
	gtypes765,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets765,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names766,
	types766,
	attr_flags766,
	gtypes766,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets766,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names767,
	types767,
	attr_flags767,
	gtypes767,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets767,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names768,
	types768,
	attr_flags768,
	gtypes768,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets768,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names769,
	types769,
	attr_flags769,
	gtypes769,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets769,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names770,
	types770,
	attr_flags770,
	gtypes770,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets770,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names771,
	types771,
	attr_flags771,
	gtypes771,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets771,
	NULL
},
{
	(long) 20,
	(long) 19,
	"FILE",
	names772,
	types772,
	attr_flags772,
	gtypes772,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets772,
	NULL
},
{
	(long) 21,
	(long) 20,
	"RAW_FILE",
	names773,
	types773,
	attr_flags773,
	gtypes773,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets773,
	NULL
},
{
	(long) 23,
	(long) 22,
	"PLAIN_TEXT_FILE",
	names774,
	types774,
	attr_flags774,
	gtypes774,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets774,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_FILE",
	names783,
	types783,
	attr_flags783,
	gtypes783,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets783,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names796,
	types796,
	attr_flags796,
	gtypes796,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets796,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names797,
	types797,
	attr_flags797,
	gtypes797,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets797,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names798,
	types798,
	attr_flags798,
	gtypes798,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets798,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names799,
	types799,
	attr_flags799,
	gtypes799,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets799,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names800,
	types800,
	attr_flags800,
	gtypes800,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets800,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names801,
	types801,
	attr_flags801,
	gtypes801,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets801,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names802,
	types802,
	attr_flags802,
	gtypes802,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets802,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names803,
	types803,
	attr_flags803,
	gtypes803,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets803,
	NULL
},
{
	(long) 19,
	(long) 19,
	"MISMATCH_INFORMATION",
	names804,
	types804,
	attr_flags804,
	gtypes804,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets804,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names805,
	types805,
	attr_flags805,
	gtypes805,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets805,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names806,
	types806,
	attr_flags806,
	gtypes806,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets806,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names807,
	types807,
	attr_flags807,
	gtypes807,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets807,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names808,
	types808,
	attr_flags808,
	gtypes808,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets808,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names809,
	types809,
	attr_flags809,
	gtypes809,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets809,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names810,
	types810,
	attr_flags810,
	gtypes810,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets810,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names811,
	types811,
	attr_flags811,
	gtypes811,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets811,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names812,
	types812,
	attr_flags812,
	gtypes812,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets812,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names813,
	types813,
	attr_flags813,
	gtypes813,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets813,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names814,
	types814,
	attr_flags814,
	gtypes814,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets814,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names815,
	types815,
	attr_flags815,
	gtypes815,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets815,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names816,
	types816,
	attr_flags816,
	gtypes816,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets816,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names817,
	types817,
	attr_flags817,
	gtypes817,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets817,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names818,
	types818,
	attr_flags818,
	gtypes818,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets818,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names819,
	types819,
	attr_flags819,
	gtypes819,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets819,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names820,
	types820,
	attr_flags820,
	gtypes820,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets820,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names821,
	types821,
	attr_flags821,
	gtypes821,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets821,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INTEGER_INTERVAL",
	names822,
	types822,
	attr_flags822,
	gtypes822,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets822,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names823,
	types823,
	attr_flags823,
	gtypes823,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets823,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names824,
	types824,
	attr_flags824,
	gtypes824,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets824,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names825,
	types825,
	attr_flags825,
	gtypes825,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets825,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names826,
	types826,
	attr_flags826,
	gtypes826,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets826,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names827,
	types827,
	attr_flags827,
	gtypes827,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets827,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names828,
	types828,
	attr_flags828,
	gtypes828,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets828,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names829,
	types829,
	attr_flags829,
	gtypes829,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets829,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names830,
	types830,
	attr_flags830,
	gtypes830,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets830,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names831,
	types831,
	attr_flags831,
	gtypes831,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets831,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names832,
	types832,
	attr_flags832,
	gtypes832,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets832,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names833,
	types833,
	attr_flags833,
	gtypes833,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets833,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names834,
	types834,
	attr_flags834,
	gtypes834,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets834,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names835,
	types835,
	attr_flags835,
	gtypes835,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets835,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names836,
	types836,
	attr_flags836,
	gtypes836,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets836,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names837,
	types837,
	attr_flags837,
	gtypes837,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets837,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names838,
	types838,
	attr_flags838,
	gtypes838,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets838,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names839,
	types839,
	attr_flags839,
	gtypes839,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets839,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names840,
	types840,
	attr_flags840,
	gtypes840,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets840,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names841,
	types841,
	attr_flags841,
	gtypes841,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets841,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names842,
	types842,
	attr_flags842,
	gtypes842,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets842,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names843,
	types843,
	attr_flags843,
	gtypes843,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets843,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names844,
	types844,
	attr_flags844,
	gtypes844,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets844,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names845,
	types845,
	attr_flags845,
	gtypes845,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets845,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names846,
	types846,
	attr_flags846,
	gtypes846,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets846,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names847,
	types847,
	attr_flags847,
	gtypes847,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets847,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names848,
	types848,
	attr_flags848,
	gtypes848,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets848,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names849,
	types849,
	attr_flags849,
	gtypes849,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets849,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names850,
	types850,
	attr_flags850,
	gtypes850,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets850,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names851,
	types851,
	attr_flags851,
	gtypes851,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets851,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names852,
	types852,
	attr_flags852,
	gtypes852,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets852,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names853,
	types853,
	attr_flags853,
	gtypes853,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets853,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names854,
	types854,
	attr_flags854,
	gtypes854,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets854,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names855,
	types855,
	attr_flags855,
	gtypes855,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets855,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names856,
	types856,
	attr_flags856,
	gtypes856,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets856,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names857,
	types857,
	attr_flags857,
	gtypes857,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets857,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names858,
	types858,
	attr_flags858,
	gtypes858,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets858,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names859,
	types859,
	attr_flags859,
	gtypes859,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets859,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names860,
	types860,
	attr_flags860,
	gtypes860,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets860,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names861,
	types861,
	attr_flags861,
	gtypes861,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets861,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names862,
	types862,
	attr_flags862,
	gtypes862,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets862,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names863,
	types863,
	attr_flags863,
	gtypes863,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets863,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names864,
	types864,
	attr_flags864,
	gtypes864,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets864,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names865,
	types865,
	attr_flags865,
	gtypes865,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets865,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names866,
	types866,
	attr_flags866,
	gtypes866,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets866,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names867,
	types867,
	attr_flags867,
	gtypes867,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets867,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names868,
	types868,
	attr_flags868,
	gtypes868,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets868,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names869,
	types869,
	attr_flags869,
	gtypes869,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets869,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names870,
	types870,
	attr_flags870,
	gtypes870,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets870,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names871,
	types871,
	attr_flags871,
	gtypes871,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets871,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names872,
	types872,
	attr_flags872,
	gtypes872,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets872,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names873,
	types873,
	attr_flags873,
	gtypes873,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets873,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names874,
	types874,
	attr_flags874,
	gtypes874,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets874,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names875,
	types875,
	attr_flags875,
	gtypes875,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets875,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names876,
	types876,
	attr_flags876,
	gtypes876,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets876,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names877,
	types877,
	attr_flags877,
	gtypes877,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets877,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names878,
	types878,
	attr_flags878,
	gtypes878,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets878,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names879,
	types879,
	attr_flags879,
	gtypes879,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets879,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names880,
	types880,
	attr_flags880,
	gtypes880,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets880,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names881,
	types881,
	attr_flags881,
	gtypes881,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets881,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names882,
	types882,
	attr_flags882,
	gtypes882,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets882,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names883,
	types883,
	attr_flags883,
	gtypes883,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets883,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names884,
	types884,
	attr_flags884,
	gtypes884,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets884,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names885,
	types885,
	attr_flags885,
	gtypes885,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets885,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names886,
	types886,
	attr_flags886,
	gtypes886,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets886,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names887,
	types887,
	attr_flags887,
	gtypes887,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets887,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names888,
	types888,
	attr_flags888,
	gtypes888,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets888,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names889,
	types889,
	attr_flags889,
	gtypes889,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets889,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_STACK",
	names890,
	types890,
	attr_flags890,
	gtypes890,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets890,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_STACK",
	names891,
	types891,
	attr_flags891,
	gtypes891,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets891,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_SET",
	names892,
	types892,
	attr_flags892,
	gtypes892,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets892,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names893,
	types893,
	attr_flags893,
	gtypes893,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets893,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names894,
	types894,
	attr_flags894,
	gtypes894,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets894,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names895,
	types895,
	attr_flags895,
	gtypes895,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets895,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names896,
	types896,
	attr_flags896,
	gtypes896,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets896,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names897,
	types897,
	attr_flags897,
	gtypes897,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets897,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names898,
	types898,
	attr_flags898,
	gtypes898,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets898,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names899,
	types899,
	attr_flags899,
	gtypes899,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets899,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names900,
	types900,
	attr_flags900,
	gtypes900,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets900,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names901,
	types901,
	attr_flags901,
	gtypes901,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets901,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names902,
	types902,
	attr_flags902,
	gtypes902,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets902,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names903,
	types903,
	attr_flags903,
	gtypes903,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets903,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names904,
	types904,
	attr_flags904,
	gtypes904,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets904,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_SET",
	names905,
	types905,
	attr_flags905,
	gtypes905,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets905,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_STACK",
	names906,
	types906,
	attr_flags906,
	gtypes906,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets906,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_STACK",
	names907,
	types907,
	attr_flags907,
	gtypes907,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets907,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_CONDITION_LIST",
	names908,
	types908,
	attr_flags908,
	gtypes908,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets908,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_NOTE_ELEMENT",
	names909,
	types909,
	attr_flags909,
	gtypes909,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets909,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_ACCESS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 30,
	(long) 30,
	"CONF_LOAD_PARSE_CALLBACKS",
	names911,
	types911,
	attr_flags911,
	gtypes911,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets911,
	NULL
},
{
	(long) 6,
	(long) 6,
	"CONF_PARENT_TARGET_CHECKER",
	names912,
	types912,
	attr_flags912,
	gtypes912,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets912,
	NULL
},
{
	(long) 12,
	(long) 12,
	"CONF_LOAD",
	names913,
	types913,
	attr_flags913,
	gtypes913,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets913,
	NULL
},
{
	(long) 15,
	(long) 15,
	"CONF_LOAD_LACE",
	names914,
	types914,
	attr_flags914,
	gtypes914,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets914,
	NULL
},
{
	(long) 30,
	(long) 30,
	"CONF_OPTION",
	names915,
	types915,
	attr_flags915,
	gtypes915,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets915,
	NULL
},
{
	(long) 36,
	(long) 36,
	"CONF_TARGET_OPTION",
	names916,
	types916,
	attr_flags916,
	gtypes916,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets916,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_VISIBLE",
	names917,
	types917,
	attr_flags917,
	gtypes917,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets917,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_ERROR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_ERROR_CYCLE_IN_PARENTS",
	names919,
	types919,
	attr_flags919,
	gtypes919,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets919,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_VISI",
	names920,
	types920,
	attr_flags920,
	gtypes920,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets920,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_VISI_CONFL02",
	names921,
	types921,
	attr_flags921,
	gtypes921,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets921,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_VISI_CONFL01",
	names922,
	types922,
	attr_flags922,
	gtypes922,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets922,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_VISI_CONFL03",
	names923,
	types923,
	attr_flags923,
	gtypes923,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets923,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_MULOVER",
	names924,
	types924,
	attr_flags924,
	gtypes924,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets924,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_ERROR_UUID_MISMATCH_IN_REDIRECTION",
	names925,
	types925,
	attr_flags925,
	gtypes925,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets925,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_ERROR_CYCLE_IN_REDIRECTION",
	names926,
	types926,
	attr_flags926,
	gtypes926,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets926,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_ERROR_MESSAGE_IN_REDIRECTION",
	names927,
	types927,
	attr_flags927,
	gtypes927,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets927,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_ERROR_FILE",
	names928,
	types928,
	attr_flags928,
	gtypes928,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets928,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_PARSE",
	names929,
	types929,
	attr_flags929,
	gtypes929,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets929,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_LIBOVER",
	names930,
	types930,
	attr_flags930,
	gtypes930,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets930,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_LIBTAR",
	names931,
	types931,
	attr_flags931,
	gtypes931,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets931,
	NULL
},
{
	(long) 6,
	(long) 6,
	"CONF_ERROR_GRUNDEF",
	names932,
	types932,
	attr_flags932,
	gtypes932,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets932,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_VERSION",
	names933,
	types933,
	attr_flags933,
	gtypes933,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets933,
	NULL
},
{
	(long) 6,
	(long) 6,
	"CONF_ERROR_OVERRIDE",
	names934,
	types934,
	attr_flags934,
	gtypes934,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets934,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_UUID",
	names935,
	types935,
	attr_flags935,
	gtypes935,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets935,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_ERROR_REGEXP",
	names936,
	types936,
	attr_flags936,
	gtypes936,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets936,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CASE_INSENSITIVE_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_NULL_TEXT_OUTPUT_STREAM",
	names944,
	types944,
	attr_flags944,
	gtypes944,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets944,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDERR_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDOUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EXECUTION_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING_INPUT_STREAM",
	names965,
	types965,
	attr_flags965,
	gtypes965,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets965,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_STDIN_FILE",
	names966,
	types966,
	attr_flags966,
	gtypes966,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets966,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"AST_LACE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DEPEND_SD",
	names969,
	types969,
	attr_flags969,
	gtypes969,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets969,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TWO_NAME_SD",
	names970,
	types970,
	attr_flags970,
	gtypes970,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets970,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LANG_TRIB_SD",
	names971,
	types971,
	attr_flags971,
	gtypes971,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets971,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FILE_NAME_SD",
	names972,
	types972,
	attr_flags972,
	gtypes972,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets972,
	NULL
},
{
	(long) 6,
	(long) 6,
	"ACE_SD",
	names973,
	types973,
	attr_flags973,
	gtypes973,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets973,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ROOT_SD",
	names974,
	types974,
	attr_flags974,
	gtypes974,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets974,
	NULL
},
{
	(long) 2,
	(long) 2,
	"OPT_VAL_SD",
	names975,
	types975,
	attr_flags975,
	gtypes975,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets975,
	NULL
},
{
	(long) 6,
	(long) 6,
	"CLUSTER_SD",
	names976,
	types976,
	attr_flags976,
	gtypes976,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets976,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CLAS_VISI_SD",
	names977,
	types977,
	attr_flags977,
	gtypes977,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets977,
	NULL
},
{
	(long) 6,
	(long) 6,
	"ASSEMBLY_SD",
	names978,
	types978,
	attr_flags978,
	gtypes978,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets978,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LANGUAGE_NAME_SD",
	names979,
	types979,
	attr_flags979,
	gtypes979,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets979,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LACE_LIST",
	names980,
	types980,
	attr_flags980,
	gtypes980,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets980,
	NULL
},
{
	(long) 8,
	(long) 8,
	"CLUST_PROP_SD",
	names981,
	types981,
	attr_flags981,
	gtypes981,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets981,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CLUST_ADAPT_SD",
	names982,
	types982,
	attr_flags982,
	gtypes982,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets982,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CLUST_REN_SD",
	names983,
	types983,
	attr_flags983,
	gtypes983,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets983,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CLUST_IGN_SD",
	names984,
	types984,
	attr_flags984,
	gtypes984,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets984,
	NULL
},
{
	(long) 2,
	(long) 2,
	"D_OPTION_SD",
	names985,
	types985,
	attr_flags985,
	gtypes985,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets985,
	NULL
},
{
	(long) 3,
	(long) 3,
	"D_PRECOMPILED_SD",
	names986,
	types986,
	attr_flags986,
	gtypes986,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets986,
	NULL
},
{
	(long) 3,
	(long) 3,
	"O_OPTION_SD",
	names987,
	types987,
	attr_flags987,
	gtypes987,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets987,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPTION_SD",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ASSERTION_SD",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TRACE_SD",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PRECOMPILED_SD",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPTIMIZE_SD",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FREE_OPTION_SD",
	names993,
	types993,
	attr_flags993,
	gtypes993,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets993,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DEBUG_SD",
	names994,
	types994,
	attr_flags994,
	gtypes994,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets994,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UC_CHARACTER",
	names996,
	types996,
	attr_flags996,
	gtypes996,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets996,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TUPLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"ARGUMENT_SWITCH",
	names998,
	types998,
	attr_flags998,
	gtypes998,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets998,
	NULL
},
{
	(long) 11,
	(long) 11,
	"ARGUMENT_VALUE_SWITCH",
	names999,
	types999,
	attr_flags999,
	gtypes999,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets999,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32_REF",
	names1000,
	types1000,
	attr_flags1000,
	gtypes1000,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1000,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names1001,
	types1001,
	attr_flags1001,
	gtypes1001,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1001,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names1002,
	types1002,
	attr_flags1002,
	gtypes1002,
	(uint16) 0x230E,
	(void (*)()) 0,
	offsets1002,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8_REF",
	names1003,
	types1003,
	attr_flags1003,
	gtypes1003,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1003,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names1004,
	types1004,
	attr_flags1004,
	gtypes1004,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1004,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names1005,
	types1005,
	attr_flags1005,
	gtypes1005,
	(uint16) 0x2302,
	(void (*)()) 0,
	offsets1005,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN_REF",
	names1006,
	types1006,
	attr_flags1006,
	gtypes1006,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1006,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names1007,
	types1007,
	attr_flags1007,
	gtypes1007,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1007,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names1008,
	types1008,
	attr_flags1008,
	gtypes1008,
	(uint16) 0x2301,
	(void (*)()) 0,
	offsets1008,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER_REF",
	names1009,
	types1009,
	attr_flags1009,
	gtypes1009,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1009,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1010,
	types1010,
	attr_flags1010,
	gtypes1010,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1010,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1011,
	types1011,
	attr_flags1011,
	gtypes1011,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1011,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1012,
	types1012,
	attr_flags1012,
	gtypes1012,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1012,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1013,
	types1013,
	attr_flags1013,
	gtypes1013,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1013,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1014,
	types1014,
	attr_flags1014,
	gtypes1014,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1014,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1015,
	types1015,
	attr_flags1015,
	gtypes1015,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1015,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1016,
	types1016,
	attr_flags1016,
	gtypes1016,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1016,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1017,
	types1017,
	attr_flags1017,
	gtypes1017,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1017,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1018,
	types1018,
	attr_flags1018,
	gtypes1018,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1018,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1019,
	types1019,
	attr_flags1019,
	gtypes1019,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1019,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1020,
	types1020,
	attr_flags1020,
	gtypes1020,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1020,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1021,
	types1021,
	attr_flags1021,
	gtypes1021,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1021,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1022,
	types1022,
	attr_flags1022,
	gtypes1022,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1022,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1023,
	types1023,
	attr_flags1023,
	gtypes1023,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1023,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1024,
	types1024,
	attr_flags1024,
	gtypes1024,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1024,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1025,
	types1025,
	attr_flags1025,
	gtypes1025,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1025,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1026,
	types1026,
	attr_flags1026,
	gtypes1026,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1026,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1027,
	types1027,
	attr_flags1027,
	gtypes1027,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1027,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1028,
	types1028,
	attr_flags1028,
	gtypes1028,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1028,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1029,
	types1029,
	attr_flags1029,
	gtypes1029,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1029,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1030,
	types1030,
	attr_flags1030,
	gtypes1030,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1030,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1031,
	types1031,
	attr_flags1031,
	gtypes1031,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1031,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1032,
	types1032,
	attr_flags1032,
	gtypes1032,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1032,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1033,
	types1033,
	attr_flags1033,
	gtypes1033,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1033,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1034,
	types1034,
	attr_flags1034,
	gtypes1034,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1034,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1035,
	types1035,
	attr_flags1035,
	gtypes1035,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1035,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1036,
	types1036,
	attr_flags1036,
	gtypes1036,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1036,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1037,
	types1037,
	attr_flags1037,
	gtypes1037,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1037,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1038,
	types1038,
	attr_flags1038,
	gtypes1038,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1038,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1039,
	types1039,
	attr_flags1039,
	gtypes1039,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1039,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names1040,
	types1040,
	attr_flags1040,
	gtypes1040,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1040,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names1041,
	types1041,
	attr_flags1041,
	gtypes1041,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1041,
	NULL
},
{
	(long) 12,
	(long) 12,
	"ROUTINE",
	names1042,
	types1042,
	attr_flags1042,
	gtypes1042,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1042,
	NULL
},
{
	(long) 12,
	(long) 12,
	"PROCEDURE",
	names1043,
	types1043,
	attr_flags1043,
	gtypes1043,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1043,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names1044,
	types1044,
	attr_flags1044,
	gtypes1044,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1044,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names1045,
	types1045,
	attr_flags1045,
	gtypes1045,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1045,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names1046,
	types1046,
	attr_flags1046,
	gtypes1046,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1046,
	NULL
},
{
	(long) 13,
	(long) 13,
	"PREDICATE",
	names1047,
	types1047,
	attr_flags1047,
	gtypes1047,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1047,
	NULL
},
{
	(long) 2,
	(long) 2,
	"READABLE_STRING_GENERAL",
	names1048,
	types1048,
	attr_flags1048,
	gtypes1048,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1048,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IMMUTABLE_STRING_GENERAL",
	names1049,
	types1049,
	attr_flags1049,
	gtypes1049,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1049,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_GENERAL",
	names1050,
	types1050,
	attr_flags1050,
	gtypes1050,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1050,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_8",
	names1051,
	types1051,
	attr_flags1051,
	gtypes1051,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1051,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_8",
	names1052,
	types1052,
	attr_flags1052,
	gtypes1052,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1052,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8",
	names1053,
	types1053,
	attr_flags1053,
	gtypes1053,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1053,
	NULL
},
{
	(long) 6,
	(long) 6,
	"ID_SD",
	names1054,
	types1054,
	attr_flags1054,
	gtypes1054,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1054,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING",
	names1055,
	types1055,
	attr_flags1055,
	gtypes1055,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1055,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_32",
	names1056,
	types1056,
	attr_flags1056,
	gtypes1056,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1056,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_32",
	names1057,
	types1057,
	attr_flags1057,
	gtypes1057,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1057,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32",
	names1058,
	types1058,
	attr_flags1058,
	gtypes1058,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1058,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DEBUG_OUTPUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 9,
	(long) 9,
	"DATE_TIME_CODE",
	names1060,
	types1060,
	attr_flags1060,
	gtypes1060,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1060,
	NULL
},
{
	(long) 4,
	(long) 4,
	"IRON_WEB_REPOSITORY",
	names1061,
	types1061,
	attr_flags1061,
	gtypes1061,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1061,
	NULL
},
{
	(long) 12,
	(long) 12,
	"IRON_PACKAGE",
	names1062,
	types1062,
	attr_flags1062,
	gtypes1062,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1062,
	NULL
},
{
	(long) 3,
	(long) 3,
	"IRON_WORKING_COPY_REPOSITORY",
	names1063,
	types1063,
	attr_flags1063,
	gtypes1063,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1063,
	NULL
},
{
	(long) 13,
	(long) 13,
	"XML_FILE_INPUT_STREAM",
	names1064,
	types1064,
	attr_flags1064,
	gtypes1064,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1064,
	NULL
},
{
	(long) 8,
	(long) 8,
	"XML_STRING_INPUT_STREAM",
	names1065,
	types1065,
	attr_flags1065,
	gtypes1065,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1065,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_VALUE_CHOICE",
	names1066,
	types1066,
	attr_flags1066,
	gtypes1066,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1066,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XML_POSITION",
	names1067,
	types1067,
	attr_flags1067,
	gtypes1067,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1067,
	NULL
},
{
	(long) 19,
	(long) 19,
	"CONF_CLASS",
	names1068,
	types1068,
	attr_flags1068,
	gtypes1068,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1068,
	NULL
},
{
	(long) 15,
	(long) 15,
	"RT_DBG_CALL_RECORD",
	names1069,
	types1069,
	attr_flags1069,
	gtypes1069,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1069,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_ORDERED_CAPABILITY",
	names1070,
	types1070,
	attr_flags1070,
	gtypes1070,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1070,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UUID",
	names1071,
	types1071,
	attr_flags1071,
	gtypes1071,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1071,
	NULL
},
{
	(long) 30,
	(long) 30,
	"CONF_TARGET",
	names1072,
	types1072,
	attr_flags1072,
	gtypes1072,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1072,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PATH",
	names1073,
	types1073,
	attr_flags1073,
	gtypes1073,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1073,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1074,
	types1074,
	attr_flags1074,
	gtypes1074,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1074,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1075,
	types1075,
	attr_flags1075,
	gtypes1075,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1075,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1076,
	types1076,
	attr_flags1076,
	gtypes1076,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1076,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1077,
	types1077,
	attr_flags1077,
	gtypes1077,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1077,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1078,
	types1078,
	attr_flags1078,
	gtypes1078,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1078,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1079,
	types1079,
	attr_flags1079,
	gtypes1079,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1079,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1080,
	types1080,
	attr_flags1080,
	gtypes1080,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1080,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1081,
	types1081,
	attr_flags1081,
	gtypes1081,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1081,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1082,
	types1082,
	attr_flags1082,
	gtypes1082,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1082,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1083,
	types1083,
	attr_flags1083,
	gtypes1083,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1083,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1084,
	types1084,
	attr_flags1084,
	gtypes1084,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1084,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1085,
	types1085,
	attr_flags1085,
	gtypes1085,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1085,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1086,
	types1086,
	attr_flags1086,
	gtypes1086,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1086,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1087,
	types1087,
	attr_flags1087,
	gtypes1087,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1087,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1088,
	types1088,
	attr_flags1088,
	gtypes1088,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1088,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1089,
	types1089,
	attr_flags1089,
	gtypes1089,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1089,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1090,
	types1090,
	attr_flags1090,
	gtypes1090,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1090,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1091,
	types1091,
	attr_flags1091,
	gtypes1091,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1091,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1092,
	types1092,
	attr_flags1092,
	gtypes1092,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1092,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1093,
	types1093,
	attr_flags1093,
	gtypes1093,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1093,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1094,
	types1094,
	attr_flags1094,
	gtypes1094,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1094,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1095,
	types1095,
	attr_flags1095,
	gtypes1095,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1095,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1096,
	types1096,
	attr_flags1096,
	gtypes1096,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1096,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1097,
	types1097,
	attr_flags1097,
	gtypes1097,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1097,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1098,
	types1098,
	attr_flags1098,
	gtypes1098,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1098,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1099,
	types1099,
	attr_flags1099,
	gtypes1099,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1099,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1100,
	types1100,
	attr_flags1100,
	gtypes1100,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1100,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1101,
	types1101,
	attr_flags1101,
	gtypes1101,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1101,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1102,
	types1102,
	attr_flags1102,
	gtypes1102,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1102,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1103,
	types1103,
	attr_flags1103,
	gtypes1103,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1103,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1104,
	types1104,
	attr_flags1104,
	gtypes1104,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1104,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1105,
	types1105,
	attr_flags1105,
	gtypes1105,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1105,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1106,
	types1106,
	attr_flags1106,
	gtypes1106,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1106,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1107,
	types1107,
	attr_flags1107,
	gtypes1107,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1107,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSTRACT_SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 20,
	(long) 20,
	"CONF_GROUP",
	names1121,
	types1121,
	attr_flags1121,
	gtypes1121,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1121,
	NULL
},
{
	(long) 20,
	(long) 20,
	"CONF_PHYSICAL_GROUP",
	names1122,
	types1122,
	attr_flags1122,
	gtypes1122,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1122,
	NULL
},
{
	(long) 22,
	(long) 22,
	"CONF_PHYSICAL_ASSEMBLY_INTERFACE",
	names1123,
	types1123,
	attr_flags1123,
	gtypes1123,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1123,
	NULL
},
{
	(long) 33,
	(long) 33,
	"CONF_CLUSTER",
	names1124,
	types1124,
	attr_flags1124,
	gtypes1124,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1124,
	NULL
},
{
	(long) 33,
	(long) 33,
	"CONF_TEST_CLUSTER",
	names1125,
	types1125,
	attr_flags1125,
	gtypes1125,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1125,
	NULL
},
{
	(long) 35,
	(long) 35,
	"CONF_OVERRIDE",
	names1126,
	types1126,
	attr_flags1126,
	gtypes1126,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1126,
	NULL
},
{
	(long) 22,
	(long) 22,
	"CONF_VIRTUAL_GROUP",
	names1127,
	types1127,
	attr_flags1127,
	gtypes1127,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1127,
	NULL
},
{
	(long) 28,
	(long) 28,
	"CONF_ASSEMBLY",
	names1128,
	types1128,
	attr_flags1128,
	gtypes1128,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1128,
	NULL
},
{
	(long) 26,
	(long) 26,
	"CONF_LIBRARY",
	names1129,
	types1129,
	attr_flags1129,
	gtypes1129,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1129,
	NULL
},
{
	(long) 27,
	(long) 27,
	"CONF_PRECOMPILE",
	names1130,
	types1130,
	attr_flags1130,
	gtypes1130,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1130,
	NULL
},
{
	(long) 3,
	(long) 3,
	"RT_DBG_VALUE_RECORD",
	names1131,
	types1131,
	attr_flags1131,
	gtypes1131,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1131,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1132,
	types1132,
	attr_flags1132,
	gtypes1132,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1132,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1133,
	types1133,
	attr_flags1133,
	gtypes1133,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1133,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1134,
	types1134,
	attr_flags1134,
	gtypes1134,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1134,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1135,
	types1135,
	attr_flags1135,
	gtypes1135,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1135,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1136,
	types1136,
	attr_flags1136,
	gtypes1136,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1136,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1137,
	types1137,
	attr_flags1137,
	gtypes1137,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1137,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1138,
	types1138,
	attr_flags1138,
	gtypes1138,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1138,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1139,
	types1139,
	attr_flags1139,
	gtypes1139,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1139,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1140,
	types1140,
	attr_flags1140,
	gtypes1140,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1140,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1141,
	types1141,
	attr_flags1141,
	gtypes1141,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1141,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1142,
	types1142,
	attr_flags1142,
	gtypes1142,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1142,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1143,
	types1143,
	attr_flags1143,
	gtypes1143,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1143,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1144,
	types1144,
	attr_flags1144,
	gtypes1144,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1144,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1145,
	types1145,
	attr_flags1145,
	gtypes1145,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1145,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1146,
	types1146,
	attr_flags1146,
	gtypes1146,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1146,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1147,
	types1147,
	attr_flags1147,
	gtypes1147,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1147,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1148,
	types1148,
	attr_flags1148,
	gtypes1148,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1148,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1149,
	types1149,
	attr_flags1149,
	gtypes1149,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1149,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1150,
	types1150,
	attr_flags1150,
	gtypes1150,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1150,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1151,
	types1151,
	attr_flags1151,
	gtypes1151,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1151,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1152,
	types1152,
	attr_flags1152,
	gtypes1152,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1152,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1153,
	types1153,
	attr_flags1153,
	gtypes1153,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1153,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1154,
	types1154,
	attr_flags1154,
	gtypes1154,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1154,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1155,
	types1155,
	attr_flags1155,
	gtypes1155,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1155,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1156,
	types1156,
	attr_flags1156,
	gtypes1156,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1156,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1157,
	types1157,
	attr_flags1157,
	gtypes1157,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1157,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1158,
	types1158,
	attr_flags1158,
	gtypes1158,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1158,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1159,
	types1159,
	attr_flags1159,
	gtypes1159,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1159,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1160,
	types1160,
	attr_flags1160,
	gtypes1160,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1160,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1161,
	types1161,
	attr_flags1161,
	gtypes1161,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1161,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1162,
	types1162,
	attr_flags1162,
	gtypes1162,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1162,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1163,
	types1163,
	attr_flags1163,
	gtypes1163,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1163,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1164,
	types1164,
	attr_flags1164,
	gtypes1164,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1164,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1165,
	types1165,
	attr_flags1165,
	gtypes1165,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1165,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1166,
	types1166,
	attr_flags1166,
	gtypes1166,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1166,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1167,
	types1167,
	attr_flags1167,
	gtypes1167,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1167,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1168,
	types1168,
	attr_flags1168,
	gtypes1168,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1168,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1169,
	types1169,
	attr_flags1169,
	gtypes1169,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1169,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1170,
	types1170,
	attr_flags1170,
	gtypes1170,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1170,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1171,
	types1171,
	attr_flags1171,
	gtypes1171,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1171,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1172,
	types1172,
	attr_flags1172,
	gtypes1172,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1172,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1173,
	types1173,
	attr_flags1173,
	gtypes1173,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1173,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1174,
	types1174,
	attr_flags1174,
	gtypes1174,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1174,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1175,
	types1175,
	attr_flags1175,
	gtypes1175,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1175,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1176,
	types1176,
	attr_flags1176,
	gtypes1176,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1176,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_VALUE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"JSON_BOOLEAN",
	names1178,
	types1178,
	attr_flags1178,
	gtypes1178,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1178,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_NULL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"JSON_NUMBER",
	names1180,
	types1180,
	attr_flags1180,
	gtypes1180,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1180,
	NULL
},
{
	(long) 1,
	(long) 1,
	"JSON_STRING",
	names1181,
	types1181,
	attr_flags1181,
	gtypes1181,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1181,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64_REF",
	names1183,
	types1183,
	attr_flags1183,
	gtypes1183,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1183,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names1184,
	types1184,
	attr_flags1184,
	gtypes1184,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1184,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names1185,
	types1185,
	attr_flags1185,
	gtypes1185,
	(uint16) 0x2309,
	(void (*)()) 0,
	offsets1185,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32_REF",
	names1186,
	types1186,
	attr_flags1186,
	gtypes1186,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1186,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names1187,
	types1187,
	attr_flags1187,
	gtypes1187,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1187,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names1188,
	types1188,
	attr_flags1188,
	gtypes1188,
	(uint16) 0x2308,
	(void (*)()) 0,
	offsets1188,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16_REF",
	names1189,
	types1189,
	attr_flags1189,
	gtypes1189,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1189,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names1190,
	types1190,
	attr_flags1190,
	gtypes1190,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1190,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names1191,
	types1191,
	attr_flags1191,
	gtypes1191,
	(uint16) 0x2307,
	(void (*)()) 0,
	offsets1191,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8_REF",
	names1192,
	types1192,
	attr_flags1192,
	gtypes1192,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1192,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names1193,
	types1193,
	attr_flags1193,
	gtypes1193,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1193,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names1194,
	types1194,
	attr_flags1194,
	gtypes1194,
	(uint16) 0x2306,
	(void (*)()) 0,
	offsets1194,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64_REF",
	names1195,
	types1195,
	attr_flags1195,
	gtypes1195,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1195,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names1196,
	types1196,
	attr_flags1196,
	gtypes1196,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1196,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names1197,
	types1197,
	attr_flags1197,
	gtypes1197,
	(uint16) 0x230D,
	(void (*)()) 0,
	offsets1197,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32_REF",
	names1198,
	types1198,
	attr_flags1198,
	gtypes1198,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1198,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names1199,
	types1199,
	attr_flags1199,
	gtypes1199,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1199,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names1200,
	types1200,
	attr_flags1200,
	gtypes1200,
	(uint16) 0x230C,
	(void (*)()) 0,
	offsets1200,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16_REF",
	names1201,
	types1201,
	attr_flags1201,
	gtypes1201,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1201,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names1202,
	types1202,
	attr_flags1202,
	gtypes1202,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1202,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names1203,
	types1203,
	attr_flags1203,
	gtypes1203,
	(uint16) 0x230B,
	(void (*)()) 0,
	offsets1203,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8_REF",
	names1204,
	types1204,
	attr_flags1204,
	gtypes1204,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1204,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names1205,
	types1205,
	attr_flags1205,
	gtypes1205,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1205,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names1206,
	types1206,
	attr_flags1206,
	gtypes1206,
	(uint16) 0x230A,
	(void (*)()) 0,
	offsets1206,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32_REF",
	names1207,
	types1207,
	attr_flags1207,
	gtypes1207,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1207,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names1208,
	types1208,
	attr_flags1208,
	gtypes1208,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1208,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names1209,
	types1209,
	attr_flags1209,
	gtypes1209,
	(uint16) 0x2304,
	(void (*)()) 0,
	offsets1209,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64_REF",
	names1210,
	types1210,
	attr_flags1210,
	gtypes1210,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1210,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names1211,
	types1211,
	attr_flags1211,
	gtypes1211,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1211,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names1212,
	types1212,
	attr_flags1212,
	gtypes1212,
	(uint16) 0x2303,
	(void (*)()) 0,
	offsets1212,
	NULL
},
{
	(long) 1,
	(long) 1,
	"JSON_ARRAY",
	names1213,
	types1213,
	attr_flags1213,
	gtypes1213,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1213,
	NULL
},
{
	(long) 1,
	(long) 1,
	"JSON_OBJECT",
	names1214,
	types1214,
	attr_flags1214,
	gtypes1214,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1214,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_LANGUAGE_ID",
	names1215,
	types1215,
	attr_flags1215,
	gtypes1215,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1215,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_SETTING",
	names1222,
	types1222,
	attr_flags1222,
	gtypes1222,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1222,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_LOCALE_ID",
	names1223,
	types1223,
	attr_flags1223,
	gtypes1223,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1223,
	NULL
},
{
	(long) 2,
	(long) 2,
	"I18N_LOCALE_MANAGER",
	names1224,
	types1224,
	attr_flags1224,
	gtypes1224,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1224,
	NULL
},
{
	(long) 23,
	(long) 22,
	"CONSOLE",
	names1225,
	types1225,
	attr_flags1225,
	gtypes1225,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1225,
	NULL
},
{
	(long) 13,
	(long) 13,
	"CONF_VERSION",
	names1226,
	types1226,
	attr_flags1226,
	gtypes1226,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1226,
	NULL
},
{
	(long) 10,
	(long) 10,
	"SEARCH_TABLE",
	names1227,
	types1227,
	attr_flags1227,
	gtypes1227,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1227,
	NULL
},
{
	(long) 10,
	(long) 10,
	"SEARCH_TABLE",
	names1228,
	types1228,
	attr_flags1228,
	gtypes1228,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1228,
	NULL
},
{
	(long) 10,
	(long) 10,
	"SEARCH_TABLE",
	names1229,
	types1229,
	attr_flags1229,
	gtypes1229,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1229,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_TITLECASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_UPPERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_LOWERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"YY_SCANNER",
	names1235,
	types1235,
	attr_flags1235,
	gtypes1235,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1235,
	NULL
},
{
	(long) 22,
	(long) 22,
	"YY_SCANNER_SKELETON",
	names1236,
	types1236,
	attr_flags1236,
	gtypes1236,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1236,
	NULL
},
{
	(long) 38,
	(long) 38,
	"YY_COMPRESSED_SCANNER_SKELETON",
	names1237,
	types1237,
	attr_flags1237,
	gtypes1237,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1237,
	NULL
},
{
	(long) 42,
	(long) 42,
	"CLASSNAME_FINDER_SKELETON",
	names1238,
	types1238,
	attr_flags1238,
	gtypes1238,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1238,
	NULL
},
{
	(long) 42,
	(long) 42,
	"CLASSNAME_FINDER",
	names1239,
	types1239,
	attr_flags1239,
	gtypes1239,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1239,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_ACTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CLONABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ENCODING_DETECTOR",
	names1242,
	types1242,
	attr_flags1242,
	gtypes1242,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1242,
	NULL
},
{
	(long) 4,
	(long) 4,
	"BOM_ENCODING_DETECTOR",
	names1243,
	types1243,
	attr_flags1243,
	gtypes1243,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1243,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_VISITOR",
	names1244,
	types1244,
	attr_flags1244,
	gtypes1244,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1244,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_ITERATOR",
	names1245,
	types1245,
	attr_flags1245,
	gtypes1245,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1245,
	NULL
},
{
	(long) 10,
	(long) 10,
	"CONF_GROUPS_TARGET_CHECKER",
	names1246,
	types1246,
	attr_flags1246,
	gtypes1246,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1246,
	NULL
},
{
	(long) 9,
	(long) 9,
	"CONF_PRINT_VISITOR",
	names1247,
	types1247,
	attr_flags1247,
	gtypes1247,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1247,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FIND_SEPARATOR_FACILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATE_TIME_CODE_STRING",
	names1249,
	types1249,
	attr_flags1249,
	gtypes1249,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1249,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_I",
	names1250,
	types1250,
	attr_flags1250,
	gtypes1250,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1250,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_IMP",
	names1251,
	types1251,
	attr_flags1251,
	gtypes1251,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1251,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UNICODE_CONVERSION",
	names1252,
	types1252,
	attr_flags1252,
	gtypes1252,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1252,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_HOST_LOCALE_IMP",
	names1253,
	types1253,
	attr_flags1253,
	gtypes1253,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1253,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_FILE",
	names1254,
	types1254,
	attr_flags1254,
	gtypes1254,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1254,
	NULL
},
{
	(long) 8,
	(long) 8,
	"CONF_REDIRECTION",
	names1255,
	types1255,
	attr_flags1255,
	gtypes1255,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1255,
	NULL
},
{
	(long) 22,
	(long) 22,
	"CONF_SYSTEM",
	names1256,
	types1256,
	attr_flags1256,
	gtypes1256,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1256,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LOCALIZED_PRINTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_LOCALE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_INTERFACE_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_CLASSN",
	names1260,
	types1260,
	attr_flags1260,
	gtypes1260,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1260,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ACE_TO_ECF_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 9,
	(long) 9,
	"CONF_CONDITION",
	names1262,
	types1262,
	attr_flags1262,
	gtypes1262,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1262,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_ACE_TO_ECF_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ACE_TO_ECF_TOOL",
	names1264,
	types1264,
	attr_flags1264,
	gtypes1264,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1264,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 11,
	(long) 11,
	"KL_DIRECTORY",
	names1266,
	types1266,
	attr_flags1266,
	gtypes1266,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1266,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_FILE",
	names1267,
	types1267,
	attr_flags1267,
	gtypes1267,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1267,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_OUTPUT_FILE",
	names1268,
	types1268,
	attr_flags1268,
	gtypes1268,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1268,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_BINARY_OUTPUT_FILE",
	names1269,
	types1269,
	attr_flags1269,
	gtypes1269,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1269,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_UNIX_OUTPUT_FILE",
	names1270,
	types1270,
	attr_flags1270,
	gtypes1270,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1270,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_WINDOWS_OUTPUT_FILE",
	names1271,
	types1271,
	attr_flags1271,
	gtypes1271,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1271,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_INPUT_FILE",
	names1272,
	types1272,
	attr_flags1272,
	gtypes1272,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1272,
	NULL
},
{
	(long) 26,
	(long) 25,
	"KL_TEXT_INPUT_FILE",
	names1273,
	types1273,
	attr_flags1273,
	gtypes1273,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1273,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_BINARY_INPUT_FILE",
	names1274,
	types1274,
	attr_flags1274,
	gtypes1274,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1274,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_UNIX_INPUT_FILE",
	names1275,
	types1275,
	attr_flags1275,
	gtypes1275,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1275,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_WINDOWS_INPUT_FILE",
	names1276,
	types1276,
	attr_flags1276,
	gtypes1276,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1276,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_BINARY_INPUT_FILE_32",
	names1277,
	types1277,
	attr_flags1277,
	gtypes1277,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1277,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_LOCATION",
	names1278,
	types1278,
	attr_flags1278,
	gtypes1278,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1278,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_FILE_LOCATION",
	names1279,
	types1279,
	attr_flags1279,
	gtypes1279,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1279,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_DIRECTORY_LOCATION",
	names1280,
	types1280,
	attr_flags1280,
	gtypes1280,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1280,
	NULL
},
{
	(long) 14,
	(long) 14,
	"JSON_PARSER",
	names1281,
	types1281,
	attr_flags1281,
	gtypes1281,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1281,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_FORMAT_STRING_PARSER",
	names1282,
	types1282,
	attr_flags1282,
	gtypes1282,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1282,
	NULL
},
{
	(long) 11,
	(long) 11,
	"RT_DBG_EXECUTION_RECORDER",
	names1283,
	types1283,
	attr_flags1283,
	gtypes1283,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1283,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_UNIX_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 31,
	(long) 31,
	"COMPILER",
	names1289,
	types1289,
	attr_flags1289,
	gtypes1289,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1289,
	NULL
},
{
	(long) 52,
	(long) 52,
	"REGULAR_EXPRESSION",
	names1290,
	types1290,
	attr_flags1290,
	gtypes1290,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1290,
	NULL
},
{
	(long) 52,
	(long) 52,
	"REGULAR_EXPRESSION_MATCH_AND_REPLACE",
	names1291,
	types1291,
	attr_flags1291,
	gtypes1291,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1291,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME_VALIDITY_CHECKER",
	names1292,
	types1292,
	attr_flags1292,
	gtypes1292,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1292,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME",
	names1293,
	types1293,
	attr_flags1293,
	gtypes1293,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1293,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE_VALIDITY_CHECKER",
	names1294,
	types1294,
	attr_flags1294,
	gtypes1294,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1294,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE",
	names1295,
	types1295,
	attr_flags1295,
	gtypes1295,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1295,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DATE_TIME_VALIDITY_CHECKER",
	names1296,
	types1296,
	attr_flags1296,
	gtypes1296,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1296,
	NULL
},
{
	(long) 16,
	(long) 16,
	"DATE_TIME_PARSER",
	names1297,
	types1297,
	attr_flags1297,
	gtypes1297,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1297,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DATE_TIME",
	names1298,
	types1298,
	attr_flags1298,
	gtypes1298,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1298,
	NULL
},
{
	(long) 9,
	(long) 9,
	"URI",
	names1299,
	types1299,
	attr_flags1299,
	gtypes1299,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1299,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IRI",
	names1300,
	types1300,
	attr_flags1300,
	gtypes1300,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1300,
	NULL
},
{
	(long) 11,
	(long) 11,
	"PATH_URI",
	names1301,
	types1301,
	attr_flags1301,
	gtypes1301,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1301,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EIFFEL_ENV",
	names1303,
	types1303,
	attr_flags1303,
	gtypes1303,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1303,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EC_EIFFEL_LAYOUT",
	names1304,
	types1304,
	attr_flags1304,
	gtypes1304,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1304,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER_TOKENS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LACE_TOKENS",
	names1306,
	types1306,
	attr_flags1306,
	gtypes1306,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1306,
	NULL
},
{
	(long) 43,
	(long) 43,
	"LACE_SCANNER_SKELETON",
	names1307,
	types1307,
	attr_flags1307,
	gtypes1307,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1307,
	NULL
},
{
	(long) 43,
	(long) 43,
	"LACE_SCANNER",
	names1308,
	types1308,
	attr_flags1308,
	gtypes1308,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1308,
	NULL
},
{
	(long) 23,
	(long) 23,
	"YY_PARSER_SKELETON",
	names1309,
	types1309,
	attr_flags1309,
	gtypes1309,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1309,
	NULL
},
{
	(long) 68,
	(long) 68,
	"LACE_PARSER_SKELETON",
	names1310,
	types1310,
	attr_flags1310,
	gtypes1310,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1310,
	NULL
},
{
	(long) 180,
	(long) 180,
	"LACE_PARSER",
	names1311,
	types1311,
	attr_flags1311,
	gtypes1311,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1311,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PATHNAME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"KL_PATHNAME",
	names1313,
	types1313,
	attr_flags1313,
	gtypes1313,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1313,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_STRING",
	names1314,
	types1314,
	attr_flags1314,
	gtypes1314,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1314,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_UTF8_STRING",
	names1315,
	types1315,
	attr_flags1315,
	gtypes1315,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1315,
	NULL
},};


#ifdef __cplusplus
}
#endif
