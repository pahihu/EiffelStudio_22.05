
#ifndef _C10_xm485_
#define _C10_xm485_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1067_8328(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1067_8333(EIF_REFERENCE);
extern EIF_REFERENCE F1067_8334(EIF_REFERENCE);
extern void EIF_Minit485(void);
extern void F1058_8102(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1048_7685(EIF_REFERENCE);
extern void F1058_8101(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
