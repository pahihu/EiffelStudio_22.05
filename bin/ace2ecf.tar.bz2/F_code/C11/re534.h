
#ifndef _C11_re534_
#define _C11_re534_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1207_9886(EIF_REFERENCE);
extern EIF_BOOLEAN F1207_9897(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1207_9898(EIF_REFERENCE, EIF_REFERENCE);
extern void F1207_9899(EIF_REFERENCE, EIF_REAL_32);
extern EIF_INTEGER_32 F1207_9908(EIF_REFERENCE);
extern EIF_REFERENCE F1207_9925(EIF_REFERENCE);
extern void EIF_Minit534(void);
extern char *(*R8076[])();

#ifdef __cplusplus
}
#endif

#endif
