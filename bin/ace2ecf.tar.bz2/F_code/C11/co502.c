/*
 * Code for class CONF_PRECOMPILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co502.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_PRECOMPILE}.make */
void F1130_8954 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg3;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_22_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_22_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6612[Dtype(RTCW(arg1))-1051])(arg1);
	F1121_8811(Current, tr1);
	F1121_8813(Current, arg2);
	RTLE;
}

/* {CONF_PRECOMPILE}.set_eifgens_location */
void F1130_8957 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg1;
}

/* {CONF_PRECOMPILE}.process */
void F1130_8958 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (CONF_VISITOR.process_group) */
		(void) RTCW(arg1);
		/* END INLINED CODE */
	}
	;
	F1247_10701(RTCW(arg1), Current);
	RTLE;
}

void EIF_Minit502 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
