/*
 * Code for class I18N_LOCALE_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1546.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_LOCALE_MANAGER}.make */
void F1224_10111 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(1956,F139_1956, (Current));
	tr1 = F18_186(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(1252, 0x00).id, 1252, _OBJSIZ_1_2_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_LOCALE_MANAGER}.locale */
EIF_REFERENCE F1224_10112 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	if (F1224_10115(Current, arg1)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = F141_1965(RTCW(tr1), arg1);
	} else {
		loc2 = RTLNS(eif_new_type(208, 0x00).id, 208, _OBJSIZ_1_0_0_2_0_0_0_0_);
		F207_2567(RTCW(loc2), ((EIF_INTEGER_32) 0L));
	}
	if (F1224_10117(Current, arg1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = F1253_10823(RTCW(tr1), arg1);
	} else {
		loc1 = RTLNS(eif_new_type(126, 0x00).id, 126, _OBJSIZ_35_0_0_5_0_0_0_0_);
		F127_1852(RTCW(loc1));
	}
	tr1 = RTLNS(eif_new_type(39, 0x00).id, 39, _OBJSIZ_6_0_0_0_0_0_0_0_);
	F40_432(RTCW(tr1), loc2, loc1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {I18N_LOCALE_MANAGER}.has_translations */
EIF_BOOLEAN F1224_10115 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\01';
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = F140_1961(RTCW(tr1), arg1);
	if (!tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = F1223_10106(RTCW(arg1));
		tb1 = F140_1962(RTCW(tr1), tr2);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {I18N_LOCALE_MANAGER}.has_formatting_info */
EIF_BOOLEAN F1224_10117 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1253_10824(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

void EIF_Minit546 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
