/*
 * Code for class STRING_FORMATTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st543.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STRING_FORMATTER}.format_unicode */
EIF_REFERENCE F1216_10080 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc9 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 loc10 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 loc11 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 loc12 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,loc6);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLR(5,loc13);
	RTLR(6,loc14);
	RTLR(7,tr1);
	RTLR(8,Current);
	RTLIU(9);
	
	RTGC;
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6590[Dtype(RTCW(arg1))-1051])(arg1);
	loc3 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (arg2);
	loc11 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '{';
	loc12 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '}';
	loc6 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1056_7984(RTCW(loc6), ((EIF_INTEGER_32) 2L));
	Result = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1056_7984(RTCW(Result), (EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 2L)));
	loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc8 > loc2)) break;
		loc9 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6554[Dtype(RTCW(arg1))-1051])(arg1, loc8);
		if ((EIF_BOOLEAN) (loc8 < loc2)) {
			loc10 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6554[Dtype(RTCW(arg1))-1051])(arg1, (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
		}
		if ((EIF_BOOLEAN)(loc9 == loc11)) {
			if ((EIF_BOOLEAN) (loc8 < loc2)) {
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc10 != loc11);
				if ((EIF_BOOLEAN) !loc4) {
					loc8++;
					F1058_8112(RTCW(Result), loc10);
				}
			}
		} else {
			if ((EIF_BOOLEAN)(loc9 == loc12)) {
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc8 < loc2) && (EIF_BOOLEAN)(loc10 == loc12))) {
					F1058_8112(RTCW(Result), loc10);
					loc8++;
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
				if ((EIF_BOOLEAN) (loc4 && (EIF_BOOLEAN) !loc5)) {
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					tb1 = F1048_7716(RTCW(loc6));
					if (tb1) {
						loc7 = F1048_7750(RTCW(loc6));
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc7 <= loc3))) {
							loc1 = F997_7329(RTCW(arg2), loc7);
							if ((EIF_BOOLEAN)(loc1 != NULL)) {
								loc13 = RTCCL(loc1);
								loc13 = RTRV(eif_new_type(1047, 0x00),loc13);
								if (EIF_TEST(loc13)) {
									F1058_8098(RTCW(Result), loc13);
								} else {
									loc14 = RTCCL(loc1);
									loc14 = RTRV(eif_new_type(1047, 0x00),loc14);
									if (EIF_TEST(loc14)) {
										tr1 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
										F1056_7992(RTCW(tr1), loc14);
										F1058_8098(RTCW(Result), tr1);
									} else {
										tr1 = RTCCL(loc1);
										tr1 = F1216_10085(Current, tr1);
										F1058_8098(RTCW(Result), tr1);
									}
								}
							}
						}
					}
					F1058_8128(RTCW(loc6));
				}
			} else {
				if (loc4) {
					F1058_8112(RTCW(loc6), loc9);
				} else {
					F1058_8112(RTCW(Result), loc9);
				}
			}
		}
		loc8++;
	}
	RTLE;
	return Result;
}

/* {STRING_FORMATTER}.ellipse */
RTEOMS(10080,1);
EIF_REFERENCE F1216_10081 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1058_8060(RTCW(Result), arg1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 > arg2)) {
		F1058_8081(RTCW(Result), (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 3L)));
		F1058_8098(RTCW(Result), RTOMS(10080,0));
	}
	RTLE;
	return Result;
}

/* {STRING_FORMATTER}.out_from_separate */
EIF_REFERENCE F1216_10085 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(RTCW(arg1))-1])(arg1);
	F1051_7823(RTCW(Result), tr1);
	RTLE;
	return Result;
}

void EIF_Minit543 (void)
{
	GTCX
	RTPOMS(10080,0,"...",3,3026478);
}


#ifdef __cplusplus
}
#endif
