
#ifndef _C11_js540_
#define _C11_js540_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1213_10017(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1213_10023(EIF_REFERENCE);
extern EIF_REFERENCE F1213_10025(EIF_REFERENCE);
extern void F1213_10030(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1213_10034(EIF_REFERENCE);
extern EIF_REFERENCE F1213_10035(EIF_REFERENCE);
extern void EIF_Minit540(void);
extern EIF_REFERENCE F893_6376(EIF_REFERENCE);
extern EIF_BOOLEAN F501_5372(EIF_REFERENCE);
extern EIF_REFERENCE F501_5363(EIF_REFERENCE);
extern EIF_INTEGER_32 F893_6383(EIF_REFERENCE);
extern void F893_6362(EIF_REFERENCE, EIF_INTEGER_32);
extern void F501_5378(EIF_REFERENCE);
extern char *(*R6737[])();
extern char *(*R6231[])();
extern char *(*R6741[])();
extern char *(*R4921[])();
extern char *(*R7568[])();
extern long O6713[];

#ifdef __cplusplus
}
#endif

#endif
