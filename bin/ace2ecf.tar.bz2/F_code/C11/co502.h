
#ifndef _C11_co502_
#define _C11_co502_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1130_8954(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1130_8957(EIF_REFERENCE, EIF_REFERENCE);
extern void F1130_8958(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit502(void);
extern void F1247_10701(EIF_REFERENCE, EIF_REFERENCE);
extern void F1121_8811(EIF_REFERENCE, EIF_REFERENCE);
extern void F1121_8813(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R6612[])();

#ifdef __cplusplus
}
#endif

#endif
