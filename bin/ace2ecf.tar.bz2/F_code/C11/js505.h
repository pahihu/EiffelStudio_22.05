
#ifndef _C11_js505_
#define _C11_js505_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1178_9031(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1178_9032(EIF_REFERENCE);
extern void F1178_9033(EIF_REFERENCE);
extern EIF_INTEGER_32 F1178_9036(EIF_REFERENCE);
extern EIF_REFERENCE F1178_9037(EIF_REFERENCE);
extern void EIF_Minit505(void);

#ifdef __cplusplus
}
#endif

#endif
