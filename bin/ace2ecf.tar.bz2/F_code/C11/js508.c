/*
 * Code for class JSON_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js508.h"
#include "eif_built_in.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_STRING}.make_from_string */
void F1181_9072 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1181_9100(Current, arg1);
	F1181_9075(Current, tr1);
	RTLE;
}

/* {JSON_STRING}.make_from_escaped_json_string */
void F1181_9075 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1048_7738(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {JSON_STRING}.unescaped_string_32 */
EIF_REFERENCE F1181_9085 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	Result = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O6713[Dtype(loc1)-1050]);
	F1056_7984(RTCW(Result), ti4_1);
	F1181_9088(Current, Result);
	RTLE;
	return Result;
}

/* {JSON_STRING}.representation */
EIF_REFERENCE F1181_9086 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O6713[Dtype(tr1)-1050]);
	F1051_7815(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6741[Dtype(RTCW(Result))-1052])(Result, (EIF_CHARACTER_8) '\"');
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6737[Dtype(RTCW(Result))-1052])(Result, *(EIF_REFERENCE *)(Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6741[Dtype(RTCW(Result))-1052])(Result, (EIF_CHARACTER_8) '\"');
	RTLE;
	return Result;
}

/* {JSON_STRING}.unescape_to_string_32 */
void F1181_9088 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc6);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O6713[Dtype(loc1)-1050]);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5231[Dtype(RTCW(loc1))-795])(loc1, loc2));
		if ((EIF_BOOLEAN)(loc5 == (EIF_CHARACTER_8) '\\')) {
			if ((EIF_BOOLEAN) (loc2 < loc3)) {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5231[Dtype(RTCW(loc1))-795])(loc1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L))));
				switch (tc1) {
					case (EIF_CHARACTER_8) '\"':
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						F1058_8112(RTCW(arg1), tw1);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) '\\':
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
						F1058_8112(RTCW(arg1), tw1);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) '/':
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
						F1058_8112(RTCW(arg1), tw1);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) 'b':
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\010';
						F1058_8112(RTCW(arg1), tw1);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) 'f':
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\014';
						F1058_8112(RTCW(arg1), tw1);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) 'n':
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
						F1058_8112(RTCW(arg1), tw1);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) 'r':
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\015';
						F1058_8112(RTCW(arg1), tw1);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) 't':
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
						F1058_8112(RTCW(arg1), tw1);
						loc2 += ((EIF_INTEGER_32) 2L);
						break;
					case (EIF_CHARACTER_8) 'u':
						if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 5L)) <= loc3)) {
							loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6631[Dtype(RTCW(loc1))-1051])(loc1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 5L)));
							tu4_1 = F1181_9099(Current, loc6);
							F1050_7785(RTCW(arg1), tu4_1);
							loc2 += ((EIF_INTEGER_32) 6L);
						} else {
							tw1 = (EIF_CHARACTER_32) loc5;
							F1058_8112(RTCW(arg1), tw1);
							loc2++;
						}
						break;
					default:
						tw1 = (EIF_CHARACTER_32) loc5;
						F1058_8112(RTCW(arg1), tw1);
						loc2++;
						break;
				}
			} else {
				tw1 = (EIF_CHARACTER_32) loc5;
				F1058_8112(RTCW(arg1), tw1);
				loc2++;
			}
		} else {
			loc4 = (EIF_NATURAL_32) loc5;
			if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
				tw1 = (EIF_CHARACTER_32) loc5;
				F1058_8112(RTCW(arg1), tw1);
			} else {
				if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 223L))) {
					loc2++;
					if ((EIF_BOOLEAN) (loc2 <= loc3)) {
						tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 31L));
						tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 6L));
						tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6553[Dtype(RTCW(loc1))-1051])(loc1, loc2);
						tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
						tu4_1 = eif_bit_or(tu4_1,tu4_2);
						F1050_7785(RTCW(arg1), tu4_1);
					}
				} else {
					if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 239L))) {
						loc2 += ((EIF_INTEGER_32) 2L);
						if ((EIF_BOOLEAN) (loc2 <= loc3)) {
							tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 15L));
							tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 12L));
							tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6553[Dtype(RTCW(loc1))-1051])(loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
							tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
							tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 6L));
							tu4_1 = eif_bit_or(tu4_1,tu4_2);
							tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6553[Dtype(RTCW(loc1))-1051])(loc1, loc2);
							tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
							tu4_1 = eif_bit_or(tu4_1,tu4_2);
							F1050_7785(RTCW(arg1), tu4_1);
						}
					} else {
						if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 247L))) {
							loc2 += ((EIF_INTEGER_32) 3L);
							if ((EIF_BOOLEAN) (loc2 <= loc3)) {
								tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 7L));
								tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 18L));
								tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6553[Dtype(RTCW(loc1))-1051])(loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 2L)));
								tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
								tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 12L));
								tu4_1 = eif_bit_or(tu4_1,tu4_2);
								tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6553[Dtype(RTCW(loc1))-1051])(loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
								tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
								tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 6L));
								tu4_1 = eif_bit_or(tu4_1,tu4_2);
								tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6553[Dtype(RTCW(loc1))-1051])(loc1, loc2);
								tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
								tu4_1 = eif_bit_or(tu4_1,tu4_2);
								F1050_7785(RTCW(arg1), tu4_1);
							}
						}
					}
				}
			}
			loc2++;
		}
	}
	RTLE;
}

/* {JSON_STRING}.is_equal */
EIF_BOOLEAN F1181_9090 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6698[Dtype(RTCW(tr1))-1051])(tr1, tr2);
	RTLE;
	return Result;
}

/* {JSON_STRING}.hash_code */
EIF_INTEGER_32 F1181_9096 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6231[Dtype(RTCW(tr1))-996])(tr1);
	RTLE;
	return Result;
}

/* {JSON_STRING}.hexadecimal_to_natural_32 */
EIF_NATURAL_32 F1181_9099 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O6713[Dtype(arg1)-1050]);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 2L))) {
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5231[Dtype(RTCW(arg1))-795])(arg1, ((EIF_INTEGER_32) 2L)));
		tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) 'x');
	}
	if (tb1) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	} else {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		Result *= (EIF_NATURAL_32) ((EIF_INTEGER_32) 16L);
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5231[Dtype(RTCW(arg1))-795])(arg1, loc1));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 >= (EIF_CHARACTER_8) '0') && (EIF_BOOLEAN) (loc3 <= (EIF_CHARACTER_8) '9'))) {
			tr1 = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_CHARACTER_8 *)tr1 = loc3;
			ti4_1 = F1003_7540(RTCW(tr1), (EIF_CHARACTER_8) '0');
			tu4_1 = (EIF_NATURAL_32) ti4_1;
			Result += tu4_1;
		} else {
			tc1 = eif_builtin_CHARACTER_8_as_lower__c1_c1(loc3);
			tr1 = RTLNS(eif_new_type(1004, 0x00).id, 1004, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_CHARACTER_8 *)tr1 = tc1;
			ti4_1 = F1003_7540(RTCW(tr1), (EIF_CHARACTER_8) 'a');
			tu4_1 = (EIF_NATURAL_32) (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 10L));
			Result += tu4_1;
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {JSON_STRING}.escaped_json_string */
EIF_REFERENCE F1181_9100 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6590[Dtype(RTCW(arg1))-1051])(arg1);
	Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1051_7815(RTCW(Result), (EIF_INTEGER_32) (loc3 + (EIF_INTEGER_32) (loc3 / ((EIF_INTEGER_32) 10L))));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc3)) break;
		loc4 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6554[Dtype(RTCW(arg1))-1051])(arg1, loc1);
		tb1 = (loc4 <= 0xFF);
		if (tb1) {
			loc5 = (EIF_CHARACTER_8) loc4;
			switch (loc5) {
				case (EIF_CHARACTER_8) '\000':
					tr1 = RTMS_EX_H("\\u0000",6,990242352);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6739[Dtype(RTCW(Result))-1052])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '\"':
					tr1 = RTMS_EX_H("\\\"",2,23586);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6739[Dtype(RTCW(Result))-1052])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '\\':
					tr1 = RTMS_EX_H("\\\\",2,23644);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6739[Dtype(RTCW(Result))-1052])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '/':
					tb1 = '\0';
					tb2 = F1048_7697(RTCW(arg1), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
					if (tb2) {
						tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6554[Dtype(RTCW(arg1))-1051])(arg1, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '<';
						tb1 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb1) {
						tr1 = RTMS_EX_H("\\/",2,23599);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6739[Dtype(RTCW(Result))-1052])(Result, tr1);
					} else {
						tr1 = RTMS_EX_H("/",1,47);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6739[Dtype(RTCW(Result))-1052])(Result, tr1);
					}
					break;
				case (EIF_CHARACTER_8) '\010':
					tr1 = RTMS_EX_H("\\b",2,23650);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6739[Dtype(RTCW(Result))-1052])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '\014':
					tr1 = RTMS_EX_H("\\f",2,23654);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6739[Dtype(RTCW(Result))-1052])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '\012':
					tr1 = RTMS_EX_H("\\n",2,23662);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6739[Dtype(RTCW(Result))-1052])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '\015':
					tr1 = RTMS_EX_H("\\r",2,23666);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6739[Dtype(RTCW(Result))-1052])(Result, tr1);
					break;
				case (EIF_CHARACTER_8) '\011':
					tr1 = RTMS_EX_H("\\t",2,23668);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6739[Dtype(RTCW(Result))-1052])(Result, tr1);
					break;
				default:
					tu4_1 = (EIF_NATURAL_32) loc4;
					if ((EIF_BOOLEAN) (tu4_1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
					F1053_7942(RTCW(Result), loc5);
					break;
			}
		} else {
			tr1 = RTMS_EX_H("\\u",2,23669);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6737[Dtype(RTCW(Result))-1052])(Result, tr1);
			ti4_1 = (EIF_INTEGER_32) (loc4);
			tr1 = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_INTEGER_32 *)tr1 = ti4_1;
			loc6 = F1186_9264(RTCW(tr1));
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				tb1 = '\01';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6) + O6713[Dtype(loc6)-1050]);
				if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 4L))) {
					tb2 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6) + O6713[Dtype(loc6)-1050]);
					if ((EIF_BOOLEAN) (loc2 <= ti4_1)) {
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5231[Dtype(RTCW(loc6))-795])(loc6, loc2));
						tb2 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '0');
					}
					tb1 = tb2;
				}
				if (tb1) break;
				loc2++;
			}
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6) + O6713[Dtype(loc6)-1050]);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6631[Dtype(RTCW(loc6))-1051])(loc6, loc2, ti4_1);
			loc6 = (EIF_REFERENCE) tr1;
			for (;;) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6) + O6713[Dtype(loc6)-1050]);
				if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 4L))) break;
				F1053_7924(RTCW(loc6), ((EIF_INTEGER_32) 0L));
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6737[Dtype(RTCW(Result))-1052])(Result, loc6);
		}
		loc1++;
	}
	if (loc7) {
		tr1 = RTOSCF(9101,F1181_9101, (Current));
		tr1 = F67_1011(RTCW(tr1), Result);
		Result = (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

/* {JSON_STRING}.utf_converter */
static EIF_REFERENCE F1181_9101_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (9101);
#define Result RTOSR(9101)
	RTOC_NEW(Result);
	Result= RTLN(eif_new_type(66, 0x00).id);
	tr1 = RTLNS(eif_new_type(66, 0x00).id, 66, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = (tr1);
	RTXA(tr1, Result);
	RTOSE (9101);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1181_9101 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9101,F1181_9101_body,(Current));
}

void EIF_Minit508 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
