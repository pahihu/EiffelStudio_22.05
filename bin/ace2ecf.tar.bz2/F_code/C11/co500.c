/*
 * Code for class CONF_ASSEMBLY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co500.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_ASSEMBLY}.make_from_gac */
void F1128_8908 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg6);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLR(6,arg4);
	RTLR(7,arg5);
	RTLR(8,tr2);
	RTLIU(9);
	
	RTGC;
	RTAR(Current, arg6);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg6;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_23_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6612[Dtype(RTCW(arg1))-1051])(arg1);
	F1121_8811(Current, tr1);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) arg3;
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) arg4;
	RTAR(Current, arg5);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg5;
	tr1 = RTLNSMART(eif_final_id(Y7408,Y7408_gen_type,Dftype(Current),1120).id);
	tr2 = RTMS32_EX_H("",0,0);
	F1279_11713(RTCW(tr1), tr2, arg6);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_23_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {CONF_ASSEMBLY}.classes_set */
EIF_BOOLEAN F1128_8909 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_8_) != NULL);
}

/* {CONF_ASSEMBLY}.is_assembly */
static EIF_BOOLEAN F1128_8910_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (8910);
#define Result RTOSR(8910)
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTOSE (8910);
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F1128_8910 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(8910,F1128_8910_body,(Current));
}

/* {CONF_ASSEMBLY}.is_readonly */
EIF_BOOLEAN F1128_8913 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {CONF_ASSEMBLY}.accessible_groups */
EIF_REFERENCE F1128_8920 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (RTNA((loc1)), ((EIF_REFERENCE) 0));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1226,1120,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNS(typres0.id, 1226, _OBJSIZ_4_1_0_5_0_0_0_0_);
		}
		F1227_10224(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {CONF_ASSEMBLY}.class_by_name */
EIF_REFERENCE F1128_8922 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	Result = F1121_8801(Current, arg1, arg2);
	if (arg2) {
		loc2 = F1227_10235(RTCV(F1128_8920(Current)));
		for (;;) {
			tb1 = F426_5224(loc2);
			if (tb1) break;
			loc1 = F426_5223(loc2);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7394[Dtype(RTCW(loc1))-1123])(loc1);
			if (tb2) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R7421[Dtype(RTCW(loc1))-1123])(loc1, arg1, (EIF_BOOLEAN) 0);
				F840_6261(RTCW(Result), tr1);
			}
			F426_5225(loc2);
		}
	}
	RTLE;
	return Result;
}

/* {CONF_ASSEMBLY}.name_by_class */
EIF_REFERENCE F1128_8923 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	Result = F1121_8802(Current, arg1, arg2);
	if (arg2) {
		loc2 = F1128_8920(Current);
		F1227_10270(RTCW(loc2));
		for (;;) {
			tb1 = F1227_10273(RTCW(loc2));
			if (tb1) break;
			loc1 = F1227_10275(RTCW(loc2));
			F1227_10271(RTCW(loc2));
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7394[Dtype(RTCW(loc1))-1123])(loc1);
			if (tb2) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R7422[Dtype(RTCW(loc1))-1123])(loc1, arg1, (EIF_BOOLEAN) 0);
				F840_6261(RTCW(Result), tr1);
			}
		}
	}
	RTLE;
	return Result;
}

/* {CONF_ASSEMBLY}.process */
void F1128_8935 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1121_8826(Current, arg1);
	F1247_10699(RTCW(arg1), Current);
	RTLE;
}

void EIF_Minit500 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
