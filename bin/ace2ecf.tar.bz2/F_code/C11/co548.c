/*
 * Code for class CONF_VERSION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co548.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_VERSION}.make */
void F1226_10183 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_0_) = (EIF_NATURAL_16) (EIF_NATURAL_16) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_1_) = (EIF_NATURAL_16) (EIF_NATURAL_16) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_2_) = (EIF_NATURAL_16) (EIF_NATURAL_16) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_3_) = (EIF_NATURAL_16) (EIF_NATURAL_16) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {CONF_VERSION}.make_version */
void F1226_10184 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1, EIF_NATURAL_16 arg2, EIF_NATURAL_16 arg3, EIF_NATURAL_16 arg4)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_0_) = (EIF_NATURAL_16) arg1;
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_1_) = (EIF_NATURAL_16) arg2;
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_2_) = (EIF_NATURAL_16) arg3;
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_3_) = (EIF_NATURAL_16) arg4;
	RTLE;
}

/* {CONF_VERSION}.make_from_string */
void F1226_10185 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_NATURAL_16 tu2_1;
	EIF_NATURAL_16 tu2_2;
	EIF_NATURAL_16 tu2_3;
	EIF_NATURAL_16 tu2_4;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {831,1202,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc2 = RTLNS(typres0.id, 831, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F832_6183(RTCW(loc2), ((EIF_NATURAL_16) 0U), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 4L));
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
	loc1 = F1048_7763(RTCW(arg1), tw1);
	tb1 = '\01';
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4997[Dtype(RTCW(loc1))-744])(loc1);
	if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4997[Dtype(RTCW(loc1))-744])(loc1);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 4L));
	}
	if (tb1) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4901[Dtype(RTCW(loc1))-703])(loc1);
		for (;;) {
			tb1 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_)) {
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4912[Dtype(RTCW(loc1))-703])(loc1);
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4934[Dtype(RTCW(loc1))-703])(loc1);
			tb2 = F1048_7720(RTCW(tr1));
			if (tb2) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4934[Dtype(RTCW(loc1))-703])(loc1);
				tu2_1 = F1048_7754(RTCW(tr1));
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4908[Dtype(RTCW(loc1))-703])(loc1);
				F832_6207(RTCW(loc2), tu2_1, ti4_1);
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R4914[Dtype(RTCW(loc1))-703])(loc1);
		}
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_)) {
		tu2_1 = F832_6188(RTCW(loc2), ((EIF_INTEGER_32) 1L));
		tu2_2 = F832_6188(RTCW(loc2), ((EIF_INTEGER_32) 2L));
		tu2_3 = F832_6188(RTCW(loc2), ((EIF_INTEGER_32) 3L));
		tu2_4 = F832_6188(RTCW(loc2), ((EIF_INTEGER_32) 4L));
		F1226_10184(Current, tu2_1, tu2_2, tu2_3, tu2_4);
	}
	RTLE;
}

/* {CONF_VERSION}.append_major */
void F1226_10192 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1226_10222(Current, *(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_0_), *(EIF_NATURAL_8 *)(Current+ _CHROFF_4_1_), arg1);
}

/* {CONF_VERSION}.append_minor */
void F1226_10193 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1226_10222(Current, *(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_1_), *(EIF_NATURAL_8 *)(Current+ _CHROFF_4_2_), arg1);
}

/* {CONF_VERSION}.version */
EIF_REFERENCE F1226_10198 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1048_7685(RTCW(Result));
	F1226_10192(Current, Result);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
	F1058_8112(RTCW(Result), tw1);
	F1226_10193(Current, Result);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
	F1058_8112(RTCW(Result), tw1);
	F1226_10222(Current, *(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_2_), *(EIF_NATURAL_8 *)(Current+ _CHROFF_4_3_), Result);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
	F1058_8112(RTCW(Result), tw1);
	F1226_10222(Current, *(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_3_), *(EIF_NATURAL_8 *)(Current+ _CHROFF_4_4_), Result);
	RTLE;
	return Result;
}

/* {CONF_VERSION}.set_major */
void F1226_10212 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1)
{
	GTCX
	
	
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_0_) = (EIF_NATURAL_16) arg1;
}

/* {CONF_VERSION}.set_minor */
void F1226_10213 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1)
{
	GTCX
	
	
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_1_) = (EIF_NATURAL_16) arg1;
}

/* {CONF_VERSION}.set_release */
void F1226_10214 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1)
{
	GTCX
	
	
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_2_) = (EIF_NATURAL_16) arg1;
}

/* {CONF_VERSION}.set_build */
void F1226_10215 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1)
{
	GTCX
	
	
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_3_) = (EIF_NATURAL_16) arg1;
}

/* {CONF_VERSION}.set_company */
void F1226_10216 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {CONF_VERSION}.set_product */
void F1226_10217 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {CONF_VERSION}.set_trademark */
void F1226_10218 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {CONF_VERSION}.set_copyright */
void F1226_10219 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {CONF_VERSION}.is_less */
EIF_BOOLEAN F1226_10220 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_NATURAL_16 tu2_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tb2 = '\01';
	tu2_1 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_4_5_0_);
	if (!(EIF_BOOLEAN) (*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_0_) < tu2_1)) {
		tb3 = '\0';
		tu2_1 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_4_5_0_);
		if ((EIF_BOOLEAN)(*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_0_) == tu2_1)) {
			tu2_1 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_4_5_1_);
			tb3 = (EIF_BOOLEAN) (*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_1_) < tu2_1);
		}
		tb2 = tb3;
	}
	if (!tb2) {
		tb2 = '\0';
		tb3 = '\0';
		tu2_1 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_4_5_0_);
		if ((EIF_BOOLEAN)(*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_0_) == tu2_1)) {
			tu2_1 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_4_5_1_);
			tb3 = (EIF_BOOLEAN)(*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_1_) == tu2_1);
		}
		if (tb3) {
			tu2_1 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_4_5_2_);
			tb2 = (EIF_BOOLEAN) (*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_2_) < tu2_1);
		}
		tb1 = tb2;
	}
	if (!tb1) {
		tb1 = '\0';
		tb2 = '\0';
		tb3 = '\0';
		tu2_1 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_4_5_0_);
		if ((EIF_BOOLEAN)(*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_0_) == tu2_1)) {
			tu2_1 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_4_5_1_);
			tb3 = (EIF_BOOLEAN)(*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_1_) == tu2_1);
		}
		if (tb3) {
			tu2_1 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_4_5_2_);
			tb2 = (EIF_BOOLEAN)(*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_2_) == tu2_1);
		}
		if (tb2) {
			tu2_1 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_4_5_3_);
			tb1 = (EIF_BOOLEAN) (*(EIF_NATURAL_16 *)(Current+ _I16OFF_4_5_3_) < tu2_1);
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {CONF_VERSION}.append_natural_16_to */
void F1226_10222 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1, EIF_NATURAL_8 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg3);
	RTLIU(2);
	
	RTGC;
	tr1 = eif_out__u2_s1(arg1);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O6713[Dtype(tr1)-1050]);
	ti4_1 = (EIF_INTEGER_32) arg2;
	if ((EIF_BOOLEAN) (loc1 < ti4_1)) {
		ti4_1 = (EIF_INTEGER_32) arg2;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - loc1);
		for (;;) {
			if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) break;
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '0';
			F1058_8112(RTCW(arg3), tw1);
			loc1--;
		}
	}
	F1058_8107(RTCW(arg3), arg1);
	RTLE;
}

void EIF_Minit548 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
