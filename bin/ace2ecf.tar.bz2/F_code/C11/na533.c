/*
 * Code for class reference NATURAL_8
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "na533.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NATURAL_8}.is_less */
EIF_BOOLEAN F1205_9858 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)tr1 = arg1;
	Result = F1204_9798(Current, tr1);
	RTLE;
	return Result;
}

/* {NATURAL_8}.plus */
EIF_NATURAL_8 F1205_9859 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)tr1 = arg1;
	tr1 = F1204_9807(Current, tr1);
	Result = *(EIF_NATURAL_8 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_8}.minus */
EIF_NATURAL_8 F1205_9860 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)tr1 = arg1;
	tr1 = F1204_9808(Current, tr1);
	Result = *(EIF_NATURAL_8 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_8}.integer_quotient */
EIF_NATURAL_8 F1205_9864 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)tr1 = arg1;
	tr1 = F1204_9813(Current, tr1);
	Result = *(EIF_NATURAL_8 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_8}.integer_remainder */
EIF_NATURAL_8 F1205_9865 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)tr1 = arg1;
	tr1 = F1204_9814(Current, tr1);
	Result = *(EIF_NATURAL_8 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_8}.as_natural_16 */
EIF_NATURAL_16 F1205_9868 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_16) F1204_9821(Current);
}

/* {NATURAL_8}.as_natural_32 */
EIF_NATURAL_32 F1205_9869 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_32) F1204_9822(Current);
}

/* {NATURAL_8}.as_natural_64 */
EIF_NATURAL_64 F1205_9870 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_64) F1204_9823(Current);
}

/* {NATURAL_8}.as_integer_8 */
EIF_INTEGER_8 F1205_9871 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_8) F1204_9824(Current);
}

/* {NATURAL_8}.as_integer_32 */
EIF_INTEGER_32 F1205_9873 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F1204_9826(Current);
}

/* {NATURAL_8}.to_character_8 */
EIF_CHARACTER_8 F1205_9877 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_CHARACTER_8) F1204_9845(Current);
}

/* {NATURAL_8}.to_character_32 */
EIF_CHARACTER_32 F1205_9878 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_CHARACTER_32) F1204_9846(Current);
}

/* {NATURAL_8}.bit_and */
EIF_NATURAL_8 F1205_9879 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)tr1 = arg1;
	tr1 = F1204_9847(Current, tr1);
	Result = *(EIF_NATURAL_8 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_8}.bit_or */
EIF_NATURAL_8 F1205_9880 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)tr1 = arg1;
	tr1 = F1204_9848(Current, tr1);
	Result = *(EIF_NATURAL_8 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_8}.bit_not */
EIF_NATURAL_8 F1205_9882 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return *(EIF_NATURAL_8 *)F1204_9850(Current);
}

/* {NATURAL_8}.bit_shift_left */
EIF_NATURAL_8 F1205_9883 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return *(EIF_NATURAL_8 *)F1204_9852(Current, arg1);
}

/* {NATURAL_8}.bit_shift_right */
EIF_NATURAL_8 F1205_9884 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return *(EIF_NATURAL_8 *)F1204_9853(Current, arg1);
}

void EIF_Minit533 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
