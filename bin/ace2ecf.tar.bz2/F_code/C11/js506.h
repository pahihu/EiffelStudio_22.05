
#ifndef _C11_js506_
#define _C11_js506_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1179_9041(EIF_REFERENCE);
extern EIF_REFERENCE F1179_9042(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 9045)


extern EIF_REFERENCE F1179_9045(EIF_REFERENCE);
extern void EIF_Minit506(void);
extern char *(*R6231[])();

#ifdef __cplusplus
}
#endif

#endif
