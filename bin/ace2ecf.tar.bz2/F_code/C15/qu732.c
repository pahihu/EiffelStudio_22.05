/*
 * Code for class QUICK_SORTER [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "qu732.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {QUICK_SORTER}.subsort_with_comparator */
void F162_2130 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc11);
	RTLR(1,Current);
	RTLR(2,loc12);
	RTLR(3,loc7);
	RTLR(4,arg1);
	RTLR(5,loc8);
	RTLR(6,arg2);
	RTLR(7,tr1);
	RTLR(8,tr2);
	RTLR(9,loc6);
	RTLR(10,tr3);
	RTLIU(11);
	
	RTGC;
	loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg4 - arg3) + ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 0L))) break;
		loc5 /= ((EIF_INTEGER_32) 2L);
		loc4++;
	}
	loc4 += ((EIF_INTEGER_32) 10L);
	{
		static EIF_TYPE_INDEX typarr0[] = {823,1187,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc11 = RTLNS(typres0.id, 823, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F824_6183(RTCW(loc11), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), loc4);
	{
		static EIF_TYPE_INDEX typarr0[] = {823,1187,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc12 = RTLNS(typres0.id, 823, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F824_6183(RTCW(loc12), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), loc4);
	F824_6207(RTCW(loc11), arg3, ((EIF_INTEGER_32) 1L));
	F824_6207(RTCW(loc12), arg4, ((EIF_INTEGER_32) 1L));
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) break;
		loc9 = F824_6188(RTCW(loc11), loc4);
		loc10 = F824_6188(RTCW(loc12), loc4);
		loc4--;
		loc1 = (EIF_INTEGER_32) loc9;
		loc2 = (EIF_INTEGER_32) loc10;
		if ((EIF_BOOLEAN) (loc1 < loc2)) {
			if ((EIF_BOOLEAN)(loc2 == (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)))) {
				loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4927[Dtype(RTCW(arg1))-821])(arg1, (EIF_REFERENCE) &loc1);
				loc8 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4927[Dtype(RTCW(arg1))-821])(arg1, (EIF_REFERENCE) &loc2);
				tr1 = RTCCL(loc8);
				tr2 = RTCCL(loc7);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2517[Dtype(RTCW(arg2))-236])(arg2, tr1, tr2);
				if (tb1) {
					tr1 = RTCCL(loc7);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4930[Dtype(RTCW(arg1))-795])(arg1, tr1, (EIF_REFERENCE) &loc2);
					tr1 = RTCCL(loc8);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4930[Dtype(RTCW(arg1))-795])(arg1, tr1, (EIF_REFERENCE) &loc1);
				}
			} else {
				loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc2) / ((EIF_INTEGER_32) 2L));
				loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4927[Dtype(RTCW(arg1))-821])(arg1, (EIF_REFERENCE) &loc3);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4927[Dtype(RTCW(arg1))-821])(arg1, (EIF_REFERENCE) &loc10);
				tr2 = RTCCL(tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4930[Dtype(RTCW(arg1))-795])(arg1, tr2, (EIF_REFERENCE) &loc3);
				for (;;) {
					if ((EIF_BOOLEAN) (loc1 >= loc2)) break;
					for (;;) {
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (loc1 >= loc2)) {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4927[Dtype(RTCW(arg1))-821])(arg1, (EIF_REFERENCE) &loc1);
							tr2 = RTCCL(tr1);
							tr3 = RTCCL(loc6);
							tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2517[Dtype(RTCW(arg2))-236])(arg2, tr2, tr3);
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) break;
						loc1++;
					}
					loc2--;
					for (;;) {
						tb2 = '\01';
						if (!(EIF_BOOLEAN) (loc2 <= loc1)) {
							tr1 = RTCCL(loc6);
							tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4927[Dtype(RTCW(arg1))-821])(arg1, (EIF_REFERENCE) &loc2);
							tr3 = RTCCL(tr2);
							tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2517[Dtype(RTCW(arg2))-236])(arg2, tr1, tr3);
							tb2 = (EIF_BOOLEAN) !tb3;
						}
						if (tb2) break;
						loc2--;
					}
					if ((EIF_BOOLEAN) (loc1 < loc2)) {
						loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4927[Dtype(RTCW(arg1))-821])(arg1, (EIF_REFERENCE) &loc1);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4927[Dtype(RTCW(arg1))-821])(arg1, (EIF_REFERENCE) &loc2);
						tr2 = RTCCL(tr1);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4930[Dtype(RTCW(arg1))-795])(arg1, tr2, (EIF_REFERENCE) &loc1);
						tr1 = RTCCL(loc7);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4930[Dtype(RTCW(arg1))-795])(arg1, tr1, (EIF_REFERENCE) &loc2);
						loc1++;
					}
				}
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4927[Dtype(RTCW(arg1))-821])(arg1, (EIF_REFERENCE) &loc1);
				tr2 = RTCCL(tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4930[Dtype(RTCW(arg1))-795])(arg1, tr2, (EIF_REFERENCE) &loc10);
				tr1 = RTCCL(loc6);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4930[Dtype(RTCW(arg1))-795])(arg1, tr1, (EIF_REFERENCE) &loc1);
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)) > loc9)) {
					loc4++;
					F824_6209(RTCW(loc11), loc9, loc4);
					F824_6209(RTCW(loc12), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)), loc4);
				}
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) < loc10)) {
					loc4++;
					F824_6209(RTCW(loc11), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), loc4);
					F824_6209(RTCW(loc12), loc10, loc4);
				}
			}
		}
	}
	RTLE;
}

void EIF_Minit732 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
