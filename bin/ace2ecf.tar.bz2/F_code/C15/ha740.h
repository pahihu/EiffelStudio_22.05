
#ifndef _C15_ha740_
#define _C15_ha740_

#ifdef __cplusplus
extern "C" {
#endif

extern void F796_6012(EIF_REFERENCE, EIF_INTEGER_32);
extern void F796_6013(EIF_REFERENCE, EIF_INTEGER_32);
extern void F796_6015(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F796_6016(EIF_REFERENCE);
extern EIF_REFERENCE F796_6018(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F796_6020(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F796_6023(EIF_REFERENCE);
extern EIF_REFERENCE F796_6024(EIF_REFERENCE);
extern EIF_REFERENCE F796_6025(EIF_REFERENCE);
extern EIF_REFERENCE F796_6027(EIF_REFERENCE);
extern EIF_REFERENCE F796_6028(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F796_6029(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F796_6030(EIF_REFERENCE);
extern EIF_INTEGER_32 F796_6033(EIF_REFERENCE);
extern EIF_INTEGER_32 F796_6034(EIF_REFERENCE);
extern EIF_BOOLEAN F796_6035(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F796_6036(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F796_6039(EIF_REFERENCE);
extern EIF_BOOLEAN F796_6041(EIF_REFERENCE);
extern EIF_BOOLEAN F796_6044(EIF_REFERENCE);
extern EIF_BOOLEAN F796_6045(EIF_REFERENCE);
extern EIF_BOOLEAN F796_6046(EIF_REFERENCE);
extern EIF_BOOLEAN F796_6047(EIF_REFERENCE);
extern EIF_BOOLEAN F796_6050(EIF_REFERENCE, EIF_INTEGER_32);
extern void F796_6051(EIF_REFERENCE);
extern void F796_6052(EIF_REFERENCE);
extern void F796_6054(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F796_6056(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F796_6057(EIF_REFERENCE, EIF_INTEGER_32);
extern void F796_6058(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F796_6059(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F796_6060(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F796_6063(EIF_REFERENCE, EIF_REFERENCE);
extern void F796_6064(EIF_REFERENCE, EIF_REFERENCE);
extern void F796_6066(EIF_REFERENCE);
extern EIF_REFERENCE F796_6068(EIF_REFERENCE);
extern void F796_6069(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F796_6070(EIF_REFERENCE, EIF_INTEGER_32);
extern void F796_6071(EIF_REFERENCE);
extern EIF_INTEGER_32 F796_6080(EIF_REFERENCE);
extern EIF_BOOLEAN F796_6081(EIF_REFERENCE);
extern EIF_REFERENCE F796_6088(EIF_REFERENCE);
extern EIF_REFERENCE F796_6089(EIF_REFERENCE);
extern EIF_INTEGER_32 F796_6090(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F796_6091(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F796_6092(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F796_6093(EIF_REFERENCE, EIF_INTEGER_32);
extern void F796_6094(EIF_REFERENCE, EIF_REFERENCE);
extern void F796_6096(EIF_REFERENCE, EIF_REFERENCE);
extern void F796_6097(EIF_REFERENCE, EIF_REFERENCE);
extern void F796_6098(EIF_REFERENCE, EIF_REFERENCE);
extern void F796_6102(EIF_REFERENCE, EIF_REFERENCE);
extern void F796_6103(EIF_REFERENCE, EIF_REFERENCE);
extern void F796_6108(EIF_REFERENCE);
extern void F796_6121(EIF_REFERENCE);
extern void F796_6123(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit740(void);
extern void F1110_8743(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1111_8733(EIF_REFERENCE);
extern void F437_5229(EIF_REFERENCE);
extern void F1111_8722(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F1111_8743(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1111_8740(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_REFERENCE F437_5230(EIF_REFERENCE);
extern void F1110_8722(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F705_5573(EIF_REFERENCE, EIF_INTEGER_32);
RTOSHF(EIF_REFERENCE,5230)
extern char *(*R5256[])();
extern char *(*R7381[])();
extern char *(*R7348[])();
extern char *(*R5250[])();
extern char *(*R5294[])();
extern char *(*R4750[])();
extern char *(*R5359[])();
extern char *(*R5297[])();
extern char *(*R7347[])();
extern char *(*R5299[])();
extern char *(*R5257[])();
extern char *(*R5296[])();
extern char *(*R5259[])();
extern char *(*R5295[])();
extern char *(*R5305[])();
extern char *(*R5293[])();
extern char *(*R5324[])();
extern char *(*R7375[])();
extern char *(*R5262[])();
extern char *(*R5263[])();
extern char *(*R5265[])();
extern char *(*R5267[])();
extern char *(*R5268[])();
extern char *(*R6231[])();
extern char *(*R5300[])();
extern char *(*R5301[])();
extern char *(*R4751[])();
extern char *(*R4846[])();
extern char *(*R4752[])();
extern char *(*R4921[])();
extern char *(*R4849[])();
extern char *(*R5246[])();
extern char *(*R5283[])();
extern char *(*R5274[])();
extern char *(*R5311[])();
extern char *(*R4891[])();
extern char *(*R5236[])();
extern char *(*R4895[])();
extern char *(*R5239[])();
extern char *(*R4930[])();
extern char *(*R4931[])();
extern char *(*R5435[])();
extern char *(*R4781[])();
extern char *(*R5284[])();
extern char *(*R4766[])();
extern char *(*R5360[])();
extern char *(*R5245[])();
extern char *(*R5231[])();
extern char *(*R7361[])();
extern char *(*R5248[])();
extern char *(*R7362[])();
extern char *(*R5306[])();
extern char *(*R5240[])();
extern long O5276[];
extern long O5277[];
extern long O5278[];
extern long O5279[];
extern long O5280[];
extern long O5281[];
extern long O5282[];
extern long O5240[];
extern long O5285[];
extern long O5286[];
extern long O5249[];
extern long O5326[];
extern long O4893[];
extern long O5290[];
extern long O5291[];
extern long O5292[];
extern EIF_TYPE_INDEX Y5276[];
extern EIF_TYPE_INDEX *Y5276_gen_type [];
extern EIF_TYPE_INDEX Y5277[];
extern EIF_TYPE_INDEX *Y5277_gen_type [];
extern EIF_TYPE_INDEX Y4932[];
extern EIF_TYPE_INDEX *Y4932_gen_type [];
extern EIF_TYPE_INDEX Y4782[];
extern EIF_TYPE_INDEX *Y4782_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
