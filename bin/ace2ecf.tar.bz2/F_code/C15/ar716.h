
#ifndef _C15_ar716_
#define _C15_ar716_

#ifdef __cplusplus
extern "C" {
#endif

extern void F528_5401(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F528_5402(EIF_REFERENCE);
extern EIF_REFERENCE F528_5403(EIF_REFERENCE);
extern EIF_REFERENCE F528_5405(EIF_REFERENCE);
extern EIF_INTEGER_32 F528_5406(EIF_REFERENCE);
extern void EIF_Minit716(void);
extern EIF_TYPE_INDEX Y4753[];
extern EIF_TYPE_INDEX *Y4753_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
