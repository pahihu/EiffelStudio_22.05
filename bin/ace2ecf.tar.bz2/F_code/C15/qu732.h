
#ifndef _C15_qu732_
#define _C15_qu732_

#ifdef __cplusplus
extern "C" {
#endif

extern void F162_2130(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit732(void);
extern void F824_6207(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F824_6188(EIF_REFERENCE, EIF_INTEGER_32);
extern void F824_6209(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F824_6183(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R2517[])();
extern char *(*R4927[])();
extern char *(*R4930[])();

#ifdef __cplusplus
}
#endif

#endif
