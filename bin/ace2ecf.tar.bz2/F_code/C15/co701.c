/*
 * Code for class COLLECTION [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co701.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COLLECTION}.fill */
void F601_5467 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4897[Dtype(RTCW(arg1))-703])(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4901[Dtype(RTCW(loc1))-703])(loc1);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4917[dtype-703])(Current)) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4900[Dtype(RTCW(loc1))-703])(loc1);
			tb1 = tb2;
		}
		if (tb1) break;
		ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4899[Dtype(RTCW(loc1))-703])(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4921[dtype-703])(Current, (EIF_REFERENCE) &ti4_1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4914[Dtype(RTCW(loc1))-703])(loc1);
	}
	RTLE;
}

void EIF_Minit701 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
