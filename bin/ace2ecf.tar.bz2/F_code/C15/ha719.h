
#ifndef _C15_ha719_
#define _C15_ha719_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F494_5357(EIF_REFERENCE);
extern EIF_INTEGER_32 F494_5358(EIF_REFERENCE);
extern EIF_BOOLEAN F494_5360(EIF_REFERENCE);
extern void F494_5361(EIF_REFERENCE);
extern EIF_REFERENCE F494_5362(EIF_REFERENCE);
extern void EIF_Minit719(void);
extern char *(*R5267[])();
extern char *(*R5268[])();
extern char *(*R4843[])();
extern char *(*R5231[])();
extern long O5276[];
extern long O5277[];

#ifdef __cplusplus
}
#endif

#endif
