
#ifndef _C15_ch710_
#define _C15_ch710_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F841_6244(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F841_6246(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F841_6249(EIF_REFERENCE);
extern EIF_BOOLEAN F841_6254(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F841_6255(EIF_REFERENCE);
extern EIF_BOOLEAN F841_6256(EIF_REFERENCE);
extern EIF_BOOLEAN F841_6257(EIF_REFERENCE);
extern void F841_6260(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F841_6261(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit710(void);
extern EIF_BOOLEAN F707_5583(EIF_REFERENCE);
extern EIF_BOOLEAN F577_5448(EIF_REFERENCE);
extern EIF_BOOLEAN F577_5442(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R4940[])();
extern char *(*R4942[])();
extern char *(*R4901[])();
extern char *(*R4908[])();
extern char *(*R4997[])();
extern char *(*R4913[])();
extern char *(*R4914[])();
extern char *(*R4921[])();
extern char *(*R4934[])();
extern char *(*R4938[])();
extern char *(*R5401[])();

#ifdef __cplusplus
}
#endif

#endif
