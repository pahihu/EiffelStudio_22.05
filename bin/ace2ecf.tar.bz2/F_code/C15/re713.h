
#ifndef _C15_re713_
#define _C15_re713_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F731_5589(EIF_REFERENCE);
extern void F731_5591(EIF_REFERENCE);
extern void EIF_Minit713(void);
extern char *(*R4998[])();
extern char *(*R5004[])();

#ifdef __cplusplus
}
#endif

#endif
