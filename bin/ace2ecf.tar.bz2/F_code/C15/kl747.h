
#ifndef _C15_kl747_
#define _C15_kl747_

#ifdef __cplusplus
extern "C" {
#endif

extern void F955_7061(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit747(void);
extern void F825_6212(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
