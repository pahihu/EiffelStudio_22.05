
#ifndef _C15_co701_
#define _C15_co701_

#ifdef __cplusplus
extern "C" {
#endif

extern void F601_5467(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit701(void);
extern char *(*R4900[])();
extern char *(*R4901[])();
extern char *(*R4914[])();
extern char *(*R4917[])();
extern char *(*R4921[])();
extern char *(*R4897[])();
extern char *(*R4899[])();

#ifdef __cplusplus
}
#endif

#endif
