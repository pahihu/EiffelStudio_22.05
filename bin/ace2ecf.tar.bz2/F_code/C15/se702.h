
#ifndef _C15_se702_
#define _C15_se702_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F749_5638(EIF_REFERENCE);
extern void F749_5640(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit702(void);
extern char *(*R4900[])();
extern char *(*R4921[])();

#ifdef __cplusplus
}
#endif

#endif
