
#ifndef _C15_bi703_
#define _C15_bi703_

#ifdef __cplusplus
extern "C" {
#endif

extern void F589_5461(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit703(void);
extern EIF_BOOLEAN F707_5583(EIF_REFERENCE);
extern void F577_5444(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R4914[])();
extern char *(*R4915[])();

#ifdef __cplusplus
}
#endif

#endif
