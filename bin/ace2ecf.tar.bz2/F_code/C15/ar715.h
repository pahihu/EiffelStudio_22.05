
#ifndef _C15_ar715_
#define _C15_ar715_

#ifdef __cplusplus
extern "C" {
#endif

extern void F514_5383(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F514_5384(EIF_REFERENCE);
extern EIF_REFERENCE F514_5385(EIF_REFERENCE);
extern EIF_REFERENCE F514_5387(EIF_REFERENCE);
extern EIF_INTEGER_32 F514_5388(EIF_REFERENCE);
extern void EIF_Minit715(void);
extern EIF_INTEGER_32 F894_6385(EIF_REFERENCE);
extern EIF_REFERENCE F894_6366(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4753[];
extern EIF_TYPE_INDEX *Y4753_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
