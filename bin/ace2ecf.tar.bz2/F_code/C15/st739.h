
#ifndef _C15_st739_
#define _C15_st739_

#ifdef __cplusplus
extern "C" {
#endif

extern void F805_6136(EIF_REFERENCE, EIF_INTEGER_32);
extern void F805_6137(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F805_6138(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F805_6140(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F805_6141(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F805_6142(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit739(void);
extern EIF_BOOLEAN F796_6035(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1048_7727(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1048_7695(EIF_REFERENCE);
extern char *(*R5337[])();
extern char *(*R6231[])();
extern char *(*R6596[])();
extern char *(*R5236[])();
extern char *(*R5237[])();
extern char *(*R4895[])();
extern long O4893[];
extern long O5339[];

#ifdef __cplusplus
}
#endif

#endif
