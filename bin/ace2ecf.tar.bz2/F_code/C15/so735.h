
#ifndef _C15_so735_
#define _C15_so735_

#ifdef __cplusplus
extern "C" {
#endif

extern void F161_2115(EIF_REFERENCE, EIF_REFERENCE);
extern void F161_2124(EIF_REFERENCE, EIF_REFERENCE);
extern void F161_2126(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit735(void);
extern void F162_2130(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R5232[])();
extern char *(*R5233[])();
extern char *(*R4891[])();

#ifdef __cplusplus
}
#endif

#endif
