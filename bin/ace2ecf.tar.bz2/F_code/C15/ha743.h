
#ifndef _C15_ha743_
#define _C15_ha743_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F493_5357(EIF_REFERENCE);
extern EIF_REFERENCE F493_5358(EIF_REFERENCE);
extern EIF_BOOLEAN F493_5360(EIF_REFERENCE);
extern void F493_5361(EIF_REFERENCE);
extern EIF_REFERENCE F493_5362(EIF_REFERENCE);
extern void EIF_Minit743(void);
extern char *(*R7347[])();
extern char *(*R5267[])();
extern char *(*R5268[])();
extern char *(*R4843[])();
extern char *(*R5231[])();
extern long O5276[];
extern long O5277[];

#ifdef __cplusplus
}
#endif

#endif
