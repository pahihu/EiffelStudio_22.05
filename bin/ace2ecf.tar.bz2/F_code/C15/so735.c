/*
 * Code for class SORTER [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "so735.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SORTER}.make */
void F161_2115 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {SORTER}.sort */
void F161_2124 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F161_2126(Current, arg1, *(EIF_REFERENCE *)(Current));
}

/* {SORTER}.sort_with_comparator */
void F161_2126 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4891[Dtype(RTCW(arg1))-703])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5232[Dtype(RTCW(arg1))-795])(arg1);
		ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5233[Dtype(RTCW(arg1))-795])(arg1);
		F162_2130(Current, arg1, arg2, ti4_1, ti4_2);
	}
	RTLE;
}

void EIF_Minit735 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
