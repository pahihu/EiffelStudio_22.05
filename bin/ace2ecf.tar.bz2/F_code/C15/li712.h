
#ifndef _C15_li712_
#define _C15_li712_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F865_6280(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F865_6281(EIF_REFERENCE);
extern EIF_BOOLEAN F865_6282(EIF_REFERENCE);
extern void EIF_Minit712(void);
extern EIF_BOOLEAN F707_5583(EIF_REFERENCE);
extern char *(*R4940[])();
extern char *(*R4942[])();
extern char *(*R4901[])();
extern char *(*R4908[])();
extern char *(*R4997[])();
extern char *(*R4912[])();
extern char *(*R4914[])();
extern char *(*R4934[])();
extern long O4893[];

#ifdef __cplusplus
}
#endif

#endif
