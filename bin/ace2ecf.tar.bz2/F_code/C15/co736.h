
#ifndef _C15_co736_
#define _C15_co736_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F237_2884(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit736(void);
extern char *(*R3725[])();

#ifdef __cplusplus
}
#endif

#endif
