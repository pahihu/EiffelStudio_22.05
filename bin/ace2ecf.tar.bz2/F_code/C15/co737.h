
#ifndef _C15_co737_
#define _C15_co737_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F236_2880(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F236_2883(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit737(void);
extern char *(*R2517[])();

#ifdef __cplusplus
}
#endif

#endif
