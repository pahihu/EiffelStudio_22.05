
#ifndef _C15_dy706_
#define _C15_dy706_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F853_6266(EIF_REFERENCE);
extern void EIF_Minit706(void);

#ifdef __cplusplus
}
#endif

#endif
