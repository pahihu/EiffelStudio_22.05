
#ifndef _C15_to704_
#define _C15_to704_

#ifdef __cplusplus
extern "C" {
#endif

extern void F380_4730(EIF_REFERENCE, EIF_INTEGER_32);
extern void F380_4731(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F380_4737(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit704(void);
extern void F1110_8722(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4324[];
extern EIF_TYPE_INDEX *Y4324_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
