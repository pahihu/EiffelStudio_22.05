
#ifndef _C7_ir341_
#define _C7_ir341_

#ifdef __cplusplus
extern "C" {
#endif

extern void F403_4971(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F403_4972(EIF_REFERENCE);
extern void EIF_Minit341(void);
extern void F404_4976(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
