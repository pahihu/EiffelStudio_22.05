/*
 * Code for class KL_IMPORTED_ARRAY_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl336.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_IMPORTED_ARRAY_ROUTINES}.integer_array_ */
static EIF_REFERENCE F398_4920_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4920);
#define Result RTOSR(4920)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {956,1187,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 956, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (4920);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F398_4920 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4920,F398_4920_body,(Current));
}

void EIF_Minit336 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
