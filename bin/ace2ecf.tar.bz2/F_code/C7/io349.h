
#ifndef _C7_io349_
#define _C7_io349_

#ifdef __cplusplus
extern "C" {
#endif

extern void F411_5145(EIF_REFERENCE);
extern void EIF_Minit349(void);
extern void F772_5733(EIF_REFERENCE);
extern EIF_BOOLEAN F772_5705(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
