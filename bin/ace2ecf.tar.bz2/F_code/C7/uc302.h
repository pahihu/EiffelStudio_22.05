
#ifndef _C7_uc302_
#define _C7_uc302_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,4214)
static EIF_REFERENCE F352_4214_body(EIF_REFERENCE);
extern EIF_REFERENCE F352_4214(EIF_REFERENCE);
extern void EIF_Minit302(void);

#ifdef __cplusplus
}
#endif

#endif
