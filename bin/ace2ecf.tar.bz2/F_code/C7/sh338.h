
#ifndef _C7_sh338_
#define _C7_sh338_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,4941)
static EIF_REFERENCE F400_4941_body(EIF_REFERENCE);
extern EIF_REFERENCE F400_4941(EIF_REFERENCE);
extern void EIF_Minit338(void);

#ifdef __cplusplus
}
#endif

#endif
