/*
 * Code for class CONF_VALIDITY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co315.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_VALIDITY}.valid_platform */
EIF_BOOLEAN F365_4575 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(4598,F365_4598, (Current));
	Result = F797_6020(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.valid_build */
EIF_BOOLEAN F365_4576 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(4599,F365_4599, (Current));
	Result = F797_6020(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.valid_concurrency */
EIF_BOOLEAN F365_4577 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(4600,F365_4600, (Current));
	Result = F797_6020(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.valid_void_safety */
EIF_BOOLEAN F365_4578 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(4601,F365_4601, (Current));
	Result = F797_6020(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.valid_warning */
EIF_BOOLEAN F365_4580 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\01';
	tb4 = '\0';
	tr1 = RTOSCF(4505,F360_4505, (Current));
	if (F360_4514(Current, arg2, tr1)) {
		tr1 = RTOSCF(4613,F365_4613, (Current));
		tb5 = F801_6018(RTCW(tr1), arg1);
		tb4 = tb5;
	}
	if (!tb4) {
		tb4 = '\0';
		tr1 = RTOSCF(4499,F360_4499, (Current));
		tr2 = RTOSCF(4503,F360_4503, (Current));
		if (F360_4515(Current, arg2, tr1, tr2)) {
			tr1 = RTOSCF(4612,F365_4612, (Current));
			tb5 = F801_6018(RTCW(tr1), arg1);
			tb4 = tb5;
		}
		tb3 = tb4;
	}
	if (!tb3) {
		tb3 = '\0';
		tr1 = RTOSCF(4497,F360_4497, (Current));
		tr2 = RTOSCF(4497,F360_4497, (Current));
		if (F360_4515(Current, arg2, tr1, tr2)) {
			tr1 = RTOSCF(4611,F365_4611, (Current));
			tb4 = F801_6018(RTCW(tr1), arg1);
			tb3 = tb4;
		}
		tb2 = tb3;
	}
	if (!tb2) {
		tb2 = '\0';
		tr1 = RTOSCF(4483,F360_4483, (Current));
		tr2 = RTOSCF(4495,F360_4495, (Current));
		if (F360_4515(Current, arg2, tr1, tr2)) {
			tr1 = RTOSCF(4610,F365_4610, (Current));
			tb3 = F801_6018(RTCW(tr1), arg1);
			tb2 = tb3;
		}
		tb1 = tb2;
	}
	if (!tb1) {
		tb1 = '\0';
		tr1 = RTOSCF(4481,F360_4481, (Current));
		if (F360_4513(Current, arg2, tr1)) {
			tr1 = RTOSCF(4609,F365_4609, (Current));
			tb2 = F801_6018(RTCW(tr1), arg1);
			tb1 = tb2;
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.regexp_error */
EIF_REFERENCE F365_4582 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	struct eif_ex_60 sloc2;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) sloc2.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc2.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc2.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc2.overhead, eif_new_type(66, 0x00).id);
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLR(5,tr2);
	RTLR(6,Result);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = RTLNS(eif_new_type(1289, 0x00).id, 1289, _OBJSIZ_11_16_0_25_0_0_0_0_);
		F1290_12046(RTCW(loc1));
		tr1 = F67_1011(RTCW(loc2), arg1);
		F1290_12049(RTCW(loc1), tr1);
		tb1 = F1289_11967(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,996,1052,1187,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr1 = RTLNTS(typres0.id, 3, 0);
			}
			tr2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
			((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
			RTAR(tr1,tr2);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_11_16_0_14_);
			((EIF_TYPED_VALUE *)tr1+2)->it_i4 = ti4_1;
			Result = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.is_setting_known */
EIF_BOOLEAN F365_4583 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6567[Dtype(RTCW(arg1))-1051])(arg1);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTOSCF(4615,F365_4615, (Current));
		tr2 = F1048_7738(RTCW(arg1));
		tb1 = F1227_10227(RTCW(tr1), tr2);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.valid_setting */
EIF_BOOLEAN F365_4585 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6567[Dtype(RTCW(arg1))-1051])(arg1);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = F1048_7738(RTCW(arg1));
		Result = '\01';
		tb1 = '\01';
		tb2 = '\0';
		tr1 = RTOSCF(4499,F360_4499, (Current));
		if (F360_4514(Current, arg2, tr1)) {
			tr1 = RTOSCF(4618,F365_4618, (Current));
			tb3 = F1227_10227(RTCW(tr1), loc1);
			tb2 = tb3;
		}
		if (!tb2) {
			tb2 = '\0';
			tr1 = RTOSCF(4497,F360_4497, (Current));
			tr2 = RTOSCF(4497,F360_4497, (Current));
			if (F360_4515(Current, arg2, tr1, tr2)) {
				tr1 = RTOSCF(4617,F365_4617, (Current));
				tb3 = F1227_10227(RTCW(tr1), loc1);
				tb2 = tb3;
			}
			tb1 = tb2;
		}
		if (!tb1) {
			tb1 = '\0';
			tr1 = RTOSCF(4495,F360_4495, (Current));
			if (F360_4513(Current, arg2, tr1)) {
				tr1 = RTOSCF(4616,F365_4616, (Current));
				tb2 = F1227_10227(RTCW(tr1), loc1);
				tb1 = tb2;
			}
			Result = tb1;
		}
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.valid_version_type */
EIF_BOOLEAN F365_4586 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTOSCF(4614,F365_4614, (Current));
		tb1 = F801_6020(RTCW(tr1), arg1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.get_platform_name */
EIF_REFERENCE F365_4589 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("valid_platform", EX_CHECK);
	tr1 = RTOSCF(4598,F365_4598, (Current));
	tr1 = F797_6018(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.get_build_name */
EIF_REFERENCE F365_4590 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("valid_build", EX_CHECK);
	tr1 = RTOSCF(4599,F365_4599, (Current));
	tr1 = F797_6018(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.get_concurrency_name */
EIF_REFERENCE F365_4591 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("valid_index", EX_CHECK);
	tr1 = RTOSCF(4600,F365_4600, (Current));
	tr1 = F797_6018(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.get_void_safety_name */
EIF_REFERENCE F365_4592 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("valid_index", EX_CHECK);
	tr1 = RTOSCF(4601,F365_4601, (Current));
	tr1 = F797_6018(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.get_platform */
EIF_INTEGER_32 F365_4593 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		F797_6051(RTCV(RTOSCF(4598,F365_4598, (Current))));
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) {
				tb2 = F797_6046(RTCV(RTOSCF(4598,F365_4598, (Current))));
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = F797_6024(RTCV(RTOSCF(4598,F365_4598, (Current))));
			tb2 = F1048_7727(RTCW(arg1), tr1);
			if (tb2) {
				Result = F797_6025(RTCV(RTOSCF(4598,F365_4598, (Current))));
			}
			F797_6052(RTCV(RTOSCF(4598,F365_4598, (Current))));
		}
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.get_build */
EIF_INTEGER_32 F365_4594 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		F797_6051(RTCV(RTOSCF(4599,F365_4599, (Current))));
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) {
				tb2 = F797_6046(RTCV(RTOSCF(4599,F365_4599, (Current))));
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = F797_6024(RTCV(RTOSCF(4599,F365_4599, (Current))));
			tb2 = F1048_7727(RTCW(arg1), tr1);
			if (tb2) {
				Result = F797_6025(RTCV(RTOSCF(4599,F365_4599, (Current))));
			}
			F797_6052(RTCV(RTOSCF(4599,F365_4599, (Current))));
		}
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.get_concurrency */
EIF_INTEGER_32 F365_4595 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		F797_6051(RTCV(RTOSCF(4600,F365_4600, (Current))));
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) {
				tb2 = F797_6046(RTCV(RTOSCF(4600,F365_4600, (Current))));
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = F797_6024(RTCV(RTOSCF(4600,F365_4600, (Current))));
			tb2 = F1048_7727(RTCW(arg1), tr1);
			if (tb2) {
				Result = F797_6025(RTCV(RTOSCF(4600,F365_4600, (Current))));
			}
			F797_6052(RTCV(RTOSCF(4600,F365_4600, (Current))));
		}
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.get_void_safety */
EIF_INTEGER_32 F365_4596 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		F797_6051(RTCV(RTOSCF(4601,F365_4601, (Current))));
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) {
				tb2 = F797_6046(RTCV(RTOSCF(4601,F365_4601, (Current))));
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = F797_6024(RTCV(RTOSCF(4601,F365_4601, (Current))));
			tb2 = F1048_7727(RTCW(arg1), tr1);
			if (tb2) {
				Result = F797_6025(RTCV(RTOSCF(4601,F365_4601, (Current))));
			}
			F797_6052(RTCV(RTOSCF(4601,F365_4601, (Current))));
		}
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.platform_names */
static EIF_REFERENCE F365_4598_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4598);
#define Result RTOSR(4598)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {796,1052,1187,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 796, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F797_6012(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3910,F341_3910, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTOSCF(3911,F341_3911, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	tr1 = RTOSCF(3912,F341_3912, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 8L));
	tr1 = RTOSCF(3913,F341_3913, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 15L));
	RTOSE (4598);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4598 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4598,F365_4598_body,(Current));
}

/* {CONF_VALIDITY}.build_names */
static EIF_REFERENCE F365_4599_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4599);
#define Result RTOSR(4599)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {796,1052,1187,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 796, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F797_6012(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3916,F341_3916, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 256L));
	tr1 = RTOSCF(3917,F341_3917, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 512L));
	RTOSE (4599);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4599 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4599,F365_4599_body,(Current));
}

/* {CONF_VALIDITY}.concurrency_names */
static EIF_REFERENCE F365_4600_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4600);
#define Result RTOSR(4600)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {796,1052,1187,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 796, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F797_6012(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3921,F341_3921, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 2048L));
	tr1 = RTOSCF(3922,F341_3922, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 3840L));
	tr1 = RTOSCF(3923,F341_3923, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 4096L));
	RTOSE (4600);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4600 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4600,F365_4600_body,(Current));
}

/* {CONF_VALIDITY}.void_safety_names */
static EIF_REFERENCE F365_4601_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4601);
#define Result RTOSR(4601)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {796,1052,1187,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 796, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F797_6012(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3929,F341_3929, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 4352L));
	tr1 = RTOSCF(3930,F341_3930, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 4608L));
	tr1 = RTOSCF(3931,F341_3931, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 4864L));
	tr1 = RTOSCF(3932,F341_3932, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 5120L));
	tr1 = RTOSCF(3933,F341_3933, (Current));
	F797_6059(RTCW(Result), tr1, ((EIF_INTEGER_32) 5376L));
	RTOSE (4601);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4601 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4601,F365_4601_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_default */
static EIF_REFERENCE F365_4609_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4609);
#define Result RTOSR(4609)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {807,1007,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 807, _OBJSIZ_5_6_0_7_0_0_0_0_);
	}
	F801_6012(RTCW(tr1), ((EIF_INTEGER_32) 13L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3942,F341_3942, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3944,F341_3944, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3945,F341_3945, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3947,F341_3947, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3948,F341_3948, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3949,F341_3949, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3950,F341_3950, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3951,F341_3951, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3952,F341_3952, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3953,F341_3953, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3954,F341_3954, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3955,F341_3955, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3956,F341_3956, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (4609);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4609 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4609,F365_4609_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_1_10_0 */
static EIF_REFERENCE F365_4610_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4610);
#define Result RTOSR(4610)
	RTOC_NEW(Result);
	Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (RTOSCF(4609,F365_4609, (Current)));
	tr1 = RTOSCF(3943,F341_3943, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (4610);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4610 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4610,F365_4610_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_1_17_0 */
static EIF_REFERENCE F365_4611_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4611);
#define Result RTOSR(4611)
	RTOC_NEW(Result);
	Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (RTOSCF(4610,F365_4610, (Current)));
	tr1 = RTOSCF(3946,F341_3946, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (4611);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4611 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4611,F365_4611_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_1_18_0 */
static EIF_REFERENCE F365_4612_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4612);
#define Result RTOSR(4612)
	RTOC_NEW(Result);
	Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (RTOSCF(4611,F365_4611, (Current)));
	tr1 = RTOSCF(3946,F341_3946, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 0, tr1);
	RTOSE (4612);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4612 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4612,F365_4612_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_1_21_0 */
static EIF_REFERENCE F365_4613_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4613);
#define Result RTOSR(4613)
	RTOC_NEW(Result);
	Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (RTOSCF(4612,F365_4612, (Current)));
	tr1 = RTOSCF(3945,F341_3945, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 0, tr1);
	RTOSE (4613);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4613 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4613,F365_4613_body,(Current));
}

/* {CONF_VALIDITY}.valid_version_types */
static EIF_REFERENCE F365_4614_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4614);
#define Result RTOSR(4614)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {807,1007,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 807, _OBJSIZ_5_6_0_7_0_0_0_0_);
	}
	F801_6012(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3937,F341_3937, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3938,F341_3938, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (4614);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4614 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4614,F365_4614_body,(Current));
}

/* {CONF_VALIDITY}.known_settings */
static EIF_REFERENCE F365_4615_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4615);
#define Result RTOSR(4615)
	RTOC_NEW(Result);
	Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (RTOSCF(4617,F365_4617, (Current)));
	tr1 = RTOSCF(4618,F365_4618, (Current));
	F1227_10246(RTCW(Result), tr1);
	RTOSE (4615);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4615 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4615,F365_4615_body,(Current));
}

/* {CONF_VALIDITY}.valid_settings */
static EIF_REFERENCE F365_4616_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4616);
#define Result RTOSR(4616)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1226,1052,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1226, _OBJSIZ_4_1_0_5_0_0_0_0_);
	}
	F1227_10223(RTCW(tr1), ((EIF_INTEGER_32) 40L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3957,F341_3957, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3958,F341_3958, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3959,F341_3959, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3961,F341_3961, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3962,F341_3962, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3963,F341_3963, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3964,F341_3964, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3965,F341_3965, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3966,F341_3966, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3968,F341_3968, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3969,F341_3969, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3970,F341_3970, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3971,F341_3971, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3972,F341_3972, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3973,F341_3973, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3974,F341_3974, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3976,F341_3976, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3977,F341_3977, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3978,F341_3978, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3979,F341_3979, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3980,F341_3980, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3981,F341_3981, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3982,F341_3982, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3984,F341_3984, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3985,F341_3985, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3986,F341_3986, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3987,F341_3987, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3988,F341_3988, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3989,F341_3989, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3990,F341_3990, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3991,F341_3991, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3992,F341_3992, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3993,F341_3993, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3994,F341_3994, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3996,F341_3996, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3975,F341_3975, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3997,F341_3997, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3998,F341_3998, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3999,F341_3999, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(4000,F341_4000, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3995,F341_3995, (Current));
	F1227_10240(RTCW(Result), tr1);
	RTOSE (4616);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4616 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4616,F365_4616_body,(Current));
}

/* {CONF_VALIDITY}.valid_settings_1_17_0 */
static EIF_REFERENCE F365_4617_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4617);
#define Result RTOSR(4617)
	RTOC_NEW(Result);
	Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (RTOSCF(4616,F365_4616, (Current)));
	tr1 = RTOSCF(3960,F341_3960, (Current));
	F1227_10240(RTCW(Result), tr1);
	RTOSE (4617);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4617 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4617,F365_4617_body,(Current));
}

/* {CONF_VALIDITY}.valid_settings_1_18_0 */
static EIF_REFERENCE F365_4618_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4618);
#define Result RTOSR(4618)
	RTOC_NEW(Result);
	Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (RTOSCF(4617,F365_4617, (Current)));
	tr1 = RTOSCF(3985,F341_3985, (Current));
	F1227_10242(RTCW(Result), tr1);
	tr1 = RTOSCF(3983,F341_3983, (Current));
	F1227_10240(RTCW(Result), tr1);
	RTOSE (4618);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4618 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4618,F365_4618_body,(Current));
}

/* {CONF_VALIDITY}.boolean_settings */
static EIF_REFERENCE F365_4619_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4619);
#define Result RTOSR(4619)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {807,1007,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 807, _OBJSIZ_5_6_0_7_0_0_0_0_);
	}
	F801_6012(RTCW(tr1), ((EIF_INTEGER_32) 28L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3957,F341_3957, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3958,F341_3958, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3959,F341_3959, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3960,F341_3960, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3962,F341_3962, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3961,F341_3961, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3963,F341_3963, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3964,F341_3964, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3965,F341_3965, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3968,F341_3968, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3970,F341_3970, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3971,F341_3971, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3972,F341_3972, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3973,F341_3973, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3976,F341_3976, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3977,F341_3977, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3978,F341_3978, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3980,F341_3980, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3982,F341_3982, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3989,F341_3989, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3992,F341_3992, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3993,F341_3993, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3995,F341_3995, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3994,F341_3994, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3998,F341_3998, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4000,F341_4000, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(3999,F341_3999, (Current));
	F801_6059(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (4619);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4619 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4619,F365_4619_body,(Current));
}

/* {CONF_VALIDITY}.true_boolean_settings_1_19_0_and_below */
static EIF_REFERENCE F365_4620_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4620);
#define Result RTOSR(4620)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1226,1050,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1226, _OBJSIZ_4_1_0_5_0_0_0_0_);
	}
	F1227_10223(RTCW(tr1), ((EIF_INTEGER_32) 9L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3963,F341_3963, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3964,F341_3964, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3961,F341_3961, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3962,F341_3962, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3965,F341_3965, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3978,F341_3978, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3977,F341_3977, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(3999,F341_3999, (Current));
	F1227_10240(RTCW(Result), tr1);
	tr1 = RTOSCF(4000,F341_4000, (Current));
	F1227_10240(RTCW(Result), tr1);
	RTOSE (4620);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4620 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4620,F365_4620_body,(Current));
}

/* {CONF_VALIDITY}.true_boolean_settings_1_20_0_and_above */
static EIF_REFERENCE F365_4621_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4621);
#define Result RTOSR(4621)
	RTOC_NEW(Result);
	Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (RTOSCF(4620,F365_4620, (Current)));
	tr1 = RTOSCF(3998,F341_3998, (Current));
	F1227_10240(RTCW(Result), tr1);
	RTOSE (4621);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F365_4621 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4621,F365_4621_body,(Current));
}

/* {CONF_VALIDITY}.is_boolean_setting_true */
EIF_BOOLEAN F365_4622 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(4501,F360_4501, (Current));
	if (F360_4513(Current, arg2, tr1)) {
		tr1 = RTOSCF(4620,F365_4620, (Current));
	} else {
		tr1 = RTOSCF(4621,F365_4621, (Current));
	}
	Result = F1227_10227(RTCV(tr1), arg1);
	RTLE;
	return Result;
}

void EIF_Minit315 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
