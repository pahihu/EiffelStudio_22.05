
#ifndef _C7_co319_
#define _C7_co319_

#ifdef __cplusplus
extern "C" {
#endif

extern void F369_4675(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE);
extern void F369_4683(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit319(void);

#ifdef __cplusplus
}
#endif

#endif
