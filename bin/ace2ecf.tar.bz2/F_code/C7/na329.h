
#ifndef _C7_na329_
#define _C7_na329_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F391_4738(EIF_REFERENCE, EIF_POINTER);
extern EIF_NATURAL_64 F391_4739(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit329(void);

#ifdef __cplusplus
}
#endif

#endif
