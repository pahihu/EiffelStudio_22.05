/*
 * Code for class EXECUTION_ENVIRONMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ex334.h"
#include <stdlib.h>
#include "eif_path_name.h"
#include "eif_dir.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F396_4907
static EIF_POINTER inline_F396_4907 (EIF_POINTER arg1)
{
	#ifdef EIF_WINDOWS
	return _wgetenv ((EIF_NATIVE_CHAR *) arg1);
#else
	return getenv ((EIF_NATIVE_CHAR *) arg1);
#endif
	;
}
#define INLINE_F396_4907
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EXECUTION_ENVIRONMENT}.current_working_path */
EIF_REFERENCE F396_4881 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	loc3 = RTLNS(eif_new_type(336, 0x00).id, 336, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F337_3801(RTCW(loc3), loc1);
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	loc2 = (EIF_INTEGER_32) eif_dir_current((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) -1L))) {
		Result = RTLNS(eif_new_type(1072, 0x00).id, 1072, _OBJSIZ_2_1_0_0_0_0_0_0_);
		tr1 = RTMS_EX_H(".",1,46);
		F1073_8627(RTCW(Result), tr1);
	} else {
		if ((EIF_BOOLEAN) (loc2 > loc1)) {
			loc1 = (EIF_INTEGER_32) loc2;
			F337_3891(RTCW(loc3), loc1);
			tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
			loc2 = (EIF_INTEGER_32) eif_dir_current((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 <= loc1))) {
			Result = RTLNS(eif_new_type(1072, 0x00).id, 1072, _OBJSIZ_2_1_0_0_0_0_0_0_);
			tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
			F1073_8631(RTCW(Result), tp1);
		} else {
			Result = RTLNS(eif_new_type(1072, 0x00).id, 1072, _OBJSIZ_2_1_0_0_0_0_0_0_);
			tr1 = RTMS_EX_H(".",1,46);
			F1073_8627(RTCW(Result), tr1);
		}
	}
	RTLE;
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.item */
EIF_REFERENCE F396_4885 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(391, 0x00).id, 391, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F392_4740(RTCW(loc1), arg1);
	tp1 = F392_4747(RTCW(loc1));
	loc2 = inline_F396_4907(tp1);
	tb1 = !loc2;
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNS(eif_new_type(391, 0x00).id, 391, _OBJSIZ_1_0_0_1_0_0_0_0_);
		F392_4742(RTCW(tr1), loc2);
		Result = F392_4745(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.home_directory_path */
static EIF_REFERENCE F396_4886_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,loc3);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4886);
#define Result RTOSR(4886)
	RTOC_NEW(Result);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	loc3 = RTLNS(eif_new_type(336, 0x00).id, 336, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F337_3801(RTCW(loc3), loc1);
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	loc2 = (EIF_INTEGER_32) eif_home_directory_name_ptr((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
	if ((EIF_BOOLEAN) (loc2 > loc1)) {
		loc1 = (EIF_INTEGER_32) loc2;
		F337_3891(RTCW(loc3), loc1);
		tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
		loc2 = (EIF_INTEGER_32) eif_home_directory_name_ptr((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 <= loc1))) {
		tr1 = RTLNS(eif_new_type(1072, 0x00).id, 1072, _OBJSIZ_2_1_0_0_0_0_0_0_);
		tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
		F1073_8631(RTCW(tr1), tp1);
		Result = (EIF_REFERENCE) tr1;
	}
	RTOSE (4886);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4886 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4886,F396_4886_body,(Current));
}

/* {EXECUTION_ENVIRONMENT}.user_directory_path */
static EIF_REFERENCE F396_4887_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	

	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc4);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (4887);
#define Result RTOSR(4887)
	RTOC_NEW(Result);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	loc3 = RTLNS(eif_new_type(336, 0x00).id, 336, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F337_3801(RTCW(loc3), ((EIF_INTEGER_32) 50L));
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	loc2 = (EIF_INTEGER_32) eif_user_directory_name_ptr((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
	if ((EIF_BOOLEAN) (loc2 > loc1)) {
		loc1 = (EIF_INTEGER_32) loc2;
		F337_3891(RTCW(loc3), loc1);
		tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
		loc2 = (EIF_INTEGER_32) eif_user_directory_name_ptr((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 <= loc1))) {
		tr1 = RTLNS(eif_new_type(1072, 0x00).id, 1072, _OBJSIZ_2_1_0_0_0_0_0_0_);
		tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
		F1073_8631(RTCW(tr1), tp1);
		Result = (EIF_REFERENCE) tr1;
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN)(Result != NULL)) {
		tb2 = F1073_8635(RTCW(Result));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
	} else {
		tb1 = '\0';
		tb2 = (EIF_BOOLEAN) EIF_TEST(eif_home_dir_supported());
		if (tb2) {
			tr1 = RTOSCF(4886,F396_4886, (Current));
			loc4 = tr1;
			tb1 = EIF_TEST(loc4);
		}
		if (tb1) {
			Result = (EIF_REFERENCE) loc4;
		} else {
			Result = (EIF_REFERENCE) NULL;
		}
	}
	RTOSE (4887);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4887 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4887,F396_4887_body,(Current));
}

/* {EXECUTION_ENVIRONMENT}.eif_dir_current */
EIF_INTEGER_32 F396_4906 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_dir_current((EIF_FILENAME) arg1, (EIF_INTEGER) arg2);
	
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.eif_getenv */
EIF_POINTER F396_4907 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F396_4907 ((EIF_POINTER) arg1);
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.eif_home_directory_name_ptr */
EIF_INTEGER_32 F396_4912 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_home_directory_name_ptr((EIF_FILENAME) arg1, (EIF_INTEGER) arg2);
	
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.eif_user_directory_name_ptr */
EIF_INTEGER_32 F396_4913 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_user_directory_name_ptr((EIF_FILENAME) arg1, (EIF_INTEGER) arg2);
	
	return Result;
}

void EIF_Minit334 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
