
#ifndef _C7_co328_
#define _C7_co328_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_BOOLEAN,4729)
static EIF_BOOLEAN F378_4729_body(EIF_REFERENCE);
extern EIF_BOOLEAN F378_4729(EIF_REFERENCE);
extern void EIF_Minit328(void);

#ifdef __cplusplus
}
#endif

#endif
