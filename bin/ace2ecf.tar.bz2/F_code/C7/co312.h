
#ifndef _C7_co312_
#define _C7_co312_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F362_4547(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F362_4548(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit312(void);
extern EIF_BOOLEAN F360_4513(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F360_4514(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern long O4154[];

#ifdef __cplusplus
}
#endif

#endif
