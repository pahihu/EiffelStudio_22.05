/*
 * Code for class STRING_ENVIRONMENT_EXPANDER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st340.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STRING_ENVIRONMENT_EXPANDER}.use_environment_variables */
EIF_BOOLEAN F402_4968 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {STRING_ENVIRONMENT_EXPANDER}.variable_32 */
EIF_REFERENCE F402_4970 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (F402_4968(Current)) {
		if (F339_3897(Current)) {
			tr1 = F339_3899(Current);
			Result = F1303_12456(RTCW(tr1), arg1);
		} else {
			tr1 = RTOSCF(4941,F400_4941, (Current));
			Result = F396_4885(RTCW(tr1), arg1);
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit340 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
