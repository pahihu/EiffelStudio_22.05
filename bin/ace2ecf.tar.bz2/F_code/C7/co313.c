/*
 * Code for class CONF_LOAD_CALLBACKS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co313.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOAD_CALLBACKS}.on_error */
void F363_4555 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_26_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F363_4563(Current, arg1);
	RTLE;
}

/* {CONF_LOAD_CALLBACKS}.on_start */
void F363_4556 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
}

/* {CONF_LOAD_CALLBACKS}.on_finish */
void F363_4557 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
}

/* {CONF_LOAD_CALLBACKS}.set_internal_error */
void F363_4558 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_2_0_0_3_0_0_0_0_);
	tr1 = F1259_11409(RTCV(RTOSCF(3896,F338_3896, (Current))));
	F929_6827(RTCW(loc1), tr1);
	F929_6824(RTCW(loc1));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {CONF_LOAD_CALLBACKS}.is_valid_uuid */
EIF_BOOLEAN F363_4559 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_3_1_0_0_1_0_);
	tb1 = F1071_8471(RTCW(loc1), arg1);
	RTLE;
	return (EIF_BOOLEAN) tb1;
}

/* {CONF_LOAD_CALLBACKS}.check_version */
void F363_4560 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		tr1 = RTLNS(eif_new_type(932, 0x00).id, 932, _OBJSIZ_2_0_0_3_0_0_0_0_);
		F933_6836(RTCW(tr1));
		F363_4561(Current, tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
			tr1 = F360_4512(Current, arg1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		} else {
			tb1 = F1056_8011(RTCW(arg1), loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = RTLNS(eif_new_type(932, 0x00).id, 932, _OBJSIZ_2_0_0_3_0_0_0_0_);
				F933_6836(RTCW(tr1));
				F363_4561(Current, tr1);
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_CALLBACKS}.set_error */
void F363_4561 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	loc1 = RTLNS(eif_new_type(299, 0x00).id, 299, _OBJSIZ_5_1_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Parse error",11,62499698);
	F290_3679(RTCW(loc1), tr1);
	F290_3664(RTCW(loc1));
	RTLE;
}

/* {CONF_LOAD_CALLBACKS}.set_parse_error_message */
void F363_4563 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc1);
	RTLR(5,loc5);
	RTLR(6,loc3);
	RTLR(7,loc2);
	RTLIU(8);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_2_)) {
		tb2 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc4 = tr1;
		if (!((EIF_BOOLEAN) !EIF_TEST(loc4))) {
			tb2 = (EIF_BOOLEAN) !F360_4511(Current, loc4);
		}
		tb1 = tb2;
	}
	if (tb1) {
		F363_4564(Current, arg1);
	} else {
		loc1 = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_2_0_0_3_0_0_0_0_);
		F929_6827(RTCW(loc1), arg1);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			loc3 = F270_3432(loc5);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_0_0_2_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_0_0_1_);
			F929_6826(RTCW(loc1), tr1, ti4_1, ti4_2);
		}
		*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		loc2 = RTLNS(eif_new_type(299, 0x00).id, 299, _OBJSIZ_5_1_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("Parse error",11,62499698);
		F290_3679(RTCW(loc2), tr1);
		F290_3664(RTCW(loc2));
	}
	RTLE;
}

/* {CONF_LOAD_CALLBACKS}.set_parse_warning_message */
void F363_4564 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(928, 0x00).id, 928, _OBJSIZ_2_0_0_3_0_0_0_0_);
	F929_6827(RTCW(loc1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc2 = F270_3432(loc4);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_1_);
		F929_6826(RTCW(loc1), tr1, ti4_1, ti4_2);
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_26_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {892,917,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc3 = RTLNSMART(typres0.id);
		}
		F893_6362(RTCW(loc3), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc3;
	}
	F893_6402(RTCW(loc3), loc1);
	RTLE;
}

void EIF_Minit313 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
