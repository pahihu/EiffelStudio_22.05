/*
 * Code for class CONF_EXTERNAL_INCLUDE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co328.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_EXTERNAL_INCLUDE}.is_include */
static EIF_BOOLEAN F378_4729_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (4729);
#define Result RTOSR(4729)
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTOSE (4729);
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F378_4729 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4729,F378_4729_body,(Current));
}

void EIF_Minit328 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
