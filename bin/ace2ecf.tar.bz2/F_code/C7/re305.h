
#ifndef _C7_re305_
#define _C7_re305_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F355_4308(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit305(void);

#ifdef __cplusplus
}
#endif

#endif
