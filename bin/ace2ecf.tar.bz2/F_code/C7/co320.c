/*
 * Code for class CONF_FILE_RULE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co320.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_FILE_RULE}.make */
void F370_4684 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {CONF_FILE_RULE}.is_empty */
EIF_BOOLEAN F370_4685 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = '\0';
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc1 == NULL)) {
		tb2 = F1227_10229(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc2 == NULL)) {
			tb2 = F1227_10229(RTCW(loc2));
			tb1 = tb2;
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {CONF_FILE_RULE}.add_exclude */
void F370_4690 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1226,1057,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F1227_10223(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	}
	F1227_10239(RTCW(loc1), arg1);
	F370_4700(Current);
	RTLE;
}

/* {CONF_FILE_RULE}.add_include */
void F370_4691 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1226,1057,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F1227_10223(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	}
	F1227_10239(RTCW(loc1), arg1);
	F370_4700(Current);
	RTLE;
}

/* {CONF_FILE_RULE}.set_description */
void F370_4694 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {CONF_FILE_RULE}.is_equal */
EIF_BOOLEAN F370_4696 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	if (F1_10(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_), tr1)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		Result = F1_10(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), tr1);
	}
	RTLE;
	return Result;
}

/* {CONF_FILE_RULE}.ordered_exclude */
EIF_REFERENCE F370_4698 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = F1227_10251(loc1);
		tr1 = RTOSCF(4706,F370_4706, (Current));
		F161_2124(RTCW(tr1), Result);
	}
	RTLE;
	return Result;
}

/* {CONF_FILE_RULE}.ordered_include */
EIF_REFERENCE F370_4699 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = F1227_10251(loc1);
		tr1 = RTOSCF(4706,F370_4706, (Current));
		F161_2124(RTCW(tr1), Result);
	}
	RTLE;
	return Result;
}

/* {CONF_FILE_RULE}.compile */
void F370_4700 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	tr1 = F370_4701(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F370_4701(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) loc1;
	}
	RTLE;
}

/* {CONF_FILE_RULE}.compile_list */
EIF_REFERENCE F370_4701 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	struct eif_ex_60 sloc4;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) sloc4.data;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc4.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc4.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc4.overhead, eif_new_type(66, 0x00).id);
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,tr1);
	RTLR(7,Result);
	RTLIU(8);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = F1227_10229(RTCW(arg1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc1 = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1051_7815(RTCW(loc1), ((EIF_INTEGER_32) 50L));
		loc2 = RTMS_EX_H("(",1,40);
		loc3 = RTMS_EX_H(")|",2,10620);
		F1227_10270(RTCW(arg1));
		for (;;) {
			tb1 = F1227_10273(RTCW(arg1));
			if (tb1) break;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6737[Dtype(RTCW(loc1))-1052])(loc1, loc2);
			tr1 = F1227_10275(RTCW(arg1));
			F67_1012(RTCW(loc4), tr1, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6737[Dtype(RTCW(loc1))-1052])(loc1, loc3);
			F1227_10271(RTCW(arg1));
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6677[Dtype(RTCW(loc1))-1052])(loc1, ((EIF_INTEGER_32) 1L));
		Result = RTLNS(eif_new_type(1289, 0x00).id, 1289, _OBJSIZ_11_16_0_25_0_0_0_0_);
		F1290_12046(RTCW(Result));
		tb2 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b;
		F1289_11983(RTCW(Result), tb2);
		F1290_12049(RTCW(Result), loc1);
		tb2 = F1289_11967(RTCW(Result));
		if (tb2) {
			F1289_11998(RTCW(Result));
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_4_);
			tr1 = F1048_7744(RTCW(tr1));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
			RTLE;
			return (EIF_REFERENCE) NULL;
		}
	}
	RTLE;
	return Result;
}

/* {CONF_FILE_RULE}.sorter */
static EIF_REFERENCE F370_4706_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (4706);
#define Result RTOSR(4706)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {161,1047,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 161, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	tr2 = RTLNS(eif_new_type(237, 0x00).id, 237, _OBJSIZ_0_1_0_0_0_0_0_0_);
	F238_2885(RTCW(tr2));
	F161_2115(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (4706);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F370_4706 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4706,F370_4706_body,(Current));
}

void EIF_Minit320 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
