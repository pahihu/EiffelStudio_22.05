/*
 * Code for class CONF_CONDITIONED
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co318.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_CONDITIONED}.add_condition */
void F368_4672 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + O4276[dtype-367]);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = RTLNSMART(eif_new_type(907, 0).id);
		F908_6450(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O4276[dtype-367]) = (EIF_REFERENCE) loc1;
	}
	F893_6402(RTCW(loc1), arg1);
	RTLE;
}

/* {CONF_CONDITIONED}.set_conditions */
void F368_4673 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = F706_5583(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		*(EIF_REFERENCE *)(Current + O4276[dtype-367]) = (EIF_REFERENCE) NULL;
	} else {
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O4276[dtype-367]) = (EIF_REFERENCE) arg1;
	}
	RTLE;
}

void EIF_Minit318 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
