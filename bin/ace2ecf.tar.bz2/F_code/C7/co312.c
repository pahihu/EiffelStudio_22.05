/*
 * Code for class CONF_NAMESPACE_TESTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co312.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_NAMESPACE_TESTER}.includes_this_or_before */
EIF_BOOLEAN F362_4547 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F360_4513(Current, *(EIF_REFERENCE *)(Current + O4154[Dtype(Current)-361]), arg1);
}

/* {CONF_NAMESPACE_TESTER}.includes_this_or_after */
EIF_BOOLEAN F362_4548 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F360_4514(Current, *(EIF_REFERENCE *)(Current + O4154[Dtype(Current)-361]), arg1);
}

void EIF_Minit312 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
