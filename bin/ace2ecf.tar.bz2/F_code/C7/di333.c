/*
 * Code for class DIRECTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "di333.h"
#include "eif_dir.h"
#include "eif_file.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DIRECTORY}.make */
void F395_4820 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F395_4821(Current, arg1);
}

/* {DIRECTORY}.make_with_name */
void F395_4821 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F395_4857(Current, arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {DIRECTORY}.make_with_path */
void F395_4822 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = F1073_8666(RTCW(arg1));
	F395_4820(Current, tr1);
	RTLE;
}

/* {DIRECTORY}.make_open_read */
void F395_4823 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F395_4820(Current, arg1);
	F395_4830(Current);
	RTLE;
}

/* {DIRECTORY}.create_dir */
void F395_4824 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F395_4859(Current))+ _PTROFF_0_1_0_1_0_0_);
	eif_file_mkdir((EIF_FILENAME) tp1);
	RTLE;
}

/* {DIRECTORY}.recursive_create_dir */
void F395_4825 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLR(6,loc5);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTGC;
	loc3 = F1073_8648(RTCV(F395_4826(Current)));
	loc1 = RTLNS(eif_new_type(394, 0x00).id, 394, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F395_4822(RTCW(loc1), loc3);
	tb1 = F395_4845(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {892,1072,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc2 = RTLNS(typres0.id, 892, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F893_6362(RTCW(loc2), ((EIF_INTEGER_32) 10L));
		loc4 = F1073_8643(RTCW(loc3));
		for (;;) {
			tb1 = '\01';
			tb2 = F395_4845(RTCW(loc1));
			if (!tb2) {
				tb1 = (EIF_BOOLEAN)(loc4 == NULL);
			}
			if (tb1) break;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4921[Dtype(RTCW(loc2))-703])(loc2, loc3);
			tr1 = F1073_8642(RTCW(loc3));
			loc3 = (EIF_REFERENCE) tr1;
			loc4 = F1073_8643(RTCW(loc3));
			F395_4822(RTCW(loc1), loc3);
		}
		F893_6394(RTCW(loc2));
		for (;;) {
			tb2 = F864_6282(RTCW(loc2));
			if (tb2) break;
			loc3 = F893_6367(RTCW(loc2));
			F893_6396(RTCW(loc2));
			F395_4822(RTCW(loc1), loc3);
			F395_4824(RTCW(loc1));
			tb3 = F395_4845(RTCW(loc1));
			if ((EIF_BOOLEAN) !tb3) {
				loc5 = RTLNS(eif_new_type(313, 0x00).id, 313, _OBJSIZ_5_1_0_3_0_0_0_0_);
				tr1 = RTMS32_EX_H("C\000\000\000a\000\000\000n\000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000c\000\000\000r\000\000\000e\000\000\000a\000\000\000t\000\000\000e\000\000\000:\000\000\000 \000\000\000",15,2053611808);
				tr2 = F1073_8666(RTCW(loc3));
				tr1 = F1058_8118(tr1, tr2);
				F290_3679(RTCW(loc5), tr1);
				F290_3664(RTCW(loc5));
			}
		}
	}
	RTLE;
}

/* {DIRECTORY}.path */
EIF_REFERENCE F395_4826 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1072, 0x00).id, 1072, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tp1 = *(EIF_POINTER *)(RTCV(F395_4859(Current))+ _PTROFF_0_1_0_1_0_0_);
	F1073_8631(RTCW(Result), tp1);
	RTLE;
	return Result;
}

/* {DIRECTORY}.readentry */
void F395_4827 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_3_0_0_1_0_0_);
	tp1 = (EIF_POINTER) eif_dir_next(tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_3_0_0_1_0_1_) = (EIF_POINTER) tp1;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_3_0_0_1_0_1_) == tp1)) {
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = RTOSCF(4867,F395_4867, (Current));
		tr1 = F393_4780(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_3_0_0_1_0_1_));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {DIRECTORY}.open_read */
void F395_4830 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F395_4859(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (EIF_POINTER) eif_dir_open((EIF_FILENAME) tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_3_0_0_1_0_0_) = (EIF_POINTER) tp1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTLE;
}

/* {DIRECTORY}.close */
void F395_4831 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_3_0_0_1_0_0_);
	eif_dir_close(tp1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_3_0_0_1_0_0_) = (EIF_POINTER) tp2;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {DIRECTORY}.start */
void F395_4832 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_3_0_0_1_0_0_);
	tp2 = *(EIF_POINTER *)(RTCV(F395_4859(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (EIF_POINTER) eif_dir_rewind((EIF_POINTER) tp1, (EIF_FILENAME) tp2);
	*(EIF_POINTER *)(Current+ _PTROFF_3_0_0_1_0_0_) = (EIF_POINTER) tp1;
	RTLE;
}

/* {DIRECTORY}.entries */
EIF_REFERENCE F395_4836 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(394, 0x00).id, 394, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F395_4823(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	{
		static EIF_TYPE_INDEX typarr0[] = {892,1072,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 892, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F893_6362(RTCW(Result), ((EIF_INTEGER_32) 16L));
	F395_4832(RTCW(loc1));
	F395_4827(RTCW(loc1));
	loc2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_3_0_0_1_0_1_);
	for (;;) {
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc2 == tp1)) break;
		tr1 = RTLNS(eif_new_type(1072, 0x00).id, 1072, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1073_8631(RTCW(tr1), loc2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4921[Dtype(RTCW(Result))-703])(Result, tr1);
		F395_4827(RTCW(loc1));
		loc2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_3_0_0_1_0_1_);
	}
	F395_4831(RTCW(loc1));
	RTLE;
	return Result;
}

/* {DIRECTORY}.linear_representation_32 */
EIF_REFERENCE F395_4839 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(394, 0x00).id, 394, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F395_4823(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	{
		static EIF_TYPE_INDEX typarr0[] = {892,1057,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 892, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F893_6362(RTCW(Result), ((EIF_INTEGER_32) 16L));
	F395_4832(RTCW(loc1));
	F395_4827(RTCW(loc1));
	loc2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_3_0_0_1_0_1_);
	for (;;) {
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc2 == tp1)) break;
		loc3 = RTLNS(eif_new_type(1072, 0x00).id, 1072, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1073_8631(RTCW(loc3), loc2);
		tr1 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tr2 = F1073_8666(RTCW(loc3));
		F1056_7986(RTCW(tr1), tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4921[Dtype(RTCW(Result))-703])(Result, tr1);
		F395_4827(RTCW(loc1));
		loc2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_3_0_0_1_0_1_);
	}
	F395_4831(RTCW(loc1));
	RTLE;
	return Result;
}

/* {DIRECTORY}.is_closed */
EIF_BOOLEAN F395_4843 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 1L));
}

/* {DIRECTORY}.exists */
EIF_BOOLEAN F395_4845 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F395_4859(Current))+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_BOOLEAN) EIF_TEST(eif_dir_exists((EIF_FILENAME) tp1));
	RTLE;
	return Result;
}

/* {DIRECTORY}.is_readable */
EIF_BOOLEAN F395_4846 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F395_4859(Current))+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_BOOLEAN) EIF_TEST(eif_dir_is_readable((EIF_FILENAME) tp1));
	RTLE;
	return Result;
}

/* {DIRECTORY}.dispose */
void F395_4854 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F395_4843(Current)) {
		F395_4831(Current);
	}
	RTLE;
}

/* {DIRECTORY}.set_name */
void F395_4857 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tr1 = RTOSCF(4867,F395_4867, (Current));
	tr1 = F393_4778(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DIRECTORY}.internal_name_pointer */
EIF_REFERENCE F395_4859 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTCT0("internal_name_pointer_set", EX_CHECK);
			RTCF0;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {DIRECTORY}.file_info */
static EIF_REFERENCE F395_4867_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (4867);
#define Result RTOSR(4867)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(392, 0x00).id, 392, _OBJSIZ_3_2_0_0_0_0_0_0_);
	F393_4761(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (4867);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F395_4867 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4867,F395_4867_body,(Current));
}

/* {DIRECTORY}.file_mkdir */
void F395_4868 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	eif_file_mkdir((EIF_FILENAME) arg1);
	
}

/* {DIRECTORY}.dir_open */
EIF_POINTER F395_4869 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) eif_dir_open((EIF_FILENAME) arg1);
	
	return Result;
}

/* {DIRECTORY}.dir_rewind */
EIF_POINTER F395_4870 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) eif_dir_rewind((EIF_POINTER) arg1, (EIF_FILENAME) arg2);
	
	return Result;
}

/* {DIRECTORY}.dir_close */
void F395_4871 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	eif_dir_close(arg1);
	
}

/* {DIRECTORY}.eif_dir_next */
EIF_POINTER F395_4872 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) eif_dir_next(arg1);
	
	return Result;
}

/* {DIRECTORY}.eif_dir_exists */
EIF_BOOLEAN F395_4874 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(eif_dir_exists((EIF_FILENAME) arg1));
	
	return Result;
}

/* {DIRECTORY}.eif_dir_is_readable */
EIF_BOOLEAN F395_4875 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(eif_dir_is_readable((EIF_FILENAME) arg1));
	
	return Result;
}

void EIF_Minit333 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
