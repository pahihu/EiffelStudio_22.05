/*
 * Code for class IRON_INSTALLATION_API
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir342.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_INSTALLATION_API}.initialize */
void F404_4976 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (IRON_API.initialize) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTLNSMART(eif_new_type(12, 0).id);
	F13_130(RTCW(tr1), *(EIF_REFERENCE *)(Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {IRON_INSTALLATION_API}.is_up_to_date */
EIF_BOOLEAN F404_4982 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_2 = F13_132(RTCW(tr1));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

/* {IRON_INSTALLATION_API}.installed_package */
EIF_REFERENCE F404_4984 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	if (arg2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		Result = F13_135(RTCW(tr1), arg1);
	} else {
		tr1 = F404_4985(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4781[Dtype(loc1)-452])(loc1);
			for (;;) {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4751[Dtype(loc2)-423])(loc2);
				if (tb1) break;
				if ((EIF_BOOLEAN)(Result != NULL)) break;
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4750[Dtype(loc2)-423])(loc2);
				tb2 = F1062_8211(RTCW(tr1), arg1);
				if (tb2) {
					Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4750[Dtype(loc2)-423])(loc2);
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R4752[Dtype(loc2)-423])(loc2);
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_INSTALLATION_API}.installed_packages */
EIF_REFERENCE F404_4985 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !F404_4982(Current)) {
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	}
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F13_134(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F13_132(RTCW(tr1));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_0_) = (EIF_INTEGER_32) ti4_1;
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {IRON_INSTALLATION_API}.package_installation_path */
EIF_REFERENCE F404_5002 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F401_4960(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {IRON_INSTALLATION_API}.local_path_associated_with_uri */
EIF_REFERENCE F404_5007 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,Result);
	RTLIU(7);
	
	RTGC;
	tb1 = '\01';
	tr1 = RTMS_EX_H("http://",7,769736239);
	tb2 = F1048_7732(RTCW(arg1), tr1);
	if (!tb2) {
		tr1 = RTMS_EX_H("https://",8,441357103);
		tb2 = F1048_7732(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) F404_5008(Current, arg1);
	} else {
		tr1 = RTMS_EX_H("iron:",5,1920711738);
		tb1 = F1048_7732(RTCW(arg1), tr1);
		if (tb1) {
			loc1 = RTLNS(eif_new_type(1299, 0x00).id, 1299, _OBJSIZ_6_2_0_1_0_0_0_0_);
			F1300_12306(RTCW(loc1), arg1);
			loc3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R6691[Dtype(RTCW(loc3))-1051])(loc3, (EIF_CHARACTER_8) ':', ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				tr1 = F1048_7766(RTCW(loc3), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O6713[Dtype(loc3)-1050]);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6631[Dtype(RTCW(loc3))-1051])(loc3, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), ti4_1);
				Result = F404_5009(Current, tr1, tr2);
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_INSTALLATION_API}.local_path_associated_with_url */
EIF_REFERENCE F404_5008 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,loc6);
	RTLR(1,arg1);
	RTLR(2,loc7);
	RTLR(3,loc2);
	RTLR(4,loc8);
	RTLR(5,Current);
	RTLR(6,tr1);
	RTLR(7,loc9);
	RTLR(8,loc4);
	RTLR(9,loc5);
	RTLR(10,loc1);
	RTLR(11,loc10);
	RTLR(12,loc3);
	RTLR(13,Result);
	RTLIU(14);
	
	RTGC;
	loc6 = RTLNS(eif_new_type(1299, 0x00).id, 1299, _OBJSIZ_6_2_0_1_0_0_0_0_);
	F1300_12306(RTCW(loc6), arg1);
	loc7 = F1299_12274(RTCW(loc6));
	loc2 = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1048_7685(RTCW(loc2));
	tr1 = F404_4985(Current);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		loc9 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4781[Dtype(loc8)-452])(loc8);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4751[Dtype(loc9)-423])(loc9);
			if (tb1) break;
			if ((EIF_BOOLEAN)(loc4 != NULL)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4750[Dtype(loc9)-423])(loc9);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			loc5 = F551_5415(RTCW(tr1));
			tb2 = F1051_7851(RTCW(loc7), loc5);
			if (tb2) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5) + O6713[Dtype(loc5)-1050]);
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc7) + O6713[Dtype(loc7)-1050]);
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6631[Dtype(RTCW(loc7))-1051])(loc7, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), ti4_2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4750[Dtype(loc9)-423])(loc9);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
				loc10 = F893_6376(RTCW(tr1));
				for (;;) {
					tb2 = F501_5372(loc10);
					if (tb2) break;
					if ((EIF_BOOLEAN)(loc4 != NULL)) break;
					loc3 = F501_5363(loc10);
					tb3 = '\0';
					tb4 = F1051_7851(RTCW(loc1), loc3);
					if (tb4) {
						tb4 = '\01';
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O6713[Dtype(loc1)-1050]);
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O6713[Dtype(loc3)-1050]);
						if (!(EIF_BOOLEAN)(ti4_1 == ti4_2)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O6713[Dtype(loc3)-1050]);
							tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5231[Dtype(RTCW(loc1))-795])(loc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L))));
							tb4 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '/');
						}
						tb3 = tb4;
					}
					if (tb3) {
						loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4750[Dtype(loc9)-423])(loc9);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R6678[Dtype(RTCW(loc2))-1052])(loc2);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O6713[Dtype(loc3)-1050]);
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O6713[Dtype(loc1)-1050]);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6631[Dtype(RTCW(loc1))-1051])(loc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), ti4_2);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6737[Dtype(RTCW(loc2))-1052])(loc2, tr1);
					}
					F501_5378(loc10);
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R4752[Dtype(loc9)-423])(loc9);
		}
	}
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		Result = F404_5002(Current, loc4);
		tb3 = '\0';
		if ((EIF_BOOLEAN)(Result != NULL)) {
			tr1 = RTLNS(eif_new_type(394, 0x00).id, 394, _OBJSIZ_3_0_0_1_0_2_0_0_);
			F395_4822(RTCW(tr1), Result);
			tb4 = F395_4845(RTCW(tr1));
			tb3 = tb4;
		}
		if (tb3) {
			tr1 = F1073_8654(RTCW(Result), loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTLE;
			return (EIF_REFERENCE) NULL;
		}
	}
	RTLE;
	return Result;
}

/* {IRON_INSTALLATION_API}.local_path_associated_with_relative_uri */
EIF_REFERENCE F404_5009 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLR(4,tr1);
	RTLR(5,arg2);
	RTLIU(6);
	
	RTGC;
	loc1 = F404_4984(Current, arg1, (EIF_BOOLEAN) 0);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		Result = F404_5002(Current, loc1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(Result != NULL)) {
			tr1 = RTLNS(eif_new_type(394, 0x00).id, 394, _OBJSIZ_3_0_0_1_0_2_0_0_);
			F395_4822(RTCW(tr1), Result);
			tb2 = F395_4845(RTCW(tr1));
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = F1073_8654(RTCW(Result), arg2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTLE;
			return (EIF_REFERENCE) NULL;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit342 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
