/*
 * Code for class CONF_PARSE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co311.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_PARSE_FACTORY}.new_redirection_with_file_name */
EIF_REFERENCE F361_4517 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1254, 0x00).id, 1254, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1255_10875(RTCW(tr1), arg1, arg2, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_system_generate_uuid_with_file_name */
EIF_REFERENCE F361_4518 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	Result = RTLNS(eif_new_type(1255, 0x00).id, 1255, _OBJSIZ_16_4_0_2_0_0_0_0_);
	tr1 = F61_949(RTCV(RTOSCF(4545,F361_4545, (Current))));
	F1256_10884(RTCW(Result), arg1, arg2, tr1, arg3);
	F1256_10919(RTCW(Result), (EIF_BOOLEAN) 1);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_system_with_file_name */
EIF_REFERENCE F361_4519 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1255, 0x00).id, 1255, _OBJSIZ_16_4_0_2_0_0_0_0_);
	F1256_10884(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_target */
EIF_REFERENCE F361_4520 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1071, 0x00).id, 1071, _OBJSIZ_29_1_0_0_0_0_0_0_);
	F1072_8482(RTCW(tr1), arg1, arg2);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_location_from_path */
EIF_REFERENCE F361_4521 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1279, 0x00).id, 1279, _OBJSIZ_3_0_0_0_0_0_0_0_);
	F1280_11716(RTCW(tr1), arg1, arg2);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_location_from_full_path */
EIF_REFERENCE F361_4523 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1278, 0x00).id, 1278, _OBJSIZ_3_0_0_0_0_0_0_0_);
	F1279_11713(RTCW(tr1), arg1, arg2);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_root */
EIF_REFERENCE F361_4524 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(61, 0x00).id, 61, _OBJSIZ_3_1_0_0_0_0_0_0_);
	F62_954(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_version */
EIF_REFERENCE F361_4525 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1, EIF_NATURAL_16 arg2, EIF_NATURAL_16 arg3, EIF_NATURAL_16 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1225, 0x00).id, 1225, _OBJSIZ_4_5_4_0_0_0_0_0_);
	F1226_10184(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_option */
EIF_REFERENCE F361_4526 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(914, 0x00).id, 914, _OBJSIZ_12_18_0_0_0_0_0_0_);
	Result = F915_6628(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_target_option */
EIF_REFERENCE F361_4527 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(915, 0x00).id, 915, _OBJSIZ_18_18_0_0_0_0_0_0_);
	Result = F915_6628(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_file_rule */
EIF_REFERENCE F361_4528 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(369, 0x00).id, 369, _OBJSIZ_7_0_0_0_0_0_0_0_);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_external_include */
EIF_REFERENCE F361_4529 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(377, 0x00).id, 377, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1048_7744(RTCW(arg1));
	F371_4707(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_cflag */
EIF_REFERENCE F361_4530 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(376, 0x00).id, 376, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1048_7744(RTCW(arg1));
	F371_4707(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_object */
EIF_REFERENCE F361_4531 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(375, 0x00).id, 375, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1048_7744(RTCW(arg1));
	F371_4707(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_library */
EIF_REFERENCE F361_4532 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(374, 0x00).id, 374, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1048_7744(RTCW(arg1));
	F371_4707(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_resource */
EIF_REFERENCE F361_4533 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(373, 0x00).id, 373, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1048_7744(RTCW(arg1));
	F371_4707(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_linker_flag */
EIF_REFERENCE F361_4534 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(372, 0x00).id, 372, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1048_7744(RTCW(arg1));
	F371_4707(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_make */
EIF_REFERENCE F361_4535 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(371, 0x00).id, 371, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1048_7744(RTCW(arg1));
	F371_4707(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_action */
EIF_REFERENCE F361_4536 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(368, 0x00).id, 368, _OBJSIZ_4_1_0_0_0_0_0_0_);
	tr1 = F1048_7744(RTCW(arg1));
	F369_4675(RTCW(Result), tr1, arg2, arg3);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_assertions */
EIF_REFERENCE F361_4537 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(62, 0x00).id, 62, _OBJSIZ_0_0_0_1_0_0_0_0_);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_assembly */
EIF_REFERENCE F361_4538 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	tr1 = F1048_7744(RTCW(arg2));
	loc1 = F361_4523(Current, tr1, arg3);
	tr1 = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_23_4_0_1_0_0_0_0_);
	F1121_8770(RTCW(tr1), arg1, loc1, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_assembly_from_gac */
EIF_REFERENCE F361_4539 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,arg5);
	RTLR(6,arg6);
	RTLIU(7);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1127, 0x00).id, 1127, _OBJSIZ_23_4_0_1_0_0_0_0_);
	F1128_8908(RTCW(tr1), arg1, arg2, arg3, arg4, arg5, arg6);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_library */
EIF_REFERENCE F361_4540 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	Result = RTLNS(eif_new_type(1128, 0x00).id, 1128, _OBJSIZ_21_4_0_1_0_0_0_0_);
	tr1 = F1048_7744(RTCW(arg2));
	tr1 = F361_4523(Current, tr1, arg3);
	F1129_8936(RTCW(Result), arg1, tr1, arg3);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_precompile */
EIF_REFERENCE F361_4541 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	Result = RTLNS(eif_new_type(1129, 0x00).id, 1129, _OBJSIZ_22_4_0_1_0_0_0_0_);
	tr1 = F1048_7744(RTCW(arg2));
	tr1 = F361_4523(Current, tr1, arg3);
	F1130_8954(RTCW(Result), arg1, tr1, arg3);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_cluster */
EIF_REFERENCE F361_4542 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1123, 0x00).id, 1123, _OBJSIZ_27_5_0_1_0_0_0_0_);
	F1124_8848(RTCW(tr1), arg1, arg2, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_test_cluster */
EIF_REFERENCE F361_4543 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_27_5_0_1_0_0_0_0_);
	F1124_8848(RTCW(tr1), arg1, arg2, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_override */
EIF_REFERENCE F361_4544 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1125, 0x00).id, 1125, _OBJSIZ_29_5_0_1_0_0_0_0_);
	F1124_8848(RTCW(tr1), arg1, arg2, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.uuid_generator */
static EIF_REFERENCE F361_4545_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (4545);
#define Result RTOSR(4545)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(60, 0x00).id, 60, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (4545);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F361_4545 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4545,F361_4545_body,(Current));
}

void EIF_Minit311 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
