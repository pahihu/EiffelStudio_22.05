/*
 * Code for class ENVIRONMENT_ACCESS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "en335.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ENVIRONMENT_ACCESS}.application_item */
EIF_REFERENCE F397_4917 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	return (EIF_REFERENCE) F396_4885(Current, arg1);
}

void EIF_Minit335 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
