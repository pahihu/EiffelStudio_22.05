
#ifndef _C7_kl336_
#define _C7_kl336_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,4920)
static EIF_REFERENCE F398_4920_body(EIF_REFERENCE);
extern EIF_REFERENCE F398_4920(EIF_REFERENCE);
extern void EIF_Minit336(void);

#ifdef __cplusplus
}
#endif

#endif
