
#ifndef _C7_co318_
#define _C7_co318_

#ifdef __cplusplus
extern "C" {
#endif

extern void F368_4672(EIF_REFERENCE, EIF_REFERENCE);
extern void F368_4673(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit318(void);
extern EIF_BOOLEAN F706_5583(EIF_REFERENCE);
extern void F908_6450(EIF_REFERENCE, EIF_INTEGER_32);
extern void F893_6402(EIF_REFERENCE, EIF_REFERENCE);
extern long O4276[];

#ifdef __cplusplus
}
#endif

#endif
