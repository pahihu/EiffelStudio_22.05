/*
 * Code for class UC_IMPORTED_UNICODE_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc302.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_IMPORTED_UNICODE_ROUTINES}.unicode */
static EIF_REFERENCE F352_4214_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (4214);
#define Result RTOSR(4214)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1301, 0x00).id, 1301, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (4214);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F352_4214 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4214,F352_4214_body,(Current));
}

void EIF_Minit302 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
