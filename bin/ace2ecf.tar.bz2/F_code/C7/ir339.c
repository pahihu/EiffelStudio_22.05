/*
 * Code for class IRON_LAYOUT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir339.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_LAYOUT}.make_with_path */
void F401_4943 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = F1073_8646(RTCW(arg1));
	tr1 = F1073_8648(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = F1073_8646(RTCW(arg2));
	tr1 = F1073_8648(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {IRON_LAYOUT}.repositories_configuration_file */
static EIF_REFERENCE F401_4947_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (4947);
#define Result RTOSR(4947)
	RTOC_NEW(Result);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTMS_EX_H("repositories.conf",17,415021670);
	Result = F1073_8654(RTCW(tr1), tr2);
	RTOSE (4947);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F401_4947 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4947,F401_4947_body,(Current));
}

/* {IRON_LAYOUT}.repositories_revision_file */
static EIF_REFERENCE F401_4948_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (4948);
#define Result RTOSR(4948)
	RTOC_NEW(Result);
	tr1 = RTOSCF(4951,F401_4951, (Current));
	tr2 = RTMS_EX_H("local.rev",9,1360318326);
	Result = F1073_8654(RTCW(tr1), tr2);
	RTOSE (4948);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F401_4948 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4948,F401_4948_body,(Current));
}

/* {IRON_LAYOUT}.packages_path */
static EIF_REFERENCE F401_4951_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (4951);
#define Result RTOSR(4951)
	RTOC_NEW(Result);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTMS_EX_H("packages",8,1285097587);
	Result = F1073_8654(RTCW(tr1), tr2);
	RTOSE (4951);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F401_4951 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4951,F401_4951_body,(Current));
}

/* {IRON_LAYOUT}.package_installation_path */
EIF_REFERENCE F401_4960 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	struct eif_ex_60 sloc2;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) sloc2.data;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc2.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc2.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc2.overhead, eif_new_type(66, 0x00).id);
	RTLI(11);
	RTLR(0,loc6);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,Current);
	RTLR(7,Result);
	RTLR(8,loc7);
	RTLR(9,loc1);
	RTLR(10,loc2);
	RTLIU(11);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc6 = tr1;
	loc6 = RTRV(eif_new_type(1062, 0x00),loc6);
	if (EIF_TEST(loc6)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
		tb1 = F706_5583(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
			loc3 = F893_6370(RTCW(tr1));
			loc4 = RTLNS(eif_new_type(1298, 0x00).id, 1298, _OBJSIZ_6_2_0_1_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(loc6 + _REFACS_2_);
			tr1 = F1299_12274(RTCW(tr1));
			F1299_12240(RTCW(loc4), tr1);
			F1299_12283(RTCW(loc4), loc3);
			loc5 = RTLNS(eif_new_type(1300, 0x00).id, 1300, _OBJSIZ_7_3_0_1_0_0_0_0_);
			F1301_12331(RTCW(loc5), loc4);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_6_);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	} else {
		Result = F401_4961(Current, arg1);
		tr1 = F401_4962(Current, arg1);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			loc1 = RTLNS(eif_new_type(772, 0x00).id, 772, _OBJSIZ_4_6_2_4_1_1_2_1_);
			F772_5647(RTCW(loc1), loc7);
			tb1 = '\0';
			tb2 = F772_5681(RTCW(loc1));
			if (tb2) {
				tb2 = F772_5700(RTCW(loc1));
				tb1 = tb2;
			}
			if (tb1) {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5071[Dtype(RTCW(loc1))-772])(loc1);
				F772_5794(RTCW(loc1));
				loc3 = *(EIF_REFERENCE *)(RTCW(loc1) + O4666[Dtype(loc1)-410]);
				F772_5733(RTCW(loc1));
				Result = RTLNS(eif_new_type(1072, 0x00).id, 1072, _OBJSIZ_2_1_0_0_0_0_0_0_);
				tr1 = F67_1027(RTCW(loc2), loc3);
				F1073_8627(RTCW(Result), tr1);
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_LAYOUT}.package_expected_installation_path */
EIF_REFERENCE F401_4961 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(4951,F401_4951, (Current));
	tr2 = F401_4965(Current, arg1, (EIF_BOOLEAN) 0);
	Result = F1073_8655(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {IRON_LAYOUT}.package_renaming_installation_path */
EIF_REFERENCE F401_4962 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(4951,F401_4951, (Current));
	tr2 = F401_4965(Current, arg1, (EIF_BOOLEAN) 1);
	tr1 = F1073_8655(RTCW(tr1), tr2);
	tr2 = RTMS_EX_H("renaming",8,1374354535);
	Result = F1073_8657(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {IRON_LAYOUT}.safe_package_path */
EIF_REFERENCE F401_4965 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1057, 0x00).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1056_7984(RTCW(loc1), ((EIF_INTEGER_32) 10L));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		F1058_8099(RTCW(loc1), loc2);
	}
	if (arg2) {
		tb1 = F709_5583(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
			F1058_8112(RTCW(loc1), tw1);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
			F1058_8112(RTCW(loc1), tw1);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		F1058_8098(RTCW(loc1), tr1);
	} else {
		tb1 = F709_5583(RTCW(loc1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			tr1 = F1052_7880(RTCW(tr1));
			F1058_8098(RTCW(loc1), tr1);
		}
	}
	Result = RTLNS(eif_new_type(1072, 0x00).id, 1072, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr1 = F401_4967(Current, loc1);
	F1073_8627(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {IRON_LAYOUT}.safe_name */
EIF_REFERENCE F401_4967 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc3 = (EIF_CHARACTER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6590[Dtype(RTCW(arg1))-1051])(arg1);
	F1051_7815(RTCW(Result), ti4_1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6590[Dtype(RTCW(arg1))-1051])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6554[Dtype(RTCW(arg1))-1051])(arg1, loc1);
		switch (loc3) {
			case (EIF_CHARACTER_8) '/':
			case (EIF_CHARACTER_8) ':':
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6741[Dtype(RTCW(Result))-1052])(Result, (EIF_CHARACTER_8) '_');
				break;
			case (EIF_CHARACTER_8) 'a':
			case (EIF_CHARACTER_8) 'b':
			case (EIF_CHARACTER_8) 'c':
			case (EIF_CHARACTER_8) 'd':
			case (EIF_CHARACTER_8) 'e':
			case (EIF_CHARACTER_8) 'f':
			case (EIF_CHARACTER_8) 'g':
			case (EIF_CHARACTER_8) 'h':
			case (EIF_CHARACTER_8) 'i':
			case (EIF_CHARACTER_8) 'j':
			case (EIF_CHARACTER_8) 'k':
			case (EIF_CHARACTER_8) 'l':
			case (EIF_CHARACTER_8) 'm':
			case (EIF_CHARACTER_8) 'n':
			case (EIF_CHARACTER_8) 'o':
			case (EIF_CHARACTER_8) 'p':
			case (EIF_CHARACTER_8) 'q':
			case (EIF_CHARACTER_8) 'r':
			case (EIF_CHARACTER_8) 's':
			case (EIF_CHARACTER_8) 't':
			case (EIF_CHARACTER_8) 'u':
			case (EIF_CHARACTER_8) 'v':
			case (EIF_CHARACTER_8) 'w':
			case (EIF_CHARACTER_8) 'x':
			case (EIF_CHARACTER_8) 'y':
			case (EIF_CHARACTER_8) 'z':
				tc1 = (EIF_CHARACTER_8) loc3;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6741[Dtype(RTCW(Result))-1052])(Result, tc1);
				break;
			case (EIF_CHARACTER_8) 'A':
			case (EIF_CHARACTER_8) 'B':
			case (EIF_CHARACTER_8) 'C':
			case (EIF_CHARACTER_8) 'D':
			case (EIF_CHARACTER_8) 'E':
			case (EIF_CHARACTER_8) 'F':
			case (EIF_CHARACTER_8) 'G':
			case (EIF_CHARACTER_8) 'H':
			case (EIF_CHARACTER_8) 'I':
			case (EIF_CHARACTER_8) 'J':
			case (EIF_CHARACTER_8) 'K':
			case (EIF_CHARACTER_8) 'L':
			case (EIF_CHARACTER_8) 'M':
			case (EIF_CHARACTER_8) 'N':
			case (EIF_CHARACTER_8) 'O':
			case (EIF_CHARACTER_8) 'P':
			case (EIF_CHARACTER_8) 'Q':
			case (EIF_CHARACTER_8) 'R':
			case (EIF_CHARACTER_8) 'S':
			case (EIF_CHARACTER_8) 'T':
			case (EIF_CHARACTER_8) 'U':
			case (EIF_CHARACTER_8) 'V':
			case (EIF_CHARACTER_8) 'W':
			case (EIF_CHARACTER_8) 'X':
			case (EIF_CHARACTER_8) 'Y':
			case (EIF_CHARACTER_8) 'Z':
				tc1 = (EIF_CHARACTER_8) loc3;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6741[Dtype(RTCW(Result))-1052])(Result, tc1);
				break;
			case (EIF_CHARACTER_8) '0':
			case (EIF_CHARACTER_8) '1':
			case (EIF_CHARACTER_8) '2':
			case (EIF_CHARACTER_8) '3':
			case (EIF_CHARACTER_8) '4':
			case (EIF_CHARACTER_8) '5':
			case (EIF_CHARACTER_8) '6':
			case (EIF_CHARACTER_8) '7':
			case (EIF_CHARACTER_8) '8':
			case (EIF_CHARACTER_8) '9':
				tc1 = (EIF_CHARACTER_8) loc3;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6741[Dtype(RTCW(Result))-1052])(Result, tc1);
				break;
			case (EIF_CHARACTER_8) '!':
			case (EIF_CHARACTER_8) '\?':
			case (EIF_CHARACTER_8) '@':
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6741[Dtype(RTCW(Result))-1052])(Result, (EIF_CHARACTER_8) '+');
				break;
			case (EIF_CHARACTER_8) '-':
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6741[Dtype(RTCW(Result))-1052])(Result, (EIF_CHARACTER_8) '-');
				break;
			default:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6741[Dtype(RTCW(Result))-1052])(Result, (EIF_CHARACTER_8) '_');
				break;
		}
		loc1++;
	}
	RTLE;
	return Result;
}

void EIF_Minit339 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
