
#ifndef _C7_en335_
#define _C7_en335_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F397_4917(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit335(void);
extern EIF_REFERENCE F396_4885(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
