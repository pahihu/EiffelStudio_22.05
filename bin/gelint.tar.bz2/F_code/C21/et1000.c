/*
 * Code for class ET_PARENTHESIS_SYMBOL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1000.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_PARENTHESIS_SYMBOL}.name */
EIF_REFERENCE F1939_17954 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOUCR(403,F377_5150, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	RTLE;
	return Result;
}

/* {ET_PARENTHESIS_SYMBOL}.lower_name */
EIF_REFERENCE F1939_17955 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1939_17954(Current);
}

/* {ET_PARENTHESIS_SYMBOL}.hash_code */
EIF_INTEGER_32 F1939_17956 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) 'c';
	Result = (EIF_INTEGER_32) (tc1);
	RTLE;
	return Result;
}

/* {ET_PARENTHESIS_SYMBOL}.is_parenthesis */
EIF_BOOLEAN F1939_17957 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

void EIF_Minit1000 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
