
#ifndef _C21_et1034_
#define _C21_et1034_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1973_18304(EIF_REFERENCE);
extern void F1973_18305(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1034(void);
extern void F1792_16188(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern long O13427[];

#ifdef __cplusplus
}
#endif

#endif
