
#ifndef _C21_et1004_
#define _C21_et1004_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1943_18044(EIF_REFERENCE);
extern EIF_INTEGER_32 F1943_18047(EIF_REFERENCE);
extern EIF_BOOLEAN F1943_18048(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1004(void);
extern EIF_BOOLEAN F1204_10807(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1212_10869(EIF_REFERENCE);
extern char *(*R13228[])();
extern char *(*R8341[])();
extern char *(*R13244[])();
extern char *(*R5880[])();
extern char *(*R13313[])();
extern long O13315[];

#ifdef __cplusplus
}
#endif

#endif
