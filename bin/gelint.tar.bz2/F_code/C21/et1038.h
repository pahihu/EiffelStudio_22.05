
#ifndef _C21_et1038_
#define _C21_et1038_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1977_18309(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1038(void);
extern char *(*R2434[])();

#ifdef __cplusplus
}
#endif

#endif
