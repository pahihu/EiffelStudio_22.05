
#ifndef _C21_et1023_
#define _C21_et1023_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1962_18229(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1962_18230(EIF_REFERENCE);
extern EIF_REFERENCE F1962_18234(EIF_REFERENCE);
extern EIF_REFERENCE F1962_18236(EIF_REFERENCE);
extern void F1962_18238(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1023(void);
extern EIF_REFERENCE F1908_17479(EIF_REFERENCE);
extern EIF_REFERENCE F377_4527(EIF_REFERENCE);
extern EIF_REFERENCE F1008_7607(EIF_REFERENCE);
extern char *(*R2289[])();
extern char *(*R11966[])();
extern char *(*R11799[])();

#ifdef __cplusplus
}
#endif

#endif
