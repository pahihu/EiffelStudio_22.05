
#ifndef _C21_et1026_
#define _C21_et1026_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1965_18250(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1026(void);
extern char *(*R2460[])();

#ifdef __cplusplus
}
#endif

#endif
