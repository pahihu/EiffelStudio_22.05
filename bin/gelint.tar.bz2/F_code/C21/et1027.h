
#ifndef _C21_et1027_
#define _C21_et1027_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1966_18251(EIF_REFERENCE);
extern void EIF_Minit1027(void);
extern void F1636_15323(EIF_REFERENCE);
extern void F1854_16621(EIF_REFERENCE);
extern char *(*R11961[])();
extern char *(*R11957[])();

#ifdef __cplusplus
}
#endif

#endif
