/*
 * Code for class ET_AGENT_KEYWORD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1007.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_AGENT_KEYWORD}.lower_name */
EIF_REFERENCE F1946_18068 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOUCR(1383,F377_4994, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	RTLE;
	return Result;
}

/* {ET_AGENT_KEYWORD}.hash_code */
EIF_INTEGER_32 F1946_18069 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	Result = (EIF_INTEGER_32) (tc1);
	RTLE;
	return Result;
}

/* {ET_AGENT_KEYWORD}.same_call_name */
EIF_BOOLEAN F1946_18070 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(98,F1192_10678, (Current));
	Result = F30_406(RTCW(tr1), Current, arg1);
	RTLE;
	return Result;
}

/* {ET_AGENT_KEYWORD}.same_feature_name */
EIF_BOOLEAN F1946_18071 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(98,F1192_10678, (Current));
	Result = F30_406(RTCW(tr1), Current, arg1);
	RTLE;
	return Result;
}

/* {ET_AGENT_KEYWORD}.is_equal */
EIF_BOOLEAN F1946_18072 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(98,F1192_10678, (Current));
	Result = F30_406(RTCW(tr1), Current, arg1);
	RTLE;
	return Result;
}

void EIF_Minit1007 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
