
#ifndef _C21_et1030_
#define _C21_et1030_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1969_18278(EIF_REFERENCE);
extern EIF_REFERENCE F1969_18280(EIF_REFERENCE);
extern EIF_REFERENCE F1969_18281(EIF_REFERENCE);
extern void EIF_Minit1030(void);
extern char *(*R11966[])();
extern char *(*R12274[])();
extern char *(*R12119[])();
extern char *(*R12570[])();

#ifdef __cplusplus
}
#endif

#endif
