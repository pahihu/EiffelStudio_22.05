
#ifndef _C21_et1020_
#define _C21_et1020_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1959_18210(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1959_18211(EIF_REFERENCE);
extern EIF_REFERENCE F1959_18213(EIF_REFERENCE);
extern EIF_REFERENCE F1959_18218(EIF_REFERENCE);
extern EIF_REFERENCE F1959_18220(EIF_REFERENCE);
extern void F1959_18221(EIF_REFERENCE, EIF_REFERENCE);
extern void F1959_18222(EIF_REFERENCE, EIF_REFERENCE);
extern void F1959_18224(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1020(void);
extern void F1633_15295(EIF_REFERENCE);
extern void F1636_15323(EIF_REFERENCE);
extern EIF_REFERENCE F377_4575(EIF_REFERENCE);
extern EIF_REFERENCE F1008_7607(EIF_REFERENCE);
extern char *(*R11966[])();
extern char *(*R2383[])();
extern char *(*R12051[])();
extern char *(*R11795[])();

#ifdef __cplusplus
}
#endif

#endif
