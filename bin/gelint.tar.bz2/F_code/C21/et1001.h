
#ifndef _C21_et1001_
#define _C21_et1001_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1940_17960(EIF_REFERENCE);
extern EIF_REFERENCE F1940_17961(EIF_REFERENCE);
extern EIF_INTEGER_32 F1940_17962(EIF_REFERENCE);
extern EIF_BOOLEAN F1940_17963(EIF_REFERENCE);
extern void EIF_Minit1001(void);
extern EIF_REFERENCE F377_5149(EIF_REFERENCE);
extern EIF_REFERENCE F1008_7607(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
