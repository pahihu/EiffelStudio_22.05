
#ifndef _C21_et1014_
#define _C21_et1014_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1953_18150(EIF_REFERENCE);
extern void EIF_Minit1014(void);

#ifdef __cplusplus
}
#endif

#endif
