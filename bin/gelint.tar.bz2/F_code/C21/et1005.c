/*
 * Code for class ET_ALIAS_FREE_NAME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1005.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ALIAS_FREE_NAME}.make_infix */
void F1944_18049 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'R';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOUCR(5,F1212_10869, (Current));
	tr2 = F1944_18059(Current);
	ti4_1 = F1204_10803(RTCW(tr1), tr2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {ET_ALIAS_FREE_NAME}.is_prefix */
EIF_BOOLEAN F1944_18051 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) '^';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_FREE_NAME}.is_infix */
EIF_BOOLEAN F1944_18052 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'R';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_FREE_NAME}.is_infix_freeop */
EIF_BOOLEAN F1944_18054 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'R';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_FREE_NAME}.is_prefixable */
EIF_BOOLEAN F1944_18055 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {ET_ALIAS_FREE_NAME}.is_infixable */
EIF_BOOLEAN F1944_18056 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {ET_ALIAS_FREE_NAME}.alias_name */
EIF_REFERENCE F1944_18057 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1189, 0x01).id, 1189, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F1944_18059(Current))+ _LNGOFF_1_1_0_2_);
	F1188_10512(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 8L)));
	tr1 = RTOUCR(2235,F1944_18064, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8544[Dtype(RTCW(Result))-1189])(Result, tr1);
	tr1 = F1944_18059(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8544[Dtype(RTCW(Result))-1189])(Result, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(Result))-1189])(Result, (EIF_CHARACTER_8) '\"');
	RTLE;
	return Result;
}

/* {ET_ALIAS_FREE_NAME}.alias_lower_name */
EIF_REFERENCE F1944_18058 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = F1944_18057(Current);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5880[Dtype(RTCW(Result))-819])(Result, loc1));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 >= (EIF_CHARACTER_8) 'A') && (EIF_BOOLEAN) (loc3 <= (EIF_CHARACTER_8) 'Z'))) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8341[Dtype(RTCW(Result))-1185])(Result);
			Result = (EIF_REFERENCE) tr1;
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		} else {
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {ET_ALIAS_FREE_NAME}.operator_name */
EIF_REFERENCE F1944_18059 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13162[Dtype(RTCW(tr1))-1928])(tr1);
	RTLE;
	return Result;
}

/* {ET_ALIAS_FREE_NAME}.set_infix */
void F1944_18060 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) 'R';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_FREE_NAME}.set_prefix */
void F1944_18061 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '^';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_FREE_NAME}.same_alias_name */
EIF_BOOLEAN F1944_18062 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		loc1 = arg1;
		loc1 = RTRV(eif_new_type(1942, 0x01),loc1);
		if (EIF_TEST(loc1)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc1 + O13315[Dtype(loc1)-1942]);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_) == ti4_1)) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13313[Dtype(loc1)-1943])(loc1);
				if ((EIF_BOOLEAN)(tr1 == F1944_18059(Current))) {
					RTLE;
					return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = RTOUCR(5,F1212_10869, (Current));
					tr2 = F1944_18059(Current);
					tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13313[Dtype(loc1)-1943])(loc1);
					Result = F1204_10807(RTCW(tr1), tr2, tr3);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_ALIAS_FREE_NAME}.alias_double_quote */

EIF_REFERENCE F1944_18064 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2235,RTMS_EX_H("alias \"",7,1277740834));
}

void EIF_Minit1005 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
