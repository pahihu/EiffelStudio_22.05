/*
 * Code for class ET_FREE_NAME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1004.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_FREE_NAME}.lower_name */
EIF_REFERENCE F1943_18044 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13228[Dtype(Current)-1938])(Current);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5880[Dtype(RTCW(Result))-819])(Result, loc1));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 >= (EIF_CHARACTER_8) 'A') && (EIF_BOOLEAN) (loc3 <= (EIF_CHARACTER_8) 'Z'))) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8341[Dtype(RTCW(Result))-1185])(Result);
			Result = (EIF_REFERENCE) tr1;
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		} else {
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {ET_FREE_NAME}.hash_code */
EIF_INTEGER_32 F1943_18047 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O13315[Dtype(Current)-1942]);
}


/* {ET_FREE_NAME}.same_call_name */
EIF_BOOLEAN F1943_18048 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		loc1 = arg1;
		loc1 = RTRV(eif_new_type(1942, 0x01),loc1);
		if (EIF_TEST(loc1)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc1 + O13315[Dtype(loc1)-1942]);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O13315[dtype-1942]) == ti4_1)) {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13244[Dtype(loc1)-1943])(loc1);
				if ((EIF_BOOLEAN)((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13244[dtype-1943])(Current) != tb1)) {
					RTLE;
					return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13313[Dtype(loc1)-1943])(loc1);
					if ((EIF_BOOLEAN)(tr1 == (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13313[dtype-1943])(Current))) {
						RTLE;
						return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = RTOUCR(5,F1212_10869, (Current));
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13313[dtype-1943])(Current);
						tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13313[Dtype(loc1)-1943])(loc1);
						Result = F1204_10807(RTCW(tr1), tr2, tr3);
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit1004 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
