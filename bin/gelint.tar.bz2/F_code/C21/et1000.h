
#ifndef _C21_et1000_
#define _C21_et1000_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1939_17954(EIF_REFERENCE);
extern EIF_REFERENCE F1939_17955(EIF_REFERENCE);
extern EIF_INTEGER_32 F1939_17956(EIF_REFERENCE);
extern EIF_BOOLEAN F1939_17957(EIF_REFERENCE);
extern void EIF_Minit1000(void);
extern EIF_REFERENCE F377_5150(EIF_REFERENCE);
extern EIF_REFERENCE F1008_7607(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
