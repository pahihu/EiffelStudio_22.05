
#ifndef _C21_et1015_
#define _C21_et1015_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1954_18153(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1954_18154(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1015(void);
extern void F1792_16188(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2463[])();
extern EIF_TYPE_INDEX Y12281[];
extern EIF_TYPE_INDEX *Y12281_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
