
#ifndef _C21_et1008_
#define _C21_et1008_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1947_18074(EIF_REFERENCE);
extern void EIF_Minit1008(void);
extern char *(*R13228[])();

#ifdef __cplusplus
}
#endif

#endif
