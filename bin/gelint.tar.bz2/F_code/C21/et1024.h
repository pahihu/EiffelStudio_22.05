
#ifndef _C21_et1024_
#define _C21_et1024_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1963_18239(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1963_18240(EIF_REFERENCE);
extern EIF_REFERENCE F1963_18244(EIF_REFERENCE);
extern EIF_REFERENCE F1963_18246(EIF_REFERENCE);
extern void F1963_18247(EIF_REFERENCE, EIF_REFERENCE);
extern void F1963_18249(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1024(void);
extern EIF_REFERENCE F377_4526(EIF_REFERENCE);
extern EIF_REFERENCE F1908_17479(EIF_REFERENCE);
extern EIF_REFERENCE F1008_7607(EIF_REFERENCE);
extern char *(*R2288[])();
extern char *(*R11966[])();
extern char *(*R11799[])();

#ifdef __cplusplus
}
#endif

#endif
