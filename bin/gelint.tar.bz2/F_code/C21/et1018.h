
#ifndef _C21_et1018_
#define _C21_et1018_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1957_18186(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1957_18187(EIF_REFERENCE);
extern EIF_REFERENCE F1957_18189(EIF_REFERENCE);
extern EIF_REFERENCE F1957_18193(EIF_REFERENCE);
extern EIF_REFERENCE F1957_18195(EIF_REFERENCE);
extern void F1957_18196(EIF_REFERENCE, EIF_REFERENCE);
extern void F1957_18198(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1018(void);
extern void F1636_15323(EIF_REFERENCE);
extern EIF_REFERENCE F377_4575(EIF_REFERENCE);
extern void F1631_15277(EIF_REFERENCE);
extern EIF_REFERENCE F1008_7607(EIF_REFERENCE);
extern char *(*R11966[])();
extern char *(*R12051[])();
extern char *(*R11795[])();
extern char *(*R2394[])();

#ifdef __cplusplus
}
#endif

#endif
