
#ifndef _C21_et1022_
#define _C21_et1022_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1961_18228(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1022(void);
extern char *(*R2459[])();

#ifdef __cplusplus
}
#endif

#endif
