
#ifndef _C21_xm1044_
#define _C21_xm1044_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1983_18399(EIF_REFERENCE);
extern EIF_INTEGER_32 F1983_18404(EIF_REFERENCE);
extern void F1983_18406(EIF_REFERENCE, EIF_REFERENCE);
extern void F1983_18407(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1044(void);
extern char *(*R7272[])();

#ifdef __cplusplus
}
#endif

#endif
