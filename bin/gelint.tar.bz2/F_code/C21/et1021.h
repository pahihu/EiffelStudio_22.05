
#ifndef _C21_et1021_
#define _C21_et1021_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1960_18226(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1960_18227(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1021(void);
extern void F1792_16188(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2440[])();
extern EIF_TYPE_INDEX Y12288[];
extern EIF_TYPE_INDEX *Y12288_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
