
#ifndef _C21_et1039_
#define _C21_et1039_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1978_18310(EIF_REFERENCE);
extern void F1978_18311(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1039(void);
extern void F1791_16183(EIF_REFERENCE);
extern char *(*R2445[])();

#ifdef __cplusplus
}
#endif

#endif
