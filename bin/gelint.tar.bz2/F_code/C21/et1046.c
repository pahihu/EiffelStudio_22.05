/*
 * Code for class ET_CLASS_CODES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1046.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_CLASS_CODES}.is_basic */
EIF_BOOLEAN F1985_18418 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_NATURAL_8) 1U) <= arg1) && (EIF_BOOLEAN) (arg1 <= ((EIF_NATURAL_8) 51U)));
}

/* {ET_CLASS_CODES}.class_code */
EIF_NATURAL_8 F1985_18420 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTOUCR(2539,F1985_18450, (Current));
	F1557_14142(RTCW(loc1), arg1);
	tb1 = F1550_14041(RTCW(loc1));
	if (tb1) {
		tu1_1 = F1550_14033(RTCW(loc1));
		RTLE;
		return (EIF_NATURAL_8) tu1_1;
	} else {
		RTLE;
		return (EIF_NATURAL_8) ((EIF_NATURAL_8) 0U);
	}/* NOTREACHED */
	
}

/* {ET_CLASS_CODES}.codes_by_name */
static EIF_REFERENCE F1985_18450_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2539)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1572,1114,0xFF01,1979,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1572, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F1557_14126(RTCW(tr1), ((EIF_INTEGER_32) 28L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(138,F375_3632, (Current));
	F1557_14144(RTCW(Result), tr1);
	tr1 = RTOUCR(145,F377_4111, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 1U), tr1);
	tr1 = RTOUCR(147,F377_4113, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 11U), tr1);
	tr1 = RTOUCR(148,F377_4114, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 12U), tr1);
	tr1 = RTOUCR(156,F377_4126, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 21U), tr1);
	tr1 = RTOUCR(157,F377_4127, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 22U), tr1);
	tr1 = RTOUCR(158,F377_4128, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 23U), tr1);
	tr1 = RTOUCR(159,F377_4129, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 24U), tr1);
	tr1 = RTOUCR(163,F377_4138, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 31U), tr1);
	tr1 = RTOUCR(164,F377_4139, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 32U), tr1);
	tr1 = RTOUCR(165,F377_4140, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 33U), tr1);
	tr1 = RTOUCR(166,F377_4141, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 34U), tr1);
	tr1 = RTOUCR(171,F377_4148, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 41U), tr1);
	tr1 = RTOUCR(172,F377_4149, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 42U), tr1);
	tr1 = RTOUCR(167,F377_4144, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 51U), tr1);
	tr1 = RTOUCR(180,F377_4157, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 61U), tr1);
	tr1 = RTOUCR(152,F377_4121, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 71U), tr1);
	tr1 = RTOUCR(168,F377_4145, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 72U), tr1);
	tr1 = RTOUCR(169,F377_4146, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 73U), tr1);
	tr1 = RTOUCR(173,F377_4150, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 74U), tr1);
	tr1 = RTOUCR(174,F377_4151, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 101U), tr1);
	tr1 = RTOUCR(181,F377_4158, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 102U), tr1);
	tr1 = RTOUCR(183,F377_4159, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 103U), tr1);
	tr1 = RTOUCR(144,F377_4110, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 104U), tr1);
	tr1 = RTOUCR(142,F377_4108, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 105U), tr1);
	tr1 = RTOUCR(178,F377_4155, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 106U), tr1);
	tr1 = RTOUCR(1502,F377_4116, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 107U), tr1);
	tr1 = RTOUCR(161,F377_4133, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 108U), tr1);
	tr1 = RTOUCR(1523,F377_4134, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	F1557_14153(RTCW(Result), ((EIF_NATURAL_8) 109U), tr1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1985_18450 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2539,F1985_18450_body,(Current));
}

void EIF_Minit1046 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
