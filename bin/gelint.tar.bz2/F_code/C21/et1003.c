/*
 * Code for class ET_ALIAS_NAME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1003.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ALIAS_NAME}.make_and */
void F1942_17972 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'T';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_implies */
void F1942_17973 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'U';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_or */
void F1942_17974 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'V';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_xor */
void F1942_17975 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'W';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_div */
void F1942_17976 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'G';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_divide */
void F1942_17977 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'H';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_ge */
void F1942_17978 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'I';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_gt */
void F1942_17979 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'J';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_le */
void F1942_17980 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'K';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_lt */
void F1942_17981 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'L';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_minus */
void F1942_17982 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'M';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_mod */
void F1942_17983 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'N';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_plus */
void F1942_17984 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'O';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_power */
void F1942_17985 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'P';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_times */
void F1942_17986 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'Q';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_and_then */
void F1942_17987 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'X';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_or_else */
void F1942_17988 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'Y';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_dotdot */
void F1942_17989 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'S';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_not */
void F1942_17990 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) '[';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_bracket */
void F1942_17991 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'd';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.make_parenthesis */
void F1942_17992 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(401,F1942_18042, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tc1 = (EIF_CHARACTER_8) 'c';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_ALIAS_NAME}.is_bracket */
EIF_BOOLEAN F1942_17995 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'd';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix */
EIF_BOOLEAN F1942_17996 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	tc1 = (EIF_CHARACTER_8) 'G';
	if ((EIF_BOOLEAN) (*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) >= tc1)) {
		tc1 = (EIF_CHARACTER_8) 'Y';
		Result = (EIF_BOOLEAN) (*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) <= tc1);
	}
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_and */
EIF_BOOLEAN F1942_17997 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'T';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_and_then */
EIF_BOOLEAN F1942_17998 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'X';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_div */
EIF_BOOLEAN F1942_17999 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'G';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_divide */
EIF_BOOLEAN F1942_18000 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'H';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_dotdot */
EIF_BOOLEAN F1942_18001 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'S';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_ge */
EIF_BOOLEAN F1942_18002 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'I';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_gt */
EIF_BOOLEAN F1942_18003 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'J';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_implies */
EIF_BOOLEAN F1942_18004 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'U';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_le */
EIF_BOOLEAN F1942_18005 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'K';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_lt */
EIF_BOOLEAN F1942_18006 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'L';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_minus */
EIF_BOOLEAN F1942_18007 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'M';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_mod */
EIF_BOOLEAN F1942_18008 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'N';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_or */
EIF_BOOLEAN F1942_18009 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'V';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_or_else */
EIF_BOOLEAN F1942_18010 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'Y';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_plus */
EIF_BOOLEAN F1942_18011 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'O';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_power */
EIF_BOOLEAN F1942_18012 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'P';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_times */
EIF_BOOLEAN F1942_18013 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'Q';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infix_xor */
EIF_BOOLEAN F1942_18014 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'W';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_parenthesis */
EIF_BOOLEAN F1942_18015 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) 'c';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_prefix */
EIF_BOOLEAN F1942_18016 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	tc1 = (EIF_CHARACTER_8) '[';
	if ((EIF_BOOLEAN) (*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) >= tc1)) {
		tc1 = (EIF_CHARACTER_8) '^';
		Result = (EIF_BOOLEAN) (*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) <= tc1);
	}
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_prefix_minus */
EIF_BOOLEAN F1942_18017 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) '\\';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_prefix_plus */
EIF_BOOLEAN F1942_18018 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) ']';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_prefix_not */
EIF_BOOLEAN F1942_18019 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	tc2 = (EIF_CHARACTER_8) '[';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_prefixable */
EIF_BOOLEAN F1942_18020 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13259[dtype-1941])(Current)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13254[dtype-1938])(Current);
	}
	if (!tb1) {
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13250[dtype-1938])(Current);
	}
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.is_infixable */
EIF_BOOLEAN F1942_18021 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13239[dtype-1941])(Current)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13261[dtype-1938])(Current);
	}
	if (!tb1) {
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13260[dtype-1938])(Current);
	}
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.name */
EIF_REFERENCE F1942_18022 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13299[Dtype(Current)-1941])(Current);
}

/* {ET_ALIAS_NAME}.lower_name */
EIF_REFERENCE F1942_18023 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1942_18022(Current);
}

/* {ET_ALIAS_NAME}.alias_name */
EIF_REFERENCE F1942_18024 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	switch (*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_)) {
		case (EIF_CHARACTER_8) 'd':
			Result = RTOUCR(402,F377_5149, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'c':
			Result = RTOUCR(403,F377_5150, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'T':
			Result = RTOUCR(404,F377_5130, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'X':
			Result = RTOUCR(405,F377_5146, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'G':
			Result = RTOUCR(406,F377_5134, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'H':
			Result = RTOUCR(407,F377_5135, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'I':
			Result = RTOUCR(408,F377_5136, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'J':
			Result = RTOUCR(409,F377_5137, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'U':
			Result = RTOUCR(410,F377_5131, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'K':
			Result = RTOUCR(411,F377_5138, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'L':
			Result = RTOUCR(412,F377_5139, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'M':
			Result = RTOUCR(413,F377_5140, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'N':
			Result = RTOUCR(414,F377_5141, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'V':
			Result = RTOUCR(415,F377_5132, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'Y':
			Result = RTOUCR(416,F377_5147, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'O':
			Result = RTOUCR(417,F377_5142, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'P':
			Result = RTOUCR(418,F377_5143, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'Q':
			Result = RTOUCR(419,F377_5144, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'W':
			Result = RTOUCR(420,F377_5133, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'S':
			Result = RTOUCR(421,F377_5145, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) '\\':
			Result = RTOUCR(413,F377_5140, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) ']':
			Result = RTOUCR(417,F377_5142, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) '[':
			Result = RTOUCR(422,F377_5148, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		default:
			Result = RTOUCR(423,F377_5109, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
	}
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.alias_lower_name */
EIF_REFERENCE F1942_18025 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13299[Dtype(Current)-1941])(Current);
}

/* {ET_ALIAS_NAME}.hash_code */
EIF_INTEGER_32 F1942_18028 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	Result = (EIF_INTEGER_32) (tc1);
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.position */
EIF_REFERENCE F1942_18032 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1908_17479(RTCW(tr1));
	tb1 = F1290_12708(RTCW(Result));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1928_17797(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.last_leaf */
EIF_REFERENCE F1942_18034 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
	}/* NOTREACHED */
	
}

/* {ET_ALIAS_NAME}.set_alias_keyword */
void F1942_18035 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {ET_ALIAS_NAME}.set_convert_keyword */
void F1942_18036 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {ET_ALIAS_NAME}.set_prefix */
void F1942_18037 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	switch (*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_)) {
		case (EIF_CHARACTER_8) 'O':
			tc1 = (EIF_CHARACTER_8) ']';
			*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
			break;
		case (EIF_CHARACTER_8) 'M':
			tc1 = (EIF_CHARACTER_8) '\\';
			*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
			break;
	}
	RTLE;
}

/* {ET_ALIAS_NAME}.set_infix */
void F1942_18038 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	switch (*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_)) {
		case (EIF_CHARACTER_8) ']':
			tc1 = (EIF_CHARACTER_8) 'O';
			*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
			break;
		case (EIF_CHARACTER_8) '\\':
			tc1 = (EIF_CHARACTER_8) 'M';
			*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
			break;
	}
	RTLE;
}

/* {ET_ALIAS_NAME}.same_call_name */
EIF_BOOLEAN F1942_18039 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		switch (*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_)) {
			case (EIF_CHARACTER_8) 'd':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13264[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'c':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13265[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'T':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13240[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'X':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13241[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'G':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13242[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'H':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13243[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'I':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13245[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'J':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13246[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'U':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13247[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'K':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13248[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'L':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13249[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'M':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13250[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'N':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13251[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'V':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13252[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'Y':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13253[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'O':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13254[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'P':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13255[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'Q':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13256[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'W':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13257[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) 'S':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13258[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) '\\':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13260[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) ']':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13261[Dtype(RTCW(arg1))-1938])(arg1);
				break;
			case (EIF_CHARACTER_8) '[':
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13263[Dtype(RTCW(arg1))-1938])(arg1);
				break;
		}
	}
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.same_alias_name */
EIF_BOOLEAN F1942_18040 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R13268[Dtype(Current)-1941])(Current, arg1)) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			switch (*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_)) {
				case (EIF_CHARACTER_8) 'O':
					Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13261[Dtype(RTCW(arg1))-1938])(arg1);
					break;
				case (EIF_CHARACTER_8) 'M':
					Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13260[Dtype(RTCW(arg1))-1938])(arg1);
					break;
				case (EIF_CHARACTER_8) ']':
					Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13254[Dtype(RTCW(arg1))-1938])(arg1);
					break;
				case (EIF_CHARACTER_8) '\\':
					Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13250[Dtype(RTCW(arg1))-1938])(arg1);
					break;
				default:
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					break;
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_ALIAS_NAME}.default_keyword */
static EIF_REFERENCE F1942_18042_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(401)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTOUCR(227,F377_4557, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1942_18042 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(401,F1942_18042_body,(Current));
}

void EIF_Minit1003 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
