
#ifndef _C21_et1036_
#define _C21_et1036_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1975_18306(EIF_REFERENCE);
extern void F1975_18307(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1036(void);
extern void F1787_16169(EIF_REFERENCE);
extern char *(*R2482[])();

#ifdef __cplusplus
}
#endif

#endif
