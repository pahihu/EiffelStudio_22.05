/*
 * Code for class ET_ECF_OPTIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1048.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ECF_OPTIONS}.make */
void F1987_18459 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1566,0xFF01,1189,0xFF01,1189,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1551_14126(RTCW(tr1), ((EIF_INTEGER_32) 15L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOUCR(54,F987_7511, (Current));
	F1551_14144(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,136,0xFF01,1189,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 136, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1090,0xFF01,1203,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	tr2 = RTOUCR(5,F1212_10869, (Current));
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
	RTAR(tr1,tr2);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1179,0xFF01,0xFFF9,1,1090,0xFF01,1189,1096,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A521_52_2, (EIF_POINTER) _A521_52_2, (EIF_POINTER)(F1204_10803),tr1, 1, 1);
	}
	F137_1482(RTCW(loc1), tr4);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1567_14205(RTCW(tr1), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1566,0xFF01,1189,0xFF01,1189,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1551_14126(RTCW(tr1), ((EIF_INTEGER_32) 50L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTOUCR(54,F987_7511, (Current));
	F1551_14144(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1567_14205(RTCW(tr1), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1566,0xFF01,1189,0xFF01,1189,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1551_14126(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTOUCR(54,F987_7511, (Current));
	F1551_14144(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1567_14205(RTCW(tr1), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1566,0xFF01,1189,0xFF01,1189,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1551_14126(RTCW(tr1), ((EIF_INTEGER_32) 15L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOUCR(54,F987_7511, (Current));
	F1551_14144(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1567_14205(RTCW(tr1), loc1);
	RTLE;
}

/* {ET_ECF_OPTIONS}.value */
EIF_REFERENCE F1987_18460 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1551_14142(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = F1543_14041(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1543_14033(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			Result = F1987_18460(loc1, arg1);
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTLE;
	return Result;
}

/* {ET_ECF_OPTIONS}.primary_value */
EIF_REFERENCE F1987_18464 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1551_14142(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = F1543_14041(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1543_14033(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_ECF_OPTIONS}.primary_debug_value */
EIF_REFERENCE F1987_18465 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1551_14142(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F1543_14041(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1543_14033(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_ECF_OPTIONS}.primary_assertion_value */
EIF_REFERENCE F1987_18466 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1551_14142(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1543_14041(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		Result = F1543_14033(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_ECF_OPTIONS}.primary_warning_value */
EIF_REFERENCE F1987_18467 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1551_14142(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F1543_14041(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		Result = F1543_14033(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_ECF_OPTIONS}.set_primary_value */
void F1987_18474 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1551_14153(RTCW(tr1), arg2, arg1);
	RTLE;
}

/* {ET_ECF_OPTIONS}.set_primary_debug_value */
void F1987_18475 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1551_14153(RTCW(tr1), arg2, arg1);
	RTLE;
}

/* {ET_ECF_OPTIONS}.set_primary_assertion_value */
void F1987_18476 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1551_14153(RTCW(tr1), arg2, arg1);
	RTLE;
}

/* {ET_ECF_OPTIONS}.set_primary_warning_value */
void F1987_18477 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1551_14153(RTCW(tr1), arg2, arg1);
	RTLE;
}

/* {ET_ECF_OPTIONS}.set_secondary_options */
void F1987_18478 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {ET_ECF_OPTIONS}.set_description */
void F1987_18479 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit1048 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
