
#ifndef _C21_et1041_
#define _C21_et1041_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1980_18333(EIF_REFERENCE);
extern void EIF_Minit1041(void);

#ifdef __cplusplus
}
#endif

#endif
