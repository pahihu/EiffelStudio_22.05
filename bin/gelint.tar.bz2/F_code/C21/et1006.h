
#ifndef _C21_et1006_
#define _C21_et1006_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1945_18066(EIF_REFERENCE);
extern void EIF_Minit1006(void);

#ifdef __cplusplus
}
#endif

#endif
