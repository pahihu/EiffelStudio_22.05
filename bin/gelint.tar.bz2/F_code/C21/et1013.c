/*
 * Code for class ET_SYMBOL_OPERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1013.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_SYMBOL_OPERATOR}.is_infix_div */
EIF_BOOLEAN F1952_18127 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'G';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_divide */
EIF_BOOLEAN F1952_18128 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'H';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_ge */
EIF_BOOLEAN F1952_18129 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'I';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_gt */
EIF_BOOLEAN F1952_18130 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'J';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_le */
EIF_BOOLEAN F1952_18131 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'K';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_lt */
EIF_BOOLEAN F1952_18132 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'L';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_minus */
EIF_BOOLEAN F1952_18133 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'M';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_mod */
EIF_BOOLEAN F1952_18134 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'N';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_plus */
EIF_BOOLEAN F1952_18135 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'O';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_power */
EIF_BOOLEAN F1952_18136 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'P';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_times */
EIF_BOOLEAN F1952_18137 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'Q';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_dotdot */
EIF_BOOLEAN F1952_18138 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'S';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_prefix_minus */
EIF_BOOLEAN F1952_18140 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) '\\';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_prefix_plus */
EIF_BOOLEAN F1952_18141 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) ']';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.name */
EIF_REFERENCE F1952_18142 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	switch (*(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_)) {
		case (EIF_CHARACTER_8) 'G':
			Result = RTOUCR(406,F377_5134, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'H':
			Result = RTOUCR(407,F377_5135, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'I':
			Result = RTOUCR(408,F377_5136, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'J':
			Result = RTOUCR(409,F377_5137, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'K':
			Result = RTOUCR(411,F377_5138, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'L':
			Result = RTOUCR(412,F377_5139, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'M':
			Result = RTOUCR(413,F377_5140, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'N':
			Result = RTOUCR(414,F377_5141, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'O':
			Result = RTOUCR(417,F377_5142, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'P':
			Result = RTOUCR(418,F377_5143, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'Q':
			Result = RTOUCR(419,F377_5144, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'S':
			Result = RTOUCR(421,F377_5145, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) '\\':
			Result = RTOUCR(413,F377_5140, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		case (EIF_CHARACTER_8) ']':
			Result = RTOUCR(417,F377_5142, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
		default:
			Result = RTOUCR(423,F377_5109, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
			break;
	}
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.hash_code */
EIF_INTEGER_32 F1952_18143 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	Result = (EIF_INTEGER_32) (tc1);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.set_infix_minus */
void F1952_18144 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) 'M';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_SYMBOL_OPERATOR}.set_prefix_minus */
void F1952_18145 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\\';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_SYMBOL_OPERATOR}.set_infix_plus */
void F1952_18146 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) 'O';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_SYMBOL_OPERATOR}.set_prefix_plus */
void F1952_18147 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) ']';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

void EIF_Minit1013 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
