/*
 * Code for class CONTAINER [REAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1875.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F598_6338 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O5608[Dtype(Current)-586]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit1875 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
