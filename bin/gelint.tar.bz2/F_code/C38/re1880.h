
#ifndef _C38_re1880_
#define _C38_re1880_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F767_6449(EIF_REFERENCE);
extern void F767_6451(EIF_REFERENCE);
extern void EIF_Minit1880(void);
extern EIF_INTEGER_32 F831_6866(EIF_REFERENCE);
extern void F831_6896(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
