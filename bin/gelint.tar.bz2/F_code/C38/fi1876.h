
#ifndef _C38_fi1876_
#define _C38_fi1876_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F741_6436(EIF_REFERENCE);
extern void EIF_Minit1876(void);
extern EIF_INTEGER_32 F831_6865(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
