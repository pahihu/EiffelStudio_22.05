/*
 * Code for class DS_BILINKED_LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1895.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_BILINKED_LIST}.new_cursor */
EIF_REFERENCE F1516_13816 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		EIF_TYPE_INDEX typarr0[] = {0xFF01,1416,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y10771,Y10771_gen_type,Dftype(Current),1433);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 1416, _OBJSIZ_3_2_0_0_0_0_0_0_);
	}
	F1414_13274(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {DS_BILINKED_LIST}.force_left_cursor */
void F1516_13818 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_1_);
	if (tb1) {
		tr1 = RTCCL(arg1);
		F1512_13732(Current, tr1);
	} else {
		tb1 = F1337_13184(RTCW(arg2));
		if (tb1) {
			tr1 = RTCCL(arg1);
			F1512_13730(Current, tr1);
		} else {
			RTCT0("not_before", EX_CHECK);
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				tr1 = *(EIF_REFERENCE *)(loc2 + O2248[Dtype(loc2)-249]);
				loc3 = tr1;
				tb1 = EIF_TEST(loc3);
			}
			if (tb1) {
				RTCK0;
			} else {
				RTCF0;
			}
			loc1 = RTLNSMART(eif_final_id(Y10939,Y10939_gen_type,dftype,1511).id);
			tr1 = RTCCL(arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2239[Dtype(RTCW(loc1))-241])(loc1, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2246[Dtype(loc3)-246])(loc3, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2246[Dtype(RTCW(loc1))-246])(loc1, loc2);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))++;
		}
	}
	RTLE;
}

/* {DS_BILINKED_LIST}.remove_last */
void F1516_13821 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) == ((EIF_INTEGER_32) 1L))) {
		F1512_13766(Current);
	} else {
		RTCT0("two_or_more_items", EX_CHECK);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = *(EIF_REFERENCE *)(loc1 + O2248[Dtype(loc1)-249]);
			loc2 = tr1;
			tb1 = EIF_TEST(loc2);
		}
		if (tb1) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1512_13773(Current);
		F1512_13770(Current, loc2);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))--;
	}
	RTLE;
}

/* {DS_BILINKED_LIST}.remove_at_cursor */
void F1516_13822 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tb1 = F1337_13184(RTCW(arg1));
	if (tb1) {
		F1512_13752(Current);
	} else {
		tb1 = F1346_13195(RTCW(arg1));
		if (tb1) {
			F1516_13821(Current);
		} else {
			RTCT0("not_off_and_not_last_and_not_first", EX_CHECK);
			tb1 = '\0';
			tb2 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				tr1 = *(EIF_REFERENCE *)(loc1 + O2245[Dtype(loc1)-246]);
				loc2 = tr1;
				tb2 = EIF_TEST(loc2);
			}
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(loc1 + O2248[Dtype(loc1)-249]);
				loc3 = tr1;
				tb1 = EIF_TEST(loc3);
			}
			if (tb1) {
				RTCK0;
			} else {
				RTCF0;
			}
			F1512_13774(Current, loc1, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2246[Dtype(loc3)-246])(loc3, loc2);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))--;
		}
	}
	RTLE;
}

/* {DS_BILINKED_LIST}.set_first_cell */
void F1516_13828 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2250[Dtype(RTCW(arg1))-249])(arg1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {DS_BILINKED_LIST}.cursor_back */
void F1516_13829 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc3 = *(EIF_REFERENCE *)(loc4 + O2248[Dtype(loc4)-249]);
	} else {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	}
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc3 == NULL);
	F1414_13286(RTCW(arg1), loc3, loc2, (EIF_BOOLEAN) 0);
	if (loc2) {
		if ((EIF_BOOLEAN) !loc1) {
			F1453_13519(Current, arg1);
		}
	} else {
		if (loc1) {
			F1453_13518(Current, arg1);
		}
	}
	RTLE;
}

void EIF_Minit1895 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
