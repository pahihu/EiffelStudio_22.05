
#ifndef _C38_re1866_
#define _C38_re1866_

#ifdef __cplusplus
extern "C" {
#endif

extern void F527_6224(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F527_6226(EIF_REFERENCE);
extern EIF_INTEGER_32 F527_6227(EIF_REFERENCE);
extern EIF_INTEGER_32 F527_6228(EIF_REFERENCE);
extern EIF_INTEGER_32 F527_6229(EIF_REFERENCE);
extern EIF_BOOLEAN F527_6237(EIF_REFERENCE);
extern EIF_BOOLEAN F527_6238(EIF_REFERENCE);
extern void F527_6243(EIF_REFERENCE);
extern void EIF_Minit1866(void);
extern char *(*R5881[])();
extern char *(*R5882[])();

#ifdef __cplusplus
}
#endif

#endif
