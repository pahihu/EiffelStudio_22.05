/*
 * Code for class DS_BILINKABLE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1897.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_BILINKABLE}.put_right */
void F250_2395 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O2245[Dtype(Current)-246]) = (EIF_REFERENCE) arg1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2252[Dtype(RTCW(arg1))-249])(arg1, Current);
	RTLE;
}

/* {DS_BILINKABLE}.put_left */
void F250_2396 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O2248[Dtype(Current)-249]) = (EIF_REFERENCE) arg1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2251[Dtype(RTCW(arg1))-249])(arg1, Current);
	RTLE;
}

/* {DS_BILINKABLE}.forget_left */
void F250_2397 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + O2248[Dtype(Current)-249]) = (EIF_REFERENCE) NULL;
}

/* {DS_BILINKABLE}.attach_right */
void F250_2398 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O2245[Dtype(Current)-246]) = (EIF_REFERENCE) arg1;
}

/* {DS_BILINKABLE}.attach_left */
void F250_2399 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O2248[Dtype(Current)-249]) = (EIF_REFERENCE) arg1;
}

void EIF_Minit1897 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
