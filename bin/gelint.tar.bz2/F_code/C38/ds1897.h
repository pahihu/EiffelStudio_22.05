
#ifndef _C38_ds1897_
#define _C38_ds1897_

#ifdef __cplusplus
extern "C" {
#endif

extern void F250_2395(EIF_REFERENCE, EIF_REFERENCE);
extern void F250_2396(EIF_REFERENCE, EIF_REFERENCE);
extern void F250_2397(EIF_REFERENCE);
extern void F250_2398(EIF_REFERENCE, EIF_REFERENCE);
extern void F250_2399(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1897(void);
extern char *(*R2251[])();
extern char *(*R2252[])();
extern long O2245[];
extern long O2248[];

#ifdef __cplusplus
}
#endif

#endif
