
#ifndef _C38_to1894_
#define _C38_to1894_

#ifdef __cplusplus
extern "C" {
#endif

extern void F415_5674(EIF_REFERENCE, EIF_INTEGER_32);
extern void F415_5675(EIF_REFERENCE, EIF_REAL_64, EIF_INTEGER_32);
extern void F415_5681(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1894(void);
extern void F915_7138(EIF_REFERENCE, EIF_REAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y5062[];
extern EIF_TYPE_INDEX *Y5062_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
