
#ifndef _C38_ds1896_
#define _C38_ds1896_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1417_13288(EIF_REFERENCE);
extern void EIF_Minit1896(void);

#ifdef __cplusplus
}
#endif

#endif
