
#ifndef _C38_co1875_
#define _C38_co1875_

#ifdef __cplusplus
extern "C" {
#endif

extern void F598_6338(EIF_REFERENCE);
extern void EIF_Minit1875(void);
extern long O5608[];

#ifdef __cplusplus
}
#endif

#endif
