#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O1039[2];
void O1039_init () {
	O1039[0] = + _LNGOFF_1_0_0_1_;
	O1039[1] = + _LNGOFF_2_0_0_1_;
}

static EIF_TYPE_INDEX Y1356_pgtype0[] = {1538,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1356_pgtype1[] = {1538,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y1356_gen_type [2];
EIF_TYPE_INDEX Y1356 [2];
void Y1356_init (void)
{
	egc_routines_types [1356] = Y1356;
	egc_routines_gen_types [1356] = Y1356_gen_type;
	egc_routines_offset [1356] = 117;
	Y1356_gen_type [0] = Y1356_pgtype0;
	Y1356_gen_type [1] = Y1356_pgtype1;
	{long i; for (i = 0; i < 2; i++) Y1356[i] = 1538;};
}

static EIF_TYPE_INDEX Y1357_pgtype0[] = {1538,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1357_pgtype1[] = {1538,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y1357_gen_type [2];
EIF_TYPE_INDEX Y1357 [2];
void Y1357_init (void)
{
	egc_routines_types [1357] = Y1357;
	egc_routines_gen_types [1357] = Y1357_gen_type;
	egc_routines_offset [1357] = 117;
	Y1357_gen_type [0] = Y1357_pgtype0;
	Y1357_gen_type [1] = Y1357_pgtype1;
	{long i; for (i = 0; i < 2; i++) Y1357[i] = 1538;};
}

static EIF_TYPE_INDEX Y1377_pgtype0[] = {0xFF01,1538,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1377_pgtype1[] = {0xFF01,1538,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y1377_gen_type [2];
EIF_TYPE_INDEX Y1377 [2];
void Y1377_init (void)
{
	egc_routines_types [1377] = Y1377;
	egc_routines_gen_types [1377] = Y1377_gen_type;
	egc_routines_offset [1377] = 117;
	Y1377_gen_type [0] = Y1377_pgtype0;
	Y1377_gen_type [1] = Y1377_pgtype1;
	{long i; for (i = 0; i < 2; i++) Y1377[i] = 1538;};
}

long O1555[7];
void O1555_init () {
	O1555[0] = 0;
	{long i; for (i = 1; i < 3; i++) O1555[i] = + _LNGOFF_0_0_0_0_;}
	O1555[3] = + _CHROFF_0_0_;
	O1555[4] = + _I64OFF_0_0_0_0_0_0_0_;
	O1555[5] = 0;
	O1555[6] = + _LNGOFF_1_0_0_0_;
}

static EIF_TYPE_INDEX Y1590_pgtype0[] = {0xFF01,1538,0xFF01,159,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype1[] = {0xFF01,1538,0xFF01,162,0xFFFF};
static EIF_TYPE_INDEX Y1590_pgtype2[] = {0xFF01,1538,0xFF01,163,0xFFFF};
EIF_TYPE_INDEX *Y1590_gen_type [3];
EIF_TYPE_INDEX Y1590 [3];
void Y1590_init (void)
{
	egc_routines_types [1590] = Y1590;
	egc_routines_gen_types [1590] = Y1590_gen_type;
	egc_routines_offset [1590] = 160;
	Y1590_gen_type [0] = Y1590_pgtype0;
	Y1590_gen_type [1] = Y1590_pgtype1;
	Y1590_gen_type [2] = Y1590_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y1590[i] = 1538;};
}

static EIF_TYPE_INDEX Y1671_pgtype0[] = {0xFF01,1538,0xFF01,359,0xFFFF};
static EIF_TYPE_INDEX Y1671_pgtype1[] = {0xFF01,1538,0xFF01,360,0xFFFF};
static EIF_TYPE_INDEX Y1671_pgtype2[] = {0xFF01,1538,0xFF01,361,0xFFFF};
static EIF_TYPE_INDEX Y1671_pgtype3[] = {0xFF01,1538,0xFF01,362,0xFFFF};
static EIF_TYPE_INDEX Y1671_pgtype4[] = {0xFF01,1538,0xFF01,1614,0xFFFF};
static EIF_TYPE_INDEX Y1671_pgtype5[] = {0xFF01,1538,0xFF01,1615,0xFFFF};
static EIF_TYPE_INDEX Y1671_pgtype6[] = {0xFF01,1538,0xFF01,1616,0xFFFF};
static EIF_TYPE_INDEX Y1671_pgtype7[] = {0xFF01,1538,0xFF01,1617,0xFFFF};
static EIF_TYPE_INDEX Y1671_pgtype8[] = {0xFF01,1538,0xFF01,1618,0xFFFF};
static EIF_TYPE_INDEX Y1671_pgtype9[] = {0xFF01,1538,0xFF01,1619,0xFFFF};
EIF_TYPE_INDEX *Y1671_gen_type [10];
EIF_TYPE_INDEX Y1671 [10];
void Y1671_init (void)
{
	egc_routines_types [1671] = Y1671;
	egc_routines_gen_types [1671] = Y1671_gen_type;
	egc_routines_offset [1671] = 173;
	Y1671_gen_type [0] = Y1671_pgtype0;
	Y1671_gen_type [1] = Y1671_pgtype1;
	Y1671_gen_type [2] = Y1671_pgtype2;
	Y1671_gen_type [3] = Y1671_pgtype3;
	Y1671_gen_type [4] = Y1671_pgtype4;
	Y1671_gen_type [5] = Y1671_pgtype5;
	Y1671_gen_type [6] = Y1671_pgtype6;
	Y1671_gen_type [7] = Y1671_pgtype7;
	Y1671_gen_type [8] = Y1671_pgtype8;
	Y1671_gen_type [9] = Y1671_pgtype9;
	{long i; for (i = 0; i < 10; i++) Y1671[i] = 1538;};
}

long O1777[1414];
void O1777_init () {
	{long i; for (i = 0; i < 3; i++) O1777[i] =  + _REFACS_4_;}
	{long i; for (i = 1411; i < 1414; i++) O1777[i] =  + _REFACS_11_;}
}

long O1787[1412];
void O1787_init () {
	O1787[0] = + _CHROFF_10_0_;
	O1787[1409] = + _CHROFF_97_0_;
	O1787[1410] = + _CHROFF_99_0_;
	O1787[1411] = + _CHROFF_110_0_;
}

long O1788[1412];
void O1788_init () {
	O1788[0] =  + _REFACS_5_;
	{long i; for (i = 1409; i < 1412; i++) O1788[i] =  + _REFACS_8_;}
}

long O1789[1412];
void O1789_init () {
	O1789[0] =  + _REFACS_6_;
	{long i; for (i = 1409; i < 1412; i++) O1789[i] =  + _REFACS_4_;}
}

long O1790[1412];
void O1790_init () {
	O1790[0] =  + _REFACS_7_;
	{long i; for (i = 1409; i < 1412; i++) O1790[i] =  + _REFACS_5_;}
}

long O1792[1412];
void O1792_init () {
	O1792[0] =  + _REFACS_8_;
	{long i; for (i = 1409; i < 1412; i++) O1792[i] =  + _REFACS_6_;}
}

long O1793[1412];
void O1793_init () {
	O1793[0] =  + _REFACS_9_;
	{long i; for (i = 1409; i < 1412; i++) O1793[i] =  + _REFACS_7_;}
}

long O2048[135];
void O2048_init () {
	{long i; for (i = 0; i < 2; i++) O2048[i] = + _LNGOFF_2_4_0_0_;}
	O2048[2] = + _LNGOFF_4_6_0_0_;
	O2048[3] = + _LNGOFF_3_6_0_0_;
	O2048[4] = + _LNGOFF_4_6_0_0_;
	O2048[5] = + _LNGOFF_5_6_0_0_;
	O2048[134] = + _LNGOFF_2_4_0_0_;
}


#ifdef __cplusplus
}
#endif
