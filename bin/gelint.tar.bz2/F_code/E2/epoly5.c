#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2018[1092])();
void R2018_init () {
	R2018[0] = (char *(*)()) F889_7014;
	R2018[748] = (char *(*)()) F1051_8631;
	{long i; for (i = 836; i < 842; i++) R2018[i] = (char *(*)()) F1725_15852;}
	R2018[843] = (char *(*)()) F1725_15852;
	R2018[845] = (char *(*)()) F1725_15852;
	R2018[848] = (char *(*)()) F1725_15852;
	R2018[854] = (char *(*)()) F1725_15852;
	{long i; for (i = 861; i < 863; i++) R2018[i] = (char *(*)()) F1725_15852;}
	R2018[865] = (char *(*)()) F1725_15852;
	R2018[867] = (char *(*)()) F1725_15852;
	{long i; for (i = 869; i < 871; i++) R2018[i] = (char *(*)()) F1725_15852;}
	R2018[872] = (char *(*)()) F1725_15852;
	R2018[874] = (char *(*)()) F1725_15852;
	{long i; for (i = 876; i < 880; i++) R2018[i] = (char *(*)()) F1725_15852;}
	R2018[882] = (char *(*)()) F1725_15852;
	R2018[885] = (char *(*)()) F1725_15852;
	R2018[889] = (char *(*)()) F1725_15852;
	R2018[891] = (char *(*)()) F1725_15852;
	R2018[899] = (char *(*)()) F1725_15852;
	{long i; for (i = 904; i < 911; i++) R2018[i] = (char *(*)()) F1725_15852;}
	{long i; for (i = 921; i < 923; i++) R2018[i] = (char *(*)()) F1725_15852;}
	{long i; for (i = 923; i < 925; i++) R2018[i] = (char *(*)()) F1051_8631;}
	{long i; for (i = 967; i < 969; i++) R2018[i] = (char *(*)()) F1725_15852;}
	R2018[1013] = (char *(*)()) F1725_15852;
	{long i; for (i = 1024; i < 1026; i++) R2018[i] = (char *(*)()) F1725_15852;}
	{long i; for (i = 1028; i < 1031; i++) R2018[i] = (char *(*)()) F1725_15852;}
	{long i; for (i = 1032; i < 1034; i++) R2018[i] = (char *(*)()) F1725_15852;}
	{long i; for (i = 1035; i < 1038; i++) R2018[i] = (char *(*)()) F1725_15852;}
	{long i; for (i = 1039; i < 1042; i++) R2018[i] = (char *(*)()) F1725_15852;}
	{long i; for (i = 1043; i < 1048; i++) R2018[i] = (char *(*)()) F1725_15852;}
	R2018[1089] = (char *(*)()) F1979_18327;
	R2018[1091] = (char *(*)()) F1725_15852;
}

char *(*R2019[759])();
void R2019_init () {
	{long i; for (i = 0; i < 4; i++) R2019[i] = (char *(*)()) F382_5226;}
	R2019[516] = (char *(*)()) F889_7010;
	{long i; for (i = 752; i < 756; i++) R2019[i] = (char *(*)()) F1135_10037;}
	{long i; for (i = 757; i < 759; i++) R2019[i] = (char *(*)()) F1135_10037;}
}

char *(*R2021[759])();
void R2021_init () {
	{long i; for (i = 0; i < 4; i++) R2021[i] = (char *(*)()) F382_5227;}
	R2021[516] = (char *(*)()) F898_7057;
	{long i; for (i = 752; i < 756; i++) R2021[i] = (char *(*)()) F1135_10038;}
	{long i; for (i = 757; i < 759; i++) R2021[i] = (char *(*)()) F1135_10038;}
}

char *(*R2022[759])();
void R2022_init () {
	{long i; for (i = 0; i < 4; i++) R2022[i] = (char *(*)()) F382_5228;}
	R2022[516] = (char *(*)()) F889_7014;
	{long i; for (i = 752; i < 756; i++) R2022[i] = (char *(*)()) F1135_10040;}
	{long i; for (i = 757; i < 759; i++) R2022[i] = (char *(*)()) F1135_10040;}
}

char *(*R2024[759])();
void R2024_init () {
	{long i; for (i = 0; i < 4; i++) R2024[i] = (char *(*)()) F382_5223;}
	R2024[516] = (char *(*)()) F898_7058;
	{long i; for (i = 752; i < 756; i++) R2024[i] = (char *(*)()) F1135_10028;}
	{long i; for (i = 757; i < 759; i++) R2024[i] = (char *(*)()) F1135_10028;}
}

char *(*R2038[134])();
void R2038_init () {
	R2038[0] = (char *(*)()) F223_2139;
	R2038[3] = (char *(*)()) F227_2192;
	R2038[4] = (char *(*)()) F225_2177;
	R2038[133] = (char *(*)()) F223_2139;
}

char *(*R2043[134])();
void R2043_init () {
	R2043[0] = (char *(*)()) F223_2144;
	R2043[3] = (char *(*)()) F226_2179;
	R2043[4] = (char *(*)()) F225_2179;
	R2043[133] = (char *(*)()) F223_2144;
}

char *(*R2046[134])();
void R2046_init () {
	R2046[0] = (char *(*)()) F223_2147;
	R2046[3] = (char *(*)()) F226_2180;
	R2046[4] = (char *(*)()) F225_2180;
	R2046[133] = (char *(*)()) F223_2147;
}

char *(*R2047[134])();
void R2047_init () {
	R2047[0] = (char *(*)()) F224_2172;
	R2047[3] = (char *(*)()) F226_2184;
	R2047[4] = (char *(*)()) F225_2184;
	R2047[133] = (char *(*)()) F224_2172;
}

char *(*R2054[134])();
void R2054_init () {
	R2054[0] = (char *(*)()) F224_2173;
	R2054[3] = (char *(*)()) F226_2185;
	R2054[4] = (char *(*)()) F225_2185;
	R2054[133] = (char *(*)()) F224_2173;
}

char *(*R2055[134])();
void R2055_init () {
	R2055[0] = (char *(*)()) F224_2174;
	R2055[3] = (char *(*)()) F226_2186;
	R2055[4] = (char *(*)()) F225_2186;
	R2055[133] = (char *(*)()) F224_2174;
}

char *(*R2069[134])();
void R2069_init () {
	R2069[0] = (char *(*)()) F224_2175;
	R2069[3] = (char *(*)()) F227_2196;
	R2069[4] = (char *(*)()) F228_2200;
	R2069[133] = (char *(*)()) F357_3570;
}

char *(*R2070[134])();
void R2070_init () {
	R2070[0] = (char *(*)()) F224_2176;
	R2070[3] = (char *(*)()) F227_2195;
	R2070[4] = (char *(*)()) F228_2199;
	R2070[133] = (char *(*)()) F224_2176;
}

char *(*R2072[2])();
void R2072_init () {
	R2072[0] = (char *(*)()) F226_2178_2072_1;
	R2072[1] = (char *(*)()) F225_2178;
}
static EIF_REFERENCE F226_2178_2072_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F226_2178(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1096, 0x00).id, 1096, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2075[2])();
void R2075_init () {
	R2075[0] = (char *(*)()) F227_2193;
	R2075[1] = (char *(*)()) F228_2197;
}

char *(*R2236[10])();
void R2236_init () {
	R2236[0] = (char *(*)()) F242_2383;
	R2236[1] = (char *(*)()) F243_2383_2236_1;
	R2236[2] = (char *(*)()) F244_2383_2236_1;
	R2236[3] = (char *(*)()) F242_2383;
	R2236[4] = (char *(*)()) F243_2383_2236_1;
	R2236[5] = (char *(*)()) F242_2383;
	R2236[6] = (char *(*)()) F243_2383_2236_1;
	R2236[7] = (char *(*)()) F244_2383_2236_1;
	R2236[8] = (char *(*)()) F242_2383;
	R2236[9] = (char *(*)()) F243_2383_2236_1;
}
static EIF_REFERENCE F243_2383_2236_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F243_2383(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1096, 0x00).id, 1096, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F244_2383_2236_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F244_2383(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1126, 0x00).id, 1126, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2238[10])();
void R2238_init () {
	R2238[0] = (char *(*)()) F242_2385;
	R2238[1] = (char *(*)()) F243_2385_2238_4;
	R2238[2] = (char *(*)()) F244_2385_2238_4;
	R2238[3] = (char *(*)()) F242_2385;
	R2238[4] = (char *(*)()) F243_2385_2238_4;
	R2238[5] = (char *(*)()) F242_2385;
	R2238[6] = (char *(*)()) F243_2385_2238_4;
	R2238[7] = (char *(*)()) F244_2385_2238_4;
	R2238[8] = (char *(*)()) F242_2385;
	R2238[9] = (char *(*)()) F243_2385_2238_4;
}
static void F243_2385_2238_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F243_2385(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F244_2385_2238_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F244_2385(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R2239[10])();
void R2239_init () {
	R2239[0] = (char *(*)()) F242_2386;
	R2239[1] = (char *(*)()) F243_2386_2239_4;
	R2239[2] = (char *(*)()) F244_2386_2239_4;
	R2239[3] = (char *(*)()) F242_2386;
	R2239[4] = (char *(*)()) F243_2386_2239_4;
	R2239[5] = (char *(*)()) F242_2386;
	R2239[6] = (char *(*)()) F243_2386_2239_4;
	R2239[7] = (char *(*)()) F244_2386_2239_4;
	R2239[8] = (char *(*)()) F242_2386;
	R2239[9] = (char *(*)()) F243_2386_2239_4;
}
static void F243_2386_2239_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F243_2386(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F244_2386_2239_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F244_2386(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R2242[2])();
void R2242_init () {
	R2242[0] = (char *(*)()) F245_2388;
	R2242[1] = (char *(*)()) F246_2388_2242_1;
}
static EIF_REFERENCE F246_2388_2242_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F246_2388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1096, 0x00).id, 1096, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2246[5])();
void R2246_init () {
	R2246[0] = (char *(*)()) F247_2392;
	R2246[1] = (char *(*)()) F248_2392;
	R2246[2] = (char *(*)()) F249_2392;
	R2246[3] = (char *(*)()) F250_2395;
	R2246[4] = (char *(*)()) F251_2395;
}

char *(*R2247[5])();
void R2247_init () {
	R2247[0] = (char *(*)()) F247_2393;
	R2247[1] = (char *(*)()) F248_2393;
	R2247[2] = (char *(*)()) F249_2393;
	R2247[3] = (char *(*)()) F247_2393;
	R2247[4] = (char *(*)()) F248_2393;
}

char *(*R2250[2])();
void R2250_init () {
	R2250[0] = (char *(*)()) F250_2397;
	R2250[1] = (char *(*)()) F251_2397;
}

char *(*R2251[2])();
void R2251_init () {
	R2251[0] = (char *(*)()) F250_2398;
	R2251[1] = (char *(*)()) F251_2398;
}

char *(*R2252[2])();
void R2252_init () {
	R2252[0] = (char *(*)()) F250_2399;
	R2252[1] = (char *(*)()) F251_2399;
}

char *(*R2253[374])();
void R2253_init () {
	R2253[0] = (char *(*)()) F1219_10965;
	R2253[9] = (char *(*)()) F1228_11088;
	R2253[10] = (char *(*)()) F1229_11102;
	R2253[363] = (char *(*)()) F1582_14296;
	R2253[373] = (char *(*)()) F1591_14513;
}

char *(*R2256[374])();
void R2256_init () {
	R2256[0] = (char *(*)()) F253_2403;
	{long i; for (i = 9; i < 11; i++) R2256[i] = (char *(*)()) F253_2403;}
	R2256[363] = (char *(*)()) F186_1773;
	R2256[373] = (char *(*)()) F186_1773;
}

char *(*R2259[374])();
void R2259_init () {
	R2259[0] = (char *(*)()) F1219_10970;
	R2259[9] = (char *(*)()) F1228_11082;
	R2259[10] = (char *(*)()) F1229_11101;
	R2259[363] = (char *(*)()) F1582_14281;
	R2259[373] = (char *(*)()) F1208_10855;
}

char *(*R2261[374])();
void R2261_init () {
	R2261[0] = (char *(*)()) F1219_10971;
	R2261[9] = (char *(*)()) F1228_11084;
	R2261[10] = (char *(*)()) F1229_11096;
	R2261[363] = (char *(*)()) F1582_14276;
	R2261[373] = (char *(*)()) F1586_14459;
}

char *(*R2262[374])();
void R2262_init () {
	R2262[0] = (char *(*)()) F1219_10972_2262_1;
	R2262[9] = (char *(*)()) F1228_11085_2262_1;
	R2262[10] = (char *(*)()) F1229_11097_2262_1;
	R2262[363] = (char *(*)()) F1582_14277;
	R2262[373] = (char *(*)()) F1592_14530_2262_1;
}
static EIF_REFERENCE F1219_10972_2262_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1219_10972(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1126, 0x00).id, 1126, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1228_11085_2262_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1228_11085(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1126, 0x00).id, 1126, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1229_11097_2262_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1229_11097(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1126, 0x00).id, 1126, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1592_14530_2262_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1592_14530(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1126, 0x00).id, 1126, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2263[374])();
void R2263_init () {
	R2263[0] = (char *(*)()) F253_2410;
	{long i; for (i = 9; i < 11; i++) R2263[i] = (char *(*)()) F253_2410;}
	R2263[363] = (char *(*)()) F1582_14286;
	R2263[373] = (char *(*)()) F1591_14519;
}

char *(*R2267[1821])();
void R2267_init () {
	{long i; for (i = 0; i < 5; i++) R2267[i] = (char *(*)()) F255_2636;}
	R2267[758] = (char *(*)()) F255_2636;
	{long i; for (i = 768; i < 777; i++) R2267[i] = (char *(*)()) F255_2636;}
	{long i; for (i = 778; i < 792; i++) R2267[i] = (char *(*)()) F255_2636;}
	R2267[792] = (char *(*)()) F1047_8498;
	{long i; for (i = 793; i < 796; i++) R2267[i] = (char *(*)()) F255_2636;}
	R2267[978] = (char *(*)()) F255_2636;
	R2267[981] = (char *(*)()) F1236_11505;
	{long i; for (i = 995; i < 997; i++) R2267[i] = (char *(*)()) F1236_11505;}
	R2267[1806] = (char *(*)()) F255_2636;
	R2267[1820] = (char *(*)()) F255_2636;
}

char *(*R2268[1821])();
void R2268_init () {
	{long i; for (i = 0; i < 5; i++) R2268[i] = (char *(*)()) F255_2637;}
	R2268[758] = (char *(*)()) F255_2637;
	{long i; for (i = 768; i < 777; i++) R2268[i] = (char *(*)()) F255_2637;}
	{long i; for (i = 778; i < 792; i++) R2268[i] = (char *(*)()) F255_2637;}
	R2268[792] = (char *(*)()) F1047_8499;
	{long i; for (i = 793; i < 796; i++) R2268[i] = (char *(*)()) F255_2637;}
	R2268[978] = (char *(*)()) F255_2637;
	R2268[981] = (char *(*)()) F1236_11506;
	{long i; for (i = 995; i < 997; i++) R2268[i] = (char *(*)()) F1236_11506;}
	R2268[1806] = (char *(*)()) F255_2637;
	R2268[1820] = (char *(*)()) F255_2637;
}


#ifdef __cplusplus
}
#endif
