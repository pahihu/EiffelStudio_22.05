#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R1587[2])();
void R1587_init () {
	R1587[0] = (char *(*)()) F162_1639;
	R1587[1] = (char *(*)()) F163_1642;
}

char *(*R1595[1890])();
void R1595_init () {
	{long i; for (i = 0; i < 2; i++) R1595[i] = (char *(*)()) F164_1645;}
	{long i; for (i = 3; i < 5; i++) R1595[i] = (char *(*)()) F164_1645;}
	{long i; for (i = 1057; i < 1060; i++) R1595[i] = (char *(*)()) F164_1645;}
	R1595[1888] = (char *(*)()) F2053_20777;
	R1595[1889] = (char *(*)()) F2054_20784;
}

char *(*R1605[1903])();
void R1605_init () {
	R1605[0] = (char *(*)()) F171_1669;
	R1605[1902] = (char *(*)()) F192_1826;
}

char *(*R1606[1903])();
void R1606_init () {
	R1606[0] = (char *(*)()) F171_1670;
	R1606[1902] = (char *(*)()) F192_1827;
}

char *(*R1607[1903])();
void R1607_init () {
	R1607[0] = (char *(*)()) F171_1671;
	R1607[1902] = (char *(*)()) F192_1828;
}

char *(*R1608[1903])();
void R1608_init () {
	R1608[0] = (char *(*)()) F171_1672;
	R1608[1902] = (char *(*)()) F192_1829;
}

char *(*R1609[1903])();
void R1609_init () {
	R1609[0] = (char *(*)()) F171_1673;
	R1609[1902] = (char *(*)()) F192_1830;
}


#ifdef __cplusplus
}
#endif
