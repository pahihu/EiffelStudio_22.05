#include "epoly3.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R1610[1903])();
void R1610_init () {
	R1610[0] = (char *(*)()) F171_1674;
	R1610[1902] = (char *(*)()) F192_1831;
}

char *(*R1611[1903])();
void R1611_init () {
	R1611[0] = (char *(*)()) F171_1675;
	R1611[1902] = (char *(*)()) F192_1832;
}

char *(*R1612[1903])();
void R1612_init () {
	R1612[0] = (char *(*)()) F171_1676;
	R1612[1902] = (char *(*)()) F192_1833;
}

static EIF_TYPE_INDEX Y1670_pgtype0[] = {0xFF01,359,0xFFFF};
static EIF_TYPE_INDEX Y1670_pgtype1[] = {0xFF01,360,0xFFFF};
static EIF_TYPE_INDEX Y1670_pgtype2[] = {0xFF01,361,0xFFFF};
static EIF_TYPE_INDEX Y1670_pgtype3[] = {0xFF01,362,0xFFFF};
static EIF_TYPE_INDEX Y1670_pgtype4[] = {0xFF01,1614,0xFFFF};
static EIF_TYPE_INDEX Y1670_pgtype5[] = {0xFF01,1615,0xFFFF};
static EIF_TYPE_INDEX Y1670_pgtype6[] = {0xFF01,1616,0xFFFF};
static EIF_TYPE_INDEX Y1670_pgtype7[] = {0xFF01,1617,0xFFFF};
static EIF_TYPE_INDEX Y1670_pgtype8[] = {0xFF01,1618,0xFFFF};
static EIF_TYPE_INDEX Y1670_pgtype9[] = {0xFF01,1619,0xFFFF};
EIF_TYPE_INDEX *Y1670_gen_type [10];
EIF_TYPE_INDEX Y1670 [10];
void Y1670_init (void)
{
	egc_routines_types [1670] = Y1670;
	egc_routines_gen_types [1670] = Y1670_gen_type;
	egc_routines_offset [1670] = 173;
	Y1670_gen_type [0] = Y1670_pgtype0;
	Y1670_gen_type [1] = Y1670_pgtype1;
	Y1670_gen_type [2] = Y1670_pgtype2;
	Y1670_gen_type [3] = Y1670_pgtype3;
	Y1670_gen_type [4] = Y1670_pgtype4;
	Y1670_gen_type [5] = Y1670_pgtype5;
	Y1670_gen_type [6] = Y1670_pgtype6;
	Y1670_gen_type [7] = Y1670_pgtype7;
	Y1670_gen_type [8] = Y1670_pgtype8;
	Y1670_gen_type [9] = Y1670_pgtype9;
	Y1670[0] = 359;
	Y1670[1] = 360;
	Y1670[2] = 361;
	Y1670[3] = 362;
	Y1670[4] = 1614;
	Y1670[5] = 1615;
	Y1670[6] = 1616;
	Y1670[7] = 1617;
	Y1670[8] = 1618;
	Y1670[9] = 1619;
}

char *(*R1691[11])();
void R1691_init () {
	R1691[0] = (char *(*)()) F1582_14275;
	R1691[10] = (char *(*)()) F1591_14508;
}

char *(*R1694[11])();
void R1694_init () {
	R1694[0] = (char *(*)()) F1582_14280;
	R1694[10] = (char *(*)()) F1591_14511;
}

char *(*R1794[1412])();
void R1794_init () {
	R1794[0] = (char *(*)()) F203_1892;
	{long i; for (i = 1410; i < 1412; i++) R1794[i] = (char *(*)()) F304_3403;}
}

char *(*R1900[2])();
void R1900_init () {
	R1900[0] = (char *(*)()) F206_2001;
	R1900[1] = (char *(*)()) F207_2008;
}

char *(*R1908[329])();
void R1908_init () {
	R1908[0] = (char *(*)()) F1246_11710;
	R1908[1] = (char *(*)()) F1247_11715;
	R1908[2] = (char *(*)()) F1248_11722;
	R1908[321] = (char *(*)()) F1551_14132;
	R1908[322] = (char *(*)()) F1552_14132_1908_5;
	R1908[323] = (char *(*)()) F1553_14132_1908_5;
	R1908[324] = (char *(*)()) F1554_14132_1908_5;
	R1908[325] = (char *(*)()) F1555_14132_1908_5;
	R1908[326] = (char *(*)()) F1556_14132_1908_5;
	R1908[327] = (char *(*)()) F1557_14132_1908_5;
	R1908[328] = (char *(*)()) F1558_14132_1908_5;
}
static EIF_REFERENCE F1552_14132_1908_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1552_14132(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1096, 0x00).id, 1096, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1553_14132_1908_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1553_14132(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1129, 0x00).id, 1129, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1554_14132_1908_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1554_14132(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F1555_14132_1908_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1555_14132(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1105, 0x00).id, 1105, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1556_14132_1908_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1556_14132(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_REFERENCE F1557_14132_1908_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1557_14132(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1114, 0x00).id, 1114, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1558_14132_1908_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1558_14132(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1096, 0x00).id, 1096, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y1910_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype8[] = {0xFF01,1189,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype9[] = {0xFF01,1189,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype10[] = {0xFF01,1189,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype11[] = {0xFF01,1189,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype32[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype33[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype34[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype35[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype36[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype37[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype38[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype39[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype40[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype41[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype42[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype43[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype44[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype45[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype46[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype47[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype48[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype49[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype50[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1910_pgtype51[] = {0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y1910_gen_type [1367];
EIF_TYPE_INDEX Y1910 [1367];
void Y1910_init (void)
{
	egc_routines_types [1910] = Y1910;
	egc_routines_gen_types [1910] = Y1910_gen_type;
	egc_routines_offset [1910] = 207;
	Y1910_gen_type [0] = Y1910_pgtype0;
	Y1910_gen_type [1] = Y1910_pgtype1;
	Y1910_gen_type [2] = Y1910_pgtype2;
	Y1910_gen_type [3] = Y1910_pgtype3;
	Y1910_gen_type [4] = Y1910_pgtype4;
	Y1910_gen_type [5] = Y1910_pgtype5;
	Y1910_gen_type [6] = Y1910_pgtype6;
	Y1910_gen_type [7] = Y1910_pgtype7;
	Y1910_gen_type [1037] = Y1910_pgtype8;
	Y1910_gen_type [1038] = Y1910_pgtype9;
	Y1910_gen_type [1039] = Y1910_pgtype10;
	Y1910_gen_type [1040] = Y1910_pgtype11;
	Y1910_gen_type [1233] = Y1910_pgtype12;
	Y1910_gen_type [1234] = Y1910_pgtype13;
	Y1910_gen_type [1235] = Y1910_pgtype14;
	Y1910_gen_type [1236] = Y1910_pgtype15;
	Y1910_gen_type [1237] = Y1910_pgtype16;
	Y1910_gen_type [1238] = Y1910_pgtype17;
	Y1910_gen_type [1239] = Y1910_pgtype18;
	Y1910_gen_type [1240] = Y1910_pgtype19;
	Y1910_gen_type [1281] = Y1910_pgtype20;
	Y1910_gen_type [1282] = Y1910_pgtype21;
	Y1910_gen_type [1283] = Y1910_pgtype22;
	Y1910_gen_type [1284] = Y1910_pgtype23;
	Y1910_gen_type [1285] = Y1910_pgtype24;
	Y1910_gen_type [1286] = Y1910_pgtype25;
	Y1910_gen_type [1287] = Y1910_pgtype26;
	Y1910_gen_type [1288] = Y1910_pgtype27;
	Y1910_gen_type [1343] = Y1910_pgtype28;
	Y1910_gen_type [1344] = Y1910_pgtype29;
	Y1910_gen_type [1345] = Y1910_pgtype30;
	Y1910_gen_type [1346] = Y1910_pgtype31;
	Y1910_gen_type [1347] = Y1910_pgtype32;
	Y1910_gen_type [1348] = Y1910_pgtype33;
	Y1910_gen_type [1349] = Y1910_pgtype34;
	Y1910_gen_type [1350] = Y1910_pgtype35;
	Y1910_gen_type [1351] = Y1910_pgtype36;
	Y1910_gen_type [1352] = Y1910_pgtype37;
	Y1910_gen_type [1353] = Y1910_pgtype38;
	Y1910_gen_type [1354] = Y1910_pgtype39;
	Y1910_gen_type [1355] = Y1910_pgtype40;
	Y1910_gen_type [1356] = Y1910_pgtype41;
	Y1910_gen_type [1357] = Y1910_pgtype42;
	Y1910_gen_type [1358] = Y1910_pgtype43;
	Y1910_gen_type [1359] = Y1910_pgtype44;
	Y1910_gen_type [1360] = Y1910_pgtype45;
	Y1910_gen_type [1361] = Y1910_pgtype46;
	Y1910_gen_type [1362] = Y1910_pgtype47;
	Y1910_gen_type [1363] = Y1910_pgtype48;
	Y1910_gen_type [1364] = Y1910_pgtype49;
	Y1910_gen_type [1365] = Y1910_pgtype50;
	Y1910_gen_type [1366] = Y1910_pgtype51;
	{long i; for (i = 1037; i < 1041; i++) Y1910[i] = 1189;};
}

char *(*R2016[1092])();
void R2016_init () {
	R2016[0] = (char *(*)()) F890_7037;
	R2016[748] = (char *(*)()) F218_2115;
	R2016[836] = (char *(*)()) F1726_15860;
	R2016[837] = (char *(*)()) F1727_15875;
	R2016[838] = (char *(*)()) F1728_15892;
	{long i; for (i = 839; i < 842; i++) R2016[i] = (char *(*)()) F1729_15908;}
	R2016[843] = (char *(*)()) F1716_15814;
	R2016[845] = (char *(*)()) F1734_15947;
	R2016[848] = (char *(*)()) F1738_15974;
	R2016[854] = (char *(*)()) F1702_15754;
	{long i; for (i = 861; i < 863; i++) R2016[i] = (char *(*)()) F1745_16027;}
	R2016[865] = (char *(*)()) F1745_16027;
	R2016[867] = (char *(*)()) F1745_16027;
	{long i; for (i = 869; i < 871; i++) R2016[i] = (char *(*)()) F1745_16027;}
	R2016[872] = (char *(*)()) F1761_16052;
	R2016[874] = (char *(*)()) F1763_16064;
	{long i; for (i = 876; i < 878; i++) R2016[i] = (char *(*)()) F1716_15814;}
	R2016[878] = (char *(*)()) F1768_16087;
	R2016[879] = (char *(*)()) F1769_16092;
	R2016[882] = (char *(*)()) F1716_15814;
	R2016[885] = (char *(*)()) F1763_16064;
	R2016[889] = (char *(*)()) F1716_15814;
	R2016[891] = (char *(*)()) F1781_16157;
	R2016[899] = (char *(*)()) F1702_15754;
	R2016[904] = (char *(*)()) F1702_15754;
	R2016[905] = (char *(*)()) F1763_16064;
	R2016[906] = (char *(*)()) F1761_16052;
	R2016[907] = (char *(*)()) F1734_15947;
	{long i; for (i = 908; i < 910; i++) R2016[i] = (char *(*)()) F1702_15754;}
	R2016[910] = (char *(*)()) F1761_16052;
	{long i; for (i = 921; i < 923; i++) R2016[i] = (char *(*)()) F1810_16307;}
	R2016[923] = (char *(*)()) F218_2115;
	R2016[924] = (char *(*)()) F1814_16332;
	{long i; for (i = 967; i < 969; i++) R2016[i] = (char *(*)()) F1856_16655;}
	R2016[1013] = (char *(*)()) F1903_17432;
	{long i; for (i = 1024; i < 1026; i++) R2016[i] = (char *(*)()) F1716_15814;}
	R2016[1028] = (char *(*)()) F1716_15814;
	R2016[1029] = (char *(*)()) F1919_17741;
	R2016[1030] = (char *(*)()) F1716_15814;
	{long i; for (i = 1032; i < 1034; i++) R2016[i] = (char *(*)()) F1716_15814;}
	{long i; for (i = 1035; i < 1038; i++) R2016[i] = (char *(*)()) F1716_15814;}
	{long i; for (i = 1039; i < 1042; i++) R2016[i] = (char *(*)()) F1716_15814;}
	{long i; for (i = 1043; i < 1048; i++) R2016[i] = (char *(*)()) F1716_15814;}
	R2016[1089] = (char *(*)()) F1702_15754;
	R2016[1091] = (char *(*)()) F1981_18357;
}

char *(*R2017[1092])();
void R2017_init () {
	R2017[0] = (char *(*)()) F889_7010;
	R2017[748] = (char *(*)()) F1638_15345;
	{long i; for (i = 836; i < 842; i++) R2017[i] = (char *(*)()) F1725_15845;}
	R2017[843] = (char *(*)()) F1725_15845;
	R2017[845] = (char *(*)()) F1725_15845;
	R2017[848] = (char *(*)()) F1725_15845;
	R2017[854] = (char *(*)()) F1725_15845;
	{long i; for (i = 861; i < 863; i++) R2017[i] = (char *(*)()) F1725_15845;}
	R2017[865] = (char *(*)()) F1725_15845;
	R2017[867] = (char *(*)()) F1725_15845;
	{long i; for (i = 869; i < 871; i++) R2017[i] = (char *(*)()) F1725_15845;}
	R2017[872] = (char *(*)()) F1725_15845;
	R2017[874] = (char *(*)()) F1725_15845;
	{long i; for (i = 876; i < 880; i++) R2017[i] = (char *(*)()) F1725_15845;}
	R2017[882] = (char *(*)()) F1725_15845;
	R2017[885] = (char *(*)()) F1725_15845;
	R2017[889] = (char *(*)()) F1725_15845;
	R2017[891] = (char *(*)()) F1725_15845;
	R2017[899] = (char *(*)()) F1725_15845;
	{long i; for (i = 904; i < 911; i++) R2017[i] = (char *(*)()) F1725_15845;}
	{long i; for (i = 921; i < 923; i++) R2017[i] = (char *(*)()) F1725_15845;}
	{long i; for (i = 923; i < 925; i++) R2017[i] = (char *(*)()) F1810_16301;}
	{long i; for (i = 967; i < 969; i++) R2017[i] = (char *(*)()) F1725_15845;}
	R2017[1013] = (char *(*)()) F1725_15845;
	{long i; for (i = 1024; i < 1026; i++) R2017[i] = (char *(*)()) F1725_15845;}
	{long i; for (i = 1028; i < 1031; i++) R2017[i] = (char *(*)()) F1725_15845;}
	{long i; for (i = 1032; i < 1034; i++) R2017[i] = (char *(*)()) F1725_15845;}
	{long i; for (i = 1035; i < 1038; i++) R2017[i] = (char *(*)()) F1725_15845;}
	{long i; for (i = 1039; i < 1042; i++) R2017[i] = (char *(*)()) F1725_15845;}
	{long i; for (i = 1043; i < 1048; i++) R2017[i] = (char *(*)()) F1725_15845;}
	R2017[1089] = (char *(*)()) F1979_18326;
	R2017[1091] = (char *(*)()) F1725_15845;
}


#ifdef __cplusplus
}
#endif
