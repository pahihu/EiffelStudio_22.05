
#ifndef _C34_to1670_
#define _C34_to1670_

#ifdef __cplusplus
extern "C" {
#endif

extern void F411_5674(EIF_REFERENCE, EIF_INTEGER_32);
extern void F411_5675(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F411_5681(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1670(void);
extern void F911_7138(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y5062[];
extern EIF_TYPE_INDEX *Y5062_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
