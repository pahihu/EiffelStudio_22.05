
#ifndef _C34_ds1691_
#define _C34_ds1691_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1406_13240(EIF_REFERENCE);
extern void EIF_Minit1691(void);

#ifdef __cplusplus
}
#endif

#endif
