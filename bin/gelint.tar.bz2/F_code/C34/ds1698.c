/*
 * Code for class DS_SPARSE_CONTAINER_CURSOR [INTEGER_32, INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1698.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_CONTAINER_CURSOR}.make */
void F1373_13213 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -2L);
	RTLE;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.after */
EIF_BOOLEAN F1373_13215 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) == ((EIF_INTEGER_32) -3L));
}

/* {DS_SPARSE_CONTAINER_CURSOR}.before */
EIF_BOOLEAN F1373_13216 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) == ((EIF_INTEGER_32) -2L));
}

/* {DS_SPARSE_CONTAINER_CURSOR}.off */
EIF_BOOLEAN F1373_13217 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) < ((EIF_INTEGER_32) 0L));
}

/* {DS_SPARSE_CONTAINER_CURSOR}.set_position */
void F1373_13219 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.set_after */
void F1373_13220 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -3L);
}

/* {DS_SPARSE_CONTAINER_CURSOR}.set_before */
void F1373_13221 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -2L);
}

/* {DS_SPARSE_CONTAINER_CURSOR}.correct_mismatch */
void F1373_13226 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOUCR(10,F963_7258, (Current))) + _REFACS_7_);
	loc2 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
		tb2 = F1189_10581(loc2);
		tb1 = tb2;
	}
	if (tb1) {
		F1373_13227(Current);
	} else {
		tb1 = F1182_10246(loc2);
		if (tb1) {
			loc1 = F1182_10280(loc2);
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 20130823L))) {
				F1373_13227(Current);
			} else {
				F963_7257(Current);
			}
		} else {
			F963_7257(Current);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.correct_mismatch_20130823 */
void F1373_13227 (EIF_REFERENCE Current)
{
	GTCX
	
	
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_))--;
}

void EIF_Minit1698 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
