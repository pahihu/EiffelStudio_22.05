
#ifndef _C34_to1689_
#define _C34_to1689_

#ifdef __cplusplus
extern "C" {
#endif

extern void F412_5674(EIF_REFERENCE, EIF_INTEGER_32);
extern void F412_5675(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F412_5681(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1689(void);
extern void F912_7138(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y5062[];
extern EIF_TYPE_INDEX *Y5062_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
