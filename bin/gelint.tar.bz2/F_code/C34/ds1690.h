
#ifndef _C34_ds1690_
#define _C34_ds1690_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1580_14267(EIF_REFERENCE);
extern void F1580_14269(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1580_14270(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1690(void);
extern void F1373_13213(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_TYPE_INDEX Y10771[];
extern EIF_TYPE_INDEX *Y10771_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
