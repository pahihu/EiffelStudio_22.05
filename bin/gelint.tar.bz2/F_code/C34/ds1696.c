/*
 * Code for class DS_SPARSE_SET [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1696.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_SET}.make_equal */
void F1576_14207 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1547_14032(Current, arg1);
	tr1 = RTLNSMART(eif_final_id(Y10813,Y10813_gen_type,Dftype(Current),1459).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_SPARSE_SET}.item */
EIF_INTEGER_32 F1576_14210 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1547_14065(Current, arg1);
	RTLE;
	return (EIF_INTEGER_32) F1578_14242(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_));
}

/* {DS_SPARSE_SET}.has */
EIF_BOOLEAN F1576_14212 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1547_14065(Current, arg1);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_SET}.extendible */
EIF_BOOLEAN F1576_14213 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_) >= (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) + arg1));
}

/* {DS_SPARSE_SET}.search */
void F1576_14216 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1547_14065(Current, arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_6_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_);
	RTLE;
}

/* {DS_SPARSE_SET}.is_equal */
EIF_BOOLEAN F1576_14217 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tb2 = '\0';
		tr1 = RTOUCR(98,F1192_10678, (Current));
		tb3 = F30_406(RTCW(tr1), Current, arg1);
		if (tb3) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_7_0_0_8_);
			tb2 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) == ti4_1);
		}
		if (tb2) {
			tb1 = F1461_13523(Current, arg1);
		}
		if (tb1) {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L)))) break;
				if ((EIF_BOOLEAN) (F1578_14243(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
					loc1 = F1578_14242(Current, loc2);
					Result = F1576_14212(RTCW(arg1), loc1);
				}
				loc2--;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_SET}.put */
void F1576_14218 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1547_14051(Current);
	F1547_14065(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		F1578_14246(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_));
	} else {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_))++;
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
		} else {
			ti4_1 = F1578_14243(Current, loc1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
		}
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_4_);
		ti4_1 = F1578_14259(Current, loc2);
		F1578_14253(Current, ti4_1, loc1);
		F1578_14260(Current, loc1, loc2);
		F1578_14246(Current, arg1, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_SET}.put_new */
void F1576_14219 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1547_14051(Current);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_))++;
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
	} else {
		ti4_1 = F1578_14243(Current, loc1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
	}
	loc2 = F1580_14270(Current, arg1);
	ti4_1 = F1578_14259(Current, loc2);
	F1578_14253(Current, ti4_1, loc1);
	F1578_14260(Current, loc1, loc2);
	F1578_14246(Current, arg1, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_SET}.put_last */
void F1576_14220 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1547_14051(Current);
	F1547_14065(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		F1578_14246(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_));
	} else {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_))) {
			F1547_14057(Current);
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_) = (EIF_INTEGER_32) loc1;
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_4_);
		ti4_1 = F1578_14259(Current, loc2);
		F1578_14253(Current, ti4_1, loc1);
		F1578_14260(Current, loc1, loc2);
		F1578_14246(Current, arg1, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_SET}.force */
void F1576_14221 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1547_14051(Current);
	F1547_14065(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		F1578_14246(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_));
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_))) {
			ti4_1 = F1547_14121(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) + ((EIF_INTEGER_32) 1L)));
			F1547_14056(Current, ti4_1);
			loc2 = F1580_14270(Current, arg1);
		} else {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_4_);
		}
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_))++;
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
		} else {
			ti4_1 = F1578_14243(Current, loc1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
		}
		ti4_1 = F1578_14259(Current, loc2);
		F1578_14253(Current, ti4_1, loc1);
		F1578_14260(Current, loc1, loc2);
		F1578_14246(Current, arg1, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_SET}.force_new */
void F1576_14222 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1547_14051(Current);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_))) {
		ti4_1 = F1547_14121(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) + ((EIF_INTEGER_32) 1L)));
		F1547_14056(Current, ti4_1);
	}
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_))++;
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
	} else {
		ti4_1 = F1578_14243(Current, loc1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
	}
	loc2 = F1580_14270(Current, arg1);
	ti4_1 = F1578_14259(Current, loc2);
	F1578_14253(Current, ti4_1, loc1);
	F1578_14260(Current, loc1, loc2);
	F1578_14246(Current, arg1, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_SET}.force_last */
void F1576_14223 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1547_14051(Current);
	F1547_14065(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		F1578_14246(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_));
	} else {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_))) {
			ti4_1 = F1547_14121(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			F1547_14056(Current, ti4_1);
			loc2 = F1580_14270(Current, arg1);
		} else {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_4_);
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_) = (EIF_INTEGER_32) loc1;
		ti4_1 = F1578_14259(Current, loc2);
		F1578_14253(Current, ti4_1, loc1);
		F1578_14260(Current, loc1, loc2);
		F1578_14246(Current, arg1, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_SET}.extend */
void F1576_14224 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10794[Dtype(RTCW(arg1))-1480])(arg1);
		F1338_13187(RTCW(loc1));
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5399[Dtype(RTCW(loc1))-529])(loc1);
			if (tb1) break;
			ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5398[Dtype(RTCW(loc1))-529])(loc1));
			F1576_14218(Current, ti4_1);
			F1338_13188(RTCW(loc1));
		}
	}
	RTLE;
}

/* {DS_SPARSE_SET}.extend_last */
void F1576_14225 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10794[Dtype(RTCW(arg1))-1480])(arg1);
		F1338_13187(RTCW(loc1));
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5399[Dtype(RTCW(loc1))-529])(loc1);
			if (tb1) break;
			ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5398[Dtype(RTCW(loc1))-529])(loc1));
			F1576_14220(Current, ti4_1);
			F1338_13188(RTCW(loc1));
		}
	}
	RTLE;
}

/* {DS_SPARSE_SET}.append_last */
void F1576_14227 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10762[Dtype(RTCW(arg1))-1480])(arg1);
	if ((EIF_BOOLEAN) !F1576_14213(Current, loc1)) {
		ti4_1 = F1547_14121(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) + loc1));
		F1547_14056(Current, ti4_1);
	}
	F1576_14225(Current, arg1);
	RTLE;
}

/* {DS_SPARSE_SET}.key_storage_item */
EIF_INTEGER_32 F1576_14232 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F1578_14242(Current, arg1);
}

/* {DS_SPARSE_SET}.key_equality_tester */
EIF_REFERENCE F1576_14233 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
}

/* {DS_SPARSE_SET}.internal_set_key_equality_tester */
void F1576_14234 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {DS_SPARSE_SET}.make_key_storage */
void F1576_14235 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
}

/* {DS_SPARSE_SET}.key_storage_put */
void F1576_14236 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	RTGC;
}

/* {DS_SPARSE_SET}.clone_key_storage */
void F1576_14237 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {DS_SPARSE_SET}.key_storage_resize */
void F1576_14238 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
}

/* {DS_SPARSE_SET}.key_storage_wipe_out */
void F1576_14239 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {DS_SPARSE_SET}.key_storage_keep_head */
void F1576_14240 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit1696 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
