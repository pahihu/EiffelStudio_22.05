/*
 * Code for class DS_SPARSE_CONTAINER [INTEGER_32, INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1697.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_CONTAINER}.make */
void F1547_14032 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O11065[dtype-1542]) = (EIF_INTEGER_32) arg1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11028[dtype-1566])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11033[dtype-1566])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11039[dtype-1566])(Current, arg1);
	ti4_1 = F1547_14122(Current, arg1);
	*(EIF_INTEGER_32 *)(Current + O11050[dtype-1542]) = (EIF_INTEGER_32) ti4_1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11044[dtype-1566])(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O11050[dtype-1542]) + ((EIF_INTEGER_32) 1L)));
	*(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current + O11051[dtype-1542]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	F1547_14051(Current);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10794[dtype-1480])(Current);
	F1547_14102(Current, tr1);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.found_item */
EIF_INTEGER_32 F1547_14033 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	return (EIF_INTEGER_32) (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11016[dtype-1566])(Current, *(EIF_INTEGER_32 *)(Current + O11055[dtype-1542])));
}

/* {DS_SPARSE_CONTAINER}.first */
EIF_INTEGER_32 F1547_14034 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1) > ((EIF_INTEGER_32) -2L))) break;
		loc1++;
	}
	RTLE;
	return (EIF_INTEGER_32) (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11016[dtype-1566])(Current, loc1));
}

/* {DS_SPARSE_CONTAINER}.last */
EIF_INTEGER_32 F1547_14035 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]);
	for (;;) {
		if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1) > ((EIF_INTEGER_32) -2L))) break;
		loc1--;
	}
	RTLE;
	return (EIF_INTEGER_32) (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11016[dtype-1566])(Current, loc1));
}

/* {DS_SPARSE_CONTAINER}.count */
EIF_INTEGER_32 F1547_14037 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O11066[Dtype(Current)-1542]);
}


/* {DS_SPARSE_CONTAINER}.capacity */
EIF_INTEGER_32 F1547_14038 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O11065[Dtype(Current)-1542]);
}


/* {DS_SPARSE_CONTAINER}.found */
EIF_BOOLEAN F1547_14041 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O11055[Dtype(Current)-1542]) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_CONTAINER}.do_all */
void F1547_14042 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]))) break;
		if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1) > ((EIF_INTEGER_32) -2L))) {
			ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11016[dtype-1566])(Current, loc1));
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_INTEGER_32)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), ti4_1);
		}
		loc1++;
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.do_if */
void F1547_14044 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]))) break;
		if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1) > ((EIF_INTEGER_32) -2L))) {
			loc2 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11016[dtype-1566])(Current, loc1));
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_POINTER, EIF_REFERENCE, EIF_INTEGER_32)) *(EIF_POINTER *)(RTCW(arg2)+ _PTROFF_4_3_0_3_0_0_))(
				*(EIF_POINTER *)(RTCW(arg2)+ _PTROFF_4_3_0_3_0_1_),
				*(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_), loc2);
			tb1 = tb1;
			if (tb1) {
				(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_INTEGER_32)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
					*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
					*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), loc2);
			}
		}
		loc1++;
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.there_exists */
EIF_BOOLEAN F1547_14048 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]))) break;
		if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1) > ((EIF_INTEGER_32) -2L))) {
			ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11016[dtype-1566])(Current, loc1));
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_POINTER, EIF_REFERENCE, EIF_INTEGER_32)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_3_0_3_0_0_))(
				*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_3_0_3_0_1_),
				*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), ti4_1);
			tb1 = tb1;
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]);
			}
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.for_all */
EIF_BOOLEAN F1547_14049 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]))) break;
		if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1) > ((EIF_INTEGER_32) -2L))) {
			ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11016[dtype-1566])(Current, loc1));
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_POINTER, EIF_REFERENCE, EIF_INTEGER_32)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_3_0_3_0_0_))(
				*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_3_0_3_0_1_),
				*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), ti4_1);
			tb1 = tb1;
			if ((EIF_BOOLEAN) !tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				loc1 = *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]);
			}
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.unset_found_item */
void F1547_14051 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O11055[Dtype(Current)-1542]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
}

/* {DS_SPARSE_CONTAINER}.copy */
void F1547_14052 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1547_14104(Current);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = F1454_13510(Current, loc1);
		}
		if (tb1) {
			F1547_14102(Current, loc1);
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10794[dtype-1480])(Current);
			F1547_14102(Current, tr1);
		}
		F1547_14051(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11029[dtype-1566])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11035[dtype-1566])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11047[dtype-1566])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11041[dtype-1566])(Current);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.remove */
void F1547_14053 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1547_14051(Current);
	F1547_14065(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]) != ((EIF_INTEGER_32) -1L))) {
		F1547_14070(Current, *(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]));
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.remove_found_item */
void F1547_14054 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1547_14070(Current, *(EIF_INTEGER_32 *)(Current + O11055[Dtype(Current)-1542]));
	F1547_14051(Current);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.wipe_out */
void F1547_14055 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1547_14104(Current);
	F1547_14051(Current);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O11066[dtype-1542]) > ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11031[dtype-1566])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11037[dtype-1566])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11043[dtype-1566])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11049[dtype-1566])(Current);
		*(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		*(EIF_INTEGER_32 *)(Current + O11051[dtype-1542]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		*(EIF_INTEGER_32 *)(Current + O11066[dtype-1542]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	*(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.resize */
void F1547_14056 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1547_14051(Current);
	loc1 = F1547_14122(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11048[dtype-1566])(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
	loc2 = *(EIF_INTEGER_32 *)(Current + O11050[dtype-1542]);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11046[dtype-1566])(Current, ((EIF_INTEGER_32) -1L), loc2);
		loc2--;
	}
	*(EIF_INTEGER_32 *)(Current + O11050[dtype-1542]) = (EIF_INTEGER_32) loc1;
	loc2 = *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
			ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11018[dtype-1566])(Current, loc2));
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R11026[dtype-1566])(Current, (EIF_REFERENCE) &ti4_1);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11045[dtype-1566])(Current, loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11040[dtype-1566])(Current, ti4_1, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11046[dtype-1566])(Current, loc2, loc3);
		}
		loc2--;
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11030[dtype-1566])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11036[dtype-1566])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11042[dtype-1566])(Current, arg1);
	*(EIF_INTEGER_32 *)(Current + O11065[dtype-1542]) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.compress */
void F1547_14057 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]) != (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O11066[dtype-1542]) - ((EIF_INTEGER_32) 1L)))) {
		F1547_14051(Current);
		loc3 = *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1) > ((EIF_INTEGER_32) -2L))) {
				if ((EIF_BOOLEAN)(loc2 != loc1)) {
					ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11016[dtype-1566])(Current, loc1));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11017[dtype-1566])(Current, (EIF_REFERENCE) &ti4_1, loc2);
					ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11018[dtype-1566])(Current, loc1));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11034[dtype-1566])(Current, (EIF_REFERENCE) &ti4_1, loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11040[dtype-1566])(Current, ((EIF_INTEGER_32) -1L), loc2);
					F1547_14105(Current, loc1, loc2);
				}
				loc2++;
			}
			loc1++;
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11032[dtype-1566])(Current, *(EIF_INTEGER_32 *)(Current + O11066[dtype-1542]));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11038[dtype-1566])(Current, *(EIF_INTEGER_32 *)(Current + O11066[dtype-1542]));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11043[dtype-1566])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11049[dtype-1566])(Current);
		loc3 = *(EIF_INTEGER_32 *)(Current + O11066[dtype-1542]);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11018[dtype-1566])(Current, loc1));
			loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R11026[dtype-1566])(Current, (EIF_REFERENCE) &ti4_1);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11045[dtype-1566])(Current, loc4);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11040[dtype-1566])(Current, ti4_1, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11046[dtype-1566])(Current, loc1, loc4);
			loc1++;
		}
		*(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]) = (EIF_INTEGER_32) loc3;
		*(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.search_position */
void F1547_14065 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (EIF_FALSE) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11045[dtype-1566])(Current, *(EIF_INTEGER_32 *)(Current + O11050[dtype-1542]));
		*(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]) = (EIF_INTEGER_32) ti4_1;
		*(EIF_INTEGER_32 *)(Current + O11053[dtype-1542]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O11050[dtype-1542]);
		*(EIF_INTEGER_32 *)(Current + O11054[dtype-1542]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		loc3 = *(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11024[dtype-1566])(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			loc4 = *(EIF_INTEGER_32 *)(Current + O11053[dtype-1542]);
			loc2 = *(EIF_INTEGER_32 *)(Current + O11054[dtype-1542]);
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11018[dtype-1566])(Current, loc3));
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5465[Dtype(loc5)-453])(loc5, (EIF_REFERENCE) &arg1, (EIF_REFERENCE) &ti4_1);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R11026[dtype-1566])(Current, (EIF_REFERENCE) &arg1);
				loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11045[dtype-1566])(Current, loc4);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11018[dtype-1566])(Current, loc1));
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5465[Dtype(loc5)-453])(loc5, (EIF_REFERENCE) &arg1, (EIF_REFERENCE) &ti4_1);
					if (tb1) {
						loc3 = (EIF_INTEGER_32) loc1;
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 = (EIF_INTEGER_32) loc1;
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
			}
			*(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]) = (EIF_INTEGER_32) loc3;
			*(EIF_INTEGER_32 *)(Current + O11053[dtype-1542]) = (EIF_INTEGER_32) loc4;
			*(EIF_INTEGER_32 *)(Current + O11054[dtype-1542]) = (EIF_INTEGER_32) loc2;
		} else {
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				tb1 = (EIF_BOOLEAN)(arg1 != (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11018[dtype-1566])(Current, loc3)));
			}
			if (tb1) {
				loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R11026[dtype-1566])(Current, (EIF_REFERENCE) &arg1);
				loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11045[dtype-1566])(Current, loc4);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					if ((EIF_BOOLEAN)(arg1 == (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11018[dtype-1566])(Current, loc1)))) {
						loc3 = (EIF_INTEGER_32) loc1;
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 = (EIF_INTEGER_32) loc1;
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
				*(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]) = (EIF_INTEGER_32) loc3;
				*(EIF_INTEGER_32 *)(Current + O11053[dtype-1542]) = (EIF_INTEGER_32) loc4;
				*(EIF_INTEGER_32 *)(Current + O11054[dtype-1542]) = (EIF_INTEGER_32) loc2;
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.position_of_key */
EIF_INTEGER_32 F1547_14066 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (EIF_FALSE) {
		RTLE;
		return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11045[dtype-1566])(Current, *(EIF_INTEGER_32 *)(Current + O11050[dtype-1542]));
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11024[dtype-1566])(Current);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R11026[dtype-1566])(Current, (EIF_REFERENCE) &arg1);
			loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11045[dtype-1566])(Current, loc3);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
				ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11018[dtype-1566])(Current, loc1));
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5465[Dtype(loc4)-453])(loc4, (EIF_REFERENCE) &arg1, (EIF_REFERENCE) &ti4_1);
				if (tb1) {
					loc2 = (EIF_INTEGER_32) loc1;
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				} else {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1);
					loc1 = (EIF_INTEGER_32) ti4_1;
				}
			}
		} else {
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R11026[dtype-1566])(Current, (EIF_REFERENCE) &arg1);
			loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11045[dtype-1566])(Current, loc3);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
				if ((EIF_BOOLEAN)(arg1 == (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11018[dtype-1566])(Current, loc1)))) {
					loc2 = (EIF_INTEGER_32) loc1;
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				} else {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1);
					loc1 = (EIF_INTEGER_32) ti4_1;
				}
			}
		}
		RTLE;
		return (EIF_INTEGER_32) loc2;
	}/* NOTREACHED */
	
}

/* {DS_SPARSE_CONTAINER}.remove_position */
void F1547_14070 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]))) {
		loc1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11018[dtype-1566])(Current, arg1));
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R11026[dtype-1566])(Current, (EIF_REFERENCE) &loc1);
		if ((EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11045[dtype-1566])(Current, loc2) == arg1)) {
			*(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]) = (EIF_INTEGER_32) arg1;
			*(EIF_INTEGER_32 *)(Current + O11053[dtype-1542]) = (EIF_INTEGER_32) loc2;
			*(EIF_INTEGER_32 *)(Current + O11054[dtype-1542]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		} else {
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11024[dtype-1566])(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11025[dtype-1566])(Current, NULL);
			F1547_14065(Current, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11025[dtype-1566])(Current, loc3);
		}
	}
	F1547_14107(Current, *(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]));
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O11054[dtype-1542]) == ((EIF_INTEGER_32) -1L))) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, *(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]));
		ti4_2 = *(EIF_INTEGER_32 *)(Current + O11053[dtype-1542]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11046[dtype-1566])(Current, ti4_1, ti4_2);
	} else {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, *(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]));
		ti4_2 = *(EIF_INTEGER_32 *)(Current + O11054[dtype-1542]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11040[dtype-1566])(Current, ti4_1, ti4_2);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O11051[dtype-1542]) == ((EIF_INTEGER_32) -1L)) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]) == *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542])))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11032[dtype-1566])(Current, *(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11038[dtype-1566])(Current, *(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11040[dtype-1566])(Current, ((EIF_INTEGER_32) -1L), *(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]));
		*(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		(*(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]))--;
	} else {
		tr1 = RTLNTY2(eif_final_id(Y10771,Y10771_gen_type,dftype,1433), 0x00);
		tb1 = (EIF_BOOLEAN) eif_builtin_TYPE_has_default__b (tr1);
		if (tb1) {
			tr1 = RTLNTY2(eif_final_id(Y10771,Y10771_gen_type,dftype,1433), 0x00);
			ti4_1 = F1071_8823(tr1);
			ti4_2 = *(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11017[dtype-1566])(Current, (EIF_REFERENCE) &ti4_1, ti4_2);
		}
		tr1 = RTLNTY2(eif_final_id(Y11067,Y11067_gen_type,dftype,1542), 0x00);
		tb1 = (EIF_BOOLEAN) eif_builtin_TYPE_has_default__b (tr1);
		if (tb1) {
			tr1 = RTLNTY2(eif_final_id(Y11067,Y11067_gen_type,dftype,1542), 0x00);
			ti4_1 = F1071_8823(tr1);
			ti4_2 = *(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11034[dtype-1566])(Current, (EIF_REFERENCE) &ti4_1, ti4_2);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11040[dtype-1566])(Current, (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - *(EIF_INTEGER_32 *)(Current + O11051[dtype-1542])), *(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]));
		*(EIF_INTEGER_32 *)(Current + O11051[dtype-1542]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O11052[dtype-1542]);
	}
	(*(EIF_INTEGER_32 *)(Current + O11066[dtype-1542]))--;
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.set_internal_cursor */
void F1547_14102 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {DS_SPARSE_CONTAINER}.internal_cursor */
EIF_REFERENCE F1547_14103 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {DS_SPARSE_CONTAINER}.move_all_cursors_after */
void F1547_14104 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		F1373_13220(RTCW(loc1));
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		F1320_13176(RTCW(loc1), NULL);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.move_all_cursors */
void F1547_14105 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == arg1)) {
			F1373_13219(RTCW(loc1), arg2);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc1 = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.move_cursors_forth */
void F1547_14107 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == arg1)) {
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
				loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
				loc5 = *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]);
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (loc4 > loc5)) {
						tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc4) > ((EIF_INTEGER_32) -2L));
					}
					if (tb1) break;
					loc4++;
				}
			}
			if ((EIF_BOOLEAN) (loc4 > loc5)) {
				F1373_13220(RTCW(loc1));
				if ((EIF_BOOLEAN)(loc3 == NULL)) {
					loc3 = (EIF_REFERENCE) loc1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
					F1320_13176(RTCW(loc3), loc2);
					F1320_13176(RTCW(loc1), NULL);
					loc1 = (EIF_REFERENCE) loc2;
				}
			} else {
				F1373_13219(RTCW(loc1), loc4);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				loc1 = (EIF_REFERENCE) tr1;
			}
		} else {
			loc3 = (EIF_REFERENCE) loc1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_item */
EIF_INTEGER_32 F1547_14108 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	Result = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11016[Dtype(Current)-1566])(Current, ti4_1));
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_is_first */
EIF_BOOLEAN F1547_14109 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1435_13475(Current)) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[Dtype(Current)-1566])(Current, loc1) > ((EIF_INTEGER_32) -2L))) break;
			loc1++;
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == loc1);
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_is_last */
EIF_BOOLEAN F1547_14110 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1435_13475(Current)) {
		loc1 = *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]);
		for (;;) {
			if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1) > ((EIF_INTEGER_32) -2L))) break;
			loc1--;
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == loc1);
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_same_position */
EIF_BOOLEAN F1547_14111 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_start */
void F1547_14112 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if (F1435_13475(Current)) {
		F1373_13220(RTCW(arg1));
	} else {
		loc3 = F1454_13515(Current, arg1);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc2 = *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 > loc2)) {
				tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1) > ((EIF_INTEGER_32) -2L));
			}
			if (tb1) break;
			loc1++;
		}
		if ((EIF_BOOLEAN) (loc1 > loc2)) {
			F1373_13220(RTCW(arg1));
			if ((EIF_BOOLEAN) !loc3) {
				F1454_13519(Current, arg1);
			}
		} else {
			F1373_13219(RTCW(arg1), loc1);
			if (loc3) {
				F1454_13518(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_finish */
void F1547_14113 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if (F1435_13475(Current)) {
		F1373_13221(RTCW(arg1));
	} else {
		loc2 = F1454_13515(Current, arg1);
		loc1 = *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
				tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1) > ((EIF_INTEGER_32) -2L));
			}
			if (tb1) break;
			loc1--;
		}
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
			F1373_13221(RTCW(arg1));
			if ((EIF_BOOLEAN) !loc2) {
				F1454_13519(Current, arg1);
			}
		} else {
			F1373_13219(RTCW(arg1), loc1);
			if (loc2) {
				F1454_13518(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_forth */
void F1547_14114 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_1 = ((EIF_INTEGER_32) -2L);
	if ((EIF_BOOLEAN)(loc4 == ti4_1)) {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
	}
	loc2 = *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > loc2)) {
			tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1) > ((EIF_INTEGER_32) -2L));
		}
		if (tb1) break;
		loc1++;
	}
	if ((EIF_BOOLEAN) (loc1 > loc2)) {
		F1373_13220(RTCW(arg1));
		if ((EIF_BOOLEAN) !loc3) {
			F1454_13519(Current, arg1);
		}
	} else {
		F1373_13219(RTCW(arg1), loc1);
		if (loc3) {
			F1454_13518(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_back */
void F1547_14115 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_1 = ((EIF_INTEGER_32) -3L);
	if ((EIF_BOOLEAN)(loc3 == ti4_1)) {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = *(EIF_INTEGER_32 *)(Current + O11015[dtype-1542]);
	} else {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
	}
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
			tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11019[dtype-1566])(Current, loc1) > ((EIF_INTEGER_32) -2L));
		}
		if (tb1) break;
		loc1--;
	}
	if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
		F1373_13221(RTCW(arg1));
		if ((EIF_BOOLEAN) !loc2) {
			F1454_13519(Current, arg1);
		}
	} else {
		F1373_13219(RTCW(arg1), loc1);
		if (loc2) {
			F1454_13518(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_go_after */
void F1547_14118 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1454_13515(Current, arg1);
	F1373_13220(RTCW(arg1));
	if ((EIF_BOOLEAN) !loc1) {
		F1454_13519(Current, arg1);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_go_before */
void F1547_14119 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1454_13515(Current, arg1);
	F1373_13221(RTCW(arg1));
	if ((EIF_BOOLEAN) !loc1) {
		F1454_13519(Current, arg1);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.new_capacity */
EIF_INTEGER_32 F1547_14121 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * arg1);
}

/* {DS_SPARSE_CONTAINER}.new_modulus */
EIF_INTEGER_32 F1547_14122 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 3L)) / ((EIF_INTEGER_32) 2L));
}

void EIF_Minit1697 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
