
#ifndef _C34_re1677_
#define _C34_re1677_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F764_6449(EIF_REFERENCE);
extern void F764_6451(EIF_REFERENCE);
extern void EIF_Minit1677(void);
extern char *(*R5673[])();
extern char *(*R5679[])();

#ifdef __cplusplus
}
#endif

#endif
