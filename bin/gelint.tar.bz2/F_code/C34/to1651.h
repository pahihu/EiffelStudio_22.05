
#ifndef _C34_to1651_
#define _C34_to1651_

#ifdef __cplusplus
extern "C" {
#endif

extern void F410_5674(EIF_REFERENCE, EIF_INTEGER_32);
extern void F410_5675(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern void F410_5681(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1651(void);
extern void F910_7138(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y5062[];
extern EIF_TYPE_INDEX *Y5062_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
