
#ifndef _C34_re1658_
#define _C34_re1658_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F763_6449(EIF_REFERENCE);
extern void F763_6451(EIF_REFERENCE);
extern void EIF_Minit1658(void);
extern char *(*R5673[])();
extern char *(*R5679[])();

#ifdef __cplusplus
}
#endif

#endif
