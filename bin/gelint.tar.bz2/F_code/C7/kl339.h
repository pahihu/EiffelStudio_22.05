
#ifndef _C7_kl339_
#define _C7_kl339_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F452_6116_body(EIF_REFERENCE);
extern EIF_REFERENCE F452_6116(EIF_REFERENCE);
static EIF_REFERENCE F452_6117_body(EIF_REFERENCE);
extern EIF_REFERENCE F452_6117(EIF_REFERENCE);
extern void EIF_Minit339(void);

#ifdef __cplusplus
}
#endif

#endif
