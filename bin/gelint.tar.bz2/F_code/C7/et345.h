
#ifndef _C7_et345_
#define _C7_et345_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F465_6126(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit345(void);
extern char *(*R13319[])();

#ifdef __cplusplus
}
#endif

#endif
