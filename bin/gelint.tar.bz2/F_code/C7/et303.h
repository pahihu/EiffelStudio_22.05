
#ifndef _C7_et303_
#define _C7_et303_

#ifdef __cplusplus
extern "C" {
#endif

extern void F386_5251(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F386_5252(EIF_REFERENCE);
extern void F386_5253(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit303(void);
extern void F382_5232(EIF_REFERENCE, EIF_REFERENCE);
extern void F988_7526(EIF_REFERENCE, EIF_REFERENCE);
extern void F382_5229(EIF_REFERENCE, EIF_REFERENCE);
extern void F988_7524(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4636[])();
extern char *(*R4637[])();
extern char *(*R8142[])();

#ifdef __cplusplus
}
#endif

#endif
