
#ifndef _C7_re316_
#define _C7_re316_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F399_5518(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit316(void);

#ifdef __cplusplus
}
#endif

#endif
