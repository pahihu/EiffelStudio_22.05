/*
 * Code for class ET_CLASS_NAME_TESTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et344.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_CLASS_NAME_TESTER}.test */
EIF_BOOLEAN F464_6125 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		if ((EIF_BOOLEAN)(arg1 == NULL)) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			if ((EIF_BOOLEAN)(arg2 == NULL)) {
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				Result = F1981_18372(RTCW(arg1), arg2);
				RTLE;
				return (EIF_BOOLEAN) Result;
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit344 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
