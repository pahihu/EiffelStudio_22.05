/*
 * Code for class KL_UNICODE_CHARACTER_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl332.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_UNICODE_CHARACTER_BUFFER}.make */
void F427_5872 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1186, 1).id);
	F1185_10346(RTCW(tr1), (EIF_CHARACTER_32) 0U, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tc1 = (EIF_CHARACTER_8) ((EIF_INTEGER_32) 255L);
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) tc1;
	tw1 = (EIF_CHARACTER_32) ((EIF_NATURAL_32) 4294967295U);
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_3_1_0_0_) = (EIF_CHARACTER_32) tw1;
	RTLE;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.item */
EIF_CHARACTER_8 F427_5875 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = F427_5876(Current, arg1);
	tb1 = (loc1 <= 0xFF);
	if (tb1) {
		tc1 = (EIF_CHARACTER_8) loc1;
		RTLE;
		return (EIF_CHARACTER_8) tc1;
	} else {
		RTLE;
		return (EIF_CHARACTER_8) *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
	}/* NOTREACHED */
	
}

/* {KL_UNICODE_CHARACTER_BUFFER}.unicode_item */
EIF_CHARACTER_32 F427_5876 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	/* INLINED CODE (SPECIAL.item) */
	tw2 = *((EIF_CHARACTER_32 *)RTCW(tr1) + (arg1));
	/* END INLINED CODE */
	Result = tw2;
	RTLE;
	return Result;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.item_code */
EIF_NATURAL_32 F427_5877 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tw1 = F427_5876(Current, arg1);
	Result = (EIF_NATURAL_32) tw1;
	RTLE;
	return Result;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.substring */
EIF_REFERENCE F427_5878 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 < arg1)) {
		tr1 = RTLNS(eif_new_type(1189, 0x01).id, 1189, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1188_10512(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x01).id, 1189, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1188_10512(RTCW(Result), (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 - arg1) + ((EIF_INTEGER_32) 1L)));
		F427_5889(Current, arg1, arg2, Result);
	}
	RTLE;
	return Result;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.unicode_substring */
EIF_REFERENCE F427_5879 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 < arg1)) {
		tr1 = RTLNS(eif_new_type(1186, 0x01).id, 1186, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1185_10345(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1187_10507(RTCW(tr1), (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
	return Result;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.count */
EIF_INTEGER_32 F427_5883 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - ((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.as_unicode_special */
EIF_REFERENCE F427_5884 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {KL_UNICODE_CHARACTER_BUFFER}.put */
void F427_5887 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tw1 = (EIF_CHARACTER_32) arg1;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_CHARACTER_32 *)RTCW(tr1) + (arg2)) = tw1;
	/* END INLINED CODE */
	;
	RTLE;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.append_substring_to_string */
void F427_5889 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg3);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= arg2)) {
		loc1 = (EIF_INTEGER_32) arg1;
		loc2 = (EIF_INTEGER_32) arg2;
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tc1 = F427_5875(Current, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg3))-1189])(arg3, tc1);
			loc1++;
		}
	}
	RTLE;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.append_utf8_substring_to_string */
void F427_5891 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg3);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= arg2)) {
		tr1 = RTLNS(eif_new_type(1202, 0x01).id, 1202, _OBJSIZ_0_0_0_0_0_0_0_0_);
		F1203_10763(RTCW(tr1), arg3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.fill_from_string */
void F427_5892 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8319[Dtype(RTCW(arg1))-1185])(arg1);
	F427_5893(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1, arg2);
	RTLE;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.fill_from_substring */
void F427_5893 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 <= arg3)) {
		loc4 = arg1;
		loc4 = RTRV(eif_new_type(1184, 0x01),loc4);
		if (EIF_TEST(loc4)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F1187_10435(RTCW(tr1), loc4, arg2, arg3, (EIF_INTEGER_32) (arg4 + ((EIF_INTEGER_32) 1L)));
		} else {
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg4 + ((EIF_INTEGER_32) 1L));
			loc1 = (EIF_INTEGER_32) arg2;
			loc3 = (EIF_INTEGER_32) arg3;
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc3)) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8283[Dtype(RTCW(arg1))-1185])(arg1, loc1);
				F1187_10447(RTCW(tr1), tw1, loc2);
				loc2++;
				loc1++;
			}
		}
	}
	RTLE;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.fill_from_iso_8859_1_substring */
void F427_5894 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 <= arg3)) {
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg4 + ((EIF_INTEGER_32) 1L));
		loc4 = *(EIF_REFERENCE *)(RTCW(arg1));
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L));
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			/* INLINED CODE (SPECIAL.item) */
			tc2 = *((EIF_CHARACTER_8 *)RTCW(loc4) + (loc1));
			/* END INLINED CODE */
			tc1 = tc2;
			tw1 = (EIF_CHARACTER_32) tc1;
			F1187_10447(RTCW(tr1), tw1, loc2);
			loc2++;
			loc1++;
		}
	}
	RTLE;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.fill_from_iso_8859_1_stream */
EIF_INTEGER_32 F427_5896 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = RTLNSMART(eif_new_type(1189, 0).id);
		ti4_1 = F427_5883(Current);
		F1188_10513(RTCW(loc1), (EIF_CHARACTER_8) '\000', ti4_1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 < arg3)) {
			ti4_1 = F427_5883(Current);
			F1190_10657(RTCW(loc1), ti4_1);
			ti4_1 = F427_5883(Current);
			F1190_10674(RTCW(loc1), ti4_1);
		}
	}
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8734[Dtype(RTCW(arg1))-1218])(arg1, loc1, ((EIF_INTEGER_32) 1L), arg3);
	F427_5894(Current, loc1, ((EIF_INTEGER_32) 1L), Result, arg2);
	RTLE;
	return Result;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.fill_from_utf8_stream */
EIF_INTEGER_32 F427_5897 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc7 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc8 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc9 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = RTLNSMART(eif_new_type(1189, 0).id);
		ti4_1 = F427_5883(Current);
		F1188_10513(RTCW(loc1), (EIF_CHARACTER_8) '\000', ti4_1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 < arg3)) {
			ti4_1 = F427_5883(Current);
			F1190_10657(RTCW(loc1), ti4_1);
			ti4_1 = F427_5883(Current);
			F1190_10674(RTCW(loc1), ti4_1);
		}
	}
	loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8734[Dtype(RTCW(arg1))-1218])(arg1, loc1, ((EIF_INTEGER_32) 1L), arg3);
	loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
	loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
	loc4--;
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > loc4)) break;
		/* INLINED CODE (SPECIAL.item) */
		tc2 = *((EIF_CHARACTER_8 *)RTCW(loc2) + (loc3));
		/* END INLINED CODE */
		loc6 = tc2;
		tr1 = RTLNS(eif_new_type(1202, 0x01).id, 1202, _OBJSIZ_0_0_0_0_0_0_0_0_);
		if ((EIF_BOOLEAN) !F1203_10734(RTCW(tr1), loc6)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F1187_10447(RTCW(tr1), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_3_1_0_0_), loc5);
			loc5++;
			loc3++;
		} else {
			tr1 = RTLNS(eif_new_type(1202, 0x01).id, 1202, _OBJSIZ_0_0_0_0_0_0_0_0_);
			switch (F1203_10749(RTCW(tr1), loc6)) {
				case 1L:
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tw1 = (EIF_CHARACTER_32) loc6;
					F1187_10447(RTCW(tr1), tw1, loc5);
					loc3++;
					break;
				case 2L:
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)) <= loc4)) {
						/* INLINED CODE (SPECIAL.item) */
						tc2 = *((EIF_CHARACTER_8 *)RTCW(loc2) + ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L))));
						/* END INLINED CODE */
						loc7 = tc2;
					} else {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(arg1))-1218])(arg1);
						if ((EIF_BOOLEAN) !tb1) {
							loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
							if ((EIF_BOOLEAN) (ti4_1 < loc10)) {
								F1190_10657(RTCW(loc1), loc10);
								F1190_10674(RTCW(loc1), loc10);
								loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
							}
							loc11 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8734[Dtype(RTCW(arg1))-1218])(arg1, loc1, ((EIF_INTEGER_32) 1L), loc10);
							loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
							loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc11 - ((EIF_INTEGER_32) 1L));
							if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)) <= loc4)) {
								/* INLINED CODE (SPECIAL.item) */
								tc2 = *((EIF_CHARACTER_8 *)RTCW(loc2) + ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L))));
								/* END INLINED CODE */
								loc7 = tc2;
							} else {
								loc7 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\377';
							}
						} else {
							loc7 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\377';
						}
					}
					tr1 = RTLNS(eif_new_type(1202, 0x01).id, 1202, _OBJSIZ_0_0_0_0_0_0_0_0_);
					if ((EIF_BOOLEAN) !F1203_10736(RTCW(tr1), loc7, loc6)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F1187_10447(RTCW(tr1), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_3_1_0_0_), loc5);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						tr2 = RTLNS(eif_new_type(1202, 0x01).id, 1202, _OBJSIZ_0_0_0_0_0_0_0_0_);
						tu4_1 = F1203_10745(RTCW(tr2), loc6, loc7);
						tw1 = (EIF_CHARACTER_32) tu4_1;
						F1187_10447(RTCW(tr1), tw1, loc5);
					}
					loc3 += ((EIF_INTEGER_32) 2L);
					break;
				case 3L:
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 2L)) <= loc4)) {
						/* INLINED CODE (SPECIAL.item) */
						tc2 = *((EIF_CHARACTER_8 *)RTCW(loc2) + ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L))));
						/* END INLINED CODE */
						loc7 = tc2;
						/* INLINED CODE (SPECIAL.item) */
						tc2 = *((EIF_CHARACTER_8 *)RTCW(loc2) + ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 2L))));
						/* END INLINED CODE */
						loc8 = tc2;
					} else {
						loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - loc3);
						if ((EIF_BOOLEAN) (loc10 > ((EIF_INTEGER_32) 0L))) {
							F1190_10600(RTCW(loc1), loc1, (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)) + loc10), ((EIF_INTEGER_32) 1L));
						}
						loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc10 - ((EIF_INTEGER_32) 1L));
						loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) - loc10);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						if ((EIF_BOOLEAN) (ti4_1 < loc10)) {
							F1190_10657(RTCW(loc1), loc10);
							F1190_10674(RTCW(loc1), loc10);
							loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
						}
						for (;;) {
							tb1 = '\01';
							if (!(EIF_BOOLEAN) (loc10 <= ((EIF_INTEGER_32) 0L))) {
								tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(arg1))-1218])(arg1);
								tb1 = tb2;
							}
							if (tb1) break;
							loc11 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8734[Dtype(RTCW(arg1))-1218])(arg1, loc1, ((EIF_INTEGER_32) 1L), loc10);
							loc4 += loc11;
							loc10 -= loc11;
						}
						if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 2L)) <= loc4)) {
							/* INLINED CODE (SPECIAL.item) */
							tc2 = *((EIF_CHARACTER_8 *)RTCW(loc2) + ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L))));
							/* END INLINED CODE */
							loc7 = tc2;
							/* INLINED CODE (SPECIAL.item) */
							tc2 = *((EIF_CHARACTER_8 *)RTCW(loc2) + ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 2L))));
							/* END INLINED CODE */
							loc8 = tc2;
						} else {
							loc7 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\377';
							loc8 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\377';
						}
					}
					tb2 = '\01';
					tr1 = RTLNS(eif_new_type(1202, 0x01).id, 1202, _OBJSIZ_0_0_0_0_0_0_0_0_);
					if (!(EIF_BOOLEAN) !F1203_10736(RTCW(tr1), loc7, loc6)) {
						tr1 = RTLNS(eif_new_type(1202, 0x01).id, 1202, _OBJSIZ_0_0_0_0_0_0_0_0_);
						tb2 = (EIF_BOOLEAN) !F1203_10735(RTCW(tr1), loc8);
					}
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F1187_10447(RTCW(tr1), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_3_1_0_0_), loc5);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						tr2 = RTLNS(eif_new_type(1202, 0x01).id, 1202, _OBJSIZ_0_0_0_0_0_0_0_0_);
						tu4_1 = F1203_10746(RTCW(tr2), loc6, loc7, loc8);
						tw1 = (EIF_CHARACTER_32) tu4_1;
						F1187_10447(RTCW(tr1), tw1, loc5);
					}
					loc3 += ((EIF_INTEGER_32) 3L);
					break;
				default:
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 3L)) <= loc4)) {
						/* INLINED CODE (SPECIAL.item) */
						tc2 = *((EIF_CHARACTER_8 *)RTCW(loc2) + ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L))));
						/* END INLINED CODE */
						loc7 = tc2;
						/* INLINED CODE (SPECIAL.item) */
						tc2 = *((EIF_CHARACTER_8 *)RTCW(loc2) + ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 2L))));
						/* END INLINED CODE */
						loc8 = tc2;
						/* INLINED CODE (SPECIAL.item) */
						tc2 = *((EIF_CHARACTER_8 *)RTCW(loc2) + ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 3L))));
						/* END INLINED CODE */
						loc9 = tc2;
					} else {
						loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - loc3);
						if ((EIF_BOOLEAN) (loc10 > ((EIF_INTEGER_32) 0L))) {
							F1190_10600(RTCW(loc1), loc1, (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)) + loc10), ((EIF_INTEGER_32) 1L));
						}
						loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc10 - ((EIF_INTEGER_32) 1L));
						loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) - loc10);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						if ((EIF_BOOLEAN) (ti4_1 < loc10)) {
							F1190_10657(RTCW(loc1), loc10);
							F1190_10674(RTCW(loc1), loc10);
							loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
						}
						for (;;) {
							tb2 = '\01';
							if (!(EIF_BOOLEAN) (loc10 <= ((EIF_INTEGER_32) 0L))) {
								tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(arg1))-1218])(arg1);
								tb2 = tb3;
							}
							if (tb2) break;
							loc11 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8734[Dtype(RTCW(arg1))-1218])(arg1, loc1, ((EIF_INTEGER_32) 1L), loc10);
							loc4 += loc11;
							loc10 -= loc11;
						}
						if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 3L)) <= loc4)) {
							/* INLINED CODE (SPECIAL.item) */
							tc2 = *((EIF_CHARACTER_8 *)RTCW(loc2) + ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L))));
							/* END INLINED CODE */
							loc7 = tc2;
							/* INLINED CODE (SPECIAL.item) */
							tc2 = *((EIF_CHARACTER_8 *)RTCW(loc2) + ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 2L))));
							/* END INLINED CODE */
							loc8 = tc2;
							/* INLINED CODE (SPECIAL.item) */
							tc2 = *((EIF_CHARACTER_8 *)RTCW(loc2) + ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 3L))));
							/* END INLINED CODE */
							loc9 = tc2;
						} else {
							loc7 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\377';
							loc8 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\377';
							loc9 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\377';
						}
					}
					tb3 = '\01';
					tb4 = '\01';
					tr1 = RTLNS(eif_new_type(1202, 0x01).id, 1202, _OBJSIZ_0_0_0_0_0_0_0_0_);
					if (!(EIF_BOOLEAN) !F1203_10736(RTCW(tr1), loc7, loc6)) {
						tr1 = RTLNS(eif_new_type(1202, 0x01).id, 1202, _OBJSIZ_0_0_0_0_0_0_0_0_);
						tb4 = (EIF_BOOLEAN) !F1203_10735(RTCW(tr1), loc8);
					}
					if (!tb4) {
						tr1 = RTLNS(eif_new_type(1202, 0x01).id, 1202, _OBJSIZ_0_0_0_0_0_0_0_0_);
						tb3 = (EIF_BOOLEAN) !F1203_10735(RTCW(tr1), loc9);
					}
					if (tb3) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F1187_10447(RTCW(tr1), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_3_1_0_0_), loc5);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						tr2 = RTLNS(eif_new_type(1202, 0x01).id, 1202, _OBJSIZ_0_0_0_0_0_0_0_0_);
						tu4_1 = F1203_10747(RTCW(tr2), loc6, loc7, loc8, loc9);
						tw1 = (EIF_CHARACTER_32) tu4_1;
						F1187_10447(RTCW(tr1), tw1, loc5);
					}
					loc3 += ((EIF_INTEGER_32) 4L);
					break;
			}
			loc5++;
		}
	}
	RTLE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
}

/* {KL_UNICODE_CHARACTER_BUFFER}.move_left */
void F427_5898 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg3 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1187_10435(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg1 + arg3), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
}

/* {KL_UNICODE_CHARACTER_BUFFER}.resize */
void F427_5900 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = F427_5883(Current);
	if ((EIF_BOOLEAN) (arg1 > loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1187_10492(RTCW(tr1), (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1187_10509(RTCW(tr1), (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		F911_7159(RTCW(tr1), tw1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
}

void EIF_Minit332 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
