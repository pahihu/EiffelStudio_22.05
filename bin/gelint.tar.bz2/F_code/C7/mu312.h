
#ifndef _C7_mu312_
#define _C7_mu312_

#ifdef __cplusplus
extern "C" {
#endif

extern void F395_5314(EIF_REFERENCE);
extern EIF_BOOLEAN F395_5316(EIF_REFERENCE);
extern void F395_5317(EIF_REFERENCE);
extern EIF_BOOLEAN F395_5318(EIF_REFERENCE);
extern void F395_5319(EIF_REFERENCE);
extern void F395_5320(EIF_REFERENCE);
extern void F395_5323(EIF_REFERENCE);
extern EIF_POINTER F395_5325(EIF_REFERENCE);
extern void F395_5326(EIF_REFERENCE, EIF_POINTER);
extern void F395_5327(EIF_REFERENCE, EIF_POINTER);
extern EIF_BOOLEAN F395_5328(EIF_REFERENCE, EIF_POINTER);
extern void F395_5329(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit312(void);

#ifdef __cplusplus
}
#endif

#endif
