
#ifndef _C7_et304_
#define _C7_et304_

#ifdef __cplusplus
extern "C" {
#endif

extern void F387_5254(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F387_5256(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit304(void);
extern void F382_5231(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F989_7527(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE);
extern void F382_5229(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F382_5223(EIF_REFERENCE, EIF_REFERENCE);
extern void F2040_20413(EIF_REFERENCE);
extern EIF_BOOLEAN F1295_12828(EIF_REFERENCE);
extern EIF_REFERENCE F889_7010(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R4636[])();
extern char *(*R2612[])();
extern char *(*R4644[])();
extern char *(*R8142[])();
extern char *(*R6326[])();
extern char *(*R2602[])();

#ifdef __cplusplus
}
#endif

#endif
