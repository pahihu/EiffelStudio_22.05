/*
 * Code for class KL_STRING_EQUALITY_TESTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl346.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STRING_EQUALITY_TESTER}.test */
EIF_BOOLEAN F466_6127 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		if ((EIF_BOOLEAN)(arg1 == NULL)) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			if ((EIF_BOOLEAN)(arg2 == NULL)) {
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN)(ti4_1 == loc2)) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > loc2)) break;
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8494[Dtype(RTCW(arg1))-1189])(arg1, loc1);
						ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8494[Dtype(RTCW(arg2))-1189])(arg2, loc1);
						if ((EIF_BOOLEAN)(ti4_1 != ti4_2)) {
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
						} else {
							loc1++;
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit346 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
