/*
 * Code for class UT_SHARED_ISE_VERSIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut347.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_SHARED_ISE_VERSIONS}.ise_5_7_0 */
static EIF_REFERENCE F471_6136_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(77)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 5L), ((EIF_INTEGER_32) 7L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F471_6136 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(77,F471_6136_body,(Current));
}

/* {UT_SHARED_ISE_VERSIONS}.ise_5_7_59914 */
static EIF_REFERENCE F471_6138_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(78)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 5L), ((EIF_INTEGER_32) 7L), ((EIF_INTEGER_32) 59914L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F471_6138 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(78,F471_6138_body,(Current));
}

/* {UT_SHARED_ISE_VERSIONS}.ise_6_0_6_7057 */
static EIF_REFERENCE F471_6143_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(37)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 7057L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F471_6143 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(37,F471_6143_body,(Current));
}

/* {UT_SHARED_ISE_VERSIONS}.ise_6_0_6_7358 */
static EIF_REFERENCE F471_6144_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(79)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 7358L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F471_6144 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(79,F471_6144_body,(Current));
}

/* {UT_SHARED_ISE_VERSIONS}.ise_6_1_0 */
static EIF_REFERENCE F471_6146_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(80)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F471_6146 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(80,F471_6146_body,(Current));
}

/* {UT_SHARED_ISE_VERSIONS}.ise_6_3_7_4554 */
static EIF_REFERENCE F471_6153_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(81)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 3L), ((EIF_INTEGER_32) 7L), ((EIF_INTEGER_32) 4554L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F471_6153 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(81,F471_6153_body,(Current));
}

/* {UT_SHARED_ISE_VERSIONS}.ise_6_3_7_5660 */
static EIF_REFERENCE F471_6154_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(82)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 3L), ((EIF_INTEGER_32) 7L), ((EIF_INTEGER_32) 5660L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F471_6154 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(82,F471_6154_body,(Current));
}

/* {UT_SHARED_ISE_VERSIONS}.ise_6_4_7_7252 */
static EIF_REFERENCE F471_6158_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(83)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 4L), ((EIF_INTEGER_32) 7L), ((EIF_INTEGER_32) 7252L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F471_6158 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(83,F471_6158_body,(Current));
}

/* {UT_SHARED_ISE_VERSIONS}.ise_17_11_0 */
static EIF_REFERENCE F471_6164_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(84)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 17L), ((EIF_INTEGER_32) 11L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F471_6164 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(84,F471_6164_body,(Current));
}

/* {UT_SHARED_ISE_VERSIONS}.ise_19_01_0 */
static EIF_REFERENCE F471_6165_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(85)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 19L), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F471_6165 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(85,F471_6165_body,(Current));
}

/* {UT_SHARED_ISE_VERSIONS}.ise_latest */
static EIF_REFERENCE F471_6166_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(3)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12735(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F471_6166 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3,F471_6166_body,(Current));
}

void EIF_Minit347 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
