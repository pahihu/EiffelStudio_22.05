
#ifndef _C7_et301_
#define _C7_et301_

#ifdef __cplusplus
extern "C" {
#endif

extern void F384_5243(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F384_5245(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit301(void);
extern void F382_5231(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F382_5229(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F382_5223(EIF_REFERENCE, EIF_REFERENCE);
extern void F2040_20413(EIF_REFERENCE);
extern EIF_BOOLEAN F1295_12828(EIF_REFERENCE);
extern EIF_REFERENCE F889_7010(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R4636[])();
extern char *(*R2612[])();
extern char *(*R4643[])();
extern char *(*R8142[])();
extern char *(*R2602[])();

#ifdef __cplusplus
}
#endif

#endif
