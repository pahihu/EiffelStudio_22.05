/*
 * Code for class ET_ECF_FILE_RULE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et323.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ECF_FILE_RULE}.make */
void F418_5684 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	tr1 = F418_5692(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = F418_5692(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ET_ECF_FILE_RULE}.is_included */
EIF_BOOLEAN F418_5685 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,loc2);
	RTLIU(8);
	
	RTGC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1090,0xFF01,1181,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
		RTAR(tr1,arg1);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1180,0xFF01,0xFFF9,1,1090,0xFF01,2132,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A1194_39_1, (EIF_POINTER) _A1194_39_1, 0, tr1, 0, 1);
		}
		tb2 = F1504_13669(loc1, tr4);
		tb1 = tb2;
	}
	if (tb1) {
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1090,0xFF01,1181,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
			RTAR(tr1,arg1);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1180,0xFF01,0xFFF9,1,1090,0xFF01,2132,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A1194_39_1, (EIF_POINTER) _A1194_39_1, 0, tr1, 0, 1);
			}
			Result = F1504_13669(loc2, tr4);
		}
	}
	RTLE;
	return Result;
}

/* {ET_ECF_FILE_RULE}.set_description */
void F418_5689 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {ET_ECF_FILE_RULE}.compiled_regexp */
EIF_REFERENCE F418_5692 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = F1434_13475(RTCW(arg1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1538,0xFF01,2132,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1538, _OBJSIZ_4_0_0_2_0_0_0_0_);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_7_0_0_8_);
		F1539_13942(RTCW(Result), ti4_1);
		loc1 = F1579_14267(RTCW(arg1));
		F1337_13187(RTCW(loc1));
		for (;;) {
			tb1 = F1369_13215(RTCW(loc1));
			if (tb1) break;
			loc2 = RTLNS(eif_new_type(2132, 0x01).id, 2132, _OBJSIZ_12_16_0_23_0_0_2_0_);
			F2132_25482(RTCW(loc2));
			tb2 = RTOUCB(EIF_BOOLEAN,212,F16_174, (RTCV(RTOUCR(213,F417_5683, (Current)))));
			if (tb2) {
				F2131_25414(RTCW(loc2), (EIF_BOOLEAN) 1);
			}
			tr1 = F1319_13167(RTCW(loc1));
			F2132_25485(RTCW(loc2), tr1);
			tb2 = F2131_25395(RTCW(loc2));
			if (tb2) {
				F1539_13961(RTCW(Result), loc2);
			}
			F1337_13188(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit323 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
