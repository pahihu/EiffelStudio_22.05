
#ifndef _C7_uc338_
#define _C7_uc338_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F451_6112_body(EIF_REFERENCE);
extern EIF_REFERENCE F451_6112(EIF_REFERENCE);
extern void EIF_Minit338(void);

#ifdef __cplusplus
}
#endif

#endif
