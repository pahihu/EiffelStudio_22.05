/*
 * Code for class UT_SHARED_ECF_VERSIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut310.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_2_0 */
static EIF_REFERENCE F393_5290_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2350)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 2L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F393_5290 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2350,F393_5290_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_4_0 */
static EIF_REFERENCE F393_5292_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2389)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 4L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F393_5292 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2389,F393_5292_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_5_0 */
static EIF_REFERENCE F393_5293_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2347)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 5L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F393_5293 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2347,F393_5293_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_9_0 */
static EIF_REFERENCE F393_5297_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2345)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 9L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F393_5297 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2345,F393_5297_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_11_0 */
static EIF_REFERENCE F393_5299_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2343)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 11L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F393_5299 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2343,F393_5299_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_13_0 */
static EIF_REFERENCE F393_5301_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2584)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 13L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F393_5301 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2584,F393_5301_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_15_0 */
static EIF_REFERENCE F393_5303_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2341)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 15L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F393_5303 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2341,F393_5303_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_16_0 */
static EIF_REFERENCE F393_5304_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2585)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 16L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F393_5304 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2585,F393_5304_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_18_0 */
static EIF_REFERENCE F393_5306_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2339)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 18L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F393_5306 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2339,F393_5306_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_20_0 */
static EIF_REFERENCE F393_5308_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2586)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 20L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F393_5308 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2586,F393_5308_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_21_0 */
static EIF_REFERENCE F393_5309_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2337)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12731(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 21L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F393_5309 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2337,F393_5309_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_last_known */
static EIF_REFERENCE F393_5310_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(2587)

	
	RTEV;
	RTOTP;
	Result = RTOUCR(2586,F393_5308, (Current));
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F393_5310 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2587,F393_5310_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_latest */
static EIF_REFERENCE F393_5311_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2523)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1293_12735(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F393_5311 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2523,F393_5311_body,(Current));
}

void EIF_Minit310 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
