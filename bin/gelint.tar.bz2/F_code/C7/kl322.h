
#ifndef _C7_kl322_
#define _C7_kl322_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F417_5683_body(EIF_REFERENCE);
extern EIF_REFERENCE F417_5683(EIF_REFERENCE);
extern void EIF_Minit322(void);

#ifdef __cplusplus
}
#endif

#endif
