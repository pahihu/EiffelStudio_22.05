/*
 * Code for class XM_UNICODE_STRUCTURE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm306.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_UNICODE_STRUCTURE_FACTORY}.same_string */
EIF_BOOLEAN F389_5258 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOUCR(76,F388_5257, (Current));
	Result = F1234_11163(RTCW(tr1), arg1, arg2);
	RTLE;
	return Result;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_string_bilinked_list */
EIF_REFERENCE F389_5260 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1515,0xFF01,1189,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1515, _OBJSIZ_4_0_0_1_0_0_0_0_);
	}
	F1512_13706(RTCW(Result));
	tr1 = RTOUCR(76,F388_5257, (Current));
	F1460_13527(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_string_queue */
EIF_REFERENCE F389_5263 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1523,0xFF01,1189,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1523, _OBJSIZ_3_0_0_1_0_0_0_0_);
	}
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_detachable_string_queue */
EIF_REFERENCE F389_5264 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1523,1189,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1523, _OBJSIZ_3_0_0_1_0_0_0_0_);
	}
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_string_string_table */
EIF_REFERENCE F389_5265 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1566,0xFF01,1189,0xFF01,1189,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1566, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F1551_14128(RTCW(Result));
	tr1 = RTOUCR(76,F388_5257, (Current));
	F1551_14144(RTCW(Result), tr1);
	tr1 = RTOUCR(76,F388_5257, (Current));
	F1460_13527(RTCW(Result), tr1);
	RTLE;
	return Result;
}

void EIF_Minit306 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
