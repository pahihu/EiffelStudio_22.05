
#ifndef _C7_et342_
#define _C7_et342_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F462_6122(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit342(void);
extern char *(*R13268[])();

#ifdef __cplusplus
}
#endif

#endif
