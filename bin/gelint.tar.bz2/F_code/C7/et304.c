/*
 * Code for class ET_DYNAMIC_AGENT_OPERAND_PULL_TYPE_SET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et304.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_DYNAMIC_AGENT_OPERAND_PULL_TYPE_SET}.make */
void F387_5254 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg2;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4636[Dtype(RTCW(arg1))-383])(arg1);
	if (tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8142[Dtype(RTCW(arg1))-1135])(arg1);
		F382_5229(Current, tr1);
	}
	RTLE;
}

/* {ET_DYNAMIC_AGENT_OPERAND_PULL_TYPE_SET}.put_type_from_attachment */
void F387_5256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLR(5,loc8);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,tr4);
	RTLR(13,tr5);
	RTLR(14,loc9);
	RTLIU(15);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_2_0_0_);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
	F382_5231(Current, arg1, tr1, arg3);
	if ((EIF_BOOLEAN) (loc1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_2_0_0_))) {
		loc8 = arg1;
		loc8 = RTRV(eif_new_type(1137, 0x01),loc8);
		if (EIF_TEST(loc8)) {
			loc4 = *(EIF_REFERENCE *)(loc8 + _REFACS_14_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
			loc3 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_0_0_0_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_0_0_0_);
			if ((EIF_BOOLEAN) (ti4_1 < loc3)) {
				loc6 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_31_);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R2602[Dtype(RTCW(loc6))-266])(loc6);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2612[Dtype(RTCW(loc6))-266])(loc6);
				F2040_20413(RTCW(tr1));
			} else {
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc2 > loc3)) break;
					loc7 = RTLNS(eif_new_type(988, 0x01).id, 988, _OBJSIZ_6_1_0_2_0_0_0_0_);
					tr1 = F889_7010(RTCW(loc4), loc2);
					tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6326[Dtype(RTCW(arg2))-988])(arg2);
					tr4 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
					tr5 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
					F989_7527(RTCW(loc7), tr1, tr2, tr3, loc2, tr4, tr5);
					tr1 = F889_7010(RTCW(loc5), loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4644[Dtype(RTCW(tr1))-383])(tr1, loc7, arg3);
					loc2++;
				}
			}
		}
	} else {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_3_);
		tb2 = F1295_12828(RTCW(tr1));
		if (tb2) {
			tb1 = (EIF_BOOLEAN) !F382_5223(Current, arg1);
		}
		if (tb1) {
			loc9 = arg1;
			loc9 = RTRV(eif_new_type(1137, 0x01),loc9);
			if (EIF_TEST(loc9)) {
				loc4 = *(EIF_REFERENCE *)(loc9 + _REFACS_14_);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
				loc3 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_0_0_0_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_0_0_0_);
				if ((EIF_BOOLEAN) (ti4_1 >= loc3)) {
					loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc2 > loc3)) break;
						loc7 = RTLNS(eif_new_type(988, 0x01).id, 988, _OBJSIZ_6_1_0_2_0_0_0_0_);
						tr1 = F889_7010(RTCW(loc4), loc2);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6326[Dtype(RTCW(arg2))-988])(arg2);
						tr4 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
						tr5 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
						F989_7527(RTCW(loc7), tr1, tr2, tr3, loc2, tr4, tr5);
						tr1 = F889_7010(RTCW(loc5), loc2);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4644[Dtype(RTCW(tr1))-383])(tr1, loc7, arg3);
						loc2++;
					}
				}
			}
		}
	}
	RTLE;
}

void EIF_Minit304 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
