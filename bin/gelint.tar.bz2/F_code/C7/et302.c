/*
 * Code for class ET_DYNAMIC_PUSH_TYPE_SET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et302.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_DYNAMIC_PUSH_TYPE_SET}.make */
void F385_5246 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4636[Dtype(RTCW(arg1))-383])(arg1);
	if (tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8142[Dtype(RTCW(arg1))-1135])(arg1);
		F382_5229(Current, tr1);
	}
	RTLE;
}

/* {ET_DYNAMIC_PUSH_TYPE_SET}.put_type_from_type_set */
void F385_5248 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_);
	F382_5231(Current, arg1, arg2, arg3);
	if ((EIF_BOOLEAN) (loc1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			loc3 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_1_0_0_0_);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 > loc3)) break;
				tr1 = F889_7010(loc4, loc2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4611[Dtype(RTCW(tr1))-378])(tr1, arg1, Current, arg3);
				loc2++;
			}
		}
	}
	RTLE;
}

/* {ET_DYNAMIC_PUSH_TYPE_SET}.put_target */
void F385_5249 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	if ((EIF_BOOLEAN)(loc4 == NULL)) {
		loc4 = RTLNSMART(eif_new_type(892, 0).id);
		F889_7009(RTCW(loc4), ((EIF_INTEGER_32) 2L));
		F889_7019(RTCW(loc4), arg1);
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc4;
	} else {
		tb1 = F889_7017(RTCW(loc4), arg1);
		if (tb1) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			F889_7020(RTCW(loc4), arg1);
		}
	}
	if ((EIF_BOOLEAN) !loc1) {
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc2 > loc3)) break;
			tr1 = F382_5226(Current, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4611[Dtype(RTCW(arg1))-378])(arg1, tr1, Current, arg2);
			loc2++;
		}
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4613[Dtype(RTCW(arg1))-378])(arg1, Current);
		}
	}
	RTLE;
}

/* {ET_DYNAMIC_PUSH_TYPE_SET}.propagate_can_be_void */
void F385_5250 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			loc2 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_0_0_0_);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				tr1 = F889_7010(loc3, loc1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4613[Dtype(RTCW(tr1))-378])(tr1, Current);
				loc1++;
			}
		}
	}
	RTLE;
}

void EIF_Minit302 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
