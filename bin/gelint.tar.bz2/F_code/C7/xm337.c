/*
 * Code for class XM_MARKUP_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm337.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_MARKUP_CONSTANTS}.default_namespace */
static EIF_REFERENCE F450_6097_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(2641)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS_EX_H("",0,0);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F450_6097 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2641,F450_6097_body,(Current));
}

/* {XM_MARKUP_CONSTANTS}.xmlns */
static EIF_REFERENCE F450_6098_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(2642)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS_EX_H("xmlns",5,1836744307);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F450_6098 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2642,F450_6098_body,(Current));
}

/* {XM_MARKUP_CONSTANTS}.xml_prefix */
static EIF_REFERENCE F450_6099_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(2643)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS_EX_H("xml",3,7892332);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F450_6099 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2643,F450_6099_body,(Current));
}

/* {XM_MARKUP_CONSTANTS}.xml_prefix_namespace */
static EIF_REFERENCE F450_6104_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(2644)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS_EX_H("http://www.w3.org/XML/1998/namespace",36,212418405);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F450_6104 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2644,F450_6104_body,(Current));
}

/* {XM_MARKUP_CONSTANTS}.xmlns_namespace */
static EIF_REFERENCE F450_6105_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(2645)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS_EX_H("http://www.w3.org/2000/xmlns/",29,1059754287);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F450_6105 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2645,F450_6105_body,(Current));
}

void EIF_Minit337 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
