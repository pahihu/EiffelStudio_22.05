
#ifndef _C7_io335_
#define _C7_io335_

#ifdef __cplusplus
extern "C" {
#endif

extern void F430_5990(EIF_REFERENCE);
extern void EIF_Minit335(void);
extern EIF_BOOLEAN F792_6521(EIF_REFERENCE);
extern void F792_6549(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
