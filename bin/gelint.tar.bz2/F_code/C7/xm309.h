
#ifndef _C7_xm309_
#define _C7_xm309_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F392_5288(EIF_REFERENCE);
extern void EIF_Minit309(void);
extern EIF_REFERENCE F388_5257(EIF_REFERENCE);
extern void F1551_14144(EIF_REFERENCE, EIF_REFERENCE);
extern void F1551_14128(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
