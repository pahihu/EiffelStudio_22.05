
#ifndef _C7_et330_
#define _C7_et330_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F425_5871_body(EIF_REFERENCE);
extern EIF_REFERENCE F425_5871(EIF_REFERENCE);
extern void EIF_Minit330(void);

#ifdef __cplusplus
}
#endif

#endif
