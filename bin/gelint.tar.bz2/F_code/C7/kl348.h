
#ifndef _C7_kl348_
#define _C7_kl348_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F472_6167_body(EIF_REFERENCE);
extern EIF_REFERENCE F472_6167(EIF_REFERENCE);
extern void EIF_Minit348(void);

#ifdef __cplusplus
}
#endif

#endif
