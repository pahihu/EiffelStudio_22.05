
#ifndef _C7_uc305_
#define _C7_uc305_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F388_5257_body(EIF_REFERENCE);
extern EIF_REFERENCE F388_5257(EIF_REFERENCE);
extern void EIF_Minit305(void);

#ifdef __cplusplus
}
#endif

#endif
