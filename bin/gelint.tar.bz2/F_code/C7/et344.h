
#ifndef _C7_et344_
#define _C7_et344_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F464_6125(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit344(void);
extern EIF_BOOLEAN F1981_18372(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
