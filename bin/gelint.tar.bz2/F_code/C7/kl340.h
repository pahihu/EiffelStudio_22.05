
#ifndef _C7_kl340_
#define _C7_kl340_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F453_6119_body(EIF_REFERENCE);
extern EIF_REFERENCE F453_6119(EIF_REFERENCE);
extern void EIF_Minit340(void);

#ifdef __cplusplus
}
#endif

#endif
