
#ifndef _C7_kl346_
#define _C7_kl346_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F466_6127(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit346(void);
extern char *(*R8494[])();

#ifdef __cplusplus
}
#endif

#endif
