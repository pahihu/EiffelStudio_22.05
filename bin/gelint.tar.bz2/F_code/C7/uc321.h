
#ifndef _C7_uc321_
#define _C7_uc321_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F416_5682_body(EIF_REFERENCE);
extern EIF_REFERENCE F416_5682(EIF_REFERENCE);
extern void EIF_Minit321(void);

#ifdef __cplusplus
}
#endif

#endif
