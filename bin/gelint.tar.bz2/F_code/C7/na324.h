
#ifndef _C7_na324_
#define _C7_na324_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F419_5693(EIF_REFERENCE, EIF_POINTER);
extern EIF_NATURAL_64 F419_5694(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit324(void);

#ifdef __cplusplus
}
#endif

#endif
