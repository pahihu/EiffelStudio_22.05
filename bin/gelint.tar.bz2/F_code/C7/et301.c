/*
 * Code for class ET_DYNAMIC_AGENT_OPERAND_PUSH_TYPE_SET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et301.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_DYNAMIC_AGENT_OPERAND_PUSH_TYPE_SET}.make */
void F384_5243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4636[Dtype(RTCW(arg1))-383])(arg1);
	if (tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8142[Dtype(RTCW(arg1))-1135])(arg1);
		F382_5229(Current, tr1);
	}
	RTLE;
}

/* {ET_DYNAMIC_AGENT_OPERAND_PUSH_TYPE_SET}.put_type_from_type_set */
void F384_5245 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,loc7);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,tr1);
	RTLR(8,loc6);
	RTLR(9,tr2);
	RTLR(10,loc8);
	RTLIU(11);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_);
	F382_5231(Current, arg1, arg2, arg3);
	if ((EIF_BOOLEAN) (loc1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_))) {
		loc7 = arg1;
		loc7 = RTRV(eif_new_type(1137, 0x01),loc7);
		if (EIF_TEST(loc7)) {
			loc4 = *(EIF_REFERENCE *)(loc7 + _REFACS_14_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
			loc3 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_0_0_0_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_0_0_0_);
			if ((EIF_BOOLEAN) (ti4_1 < loc3)) {
				loc6 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_31_);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R2602[Dtype(RTCW(loc6))-266])(loc6);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2612[Dtype(RTCW(loc6))-266])(loc6);
				F2040_20413(RTCW(tr1));
			} else {
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc2 > loc3)) break;
					tr1 = F889_7010(RTCW(loc4), loc2);
					tr2 = F889_7010(RTCW(loc5), loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4643[Dtype(RTCW(tr1))-383])(tr1, tr2, arg3);
					loc2++;
				}
			}
		}
	} else {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_3_);
		tb2 = F1295_12828(RTCW(tr1));
		if (tb2) {
			tb1 = (EIF_BOOLEAN) !F382_5223(Current, arg1);
		}
		if (tb1) {
			loc8 = arg1;
			loc8 = RTRV(eif_new_type(1137, 0x01),loc8);
			if (EIF_TEST(loc8)) {
				loc4 = *(EIF_REFERENCE *)(loc8 + _REFACS_14_);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
				loc3 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_0_0_0_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_0_0_0_);
				if ((EIF_BOOLEAN) (ti4_1 >= loc3)) {
					loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc2 > loc3)) break;
						tr1 = F889_7010(RTCW(loc4), loc2);
						tr2 = F889_7010(RTCW(loc5), loc2);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R4643[Dtype(RTCW(tr1))-383])(tr1, tr2, arg3);
						loc2++;
					}
				}
			}
		}
	}
	RTLE;
}

void EIF_Minit301 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
