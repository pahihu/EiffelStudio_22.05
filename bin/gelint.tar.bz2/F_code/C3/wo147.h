
#ifndef _C3_wo147_
#define _C3_wo147_

#ifdef __cplusplus
extern "C" {
#endif

extern void F200_1866(EIF_REFERENCE, EIF_REFERENCE);
extern void F200_1868(EIF_REFERENCE);
extern void EIF_Minit147(void);
extern void F199_1843(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
