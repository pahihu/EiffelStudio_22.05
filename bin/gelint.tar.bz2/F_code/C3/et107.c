/*
 * Code for class ET_ECF_CONDITION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et107.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ECF_CONDITION}.is_capability_supported */
EIF_BOOLEAN F160_1627 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	tr1 = F1989_18531(RTCW(arg2), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F1989_18529(RTCW(arg3), arg1, loc1);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

void EIF_Minit107 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
