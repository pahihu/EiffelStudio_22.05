
#ifndef _C3_et123_
#define _C3_et123_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F176_1740(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit123(void);
extern EIF_REFERENCE F1539_13948(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
