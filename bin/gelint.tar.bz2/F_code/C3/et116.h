
#ifndef _C3_et116_
#define _C3_et116_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F169_1657(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit116(void);
extern EIF_BOOLEAN F167_1655(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
