
#ifndef _C3_et107_
#define _C3_et107_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F160_1627(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit107(void);
extern EIF_BOOLEAN F1989_18529(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1989_18531(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
