#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* ET_ECF_FILE_RULES put_last */
void _A23_39_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_ECF_FILE_RULES put_last */
void __A23_39_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_ECF_FILE_RULE is_enabled */
EIF_BOOLEAN _A323_32_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F358_3575)(open [1].it_r, closed [1].it_r);
}

	/* ET_ECF_FILE_RULE is_enabled */
EIF_BOOLEAN __A323_32_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F358_3575)(op_1, closed [1].it_r);
}

	/* ET_ECF_FILE_RULE is_included */
EIF_BOOLEAN _A323_37_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F418_5685)(open [1].it_r, closed [1].it_r);
}

	/* ET_ECF_FILE_RULE is_included */
EIF_BOOLEAN __A323_37_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F418_5685)(op_1, closed [1].it_r);
}

	/* ET_ECF_EXTERNAL_VALUE fill_external_values */
void _A283_39_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3023[Dtype(open [1].it_r) - 361])(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_ECF_EXTERNAL_VALUE fill_external_values */
void __A283_39_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3023[Dtype(op_1) - 361])(op_1, closed [1].it_r, closed [2].it_r);
}

	/* THREAD thr_get_terminated */
EIF_BOOLEAN A146_51 (EIF_REFERENCE Current)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (Current);
}

	/* THREAD thr_main */
void A146_50 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) F199_1857)(Current, arg1);
}

	/* THREAD thr_set_terminated */
void A146_52 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) F199_1859)(Current, arg1);
}

	/* RX_PCRE_REGULAR_EXPRESSION matches */
EIF_BOOLEAN _A1194_39_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2022_19521)(open [1].it_r, closed [1].it_r);
}

	/* RX_PCRE_REGULAR_EXPRESSION matches */
EIF_BOOLEAN __A1194_39_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2022_19521)(op_1, closed [1].it_r);
}

	/* RX_PCRE_REGULAR_EXPRESSION is_compiled */
EIF_BOOLEAN _A1194_320_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2131_25395)(open [1].it_r);
}

	/* RX_PCRE_REGULAR_EXPRESSION is_compiled */
EIF_BOOLEAN __A1194_320_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2131_25395)(op_1);
}

	/* MISMATCH_INFORMATION wipe_out */
void A376_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F977_7411)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A376_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F984_7484)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A376_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F984_7485)(Current, arg1, arg2);
}

	/* ET_CLIENT_LIST has_class */
EIF_BOOLEAN _A444_62_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_CLIENT_LIST has_class */
EIF_BOOLEAN __A444_62_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* KL_STRING_ROUTINES same_case_insensitive */
EIF_BOOLEAN _A521_56_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* KL_STRING_ROUTINES same_case_insensitive */
EIF_BOOLEAN __A521_56_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_STRING_ROUTINES case_insensitive_hash_code */
EIF_INTEGER_32 _A521_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* KL_STRING_ROUTINES case_insensitive_hash_code */
EIF_INTEGER_32 __A521_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* ET_LIBRARY add_library_recursive */
void _A671_358_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1610_15078)(open [1].it_r, closed [1].it_r);
}

	/* ET_LIBRARY add_library_recursive */
void __A671_358_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1610_15078)(op_1, closed [1].it_r);
}

	/* ET_LIBRARY parse_all */
void _A671_315_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_LIBRARY parse_all */
void __A671_315_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_LIBRARY import_classes */
void _A671_317_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1609_15063)(open [1].it_r);
}

	/* ET_LIBRARY import_classes */
void __A671_317_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1609_15063)(op_1);
}

	/* ET_LIBRARY preparse */
void _A671_359_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1610_15079)(open [1].it_r, closed [1].it_r);
}

	/* ET_LIBRARY preparse */
void __A671_359_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1610_15079)(op_1, closed [1].it_r);
}

	/* ET_LIBRARY add_internal_universe_recursive */
void _A671_341_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1609_15057)(open [1].it_r, closed [1].it_r);
}

	/* ET_LIBRARY add_internal_universe_recursive */
void __A671_341_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1609_15057)(op_1, closed [1].it_r);
}

	/* ET_LIBRARY add_universe_recursive */
void _A671_310_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1609_15056)(open [1].it_r, closed [1].it_r);
}

	/* ET_LIBRARY add_universe_recursive */
void __A671_310_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1609_15056)(op_1, closed [1].it_r);
}

	/* ET_CLASS implementation_checked */
EIF_BOOLEAN _A1082_472_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19486)(open [1].it_r);
}

	/* ET_CLASS implementation_checked */
EIF_BOOLEAN __A1082_472_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19486)(op_1);
}

	/* ET_CLASS interface_checked */
EIF_BOOLEAN _A1082_457_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19471)(open [1].it_r);
}

	/* ET_CLASS interface_checked */
EIF_BOOLEAN __A1082_457_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19471)(op_1);
}

	/* ET_CLASS features_flattened */
EIF_BOOLEAN _A1082_448_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19462)(open [1].it_r);
}

	/* ET_CLASS features_flattened */
EIF_BOOLEAN __A1082_448_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19462)(op_1);
}

	/* ET_CLASS ancestors_built */
EIF_BOOLEAN _A1082_395_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19409)(open [1].it_r);
}

	/* ET_CLASS ancestors_built */
EIF_BOOLEAN __A1082_395_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19409)(op_1);
}

	/* ET_CLASS is_parsed */
EIF_BOOLEAN _A1082_333_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19347)(open [1].it_r);
}

	/* ET_CLASS is_parsed */
EIF_BOOLEAN __A1082_333_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19347)(op_1);
}

	/* ET_CLASS is_marked */
EIF_BOOLEAN _A1082_108_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1134_10019)(open [1].it_r);
}

	/* ET_CLASS is_marked */
EIF_BOOLEAN __A1082_108_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1134_10019)(op_1);
}

	/* ET_CLASS is_in_override_group */
EIF_BOOLEAN _A1082_330_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19344)(open [1].it_r);
}

	/* ET_CLASS is_in_override_group */
EIF_BOOLEAN __A1082_330_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19344)(op_1);
}

	/* ET_CLASS is_in_group_recursive */
EIF_BOOLEAN _A1082_321_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS is_in_group_recursive */
EIF_BOOLEAN __A1082_321_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS is_in_group */
EIF_BOOLEAN _A1082_320_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2021_19334)(open [1].it_r, closed [1].it_r);
}

	/* ET_CLASS is_in_group */
EIF_BOOLEAN __A1082_320_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2021_19334)(op_1, closed [1].it_r);
}

	/* ET_CLASS add_by_group */
void _A1082_318_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS add_by_group */
void __A1082_318_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS reset_errors */
void _A1082_243_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS reset_errors */
void __A1082_243_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS reset_after_parsed_and_errors */
void _A1082_244_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19258)(open [1].it_r);
}

	/* ET_CLASS reset_after_parsed_and_errors */
void __A1082_244_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19258)(op_1);
}

	/* ET_CLASS reset_after_preparsed */
void _A1082_238_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19252)(open [1].it_r);
}

	/* ET_CLASS reset_after_preparsed */
void __A1082_238_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19252)(op_1);
}

	/* ET_CLASS has_syntax_error */
EIF_BOOLEAN _A1082_335_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19349)(open [1].it_r);
}

	/* ET_CLASS has_syntax_error */
EIF_BOOLEAN __A1082_335_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19349)(op_1);
}

	/* ET_CLASS reset_after_parsed */
void _A1082_239_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19253)(open [1].it_r);
}

	/* ET_CLASS reset_after_parsed */
void __A1082_239_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19253)(op_1);
}

	/* ET_CLASS has_ancestors_error */
EIF_BOOLEAN _A1082_397_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19411)(open [1].it_r);
}

	/* ET_CLASS has_ancestors_error */
EIF_BOOLEAN __A1082_397_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19411)(op_1);
}

	/* ET_CLASS set_ancestors_error */
void _A1082_399_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19413)(open [1].it_r);
}

	/* ET_CLASS set_ancestors_error */
void __A1082_399_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19413)(op_1);
}

	/* ET_CLASS reset_after_ancestors_built */
void _A1082_240_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19254)(open [1].it_r);
}

	/* ET_CLASS reset_after_ancestors_built */
void __A1082_240_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19254)(op_1);
}

	/* ET_CLASS has_flattening_error */
EIF_BOOLEAN _A1082_450_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19464)(open [1].it_r);
}

	/* ET_CLASS has_flattening_error */
EIF_BOOLEAN __A1082_450_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19464)(op_1);
}

	/* ET_CLASS set_flattening_error */
void _A1082_452_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19466)(open [1].it_r);
}

	/* ET_CLASS set_flattening_error */
void __A1082_452_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19466)(op_1);
}

	/* ET_CLASS reset_after_features_flattened */
void _A1082_241_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19255)(open [1].it_r);
}

	/* ET_CLASS reset_after_features_flattened */
void __A1082_241_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19255)(op_1);
}

	/* ET_CLASS has_interface_error */
EIF_BOOLEAN _A1082_459_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19473)(open [1].it_r);
}

	/* ET_CLASS has_interface_error */
EIF_BOOLEAN __A1082_459_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19473)(op_1);
}

	/* ET_CLASS set_interface_error */
void _A1082_461_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19475)(open [1].it_r);
}

	/* ET_CLASS set_interface_error */
void __A1082_461_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19475)(op_1);
}

	/* ET_CLASS reset_after_interface_checked */
void _A1082_242_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19256)(open [1].it_r);
}

	/* ET_CLASS reset_after_interface_checked */
void __A1082_242_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19256)(op_1);
}

	/* ET_CLASS not_implementation_checked */
EIF_BOOLEAN _A1082_99_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1134_10015)(open [1].it_r);
}

	/* ET_CLASS not_implementation_checked */
EIF_BOOLEAN __A1082_99_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1134_10015)(op_1);
}

	/* ET_CLASS has_implementation_error */
EIF_BOOLEAN _A1082_474_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19488)(open [1].it_r);
}

	/* ET_CLASS has_implementation_error */
EIF_BOOLEAN __A1082_474_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19488)(op_1);
}

	/* ET_CLASS set_implementation_error */
void _A1082_476_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19490)(open [1].it_r);
}

	/* ET_CLASS set_implementation_error */
void __A1082_476_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2021_19490)(op_1);
}

	/* ET_CLASS unmark_ignored_class */
void _A1082_282_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS unmark_ignored_class */
void __A1082_282_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS mark_ignored_class */
void _A1082_281_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS mark_ignored_class */
void __A1082_281_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS set_index */
void _A1082_304_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) F2021_19318)(open [1].it_r, closed [1].it_i4);
}

	/* ET_CLASS set_index */
void __A1082_304_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) F2021_19318)(op_1, closed [1].it_i4);
}

	/* ET_CLASS is_unknown */
EIF_BOOLEAN _A1082_278_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19292)(open [1].it_r);
}

	/* ET_CLASS is_unknown */
EIF_BOOLEAN __A1082_278_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2021_19292)(op_1);
}

	/* ET_CLASS add_to_conforming_descendants */
void _A1082_387_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS add_to_conforming_descendants */
void __A1082_387_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS add_to_descendants */
void _A1082_385_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS add_to_descendants */
void __A1082_385_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_MASTER_CLASS process */
void _A644_164_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1583_14414)(open [1].it_r, closed [1].it_r);
}

	/* ET_MASTER_CLASS process */
void __A644_164_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1583_14414)(op_1, closed [1].it_r);
}

	/* ET_MASTER_CLASS reset_local_modified_class */
void _A644_162_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS reset_local_modified_class */
void __A644_162_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_MASTER_CLASS unmark_overridden */
void _A644_144_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_MASTER_CLASS unmark_overridden */
void __A644_144_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_MASTER_CLASS mark_overridden */
void _A644_143_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_MASTER_CLASS mark_overridden */
void __A644_143_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_MASTER_CLASS local_override_classes_do_if */
void _A644_151_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1583_14401)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_override_classes_do_if */
void __A644_151_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1583_14401)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS is_in_universe */
EIF_BOOLEAN _A644_86_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_MASTER_CLASS is_in_universe */
EIF_BOOLEAN __A644_86_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_MASTER_CLASS local_non_override_classes_do_if */
void _A644_152_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1583_14402)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_non_override_classes_do_if */
void __A644_152_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1583_14402)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_classes_do_all */
void _A644_145_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_MASTER_CLASS local_classes_do_all */
void __A644_145_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_MASTER_CLASS local_classes_do_if */
void _A644_150_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1583_14400)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_classes_do_if */
void __A644_150_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1583_14400)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS is_preparsed */
EIF_BOOLEAN _A644_98_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1583_14348)(open [1].it_r);
}

	/* ET_MASTER_CLASS is_preparsed */
EIF_BOOLEAN __A644_98_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1583_14348)(op_1);
}

	/* ET_MASTER_CLASS has_syntax_error */
EIF_BOOLEAN _A644_101_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1583_14351)(open [1].it_r);
}

	/* ET_MASTER_CLASS has_syntax_error */
EIF_BOOLEAN __A644_101_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1583_14351)(op_1);
}

	/* ET_MASTER_CLASS local_classes_do_unless_actual */
void _A644_154_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1583_14404)(open [1].it_r, closed [1].it_r);
}

	/* ET_MASTER_CLASS local_classes_do_unless_actual */
void __A644_154_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1583_14404)(op_1, closed [1].it_r);
}

	/* ET_MASTER_CLASS set_modified */
void _A644_97_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) F1583_14347)(open [1].it_r, closed [1].it_b);
}

	/* ET_MASTER_CLASS set_modified */
void __A644_97_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) F1583_14347)(op_1, closed [1].it_b);
}

	/* ET_MASTER_CLASS remove_unknown_imported_classes */
void _A644_136_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1583_14386)(open [1].it_r);
}

	/* ET_MASTER_CLASS remove_unknown_imported_classes */
void __A644_136_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1583_14386)(op_1);
}

	/* ET_MASTER_CLASS reset_local_modified_classes */
void _A644_161_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1583_14411)(open [1].it_r, closed [1].it_r);
}

	/* ET_MASTER_CLASS reset_local_modified_classes */
void __A644_161_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1583_14411)(op_1, closed [1].it_r);
}

	/* ET_MASTER_CLASS remove_unknown_local_classes */
void _A644_134_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1583_14384)(open [1].it_r);
}

	/* ET_MASTER_CLASS remove_unknown_local_classes */
void __A644_134_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1583_14384)(op_1);
}

	/* ET_MASTER_CLASS local_ignored_classes_do_if */
void _A644_153_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1583_14403)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_ignored_classes_do_if */
void __A644_153_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1583_14403)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS has_imported_class */
EIF_BOOLEAN _A644_95_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1583_14345)(open [1].it_r, closed [1].it_r);
}

	/* ET_MASTER_CLASS has_imported_class */
EIF_BOOLEAN __A644_95_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1583_14345)(op_1, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] force_last */
void _A1286_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] force_last */
void _A2068_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_ARRAYED_LIST [NATURAL_32] force_last */
void _A2075_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_n4);
}

	/* DS_ARRAYED_LIST [G#1] force_last */
void __A1286_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_ARRAYED_LIST [INTEGER_32] force_last */
void __A2068_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_ARRAYED_LIST [NATURAL_32] force_last */
void __A2075_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_NATURAL_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_ARRAYED_LIST [G#1] has_void */
EIF_BOOLEAN _A1286_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] has_void */
EIF_BOOLEAN _A2068_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_ARRAYED_LIST [NATURAL_32] has_void */
EIF_BOOLEAN _A2075_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] has_void */
EIF_BOOLEAN __A1286_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_ARRAYED_LIST [INTEGER_32] has_void */
EIF_BOOLEAN __A2068_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_ARRAYED_LIST [NATURAL_32] has_void */
EIF_BOOLEAN __A2075_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_ARRAYED_LIST [G#1] is_empty */
EIF_BOOLEAN _A1286_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10763[Dtype(open [1].it_r) - 1480])(open [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] is_empty */
EIF_BOOLEAN _A2068_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1435_13475)(open [1].it_r);
}

	/* DS_ARRAYED_LIST [NATURAL_32] is_empty */
EIF_BOOLEAN _A2075_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1438_13475)(open [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] is_empty */
EIF_BOOLEAN __A1286_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10763[Dtype(op_1) - 1480])(op_1);
}

	/* DS_ARRAYED_LIST [INTEGER_32] is_empty */
EIF_BOOLEAN __A2068_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1435_13475)(op_1);
}

	/* DS_ARRAYED_LIST [NATURAL_32] is_empty */
EIF_BOOLEAN __A2075_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1438_13475)(op_1);
}

	/* DS_ARRAYED_LIST [G#1] there_exists */
EIF_BOOLEAN _A1286_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R10769[Dtype(open [1].it_r) - 1511])(open [1].it_r, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] there_exists */
EIF_BOOLEAN _A2068_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1505_13669)(open [1].it_r, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [NATURAL_32] there_exists */
EIF_BOOLEAN _A2075_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1507_13669)(open [1].it_r, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] there_exists */
EIF_BOOLEAN __A1286_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R10769[Dtype(op_1) - 1511])(op_1, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] there_exists */
EIF_BOOLEAN __A2068_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1505_13669)(op_1, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [NATURAL_32] there_exists */
EIF_BOOLEAN __A2075_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1507_13669)(op_1, closed [1].it_r);
}

	/* ET_SYSTEM_PROCESSOR process_custom */
void _A605_155 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR process_custom */
void __A605_155 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR check_implementation_validity */
void _A605_153 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR check_implementation_validity */
void __A605_153 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR parse_marked_classes */
void _A605_148 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR parse_marked_classes */
void __A605_148 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR parse_classes */
void _A605_147 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR parse_classes */
void __A605_147 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_DOTNET_ASSEMBLY add_dotnet_assembly_recursive */
void _A667_326_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1606_15000)(open [1].it_r, closed [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY add_dotnet_assembly_recursive */
void __A667_326_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1606_15000)(op_1, closed [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY add_universe_recursive */
void _A667_325_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1606_14999)(open [1].it_r, closed [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY add_universe_recursive */
void __A667_325_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1606_14999)(op_1, closed [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY is_consumable */
EIF_BOOLEAN _A667_327_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1606_15001)(open [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY is_consumable */
EIF_BOOLEAN __A667_327_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1606_15001)(op_1);
}

	/* ET_DOTNET_ASSEMBLY parse_all */
void _A667_289_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY parse_all */
void __A667_289_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_DOTNET_ASSEMBLY import_classes */
void _A667_329_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1606_15003)(open [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY import_classes */
void __A667_329_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1606_15003)(op_1);
}

	/* ET_DOTNET_ASSEMBLY preparse */
void _A667_287_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1605_14961)(open [1].it_r, closed [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY preparse */
void __A667_287_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1605_14961)(op_1, closed [1].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] conjuncted_semistrict */
EIF_BOOLEAN _A1296_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] conjuncted_semistrict */
EIF_BOOLEAN _A1975_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_b, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] conjuncted_semistrict */
EIF_BOOLEAN _A1977_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_c1, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] conjuncted_semistrict */
EIF_BOOLEAN _A1978_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] conjuncted_semistrict */
EIF_BOOLEAN __A1296_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] conjuncted_semistrict */
EIF_BOOLEAN __A1975_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] conjuncted_semistrict */
EIF_BOOLEAN __A1977_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] conjuncted_semistrict */
EIF_BOOLEAN __A1978_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] call */
void _A1296_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] call */
void _A1975_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_b, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] call */
void _A1977_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_c1, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] call */
void _A1978_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] call */
void __A1296_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] call */
void __A1975_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] call */
void __A1977_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] call */
void __A1978_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] negated */
EIF_BOOLEAN _A1296_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] negated */
EIF_BOOLEAN _A1975_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_b, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] negated */
EIF_BOOLEAN _A1977_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_c1, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] negated */
EIF_BOOLEAN _A1978_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] negated */
EIF_BOOLEAN __A1296_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] negated */
EIF_BOOLEAN __A1975_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] negated */
EIF_BOOLEAN __A1977_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] negated */
EIF_BOOLEAN __A1978_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] conjuncted */
EIF_BOOLEAN _A1296_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] conjuncted */
EIF_BOOLEAN _A1975_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_b, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] conjuncted */
EIF_BOOLEAN _A1977_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_c1, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] conjuncted */
EIF_BOOLEAN _A1978_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] conjuncted */
EIF_BOOLEAN __A1296_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] conjuncted */
EIF_BOOLEAN __A1975_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] conjuncted */
EIF_BOOLEAN __A1977_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] conjuncted */
EIF_BOOLEAN __A1978_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* UT_COUNTER increment */
void _A32_35 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* UT_COUNTER increment */
void __A32_35 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN _A514_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F733_6436)(open [1].it_r);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN __A514_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F733_6436)(op_1);
}

	/* ET_ECF_CLUSTER fill_file_rules */
void _A662_213_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1601_14731)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_ECF_CLUSTER fill_file_rules */
void __A662_213_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1601_14731)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* UT_TRISTATE set_true */
void _A31_38 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* UT_TRISTATE set_true */
void __A31_38 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* UT_TRISTATE is_true */
EIF_BOOLEAN _A31_35 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* UT_TRISTATE is_true */
EIF_BOOLEAN __A31_35 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* ET_UNIVERSE fake inline-agent#25952#208#83# of classes_modified_recursive */
EIF_BOOLEAN _A666_282_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1605_25952)(closed [1].it_r, open [1].it_r);
}

	/* ET_UNIVERSE fake inline-agent#25952#208#83# of classes_modified_recursive */
EIF_BOOLEAN __A666_282_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1605_25952)(closed [1].it_r, op_2);
}

	/* ET_UNIVERSE master_classes_do_if */
void _A666_253_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1605_14944)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE master_classes_do_if */
void __A666_253_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1605_14944)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE master_classes_do_if_until */
void _A666_254_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1605_14945)(open [1].it_r, closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_UNIVERSE master_classes_do_if_until */
void __A666_254_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1605_14945)(op_1, closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_UNIVERSE master_classes_do_all */
void _A666_251_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1605_14942)(open [1].it_r, closed [1].it_r);
}

	/* ET_UNIVERSE master_classes_do_all */
void __A666_251_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1605_14942)(op_1, closed [1].it_r);
}

	/* ET_UNIVERSE master_classes_do_until */
void _A666_252_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1605_14943)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE master_classes_do_until */
void __A666_252_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1605_14943)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE classes_do_if */
void _A666_243_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R11615[Dtype(open [1].it_r) - 1605])(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE classes_do_if */
void __A666_243_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R11615[Dtype(op_1) - 1605])(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE classes_do_if_until */
void _A666_245_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE classes_do_if_until */
void __A666_245_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE classes_do_unless */
void _A666_244_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE classes_do_unless */
void __A666_244_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE classes_do_all */
void _A666_241_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11613[Dtype(open [1].it_r) - 1605])(open [1].it_r, closed [1].it_r);
}

	/* ET_UNIVERSE classes_do_all */
void __A666_241_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11613[Dtype(op_1) - 1605])(op_1, closed [1].it_r);
}

	/* ET_UNIVERSE classes_do_until */
void _A666_242_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1605_14933)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE classes_do_until */
void __A666_242_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1605_14933)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE insert_in_hash_table */
void _A666_280_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_i4, open [1].it_r);
}

	/* ET_UNIVERSE insert_in_hash_table */
void __A666_280_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_4)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_i4, op_4);
}

	/* ET_UNIVERSE add_classes_by_wildcarded_name */
void _A666_80_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE add_classes_by_wildcarded_name */
void __A666_80_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE do_class_by_wildcarded_name */
void _A666_268_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_UNIVERSE do_class_by_wildcarded_name */
void __A666_268_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* ET_UNIVERSE do_class_by_name */
void _A666_267_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE do_class_by_name */
void __A666_267_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE do_master_class_by_name */
void _A666_266_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE do_master_class_by_name */
void __A666_266_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE has_class */
EIF_BOOLEAN _A666_71_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE has_class */
EIF_BOOLEAN __A666_71_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE has_master_class */
EIF_BOOLEAN _A666_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1605_14760)(open [1].it_r, closed [1].it_r);
}

	/* ET_UNIVERSE has_master_class */
EIF_BOOLEAN __A666_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1605_14760)(op_1, closed [1].it_r);
}

	/* DS_HASH_TABLE [G#1, G#2] has */
EIF_BOOLEAN _A1258_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_TABLE [INTEGER_32, G#2] has */
EIF_BOOLEAN _A1306_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_TABLE [BOOLEAN, G#2] has */
EIF_BOOLEAN _A1371_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_TABLE [G#1, INTEGER_32] has */
EIF_BOOLEAN _A1701_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_BOOLEAN Result;
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(1096, 0x00).id, 1096, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = open [1].it_i4;
	Result = f_ptr (closed [1].it_r, arg1);
	RTLE;
	return Result;
}

	/* DS_HASH_TABLE [NATURAL_64, NATURAL_32] has */
EIF_BOOLEAN _A1800_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_n4);
}

	/* DS_HASH_TABLE [G#1, NATURAL_8] has */
EIF_BOOLEAN _A1914_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_n1);
}

	/* DS_HASH_TABLE [NATURAL_8, G#2] has */
EIF_BOOLEAN _A1951_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_TABLE [INTEGER_32, INTEGER_32] has */
EIF_BOOLEAN _A2011_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_HASH_TABLE [G#1, G#2] has */
EIF_BOOLEAN __A1258_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [INTEGER_32, G#2] has */
EIF_BOOLEAN __A1306_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [BOOLEAN, G#2] has */
EIF_BOOLEAN __A1371_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [G#1, INTEGER_32] has */
EIF_BOOLEAN __A1701_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	EIF_BOOLEAN Result;
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(1096, 0x00).id, 1096, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = op_2;
	Result = f_ptr (closed [1].it_r, arg1);
	RTLE;
	return Result;
}

	/* DS_HASH_TABLE [NATURAL_64, NATURAL_32] has */
EIF_BOOLEAN __A1800_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_NATURAL_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [G#1, NATURAL_8] has */
EIF_BOOLEAN __A1914_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8), EIF_TYPED_VALUE * closed, EIF_NATURAL_8 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [NATURAL_8, G#2] has */
EIF_BOOLEAN __A1951_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [INTEGER_32, INTEGER_32] has */
EIF_BOOLEAN __A2011_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [G#1] force_last */
void _A1438_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_SET [INTEGER_32] force_last */
void _A1690_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_HASH_SET [G#1] force_last */
void __A1438_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [INTEGER_32] force_last */
void __A1690_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [G#1] has */
EIF_BOOLEAN _A1438_131_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_SET [INTEGER_32] has */
EIF_BOOLEAN _A1690_131_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_HASH_SET [G#1] has */
EIF_BOOLEAN __A1438_131_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [INTEGER_32] has */
EIF_BOOLEAN __A1690_131_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [G#1] remove */
void _A1438_69_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_SET [INTEGER_32] remove */
void _A1690_69_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_HASH_SET [G#1] remove */
void __A1438_69_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [INTEGER_32] remove */
void __A1690_69_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_ANCESTORS_STATUS_CHECKER process_class */
void _A417_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_ANCESTORS_STATUS_CHECKER process_class */
void __A417_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_FLATTENING_STATUS_CHECKER process_class */
void _A416_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_FLATTENING_STATUS_CHECKER process_class */
void __A416_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_INTERFACE_STATUS_CHECKER process_class */
void _A415_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_INTERFACE_STATUS_CHECKER process_class */
void __A415_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_IMPLEMENTATION_STATUS_CHECKER process_class */
void _A418_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_IMPLEMENTATION_STATUS_CHECKER process_class */
void __A418_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_ADAPTED_LIBRARY export_classes */
void _A230_43_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F304_3407)(open [1].it_r, closed [1].it_r);
}

	/* ET_ADAPTED_LIBRARY export_classes */
void __A230_43_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F304_3407)(op_1, closed [1].it_r);
}

	/* ET_ADAPTED_LIBRARY propagate_read_only */
void _A230_40_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F304_3404)(open [1].it_r);
}

	/* ET_ADAPTED_LIBRARY propagate_read_only */
void __A230_40_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F304_3404)(op_1);
}

	/* ET_ADAPTED_DOTNET_ASSEMBLY export_classes */
void _A231_43_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F304_3407)(open [1].it_r, closed [1].it_r);
}

	/* ET_ADAPTED_DOTNET_ASSEMBLY export_classes */
void __A231_43_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F304_3407)(op_1, closed [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE dotnet_assemblies_do_if */
void _A670_309_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1609_15055)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_INTERNAL_UNIVERSE dotnet_assemblies_do_if */
void __A670_309_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1609_15055)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_INTERNAL_UNIVERSE clusters_do_explicit */
void _A670_301_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1609_15047)(open [1].it_r, closed [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE clusters_do_explicit */
void __A670_301_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1609_15047)(op_1, closed [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE add_implicit_subclusters */
void _A670_299_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE add_implicit_subclusters */
void __A670_299_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_INTERNAL_UNIVERSE do_cluster_with_absolute_pathname */
void _A670_312_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE do_cluster_with_absolute_pathname */
void __A670_312_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_INTERNAL_UNIVERSE has_cluster_with_absolute_pathname */
EIF_BOOLEAN _A670_276_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE has_cluster_with_absolute_pathname */
EIF_BOOLEAN __A670_276_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_INTERNAL_UNIVERSE has_cluster_by_name */
EIF_BOOLEAN _A670_274_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE has_cluster_by_name */
EIF_BOOLEAN __A670_274_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_INTERNAL_UNIVERSE has_cluster */
EIF_BOOLEAN _A670_272_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE has_cluster */
EIF_BOOLEAN __A670_272_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_DOTNET_ASSEMBLIES put_last */
void _A617_40_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_DOTNET_ASSEMBLIES put_last */
void __A617_40_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_CLUSTER process */
void _A661_171_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1600_14699)(open [1].it_r, closed [1].it_r);
}

	/* ET_CLUSTER process */
void __A661_171_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1600_14699)(op_1, closed [1].it_r);
}

	/* DS_CELL [G#1] put */
void _A1303_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_CELL [INTEGER_32] put */
void _A1536_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_CELL [CHARACTER_8] put */
void _A2059_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_c1);
}

	/* DS_CELL [G#1] put */
void __A1303_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_CELL [INTEGER_32] put */
void __A1536_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_CELL [CHARACTER_8] put */
void __A2059_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_SYSTEM build_scm_write_mapping */
void _A672_421_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_SYSTEM build_scm_write_mapping */
void __A672_421_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_SYSTEM build_scm_read_mapping */
void _A672_417_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_SYSTEM build_scm_read_mapping */
void __A672_417_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_PARENT_LIST has_conforming_parent */
EIF_BOOLEAN _A701_68_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1640_15366)(open [1].it_r);
}

	/* ET_PARENT_LIST has_conforming_parent */
EIF_BOOLEAN __A701_68_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1640_15366)(op_1);
}

	/* ET_DYNAMIC_SYSTEM compile_all_features */
void _A1051_140_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_DYNAMIC_SYSTEM compile_all_features */
void __A1051_140_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_EIFFEL_SCANNER_SKELETON add_universe_full_name */
void _A1120_510_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_EIFFEL_SCANNER_SKELETON add_universe_full_name */
void __A1120_510_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_ECF_OPTIONS set_primary_assertion_value */
void _A1048_53_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_ECF_OPTIONS set_primary_assertion_value */
void __A1048_53_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions_in_option */
void _A1139_198_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions_in_option */
void __A1139_198_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions_in_cluster */
void _A1139_196_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions_in_cluster */
void __A1139_196_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions_in_adapted_group */
void _A1139_197_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions_in_adapted_group */
void __A1139_197_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions */
void _A1139_195_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2078_23720)(open [1].it_r, closed [1].it_r);
}

	/* ET_ECF_TARGET override_all_assertions */
void __A1139_195_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2078_23720)(op_1, closed [1].it_r);
}

	/* ET_CLUSTER_DEPENDENCE_CONSTRAINT matches_pathname */
EIF_BOOLEAN _A1186_48_4 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, open [1].it_r);
}

	/* ET_CLUSTER_DEPENDENCE_CONSTRAINT matches_pathname */
EIF_BOOLEAN __A1186_48_4 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_4)
{
	return f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, op_4);
}

	/* ET_ECF_PARSER_SKELETON adapt_options */
void _A1189_367_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_ECF_PARSER_SKELETON adapt_options */
void __A1189_367_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_ECF_PARSER build_library */
void _A1190_380_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_ECF_PARSER build_library */
void __A1190_380_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_REFERENCE op_4)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, closed [2].it_r, closed [3].it_r);
}

	/* ET_ECF_PARSER build_system_config */
void _A1190_377_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_ECF_PARSER build_system_config */
void __A1190_377_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_REFERENCE op_4)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, closed [2].it_r, closed [3].it_r);
}

	/* ET_ECF_SYSTEM_PARSER override_target */
void _A1191_399_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_ECF_SYSTEM_PARSER override_target */
void __A1191_399_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_ECF_SYSTEM_PARSER build_system */
void _A1191_379_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* ET_ECF_SYSTEM_PARSER build_system */
void __A1191_379_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_REFERENCE op_4)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}


#ifdef __cplusplus
}
#endif
