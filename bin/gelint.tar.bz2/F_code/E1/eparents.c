#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ANY */
static EIF_TYPE_INDEX ptf0[] = {0xFFFF};
static struct eif_par_types par0 = {0, ptf0, (uint16) 0, (uint16) 0, (char) 0};

/* KL_BOOLEAN_ROUTINES */
static EIF_TYPE_INDEX ptf1[] = {0,0xFFFF};
static struct eif_par_types par1 = {1, ptf1, (uint16) 1, (uint16) 0, (char) 0};

/* LX_DESCRIPTION_OVERRIDER */
static EIF_TYPE_INDEX ptf2[] = {0,0xFFFF};
static struct eif_par_types par2 = {2, ptf2, (uint16) 1, (uint16) 0, (char) 0};

/* LX_ACTION_FACTORY */
static EIF_TYPE_INDEX ptf3[] = {0,0xFFFF};
static struct eif_par_types par3 = {3, ptf3, (uint16) 1, (uint16) 0, (char) 0};

/* LX_START_CONDITION */
static EIF_TYPE_INDEX ptf4[] = {0,0xFFFF};
static struct eif_par_types par4 = {4, ptf4, (uint16) 1, (uint16) 0, (char) 0};

/* DESCRIPTOR_CACHE */
static EIF_TYPE_INDEX ptf5[] = {0,0xFFFF};
static struct eif_par_types par5 = {5, ptf5, (uint16) 1, (uint16) 0, (char) 0};

/* UT_BOOLEAN_FORMATTER */
static EIF_TYPE_INDEX ptf6[] = {0,0xFFFF};
static struct eif_par_types par6 = {6, ptf6, (uint16) 1, (uint16) 0, (char) 0};

/* UT_ARRAY_FORMATTER */
static EIF_TYPE_INDEX ptf7[] = {0,0xFFFF};
static struct eif_par_types par7 = {7, ptf7, (uint16) 1, (uint16) 0, (char) 0};

/* C_DATE */
static EIF_TYPE_INDEX ptf8[] = {0,0xFFFF};
static struct eif_par_types par8 = {8, ptf8, (uint16) 1, (uint16) 0, (char) 0};

/* KL_EIFFEL_COMPILER */
static EIF_TYPE_INDEX ptf9[] = {0,0xFFFF};
static struct eif_par_types par9 = {9, ptf9, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EIFFEL_DECLARATION */
static EIF_TYPE_INDEX ptf10[] = {0,0xFFFF};
static struct eif_par_types par10 = {10, ptf10, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_VISIBLE_CLASS */
static EIF_TYPE_INDEX ptf11[] = {0,0xFFFF};
static struct eif_par_types par11 = {11, ptf11, (uint16) 1, (uint16) 0, (char) 0};

/* RX_CHARACTER_SET */
static EIF_TYPE_INDEX ptf12[] = {0,0xFFFF};
static struct eif_par_types par12 = {12, ptf12, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ITERATION_CURSOR_SCOPE */
static EIF_TYPE_INDEX ptf13[] = {0,0xFFFF};
static struct eif_par_types par13 = {13, ptf13, (uint16) 1, (uint16) 0, (char) 0};

/* ET_OBJECT_TEST_SCOPE */
static EIF_TYPE_INDEX ptf14[] = {0,0xFFFF};
static struct eif_par_types par14 = {14, ptf14, (uint16) 1, (uint16) 0, (char) 0};

/* KL_OPERATING_SYSTEM */
static EIF_TYPE_INDEX ptf15[] = {0,0xFFFF};
static struct eif_par_types par15 = {15, ptf15, (uint16) 1, (uint16) 0, (char) 0};

/* KL_AGENT_ROUTINES [G#1] */
static EIF_TYPE_INDEX ptf16[] = {0,0xFFFF};
static struct eif_par_types par16 = {16, ptf16, (uint16) 1, (uint16) 1, (char) 0};

/* KL_AGENT_ROUTINES [BOOLEAN] */
static EIF_TYPE_INDEX ptf17[] = {0,0xFFFF};
static struct eif_par_types par17 = {17, ptf17, (uint16) 1, (uint16) 1, (char) 0};

/* KL_AGENT_ROUTINES [CHARACTER_8] */
static EIF_TYPE_INDEX ptf18[] = {0,0xFFFF};
static struct eif_par_types par18 = {18, ptf18, (uint16) 1, (uint16) 1, (char) 0};

/* KL_AGENT_ROUTINES [INTEGER_32] */
static EIF_TYPE_INDEX ptf19[] = {0,0xFFFF};
static struct eif_par_types par19 = {19, ptf19, (uint16) 1, (uint16) 1, (char) 0};

/* LX_DESCRIPTION */
static EIF_TYPE_INDEX ptf20[] = {0,0xFFFF};
static struct eif_par_types par20 = {20, ptf20, (uint16) 1, (uint16) 0, (char) 0};

/* VERSIONABLE */
static EIF_TYPE_INDEX ptf21[] = {0,0xFFFF};
static struct eif_par_types par21 = {21, ptf21, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_CONFIG_PROCESSOR */
static EIF_TYPE_INDEX ptf22[] = {0,0xFFFF};
static struct eif_par_types par22 = {22, ptf22, (uint16) 1, (uint16) 0, (char) 0};

/* XM_POSITION_TABLE */
static EIF_TYPE_INDEX ptf23[] = {0,0xFFFF};
static struct eif_par_types par23 = {23, ptf23, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_OPTION_NAMES */
static EIF_TYPE_INDEX ptf24[] = {0,0xFFFF};
static struct eif_par_types par24 = {24, ptf24, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_SETTING_NAMES */
static EIF_TYPE_INDEX ptf25[] = {0,0xFFFF};
static struct eif_par_types par25 = {25, ptf25, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_FILE_RULES */
static EIF_TYPE_INDEX ptf26[] = {0,0xFFFF};
static struct eif_par_types par26 = {26, ptf26, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_STATE */
static EIF_TYPE_INDEX ptf27[] = {0,0xFFFF};
static struct eif_par_types par27 = {27, ptf27, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_TARGET_PARENT */
static EIF_TYPE_INDEX ptf28[] = {0,0xFFFF};
static struct eif_par_types par28 = {28, ptf28, (uint16) 1, (uint16) 0, (char) 0};

/* KL_ANY_ROUTINES */
static EIF_TYPE_INDEX ptf29[] = {0,0xFFFF};
static struct eif_par_types par29 = {29, ptf29, (uint16) 1, (uint16) 0, (char) 0};

/* SYSTEM_ENCODINGS */
static EIF_TYPE_INDEX ptf30[] = {0,0xFFFF};
static struct eif_par_types par30 = {30, ptf30, (uint16) 1, (uint16) 0, (char) 0};

/* CODE_PAGE_CONSTANTS */
static EIF_TYPE_INDEX ptf31[] = {0,0xFFFF};
static struct eif_par_types par31 = {31, ptf31, (uint16) 1, (uint16) 0, (char) 0};

/* ENCODING */
static EIF_TYPE_INDEX ptf32[] = {0,0xFFFF};
static struct eif_par_types par32 = {32, ptf32, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_ROUTINES */
static EIF_TYPE_INDEX ptf33[] = {0,0xFFFF};
static struct eif_par_types par33 = {33, ptf33, (uint16) 1, (uint16) 0, (char) 0};

/* UT_TRISTATE */
static EIF_TYPE_INDEX ptf34[] = {0,0xFFFF};
static struct eif_par_types par34 = {34, ptf34, (uint16) 1, (uint16) 0, (char) 0};

/* UT_COUNTER */
static EIF_TYPE_INDEX ptf35[] = {0,0xFFFF};
static struct eif_par_types par35 = {35, ptf35, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SPECIAL_ROUTINES [G#1] */
static EIF_TYPE_INDEX ptf36[] = {0,0xFFFF};
static struct eif_par_types par36 = {36, ptf36, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [INTEGER_32] */
static EIF_TYPE_INDEX ptf37[] = {0,0xFFFF};
static struct eif_par_types par37 = {37, ptf37, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [BOOLEAN] */
static EIF_TYPE_INDEX ptf38[] = {0,0xFFFF};
static struct eif_par_types par38 = {38, ptf38, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [NATURAL_64] */
static EIF_TYPE_INDEX ptf39[] = {0,0xFFFF};
static struct eif_par_types par39 = {39, ptf39, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [NATURAL_32] */
static EIF_TYPE_INDEX ptf40[] = {0,0xFFFF};
static struct eif_par_types par40 = {40, ptf40, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [NATURAL_8] */
static EIF_TYPE_INDEX ptf41[] = {0,0xFFFF};
static struct eif_par_types par41 = {41, ptf41, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [CHARACTER_8] */
static EIF_TYPE_INDEX ptf42[] = {0,0xFFFF};
static struct eif_par_types par42 = {42, ptf42, (uint16) 1, (uint16) 1, (char) 0};

/* SYSTEM_STRING_FACTORY */
static EIF_TYPE_INDEX ptf43[] = {0,0xFFFF};
static struct eif_par_types par43 = {43, ptf43, (uint16) 1, (uint16) 0, (char) 0};

/* CHARACTER_PROPERTY */
static EIF_TYPE_INDEX ptf44[] = {0,0xFFFF};
static struct eif_par_types par44 = {44, ptf44, (uint16) 1, (uint16) 0, (char) 0};

/* KL_STANDARD_FILES */
static EIF_TYPE_INDEX ptf45[] = {0,0xFFFF};
static struct eif_par_types par45 = {45, ptf45, (uint16) 1, (uint16) 0, (char) 0};

/* ET_PARENT_FEATURE */
static EIF_TYPE_INDEX ptf46[] = {0,0xFFFF};
static struct eif_par_types par46 = {46, ptf46, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_CAPABILITY_NAMES */
static EIF_TYPE_INDEX ptf47[] = {0,0xFFFF};
static struct eif_par_types par47 = {47, ptf47, (uint16) 1, (uint16) 0, (char) 0};

/* DT_SHARED_SYSTEM_CLOCK */
static EIF_TYPE_INDEX ptf48[] = {0,0xFFFF};
static struct eif_par_types par48 = {48, ptf48, (uint16) 1, (uint16) 0, (char) 0};

/* SYSTEM_STRING */
static EIF_TYPE_INDEX ptf49[] = {0,0xFFFF};
static struct eif_par_types par49 = {49, ptf49, (uint16) 1, (uint16) 0, (char) 0};

/* RT_DBG_EXECUTION_PARAMETERS */
static EIF_TYPE_INDEX ptf50[] = {0,0xFFFF};
static struct eif_par_types par50 = {50, ptf50, (uint16) 1, (uint16) 0, (char) 0};

/* reference UTF_CONVERTER */
static EIF_TYPE_INDEX ptf51[] = {0,0xFFFF};
static struct eif_par_types par51 = {51, ptf51, (uint16) 1, (uint16) 0, (char) 1};

/* UTF_CONVERTER */
static EIF_TYPE_INDEX ptf52[] = {51,0xFFFF};
static struct eif_par_types par52 = {52, ptf52, (uint16) 1, (uint16) 0, (char) 1};

/* ISE_RUNTIME */
static EIF_TYPE_INDEX ptf53[] = {0,0xFFFF};
static struct eif_par_types par53 = {53, ptf53, (uint16) 1, (uint16) 0, (char) 0};

/* NATIVE_ARRAY [G#1] */
static EIF_TYPE_INDEX ptf54[] = {0,0xFFFF};
static struct eif_par_types par54 = {54, ptf54, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [INTEGER_32] */
static EIF_TYPE_INDEX ptf55[] = {0,0xFFFF};
static struct eif_par_types par55 = {55, ptf55, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [BOOLEAN] */
static EIF_TYPE_INDEX ptf56[] = {0,0xFFFF};
static struct eif_par_types par56 = {56, ptf56, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [NATURAL_64] */
static EIF_TYPE_INDEX ptf57[] = {0,0xFFFF};
static struct eif_par_types par57 = {57, ptf57, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [NATURAL_32] */
static EIF_TYPE_INDEX ptf58[] = {0,0xFFFF};
static struct eif_par_types par58 = {58, ptf58, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [NATURAL_16] */
static EIF_TYPE_INDEX ptf59[] = {0,0xFFFF};
static struct eif_par_types par59 = {59, ptf59, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [NATURAL_8] */
static EIF_TYPE_INDEX ptf60[] = {0,0xFFFF};
static struct eif_par_types par60 = {60, ptf60, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [CHARACTER_32] */
static EIF_TYPE_INDEX ptf61[] = {0,0xFFFF};
static struct eif_par_types par61 = {61, ptf61, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [CHARACTER_8] */
static EIF_TYPE_INDEX ptf62[] = {0,0xFFFF};
static struct eif_par_types par62 = {62, ptf62, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [POINTER] */
static EIF_TYPE_INDEX ptf63[] = {0,0xFFFF};
static struct eif_par_types par63 = {63, ptf63, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [REAL_32] */
static EIF_TYPE_INDEX ptf64[] = {0,0xFFFF};
static struct eif_par_types par64 = {64, ptf64, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [REAL_64] */
static EIF_TYPE_INDEX ptf65[] = {0,0xFFFF};
static struct eif_par_types par65 = {65, ptf65, (uint16) 1, (uint16) 1, (char) 0};

/* OPERATING_ENVIRONMENT */
static EIF_TYPE_INDEX ptf66[] = {0,0xFFFF};
static struct eif_par_types par66 = {66, ptf66, (uint16) 1, (uint16) 0, (char) 0};

/* STD_FILES */
static EIF_TYPE_INDEX ptf67[] = {0,0xFFFF};
static struct eif_par_types par67 = {67, ptf67, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SYSTEM_PROCESSOR_FACTORY */
static EIF_TYPE_INDEX ptf68[] = {0,0xFFFF};
static struct eif_par_types par68 = {68, ptf68, (uint16) 1, (uint16) 0, (char) 0};

/* MEMORY_STRUCTURE */
static EIF_TYPE_INDEX ptf69[] = {0,0xFFFF};
static struct eif_par_types par69 = {69, ptf69, (uint16) 1, (uint16) 0, (char) 0};

/* DP_COMMAND */
static EIF_TYPE_INDEX ptf70[] = {0,0xFFFF};
static struct eif_par_types par70 = {70, ptf70, (uint16) 1, (uint16) 0, (char) 0};

/* LX_ACTION */
static EIF_TYPE_INDEX ptf71[] = {70,0xFFFF};
static struct eif_par_types par71 = {71, ptf71, (uint16) 1, (uint16) 0, (char) 0};

/* KI_PLATFORM */
static EIF_TYPE_INDEX ptf72[] = {0,0xFFFF};
static struct eif_par_types par72 = {72, ptf72, (uint16) 1, (uint16) 0, (char) 0};

/* KI_OUTPUT_STREAM [CHARACTER_8] */
static EIF_TYPE_INDEX ptf73[] = {0,0xFFFF};
static struct eif_par_types par73 = {73, ptf73, (uint16) 1, (uint16) 1, (char) 0};

/* CODE_SETS */
static EIF_TYPE_INDEX ptf74[] = {0,0xFFFF};
static struct eif_par_types par74 = {74, ptf74, (uint16) 1, (uint16) 0, (char) 0};

/* DT_SHARED_WEEK_DAYS_FROM_SUNDAY */
static EIF_TYPE_INDEX ptf75[] = {0,0xFFFF};
static struct eif_par_types par75 = {75, ptf75, (uint16) 1, (uint16) 0, (char) 0};

/* KL_PART_COMPARABLE */
static EIF_TYPE_INDEX ptf76[] = {0,0xFFFF};
static struct eif_par_types par76 = {76, ptf76, (uint16) 1, (uint16) 0, (char) 0};

/* KI_SYSTEM_CLOCK */
static EIF_TYPE_INDEX ptf77[] = {0,0xFFFF};
static struct eif_par_types par77 = {77, ptf77, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SYSTEM_CLOCK */
static EIF_TYPE_INDEX ptf78[] = {77,0xFFFF};
static struct eif_par_types par78 = {78, ptf78, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SHARED_IDENTIFIER_TESTER */
static EIF_TYPE_INDEX ptf79[] = {0,0xFFFF};
static struct eif_par_types par79 = {79, ptf79, (uint16) 1, (uint16) 0, (char) 0};

/* DS_SORTER [G#1] */
static EIF_TYPE_INDEX ptf80[] = {0,0xFFFF};
static struct eif_par_types par80 = {80, ptf80, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf81[] = {0,0xFFFF};
static struct eif_par_types par81 = {81, ptf81, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf82[] = {0,0xFFFF};
static struct eif_par_types par82 = {82, ptf82, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTER [NATURAL_32] */
static EIF_TYPE_INDEX ptf83[] = {0,0xFFFF};
static struct eif_par_types par83 = {83, ptf83, (uint16) 1, (uint16) 1, (char) 0};

/* DS_INDEXABLE_SORTER [G#1] */
static EIF_TYPE_INDEX ptf84[] = {80,0xFFF8,1,0xFFFF};
static struct eif_par_types par84 = {84, ptf84, (uint16) 1, (uint16) 1, (char) 0};

/* DS_INDEXABLE_SORTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf85[] = {81,1096,0xFFFF};
static struct eif_par_types par85 = {85, ptf85, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BUBBLE_SORTER [G#1] */
static EIF_TYPE_INDEX ptf86[] = {84,0xFFF8,1,0xFFFF};
static struct eif_par_types par86 = {86, ptf86, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BUBBLE_SORTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf87[] = {85,1096,0xFFFF};
static struct eif_par_types par87 = {87, ptf87, (uint16) 1, (uint16) 1, (char) 0};

/* DS_QUICK_SORTER [G#1] */
static EIF_TYPE_INDEX ptf88[] = {84,0xFFF8,1,0xFFFF};
static struct eif_par_types par88 = {88, ptf88, (uint16) 1, (uint16) 1, (char) 0};

/* LX_EQUIVALENCE_CLASSES */
static EIF_TYPE_INDEX ptf89[] = {0,0xFFFF};
static struct eif_par_types par89 = {89, ptf89, (uint16) 1, (uint16) 0, (char) 0};

/* LX_SYMBOL_PARTITIONS */
static EIF_TYPE_INDEX ptf90[] = {89,0xFFFF};
static struct eif_par_types par90 = {90, ptf90, (uint16) 1, (uint16) 0, (char) 0};

/* YY_PARSER */
static EIF_TYPE_INDEX ptf91[] = {0,0xFFFF};
static struct eif_par_types par91 = {91, ptf91, (uint16) 1, (uint16) 0, (char) 0};

/* OBJECT_GRAPH_TRAVERSABLE */
static EIF_TYPE_INDEX ptf92[] = {0,0xFFFF};
static struct eif_par_types par92 = {92, ptf92, (uint16) 1, (uint16) 0, (char) 0};

/* OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE */
static EIF_TYPE_INDEX ptf93[] = {92,0xFFFF};
static struct eif_par_types par93 = {93, ptf93, (uint16) 1, (uint16) 0, (char) 0};

/* KL_ANY */
static EIF_TYPE_INDEX ptf94[] = {0,0xFFFF};
static struct eif_par_types par94 = {94, ptf94, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_PLATFORM */
static EIF_TYPE_INDEX ptf95[] = {94,0xFFFF};
static struct eif_par_types par95 = {95, ptf95, (uint16) 1, (uint16) 0, (char) 0};

/* KL_CHARACTER_ROUTINES */
static EIF_TYPE_INDEX ptf96[] = {95,0xFFFF};
static struct eif_par_types par96 = {96, ptf96, (uint16) 1, (uint16) 0, (char) 0};

/* UC_UNICODE_CONSTANTS */
static EIF_TYPE_INDEX ptf97[] = {95,0xFFFF};
static struct eif_par_types par97 = {97, ptf97, (uint16) 1, (uint16) 0, (char) 0};

/* UC_STRING_HANDLER */
static EIF_TYPE_INDEX ptf98[] = {0,0xFFFF};
static struct eif_par_types par98 = {98, ptf98, (uint16) 1, (uint16) 0, (char) 0};

/* XM_CALLBACKS_FILTER_FACTORY */
static EIF_TYPE_INDEX ptf99[] = {0,0xFFFF};
static struct eif_par_types par99 = {99, ptf99, (uint16) 1, (uint16) 0, (char) 0};

/* XM_ERROR_CODES */
static EIF_TYPE_INDEX ptf100[] = {0,0xFFFF};
static struct eif_par_types par100 = {100, ptf100, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EXTERNAL_RESOLVER */
static EIF_TYPE_INDEX ptf101[] = {0,0xFFFF};
static struct eif_par_types par101 = {101, ptf101, (uint16) 1, (uint16) 0, (char) 0};

/* XM_NULL_EXTERNAL_RESOLVER */
static EIF_TYPE_INDEX ptf102[] = {101,0xFFFF};
static struct eif_par_types par102 = {102, ptf102, (uint16) 1, (uint16) 0, (char) 0};

/* XM_SOURCE */
static EIF_TYPE_INDEX ptf103[] = {0,0xFFFF};
static struct eif_par_types par103 = {103, ptf103, (uint16) 1, (uint16) 0, (char) 0};

/* XM_URI_SOURCE */
static EIF_TYPE_INDEX ptf104[] = {103,0xFFFF};
static struct eif_par_types par104 = {104, ptf104, (uint16) 1, (uint16) 0, (char) 0};

/* XM_DEFAULT_URI_SOURCE */
static EIF_TYPE_INDEX ptf105[] = {104,0xFFFF};
static struct eif_par_types par105 = {105, ptf105, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXPRESSIONS */
static EIF_TYPE_INDEX ptf106[] = {0,0xFFFF};
static struct eif_par_types par106 = {106, ptf106, (uint16) 1, (uint16) 0, (char) 0};

/* SYSTEM_ENCODINGS_I */
static EIF_TYPE_INDEX ptf107[] = {0,0xFFFF};
static struct eif_par_types par107 = {107, ptf107, (uint16) 1, (uint16) 0, (char) 0};

/* KL_CELL [G#1] */
static EIF_TYPE_INDEX ptf108[] = {0,0xFFFF};
static struct eif_par_types par108 = {108, ptf108, (uint16) 1, (uint16) 1, (char) 0};

/* KL_CELL [CHARACTER_8] */
static EIF_TYPE_INDEX ptf109[] = {0,0xFFFF};
static struct eif_par_types par109 = {109, ptf109, (uint16) 1, (uint16) 1, (char) 0};

/* KL_LINKABLE [G#1] */
static EIF_TYPE_INDEX ptf110[] = {108,0xFFF8,1,0xFFFF};
static struct eif_par_types par110 = {110, ptf110, (uint16) 1, (uint16) 1, (char) 0};

/* KL_LINKABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf111[] = {109,1126,0xFFFF};
static struct eif_par_types par111 = {111, ptf111, (uint16) 1, (uint16) 1, (char) 0};

/* RX_PCRE_SHARED_CHARACTER_SETS */
static EIF_TYPE_INDEX ptf112[] = {0,0xFFFF};
static struct eif_par_types par112 = {112, ptf112, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_OPTION_ROUTINES */
static EIF_TYPE_INDEX ptf113[] = {0,0xFFFF};
static struct eif_par_types par113 = {113, ptf113, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_ERROR_CONSTANTS */
static EIF_TYPE_INDEX ptf114[] = {0,0xFFFF};
static struct eif_par_types par114 = {114, ptf114, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_BYTE_CODE_CONSTANTS */
static EIF_TYPE_INDEX ptf115[] = {0,0xFFFF};
static struct eif_par_types par115 = {115, ptf115, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_EIFFEL_COMPILER */
static EIF_TYPE_INDEX ptf116[] = {0,0xFFFF};
static struct eif_par_types par116 = {116, ptf116, (uint16) 1, (uint16) 0, (char) 0};

/* DS_TOPOLOGICAL_SORTER [G#1] */
static EIF_TYPE_INDEX ptf117[] = {0,0xFFFF};
static struct eif_par_types par117 = {117, ptf117, (uint16) 1, (uint16) 1, (char) 0};

/* DS_HASH_TOPOLOGICAL_SORTER [G#1] */
static EIF_TYPE_INDEX ptf118[] = {117,0xFFF8,1,0xFFFF};
static struct eif_par_types par118 = {118, ptf118, (uint16) 1, (uint16) 1, (char) 0};

/* KL_IMPORTED_AGENT_ROUTINES */
static EIF_TYPE_INDEX ptf119[] = {0,0xFFFF};
static struct eif_par_types par119 = {119, ptf119, (uint16) 1, (uint16) 0, (char) 0};

/* ET_IMPORTED_AGENT_ROUTINES */
static EIF_TYPE_INDEX ptf120[] = {119,0xFFFF};
static struct eif_par_types par120 = {120, ptf120, (uint16) 1, (uint16) 0, (char) 0};

/* OBJECT_GRAPH_MARKER */
static EIF_TYPE_INDEX ptf121[] = {0,0xFFFF};
static struct eif_par_types par121 = {121, ptf121, (uint16) 1, (uint16) 0, (char) 0};

/* MATH_CONST */
static EIF_TYPE_INDEX ptf122[] = {0,0xFFFF};
static struct eif_par_types par122 = {122, ptf122, (uint16) 1, (uint16) 0, (char) 0};

/* DOUBLE_MATH */
static EIF_TYPE_INDEX ptf123[] = {122,0xFFFF};
static struct eif_par_types par123 = {123, ptf123, (uint16) 1, (uint16) 0, (char) 0};

/* KI_EXCEPTIONS */
static EIF_TYPE_INDEX ptf124[] = {0,0xFFFF};
static struct eif_par_types par124 = {124, ptf124, (uint16) 1, (uint16) 0, (char) 0};

/* KI_BUFFER [G#1] */
static EIF_TYPE_INDEX ptf125[] = {0,0xFFFF};
static struct eif_par_types par125 = {125, ptf125, (uint16) 1, (uint16) 1, (char) 0};

/* KI_BUFFER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf126[] = {0,0xFFFF};
static struct eif_par_types par126 = {126, ptf126, (uint16) 1, (uint16) 1, (char) 0};

/* KI_CHARACTER_BUFFER */
static EIF_TYPE_INDEX ptf127[] = {126,1126,0xFFFF};
static struct eif_par_types par127 = {127, ptf127, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SUPPLIER_HANDLER */
static EIF_TYPE_INDEX ptf128[] = {0,0xFFFF};
static struct eif_par_types par128 = {128, ptf128, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SHARED_CLASS_CODES */
static EIF_TYPE_INDEX ptf129[] = {0,0xFFFF};
static struct eif_par_types par129 = {129, ptf129, (uint16) 1, (uint16) 0, (char) 0};

/* ET_BREAK */
static EIF_TYPE_INDEX ptf130[] = {0,0xFFFF};
static struct eif_par_types par130 = {130, ptf130, (uint16) 1, (uint16) 0, (char) 0};

/* ET_COMMENT */
static EIF_TYPE_INDEX ptf131[] = {130,0xFFFF};
static struct eif_par_types par131 = {131, ptf131, (uint16) 1, (uint16) 0, (char) 0};

/* KL_HASH_FUNCTION [G#1] */
static EIF_TYPE_INDEX ptf132[] = {0,0xFFFF};
static struct eif_par_types par132 = {132, ptf132, (uint16) 1, (uint16) 1, (char) 0};

/* KL_HASH_FUNCTION [INTEGER_32] */
static EIF_TYPE_INDEX ptf133[] = {0,0xFFFF};
static struct eif_par_types par133 = {133, ptf133, (uint16) 1, (uint16) 1, (char) 0};

/* KL_HASH_FUNCTION [NATURAL_32] */
static EIF_TYPE_INDEX ptf134[] = {0,0xFFFF};
static struct eif_par_types par134 = {134, ptf134, (uint16) 1, (uint16) 1, (char) 0};

/* KL_HASH_FUNCTION [NATURAL_8] */
static EIF_TYPE_INDEX ptf135[] = {0,0xFFFF};
static struct eif_par_types par135 = {135, ptf135, (uint16) 1, (uint16) 1, (char) 0};

/* KL_AGENT_HASH_FUNCTION [G#1] */
static EIF_TYPE_INDEX ptf136[] = {132,0xFFF8,1,0xFFFF};
static struct eif_par_types par136 = {136, ptf136, (uint16) 1, (uint16) 1, (char) 0};

/* REFLECTOR_HELPER */
static EIF_TYPE_INDEX ptf137[] = {0,0xFFFF};
static struct eif_par_types par137 = {137, ptf137, (uint16) 1, (uint16) 0, (char) 0};

/* REFACTORING_HELPER */
static EIF_TYPE_INDEX ptf138[] = {0,0xFFFF};
static struct eif_par_types par138 = {138, ptf138, (uint16) 1, (uint16) 0, (char) 0};

/* KL_GOBO_VERSION */
static EIF_TYPE_INDEX ptf139[] = {0,0xFFFF};
static struct eif_par_types par139 = {139, ptf139, (uint16) 1, (uint16) 0, (char) 0};

/* GELINT_VERSION */
static EIF_TYPE_INDEX ptf140[] = {139,0xFFFF};
static struct eif_par_types par140 = {140, ptf140, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ADAPTED_CLASS */
static EIF_TYPE_INDEX ptf141[] = {0,0xFFFF};
static struct eif_par_types par141 = {141, ptf141, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DOTNET_ASSEMBLY_CONSUMER */
static EIF_TYPE_INDEX ptf142[] = {0,0xFFFF};
static struct eif_par_types par142 = {142, ptf142, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DOTNET_ASSEMBLY_CLASSIC_CONSUMER */
static EIF_TYPE_INDEX ptf143[] = {142,0xFFFF};
static struct eif_par_types par143 = {143, ptf143, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEPTION_MANAGER */
static EIF_TYPE_INDEX ptf144[] = {0,0xFFFF};
static struct eif_par_types par144 = {144, ptf144, (uint16) 1, (uint16) 0, (char) 0};

/* ISE_EXCEPTION_MANAGER */
static EIF_TYPE_INDEX ptf145[] = {144,0xFFFF};
static struct eif_par_types par145 = {145, ptf145, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEP_CONST */
static EIF_TYPE_INDEX ptf146[] = {0,0xFFFF};
static struct eif_par_types par146 = {146, ptf146, (uint16) 1, (uint16) 0, (char) 0};

/* CELL [G#1] */
static EIF_TYPE_INDEX ptf147[] = {0,0xFFFF};
static struct eif_par_types par147 = {147, ptf147, (uint16) 1, (uint16) 1, (char) 0};

/* CELL [INTEGER_32] */
static EIF_TYPE_INDEX ptf148[] = {0,0xFFFF};
static struct eif_par_types par148 = {148, ptf148, (uint16) 1, (uint16) 1, (char) 0};

/* CELL [CHARACTER_32] */
static EIF_TYPE_INDEX ptf149[] = {0,0xFFFF};
static struct eif_par_types par149 = {149, ptf149, (uint16) 1, (uint16) 1, (char) 0};

/* CELL [BOOLEAN] */
static EIF_TYPE_INDEX ptf150[] = {0,0xFFFF};
static struct eif_par_types par150 = {150, ptf150, (uint16) 1, (uint16) 1, (char) 0};

/* CELL [NATURAL_64] */
static EIF_TYPE_INDEX ptf151[] = {0,0xFFFF};
static struct eif_par_types par151 = {151, ptf151, (uint16) 1, (uint16) 1, (char) 0};

/* LINKABLE [G#1] */
static EIF_TYPE_INDEX ptf152[] = {147,0xFFF8,1,0xFFFF};
static struct eif_par_types par152 = {152, ptf152, (uint16) 1, (uint16) 1, (char) 0};

/* LINKABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf153[] = {148,1096,0xFFFF};
static struct eif_par_types par153 = {153, ptf153, (uint16) 1, (uint16) 1, (char) 0};

/* UT_SHARED_ECMA_VERSIONS */
static EIF_TYPE_INDEX ptf154[] = {0,0xFFFF};
static struct eif_par_types par154 = {154, ptf154, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SHARED_ISE_VARIABLES */
static EIF_TYPE_INDEX ptf155[] = {0,0xFFFF};
static struct eif_par_types par155 = {155, ptf155, (uint16) 1, (uint16) 0, (char) 0};

/* XM_UNICODE_CHARACTERS */
static EIF_TYPE_INDEX ptf156[] = {0,0xFFFF};
static struct eif_par_types par156 = {156, ptf156, (uint16) 1, (uint16) 0, (char) 0};

/* XM_UNICODE_CHARACTERS_1_1 */
static EIF_TYPE_INDEX ptf157[] = {156,0xFFFF};
static struct eif_par_types par157 = {157, ptf157, (uint16) 1, (uint16) 0, (char) 0};

/* XM_UNICODE_CHARACTERS_1_0 */
static EIF_TYPE_INDEX ptf158[] = {156,0xFFFF};
static struct eif_par_types par158 = {158, ptf158, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_CONDITION */
static EIF_TYPE_INDEX ptf159[] = {0,0xFFFF};
static struct eif_par_types par159 = {159, ptf159, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_CONDITIONS */
static EIF_TYPE_INDEX ptf160[] = {159,0xFFFF};
static struct eif_par_types par160 = {160, ptf160, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_ORED_CONDITIONS */
static EIF_TYPE_INDEX ptf161[] = {160,0xFFFF};
static struct eif_par_types par161 = {161, ptf161, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_ANDED_CONDITIONS */
static EIF_TYPE_INDEX ptf162[] = {160,0xFFFF};
static struct eif_par_types par162 = {162, ptf162, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_CONDITION_ITEM */
static EIF_TYPE_INDEX ptf163[] = {159,0xFFFF};
static struct eif_par_types par163 = {163, ptf163, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_DYNAMIC_RUNTIME_CONDITION */
static EIF_TYPE_INDEX ptf164[] = {163,0xFFFF};
static struct eif_par_types par164 = {164, ptf164, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_DOTNET_CONDITION */
static EIF_TYPE_INDEX ptf165[] = {163,0xFFFF};
static struct eif_par_types par165 = {165, ptf165, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_VERSION_CONDITION */
static EIF_TYPE_INDEX ptf166[] = {163,0xFFFF};
static struct eif_par_types par166 = {166, ptf166, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_MSIL_CLR_VERSION_CONDITION */
static EIF_TYPE_INDEX ptf167[] = {166,0xFFFF};
static struct eif_par_types par167 = {167, ptf167, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_COMPILER_VERSION_CONDITION */
static EIF_TYPE_INDEX ptf168[] = {166,0xFFFF};
static struct eif_par_types par168 = {168, ptf168, (uint16) 1, (uint16) 0, (char) 0};

/* XM_DTD_CALLBACKS */
static EIF_TYPE_INDEX ptf169[] = {0,0xFFFF};
static struct eif_par_types par169 = {169, ptf169, (uint16) 1, (uint16) 0, (char) 0};

/* XM_DTD_CALLBACKS_NULL */
static EIF_TYPE_INDEX ptf170[] = {169,0xFFFF};
static struct eif_par_types par170 = {170, ptf170, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EIFFEL_PARSER_ERRORS */
static EIF_TYPE_INDEX ptf171[] = {0,0xFFFF};
static struct eif_par_types par171 = {171, ptf171, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_BOOLEAN_ROUTINES */
static EIF_TYPE_INDEX ptf172[] = {0,0xFFFF};
static struct eif_par_types par172 = {172, ptf172, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_VALUES */
static EIF_TYPE_INDEX ptf173[] = {0,0xFFFF};
static struct eif_par_types par173 = {173, ptf173, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_FLAGS */
static EIF_TYPE_INDEX ptf174[] = {173,0xFFFF};
static struct eif_par_types par174 = {174, ptf174, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_LINKER_FLAGS */
static EIF_TYPE_INDEX ptf175[] = {174,0xFFFF};
static struct eif_par_types par175 = {175, ptf175, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_CFLAGS */
static EIF_TYPE_INDEX ptf176[] = {174,0xFFFF};
static struct eif_par_types par176 = {176, ptf176, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_PATHNAMES */
static EIF_TYPE_INDEX ptf177[] = {173,0xFFFF};
static struct eif_par_types par177 = {177, ptf177, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_MAKES */
static EIF_TYPE_INDEX ptf178[] = {177,0xFFFF};
static struct eif_par_types par178 = {178, ptf178, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_RESOURCES */
static EIF_TYPE_INDEX ptf179[] = {177,0xFFFF};
static struct eif_par_types par179 = {179, ptf179, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_LIBRARIES */
static EIF_TYPE_INDEX ptf180[] = {177,0xFFFF};
static struct eif_par_types par180 = {180, ptf180, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_OBJECTS */
static EIF_TYPE_INDEX ptf181[] = {177,0xFFFF};
static struct eif_par_types par181 = {181, ptf181, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_INCLUDES */
static EIF_TYPE_INDEX ptf182[] = {177,0xFFFF};
static struct eif_par_types par182 = {182, ptf182, (uint16) 1, (uint16) 0, (char) 0};

/* ENCODING_HELPER */
static EIF_TYPE_INDEX ptf183[] = {0,0xFFFF};
static struct eif_par_types par183 = {183, ptf183, (uint16) 1, (uint16) 0, (char) 0};

/* SYSTEM_ENCODINGS_IMP */
static EIF_TYPE_INDEX ptf184[] = {107,0xFFFF};
static struct eif_par_types par184 = {184, ptf184, (uint16) 1, (uint16) 0, (char) 0};

/* KI_FILE_SYSTEM_ENTRY */
static EIF_TYPE_INDEX ptf185[] = {0,0xFFFF};
static struct eif_par_types par185 = {185, ptf185, (uint16) 1, (uint16) 0, (char) 0};

/* KI_FILE */
static EIF_TYPE_INDEX ptf186[] = {185,0xFFFF};
static struct eif_par_types par186 = {186, ptf186, (uint16) 1, (uint16) 0, (char) 0};

/* XM_NODE_PROCESSOR */
static EIF_TYPE_INDEX ptf187[] = {0,0xFFFF};
static struct eif_par_types par187 = {187, ptf187, (uint16) 1, (uint16) 0, (char) 0};

/* XM_TREE_TO_EVENTS */
static EIF_TYPE_INDEX ptf188[] = {187,0xFFFF};
static struct eif_par_types par188 = {188, ptf188, (uint16) 1, (uint16) 0, (char) 0};

/* XM_NODE_TYPER */
static EIF_TYPE_INDEX ptf189[] = {187,0xFFFF};
static struct eif_par_types par189 = {189, ptf189, (uint16) 1, (uint16) 0, (char) 0};

/* XM_DTD_CALLBACKS_SOURCE */
static EIF_TYPE_INDEX ptf190[] = {0,0xFFFF};
static struct eif_par_types par190 = {190, ptf190, (uint16) 1, (uint16) 0, (char) 0};

/* XM_FORWARD_DTD_CALLBACKS */
static EIF_TYPE_INDEX ptf191[] = {190,0xFFF7,169,0xFFFF};
static struct eif_par_types par191 = {191, ptf191, (uint16) 2, (uint16) 0, (char) 0};

/* ET_SHARED_STANDARD_ONCE_KEYS */
static EIF_TYPE_INDEX ptf192[] = {0,0xFFFF};
static struct eif_par_types par192 = {192, ptf192, (uint16) 1, (uint16) 0, (char) 0};

/* UC_IMPORTED_UTF32_ROUTINES */
static EIF_TYPE_INDEX ptf193[] = {0,0xFFFF};
static struct eif_par_types par193 = {193, ptf193, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_CHARACTER_ROUTINES */
static EIF_TYPE_INDEX ptf194[] = {0,0xFFFF};
static struct eif_par_types par194 = {194, ptf194, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_STREAMS */
static EIF_TYPE_INDEX ptf195[] = {0,0xFFFF};
static struct eif_par_types par195 = {195, ptf195, (uint16) 1, (uint16) 0, (char) 0};

/* THREAD_ENVIRONMENT */
static EIF_TYPE_INDEX ptf196[] = {0,0xFFFF};
static struct eif_par_types par196 = {196, ptf196, (uint16) 1, (uint16) 0, (char) 0};

/* THREAD_CONTROL */
static EIF_TYPE_INDEX ptf197[] = {196,0xFFFF};
static struct eif_par_types par197 = {197, ptf197, (uint16) 1, (uint16) 0, (char) 0};

/* THREAD */
static EIF_TYPE_INDEX ptf198[] = {197,0xFFFF};
static struct eif_par_types par198 = {198, ptf198, (uint16) 1, (uint16) 0, (char) 0};

/* WORKER_THREAD */
static EIF_TYPE_INDEX ptf199[] = {198,0xFFFF};
static struct eif_par_types par199 = {199, ptf199, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_CONFIG */
static EIF_TYPE_INDEX ptf200[] = {0,0xFFFF};
static struct eif_par_types par200 = {200, ptf200, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_REDIRECTION_CONFIG */
static EIF_TYPE_INDEX ptf201[] = {200,0xFFFF};
static struct eif_par_types par201 = {201, ptf201, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_SYSTEM_CONFIG */
static EIF_TYPE_INDEX ptf202[] = {200,0xFFFF};
static struct eif_par_types par202 = {202, ptf202, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_ELEMENT_NAMES */
static EIF_TYPE_INDEX ptf203[] = {0,0xFFFF};
static struct eif_par_types par203 = {203, ptf203, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_ROOT */
static EIF_TYPE_INDEX ptf204[] = {0,0xFFFF};
static struct eif_par_types par204 = {204, ptf204, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_ROOT_ALL_CLASSES */
static EIF_TYPE_INDEX ptf205[] = {204,0xFFFF};
static struct eif_par_types par205 = {205, ptf205, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_ROOT_CLASS */
static EIF_TYPE_INDEX ptf206[] = {204,0xFFFF};
static struct eif_par_types par206 = {206, ptf206, (uint16) 1, (uint16) 0, (char) 0};

/* KL_VALUES [G#1, G#2] */
static EIF_TYPE_INDEX ptf207[] = {0,0xFFFF};
static struct eif_par_types par207 = {207, ptf207, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf208[] = {0,0xFFFF};
static struct eif_par_types par208 = {208, ptf208, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf209[] = {0,0xFFFF};
static struct eif_par_types par209 = {209, ptf209, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf210[] = {0,0xFFFF};
static struct eif_par_types par210 = {210, ptf210, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf211[] = {0,0xFFFF};
static struct eif_par_types par211 = {211, ptf211, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf212[] = {0,0xFFFF};
static struct eif_par_types par212 = {212, ptf212, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf213[] = {0,0xFFFF};
static struct eif_par_types par213 = {213, ptf213, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf214[] = {0,0xFFFF};
static struct eif_par_types par214 = {214, ptf214, (uint16) 1, (uint16) 2, (char) 0};

/* UT_CHARACTER_32_CODES */
static EIF_TYPE_INDEX ptf215[] = {0,0xFFFF};
static struct eif_par_types par215 = {215, ptf215, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SHARED_ALIAS_NAME_TESTER */
static EIF_TYPE_INDEX ptf216[] = {0,0xFFFF};
static struct eif_par_types par216 = {216, ptf216, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ARGUMENT_OPERANDS */
static EIF_TYPE_INDEX ptf217[] = {0,0xFFFF};
static struct eif_par_types par217 = {217, ptf217, (uint16) 1, (uint16) 0, (char) 0};

/* ET_AGENT_ARGUMENT_OPERANDS */
static EIF_TYPE_INDEX ptf218[] = {217,0xFFFF};
static struct eif_par_types par218 = {218, ptf218, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ACTUAL_ARGUMENTS */
static EIF_TYPE_INDEX ptf219[] = {217,0xFFF7,106,0xFFFF};
static struct eif_par_types par219 = {219, ptf219, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DYNAMIC_PRIMARY_TYPES */
static EIF_TYPE_INDEX ptf220[] = {0,0xFFFF};
static struct eif_par_types par220 = {220, ptf220, (uint16) 1, (uint16) 0, (char) 0};

/* AP_CONSTANTS */
static EIF_TYPE_INDEX ptf221[] = {0,0xFFFF};
static struct eif_par_types par221 = {221, ptf221, (uint16) 1, (uint16) 0, (char) 0};

/* AP_OPTION */
static EIF_TYPE_INDEX ptf222[] = {221,0xFFFF};
static struct eif_par_types par222 = {222, ptf222, (uint16) 1, (uint16) 0, (char) 0};

/* AP_FLAG */
static EIF_TYPE_INDEX ptf223[] = {222,0xFFFF};
static struct eif_par_types par223 = {223, ptf223, (uint16) 1, (uint16) 0, (char) 0};

/* AP_OPTION_WITH_PARAMETER [G#1] */
static EIF_TYPE_INDEX ptf224[] = {222,0xFFFF};
static struct eif_par_types par224 = {224, ptf224, (uint16) 1, (uint16) 1, (char) 0};

/* AP_OPTION_WITH_PARAMETER [INTEGER_32] */
static EIF_TYPE_INDEX ptf225[] = {222,0xFFFF};
static struct eif_par_types par225 = {225, ptf225, (uint16) 1, (uint16) 1, (char) 0};

/* AP_INTEGER_OPTION */
static EIF_TYPE_INDEX ptf226[] = {225,1096,0xFFFF};
static struct eif_par_types par226 = {226, ptf226, (uint16) 1, (uint16) 0, (char) 0};

/* AP_STRING_OPTION */
static EIF_TYPE_INDEX ptf227[] = {224,0xFF01,1189,0xFFFF};
static struct eif_par_types par227 = {227, ptf227, (uint16) 1, (uint16) 0, (char) 0};

/* RT_EXTENSION_COMMON */
static EIF_TYPE_INDEX ptf228[] = {0,0xFFFF};
static struct eif_par_types par228 = {228, ptf228, (uint16) 1, (uint16) 0, (char) 0};

/* RT_EXTENSION_GENERAL */
static EIF_TYPE_INDEX ptf229[] = {228,0xFFFF};
static struct eif_par_types par229 = {229, ptf229, (uint16) 1, (uint16) 0, (char) 0};

/* RT_EXTENSION */
static EIF_TYPE_INDEX ptf230[] = {229,0xFFFF};
static struct eif_par_types par230 = {230, ptf230, (uint16) 1, (uint16) 0, (char) 0};

/* RT_DBG_COMMON */
static EIF_TYPE_INDEX ptf231[] = {228,0xFFFF};
static struct eif_par_types par231 = {231, ptf231, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_SEARCHER */
static EIF_TYPE_INDEX ptf232[] = {0,0xFFFF};
static struct eif_par_types par232 = {232, ptf232, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_32_SEARCHER */
static EIF_TYPE_INDEX ptf233[] = {232,0xFFFF};
static struct eif_par_types par233 = {233, ptf233, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_8_SEARCHER */
static EIF_TYPE_INDEX ptf234[] = {232,0xFFFF};
static struct eif_par_types par234 = {234, ptf234, (uint16) 1, (uint16) 0, (char) 0};

/* NUMERIC_INFORMATION */
static EIF_TYPE_INDEX ptf235[] = {0,0xFFFF};
static struct eif_par_types par235 = {235, ptf235, (uint16) 1, (uint16) 0, (char) 0};

/* INTEGER_OVERFLOW_CHECKER */
static EIF_TYPE_INDEX ptf236[] = {235,0xFFFF};
static struct eif_par_types par236 = {236, ptf236, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_TO_NUMERIC_CONVERTOR */
static EIF_TYPE_INDEX ptf237[] = {235,0xFFFF};
static struct eif_par_types par237 = {237, ptf237, (uint16) 1, (uint16) 0, (char) 0};

/* HEXADECIMAL_STRING_TO_INTEGER_CONVERTER */
static EIF_TYPE_INDEX ptf238[] = {237,0xFFFF};
static struct eif_par_types par238 = {238, ptf238, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_TO_REAL_CONVERTOR */
static EIF_TYPE_INDEX ptf239[] = {237,0xFFFF};
static struct eif_par_types par239 = {239, ptf239, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_TO_INTEGER_CONVERTOR */
static EIF_TYPE_INDEX ptf240[] = {237,0xFFFF};
static struct eif_par_types par240 = {240, ptf240, (uint16) 1, (uint16) 0, (char) 0};

/* DS_CELL [G#1] */
static EIF_TYPE_INDEX ptf241[] = {0,0xFFFF};
static struct eif_par_types par241 = {241, ptf241, (uint16) 1, (uint16) 1, (char) 0};

/* DS_CELL [INTEGER_32] */
static EIF_TYPE_INDEX ptf242[] = {0,0xFFFF};
static struct eif_par_types par242 = {242, ptf242, (uint16) 1, (uint16) 1, (char) 0};

/* DS_CELL [CHARACTER_8] */
static EIF_TYPE_INDEX ptf243[] = {0,0xFFFF};
static struct eif_par_types par243 = {243, ptf243, (uint16) 1, (uint16) 1, (char) 0};

/* DS_PAIR [G#1, G#2] */
static EIF_TYPE_INDEX ptf244[] = {241,0xFFF8,1,0xFFFF};
static struct eif_par_types par244 = {244, ptf244, (uint16) 1, (uint16) 2, (char) 0};

/* DS_PAIR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf245[] = {242,1096,0xFFFF};
static struct eif_par_types par245 = {245, ptf245, (uint16) 1, (uint16) 2, (char) 0};

/* DS_LINKABLE [G#1] */
static EIF_TYPE_INDEX ptf246[] = {241,0xFFF8,1,0xFFFF};
static struct eif_par_types par246 = {246, ptf246, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf247[] = {242,1096,0xFFFF};
static struct eif_par_types par247 = {247, ptf247, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf248[] = {243,1126,0xFFFF};
static struct eif_par_types par248 = {248, ptf248, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINKABLE [G#1] */
static EIF_TYPE_INDEX ptf249[] = {246,0xFFF8,1,0xFFFF};
static struct eif_par_types par249 = {249, ptf249, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINKABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf250[] = {247,1096,0xFFFF};
static struct eif_par_types par250 = {250, ptf250, (uint16) 1, (uint16) 1, (char) 0};

/* KI_INPUT_STREAM [G#1] */
static EIF_TYPE_INDEX ptf251[] = {0,0xFFFF};
static struct eif_par_types par251 = {251, ptf251, (uint16) 1, (uint16) 1, (char) 0};

/* KI_INPUT_STREAM [CHARACTER_8] */
static EIF_TYPE_INDEX ptf252[] = {0,0xFFFF};
static struct eif_par_types par252 = {252, ptf252, (uint16) 1, (uint16) 1, (char) 0};

/* ET_AST_PROCESSOR */
static EIF_TYPE_INDEX ptf253[] = {0,0xFFFF};
static struct eif_par_types par253 = {253, ptf253, (uint16) 1, (uint16) 0, (char) 0};

/* ET_AST_NULL_PROCESSOR */
static EIF_TYPE_INDEX ptf254[] = {253,0xFFFF};
static struct eif_par_types par254 = {254, ptf254, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ATTACHMENT_SCOPE_BUILDER */
static EIF_TYPE_INDEX ptf255[] = {254,0xFFFF};
static struct eif_par_types par255 = {255, ptf255, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLASS_TYPE_STATUS_CHECKER3 */
static EIF_TYPE_INDEX ptf256[] = {254,0xFFFF};
static struct eif_par_types par256 = {256, ptf256, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLASS_TYPE_STATUS_CHECKER2 */
static EIF_TYPE_INDEX ptf257[] = {254,0xFFFF};
static struct eif_par_types par257 = {257, ptf257, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLASS_TYPE_STATUS_CHECKER1 */
static EIF_TYPE_INDEX ptf258[] = {254,0xFFFF};
static struct eif_par_types par258 = {258, ptf258, (uint16) 1, (uint16) 0, (char) 0};

/* PART_COMPARABLE */
static EIF_TYPE_INDEX ptf259[] = {0,0xFFFF};
static struct eif_par_types par259 = {259, ptf259, (uint16) 1, (uint16) 0, (char) 0};

/* COMPARABLE */
static EIF_TYPE_INDEX ptf260[] = {259,0xFFFF};
static struct eif_par_types par260 = {260, ptf260, (uint16) 1, (uint16) 0, (char) 0};

/* KL_COMPARABLE */
static EIF_TYPE_INDEX ptf261[] = {260,0xFFFF};
static struct eif_par_types par261 = {261, ptf261, (uint16) 1, (uint16) 0, (char) 0};

/* LX_RULE */
static EIF_TYPE_INDEX ptf262[] = {261,0xFFFF};
static struct eif_par_types par262 = {262, ptf262, (uint16) 1, (uint16) 0, (char) 0};

/* PLATFORM */
static EIF_TYPE_INDEX ptf263[] = {0,0xFFFF};
static struct eif_par_types par263 = {263, ptf263, (uint16) 1, (uint16) 0, (char) 0};

/* KL_PLATFORM */
static EIF_TYPE_INDEX ptf264[] = {72,0xFFF7,263,0xFFFF};
static struct eif_par_types par264 = {264, ptf264, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DYNAMIC_TYPE_SET_BUILDER */
static EIF_TYPE_INDEX ptf265[] = {0,0xFFFF};
static struct eif_par_types par265 = {265, ptf265, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_NULL_TYPE_SET_BUILDER */
static EIF_TYPE_INDEX ptf266[] = {265,0xFFFF};
static struct eif_par_types par266 = {266, ptf266, (uint16) 1, (uint16) 0, (char) 0};

/* YY_BUFFER */
static EIF_TYPE_INDEX ptf267[] = {0,0xFFFF};
static struct eif_par_types par267 = {267, ptf267, (uint16) 1, (uint16) 0, (char) 0};

/* YY_UTF8_BUFFER */
static EIF_TYPE_INDEX ptf268[] = {267,0xFFFF};
static struct eif_par_types par268 = {268, ptf268, (uint16) 1, (uint16) 0, (char) 0};

/* YY_UNICODE_BUFFER */
static EIF_TYPE_INDEX ptf269[] = {267,0xFFFF};
static struct eif_par_types par269 = {269, ptf269, (uint16) 1, (uint16) 0, (char) 0};

/* YY_FILE_BUFFER */
static EIF_TYPE_INDEX ptf270[] = {267,0xFFF7,195,0xFFFF};
static struct eif_par_types par270 = {270, ptf270, (uint16) 2, (uint16) 0, (char) 0};

/* YY_UTF8_FILE_BUFFER */
static EIF_TYPE_INDEX ptf271[] = {270,0xFFF7,268,0xFFFF};
static struct eif_par_types par271 = {271, ptf271, (uint16) 2, (uint16) 0, (char) 0};

/* YY_UNICODE_FILE_BUFFER */
static EIF_TYPE_INDEX ptf272[] = {269,0xFFF7,270,0xFFFF};
static struct eif_par_types par272 = {272, ptf272, (uint16) 2, (uint16) 0, (char) 0};

/* XM_CALLBACKS_SOURCE */
static EIF_TYPE_INDEX ptf273[] = {0,0xFFFF};
static struct eif_par_types par273 = {273, ptf273, (uint16) 1, (uint16) 0, (char) 0};

/* XM_CALLBACKS */
static EIF_TYPE_INDEX ptf274[] = {0,0xFFFF};
static struct eif_par_types par274 = {274, ptf274, (uint16) 1, (uint16) 0, (char) 0};

/* XM_CALLBACKS_NULL */
static EIF_TYPE_INDEX ptf275[] = {274,0xFFFF};
static struct eif_par_types par275 = {275, ptf275, (uint16) 1, (uint16) 0, (char) 0};

/* XM_FORWARD_CALLBACKS */
static EIF_TYPE_INDEX ptf276[] = {273,0xFFF7,274,0xFFFF};
static struct eif_par_types par276 = {276, ptf276, (uint16) 2, (uint16) 0, (char) 0};

/* XM_CALLBACKS_FILTER */
static EIF_TYPE_INDEX ptf277[] = {274,0xFFF7,273,0xFFF7,276,0xFFFF};
static struct eif_par_types par277 = {277, ptf277, (uint16) 3, (uint16) 0, (char) 0};

/* XM_CALLBACKS_TO_TREE_FILTER */
static EIF_TYPE_INDEX ptf278[] = {277,0xFFFF};
static struct eif_par_types par278 = {278, ptf278, (uint16) 1, (uint16) 0, (char) 0};

/* XM_STOP_ON_ERROR_FILTER */
static EIF_TYPE_INDEX ptf279[] = {277,0xFFFF};
static struct eif_par_types par279 = {279, ptf279, (uint16) 1, (uint16) 0, (char) 0};

/* XM_PARSER_STOP_ON_ERROR_FILTER */
static EIF_TYPE_INDEX ptf280[] = {279,0xFFFF};
static struct eif_par_types par280 = {280, ptf280, (uint16) 1, (uint16) 0, (char) 0};

/* UT_CHARACTER_CODES */
static EIF_TYPE_INDEX ptf281[] = {0,0xFFFF};
static struct eif_par_types par281 = {281, ptf281, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLOSURE */
static EIF_TYPE_INDEX ptf282[] = {0,0xFFFF};
static struct eif_par_types par282 = {282, ptf282, (uint16) 1, (uint16) 0, (char) 0};

/* ET_NESTED_CLOSURE */
static EIF_TYPE_INDEX ptf283[] = {282,0xFFFF};
static struct eif_par_types par283 = {283, ptf283, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FEATURE_CLOSURE */
static EIF_TYPE_INDEX ptf284[] = {282,0xFFFF};
static struct eif_par_types par284 = {284, ptf284, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXTENDED_ATTRIBUTE_CLOSURE */
static EIF_TYPE_INDEX ptf285[] = {284,0xFFFF};
static struct eif_par_types par285 = {285, ptf285, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ROUTINE_CLOSURE */
static EIF_TYPE_INDEX ptf286[] = {284,0xFFFF};
static struct eif_par_types par286 = {286, ptf286, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXTERNAL_ROUTINE_CLOSURE */
static EIF_TYPE_INDEX ptf287[] = {286,0xFFFF};
static struct eif_par_types par287 = {287, ptf287, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INTERNAL_ROUTINE_CLOSURE */
static EIF_TYPE_INDEX ptf288[] = {286,0xFFFF};
static struct eif_par_types par288 = {288, ptf288, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ADAPTED_GROUP */
static EIF_TYPE_INDEX ptf289[] = {0,0xFFFF};
static struct eif_par_types par289 = {289, ptf289, (uint16) 1, (uint16) 0, (char) 0};

/* DT_DATE_HANDLER */
static EIF_TYPE_INDEX ptf290[] = {0,0xFFFF};
static struct eif_par_types par290 = {290, ptf290, (uint16) 1, (uint16) 0, (char) 0};

/* DT_SHARED_WEEK_DAYS_FROM_MONDAY */
static EIF_TYPE_INDEX ptf291[] = {0,0xFFFF};
static struct eif_par_types par291 = {291, ptf291, (uint16) 1, (uint16) 0, (char) 0};

/* DT_TIME_HANDLER */
static EIF_TYPE_INDEX ptf292[] = {0,0xFFFF};
static struct eif_par_types par292 = {292, ptf292, (uint16) 1, (uint16) 0, (char) 0};

/* DT_DATE_TIME_HANDLER */
static EIF_TYPE_INDEX ptf293[] = {290,0xFFF7,292,0xFFFF};
static struct eif_par_types par293 = {293, ptf293, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CONSTRAINT_ACTUAL_PARAMETER_ITEM */
static EIF_TYPE_INDEX ptf294[] = {0,0xFFFF};
static struct eif_par_types par294 = {294, ptf294, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONSTRAINT_ACTUAL_PARAMETER_COMMA */
static EIF_TYPE_INDEX ptf295[] = {294,0xFFFF};
static struct eif_par_types par295 = {295, ptf295, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONSTRAINT_LABELED_ACTUAL_PARAMETER_SEMICOLON */
static EIF_TYPE_INDEX ptf296[] = {294,0xFFFF};
static struct eif_par_types par296 = {296, ptf296, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONSTRAINT_ACTUAL_PARAMETER */
static EIF_TYPE_INDEX ptf297[] = {294,0xFFFF};
static struct eif_par_types par297 = {297, ptf297, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONSTRAINT_LABELED_COMMA_ACTUAL_PARAMETER */
static EIF_TYPE_INDEX ptf298[] = {297,0xFFFF};
static struct eif_par_types par298 = {298, ptf298, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONSTRAINT_LABELED_ACTUAL_PARAMETER */
static EIF_TYPE_INDEX ptf299[] = {297,0xFFFF};
static struct eif_par_types par299 = {299, ptf299, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONSTRAINT_TYPE */
static EIF_TYPE_INDEX ptf300[] = {297,0xFFFF};
static struct eif_par_types par300 = {300, ptf300, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONSTRAINT_NAMED_TYPE */
static EIF_TYPE_INDEX ptf301[] = {300,0xFFFF};
static struct eif_par_types par301 = {301, ptf301, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONSTRAINT_GENERIC_NAMED_TYPE */
static EIF_TYPE_INDEX ptf302[] = {301,0xFFFF};
static struct eif_par_types par302 = {302, ptf302, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ADAPTED_UNIVERSE */
static EIF_TYPE_INDEX ptf303[] = {0,0xFFFF};
static struct eif_par_types par303 = {303, ptf303, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ADAPTED_LIBRARY */
static EIF_TYPE_INDEX ptf304[] = {303,0xFFF7,289,0xFFFF};
static struct eif_par_types par304 = {304, ptf304, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ADAPTED_DOTNET_ASSEMBLY */
static EIF_TYPE_INDEX ptf305[] = {303,0xFFF7,289,0xFFFF};
static struct eif_par_types par305 = {305, ptf305, (uint16) 2, (uint16) 0, (char) 0};

/* CURSOR */
static EIF_TYPE_INDEX ptf306[] = {0,0xFFFF};
static struct eif_par_types par306 = {306, ptf306, (uint16) 1, (uint16) 0, (char) 0};

/* LINKED_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf307[] = {306,0xFFFF};
static struct eif_par_types par307 = {307, ptf307, (uint16) 1, (uint16) 1, (char) 0};

/* LINKED_LIST_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf308[] = {306,0xFFFF};
static struct eif_par_types par308 = {308, ptf308, (uint16) 1, (uint16) 1, (char) 0};

/* HASH_TABLE_CURSOR */
static EIF_TYPE_INDEX ptf309[] = {306,0xFFFF};
static struct eif_par_types par309 = {309, ptf309, (uint16) 1, (uint16) 0, (char) 0};

/* ARRAYED_LIST_CURSOR */
static EIF_TYPE_INDEX ptf310[] = {306,0xFFFF};
static struct eif_par_types par310 = {310, ptf310, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEPTION_MANAGER_FACTORY */
static EIF_TYPE_INDEX ptf311[] = {0,0xFFFF};
static struct eif_par_types par311 = {311, ptf311, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEPTIONS */
static EIF_TYPE_INDEX ptf312[] = {146,0xFFF7,311,0xFFFF};
static struct eif_par_types par312 = {312, ptf312, (uint16) 2, (uint16) 0, (char) 0};

/* KL_EXCEPTIONS */
static EIF_TYPE_INDEX ptf313[] = {124,0xFFF7,312,0xFFFF};
static struct eif_par_types par313 = {313, ptf313, (uint16) 2, (uint16) 0, (char) 0};

/* EXCEPTION */
static EIF_TYPE_INDEX ptf314[] = {311,0xFFFF};
static struct eif_par_types par314 = {314, ptf314, (uint16) 1, (uint16) 0, (char) 0};

/* DEVELOPER_EXCEPTION */
static EIF_TYPE_INDEX ptf315[] = {314,0xFFFF};
static struct eif_par_types par315 = {315, ptf315, (uint16) 1, (uint16) 0, (char) 0};

/* CONVERSION_FAILURE */
static EIF_TYPE_INDEX ptf316[] = {315,0xFFFF};
static struct eif_par_types par316 = {316, ptf316, (uint16) 1, (uint16) 0, (char) 0};

/* MACHINE_EXCEPTION */
static EIF_TYPE_INDEX ptf317[] = {314,0xFFFF};
static struct eif_par_types par317 = {317, ptf317, (uint16) 1, (uint16) 0, (char) 0};

/* HARDWARE_EXCEPTION */
static EIF_TYPE_INDEX ptf318[] = {317,0xFFFF};
static struct eif_par_types par318 = {318, ptf318, (uint16) 1, (uint16) 0, (char) 0};

/* FLOATING_POINT_FAILURE */
static EIF_TYPE_INDEX ptf319[] = {318,0xFFFF};
static struct eif_par_types par319 = {319, ptf319, (uint16) 1, (uint16) 0, (char) 0};

/* OPERATING_SYSTEM_EXCEPTION */
static EIF_TYPE_INDEX ptf320[] = {317,0xFFFF};
static struct eif_par_types par320 = {320, ptf320, (uint16) 1, (uint16) 0, (char) 0};

/* COM_FAILURE */
static EIF_TYPE_INDEX ptf321[] = {320,0xFFFF};
static struct eif_par_types par321 = {321, ptf321, (uint16) 1, (uint16) 0, (char) 0};

/* OPERATING_SYSTEM_FAILURE */
static EIF_TYPE_INDEX ptf322[] = {320,0xFFFF};
static struct eif_par_types par322 = {322, ptf322, (uint16) 1, (uint16) 0, (char) 0};

/* OPERATING_SYSTEM_SIGNAL_FAILURE */
static EIF_TYPE_INDEX ptf323[] = {320,0xFFFF};
static struct eif_par_types par323 = {323, ptf323, (uint16) 1, (uint16) 0, (char) 0};

/* OBSOLETE_EXCEPTION */
static EIF_TYPE_INDEX ptf324[] = {314,0xFFFF};
static struct eif_par_types par324 = {324, ptf324, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEPTION_IN_SIGNAL_HANDLER_FAILURE */
static EIF_TYPE_INDEX ptf325[] = {324,0xFFFF};
static struct eif_par_types par325 = {325, ptf325, (uint16) 1, (uint16) 0, (char) 0};

/* RESUMPTION_FAILURE */
static EIF_TYPE_INDEX ptf326[] = {324,0xFFFF};
static struct eif_par_types par326 = {326, ptf326, (uint16) 1, (uint16) 0, (char) 0};

/* RESCUE_FAILURE */
static EIF_TYPE_INDEX ptf327[] = {324,0xFFFF};
static struct eif_par_types par327 = {327, ptf327, (uint16) 1, (uint16) 0, (char) 0};

/* SYS_EXCEPTION */
static EIF_TYPE_INDEX ptf328[] = {314,0xFFFF};
static struct eif_par_types par328 = {328, ptf328, (uint16) 1, (uint16) 0, (char) 0};

/* OLD_VIOLATION */
static EIF_TYPE_INDEX ptf329[] = {328,0xFFFF};
static struct eif_par_types par329 = {329, ptf329, (uint16) 1, (uint16) 0, (char) 0};

/* EIFFEL_RUNTIME_PANIC */
static EIF_TYPE_INDEX ptf330[] = {328,0xFFFF};
static struct eif_par_types par330 = {330, ptf330, (uint16) 1, (uint16) 0, (char) 0};

/* EIF_EXCEPTION */
static EIF_TYPE_INDEX ptf331[] = {328,0xFFFF};
static struct eif_par_types par331 = {331, ptf331, (uint16) 1, (uint16) 0, (char) 0};

/* EIFFEL_RUNTIME_EXCEPTION */
static EIF_TYPE_INDEX ptf332[] = {331,0xFFFF};
static struct eif_par_types par332 = {332, ptf332, (uint16) 1, (uint16) 0, (char) 0};

/* NO_MORE_MEMORY */
static EIF_TYPE_INDEX ptf333[] = {332,0xFFFF};
static struct eif_par_types par333 = {333, ptf333, (uint16) 1, (uint16) 0, (char) 0};

/* EXTERNAL_FAILURE */
static EIF_TYPE_INDEX ptf334[] = {332,0xFFFF};
static struct eif_par_types par334 = {334, ptf334, (uint16) 1, (uint16) 0, (char) 0};

/* DATA_EXCEPTION */
static EIF_TYPE_INDEX ptf335[] = {332,0xFFFF};
static struct eif_par_types par335 = {335, ptf335, (uint16) 1, (uint16) 0, (char) 0};

/* MISMATCH_FAILURE */
static EIF_TYPE_INDEX ptf336[] = {335,0xFFFF};
static struct eif_par_types par336 = {336, ptf336, (uint16) 1, (uint16) 0, (char) 0};

/* IO_FAILURE */
static EIF_TYPE_INDEX ptf337[] = {335,0xFFFF};
static struct eif_par_types par337 = {337, ptf337, (uint16) 1, (uint16) 0, (char) 0};

/* SERIALIZATION_FAILURE */
static EIF_TYPE_INDEX ptf338[] = {335,0xFFFF};
static struct eif_par_types par338 = {338, ptf338, (uint16) 1, (uint16) 0, (char) 0};

/* LANGUAGE_EXCEPTION */
static EIF_TYPE_INDEX ptf339[] = {331,0xFFFF};
static struct eif_par_types par339 = {339, ptf339, (uint16) 1, (uint16) 0, (char) 0};

/* BAD_INSPECT_VALUE */
static EIF_TYPE_INDEX ptf340[] = {339,0xFFFF};
static struct eif_par_types par340 = {340, ptf340, (uint16) 1, (uint16) 0, (char) 0};

/* ROUTINE_FAILURE */
static EIF_TYPE_INDEX ptf341[] = {339,0xFFFF};
static struct eif_par_types par341 = {341, ptf341, (uint16) 1, (uint16) 0, (char) 0};

/* VOID_TARGET */
static EIF_TYPE_INDEX ptf342[] = {339,0xFFFF};
static struct eif_par_types par342 = {342, ptf342, (uint16) 1, (uint16) 0, (char) 0};

/* VOID_ASSIGNED_TO_EXPANDED */
static EIF_TYPE_INDEX ptf343[] = {339,0xFFFF};
static struct eif_par_types par343 = {343, ptf343, (uint16) 1, (uint16) 0, (char) 0};

/* EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION */
static EIF_TYPE_INDEX ptf344[] = {339,0xFFFF};
static struct eif_par_types par344 = {344, ptf344, (uint16) 1, (uint16) 0, (char) 0};

/* ADDRESS_APPLIED_TO_MELTED_FEATURE */
static EIF_TYPE_INDEX ptf345[] = {344,0xFFFF};
static struct eif_par_types par345 = {345, ptf345, (uint16) 1, (uint16) 0, (char) 0};

/* CREATE_ON_DEFERRED */
static EIF_TYPE_INDEX ptf346[] = {344,0xFFFF};
static struct eif_par_types par346 = {346, ptf346, (uint16) 1, (uint16) 0, (char) 0};

/* ASSERTION_VIOLATION */
static EIF_TYPE_INDEX ptf347[] = {314,0xFFFF};
static struct eif_par_types par347 = {347, ptf347, (uint16) 1, (uint16) 0, (char) 0};

/* LOOP_INVARIANT_VIOLATION */
static EIF_TYPE_INDEX ptf348[] = {347,0xFFFF};
static struct eif_par_types par348 = {348, ptf348, (uint16) 1, (uint16) 0, (char) 0};

/* VARIANT_VIOLATION */
static EIF_TYPE_INDEX ptf349[] = {347,0xFFFF};
static struct eif_par_types par349 = {349, ptf349, (uint16) 1, (uint16) 0, (char) 0};

/* CHECK_VIOLATION */
static EIF_TYPE_INDEX ptf350[] = {347,0xFFFF};
static struct eif_par_types par350 = {350, ptf350, (uint16) 1, (uint16) 0, (char) 0};

/* INVARIANT_VIOLATION */
static EIF_TYPE_INDEX ptf351[] = {347,0xFFFF};
static struct eif_par_types par351 = {351, ptf351, (uint16) 1, (uint16) 0, (char) 0};

/* POSTCONDITION_VIOLATION */
static EIF_TYPE_INDEX ptf352[] = {347,0xFFFF};
static struct eif_par_types par352 = {352, ptf352, (uint16) 1, (uint16) 0, (char) 0};

/* PRECONDITION_VIOLATION */
static EIF_TYPE_INDEX ptf353[] = {347,0xFFFF};
static struct eif_par_types par353 = {353, ptf353, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_ARGUMENTS */
static EIF_TYPE_INDEX ptf354[] = {0,0xFFFF};
static struct eif_par_types par354 = {354, ptf354, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_EXCEPTIONS */
static EIF_TYPE_INDEX ptf355[] = {0,0xFFFF};
static struct eif_par_types par355 = {355, ptf355, (uint16) 1, (uint16) 0, (char) 0};

/* AP_DISPLAY_HELP_FLAG */
static EIF_TYPE_INDEX ptf356[] = {223,0xFFF7,355,0xFFFF};
static struct eif_par_types par356 = {356, ptf356, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_CONDITIONED */
static EIF_TYPE_INDEX ptf357[] = {0,0xFFFF};
static struct eif_par_types par357 = {357, ptf357, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_ACTION */
static EIF_TYPE_INDEX ptf358[] = {357,0xFFFF};
static struct eif_par_types par358 = {358, ptf358, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_VALUE */
static EIF_TYPE_INDEX ptf359[] = {357,0xFFFF};
static struct eif_par_types par359 = {359, ptf359, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_FLAG */
static EIF_TYPE_INDEX ptf360[] = {359,0xFFFF};
static struct eif_par_types par360 = {360, ptf360, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_LINKER_FLAG */
static EIF_TYPE_INDEX ptf361[] = {360,0xFFFF};
static struct eif_par_types par361 = {361, ptf361, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_CFLAG */
static EIF_TYPE_INDEX ptf362[] = {360,0xFFFF};
static struct eif_par_types par362 = {362, ptf362, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_GROUP */
static EIF_TYPE_INDEX ptf363[] = {357,0xFFFF};
static struct eif_par_types par363 = {363, ptf363, (uint16) 1, (uint16) 0, (char) 0};

/* UT_IMPORTED_FORMATTERS */
static EIF_TYPE_INDEX ptf364[] = {0,0xFFFF};
static struct eif_par_types par364 = {364, ptf364, (uint16) 1, (uint16) 0, (char) 0};

/* KL_PART_COMPARATOR [G#1] */
static EIF_TYPE_INDEX ptf365[] = {0,0xFFFF};
static struct eif_par_types par365 = {365, ptf365, (uint16) 1, (uint16) 1, (char) 0};

/* KL_PART_COMPARATOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf366[] = {0,0xFFFF};
static struct eif_par_types par366 = {366, ptf366, (uint16) 1, (uint16) 1, (char) 0};

/* KL_PART_COMPARATOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf367[] = {0,0xFFFF};
static struct eif_par_types par367 = {367, ptf367, (uint16) 1, (uint16) 1, (char) 0};

/* KL_PART_COMPARATOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf368[] = {0,0xFFFF};
static struct eif_par_types par368 = {368, ptf368, (uint16) 1, (uint16) 1, (char) 0};

/* KL_REVERSE_PART_COMPARATOR [G#1] */
static EIF_TYPE_INDEX ptf369[] = {365,0xFFF8,1,0xFFFF};
static struct eif_par_types par369 = {369, ptf369, (uint16) 1, (uint16) 1, (char) 0};

/* KL_REVERSE_PART_COMPARATOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf370[] = {366,1096,0xFFFF};
static struct eif_par_types par370 = {370, ptf370, (uint16) 1, (uint16) 1, (char) 0};

/* ET_SEEDED_QUERY_COMPARATOR */
static EIF_TYPE_INDEX ptf371[] = {365,0xFF01,1824,0xFFFF};
static struct eif_par_types par371 = {371, ptf371, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SEEDED_PROCEDURE_COMPARATOR */
static EIF_TYPE_INDEX ptf372[] = {365,0xFF01,1846,0xFFFF};
static struct eif_par_types par372 = {372, ptf372, (uint16) 1, (uint16) 0, (char) 0};

/* UC_IMPORTED_UTF16_ROUTINES */
static EIF_TYPE_INDEX ptf373[] = {0,0xFFFF};
static struct eif_par_types par373 = {373, ptf373, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SHARED_CLASS_NAME_TESTER */
static EIF_TYPE_INDEX ptf374[] = {0,0xFFFF};
static struct eif_par_types par374 = {374, ptf374, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TOKEN_CODES */
static EIF_TYPE_INDEX ptf375[] = {0,0xFFFF};
static struct eif_par_types par375 = {375, ptf375, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TOKEN_CONSTANTS */
static EIF_TYPE_INDEX ptf376[] = {375,0xFFFF};
static struct eif_par_types par376 = {376, ptf376, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_TARGET */
static EIF_TYPE_INDEX ptf377[] = {0,0xFFFF};
static struct eif_par_types par377 = {377, ptf377, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_EQUALITY_EXPRESSION */
static EIF_TYPE_INDEX ptf378[] = {377,0xFFFF};
static struct eif_par_types par378 = {378, ptf378, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_OBJECT_EQUALITY_EXPRESSION */
static EIF_TYPE_INDEX ptf379[] = {377,0xFFFF};
static struct eif_par_types par379 = {379, ptf379, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_TYPE_SET */
static EIF_TYPE_INDEX ptf380[] = {377,0xFFF7,220,0xFFFF};
static struct eif_par_types par380 = {380, ptf380, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DYNAMIC_EXTENDIBLE_TYPE_SET */
static EIF_TYPE_INDEX ptf381[] = {380,0xFFFF};
static struct eif_par_types par381 = {381, ptf381, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_STANDALONE_TYPE_SET */
static EIF_TYPE_INDEX ptf382[] = {381,0xFFFF};
static struct eif_par_types par382 = {382, ptf382, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_AGENT_OPERAND_PUSH_TYPE_SET */
static EIF_TYPE_INDEX ptf383[] = {381,0xFFFF};
static struct eif_par_types par383 = {383, ptf383, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_PUSH_TYPE_SET */
static EIF_TYPE_INDEX ptf384[] = {381,0xFFFF};
static struct eif_par_types par384 = {384, ptf384, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_PULL_TYPE_SET */
static EIF_TYPE_INDEX ptf385[] = {381,0xFFFF};
static struct eif_par_types par385 = {385, ptf385, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_AGENT_OPERAND_PULL_TYPE_SET */
static EIF_TYPE_INDEX ptf386[] = {385,0xFFFF};
static struct eif_par_types par386 = {386, ptf386, (uint16) 1, (uint16) 0, (char) 0};

/* UC_SHARED_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf387[] = {0,0xFFFF};
static struct eif_par_types par387 = {387, ptf387, (uint16) 1, (uint16) 0, (char) 0};

/* XM_UNICODE_STRUCTURE_FACTORY */
static EIF_TYPE_INDEX ptf388[] = {387,0xFFFF};
static struct eif_par_types par388 = {388, ptf388, (uint16) 1, (uint16) 0, (char) 0};

/* XM_END_TAG_CHECKER */
static EIF_TYPE_INDEX ptf389[] = {277,0xFFF7,388,0xFFFF};
static struct eif_par_types par389 = {389, ptf389, (uint16) 2, (uint16) 0, (char) 0};

/* XM_SHARED_STRINGS_FILTER */
static EIF_TYPE_INDEX ptf390[] = {277,0xFFF7,388,0xFFFF};
static struct eif_par_types par390 = {390, ptf390, (uint16) 2, (uint16) 0, (char) 0};

/* XM_EIFFEL_UNICODE_STRUCTURE_FACTORY */
static EIF_TYPE_INDEX ptf391[] = {388,0xFFFF};
static struct eif_par_types par391 = {391, ptf391, (uint16) 1, (uint16) 0, (char) 0};

/* UT_SHARED_ECF_VERSIONS */
static EIF_TYPE_INDEX ptf392[] = {0,0xFFFF};
static struct eif_par_types par392 = {392, ptf392, (uint16) 1, (uint16) 0, (char) 0};

/* DISPOSABLE */
static EIF_TYPE_INDEX ptf393[] = {0,0xFFFF};
static struct eif_par_types par393 = {393, ptf393, (uint16) 1, (uint16) 0, (char) 0};

/* MUTEX */
static EIF_TYPE_INDEX ptf394[] = {393,0xFFFF};
static struct eif_par_types par394 = {394, ptf394, (uint16) 1, (uint16) 0, (char) 0};

/* MANAGED_POINTER */
static EIF_TYPE_INDEX ptf395[] = {393,0xFFF7,263,0xFFFF};
static struct eif_par_types par395 = {395, ptf395, (uint16) 2, (uint16) 0, (char) 0};

/* REFLECTOR_CONSTANTS */
static EIF_TYPE_INDEX ptf396[] = {0,0xFFFF};
static struct eif_par_types par396 = {396, ptf396, (uint16) 1, (uint16) 0, (char) 0};

/* REFLECTED_OBJECT */
static EIF_TYPE_INDEX ptf397[] = {396,0xFFFF};
static struct eif_par_types par397 = {397, ptf397, (uint16) 1, (uint16) 0, (char) 0};

/* REFLECTOR */
static EIF_TYPE_INDEX ptf398[] = {137,0xFFF7,396,0xFFFF};
static struct eif_par_types par398 = {398, ptf398, (uint16) 2, (uint16) 0, (char) 0};

/* INTERNAL */
static EIF_TYPE_INDEX ptf399[] = {398,0xFFF7,121,0xFFFF};
static struct eif_par_types par399 = {399, ptf399, (uint16) 2, (uint16) 0, (char) 0};

/* RT_DBG_INTERNAL */
static EIF_TYPE_INDEX ptf400[] = {396,0xFFFF};
static struct eif_par_types par400 = {400, ptf400, (uint16) 1, (uint16) 0, (char) 0};

/* REFLECTED_COPY_SEMANTICS_OBJECT */
static EIF_TYPE_INDEX ptf401[] = {397,0xFFF7,396,0xFFFF};
static struct eif_par_types par401 = {401, ptf401, (uint16) 2, (uint16) 0, (char) 0};

/* REFLECTED_REFERENCE_OBJECT */
static EIF_TYPE_INDEX ptf402[] = {397,0xFFF7,396,0xFFFF};
static struct eif_par_types par402 = {402, ptf402, (uint16) 2, (uint16) 0, (char) 0};

/* TO_SPECIAL [G#1] */
static EIF_TYPE_INDEX ptf403[] = {0,0xFFFF};
static struct eif_par_types par403 = {403, ptf403, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [INTEGER_32] */
static EIF_TYPE_INDEX ptf404[] = {0,0xFFFF};
static struct eif_par_types par404 = {404, ptf404, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [BOOLEAN] */
static EIF_TYPE_INDEX ptf405[] = {0,0xFFFF};
static struct eif_par_types par405 = {405, ptf405, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [NATURAL_64] */
static EIF_TYPE_INDEX ptf406[] = {0,0xFFFF};
static struct eif_par_types par406 = {406, ptf406, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [NATURAL_32] */
static EIF_TYPE_INDEX ptf407[] = {0,0xFFFF};
static struct eif_par_types par407 = {407, ptf407, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [NATURAL_16] */
static EIF_TYPE_INDEX ptf408[] = {0,0xFFFF};
static struct eif_par_types par408 = {408, ptf408, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [NATURAL_8] */
static EIF_TYPE_INDEX ptf409[] = {0,0xFFFF};
static struct eif_par_types par409 = {409, ptf409, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [CHARACTER_32] */
static EIF_TYPE_INDEX ptf410[] = {0,0xFFFF};
static struct eif_par_types par410 = {410, ptf410, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [CHARACTER_8] */
static EIF_TYPE_INDEX ptf411[] = {0,0xFFFF};
static struct eif_par_types par411 = {411, ptf411, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [POINTER] */
static EIF_TYPE_INDEX ptf412[] = {0,0xFFFF};
static struct eif_par_types par412 = {412, ptf412, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [REAL_32] */
static EIF_TYPE_INDEX ptf413[] = {0,0xFFFF};
static struct eif_par_types par413 = {413, ptf413, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [REAL_64] */
static EIF_TYPE_INDEX ptf414[] = {0,0xFFFF};
static struct eif_par_types par414 = {414, ptf414, (uint16) 1, (uint16) 1, (char) 0};

/* UC_IMPORTED_UTF8_ROUTINES */
static EIF_TYPE_INDEX ptf415[] = {0,0xFFFF};
static struct eif_par_types par415 = {415, ptf415, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_OPERATING_SYSTEM */
static EIF_TYPE_INDEX ptf416[] = {0,0xFFFF};
static struct eif_par_types par416 = {416, ptf416, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_FILE_RULE */
static EIF_TYPE_INDEX ptf417[] = {357,0xFFF7,416,0xFFFF};
static struct eif_par_types par417 = {417, ptf417, (uint16) 2, (uint16) 0, (char) 0};

/* NATIVE_STRING_HANDLER */
static EIF_TYPE_INDEX ptf418[] = {0,0xFFFF};
static struct eif_par_types par418 = {418, ptf418, (uint16) 1, (uint16) 0, (char) 0};

/* NATIVE_STRING */
static EIF_TYPE_INDEX ptf419[] = {418,0xFFFF};
static struct eif_par_types par419 = {419, ptf419, (uint16) 1, (uint16) 0, (char) 0};

/* EXECUTION_ENVIRONMENT */
static EIF_TYPE_INDEX ptf420[] = {418,0xFFFF};
static struct eif_par_types par420 = {420, ptf420, (uint16) 1, (uint16) 0, (char) 0};

/* DIRECTORY */
static EIF_TYPE_INDEX ptf421[] = {393,0xFFF7,418,0xFFFF};
static struct eif_par_types par421 = {421, ptf421, (uint16) 2, (uint16) 0, (char) 0};

/* FILE_INFO */
static EIF_TYPE_INDEX ptf422[] = {409,1114,0xFFF7,418,0xFFFF};
static struct eif_par_types par422 = {422, ptf422, (uint16) 2, (uint16) 0, (char) 0};

/* UNIX_FILE_INFO */
static EIF_TYPE_INDEX ptf423[] = {422,0xFFFF};
static struct eif_par_types par423 = {423, ptf423, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SHARED_FEATURE_NAME_TESTER */
static EIF_TYPE_INDEX ptf424[] = {0,0xFFFF};
static struct eif_par_types par424 = {424, ptf424, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_HANDLER */
static EIF_TYPE_INDEX ptf425[] = {0,0xFFFF};
static struct eif_par_types par425 = {425, ptf425, (uint16) 1, (uint16) 0, (char) 0};

/* KL_UNICODE_CHARACTER_BUFFER */
static EIF_TYPE_INDEX ptf426[] = {127,0xFFF7,425,0xFFFF};
static struct eif_par_types par426 = {426, ptf426, (uint16) 2, (uint16) 0, (char) 0};

/* KL_CHARACTER_BUFFER */
static EIF_TYPE_INDEX ptf427[] = {127,0xFFF7,425,0xFFFF};
static struct eif_par_types par427 = {427, ptf427, (uint16) 2, (uint16) 0, (char) 0};

/* C_STRING */
static EIF_TYPE_INDEX ptf428[] = {425,0xFFFF};
static struct eif_par_types par428 = {428, ptf428, (uint16) 1, (uint16) 0, (char) 0};

/* IO_MEDIUM */
static EIF_TYPE_INDEX ptf429[] = {393,0xFFF7,425,0xFFFF};
static struct eif_par_types par429 = {429, ptf429, (uint16) 2, (uint16) 0, (char) 0};

/* ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf430[] = {0,0xFFFF};
static struct eif_par_types par430 = {430, ptf430, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf431[] = {0,0xFFFF};
static struct eif_par_types par431 = {431, ptf431, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf432[] = {0,0xFFFF};
static struct eif_par_types par432 = {432, ptf432, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf433[] = {0,0xFFFF};
static struct eif_par_types par433 = {433, ptf433, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf434[] = {0,0xFFFF};
static struct eif_par_types par434 = {434, ptf434, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf435[] = {0,0xFFFF};
static struct eif_par_types par435 = {435, ptf435, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf436[] = {0,0xFFFF};
static struct eif_par_types par436 = {436, ptf436, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf437[] = {0,0xFFFF};
static struct eif_par_types par437 = {437, ptf437, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf438[] = {0,0xFFFF};
static struct eif_par_types par438 = {438, ptf438, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf439[] = {0,0xFFFF};
static struct eif_par_types par439 = {439, ptf439, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf440[] = {0,0xFFFF};
static struct eif_par_types par440 = {440, ptf440, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf441[] = {0,0xFFFF};
static struct eif_par_types par441 = {441, ptf441, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_QUEUE_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf442[] = {430,0xFFF8,1,0xFFFF};
static struct eif_par_types par442 = {442, ptf442, (uint16) 1, (uint16) 1, (char) 0};

/* FILE_ITERATION_CURSOR */
static EIF_TYPE_INDEX ptf443[] = {393,0xFFF7,433,1126,0xFFFF};
static struct eif_par_types par443 = {443, ptf443, (uint16) 2, (uint16) 0, (char) 0};

/* TABLE_ITERATION_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf444[] = {430,0xFFF8,1,0xFFFF};
static struct eif_par_types par444 = {444, ptf444, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERATION_CURSOR [POINTER, G#2] */
static EIF_TYPE_INDEX ptf445[] = {439,1174,0xFFFF};
static struct eif_par_types par445 = {445, ptf445, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERATION_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf446[] = {430,0xFFF8,1,0xFFFF};
static struct eif_par_types par446 = {446, ptf446, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERATION_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf447[] = {431,1096,0xFFFF};
static struct eif_par_types par447 = {447, ptf447, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERATION_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf448[] = {431,1096,0xFFFF};
static struct eif_par_types par448 = {448, ptf448, (uint16) 1, (uint16) 2, (char) 0};

/* XM_MARKUP_CONSTANTS */
static EIF_TYPE_INDEX ptf449[] = {0,0xFFFF};
static struct eif_par_types par449 = {449, ptf449, (uint16) 1, (uint16) 0, (char) 0};

/* UC_IMPORTED_UNICODE_ROUTINES */
static EIF_TYPE_INDEX ptf450[] = {0,0xFFFF};
static struct eif_par_types par450 = {450, ptf450, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_SPECIAL_ROUTINES */
static EIF_TYPE_INDEX ptf451[] = {0,0xFFFF};
static struct eif_par_types par451 = {451, ptf451, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_STANDARD_FILES */
static EIF_TYPE_INDEX ptf452[] = {0,0xFFFF};
static struct eif_par_types par452 = {452, ptf452, (uint16) 1, (uint16) 0, (char) 0};

/* KL_EQUALITY_TESTER [G#1] */
static EIF_TYPE_INDEX ptf453[] = {0,0xFFFF};
static struct eif_par_types par453 = {453, ptf453, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf454[] = {0,0xFFFF};
static struct eif_par_types par454 = {454, ptf454, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [BOOLEAN] */
static EIF_TYPE_INDEX ptf455[] = {0,0xFFFF};
static struct eif_par_types par455 = {455, ptf455, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [NATURAL_32] */
static EIF_TYPE_INDEX ptf456[] = {0,0xFFFF};
static struct eif_par_types par456 = {456, ptf456, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [NATURAL_64] */
static EIF_TYPE_INDEX ptf457[] = {0,0xFFFF};
static struct eif_par_types par457 = {457, ptf457, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [NATURAL_8] */
static EIF_TYPE_INDEX ptf458[] = {0,0xFFFF};
static struct eif_par_types par458 = {458, ptf458, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf459[] = {0,0xFFFF};
static struct eif_par_types par459 = {459, ptf459, (uint16) 1, (uint16) 1, (char) 0};

/* ET_IDENTIFIER_TESTER */
static EIF_TYPE_INDEX ptf460[] = {453,0xFF01,1980,0xFFFF};
static struct eif_par_types par460 = {460, ptf460, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ALIAS_NAME_TESTER */
static EIF_TYPE_INDEX ptf461[] = {453,0xFF01,1941,0xFFFF};
static struct eif_par_types par461 = {461, ptf461, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DOTNET_SIGNATURE_TESTER */
static EIF_TYPE_INDEX ptf462[] = {453,0xFF01,1823,0xFFFF};
static struct eif_par_types par462 = {462, ptf462, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLASS_NAME_TESTER */
static EIF_TYPE_INDEX ptf463[] = {453,0xFF01,1979,0xFFFF};
static struct eif_par_types par463 = {463, ptf463, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FEATURE_NAME_TESTER */
static EIF_TYPE_INDEX ptf464[] = {453,0xFF01,1944,0xFFFF};
static struct eif_par_types par464 = {464, ptf464, (uint16) 1, (uint16) 0, (char) 0};

/* KL_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf465[] = {453,0xFF01,1189,0xFFFF};
static struct eif_par_types par465 = {465, ptf465, (uint16) 1, (uint16) 0, (char) 0};

/* KL_COMPARATOR [G#1] */
static EIF_TYPE_INDEX ptf466[] = {365,0xFFF8,1,0xFFF7,453,0xFFF8,1,0xFFFF};
static struct eif_par_types par466 = {466, ptf466, (uint16) 2, (uint16) 1, (char) 0};

/* KL_COMPARATOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf467[] = {366,1096,0xFFF7,454,1096,0xFFFF};
static struct eif_par_types par467 = {467, ptf467, (uint16) 2, (uint16) 1, (char) 0};

/* KL_COMPARABLE_COMPARATOR [G#1] */
static EIF_TYPE_INDEX ptf468[] = {466,0xFFF8,1,0xFFFF};
static struct eif_par_types par468 = {468, ptf468, (uint16) 1, (uint16) 1, (char) 0};

/* KL_COMPARABLE_COMPARATOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf469[] = {467,1096,0xFFFF};
static struct eif_par_types par469 = {469, ptf469, (uint16) 1, (uint16) 1, (char) 0};

/* UT_SHARED_ISE_VERSIONS */
static EIF_TYPE_INDEX ptf470[] = {0,0xFFFF};
static struct eif_par_types par470 = {470, ptf470, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_EXECUTION_ENVIRONMENT */
static EIF_TYPE_INDEX ptf471[] = {0,0xFFFF};
static struct eif_par_types par471 = {471, ptf471, (uint16) 1, (uint16) 0, (char) 0};

/* ITERABLE [G#1] */
static EIF_TYPE_INDEX ptf472[] = {0,0xFFFF};
static struct eif_par_types par472 = {472, ptf472, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf473[] = {0,0xFFFF};
static struct eif_par_types par473 = {473, ptf473, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf474[] = {0,0xFFFF};
static struct eif_par_types par474 = {474, ptf474, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf475[] = {0,0xFFFF};
static struct eif_par_types par475 = {475, ptf475, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf476[] = {0,0xFFFF};
static struct eif_par_types par476 = {476, ptf476, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf477[] = {0,0xFFFF};
static struct eif_par_types par477 = {477, ptf477, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf478[] = {0,0xFFFF};
static struct eif_par_types par478 = {478, ptf478, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [NATURAL_16] */
static EIF_TYPE_INDEX ptf479[] = {0,0xFFFF};
static struct eif_par_types par479 = {479, ptf479, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf480[] = {0,0xFFFF};
static struct eif_par_types par480 = {480, ptf480, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [POINTER] */
static EIF_TYPE_INDEX ptf481[] = {0,0xFFFF};
static struct eif_par_types par481 = {481, ptf481, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [REAL_32] */
static EIF_TYPE_INDEX ptf482[] = {0,0xFFFF};
static struct eif_par_types par482 = {482, ptf482, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [REAL_64] */
static EIF_TYPE_INDEX ptf483[] = {0,0xFFFF};
static struct eif_par_types par483 = {483, ptf483, (uint16) 1, (uint16) 1, (char) 0};

/* STRING_ITERATION_CURSOR */
static EIF_TYPE_INDEX ptf484[] = {434,1123,0xFFF7,476,1123,0xFFFF};
static struct eif_par_types par484 = {484, ptf484, (uint16) 2, (uint16) 0, (char) 0};

/* ARGUMENTS_32 */
static EIF_TYPE_INDEX ptf485[] = {472,0xFF01,1185,0xFFFF};
static struct eif_par_types par485 = {485, ptf485, (uint16) 1, (uint16) 0, (char) 0};

/* TABLE_ITERABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf486[] = {472,0xFFF8,1,0xFFFF};
static struct eif_par_types par486 = {486, ptf486, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERABLE [POINTER, G#2] */
static EIF_TYPE_INDEX ptf487[] = {481,1174,0xFFFF};
static struct eif_par_types par487 = {487, ptf487, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf488[] = {472,0xFFF8,1,0xFFFF};
static struct eif_par_types par488 = {488, ptf488, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf489[] = {473,1096,0xFFFF};
static struct eif_par_types par489 = {489, ptf489, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf490[] = {473,1096,0xFFFF};
static struct eif_par_types par490 = {490, ptf490, (uint16) 1, (uint16) 2, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf491[] = {430,0xFFF8,1,0xFFF7,472,0xFFF8,1,0xFFFF};
static struct eif_par_types par491 = {491, ptf491, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf492[] = {431,1096,0xFFF7,473,1096,0xFFFF};
static struct eif_par_types par492 = {492, ptf492, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf493[] = {432,1129,0xFFF7,474,1129,0xFFFF};
static struct eif_par_types par493 = {493, ptf493, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf494[] = {433,1126,0xFFF7,475,1126,0xFFFF};
static struct eif_par_types par494 = {494, ptf494, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf495[] = {434,1123,0xFFF7,476,1123,0xFFFF};
static struct eif_par_types par495 = {495, ptf495, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf496[] = {435,1105,0xFFF7,477,1105,0xFFFF};
static struct eif_par_types par496 = {496, ptf496, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf497[] = {436,1108,0xFFF7,478,1108,0xFFFF};
static struct eif_par_types par497 = {497, ptf497, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf498[] = {437,1111,0xFFF7,479,1111,0xFFFF};
static struct eif_par_types par498 = {498, ptf498, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf499[] = {438,1114,0xFFF7,480,1114,0xFFFF};
static struct eif_par_types par499 = {499, ptf499, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf500[] = {439,1174,0xFFF7,481,1174,0xFFFF};
static struct eif_par_types par500 = {500, ptf500, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf501[] = {440,1117,0xFFF7,482,1117,0xFFFF};
static struct eif_par_types par501 = {501, ptf501, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf502[] = {441,1120,0xFFF7,483,1120,0xFFFF};
static struct eif_par_types par502 = {502, ptf502, (uint16) 2, (uint16) 1, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf503[] = {491,0xFFF8,1,0xFFFF};
static struct eif_par_types par503 = {503, ptf503, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf504[] = {492,1096,0xFFFF};
static struct eif_par_types par504 = {504, ptf504, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf505[] = {493,1129,0xFFFF};
static struct eif_par_types par505 = {505, ptf505, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [CHARACTER_8, G#2] */
static EIF_TYPE_INDEX ptf506[] = {494,1126,0xFFFF};
static struct eif_par_types par506 = {506, ptf506, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [CHARACTER_32, G#2] */
static EIF_TYPE_INDEX ptf507[] = {495,1123,0xFFFF};
static struct eif_par_types par507 = {507, ptf507, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [NATURAL_64, G#2] */
static EIF_TYPE_INDEX ptf508[] = {496,1105,0xFFFF};
static struct eif_par_types par508 = {508, ptf508, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [NATURAL_32, G#2] */
static EIF_TYPE_INDEX ptf509[] = {497,1108,0xFFFF};
static struct eif_par_types par509 = {509, ptf509, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [NATURAL_16, G#2] */
static EIF_TYPE_INDEX ptf510[] = {498,1111,0xFFFF};
static struct eif_par_types par510 = {510, ptf510, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf511[] = {499,1114,0xFFFF};
static struct eif_par_types par511 = {511, ptf511, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [POINTER, G#2] */
static EIF_TYPE_INDEX ptf512[] = {500,1174,0xFFFF};
static struct eif_par_types par512 = {512, ptf512, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [REAL_32, G#2] */
static EIF_TYPE_INDEX ptf513[] = {501,1117,0xFFFF};
static struct eif_par_types par513 = {513, ptf513, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [REAL_64, G#2] */
static EIF_TYPE_INDEX ptf514[] = {502,1120,0xFFFF};
static struct eif_par_types par514 = {514, ptf514, (uint16) 1, (uint16) 2, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf515[] = {503,0xFFF8,1,0xFF01,794,0xFFF8,1,0xFFFF};
static struct eif_par_types par515 = {515, ptf515, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf516[] = {504,1096,0xFF01,795,1096,0xFFFF};
static struct eif_par_types par516 = {516, ptf516, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf517[] = {505,1129,0xFF01,796,1129,0xFFFF};
static struct eif_par_types par517 = {517, ptf517, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf518[] = {506,1126,0xFF01,797,1126,0xFFFF};
static struct eif_par_types par518 = {518, ptf518, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf519[] = {507,1123,0xFF01,798,1123,0xFFFF};
static struct eif_par_types par519 = {519, ptf519, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf520[] = {508,1105,0xFF01,799,1105,0xFFFF};
static struct eif_par_types par520 = {520, ptf520, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf521[] = {509,1108,0xFF01,800,1108,0xFFFF};
static struct eif_par_types par521 = {521, ptf521, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf522[] = {510,1111,0xFF01,801,1111,0xFFFF};
static struct eif_par_types par522 = {522, ptf522, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf523[] = {511,1114,0xFF01,802,1114,0xFFFF};
static struct eif_par_types par523 = {523, ptf523, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf524[] = {512,1174,0xFF01,803,1174,0xFFFF};
static struct eif_par_types par524 = {524, ptf524, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf525[] = {513,1117,0xFF01,804,1117,0xFFFF};
static struct eif_par_types par525 = {525, ptf525, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf526[] = {514,1120,0xFF01,805,1120,0xFFFF};
static struct eif_par_types par526 = {526, ptf526, (uint16) 1, (uint16) 1, (char) 0};

/* LINKED_LIST_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf527[] = {515,0xFFF8,1,0xFFFF};
static struct eif_par_types par527 = {527, ptf527, (uint16) 1, (uint16) 1, (char) 0};

/* LINKED_LIST_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf528[] = {516,1096,0xFFFF};
static struct eif_par_types par528 = {528, ptf528, (uint16) 1, (uint16) 1, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf529[] = {515,0xFFF8,1,0xFFF7,444,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par529 = {529, ptf529, (uint16) 2, (uint16) 2, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [POINTER, G#2] */
static EIF_TYPE_INDEX ptf530[] = {524,1174,0xFFF7,445,1174,0xFFF8,2,0xFFFF};
static struct eif_par_types par530 = {530, ptf530, (uint16) 2, (uint16) 2, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf531[] = {515,0xFFF8,1,0xFFF7,446,0xFFF8,1,1096,0xFFFF};
static struct eif_par_types par531 = {531, ptf531, (uint16) 2, (uint16) 2, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf532[] = {516,1096,0xFFF7,447,1096,0xFFF8,2,0xFFFF};
static struct eif_par_types par532 = {532, ptf532, (uint16) 2, (uint16) 2, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf533[] = {516,1096,0xFFF7,448,1096,1096,0xFFFF};
static struct eif_par_types par533 = {533, ptf533, (uint16) 2, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf534[] = {503,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par534 = {534, ptf534, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf535[] = {504,1096,0xFFF8,2,0xFFFF};
static struct eif_par_types par535 = {535, ptf535, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf536[] = {505,1129,0xFFF8,2,0xFFFF};
static struct eif_par_types par536 = {536, ptf536, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [NATURAL_64, G#2] */
static EIF_TYPE_INDEX ptf537[] = {508,1105,0xFFF8,2,0xFFFF};
static struct eif_par_types par537 = {537, ptf537, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [NATURAL_32, G#2] */
static EIF_TYPE_INDEX ptf538[] = {509,1108,0xFFF8,2,0xFFFF};
static struct eif_par_types par538 = {538, ptf538, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [NATURAL_16, G#2] */
static EIF_TYPE_INDEX ptf539[] = {510,1111,0xFFF8,2,0xFFFF};
static struct eif_par_types par539 = {539, ptf539, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf540[] = {511,1114,0xFFF8,2,0xFFFF};
static struct eif_par_types par540 = {540, ptf540, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [CHARACTER_32, G#2] */
static EIF_TYPE_INDEX ptf541[] = {507,1123,0xFFF8,2,0xFFFF};
static struct eif_par_types par541 = {541, ptf541, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [CHARACTER_8, G#2] */
static EIF_TYPE_INDEX ptf542[] = {506,1126,0xFFF8,2,0xFFFF};
static struct eif_par_types par542 = {542, ptf542, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [POINTER, G#2] */
static EIF_TYPE_INDEX ptf543[] = {512,1174,0xFFF8,2,0xFFFF};
static struct eif_par_types par543 = {543, ptf543, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [REAL_32, G#2] */
static EIF_TYPE_INDEX ptf544[] = {513,1117,0xFFF8,2,0xFFFF};
static struct eif_par_types par544 = {544, ptf544, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [REAL_64, G#2] */
static EIF_TYPE_INDEX ptf545[] = {514,1120,0xFFF8,2,0xFFFF};
static struct eif_par_types par545 = {545, ptf545, (uint16) 1, (uint16) 2, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf546[] = {534,0xFFF8,1,0xFF01,964,0xFFF8,1,0xFFFF};
static struct eif_par_types par546 = {546, ptf546, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf547[] = {535,1096,0xFF01,965,1096,0xFFFF};
static struct eif_par_types par547 = {547, ptf547, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf548[] = {536,1129,0xFF01,966,1129,0xFFFF};
static struct eif_par_types par548 = {548, ptf548, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf549[] = {537,1105,0xFF01,967,1105,0xFFFF};
static struct eif_par_types par549 = {549, ptf549, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf550[] = {538,1108,0xFF01,968,1108,0xFFFF};
static struct eif_par_types par550 = {550, ptf550, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf551[] = {539,1111,0xFF01,969,1111,0xFFFF};
static struct eif_par_types par551 = {551, ptf551, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf552[] = {540,1114,0xFF01,970,1114,0xFFFF};
static struct eif_par_types par552 = {552, ptf552, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf553[] = {541,1123,0xFF01,971,1123,0xFFFF};
static struct eif_par_types par553 = {553, ptf553, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf554[] = {542,1126,0xFF01,972,1126,0xFFFF};
static struct eif_par_types par554 = {554, ptf554, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf555[] = {543,1174,0xFF01,973,1174,0xFFFF};
static struct eif_par_types par555 = {555, ptf555, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf556[] = {544,1117,0xFF01,974,1117,0xFFFF};
static struct eif_par_types par556 = {556, ptf556, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf557[] = {545,1120,0xFF01,975,1120,0xFFFF};
static struct eif_par_types par557 = {557, ptf557, (uint16) 1, (uint16) 1, (char) 0};

/* STRING_32_ITERATION_CURSOR */
static EIF_TYPE_INDEX ptf558[] = {541,1123,0xFF01,1184,0xFFFF};
static struct eif_par_types par558 = {558, ptf558, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_8_ITERATION_CURSOR */
static EIF_TYPE_INDEX ptf559[] = {542,1126,0xFF01,1187,0xFFFF};
static struct eif_par_types par559 = {559, ptf559, (uint16) 1, (uint16) 0, (char) 0};

/* ARRAY_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf560[] = {534,0xFFF8,1,0xFF01,819,0xFFF8,1,0xFFFF};
static struct eif_par_types par560 = {560, ptf560, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf561[] = {535,1096,0xFF01,820,1096,0xFFFF};
static struct eif_par_types par561 = {561, ptf561, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf562[] = {536,1129,0xFF01,821,1129,0xFFFF};
static struct eif_par_types par562 = {562, ptf562, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf563[] = {537,1105,0xFF01,822,1105,0xFFFF};
static struct eif_par_types par563 = {563, ptf563, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf564[] = {538,1108,0xFF01,823,1108,0xFFFF};
static struct eif_par_types par564 = {564, ptf564, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf565[] = {539,1111,0xFF01,824,1111,0xFFFF};
static struct eif_par_types par565 = {565, ptf565, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf566[] = {540,1114,0xFF01,825,1114,0xFFFF};
static struct eif_par_types par566 = {566, ptf566, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf567[] = {541,1123,0xFF01,826,1123,0xFFFF};
static struct eif_par_types par567 = {567, ptf567, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf568[] = {542,1126,0xFF01,827,1126,0xFFFF};
static struct eif_par_types par568 = {568, ptf568, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf569[] = {543,1174,0xFF01,828,1174,0xFFFF};
static struct eif_par_types par569 = {569, ptf569, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf570[] = {544,1117,0xFF01,829,1117,0xFFFF};
static struct eif_par_types par570 = {570, ptf570, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf571[] = {545,1120,0xFF01,830,1120,0xFFFF};
static struct eif_par_types par571 = {571, ptf571, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf572[] = {534,0xFFF8,1,0xFF01,903,0xFFF8,1,0xFFFF};
static struct eif_par_types par572 = {572, ptf572, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf573[] = {535,1096,0xFF01,904,1096,0xFFFF};
static struct eif_par_types par573 = {573, ptf573, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf574[] = {536,1129,0xFF01,905,1129,0xFFFF};
static struct eif_par_types par574 = {574, ptf574, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf575[] = {537,1105,0xFF01,906,1105,0xFFFF};
static struct eif_par_types par575 = {575, ptf575, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf576[] = {538,1108,0xFF01,907,1108,0xFFFF};
static struct eif_par_types par576 = {576, ptf576, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf577[] = {539,1111,0xFF01,908,1111,0xFFFF};
static struct eif_par_types par577 = {577, ptf577, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf578[] = {540,1114,0xFF01,909,1114,0xFFFF};
static struct eif_par_types par578 = {578, ptf578, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf579[] = {541,1123,0xFF01,910,1123,0xFFFF};
static struct eif_par_types par579 = {579, ptf579, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf580[] = {542,1126,0xFF01,911,1126,0xFFFF};
static struct eif_par_types par580 = {580, ptf580, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf581[] = {543,1174,0xFF01,912,1174,0xFFFF};
static struct eif_par_types par581 = {581, ptf581, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf582[] = {544,1117,0xFF01,913,1117,0xFFFF};
static struct eif_par_types par582 = {582, ptf582, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf583[] = {545,1120,0xFF01,914,1120,0xFFFF};
static struct eif_par_types par583 = {583, ptf583, (uint16) 1, (uint16) 1, (char) 0};

/* ARGUMENTS */
static EIF_TYPE_INDEX ptf584[] = {472,0xFF01,1189,0xFFFF};
static struct eif_par_types par584 = {584, ptf584, (uint16) 1, (uint16) 0, (char) 0};

/* KL_ARGUMENTS */
static EIF_TYPE_INDEX ptf585[] = {584,0xFFFF};
static struct eif_par_types par585 = {585, ptf585, (uint16) 1, (uint16) 0, (char) 0};

/* CONTAINER [G#1] */
static EIF_TYPE_INDEX ptf586[] = {472,0xFFF8,1,0xFFFF};
static struct eif_par_types par586 = {586, ptf586, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [INTEGER_32] */
static EIF_TYPE_INDEX ptf587[] = {473,1096,0xFFFF};
static struct eif_par_types par587 = {587, ptf587, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [BOOLEAN] */
static EIF_TYPE_INDEX ptf588[] = {474,1129,0xFFFF};
static struct eif_par_types par588 = {588, ptf588, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf589[] = {475,1126,0xFFFF};
static struct eif_par_types par589 = {589, ptf589, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [CHARACTER_32] */
static EIF_TYPE_INDEX ptf590[] = {476,1123,0xFFFF};
static struct eif_par_types par590 = {590, ptf590, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [NATURAL_64] */
static EIF_TYPE_INDEX ptf591[] = {477,1105,0xFFFF};
static struct eif_par_types par591 = {591, ptf591, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [NATURAL_32] */
static EIF_TYPE_INDEX ptf592[] = {478,1108,0xFFFF};
static struct eif_par_types par592 = {592, ptf592, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [NATURAL_16] */
static EIF_TYPE_INDEX ptf593[] = {479,1111,0xFFFF};
static struct eif_par_types par593 = {593, ptf593, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [NATURAL_8] */
static EIF_TYPE_INDEX ptf594[] = {480,1114,0xFFFF};
static struct eif_par_types par594 = {594, ptf594, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [POINTER] */
static EIF_TYPE_INDEX ptf595[] = {481,1174,0xFFFF};
static struct eif_par_types par595 = {595, ptf595, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [REAL_32] */
static EIF_TYPE_INDEX ptf596[] = {482,1117,0xFFFF};
static struct eif_par_types par596 = {596, ptf596, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [REAL_64] */
static EIF_TYPE_INDEX ptf597[] = {483,1120,0xFFFF};
static struct eif_par_types par597 = {597, ptf597, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [G#1] */
static EIF_TYPE_INDEX ptf598[] = {586,0xFFF8,1,0xFFFF};
static struct eif_par_types par598 = {598, ptf598, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf599[] = {587,1096,0xFFFF};
static struct eif_par_types par599 = {599, ptf599, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf600[] = {588,1129,0xFFFF};
static struct eif_par_types par600 = {600, ptf600, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf601[] = {589,1126,0xFFFF};
static struct eif_par_types par601 = {601, ptf601, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf602[] = {590,1123,0xFFFF};
static struct eif_par_types par602 = {602, ptf602, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf603[] = {591,1105,0xFFFF};
static struct eif_par_types par603 = {603, ptf603, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf604[] = {592,1108,0xFFFF};
static struct eif_par_types par604 = {604, ptf604, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [NATURAL_16] */
static EIF_TYPE_INDEX ptf605[] = {593,1111,0xFFFF};
static struct eif_par_types par605 = {605, ptf605, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf606[] = {594,1114,0xFFFF};
static struct eif_par_types par606 = {606, ptf606, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [POINTER] */
static EIF_TYPE_INDEX ptf607[] = {595,1174,0xFFFF};
static struct eif_par_types par607 = {607, ptf607, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [REAL_32] */
static EIF_TYPE_INDEX ptf608[] = {596,1117,0xFFFF};
static struct eif_par_types par608 = {608, ptf608, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [REAL_64] */
static EIF_TYPE_INDEX ptf609[] = {597,1120,0xFFFF};
static struct eif_par_types par609 = {609, ptf609, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [G#1] */
static EIF_TYPE_INDEX ptf610[] = {598,0xFFF8,1,0xFFFF};
static struct eif_par_types par610 = {610, ptf610, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [INTEGER_32] */
static EIF_TYPE_INDEX ptf611[] = {599,1096,0xFFFF};
static struct eif_par_types par611 = {611, ptf611, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [BOOLEAN] */
static EIF_TYPE_INDEX ptf612[] = {600,1129,0xFFFF};
static struct eif_par_types par612 = {612, ptf612, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf613[] = {601,1126,0xFFFF};
static struct eif_par_types par613 = {613, ptf613, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf614[] = {602,1123,0xFFFF};
static struct eif_par_types par614 = {614, ptf614, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [NATURAL_64] */
static EIF_TYPE_INDEX ptf615[] = {603,1105,0xFFFF};
static struct eif_par_types par615 = {615, ptf615, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [NATURAL_32] */
static EIF_TYPE_INDEX ptf616[] = {604,1108,0xFFFF};
static struct eif_par_types par616 = {616, ptf616, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [NATURAL_16] */
static EIF_TYPE_INDEX ptf617[] = {605,1111,0xFFFF};
static struct eif_par_types par617 = {617, ptf617, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [NATURAL_8] */
static EIF_TYPE_INDEX ptf618[] = {606,1114,0xFFFF};
static struct eif_par_types par618 = {618, ptf618, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [POINTER] */
static EIF_TYPE_INDEX ptf619[] = {607,1174,0xFFFF};
static struct eif_par_types par619 = {619, ptf619, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [REAL_32] */
static EIF_TYPE_INDEX ptf620[] = {608,1117,0xFFFF};
static struct eif_par_types par620 = {620, ptf620, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [REAL_64] */
static EIF_TYPE_INDEX ptf621[] = {609,1120,0xFFFF};
static struct eif_par_types par621 = {621, ptf621, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [G#1] */
static EIF_TYPE_INDEX ptf622[] = {610,0xFFF8,1,0xFFFF};
static struct eif_par_types par622 = {622, ptf622, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [INTEGER_32] */
static EIF_TYPE_INDEX ptf623[] = {611,1096,0xFFFF};
static struct eif_par_types par623 = {623, ptf623, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [BOOLEAN] */
static EIF_TYPE_INDEX ptf624[] = {612,1129,0xFFFF};
static struct eif_par_types par624 = {624, ptf624, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [NATURAL_64] */
static EIF_TYPE_INDEX ptf625[] = {615,1105,0xFFFF};
static struct eif_par_types par625 = {625, ptf625, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [NATURAL_32] */
static EIF_TYPE_INDEX ptf626[] = {616,1108,0xFFFF};
static struct eif_par_types par626 = {626, ptf626, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [NATURAL_16] */
static EIF_TYPE_INDEX ptf627[] = {617,1111,0xFFFF};
static struct eif_par_types par627 = {627, ptf627, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [NATURAL_8] */
static EIF_TYPE_INDEX ptf628[] = {618,1114,0xFFFF};
static struct eif_par_types par628 = {628, ptf628, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf629[] = {614,1123,0xFFFF};
static struct eif_par_types par629 = {629, ptf629, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf630[] = {613,1126,0xFFFF};
static struct eif_par_types par630 = {630, ptf630, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [POINTER] */
static EIF_TYPE_INDEX ptf631[] = {619,1174,0xFFFF};
static struct eif_par_types par631 = {631, ptf631, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [REAL_32] */
static EIF_TYPE_INDEX ptf632[] = {620,1117,0xFFFF};
static struct eif_par_types par632 = {632, ptf632, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [REAL_64] */
static EIF_TYPE_INDEX ptf633[] = {621,1120,0xFFFF};
static struct eif_par_types par633 = {633, ptf633, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [G#1] */
static EIF_TYPE_INDEX ptf634[] = {586,0xFFF8,1,0xFFFF};
static struct eif_par_types par634 = {634, ptf634, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [INTEGER_32] */
static EIF_TYPE_INDEX ptf635[] = {587,1096,0xFFFF};
static struct eif_par_types par635 = {635, ptf635, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [BOOLEAN] */
static EIF_TYPE_INDEX ptf636[] = {588,1129,0xFFFF};
static struct eif_par_types par636 = {636, ptf636, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [CHARACTER_8] */
static EIF_TYPE_INDEX ptf637[] = {589,1126,0xFFFF};
static struct eif_par_types par637 = {637, ptf637, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [CHARACTER_32] */
static EIF_TYPE_INDEX ptf638[] = {590,1123,0xFFFF};
static struct eif_par_types par638 = {638, ptf638, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [NATURAL_64] */
static EIF_TYPE_INDEX ptf639[] = {591,1105,0xFFFF};
static struct eif_par_types par639 = {639, ptf639, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [NATURAL_32] */
static EIF_TYPE_INDEX ptf640[] = {592,1108,0xFFFF};
static struct eif_par_types par640 = {640, ptf640, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [NATURAL_16] */
static EIF_TYPE_INDEX ptf641[] = {593,1111,0xFFFF};
static struct eif_par_types par641 = {641, ptf641, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [NATURAL_8] */
static EIF_TYPE_INDEX ptf642[] = {594,1114,0xFFFF};
static struct eif_par_types par642 = {642, ptf642, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [POINTER] */
static EIF_TYPE_INDEX ptf643[] = {595,1174,0xFFFF};
static struct eif_par_types par643 = {643, ptf643, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [REAL_32] */
static EIF_TYPE_INDEX ptf644[] = {596,1117,0xFFFF};
static struct eif_par_types par644 = {644, ptf644, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [REAL_64] */
static EIF_TYPE_INDEX ptf645[] = {597,1120,0xFFFF};
static struct eif_par_types par645 = {645, ptf645, (uint16) 1, (uint16) 1, (char) 0};

/* SET [INTEGER_32] */
static EIF_TYPE_INDEX ptf646[] = {635,1096,0xFFFF};
static struct eif_par_types par646 = {646, ptf646, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [G#1] */
static EIF_TYPE_INDEX ptf647[] = {634,0xFFF8,1,0xFFFF};
static struct eif_par_types par647 = {647, ptf647, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [INTEGER_32] */
static EIF_TYPE_INDEX ptf648[] = {635,1096,0xFFFF};
static struct eif_par_types par648 = {648, ptf648, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [BOOLEAN] */
static EIF_TYPE_INDEX ptf649[] = {636,1129,0xFFFF};
static struct eif_par_types par649 = {649, ptf649, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [CHARACTER_8] */
static EIF_TYPE_INDEX ptf650[] = {637,1126,0xFFFF};
static struct eif_par_types par650 = {650, ptf650, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [CHARACTER_32] */
static EIF_TYPE_INDEX ptf651[] = {638,1123,0xFFFF};
static struct eif_par_types par651 = {651, ptf651, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [NATURAL_64] */
static EIF_TYPE_INDEX ptf652[] = {639,1105,0xFFFF};
static struct eif_par_types par652 = {652, ptf652, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [NATURAL_32] */
static EIF_TYPE_INDEX ptf653[] = {640,1108,0xFFFF};
static struct eif_par_types par653 = {653, ptf653, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [NATURAL_16] */
static EIF_TYPE_INDEX ptf654[] = {641,1111,0xFFFF};
static struct eif_par_types par654 = {654, ptf654, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [NATURAL_8] */
static EIF_TYPE_INDEX ptf655[] = {642,1114,0xFFFF};
static struct eif_par_types par655 = {655, ptf655, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [POINTER] */
static EIF_TYPE_INDEX ptf656[] = {643,1174,0xFFFF};
static struct eif_par_types par656 = {656, ptf656, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [REAL_32] */
static EIF_TYPE_INDEX ptf657[] = {644,1117,0xFFFF};
static struct eif_par_types par657 = {657, ptf657, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [REAL_64] */
static EIF_TYPE_INDEX ptf658[] = {645,1120,0xFFFF};
static struct eif_par_types par658 = {658, ptf658, (uint16) 1, (uint16) 1, (char) 0};

/* TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf659[] = {647,0xFFF8,1,0xFFFF};
static struct eif_par_types par659 = {659, ptf659, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf660[] = {647,0xFFF8,1,0xFFFF};
static struct eif_par_types par660 = {660, ptf660, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf661[] = {648,1096,0xFFFF};
static struct eif_par_types par661 = {661, ptf661, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf662[] = {648,1096,0xFFFF};
static struct eif_par_types par662 = {662, ptf662, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [BOOLEAN, INTEGER_32] */
static EIF_TYPE_INDEX ptf663[] = {649,1129,0xFFFF};
static struct eif_par_types par663 = {663, ptf663, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [CHARACTER_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf664[] = {650,1126,0xFFFF};
static struct eif_par_types par664 = {664, ptf664, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [CHARACTER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf665[] = {651,1123,0xFFFF};
static struct eif_par_types par665 = {665, ptf665, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [NATURAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf666[] = {652,1105,0xFFFF};
static struct eif_par_types par666 = {666, ptf666, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [NATURAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf667[] = {653,1108,0xFFFF};
static struct eif_par_types par667 = {667, ptf667, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [NATURAL_16, INTEGER_32] */
static EIF_TYPE_INDEX ptf668[] = {654,1111,0xFFFF};
static struct eif_par_types par668 = {668, ptf668, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [NATURAL_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf669[] = {655,1114,0xFFFF};
static struct eif_par_types par669 = {669, ptf669, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [POINTER, G#2] */
static EIF_TYPE_INDEX ptf670[] = {656,1174,0xFFFF};
static struct eif_par_types par670 = {670, ptf670, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [POINTER, INTEGER_32] */
static EIF_TYPE_INDEX ptf671[] = {656,1174,0xFFFF};
static struct eif_par_types par671 = {671, ptf671, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [REAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf672[] = {657,1117,0xFFFF};
static struct eif_par_types par672 = {672, ptf672, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [REAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf673[] = {658,1120,0xFFFF};
static struct eif_par_types par673 = {673, ptf673, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf674[] = {659,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par674 = {674, ptf674, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf675[] = {660,0xFFF8,1,1096,0xFFFF};
static struct eif_par_types par675 = {675, ptf675, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf676[] = {661,1096,0xFFF8,2,0xFFFF};
static struct eif_par_types par676 = {676, ptf676, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf677[] = {662,1096,1096,0xFFFF};
static struct eif_par_types par677 = {677, ptf677, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [BOOLEAN, INTEGER_32] */
static EIF_TYPE_INDEX ptf678[] = {663,1129,1096,0xFFFF};
static struct eif_par_types par678 = {678, ptf678, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [NATURAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf679[] = {666,1105,1096,0xFFFF};
static struct eif_par_types par679 = {679, ptf679, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [NATURAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf680[] = {667,1108,1096,0xFFFF};
static struct eif_par_types par680 = {680, ptf680, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [NATURAL_16, INTEGER_32] */
static EIF_TYPE_INDEX ptf681[] = {668,1111,1096,0xFFFF};
static struct eif_par_types par681 = {681, ptf681, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [NATURAL_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf682[] = {669,1114,1096,0xFFFF};
static struct eif_par_types par682 = {682, ptf682, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [CHARACTER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf683[] = {665,1123,1096,0xFFFF};
static struct eif_par_types par683 = {683, ptf683, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [CHARACTER_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf684[] = {664,1126,1096,0xFFFF};
static struct eif_par_types par684 = {684, ptf684, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [POINTER, G#2] */
static EIF_TYPE_INDEX ptf685[] = {670,1174,0xFFF8,2,0xFFFF};
static struct eif_par_types par685 = {685, ptf685, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [POINTER, INTEGER_32] */
static EIF_TYPE_INDEX ptf686[] = {671,1174,1096,0xFFFF};
static struct eif_par_types par686 = {686, ptf686, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [REAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf687[] = {672,1117,1096,0xFFFF};
static struct eif_par_types par687 = {687, ptf687, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [REAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf688[] = {673,1120,1096,0xFFFF};
static struct eif_par_types par688 = {688, ptf688, (uint16) 1, (uint16) 2, (char) 0};

/* ACTIVE [G#1] */
static EIF_TYPE_INDEX ptf689[] = {647,0xFFF8,1,0xFFFF};
static struct eif_par_types par689 = {689, ptf689, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [INTEGER_32] */
static EIF_TYPE_INDEX ptf690[] = {648,1096,0xFFFF};
static struct eif_par_types par690 = {690, ptf690, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [BOOLEAN] */
static EIF_TYPE_INDEX ptf691[] = {649,1129,0xFFFF};
static struct eif_par_types par691 = {691, ptf691, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf692[] = {650,1126,0xFFFF};
static struct eif_par_types par692 = {692, ptf692, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf693[] = {651,1123,0xFFFF};
static struct eif_par_types par693 = {693, ptf693, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [NATURAL_64] */
static EIF_TYPE_INDEX ptf694[] = {652,1105,0xFFFF};
static struct eif_par_types par694 = {694, ptf694, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [NATURAL_32] */
static EIF_TYPE_INDEX ptf695[] = {653,1108,0xFFFF};
static struct eif_par_types par695 = {695, ptf695, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [NATURAL_16] */
static EIF_TYPE_INDEX ptf696[] = {654,1111,0xFFFF};
static struct eif_par_types par696 = {696, ptf696, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [NATURAL_8] */
static EIF_TYPE_INDEX ptf697[] = {655,1114,0xFFFF};
static struct eif_par_types par697 = {697, ptf697, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [POINTER] */
static EIF_TYPE_INDEX ptf698[] = {656,1174,0xFFFF};
static struct eif_par_types par698 = {698, ptf698, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [REAL_32] */
static EIF_TYPE_INDEX ptf699[] = {657,1117,0xFFFF};
static struct eif_par_types par699 = {699, ptf699, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [REAL_64] */
static EIF_TYPE_INDEX ptf700[] = {658,1120,0xFFFF};
static struct eif_par_types par700 = {700, ptf700, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [G#1] */
static EIF_TYPE_INDEX ptf701[] = {689,0xFFF8,1,0xFFFF};
static struct eif_par_types par701 = {701, ptf701, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [INTEGER_32] */
static EIF_TYPE_INDEX ptf702[] = {690,1096,0xFFFF};
static struct eif_par_types par702 = {702, ptf702, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [BOOLEAN] */
static EIF_TYPE_INDEX ptf703[] = {691,1129,0xFFFF};
static struct eif_par_types par703 = {703, ptf703, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf704[] = {692,1126,0xFFFF};
static struct eif_par_types par704 = {704, ptf704, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf705[] = {693,1123,0xFFFF};
static struct eif_par_types par705 = {705, ptf705, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [NATURAL_64] */
static EIF_TYPE_INDEX ptf706[] = {694,1105,0xFFFF};
static struct eif_par_types par706 = {706, ptf706, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [NATURAL_32] */
static EIF_TYPE_INDEX ptf707[] = {695,1108,0xFFFF};
static struct eif_par_types par707 = {707, ptf707, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [NATURAL_16] */
static EIF_TYPE_INDEX ptf708[] = {696,1111,0xFFFF};
static struct eif_par_types par708 = {708, ptf708, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [NATURAL_8] */
static EIF_TYPE_INDEX ptf709[] = {697,1114,0xFFFF};
static struct eif_par_types par709 = {709, ptf709, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [POINTER] */
static EIF_TYPE_INDEX ptf710[] = {698,1174,0xFFFF};
static struct eif_par_types par710 = {710, ptf710, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [REAL_32] */
static EIF_TYPE_INDEX ptf711[] = {699,1117,0xFFFF};
static struct eif_par_types par711 = {711, ptf711, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [REAL_64] */
static EIF_TYPE_INDEX ptf712[] = {700,1120,0xFFFF};
static struct eif_par_types par712 = {712, ptf712, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [G#1] */
static EIF_TYPE_INDEX ptf713[] = {586,0xFFF8,1,0xFFFF};
static struct eif_par_types par713 = {713, ptf713, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [INTEGER_32] */
static EIF_TYPE_INDEX ptf714[] = {587,1096,0xFFFF};
static struct eif_par_types par714 = {714, ptf714, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [BOOLEAN] */
static EIF_TYPE_INDEX ptf715[] = {588,1129,0xFFFF};
static struct eif_par_types par715 = {715, ptf715, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [CHARACTER_8] */
static EIF_TYPE_INDEX ptf716[] = {589,1126,0xFFFF};
static struct eif_par_types par716 = {716, ptf716, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [CHARACTER_32] */
static EIF_TYPE_INDEX ptf717[] = {590,1123,0xFFFF};
static struct eif_par_types par717 = {717, ptf717, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [NATURAL_64] */
static EIF_TYPE_INDEX ptf718[] = {591,1105,0xFFFF};
static struct eif_par_types par718 = {718, ptf718, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [NATURAL_32] */
static EIF_TYPE_INDEX ptf719[] = {592,1108,0xFFFF};
static struct eif_par_types par719 = {719, ptf719, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [NATURAL_16] */
static EIF_TYPE_INDEX ptf720[] = {593,1111,0xFFFF};
static struct eif_par_types par720 = {720, ptf720, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [NATURAL_8] */
static EIF_TYPE_INDEX ptf721[] = {594,1114,0xFFFF};
static struct eif_par_types par721 = {721, ptf721, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [POINTER] */
static EIF_TYPE_INDEX ptf722[] = {595,1174,0xFFFF};
static struct eif_par_types par722 = {722, ptf722, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [REAL_32] */
static EIF_TYPE_INDEX ptf723[] = {596,1117,0xFFFF};
static struct eif_par_types par723 = {723, ptf723, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [REAL_64] */
static EIF_TYPE_INDEX ptf724[] = {597,1120,0xFFFF};
static struct eif_par_types par724 = {724, ptf724, (uint16) 1, (uint16) 1, (char) 0};

/* INFINITE [INTEGER_32] */
static EIF_TYPE_INDEX ptf725[] = {714,1096,0xFFFF};
static struct eif_par_types par725 = {725, ptf725, (uint16) 1, (uint16) 1, (char) 0};

/* COUNTABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf726[] = {725,1096,0xFFFF};
static struct eif_par_types par726 = {726, ptf726, (uint16) 1, (uint16) 1, (char) 0};

/* COUNTABLE_SEQUENCE [INTEGER_32] */
static EIF_TYPE_INDEX ptf727[] = {726,1096,0xFFF7,611,1096,0xFFFF};
static struct eif_par_types par727 = {727, ptf727, (uint16) 2, (uint16) 1, (char) 0};

/* PRIMES */
static EIF_TYPE_INDEX ptf728[] = {727,1096,0xFFF7,431,1096,0xFFFF};
static struct eif_par_types par728 = {728, ptf728, (uint16) 2, (uint16) 0, (char) 0};

/* FINITE [G#1] */
static EIF_TYPE_INDEX ptf729[] = {713,0xFFF8,1,0xFFFF};
static struct eif_par_types par729 = {729, ptf729, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [INTEGER_32] */
static EIF_TYPE_INDEX ptf730[] = {714,1096,0xFFFF};
static struct eif_par_types par730 = {730, ptf730, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [BOOLEAN] */
static EIF_TYPE_INDEX ptf731[] = {715,1129,0xFFFF};
static struct eif_par_types par731 = {731, ptf731, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf732[] = {716,1126,0xFFFF};
static struct eif_par_types par732 = {732, ptf732, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf733[] = {717,1123,0xFFFF};
static struct eif_par_types par733 = {733, ptf733, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [NATURAL_64] */
static EIF_TYPE_INDEX ptf734[] = {718,1105,0xFFFF};
static struct eif_par_types par734 = {734, ptf734, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [NATURAL_32] */
static EIF_TYPE_INDEX ptf735[] = {719,1108,0xFFFF};
static struct eif_par_types par735 = {735, ptf735, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [NATURAL_16] */
static EIF_TYPE_INDEX ptf736[] = {720,1111,0xFFFF};
static struct eif_par_types par736 = {736, ptf736, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [NATURAL_8] */
static EIF_TYPE_INDEX ptf737[] = {721,1114,0xFFFF};
static struct eif_par_types par737 = {737, ptf737, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [POINTER] */
static EIF_TYPE_INDEX ptf738[] = {722,1174,0xFFFF};
static struct eif_par_types par738 = {738, ptf738, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [REAL_32] */
static EIF_TYPE_INDEX ptf739[] = {723,1117,0xFFFF};
static struct eif_par_types par739 = {739, ptf739, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [REAL_64] */
static EIF_TYPE_INDEX ptf740[] = {724,1120,0xFFFF};
static struct eif_par_types par740 = {740, ptf740, (uint16) 1, (uint16) 1, (char) 0};

/* DISPENSER [G#1] */
static EIF_TYPE_INDEX ptf741[] = {689,0xFFF8,1,0xFFF7,729,0xFFF8,1,0xFFFF};
static struct eif_par_types par741 = {741, ptf741, (uint16) 2, (uint16) 1, (char) 0};

/* QUEUE [G#1] */
static EIF_TYPE_INDEX ptf742[] = {741,0xFFF8,1,0xFFFF};
static struct eif_par_types par742 = {742, ptf742, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [G#1] */
static EIF_TYPE_INDEX ptf743[] = {729,0xFFF8,1,0xFFFF};
static struct eif_par_types par743 = {743, ptf743, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [INTEGER_32] */
static EIF_TYPE_INDEX ptf744[] = {730,1096,0xFFFF};
static struct eif_par_types par744 = {744, ptf744, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [BOOLEAN] */
static EIF_TYPE_INDEX ptf745[] = {731,1129,0xFFFF};
static struct eif_par_types par745 = {745, ptf745, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [NATURAL_64] */
static EIF_TYPE_INDEX ptf746[] = {734,1105,0xFFFF};
static struct eif_par_types par746 = {746, ptf746, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [NATURAL_32] */
static EIF_TYPE_INDEX ptf747[] = {735,1108,0xFFFF};
static struct eif_par_types par747 = {747, ptf747, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [NATURAL_16] */
static EIF_TYPE_INDEX ptf748[] = {736,1111,0xFFFF};
static struct eif_par_types par748 = {748, ptf748, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [NATURAL_8] */
static EIF_TYPE_INDEX ptf749[] = {737,1114,0xFFFF};
static struct eif_par_types par749 = {749, ptf749, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [CHARACTER_32] */
static EIF_TYPE_INDEX ptf750[] = {733,1123,0xFFFF};
static struct eif_par_types par750 = {750, ptf750, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [CHARACTER_8] */
static EIF_TYPE_INDEX ptf751[] = {732,1126,0xFFFF};
static struct eif_par_types par751 = {751, ptf751, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [POINTER] */
static EIF_TYPE_INDEX ptf752[] = {738,1174,0xFFFF};
static struct eif_par_types par752 = {752, ptf752, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [REAL_32] */
static EIF_TYPE_INDEX ptf753[] = {739,1117,0xFFFF};
static struct eif_par_types par753 = {753, ptf753, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [REAL_64] */
static EIF_TYPE_INDEX ptf754[] = {740,1120,0xFFFF};
static struct eif_par_types par754 = {754, ptf754, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [G#1] */
static EIF_TYPE_INDEX ptf755[] = {743,0xFFF8,1,0xFFFF};
static struct eif_par_types par755 = {755, ptf755, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf756[] = {744,1096,0xFFFF};
static struct eif_par_types par756 = {756, ptf756, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf757[] = {745,1129,0xFFFF};
static struct eif_par_types par757 = {757, ptf757, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf758[] = {746,1105,0xFFFF};
static struct eif_par_types par758 = {758, ptf758, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf759[] = {747,1108,0xFFFF};
static struct eif_par_types par759 = {759, ptf759, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [NATURAL_16] */
static EIF_TYPE_INDEX ptf760[] = {748,1111,0xFFFF};
static struct eif_par_types par760 = {760, ptf760, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf761[] = {749,1114,0xFFFF};
static struct eif_par_types par761 = {761, ptf761, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf762[] = {750,1123,0xFFFF};
static struct eif_par_types par762 = {762, ptf762, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf763[] = {751,1126,0xFFFF};
static struct eif_par_types par763 = {763, ptf763, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [POINTER] */
static EIF_TYPE_INDEX ptf764[] = {752,1174,0xFFFF};
static struct eif_par_types par764 = {764, ptf764, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [REAL_32] */
static EIF_TYPE_INDEX ptf765[] = {753,1117,0xFFFF};
static struct eif_par_types par765 = {765, ptf765, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [REAL_64] */
static EIF_TYPE_INDEX ptf766[] = {754,1120,0xFFFF};
static struct eif_par_types par766 = {766, ptf766, (uint16) 1, (uint16) 1, (char) 0};

/* SEQUENCE [G#1] */
static EIF_TYPE_INDEX ptf767[] = {689,0xFFF8,1,0xFFF7,622,0xFFF8,1,0xFFF7,729,0xFFF8,1,0xFFFF};
static struct eif_par_types par767 = {767, ptf767, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [INTEGER_32] */
static EIF_TYPE_INDEX ptf768[] = {690,1096,0xFFF7,623,1096,0xFFF7,730,1096,0xFFFF};
static struct eif_par_types par768 = {768, ptf768, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [BOOLEAN] */
static EIF_TYPE_INDEX ptf769[] = {691,1129,0xFFF7,624,1129,0xFFF7,731,1129,0xFFFF};
static struct eif_par_types par769 = {769, ptf769, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [NATURAL_64] */
static EIF_TYPE_INDEX ptf770[] = {694,1105,0xFFF7,625,1105,0xFFF7,734,1105,0xFFFF};
static struct eif_par_types par770 = {770, ptf770, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [NATURAL_32] */
static EIF_TYPE_INDEX ptf771[] = {695,1108,0xFFF7,626,1108,0xFFF7,735,1108,0xFFFF};
static struct eif_par_types par771 = {771, ptf771, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [NATURAL_16] */
static EIF_TYPE_INDEX ptf772[] = {696,1111,0xFFF7,627,1111,0xFFF7,736,1111,0xFFFF};
static struct eif_par_types par772 = {772, ptf772, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [NATURAL_8] */
static EIF_TYPE_INDEX ptf773[] = {697,1114,0xFFF7,628,1114,0xFFF7,737,1114,0xFFFF};
static struct eif_par_types par773 = {773, ptf773, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf774[] = {693,1123,0xFFF7,629,1123,0xFFF7,733,1123,0xFFFF};
static struct eif_par_types par774 = {774, ptf774, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf775[] = {692,1126,0xFFF7,630,1126,0xFFF7,732,1126,0xFFFF};
static struct eif_par_types par775 = {775, ptf775, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [POINTER] */
static EIF_TYPE_INDEX ptf776[] = {698,1174,0xFFF7,631,1174,0xFFF7,738,1174,0xFFFF};
static struct eif_par_types par776 = {776, ptf776, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [REAL_32] */
static EIF_TYPE_INDEX ptf777[] = {699,1117,0xFFF7,632,1117,0xFFF7,739,1117,0xFFFF};
static struct eif_par_types par777 = {777, ptf777, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [REAL_64] */
static EIF_TYPE_INDEX ptf778[] = {700,1120,0xFFF7,633,1120,0xFFF7,740,1120,0xFFFF};
static struct eif_par_types par778 = {778, ptf778, (uint16) 3, (uint16) 1, (char) 0};

/* UNBOUNDED [G#1] */
static EIF_TYPE_INDEX ptf779[] = {729,0xFFF8,1,0xFFFF};
static struct eif_par_types par779 = {779, ptf779, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [INTEGER_32] */
static EIF_TYPE_INDEX ptf780[] = {730,1096,0xFFFF};
static struct eif_par_types par780 = {780, ptf780, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [BOOLEAN] */
static EIF_TYPE_INDEX ptf781[] = {731,1129,0xFFFF};
static struct eif_par_types par781 = {781, ptf781, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [NATURAL_64] */
static EIF_TYPE_INDEX ptf782[] = {734,1105,0xFFFF};
static struct eif_par_types par782 = {782, ptf782, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [NATURAL_32] */
static EIF_TYPE_INDEX ptf783[] = {735,1108,0xFFFF};
static struct eif_par_types par783 = {783, ptf783, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [NATURAL_16] */
static EIF_TYPE_INDEX ptf784[] = {736,1111,0xFFFF};
static struct eif_par_types par784 = {784, ptf784, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [NATURAL_8] */
static EIF_TYPE_INDEX ptf785[] = {737,1114,0xFFFF};
static struct eif_par_types par785 = {785, ptf785, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [CHARACTER_32] */
static EIF_TYPE_INDEX ptf786[] = {733,1123,0xFFFF};
static struct eif_par_types par786 = {786, ptf786, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [CHARACTER_8] */
static EIF_TYPE_INDEX ptf787[] = {732,1126,0xFFFF};
static struct eif_par_types par787 = {787, ptf787, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [POINTER] */
static EIF_TYPE_INDEX ptf788[] = {738,1174,0xFFFF};
static struct eif_par_types par788 = {788, ptf788, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [REAL_32] */
static EIF_TYPE_INDEX ptf789[] = {739,1117,0xFFFF};
static struct eif_par_types par789 = {789, ptf789, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [REAL_64] */
static EIF_TYPE_INDEX ptf790[] = {740,1120,0xFFFF};
static struct eif_par_types par790 = {790, ptf790, (uint16) 1, (uint16) 1, (char) 0};

/* FILE */
static EIF_TYPE_INDEX ptf791[] = {787,1126,0xFFF7,775,1126,0xFFF7,429,0xFFF7,418,0xFFFF};
static struct eif_par_types par791 = {791, ptf791, (uint16) 4, (uint16) 0, (char) 0};

/* RAW_FILE */
static EIF_TYPE_INDEX ptf792[] = {791,0xFFFF};
static struct eif_par_types par792 = {792, ptf792, (uint16) 1, (uint16) 0, (char) 0};

/* PLAIN_TEXT_FILE */
static EIF_TYPE_INDEX ptf793[] = {791,0xFFFF};
static struct eif_par_types par793 = {793, ptf793, (uint16) 1, (uint16) 0, (char) 0};

/* READABLE_INDEXABLE [G#1] */
static EIF_TYPE_INDEX ptf794[] = {472,0xFFF8,1,0xFFFF};
static struct eif_par_types par794 = {794, ptf794, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf795[] = {473,1096,0xFFFF};
static struct eif_par_types par795 = {795, ptf795, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf796[] = {474,1129,0xFFFF};
static struct eif_par_types par796 = {796, ptf796, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf797[] = {475,1126,0xFFFF};
static struct eif_par_types par797 = {797, ptf797, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf798[] = {476,1123,0xFFFF};
static struct eif_par_types par798 = {798, ptf798, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf799[] = {477,1105,0xFFFF};
static struct eif_par_types par799 = {799, ptf799, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf800[] = {478,1108,0xFFFF};
static struct eif_par_types par800 = {800, ptf800, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [NATURAL_16] */
static EIF_TYPE_INDEX ptf801[] = {479,1111,0xFFFF};
static struct eif_par_types par801 = {801, ptf801, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf802[] = {480,1114,0xFFFF};
static struct eif_par_types par802 = {802, ptf802, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [POINTER] */
static EIF_TYPE_INDEX ptf803[] = {481,1174,0xFFFF};
static struct eif_par_types par803 = {803, ptf803, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [REAL_32] */
static EIF_TYPE_INDEX ptf804[] = {482,1117,0xFFFF};
static struct eif_par_types par804 = {804, ptf804, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [REAL_64] */
static EIF_TYPE_INDEX ptf805[] = {483,1120,0xFFFF};
static struct eif_par_types par805 = {805, ptf805, (uint16) 1, (uint16) 1, (char) 0};

/* INDEXABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf806[] = {660,0xFFF8,1,1096,0xFFF7,794,0xFFF8,1,0xFFFF};
static struct eif_par_types par806 = {806, ptf806, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf807[] = {662,1096,1096,0xFFF7,795,1096,0xFFFF};
static struct eif_par_types par807 = {807, ptf807, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [BOOLEAN, INTEGER_32] */
static EIF_TYPE_INDEX ptf808[] = {663,1129,1096,0xFFF7,796,1129,0xFFFF};
static struct eif_par_types par808 = {808, ptf808, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [CHARACTER_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf809[] = {664,1126,1096,0xFFF7,797,1126,0xFFFF};
static struct eif_par_types par809 = {809, ptf809, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [CHARACTER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf810[] = {665,1123,1096,0xFFF7,798,1123,0xFFFF};
static struct eif_par_types par810 = {810, ptf810, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [NATURAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf811[] = {666,1105,1096,0xFFF7,799,1105,0xFFFF};
static struct eif_par_types par811 = {811, ptf811, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [NATURAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf812[] = {667,1108,1096,0xFFF7,800,1108,0xFFFF};
static struct eif_par_types par812 = {812, ptf812, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [NATURAL_16, INTEGER_32] */
static EIF_TYPE_INDEX ptf813[] = {668,1111,1096,0xFFF7,801,1111,0xFFFF};
static struct eif_par_types par813 = {813, ptf813, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [NATURAL_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf814[] = {669,1114,1096,0xFFF7,802,1114,0xFFFF};
static struct eif_par_types par814 = {814, ptf814, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [POINTER, INTEGER_32] */
static EIF_TYPE_INDEX ptf815[] = {671,1174,1096,0xFFF7,803,1174,0xFFFF};
static struct eif_par_types par815 = {815, ptf815, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [REAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf816[] = {672,1117,1096,0xFFF7,804,1117,0xFFFF};
static struct eif_par_types par816 = {816, ptf816, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [REAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf817[] = {673,1120,1096,0xFFF7,805,1120,0xFFFF};
static struct eif_par_types par817 = {817, ptf817, (uint16) 2, (uint16) 2, (char) 0};

/* INTEGER_INTERVAL */
static EIF_TYPE_INDEX ptf818[] = {756,1096,0xFFF7,807,1096,1096,0xFFF7,646,1096,0xFFFF};
static struct eif_par_types par818 = {818, ptf818, (uint16) 3, (uint16) 0, (char) 0};

/* ARRAY [G#1] */
static EIF_TYPE_INDEX ptf819[] = {755,0xFFF8,1,0xFFF7,806,0xFFF8,1,1096,0xFFF7,403,0xFFF8,1,0xFFFF};
static struct eif_par_types par819 = {819, ptf819, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [INTEGER_32] */
static EIF_TYPE_INDEX ptf820[] = {756,1096,0xFFF7,807,1096,1096,0xFFF7,404,1096,0xFFFF};
static struct eif_par_types par820 = {820, ptf820, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [BOOLEAN] */
static EIF_TYPE_INDEX ptf821[] = {757,1129,0xFFF7,808,1129,1096,0xFFF7,405,1129,0xFFFF};
static struct eif_par_types par821 = {821, ptf821, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [NATURAL_64] */
static EIF_TYPE_INDEX ptf822[] = {758,1105,0xFFF7,811,1105,1096,0xFFF7,406,1105,0xFFFF};
static struct eif_par_types par822 = {822, ptf822, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [NATURAL_32] */
static EIF_TYPE_INDEX ptf823[] = {759,1108,0xFFF7,812,1108,1096,0xFFF7,407,1108,0xFFFF};
static struct eif_par_types par823 = {823, ptf823, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [NATURAL_16] */
static EIF_TYPE_INDEX ptf824[] = {760,1111,0xFFF7,813,1111,1096,0xFFF7,408,1111,0xFFFF};
static struct eif_par_types par824 = {824, ptf824, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [NATURAL_8] */
static EIF_TYPE_INDEX ptf825[] = {761,1114,0xFFF7,814,1114,1096,0xFFF7,409,1114,0xFFFF};
static struct eif_par_types par825 = {825, ptf825, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [CHARACTER_32] */
static EIF_TYPE_INDEX ptf826[] = {762,1123,0xFFF7,810,1123,1096,0xFFF7,410,1123,0xFFFF};
static struct eif_par_types par826 = {826, ptf826, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [CHARACTER_8] */
static EIF_TYPE_INDEX ptf827[] = {763,1126,0xFFF7,809,1126,1096,0xFFF7,411,1126,0xFFFF};
static struct eif_par_types par827 = {827, ptf827, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [POINTER] */
static EIF_TYPE_INDEX ptf828[] = {764,1174,0xFFF7,815,1174,1096,0xFFF7,412,1174,0xFFFF};
static struct eif_par_types par828 = {828, ptf828, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [REAL_32] */
static EIF_TYPE_INDEX ptf829[] = {765,1117,0xFFF7,816,1117,1096,0xFFF7,413,1117,0xFFFF};
static struct eif_par_types par829 = {829, ptf829, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [REAL_64] */
static EIF_TYPE_INDEX ptf830[] = {766,1120,0xFFF7,817,1120,1096,0xFFF7,414,1120,0xFFFF};
static struct eif_par_types par830 = {830, ptf830, (uint16) 3, (uint16) 1, (char) 0};

/* KL_ARRAY [G#1] */
static EIF_TYPE_INDEX ptf831[] = {819,0xFFF8,1,0xFFFF};
static struct eif_par_types par831 = {831, ptf831, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [INTEGER_32] */
static EIF_TYPE_INDEX ptf832[] = {820,1096,0xFFFF};
static struct eif_par_types par832 = {832, ptf832, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [BOOLEAN] */
static EIF_TYPE_INDEX ptf833[] = {821,1129,0xFFFF};
static struct eif_par_types par833 = {833, ptf833, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [NATURAL_64] */
static EIF_TYPE_INDEX ptf834[] = {822,1105,0xFFFF};
static struct eif_par_types par834 = {834, ptf834, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [NATURAL_32] */
static EIF_TYPE_INDEX ptf835[] = {823,1108,0xFFFF};
static struct eif_par_types par835 = {835, ptf835, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [NATURAL_8] */
static EIF_TYPE_INDEX ptf836[] = {825,1114,0xFFFF};
static struct eif_par_types par836 = {836, ptf836, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [CHARACTER_8] */
static EIF_TYPE_INDEX ptf837[] = {827,1126,0xFFFF};
static struct eif_par_types par837 = {837, ptf837, (uint16) 1, (uint16) 1, (char) 0};

/* CHAIN [G#1] */
static EIF_TYPE_INDEX ptf838[] = {701,0xFFF8,1,0xFFF7,806,0xFFF8,1,1096,0xFFF7,767,0xFFF8,1,0xFFFF};
static struct eif_par_types par838 = {838, ptf838, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [INTEGER_32] */
static EIF_TYPE_INDEX ptf839[] = {702,1096,0xFFF7,807,1096,1096,0xFFF7,768,1096,0xFFFF};
static struct eif_par_types par839 = {839, ptf839, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [BOOLEAN] */
static EIF_TYPE_INDEX ptf840[] = {703,1129,0xFFF7,808,1129,1096,0xFFF7,769,1129,0xFFFF};
static struct eif_par_types par840 = {840, ptf840, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [NATURAL_64] */
static EIF_TYPE_INDEX ptf841[] = {706,1105,0xFFF7,811,1105,1096,0xFFF7,770,1105,0xFFFF};
static struct eif_par_types par841 = {841, ptf841, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [NATURAL_32] */
static EIF_TYPE_INDEX ptf842[] = {707,1108,0xFFF7,812,1108,1096,0xFFF7,771,1108,0xFFFF};
static struct eif_par_types par842 = {842, ptf842, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [NATURAL_16] */
static EIF_TYPE_INDEX ptf843[] = {708,1111,0xFFF7,813,1111,1096,0xFFF7,772,1111,0xFFFF};
static struct eif_par_types par843 = {843, ptf843, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [NATURAL_8] */
static EIF_TYPE_INDEX ptf844[] = {709,1114,0xFFF7,814,1114,1096,0xFFF7,773,1114,0xFFFF};
static struct eif_par_types par844 = {844, ptf844, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [CHARACTER_32] */
static EIF_TYPE_INDEX ptf845[] = {705,1123,0xFFF7,810,1123,1096,0xFFF7,774,1123,0xFFFF};
static struct eif_par_types par845 = {845, ptf845, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [CHARACTER_8] */
static EIF_TYPE_INDEX ptf846[] = {704,1126,0xFFF7,809,1126,1096,0xFFF7,775,1126,0xFFFF};
static struct eif_par_types par846 = {846, ptf846, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [POINTER] */
static EIF_TYPE_INDEX ptf847[] = {710,1174,0xFFF7,815,1174,1096,0xFFF7,776,1174,0xFFFF};
static struct eif_par_types par847 = {847, ptf847, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [REAL_32] */
static EIF_TYPE_INDEX ptf848[] = {711,1117,0xFFF7,816,1117,1096,0xFFF7,777,1117,0xFFFF};
static struct eif_par_types par848 = {848, ptf848, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [REAL_64] */
static EIF_TYPE_INDEX ptf849[] = {712,1120,0xFFF7,817,1120,1096,0xFFF7,778,1120,0xFFFF};
static struct eif_par_types par849 = {849, ptf849, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [G#1] */
static EIF_TYPE_INDEX ptf850[] = {838,0xFFF8,1,0xFFF7,779,0xFFF8,1,0xFFF7,675,0xFFF8,1,1096,0xFFFF};
static struct eif_par_types par850 = {850, ptf850, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [INTEGER_32] */
static EIF_TYPE_INDEX ptf851[] = {839,1096,0xFFF7,780,1096,0xFFF7,677,1096,1096,0xFFFF};
static struct eif_par_types par851 = {851, ptf851, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [BOOLEAN] */
static EIF_TYPE_INDEX ptf852[] = {840,1129,0xFFF7,781,1129,0xFFF7,678,1129,1096,0xFFFF};
static struct eif_par_types par852 = {852, ptf852, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [NATURAL_64] */
static EIF_TYPE_INDEX ptf853[] = {841,1105,0xFFF7,782,1105,0xFFF7,679,1105,1096,0xFFFF};
static struct eif_par_types par853 = {853, ptf853, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [NATURAL_32] */
static EIF_TYPE_INDEX ptf854[] = {842,1108,0xFFF7,783,1108,0xFFF7,680,1108,1096,0xFFFF};
static struct eif_par_types par854 = {854, ptf854, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [NATURAL_16] */
static EIF_TYPE_INDEX ptf855[] = {843,1111,0xFFF7,784,1111,0xFFF7,681,1111,1096,0xFFFF};
static struct eif_par_types par855 = {855, ptf855, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [NATURAL_8] */
static EIF_TYPE_INDEX ptf856[] = {844,1114,0xFFF7,785,1114,0xFFF7,682,1114,1096,0xFFFF};
static struct eif_par_types par856 = {856, ptf856, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [CHARACTER_32] */
static EIF_TYPE_INDEX ptf857[] = {845,1123,0xFFF7,786,1123,0xFFF7,683,1123,1096,0xFFFF};
static struct eif_par_types par857 = {857, ptf857, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [CHARACTER_8] */
static EIF_TYPE_INDEX ptf858[] = {846,1126,0xFFF7,787,1126,0xFFF7,684,1126,1096,0xFFFF};
static struct eif_par_types par858 = {858, ptf858, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [POINTER] */
static EIF_TYPE_INDEX ptf859[] = {847,1174,0xFFF7,788,1174,0xFFF7,686,1174,1096,0xFFFF};
static struct eif_par_types par859 = {859, ptf859, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [REAL_32] */
static EIF_TYPE_INDEX ptf860[] = {848,1117,0xFFF7,789,1117,0xFFF7,687,1117,1096,0xFFFF};
static struct eif_par_types par860 = {860, ptf860, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [REAL_64] */
static EIF_TYPE_INDEX ptf861[] = {849,1120,0xFFF7,790,1120,0xFFF7,688,1120,1096,0xFFFF};
static struct eif_par_types par861 = {861, ptf861, (uint16) 3, (uint16) 1, (char) 0};

/* LIST [G#1] */
static EIF_TYPE_INDEX ptf862[] = {838,0xFFF8,1,0xFFFF};
static struct eif_par_types par862 = {862, ptf862, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf863[] = {839,1096,0xFFFF};
static struct eif_par_types par863 = {863, ptf863, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [BOOLEAN] */
static EIF_TYPE_INDEX ptf864[] = {840,1129,0xFFFF};
static struct eif_par_types par864 = {864, ptf864, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [NATURAL_64] */
static EIF_TYPE_INDEX ptf865[] = {841,1105,0xFFFF};
static struct eif_par_types par865 = {865, ptf865, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [NATURAL_32] */
static EIF_TYPE_INDEX ptf866[] = {842,1108,0xFFFF};
static struct eif_par_types par866 = {866, ptf866, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [NATURAL_16] */
static EIF_TYPE_INDEX ptf867[] = {843,1111,0xFFFF};
static struct eif_par_types par867 = {867, ptf867, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [NATURAL_8] */
static EIF_TYPE_INDEX ptf868[] = {844,1114,0xFFFF};
static struct eif_par_types par868 = {868, ptf868, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [CHARACTER_32] */
static EIF_TYPE_INDEX ptf869[] = {845,1123,0xFFFF};
static struct eif_par_types par869 = {869, ptf869, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [CHARACTER_8] */
static EIF_TYPE_INDEX ptf870[] = {846,1126,0xFFFF};
static struct eif_par_types par870 = {870, ptf870, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [POINTER] */
static EIF_TYPE_INDEX ptf871[] = {847,1174,0xFFFF};
static struct eif_par_types par871 = {871, ptf871, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [REAL_32] */
static EIF_TYPE_INDEX ptf872[] = {848,1117,0xFFFF};
static struct eif_par_types par872 = {872, ptf872, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [REAL_64] */
static EIF_TYPE_INDEX ptf873[] = {849,1120,0xFFFF};
static struct eif_par_types par873 = {873, ptf873, (uint16) 1, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [G#1] */
static EIF_TYPE_INDEX ptf874[] = {862,0xFFF8,1,0xFFF7,850,0xFFF8,1,0xFFFF};
static struct eif_par_types par874 = {874, ptf874, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf875[] = {863,1096,0xFFF7,851,1096,0xFFFF};
static struct eif_par_types par875 = {875, ptf875, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [BOOLEAN] */
static EIF_TYPE_INDEX ptf876[] = {864,1129,0xFFF7,852,1129,0xFFFF};
static struct eif_par_types par876 = {876, ptf876, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [NATURAL_64] */
static EIF_TYPE_INDEX ptf877[] = {865,1105,0xFFF7,853,1105,0xFFFF};
static struct eif_par_types par877 = {877, ptf877, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [NATURAL_32] */
static EIF_TYPE_INDEX ptf878[] = {866,1108,0xFFF7,854,1108,0xFFFF};
static struct eif_par_types par878 = {878, ptf878, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [NATURAL_16] */
static EIF_TYPE_INDEX ptf879[] = {867,1111,0xFFF7,855,1111,0xFFFF};
static struct eif_par_types par879 = {879, ptf879, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [NATURAL_8] */
static EIF_TYPE_INDEX ptf880[] = {868,1114,0xFFF7,856,1114,0xFFFF};
static struct eif_par_types par880 = {880, ptf880, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [CHARACTER_32] */
static EIF_TYPE_INDEX ptf881[] = {869,1123,0xFFF7,857,1123,0xFFFF};
static struct eif_par_types par881 = {881, ptf881, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [CHARACTER_8] */
static EIF_TYPE_INDEX ptf882[] = {870,1126,0xFFF7,858,1126,0xFFFF};
static struct eif_par_types par882 = {882, ptf882, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [POINTER] */
static EIF_TYPE_INDEX ptf883[] = {871,1174,0xFFF7,859,1174,0xFFFF};
static struct eif_par_types par883 = {883, ptf883, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [REAL_32] */
static EIF_TYPE_INDEX ptf884[] = {872,1117,0xFFF7,860,1117,0xFFFF};
static struct eif_par_types par884 = {884, ptf884, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [REAL_64] */
static EIF_TYPE_INDEX ptf885[] = {873,1120,0xFFF7,861,1120,0xFFFF};
static struct eif_par_types par885 = {885, ptf885, (uint16) 2, (uint16) 1, (char) 0};

/* LINKED_LIST [G#1] */
static EIF_TYPE_INDEX ptf886[] = {874,0xFFF8,1,0xFFFF};
static struct eif_par_types par886 = {886, ptf886, (uint16) 1, (uint16) 1, (char) 0};

/* LINKED_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf887[] = {875,1096,0xFFFF};
static struct eif_par_types par887 = {887, ptf887, (uint16) 1, (uint16) 1, (char) 0};

/* ET_TAIL_LIST [G#1] */
static EIF_TYPE_INDEX ptf888[] = {0,0xFFFF};
static struct eif_par_types par888 = {888, ptf888, (uint16) 1, (uint16) 1, (char) 0};

/* ET_AGENT_IMPLICIT_OPEN_ARGUMENT_LIST */
static EIF_TYPE_INDEX ptf889[] = {218,0xFFF7,888,0xFF01,1723,0xFFFF};
static struct eif_par_types par889 = {889, ptf889, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ITERATION_COMPONENT_LIST */
static EIF_TYPE_INDEX ptf890[] = {888,0xFF01,1853,0xFFFF};
static struct eif_par_types par890 = {890, ptf890, (uint16) 1, (uint16) 0, (char) 0};

/* ET_OBJECT_TEST_LIST */
static EIF_TYPE_INDEX ptf891[] = {888,0xFF01,1729,0xFFFF};
static struct eif_par_types par891 = {891, ptf891, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_TARGET_LIST */
static EIF_TYPE_INDEX ptf892[] = {888,0xFF01,377,0xFFFF};
static struct eif_par_types par892 = {892, ptf892, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_PRECURSOR_LIST */
static EIF_TYPE_INDEX ptf893[] = {888,0xFF01,1016,0xFFFF};
static struct eif_par_types par893 = {893, ptf893, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_FEATURE_LIST */
static EIF_TYPE_INDEX ptf894[] = {888,0xFF01,1015,0xFFFF};
static struct eif_par_types par894 = {894, ptf894, (uint16) 1, (uint16) 0, (char) 0};

/* ET_BASE_TYPE_LIST */
static EIF_TYPE_INDEX ptf895[] = {888,0xFF01,2017,0xFFFF};
static struct eif_par_types par895 = {895, ptf895, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_TYPE_SET_LIST */
static EIF_TYPE_INDEX ptf896[] = {888,0xFF01,380,0xFFFF};
static struct eif_par_types par896 = {896, ptf896, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TAIL_HASH_LIST [G#1] */
static EIF_TYPE_INDEX ptf897[] = {888,0xFFF8,1,0xFFF7,451,0xFFFF};
static struct eif_par_types par897 = {897, ptf897, (uint16) 2, (uint16) 1, (char) 0};

/* ET_DYNAMIC_PRIMARY_TYPE_LIST */
static EIF_TYPE_INDEX ptf898[] = {220,0xFFF7,888,0xFF01,1136,0xFFFF};
static struct eif_par_types par898 = {898, ptf898, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DYNAMIC_PRIMARY_TYPE_HASH_LIST */
static EIF_TYPE_INDEX ptf899[] = {898,0xFFF7,897,0xFF01,1136,0xFFFF};
static struct eif_par_types par899 = {899, ptf899, (uint16) 2, (uint16) 0, (char) 0};

/* DEBUG_OUTPUT */
static EIF_TYPE_INDEX ptf900[] = {0,0xFFFF};
static struct eif_par_types par900 = {900, ptf900, (uint16) 1, (uint16) 0, (char) 0};

/* RT_DBG_CALL_RECORD */
static EIF_TYPE_INDEX ptf901[] = {900,0xFFFF};
static struct eif_par_types par901 = {901, ptf901, (uint16) 1, (uint16) 0, (char) 0};

/* ABSTRACT_SPECIAL */
static EIF_TYPE_INDEX ptf902[] = {900,0xFFFF};
static struct eif_par_types par902 = {902, ptf902, (uint16) 1, (uint16) 0, (char) 0};

/* SPECIAL [G#1] */
static EIF_TYPE_INDEX ptf903[] = {902,0xFFF7,794,0xFFF8,1,0xFFFF};
static struct eif_par_types par903 = {903, ptf903, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [INTEGER_32] */
static EIF_TYPE_INDEX ptf904[] = {902,0xFFF7,795,1096,0xFFFF};
static struct eif_par_types par904 = {904, ptf904, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [BOOLEAN] */
static EIF_TYPE_INDEX ptf905[] = {902,0xFFF7,796,1129,0xFFFF};
static struct eif_par_types par905 = {905, ptf905, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [NATURAL_64] */
static EIF_TYPE_INDEX ptf906[] = {902,0xFFF7,799,1105,0xFFFF};
static struct eif_par_types par906 = {906, ptf906, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [NATURAL_32] */
static EIF_TYPE_INDEX ptf907[] = {902,0xFFF7,800,1108,0xFFFF};
static struct eif_par_types par907 = {907, ptf907, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [NATURAL_16] */
static EIF_TYPE_INDEX ptf908[] = {902,0xFFF7,801,1111,0xFFFF};
static struct eif_par_types par908 = {908, ptf908, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [NATURAL_8] */
static EIF_TYPE_INDEX ptf909[] = {902,0xFFF7,802,1114,0xFFFF};
static struct eif_par_types par909 = {909, ptf909, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [CHARACTER_32] */
static EIF_TYPE_INDEX ptf910[] = {902,0xFFF7,798,1123,0xFFFF};
static struct eif_par_types par910 = {910, ptf910, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [CHARACTER_8] */
static EIF_TYPE_INDEX ptf911[] = {902,0xFFF7,797,1126,0xFFFF};
static struct eif_par_types par911 = {911, ptf911, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [POINTER] */
static EIF_TYPE_INDEX ptf912[] = {902,0xFFF7,803,1174,0xFFFF};
static struct eif_par_types par912 = {912, ptf912, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [REAL_32] */
static EIF_TYPE_INDEX ptf913[] = {902,0xFFF7,804,1117,0xFFFF};
static struct eif_par_types par913 = {913, ptf913, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [REAL_64] */
static EIF_TYPE_INDEX ptf914[] = {902,0xFFF7,805,1120,0xFFFF};
static struct eif_par_types par914 = {914, ptf914, (uint16) 2, (uint16) 1, (char) 0};

/* RT_DBG_VALUE_RECORD */
static EIF_TYPE_INDEX ptf915[] = {900,0xFFF7,231,0xFFF7,400,0xFFFF};
static struct eif_par_types par915 = {915, ptf915, (uint16) 3, (uint16) 0, (char) 0};

/* RT_DBG_FIELD_RECORD [G#1] */
static EIF_TYPE_INDEX ptf916[] = {915,0xFFFF};
static struct eif_par_types par916 = {916, ptf916, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [REAL_64] */
static EIF_TYPE_INDEX ptf917[] = {915,0xFFFF};
static struct eif_par_types par917 = {917, ptf917, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [NATURAL_16] */
static EIF_TYPE_INDEX ptf918[] = {915,0xFFFF};
static struct eif_par_types par918 = {918, ptf918, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [NATURAL_8] */
static EIF_TYPE_INDEX ptf919[] = {915,0xFFFF};
static struct eif_par_types par919 = {919, ptf919, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [INTEGER_8] */
static EIF_TYPE_INDEX ptf920[] = {915,0xFFFF};
static struct eif_par_types par920 = {920, ptf920, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [NATURAL_64] */
static EIF_TYPE_INDEX ptf921[] = {915,0xFFFF};
static struct eif_par_types par921 = {921, ptf921, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [POINTER] */
static EIF_TYPE_INDEX ptf922[] = {915,0xFFFF};
static struct eif_par_types par922 = {922, ptf922, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [NATURAL_32] */
static EIF_TYPE_INDEX ptf923[] = {915,0xFFFF};
static struct eif_par_types par923 = {923, ptf923, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [REAL_32] */
static EIF_TYPE_INDEX ptf924[] = {915,0xFFFF};
static struct eif_par_types par924 = {924, ptf924, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [INTEGER_32] */
static EIF_TYPE_INDEX ptf925[] = {915,0xFFFF};
static struct eif_par_types par925 = {925, ptf925, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [INTEGER_16] */
static EIF_TYPE_INDEX ptf926[] = {915,0xFFFF};
static struct eif_par_types par926 = {926, ptf926, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [BOOLEAN] */
static EIF_TYPE_INDEX ptf927[] = {915,0xFFFF};
static struct eif_par_types par927 = {927, ptf927, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [CHARACTER_32] */
static EIF_TYPE_INDEX ptf928[] = {915,0xFFFF};
static struct eif_par_types par928 = {928, ptf928, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [CHARACTER_8] */
static EIF_TYPE_INDEX ptf929[] = {915,0xFFFF};
static struct eif_par_types par929 = {929, ptf929, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [INTEGER_64] */
static EIF_TYPE_INDEX ptf930[] = {915,0xFFFF};
static struct eif_par_types par930 = {930, ptf930, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [G#1] */
static EIF_TYPE_INDEX ptf931[] = {915,0xFFFF};
static struct eif_par_types par931 = {931, ptf931, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [NATURAL_32] */
static EIF_TYPE_INDEX ptf932[] = {915,0xFFFF};
static struct eif_par_types par932 = {932, ptf932, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [INTEGER_16] */
static EIF_TYPE_INDEX ptf933[] = {915,0xFFFF};
static struct eif_par_types par933 = {933, ptf933, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [INTEGER_32] */
static EIF_TYPE_INDEX ptf934[] = {915,0xFFFF};
static struct eif_par_types par934 = {934, ptf934, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [INTEGER_64] */
static EIF_TYPE_INDEX ptf935[] = {915,0xFFFF};
static struct eif_par_types par935 = {935, ptf935, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [CHARACTER_8] */
static EIF_TYPE_INDEX ptf936[] = {915,0xFFFF};
static struct eif_par_types par936 = {936, ptf936, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [POINTER] */
static EIF_TYPE_INDEX ptf937[] = {915,0xFFFF};
static struct eif_par_types par937 = {937, ptf937, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [REAL_64] */
static EIF_TYPE_INDEX ptf938[] = {915,0xFFFF};
static struct eif_par_types par938 = {938, ptf938, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [NATURAL_16] */
static EIF_TYPE_INDEX ptf939[] = {915,0xFFFF};
static struct eif_par_types par939 = {939, ptf939, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [REAL_32] */
static EIF_TYPE_INDEX ptf940[] = {915,0xFFFF};
static struct eif_par_types par940 = {940, ptf940, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [NATURAL_8] */
static EIF_TYPE_INDEX ptf941[] = {915,0xFFFF};
static struct eif_par_types par941 = {941, ptf941, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [NATURAL_64] */
static EIF_TYPE_INDEX ptf942[] = {915,0xFFFF};
static struct eif_par_types par942 = {942, ptf942, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [INTEGER_8] */
static EIF_TYPE_INDEX ptf943[] = {915,0xFFFF};
static struct eif_par_types par943 = {943, ptf943, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [CHARACTER_32] */
static EIF_TYPE_INDEX ptf944[] = {915,0xFFFF};
static struct eif_par_types par944 = {944, ptf944, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [BOOLEAN] */
static EIF_TYPE_INDEX ptf945[] = {915,0xFFFF};
static struct eif_par_types par945 = {945, ptf945, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [G#1] */
static EIF_TYPE_INDEX ptf946[] = {915,0xFFFF};
static struct eif_par_types par946 = {946, ptf946, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [NATURAL_64] */
static EIF_TYPE_INDEX ptf947[] = {915,0xFFFF};
static struct eif_par_types par947 = {947, ptf947, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [INTEGER_32] */
static EIF_TYPE_INDEX ptf948[] = {915,0xFFFF};
static struct eif_par_types par948 = {948, ptf948, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [CHARACTER_32] */
static EIF_TYPE_INDEX ptf949[] = {915,0xFFFF};
static struct eif_par_types par949 = {949, ptf949, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [NATURAL_8] */
static EIF_TYPE_INDEX ptf950[] = {915,0xFFFF};
static struct eif_par_types par950 = {950, ptf950, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [REAL_32] */
static EIF_TYPE_INDEX ptf951[] = {915,0xFFFF};
static struct eif_par_types par951 = {951, ptf951, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [NATURAL_16] */
static EIF_TYPE_INDEX ptf952[] = {915,0xFFFF};
static struct eif_par_types par952 = {952, ptf952, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [INTEGER_8] */
static EIF_TYPE_INDEX ptf953[] = {915,0xFFFF};
static struct eif_par_types par953 = {953, ptf953, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [POINTER] */
static EIF_TYPE_INDEX ptf954[] = {915,0xFFFF};
static struct eif_par_types par954 = {954, ptf954, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [REAL_64] */
static EIF_TYPE_INDEX ptf955[] = {915,0xFFFF};
static struct eif_par_types par955 = {955, ptf955, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [NATURAL_32] */
static EIF_TYPE_INDEX ptf956[] = {915,0xFFFF};
static struct eif_par_types par956 = {956, ptf956, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [INTEGER_16] */
static EIF_TYPE_INDEX ptf957[] = {915,0xFFFF};
static struct eif_par_types par957 = {957, ptf957, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [CHARACTER_8] */
static EIF_TYPE_INDEX ptf958[] = {915,0xFFFF};
static struct eif_par_types par958 = {958, ptf958, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [INTEGER_64] */
static EIF_TYPE_INDEX ptf959[] = {915,0xFFFF};
static struct eif_par_types par959 = {959, ptf959, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [BOOLEAN] */
static EIF_TYPE_INDEX ptf960[] = {915,0xFFFF};
static struct eif_par_types par960 = {960, ptf960, (uint16) 1, (uint16) 1, (char) 0};

/* NUMERIC */
static EIF_TYPE_INDEX ptf961[] = {900,0xFFFF};
static struct eif_par_types par961 = {961, ptf961, (uint16) 1, (uint16) 0, (char) 0};

/* MISMATCH_CORRECTOR */
static EIF_TYPE_INDEX ptf962[] = {0,0xFFFF};
static struct eif_par_types par962 = {962, ptf962, (uint16) 1, (uint16) 0, (char) 0};

/* ARRAYED_QUEUE [G#1] */
static EIF_TYPE_INDEX ptf963[] = {742,0xFFF8,1,0xFFF7,755,0xFFF8,1,0xFFF7,962,0xFFFF};
static struct eif_par_types par963 = {963, ptf963, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAYED_LIST [G#1] */
static EIF_TYPE_INDEX ptf964[] = {403,0xFFF8,1,0xFFF7,755,0xFFF8,1,0xFFF7,874,0xFFF8,1,0xFFF7,962,0xFFFF};
static struct eif_par_types par964 = {964, ptf964, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf965[] = {404,1096,0xFFF7,756,1096,0xFFF7,875,1096,0xFFF7,962,0xFFFF};
static struct eif_par_types par965 = {965, ptf965, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [BOOLEAN] */
static EIF_TYPE_INDEX ptf966[] = {405,1129,0xFFF7,757,1129,0xFFF7,876,1129,0xFFF7,962,0xFFFF};
static struct eif_par_types par966 = {966, ptf966, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [NATURAL_64] */
static EIF_TYPE_INDEX ptf967[] = {406,1105,0xFFF7,758,1105,0xFFF7,877,1105,0xFFF7,962,0xFFFF};
static struct eif_par_types par967 = {967, ptf967, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [NATURAL_32] */
static EIF_TYPE_INDEX ptf968[] = {407,1108,0xFFF7,759,1108,0xFFF7,878,1108,0xFFF7,962,0xFFFF};
static struct eif_par_types par968 = {968, ptf968, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [NATURAL_16] */
static EIF_TYPE_INDEX ptf969[] = {408,1111,0xFFF7,760,1111,0xFFF7,879,1111,0xFFF7,962,0xFFFF};
static struct eif_par_types par969 = {969, ptf969, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [NATURAL_8] */
static EIF_TYPE_INDEX ptf970[] = {409,1114,0xFFF7,761,1114,0xFFF7,880,1114,0xFFF7,962,0xFFFF};
static struct eif_par_types par970 = {970, ptf970, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [CHARACTER_32] */
static EIF_TYPE_INDEX ptf971[] = {410,1123,0xFFF7,762,1123,0xFFF7,881,1123,0xFFF7,962,0xFFFF};
static struct eif_par_types par971 = {971, ptf971, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [CHARACTER_8] */
static EIF_TYPE_INDEX ptf972[] = {411,1126,0xFFF7,763,1126,0xFFF7,882,1126,0xFFF7,962,0xFFFF};
static struct eif_par_types par972 = {972, ptf972, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [POINTER] */
static EIF_TYPE_INDEX ptf973[] = {412,1174,0xFFF7,764,1174,0xFFF7,883,1174,0xFFF7,962,0xFFFF};
static struct eif_par_types par973 = {973, ptf973, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [REAL_32] */
static EIF_TYPE_INDEX ptf974[] = {413,1117,0xFFF7,765,1117,0xFFF7,884,1117,0xFFF7,962,0xFFFF};
static struct eif_par_types par974 = {974, ptf974, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [REAL_64] */
static EIF_TYPE_INDEX ptf975[] = {414,1120,0xFFF7,766,1120,0xFFF7,885,1120,0xFFF7,962,0xFFFF};
static struct eif_par_types par975 = {975, ptf975, (uint16) 4, (uint16) 1, (char) 0};

/* HASH_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf976[] = {779,0xFFF8,1,0xFFF7,674,0xFFF8,1,0xFFF8,2,0xFFF7,486,0xFFF8,1,0xFFF8,2,0xFFF7,794,0xFFF8,1,0xFFF7,962,0xFFFF};
static struct eif_par_types par976 = {976, ptf976, (uint16) 5, (uint16) 2, (char) 0};

/* HASH_TABLE [POINTER, G#2] */
static EIF_TYPE_INDEX ptf977[] = {788,1174,0xFFF7,685,1174,0xFFF8,2,0xFFF7,487,1174,0xFFF8,2,0xFFF7,803,1174,0xFFF7,962,0xFFFF};
static struct eif_par_types par977 = {977, ptf977, (uint16) 5, (uint16) 2, (char) 0};

/* HASH_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf978[] = {779,0xFFF8,1,0xFFF7,675,0xFFF8,1,1096,0xFFF7,488,0xFFF8,1,1096,0xFFF7,794,0xFFF8,1,0xFFF7,962,0xFFFF};
static struct eif_par_types par978 = {978, ptf978, (uint16) 5, (uint16) 2, (char) 0};

/* HASH_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf979[] = {780,1096,0xFFF7,676,1096,0xFFF8,2,0xFFF7,489,1096,0xFFF8,2,0xFFF7,795,1096,0xFFF7,962,0xFFFF};
static struct eif_par_types par979 = {979, ptf979, (uint16) 5, (uint16) 2, (char) 0};

/* HASH_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf980[] = {780,1096,0xFFF7,677,1096,1096,0xFFF7,490,1096,1096,0xFFF7,795,1096,0xFFF7,962,0xFFFF};
static struct eif_par_types par980 = {980, ptf980, (uint16) 5, (uint16) 2, (char) 0};

/* STRING_TABLE [G#1] */
static EIF_TYPE_INDEX ptf981[] = {976,0xFFF8,1,0xFF01,1181,0xFFFF};
static struct eif_par_types par981 = {981, ptf981, (uint16) 1, (uint16) 1, (char) 0};

/* STRING_TABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf982[] = {979,1096,0xFF01,1181,0xFFFF};
static struct eif_par_types par982 = {982, ptf982, (uint16) 1, (uint16) 1, (char) 0};

/* MISMATCH_INFORMATION */
static EIF_TYPE_INDEX ptf983[] = {976,0,0xFF01,1189,0xFFFF};
static struct eif_par_types par983 = {983, ptf983, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_ARRAY_ROUTINES */
static EIF_TYPE_INDEX ptf984[] = {0,0xFFFF};
static struct eif_par_types par984 = {984, ptf984, (uint16) 1, (uint16) 0, (char) 0};

/* KI_DIRECTORY */
static EIF_TYPE_INDEX ptf985[] = {185,0xFFF7,251,0xFF01,1189,0xFFF7,984,0xFFFF};
static struct eif_par_types par985 = {985, ptf985, (uint16) 3, (uint16) 0, (char) 0};

/* KL_SHARED_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf986[] = {0,0xFFFF};
static struct eif_par_types par986 = {986, ptf986, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_ATTACHMENT */
static EIF_TYPE_INDEX ptf987[] = {0,0xFFFF};
static struct eif_par_types par987 = {987, ptf987, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_AGENT_OPERAND_ATTACHMENT */
static EIF_TYPE_INDEX ptf988[] = {987,0xFFFF};
static struct eif_par_types par988 = {988, ptf988, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_BUILTIN_ATTACHMENT */
static EIF_TYPE_INDEX ptf989[] = {987,0xFFFF};
static struct eif_par_types par989 = {989, ptf989, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_TUPLE_LABEL_SETTER */
static EIF_TYPE_INDEX ptf990[] = {987,0xFFFF};
static struct eif_par_types par990 = {990, ptf990, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_OBJECT_TEST */
static EIF_TYPE_INDEX ptf991[] = {987,0xFFFF};
static struct eif_par_types par991 = {991, ptf991, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_MANIFEST_STRING_AREA_ATTACHMENT */
static EIF_TYPE_INDEX ptf992[] = {987,0xFFFF};
static struct eif_par_types par992 = {992, ptf992, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_LIKE_ARGUMENT_CALL_ATTACHMENT */
static EIF_TYPE_INDEX ptf993[] = {987,0xFFFF};
static struct eif_par_types par993 = {993, ptf993, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_IF_EXPRESSION_ATTACHMENT */
static EIF_TYPE_INDEX ptf994[] = {987,0xFFFF};
static struct eif_par_types par994 = {994, ptf994, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_CREATION_INSTRUCTION */
static EIF_TYPE_INDEX ptf995[] = {987,0xFFFF};
static struct eif_par_types par995 = {995, ptf995, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_CAP_ATTACHMENT */
static EIF_TYPE_INDEX ptf996[] = {987,0xFFFF};
static struct eif_par_types par996 = {996, ptf996, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_ASSIGNMENT_ATTEMPT */
static EIF_TYPE_INDEX ptf997[] = {987,0xFFFF};
static struct eif_par_types par997 = {997, ptf997, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_ASSIGNMENT */
static EIF_TYPE_INDEX ptf998[] = {987,0xFFFF};
static struct eif_par_types par998 = {998, ptf998, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_ARGUMENT_ATTACHMENT */
static EIF_TYPE_INDEX ptf999[] = {987,0xFFFF};
static struct eif_par_types par999 = {999, ptf999, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_AGENT_CLOSED_OPERANDS_ATTACHMENT */
static EIF_TYPE_INDEX ptf1000[] = {987,0xFFFF};
static struct eif_par_types par1000 = {1000, ptf1000, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_AGENT_CLOSED_OPERANDS_ITEM_ATTACHMENT */
static EIF_TYPE_INDEX ptf1001[] = {987,0xFFFF};
static struct eif_par_types par1001 = {1001, ptf1001, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_MANIFEST_TUPLE_ITEM_ATTACHMENT */
static EIF_TYPE_INDEX ptf1002[] = {987,0xFFFF};
static struct eif_par_types par1002 = {1002, ptf1002, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_MANIFEST_ARRAY_AREA_ATTACHMENT */
static EIF_TYPE_INDEX ptf1003[] = {987,0xFFFF};
static struct eif_par_types par1003 = {1003, ptf1003, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_MANIFEST_ARRAY_ITEM_ATTACHMENT */
static EIF_TYPE_INDEX ptf1004[] = {987,0xFFFF};
static struct eif_par_types par1004 = {1004, ptf1004, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_AGENT_RESULT_ATTACHMENT */
static EIF_TYPE_INDEX ptf1005[] = {987,0xFFFF};
static struct eif_par_types par1005 = {1005, ptf1005, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_INTEGER_ROUTINES */
static EIF_TYPE_INDEX ptf1006[] = {0,0xFFFF};
static struct eif_par_types par1006 = {1006, ptf1006, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SHARED_TOKEN_CONSTANTS */
static EIF_TYPE_INDEX ptf1007[] = {0,0xFFFF};
static struct eif_par_types par1007 = {1007, ptf1007, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_ADAPTED_DOTNET_ASSEMBLY */
static EIF_TYPE_INDEX ptf1008[] = {305,0xFFF7,363,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1008 = {1008, ptf1008, (uint16) 3, (uint16) 0, (char) 0};

/* ET_SUPPLIER_BUILDER */
static EIF_TYPE_INDEX ptf1009[] = {128,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1009 = {1009, ptf1009, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DYNAMIC_NULL_ATTACHMENT */
static EIF_TYPE_INDEX ptf1010[] = {987,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1010 = {1010, ptf1010, (uint16) 2, (uint16) 0, (char) 0};

/* ET_AST_FACTORY */
static EIF_TYPE_INDEX ptf1011[] = {1007,0xFFFF};
static struct eif_par_types par1011 = {1011, ptf1011, (uint16) 1, (uint16) 0, (char) 0};

/* ET_MASTER_CLASS_CHECKER */
static EIF_TYPE_INDEX ptf1012[] = {254,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1012 = {1012, ptf1012, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_ADAPTED_LIBRARY */
static EIF_TYPE_INDEX ptf1013[] = {304,0xFFF7,363,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1013 = {1013, ptf1013, (uint16) 3, (uint16) 0, (char) 0};

/* ET_ECF_ADAPTED_PRECOMPILED_LIBRARY */
static EIF_TYPE_INDEX ptf1014[] = {1013,0xFFFF};
static struct eif_par_types par1014 = {1014, ptf1014, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_FEATURE */
static EIF_TYPE_INDEX ptf1015[] = {900,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1015 = {1015, ptf1015, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DYNAMIC_PRECURSOR */
static EIF_TYPE_INDEX ptf1016[] = {1015,0xFFFF};
static struct eif_par_types par1016 = {1016, ptf1016, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ONCE_ROUTINE_CLOSURE */
static EIF_TYPE_INDEX ptf1017[] = {288,0xFFF7,192,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1017 = {1017, ptf1017, (uint16) 3, (uint16) 0, (char) 0};

/* ET_DYNAMIC_QUALIFIED_CALL */
static EIF_TYPE_INDEX ptf1018[] = {377,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1018 = {1018, ptf1018, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DYNAMIC_QUALIFIED_PROCEDURE_CALL */
static EIF_TYPE_INDEX ptf1019[] = {1018,0xFFFF};
static struct eif_par_types par1019 = {1019, ptf1019, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_QUALIFIED_QUERY_CALL */
static EIF_TYPE_INDEX ptf1020[] = {1018,0xFFFF};
static struct eif_par_types par1020 = {1020, ptf1020, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLASS_PROCESSOR */
static EIF_TYPE_INDEX ptf1021[] = {253,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1021 = {1021, ptf1021, (uint16) 2, (uint16) 0, (char) 0};

/* ET_INTERFACE_STATUS_CHECKER */
static EIF_TYPE_INDEX ptf1022[] = {1021,0xFFF7,254,0xFFFF};
static struct eif_par_types par1022 = {1022, ptf1022, (uint16) 2, (uint16) 0, (char) 0};

/* ET_FLATTENING_STATUS_CHECKER */
static EIF_TYPE_INDEX ptf1023[] = {1021,0xFFF7,254,0xFFFF};
static struct eif_par_types par1023 = {1023, ptf1023, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ANCESTORS_STATUS_CHECKER */
static EIF_TYPE_INDEX ptf1024[] = {1021,0xFFF7,254,0xFFFF};
static struct eif_par_types par1024 = {1024, ptf1024, (uint16) 2, (uint16) 0, (char) 0};

/* ET_IMPLEMENTATION_STATUS_CHECKER */
static EIF_TYPE_INDEX ptf1025[] = {1021,0xFFF7,254,0xFFFF};
static struct eif_par_types par1025 = {1025, ptf1025, (uint16) 2, (uint16) 0, (char) 0};

/* ET_IMPLEMENTATION_CHECKER */
static EIF_TYPE_INDEX ptf1026[] = {1021,0xFFF7,254,0xFFF7,424,0xFFFF};
static struct eif_par_types par1026 = {1026, ptf1026, (uint16) 3, (uint16) 0, (char) 0};

/* ET_INTERFACE_CHECKER */
static EIF_TYPE_INDEX ptf1027[] = {1021,0xFFF7,254,0xFFF7,216,0xFFF7,424,0xFFFF};
static struct eif_par_types par1027 = {1027, ptf1027, (uint16) 4, (uint16) 0, (char) 0};

/* ET_FEATURE_FLATTENER */
static EIF_TYPE_INDEX ptf1028[] = {1021,0xFFF7,254,0xFFF7,424,0xFFF7,216,0xFFF7,374,0xFFF7,470,0xFFFF};
static struct eif_par_types par1028 = {1028, ptf1028, (uint16) 6, (uint16) 0, (char) 0};

/* ET_ANCESTOR_BUILDER */
static EIF_TYPE_INDEX ptf1029[] = {1021,0xFFF7,254,0xFFFF};
static struct eif_par_types par1029 = {1029, ptf1029, (uint16) 2, (uint16) 0, (char) 0};

/* ET_PROVIDER_CHECKER */
static EIF_TYPE_INDEX ptf1030[] = {1021,0xFFF7,254,0xFFFF};
static struct eif_par_types par1030 = {1030, ptf1030, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CLASS_SUBPROCESSOR */
static EIF_TYPE_INDEX ptf1031[] = {1021,0xFFFF};
static struct eif_par_types par1031 = {1031, ptf1031, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TYPE_CHECKER */
static EIF_TYPE_INDEX ptf1032[] = {1031,0xFFF7,254,0xFFF7,470,0xFFFF};
static struct eif_par_types par1032 = {1032, ptf1032, (uint16) 3, (uint16) 0, (char) 0};

/* ET_OBJECT_TEST_SCOPE_BUILDER */
static EIF_TYPE_INDEX ptf1033[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1033 = {1033, ptf1033, (uint16) 2, (uint16) 0, (char) 0};

/* ET_QUALIFIED_ANCHORED_TYPE_STATUS_CHECKER */
static EIF_TYPE_INDEX ptf1034[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1034 = {1034, ptf1034, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ADAPTED_BASE_CLASS_CHECKER */
static EIF_TYPE_INDEX ptf1035[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1035 = {1035, ptf1035, (uint16) 2, (uint16) 0, (char) 0};

/* ET_PARENT_CHECKER3 */
static EIF_TYPE_INDEX ptf1036[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1036 = {1036, ptf1036, (uint16) 2, (uint16) 0, (char) 0};

/* ET_QUALIFIED_ANCHORED_TYPE_CHECKER */
static EIF_TYPE_INDEX ptf1037[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1037 = {1037, ptf1037, (uint16) 2, (uint16) 0, (char) 0};

/* ET_UNFOLDED_TUPLE_ACTUAL_PARAMETERS_RESOLVER2 */
static EIF_TYPE_INDEX ptf1038[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1038 = {1038, ptf1038, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DOTNET_FEATURE_ADAPTATION_RESOLVER */
static EIF_TYPE_INDEX ptf1039[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1039 = {1039, ptf1039, (uint16) 2, (uint16) 0, (char) 0};

/* ET_FEATURE_ADAPTATION_RESOLVER */
static EIF_TYPE_INDEX ptf1040[] = {1031,0xFFF7,254,0xFFF7,424,0xFFF7,374,0xFFFF};
static struct eif_par_types par1040 = {1040, ptf1040, (uint16) 4, (uint16) 0, (char) 0};

/* ET_PARENT_CHECKER2 */
static EIF_TYPE_INDEX ptf1041[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1041 = {1041, ptf1041, (uint16) 2, (uint16) 0, (char) 0};

/* ET_FORMAL_PARAMETER_CHECKER2 */
static EIF_TYPE_INDEX ptf1042[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1042 = {1042, ptf1042, (uint16) 2, (uint16) 0, (char) 0};

/* ET_SIGNATURE_CHECKER */
static EIF_TYPE_INDEX ptf1043[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1043 = {1043, ptf1043, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ANCHORED_TYPE_CHECKER */
static EIF_TYPE_INDEX ptf1044[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1044 = {1044, ptf1044, (uint16) 2, (uint16) 0, (char) 0};

/* ET_IDENTIFIER_TYPE_RESOLVER */
static EIF_TYPE_INDEX ptf1045[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1045 = {1045, ptf1045, (uint16) 2, (uint16) 0, (char) 0};

/* ET_PRECURSOR_CHECKER */
static EIF_TYPE_INDEX ptf1046[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1046 = {1046, ptf1046, (uint16) 2, (uint16) 0, (char) 0};

/* ET_FORMAL_PARAMETER_CHECKER1 */
static EIF_TYPE_INDEX ptf1047[] = {1031,0xFFF7,254,0xFFF7,470,0xFFFF};
static struct eif_par_types par1047 = {1047, ptf1047, (uint16) 3, (uint16) 0, (char) 0};

/* ET_PARENT_CHECKER1 */
static EIF_TYPE_INDEX ptf1048[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1048 = {1048, ptf1048, (uint16) 2, (uint16) 0, (char) 0};

/* ET_UNFOLDED_TUPLE_ACTUAL_PARAMETERS_RESOLVER1 */
static EIF_TYPE_INDEX ptf1049[] = {1031,0xFFF7,254,0xFFFF};
static struct eif_par_types par1049 = {1049, ptf1049, (uint16) 2, (uint16) 0, (char) 0};

/* ET_HEAD_LIST [G#1] */
static EIF_TYPE_INDEX ptf1050[] = {0,0xFFFF};
static struct eif_par_types par1050 = {1050, ptf1050, (uint16) 1, (uint16) 1, (char) 0};

/* ET_CONSTRAINT_ACTUAL_PARAMETER_LIST */
static EIF_TYPE_INDEX ptf1051[] = {1050,0xFF01,294,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1051 = {1051, ptf1051, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CLIENT_LIST */
static EIF_TYPE_INDEX ptf1052[] = {1050,0xFF01,1648,0xFFFF};
static struct eif_par_types par1052 = {1052, ptf1052, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FEATURE_LIST */
static EIF_TYPE_INDEX ptf1053[] = {1050,0xFF01,1822,0xFFFF};
static struct eif_par_types par1053 = {1053, ptf1053, (uint16) 1, (uint16) 0, (char) 0};

/* ET_PROCEDURE_LIST */
static EIF_TYPE_INDEX ptf1054[] = {1053,0xFFFF};
static struct eif_par_types par1054 = {1054, ptf1054, (uint16) 1, (uint16) 0, (char) 0};

/* ET_QUERY_LIST */
static EIF_TYPE_INDEX ptf1055[] = {1053,0xFFFF};
static struct eif_par_types par1055 = {1055, ptf1055, (uint16) 1, (uint16) 0, (char) 0};

/* HASHABLE */
static EIF_TYPE_INDEX ptf1056[] = {0,0xFFFF};
static struct eif_par_types par1056 = {1056, ptf1056, (uint16) 1, (uint16) 0, (char) 0};

/* LX_SYMBOL_CLASS */
static EIF_TYPE_INDEX ptf1057[] = {1056,0xFFFF};
static struct eif_par_types par1057 = {1057, ptf1057, (uint16) 1, (uint16) 0, (char) 0};

/* PATH */
static EIF_TYPE_INDEX ptf1058[] = {1056,0xFFF7,260,0xFFF7,418,0xFFF7,900,0xFFFF};
static struct eif_par_types par1058 = {1058, ptf1058, (uint16) 4, (uint16) 0, (char) 0};

/* TYPE [G#1] */
static EIF_TYPE_INDEX ptf1059[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1059 = {1059, ptf1059, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [ANY]] */
static EIF_TYPE_INDEX ptf1060[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1060 = {1060, ptf1060, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [POINTER] */
static EIF_TYPE_INDEX ptf1061[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1061 = {1061, ptf1061, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [REAL_64] */
static EIF_TYPE_INDEX ptf1062[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1062 = {1062, ptf1062, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [REAL_32] */
static EIF_TYPE_INDEX ptf1063[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1063 = {1063, ptf1063, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [NATURAL_8] */
static EIF_TYPE_INDEX ptf1064[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1064 = {1064, ptf1064, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [NATURAL_16] */
static EIF_TYPE_INDEX ptf1065[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1065 = {1065, ptf1065, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [NATURAL_32] */
static EIF_TYPE_INDEX ptf1066[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1066 = {1066, ptf1066, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [NATURAL_64] */
static EIF_TYPE_INDEX ptf1067[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1067 = {1067, ptf1067, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [INTEGER_8] */
static EIF_TYPE_INDEX ptf1068[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1068 = {1068, ptf1068, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [INTEGER_16] */
static EIF_TYPE_INDEX ptf1069[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1069 = {1069, ptf1069, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1070[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1070 = {1070, ptf1070, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [INTEGER_64] */
static EIF_TYPE_INDEX ptf1071[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1071 = {1071, ptf1071, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1072[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1072 = {1072, ptf1072, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1073[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1073 = {1073, ptf1073, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf1074[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1074 = {1074, ptf1074, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [REAL_32]] */
static EIF_TYPE_INDEX ptf1075[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1075 = {1075, ptf1075, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [NATURAL_16]] */
static EIF_TYPE_INDEX ptf1076[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1076 = {1076, ptf1076, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [NATURAL_64]] */
static EIF_TYPE_INDEX ptf1077[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1077 = {1077, ptf1077, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [UTF_CONVERTER] */
static EIF_TYPE_INDEX ptf1078[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1078 = {1078, ptf1078, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [POINTER]] */
static EIF_TYPE_INDEX ptf1079[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1079 = {1079, ptf1079, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [REAL_64]] */
static EIF_TYPE_INDEX ptf1080[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1080 = {1080, ptf1080, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [BOOLEAN]] */
static EIF_TYPE_INDEX ptf1081[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1081 = {1081, ptf1081, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [INTEGER_32]] */
static EIF_TYPE_INDEX ptf1082[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1082 = {1082, ptf1082, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [CHARACTER_32]] */
static EIF_TYPE_INDEX ptf1083[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1083 = {1083, ptf1083, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [NATURAL_8]] */
static EIF_TYPE_INDEX ptf1084[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1084 = {1084, ptf1084, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [NATURAL_32]] */
static EIF_TYPE_INDEX ptf1085[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1085 = {1085, ptf1085, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [INTEGER_8]] */
static EIF_TYPE_INDEX ptf1086[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1086 = {1086, ptf1086, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [INTEGER_16]] */
static EIF_TYPE_INDEX ptf1087[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1087 = {1087, ptf1087, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [INTEGER_64]] */
static EIF_TYPE_INDEX ptf1088[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1088 = {1088, ptf1088, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [CHARACTER_8]] */
static EIF_TYPE_INDEX ptf1089[] = {1056,0xFFF7,259,0xFFF7,900,0xFFFF};
static struct eif_par_types par1089 = {1089, ptf1089, (uint16) 3, (uint16) 1, (char) 0};

/* TUPLE */
static EIF_TYPE_INDEX ptf1090[] = {1056,0xFFF7,962,0xFFF7,794,0,0xFFFF};
static struct eif_par_types par1090 = {1090, ptf1090, (uint16) 3, (uint16) 0, (char) 0};

/* INTEGER_64_REF */
static EIF_TYPE_INDEX ptf1091[] = {961,0xFFF7,260,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1091 = {1091, ptf1091, (uint16) 3, (uint16) 0, (char) 0};

/* reference INTEGER_64 */
static EIF_TYPE_INDEX ptf1092[] = {1091,0xFFFF};
static struct eif_par_types par1092 = {1092, ptf1092, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_64 */
static EIF_TYPE_INDEX ptf1093[] = {1092,0xFFFF};
static struct eif_par_types par1093 = {1093, ptf1093, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_32_REF */
static EIF_TYPE_INDEX ptf1094[] = {961,0xFFF7,260,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1094 = {1094, ptf1094, (uint16) 3, (uint16) 0, (char) 0};

/* reference INTEGER_32 */
static EIF_TYPE_INDEX ptf1095[] = {1094,0xFFFF};
static struct eif_par_types par1095 = {1095, ptf1095, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_32 */
static EIF_TYPE_INDEX ptf1096[] = {1095,0xFFFF};
static struct eif_par_types par1096 = {1096, ptf1096, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_16_REF */
static EIF_TYPE_INDEX ptf1097[] = {961,0xFFF7,260,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1097 = {1097, ptf1097, (uint16) 3, (uint16) 0, (char) 0};

/* reference INTEGER_16 */
static EIF_TYPE_INDEX ptf1098[] = {1097,0xFFFF};
static struct eif_par_types par1098 = {1098, ptf1098, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_16 */
static EIF_TYPE_INDEX ptf1099[] = {1098,0xFFFF};
static struct eif_par_types par1099 = {1099, ptf1099, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_8_REF */
static EIF_TYPE_INDEX ptf1100[] = {961,0xFFF7,260,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1100 = {1100, ptf1100, (uint16) 3, (uint16) 0, (char) 0};

/* reference INTEGER_8 */
static EIF_TYPE_INDEX ptf1101[] = {1100,0xFFFF};
static struct eif_par_types par1101 = {1101, ptf1101, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_8 */
static EIF_TYPE_INDEX ptf1102[] = {1101,0xFFFF};
static struct eif_par_types par1102 = {1102, ptf1102, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_64_REF */
static EIF_TYPE_INDEX ptf1103[] = {961,0xFFF7,260,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1103 = {1103, ptf1103, (uint16) 3, (uint16) 0, (char) 0};

/* reference NATURAL_64 */
static EIF_TYPE_INDEX ptf1104[] = {1103,0xFFFF};
static struct eif_par_types par1104 = {1104, ptf1104, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_64 */
static EIF_TYPE_INDEX ptf1105[] = {1104,0xFFFF};
static struct eif_par_types par1105 = {1105, ptf1105, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_32_REF */
static EIF_TYPE_INDEX ptf1106[] = {961,0xFFF7,260,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1106 = {1106, ptf1106, (uint16) 3, (uint16) 0, (char) 0};

/* reference NATURAL_32 */
static EIF_TYPE_INDEX ptf1107[] = {1106,0xFFFF};
static struct eif_par_types par1107 = {1107, ptf1107, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_32 */
static EIF_TYPE_INDEX ptf1108[] = {1107,0xFFFF};
static struct eif_par_types par1108 = {1108, ptf1108, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_16_REF */
static EIF_TYPE_INDEX ptf1109[] = {961,0xFFF7,260,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1109 = {1109, ptf1109, (uint16) 3, (uint16) 0, (char) 0};

/* reference NATURAL_16 */
static EIF_TYPE_INDEX ptf1110[] = {1109,0xFFFF};
static struct eif_par_types par1110 = {1110, ptf1110, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_16 */
static EIF_TYPE_INDEX ptf1111[] = {1110,0xFFFF};
static struct eif_par_types par1111 = {1111, ptf1111, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_8_REF */
static EIF_TYPE_INDEX ptf1112[] = {961,0xFFF7,260,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1112 = {1112, ptf1112, (uint16) 3, (uint16) 0, (char) 0};

/* reference NATURAL_8 */
static EIF_TYPE_INDEX ptf1113[] = {1112,0xFFFF};
static struct eif_par_types par1113 = {1113, ptf1113, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_8 */
static EIF_TYPE_INDEX ptf1114[] = {1113,0xFFFF};
static struct eif_par_types par1114 = {1114, ptf1114, (uint16) 1, (uint16) 0, (char) 1};

/* REAL_32_REF */
static EIF_TYPE_INDEX ptf1115[] = {961,0xFFF7,260,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1115 = {1115, ptf1115, (uint16) 3, (uint16) 0, (char) 0};

/* reference REAL_32 */
static EIF_TYPE_INDEX ptf1116[] = {1115,0xFFFF};
static struct eif_par_types par1116 = {1116, ptf1116, (uint16) 1, (uint16) 0, (char) 1};

/* REAL_32 */
static EIF_TYPE_INDEX ptf1117[] = {1116,0xFFFF};
static struct eif_par_types par1117 = {1117, ptf1117, (uint16) 1, (uint16) 0, (char) 1};

/* REAL_64_REF */
static EIF_TYPE_INDEX ptf1118[] = {961,0xFFF7,260,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1118 = {1118, ptf1118, (uint16) 3, (uint16) 0, (char) 0};

/* reference REAL_64 */
static EIF_TYPE_INDEX ptf1119[] = {1118,0xFFFF};
static struct eif_par_types par1119 = {1119, ptf1119, (uint16) 1, (uint16) 0, (char) 1};

/* REAL_64 */
static EIF_TYPE_INDEX ptf1120[] = {1119,0xFFFF};
static struct eif_par_types par1120 = {1120, ptf1120, (uint16) 1, (uint16) 0, (char) 1};

/* CHARACTER_32_REF */
static EIF_TYPE_INDEX ptf1121[] = {260,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1121 = {1121, ptf1121, (uint16) 2, (uint16) 0, (char) 0};

/* reference CHARACTER_32 */
static EIF_TYPE_INDEX ptf1122[] = {1121,0xFFFF};
static struct eif_par_types par1122 = {1122, ptf1122, (uint16) 1, (uint16) 0, (char) 1};

/* CHARACTER_32 */
static EIF_TYPE_INDEX ptf1123[] = {1122,0xFFFF};
static struct eif_par_types par1123 = {1123, ptf1123, (uint16) 1, (uint16) 0, (char) 1};

/* CHARACTER_8_REF */
static EIF_TYPE_INDEX ptf1124[] = {260,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1124 = {1124, ptf1124, (uint16) 2, (uint16) 0, (char) 0};

/* reference CHARACTER_8 */
static EIF_TYPE_INDEX ptf1125[] = {1124,0xFFFF};
static struct eif_par_types par1125 = {1125, ptf1125, (uint16) 1, (uint16) 0, (char) 1};

/* CHARACTER_8 */
static EIF_TYPE_INDEX ptf1126[] = {1125,0xFFFF};
static struct eif_par_types par1126 = {1126, ptf1126, (uint16) 1, (uint16) 0, (char) 1};

/* BOOLEAN_REF */
static EIF_TYPE_INDEX ptf1127[] = {1056,0xFFFF};
static struct eif_par_types par1127 = {1127, ptf1127, (uint16) 1, (uint16) 0, (char) 0};

/* reference BOOLEAN */
static EIF_TYPE_INDEX ptf1128[] = {1127,0xFFFF};
static struct eif_par_types par1128 = {1128, ptf1128, (uint16) 1, (uint16) 0, (char) 1};

/* BOOLEAN */
static EIF_TYPE_INDEX ptf1129[] = {1128,0xFFFF};
static struct eif_par_types par1129 = {1129, ptf1129, (uint16) 1, (uint16) 0, (char) 1};

/* ET_CLUSTER_SCM_MAPPING */
static EIF_TYPE_INDEX ptf1130[] = {1056,0xFFFF};
static struct eif_par_types par1130 = {1130, ptf1130, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLUSTER_SCM_WRITE_MAPPING */
static EIF_TYPE_INDEX ptf1131[] = {1130,0xFFFF};
static struct eif_par_types par1131 = {1131, ptf1131, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLUSTER_SCM_READ_MAPPING */
static EIF_TYPE_INDEX ptf1132[] = {1130,0xFFFF};
static struct eif_par_types par1132 = {1132, ptf1132, (uint16) 1, (uint16) 0, (char) 0};

/* ET_NAMED_CLASS */
static EIF_TYPE_INDEX ptf1133[] = {1056,0xFFFF};
static struct eif_par_types par1133 = {1133, ptf1133, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_TYPE */
static EIF_TYPE_INDEX ptf1134[] = {380,0xFFF7,1056,0xFFF7,900,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1134 = {1134, ptf1134, (uint16) 4, (uint16) 0, (char) 0};

/* ET_DYNAMIC_SECONDARY_TYPE */
static EIF_TYPE_INDEX ptf1135[] = {1134,0xFFFF};
static struct eif_par_types par1135 = {1135, ptf1135, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_PRIMARY_TYPE */
static EIF_TYPE_INDEX ptf1136[] = {1134,0xFFFF};
static struct eif_par_types par1136 = {1136, ptf1136, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_TUPLE_TYPE */
static EIF_TYPE_INDEX ptf1137[] = {1136,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1137 = {1137, ptf1137, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DYNAMIC_SPECIAL_TYPE */
static EIF_TYPE_INDEX ptf1138[] = {1136,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1138 = {1138, ptf1138, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DYNAMIC_ROUTINE_TYPE */
static EIF_TYPE_INDEX ptf1139[] = {1136,0xFFFF};
static struct eif_par_types par1139 = {1139, ptf1139, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_FUNCTION_TYPE */
static EIF_TYPE_INDEX ptf1140[] = {1139,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1140 = {1140, ptf1140, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DYNAMIC_PROCEDURE_TYPE */
static EIF_TYPE_INDEX ptf1141[] = {1139,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1141 = {1141, ptf1141, (uint16) 2, (uint16) 0, (char) 0};

/* POINTER_REF */
static EIF_TYPE_INDEX ptf1142[] = {1056,0xFFF7,138,0xFFFF};
static struct eif_par_types par1142 = {1142, ptf1142, (uint16) 2, (uint16) 0, (char) 0};

/* reference TYPED_POINTER [G#1] */
static EIF_TYPE_INDEX ptf1143[] = {1142,0xFFFF};
static struct eif_par_types par1143 = {1143, ptf1143, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [G#1] */
static EIF_TYPE_INDEX ptf1144[] = {1143,0xFFF8,1,0xFFFF};
static struct eif_par_types par1144 = {1144, ptf1144, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [REAL_32] */
static EIF_TYPE_INDEX ptf1145[] = {1142,0xFFFF};
static struct eif_par_types par1145 = {1145, ptf1145, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [REAL_32] */
static EIF_TYPE_INDEX ptf1146[] = {1145,1117,0xFFFF};
static struct eif_par_types par1146 = {1146, ptf1146, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [NATURAL_16] */
static EIF_TYPE_INDEX ptf1147[] = {1142,0xFFFF};
static struct eif_par_types par1147 = {1147, ptf1147, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [NATURAL_16] */
static EIF_TYPE_INDEX ptf1148[] = {1147,1111,0xFFFF};
static struct eif_par_types par1148 = {1148, ptf1148, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [NATURAL_64] */
static EIF_TYPE_INDEX ptf1149[] = {1142,0xFFFF};
static struct eif_par_types par1149 = {1149, ptf1149, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [NATURAL_64] */
static EIF_TYPE_INDEX ptf1150[] = {1149,1105,0xFFFF};
static struct eif_par_types par1150 = {1150, ptf1150, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [POINTER] */
static EIF_TYPE_INDEX ptf1151[] = {1142,0xFFFF};
static struct eif_par_types par1151 = {1151, ptf1151, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [POINTER] */
static EIF_TYPE_INDEX ptf1152[] = {1151,1174,0xFFFF};
static struct eif_par_types par1152 = {1152, ptf1152, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [REAL_64] */
static EIF_TYPE_INDEX ptf1153[] = {1142,0xFFFF};
static struct eif_par_types par1153 = {1153, ptf1153, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [REAL_64] */
static EIF_TYPE_INDEX ptf1154[] = {1153,1120,0xFFFF};
static struct eif_par_types par1154 = {1154, ptf1154, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [BOOLEAN] */
static EIF_TYPE_INDEX ptf1155[] = {1142,0xFFFF};
static struct eif_par_types par1155 = {1155, ptf1155, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [BOOLEAN] */
static EIF_TYPE_INDEX ptf1156[] = {1155,1129,0xFFFF};
static struct eif_par_types par1156 = {1156, ptf1156, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf1157[] = {1142,0xFFFF};
static struct eif_par_types par1157 = {1157, ptf1157, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf1158[] = {1157,1096,0xFFFF};
static struct eif_par_types par1158 = {1158, ptf1158, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [CHARACTER_32] */
static EIF_TYPE_INDEX ptf1159[] = {1142,0xFFFF};
static struct eif_par_types par1159 = {1159, ptf1159, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [CHARACTER_32] */
static EIF_TYPE_INDEX ptf1160[] = {1159,1123,0xFFFF};
static struct eif_par_types par1160 = {1160, ptf1160, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [NATURAL_8] */
static EIF_TYPE_INDEX ptf1161[] = {1142,0xFFFF};
static struct eif_par_types par1161 = {1161, ptf1161, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [NATURAL_8] */
static EIF_TYPE_INDEX ptf1162[] = {1161,1114,0xFFFF};
static struct eif_par_types par1162 = {1162, ptf1162, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [NATURAL_32] */
static EIF_TYPE_INDEX ptf1163[] = {1142,0xFFFF};
static struct eif_par_types par1163 = {1163, ptf1163, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [NATURAL_32] */
static EIF_TYPE_INDEX ptf1164[] = {1163,1108,0xFFFF};
static struct eif_par_types par1164 = {1164, ptf1164, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [INTEGER_8] */
static EIF_TYPE_INDEX ptf1165[] = {1142,0xFFFF};
static struct eif_par_types par1165 = {1165, ptf1165, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [INTEGER_8] */
static EIF_TYPE_INDEX ptf1166[] = {1165,1102,0xFFFF};
static struct eif_par_types par1166 = {1166, ptf1166, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [INTEGER_16] */
static EIF_TYPE_INDEX ptf1167[] = {1142,0xFFFF};
static struct eif_par_types par1167 = {1167, ptf1167, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [INTEGER_16] */
static EIF_TYPE_INDEX ptf1168[] = {1167,1099,0xFFFF};
static struct eif_par_types par1168 = {1168, ptf1168, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [INTEGER_64] */
static EIF_TYPE_INDEX ptf1169[] = {1142,0xFFFF};
static struct eif_par_types par1169 = {1169, ptf1169, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [INTEGER_64] */
static EIF_TYPE_INDEX ptf1170[] = {1169,1093,0xFFFF};
static struct eif_par_types par1170 = {1170, ptf1170, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1171[] = {1142,0xFFFF};
static struct eif_par_types par1171 = {1171, ptf1171, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1172[] = {1171,1126,0xFFFF};
static struct eif_par_types par1172 = {1172, ptf1172, (uint16) 1, (uint16) 1, (char) 1};

/* reference POINTER */
static EIF_TYPE_INDEX ptf1173[] = {1142,0xFFFF};
static struct eif_par_types par1173 = {1173, ptf1173, (uint16) 1, (uint16) 0, (char) 1};

/* POINTER */
static EIF_TYPE_INDEX ptf1174[] = {1173,0xFFFF};
static struct eif_par_types par1174 = {1174, ptf1174, (uint16) 1, (uint16) 0, (char) 1};

/* ROUTINE [G#1] */
static EIF_TYPE_INDEX ptf1175[] = {1056,0xFFF7,962,0xFFFF};
static struct eif_par_types par1175 = {1175, ptf1175, (uint16) 2, (uint16) 1, (char) 0};

/* PROCEDURE [G#1] */
static EIF_TYPE_INDEX ptf1176[] = {1175,0xFFF8,1,0xFFFF};
static struct eif_par_types par1176 = {1176, ptf1176, (uint16) 1, (uint16) 1, (char) 0};

/* FUNCTION [G#1, G#2] */
static EIF_TYPE_INDEX ptf1177[] = {1175,0xFFF8,1,0xFFFF};
static struct eif_par_types par1177 = {1177, ptf1177, (uint16) 1, (uint16) 2, (char) 0};

/* FUNCTION [G#1, BOOLEAN] */
static EIF_TYPE_INDEX ptf1178[] = {1175,0xFFF8,1,0xFFFF};
static struct eif_par_types par1178 = {1178, ptf1178, (uint16) 1, (uint16) 2, (char) 0};

/* FUNCTION [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1179[] = {1175,0xFFF8,1,0xFFFF};
static struct eif_par_types par1179 = {1179, ptf1179, (uint16) 1, (uint16) 2, (char) 0};

/* PREDICATE [G#1] */
static EIF_TYPE_INDEX ptf1180[] = {1178,0xFFF8,1,1129,0xFFFF};
static struct eif_par_types par1180 = {1180, ptf1180, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_STRING_GENERAL */
static EIF_TYPE_INDEX ptf1181[] = {260,0xFFF7,1056,0xFFF7,425,0xFFFF};
static struct eif_par_types par1181 = {1181, ptf1181, (uint16) 3, (uint16) 0, (char) 0};

/* IMMUTABLE_STRING_GENERAL */
static EIF_TYPE_INDEX ptf1182[] = {1181,0xFFFF};
static struct eif_par_types par1182 = {1182, ptf1182, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_GENERAL */
static EIF_TYPE_INDEX ptf1183[] = {1181,0xFFFF};
static struct eif_par_types par1183 = {1183, ptf1183, (uint16) 1, (uint16) 0, (char) 0};

/* READABLE_STRING_32 */
static EIF_TYPE_INDEX ptf1184[] = {1181,0xFFF7,798,1123,0xFFFF};
static struct eif_par_types par1184 = {1184, ptf1184, (uint16) 2, (uint16) 0, (char) 0};

/* IMMUTABLE_STRING_32 */
static EIF_TYPE_INDEX ptf1185[] = {1184,0xFFF7,1182,0xFFF7,962,0xFFFF};
static struct eif_par_types par1185 = {1185, ptf1185, (uint16) 3, (uint16) 0, (char) 0};

/* STRING_32 */
static EIF_TYPE_INDEX ptf1186[] = {1184,0xFFF7,1183,0xFFF7,683,1123,1096,0xFFF7,810,1123,1096,0xFFF7,762,1123,0xFFF7,410,1123,0xFFF7,962,0xFFFF};
static struct eif_par_types par1186 = {1186, ptf1186, (uint16) 7, (uint16) 0, (char) 0};

/* READABLE_STRING_8 */
static EIF_TYPE_INDEX ptf1187[] = {1181,0xFFF7,797,1126,0xFFFF};
static struct eif_par_types par1187 = {1187, ptf1187, (uint16) 2, (uint16) 0, (char) 0};

/* IMMUTABLE_STRING_8 */
static EIF_TYPE_INDEX ptf1188[] = {1187,0xFFF7,1182,0xFFFF};
static struct eif_par_types par1188 = {1188, ptf1188, (uint16) 2, (uint16) 0, (char) 0};

/* STRING_8 */
static EIF_TYPE_INDEX ptf1189[] = {1187,0xFFF7,1183,0xFFF7,684,1126,1096,0xFFF7,809,1126,1096,0xFFF7,763,1126,0xFFF7,411,1126,0xFFF7,962,0xFFFF};
static struct eif_par_types par1189 = {1189, ptf1189, (uint16) 7, (uint16) 0, (char) 0};

/* KL_STRING */
static EIF_TYPE_INDEX ptf1190[] = {1189,0xFFFF};
static struct eif_par_types par1190 = {1190, ptf1190, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_ANY_ROUTINES */
static EIF_TYPE_INDEX ptf1191[] = {0,0xFFFF};
static struct eif_par_types par1191 = {1191, ptf1191, (uint16) 1, (uint16) 0, (char) 0};

/* UC_UTF32_ROUTINES */
static EIF_TYPE_INDEX ptf1192[] = {97,0xFFF7,450,0xFFF7,1191,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1192 = {1192, ptf1192, (uint16) 4, (uint16) 0, (char) 0};

/* UC_UTF16_ROUTINES */
static EIF_TYPE_INDEX ptf1193[] = {97,0xFFF7,1191,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1193 = {1193, ptf1193, (uint16) 3, (uint16) 0, (char) 0};

/* KL_NATURAL_32_ROUTINES */
static EIF_TYPE_INDEX ptf1194[] = {1191,0xFFFF};
static struct eif_par_types par1194 = {1194, ptf1194, (uint16) 1, (uint16) 0, (char) 0};

/* KL_ARRAY_ROUTINES [G#1] */
static EIF_TYPE_INDEX ptf1195[] = {1191,0xFFFF};
static struct eif_par_types par1195 = {1195, ptf1195, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [INTEGER_32] */
static EIF_TYPE_INDEX ptf1196[] = {1191,0xFFFF};
static struct eif_par_types par1196 = {1196, ptf1196, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [BOOLEAN] */
static EIF_TYPE_INDEX ptf1197[] = {1191,0xFFFF};
static struct eif_par_types par1197 = {1197, ptf1197, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [NATURAL_64] */
static EIF_TYPE_INDEX ptf1198[] = {1191,0xFFFF};
static struct eif_par_types par1198 = {1198, ptf1198, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [NATURAL_32] */
static EIF_TYPE_INDEX ptf1199[] = {1191,0xFFFF};
static struct eif_par_types par1199 = {1199, ptf1199, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [NATURAL_8] */
static EIF_TYPE_INDEX ptf1200[] = {1191,0xFFFF};
static struct eif_par_types par1200 = {1200, ptf1200, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1201[] = {1191,0xFFFF};
static struct eif_par_types par1201 = {1201, ptf1201, (uint16) 1, (uint16) 1, (char) 0};

/* UC_UTF8_ROUTINES */
static EIF_TYPE_INDEX ptf1202[] = {450,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1202 = {1202, ptf1202, (uint16) 2, (uint16) 0, (char) 0};

/* KL_STRING_ROUTINES */
static EIF_TYPE_INDEX ptf1203[] = {95,0xFFF7,194,0xFFF7,1006,0xFFF7,1191,0xFFF7,450,0xFFF7,373,0xFFF7,193,0xFFFF};
static struct eif_par_types par1203 = {1203, ptf1203, (uint16) 7, (uint16) 0, (char) 0};

/* ET_STANDALONE_CLOSURE */
static EIF_TYPE_INDEX ptf1204[] = {282,0xFFF7,1056,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1204 = {1204, ptf1204, (uint16) 3, (uint16) 0, (char) 0};

/* KI_CHARACTER_INPUT_STREAM */
static EIF_TYPE_INDEX ptf1205[] = {252,1126,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1205 = {1205, ptf1205, (uint16) 2, (uint16) 0, (char) 0};

/* KI_TEXT_INPUT_STREAM */
static EIF_TYPE_INDEX ptf1206[] = {1205,0xFFFF};
static struct eif_par_types par1206 = {1206, ptf1206, (uint16) 1, (uint16) 0, (char) 0};

/* KI_INPUT_FILE */
static EIF_TYPE_INDEX ptf1207[] = {186,0xFFF7,1205,0xFFF7,95,0xFFFF};
static struct eif_par_types par1207 = {1207, ptf1207, (uint16) 3, (uint16) 0, (char) 0};

/* KI_BINARY_INPUT_FILE */
static EIF_TYPE_INDEX ptf1208[] = {1207,0xFFFF};
static struct eif_par_types par1208 = {1208, ptf1208, (uint16) 1, (uint16) 0, (char) 0};

/* KI_TEXT_INPUT_FILE */
static EIF_TYPE_INDEX ptf1209[] = {1207,0xFFF7,1206,0xFFFF};
static struct eif_par_types par1209 = {1209, ptf1209, (uint16) 2, (uint16) 0, (char) 0};

/* UC_UNICODE_FACTORY */
static EIF_TYPE_INDEX ptf1210[] = {415,0xFFF7,373,0xFFF7,450,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1210 = {1210, ptf1210, (uint16) 4, (uint16) 0, (char) 0};

/* KL_IMPORTED_STRING_ROUTINES */
static EIF_TYPE_INDEX ptf1211[] = {0,0xFFFF};
static struct eif_par_types par1211 = {1211, ptf1211, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EIFFEL_CHARACTER_ENTITY */
static EIF_TYPE_INDEX ptf1212[] = {1006,0xFFF7,1211,0xFFF7,1191,0xFFF7,95,0xFFF7,415,0xFFF7,450,0xFFFF};
static struct eif_par_types par1212 = {1212, ptf1212, (uint16) 6, (uint16) 0, (char) 0};

/* ST_COPY_ON_WRITE_STRING */
static EIF_TYPE_INDEX ptf1213[] = {1211,0xFFFF};
static struct eif_par_types par1213 = {1213, ptf1213, (uint16) 1, (uint16) 0, (char) 0};

/* XM_CONTENT_CONCATENATOR */
static EIF_TYPE_INDEX ptf1214[] = {277,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1214 = {1214, ptf1214, (uint16) 2, (uint16) 0, (char) 0};

/* XM_WHITESPACE_NORMALIZER */
static EIF_TYPE_INDEX ptf1215[] = {277,0xFFF7,449,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1215 = {1215, ptf1215, (uint16) 3, (uint16) 0, (char) 0};

/* XM_XMLNS_GENERATOR */
static EIF_TYPE_INDEX ptf1216[] = {277,0xFFF7,449,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1216 = {1216, ptf1216, (uint16) 3, (uint16) 0, (char) 0};

/* XM_NAMESPACE_RESOLVER */
static EIF_TYPE_INDEX ptf1217[] = {277,0xFFF7,449,0xFFF7,388,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1217 = {1217, ptf1217, (uint16) 4, (uint16) 0, (char) 0};

/* XM_EIFFEL_INPUT_STREAM */
static EIF_TYPE_INDEX ptf1218[] = {1205,0xFFF7,452,0xFFF7,1211,0xFFF7,1191,0xFFF7,415,0xFFF7,373,0xFFFF};
static struct eif_par_types par1218 = {1218, ptf1218, (uint16) 6, (uint16) 0, (char) 0};

/* XM_FILE_SOURCE */
static EIF_TYPE_INDEX ptf1219[] = {104,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1219 = {1219, ptf1219, (uint16) 2, (uint16) 0, (char) 0};

/* UC_CHARACTER */
static EIF_TYPE_INDEX ptf1220[] = {261,0xFFF7,1056,0xFFF7,95,0xFFF7,450,0xFFF7,1006,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1220 = {1220, ptf1220, (uint16) 6, (uint16) 0, (char) 0};

/* ET_ECF_BUILD_CONDITION */
static EIF_TYPE_INDEX ptf1221[] = {163,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1221 = {1221, ptf1221, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_PLATFORM_CONDITION */
static EIF_TYPE_INDEX ptf1222[] = {163,0xFFF7,1211,0xFFF7,416,0xFFFF};
static struct eif_par_types par1222 = {1222, ptf1222, (uint16) 3, (uint16) 0, (char) 0};

/* ET_ECF_CUSTOM_CONDITION */
static EIF_TYPE_INDEX ptf1223[] = {163,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1223 = {1223, ptf1223, (uint16) 2, (uint16) 0, (char) 0};

/* XM_NAMESPACE */
static EIF_TYPE_INDEX ptf1224[] = {1056,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1224 = {1224, ptf1224, (uint16) 2, (uint16) 0, (char) 0};

/* XM_EIFFEL_PARSER_NAME */
static EIF_TYPE_INDEX ptf1225[] = {1056,0xFFF7,449,0xFFF7,388,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1225 = {1225, ptf1225, (uint16) 4, (uint16) 0, (char) 0};

/* KL_INTEGER_ROUTINES */
static EIF_TYPE_INDEX ptf1226[] = {95,0xFFF7,1211,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1226 = {1226, ptf1226, (uint16) 3, (uint16) 0, (char) 0};

/* KL_STRING_INPUT_STREAM */
static EIF_TYPE_INDEX ptf1227[] = {1206,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1227 = {1227, ptf1227, (uint16) 2, (uint16) 0, (char) 0};

/* KL_STDIN_FILE */
static EIF_TYPE_INDEX ptf1228[] = {1206,0xFFF7,1211,0xFFF7,425,0xFFFF};
static struct eif_par_types par1228 = {1228, ptf1228, (uint16) 3, (uint16) 0, (char) 0};

/* AP_OPTION_COMPARATOR */
static EIF_TYPE_INDEX ptf1229[] = {466,0xFF01,222,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1229 = {1229, ptf1229, (uint16) 2, (uint16) 0, (char) 0};

/* ST_WORD_WRAPPER */
static EIF_TYPE_INDEX ptf1230[] = {1211,0xFFFF};
static struct eif_par_types par1230 = {1230, ptf1230, (uint16) 1, (uint16) 0, (char) 0};

/* KL_CASE_INSENSITIVE_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf1231[] = {453,0xFF01,1189,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1231 = {1231, ptf1231, (uint16) 2, (uint16) 0, (char) 0};

/* ET_BUILTIN_FEATURE_CHECKER */
static EIF_TYPE_INDEX ptf1232[] = {1031,0xFFF7,254,0xFFF7,424,0xFFF7,984,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1232 = {1232, ptf1232, (uint16) 5, (uint16) 0, (char) 0};

/* UC_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf1233[] = {453,0xFF01,1189,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1233 = {1233, ptf1233, (uint16) 2, (uint16) 0, (char) 0};

/* GELINT */
static EIF_TYPE_INDEX ptf1234[] = {140,0xFFF7,355,0xFFF7,354,0xFFF7,471,0xFFF7,452,0xFFF7,387,0xFFF7,470,0xFFF7,155,0xFFF7,154,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1234 = {1234, ptf1234, (uint16) 10, (uint16) 0, (char) 0};

/* ET_FEATURE_CHECKER */
static EIF_TYPE_INDEX ptf1235[] = {1031,0xFFF7,254,0xFFF7,192,0xFFF7,95,0xFFF7,1006,0xFFF7,1191,0xFFF7,1211,0xFFF7,470,0xFFFF};
static struct eif_par_types par1235 = {1235, ptf1235, (uint16) 8, (uint16) 0, (char) 0};

/* KI_CHARACTER_OUTPUT_STREAM */
static EIF_TYPE_INDEX ptf1236[] = {73,1126,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1236 = {1236, ptf1236, (uint16) 2, (uint16) 0, (char) 0};

/* KI_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1237[] = {186,0xFFF7,1236,0xFFFF};
static struct eif_par_types par1237 = {1237, ptf1237, (uint16) 2, (uint16) 0, (char) 0};

/* KI_BINARY_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1238[] = {1237,0xFFFF};
static struct eif_par_types par1238 = {1238, ptf1238, (uint16) 1, (uint16) 0, (char) 0};

/* KI_TEXT_OUTPUT_STREAM */
static EIF_TYPE_INDEX ptf1239[] = {1236,0xFFFF};
static struct eif_par_types par1239 = {1239, ptf1239, (uint16) 1, (uint16) 0, (char) 0};

/* KL_NULL_TEXT_OUTPUT_STREAM */
static EIF_TYPE_INDEX ptf1240[] = {1239,0xFFFF};
static struct eif_par_types par1240 = {1240, ptf1240, (uint16) 1, (uint16) 0, (char) 0};

/* KL_STDERR_FILE */
static EIF_TYPE_INDEX ptf1241[] = {1239,0xFFFF};
static struct eif_par_types par1241 = {1241, ptf1241, (uint16) 1, (uint16) 0, (char) 0};

/* KL_STDOUT_FILE */
static EIF_TYPE_INDEX ptf1242[] = {1239,0xFFFF};
static struct eif_par_types par1242 = {1242, ptf1242, (uint16) 1, (uint16) 0, (char) 0};

/* KI_TEXT_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1243[] = {1237,0xFFF7,1239,0xFFFF};
static struct eif_par_types par1243 = {1243, ptf1243, (uint16) 2, (uint16) 0, (char) 0};

/* KL_STRING_VALUES */
static EIF_TYPE_INDEX ptf1244[] = {207,0xFF01,1189,0xFF01,1189,0xFFF7,1211,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1244 = {1244, ptf1244, (uint16) 3, (uint16) 0, (char) 0};

/* KL_EXECUTION_ENVIRONMENT */
static EIF_TYPE_INDEX ptf1245[] = {1244,0xFFFF};
static struct eif_par_types par1245 = {1245, ptf1245, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_VARIABLES */
static EIF_TYPE_INDEX ptf1246[] = {1244,0xFFF7,471,0xFFF7,986,0xFFFF};
static struct eif_par_types par1246 = {1246, ptf1246, (uint16) 3, (uint16) 0, (char) 0};

/* ET_ECF_SETTINGS */
static EIF_TYPE_INDEX ptf1247[] = {1244,0xFFF7,986,0xFFFF};
static struct eif_par_types par1247 = {1247, ptf1247, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DYNAMIC_TYPE_BUILDER */
static EIF_TYPE_INDEX ptf1248[] = {265,0xFFF7,1235,0xFFF7,1211,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1248 = {1248, ptf1248, (uint16) 4, (uint16) 0, (char) 0};

/* ET_DYNAMIC_PUSH_TYPE_SET_BUILDER */
static EIF_TYPE_INDEX ptf1249[] = {1248,0xFFFF};
static struct eif_par_types par1249 = {1249, ptf1249, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DYNAMIC_PULL_TYPE_SET_BUILDER */
static EIF_TYPE_INDEX ptf1250[] = {1248,0xFFFF};
static struct eif_par_types par1250 = {1250, ptf1250, (uint16) 1, (uint16) 0, (char) 0};

/* UT_INTEGER_FORMATTER */
static EIF_TYPE_INDEX ptf1251[] = {0,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1251 = {1251, ptf1251, (uint16) 2, (uint16) 0, (char) 0};

/* THREAD_ATTRIBUTES */
static EIF_TYPE_INDEX ptf1252[] = {0,0xFFF7,69,0xFFFF};
static struct eif_par_types par1252 = {1252, ptf1252, (uint16) 2, (uint16) 0, (char) 0};

/* ET_STANDARD_ONCE_KEYS */
static EIF_TYPE_INDEX ptf1253[] = {0,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1253 = {1253, ptf1253, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_AST_FACTORY */
static EIF_TYPE_INDEX ptf1254[] = {0,0xFFF7,986,0xFFFF};
static struct eif_par_types par1254 = {1254, ptf1254, (uint16) 2, (uint16) 0, (char) 0};

/* RX_BYTE_CODE */
static EIF_TYPE_INDEX ptf1255[] = {0,0xFFF7,451,0xFFFF};
static struct eif_par_types par1255 = {1255, ptf1255, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ATTACHMENT_SCOPE */
static EIF_TYPE_INDEX ptf1256[] = {0,0xFFF7,79,0xFFFF};
static struct eif_par_types par1256 = {1256, ptf1256, (uint16) 2, (uint16) 0, (char) 0};

/* ST_SPLITTER */
static EIF_TYPE_INDEX ptf1257[] = {0,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1257 = {1257, ptf1257, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_TARGETS */
static EIF_TYPE_INDEX ptf1258[] = {0,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1258 = {1258, ptf1258, (uint16) 2, (uint16) 0, (char) 0};

/* XM_TREE_CALLBACKS_PIPE */
static EIF_TYPE_INDEX ptf1259[] = {0,0xFFF7,99,0xFFFF};
static struct eif_par_types par1259 = {1259, ptf1259, (uint16) 2, (uint16) 0, (char) 0};

/* KL_TYPE [G#1] */
static EIF_TYPE_INDEX ptf1260[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1260 = {1260, ptf1260, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1261[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1261 = {1261, ptf1261, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1262[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1262 = {1262, ptf1262, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [NATURAL_64] */
static EIF_TYPE_INDEX ptf1263[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1263 = {1263, ptf1263, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [NATURAL_32] */
static EIF_TYPE_INDEX ptf1264[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1264 = {1264, ptf1264, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [NATURAL_8] */
static EIF_TYPE_INDEX ptf1265[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1265 = {1265, ptf1265, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1266[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1266 = {1266, ptf1266, (uint16) 2, (uint16) 1, (char) 0};

/* CONSOLE */
static EIF_TYPE_INDEX ptf1267[] = {793,0xFFF7,0,0xFFFF};
static struct eif_par_types par1267 = {1267, ptf1267, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ISE_VARIABLES */
static EIF_TYPE_INDEX ptf1268[] = {0,0xFFF7,471,0xFFFF};
static struct eif_par_types par1268 = {1268, ptf1268, (uint16) 2, (uint16) 0, (char) 0};

/* UC_V510_CTYPE_TITLECASE */
static EIF_TYPE_INDEX ptf1269[] = {0,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1269 = {1269, ptf1269, (uint16) 2, (uint16) 0, (char) 0};

/* UC_V510_CTYPE_UPPERCASE */
static EIF_TYPE_INDEX ptf1270[] = {0,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1270 = {1270, ptf1270, (uint16) 2, (uint16) 0, (char) 0};

/* UC_V510_CTYPE_LOWERCASE */
static EIF_TYPE_INDEX ptf1271[] = {0,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1271 = {1271, ptf1271, (uint16) 2, (uint16) 0, (char) 0};

/* UC_V510_CTYPE */
static EIF_TYPE_INDEX ptf1272[] = {1271,0xFFF7,1270,0xFFF7,1269,0xFFF7,97,0xFFFF};
static struct eif_par_types par1272 = {1272, ptf1272, (uint16) 4, (uint16) 0, (char) 0};

/* UC_CTYPE */
static EIF_TYPE_INDEX ptf1273[] = {1272,0xFFFF};
static struct eif_par_types par1273 = {1273, ptf1273, (uint16) 1, (uint16) 0, (char) 0};

/* YY_SCANNER */
static EIF_TYPE_INDEX ptf1274[] = {0,0xFFF7,452,0xFFFF};
static struct eif_par_types par1274 = {1274, ptf1274, (uint16) 2, (uint16) 0, (char) 0};

/* YY_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf1275[] = {1274,0xFFF7,451,0xFFF7,1211,0xFFF7,984,0xFFFF};
static struct eif_par_types par1275 = {1275, ptf1275, (uint16) 4, (uint16) 0, (char) 0};

/* YY_FULL_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf1276[] = {1275,0xFFFF};
static struct eif_par_types par1276 = {1276, ptf1276, (uint16) 1, (uint16) 0, (char) 0};

/* YY_COMPRESSED_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf1277[] = {1275,0xFFFF};
static struct eif_par_types par1277 = {1277, ptf1277, (uint16) 1, (uint16) 0, (char) 0};

/* LX_LEX_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf1278[] = {1277,0xFFF7,281,0xFFF7,1211,0xFFF7,986,0xFFFF};
static struct eif_par_types par1278 = {1278, ptf1278, (uint16) 4, (uint16) 0, (char) 0};

/* XM_STRING_MODE */
static EIF_TYPE_INDEX ptf1279[] = {0,0xFFF7,172,0xFFFF};
static struct eif_par_types par1279 = {1279, ptf1279, (uint16) 2, (uint16) 0, (char) 0};

/* XM_PARSER */
static EIF_TYPE_INDEX ptf1280[] = {1279,0xFFF7,100,0xFFF7,273,0xFFF7,190,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1280 = {1280, ptf1280, (uint16) 5, (uint16) 0, (char) 0};

/* XM_NON_INCREMENTAL_PARSER */
static EIF_TYPE_INDEX ptf1281[] = {1280,0xFFFF};
static struct eif_par_types par1281 = {1281, ptf1281, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_ESCAPE_CONSTANTS */
static EIF_TYPE_INDEX ptf1282[] = {0,0xFFF7,215,0xFFFF};
static struct eif_par_types par1282 = {1282, ptf1282, (uint16) 2, (uint16) 0, (char) 0};

/* KL_GREGORIAN_CALENDAR */
static EIF_TYPE_INDEX ptf1283[] = {0,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1283 = {1283, ptf1283, (uint16) 2, (uint16) 0, (char) 0};

/* DT_GREGORIAN_CALENDAR */
static EIF_TYPE_INDEX ptf1284[] = {1283,0xFFF7,291,0xFFFF};
static struct eif_par_types par1284 = {1284, ptf1284, (uint16) 2, (uint16) 0, (char) 0};

/* DT_WEEK_DAYS_FROM_SUNDAY */
static EIF_TYPE_INDEX ptf1285[] = {1284,0xFFFF};
static struct eif_par_types par1285 = {1285, ptf1285, (uint16) 1, (uint16) 0, (char) 0};

/* DT_WEEK_DAYS_FROM_MONDAY */
static EIF_TYPE_INDEX ptf1286[] = {1284,0xFFFF};
static struct eif_par_types par1286 = {1286, ptf1286, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ADAPTED_LIBRARIES */
static EIF_TYPE_INDEX ptf1287[] = {0,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1287 = {1287, ptf1287, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_ADAPTED_LIBRARIES */
static EIF_TYPE_INDEX ptf1288[] = {1287,0xFFFF};
static struct eif_par_types par1288 = {1288, ptf1288, (uint16) 1, (uint16) 0, (char) 0};

/* ET_POSITION */
static EIF_TYPE_INDEX ptf1289[] = {0,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1289 = {1289, ptf1289, (uint16) 2, (uint16) 0, (char) 0};

/* ET_COMPRESSED_POSITION */
static EIF_TYPE_INDEX ptf1290[] = {1289,0xFFFF};
static struct eif_par_types par1290 = {1290, ptf1290, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FILE_POSITION */
static EIF_TYPE_INDEX ptf1291[] = {1290,0xFFFF};
static struct eif_par_types par1291 = {1291, ptf1291, (uint16) 1, (uint16) 0, (char) 0};

/* UT_VERSION */
static EIF_TYPE_INDEX ptf1292[] = {0,0xFFF7,261,0xFFFF};
static struct eif_par_types par1292 = {1292, ptf1292, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_VERSION */
static EIF_TYPE_INDEX ptf1293[] = {1292,0xFFFF};
static struct eif_par_types par1293 = {1293, ptf1293, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SYSTEM_PROCESSOR */
static EIF_TYPE_INDEX ptf1294[] = {0,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1294 = {1294, ptf1294, (uint16) 2, (uint16) 0, (char) 0};

/* ET_SYSTEM_MULTIPROCESSOR */
static EIF_TYPE_INDEX ptf1295[] = {1294,0xFFFF};
static struct eif_par_types par1295 = {1295, ptf1295, (uint16) 1, (uint16) 0, (char) 0};

/* ENCODING_I */
static EIF_TYPE_INDEX ptf1296[] = {0,0xFFFF};
static struct eif_par_types par1296 = {1296, ptf1296, (uint16) 1, (uint16) 0, (char) 0};

/* UNICODE_CONVERSION */
static EIF_TYPE_INDEX ptf1297[] = {1296,0xFFFF};
static struct eif_par_types par1297 = {1297, ptf1297, (uint16) 1, (uint16) 0, (char) 0};

/* ENCODING_IMP */
static EIF_TYPE_INDEX ptf1298[] = {1296,0xFFFF};
static struct eif_par_types par1298 = {1298, ptf1298, (uint16) 1, (uint16) 0, (char) 0};

/* ET_REPLICABLE_FEATURE */
static EIF_TYPE_INDEX ptf1299[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1299 = {1299, ptf1299, (uint16) 2, (uint16) 0, (char) 0};

/* ET_REPLICATED_FEATURE */
static EIF_TYPE_INDEX ptf1300[] = {1299,0xFFFF};
static struct eif_par_types par1300 = {1300, ptf1300, (uint16) 1, (uint16) 0, (char) 0};

/* XM_POSITION */
static EIF_TYPE_INDEX ptf1301[] = {0,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1301 = {1301, ptf1301, (uint16) 2, (uint16) 0, (char) 0};

/* XM_STREAM_POSITION */
static EIF_TYPE_INDEX ptf1302[] = {1301,0xFFFF};
static struct eif_par_types par1302 = {1302, ptf1302, (uint16) 1, (uint16) 0, (char) 0};

/* XM_DEFAULT_POSITION */
static EIF_TYPE_INDEX ptf1303[] = {1301,0xFFF7,1302,0xFFFF};
static struct eif_par_types par1303 = {1303, ptf1303, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ADAPTED_DOTNET_ASSEMBLIES */
static EIF_TYPE_INDEX ptf1304[] = {0,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1304 = {1304, ptf1304, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_ADAPTED_DOTNET_ASSEMBLIES */
static EIF_TYPE_INDEX ptf1305[] = {1304,0xFFFF};
static struct eif_par_types par1305 = {1305, ptf1305, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DOTNET_ASSEMBLIES */
static EIF_TYPE_INDEX ptf1306[] = {1304,0xFFFF};
static struct eif_par_types par1306 = {1306, ptf1306, (uint16) 1, (uint16) 0, (char) 0};

/* DT_WEEK_DAY */
static EIF_TYPE_INDEX ptf1307[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1307 = {1307, ptf1307, (uint16) 2, (uint16) 0, (char) 0};

/* DT_WEEK_DAY_FROM_MONDAY */
static EIF_TYPE_INDEX ptf1308[] = {1307,0xFFF7,1286,0xFFF7,75,0xFFFF};
static struct eif_par_types par1308 = {1308, ptf1308, (uint16) 3, (uint16) 0, (char) 0};

/* DT_WEEK_DAY_FROM_SUNDAY */
static EIF_TYPE_INDEX ptf1309[] = {1307,0xFFF7,1285,0xFFF7,291,0xFFFF};
static struct eif_par_types par1309 = {1309, ptf1309, (uint16) 3, (uint16) 0, (char) 0};

/* ET_FLATTENED_FEATURE */
static EIF_TYPE_INDEX ptf1310[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1310 = {1310, ptf1310, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ADAPTED_FEATURE */
static EIF_TYPE_INDEX ptf1311[] = {1310,0xFFF7,1299,0xFFFF};
static struct eif_par_types par1311 = {1311, ptf1311, (uint16) 2, (uint16) 0, (char) 0};

/* ET_REDECLARED_FEATURE */
static EIF_TYPE_INDEX ptf1312[] = {1311,0xFFFF};
static struct eif_par_types par1312 = {1312, ptf1312, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INHERITED_FEATURE */
static EIF_TYPE_INDEX ptf1313[] = {1311,0xFFFF};
static struct eif_par_types par1313 = {1313, ptf1313, (uint16) 1, (uint16) 0, (char) 0};

/* LX_TABLES */
static EIF_TYPE_INDEX ptf1314[] = {0,0xFFF7,984,0xFFFF};
static struct eif_par_types par1314 = {1314, ptf1314, (uint16) 2, (uint16) 0, (char) 0};

/* LX_SCANNER */
static EIF_TYPE_INDEX ptf1315[] = {1275,0xFFF7,1314,0xFFFF};
static struct eif_par_types par1315 = {1315, ptf1315, (uint16) 2, (uint16) 0, (char) 0};

/* LX_FULL_TABLES */
static EIF_TYPE_INDEX ptf1316[] = {1314,0xFFFF};
static struct eif_par_types par1316 = {1316, ptf1316, (uint16) 1, (uint16) 0, (char) 0};

/* LX_FULL_SCANNER */
static EIF_TYPE_INDEX ptf1317[] = {1315,0xFFF7,1276,0xFFF7,1316,0xFFFF};
static struct eif_par_types par1317 = {1317, ptf1317, (uint16) 3, (uint16) 0, (char) 0};

/* DS_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1318[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1318 = {1318, ptf1318, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1319[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1319 = {1319, ptf1319, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1320[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1320 = {1320, ptf1320, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1321[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1321 = {1321, ptf1321, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1322[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1322 = {1322, ptf1322, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf1323[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1323 = {1323, ptf1323, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1324[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1324 = {1324, ptf1324, (uint16) 2, (uint16) 1, (char) 0};

/* DS_INDEXED_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1325[] = {1318,0xFFF8,1,0xFFFF};
static struct eif_par_types par1325 = {1325, ptf1325, (uint16) 1, (uint16) 1, (char) 0};

/* DS_INDEXED_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1326[] = {1319,1096,0xFFFF};
static struct eif_par_types par1326 = {1326, ptf1326, (uint16) 1, (uint16) 1, (char) 0};

/* DS_INDEXED_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1327[] = {1324,1126,0xFFFF};
static struct eif_par_types par1327 = {1327, ptf1327, (uint16) 1, (uint16) 1, (char) 0};

/* DS_INDEXED_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1328[] = {1322,1108,0xFFFF};
static struct eif_par_types par1328 = {1328, ptf1328, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1329[] = {1318,0xFFF8,1,0xFFFF};
static struct eif_par_types par1329 = {1329, ptf1329, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1330[] = {1319,1096,0xFFFF};
static struct eif_par_types par1330 = {1330, ptf1330, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1331[] = {1320,1129,0xFFFF};
static struct eif_par_types par1331 = {1331, ptf1331, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1332[] = {1321,1105,0xFFFF};
static struct eif_par_types par1332 = {1332, ptf1332, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf1333[] = {1323,1114,0xFFFF};
static struct eif_par_types par1333 = {1333, ptf1333, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1334[] = {1324,1126,0xFFFF};
static struct eif_par_types par1334 = {1334, ptf1334, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1335[] = {1322,1108,0xFFFF};
static struct eif_par_types par1335 = {1335, ptf1335, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1336[] = {1318,0xFFF8,1,0xFFF7,430,0xFFF8,1,0xFFF7,472,0xFFF8,1,0xFFFF};
static struct eif_par_types par1336 = {1336, ptf1336, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1337[] = {1319,1096,0xFFF7,431,1096,0xFFF7,473,1096,0xFFFF};
static struct eif_par_types par1337 = {1337, ptf1337, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1338[] = {1320,1129,0xFFF7,432,1129,0xFFF7,474,1129,0xFFFF};
static struct eif_par_types par1338 = {1338, ptf1338, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1339[] = {1321,1105,0xFFF7,435,1105,0xFFF7,477,1105,0xFFFF};
static struct eif_par_types par1339 = {1339, ptf1339, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1340[] = {1322,1108,0xFFF7,436,1108,0xFFF7,478,1108,0xFFFF};
static struct eif_par_types par1340 = {1340, ptf1340, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf1341[] = {1323,1114,0xFFF7,438,1114,0xFFF7,480,1114,0xFFFF};
static struct eif_par_types par1341 = {1341, ptf1341, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1342[] = {1324,1126,0xFFF7,433,1126,0xFFF7,475,1126,0xFFFF};
static struct eif_par_types par1342 = {1342, ptf1342, (uint16) 3, (uint16) 1, (char) 0};

/* DS_SET_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1343[] = {1336,0xFFF8,1,0xFFFF};
static struct eif_par_types par1343 = {1343, ptf1343, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SET_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1344[] = {1337,1096,0xFFFF};
static struct eif_par_types par1344 = {1344, ptf1344, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1345[] = {1336,0xFFF8,1,0xFFFF};
static struct eif_par_types par1345 = {1345, ptf1345, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1346[] = {1337,1096,0xFFFF};
static struct eif_par_types par1346 = {1346, ptf1346, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1347[] = {1338,1129,0xFFFF};
static struct eif_par_types par1347 = {1347, ptf1347, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1348[] = {1339,1105,0xFFFF};
static struct eif_par_types par1348 = {1348, ptf1348, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1349[] = {1340,1108,0xFFFF};
static struct eif_par_types par1349 = {1349, ptf1349, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf1350[] = {1341,1114,0xFFFF};
static struct eif_par_types par1350 = {1350, ptf1350, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1351[] = {1342,1126,0xFFFF};
static struct eif_par_types par1351 = {1351, ptf1351, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1352[] = {1345,0xFFF8,2,0xFFFF};
static struct eif_par_types par1352 = {1352, ptf1352, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1353[] = {1345,0xFFF8,2,0xFFFF};
static struct eif_par_types par1353 = {1353, ptf1353, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1354[] = {1345,0xFFF8,2,0xFFFF};
static struct eif_par_types par1354 = {1354, ptf1354, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1355[] = {1346,1096,0xFFFF};
static struct eif_par_types par1355 = {1355, ptf1355, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1356[] = {1349,1108,0xFFFF};
static struct eif_par_types par1356 = {1356, ptf1356, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf1357[] = {1350,1114,0xFFFF};
static struct eif_par_types par1357 = {1357, ptf1357, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf1358[] = {1345,0xFFF8,2,0xFFFF};
static struct eif_par_types par1358 = {1358, ptf1358, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1359[] = {1346,1096,0xFFFF};
static struct eif_par_types par1359 = {1359, ptf1359, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1360[] = {1345,0xFFF8,1,0xFFFF};
static struct eif_par_types par1360 = {1360, ptf1360, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1361[] = {1346,1096,0xFFFF};
static struct eif_par_types par1361 = {1361, ptf1361, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1362[] = {1347,1129,0xFFFF};
static struct eif_par_types par1362 = {1362, ptf1362, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1363[] = {1345,0xFFF8,1,0xFFFF};
static struct eif_par_types par1363 = {1363, ptf1363, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1364[] = {1348,1105,0xFFFF};
static struct eif_par_types par1364 = {1364, ptf1364, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf1365[] = {1345,0xFFF8,1,0xFFFF};
static struct eif_par_types par1365 = {1365, ptf1365, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf1366[] = {1350,1114,0xFFFF};
static struct eif_par_types par1366 = {1366, ptf1366, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1367[] = {1346,1096,0xFFFF};
static struct eif_par_types par1367 = {1367, ptf1367, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1368[] = {1345,0xFFF8,1,0xFFF7,962,0xFFFF};
static struct eif_par_types par1368 = {1368, ptf1368, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1369[] = {1346,1096,0xFFF7,962,0xFFFF};
static struct eif_par_types par1369 = {1369, ptf1369, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1370[] = {1347,1129,0xFFF7,962,0xFFFF};
static struct eif_par_types par1370 = {1370, ptf1370, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1371[] = {1345,0xFFF8,1,0xFFF7,962,0xFFFF};
static struct eif_par_types par1371 = {1371, ptf1371, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1372[] = {1346,1096,0xFFF7,962,0xFFFF};
static struct eif_par_types par1372 = {1372, ptf1372, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1373[] = {1348,1105,0xFFF7,962,0xFFFF};
static struct eif_par_types par1373 = {1373, ptf1373, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf1374[] = {1345,0xFFF8,1,0xFFF7,962,0xFFFF};
static struct eif_par_types par1374 = {1374, ptf1374, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf1375[] = {1350,1114,0xFFF7,962,0xFFFF};
static struct eif_par_types par1375 = {1375, ptf1375, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1376[] = {1368,0xFFF8,1,0xFFF8,2,0xFFF7,1360,0xFFF8,1,0xFFF8,2,0xFFF7,1329,0xFFF8,1,0xFFFF};
static struct eif_par_types par1376 = {1376, ptf1376, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1377[] = {1369,1096,0xFFF8,2,0xFFF7,1361,1096,0xFFF8,2,0xFFF7,1330,1096,0xFFFF};
static struct eif_par_types par1377 = {1377, ptf1377, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1378[] = {1370,1129,0xFFF8,2,0xFFF7,1362,1129,0xFFF8,2,0xFFF7,1331,1129,0xFFFF};
static struct eif_par_types par1378 = {1378, ptf1378, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1379[] = {1371,0xFFF8,1,1096,0xFFF7,1363,0xFFF8,1,1096,0xFFF7,1329,0xFFF8,1,0xFFFF};
static struct eif_par_types par1379 = {1379, ptf1379, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1380[] = {1373,1105,1108,0xFFF7,1364,1105,1108,0xFFF7,1332,1105,0xFFFF};
static struct eif_par_types par1380 = {1380, ptf1380, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf1381[] = {1374,0xFFF8,1,1114,0xFFF7,1365,0xFFF8,1,1114,0xFFF7,1329,0xFFF8,1,0xFFFF};
static struct eif_par_types par1381 = {1381, ptf1381, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf1382[] = {1375,1114,0xFFF8,2,0xFFF7,1366,1114,0xFFF8,2,0xFFF7,1333,1114,0xFFFF};
static struct eif_par_types par1382 = {1382, ptf1382, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1383[] = {1372,1096,1096,0xFFF7,1367,1096,1096,0xFFF7,1330,1096,0xFFFF};
static struct eif_par_types par1383 = {1383, ptf1383, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1384[] = {1376,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1384 = {1384, ptf1384, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1385[] = {1377,1096,0xFFF8,2,0xFFFF};
static struct eif_par_types par1385 = {1385, ptf1385, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1386[] = {1378,1129,0xFFF8,2,0xFFFF};
static struct eif_par_types par1386 = {1386, ptf1386, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1387[] = {1379,0xFFF8,1,1096,0xFFFF};
static struct eif_par_types par1387 = {1387, ptf1387, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1388[] = {1380,1105,1108,0xFFFF};
static struct eif_par_types par1388 = {1388, ptf1388, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf1389[] = {1381,0xFFF8,1,1114,0xFFFF};
static struct eif_par_types par1389 = {1389, ptf1389, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf1390[] = {1382,1114,0xFFF8,2,0xFFFF};
static struct eif_par_types par1390 = {1390, ptf1390, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1391[] = {1383,1096,1096,0xFFFF};
static struct eif_par_types par1391 = {1391, ptf1391, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1392[] = {1384,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1392 = {1392, ptf1392, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1393[] = {1385,1096,0xFFF8,2,0xFFFF};
static struct eif_par_types par1393 = {1393, ptf1393, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1394[] = {1386,1129,0xFFF8,2,0xFFFF};
static struct eif_par_types par1394 = {1394, ptf1394, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1395[] = {1387,0xFFF8,1,1096,0xFFFF};
static struct eif_par_types par1395 = {1395, ptf1395, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1396[] = {1388,1105,1108,0xFFFF};
static struct eif_par_types par1396 = {1396, ptf1396, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf1397[] = {1389,0xFFF8,1,1114,0xFFFF};
static struct eif_par_types par1397 = {1397, ptf1397, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf1398[] = {1390,1114,0xFFF8,2,0xFFFF};
static struct eif_par_types par1398 = {1398, ptf1398, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1399[] = {1391,1096,1096,0xFFFF};
static struct eif_par_types par1399 = {1399, ptf1399, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_SET_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1400[] = {1368,0xFFF8,1,0xFFF8,1,0xFFF7,1343,0xFFF8,1,0xFFFF};
static struct eif_par_types par1400 = {1400, ptf1400, (uint16) 2, (uint16) 1, (char) 0};

/* DS_SPARSE_SET_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1401[] = {1372,1096,1096,0xFFF7,1344,1096,0xFFFF};
static struct eif_par_types par1401 = {1401, ptf1401, (uint16) 2, (uint16) 1, (char) 0};

/* DS_ARRAYED_SPARSE_SET_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1402[] = {1400,0xFFF8,1,0xFFFF};
static struct eif_par_types par1402 = {1402, ptf1402, (uint16) 1, (uint16) 1, (char) 0};

/* DS_ARRAYED_SPARSE_SET_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1403[] = {1401,1096,0xFFFF};
static struct eif_par_types par1403 = {1403, ptf1403, (uint16) 1, (uint16) 1, (char) 0};

/* DS_HASH_SET_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1404[] = {1402,0xFFF8,1,0xFFFF};
static struct eif_par_types par1404 = {1404, ptf1404, (uint16) 1, (uint16) 1, (char) 0};

/* DS_HASH_SET_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1405[] = {1403,1096,0xFFFF};
static struct eif_par_types par1405 = {1405, ptf1405, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1406[] = {1345,0xFFF8,1,0xFFF7,1329,0xFFF8,1,0xFFF7,1325,0xFFF8,1,0xFFFF};
static struct eif_par_types par1406 = {1406, ptf1406, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LIST_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1407[] = {1346,1096,0xFFF7,1330,1096,0xFFF7,1326,1096,0xFFFF};
static struct eif_par_types par1407 = {1407, ptf1407, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LIST_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1408[] = {1351,1126,0xFFF7,1334,1126,0xFFF7,1327,1126,0xFFFF};
static struct eif_par_types par1408 = {1408, ptf1408, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LIST_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1409[] = {1349,1108,0xFFF7,1335,1108,0xFFF7,1328,1108,0xFFFF};
static struct eif_par_types par1409 = {1409, ptf1409, (uint16) 3, (uint16) 1, (char) 0};

/* DS_ARRAYED_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1410[] = {1406,0xFFF8,1,0xFFF7,962,0xFFFF};
static struct eif_par_types par1410 = {1410, ptf1410, (uint16) 2, (uint16) 1, (char) 0};

/* DS_ARRAYED_LIST_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1411[] = {1407,1096,0xFFF7,962,0xFFFF};
static struct eif_par_types par1411 = {1411, ptf1411, (uint16) 2, (uint16) 1, (char) 0};

/* DS_ARRAYED_LIST_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1412[] = {1409,1108,0xFFF7,962,0xFFFF};
static struct eif_par_types par1412 = {1412, ptf1412, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1413[] = {1406,0xFFF8,1,0xFFFF};
static struct eif_par_types par1413 = {1413, ptf1413, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKED_LIST_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1414[] = {1407,1096,0xFFFF};
static struct eif_par_types par1414 = {1414, ptf1414, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKED_LIST_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1415[] = {1408,1126,0xFFFF};
static struct eif_par_types par1415 = {1415, ptf1415, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINKED_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1416[] = {1413,0xFFF8,1,0xFFFF};
static struct eif_par_types par1416 = {1416, ptf1416, (uint16) 1, (uint16) 1, (char) 0};

/* KL_CLONABLE */
static EIF_TYPE_INDEX ptf1417[] = {0,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1417 = {1417, ptf1417, (uint16) 2, (uint16) 0, (char) 0};

/* LX_TRANSITION_TABLE [G#1] */
static EIF_TYPE_INDEX ptf1418[] = {0,0xFFF7,1417,0xFFFF};
static struct eif_par_types par1418 = {1418, ptf1418, (uint16) 2, (uint16) 1, (char) 0};

/* LX_STATE */
static EIF_TYPE_INDEX ptf1419[] = {1417,0xFFFF};
static struct eif_par_types par1419 = {1419, ptf1419, (uint16) 1, (uint16) 0, (char) 0};

/* LX_NFA_STATE */
static EIF_TYPE_INDEX ptf1420[] = {1419,0xFFF7,261,0xFFFF};
static struct eif_par_types par1420 = {1420, ptf1420, (uint16) 2, (uint16) 0, (char) 0};

/* LX_DFA_STATE */
static EIF_TYPE_INDEX ptf1421[] = {1419,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1421 = {1421, ptf1421, (uint16) 2, (uint16) 0, (char) 0};

/* LX_AUTOMATON */
static EIF_TYPE_INDEX ptf1422[] = {1417,0xFFFF};
static struct eif_par_types par1422 = {1422, ptf1422, (uint16) 1, (uint16) 0, (char) 0};

/* LX_NFA */
static EIF_TYPE_INDEX ptf1423[] = {1422,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1423 = {1423, ptf1423, (uint16) 2, (uint16) 0, (char) 0};

/* LX_DFA */
static EIF_TYPE_INDEX ptf1424[] = {1422,0xFFFF};
static struct eif_par_types par1424 = {1424, ptf1424, (uint16) 1, (uint16) 0, (char) 0};

/* LX_GENERATABLE_DFA */
static EIF_TYPE_INDEX ptf1425[] = {1424,0xFFF7,1314,0xFFF7,281,0xFFF7,1006,0xFFF7,1211,0xFFF7,364,0xFFFF};
static struct eif_par_types par1425 = {1425, ptf1425, (uint16) 6, (uint16) 0, (char) 0};

/* LX_FULL_DFA */
static EIF_TYPE_INDEX ptf1426[] = {1425,0xFFF7,1316,0xFFFF};
static struct eif_par_types par1426 = {1426, ptf1426, (uint16) 2, (uint16) 0, (char) 0};

/* DT_DURATION */
static EIF_TYPE_INDEX ptf1427[] = {76,0xFFF7,1056,0xFFF7,1417,0xFFFF};
static struct eif_par_types par1427 = {1427, ptf1427, (uint16) 3, (uint16) 0, (char) 0};

/* DT_ABSOLUTE_TIME */
static EIF_TYPE_INDEX ptf1428[] = {261,0xFFF7,1056,0xFFF7,1417,0xFFFF};
static struct eif_par_types par1428 = {1428, ptf1428, (uint16) 3, (uint16) 0, (char) 0};

/* LX_TRANSITION [G#1] */
static EIF_TYPE_INDEX ptf1429[] = {1417,0xFFFF};
static struct eif_par_types par1429 = {1429, ptf1429, (uint16) 1, (uint16) 1, (char) 0};

/* LX_SYMBOL_TRANSITION [G#1] */
static EIF_TYPE_INDEX ptf1430[] = {1429,0xFFF8,1,0xFFFF};
static struct eif_par_types par1430 = {1430, ptf1430, (uint16) 1, (uint16) 1, (char) 0};

/* LX_SYMBOL_CLASS_TRANSITION [G#1] */
static EIF_TYPE_INDEX ptf1431[] = {1429,0xFFF8,1,0xFFFF};
static struct eif_par_types par1431 = {1431, ptf1431, (uint16) 1, (uint16) 1, (char) 0};

/* LX_EPSILON_TRANSITION [G#1] */
static EIF_TYPE_INDEX ptf1432[] = {1429,0xFFF8,1,0xFFFF};
static struct eif_par_types par1432 = {1432, ptf1432, (uint16) 1, (uint16) 1, (char) 0};

/* DS_CONTAINER [G#1] */
static EIF_TYPE_INDEX ptf1433[] = {0,0xFFF7,1417,0xFFFF};
static struct eif_par_types par1433 = {1433, ptf1433, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [INTEGER_32] */
static EIF_TYPE_INDEX ptf1434[] = {0,0xFFF7,1417,0xFFFF};
static struct eif_par_types par1434 = {1434, ptf1434, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [BOOLEAN] */
static EIF_TYPE_INDEX ptf1435[] = {0,0xFFF7,1417,0xFFFF};
static struct eif_par_types par1435 = {1435, ptf1435, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [NATURAL_64] */
static EIF_TYPE_INDEX ptf1436[] = {0,0xFFF7,1417,0xFFFF};
static struct eif_par_types par1436 = {1436, ptf1436, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [NATURAL_32] */
static EIF_TYPE_INDEX ptf1437[] = {0,0xFFF7,1417,0xFFFF};
static struct eif_par_types par1437 = {1437, ptf1437, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [NATURAL_8] */
static EIF_TYPE_INDEX ptf1438[] = {0,0xFFF7,1417,0xFFFF};
static struct eif_par_types par1438 = {1438, ptf1438, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1439[] = {0,0xFFF7,1417,0xFFFF};
static struct eif_par_types par1439 = {1439, ptf1439, (uint16) 2, (uint16) 1, (char) 0};

/* DS_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1440[] = {1433,0xFFF8,1,0xFFF7,207,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1440 = {1440, ptf1440, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1441[] = {1434,1096,0xFFF7,208,1096,0xFFF8,2,0xFFFF};
static struct eif_par_types par1441 = {1441, ptf1441, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1442[] = {1435,1129,0xFFF7,209,1129,0xFFF8,2,0xFFFF};
static struct eif_par_types par1442 = {1442, ptf1442, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1443[] = {1433,0xFFF8,1,0xFFF7,210,0xFFF8,1,1096,0xFFFF};
static struct eif_par_types par1443 = {1443, ptf1443, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1444[] = {1436,1105,0xFFF7,211,1105,1108,0xFFFF};
static struct eif_par_types par1444 = {1444, ptf1444, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf1445[] = {1433,0xFFF8,1,0xFFF7,212,0xFFF8,1,1114,0xFFFF};
static struct eif_par_types par1445 = {1445, ptf1445, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf1446[] = {1438,1114,0xFFF7,213,1114,0xFFF8,2,0xFFFF};
static struct eif_par_types par1446 = {1446, ptf1446, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1447[] = {1434,1096,0xFFF7,214,1096,1096,0xFFFF};
static struct eif_par_types par1447 = {1447, ptf1447, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SORTABLE [G#1] */
static EIF_TYPE_INDEX ptf1448[] = {1433,0xFFF8,1,0xFFFF};
static struct eif_par_types par1448 = {1448, ptf1448, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1449[] = {1434,1096,0xFFFF};
static struct eif_par_types par1449 = {1449, ptf1449, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1450[] = {1439,1126,0xFFFF};
static struct eif_par_types par1450 = {1450, ptf1450, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf1451[] = {1437,1108,0xFFFF};
static struct eif_par_types par1451 = {1451, ptf1451, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [G#1] */
static EIF_TYPE_INDEX ptf1452[] = {1433,0xFFF8,1,0xFFFF};
static struct eif_par_types par1452 = {1452, ptf1452, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1453[] = {1434,1096,0xFFFF};
static struct eif_par_types par1453 = {1453, ptf1453, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1454[] = {1435,1129,0xFFFF};
static struct eif_par_types par1454 = {1454, ptf1454, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf1455[] = {1436,1105,0xFFFF};
static struct eif_par_types par1455 = {1455, ptf1455, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf1456[] = {1437,1108,0xFFFF};
static struct eif_par_types par1456 = {1456, ptf1456, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf1457[] = {1438,1114,0xFFFF};
static struct eif_par_types par1457 = {1457, ptf1457, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1458[] = {1439,1126,0xFFFF};
static struct eif_par_types par1458 = {1458, ptf1458, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [G#1] */
static EIF_TYPE_INDEX ptf1459[] = {1433,0xFFF8,1,0xFFFF};
static struct eif_par_types par1459 = {1459, ptf1459, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1460[] = {1434,1096,0xFFFF};
static struct eif_par_types par1460 = {1460, ptf1460, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1461[] = {1435,1129,0xFFFF};
static struct eif_par_types par1461 = {1461, ptf1461, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf1462[] = {1436,1105,0xFFFF};
static struct eif_par_types par1462 = {1462, ptf1462, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf1463[] = {1437,1108,0xFFFF};
static struct eif_par_types par1463 = {1463, ptf1463, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf1464[] = {1438,1114,0xFFFF};
static struct eif_par_types par1464 = {1464, ptf1464, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1465[] = {1439,1126,0xFFFF};
static struct eif_par_types par1465 = {1465, ptf1465, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINEAR [G#1] */
static EIF_TYPE_INDEX ptf1466[] = {1452,0xFFF8,1,0xFFF7,1459,0xFFF8,1,0xFFF7,472,0xFFF8,1,0xFFFF};
static struct eif_par_types par1466 = {1466, ptf1466, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1467[] = {1453,1096,0xFFF7,1460,1096,0xFFF7,473,1096,0xFFFF};
static struct eif_par_types par1467 = {1467, ptf1467, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1468[] = {1454,1129,0xFFF7,1461,1129,0xFFF7,474,1129,0xFFFF};
static struct eif_par_types par1468 = {1468, ptf1468, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1469[] = {1455,1105,0xFFF7,1462,1105,0xFFF7,477,1105,0xFFFF};
static struct eif_par_types par1469 = {1469, ptf1469, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1470[] = {1456,1108,0xFFF7,1463,1108,0xFFF7,478,1108,0xFFFF};
static struct eif_par_types par1470 = {1470, ptf1470, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [NATURAL_8] */
static EIF_TYPE_INDEX ptf1471[] = {1457,1114,0xFFF7,1464,1114,0xFFF7,480,1114,0xFFFF};
static struct eif_par_types par1471 = {1471, ptf1471, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1472[] = {1458,1126,0xFFF7,1465,1126,0xFFF7,475,1126,0xFFFF};
static struct eif_par_types par1472 = {1472, ptf1472, (uint16) 3, (uint16) 1, (char) 0};

/* DS_BILINEAR [G#1] */
static EIF_TYPE_INDEX ptf1473[] = {1466,0xFFF8,1,0xFFFF};
static struct eif_par_types par1473 = {1473, ptf1473, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1474[] = {1467,1096,0xFFFF};
static struct eif_par_types par1474 = {1474, ptf1474, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1475[] = {1468,1129,0xFFFF};
static struct eif_par_types par1475 = {1475, ptf1475, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1476[] = {1469,1105,0xFFFF};
static struct eif_par_types par1476 = {1476, ptf1476, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1477[] = {1470,1108,0xFFFF};
static struct eif_par_types par1477 = {1477, ptf1477, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [NATURAL_8] */
static EIF_TYPE_INDEX ptf1478[] = {1471,1114,0xFFFF};
static struct eif_par_types par1478 = {1478, ptf1478, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1479[] = {1472,1126,0xFFFF};
static struct eif_par_types par1479 = {1479, ptf1479, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SPARSE_TABLE_KEYS [G#1, G#2] */
static EIF_TYPE_INDEX ptf1480[] = {1473,0xFFF8,2,0xFFFF};
static struct eif_par_types par1480 = {1480, ptf1480, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1481[] = {1473,0xFFF8,2,0xFFFF};
static struct eif_par_types par1481 = {1481, ptf1481, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1482[] = {1473,0xFFF8,2,0xFFFF};
static struct eif_par_types par1482 = {1482, ptf1482, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1483[] = {1474,1096,0xFFFF};
static struct eif_par_types par1483 = {1483, ptf1483, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1484[] = {1477,1108,0xFFFF};
static struct eif_par_types par1484 = {1484, ptf1484, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf1485[] = {1478,1114,0xFFFF};
static struct eif_par_types par1485 = {1485, ptf1485, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf1486[] = {1473,0xFFF8,2,0xFFFF};
static struct eif_par_types par1486 = {1486, ptf1486, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1487[] = {1474,1096,0xFFFF};
static struct eif_par_types par1487 = {1487, ptf1487, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1488[] = {1440,0xFFF8,1,0xFFF8,2,0xFFF7,1473,0xFFF8,1,0xFFFF};
static struct eif_par_types par1488 = {1488, ptf1488, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1489[] = {1441,1096,0xFFF8,2,0xFFF7,1474,1096,0xFFFF};
static struct eif_par_types par1489 = {1489, ptf1489, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1490[] = {1442,1129,0xFFF8,2,0xFFF7,1475,1129,0xFFFF};
static struct eif_par_types par1490 = {1490, ptf1490, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1491[] = {1443,0xFFF8,1,1096,0xFFF7,1473,0xFFF8,1,0xFFFF};
static struct eif_par_types par1491 = {1491, ptf1491, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1492[] = {1444,1105,1108,0xFFF7,1476,1105,0xFFFF};
static struct eif_par_types par1492 = {1492, ptf1492, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf1493[] = {1445,0xFFF8,1,1114,0xFFF7,1473,0xFFF8,1,0xFFFF};
static struct eif_par_types par1493 = {1493, ptf1493, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf1494[] = {1446,1114,0xFFF8,2,0xFFF7,1478,1114,0xFFFF};
static struct eif_par_types par1494 = {1494, ptf1494, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1495[] = {1447,1096,1096,0xFFF7,1474,1096,0xFFFF};
static struct eif_par_types par1495 = {1495, ptf1495, (uint16) 2, (uint16) 2, (char) 0};

/* DS_EXTENDIBLE [G#1] */
static EIF_TYPE_INDEX ptf1496[] = {1459,0xFFF8,1,0xFFFF};
static struct eif_par_types par1496 = {1496, ptf1496, (uint16) 1, (uint16) 1, (char) 0};

/* DS_EXTENDIBLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1497[] = {1460,1096,0xFFFF};
static struct eif_par_types par1497 = {1497, ptf1497, (uint16) 1, (uint16) 1, (char) 0};

/* DS_EXTENDIBLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1498[] = {1465,1126,0xFFFF};
static struct eif_par_types par1498 = {1498, ptf1498, (uint16) 1, (uint16) 1, (char) 0};

/* DS_EXTENDIBLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf1499[] = {1463,1108,0xFFFF};
static struct eif_par_types par1499 = {1499, ptf1499, (uint16) 1, (uint16) 1, (char) 0};

/* DS_EXTENDIBLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1500[] = {1461,1129,0xFFFF};
static struct eif_par_types par1500 = {1500, ptf1500, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SET [G#1] */
static EIF_TYPE_INDEX ptf1501[] = {1466,0xFFF8,1,0xFFF7,1496,0xFFF8,1,0xFFFF};
static struct eif_par_types par1501 = {1501, ptf1501, (uint16) 2, (uint16) 1, (char) 0};

/* DS_SET [INTEGER_32] */
static EIF_TYPE_INDEX ptf1502[] = {1467,1096,0xFFF7,1497,1096,0xFFFF};
static struct eif_par_types par1502 = {1502, ptf1502, (uint16) 2, (uint16) 1, (char) 0};

/* DS_INDEXABLE [G#1] */
static EIF_TYPE_INDEX ptf1503[] = {1448,0xFFF8,1,0xFFF7,1496,0xFFF8,1,0xFFFF};
static struct eif_par_types par1503 = {1503, ptf1503, (uint16) 2, (uint16) 1, (char) 0};

/* DS_INDEXABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1504[] = {1449,1096,0xFFF7,1497,1096,0xFFFF};
static struct eif_par_types par1504 = {1504, ptf1504, (uint16) 2, (uint16) 1, (char) 0};

/* DS_INDEXABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1505[] = {1450,1126,0xFFF7,1498,1126,0xFFFF};
static struct eif_par_types par1505 = {1505, ptf1505, (uint16) 2, (uint16) 1, (char) 0};

/* DS_INDEXABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf1506[] = {1451,1108,0xFFF7,1499,1108,0xFFFF};
static struct eif_par_types par1506 = {1506, ptf1506, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LIST [G#1] */
static EIF_TYPE_INDEX ptf1507[] = {1473,0xFFF8,1,0xFFF7,1503,0xFFF8,1,0xFFFF};
static struct eif_par_types par1507 = {1507, ptf1507, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf1508[] = {1474,1096,0xFFF7,1504,1096,0xFFFF};
static struct eif_par_types par1508 = {1508, ptf1508, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LIST [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1509[] = {1479,1126,0xFFF7,1505,1126,0xFFFF};
static struct eif_par_types par1509 = {1509, ptf1509, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LIST [NATURAL_32] */
static EIF_TYPE_INDEX ptf1510[] = {1477,1108,0xFFF7,1506,1108,0xFFFF};
static struct eif_par_types par1510 = {1510, ptf1510, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_LIST [G#1] */
static EIF_TYPE_INDEX ptf1511[] = {1507,0xFFF8,1,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1511 = {1511, ptf1511, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf1512[] = {1508,1096,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1512 = {1512, ptf1512, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_LIST [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1513[] = {1509,1126,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1513 = {1513, ptf1513, (uint16) 2, (uint16) 1, (char) 0};

/* XM_LINKED_LIST [G#1] */
static EIF_TYPE_INDEX ptf1514[] = {1511,0xFFF8,1,0xFFFF};
static struct eif_par_types par1514 = {1514, ptf1514, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINKED_LIST [G#1] */
static EIF_TYPE_INDEX ptf1515[] = {1511,0xFFF8,1,0xFFFF};
static struct eif_par_types par1515 = {1515, ptf1515, (uint16) 1, (uint16) 1, (char) 0};

/* AP_ALTERNATIVE_OPTIONS_LIST */
static EIF_TYPE_INDEX ptf1516[] = {1511,0xFF01,222,0xFFFF};
static struct eif_par_types par1516 = {1516, ptf1516, (uint16) 1, (uint16) 0, (char) 0};

/* DS_DISPENSER [G#1] */
static EIF_TYPE_INDEX ptf1517[] = {1496,0xFFF8,1,0xFFFF};
static struct eif_par_types par1517 = {1517, ptf1517, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DISPENSER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1518[] = {1498,1126,0xFFFF};
static struct eif_par_types par1518 = {1518, ptf1518, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DISPENSER [BOOLEAN] */
static EIF_TYPE_INDEX ptf1519[] = {1500,1129,0xFFFF};
static struct eif_par_types par1519 = {1519, ptf1519, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DISPENSER [INTEGER_32] */
static EIF_TYPE_INDEX ptf1520[] = {1497,1096,0xFFFF};
static struct eif_par_types par1520 = {1520, ptf1520, (uint16) 1, (uint16) 1, (char) 0};

/* DS_QUEUE [G#1] */
static EIF_TYPE_INDEX ptf1521[] = {1517,0xFFF8,1,0xFFFF};
static struct eif_par_types par1521 = {1521, ptf1521, (uint16) 1, (uint16) 1, (char) 0};

/* DS_QUEUE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1522[] = {1518,1126,0xFFFF};
static struct eif_par_types par1522 = {1522, ptf1522, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKED_QUEUE [G#1] */
static EIF_TYPE_INDEX ptf1523[] = {1521,0xFFF8,1,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1523 = {1523, ptf1523, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_QUEUE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1524[] = {1522,1126,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1524 = {1524, ptf1524, (uint16) 2, (uint16) 1, (char) 0};

/* DS_STACK [G#1] */
static EIF_TYPE_INDEX ptf1525[] = {1517,0xFFF8,1,0xFFFF};
static struct eif_par_types par1525 = {1525, ptf1525, (uint16) 1, (uint16) 1, (char) 0};

/* DS_STACK [BOOLEAN] */
static EIF_TYPE_INDEX ptf1526[] = {1519,1129,0xFFFF};
static struct eif_par_types par1526 = {1526, ptf1526, (uint16) 1, (uint16) 1, (char) 0};

/* DS_STACK [INTEGER_32] */
static EIF_TYPE_INDEX ptf1527[] = {1520,1096,0xFFFF};
static struct eif_par_types par1527 = {1527, ptf1527, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKED_STACK [G#1] */
static EIF_TYPE_INDEX ptf1528[] = {1525,0xFFF8,1,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1528 = {1528, ptf1528, (uint16) 2, (uint16) 1, (char) 0};

/* DS_RESIZABLE [G#1] */
static EIF_TYPE_INDEX ptf1529[] = {1433,0xFFF8,1,0xFFFF};
static struct eif_par_types par1529 = {1529, ptf1529, (uint16) 1, (uint16) 1, (char) 0};

/* DS_RESIZABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1530[] = {1434,1096,0xFFFF};
static struct eif_par_types par1530 = {1530, ptf1530, (uint16) 1, (uint16) 1, (char) 0};

/* DS_RESIZABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1531[] = {1435,1129,0xFFFF};
static struct eif_par_types par1531 = {1531, ptf1531, (uint16) 1, (uint16) 1, (char) 0};

/* DS_RESIZABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf1532[] = {1436,1105,0xFFFF};
static struct eif_par_types par1532 = {1532, ptf1532, (uint16) 1, (uint16) 1, (char) 0};

/* DS_RESIZABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf1533[] = {1438,1114,0xFFFF};
static struct eif_par_types par1533 = {1533, ptf1533, (uint16) 1, (uint16) 1, (char) 0};

/* DS_RESIZABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf1534[] = {1437,1108,0xFFFF};
static struct eif_par_types par1534 = {1534, ptf1534, (uint16) 1, (uint16) 1, (char) 0};

/* DS_ARRAYED_STACK [G#1] */
static EIF_TYPE_INDEX ptf1535[] = {1525,0xFFF8,1,0xFFF7,1529,0xFFF8,1,0xFFF7,1191,0xFFF7,962,0xFFFF};
static struct eif_par_types par1535 = {1535, ptf1535, (uint16) 4, (uint16) 1, (char) 0};

/* DS_ARRAYED_STACK [BOOLEAN] */
static EIF_TYPE_INDEX ptf1536[] = {1526,1129,0xFFF7,1531,1129,0xFFF7,1191,0xFFF7,962,0xFFFF};
static struct eif_par_types par1536 = {1536, ptf1536, (uint16) 4, (uint16) 1, (char) 0};

/* DS_ARRAYED_STACK [INTEGER_32] */
static EIF_TYPE_INDEX ptf1537[] = {1527,1096,0xFFF7,1530,1096,0xFFF7,1191,0xFFF7,962,0xFFFF};
static struct eif_par_types par1537 = {1537, ptf1537, (uint16) 4, (uint16) 1, (char) 0};

/* DS_ARRAYED_LIST [G#1] */
static EIF_TYPE_INDEX ptf1538[] = {1507,0xFFF8,1,0xFFF7,1529,0xFFF8,1,0xFFF7,1191,0xFFF7,962,0xFFFF};
static struct eif_par_types par1538 = {1538, ptf1538, (uint16) 4, (uint16) 1, (char) 0};

/* DS_ARRAYED_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf1539[] = {1508,1096,0xFFF7,1530,1096,0xFFF7,1191,0xFFF7,962,0xFFFF};
static struct eif_par_types par1539 = {1539, ptf1539, (uint16) 4, (uint16) 1, (char) 0};

/* DS_ARRAYED_LIST [NATURAL_32] */
static EIF_TYPE_INDEX ptf1540[] = {1510,1108,0xFFF7,1534,1108,0xFFF7,1191,0xFFF7,962,0xFFFF};
static struct eif_par_types par1540 = {1540, ptf1540, (uint16) 4, (uint16) 1, (char) 0};

/* LX_START_CONDITIONS */
static EIF_TYPE_INDEX ptf1541[] = {1538,0xFF01,4,0xFFF7,1211,0xFFF7,984,0xFFFF};
static struct eif_par_types par1541 = {1541, ptf1541, (uint16) 3, (uint16) 0, (char) 0};

/* DS_SPARSE_CONTAINER [G#1, G#2] */
static EIF_TYPE_INDEX ptf1542[] = {1433,0xFFF8,1,0xFFF7,1473,0xFFF8,1,0xFFF7,1529,0xFFF8,1,0xFFFF};
static struct eif_par_types par1542 = {1542, ptf1542, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1543[] = {1434,1096,0xFFF7,1474,1096,0xFFF7,1530,1096,0xFFFF};
static struct eif_par_types par1543 = {1543, ptf1543, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1544[] = {1435,1129,0xFFF7,1475,1129,0xFFF7,1531,1129,0xFFFF};
static struct eif_par_types par1544 = {1544, ptf1544, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1545[] = {1433,0xFFF8,1,0xFFF7,1473,0xFFF8,1,0xFFF7,1529,0xFFF8,1,0xFFFF};
static struct eif_par_types par1545 = {1545, ptf1545, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1546[] = {1434,1096,0xFFF7,1474,1096,0xFFF7,1530,1096,0xFFFF};
static struct eif_par_types par1546 = {1546, ptf1546, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1547[] = {1436,1105,0xFFF7,1476,1105,0xFFF7,1532,1105,0xFFFF};
static struct eif_par_types par1547 = {1547, ptf1547, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf1548[] = {1433,0xFFF8,1,0xFFF7,1473,0xFFF8,1,0xFFF7,1529,0xFFF8,1,0xFFFF};
static struct eif_par_types par1548 = {1548, ptf1548, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf1549[] = {1438,1114,0xFFF7,1478,1114,0xFFF7,1533,1114,0xFFFF};
static struct eif_par_types par1549 = {1549, ptf1549, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1550[] = {1488,0xFFF8,1,0xFFF8,2,0xFFF7,1542,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1550 = {1550, ptf1550, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1551[] = {1489,1096,0xFFF8,2,0xFFF7,1543,1096,0xFFF8,2,0xFFFF};
static struct eif_par_types par1551 = {1551, ptf1551, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1552[] = {1490,1129,0xFFF8,2,0xFFF7,1544,1129,0xFFF8,2,0xFFFF};
static struct eif_par_types par1552 = {1552, ptf1552, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1553[] = {1491,0xFFF8,1,1096,0xFFF7,1545,0xFFF8,1,1096,0xFFFF};
static struct eif_par_types par1553 = {1553, ptf1553, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1554[] = {1492,1105,1108,0xFFF7,1547,1105,1108,0xFFFF};
static struct eif_par_types par1554 = {1554, ptf1554, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf1555[] = {1493,0xFFF8,1,1114,0xFFF7,1548,0xFFF8,1,1114,0xFFFF};
static struct eif_par_types par1555 = {1555, ptf1555, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf1556[] = {1494,1114,0xFFF8,2,0xFFF7,1549,1114,0xFFF8,2,0xFFFF};
static struct eif_par_types par1556 = {1556, ptf1556, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1557[] = {1495,1096,1096,0xFFF7,1546,1096,1096,0xFFFF};
static struct eif_par_types par1557 = {1557, ptf1557, (uint16) 2, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1558[] = {1550,0xFFF8,1,0xFFF8,2,0xFFF7,451,0xFFF7,962,0xFFFF};
static struct eif_par_types par1558 = {1558, ptf1558, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1559[] = {1551,1096,0xFFF8,2,0xFFF7,451,0xFFF7,962,0xFFFF};
static struct eif_par_types par1559 = {1559, ptf1559, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1560[] = {1552,1129,0xFFF8,2,0xFFF7,451,0xFFF7,962,0xFFFF};
static struct eif_par_types par1560 = {1560, ptf1560, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1561[] = {1553,0xFFF8,1,1096,0xFFF7,451,0xFFF7,962,0xFFFF};
static struct eif_par_types par1561 = {1561, ptf1561, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1562[] = {1554,1105,1108,0xFFF7,451,0xFFF7,962,0xFFFF};
static struct eif_par_types par1562 = {1562, ptf1562, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf1563[] = {1555,0xFFF8,1,1114,0xFFF7,451,0xFFF7,962,0xFFFF};
static struct eif_par_types par1563 = {1563, ptf1563, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf1564[] = {1556,1114,0xFFF8,2,0xFFF7,451,0xFFF7,962,0xFFFF};
static struct eif_par_types par1564 = {1564, ptf1564, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1565[] = {1557,1096,1096,0xFFF7,451,0xFFF7,962,0xFFFF};
static struct eif_par_types par1565 = {1565, ptf1565, (uint16) 3, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1566[] = {1558,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1566 = {1566, ptf1566, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1567[] = {1559,1096,0xFFF8,2,0xFFFF};
static struct eif_par_types par1567 = {1567, ptf1567, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1568[] = {1560,1129,0xFFF8,2,0xFFFF};
static struct eif_par_types par1568 = {1568, ptf1568, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1569[] = {1561,0xFFF8,1,1096,0xFFFF};
static struct eif_par_types par1569 = {1569, ptf1569, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1570[] = {1562,1105,1108,0xFFFF};
static struct eif_par_types par1570 = {1570, ptf1570, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [G#1, NATURAL_8] */
static EIF_TYPE_INDEX ptf1571[] = {1563,0xFFF8,1,1114,0xFFFF};
static struct eif_par_types par1571 = {1571, ptf1571, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf1572[] = {1564,1114,0xFFF8,2,0xFFFF};
static struct eif_par_types par1572 = {1572, ptf1572, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1573[] = {1565,1096,1096,0xFFFF};
static struct eif_par_types par1573 = {1573, ptf1573, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_SET [G#1] */
static EIF_TYPE_INDEX ptf1574[] = {1501,0xFFF8,1,0xFFF7,1542,0xFFF8,1,0xFFF8,1,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1574 = {1574, ptf1574, (uint16) 3, (uint16) 1, (char) 0};

/* DS_SPARSE_SET [INTEGER_32] */
static EIF_TYPE_INDEX ptf1575[] = {1502,1096,0xFFF7,1546,1096,1096,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1575 = {1575, ptf1575, (uint16) 3, (uint16) 1, (char) 0};

/* DS_ARRAYED_SPARSE_SET [G#1] */
static EIF_TYPE_INDEX ptf1576[] = {1574,0xFFF8,1,0xFFF7,451,0xFFF7,962,0xFFFF};
static struct eif_par_types par1576 = {1576, ptf1576, (uint16) 3, (uint16) 1, (char) 0};

/* DS_ARRAYED_SPARSE_SET [INTEGER_32] */
static EIF_TYPE_INDEX ptf1577[] = {1575,1096,0xFFF7,451,0xFFF7,962,0xFFFF};
static struct eif_par_types par1577 = {1577, ptf1577, (uint16) 3, (uint16) 1, (char) 0};

/* DS_HASH_SET [G#1] */
static EIF_TYPE_INDEX ptf1578[] = {1576,0xFFF8,1,0xFFFF};
static struct eif_par_types par1578 = {1578, ptf1578, (uint16) 1, (uint16) 1, (char) 0};

/* DS_HASH_SET [INTEGER_32] */
static EIF_TYPE_INDEX ptf1579[] = {1577,1096,0xFFFF};
static struct eif_par_types par1579 = {1579, ptf1579, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SHARED_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1580[] = {0,0xFFF7,416,0xFFFF};
static struct eif_par_types par1580 = {1580, ptf1580, (uint16) 2, (uint16) 0, (char) 0};

/* KL_DIRECTORY */
static EIF_TYPE_INDEX ptf1581[] = {985,0xFFF7,1580,0xFFF7,1211,0xFFF7,1191,0xFFF7,984,0xFFF7,421,0xFFFF};
static struct eif_par_types par1581 = {1581, ptf1581, (uint16) 6, (uint16) 0, (char) 0};

/* ET_MASTER_CLASS */
static EIF_TYPE_INDEX ptf1582[] = {1133,0xFFF7,1007,0xFFF7,1580,0xFFF7,120,0xFFFF};
static struct eif_par_types par1582 = {1582, ptf1582, (uint16) 4, (uint16) 0, (char) 0};

/* AP_BASIC_PARSER */
static EIF_TYPE_INDEX ptf1583[] = {354,0xFFF7,452,0xFFF7,355,0xFFF7,986,0xFFF7,1580,0xFFF7,984,0xFFF7,1211,0xFFF7,221,0xFFFF};
static struct eif_par_types par1583 = {1583, ptf1583, (uint16) 8, (uint16) 0, (char) 0};

/* AP_PARSER */
static EIF_TYPE_INDEX ptf1584[] = {1583,0xFFFF};
static struct eif_par_types par1584 = {1584, ptf1584, (uint16) 1, (uint16) 0, (char) 0};

/* KL_FILE */
static EIF_TYPE_INDEX ptf1585[] = {186,0xFFF7,1580,0xFFF7,1211,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1585 = {1585, ptf1585, (uint16) 4, (uint16) 0, (char) 0};

/* KL_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1586[] = {1237,0xFFF7,1585,0xFFFF};
static struct eif_par_types par1586 = {1586, ptf1586, (uint16) 2, (uint16) 0, (char) 0};

/* KL_BINARY_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1587[] = {1238,0xFFF7,1586,0xFFF7,792,0xFFFF};
static struct eif_par_types par1587 = {1587, ptf1587, (uint16) 3, (uint16) 0, (char) 0};

/* KL_UNIX_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1588[] = {1243,0xFFF7,1587,0xFFFF};
static struct eif_par_types par1588 = {1588, ptf1588, (uint16) 2, (uint16) 0, (char) 0};

/* KL_WINDOWS_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1589[] = {1243,0xFFF7,1587,0xFFFF};
static struct eif_par_types par1589 = {1589, ptf1589, (uint16) 2, (uint16) 0, (char) 0};

/* KL_INPUT_FILE */
static EIF_TYPE_INDEX ptf1590[] = {1207,0xFFF7,1585,0xFFF7,425,0xFFFF};
static struct eif_par_types par1590 = {1590, ptf1590, (uint16) 3, (uint16) 0, (char) 0};

/* KL_TEXT_INPUT_FILE */
static EIF_TYPE_INDEX ptf1591[] = {1209,0xFFF7,1590,0xFFF7,793,0xFFFF};
static struct eif_par_types par1591 = {1591, ptf1591, (uint16) 3, (uint16) 0, (char) 0};

/* KL_BINARY_INPUT_FILE */
static EIF_TYPE_INDEX ptf1592[] = {1208,0xFFF7,1590,0xFFF7,792,0xFFFF};
static struct eif_par_types par1592 = {1592, ptf1592, (uint16) 3, (uint16) 0, (char) 0};

/* KL_UNIX_INPUT_FILE */
static EIF_TYPE_INDEX ptf1593[] = {1209,0xFFF7,1592,0xFFFF};
static struct eif_par_types par1593 = {1593, ptf1593, (uint16) 2, (uint16) 0, (char) 0};

/* KL_WINDOWS_INPUT_FILE */
static EIF_TYPE_INDEX ptf1594[] = {1209,0xFFF7,1592,0xFFFF};
static struct eif_par_types par1594 = {1594, ptf1594, (uint16) 2, (uint16) 0, (char) 0};

/* ET_GROUP */
static EIF_TYPE_INDEX ptf1595[] = {289,0xFFF7,1056,0xFFF7,900,0xFFF7,1191,0xFFF7,1211,0xFFF7,471,0xFFF7,1580,0xFFFF};
static struct eif_par_types par1595 = {1595, ptf1595, (uint16) 7, (uint16) 0, (char) 0};

/* ET_SECONDARY_GROUP */
static EIF_TYPE_INDEX ptf1596[] = {1595,0xFFFF};
static struct eif_par_types par1596 = {1596, ptf1596, (uint16) 1, (uint16) 0, (char) 0};

/* ET_PRIMARY_GROUP */
static EIF_TYPE_INDEX ptf1597[] = {1595,0xFFFF};
static struct eif_par_types par1597 = {1597, ptf1597, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TEXT_GROUP */
static EIF_TYPE_INDEX ptf1598[] = {1597,0xFFF7,120,0xFFFF};
static struct eif_par_types par1598 = {1598, ptf1598, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CLUSTER */
static EIF_TYPE_INDEX ptf1599[] = {1597,0xFFF7,120,0xFFF7,416,0xFFFF};
static struct eif_par_types par1599 = {1599, ptf1599, (uint16) 3, (uint16) 0, (char) 0};

/* ET_ECF_CLUSTER */
static EIF_TYPE_INDEX ptf1600[] = {1599,0xFFF7,363,0xFFF7,392,0xFFFF};
static struct eif_par_types par1600 = {1600, ptf1600, (uint16) 3, (uint16) 0, (char) 0};

/* ET_BUILTIN_GROUP */
static EIF_TYPE_INDEX ptf1601[] = {1597,0xFFFF};
static struct eif_par_types par1601 = {1601, ptf1601, (uint16) 1, (uint16) 0, (char) 0};

/* ET_UNKNOWN_GROUP */
static EIF_TYPE_INDEX ptf1602[] = {1601,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1602 = {1602, ptf1602, (uint16) 2, (uint16) 0, (char) 0};

/* ET_NONE_GROUP */
static EIF_TYPE_INDEX ptf1603[] = {1601,0xFFFF};
static struct eif_par_types par1603 = {1603, ptf1603, (uint16) 1, (uint16) 0, (char) 0};

/* ET_UNIVERSE */
static EIF_TYPE_INDEX ptf1604[] = {303,0xFFF7,1056,0xFFF7,374,0xFFF7,1007,0xFFF7,120,0xFFF7,1580,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1604 = {1604, ptf1604, (uint16) 7, (uint16) 0, (char) 0};

/* ET_DOTNET_ASSEMBLY */
static EIF_TYPE_INDEX ptf1605[] = {1597,0xFFF7,1604,0xFFF7,305,0xFFFF};
static struct eif_par_types par1605 = {1605, ptf1605, (uint16) 3, (uint16) 0, (char) 0};

/* ET_ECF_DOTNET_ASSEMBLY */
static EIF_TYPE_INDEX ptf1606[] = {1605,0xFFFF};
static struct eif_par_types par1606 = {1606, ptf1606, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DOTNET_GAC_ASSEMBLY */
static EIF_TYPE_INDEX ptf1607[] = {1605,0xFFFF};
static struct eif_par_types par1607 = {1607, ptf1607, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INTERNAL_UNIVERSE */
static EIF_TYPE_INDEX ptf1608[] = {1604,0xFFFF};
static struct eif_par_types par1608 = {1608, ptf1608, (uint16) 1, (uint16) 0, (char) 0};

/* ET_LIBRARY */
static EIF_TYPE_INDEX ptf1609[] = {1597,0xFFF7,1608,0xFFF7,304,0xFFFF};
static struct eif_par_types par1609 = {1609, ptf1609, (uint16) 3, (uint16) 0, (char) 0};

/* ET_SYSTEM */
static EIF_TYPE_INDEX ptf1610[] = {1608,0xFFF7,471,0xFFF7,470,0xFFFF};
static struct eif_par_types par1610 = {1610, ptf1610, (uint16) 3, (uint16) 0, (char) 0};

/* ET_ECF_INTERNAL_UNIVERSE */
static EIF_TYPE_INDEX ptf1611[] = {1608,0xFFF7,202,0xFFFF};
static struct eif_par_types par1611 = {1611, ptf1611, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_LIBRARY */
static EIF_TYPE_INDEX ptf1612[] = {1609,0xFFF7,1611,0xFFFF};
static struct eif_par_types par1612 = {1612, ptf1612, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_SYSTEM */
static EIF_TYPE_INDEX ptf1613[] = {1610,0xFFF7,1611,0xFFFF};
static struct eif_par_types par1613 = {1613, ptf1613, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_PATHNAME */
static EIF_TYPE_INDEX ptf1614[] = {359,0xFFF7,1580,0xFFFF};
static struct eif_par_types par1614 = {1614, ptf1614, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_MAKE */
static EIF_TYPE_INDEX ptf1615[] = {1614,0xFFFF};
static struct eif_par_types par1615 = {1615, ptf1615, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_RESOURCE */
static EIF_TYPE_INDEX ptf1616[] = {1614,0xFFFF};
static struct eif_par_types par1616 = {1616, ptf1616, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_LIBRARY */
static EIF_TYPE_INDEX ptf1617[] = {1614,0xFFFF};
static struct eif_par_types par1617 = {1617, ptf1617, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_OBJECT */
static EIF_TYPE_INDEX ptf1618[] = {1614,0xFFFF};
static struct eif_par_types par1618 = {1618, ptf1618, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_EXTERNAL_INCLUDE */
static EIF_TYPE_INDEX ptf1619[] = {1614,0xFFFF};
static struct eif_par_types par1619 = {1619, ptf1619, (uint16) 1, (uint16) 0, (char) 0};

/* ET_AST_NODE */
static EIF_TYPE_INDEX ptf1620[] = {0,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1620 = {1620, ptf1620, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ELSEIF_EXPRESSION_LIST */
static EIF_TYPE_INDEX ptf1621[] = {1620,0xFFF7,1050,0xFF01,1631,0xFFFF};
static struct eif_par_types par1621 = {1621, ptf1621, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ELSEIF_PART */
static EIF_TYPE_INDEX ptf1622[] = {1620,0xFFFF};
static struct eif_par_types par1622 = {1622, ptf1622, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INDEXING_TERM_LIST */
static EIF_TYPE_INDEX ptf1623[] = {1620,0xFFF7,1050,0xFF01,1671,0xFFFF};
static struct eif_par_types par1623 = {1623, ptf1623, (uint16) 2, (uint16) 0, (char) 0};

/* ET_EXPORT_LIST */
static EIF_TYPE_INDEX ptf1624[] = {1620,0xFFF7,1050,0xFF01,1814,0xFFFF};
static struct eif_par_types par1624 = {1624, ptf1624, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ALIAS_NAME_LIST */
static EIF_TYPE_INDEX ptf1625[] = {1620,0xFFF7,1050,0xFF01,1941,0xFFFF};
static struct eif_par_types par1625 = {1625, ptf1625, (uint16) 2, (uint16) 0, (char) 0};

/* ET_MANIFEST_STRING_LIST */
static EIF_TYPE_INDEX ptf1626[] = {1620,0xFFF7,1050,0xFF01,1679,0xFFFF};
static struct eif_par_types par1626 = {1626, ptf1626, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CHOICE_LIST */
static EIF_TYPE_INDEX ptf1627[] = {1620,0xFFF7,1050,0xFF01,1682,0xFFFF};
static struct eif_par_types par1627 = {1627, ptf1627, (uint16) 2, (uint16) 0, (char) 0};

/* ET_WHEN_PART */
static EIF_TYPE_INDEX ptf1628[] = {1620,0xFFFF};
static struct eif_par_types par1628 = {1628, ptf1628, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FEATURE_CLAUSE */
static EIF_TYPE_INDEX ptf1629[] = {1620,0xFFFF};
static struct eif_par_types par1629 = {1629, ptf1629, (uint16) 1, (uint16) 0, (char) 0};

/* ET_WHEN_PART_LIST */
static EIF_TYPE_INDEX ptf1630[] = {1620,0xFFF7,1050,0xFF01,1628,0xFFFF};
static struct eif_par_types par1630 = {1630, ptf1630, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ELSEIF_EXPRESSION */
static EIF_TYPE_INDEX ptf1631[] = {1620,0xFFFF};
static struct eif_par_types par1631 = {1631, ptf1631, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ELSEIF_PART_LIST */
static EIF_TYPE_INDEX ptf1632[] = {1620,0xFFF7,1050,0xFF01,1622,0xFFFF};
static struct eif_par_types par1632 = {1632, ptf1632, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CREATION_REGION */
static EIF_TYPE_INDEX ptf1633[] = {1620,0xFFFF};
static struct eif_par_types par1633 = {1633, ptf1633, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLIENTS */
static EIF_TYPE_INDEX ptf1634[] = {1620,0xFFF7,1052,0xFFFF};
static struct eif_par_types par1634 = {1634, ptf1634, (uint16) 2, (uint16) 0, (char) 0};

/* ET_COMPOUND */
static EIF_TYPE_INDEX ptf1635[] = {1620,0xFFF7,1050,0xFF01,1952,0xFFFF};
static struct eif_par_types par1635 = {1635, ptf1635, (uint16) 2, (uint16) 0, (char) 0};

/* ET_VARIANT */
static EIF_TYPE_INDEX ptf1636[] = {1620,0xFFFF};
static struct eif_par_types par1636 = {1636, ptf1636, (uint16) 1, (uint16) 0, (char) 0};

/* ET_AGENT_ARGUMENT_OPERAND_LIST */
static EIF_TYPE_INDEX ptf1637[] = {218,0xFFF7,1620,0xFFF7,1050,0xFF01,1697,0xFFFF};
static struct eif_par_types par1637 = {1637, ptf1637, (uint16) 3, (uint16) 0, (char) 0};

/* ET_PARENT_CLAUSE_LIST */
static EIF_TYPE_INDEX ptf1638[] = {1620,0xFFF7,1050,0xFF01,1639,0xFFFF};
static struct eif_par_types par1638 = {1638, ptf1638, (uint16) 2, (uint16) 0, (char) 0};

/* ET_PARENT_LIST */
static EIF_TYPE_INDEX ptf1639[] = {1620,0xFFF7,1050,0xFF01,1694,0xFFFF};
static struct eif_par_types par1639 = {1639, ptf1639, (uint16) 2, (uint16) 0, (char) 0};

/* ET_FEATURE_CLAUSE_LIST */
static EIF_TYPE_INDEX ptf1640[] = {1620,0xFFF7,1050,0xFF01,1629,0xFFFF};
static struct eif_par_types par1640 = {1640, ptf1640, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CONVERT_FEATURE_LIST */
static EIF_TYPE_INDEX ptf1641[] = {1620,0xFFF7,1050,0xFF01,1686,0xFFFF};
static struct eif_par_types par1641 = {1641, ptf1641, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CREATOR_LIST */
static EIF_TYPE_INDEX ptf1642[] = {1620,0xFFF7,1050,0xFF01,1906,0xFFFF};
static struct eif_par_types par1642 = {1642, ptf1642, (uint16) 2, (uint16) 0, (char) 0};

/* ET_INDEXING_LIST */
static EIF_TYPE_INDEX ptf1643[] = {1620,0xFFF7,1050,0xFF01,1675,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1643 = {1643, ptf1643, (uint16) 3, (uint16) 0, (char) 0};

/* ET_LOCAL_VARIABLE_LIST */
static EIF_TYPE_INDEX ptf1644[] = {1620,0xFFF7,1050,0xFF01,1805,0xFFFF};
static struct eif_par_types par1644 = {1644, ptf1644, (uint16) 2, (uint16) 0, (char) 0};

/* ET_FORMAL_ARGUMENT_LIST */
static EIF_TYPE_INDEX ptf1645[] = {1620,0xFFF7,1050,0xFF01,1801,0xFFFF};
static struct eif_par_types par1645 = {1645, ptf1645, (uint16) 2, (uint16) 0, (char) 0};

/* ET_TYPE_LIST */
static EIF_TYPE_INDEX ptf1646[] = {1620,0xFFF7,1050,0xFF01,1704,0xFFFF};
static struct eif_par_types par1646 = {1646, ptf1646, (uint16) 2, (uint16) 0, (char) 0};

/* ET_BRACED_TYPE_LIST */
static EIF_TYPE_INDEX ptf1647[] = {1646,0xFFFF};
static struct eif_par_types par1647 = {1647, ptf1647, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLIENT_ITEM */
static EIF_TYPE_INDEX ptf1648[] = {1620,0xFFFF};
static struct eif_par_types par1648 = {1648, ptf1648, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLIENT */
static EIF_TYPE_INDEX ptf1649[] = {1648,0xFFFF};
static struct eif_par_types par1649 = {1649, ptf1649, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLIENT_COMMA */
static EIF_TYPE_INDEX ptf1650[] = {1649,0xFFFF};
static struct eif_par_types par1650 = {1650, ptf1650, (uint16) 1, (uint16) 0, (char) 0};

/* ET_RENAME_ITEM */
static EIF_TYPE_INDEX ptf1651[] = {1620,0xFFFF};
static struct eif_par_types par1651 = {1651, ptf1651, (uint16) 1, (uint16) 0, (char) 0};

/* ET_RENAME */
static EIF_TYPE_INDEX ptf1652[] = {1651,0xFFFF};
static struct eif_par_types par1652 = {1652, ptf1652, (uint16) 1, (uint16) 0, (char) 0};

/* ET_RENAME_COMMA */
static EIF_TYPE_INDEX ptf1653[] = {1652,0xFFFF};
static struct eif_par_types par1653 = {1653, ptf1653, (uint16) 1, (uint16) 0, (char) 0};

/* ET_RENAME_LIST */
static EIF_TYPE_INDEX ptf1654[] = {1620,0xFFF7,1050,0xFF01,1651,0xFFFF};
static struct eif_par_types par1654 = {1654, ptf1654, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CONSTRAINT_RENAME_LIST */
static EIF_TYPE_INDEX ptf1655[] = {1654,0xFFFF};
static struct eif_par_types par1655 = {1655, ptf1655, (uint16) 1, (uint16) 0, (char) 0};

/* ET_LOOP_COMPONENT */
static EIF_TYPE_INDEX ptf1656[] = {1620,0xFFFF};
static struct eif_par_types par1656 = {1656, ptf1656, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ASSERTION_ITEM */
static EIF_TYPE_INDEX ptf1657[] = {1620,0xFFFF};
static struct eif_par_types par1657 = {1657, ptf1657, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ASSERTION_SEMICOLON */
static EIF_TYPE_INDEX ptf1658[] = {1657,0xFFFF};
static struct eif_par_types par1658 = {1658, ptf1658, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ASSERTION */
static EIF_TYPE_INDEX ptf1659[] = {1657,0xFFFF};
static struct eif_par_types par1659 = {1659, ptf1659, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TAGGED_ASSERTION */
static EIF_TYPE_INDEX ptf1660[] = {1659,0xFFFF};
static struct eif_par_types par1660 = {1660, ptf1660, (uint16) 1, (uint16) 0, (char) 0};

/* ET_UNTAGGED_ASSERTION */
static EIF_TYPE_INDEX ptf1661[] = {1659,0xFFFF};
static struct eif_par_types par1661 = {1661, ptf1661, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLASS_ASSERTION */
static EIF_TYPE_INDEX ptf1662[] = {1661,0xFFFF};
static struct eif_par_types par1662 = {1662, ptf1662, (uint16) 1, (uint16) 0, (char) 0};

/* ET_PRECURSOR_CLASS_NAME */
static EIF_TYPE_INDEX ptf1663[] = {1620,0xFFFF};
static struct eif_par_types par1663 = {1663, ptf1663, (uint16) 1, (uint16) 0, (char) 0};

/* ET_BRACED_CLASS_NAME */
static EIF_TYPE_INDEX ptf1664[] = {1663,0xFFFF};
static struct eif_par_types par1664 = {1664, ptf1664, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TAG */
static EIF_TYPE_INDEX ptf1665[] = {1620,0xFFFF};
static struct eif_par_types par1665 = {1665, ptf1665, (uint16) 1, (uint16) 0, (char) 0};

/* ET_IDENTIFIER_COLON */
static EIF_TYPE_INDEX ptf1666[] = {1665,0xFFFF};
static struct eif_par_types par1666 = {1666, ptf1666, (uint16) 1, (uint16) 0, (char) 0};

/* ET_LABEL */
static EIF_TYPE_INDEX ptf1667[] = {1620,0xFFFF};
static struct eif_par_types par1667 = {1667, ptf1667, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXTERNAL_LANGUAGE */
static EIF_TYPE_INDEX ptf1668[] = {1620,0xFFFF};
static struct eif_par_types par1668 = {1668, ptf1668, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXPRESSION_ITEM */
static EIF_TYPE_INDEX ptf1669[] = {1620,0xFFFF};
static struct eif_par_types par1669 = {1669, ptf1669, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXPRESSION_COMMA */
static EIF_TYPE_INDEX ptf1670[] = {1669,0xFFFF};
static struct eif_par_types par1670 = {1670, ptf1670, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INDEXING_TERM_ITEM */
static EIF_TYPE_INDEX ptf1671[] = {1620,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1671 = {1671, ptf1671, (uint16) 2, (uint16) 0, (char) 0};

/* ET_INDEXING_TERM_COMMA */
static EIF_TYPE_INDEX ptf1672[] = {1671,0xFFFF};
static struct eif_par_types par1672 = {1672, ptf1672, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INDEXING_TERM */
static EIF_TYPE_INDEX ptf1673[] = {1671,0xFFFF};
static struct eif_par_types par1673 = {1673, ptf1673, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CUSTOM_ATTRIBUTE */
static EIF_TYPE_INDEX ptf1674[] = {1673,0xFFFF};
static struct eif_par_types par1674 = {1674, ptf1674, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INDEXING_ITEM */
static EIF_TYPE_INDEX ptf1675[] = {1620,0xFFFF};
static struct eif_par_types par1675 = {1675, ptf1675, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INDEXING_SEMICOLON */
static EIF_TYPE_INDEX ptf1676[] = {1675,0xFFFF};
static struct eif_par_types par1676 = {1676, ptf1676, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INDEXING */
static EIF_TYPE_INDEX ptf1677[] = {1675,0xFFFF};
static struct eif_par_types par1677 = {1677, ptf1677, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TAGGED_INDEXING */
static EIF_TYPE_INDEX ptf1678[] = {1677,0xFFFF};
static struct eif_par_types par1678 = {1678, ptf1678, (uint16) 1, (uint16) 0, (char) 0};

/* ET_MANIFEST_STRING_ITEM */
static EIF_TYPE_INDEX ptf1679[] = {1620,0xFFFF};
static struct eif_par_types par1679 = {1679, ptf1679, (uint16) 1, (uint16) 0, (char) 0};

/* ET_MANIFEST_STRING_COMMA */
static EIF_TYPE_INDEX ptf1680[] = {1679,0xFFFF};
static struct eif_par_types par1680 = {1680, ptf1680, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXTERNAL_ALIAS */
static EIF_TYPE_INDEX ptf1681[] = {1620,0xFFFF};
static struct eif_par_types par1681 = {1681, ptf1681, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CHOICE_ITEM */
static EIF_TYPE_INDEX ptf1682[] = {1620,0xFFFF};
static struct eif_par_types par1682 = {1682, ptf1682, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CHOICE_COMMA */
static EIF_TYPE_INDEX ptf1683[] = {1682,0xFFFF};
static struct eif_par_types par1683 = {1683, ptf1683, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CHOICE */
static EIF_TYPE_INDEX ptf1684[] = {1682,0xFFFF};
static struct eif_par_types par1684 = {1684, ptf1684, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CHOICE_RANGE */
static EIF_TYPE_INDEX ptf1685[] = {1684,0xFFFF};
static struct eif_par_types par1685 = {1685, ptf1685, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONVERT_FEATURE_ITEM */
static EIF_TYPE_INDEX ptf1686[] = {1620,0xFFFF};
static struct eif_par_types par1686 = {1686, ptf1686, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONVERT_FEATURE_COMMA */
static EIF_TYPE_INDEX ptf1687[] = {1686,0xFFFF};
static struct eif_par_types par1687 = {1687, ptf1687, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONVERT_FEATURE */
static EIF_TYPE_INDEX ptf1688[] = {1686,0xFFFF};
static struct eif_par_types par1688 = {1688, ptf1688, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONVERT_PROCEDURE */
static EIF_TYPE_INDEX ptf1689[] = {1688,0xFFFF};
static struct eif_par_types par1689 = {1689, ptf1689, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONVERT_FUNCTION */
static EIF_TYPE_INDEX ptf1690[] = {1688,0xFFFF};
static struct eif_par_types par1690 = {1690, ptf1690, (uint16) 1, (uint16) 0, (char) 0};

/* ET_BUILTIN_CONVERT_FEATURE */
static EIF_TYPE_INDEX ptf1691[] = {1688,0xFFFF};
static struct eif_par_types par1691 = {1691, ptf1691, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONDITIONAL */
static EIF_TYPE_INDEX ptf1692[] = {1620,0xFFFF};
static struct eif_par_types par1692 = {1692, ptf1692, (uint16) 1, (uint16) 0, (char) 0};

/* ET_KEYWORD_EXPRESSION */
static EIF_TYPE_INDEX ptf1693[] = {1692,0xFFFF};
static struct eif_par_types par1693 = {1693, ptf1693, (uint16) 1, (uint16) 0, (char) 0};

/* ET_PARENT_ITEM */
static EIF_TYPE_INDEX ptf1694[] = {1620,0xFFFF};
static struct eif_par_types par1694 = {1694, ptf1694, (uint16) 1, (uint16) 0, (char) 0};

/* ET_PARENT_SEMICOLON */
static EIF_TYPE_INDEX ptf1695[] = {1694,0xFFFF};
static struct eif_par_types par1695 = {1695, ptf1695, (uint16) 1, (uint16) 0, (char) 0};

/* ET_PARENT */
static EIF_TYPE_INDEX ptf1696[] = {1694,0xFFFF};
static struct eif_par_types par1696 = {1696, ptf1696, (uint16) 1, (uint16) 0, (char) 0};

/* ET_AGENT_ARGUMENT_OPERAND_ITEM */
static EIF_TYPE_INDEX ptf1697[] = {1620,0xFFFF};
static struct eif_par_types par1697 = {1697, ptf1697, (uint16) 1, (uint16) 0, (char) 0};

/* ET_AGENT_ARGUMENT_OPERAND_COMMA */
static EIF_TYPE_INDEX ptf1698[] = {1697,0xFFFF};
static struct eif_par_types par1698 = {1698, ptf1698, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TYPE_CONSTRAINT_ITEM */
static EIF_TYPE_INDEX ptf1699[] = {1620,0xFFFF};
static struct eif_par_types par1699 = {1699, ptf1699, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TYPE_CONSTRAINT_COMMA */
static EIF_TYPE_INDEX ptf1700[] = {1699,0xFFFF};
static struct eif_par_types par1700 = {1700, ptf1700, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CALL_COMPONENT */
static EIF_TYPE_INDEX ptf1701[] = {1620,0xFFFF};
static struct eif_par_types par1701 = {1701, ptf1701, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TARGET_TYPE */
static EIF_TYPE_INDEX ptf1702[] = {1620,0xFFFF};
static struct eif_par_types par1702 = {1702, ptf1702, (uint16) 1, (uint16) 0, (char) 0};

/* ET_BRACED_TYPE */
static EIF_TYPE_INDEX ptf1703[] = {1702,0xFFFF};
static struct eif_par_types par1703 = {1703, ptf1703, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TYPE_ITEM */
static EIF_TYPE_INDEX ptf1704[] = {1620,0xFFFF};
static struct eif_par_types par1704 = {1704, ptf1704, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TYPE_COMMA */
static EIF_TYPE_INDEX ptf1705[] = {1704,0xFFFF};
static struct eif_par_types par1705 = {1705, ptf1705, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DECLARED_TYPE */
static EIF_TYPE_INDEX ptf1706[] = {1620,0xFFFF};
static struct eif_par_types par1706 = {1706, ptf1706, (uint16) 1, (uint16) 0, (char) 0};

/* ET_COLON_TYPE */
static EIF_TYPE_INDEX ptf1707[] = {1706,0xFFFF};
static struct eif_par_types par1707 = {1707, ptf1707, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ASSIGNER */
static EIF_TYPE_INDEX ptf1708[] = {1620,0xFFFF};
static struct eif_par_types par1708 = {1708, ptf1708, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ASSIGN_FEATURE_NAME */
static EIF_TYPE_INDEX ptf1709[] = {1708,0xFFFF};
static struct eif_par_types par1709 = {1709, ptf1709, (uint16) 1, (uint16) 0, (char) 0};

/* ET_QUALIFIED_FEATURE_NAME */
static EIF_TYPE_INDEX ptf1710[] = {1620,0xFFFF};
static struct eif_par_types par1710 = {1710, ptf1710, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DOT_FEATURE_NAME */
static EIF_TYPE_INDEX ptf1711[] = {1710,0xFFFF};
static struct eif_par_types par1711 = {1711, ptf1711, (uint16) 1, (uint16) 0, (char) 0};

/* ET_OBSOLETE */
static EIF_TYPE_INDEX ptf1712[] = {1620,0xFFFF};
static struct eif_par_types par1712 = {1712, ptf1712, (uint16) 1, (uint16) 0, (char) 0};

/* ET_KEYWORD_MANIFEST_STRING */
static EIF_TYPE_INDEX ptf1713[] = {1668,0xFFF7,1681,0xFFF7,1712,0xFFFF};
static struct eif_par_types par1713 = {1713, ptf1713, (uint16) 3, (uint16) 0, (char) 0};

/* ET_CREATION_COMPONENT */
static EIF_TYPE_INDEX ptf1714[] = {1620,0xFFFF};
static struct eif_par_types par1714 = {1714, ptf1714, (uint16) 1, (uint16) 0, (char) 0};

/* ET_OPERAND */
static EIF_TYPE_INDEX ptf1715[] = {1620,0xFFFF};
static struct eif_par_types par1715 = {1715, ptf1715, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TARGET_OPERAND */
static EIF_TYPE_INDEX ptf1716[] = {1715,0xFFFF};
static struct eif_par_types par1716 = {1716, ptf1716, (uint16) 1, (uint16) 0, (char) 0};

/* ET_AGENT_TARGET */
static EIF_TYPE_INDEX ptf1717[] = {1716,0xFFFF};
static struct eif_par_types par1717 = {1717, ptf1717, (uint16) 1, (uint16) 0, (char) 0};

/* ET_AGENT_IMPLICIT_CURRENT_TARGET */
static EIF_TYPE_INDEX ptf1718[] = {1717,0xFFFF};
static struct eif_par_types par1718 = {1718, ptf1718, (uint16) 1, (uint16) 0, (char) 0};

/* ET_AGENT_OPEN_TARGET */
static EIF_TYPE_INDEX ptf1719[] = {1717,0xFFF7,1703,0xFFFF};
static struct eif_par_types par1719 = {1719, ptf1719, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ARGUMENT_OPERAND */
static EIF_TYPE_INDEX ptf1720[] = {1715,0xFFFF};
static struct eif_par_types par1720 = {1720, ptf1720, (uint16) 1, (uint16) 0, (char) 0};

/* ET_AGENT_ARGUMENT_OPERAND */
static EIF_TYPE_INDEX ptf1721[] = {1720,0xFFF7,1697,0xFFFF};
static struct eif_par_types par1721 = {1721, ptf1721, (uint16) 2, (uint16) 0, (char) 0};

/* ET_AGENT_TYPED_OPEN_ARGUMENT */
static EIF_TYPE_INDEX ptf1722[] = {1721,0xFFF7,1703,0xFFFF};
static struct eif_par_types par1722 = {1722, ptf1722, (uint16) 2, (uint16) 0, (char) 0};

/* ET_AGENT_IMPLICIT_OPEN_ARGUMENT */
static EIF_TYPE_INDEX ptf1723[] = {1721,0xFFFF};
static struct eif_par_types par1723 = {1723, ptf1723, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXPRESSION */
static EIF_TYPE_INDEX ptf1724[] = {1669,0xFFF7,1692,0xFFF7,1661,0xFFF7,219,0xFFF7,1720,0xFFF7,1721,0xFFF7,1716,0xFFF7,1717,0xFFFF};
static struct eif_par_types par1724 = {1724, ptf1724, (uint16) 8, (uint16) 0, (char) 0};

/* ET_INFIX_CAST_EXPRESSION */
static EIF_TYPE_INDEX ptf1725[] = {1724,0xFFFF};
static struct eif_par_types par1725 = {1725, ptf1725, (uint16) 1, (uint16) 0, (char) 0};

/* ET_PARENTHESIZED_EXPRESSION */
static EIF_TYPE_INDEX ptf1726[] = {1724,0xFFF7,1717,0xFFFF};
static struct eif_par_types par1726 = {1726, ptf1726, (uint16) 2, (uint16) 0, (char) 0};

/* ET_IF_EXPRESSION */
static EIF_TYPE_INDEX ptf1727[] = {1724,0xFFFF};
static struct eif_par_types par1727 = {1727, ptf1727, (uint16) 1, (uint16) 0, (char) 0};

/* ET_OBJECT_TEST */
static EIF_TYPE_INDEX ptf1728[] = {1724,0xFFFF};
static struct eif_par_types par1728 = {1728, ptf1728, (uint16) 1, (uint16) 0, (char) 0};

/* ET_NAMED_OBJECT_TEST */
static EIF_TYPE_INDEX ptf1729[] = {1728,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1729 = {1729, ptf1729, (uint16) 2, (uint16) 0, (char) 0};

/* ET_OLD_OBJECT_TEST */
static EIF_TYPE_INDEX ptf1730[] = {1729,0xFFFF};
static struct eif_par_types par1730 = {1730, ptf1730, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INLINE_CONSTANT */
static EIF_TYPE_INDEX ptf1731[] = {1724,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1731 = {1731, ptf1731, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ONCE_MANIFEST_STRING */
static EIF_TYPE_INDEX ptf1732[] = {1731,0xFFFF};
static struct eif_par_types par1732 = {1732, ptf1732, (uint16) 1, (uint16) 0, (char) 0};

/* ET_UNARY_EXPRESSION */
static EIF_TYPE_INDEX ptf1733[] = {1724,0xFFFF};
static struct eif_par_types par1733 = {1733, ptf1733, (uint16) 1, (uint16) 0, (char) 0};

/* ET_OLD_EXPRESSION */
static EIF_TYPE_INDEX ptf1734[] = {1733,0xFFFF};
static struct eif_par_types par1734 = {1734, ptf1734, (uint16) 1, (uint16) 0, (char) 0};

/* ET_OBJECT_TEST_LOCAL_NAME */
static EIF_TYPE_INDEX ptf1735[] = {1724,0xFFFF};
static struct eif_par_types par1735 = {1735, ptf1735, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CREATION_EXPRESSION */
static EIF_TYPE_INDEX ptf1736[] = {1724,0xFFF7,1714,0xFFFF};
static struct eif_par_types par1736 = {1736, ptf1736, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CREATE_EXPRESSION */
static EIF_TYPE_INDEX ptf1737[] = {1736,0xFFFF};
static struct eif_par_types par1737 = {1737, ptf1737, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ARGUMENT_NAME */
static EIF_TYPE_INDEX ptf1738[] = {1724,0xFFFF};
static struct eif_par_types par1738 = {1738, ptf1738, (uint16) 1, (uint16) 0, (char) 0};

/* ET_LOCAL_NAME */
static EIF_TYPE_INDEX ptf1739[] = {1724,0xFFFF};
static struct eif_par_types par1739 = {1739, ptf1739, (uint16) 1, (uint16) 0, (char) 0};

/* ET_IDENTIFIER_COMMA */
static EIF_TYPE_INDEX ptf1740[] = {1739,0xFFF7,1738,0xFFF7,1735,0xFFF7,1667,0xFFFF};
static struct eif_par_types par1740 = {1740, ptf1740, (uint16) 4, (uint16) 0, (char) 0};

/* ET_WRITABLE */
static EIF_TYPE_INDEX ptf1741[] = {1724,0xFFFF};
static struct eif_par_types par1741 = {1741, ptf1741, (uint16) 1, (uint16) 0, (char) 0};

/* ET_AGENT */
static EIF_TYPE_INDEX ptf1742[] = {1724,0xFFFF};
static struct eif_par_types par1742 = {1742, ptf1742, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CALL_AGENT */
static EIF_TYPE_INDEX ptf1743[] = {1742,0xFFF7,1701,0xFFFF};
static struct eif_par_types par1743 = {1743, ptf1743, (uint16) 2, (uint16) 0, (char) 0};

/* ET_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1744[] = {1742,0xFFF7,283,0xFFFF};
static struct eif_par_types par1744 = {1744, ptf1744, (uint16) 2, (uint16) 0, (char) 0};

/* ET_QUERY_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1745[] = {1744,0xFFFF};
static struct eif_par_types par1745 = {1745, ptf1745, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ROUTINE_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1746[] = {1744,0xFFF7,286,0xFFFF};
static struct eif_par_types par1746 = {1746, ptf1746, (uint16) 2, (uint16) 0, (char) 0};

/* ET_FUNCTION_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1747[] = {1745,0xFFF7,1746,0xFFFF};
static struct eif_par_types par1747 = {1747, ptf1747, (uint16) 2, (uint16) 0, (char) 0};

/* ET_PROCEDURE_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1748[] = {1746,0xFFFF};
static struct eif_par_types par1748 = {1748, ptf1748, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXTERNAL_ROUTINE_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1749[] = {1746,0xFFF7,287,0xFFFF};
static struct eif_par_types par1749 = {1749, ptf1749, (uint16) 2, (uint16) 0, (char) 0};

/* ET_EXTERNAL_FUNCTION_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1750[] = {1747,0xFFF7,1749,0xFFFF};
static struct eif_par_types par1750 = {1750, ptf1750, (uint16) 2, (uint16) 0, (char) 0};

/* ET_EXTERNAL_PROCEDURE_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1751[] = {1748,0xFFF7,1749,0xFFFF};
static struct eif_par_types par1751 = {1751, ptf1751, (uint16) 2, (uint16) 0, (char) 0};

/* ET_INTERNAL_ROUTINE_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1752[] = {1746,0xFFF7,288,0xFFFF};
static struct eif_par_types par1752 = {1752, ptf1752, (uint16) 2, (uint16) 0, (char) 0};

/* ET_INTERNAL_PROCEDURE_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1753[] = {1748,0xFFF7,1752,0xFFFF};
static struct eif_par_types par1753 = {1753, ptf1753, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DO_PROCEDURE_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1754[] = {1753,0xFFFF};
static struct eif_par_types par1754 = {1754, ptf1754, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INTERNAL_FUNCTION_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1755[] = {1747,0xFFF7,1752,0xFFFF};
static struct eif_par_types par1755 = {1755, ptf1755, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DO_FUNCTION_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1756[] = {1755,0xFFFF};
static struct eif_par_types par1756 = {1756, ptf1756, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ONCE_ROUTINE_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1757[] = {1752,0xFFF7,1017,0xFFFF};
static struct eif_par_types par1757 = {1757, ptf1757, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ONCE_PROCEDURE_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1758[] = {1753,0xFFF7,1757,0xFFFF};
static struct eif_par_types par1758 = {1758, ptf1758, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ONCE_FUNCTION_INLINE_AGENT */
static EIF_TYPE_INDEX ptf1759[] = {1755,0xFFF7,1757,0xFFFF};
static struct eif_par_types par1759 = {1759, ptf1759, (uint16) 2, (uint16) 0, (char) 0};

/* ET_BINARY_EXPRESSION */
static EIF_TYPE_INDEX ptf1760[] = {1724,0xFFFF};
static struct eif_par_types par1760 = {1760, ptf1760, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EQUALITY_EXPRESSION */
static EIF_TYPE_INDEX ptf1761[] = {1760,0xFFFF};
static struct eif_par_types par1761 = {1761, ptf1761, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONVERT_EXPRESSION */
static EIF_TYPE_INDEX ptf1762[] = {1724,0xFFFF};
static struct eif_par_types par1762 = {1762, ptf1762, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONVERT_BUILTIN_EXPRESSION */
static EIF_TYPE_INDEX ptf1763[] = {1762,0xFFFF};
static struct eif_par_types par1763 = {1763, ptf1763, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ADDRESS_EXPRESSION */
static EIF_TYPE_INDEX ptf1764[] = {1724,0xFFFF};
static struct eif_par_types par1764 = {1764, ptf1764, (uint16) 1, (uint16) 0, (char) 0};

/* ET_RESULT_ADDRESS */
static EIF_TYPE_INDEX ptf1765[] = {1764,0xFFFF};
static struct eif_par_types par1765 = {1765, ptf1765, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FEATURE_ADDRESS */
static EIF_TYPE_INDEX ptf1766[] = {1764,0xFFFF};
static struct eif_par_types par1766 = {1766, ptf1766, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXPRESSION_ADDRESS */
static EIF_TYPE_INDEX ptf1767[] = {1764,0xFFFF};
static struct eif_par_types par1767 = {1767, ptf1767, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CURRENT_ADDRESS */
static EIF_TYPE_INDEX ptf1768[] = {1764,0xFFFF};
static struct eif_par_types par1768 = {1768, ptf1768, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CHOICE_CONSTANT */
static EIF_TYPE_INDEX ptf1769[] = {1684,0xFFF7,1724,0xFFFF};
static struct eif_par_types par1769 = {1769, ptf1769, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CONSTANT */
static EIF_TYPE_INDEX ptf1770[] = {1724,0xFFFF};
static struct eif_par_types par1770 = {1770, ptf1770, (uint16) 1, (uint16) 0, (char) 0};

/* ET_MANIFEST_TYPE */
static EIF_TYPE_INDEX ptf1771[] = {1770,0xFFF7,1703,0xFFFF};
static struct eif_par_types par1771 = {1771, ptf1771, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CALL_WITH_ACTUAL_ARGUMENTS */
static EIF_TYPE_INDEX ptf1772[] = {1620,0xFFFF};
static struct eif_par_types par1772 = {1772, ptf1772, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CREATION_CALL */
static EIF_TYPE_INDEX ptf1773[] = {1772,0xFFFF};
static struct eif_par_types par1773 = {1773, ptf1773, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONVERT_FROM_EXPRESSION */
static EIF_TYPE_INDEX ptf1774[] = {1762,0xFFF7,1736,0xFFF7,1773,0xFFFF};
static struct eif_par_types par1774 = {1774, ptf1774, (uint16) 3, (uint16) 0, (char) 0};

/* ET_CALL_WITH_ACTUAL_ARGUMENT_LIST */
static EIF_TYPE_INDEX ptf1775[] = {1772,0xFFFF};
static struct eif_par_types par1775 = {1775, ptf1775, (uint16) 1, (uint16) 0, (char) 0};

/* ET_QUALIFIED_CALL */
static EIF_TYPE_INDEX ptf1776[] = {1775,0xFFF7,1773,0xFFFF};
static struct eif_par_types par1776 = {1776, ptf1776, (uint16) 2, (uint16) 0, (char) 0};

/* ET_STATIC_FEATURE_CALL */
static EIF_TYPE_INDEX ptf1777[] = {1776,0xFFFF};
static struct eif_par_types par1777 = {1777, ptf1777, (uint16) 1, (uint16) 0, (char) 0};

/* ET_STATIC_CALL_EXPRESSION */
static EIF_TYPE_INDEX ptf1778[] = {1777,0xFFF7,1769,0xFFFF};
static struct eif_par_types par1778 = {1778, ptf1778, (uint16) 2, (uint16) 0, (char) 0};

/* ET_PRECURSOR_CALL */
static EIF_TYPE_INDEX ptf1779[] = {1775,0xFFFF};
static struct eif_par_types par1779 = {1779, ptf1779, (uint16) 1, (uint16) 0, (char) 0};

/* ET_PRECURSOR_EXPRESSION */
static EIF_TYPE_INDEX ptf1780[] = {1779,0xFFF7,1724,0xFFFF};
static struct eif_par_types par1780 = {1780, ptf1780, (uint16) 2, (uint16) 0, (char) 0};

/* ET_FEATURE_CALL */
static EIF_TYPE_INDEX ptf1781[] = {1701,0xFFF7,1772,0xFFFF};
static struct eif_par_types par1781 = {1781, ptf1781, (uint16) 2, (uint16) 0, (char) 0};

/* ET_UNQUALIFIED_FEATURE_CALL */
static EIF_TYPE_INDEX ptf1782[] = {1781,0xFFFF};
static struct eif_par_types par1782 = {1782, ptf1782, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FEATURE_CALL_EXPRESSION */
static EIF_TYPE_INDEX ptf1783[] = {1781,0xFFF7,1724,0xFFFF};
static struct eif_par_types par1783 = {1783, ptf1783, (uint16) 2, (uint16) 0, (char) 0};

/* ET_UNQUALIFIED_FEATURE_CALL_EXPRESSION */
static EIF_TYPE_INDEX ptf1784[] = {1783,0xFFF7,1782,0xFFFF};
static struct eif_par_types par1784 = {1784, ptf1784, (uint16) 2, (uint16) 0, (char) 0};

/* ET_REGULAR_FEATURE_CALL */
static EIF_TYPE_INDEX ptf1785[] = {1781,0xFFF7,1775,0xFFFF};
static struct eif_par_types par1785 = {1785, ptf1785, (uint16) 2, (uint16) 0, (char) 0};

/* ET_UNQUALIFIED_REGULAR_FEATURE_CALL */
static EIF_TYPE_INDEX ptf1786[] = {1785,0xFFF7,1782,0xFFFF};
static struct eif_par_types par1786 = {1786, ptf1786, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CALL_EXPRESSION */
static EIF_TYPE_INDEX ptf1787[] = {1785,0xFFF7,1783,0xFFF7,1769,0xFFFF};
static struct eif_par_types par1787 = {1787, ptf1787, (uint16) 3, (uint16) 0, (char) 0};

/* ET_UNQUALIFIED_CALL_EXPRESSION */
static EIF_TYPE_INDEX ptf1788[] = {1786,0xFFF7,1784,0xFFF7,1787,0xFFFF};
static struct eif_par_types par1788 = {1788, ptf1788, (uint16) 3, (uint16) 0, (char) 0};

/* ET_QUALIFIED_FEATURE_CALL */
static EIF_TYPE_INDEX ptf1789[] = {1781,0xFFFF};
static struct eif_par_types par1789 = {1789, ptf1789, (uint16) 1, (uint16) 0, (char) 0};

/* ET_QUALIFIED_REGULAR_FEATURE_CALL */
static EIF_TYPE_INDEX ptf1790[] = {1785,0xFFF7,1789,0xFFF7,1776,0xFFFF};
static struct eif_par_types par1790 = {1790, ptf1790, (uint16) 3, (uint16) 0, (char) 0};

/* ET_PARENTHESIS_CALL */
static EIF_TYPE_INDEX ptf1791[] = {1789,0xFFF7,1775,0xFFFF};
static struct eif_par_types par1791 = {1791, ptf1791, (uint16) 2, (uint16) 0, (char) 0};

/* ET_QUALIFIED_FEATURE_CALL_EXPRESSION */
static EIF_TYPE_INDEX ptf1792[] = {1783,0xFFF7,1789,0xFFFF};
static struct eif_par_types par1792 = {1792, ptf1792, (uint16) 2, (uint16) 0, (char) 0};

/* ET_PARENTHESIS_EXPRESSION */
static EIF_TYPE_INDEX ptf1793[] = {1791,0xFFF7,1792,0xFFFF};
static struct eif_par_types par1793 = {1793, ptf1793, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CONVERT_TO_EXPRESSION */
static EIF_TYPE_INDEX ptf1794[] = {1762,0xFFF7,1792,0xFFFF};
static struct eif_par_types par1794 = {1794, ptf1794, (uint16) 2, (uint16) 0, (char) 0};

/* ET_INFIX_EXPRESSION */
static EIF_TYPE_INDEX ptf1795[] = {1792,0xFFF7,1760,0xFFFF};
static struct eif_par_types par1795 = {1795, ptf1795, (uint16) 2, (uint16) 0, (char) 0};

/* ET_PREFIX_EXPRESSION */
static EIF_TYPE_INDEX ptf1796[] = {1792,0xFFF7,1733,0xFFFF};
static struct eif_par_types par1796 = {1796, ptf1796, (uint16) 2, (uint16) 0, (char) 0};

/* ET_BRACKET_EXPRESSION */
static EIF_TYPE_INDEX ptf1797[] = {1792,0xFFF7,1775,0xFFFF};
static struct eif_par_types par1797 = {1797, ptf1797, (uint16) 2, (uint16) 0, (char) 0};

/* ET_QUALIFIED_CALL_EXPRESSION */
static EIF_TYPE_INDEX ptf1798[] = {1790,0xFFF7,1792,0xFFF7,1787,0xFFFF};
static struct eif_par_types par1798 = {1798, ptf1798, (uint16) 3, (uint16) 0, (char) 0};

/* ET_OBJECT_EQUALITY_EXPRESSION */
static EIF_TYPE_INDEX ptf1799[] = {1760,0xFFF7,1792,0xFFFF};
static struct eif_par_types par1799 = {1799, ptf1799, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ENTITY_DECLARATION */
static EIF_TYPE_INDEX ptf1800[] = {1620,0xFFFF};
static struct eif_par_types par1800 = {1800, ptf1800, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FORMAL_ARGUMENT_ITEM */
static EIF_TYPE_INDEX ptf1801[] = {1800,0xFFFF};
static struct eif_par_types par1801 = {1801, ptf1801, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FORMAL_ARGUMENT_SEMICOLON */
static EIF_TYPE_INDEX ptf1802[] = {1801,0xFFFF};
static struct eif_par_types par1802 = {1802, ptf1802, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FORMAL_ARGUMENT */
static EIF_TYPE_INDEX ptf1803[] = {1801,0xFFFF};
static struct eif_par_types par1803 = {1803, ptf1803, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FORMAL_COMMA_ARGUMENT */
static EIF_TYPE_INDEX ptf1804[] = {1803,0xFFFF};
static struct eif_par_types par1804 = {1804, ptf1804, (uint16) 1, (uint16) 0, (char) 0};

/* ET_LOCAL_VARIABLE_ITEM */
static EIF_TYPE_INDEX ptf1805[] = {1800,0xFFFF};
static struct eif_par_types par1805 = {1805, ptf1805, (uint16) 1, (uint16) 0, (char) 0};

/* ET_LOCAL_VARIABLE_SEMICOLON */
static EIF_TYPE_INDEX ptf1806[] = {1805,0xFFFF};
static struct eif_par_types par1806 = {1806, ptf1806, (uint16) 1, (uint16) 0, (char) 0};

/* ET_LOCAL_VARIABLE */
static EIF_TYPE_INDEX ptf1807[] = {1805,0xFFFF};
static struct eif_par_types par1807 = {1807, ptf1807, (uint16) 1, (uint16) 0, (char) 0};

/* ET_LOCAL_COMMA_VARIABLE */
static EIF_TYPE_INDEX ptf1808[] = {1807,0xFFFF};
static struct eif_par_types par1808 = {1808, ptf1808, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXPRESSION_LIST */
static EIF_TYPE_INDEX ptf1809[] = {1620,0xFFF7,1050,0xFF01,1669,0xFFFF};
static struct eif_par_types par1809 = {1809, ptf1809, (uint16) 2, (uint16) 0, (char) 0};

/* ET_MANIFEST_TUPLE */
static EIF_TYPE_INDEX ptf1810[] = {1724,0xFFF7,1809,0xFFFF};
static struct eif_par_types par1810 = {1810, ptf1810, (uint16) 2, (uint16) 0, (char) 0};

/* ET_MANIFEST_ARRAY */
static EIF_TYPE_INDEX ptf1811[] = {1724,0xFFF7,1809,0xFFFF};
static struct eif_par_types par1811 = {1811, ptf1811, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ACTUAL_ARGUMENT_LIST */
static EIF_TYPE_INDEX ptf1812[] = {219,0xFFF7,1809,0xFFFF};
static struct eif_par_types par1812 = {1812, ptf1812, (uint16) 2, (uint16) 0, (char) 0};

/* ET_UNFOLDED_TUPLE_ACTUAL_ARGUMENT_LIST */
static EIF_TYPE_INDEX ptf1813[] = {1812,0xFFFF};
static struct eif_par_types par1813 = {1813, ptf1813, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXPORT */
static EIF_TYPE_INDEX ptf1814[] = {1620,0xFFFF};
static struct eif_par_types par1814 = {1814, ptf1814, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ALL_EXPORT */
static EIF_TYPE_INDEX ptf1815[] = {1814,0xFFFF};
static struct eif_par_types par1815 = {1815, ptf1815, (uint16) 1, (uint16) 0, (char) 0};

/* ET_NULL_EXPORT */
static EIF_TYPE_INDEX ptf1816[] = {1814,0xFFFF};
static struct eif_par_types par1816 = {1816, ptf1816, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXTENDED_FEATURE_NAME */
static EIF_TYPE_INDEX ptf1817[] = {1620,0xFFFF};
static struct eif_par_types par1817 = {1817, ptf1817, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXTENDED_FEATURE_NAME_COMMA */
static EIF_TYPE_INDEX ptf1818[] = {1817,0xFFFF};
static struct eif_par_types par1818 = {1818, ptf1818, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ALIASED_FEATURE_NAME */
static EIF_TYPE_INDEX ptf1819[] = {1817,0xFFFF};
static struct eif_par_types par1819 = {1819, ptf1819, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FEATURE_NAME_ITEM */
static EIF_TYPE_INDEX ptf1820[] = {1817,0xFFFF};
static struct eif_par_types par1820 = {1820, ptf1820, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FEATURE_NAME_COMMA */
static EIF_TYPE_INDEX ptf1821[] = {1820,0xFFFF};
static struct eif_par_types par1821 = {1821, ptf1821, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FEATURE */
static EIF_TYPE_INDEX ptf1822[] = {1620,0xFFF7,1310,0xFFF7,1204,0xFFF7,900,0xFFFF};
static struct eif_par_types par1822 = {1822, ptf1822, (uint16) 4, (uint16) 0, (char) 0};

/* ET_DOTNET_FEATURE */
static EIF_TYPE_INDEX ptf1823[] = {1822,0xFFFF};
static struct eif_par_types par1823 = {1823, ptf1823, (uint16) 1, (uint16) 0, (char) 0};

/* ET_QUERY */
static EIF_TYPE_INDEX ptf1824[] = {1822,0xFFFF};
static struct eif_par_types par1824 = {1824, ptf1824, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONSTANT_QUERY */
static EIF_TYPE_INDEX ptf1825[] = {1824,0xFFFF};
static struct eif_par_types par1825 = {1825, ptf1825, (uint16) 1, (uint16) 0, (char) 0};

/* ET_UNIQUE_ATTRIBUTE */
static EIF_TYPE_INDEX ptf1826[] = {1825,0xFFFF};
static struct eif_par_types par1826 = {1826, ptf1826, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CONSTANT_ATTRIBUTE */
static EIF_TYPE_INDEX ptf1827[] = {1825,0xFFFF};
static struct eif_par_types par1827 = {1827, ptf1827, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ATTRIBUTE */
static EIF_TYPE_INDEX ptf1828[] = {1824,0xFFFF};
static struct eif_par_types par1828 = {1828, ptf1828, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXTENDED_ATTRIBUTE */
static EIF_TYPE_INDEX ptf1829[] = {1828,0xFFF7,285,0xFFFF};
static struct eif_par_types par1829 = {1829, ptf1829, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DOTNET_QUERY */
static EIF_TYPE_INDEX ptf1830[] = {1824,0xFFF7,1823,0xFFFF};
static struct eif_par_types par1830 = {1830, ptf1830, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DOTNET_CONSTANT_ATTRIBUTE */
static EIF_TYPE_INDEX ptf1831[] = {1827,0xFFF7,1830,0xFFFF};
static struct eif_par_types par1831 = {1831, ptf1831, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DOTNET_ATTRIBUTE */
static EIF_TYPE_INDEX ptf1832[] = {1828,0xFFF7,1830,0xFFFF};
static struct eif_par_types par1832 = {1832, ptf1832, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ROUTINE */
static EIF_TYPE_INDEX ptf1833[] = {1822,0xFFF7,286,0xFFFF};
static struct eif_par_types par1833 = {1833, ptf1833, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DOTNET_ROUTINE */
static EIF_TYPE_INDEX ptf1834[] = {1833,0xFFF7,1823,0xFFFF};
static struct eif_par_types par1834 = {1834, ptf1834, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DEFERRED_ROUTINE */
static EIF_TYPE_INDEX ptf1835[] = {1833,0xFFFF};
static struct eif_par_types par1835 = {1835, ptf1835, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EXTERNAL_ROUTINE */
static EIF_TYPE_INDEX ptf1836[] = {1833,0xFFF7,287,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1836 = {1836, ptf1836, (uint16) 3, (uint16) 0, (char) 0};

/* ET_INTERNAL_ROUTINE */
static EIF_TYPE_INDEX ptf1837[] = {1833,0xFFF7,288,0xFFFF};
static struct eif_par_types par1837 = {1837, ptf1837, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ONCE_ROUTINE */
static EIF_TYPE_INDEX ptf1838[] = {1837,0xFFF7,1017,0xFFFF};
static struct eif_par_types par1838 = {1838, ptf1838, (uint16) 2, (uint16) 0, (char) 0};

/* ET_FUNCTION */
static EIF_TYPE_INDEX ptf1839[] = {1824,0xFFF7,1833,0xFFFF};
static struct eif_par_types par1839 = {1839, ptf1839, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DOTNET_FUNCTION */
static EIF_TYPE_INDEX ptf1840[] = {1839,0xFFF7,1830,0xFFF7,1834,0xFFFF};
static struct eif_par_types par1840 = {1840, ptf1840, (uint16) 3, (uint16) 0, (char) 0};

/* ET_DEFERRED_FUNCTION */
static EIF_TYPE_INDEX ptf1841[] = {1839,0xFFF7,1835,0xFFFF};
static struct eif_par_types par1841 = {1841, ptf1841, (uint16) 2, (uint16) 0, (char) 0};

/* ET_EXTERNAL_FUNCTION */
static EIF_TYPE_INDEX ptf1842[] = {1839,0xFFF7,1836,0xFFFF};
static struct eif_par_types par1842 = {1842, ptf1842, (uint16) 2, (uint16) 0, (char) 0};

/* ET_INTERNAL_FUNCTION */
static EIF_TYPE_INDEX ptf1843[] = {1839,0xFFF7,1837,0xFFFF};
static struct eif_par_types par1843 = {1843, ptf1843, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DO_FUNCTION */
static EIF_TYPE_INDEX ptf1844[] = {1843,0xFFFF};
static struct eif_par_types par1844 = {1844, ptf1844, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ONCE_FUNCTION */
static EIF_TYPE_INDEX ptf1845[] = {1843,0xFFF7,1838,0xFFFF};
static struct eif_par_types par1845 = {1845, ptf1845, (uint16) 2, (uint16) 0, (char) 0};

/* ET_PROCEDURE */
static EIF_TYPE_INDEX ptf1846[] = {1833,0xFFFF};
static struct eif_par_types par1846 = {1846, ptf1846, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DOTNET_PROCEDURE */
static EIF_TYPE_INDEX ptf1847[] = {1846,0xFFF7,1834,0xFFFF};
static struct eif_par_types par1847 = {1847, ptf1847, (uint16) 2, (uint16) 0, (char) 0};

/* ET_EXTERNAL_PROCEDURE */
static EIF_TYPE_INDEX ptf1848[] = {1846,0xFFF7,1836,0xFFFF};
static struct eif_par_types par1848 = {1848, ptf1848, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DEFERRED_PROCEDURE */
static EIF_TYPE_INDEX ptf1849[] = {1846,0xFFF7,1835,0xFFFF};
static struct eif_par_types par1849 = {1849, ptf1849, (uint16) 2, (uint16) 0, (char) 0};

/* ET_INTERNAL_PROCEDURE */
static EIF_TYPE_INDEX ptf1850[] = {1846,0xFFF7,1837,0xFFFF};
static struct eif_par_types par1850 = {1850, ptf1850, (uint16) 2, (uint16) 0, (char) 0};

/* ET_DO_PROCEDURE */
static EIF_TYPE_INDEX ptf1851[] = {1850,0xFFFF};
static struct eif_par_types par1851 = {1851, ptf1851, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ONCE_PROCEDURE */
static EIF_TYPE_INDEX ptf1852[] = {1850,0xFFF7,1838,0xFFFF};
static struct eif_par_types par1852 = {1852, ptf1852, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ITERATION_COMPONENT */
static EIF_TYPE_INDEX ptf1853[] = {1620,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1853 = {1853, ptf1853, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ACROSS_COMPONENT */
static EIF_TYPE_INDEX ptf1854[] = {1853,0xFFFF};
static struct eif_par_types par1854 = {1854, ptf1854, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ITERATION_EXPRESSION */
static EIF_TYPE_INDEX ptf1855[] = {1853,0xFFF7,1724,0xFFFF};
static struct eif_par_types par1855 = {1855, ptf1855, (uint16) 2, (uint16) 0, (char) 0};

/* ET_QUANTIFIER_EXPRESSION */
static EIF_TYPE_INDEX ptf1856[] = {1855,0xFFFF};
static struct eif_par_types par1856 = {1856, ptf1856, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ACROSS_EXPRESSION */
static EIF_TYPE_INDEX ptf1857[] = {1855,0xFFF7,1854,0xFFFF};
static struct eif_par_types par1857 = {1857, ptf1857, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CONSTRAINT */
static EIF_TYPE_INDEX ptf1858[] = {1620,0xFFFF};
static struct eif_par_types par1858 = {1858, ptf1858, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TYPE_CONSTRAINT_LIST */
static EIF_TYPE_INDEX ptf1859[] = {1858,0xFFF7,1050,0xFF01,1699,0xFFFF};
static struct eif_par_types par1859 = {1859, ptf1859, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CONSTRAINT_BASE_TYPES */
static EIF_TYPE_INDEX ptf1860[] = {1858,0xFFFF};
static struct eif_par_types par1860 = {1860, ptf1860, (uint16) 1, (uint16) 0, (char) 0};

/* ET_BASE_TYPE_CONSTRAINT_LIST */
static EIF_TYPE_INDEX ptf1861[] = {1860,0xFFF7,1050,0xFF01,1864,0xFFFF};
static struct eif_par_types par1861 = {1861, ptf1861, (uint16) 2, (uint16) 0, (char) 0};

/* ET_TYPE_CONSTRAINT */
static EIF_TYPE_INDEX ptf1862[] = {1858,0xFFF7,1699,0xFFFF};
static struct eif_par_types par1862 = {1862, ptf1862, (uint16) 2, (uint16) 0, (char) 0};

/* ET_TYPE_RENAME_CONSTRAINT */
static EIF_TYPE_INDEX ptf1863[] = {1862,0xFFFF};
static struct eif_par_types par1863 = {1863, ptf1863, (uint16) 1, (uint16) 0, (char) 0};

/* ET_BASE_TYPE_CONSTRAINT */
static EIF_TYPE_INDEX ptf1864[] = {1860,0xFFF7,1862,0xFFF7,141,0xFFFF};
static struct eif_par_types par1864 = {1864, ptf1864, (uint16) 3, (uint16) 0, (char) 0};

/* ET_BASE_TYPE_RENAME_CONSTRAINT */
static EIF_TYPE_INDEX ptf1865[] = {1864,0xFFF7,1863,0xFFFF};
static struct eif_par_types par1865 = {1865, ptf1865, (uint16) 2, (uint16) 0, (char) 0};

/* ET_TYPE_MARK */
static EIF_TYPE_INDEX ptf1866[] = {1620,0xFFFF};
static struct eif_par_types par1866 = {1866, ptf1866, (uint16) 1, (uint16) 0, (char) 0};

/* ET_IMPLICIT_TYPE_MARK */
static EIF_TYPE_INDEX ptf1867[] = {1866,0xFFFF};
static struct eif_par_types par1867 = {1867, ptf1867, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ATTACHMENT_MARK_SEPARATE_KEYWORD */
static EIF_TYPE_INDEX ptf1868[] = {1866,0xFFFF};
static struct eif_par_types par1868 = {1868, ptf1868, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ACTUAL_PARAMETER_ITEM */
static EIF_TYPE_INDEX ptf1869[] = {1620,0xFFFF};
static struct eif_par_types par1869 = {1869, ptf1869, (uint16) 1, (uint16) 0, (char) 0};

/* ET_LABELED_ACTUAL_PARAMETER_SEMICOLON */
static EIF_TYPE_INDEX ptf1870[] = {1869,0xFFFF};
static struct eif_par_types par1870 = {1870, ptf1870, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ACTUAL_PARAMETER_COMMA */
static EIF_TYPE_INDEX ptf1871[] = {1869,0xFFFF};
static struct eif_par_types par1871 = {1871, ptf1871, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FORMAL_PARAMETER_ITEM */
static EIF_TYPE_INDEX ptf1872[] = {1869,0xFFFF};
static struct eif_par_types par1872 = {1872, ptf1872, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FORMAL_PARAMETER_COMMA */
static EIF_TYPE_INDEX ptf1873[] = {1872,0xFFFF};
static struct eif_par_types par1873 = {1873, ptf1873, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ACTUAL_PARAMETER */
static EIF_TYPE_INDEX ptf1874[] = {1869,0xFFF7,297,0xFFFF};
static struct eif_par_types par1874 = {1874, ptf1874, (uint16) 2, (uint16) 0, (char) 0};

/* ET_LABELED_ACTUAL_PARAMETER */
static EIF_TYPE_INDEX ptf1875[] = {1874,0xFFF7,1800,0xFFFF};
static struct eif_par_types par1875 = {1875, ptf1875, (uint16) 2, (uint16) 0, (char) 0};

/* ET_LABELED_COMMA_ACTUAL_PARAMETER */
static EIF_TYPE_INDEX ptf1876[] = {1875,0xFFFF};
static struct eif_par_types par1876 = {1876, ptf1876, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TYPE */
static EIF_TYPE_INDEX ptf1877[] = {1704,0xFFF7,1874,0xFFF7,1862,0xFFF7,300,0xFFF7,1706,0xFFF7,1702,0xFFF7,900,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1877 = {1877, ptf1877, (uint16) 8, (uint16) 0, (char) 0};

/* ET_NAMED_TYPE */
static EIF_TYPE_INDEX ptf1878[] = {1877,0xFFFF};
static struct eif_par_types par1878 = {1878, ptf1878, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FORMAL_PARAMETER_TYPE */
static EIF_TYPE_INDEX ptf1879[] = {1878,0xFFFF};
static struct eif_par_types par1879 = {1879, ptf1879, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FORMAL_PARAMETER */
static EIF_TYPE_INDEX ptf1880[] = {1872,0xFFF7,1879,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1880 = {1880, ptf1880, (uint16) 3, (uint16) 0, (char) 0};

/* ET_CONSTRAINED_FORMAL_PARAMETER */
static EIF_TYPE_INDEX ptf1881[] = {1880,0xFFFF};
static struct eif_par_types par1881 = {1881, ptf1881, (uint16) 1, (uint16) 0, (char) 0};

/* ET_LIKE_TYPE */
static EIF_TYPE_INDEX ptf1882[] = {1877,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1882 = {1882, ptf1882, (uint16) 2, (uint16) 0, (char) 0};

/* ET_LIKE_CURRENT */
static EIF_TYPE_INDEX ptf1883[] = {1882,0xFFFF};
static struct eif_par_types par1883 = {1883, ptf1883, (uint16) 1, (uint16) 0, (char) 0};

/* ET_LIKE_N */
static EIF_TYPE_INDEX ptf1884[] = {1882,0xFFFF};
static struct eif_par_types par1884 = {1884, ptf1884, (uint16) 1, (uint16) 0, (char) 0};

/* ET_LIKE_IDENTIFIER */
static EIF_TYPE_INDEX ptf1885[] = {1882,0xFFFF};
static struct eif_par_types par1885 = {1885, ptf1885, (uint16) 1, (uint16) 0, (char) 0};

/* ET_LIKE_FEATURE */
static EIF_TYPE_INDEX ptf1886[] = {1885,0xFFFF};
static struct eif_par_types par1886 = {1886, ptf1886, (uint16) 1, (uint16) 0, (char) 0};

/* ET_QUALIFIED_LIKE_IDENTIFIER */
static EIF_TYPE_INDEX ptf1887[] = {1885,0xFFFF};
static struct eif_par_types par1887 = {1887, ptf1887, (uint16) 1, (uint16) 0, (char) 0};

/* ET_QUALIFIED_LIKE_BRACED_TYPE */
static EIF_TYPE_INDEX ptf1888[] = {1887,0xFFFF};
static struct eif_par_types par1888 = {1888, ptf1888, (uint16) 1, (uint16) 0, (char) 0};

/* ET_QUALIFIED_LIKE_TYPE */
static EIF_TYPE_INDEX ptf1889[] = {1887,0xFFFF};
static struct eif_par_types par1889 = {1889, ptf1889, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ACTUAL_PARAMETERS */
static EIF_TYPE_INDEX ptf1890[] = {1620,0xFFFF};
static struct eif_par_types par1890 = {1890, ptf1890, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ACTUAL_PARAMETER_SUBLIST */
static EIF_TYPE_INDEX ptf1891[] = {1890,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1891 = {1891, ptf1891, (uint16) 2, (uint16) 0, (char) 0};

/* ET_UNFOLDED_TUPLE_ACTUAL_PARAMETERS */
static EIF_TYPE_INDEX ptf1892[] = {1890,0xFFFF};
static struct eif_par_types par1892 = {1892, ptf1892, (uint16) 1, (uint16) 0, (char) 0};

/* ET_UNFOLDED_EMPTY_TUPLE_ACTUAL_PARAMETERS */
static EIF_TYPE_INDEX ptf1893[] = {1890,0xFFFF};
static struct eif_par_types par1893 = {1893, ptf1893, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ACTUAL_PARAMETER_LIST */
static EIF_TYPE_INDEX ptf1894[] = {1890,0xFFF7,1050,0xFF01,1869,0xFFFF};
static struct eif_par_types par1894 = {1894, ptf1894, (uint16) 2, (uint16) 0, (char) 0};

/* ET_FORMAL_PARAMETER_LIST */
static EIF_TYPE_INDEX ptf1895[] = {1894,0xFFFF};
static struct eif_par_types par1895 = {1895, ptf1895, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ASSERTIONS */
static EIF_TYPE_INDEX ptf1896[] = {1620,0xFFF7,1050,0xFF01,1657,0xFFFF};
static struct eif_par_types par1896 = {1896, ptf1896, (uint16) 2, (uint16) 0, (char) 0};

/* ET_LOOP_INVARIANTS */
static EIF_TYPE_INDEX ptf1897[] = {1896,0xFFFF};
static struct eif_par_types par1897 = {1897, ptf1897, (uint16) 1, (uint16) 0, (char) 0};

/* ET_POSTCONDITIONS */
static EIF_TYPE_INDEX ptf1898[] = {1896,0xFFFF};
static struct eif_par_types par1898 = {1898, ptf1898, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INVARIANTS */
static EIF_TYPE_INDEX ptf1899[] = {1896,0xFFF7,1204,0xFFFF};
static struct eif_par_types par1899 = {1899, ptf1899, (uint16) 2, (uint16) 0, (char) 0};

/* ET_PRECONDITIONS */
static EIF_TYPE_INDEX ptf1900[] = {1896,0xFFFF};
static struct eif_par_types par1900 = {1900, ptf1900, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FEATURE_NAME_LIST */
static EIF_TYPE_INDEX ptf1901[] = {1620,0xFFF7,1050,0xFF01,1820,0xFFFF};
static struct eif_par_types par1901 = {1901, ptf1901, (uint16) 2, (uint16) 0, (char) 0};

/* ET_STRIP_EXPRESSION */
static EIF_TYPE_INDEX ptf1902[] = {1724,0xFFF7,1901,0xFFFF};
static struct eif_par_types par1902 = {1902, ptf1902, (uint16) 2, (uint16) 0, (char) 0};

/* ET_KEYWORD_FEATURE_NAME_LIST */
static EIF_TYPE_INDEX ptf1903[] = {1901,0xFFFF};
static struct eif_par_types par1903 = {1903, ptf1903, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FEATURE_EXPORT */
static EIF_TYPE_INDEX ptf1904[] = {1814,0xFFF7,1901,0xFFFF};
static struct eif_par_types par1904 = {1904, ptf1904, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CONSTRAINT_CREATOR */
static EIF_TYPE_INDEX ptf1905[] = {1901,0xFFFF};
static struct eif_par_types par1905 = {1905, ptf1905, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CREATOR */
static EIF_TYPE_INDEX ptf1906[] = {1901,0xFFFF};
static struct eif_par_types par1906 = {1906, ptf1906, (uint16) 1, (uint16) 0, (char) 0};

/* ET_AST_LEAF */
static EIF_TYPE_INDEX ptf1907[] = {1620,0xFFF7,1290,0xFFFF};
static struct eif_par_types par1907 = {1907, ptf1907, (uint16) 2, (uint16) 0, (char) 0};

/* ET_AST_NULL_LEAF */
static EIF_TYPE_INDEX ptf1908[] = {1907,0xFFFF};
static struct eif_par_types par1908 = {1908, ptf1908, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLASS_MARK */
static EIF_TYPE_INDEX ptf1909[] = {1866,0xFFF7,1907,0xFFFF};
static struct eif_par_types par1909 = {1909, ptf1909, (uint16) 2, (uint16) 0, (char) 0};

/* ET_SYMBOL */
static EIF_TYPE_INDEX ptf1910[] = {1909,0xFFF7,375,0xFFFF};
static struct eif_par_types par1910 = {1910, ptf1910, (uint16) 2, (uint16) 0, (char) 0};

/* ET_QUESTION_MARK_SYMBOL */
static EIF_TYPE_INDEX ptf1911[] = {1910,0xFFF7,1721,0xFFFF};
static struct eif_par_types par1911 = {1911, ptf1911, (uint16) 2, (uint16) 0, (char) 0};

/* ET_REAL_CONSTANT */
static EIF_TYPE_INDEX ptf1912[] = {1907,0xFFF7,1770,0xFFF7,1673,0xFFFF};
static struct eif_par_types par1912 = {1912, ptf1912, (uint16) 3, (uint16) 0, (char) 0};

/* ET_UNDERSCORED_REAL_CONSTANT */
static EIF_TYPE_INDEX ptf1913[] = {1912,0xFFFF};
static struct eif_par_types par1913 = {1913, ptf1913, (uint16) 1, (uint16) 0, (char) 0};

/* ET_REGULAR_REAL_CONSTANT */
static EIF_TYPE_INDEX ptf1914[] = {1912,0xFFFF};
static struct eif_par_types par1914 = {1914, ptf1914, (uint16) 1, (uint16) 0, (char) 0};

/* ET_TOKEN */
static EIF_TYPE_INDEX ptf1915[] = {1907,0xFFFF};
static struct eif_par_types par1915 = {1915, ptf1915, (uint16) 1, (uint16) 0, (char) 0};

/* ET_KEYWORD */
static EIF_TYPE_INDEX ptf1916[] = {1915,0xFFF7,1909,0xFFFF};
static struct eif_par_types par1916 = {1916, ptf1916, (uint16) 2, (uint16) 0, (char) 0};

/* ET_VOID */
static EIF_TYPE_INDEX ptf1917[] = {1724,0xFFF7,1916,0xFFFF};
static struct eif_par_types par1917 = {1917, ptf1917, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CURRENT */
static EIF_TYPE_INDEX ptf1918[] = {1724,0xFFF7,1916,0xFFFF};
static struct eif_par_types par1918 = {1918, ptf1918, (uint16) 2, (uint16) 0, (char) 0};

/* ET_RESULT */
static EIF_TYPE_INDEX ptf1919[] = {1741,0xFFF7,1916,0xFFFF};
static struct eif_par_types par1919 = {1919, ptf1919, (uint16) 2, (uint16) 0, (char) 0};

/* ET_BOOLEAN_CONSTANT */
static EIF_TYPE_INDEX ptf1920[] = {1770,0xFFF7,1673,0xFFF7,1916,0xFFFF};
static struct eif_par_types par1920 = {1920, ptf1920, (uint16) 3, (uint16) 0, (char) 0};

/* ET_TRUE_CONSTANT */
static EIF_TYPE_INDEX ptf1921[] = {1920,0xFFFF};
static struct eif_par_types par1921 = {1921, ptf1921, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FALSE_CONSTANT */
static EIF_TYPE_INDEX ptf1922[] = {1920,0xFFFF};
static struct eif_par_types par1922 = {1922, ptf1922, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CHARACTER_CONSTANT */
static EIF_TYPE_INDEX ptf1923[] = {1770,0xFFF7,1769,0xFFF7,1673,0xFFF7,1907,0xFFFF};
static struct eif_par_types par1923 = {1923, ptf1923, (uint16) 4, (uint16) 0, (char) 0};

/* ET_C3_CHARACTER_CONSTANT */
static EIF_TYPE_INDEX ptf1924[] = {1923,0xFFFF};
static struct eif_par_types par1924 = {1924, ptf1924, (uint16) 1, (uint16) 0, (char) 0};

/* ET_C2_CHARACTER_CONSTANT */
static EIF_TYPE_INDEX ptf1925[] = {1923,0xFFFF};
static struct eif_par_types par1925 = {1925, ptf1925, (uint16) 1, (uint16) 0, (char) 0};

/* ET_C1_CHARACTER_CONSTANT */
static EIF_TYPE_INDEX ptf1926[] = {1923,0xFFFF};
static struct eif_par_types par1926 = {1926, ptf1926, (uint16) 1, (uint16) 0, (char) 0};

/* ET_MANIFEST_STRING */
static EIF_TYPE_INDEX ptf1927[] = {1770,0xFFF7,1679,0xFFF7,1673,0xFFF7,1668,0xFFF7,1681,0xFFF7,1712,0xFFF7,1907,0xFFFF};
static struct eif_par_types par1927 = {1927, ptf1927, (uint16) 7, (uint16) 0, (char) 0};

/* ET_VERBATIM_STRING */
static EIF_TYPE_INDEX ptf1928[] = {1927,0xFFFF};
static struct eif_par_types par1928 = {1928, ptf1928, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SPECIAL_MANIFEST_STRING */
static EIF_TYPE_INDEX ptf1929[] = {1927,0xFFFF};
static struct eif_par_types par1929 = {1929, ptf1929, (uint16) 1, (uint16) 0, (char) 0};

/* ET_REGULAR_MANIFEST_STRING */
static EIF_TYPE_INDEX ptf1930[] = {1927,0xFFFF};
static struct eif_par_types par1930 = {1930, ptf1930, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INTEGER_CONSTANT */
static EIF_TYPE_INDEX ptf1931[] = {1907,0xFFF7,1770,0xFFF7,1769,0xFFF7,1673,0xFFFF};
static struct eif_par_types par1931 = {1931, ptf1931, (uint16) 4, (uint16) 0, (char) 0};

/* ET_UNDERSCORED_INTEGER_CONSTANT */
static EIF_TYPE_INDEX ptf1932[] = {1931,0xFFFF};
static struct eif_par_types par1932 = {1932, ptf1932, (uint16) 1, (uint16) 0, (char) 0};

/* ET_REGULAR_INTEGER_CONSTANT */
static EIF_TYPE_INDEX ptf1933[] = {1931,0xFFFF};
static struct eif_par_types par1933 = {1933, ptf1933, (uint16) 1, (uint16) 0, (char) 0};

/* ET_OCTAL_INTEGER_CONSTANT */
static EIF_TYPE_INDEX ptf1934[] = {1931,0xFFFF};
static struct eif_par_types par1934 = {1934, ptf1934, (uint16) 1, (uint16) 0, (char) 0};

/* ET_HEXADECIMAL_INTEGER_CONSTANT */
static EIF_TYPE_INDEX ptf1935[] = {1931,0xFFFF};
static struct eif_par_types par1935 = {1935, ptf1935, (uint16) 1, (uint16) 0, (char) 0};

/* ET_BINARY_INTEGER_CONSTANT */
static EIF_TYPE_INDEX ptf1936[] = {1931,0xFFFF};
static struct eif_par_types par1936 = {1936, ptf1936, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CALL_NAME */
static EIF_TYPE_INDEX ptf1937[] = {1620,0xFFF7,1056,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1937 = {1937, ptf1937, (uint16) 3, (uint16) 0, (char) 0};

/* ET_PARENTHESIS_SYMBOL */
static EIF_TYPE_INDEX ptf1938[] = {1910,0xFFF7,1937,0xFFFF};
static struct eif_par_types par1938 = {1938, ptf1938, (uint16) 2, (uint16) 0, (char) 0};

/* ET_BRACKET_SYMBOL */
static EIF_TYPE_INDEX ptf1939[] = {1910,0xFFF7,1937,0xFFFF};
static struct eif_par_types par1939 = {1939, ptf1939, (uint16) 2, (uint16) 0, (char) 0};

/* ET_PRECURSOR_KEYWORD */
static EIF_TYPE_INDEX ptf1940[] = {1916,0xFFF7,1937,0xFFFF};
static struct eif_par_types par1940 = {1940, ptf1940, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ALIAS_NAME */
static EIF_TYPE_INDEX ptf1941[] = {1937,0xFFF7,375,0xFFFF};
static struct eif_par_types par1941 = {1941, ptf1941, (uint16) 2, (uint16) 0, (char) 0};

/* ET_FREE_NAME */
static EIF_TYPE_INDEX ptf1942[] = {1937,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1942 = {1942, ptf1942, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ALIAS_FREE_NAME */
static EIF_TYPE_INDEX ptf1943[] = {1941,0xFFF7,1942,0xFFFF};
static struct eif_par_types par1943 = {1943, ptf1943, (uint16) 2, (uint16) 0, (char) 0};

/* ET_FEATURE_NAME */
static EIF_TYPE_INDEX ptf1944[] = {1937,0xFFF7,1820,0xFFF7,1710,0xFFF7,1708,0xFFFF};
static struct eif_par_types par1944 = {1944, ptf1944, (uint16) 4, (uint16) 0, (char) 0};

/* ET_AGENT_KEYWORD */
static EIF_TYPE_INDEX ptf1945[] = {1916,0xFFF7,1944,0xFFFF};
static struct eif_par_types par1945 = {1945, ptf1945, (uint16) 2, (uint16) 0, (char) 0};

/* ET_OPERATOR */
static EIF_TYPE_INDEX ptf1946[] = {1937,0xFFF7,375,0xFFFF};
static struct eif_par_types par1946 = {1946, ptf1946, (uint16) 2, (uint16) 0, (char) 0};

/* ET_INFIX_OR_ELSE_OPERATOR */
static EIF_TYPE_INDEX ptf1947[] = {1946,0xFFFF};
static struct eif_par_types par1947 = {1947, ptf1947, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INFIX_AND_THEN_OPERATOR */
static EIF_TYPE_INDEX ptf1948[] = {1946,0xFFFF};
static struct eif_par_types par1948 = {1948, ptf1948, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FREE_OPERATOR */
static EIF_TYPE_INDEX ptf1949[] = {1946,0xFFF7,1942,0xFFF7,1915,0xFFFF};
static struct eif_par_types par1949 = {1949, ptf1949, (uint16) 3, (uint16) 0, (char) 0};

/* ET_KEYWORD_OPERATOR */
static EIF_TYPE_INDEX ptf1950[] = {1916,0xFFF7,1946,0xFFFF};
static struct eif_par_types par1950 = {1950, ptf1950, (uint16) 2, (uint16) 0, (char) 0};

/* ET_SYMBOL_OPERATOR */
static EIF_TYPE_INDEX ptf1951[] = {1910,0xFFF7,1946,0xFFFF};
static struct eif_par_types par1951 = {1951, ptf1951, (uint16) 2, (uint16) 0, (char) 0};

/* ET_INSTRUCTION */
static EIF_TYPE_INDEX ptf1952[] = {1620,0xFFFF};
static struct eif_par_types par1952 = {1952, ptf1952, (uint16) 1, (uint16) 0, (char) 0};

/* ET_STATIC_CALL_INSTRUCTION */
static EIF_TYPE_INDEX ptf1953[] = {1777,0xFFF7,1952,0xFFFF};
static struct eif_par_types par1953 = {1953, ptf1953, (uint16) 2, (uint16) 0, (char) 0};

/* ET_LOOP_INSTRUCTION */
static EIF_TYPE_INDEX ptf1954[] = {1952,0xFFF7,1656,0xFFFF};
static struct eif_par_types par1954 = {1954, ptf1954, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CHECK_INSTRUCTION */
static EIF_TYPE_INDEX ptf1955[] = {1952,0xFFF7,1896,0xFFFF};
static struct eif_par_types par1955 = {1955, ptf1955, (uint16) 2, (uint16) 0, (char) 0};

/* ET_INSPECT_INSTRUCTION */
static EIF_TYPE_INDEX ptf1956[] = {1952,0xFFFF};
static struct eif_par_types par1956 = {1956, ptf1956, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DEBUG_INSTRUCTION */
static EIF_TYPE_INDEX ptf1957[] = {1952,0xFFFF};
static struct eif_par_types par1957 = {1957, ptf1957, (uint16) 1, (uint16) 0, (char) 0};

/* ET_IF_INSTRUCTION */
static EIF_TYPE_INDEX ptf1958[] = {1952,0xFFFF};
static struct eif_par_types par1958 = {1958, ptf1958, (uint16) 1, (uint16) 0, (char) 0};

/* ET_PRECURSOR_INSTRUCTION */
static EIF_TYPE_INDEX ptf1959[] = {1779,0xFFF7,1952,0xFFFF};
static struct eif_par_types par1959 = {1959, ptf1959, (uint16) 2, (uint16) 0, (char) 0};

/* ET_RETRY_INSTRUCTION */
static EIF_TYPE_INDEX ptf1960[] = {1952,0xFFF7,1916,0xFFFF};
static struct eif_par_types par1960 = {1960, ptf1960, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ASSIGNMENT_ATTEMPT */
static EIF_TYPE_INDEX ptf1961[] = {1952,0xFFFF};
static struct eif_par_types par1961 = {1961, ptf1961, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ASSIGNMENT */
static EIF_TYPE_INDEX ptf1962[] = {1952,0xFFFF};
static struct eif_par_types par1962 = {1962, ptf1962, (uint16) 1, (uint16) 0, (char) 0};

/* ET_NULL_INSTRUCTION */
static EIF_TYPE_INDEX ptf1963[] = {1952,0xFFFF};
static struct eif_par_types par1963 = {1963, ptf1963, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SEMICOLON_SYMBOL */
static EIF_TYPE_INDEX ptf1964[] = {1910,0xFFF7,1816,0xFFF7,1963,0xFFFF};
static struct eif_par_types par1964 = {1964, ptf1964, (uint16) 3, (uint16) 0, (char) 0};

/* ET_ITERATION_INSTRUCTION */
static EIF_TYPE_INDEX ptf1965[] = {1853,0xFFF7,1952,0xFFF7,1656,0xFFFF};
static struct eif_par_types par1965 = {1965, ptf1965, (uint16) 3, (uint16) 0, (char) 0};

/* ET_REPEAT_INSTRUCTION */
static EIF_TYPE_INDEX ptf1966[] = {1965,0xFFFF};
static struct eif_par_types par1966 = {1966, ptf1966, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ACROSS_INSTRUCTION */
static EIF_TYPE_INDEX ptf1967[] = {1965,0xFFF7,1854,0xFFFF};
static struct eif_par_types par1967 = {1967, ptf1967, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CREATION_INSTRUCTION */
static EIF_TYPE_INDEX ptf1968[] = {1952,0xFFF7,1714,0xFFFF};
static struct eif_par_types par1968 = {1968, ptf1968, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CREATE_INSTRUCTION */
static EIF_TYPE_INDEX ptf1969[] = {1968,0xFFFF};
static struct eif_par_types par1969 = {1969, ptf1969, (uint16) 1, (uint16) 0, (char) 0};

/* ET_BANG_INSTRUCTION */
static EIF_TYPE_INDEX ptf1970[] = {1968,0xFFFF};
static struct eif_par_types par1970 = {1970, ptf1970, (uint16) 1, (uint16) 0, (char) 0};

/* ET_FEATURE_CALL_INSTRUCTION */
static EIF_TYPE_INDEX ptf1971[] = {1781,0xFFF7,1952,0xFFFF};
static struct eif_par_types par1971 = {1971, ptf1971, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CALL_INSTRUCTION */
static EIF_TYPE_INDEX ptf1972[] = {1785,0xFFF7,1971,0xFFFF};
static struct eif_par_types par1972 = {1972, ptf1972, (uint16) 2, (uint16) 0, (char) 0};

/* ET_UNQUALIFIED_FEATURE_CALL_INSTRUCTION */
static EIF_TYPE_INDEX ptf1973[] = {1971,0xFFF7,1782,0xFFFF};
static struct eif_par_types par1973 = {1973, ptf1973, (uint16) 2, (uint16) 0, (char) 0};

/* ET_UNQUALIFIED_CALL_INSTRUCTION */
static EIF_TYPE_INDEX ptf1974[] = {1786,0xFFF7,1973,0xFFF7,1972,0xFFFF};
static struct eif_par_types par1974 = {1974, ptf1974, (uint16) 3, (uint16) 0, (char) 0};

/* ET_QUALIFIED_FEATURE_CALL_INSTRUCTION */
static EIF_TYPE_INDEX ptf1975[] = {1971,0xFFF7,1789,0xFFFF};
static struct eif_par_types par1975 = {1975, ptf1975, (uint16) 2, (uint16) 0, (char) 0};

/* ET_PARENTHESIS_INSTRUCTION */
static EIF_TYPE_INDEX ptf1976[] = {1791,0xFFF7,1975,0xFFFF};
static struct eif_par_types par1976 = {1976, ptf1976, (uint16) 2, (uint16) 0, (char) 0};

/* ET_QUALIFIED_CALL_INSTRUCTION */
static EIF_TYPE_INDEX ptf1977[] = {1790,0xFFF7,1975,0xFFF7,1972,0xFFFF};
static struct eif_par_types par1977 = {1977, ptf1977, (uint16) 3, (uint16) 0, (char) 0};

/* ET_ASSIGNER_INSTRUCTION */
static EIF_TYPE_INDEX ptf1978[] = {1952,0xFFF7,1975,0xFFF7,219,0xFFFF};
static struct eif_par_types par1978 = {1978, ptf1978, (uint16) 3, (uint16) 0, (char) 0};

/* ET_CLASS_NAME */
static EIF_TYPE_INDEX ptf1979[] = {1620,0xFFF7,1663,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1979 = {1979, ptf1979, (uint16) 3, (uint16) 0, (char) 0};

/* ET_IDENTIFIER */
static EIF_TYPE_INDEX ptf1980[] = {1944,0xFFF7,1979,0xFFF7,1739,0xFFF7,1735,0xFFF7,1738,0xFFF7,1667,0xFFF7,1665,0xFFF7,1741,0xFFF7,1769,0xFFF7,1673,0xFFF7,1915,0xFFF7,1784,0xFFF7,1973,0xFFF7,1211,0xFFF7,1191,0xFFFF};
static struct eif_par_types par1980 = {1980, ptf1980, (uint16) 15, (uint16) 0, (char) 0};

/* UT_CHARACTER_FORMATTER */
static EIF_TYPE_INDEX ptf1981[] = {0,0xFFF7,364,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1981 = {1981, ptf1981, (uint16) 3, (uint16) 0, (char) 0};

/* XM_DTD_EXTERNAL_ID */
static EIF_TYPE_INDEX ptf1982[] = {0,0xFFF7,1056,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1982 = {1982, ptf1982, (uint16) 3, (uint16) 0, (char) 0};

/* RX_CASE_MAPPING */
static EIF_TYPE_INDEX ptf1983[] = {0,0xFFF7,451,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1983 = {1983, ptf1983, (uint16) 3, (uint16) 0, (char) 0};

/* ET_CLASS_CODES */
static EIF_TYPE_INDEX ptf1984[] = {0,0xFFF7,374,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1984 = {1984, ptf1984, (uint16) 3, (uint16) 0, (char) 0};

/* ET_ECF_NOTE_ELEMENT */
static EIF_TYPE_INDEX ptf1985[] = {0,0xFFF7,986,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1985 = {1985, ptf1985, (uint16) 3, (uint16) 0, (char) 0};

/* ET_ECF_OPTIONS */
static EIF_TYPE_INDEX ptf1986[] = {0,0xFFF7,1211,0xFFF7,986,0xFFFF};
static struct eif_par_types par1986 = {1986, ptf1986, (uint16) 3, (uint16) 0, (char) 0};

/* RT_DBG_EXECUTION_RECORDER */
static EIF_TYPE_INDEX ptf1987[] = {0,0xFFFF};
static struct eif_par_types par1987 = {1987, ptf1987, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_CAPABILITIES */
static EIF_TYPE_INDEX ptf1988[] = {0,0xFFF7,1211,0xFFF7,986,0xFFFF};
static struct eif_par_types par1988 = {1988, ptf1988, (uint16) 3, (uint16) 0, (char) 0};

/* ET_DYNAMIC_SYSTEM */
static EIF_TYPE_INDEX ptf1989[] = {0,0xFFF7,470,0xFFF7,1007,0xFFFF};
static struct eif_par_types par1989 = {1989, ptf1989, (uint16) 3, (uint16) 0, (char) 0};

/* XM_OUTPUT */
static EIF_TYPE_INDEX ptf1990[] = {0,0xFFF7,452,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1990 = {1990, ptf1990, (uint16) 3, (uint16) 0, (char) 0};

/* XM_PRETTY_PRINT_FILTER */
static EIF_TYPE_INDEX ptf1991[] = {277,0xFFF7,1990,0xFFF7,449,0xFFFF};
static struct eif_par_types par1991 = {1991, ptf1991, (uint16) 3, (uint16) 0, (char) 0};

/* XM_INDENT_PRETTY_PRINT_FILTER */
static EIF_TYPE_INDEX ptf1992[] = {1991,0xFFFF};
static struct eif_par_types par1992 = {1992, ptf1992, (uint16) 1, (uint16) 0, (char) 0};

/* XM_CANONICAL_PRETTY_PRINT_FILTER */
static EIF_TYPE_INDEX ptf1993[] = {1991,0xFFFF};
static struct eif_par_types par1993 = {1993, ptf1993, (uint16) 1, (uint16) 0, (char) 0};

/* XM_SHARED_UNICODE_CHARACTERS */
static EIF_TYPE_INDEX ptf1994[] = {0,0xFFF7,449,0xFFF7,1211,0xFFFF};
static struct eif_par_types par1994 = {1994, ptf1994, (uint16) 3, (uint16) 0, (char) 0};

/* XM_UNICODE_VALIDATION_FILTER */
static EIF_TYPE_INDEX ptf1995[] = {277,0xFFF7,1994,0xFFFF};
static struct eif_par_types par1995 = {1995, ptf1995, (uint16) 2, (uint16) 0, (char) 0};

/* KI_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1996[] = {0,0xFFF7,1191,0xFFF7,984,0xFFFF};
static struct eif_par_types par1996 = {1996, ptf1996, (uint16) 3, (uint16) 0, (char) 0};

/* KL_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1997[] = {1996,0xFFF7,1211,0xFFF7,1191,0xFFF7,1580,0xFFFF};
static struct eif_par_types par1997 = {1997, ptf1997, (uint16) 4, (uint16) 0, (char) 0};

/* KL_UNIX_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1998[] = {1997,0xFFFF};
static struct eif_par_types par1998 = {1998, ptf1998, (uint16) 1, (uint16) 0, (char) 0};

/* KL_WINDOWS_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1999[] = {1997,0xFFFF};
static struct eif_par_types par1999 = {1999, ptf1999, (uint16) 1, (uint16) 0, (char) 0};

/* KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY */
static EIF_TYPE_INDEX ptf2000[] = {1999,0xFFFF};
static struct eif_par_types par2000 = {2000, ptf2000, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLUSTERS */
static EIF_TYPE_INDEX ptf2001[] = {0,0xFFF7,1580,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2001 = {2001, ptf2001, (uint16) 3, (uint16) 0, (char) 0};

/* ET_ECF_CLUSTERS */
static EIF_TYPE_INDEX ptf2002[] = {2001,0xFFFF};
static struct eif_par_types par2002 = {2002, ptf2002, (uint16) 1, (uint16) 0, (char) 0};

/* XM_NODE */
static EIF_TYPE_INDEX ptf2003[] = {0,0xFFF7,1417,0xFFF7,388,0xFFFF};
static struct eif_par_types par2003 = {2003, ptf2003, (uint16) 3, (uint16) 0, (char) 0};

/* XM_COMPOSITE_NODE */
static EIF_TYPE_INDEX ptf2004[] = {2003,0xFFFF};
static struct eif_par_types par2004 = {2004, ptf2004, (uint16) 1, (uint16) 0, (char) 0};

/* XM_DOCUMENT_NODE */
static EIF_TYPE_INDEX ptf2005[] = {2004,0xFFFF};
static struct eif_par_types par2005 = {2005, ptf2005, (uint16) 1, (uint16) 0, (char) 0};

/* XM_ELEMENT_NODE */
static EIF_TYPE_INDEX ptf2006[] = {2004,0xFFFF};
static struct eif_par_types par2006 = {2006, ptf2006, (uint16) 1, (uint16) 0, (char) 0};

/* XM_COMMENT */
static EIF_TYPE_INDEX ptf2007[] = {2005,0xFFF7,2006,0xFFFF};
static struct eif_par_types par2007 = {2007, ptf2007, (uint16) 2, (uint16) 0, (char) 0};

/* XM_PROCESSING_INSTRUCTION */
static EIF_TYPE_INDEX ptf2008[] = {2005,0xFFF7,2006,0xFFFF};
static struct eif_par_types par2008 = {2008, ptf2008, (uint16) 2, (uint16) 0, (char) 0};

/* XM_CHARACTER_DATA */
static EIF_TYPE_INDEX ptf2009[] = {2006,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2009 = {2009, ptf2009, (uint16) 2, (uint16) 0, (char) 0};

/* XM_NAMED_NODE */
static EIF_TYPE_INDEX ptf2010[] = {2006,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2010 = {2010, ptf2010, (uint16) 2, (uint16) 0, (char) 0};

/* XM_ATTRIBUTE */
static EIF_TYPE_INDEX ptf2011[] = {2010,0xFFF7,449,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2011 = {2011, ptf2011, (uint16) 3, (uint16) 0, (char) 0};

/* XM_COMPOSITE */
static EIF_TYPE_INDEX ptf2012[] = {2003,0xFFF7,472,0xFF01,2004,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2012 = {2012, ptf2012, (uint16) 3, (uint16) 0, (char) 0};

/* XM_DOCUMENT */
static EIF_TYPE_INDEX ptf2013[] = {2012,0xFFFF};
static struct eif_par_types par2013 = {2013, ptf2013, (uint16) 1, (uint16) 0, (char) 0};

/* XM_ELEMENT */
static EIF_TYPE_INDEX ptf2014[] = {2012,0xFFF7,2010,0xFFF7,2005,0xFFFF};
static struct eif_par_types par2014 = {2014, ptf2014, (uint16) 3, (uint16) 0, (char) 0};

/* ET_TYPE_CONTEXT */
static EIF_TYPE_INDEX ptf2015[] = {0,0xFFF7,1007,0xFFF7,1191,0xFFFF};
static struct eif_par_types par2015 = {2015, ptf2015, (uint16) 3, (uint16) 0, (char) 0};

/* ET_NESTED_TYPE_CONTEXT */
static EIF_TYPE_INDEX ptf2016[] = {2015,0xFFF7,888,0xFF01,1877,0xFFFF};
static struct eif_par_types par2016 = {2016, ptf2016, (uint16) 2, (uint16) 0, (char) 0};

/* ET_BASE_TYPE */
static EIF_TYPE_INDEX ptf2017[] = {1878,0xFFF7,2015,0xFFF7,1864,0xFFFF};
static struct eif_par_types par2017 = {2017, ptf2017, (uint16) 3, (uint16) 0, (char) 0};

/* ET_TUPLE_TYPE */
static EIF_TYPE_INDEX ptf2018[] = {2017,0xFFFF};
static struct eif_par_types par2018 = {2018, ptf2018, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLASS_TYPE */
static EIF_TYPE_INDEX ptf2019[] = {2017,0xFFF7,424,0xFFFF};
static struct eif_par_types par2019 = {2019, ptf2019, (uint16) 2, (uint16) 0, (char) 0};

/* ET_CLASS */
static EIF_TYPE_INDEX ptf2020[] = {1133,0xFFF7,2019,0xFFF7,129,0xFFF7,1056,0xFFFF};
static struct eif_par_types par2020 = {2020, ptf2020, (uint16) 4, (uint16) 0, (char) 0};

/* RX_PATTERN_MATCHER */
static EIF_TYPE_INDEX ptf2021[] = {0,0xFFF7,1211,0xFFF7,1191,0xFFFF};
static struct eif_par_types par2021 = {2021, ptf2021, (uint16) 3, (uint16) 0, (char) 0};

/* RX_REGULAR_EXPRESSION */
static EIF_TYPE_INDEX ptf2022[] = {2021,0xFFF7,215,0xFFF7,984,0xFFFF};
static struct eif_par_types par2022 = {2022, ptf2022, (uint16) 3, (uint16) 0, (char) 0};

/* LX_PATTERN_MATCHER */
static EIF_TYPE_INDEX ptf2023[] = {2021,0xFFFF};
static struct eif_par_types par2023 = {2023, ptf2023, (uint16) 1, (uint16) 0, (char) 0};

/* LX_DFA_PATTERN_MATCHER */
static EIF_TYPE_INDEX ptf2024[] = {2023,0xFFFF};
static struct eif_par_types par2024 = {2024, ptf2024, (uint16) 1, (uint16) 0, (char) 0};

/* LX_WILDCARD */
static EIF_TYPE_INDEX ptf2025[] = {2023,0xFFFF};
static struct eif_par_types par2025 = {2025, ptf2025, (uint16) 1, (uint16) 0, (char) 0};

/* LX_DFA_WILDCARD */
static EIF_TYPE_INDEX ptf2026[] = {2025,0xFFF7,2024,0xFFFF};
static struct eif_par_types par2026 = {2026, ptf2026, (uint16) 2, (uint16) 0, (char) 0};

/* DT_DATE_VALUE */
static EIF_TYPE_INDEX ptf2027[] = {0,0xFFF7,1211,0xFFF7,1006,0xFFFF};
static struct eif_par_types par2027 = {2027, ptf2027, (uint16) 3, (uint16) 0, (char) 0};

/* DT_DATE_DURATION */
static EIF_TYPE_INDEX ptf2028[] = {1427,0xFFF7,2027,0xFFF7,1284,0xFFF7,1191,0xFFFF};
static struct eif_par_types par2028 = {2028, ptf2028, (uint16) 4, (uint16) 0, (char) 0};

/* DT_DATE */
static EIF_TYPE_INDEX ptf2029[] = {1428,0xFFF7,2027,0xFFF7,1284,0xFFF7,291,0xFFF7,290,0xFFFF};
static struct eif_par_types par2029 = {2029, ptf2029, (uint16) 5, (uint16) 0, (char) 0};

/* DT_TIME_VALUE */
static EIF_TYPE_INDEX ptf2030[] = {0,0xFFF7,1211,0xFFF7,1006,0xFFFF};
static struct eif_par_types par2030 = {2030, ptf2030, (uint16) 3, (uint16) 0, (char) 0};

/* DT_TIME_DURATION */
static EIF_TYPE_INDEX ptf2031[] = {1427,0xFFF7,2030,0xFFF7,1284,0xFFF7,1191,0xFFFF};
static struct eif_par_types par2031 = {2031, ptf2031, (uint16) 4, (uint16) 0, (char) 0};

/* DT_TIME */
static EIF_TYPE_INDEX ptf2032[] = {1428,0xFFF7,2030,0xFFF7,1284,0xFFF7,292,0xFFFF};
static struct eif_par_types par2032 = {2032, ptf2032, (uint16) 4, (uint16) 0, (char) 0};

/* DT_DATE_TIME_VALUE */
static EIF_TYPE_INDEX ptf2033[] = {2027,0xFFF7,2030,0xFFFF};
static struct eif_par_types par2033 = {2033, ptf2033, (uint16) 2, (uint16) 0, (char) 0};

/* DT_DATE_TIME_DURATION */
static EIF_TYPE_INDEX ptf2034[] = {2028,0xFFF7,2031,0xFFF7,2033,0xFFFF};
static struct eif_par_types par2034 = {2034, ptf2034, (uint16) 3, (uint16) 0, (char) 0};

/* DT_DATE_TIME */
static EIF_TYPE_INDEX ptf2035[] = {2029,0xFFF7,2032,0xFFF7,2033,0xFFF7,293,0xFFFF};
static struct eif_par_types par2035 = {2035, ptf2035, (uint16) 4, (uint16) 0, (char) 0};

/* UT_ERROR_HANDLER */
static EIF_TYPE_INDEX ptf2036[] = {0,0xFFF7,452,0xFFF7,195,0xFFFF};
static struct eif_par_types par2036 = {2036, ptf2036, (uint16) 3, (uint16) 0, (char) 0};

/* AP_ERROR_HANDLER */
static EIF_TYPE_INDEX ptf2037[] = {2036,0xFFFF};
static struct eif_par_types par2037 = {2037, ptf2037, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_ERROR_HANDLER */
static EIF_TYPE_INDEX ptf2038[] = {2036,0xFFFF};
static struct eif_par_types par2038 = {2038, ptf2038, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ERROR_HANDLER */
static EIF_TYPE_INDEX ptf2039[] = {2036,0xFFF7,984,0xFFFF};
static struct eif_par_types par2039 = {2039, ptf2039, (uint16) 2, (uint16) 0, (char) 0};

/* ET_NULL_ERROR_HANDLER */
static EIF_TYPE_INDEX ptf2040[] = {2039,0xFFFF};
static struct eif_par_types par2040 = {2040, ptf2040, (uint16) 1, (uint16) 0, (char) 0};

/* XM_XMLNS_GENERATOR_CONTEXT */
static EIF_TYPE_INDEX ptf2041[] = {0,0xFFF7,1211,0xFFF7,449,0xFFF7,387,0xFFFF};
static struct eif_par_types par2041 = {2041, ptf2041, (uint16) 4, (uint16) 0, (char) 0};

/* XM_NAMESPACE_RESOLVER_CONTEXT */
static EIF_TYPE_INDEX ptf2042[] = {0,0xFFF7,1210,0xFFF7,388,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2042 = {2042, ptf2042, (uint16) 4, (uint16) 0, (char) 0};

/* XM_DTD_ATTRIBUTE_CONTENT */
static EIF_TYPE_INDEX ptf2043[] = {0,0xFFF7,1210,0xFFF7,1211,0xFFF7,172,0xFFFF};
static struct eif_par_types par2043 = {2043, ptf2043, (uint16) 4, (uint16) 0, (char) 0};

/* UC_UNICODE_ROUTINES */
static EIF_TYPE_INDEX ptf2044[] = {0,0xFFF7,1273,0xFFF7,1006,0xFFF7,95,0xFFFF};
static struct eif_par_types par2044 = {2044, ptf2044, (uint16) 4, (uint16) 0, (char) 0};

/* ET_FEATURE_IDS */
static EIF_TYPE_INDEX ptf2045[] = {0,0xFFF7,1417,0xFFF7,1191,0xFFF7,984,0xFFFF};
static struct eif_par_types par2045 = {2045, ptf2045, (uint16) 4, (uint16) 0, (char) 0};

/* ET_ECF_SETTING_DEFAULTS */
static EIF_TYPE_INDEX ptf2046[] = {0,0xFFF7,392,0xFFF7,986,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2046 = {2046, ptf2046, (uint16) 4, (uint16) 0, (char) 0};

/* ET_ECF_OPTION_DEFAULTS */
static EIF_TYPE_INDEX ptf2047[] = {0,0xFFF7,392,0xFFF7,986,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2047 = {2047, ptf2047, (uint16) 4, (uint16) 0, (char) 0};

/* DT_CLOCK */
static EIF_TYPE_INDEX ptf2048[] = {0,0xFFF7,290,0xFFF7,292,0xFFF7,293,0xFFFF};
static struct eif_par_types par2048 = {2048, ptf2048, (uint16) 4, (uint16) 0, (char) 0};

/* DT_SYSTEM_CLOCK */
static EIF_TYPE_INDEX ptf2049[] = {2048,0xFFF7,1284,0xFFF7,78,0xFFFF};
static struct eif_par_types par2049 = {2049, ptf2049, (uint16) 3, (uint16) 0, (char) 0};

/* DT_UTC_SYSTEM_CLOCK */
static EIF_TYPE_INDEX ptf2050[] = {2048,0xFFF7,1284,0xFFF7,78,0xFFFF};
static struct eif_par_types par2050 = {2050, ptf2050, (uint16) 3, (uint16) 0, (char) 0};

/* ET_ECF_CAPABILITY_DEFAULTS */
static EIF_TYPE_INDEX ptf2051[] = {0,0xFFF7,392,0xFFF7,986,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2051 = {2051, ptf2051, (uint16) 4, (uint16) 0, (char) 0};

/* ET_ECF_VOID_SAFETY_CONDITION */
static EIF_TYPE_INDEX ptf2052[] = {163,0xFFF7,2051,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2052 = {2052, ptf2052, (uint16) 3, (uint16) 0, (char) 0};

/* ET_ECF_CONCURRENCY_CONDITION */
static EIF_TYPE_INDEX ptf2053[] = {163,0xFFF7,2051,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2053 = {2053, ptf2053, (uint16) 3, (uint16) 0, (char) 0};

/* YY_PARSER_TOKENS */
static EIF_TYPE_INDEX ptf2054[] = {0,0xFFF7,95,0xFFF7,1006,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2054 = {2054, ptf2054, (uint16) 4, (uint16) 0, (char) 0};

/* LX_WILDCARD_TOKENS */
static EIF_TYPE_INDEX ptf2055[] = {2054,0xFFFF};
static struct eif_par_types par2055 = {2055, ptf2055, (uint16) 1, (uint16) 0, (char) 0};

/* LX_WILDCARD_SCANNER */
static EIF_TYPE_INDEX ptf2056[] = {1278,0xFFF7,2055,0xFFFF};
static struct eif_par_types par2056 = {2056, ptf2056, (uint16) 2, (uint16) 0, (char) 0};

/* ET_EIFFEL_TOKENS */
static EIF_TYPE_INDEX ptf2057[] = {2054,0xFFFF};
static struct eif_par_types par2057 = {2057, ptf2057, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EIFFEL_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf2058[] = {1277,0xFFF7,2057,0xFFF7,281,0xFFF7,1006,0xFFF7,1211,0xFFF7,95,0xFFF7,116,0xFFF7,471,0xFFF7,1580,0xFFF7,1007,0xFFF7,986,0xFFFF};
static struct eif_par_types par2058 = {2058, ptf2058, (uint16) 11, (uint16) 0, (char) 0};

/* ET_EIFFEL_PREPARSER_SKELETON */
static EIF_TYPE_INDEX ptf2059[] = {2058,0xFFF7,254,0xFFFF};
static struct eif_par_types par2059 = {2059, ptf2059, (uint16) 2, (uint16) 0, (char) 0};

/* ET_EIFFEL_PREPARSER */
static EIF_TYPE_INDEX ptf2060[] = {2059,0xFFFF};
static struct eif_par_types par2060 = {2060, ptf2060, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EIFFEL_SCANNER */
static EIF_TYPE_INDEX ptf2061[] = {2058,0xFFFF};
static struct eif_par_types par2061 = {2061, ptf2061, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EIFFEL_TOKENS */
static EIF_TYPE_INDEX ptf2062[] = {2054,0xFFFF};
static struct eif_par_types par2062 = {2062, ptf2062, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EIFFEL_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf2063[] = {1277,0xFFF7,2062,0xFFF7,171,0xFFFF};
static struct eif_par_types par2063 = {2063, ptf2063, (uint16) 3, (uint16) 0, (char) 0};

/* XM_EIFFEL_SCANNER */
static EIF_TYPE_INDEX ptf2064[] = {2063,0xFFFF};
static struct eif_par_types par2064 = {2064, ptf2064, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EIFFEL_SCANNER_DTD */
static EIF_TYPE_INDEX ptf2065[] = {2064,0xFFFF};
static struct eif_par_types par2065 = {2065, ptf2065, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EIFFEL_ENTITY_DEF */
static EIF_TYPE_INDEX ptf2066[] = {1056,0xFFF7,2064,0xFFF7,415,0xFFFF};
static struct eif_par_types par2066 = {2066, ptf2066, (uint16) 3, (uint16) 0, (char) 0};

/* XM_EIFFEL_PE_ENTITY_DEF */
static EIF_TYPE_INDEX ptf2067[] = {2066,0xFFFF};
static struct eif_par_types par2067 = {2067, ptf2067, (uint16) 1, (uint16) 0, (char) 0};

/* YY_PARSER_SKELETON */
static EIF_TYPE_INDEX ptf2068[] = {91,0xFFF7,2054,0xFFF7,452,0xFFF7,451,0xFFF7,984,0xFFFF};
static struct eif_par_types par2068 = {2068, ptf2068, (uint16) 5, (uint16) 0, (char) 0};

/* LX_LEX_PARSER_SKELETON */
static EIF_TYPE_INDEX ptf2069[] = {2068,0xFFF7,1278,0xFFFF};
static struct eif_par_types par2069 = {2069, ptf2069, (uint16) 2, (uint16) 0, (char) 0};

/* LX_WILDCARD_PARSER */
static EIF_TYPE_INDEX ptf2070[] = {2069,0xFFF7,2056,0xFFFF};
static struct eif_par_types par2070 = {2070, ptf2070, (uint16) 2, (uint16) 0, (char) 0};

/* XM_EIFFEL_PARSER_SKELETON */
static EIF_TYPE_INDEX ptf2071[] = {1281,0xFFF7,276,0xFFF7,191,0xFFF7,2068,0xFFF7,2062,0xFFF7,171,0xFFF7,1210,0xFFF7,415,0xFFF7,450,0xFFF7,391,0xFFF7,1006,0xFFF7,1191,0xFFFF};
static struct eif_par_types par2071 = {2071, ptf2071, (uint16) 12, (uint16) 0, (char) 0};

/* XM_EIFFEL_PARSER */
static EIF_TYPE_INDEX ptf2072[] = {2071,0xFFFF};
static struct eif_par_types par2072 = {2072, ptf2072, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EIFFEL_PARSER_SKELETON */
static EIF_TYPE_INDEX ptf2073[] = {2068,0xFFF7,2058,0xFFF7,1021,0xFFF7,254,0xFFF7,424,0xFFF7,470,0xFFFF};
static struct eif_par_types par2073 = {2073, ptf2073, (uint16) 6, (uint16) 0, (char) 0};

/* ET_EIFFEL_PARSER */
static EIF_TYPE_INDEX ptf2074[] = {2073,0xFFF7,2061,0xFFFF};
static struct eif_par_types par2074 = {2074, ptf2074, (uint16) 2, (uint16) 0, (char) 0};

/* UT_STRING_FORMATTER */
static EIF_TYPE_INDEX ptf2075[] = {0,0xFFF7,1211,0xFFF7,1006,0xFFF7,1191,0xFFF7,364,0xFFFF};
static struct eif_par_types par2075 = {2075, ptf2075, (uint16) 5, (uint16) 0, (char) 0};

/* XM_DTD_ELEMENT_CONTENT */
static EIF_TYPE_INDEX ptf2076[] = {0,0xFFF7,95,0xFFF7,1210,0xFFF7,388,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2076 = {2076, ptf2076, (uint16) 5, (uint16) 0, (char) 0};

/* ET_ECF_TARGET */
static EIF_TYPE_INDEX ptf2077[] = {0,0xFFF7,203,0xFFF7,1007,0xFFF7,471,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2077 = {2077, ptf2077, (uint16) 5, (uint16) 0, (char) 0};

/* UT_ERROR */
static EIF_TYPE_INDEX ptf2078[] = {0,0xFFF7,354,0xFFF7,1211,0xFFF7,984,0xFFF7,1191,0xFFFF};
static struct eif_par_types par2078 = {2078, ptf2078, (uint16) 5, (uint16) 0, (char) 0};

/* LX_INVALID_UNICODE_CHARACTER_ERROR */
static EIF_TYPE_INDEX ptf2079[] = {2078,0xFFFF};
static struct eif_par_types par2079 = {2079, ptf2079, (uint16) 1, (uint16) 0, (char) 0};

/* LX_CHARACTER_OUT_OF_RANGE_ERROR */
static EIF_TYPE_INDEX ptf2080[] = {2078,0xFFFF};
static struct eif_par_types par2080 = {2080, ptf2080, (uint16) 1, (uint16) 0, (char) 0};

/* LX_BAD_START_CONDITION_ERROR */
static EIF_TYPE_INDEX ptf2081[] = {2078,0xFFFF};
static struct eif_par_types par2081 = {2081, ptf2081, (uint16) 1, (uint16) 0, (char) 0};

/* LX_BAD_CHARACTER_IN_BRACKETS_ERROR */
static EIF_TYPE_INDEX ptf2082[] = {2078,0xFFFF};
static struct eif_par_types par2082 = {2082, ptf2082, (uint16) 1, (uint16) 0, (char) 0};

/* LX_BAD_CHARACTER_CLASS_ERROR */
static EIF_TYPE_INDEX ptf2083[] = {2078,0xFFFF};
static struct eif_par_types par2083 = {2083, ptf2083, (uint16) 1, (uint16) 0, (char) 0};

/* LX_BAD_CHARACTER_ERROR */
static EIF_TYPE_INDEX ptf2084[] = {2078,0xFFFF};
static struct eif_par_types par2084 = {2084, ptf2084, (uint16) 1, (uint16) 0, (char) 0};

/* LX_UNRECOGNIZED_OPTION_ERROR */
static EIF_TYPE_INDEX ptf2085[] = {2078,0xFFFF};
static struct eif_par_types par2085 = {2085, ptf2085, (uint16) 1, (uint16) 0, (char) 0};

/* LX_UNRECOGNIZED_DIRECTIVE_ERROR */
static EIF_TYPE_INDEX ptf2086[] = {2078,0xFFFF};
static struct eif_par_types par2086 = {2086, ptf2086, (uint16) 1, (uint16) 0, (char) 0};

/* LX_UNDEFINED_DEFINITION_ERROR */
static EIF_TYPE_INDEX ptf2087[] = {2078,0xFFFF};
static struct eif_par_types par2087 = {2087, ptf2087, (uint16) 1, (uint16) 0, (char) 0};

/* LX_START_CONDITION_EXPECTED_ERROR */
static EIF_TYPE_INDEX ptf2088[] = {2078,0xFFFF};
static struct eif_par_types par2088 = {2088, ptf2088, (uint16) 1, (uint16) 0, (char) 0};

/* LX_NAME_DEFINED_TWICE_ERROR */
static EIF_TYPE_INDEX ptf2089[] = {2078,0xFFFF};
static struct eif_par_types par2089 = {2089, ptf2089, (uint16) 1, (uint16) 0, (char) 0};

/* LX_START_CONDITION_DECLARED_TWICE_ERROR */
static EIF_TYPE_INDEX ptf2090[] = {2078,0xFFFF};
static struct eif_par_types par2090 = {2090, ptf2090, (uint16) 1, (uint16) 0, (char) 0};

/* LX_MISSING_QUOTE_ERROR */
static EIF_TYPE_INDEX ptf2091[] = {2078,0xFFFF};
static struct eif_par_types par2091 = {2091, ptf2091, (uint16) 1, (uint16) 0, (char) 0};

/* LX_MISSING_BRACKET_ERROR */
static EIF_TYPE_INDEX ptf2092[] = {2078,0xFFFF};
static struct eif_par_types par2092 = {2092, ptf2092, (uint16) 1, (uint16) 0, (char) 0};

/* LX_INCOMPLETE_NAME_DEFINITION_ERROR */
static EIF_TYPE_INDEX ptf2093[] = {2078,0xFFFF};
static struct eif_par_types par2093 = {2093, ptf2093, (uint16) 1, (uint16) 0, (char) 0};

/* LX_DIRECTIVE_EXPECTED_ERROR */
static EIF_TYPE_INDEX ptf2094[] = {2078,0xFFFF};
static struct eif_par_types par2094 = {2094, ptf2094, (uint16) 1, (uint16) 0, (char) 0};

/* LX_INTEGER_TOO_LARGE_ERROR */
static EIF_TYPE_INDEX ptf2095[] = {2078,0xFFFF};
static struct eif_par_types par2095 = {2095, ptf2095, (uint16) 1, (uint16) 0, (char) 0};

/* LX_BAD_ITERATION_VALUES_ERROR */
static EIF_TYPE_INDEX ptf2096[] = {2078,0xFFFF};
static struct eif_par_types par2096 = {2096, ptf2096, (uint16) 1, (uint16) 0, (char) 0};

/* LX_UNDECLARED_START_CONDITION_ERROR */
static EIF_TYPE_INDEX ptf2097[] = {2078,0xFFFF};
static struct eif_par_types par2097 = {2097, ptf2097, (uint16) 1, (uint16) 0, (char) 0};

/* LX_TRAILING_CONTEXT_USED_TWICE_ERROR */
static EIF_TYPE_INDEX ptf2098[] = {2078,0xFFFF};
static struct eif_par_types par2098 = {2098, ptf2098, (uint16) 1, (uint16) 0, (char) 0};

/* LX_START_CONDITION_SPECIFIED_TWICE_ERROR */
static EIF_TYPE_INDEX ptf2099[] = {2078,0xFFFF};
static struct eif_par_types par2099 = {2099, ptf2099, (uint16) 1, (uint16) 0, (char) 0};

/* LX_BAD_START_CONDITION_LIST_ERROR */
static EIF_TYPE_INDEX ptf2100[] = {2078,0xFFFF};
static struct eif_par_types par2100 = {2100, ptf2100, (uint16) 1, (uint16) 0, (char) 0};

/* UT_SYNTAX_ERROR */
static EIF_TYPE_INDEX ptf2101[] = {2078,0xFFFF};
static struct eif_par_types par2101 = {2101, ptf2101, (uint16) 1, (uint16) 0, (char) 0};

/* LX_FULL_AND_REJECT_ERROR */
static EIF_TYPE_INDEX ptf2102[] = {2078,0xFFFF};
static struct eif_par_types par2102 = {2102, ptf2102, (uint16) 1, (uint16) 0, (char) 0};

/* LX_ALL_START_CONDITIONS_EOF_ERROR */
static EIF_TYPE_INDEX ptf2103[] = {2078,0xFFFF};
static struct eif_par_types par2103 = {2103, ptf2103, (uint16) 1, (uint16) 0, (char) 0};

/* LX_FULL_AND_VARIABLE_TRAILING_CONTEXT_ERROR */
static EIF_TYPE_INDEX ptf2104[] = {2078,0xFFFF};
static struct eif_par_types par2104 = {2104, ptf2104, (uint16) 1, (uint16) 0, (char) 0};

/* LX_UNRECOGNIZED_RULE_ERROR */
static EIF_TYPE_INDEX ptf2105[] = {2078,0xFFFF};
static struct eif_par_types par2105 = {2105, ptf2105, (uint16) 1, (uint16) 0, (char) 0};

/* LX_FULL_AND_META_ERROR */
static EIF_TYPE_INDEX ptf2106[] = {2078,0xFFFF};
static struct eif_par_types par2106 = {2106, ptf2106, (uint16) 1, (uint16) 0, (char) 0};

/* LX_NEGATIVE_RANGE_IN_CHARACTER_CLASS_ERROR */
static EIF_TYPE_INDEX ptf2107[] = {2078,0xFFFF};
static struct eif_par_types par2107 = {2107, ptf2107, (uint16) 1, (uint16) 0, (char) 0};

/* LX_MULTIPLE_EOF_RULES_ERROR */
static EIF_TYPE_INDEX ptf2108[] = {2078,0xFFFF};
static struct eif_par_types par2108 = {2108, ptf2108, (uint16) 1, (uint16) 0, (char) 0};

/* LX_ITERATION_NOT_POSITIVE_ERROR */
static EIF_TYPE_INDEX ptf2109[] = {2078,0xFFFF};
static struct eif_par_types par2109 = {2109, ptf2109, (uint16) 1, (uint16) 0, (char) 0};

/* AP_ERROR */
static EIF_TYPE_INDEX ptf2110[] = {2078,0xFFFF};
static struct eif_par_types par2110 = {2110, ptf2110, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ECF_ERROR */
static EIF_TYPE_INDEX ptf2111[] = {2078,0xFFFF};
static struct eif_par_types par2111 = {2111, ptf2111, (uint16) 1, (uint16) 0, (char) 0};

/* UT_VERSION_NUMBER */
static EIF_TYPE_INDEX ptf2112[] = {2078,0xFFFF};
static struct eif_par_types par2112 = {2112, ptf2112, (uint16) 1, (uint16) 0, (char) 0};

/* UT_CANNOT_READ_FILE_ERROR */
static EIF_TYPE_INDEX ptf2113[] = {2078,0xFFFF};
static struct eif_par_types par2113 = {2113, ptf2113, (uint16) 1, (uint16) 0, (char) 0};

/* UT_MESSAGE */
static EIF_TYPE_INDEX ptf2114[] = {2078,0xFFFF};
static struct eif_par_types par2114 = {2114, ptf2114, (uint16) 1, (uint16) 0, (char) 0};

/* ET_ERROR */
static EIF_TYPE_INDEX ptf2115[] = {2078,0xFFFF};
static struct eif_par_types par2115 = {2115, ptf2115, (uint16) 1, (uint16) 0, (char) 0};

/* ET_SYSTEM_ERROR */
static EIF_TYPE_INDEX ptf2116[] = {2115,0xFFFF};
static struct eif_par_types par2116 = {2116, ptf2116, (uint16) 1, (uint16) 0, (char) 0};

/* ET_DOTNET_ASSEMBLY_ERROR */
static EIF_TYPE_INDEX ptf2117[] = {2115,0xFFFF};
static struct eif_par_types par2117 = {2117, ptf2117, (uint16) 1, (uint16) 0, (char) 0};

/* ET_UNIVERSE_ERROR */
static EIF_TYPE_INDEX ptf2118[] = {2115,0xFFFF};
static struct eif_par_types par2118 = {2118, ptf2118, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLUSTER_ERROR */
static EIF_TYPE_INDEX ptf2119[] = {2115,0xFFFF};
static struct eif_par_types par2119 = {2119, ptf2119, (uint16) 1, (uint16) 0, (char) 0};

/* ET_INTERNAL_ERROR */
static EIF_TYPE_INDEX ptf2120[] = {2115,0xFFFF};
static struct eif_par_types par2120 = {2120, ptf2120, (uint16) 1, (uint16) 0, (char) 0};

/* ET_EIFFEL_ERROR */
static EIF_TYPE_INDEX ptf2121[] = {2115,0xFFFF};
static struct eif_par_types par2121 = {2121, ptf2121, (uint16) 1, (uint16) 0, (char) 0};

/* ET_VALIDITY_ERROR */
static EIF_TYPE_INDEX ptf2122[] = {2121,0xFFF7,1007,0xFFFF};
static struct eif_par_types par2122 = {2122, ptf2122, (uint16) 2, (uint16) 0, (char) 0};

/* ET_SYNTAX_ERROR */
static EIF_TYPE_INDEX ptf2123[] = {2121,0xFFFF};
static struct eif_par_types par2123 = {2123, ptf2123, (uint16) 1, (uint16) 0, (char) 0};

/* ET_CLUSTER_DEPENDENCE_CONSTRAINT */
static EIF_TYPE_INDEX ptf2124[] = {0,0xFFF7,1580,0xFFF7,416,0xFFF7,471,0xFFF7,986,0xFFF7,1211,0xFFFF};
static struct eif_par_types par2124 = {2124, ptf2124, (uint16) 6, (uint16) 0, (char) 0};

/* KI_PATHNAME */
static EIF_TYPE_INDEX ptf2125[] = {0,0xFFF7,1417,0xFFF7,1211,0xFFF7,1191,0xFFF7,984,0xFFF7,986,0xFFF7,387,0xFFFF};
static struct eif_par_types par2125 = {2125, ptf2125, (uint16) 7, (uint16) 0, (char) 0};

/* KL_PATHNAME */
static EIF_TYPE_INDEX ptf2126[] = {2125,0xFFF7,984,0xFFFF};
static struct eif_par_types par2126 = {2126, ptf2126, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_PARSER_SKELETON */
static EIF_TYPE_INDEX ptf2127[] = {0,0xFFF7,203,0xFFF7,2047,0xFFF7,2046,0xFFF7,2051,0xFFF7,470,0xFFF7,1211,0xFFF7,986,0xFFF7,471,0xFFF7,416,0xFFF7,1580,0xFFF7,392,0xFFFF};
static struct eif_par_types par2127 = {2127, ptf2127, (uint16) 12, (uint16) 0, (char) 0};

/* ET_ECF_PARSER */
static EIF_TYPE_INDEX ptf2128[] = {2127,0xFFF7,986,0xFFFF};
static struct eif_par_types par2128 = {2128, ptf2128, (uint16) 2, (uint16) 0, (char) 0};

/* ET_ECF_SYSTEM_PARSER */
static EIF_TYPE_INDEX ptf2129[] = {2128,0xFFFF};
static struct eif_par_types par2129 = {2129, ptf2129, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_COMPILER */
static EIF_TYPE_INDEX ptf2130[] = {0,0xFFF7,115,0xFFF7,114,0xFFF7,1282,0xFFF7,113,0xFFF7,112,0xFFF7,1211,0xFFF7,194,0xFFF7,1006,0xFFF7,364,0xFFF7,452,0xFFF7,95,0xFFFF};
static struct eif_par_types par2130 = {2130, ptf2130, (uint16) 12, (uint16) 0, (char) 0};

/* RX_PCRE_MATCHER */
static EIF_TYPE_INDEX ptf2131[] = {2021,0xFFF7,2130,0xFFF7,451,0xFFFF};
static struct eif_par_types par2131 = {2131, ptf2131, (uint16) 3, (uint16) 0, (char) 0};

/* RX_PCRE_REGULAR_EXPRESSION */
static EIF_TYPE_INDEX ptf2132[] = {2022,0xFFF7,2131,0xFFFF};
static struct eif_par_types par2132 = {2132, ptf2132, (uint16) 2, (uint16) 0, (char) 0};

/* UC_STRING */
static EIF_TYPE_INDEX ptf2133[] = {0,0xFFF7,1190,0xFFF7,261,0xFFF7,1239,0xFFF7,98,0xFFF7,450,0xFFF7,415,0xFFF7,373,0xFFF7,193,0xFFF7,1006,0xFFF7,1191,0xFFF7,95,0xFFF7,900,0xFFFF};
static struct eif_par_types par2133 = {2133, ptf2133, (uint16) 13, (uint16) 0, (char) 0};

/* UC_UTF8_STRING */
static EIF_TYPE_INDEX ptf2134[] = {2133,0xFFFF};
static struct eif_par_types par2134 = {2134, ptf2134, (uint16) 1, (uint16) 0, (char) 0};

int egc_partab_size_init = 2134				;
				struct eif_par_types *egc_partab_init[] = {
&par0,
&par1,
&par2,
&par3,
&par4,
&par5,
&par6,
&par7,
&par8,
&par9,
&par10,
&par11,
&par12,
&par13,
&par14,
&par15,
&par16,
&par17,
&par18,
&par19,
&par20,
&par21,
&par22,
&par23,
&par24,
&par25,
&par26,
&par27,
&par28,
&par29,
&par30,
&par31,
&par32,
&par33,
&par34,
&par35,
&par36,
&par37,
&par38,
&par39,
&par40,
&par41,
&par42,
&par43,
&par44,
&par45,
&par46,
&par47,
&par48,
&par49,
&par50,
&par51,
&par52,
&par53,
&par54,
&par55,
&par56,
&par57,
&par58,
&par59,
&par60,
&par61,
&par62,
&par63,
&par64,
&par65,
&par66,
&par67,
&par68,
&par69,
&par70,
&par71,
&par72,
&par73,
&par74,
&par75,
&par76,
&par77,
&par78,
&par79,
&par80,
&par81,
&par82,
&par83,
&par84,
&par85,
&par86,
&par87,
&par88,
&par89,
&par90,
&par91,
&par92,
&par93,
&par94,
&par95,
&par96,
&par97,
&par98,
&par99,
&par100,
&par101,
&par102,
&par103,
&par104,
&par105,
&par106,
&par107,
&par108,
&par109,
&par110,
&par111,
&par112,
&par113,
&par114,
&par115,
&par116,
&par117,
&par118,
&par119,
&par120,
&par121,
&par122,
&par123,
&par124,
&par125,
&par126,
&par127,
&par128,
&par129,
&par130,
&par131,
&par132,
&par133,
&par134,
&par135,
&par136,
&par137,
&par138,
&par139,
&par140,
&par141,
&par142,
&par143,
&par144,
&par145,
&par146,
&par147,
&par148,
&par149,
&par150,
&par151,
&par152,
&par153,
&par154,
&par155,
&par156,
&par157,
&par158,
&par159,
&par160,
&par161,
&par162,
&par163,
&par164,
&par165,
&par166,
&par167,
&par168,
&par169,
&par170,
&par171,
&par172,
&par173,
&par174,
&par175,
&par176,
&par177,
&par178,
&par179,
&par180,
&par181,
&par182,
&par183,
&par184,
&par185,
&par186,
&par187,
&par188,
&par189,
&par190,
&par191,
&par192,
&par193,
&par194,
&par195,
&par196,
&par197,
&par198,
&par199,
&par200,
&par201,
&par202,
&par203,
&par204,
&par205,
&par206,
&par207,
&par208,
&par209,
&par210,
&par211,
&par212,
&par213,
&par214,
&par215,
&par216,
&par217,
&par218,
&par219,
&par220,
&par221,
&par222,
&par223,
&par224,
&par225,
&par226,
&par227,
&par228,
&par229,
&par230,
&par231,
&par232,
&par233,
&par234,
&par235,
&par236,
&par237,
&par238,
&par239,
&par240,
&par241,
&par242,
&par243,
&par244,
&par245,
&par246,
&par247,
&par248,
&par249,
&par250,
&par251,
&par252,
&par253,
&par254,
&par255,
&par256,
&par257,
&par258,
&par259,
&par260,
&par261,
&par262,
&par263,
&par264,
&par265,
&par266,
&par267,
&par268,
&par269,
&par270,
&par271,
&par272,
&par273,
&par274,
&par275,
&par276,
&par277,
&par278,
&par279,
&par280,
&par281,
&par282,
&par283,
&par284,
&par285,
&par286,
&par287,
&par288,
&par289,
&par290,
&par291,
&par292,
&par293,
&par294,
&par295,
&par296,
&par297,
&par298,
&par299,
&par300,
&par301,
&par302,
&par303,
&par304,
&par305,
&par306,
&par307,
&par308,
&par309,
&par310,
&par311,
&par312,
&par313,
&par314,
&par315,
&par316,
&par317,
&par318,
&par319,
&par320,
&par321,
&par322,
&par323,
&par324,
&par325,
&par326,
&par327,
&par328,
&par329,
&par330,
&par331,
&par332,
&par333,
&par334,
&par335,
&par336,
&par337,
&par338,
&par339,
&par340,
&par341,
&par342,
&par343,
&par344,
&par345,
&par346,
&par347,
&par348,
&par349,
&par350,
&par351,
&par352,
&par353,
&par354,
&par355,
&par356,
&par357,
&par358,
&par359,
&par360,
&par361,
&par362,
&par363,
&par364,
&par365,
&par366,
&par367,
&par368,
&par369,
&par370,
&par371,
&par372,
&par373,
&par374,
&par375,
&par376,
&par377,
&par378,
&par379,
&par380,
&par381,
&par382,
&par383,
&par384,
&par385,
&par386,
&par387,
&par388,
&par389,
&par390,
&par391,
&par392,
&par393,
&par394,
&par395,
&par396,
&par397,
&par398,
&par399,
&par400,
&par401,
&par402,
&par403,
&par404,
&par405,
&par406,
&par407,
&par408,
&par409,
&par410,
&par411,
&par412,
&par413,
&par414,
&par415,
&par416,
&par417,
&par418,
&par419,
&par420,
&par421,
&par422,
&par423,
&par424,
&par425,
&par426,
&par427,
&par428,
&par429,
&par430,
&par431,
&par432,
&par433,
&par434,
&par435,
&par436,
&par437,
&par438,
&par439,
&par440,
&par441,
&par442,
&par443,
&par444,
&par445,
&par446,
&par447,
&par448,
&par449,
&par450,
&par451,
&par452,
&par453,
&par454,
&par455,
&par456,
&par457,
&par458,
&par459,
&par460,
&par461,
&par462,
&par463,
&par464,
&par465,
&par466,
&par467,
&par468,
&par469,
&par470,
&par471,
&par472,
&par473,
&par474,
&par475,
&par476,
&par477,
&par478,
&par479,
&par480,
&par481,
&par482,
&par483,
&par484,
&par485,
&par486,
&par487,
&par488,
&par489,
&par490,
&par491,
&par492,
&par493,
&par494,
&par495,
&par496,
&par497,
&par498,
&par499,
&par500,
&par501,
&par502,
&par503,
&par504,
&par505,
&par506,
&par507,
&par508,
&par509,
&par510,
&par511,
&par512,
&par513,
&par514,
&par515,
&par516,
&par517,
&par518,
&par519,
&par520,
&par521,
&par522,
&par523,
&par524,
&par525,
&par526,
&par527,
&par528,
&par529,
&par530,
&par531,
&par532,
&par533,
&par534,
&par535,
&par536,
&par537,
&par538,
&par539,
&par540,
&par541,
&par542,
&par543,
&par544,
&par545,
&par546,
&par547,
&par548,
&par549,
&par550,
&par551,
&par552,
&par553,
&par554,
&par555,
&par556,
&par557,
&par558,
&par559,
&par560,
&par561,
&par562,
&par563,
&par564,
&par565,
&par566,
&par567,
&par568,
&par569,
&par570,
&par571,
&par572,
&par573,
&par574,
&par575,
&par576,
&par577,
&par578,
&par579,
&par580,
&par581,
&par582,
&par583,
&par584,
&par585,
&par586,
&par587,
&par588,
&par589,
&par590,
&par591,
&par592,
&par593,
&par594,
&par595,
&par596,
&par597,
&par598,
&par599,
&par600,
&par601,
&par602,
&par603,
&par604,
&par605,
&par606,
&par607,
&par608,
&par609,
&par610,
&par611,
&par612,
&par613,
&par614,
&par615,
&par616,
&par617,
&par618,
&par619,
&par620,
&par621,
&par622,
&par623,
&par624,
&par625,
&par626,
&par627,
&par628,
&par629,
&par630,
&par631,
&par632,
&par633,
&par634,
&par635,
&par636,
&par637,
&par638,
&par639,
&par640,
&par641,
&par642,
&par643,
&par644,
&par645,
&par646,
&par647,
&par648,
&par649,
&par650,
&par651,
&par652,
&par653,
&par654,
&par655,
&par656,
&par657,
&par658,
&par659,
&par660,
&par661,
&par662,
&par663,
&par664,
&par665,
&par666,
&par667,
&par668,
&par669,
&par670,
&par671,
&par672,
&par673,
&par674,
&par675,
&par676,
&par677,
&par678,
&par679,
&par680,
&par681,
&par682,
&par683,
&par684,
&par685,
&par686,
&par687,
&par688,
&par689,
&par690,
&par691,
&par692,
&par693,
&par694,
&par695,
&par696,
&par697,
&par698,
&par699,
&par700,
&par701,
&par702,
&par703,
&par704,
&par705,
&par706,
&par707,
&par708,
&par709,
&par710,
&par711,
&par712,
&par713,
&par714,
&par715,
&par716,
&par717,
&par718,
&par719,
&par720,
&par721,
&par722,
&par723,
&par724,
&par725,
&par726,
&par727,
&par728,
&par729,
&par730,
&par731,
&par732,
&par733,
&par734,
&par735,
&par736,
&par737,
&par738,
&par739,
&par740,
&par741,
&par742,
&par743,
&par744,
&par745,
&par746,
&par747,
&par748,
&par749,
&par750,
&par751,
&par752,
&par753,
&par754,
&par755,
&par756,
&par757,
&par758,
&par759,
&par760,
&par761,
&par762,
&par763,
&par764,
&par765,
&par766,
&par767,
&par768,
&par769,
&par770,
&par771,
&par772,
&par773,
&par774,
&par775,
&par776,
&par777,
&par778,
&par779,
&par780,
&par781,
&par782,
&par783,
&par784,
&par785,
&par786,
&par787,
&par788,
&par789,
&par790,
&par791,
&par792,
&par793,
&par794,
&par795,
&par796,
&par797,
&par798,
&par799,
&par800,
&par801,
&par802,
&par803,
&par804,
&par805,
&par806,
&par807,
&par808,
&par809,
&par810,
&par811,
&par812,
&par813,
&par814,
&par815,
&par816,
&par817,
&par818,
&par819,
&par820,
&par821,
&par822,
&par823,
&par824,
&par825,
&par826,
&par827,
&par828,
&par829,
&par830,
&par831,
&par832,
&par833,
&par834,
&par835,
&par836,
&par837,
&par838,
&par839,
&par840,
&par841,
&par842,
&par843,
&par844,
&par845,
&par846,
&par847,
&par848,
&par849,
&par850,
&par851,
&par852,
&par853,
&par854,
&par855,
&par856,
&par857,
&par858,
&par859,
&par860,
&par861,
&par862,
&par863,
&par864,
&par865,
&par866,
&par867,
&par868,
&par869,
&par870,
&par871,
&par872,
&par873,
&par874,
&par875,
&par876,
&par877,
&par878,
&par879,
&par880,
&par881,
&par882,
&par883,
&par884,
&par885,
&par886,
&par887,
&par888,
&par889,
&par890,
&par891,
&par892,
&par893,
&par894,
&par895,
&par896,
&par897,
&par898,
&par899,
&par900,
&par901,
&par902,
&par903,
&par904,
&par905,
&par906,
&par907,
&par908,
&par909,
&par910,
&par911,
&par912,
&par913,
&par914,
&par915,
&par916,
&par917,
&par918,
&par919,
&par920,
&par921,
&par922,
&par923,
&par924,
&par925,
&par926,
&par927,
&par928,
&par929,
&par930,
&par931,
&par932,
&par933,
&par934,
&par935,
&par936,
&par937,
&par938,
&par939,
&par940,
&par941,
&par942,
&par943,
&par944,
&par945,
&par946,
&par947,
&par948,
&par949,
&par950,
&par951,
&par952,
&par953,
&par954,
&par955,
&par956,
&par957,
&par958,
&par959,
&par960,
&par961,
&par962,
&par963,
&par964,
&par965,
&par966,
&par967,
&par968,
&par969,
&par970,
&par971,
&par972,
&par973,
&par974,
&par975,
&par976,
&par977,
&par978,
&par979,
&par980,
&par981,
&par982,
&par983,
&par984,
&par985,
&par986,
&par987,
&par988,
&par989,
&par990,
&par991,
&par992,
&par993,
&par994,
&par995,
&par996,
&par997,
&par998,
&par999,
&par1000,
&par1001,
&par1002,
&par1003,
&par1004,
&par1005,
&par1006,
&par1007,
&par1008,
&par1009,
&par1010,
&par1011,
&par1012,
&par1013,
&par1014,
&par1015,
&par1016,
&par1017,
&par1018,
&par1019,
&par1020,
&par1021,
&par1022,
&par1023,
&par1024,
&par1025,
&par1026,
&par1027,
&par1028,
&par1029,
&par1030,
&par1031,
&par1032,
&par1033,
&par1034,
&par1035,
&par1036,
&par1037,
&par1038,
&par1039,
&par1040,
&par1041,
&par1042,
&par1043,
&par1044,
&par1045,
&par1046,
&par1047,
&par1048,
&par1049,
&par1050,
&par1051,
&par1052,
&par1053,
&par1054,
&par1055,
&par1056,
&par1057,
&par1058,
&par1059,
&par1060,
&par1061,
&par1062,
&par1063,
&par1064,
&par1065,
&par1066,
&par1067,
&par1068,
&par1069,
&par1070,
&par1071,
&par1072,
&par1073,
&par1074,
&par1075,
&par1076,
&par1077,
&par1078,
&par1079,
&par1080,
&par1081,
&par1082,
&par1083,
&par1084,
&par1085,
&par1086,
&par1087,
&par1088,
&par1089,
&par1090,
&par1091,
&par1092,
&par1093,
&par1094,
&par1095,
&par1096,
&par1097,
&par1098,
&par1099,
&par1100,
&par1101,
&par1102,
&par1103,
&par1104,
&par1105,
&par1106,
&par1107,
&par1108,
&par1109,
&par1110,
&par1111,
&par1112,
&par1113,
&par1114,
&par1115,
&par1116,
&par1117,
&par1118,
&par1119,
&par1120,
&par1121,
&par1122,
&par1123,
&par1124,
&par1125,
&par1126,
&par1127,
&par1128,
&par1129,
&par1130,
&par1131,
&par1132,
&par1133,
&par1134,
&par1135,
&par1136,
&par1137,
&par1138,
&par1139,
&par1140,
&par1141,
&par1142,
&par1143,
&par1144,
&par1145,
&par1146,
&par1147,
&par1148,
&par1149,
&par1150,
&par1151,
&par1152,
&par1153,
&par1154,
&par1155,
&par1156,
&par1157,
&par1158,
&par1159,
&par1160,
&par1161,
&par1162,
&par1163,
&par1164,
&par1165,
&par1166,
&par1167,
&par1168,
&par1169,
&par1170,
&par1171,
&par1172,
&par1173,
&par1174,
&par1175,
&par1176,
&par1177,
&par1178,
&par1179,
&par1180,
&par1181,
&par1182,
&par1183,
&par1184,
&par1185,
&par1186,
&par1187,
&par1188,
&par1189,
&par1190,
&par1191,
&par1192,
&par1193,
&par1194,
&par1195,
&par1196,
&par1197,
&par1198,
&par1199,
&par1200,
&par1201,
&par1202,
&par1203,
&par1204,
&par1205,
&par1206,
&par1207,
&par1208,
&par1209,
&par1210,
&par1211,
&par1212,
&par1213,
&par1214,
&par1215,
&par1216,
&par1217,
&par1218,
&par1219,
&par1220,
&par1221,
&par1222,
&par1223,
&par1224,
&par1225,
&par1226,
&par1227,
&par1228,
&par1229,
&par1230,
&par1231,
&par1232,
&par1233,
&par1234,
&par1235,
&par1236,
&par1237,
&par1238,
&par1239,
&par1240,
&par1241,
&par1242,
&par1243,
&par1244,
&par1245,
&par1246,
&par1247,
&par1248,
&par1249,
&par1250,
&par1251,
&par1252,
&par1253,
&par1254,
&par1255,
&par1256,
&par1257,
&par1258,
&par1259,
&par1260,
&par1261,
&par1262,
&par1263,
&par1264,
&par1265,
&par1266,
&par1267,
&par1268,
&par1269,
&par1270,
&par1271,
&par1272,
&par1273,
&par1274,
&par1275,
&par1276,
&par1277,
&par1278,
&par1279,
&par1280,
&par1281,
&par1282,
&par1283,
&par1284,
&par1285,
&par1286,
&par1287,
&par1288,
&par1289,
&par1290,
&par1291,
&par1292,
&par1293,
&par1294,
&par1295,
&par1296,
&par1297,
&par1298,
&par1299,
&par1300,
&par1301,
&par1302,
&par1303,
&par1304,
&par1305,
&par1306,
&par1307,
&par1308,
&par1309,
&par1310,
&par1311,
&par1312,
&par1313,
&par1314,
&par1315,
&par1316,
&par1317,
&par1318,
&par1319,
&par1320,
&par1321,
&par1322,
&par1323,
&par1324,
&par1325,
&par1326,
&par1327,
&par1328,
&par1329,
&par1330,
&par1331,
&par1332,
&par1333,
&par1334,
&par1335,
&par1336,
&par1337,
&par1338,
&par1339,
&par1340,
&par1341,
&par1342,
&par1343,
&par1344,
&par1345,
&par1346,
&par1347,
&par1348,
&par1349,
&par1350,
&par1351,
&par1352,
&par1353,
&par1354,
&par1355,
&par1356,
&par1357,
&par1358,
&par1359,
&par1360,
&par1361,
&par1362,
&par1363,
&par1364,
&par1365,
&par1366,
&par1367,
&par1368,
&par1369,
&par1370,
&par1371,
&par1372,
&par1373,
&par1374,
&par1375,
&par1376,
&par1377,
&par1378,
&par1379,
&par1380,
&par1381,
&par1382,
&par1383,
&par1384,
&par1385,
&par1386,
&par1387,
&par1388,
&par1389,
&par1390,
&par1391,
&par1392,
&par1393,
&par1394,
&par1395,
&par1396,
&par1397,
&par1398,
&par1399,
&par1400,
&par1401,
&par1402,
&par1403,
&par1404,
&par1405,
&par1406,
&par1407,
&par1408,
&par1409,
&par1410,
&par1411,
&par1412,
&par1413,
&par1414,
&par1415,
&par1416,
&par1417,
&par1418,
&par1419,
&par1420,
&par1421,
&par1422,
&par1423,
&par1424,
&par1425,
&par1426,
&par1427,
&par1428,
&par1429,
&par1430,
&par1431,
&par1432,
&par1433,
&par1434,
&par1435,
&par1436,
&par1437,
&par1438,
&par1439,
&par1440,
&par1441,
&par1442,
&par1443,
&par1444,
&par1445,
&par1446,
&par1447,
&par1448,
&par1449,
&par1450,
&par1451,
&par1452,
&par1453,
&par1454,
&par1455,
&par1456,
&par1457,
&par1458,
&par1459,
&par1460,
&par1461,
&par1462,
&par1463,
&par1464,
&par1465,
&par1466,
&par1467,
&par1468,
&par1469,
&par1470,
&par1471,
&par1472,
&par1473,
&par1474,
&par1475,
&par1476,
&par1477,
&par1478,
&par1479,
&par1480,
&par1481,
&par1482,
&par1483,
&par1484,
&par1485,
&par1486,
&par1487,
&par1488,
&par1489,
&par1490,
&par1491,
&par1492,
&par1493,
&par1494,
&par1495,
&par1496,
&par1497,
&par1498,
&par1499,
&par1500,
&par1501,
&par1502,
&par1503,
&par1504,
&par1505,
&par1506,
&par1507,
&par1508,
&par1509,
&par1510,
&par1511,
&par1512,
&par1513,
&par1514,
&par1515,
&par1516,
&par1517,
&par1518,
&par1519,
&par1520,
&par1521,
&par1522,
&par1523,
&par1524,
&par1525,
&par1526,
&par1527,
&par1528,
&par1529,
&par1530,
&par1531,
&par1532,
&par1533,
&par1534,
&par1535,
&par1536,
&par1537,
&par1538,
&par1539,
&par1540,
&par1541,
&par1542,
&par1543,
&par1544,
&par1545,
&par1546,
&par1547,
&par1548,
&par1549,
&par1550,
&par1551,
&par1552,
&par1553,
&par1554,
&par1555,
&par1556,
&par1557,
&par1558,
&par1559,
&par1560,
&par1561,
&par1562,
&par1563,
&par1564,
&par1565,
&par1566,
&par1567,
&par1568,
&par1569,
&par1570,
&par1571,
&par1572,
&par1573,
&par1574,
&par1575,
&par1576,
&par1577,
&par1578,
&par1579,
&par1580,
&par1581,
&par1582,
&par1583,
&par1584,
&par1585,
&par1586,
&par1587,
&par1588,
&par1589,
&par1590,
&par1591,
&par1592,
&par1593,
&par1594,
&par1595,
&par1596,
&par1597,
&par1598,
&par1599,
&par1600,
&par1601,
&par1602,
&par1603,
&par1604,
&par1605,
&par1606,
&par1607,
&par1608,
&par1609,
&par1610,
&par1611,
&par1612,
&par1613,
&par1614,
&par1615,
&par1616,
&par1617,
&par1618,
&par1619,
&par1620,
&par1621,
&par1622,
&par1623,
&par1624,
&par1625,
&par1626,
&par1627,
&par1628,
&par1629,
&par1630,
&par1631,
&par1632,
&par1633,
&par1634,
&par1635,
&par1636,
&par1637,
&par1638,
&par1639,
&par1640,
&par1641,
&par1642,
&par1643,
&par1644,
&par1645,
&par1646,
&par1647,
&par1648,
&par1649,
&par1650,
&par1651,
&par1652,
&par1653,
&par1654,
&par1655,
&par1656,
&par1657,
&par1658,
&par1659,
&par1660,
&par1661,
&par1662,
&par1663,
&par1664,
&par1665,
&par1666,
&par1667,
&par1668,
&par1669,
&par1670,
&par1671,
&par1672,
&par1673,
&par1674,
&par1675,
&par1676,
&par1677,
&par1678,
&par1679,
&par1680,
&par1681,
&par1682,
&par1683,
&par1684,
&par1685,
&par1686,
&par1687,
&par1688,
&par1689,
&par1690,
&par1691,
&par1692,
&par1693,
&par1694,
&par1695,
&par1696,
&par1697,
&par1698,
&par1699,
&par1700,
&par1701,
&par1702,
&par1703,
&par1704,
&par1705,
&par1706,
&par1707,
&par1708,
&par1709,
&par1710,
&par1711,
&par1712,
&par1713,
&par1714,
&par1715,
&par1716,
&par1717,
&par1718,
&par1719,
&par1720,
&par1721,
&par1722,
&par1723,
&par1724,
&par1725,
&par1726,
&par1727,
&par1728,
&par1729,
&par1730,
&par1731,
&par1732,
&par1733,
&par1734,
&par1735,
&par1736,
&par1737,
&par1738,
&par1739,
&par1740,
&par1741,
&par1742,
&par1743,
&par1744,
&par1745,
&par1746,
&par1747,
&par1748,
&par1749,
&par1750,
&par1751,
&par1752,
&par1753,
&par1754,
&par1755,
&par1756,
&par1757,
&par1758,
&par1759,
&par1760,
&par1761,
&par1762,
&par1763,
&par1764,
&par1765,
&par1766,
&par1767,
&par1768,
&par1769,
&par1770,
&par1771,
&par1772,
&par1773,
&par1774,
&par1775,
&par1776,
&par1777,
&par1778,
&par1779,
&par1780,
&par1781,
&par1782,
&par1783,
&par1784,
&par1785,
&par1786,
&par1787,
&par1788,
&par1789,
&par1790,
&par1791,
&par1792,
&par1793,
&par1794,
&par1795,
&par1796,
&par1797,
&par1798,
&par1799,
&par1800,
&par1801,
&par1802,
&par1803,
&par1804,
&par1805,
&par1806,
&par1807,
&par1808,
&par1809,
&par1810,
&par1811,
&par1812,
&par1813,
&par1814,
&par1815,
&par1816,
&par1817,
&par1818,
&par1819,
&par1820,
&par1821,
&par1822,
&par1823,
&par1824,
&par1825,
&par1826,
&par1827,
&par1828,
&par1829,
&par1830,
&par1831,
&par1832,
&par1833,
&par1834,
&par1835,
&par1836,
&par1837,
&par1838,
&par1839,
&par1840,
&par1841,
&par1842,
&par1843,
&par1844,
&par1845,
&par1846,
&par1847,
&par1848,
&par1849,
&par1850,
&par1851,
&par1852,
&par1853,
&par1854,
&par1855,
&par1856,
&par1857,
&par1858,
&par1859,
&par1860,
&par1861,
&par1862,
&par1863,
&par1864,
&par1865,
&par1866,
&par1867,
&par1868,
&par1869,
&par1870,
&par1871,
&par1872,
&par1873,
&par1874,
&par1875,
&par1876,
&par1877,
&par1878,
&par1879,
&par1880,
&par1881,
&par1882,
&par1883,
&par1884,
&par1885,
&par1886,
&par1887,
&par1888,
&par1889,
&par1890,
&par1891,
&par1892,
&par1893,
&par1894,
&par1895,
&par1896,
&par1897,
&par1898,
&par1899,
&par1900,
&par1901,
&par1902,
&par1903,
&par1904,
&par1905,
&par1906,
&par1907,
&par1908,
&par1909,
&par1910,
&par1911,
&par1912,
&par1913,
&par1914,
&par1915,
&par1916,
&par1917,
&par1918,
&par1919,
&par1920,
&par1921,
&par1922,
&par1923,
&par1924,
&par1925,
&par1926,
&par1927,
&par1928,
&par1929,
&par1930,
&par1931,
&par1932,
&par1933,
&par1934,
&par1935,
&par1936,
&par1937,
&par1938,
&par1939,
&par1940,
&par1941,
&par1942,
&par1943,
&par1944,
&par1945,
&par1946,
&par1947,
&par1948,
&par1949,
&par1950,
&par1951,
&par1952,
&par1953,
&par1954,
&par1955,
&par1956,
&par1957,
&par1958,
&par1959,
&par1960,
&par1961,
&par1962,
&par1963,
&par1964,
&par1965,
&par1966,
&par1967,
&par1968,
&par1969,
&par1970,
&par1971,
&par1972,
&par1973,
&par1974,
&par1975,
&par1976,
&par1977,
&par1978,
&par1979,
&par1980,
&par1981,
&par1982,
&par1983,
&par1984,
&par1985,
&par1986,
&par1987,
&par1988,
&par1989,
&par1990,
&par1991,
&par1992,
&par1993,
&par1994,
&par1995,
&par1996,
&par1997,
&par1998,
&par1999,
&par2000,
&par2001,
&par2002,
&par2003,
&par2004,
&par2005,
&par2006,
&par2007,
&par2008,
&par2009,
&par2010,
&par2011,
&par2012,
&par2013,
&par2014,
&par2015,
&par2016,
&par2017,
&par2018,
&par2019,
&par2020,
&par2021,
&par2022,
&par2023,
&par2024,
&par2025,
&par2026,
&par2027,
&par2028,
&par2029,
&par2030,
&par2031,
&par2032,
&par2033,
&par2034,
&par2035,
&par2036,
&par2037,
&par2038,
&par2039,
&par2040,
&par2041,
&par2042,
&par2043,
&par2044,
&par2045,
&par2046,
&par2047,
&par2048,
&par2049,
&par2050,
&par2051,
&par2052,
&par2053,
&par2054,
&par2055,
&par2056,
&par2057,
&par2058,
&par2059,
&par2060,
&par2061,
&par2062,
&par2063,
&par2064,
&par2065,
&par2066,
&par2067,
&par2068,
&par2069,
&par2070,
&par2071,
&par2072,
&par2073,
&par2074,
&par2075,
&par2076,
&par2077,
&par2078,
&par2079,
&par2080,
&par2081,
&par2082,
&par2083,
&par2084,
&par2085,
&par2086,
&par2087,
&par2088,
&par2089,
&par2090,
&par2091,
&par2092,
&par2093,
&par2094,
&par2095,
&par2096,
&par2097,
&par2098,
&par2099,
&par2100,
&par2101,
&par2102,
&par2103,
&par2104,
&par2105,
&par2106,
&par2107,
&par2108,
&par2109,
&par2110,
&par2111,
&par2112,
&par2113,
&par2114,
&par2115,
&par2116,
&par2117,
&par2118,
&par2119,
&par2120,
&par2121,
&par2122,
&par2123,
&par2124,
&par2125,
&par2126,
&par2127,
&par2128,
&par2129,
&par2130,
&par2131,
&par2132,
&par2133,
&par2134,
NULL};

#ifdef __cplusplus
}
#endif
