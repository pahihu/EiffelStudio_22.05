/*
 * Code for class ET_FEATURE_CALL_EXPRESSION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et845.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_FEATURE_CALL_EXPRESSION}.parenthesis_call */
EIF_REFERENCE F1784_16165 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit845 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
