
#ifndef _C17_et809_
#define _C17_et809_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1748_16036(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit809(void);
extern EIF_INTEGER_32 F1291_12720(EIF_REFERENCE);
extern void F1745_16018(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F377_4575(EIF_REFERENCE);
extern EIF_INTEGER_32 F1291_12721(EIF_REFERENCE);
extern void F1917_17654(EIF_REFERENCE);
extern void F1291_12722(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F1008_7607(EIF_REFERENCE);
extern char *(*R11795[])();
extern long O12230[];
extern long O12231[];

#ifdef __cplusplus
}
#endif

#endif
