
#ifndef _C17_et804_
#define _C17_et804_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1743_15990(EIF_REFERENCE);
extern EIF_REFERENCE F1743_15991(EIF_REFERENCE);
extern EIF_REFERENCE F1743_15992(EIF_REFERENCE);
extern void F1743_15998(EIF_REFERENCE, EIF_REFERENCE);
extern void F1743_15999(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit804(void);
extern long O12210[];
extern long O12208[];
extern long O12209[];

#ifdef __cplusplus
}
#endif

#endif
