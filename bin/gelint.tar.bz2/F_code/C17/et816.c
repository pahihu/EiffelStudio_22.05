/*
 * Code for class ET_DO_PROCEDURE_INLINE_AGENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et816.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_DO_PROCEDURE_INLINE_AGENT}.process */
void F1755_16043 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2343[Dtype(RTCW(arg1))-254])(arg1, Current);
}

void EIF_Minit816 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
