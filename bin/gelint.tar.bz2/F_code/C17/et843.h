
#ifndef _C17_et843_
#define _C17_et843_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1782_16162(EIF_REFERENCE);
extern void EIF_Minit843(void);

#ifdef __cplusplus
}
#endif

#endif
