/*
 * Code for class ET_UNQUALIFIED_FEATURE_CALL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et844.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_UNQUALIFIED_FEATURE_CALL}.target */
EIF_REFERENCE F1783_16163 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit844 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
