
#ifndef _C17_et828_
#define _C17_et828_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1767_16078(EIF_REFERENCE, EIF_REFERENCE);
extern void F1767_16079(EIF_REFERENCE);
extern EIF_REFERENCE F1767_16081(EIF_REFERENCE);
extern void F1767_16082(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit828(void);
extern EIF_REFERENCE F377_4533(EIF_REFERENCE);
extern EIF_REFERENCE F1908_17482(EIF_REFERENCE);
extern EIF_REFERENCE F1008_7607(EIF_REFERENCE);
extern char *(*R12381[])();
extern char *(*R2364[])();

#ifdef __cplusplus
}
#endif

#endif
