
#ifndef _C17_et827_
#define _C17_et827_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1766_16073(EIF_REFERENCE);
extern EIF_REFERENCE F1766_16075(EIF_REFERENCE);
extern void F1766_16077(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit827(void);
extern EIF_REFERENCE F377_4604(EIF_REFERENCE);
extern EIF_REFERENCE F377_4533(EIF_REFERENCE);
extern EIF_REFERENCE F1008_7607(EIF_REFERENCE);
extern char *(*R2458[])();

#ifdef __cplusplus
}
#endif

#endif
