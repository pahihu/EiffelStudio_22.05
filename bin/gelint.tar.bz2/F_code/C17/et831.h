
#ifndef _C17_et831_
#define _C17_et831_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1770_16095(EIF_REFERENCE);
extern EIF_REFERENCE F1770_16096(EIF_REFERENCE);
extern void EIF_Minit831(void);

#ifdef __cplusplus
}
#endif

#endif
