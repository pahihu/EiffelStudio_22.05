/*
 * Code for class ET_INLINE_AGENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et806.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_INLINE_AGENT}.make */
void F1745_16018 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(313,F377_4555, (RTCV(RTOUCR(24,F1008_7607, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12208[dtype-1742]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(1718, 0x01).id, 1718, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F1719_15818(RTCW(tr1), Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12209[dtype-1742]) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O12210[dtype-1742]) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {ET_INLINE_AGENT}.reset */
void F1745_16019 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12209[dtype-1742]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R12121[Dtype(RTCW(tr1))-1718])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + O12210[dtype-1742]);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1637, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		F1638_15344(loc1);
	} else {
		*(EIF_REFERENCE *)(Current + O12210[dtype-1742]) = (EIF_REFERENCE) NULL;
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2823[dtype-1750])(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R12570[Dtype(loc2)-1859])(loc2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		F1646_15431(loc3);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		F1901_17404(loc4);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		F1899_17368(loc5);
	}
	RTLE;
}

/* {ET_INLINE_AGENT}.position */
EIF_REFERENCE F1745_16022 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12208[Dtype(Current)-1742]);
	Result = F1908_17479(RTCW(tr1));
	RTLE;
	return Result;
}

/* {ET_INLINE_AGENT}.first_leaf */
EIF_REFERENCE F1745_16023 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + O12208[Dtype(Current)-1742]);
}

/* {ET_INLINE_AGENT}.is_instance_free */
EIF_BOOLEAN F1745_16027 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {ET_INLINE_AGENT}.set_result_index */
void F1745_16028 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O12226[Dtype(Current)-1744]) = (EIF_INTEGER_32) arg1;
}

/* {ET_INLINE_AGENT}.set_attached_result_index */
void F1745_16029 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O12227[Dtype(Current)-1744]) = (EIF_INTEGER_32) arg1;
}

/* {ET_INLINE_AGENT}.implicit_target_position */
EIF_REFERENCE F1745_16030 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1745_16023(Current);
}

/* {ET_INLINE_AGENT}.implicit_argument_position */
EIF_REFERENCE F1745_16031 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1747_16035(Current);
}

void EIF_Minit806 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
