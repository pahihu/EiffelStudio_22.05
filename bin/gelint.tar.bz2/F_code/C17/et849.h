
#ifndef _C17_et849_
#define _C17_et849_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1788_16176(EIF_REFERENCE);
extern void F1788_16177(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit849(void);
extern void F1792_16188(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
