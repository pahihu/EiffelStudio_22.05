
#ifndef _C17_et807_
#define _C17_et807_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1746_16032(EIF_REFERENCE);
extern EIF_REFERENCE F1746_16034(EIF_REFERENCE);
extern void EIF_Minit807(void);
extern char *(*R12101[])();
extern long O12230[];
extern long O12231[];

#ifdef __cplusplus
}
#endif

#endif
