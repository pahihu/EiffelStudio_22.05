
#ifndef _C17_et842_
#define _C17_et842_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1781_16157(EIF_REFERENCE);
extern void F1781_16158(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1781_16159(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit842(void);
extern void F1792_16188(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2439[])();
extern EIF_TYPE_INDEX Y12288[];
extern EIF_TYPE_INDEX *Y12288_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
