/*
 * Code for class ET_INTERNAL_ROUTINE_INLINE_AGENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et814.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_INTERNAL_ROUTINE_INLINE_AGENT}.reset */
void F1753_16042 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	F1745_16019(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1645_15419(loc1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		F1636_15323(loc2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		F1636_15323(loc3);
	}
	RTLE;
}

void EIF_Minit814 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
