
#ifndef _C17_et812_
#define _C17_et812_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1751_16038(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1751_16039(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit812(void);
extern void F1748_16036(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2360[])();

#ifdef __cplusplus
}
#endif

#endif
