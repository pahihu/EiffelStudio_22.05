/*
 * Code for class ET_CONVERT_FROM_EXPRESSION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et836.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_CONVERT_FROM_EXPRESSION}.make */
void F1775_16110 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,loc1);
	RTLR(5,tr1);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg3;
	loc1 = RTLNS(eif_new_type(1980, 0x01).id, 1980, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	F1981_18337(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O13230[Dtype(tr1)-1937]);
	F1938_17910(RTCW(loc1), ti4_1);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11795[Dtype(RTCW(arg3))-1621])(arg3);
	ti4_1 = F1291_12720(RTCW(loc2));
	ti4_2 = F1291_12721(RTCW(loc2));
	F1291_12722(RTCW(loc1), ti4_1, ti4_2);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {ET_CONVERT_FROM_EXPRESSION}.type */
EIF_REFERENCE F1775_16111 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {ET_CONVERT_FROM_EXPRESSION}.creation_call */
EIF_REFERENCE F1775_16112 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {ET_CONVERT_FROM_EXPRESSION}.name */
EIF_REFERENCE F1775_16113 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {ET_CONVERT_FROM_EXPRESSION}.arguments */
EIF_REFERENCE F1775_16114 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
}

/* {ET_CONVERT_FROM_EXPRESSION}.type_position */
EIF_REFERENCE F1775_16115 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11795[Dtype(RTCW(tr1))-1621])(tr1);
	RTLE;
	return Result;
}

/* {ET_CONVERT_FROM_EXPRESSION}.process */
void F1775_16116 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2326[Dtype(RTCW(arg1))-254])(arg1, Current);
}

void EIF_Minit836 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
