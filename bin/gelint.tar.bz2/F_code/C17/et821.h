
#ifndef _C17_et821_
#define _C17_et821_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1760_16046(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit821(void);
extern char *(*R2425[])();

#ifdef __cplusplus
}
#endif

#endif
