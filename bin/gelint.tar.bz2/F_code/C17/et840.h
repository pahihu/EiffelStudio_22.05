
#ifndef _C17_et840_
#define _C17_et840_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1779_16140(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1779_16141(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit840(void);
extern void F1792_16188(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2462[])();
extern EIF_TYPE_INDEX Y12281[];
extern EIF_TYPE_INDEX *Y12281_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
