
#ifndef _C17_et810_
#define _C17_et810_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1749_16037(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit810(void);
extern void F1745_16018(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F377_4575(EIF_REFERENCE);
extern EIF_REFERENCE F1008_7607(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
