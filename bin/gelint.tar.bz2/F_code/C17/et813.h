
#ifndef _C17_et813_
#define _C17_et813_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1752_16040(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1752_16041(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit813(void);
extern void F1749_16037(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2362[])();

#ifdef __cplusplus
}
#endif

#endif
