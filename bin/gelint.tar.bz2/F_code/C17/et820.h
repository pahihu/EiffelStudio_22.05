
#ifndef _C17_et820_
#define _C17_et820_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1759_16045(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit820(void);
extern char *(*R2428[])();

#ifdef __cplusplus
}
#endif

#endif
