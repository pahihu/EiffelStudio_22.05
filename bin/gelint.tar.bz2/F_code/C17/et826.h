
#ifndef _C17_et826_
#define _C17_et826_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1765_16069(EIF_REFERENCE);
extern void F1765_16072(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit826(void);
extern EIF_REFERENCE F1908_17479(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
