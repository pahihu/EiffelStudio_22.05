
#ifndef _C17_et824_
#define _C17_et824_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1763_16059(EIF_REFERENCE);
extern EIF_REFERENCE F1763_16061(EIF_REFERENCE);
extern EIF_REFERENCE F1763_16063(EIF_REFERENCE);
extern EIF_BOOLEAN F1763_16064(EIF_REFERENCE);
extern void EIF_Minit824(void);
extern char *(*R2016[])();
extern char *(*R11795[])();
extern char *(*R11799[])();

#ifdef __cplusplus
}
#endif

#endif
