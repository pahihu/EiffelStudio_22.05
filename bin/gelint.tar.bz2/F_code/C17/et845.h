
#ifndef _C17_et845_
#define _C17_et845_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1784_16165(EIF_REFERENCE);
extern void EIF_Minit845(void);

#ifdef __cplusplus
}
#endif

#endif
