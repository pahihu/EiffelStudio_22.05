
#ifndef _C17_et816_
#define _C17_et816_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1755_16043(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit816(void);
extern char *(*R2343[])();

#ifdef __cplusplus
}
#endif

#endif
