/*
 * Code for class ET_CONSTANT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et832.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_CONSTANT}.is_boolean_constant */
EIF_BOOLEAN F1771_16097 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {ET_CONSTANT}.is_character_constant */
EIF_BOOLEAN F1771_16098 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {ET_CONSTANT}.is_integer_constant */
EIF_BOOLEAN F1771_16099 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

void EIF_Minit832 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
