
#ifndef _C17_et837_
#define _C17_et837_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1776_16117(EIF_REFERENCE);
extern EIF_REFERENCE F1776_16118(EIF_REFERENCE);
extern void F1776_16119(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit837(void);
extern void F1813_16328(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
