
#ifndef _C17_et823_
#define _C17_et823_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1762_16055(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1762_16056(EIF_REFERENCE);
extern void F1762_16058(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit823(void);
extern char *(*R11966[])();
extern char *(*R2353[])();

#ifdef __cplusplus
}
#endif

#endif
