
#ifndef _C17_et818_
#define _C17_et818_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1757_16044(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit818(void);
extern char *(*R2341[])();

#ifdef __cplusplus
}
#endif

#endif
