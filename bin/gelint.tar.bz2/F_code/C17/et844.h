
#ifndef _C17_et844_
#define _C17_et844_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1783_16163(EIF_REFERENCE);
extern void EIF_Minit844(void);

#ifdef __cplusplus
}
#endif

#endif
