
#ifndef _C17_et830_
#define _C17_et830_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1769_16089(EIF_REFERENCE);
extern EIF_REFERENCE F1769_16091(EIF_REFERENCE);
extern EIF_BOOLEAN F1769_16092(EIF_REFERENCE);
extern void F1769_16094(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit830(void);
extern EIF_REFERENCE F377_4533(EIF_REFERENCE);
extern EIF_REFERENCE F377_4568(EIF_REFERENCE);
extern EIF_REFERENCE F1008_7607(EIF_REFERENCE);
extern char *(*R2335[])();

#ifdef __cplusplus
}
#endif

#endif
