
#ifndef _C17_et825_
#define _C17_et825_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1764_16065(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1764_16067(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit825(void);
extern char *(*R2322[])();

#ifdef __cplusplus
}
#endif

#endif
