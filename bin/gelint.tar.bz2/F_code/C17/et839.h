
#ifndef _C17_et839_
#define _C17_et839_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1778_16129(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1778_16130(EIF_REFERENCE);
extern EIF_REFERENCE F1778_16133(EIF_REFERENCE);
extern EIF_REFERENCE F1778_16135(EIF_REFERENCE);
extern void F1778_16137(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit839(void);
extern void F1777_16121(EIF_REFERENCE);
extern EIF_REFERENCE F1908_17479(EIF_REFERENCE);
extern EIF_BOOLEAN F1290_12708(EIF_REFERENCE);
extern void F1777_16120(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R12089[])();
extern char *(*R11795[])();
extern char *(*R12570[])();

#ifdef __cplusplus
}
#endif

#endif
