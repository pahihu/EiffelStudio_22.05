/*
 * Code for class ET_AGENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et804.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_AGENT}.target */
EIF_REFERENCE F1743_15990 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O12209[Dtype(Current)-1742]);
}


/* {ET_AGENT}.arguments */
EIF_REFERENCE F1743_15991 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O12210[Dtype(Current)-1742]);
}


/* {ET_AGENT}.implicit_result */
EIF_REFERENCE F1743_15992 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {ET_AGENT}.set_agent_keyword */
void F1743_15998 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O12208[Dtype(Current)-1742]) = (EIF_REFERENCE) arg1;
}

/* {ET_AGENT}.set_arguments */
void F1743_15999 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O12210[Dtype(Current)-1742]) = (EIF_REFERENCE) arg1;
}

void EIF_Minit804 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
