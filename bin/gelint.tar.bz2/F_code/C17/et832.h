
#ifndef _C17_et832_
#define _C17_et832_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1771_16097(EIF_REFERENCE);
extern EIF_BOOLEAN F1771_16098(EIF_REFERENCE);
extern EIF_BOOLEAN F1771_16099(EIF_REFERENCE);
extern void EIF_Minit832(void);

#ifdef __cplusplus
}
#endif

#endif
