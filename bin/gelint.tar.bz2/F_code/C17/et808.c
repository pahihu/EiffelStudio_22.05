/*
 * Code for class ET_ROUTINE_INLINE_AGENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et808.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ROUTINE_INLINE_AGENT}.last_leaf */
EIF_REFERENCE F1747_16035 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12210[Dtype(Current)-1742]);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1637, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = F1638_15350(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_2_);
	}/* NOTREACHED */
	
}

void EIF_Minit808 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
