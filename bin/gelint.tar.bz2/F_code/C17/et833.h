
#ifndef _C17_et833_
#define _C17_et833_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1772_16105(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit833(void);
extern char *(*R2417[])();

#ifdef __cplusplus
}
#endif

#endif
