
#ifndef _C17_et814_
#define _C17_et814_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1753_16042(EIF_REFERENCE);
extern void EIF_Minit814(void);
extern void F1636_15323(EIF_REFERENCE);
extern void F1745_16019(EIF_REFERENCE);
extern void F1645_15419(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
