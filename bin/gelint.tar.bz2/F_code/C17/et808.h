
#ifndef _C17_et808_
#define _C17_et808_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1747_16035(EIF_REFERENCE);
extern void EIF_Minit808(void);
extern EIF_REFERENCE F1638_15350(EIF_REFERENCE);
extern long O12210[];

#ifdef __cplusplus
}
#endif

#endif
