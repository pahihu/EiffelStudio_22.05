
#ifndef _C17_et834_
#define _C17_et834_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1773_16108(EIF_REFERENCE);
extern void EIF_Minit834(void);
extern char *(*R2018[])();
extern char *(*R12265[])();

#ifdef __cplusplus
}
#endif

#endif
