/*
 * Code for class ET_CHOICE_CONSTANT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et831.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_CHOICE_CONSTANT}.lower */
EIF_REFERENCE F1770_16095 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {ET_CHOICE_CONSTANT}.upper */
EIF_REFERENCE F1770_16096 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

void EIF_Minit831 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
