
#ifndef _C17_et822_
#define _C17_et822_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1761_16047(EIF_REFERENCE);
extern EIF_REFERENCE F1761_16048(EIF_REFERENCE);
extern EIF_REFERENCE F1761_16049(EIF_REFERENCE);
extern EIF_REFERENCE F1761_16051(EIF_REFERENCE);
extern EIF_BOOLEAN F1761_16052(EIF_REFERENCE);
extern void F1761_16053(EIF_REFERENCE, EIF_REFERENCE);
extern void F1761_16054(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit822(void);
extern char *(*R2016[])();
extern char *(*R11795[])();
extern char *(*R11799[])();

#ifdef __cplusplus
}
#endif

#endif
