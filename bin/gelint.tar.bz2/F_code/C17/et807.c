/*
 * Code for class ET_QUERY_INLINE_AGENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et807.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_QUERY_INLINE_AGENT}.type */
EIF_REFERENCE F1746_16032 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12230[Dtype(Current)-1745]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12101[Dtype(RTCW(tr1))-1879])(tr1);
	RTLE;
	return Result;
}

/* {ET_QUERY_INLINE_AGENT}.implicit_result */
EIF_REFERENCE F1746_16034 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O12231[Dtype(Current)-1745]);
}


void EIF_Minit807 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
