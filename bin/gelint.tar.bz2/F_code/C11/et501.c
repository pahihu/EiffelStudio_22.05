/*
 * Code for class ET_DYNAMIC_FUNCTION_TYPE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et501.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_DYNAMIC_FUNCTION_TYPE}.make */
void F1141_10124 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,arg4);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) arg3;
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) arg4;
	F1137_10055(Current, arg1, arg2);
	RTLE;
}

/* {ET_DYNAMIC_FUNCTION_TYPE}.result_type_set */
EIF_REFERENCE F1141_10125 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_16_);
}


/* {ET_DYNAMIC_FUNCTION_TYPE}.new_dynamic_query */
EIF_REFERENCE F1141_10126 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	Result = F1137_10104(Current, arg1, arg2);
	tb1 = '\0';
	tu1_1 = *(EIF_NATURAL_8 *)(RTCW(Result) + O6827[Dtype(Result)-1015]);
	tu1_2 = ((EIF_NATURAL_8) 13U);
	if ((EIF_BOOLEAN)(tu1_1 == tu1_2)) {
		tu1_1 = *(EIF_NATURAL_8 *)(RTCW(Result) + O6828[Dtype(Result)-1015]);
		tu1_2 = ((EIF_NATURAL_8) 2U);
		tb1 = (EIF_BOOLEAN)(tu1_1 == tu1_2);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_31_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2623[Dtype(RTCW(tr1))-266])(tr1, Current, Result);
		loc1 = *(EIF_REFERENCE *)(RTCW(Result));
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4641[Dtype(RTCW(loc1))-383])(loc1);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4641[Dtype(RTCW(tr2))-383])(tr2);
			tb1 = (EIF_BOOLEAN)(tr1 == tr2);
		}
		if (tb1) {
			F1016_8029(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_16_));
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit501 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
