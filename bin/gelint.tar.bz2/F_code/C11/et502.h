
#ifndef _C11_et502_
#define _C11_et502_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1142_10127(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1142_10128(EIF_REFERENCE);
extern EIF_REFERENCE F1142_10129(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit502(void);
extern void F1137_10055(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1137_10105(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2623[])();
extern long O6827[];
extern long O6828[];

#ifdef __cplusplus
}
#endif

#endif
