
#ifndef _C11_kl545_
#define _C11_kl545_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1228_11080(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1228_11082(EIF_REFERENCE);
static EIF_REFERENCE F1228_11084_body(EIF_REFERENCE);
extern EIF_REFERENCE F1228_11084(EIF_REFERENCE);
extern EIF_CHARACTER_8 F1228_11085(EIF_REFERENCE);
extern EIF_REFERENCE F1228_11086(EIF_REFERENCE);
extern void F1228_11088(EIF_REFERENCE);
extern void EIF_Minit545(void);
extern void F1182_10215(EIF_REFERENCE);
extern char *(*R5880[])();

#ifdef __cplusplus
}
#endif

#endif
