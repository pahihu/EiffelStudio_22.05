
#ifndef _C11_ki523_
#define _C11_ki523_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1206_10848(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit523(void);
extern char *(*R5646[])();
extern char *(*R2253[])();
extern char *(*R2259[])();
extern char *(*R2262[])();

#ifdef __cplusplus
}
#endif

#endif
