
#ifndef _C11_et522_
#define _C11_et522_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1205_10832(EIF_REFERENCE);
extern EIF_BOOLEAN F1205_10833(EIF_REFERENCE);
extern void F1205_10841(EIF_REFERENCE);
extern void F1205_10842(EIF_REFERENCE);
extern void F1205_10843(EIF_REFERENCE);
extern EIF_REFERENCE F1205_10844(EIF_REFERENCE);
extern EIF_REFERENCE F1205_10845(EIF_REFERENCE);
extern void EIF_Minit522(void);
extern long O8725[];
extern long O8726[];

#ifdef __cplusplus
}
#endif

#endif
