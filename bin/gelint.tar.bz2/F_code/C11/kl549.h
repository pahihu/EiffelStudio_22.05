
#ifndef _C11_kl549_
#define _C11_kl549_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1232_11125(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit549(void);
extern EIF_BOOLEAN F1204_10807(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1212_10869(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
