
#ifndef _C11_st548_
#define _C11_st548_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1231_11114(EIF_REFERENCE);
extern void F1231_11120(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1231_11121(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1231_11122(EIF_REFERENCE, EIF_REFERENCE);
extern void F1231_11123(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1231_11124(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit548(void);
extern EIF_REFERENCE F1204_10813(EIF_REFERENCE, EIF_REFERENCE);
extern void F1188_10512(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1188_10513(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern EIF_REFERENCE F1212_10869(EIF_REFERENCE);
extern char *(*R8360[])();
extern char *(*R5880[])();
extern char *(*R5646[])();
extern char *(*R8544[])();
extern char *(*R8546[])();

#ifdef __cplusplus
}
#endif

#endif
