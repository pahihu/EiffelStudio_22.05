
#ifndef _C11_kl529_
#define _C11_kl529_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F1212_10869_body(EIF_REFERENCE);
extern EIF_REFERENCE F1212_10869(EIF_REFERENCE);
extern void EIF_Minit529(void);

#ifdef __cplusplus
}
#endif

#endif
