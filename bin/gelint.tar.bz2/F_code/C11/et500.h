
#ifndef _C11_et500_
#define _C11_et500_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1140_10119(EIF_REFERENCE);
extern void F1140_10123(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit500(void);

#ifdef __cplusplus
}
#endif

#endif
