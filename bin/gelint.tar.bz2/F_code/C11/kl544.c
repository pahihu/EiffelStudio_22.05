/*
 * Code for class KL_INTEGER_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl544.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_INTEGER_ROUTINES}.to_character */
EIF_CHARACTER_8 F1227_11061 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	
	
	tc1 = (EIF_CHARACTER_8) arg1;
	return (EIF_CHARACTER_8) tc1;
}

/* {KL_INTEGER_ROUTINES}.to_hexadecimal */
EIF_REFERENCE F1227_11062 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1189, 0x01).id, 1189, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1188_10512(RTCW(Result), ((EIF_INTEGER_32) 8L));
	F1227_11069(Current, arg1, Result, arg2);
	RTLE;
	return Result;
}

/* {KL_INTEGER_ROUTINES}.to_integer */
EIF_INTEGER_32 F1227_11065 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) arg1;
}

/* {KL_INTEGER_ROUTINES}.append_decimal_integer */
void F1227_11067 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '0');
	} else {
		if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 0L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '-');
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 / ((EIF_INTEGER_32) 10L));
			switch ((EIF_INTEGER_32) (loc2 % ((EIF_INTEGER_32) 10L))) {
				case 0L:
					if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
						F1227_11067(Current, loc1, arg2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '1');
					break;
				case 1L:
					if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
						F1227_11067(Current, loc1, arg2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '2');
					break;
				case 2L:
					if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
						F1227_11067(Current, loc1, arg2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '3');
					break;
				case 3L:
					if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
						F1227_11067(Current, loc1, arg2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '4');
					break;
				case 4L:
					if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
						F1227_11067(Current, loc1, arg2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '5');
					break;
				case 5L:
					if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
						F1227_11067(Current, loc1, arg2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '6');
					break;
				case 6L:
					if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
						F1227_11067(Current, loc1, arg2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '7');
					break;
				case 7L:
					if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
						F1227_11067(Current, loc1, arg2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '8');
					break;
				case 8L:
					if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
						F1227_11067(Current, loc1, arg2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '9');
					break;
				case 9L:
					F1227_11067(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), arg2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '0');
					break;
				default:
					RTEC(EN_WHEN);
			}
		} else {
			loc2 = (EIF_INTEGER_32) arg1;
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 / ((EIF_INTEGER_32) 10L));
			if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
				F1227_11067(Current, loc1, arg2);
			}
			switch ((EIF_INTEGER_32) (loc2 % ((EIF_INTEGER_32) 10L))) {
				case 0L:
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '0');
					break;
				case 1L:
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '1');
					break;
				case 2L:
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '2');
					break;
				case 3L:
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '3');
					break;
				case 4L:
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '4');
					break;
				case 5L:
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '5');
					break;
				case 6L:
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '6');
					break;
				case 7L:
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '7');
					break;
				case 8L:
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '8');
					break;
				case 9L:
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '9');
					break;
				default:
					RTEC(EN_WHEN);
			}
		}
	}
	RTLE;
}

/* {KL_INTEGER_ROUTINES}.append_hexadecimal_integer */
void F1227_11069 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '0');
	} else {
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 16L));
		if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
			F1227_11069(Current, loc1, arg2, arg3);
		}
		switch ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 16L))) {
			case 0L:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '0');
				break;
			case 1L:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '1');
				break;
			case 2L:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '2');
				break;
			case 3L:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '3');
				break;
			case 4L:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '4');
				break;
			case 5L:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '5');
				break;
			case 6L:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '6');
				break;
			case 7L:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '7');
				break;
			case 8L:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '8');
				break;
			case 9L:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '9');
				break;
			case 10L:
				if (arg3) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'A');
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'a');
				}
				break;
			case 11L:
				if (arg3) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'B');
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'b');
				}
				break;
			case 12L:
				if (arg3) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'C');
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'c');
				}
				break;
			case 13L:
				if (arg3) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'D');
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'd');
				}
				break;
			case 14L:
				if (arg3) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'E');
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'e');
				}
				break;
			case 15L:
				if (arg3) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'F');
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'f');
				}
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	RTLE;
}

/* {KL_INTEGER_ROUTINES}.div */
EIF_INTEGER_32 F1227_11070 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 / arg2);
}

void EIF_Minit544 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
