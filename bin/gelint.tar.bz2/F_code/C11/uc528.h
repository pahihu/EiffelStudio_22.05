
#ifndef _C11_uc528_
#define _C11_uc528_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1211_10860(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1211_10863(EIF_REFERENCE);
extern void EIF_Minit528(void);
extern void F2134_25535(EIF_REFERENCE, EIF_REFERENCE);
extern void F2134_25528(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
