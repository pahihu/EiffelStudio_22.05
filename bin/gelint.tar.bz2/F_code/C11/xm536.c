/*
 * Code for class XM_EIFFEL_INPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm536.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_INPUT_STREAM}.make_from_stream */
void F1219_10957 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1524,1126,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1189, 1).id);
	F1182_10215(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.is_valid_encoding */
EIF_BOOLEAN F1219_10958 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		Result = '\01';
		tb1 = '\01';
		tb2 = '\01';
		tr1 = RTOUCR(5,F1212_10869, (Current));
		tr2 = RTOUCR(2648,F1219_10962, (Current));
		tb3 = F1204_10807(RTCW(tr1), arg1, tr2);
		if (!tb3) {
			tr1 = RTOUCR(5,F1212_10869, (Current));
			tr2 = RTOUCR(2649,F1219_10961, (Current));
			tb3 = F1204_10807(RTCW(tr1), arg1, tr2);
			tb2 = tb3;
		}
		if (!tb2) {
			tr1 = RTOUCR(5,F1212_10869, (Current));
			tr2 = RTOUCR(2650,F1219_10963, (Current));
			tb2 = F1204_10807(RTCW(tr1), arg1, tr2);
			tb1 = tb2;
		}
		if (!tb1) {
			tr1 = RTOUCR(5,F1212_10869, (Current));
			tr2 = RTOUCR(2651,F1219_10964, (Current));
			tb1 = F1204_10807(RTCW(tr1), arg1, tr2);
			Result = tb1;
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.is_applicable_encoding */
EIF_BOOLEAN F1219_10959 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 6L))) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\01';
		tr1 = RTOUCR(5,F1212_10869, (Current));
		tr2 = RTOUCR(2648,F1219_10962, (Current));
		tb2 = F1204_10807(RTCW(tr1), arg1, tr2);
		if (!tb2) {
			tr1 = RTOUCR(5,F1212_10869, (Current));
			tr2 = RTOUCR(2649,F1219_10961, (Current));
			tb2 = F1204_10807(RTCW(tr1), arg1, tr2);
			tb1 = tb2;
		}
		if (tb1) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 1L))) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 3L)));
		} else {
			tr1 = RTOUCR(5,F1212_10869, (Current));
			tr2 = RTOUCR(2650,F1219_10963, (Current));
			tb1 = F1204_10807(RTCW(tr1), arg1, tr2);
			if (tb1) {
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
				ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 1L)));
			} else {
				tr1 = RTOUCR(5,F1212_10869, (Current));
				tr2 = RTOUCR(2651,F1219_10964, (Current));
				tb1 = F1204_10807(RTCW(tr1), arg1, tr2);
				if (tb1) {
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
					ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
					RTLE;
					return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 4L)) || (EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 5L)));
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.set_encoding */
void F1219_10960 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOUCR(5,F1212_10869, (Current));
	tr2 = RTOUCR(2648,F1219_10962, (Current));
	tb1 = F1204_10807(RTCW(tr1), arg1, tr2);
	if (tb1) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	} else {
		tr1 = RTOUCR(5,F1212_10869, (Current));
		tr2 = RTOUCR(2651,F1219_10964, (Current));
		tb1 = F1204_10807(RTCW(tr1), arg1, tr2);
		if (tb1) {
		} else {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.encoding_us_ascii */

EIF_REFERENCE F1219_10961 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2649,RTMS_EX_H("us-ascii",8,1951510633));
}

/* {XM_EIFFEL_INPUT_STREAM}.encoding_latin_1 */

EIF_REFERENCE F1219_10962 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2648,RTMS_EX_H("iso-8859-1",10,1003358513));
}

/* {XM_EIFFEL_INPUT_STREAM}.encoding_utf_8 */

EIF_REFERENCE F1219_10963 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2650,RTMS_EX_H("utf-8",5,1953751864));
}

/* {XM_EIFFEL_INPUT_STREAM}.encoding_utf_16 */

EIF_REFERENCE F1219_10964 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2651,RTMS_EX_H("utf-16",6,1945159990));
}

/* {XM_EIFFEL_INPUT_STREAM}.read_character */
void F1219_10965 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 6L))) {
		F1219_10984(Current);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(tr1))-1218])(tr1);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			F1219_10983(Current);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current);
			F1525_13863(RTCW(tr1));
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(tr1))-1218])(tr1);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				F1219_10983(Current);
			}
		} else {
			F1219_10983(Current);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.read_string */
void F1219_10966 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(5,F1212_10869, (Current));
	F1204_10824(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	F1219_10965(Current);
	loc1 = (EIF_INTEGER_32) arg1;
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
			tb1 = F1219_10970(Current);
		}
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tc1 = F1219_10972(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(tr1))-1189])(tr1, tc1);
		F1219_10965(Current);
		loc1--;
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.read_to_string */
EIF_INTEGER_32 F1219_10967 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\01';
	if (!(EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 6L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 2L)))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		F1219_10965(Current);
		if ((EIF_BOOLEAN) !F1219_10970(Current)) {
			tc1 = F1219_10972(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5646[Dtype(RTCW(arg1))-819])(arg1, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &arg2);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 1L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8734[Dtype(RTCW(tr1))-1218])(tr1, arg1, arg2, arg3);
		} else {
			Result = F1206_10848(Current, arg1, arg2, arg3);
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.end_of_input */
EIF_BOOLEAN F1219_10970 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(tr1))-1218])(tr1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.name */
EIF_REFERENCE F1219_10971 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2261[Dtype(RTCW(tr1))-1218])(tr1);
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.last_character */
EIF_CHARACTER_8 F1219_10972 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1525_13854(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2262[Dtype(RTCW(tr1))-1218])(tr1));
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.last_string */
EIF_REFERENCE F1219_10973 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {XM_EIFFEL_INPUT_STREAM}.noqueue_read_character */
void F1219_10983 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 1L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 2L)))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2253[Dtype(RTCW(tr1))-1218])(tr1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 3L))) {
			F1219_10986(Current);
		} else {
			F1219_10985(Current);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.utf16_detect_read_character */
void F1219_10984 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2253[Dtype(RTCW(tr1))-1218])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(tr1))-1218])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2262[Dtype(RTCW(tr1))-1218])(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2253[Dtype(RTCW(tr1))-1218])(tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(tr1))-1218])(tr1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2262[Dtype(RTCW(tr1))-1218])(tr1));
			tr1 = RTOUCR(2538,F374_3631, (Current));
			ti4_1 = (EIF_INTEGER_32) (loc1);
			ti4_2 = (EIF_INTEGER_32) (loc2);
			tb1 = F1194_10696(RTCW(tr1), ti4_1, ti4_2);
			if (tb1) {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			} else {
				tr1 = RTOUCR(2538,F374_3631, (Current));
				ti4_1 = (EIF_INTEGER_32) (loc1);
				ti4_2 = (EIF_INTEGER_32) (loc2);
				tb1 = F1194_10697(RTCW(tr1), ti4_1, ti4_2);
				if (tb1) {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				} else {
					tb1 = '\0';
					ti4_1 = (EIF_INTEGER_32) (loc1);
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
						tb1 = (EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_8) '<');
					}
					if (tb1) {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
						tr1 = *(EIF_REFERENCE *)(Current);
						F1525_13860(RTCW(tr1), (EIF_CHARACTER_8) '<');
					} else {
						tb1 = '\0';
						if ((EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '<')) {
							ti4_1 = (EIF_INTEGER_32) (loc2);
							tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
						}
						if (tb1) {
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
							tr1 = *(EIF_REFERENCE *)(Current);
							F1525_13860(RTCW(tr1), (EIF_CHARACTER_8) '<');
						} else {
							tr1 = RTOUCR(2533,F416_5682, (Current));
							tb1 = F1203_10738(RTCW(tr1), loc1, loc2);
							if (tb1) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R2253[Dtype(RTCW(tr1))-1218])(tr1);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(tr1))-1218])(tr1);
								if ((EIF_BOOLEAN) !tb1) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2262[Dtype(RTCW(tr1))-1218])(tr1));
									tr1 = RTOUCR(2533,F416_5682, (Current));
									tb1 = F1203_10737(RTCW(tr1), loc1, loc2, loc3);
									if (tb1) {
									} else {
										tr1 = *(EIF_REFERENCE *)(Current);
										F1525_13860(RTCW(tr1), loc1);
										tr1 = *(EIF_REFERENCE *)(Current);
										F1525_13860(RTCW(tr1), loc2);
										tr1 = *(EIF_REFERENCE *)(Current);
										F1525_13860(RTCW(tr1), loc3);
									}
								} else {
									tr1 = *(EIF_REFERENCE *)(Current);
									F1525_13860(RTCW(tr1), loc1);
									tr1 = *(EIF_REFERENCE *)(Current);
									F1525_13860(RTCW(tr1), loc2);
								}
							} else {
								tr1 = *(EIF_REFERENCE *)(Current);
								F1525_13860(RTCW(tr1), loc1);
								tr1 = *(EIF_REFERENCE *)(Current);
								F1525_13860(RTCW(tr1), loc2);
							}
						}
					}
				}
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			F1525_13860(RTCW(tr1), loc1);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.utf16_read_character */
void F1219_10985 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2253[Dtype(RTCW(tr1))-1218])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(tr1))-1218])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2262[Dtype(RTCW(tr1))-1218])(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2253[Dtype(RTCW(tr1))-1218])(tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(tr1))-1218])(tr1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2262[Dtype(RTCW(tr1))-1218])(tr1));
			loc3 = F1219_10988(Current, loc1, loc2);
			loc4 = F1219_10989(Current, loc1, loc2);
			tr1 = RTOUCR(2538,F374_3631, (Current));
			tb1 = F1194_10699(RTCW(tr1), loc3);
			if (tb1) {
				tr1 = RTOUCR(2538,F374_3631, (Current));
				tb1 = F1194_10700(RTCW(tr1), loc3);
				if (tb1) {
					tr1 = RTOUCR(2538,F374_3631, (Current));
					loc5 = F1194_10702(RTCW(tr1), loc3, loc4);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R2253[Dtype(RTCW(tr1))-1218])(tr1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(tr1))-1218])(tr1);
					if ((EIF_BOOLEAN) !tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2262[Dtype(RTCW(tr1))-1218])(tr1));
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R2253[Dtype(RTCW(tr1))-1218])(tr1);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(tr1))-1218])(tr1);
						if ((EIF_BOOLEAN) !tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							loc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2262[Dtype(RTCW(tr1))-1218])(tr1));
							loc3 = F1219_10988(Current, loc1, loc2);
							loc4 = F1219_10989(Current, loc1, loc2);
							tr1 = RTOUCR(2538,F374_3631, (Current));
							tb1 = F1194_10701(RTCW(tr1), loc3);
							if (tb1) {
								tr1 = RTOUCR(2538,F374_3631, (Current));
								tr2 = RTOUCR(2538,F374_3631, (Current));
								ti4_1 = F1194_10702(RTCW(tr2), loc3, loc4);
								ti4_1 = F1194_10703(RTCW(tr1), loc5, ti4_1);
								F1219_10987(Current, ti4_1);
							}
						}
					}
				}
			} else {
				F1219_10987(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 * ((EIF_INTEGER_32) 256L)) + loc4));
			}
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.latin1_read_character */
void F1219_10986 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2253[Dtype(RTCW(tr1))-1218])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2259[Dtype(RTCW(tr1))-1218])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2262[Dtype(RTCW(tr1))-1218])(tr1));
		ti4_1 = (EIF_INTEGER_32) (tc1);
		if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 128L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2262[Dtype(RTCW(tr1))-1218])(tr1));
			ti4_1 = (EIF_INTEGER_32) (tc1);
			F1219_10987(Current, ti4_1);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.append_character */
void F1219_10987 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc3 = RTOUCR(2652,F1219_10991, (Current));
	tr1 = RTOUCR(5,F1212_10869, (Current));
	F1204_10824(RTCW(tr1), loc3);
	tr1 = RTOUCR(2533,F416_5682, (Current));
	F1203_10764(RTCW(tr1), loc3, arg1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5880[Dtype(RTCW(loc3))-819])(loc3, loc1));
		F1525_13860(RTCW(tr1), tc1);
		loc1++;
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.most_significant */
EIF_INTEGER_32 F1219_10988 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 4L))) {
		ti4_1 = (EIF_INTEGER_32) (arg1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		ti4_1 = (EIF_INTEGER_32) (arg2);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}/* NOTREACHED */
	
}

/* {XM_EIFFEL_INPUT_STREAM}.least_significant */
EIF_INTEGER_32 F1219_10989 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 4L))) {
		ti4_1 = (EIF_INTEGER_32) (arg2);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		ti4_1 = (EIF_INTEGER_32) (arg1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}/* NOTREACHED */
	
}

/* {XM_EIFFEL_INPUT_STREAM}.utf8_buffer */
static EIF_REFERENCE F1219_10991_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2652)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1189, 0x01).id, 1189, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1188_10512(RTCW(tr1), ((EIF_INTEGER_32) 6L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1219_10991 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2652,F1219_10991_body,(Current));
}

void EIF_Minit536 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
