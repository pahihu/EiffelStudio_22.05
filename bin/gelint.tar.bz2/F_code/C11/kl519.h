
#ifndef _C11_kl519_
#define _C11_kl519_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1195_10719(EIF_REFERENCE, EIF_NATURAL_32, EIF_BOOLEAN);
extern void F1195_10720(EIF_REFERENCE, EIF_NATURAL_32, EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit519(void);
extern void F1188_10512(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R8546[])();

#ifdef __cplusplus
}
#endif

#endif
