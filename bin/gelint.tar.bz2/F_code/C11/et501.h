
#ifndef _C11_et501_
#define _C11_et501_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1141_10124(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1141_10125(EIF_REFERENCE);
extern EIF_REFERENCE F1141_10126(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit501(void);
extern void F1137_10055(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1137_10104(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1016_8029(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2623[])();
extern char *(*R4641[])();
extern long O6827[];
extern long O6828[];

#ifdef __cplusplus
}
#endif

#endif
