
#ifndef _C11_st508_
#define _C11_st508_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1184_10313(EIF_REFERENCE);
extern void F1184_10315(EIF_REFERENCE, EIF_NATURAL_32);
extern void F1184_10326(EIF_REFERENCE, EIF_REFERENCE);
extern void F1184_10327(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit508(void);
extern char *(*R8320[])();
extern char *(*R8408[])();
extern char *(*R8375[])();
extern char *(*R8378[])();
extern char *(*R8379[])();
extern char *(*R8319[])();
extern char *(*R8282[])();
extern long O8373[];
extern long O8372[];

#ifdef __cplusplus
}
#endif

#endif
