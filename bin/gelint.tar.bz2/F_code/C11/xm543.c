/*
 * Code for class XM_EIFFEL_PARSER_NAME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm543.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_PARSER_NAME}.make_namespaces */
void F1226_11038 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1226_11039(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_EIFFEL_PARSER_NAME}.make_no_namespaces */
void F1226_11039 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = F389_5260(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_EIFFEL_PARSER_NAME}.is_namespace_name */
EIF_BOOLEAN F1226_11043 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 2L))) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_NAME}.ns_prefix */
EIF_REFERENCE F1226_11047 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_)) {
		tb1 = F1226_11043(Current);
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {XM_EIFFEL_PARSER_NAME}.local_part */
EIF_REFERENCE F1226_11048 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_)) {
		RTLE;
		return (EIF_REFERENCE) F1226_11051(Current);
	} else {
		tr1 = RTOUCR(5,F1212_10869, (Current));
		Result = F1204_10813(RTCW(tr1), *(EIF_REFERENCE *)(Current));
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) > ((EIF_INTEGER_32) 1L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(Result))-1189])(Result, (EIF_CHARACTER_8) ':');
			tr1 = RTOUCR(5,F1212_10869, (Current));
			tr1 = F1204_10814(RTCW(tr1), Result, *(EIF_REFERENCE *)(Current + _REFACS_1_));
			Result = (EIF_REFERENCE) tr1;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) > ((EIF_INTEGER_32) 2L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10794[Dtype(RTCW(tr1))-1480])(tr1);
				F1337_13187(RTCW(loc1));
				for (;;) {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5399[Dtype(RTCW(loc1))-529])(loc1);
					if (tb1) break;
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(Result))-1189])(Result, (EIF_CHARACTER_8) ':');
					tr1 = RTOUCR(5,F1212_10869, (Current));
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5398[Dtype(RTCW(loc1))-529])(loc1);
					tr1 = F1204_10814(RTCW(tr1), Result, tr2);
					Result = (EIF_REFERENCE) tr1;
					F1337_13188(RTCW(loc1));
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_NAME}.item */
EIF_REFERENCE F1226_11049 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
	} else {
		if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 2L))) {
			RTLE;
			return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R10878[Dtype(RTCW(tr1))-1511])(tr1, (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 2L)));
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_NAME}.last */
EIF_REFERENCE F1226_11051 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 1L))) {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 2L))) {
			RTLE;
			return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10831[Dtype(RTCW(tr1))-1511])(tr1);
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_NAME}.hash_code */
EIF_INTEGER_32 F1226_11052 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F1226_11049(Current, loc1);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7272[Dtype(RTCW(tr1))-1057])(tr1);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result / ((EIF_INTEGER_32) 3L)) + (EIF_INTEGER_32) (ti4_1 / ((EIF_INTEGER_32) 3L)));
		loc1++;
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_NAME}.can_force_last */
EIF_BOOLEAN F1226_11054 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_)) {
		Result = '\0';
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) < ((EIF_INTEGER_32) 2L))) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			Result = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_NAME}.force_last */
void F1226_11055 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_))++;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 1L))) {
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 2L))) {
			RTAR(Current, arg1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 3L))) {
				tr1 = F389_5260(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10854[Dtype(RTCW(tr1))-1511])(tr1, arg1);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_NAME}.is_equal */
EIF_BOOLEAN F1226_11057 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_1_0_0_);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ti4_1)) {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 1L))) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
				Result = F389_5258(Current, *(EIF_REFERENCE *)(Current), tr1);
			} else {
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 2L))) {
					Result = '\0';
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
					if (F389_5258(Current, *(EIF_REFERENCE *)(Current), tr1)) {
						tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
						Result = F389_5258(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), tr1);
					}
				} else {
					Result = '\0';
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
					if (F389_5258(Current, *(EIF_REFERENCE *)(Current), tr1)) {
						tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
						Result = F389_5258(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), tr1);
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10794[Dtype(RTCW(tr1))-1480])(tr1);
					F1337_13187(RTCW(loc1));
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
					loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10794[Dtype(RTCW(tr1))-1480])(tr1);
					F1337_13187(RTCW(loc2));
					for (;;) {
						tb1 = '\01';
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5399[Dtype(RTCW(loc1))-529])(loc1);
						if (!tb2) {
							tb1 = (EIF_BOOLEAN) !Result;
						}
						if (tb1) break;
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5398[Dtype(RTCW(loc1))-529])(loc1);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5398[Dtype(RTCW(loc2))-529])(loc2);
						Result = F389_5258(Current, tr1, tr2);
						F1337_13188(RTCW(loc1));
						F1337_13188(RTCW(loc2));
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit543 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
