
#ifndef _C11_kl516_
#define _C11_kl516_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F1192_10678_body(EIF_REFERENCE);
extern EIF_REFERENCE F1192_10678(EIF_REFERENCE);
extern void EIF_Minit516(void);

#ifdef __cplusplus
}
#endif

#endif
