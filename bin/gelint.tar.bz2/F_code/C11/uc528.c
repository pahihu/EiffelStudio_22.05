/*
 * Code for class UC_UNICODE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc528.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_UNICODE_FACTORY}.new_unicode_string_from_utf8 */
EIF_REFERENCE F1211_10860 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(2134, 0x01).id, 2134, _OBJSIZ_1_1_0_6_0_0_0_0_);
	F2134_25535(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {UC_UNICODE_FACTORY}.new_unicode_string_empty */
EIF_REFERENCE F1211_10863 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(2134, 0x01).id, 2134, _OBJSIZ_1_1_0_6_0_0_0_0_);
	F2134_25528(RTCW(tr1));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit528 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
