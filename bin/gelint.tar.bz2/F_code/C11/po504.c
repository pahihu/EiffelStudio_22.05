/*
 * Code for class POINTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po504.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {POINTER}.hash_code */
EIF_INTEGER_32 F1175_10157 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F1143_10131(Current);
}

/* {POINTER}.is_default_pointer */
EIF_BOOLEAN F1175_10158 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F1143_10136(Current);
}

/* {POINTER}.plus */
EIF_POINTER F1175_10159 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_POINTER) F1143_10137(Current, arg1);
}

void EIF_Minit504 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
