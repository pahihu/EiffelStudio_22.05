/*
 * Code for class ET_ECF_BUILD_CONDITION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et539.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ECF_BUILD_CONDITION}.make */
void F1222_11008 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {ET_ECF_BUILD_CONDITION}.make_excluded */
void F1222_11009 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {ET_ECF_BUILD_CONDITION}.is_enabled */
EIF_BOOLEAN F1222_11011 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLR(7,tr3);
	RTLR(8,tr4);
	RTLR(9,tr5);
	RTLIU(10);
	
	RTGC;
	loc1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_8_);
	tr2 = RTOUCR(2310,F26_337, (Current));
	tr1 = F1248_11722(RTCW(tr1), tr2);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = RTOUCR(5,F1212_10869, (Current));
		tr2 = RTOUCR(2333,F26_378, (Current));
		tb1 = F1204_10807(RTCW(tr1), loc4, tr2);
		loc1 = tb1;
	}
	if (loc1) {
		loc2 = RTOUCR(2331,F26_370, (Current));
	} else {
		loc2 = RTOUCR(2336,F26_382, (Current));
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tc1 = (EIF_CHARACTER_8) ' ';
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5605[Dtype(RTCW(tr1))-728])(tr1, (EIF_REFERENCE) &tc1);
	if (tb1) {
		loc3 = RTLNS(eif_new_type(1257, 0x01).id, 1257, _OBJSIZ_2_2_0_0_0_0_0_0_);
		tr1 = RTOUCR(349,F48_655, (Current));
		F1258_12105(RTCW(loc3), tr1);
		tr1 = F1258_12114(RTCW(loc3), *(EIF_REFERENCE *)(Current));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1090,0xFF01,1203,0xFF01,1189,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 0);
		}
		tr3 = RTOUCR(5,F1212_10869, (Current));
		((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
		RTAR(tr2,tr3);
		((EIF_TYPED_VALUE *)tr2+2)->it_r = loc2;
		RTAR(tr2,loc2);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1180,0xFF01,0xFFF9,1,1090,0xFF01,1189,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A521_56_2, (EIF_POINTER) _A521_56_2, (EIF_POINTER)(F1204_10807),tr2, 1, 1);
		}
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R10769[Dtype(RTCW(tr1))-1511])(tr1, tr5);
	} else {
		tr1 = RTOUCR(5,F1212_10869, (Current));
		Result = F1204_10807(RTCW(tr1), *(EIF_REFERENCE *)(Current), loc2);
	}
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) != Result);
}

void EIF_Minit539 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
