/*
 * Code for class ST_WORD_WRAPPER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st548.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ST_WORD_WRAPPER}.make */
void F1231_11114 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 79L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {ST_WORD_WRAPPER}.set_maximum_text_width */
void F1231_11120 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {ST_WORD_WRAPPER}.set_new_line_indentation */
void F1231_11121 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) arg1;
}

/* {ST_WORD_WRAPPER}.wrapped_string */
EIF_REFERENCE F1231_11122 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc6);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOUCR(5,F1212_10869, (Current));
	loc1 = F1204_10813(RTCW(tr1), arg1);
	F1231_11123(Current, loc1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	loc6 = RTLNS(eif_new_type(1189, 0x01).id, 1189, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1188_10513(RTCW(loc6), (EIF_CHARACTER_8) ' ', *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_));
	Result = RTLNS(eif_new_type(1189, 0x01).id, 1189, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	F1188_10512(RTCW(Result), ti4_1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc4 > loc2)) break;
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc4 + loc3) <= loc2)) {
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + loc3);
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN)(loc5 == loc4)) {
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5880[Dtype(RTCW(loc1))-819])(loc1, loc5));
					tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) ' ');
				}
				if (tb1) break;
				loc5--;
			}
		} else {
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		}
		if ((EIF_BOOLEAN)(loc5 == loc4)) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_))++;
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + loc3) - ((EIF_INTEGER_32) 1L));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8360[Dtype(RTCW(loc1))-1185])(loc1, loc4, loc5);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8544[Dtype(RTCW(Result))-1189])(Result, tr1);
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8360[Dtype(RTCW(loc1))-1185])(loc1, loc4, (EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8544[Dtype(RTCW(Result))-1189])(Result, tr1);
		}
		loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc4 <= ti4_1)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(Result))-1189])(Result, (EIF_CHARACTER_8) '\012');
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8544[Dtype(RTCW(Result))-1189])(Result, loc6);
		}
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ti4_1);
	}
	RTLE;
	return Result;
}

/* {ST_WORD_WRAPPER}.canonify_whitespace */
void F1231_11123 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5880[Dtype(RTCW(arg1))-819])(arg1, loc1));
		if (F1231_11124(Current, loc3)) {
			tc1 = (EIF_CHARACTER_8) ' ';
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5646[Dtype(RTCW(arg1))-819])(arg1, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc1);
		}
		loc1++;
	}
	RTLE;
}

/* {ST_WORD_WRAPPER}.is_space */
EIF_BOOLEAN F1231_11124 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) ' ') || (EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '\011')) || (EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '\012')) || (EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '\015'));
}

void EIF_Minit548 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
