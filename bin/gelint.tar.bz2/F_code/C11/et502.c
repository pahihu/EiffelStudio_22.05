/*
 * Code for class ET_DYNAMIC_PROCEDURE_TYPE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et502.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_DYNAMIC_PROCEDURE_TYPE}.make */
void F1142_10127 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) arg3;
	F1137_10055(Current, arg1, arg2);
	RTLE;
}

/* {ET_DYNAMIC_PROCEDURE_TYPE}.result_type_set */
EIF_REFERENCE F1142_10128 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {ET_DYNAMIC_PROCEDURE_TYPE}.new_dynamic_procedure */
EIF_REFERENCE F1142_10129 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	Result = F1137_10105(Current, arg1, arg2);
	tb1 = '\0';
	tu1_1 = *(EIF_NATURAL_8 *)(RTCW(Result) + O6827[Dtype(Result)-1015]);
	tu1_2 = ((EIF_NATURAL_8) 37U);
	if ((EIF_BOOLEAN)(tu1_1 == tu1_2)) {
		tu1_1 = *(EIF_NATURAL_8 *)(RTCW(Result) + O6828[Dtype(Result)-1015]);
		tu1_2 = ((EIF_NATURAL_8) 1U);
		tb1 = (EIF_BOOLEAN)(tu1_1 == tu1_2);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_31_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2623[Dtype(RTCW(tr1))-266])(tr1, Current, Result);
	}
	RTLE;
	return Result;
}

void EIF_Minit502 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
