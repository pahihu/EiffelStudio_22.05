/*
 * Code for class ET_DYNAMIC_ROUTINE_TYPE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et500.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_DYNAMIC_ROUTINE_TYPE}.is_agent_type */
EIF_BOOLEAN F1140_10119 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {ET_DYNAMIC_ROUTINE_TYPE}.set_set_rout_disp_final_feature */
void F1140_10123 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit500 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
