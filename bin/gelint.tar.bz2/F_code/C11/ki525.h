
#ifndef _C11_ki525_
#define _C11_ki525_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1208_10855(EIF_REFERENCE);
extern void EIF_Minit525(void);

#ifdef __cplusplus
}
#endif

#endif
