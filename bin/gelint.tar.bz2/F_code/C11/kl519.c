/*
 * Code for class KL_NATURAL_32_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl519.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_NATURAL_32_ROUTINES}.to_hexadecimal */
EIF_REFERENCE F1195_10719 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1189, 0x01).id, 1189, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1188_10512(RTCW(Result), ((EIF_INTEGER_32) 8L));
	F1195_10720(Current, arg1, Result, arg2);
	RTLE;
	return Result;
}

/* {KL_NATURAL_32_ROUTINES}.append_hexadecimal_integer */
void F1195_10720 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '0');
	} else {
		loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) (arg1 / (EIF_NATURAL_32) ((EIF_INTEGER_32) 16L));
		if ((EIF_BOOLEAN)(loc1 != (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
			F1195_10720(Current, loc1, arg2, arg3);
		}
		switch ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 16L))) {
			case 0U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '0');
				break;
			case 1U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '1');
				break;
			case 2U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '2');
				break;
			case 3U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '3');
				break;
			case 4U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '4');
				break;
			case 5U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '5');
				break;
			case 6U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '6');
				break;
			case 7U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '7');
				break;
			case 8U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '8');
				break;
			case 9U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) '9');
				break;
			case 10U:
				if (arg3) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'A');
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'a');
				}
				break;
			case 11U:
				if (arg3) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'B');
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'b');
				}
				break;
			case 12U:
				if (arg3) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'C');
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'c');
				}
				break;
			case 13U:
				if (arg3) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'D');
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'd');
				}
				break;
			case 14U:
				if (arg3) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'E');
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'e');
				}
				break;
			case 15U:
				if (arg3) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'F');
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg2))-1189])(arg2, (EIF_CHARACTER_8) 'f');
				}
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	RTLE;
}

void EIF_Minit519 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
