/*
 * Code for class KL_STRING_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl521.h"
#include "eif_built_in.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STRING_ROUTINES}.new_empty_string */
EIF_REFERENCE F1204_10797 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOUCR(98,F1192_10678, (Current));
	tr2 = RTOUCR(1358,F1204_10828, (Current));
	tb1 = F30_406(RTCW(tr1), arg1, tr2);
	if (tb1) {
		tr1 = RTLNS(eif_new_type(1189, 0x01).id, 1189, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1188_10512(RTCW(tr1), arg2);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		loc1 = arg1;
		loc1 = RTRV(eif_new_type(2133, 0x01),loc1);
		if (EIF_TEST(loc1)) {
			tr1 = F2134_25553(loc1, arg2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			Result = F1204_10813(Current, arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R8407[Dtype(RTCW(Result))-1186])(Result);
		}
	}
	RTLE;
	return Result;
}

/* {KL_STRING_ROUTINES}.case_insensitive_hash_code */
EIF_INTEGER_32 F1204_10803 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		ti4_1 = eif_bit_shift_left((EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 8388593L)),((EIF_INTEGER_32) 8L));
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5880[Dtype(RTCW(arg1))-819])(arg1, loc1));
		tc1 = eif_builtin_CHARACTER_8_as_upper__c1_c1(tc1);
		ti4_2 = (EIF_INTEGER_32) (tc1);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ti4_2);
		loc1++;
	}
	if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	}
	RTLE;
	return Result;
}

/* {KL_STRING_ROUTINES}.concat */
EIF_REFERENCE F1204_10804 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(2133, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = F2134_25547(loc1, arg2);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		loc2 = arg2;
		loc2 = RTRV(eif_new_type(2133, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			tr1 = F2134_25548(loc2, arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8508[Dtype(RTCW(arg1))-1189])(arg1, arg2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}/* NOTREACHED */
	
}

/* {KL_STRING_ROUTINES}.elks_same_string */
EIF_BOOLEAN F1204_10805 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
			tr1 = RTOUCR(98,F1192_10678, (Current));
			tr2 = RTOUCR(1358,F1204_10828, (Current));
			tb1 = F30_406(RTCW(tr1), arg2, tr2);
			if (tb1) {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8503[Dtype(RTCW(arg1))-1188])(arg1, arg2);
				RTLE;
				return (EIF_BOOLEAN) tb1;
			} else {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8503[Dtype(RTCW(arg2))-1188])(arg2, arg1);
				RTLE;
				return (EIF_BOOLEAN) tb1;
			}
		}
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {KL_STRING_ROUTINES}.same_string */
EIF_BOOLEAN F1204_10806 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLR(4,Current);
	RTLR(5,tr1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
			loc3 = arg1;
			loc3 = RTRV(eif_new_type(2133, 0x01),loc3);
			if (EIF_TEST(loc3)) {
				tb1 = F2134_25571(loc3, arg2);
				RTLE;
				return (EIF_BOOLEAN) tb1;
			} else {
				loc4 = arg2;
				loc4 = RTRV(eif_new_type(2133, 0x01),loc4);
				if (EIF_TEST(loc4)) {
					Result = F2134_25571(loc4, arg1);
				} else {
					tb1 = '\0';
					tr1 = RTOUCR(98,F1192_10678, (Current));
					tr2 = RTOUCR(1358,F1204_10828, (Current));
					tb2 = F30_406(RTCW(tr1), arg1, tr2);
					if (tb2) {
						tr1 = RTOUCR(98,F1192_10678, (Current));
						tr2 = RTOUCR(1358,F1204_10828, (Current));
						tb2 = F30_406(RTCW(tr1), arg2, tr2);
						tb1 = tb2;
					}
					if (tb1) {
						Result = F1204_10805(Current, arg1, arg2);
						RTLE;
						return (EIF_BOOLEAN) Result;
					} else {
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 > loc2)) break;
							ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8494[Dtype(RTCW(arg1))-1189])(arg1, loc1);
							ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8494[Dtype(RTCW(arg2))-1189])(arg2, loc1);
							if ((EIF_BOOLEAN)(ti4_1 != ti4_2)) {
								Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
							} else {
								loc1++;
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {KL_STRING_ROUTINES}.same_case_insensitive */
EIF_BOOLEAN F1204_10807 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
			loc6 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tb1 = '\0';
			tr1 = RTOUCR(98,F1192_10678, (Current));
			tr2 = RTOUCR(1358,F1204_10828, (Current));
			tb2 = F30_406(RTCW(tr1), arg1, tr2);
			if (tb2) {
				tr1 = RTOUCR(98,F1192_10678, (Current));
				tr2 = RTOUCR(1358,F1204_10828, (Current));
				tb2 = F30_406(RTCW(tr1), arg2, tr2);
				tb1 = tb2;
			}
			if ((EIF_BOOLEAN) !tb1) {
				loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc5 > loc6)) break;
					loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8494[Dtype(RTCW(arg1))-1189])(arg1, loc5);
					loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8494[Dtype(RTCW(arg2))-1189])(arg2, loc5);
					if ((EIF_BOOLEAN)(loc3 == loc4)) {
						loc5++;
					} else {
						tr1 = RTOUCR(1359,F451_6112, (Current));
						ti4_1 = F1273_12286(RTCW(tr1), loc3);
						tr1 = RTOUCR(1359,F451_6112, (Current));
						ti4_2 = F1273_12286(RTCW(tr1), loc4);
						if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
							loc5++;
						} else {
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L));
						}
					}
				}
			} else {
				loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc5 > loc6)) break;
					loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5880[Dtype(RTCW(arg1))-819])(arg1, loc5));
					loc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5880[Dtype(RTCW(arg2))-819])(arg2, loc5));
					if ((EIF_BOOLEAN)(loc1 == loc2)) {
						loc5++;
					} else {
						tc1 = eif_builtin_CHARACTER_8_as_lower__c1_c1(loc1);
						tc2 = eif_builtin_CHARACTER_8_as_lower__c1_c1(loc2);
						if ((EIF_BOOLEAN)(tc1 == tc2)) {
							loc5++;
						} else {
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L));
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {KL_STRING_ROUTINES}.three_way_comparison */
EIF_INTEGER_32 F1204_10809 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc10);
	RTLR(6,loc11);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == arg1)) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		tb1 = '\0';
		tr1 = RTOUCR(98,F1192_10678, (Current));
		tr2 = RTOUCR(1358,F1204_10828, (Current));
		tb2 = F30_406(RTCW(tr1), arg1, tr2);
		if (tb2) {
			tr1 = RTOUCR(98,F1192_10678, (Current));
			tr2 = RTOUCR(1358,F1204_10828, (Current));
			tb2 = F30_406(RTCW(tr1), arg2, tr2);
			tb1 = tb2;
		}
		if (tb1) {
			loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			loc4 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (loc3 < loc4)) {
				loc2 = (EIF_INTEGER_32) loc3;
			} else {
				loc2 = (EIF_INTEGER_32) loc4;
			}
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5880[Dtype(RTCW(arg1))-819])(arg1, loc1));
				loc6 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5880[Dtype(RTCW(arg2))-819])(arg2, loc1));
				if ((EIF_BOOLEAN)(loc5 == loc6)) {
					loc1++;
				} else {
					if ((EIF_BOOLEAN) (loc5 < loc6)) {
						loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					} else {
						loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					}
				}
			}
			if ((EIF_BOOLEAN) !loc9) {
				if ((EIF_BOOLEAN) (loc3 < loc4)) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				} else {
					if ((EIF_BOOLEAN)(loc3 != loc4)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					}
				}
			}
		} else {
			loc10 = arg1;
			loc10 = RTRV(eif_new_type(2133, 0x01),loc10);
			if (EIF_TEST(loc10)) {
				Result = F2134_25573(loc10, arg2);
			} else {
				loc11 = arg2;
				loc11 = RTRV(eif_new_type(2133, 0x01),loc11);
				if (EIF_TEST(loc11)) {
					Result = F2134_25573(loc11, arg1);
					Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -Result;
				} else {
					loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
					loc4 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (loc3 < loc4)) {
						loc2 = (EIF_INTEGER_32) loc3;
					} else {
						loc2 = (EIF_INTEGER_32) loc4;
					}
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > loc2)) break;
						loc7 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8494[Dtype(RTCW(arg1))-1189])(arg1, loc1);
						loc8 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8494[Dtype(RTCW(arg2))-1189])(arg2, loc1);
						if ((EIF_BOOLEAN)(loc7 == loc8)) {
							loc1++;
						} else {
							if ((EIF_BOOLEAN) (loc7 < loc8)) {
								loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
							} else {
								loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
							}
						}
					}
					if ((EIF_BOOLEAN) !loc9) {
						if ((EIF_BOOLEAN) (loc3 < loc4)) {
							RTLE;
							return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							if ((EIF_BOOLEAN)(loc3 != loc4)) {
								RTLE;
								return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {KL_STRING_ROUTINES}.cloned_string */
EIF_REFERENCE F1204_10813 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	
	
	tr1 = F1_14(arg1);
	return (EIF_REFERENCE) tr1;
}

/* {KL_STRING_ROUTINES}.appended_string */
EIF_REFERENCE F1204_10814 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(2133, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		F2134_25583(loc1, arg2);
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		loc2 = arg2;
		loc2 = RTRV(eif_new_type(2133, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			RTLE;
			return (EIF_REFERENCE) F1204_10804(Current, arg1, arg2);
		} else {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8544[Dtype(RTCW(arg1))-1189])(arg1, arg2);
			RTLE;
			return (EIF_REFERENCE) arg1;
		}
	}/* NOTREACHED */
	
}

/* {KL_STRING_ROUTINES}.appended_substring */
EIF_REFERENCE F1204_10815 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,loc4);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	loc3 = arg1;
	loc3 = RTRV(eif_new_type(2133, 0x01),loc3);
	if (EIF_TEST(loc3)) {
		F2134_25586(loc3, arg2, arg3, arg4);
		RTLE;
		return (EIF_REFERENCE) loc3;
	} else {
		loc4 = arg2;
		loc4 = RTRV(eif_new_type(2133, 0x01),loc4);
		if (EIF_TEST(loc4)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			loc1 = F2134_25553(loc4, (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + arg4) - arg3) + ((EIF_INTEGER_32) 1L)));
			F2134_25583(RTCW(loc1), arg1);
			F2134_25586(RTCW(loc1), arg2, arg3, arg4);
			RTLE;
			return (EIF_REFERENCE) loc1;
		} else {
			loc2 = (EIF_INTEGER_32) arg3;
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 > arg4)) break;
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5880[Dtype(RTCW(arg2))-819])(arg2, loc2));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8546[Dtype(RTCW(arg1))-1189])(arg1, tc1);
				loc2++;
			}
			RTLE;
			return (EIF_REFERENCE) arg1;
		}
	}/* NOTREACHED */
	
}

/* {KL_STRING_ROUTINES}.append_substring_to_string */
void F1204_10817 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	loc3 = arg1;
	loc3 = RTRV(eif_new_type(2133, 0x01),loc3);
	loc4 = arg2;
	loc4 = RTRV(eif_new_type(1189, 0x01),loc4);
	if ((EIF_BOOLEAN) (EIF_TEST(loc3) && EIF_TEST(loc4))) {
		F2134_25586(loc3, loc4, arg3, arg4);
	} else {
		loc1 = (EIF_INTEGER_32) arg3;
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > arg4)) break;
			tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8282[Dtype(RTCW(arg2))-1185])(arg2, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R8379[Dtype(RTCW(arg1))-1186])(arg1, tu4_1);
			loc1++;
		}
	}
	RTLE;
}

/* {KL_STRING_ROUTINES}.as_string */
EIF_REFERENCE F1204_10820 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1189, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = RTOUCR(98,F1192_10678, (Current));
		tr2 = RTOUCR(1358,F1204_10828, (Current));
		tb2 = F30_406(RTCW(tr1), arg1, tr2);
		tb1 = tb2;
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		loc2 = arg1;
		loc2 = RTRV(eif_new_type(2133, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			tr1 = F2134_25623(loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8498[Dtype(RTCW(arg1))-1188])(arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}/* NOTREACHED */
	
}

/* {KL_STRING_ROUTINES}.hexadecimal_to_integer */
EIF_INTEGER_32 F1204_10821 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		Result *= ((EIF_INTEGER_32) 16L);
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5880[Dtype(RTCW(arg1))-819])(arg1, loc1));
		switch (tc1) {
			case (EIF_CHARACTER_8) '0':
				break;
			case (EIF_CHARACTER_8) '1':
				Result++;
				break;
			case (EIF_CHARACTER_8) '2':
				Result += ((EIF_INTEGER_32) 2L);
				break;
			case (EIF_CHARACTER_8) '3':
				Result += ((EIF_INTEGER_32) 3L);
				break;
			case (EIF_CHARACTER_8) '4':
				Result += ((EIF_INTEGER_32) 4L);
				break;
			case (EIF_CHARACTER_8) '5':
				Result += ((EIF_INTEGER_32) 5L);
				break;
			case (EIF_CHARACTER_8) '6':
				Result += ((EIF_INTEGER_32) 6L);
				break;
			case (EIF_CHARACTER_8) '7':
				Result += ((EIF_INTEGER_32) 7L);
				break;
			case (EIF_CHARACTER_8) '8':
				Result += ((EIF_INTEGER_32) 8L);
				break;
			case (EIF_CHARACTER_8) '9':
				Result += ((EIF_INTEGER_32) 9L);
				break;
			case (EIF_CHARACTER_8) 'A':
			case (EIF_CHARACTER_8) 'a':
				Result += ((EIF_INTEGER_32) 10L);
				break;
			case (EIF_CHARACTER_8) 'B':
			case (EIF_CHARACTER_8) 'b':
				Result += ((EIF_INTEGER_32) 11L);
				break;
			case (EIF_CHARACTER_8) 'C':
			case (EIF_CHARACTER_8) 'c':
				Result += ((EIF_INTEGER_32) 12L);
				break;
			case (EIF_CHARACTER_8) 'D':
			case (EIF_CHARACTER_8) 'd':
				Result += ((EIF_INTEGER_32) 13L);
				break;
			case (EIF_CHARACTER_8) 'E':
			case (EIF_CHARACTER_8) 'e':
				Result += ((EIF_INTEGER_32) 14L);
				break;
			case (EIF_CHARACTER_8) 'F':
			case (EIF_CHARACTER_8) 'f':
				Result += ((EIF_INTEGER_32) 15L);
				break;
			default:
				RTEC(EN_WHEN);
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {KL_STRING_ROUTINES}.wipe_out */
void F1204_10824 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R8398[Dtype(RTCW(arg1))-1189])(arg1, ((EIF_INTEGER_32) 0L));
}

/* {KL_STRING_ROUTINES}.dummy_string */

EIF_REFERENCE F1204_10828 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1358,RTMS_EX_H("",0,0));
}

void EIF_Minit521 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
