
#ifndef _C1_lx49_
#define _C1_lx49_

#ifdef __cplusplus
extern "C" {
#endif

extern void F72_948(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit49(void);

#ifdef __cplusplus
}
#endif

#endif
