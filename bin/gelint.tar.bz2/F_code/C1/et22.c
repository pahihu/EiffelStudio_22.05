/*
 * Code for class ET_ECF_SETTING_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et22.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ECF_SETTING_NAMES}.absent_explicit_assertion_setting_name */

EIF_REFERENCE F26_320 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2297,RTMS_EX_H("absent_explicit_assertion",25,1492485742));
}

/* {ET_ECF_SETTING_NAMES}.address_expression_setting_name */

EIF_REFERENCE F26_321 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2298,RTMS_EX_H("address_expression",18,582140782));
}

/* {ET_ECF_SETTING_NAMES}.array_optimization_setting_name */

EIF_REFERENCE F26_322 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2299,RTMS_EX_H("array_optimization",18,887890542));
}

/* {ET_ECF_SETTING_NAMES}.automatic_backup_setting_name */

EIF_REFERENCE F26_323 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2300,RTMS_EX_H("automatic_backup",16,994296176));
}

/* {ET_ECF_SETTING_NAMES}.check_for_void_target_setting_name */

EIF_REFERENCE F26_324 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2301,RTMS_EX_H("check_for_void_target",21,1202472308));
}

/* {ET_ECF_SETTING_NAMES}.check_generic_creation_constraint_setting_name */

EIF_REFERENCE F26_325 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2302,RTMS_EX_H("check_generic_creation_constraint",33,76943988));
}

/* {ET_ECF_SETTING_NAMES}.check_vape_setting_name */

EIF_REFERENCE F26_326 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2303,RTMS_EX_H("check_vape",10,405013349));
}

/* {ET_ECF_SETTING_NAMES}.cls_compliant_setting_name */

EIF_REFERENCE F26_327 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2304,RTMS_EX_H("cls_compliant",13,823584116));
}

/* {ET_ECF_SETTING_NAMES}.concurrency_setting_name */

EIF_REFERENCE F26_328 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2305,RTMS_EX_H("concurrency",11,300205945));
}

/* {ET_ECF_SETTING_NAMES}.console_application_setting_name */

EIF_REFERENCE F26_329 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (358,RTMS_EX_H("console_application",19,375043438));
}

/* {ET_ECF_SETTING_NAMES}.dead_code_removal_setting_name */

EIF_REFERENCE F26_330 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2306,RTMS_EX_H("dead_code_removal",17,1064146540));
}

/* {ET_ECF_SETTING_NAMES}.dotnet_naming_convention_setting_name */

EIF_REFERENCE F26_331 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2307,RTMS_EX_H("dotnet_naming_convention",24,1299737966));
}

/* {ET_ECF_SETTING_NAMES}.dynamic_runtime_setting_name */

EIF_REFERENCE F26_332 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2308,RTMS_EX_H("dynamic_runtime",15,1723645541));
}

/* {ET_ECF_SETTING_NAMES}.enforce_unique_class_names_setting_name */

EIF_REFERENCE F26_333 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2309,RTMS_EX_H("enforce_unique_class_names",26,1541728115));
}

/* {ET_ECF_SETTING_NAMES}.exception_trace_setting_name */

EIF_REFERENCE F26_334 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (359,RTMS_EX_H("exception_trace",15,2042636389));
}

/* {ET_ECF_SETTING_NAMES}.finalize_setting_name */

EIF_REFERENCE F26_337 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2310,RTMS_EX_H("finalize",8,1220601701));
}

/* {ET_ECF_SETTING_NAMES}.force_32bits_setting_name */

EIF_REFERENCE F26_338 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2311,RTMS_EX_H("force_32bits",12,1670958451));
}

/* {ET_ECF_SETTING_NAMES}.full_type_checking_setting_name */

EIF_REFERENCE F26_339 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2312,RTMS_EX_H("full_type_checking",18,958781543));
}

/* {ET_ECF_SETTING_NAMES}.il_verifiable_setting_name */

EIF_REFERENCE F26_340 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2313,RTMS_EX_H("il_verifiable",13,1528054629));
}

/* {ET_ECF_SETTING_NAMES}.inlining_setting_name */

EIF_REFERENCE F26_341 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2314,RTMS_EX_H("inlining",8,1620076135));
}

/* {ET_ECF_SETTING_NAMES}.inlining_size_setting_name */

EIF_REFERENCE F26_342 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2315,RTMS_EX_H("inlining_size",13,1191342437));
}

/* {ET_ECF_SETTING_NAMES}.java_generation_setting_name */

EIF_REFERENCE F26_343 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2316,RTMS_EX_H("java_generation",15,436362606));
}

/* {ET_ECF_SETTING_NAMES}.library_root_setting_name */

EIF_REFERENCE F26_344 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (364,RTMS_EX_H("library_root",12,550974580));
}

/* {ET_ECF_SETTING_NAMES}.line_generation_setting_name */

EIF_REFERENCE F26_345 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2317,RTMS_EX_H("line_generation",15,444800878));
}

/* {ET_ECF_SETTING_NAMES}.manifest_array_type_setting_name */

EIF_REFERENCE F26_346 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2318,RTMS_EX_H("manifest_array_type",19,1326410085));
}

/* {ET_ECF_SETTING_NAMES}.msil_generation_setting_name */

EIF_REFERENCE F26_352 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2296,RTMS_EX_H("msil_generation",15,2084028270));
}

/* {ET_ECF_SETTING_NAMES}.msil_generation_type_setting_name */

EIF_REFERENCE F26_353 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2319,RTMS_EX_H("msil_generation_type",20,404540773));
}

/* {ET_ECF_SETTING_NAMES}.msil_use_optimized_precompile_setting_name */

EIF_REFERENCE F26_355 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2320,RTMS_EX_H("msil_use_optimized_precompile",29,154263397));
}

/* {ET_ECF_SETTING_NAMES}.multithreaded_setting_name */

EIF_REFERENCE F26_356 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2321,RTMS_EX_H("multithreaded",13,1599663972));
}

/* {ET_ECF_SETTING_NAMES}.old_feature_replication_setting_name */

EIF_REFERENCE F26_357 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2322,RTMS_EX_H("old_feature_replication",23,660525166));
}

/* {ET_ECF_SETTING_NAMES}.old_verbatim_strings_setting_name */

EIF_REFERENCE F26_358 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2323,RTMS_EX_H("old_verbatim_strings",20,301586803));
}

/* {ET_ECF_SETTING_NAMES}.total_order_on_reals_setting_name */

EIF_REFERENCE F26_361 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (360,RTMS_EX_H("total_order_on_reals",20,243982195));
}

/* {ET_ECF_SETTING_NAMES}.use_all_cluster_name_as_namespace_setting_name */

EIF_REFERENCE F26_362 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2324,RTMS_EX_H("use_all_cluster_name_as_namespace",33,659613541));
}

/* {ET_ECF_SETTING_NAMES}.use_cluster_name_as_namespace_setting_name */

EIF_REFERENCE F26_363 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2325,RTMS_EX_H("use_cluster_name_as_namespace",29,815842661));
}

/* {ET_ECF_SETTING_NAMES}.all_setting_value */

EIF_REFERENCE F26_364 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2326,RTMS_EX_H("all",3,6384748));
}

/* {ET_ECF_SETTING_NAMES}.default_setting_value */

EIF_REFERENCE F26_365 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2327,RTMS_EX_H("default",7,626575476));
}

/* {ET_ECF_SETTING_NAMES}.exe_setting_value */

EIF_REFERENCE F26_367 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2328,RTMS_EX_H("exe",3,6649957));
}

/* {ET_ECF_SETTING_NAMES}.false_setting_value */

EIF_REFERENCE F26_368 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2329,RTMS_EX_H("false",5,1635280741));
}

/* {ET_ECF_SETTING_NAMES}.feature_setting_value */

EIF_REFERENCE F26_369 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2330,RTMS_EX_H("feature",7,1951938661));
}

/* {ET_ECF_SETTING_NAMES}.finalize_setting_value */

EIF_REFERENCE F26_370 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2331,RTMS_EX_H("finalize",8,1220601701));
}

/* {ET_ECF_SETTING_NAMES}.none_setting_value */

EIF_REFERENCE F26_374 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2332,RTMS_EX_H("none",4,1852796517));
}

/* {ET_ECF_SETTING_NAMES}.true_setting_value */

EIF_REFERENCE F26_378 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2333,RTMS_EX_H("true",4,1953658213));
}

/* {ET_ECF_SETTING_NAMES}.unix_setting_value */

EIF_REFERENCE F26_379 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2334,RTMS_EX_H("unix",4,1970170232));
}

/* {ET_ECF_SETTING_NAMES}.windows_setting_value */

EIF_REFERENCE F26_381 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2335,RTMS_EX_H("windows",7,1657536371));
}

/* {ET_ECF_SETTING_NAMES}.workbench_setting_value */

EIF_REFERENCE F26_382 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2336,RTMS_EX_H("workbench",9,1911020904));
}

void EIF_Minit22 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
