
#ifndef _C1_ut32_
#define _C1_ut32_

#ifdef __cplusplus
extern "C" {
#endif

extern void F36_451(EIF_REFERENCE, EIF_INTEGER_32);
extern void F36_454(EIF_REFERENCE);
extern void EIF_Minit32(void);

#ifdef __cplusplus
}
#endif

#endif
