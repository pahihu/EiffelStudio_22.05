
#ifndef _C1_et46_
#define _C1_et46_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F69_937(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit46(void);
extern void F1295_12758(EIF_REFERENCE);
extern void F1296_12914(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
