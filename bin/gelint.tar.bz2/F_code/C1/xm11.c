/*
 * Code for class XM_EIFFEL_DECLARATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm11.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_DECLARATION}.make */
void F11_110 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(2588,F11_111, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(2589,F11_112, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) EIF_TRUE;
	RTLE;
}

/* {XM_EIFFEL_DECLARATION}.default_version */

EIF_REFERENCE F11_111 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2588,RTMS_EX_H("1.0",3,3223088));
}

/* {XM_EIFFEL_DECLARATION}.default_encoding */

EIF_REFERENCE F11_112 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2589,RTMS_EX_H("utf-8",5,1953751864));
}

/* {XM_EIFFEL_DECLARATION}.set_version */
void F11_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {XM_EIFFEL_DECLARATION}.set_encoding */
void F11_118 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {XM_EIFFEL_DECLARATION}.set_stand_alone */
void F11_119 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) arg1;
}

/* {XM_EIFFEL_DECLARATION}.process */
void F11_120 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R2688[Dtype(RTCW(arg1))-275])(arg1, *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_1_), *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_));
}

void EIF_Minit11 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
