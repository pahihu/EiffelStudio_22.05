
#ifndef _C1_is43_
#define _C1_is43_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F54_741(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F54_746(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F54_748(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F54_756(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit43(void);

#ifdef __cplusplus
}
#endif

#endif
