/*
 * Code for class RX_CHARACTER_SET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rx13.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RX_CHARACTER_SET}.make_empty */
void F13_129 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {RX_CHARACTER_SET}.make */
void F13_130 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F13_129(Current);
	F13_136(Current, arg1);
	RTLE;
}

/* {RX_CHARACTER_SET}.has */
EIF_BOOLEAN F13_133 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_64 tu8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		Result = '\0';
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_)) {
			tr1 = RTLNS(eif_new_type(2044, 0x01).id, 2044, _OBJSIZ_0_0_0_0_0_0_0_0_);
			Result = F2045_20649(RTCW(tr1), arg1);
		}
	} else {
		if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L))) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_);
			tr1 = RTOUCR(2575,F13_147, (Current));
			ti4_1 = (EIF_INTEGER_32) arg1;
			/* INLINED CODE (SPECIAL.item) */
			tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
			/* END INLINED CODE */
			tu8_2 = tu8_3;
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
		} else {
			if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L))) {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_);
				tr1 = RTOUCR(2575,F13_147, (Current));
				ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
				/* INLINED CODE (SPECIAL.item) */
				tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
				/* END INLINED CODE */
				tu8_2 = tu8_3;
				tu8_1 = eif_bit_and(tu8_1,tu8_2);
				Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
			} else {
				if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 192L))) {
					tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_);
					tr1 = RTOUCR(2575,F13_147, (Current));
					ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
					/* INLINED CODE (SPECIAL.item) */
					tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
					/* END INLINED CODE */
					tu8_2 = tu8_3;
					tu8_1 = eif_bit_and(tu8_1,tu8_2);
					Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
				} else {
					if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 256L))) {
						tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_);
						tr1 = RTOUCR(2575,F13_147, (Current));
						ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
						/* INLINED CODE (SPECIAL.item) */
						tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
						/* END INLINED CODE */
						tu8_2 = tu8_3;
						tu8_1 = eif_bit_and(tu8_1,tu8_2);
						Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
					} else {
						loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) (arg1 / (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L));
						tb1 = '\0';
						tr1 = *(EIF_REFERENCE *)(Current);
						loc2 = tr1;
						if (EIF_TEST(loc2)) {
							tb2 = F1555_14139(loc2, loc1);
							tb1 = tb2;
						}
						if (tb1) {
							tu8_1 = F1555_14131(loc2, loc1);
							tr1 = RTOUCR(2575,F13_147, (Current));
							ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
							/* INLINED CODE (SPECIAL.item) */
							tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
							/* END INLINED CODE */
							tu8_2 = tu8_3;
							tu8_1 = eif_bit_and(tu8_1,tu8_2);
							Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
						} else {
							Result = '\0';
							if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) != *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_))) {
								tr1 = RTLNS(eif_new_type(2044, 0x01).id, 2044, _OBJSIZ_0_0_0_0_0_0_0_0_);
								Result = F2045_20649(RTCW(tr1), arg1);
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {RX_CHARACTER_SET}.set_negated */
void F13_135 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) arg1;
}

/* {RX_CHARACTER_SET}.add_string */
void F13_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8319[Dtype(RTCW(arg1))-1185])(arg1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8282[Dtype(RTCW(arg1))-1185])(arg1, loc1);
		F13_137(Current, tu4_1);
		loc1++;
	}
	RTLE;
}

/* {RX_CHARACTER_SET}.add_character */
void F13_137 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_64 tu8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L))) {
		tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_);
		tr1 = RTOUCR(2575,F13_147, (Current));
		ti4_1 = (EIF_INTEGER_32) arg1;
		/* INLINED CODE (SPECIAL.item) */
		tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
		/* END INLINED CODE */
		tu8_2 = tu8_3;
		tu8_1 = eif_bit_or(tu8_1,tu8_2);
		*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_) = (EIF_NATURAL_64) tu8_1;
	} else {
		if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L))) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_);
			tr1 = RTOUCR(2575,F13_147, (Current));
			ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
			/* INLINED CODE (SPECIAL.item) */
			tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
			/* END INLINED CODE */
			tu8_2 = tu8_3;
			tu8_1 = eif_bit_or(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_) = (EIF_NATURAL_64) tu8_1;
		} else {
			if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 192L))) {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_);
				tr1 = RTOUCR(2575,F13_147, (Current));
				ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
				/* INLINED CODE (SPECIAL.item) */
				tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
				/* END INLINED CODE */
				tu8_2 = tu8_3;
				tu8_1 = eif_bit_or(tu8_1,tu8_2);
				*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_) = (EIF_NATURAL_64) tu8_1;
			} else {
				if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 256L))) {
					tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_);
					tr1 = RTOUCR(2575,F13_147, (Current));
					ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
					/* INLINED CODE (SPECIAL.item) */
					tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
					/* END INLINED CODE */
					tu8_2 = tu8_3;
					tu8_1 = eif_bit_or(tu8_1,tu8_2);
					*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_) = (EIF_NATURAL_64) tu8_1;
				} else {
					loc2 = (EIF_NATURAL_32) (EIF_NATURAL_32) (arg1 / (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L));
					loc1 = *(EIF_REFERENCE *)(Current);
					if ((EIF_BOOLEAN)(loc1 == NULL)) {
						if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_)) {
							{
								static EIF_TYPE_INDEX typarr0[] = {1570,1105,1108,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
								loc1 = RTLNSMART(typres0.id);
							}
							F1555_14126(RTCW(loc1), ((EIF_INTEGER_32) 50L));
							RTAR(Current, loc1);
							*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
						}
					} else {
						tb1 = '\0';
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_)) {
							tb2 = F1555_14139(RTCW(loc1), loc2);
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) {
							loc1 = (EIF_REFERENCE) NULL;
						}
					}
					if ((EIF_BOOLEAN)(loc1 != NULL)) {
						tu8_1 = F1555_14132(RTCW(loc1), loc2);
						tr1 = RTOUCR(2575,F13_147, (Current));
						ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
						/* INLINED CODE (SPECIAL.item) */
						tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
						/* END INLINED CODE */
						tu8_2 = tu8_3;
						tu8_1 = eif_bit_or(tu8_1,tu8_2);
						F1555_14151(RTCW(loc1), tu8_1, loc2);
					}
				}
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {RX_CHARACTER_SET}.add_set */
void F13_138 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTGC;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_0_);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_1_);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_2_);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_3_);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_) = (EIF_NATURAL_64) tu8_1;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tb2 = F1437_13475(loc4);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc2 = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_);
		loc3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_2_);
		loc1 = *(EIF_REFERENCE *)(Current);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			if ((EIF_BOOLEAN) !loc2) {
				tr1 = F1_14(loc4);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) loc3;
			}
		} else {
			tb1 = F1437_13475(RTCW(loc1));
			if (tb1) {
				if ((EIF_BOOLEAN) !loc2) {
					F1555_14155(RTCW(loc1), loc4);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) loc3;
				}
			} else {
				if (loc3) {
					F1470_13535(RTCW(loc1));
					for (;;) {
						tb1 = F1470_13532(RTCW(loc1));
						if (tb1) break;
						tu4_1 = F1555_14135(RTCW(loc1));
						tb2 = F1555_14139(loc4, tu4_1);
						if ((EIF_BOOLEAN) !tb2) {
							tu4_1 = F1555_14135(RTCW(loc1));
							F1548_14053(RTCW(loc1), tu4_1);
						} else {
							F1470_13536(RTCW(loc1));
						}
					}
				}
				loc5 = F1470_13530(loc4);
				for (;;) {
					tb2 = F1374_13215(loc5);
					if (tb2) break;
					tu4_1 = F1381_13228(loc5);
					F1555_14142(RTCW(loc1), tu4_1);
					tb3 = F1548_14041(RTCW(loc1));
					if (tb3) {
						tu8_1 = F1548_14033(RTCW(loc1));
						tu8_2 = F1322_13167(loc5);
						tu8_1 = eif_bit_or(tu8_1,tu8_2);
						F1555_14146(RTCW(loc1), tu8_1);
					} else {
						if ((EIF_BOOLEAN) !loc2) {
							tu8_1 = F1322_13167(loc5);
							tu4_1 = F1381_13228(loc5);
							F1555_14152(RTCW(loc1), tu8_1, tu4_1);
						}
					}
					F1340_13188(loc5);
				}
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || loc3);
			}
		}
	} else {
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_2_);
		if (tb3) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = *(EIF_REFERENCE *)(Current);
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				F1548_14055(loc6);
			}
		}
	}
	tb3 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		tb4 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
		tb3 = tb4;
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) tb3;
	RTLE;
}

/* {RX_CHARACTER_SET}.add_negated_set */
void F13_139 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,loc8);
	RTLIU(9);
	
	RTGC;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_0_);
	tu8_2 = eif_bit_not(tu8_2);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_1_);
	tu8_2 = eif_bit_not(tu8_2);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_2_);
	tu8_2 = eif_bit_not(tu8_2);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_3_);
	tu8_2 = eif_bit_not(tu8_2);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_) = (EIF_NATURAL_64) tu8_1;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tb2 = F1437_13475(loc4);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc2 = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_);
		loc3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_2_);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc3;
		loc1 = *(EIF_REFERENCE *)(Current);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			if ((EIF_BOOLEAN) !loc2) {
				loc1 = F1_14(loc4);
				F1470_13535(RTCW(loc1));
				for (;;) {
					tb1 = F1470_13532(RTCW(loc1));
					if (tb1) break;
					tu8_1 = F1456_13506(RTCW(loc1));
					tu8_1 = eif_bit_not(tu8_1);
					tu4_1 = F1555_14135(RTCW(loc1));
					F1555_14145(RTCW(loc1), tu8_1, tu4_1);
					F1470_13536(RTCW(loc1));
				}
				RTAR(Current, loc1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) loc3;
			}
		} else {
			tb2 = F1437_13475(RTCW(loc1));
			if (tb2) {
				if ((EIF_BOOLEAN) !loc2) {
					F1555_14155(RTCW(loc1), loc4);
					F1470_13535(RTCW(loc1));
					for (;;) {
						tb2 = F1470_13532(RTCW(loc1));
						if (tb2) break;
						tu8_1 = F1456_13506(RTCW(loc1));
						tu8_1 = eif_bit_not(tu8_1);
						tu4_1 = F1555_14135(RTCW(loc1));
						F1555_14145(RTCW(loc1), tu8_1, tu4_1);
						F1470_13536(RTCW(loc1));
					}
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) loc3;
				}
			} else {
				if (loc3) {
					F1470_13535(RTCW(loc1));
					for (;;) {
						tb3 = F1470_13532(RTCW(loc1));
						if (tb3) break;
						tu4_1 = F1555_14135(RTCW(loc1));
						tb4 = F1555_14139(loc4, tu4_1);
						if ((EIF_BOOLEAN) !tb4) {
							tu4_1 = F1555_14135(RTCW(loc1));
							F1548_14053(RTCW(loc1), tu4_1);
						} else {
							F1470_13536(RTCW(loc1));
						}
					}
				}
				loc5 = F1470_13530(loc4);
				for (;;) {
					tb4 = F1374_13215(loc5);
					if (tb4) break;
					tu4_1 = F1381_13228(loc5);
					F1555_14142(RTCW(loc1), tu4_1);
					tb5 = F1548_14041(RTCW(loc1));
					if (tb5) {
						tu8_1 = F1548_14033(RTCW(loc1));
						tu8_2 = F1322_13167(loc5);
						tu8_2 = eif_bit_not(tu8_2);
						tu8_1 = eif_bit_or(tu8_1,tu8_2);
						F1555_14146(RTCW(loc1), tu8_1);
					} else {
						if ((EIF_BOOLEAN) !loc2) {
							tu8_1 = F1322_13167(loc5);
							tu8_1 = eif_bit_not(tu8_1);
							tu4_1 = F1381_13228(loc5);
							F1555_14152(RTCW(loc1), tu8_1, tu4_1);
						}
					}
					F1340_13188(loc5);
				}
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || loc3);
			}
		}
	} else {
		tb5 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_2_);
		if ((EIF_BOOLEAN) !tb5) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = *(EIF_REFERENCE *)(Current);
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				F1548_14055(loc6);
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_) != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_) != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L))) || (EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_) != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L))) || (EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_) != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)))) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			tb5 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				tb6 = F1437_13475(loc7);
				tb5 = (EIF_BOOLEAN) !tb6;
			}
			if (tb5) {
				tb5 = '\01';
				if (!(EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_)) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_11_0_0_8_);
					tb5 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 17372L));
				}
				if (tb5) {
					loc8 = F1470_13530(loc7);
					tb5 = EIF_TRUE;
					for (;;) {
						if (!tb5) break;
						tb6 = F1374_13215(loc8);
						if (tb6) break;
						tu8_1 = F1322_13167(loc8);
						tb5 = (EIF_BOOLEAN)(tu8_1 == (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
						F1340_13188(loc8);
					}
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) tb5;
				} else {
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_);
			}
		}
	}
	RTLE;
}

/* {RX_CHARACTER_SET}.masks */
static EIF_REFERENCE F13_147_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 loc2 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2575)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,906,1105,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 64L),sizeof(EIF_NATURAL_64), EIF_TRUE);
	}
	F907_7138(RTCW(tr1), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 64L));
	Result = (EIF_REFERENCE) tr1;
	loc2 = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_INTEGER_32) 1L);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_64 *)RTCW(Result) + (((EIF_INTEGER_32) 0L))) = loc2;
	/* END INLINED CODE */
	;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 64L))) break;
		tu8_1 = eif_bit_shift_left(loc2,((EIF_INTEGER_32) 1L));
		loc2 = (EIF_NATURAL_64) tu8_1;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_64 *)RTCW(Result) + (loc1)) = loc2;
		/* END INLINED CODE */
		;
		loc1++;
	}
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F13_147 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2575,F13_147_body,(Current));
}

void EIF_Minit13 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
