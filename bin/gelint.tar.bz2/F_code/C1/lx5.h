
#ifndef _C1_lx5_
#define _C1_lx5_

#ifdef __cplusplus
extern "C" {
#endif

extern void F5_39(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN);
extern void F5_47(EIF_REFERENCE, EIF_REFERENCE);
extern void F5_48(EIF_REFERENCE, EIF_REFERENCE);
extern void F5_49(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit5(void);
extern void F1539_13942(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1539_13966(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
