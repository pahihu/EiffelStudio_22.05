
#ifndef _C1_st45_
#define _C1_st45_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F68_857_body(EIF_REFERENCE);
extern EIF_REFERENCE F68_857(EIF_REFERENCE);
static EIF_REFERENCE F68_858_body(EIF_REFERENCE);
extern EIF_REFERENCE F68_858(EIF_REFERENCE);
static EIF_REFERENCE F68_859_body(EIF_REFERENCE);
extern EIF_REFERENCE F68_859(EIF_REFERENCE);
extern void F68_885(EIF_REFERENCE);
extern void F68_927(EIF_REFERENCE);
extern void EIF_Minit45(void);
extern void F1268_12145(EIF_REFERENCE, EIF_REFERENCE);
extern void F1268_12144(EIF_REFERENCE, EIF_REFERENCE);
extern void F1268_12146(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5389[])();

#ifdef __cplusplus
}
#endif

#endif
