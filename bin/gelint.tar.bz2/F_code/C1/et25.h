
#ifndef _C1_et25_
#define _C1_et25_

#ifdef __cplusplus
extern "C" {
#endif

extern void F29_397(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F29_405(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit25(void);

#ifdef __cplusplus
}
#endif

#endif
