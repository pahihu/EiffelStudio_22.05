
#ifndef _C1_et12_
#define _C1_et12_

#ifdef __cplusplus
extern "C" {
#endif

extern void F12_121(EIF_REFERENCE, EIF_REFERENCE);
extern void F12_126(EIF_REFERENCE, EIF_REFERENCE);
extern void F12_127(EIF_REFERENCE, EIF_REFERENCE);
extern void F12_128(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit12(void);

#ifdef __cplusplus
}
#endif

#endif
