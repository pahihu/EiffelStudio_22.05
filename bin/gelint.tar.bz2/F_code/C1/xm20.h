
#ifndef _C1_xm20_
#define _C1_xm20_

#ifdef __cplusplus
extern "C" {
#endif

extern void F24_265(EIF_REFERENCE);
extern EIF_BOOLEAN F24_266(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F24_267(EIF_REFERENCE, EIF_REFERENCE);
extern void F24_268(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit20(void);
extern void F1337_13187(EIF_REFERENCE);
extern void F1337_13190(EIF_REFERENCE);
extern EIF_REFERENCE F1414_13275(EIF_REFERENCE);
extern void F1512_13706(EIF_REFERENCE);
extern void F1337_13188(EIF_REFERENCE);
extern void F245_2387(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R10853[])();
extern char *(*R10794[])();

#ifdef __cplusplus
}
#endif

#endif
