/*
 * Code for class ET_ECF_OPTION_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et21.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ECF_OPTION_NAMES}.assertions_check_option_name */

EIF_REFERENCE F25_270 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2354,RTMS_EX_H("check",5,1752235371));
}

/* {ET_ECF_OPTION_NAMES}.assertions_invariant_option_name */

EIF_REFERENCE F25_271 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2355,RTMS_EX_H("invariant",9,997544820));
}

/* {ET_ECF_OPTION_NAMES}.assertions_loop_option_name */

EIF_REFERENCE F25_272 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2356,RTMS_EX_H("loop",4,1819242352));
}

/* {ET_ECF_OPTION_NAMES}.assertions_postcondition_option_name */

EIF_REFERENCE F25_273 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2357,RTMS_EX_H("postcondition",13,29888366));
}

/* {ET_ECF_OPTION_NAMES}.assertions_precondition_option_name */

EIF_REFERENCE F25_274 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2358,RTMS_EX_H("precondition",12,694692206));
}

/* {ET_ECF_OPTION_NAMES}.assertions_supplier_precondition_option_name */

EIF_REFERENCE F25_275 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2359,RTMS_EX_H("supplier_precondition",21,1130264430));
}

/* {ET_ECF_OPTION_NAMES}.cat_call_detection_option_name */

EIF_REFERENCE F25_276 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2390,RTMS_EX_H("cat_call_detection",18,407749998));
}

/* {ET_ECF_OPTION_NAMES}.debug_option_name */

EIF_REFERENCE F25_277 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2360,RTMS_EX_H("debug",5,1701719399));
}

/* {ET_ECF_OPTION_NAMES}.full_class_checking_option_name */

EIF_REFERENCE F25_278 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2362,RTMS_EX_H("full_class_checking",19,821682023));
}

/* {ET_ECF_OPTION_NAMES}.is_attached_by_default_option_name */

EIF_REFERENCE F25_279 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (361,RTMS_EX_H("is_attached_by_default",22,1750772596));
}

/* {ET_ECF_OPTION_NAMES}.is_obsolete_routine_type_option_name */

EIF_REFERENCE F25_280 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (362,RTMS_EX_H("is_obsolete_routine_type",24,1942807653));
}

/* {ET_ECF_OPTION_NAMES}.is_void_safe_option_name */

EIF_REFERENCE F25_281 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2391,RTMS_EX_H("is_void_safe",12,1531546981));
}

/* {ET_ECF_OPTION_NAMES}.manifest_array_type_option_name */

EIF_REFERENCE F25_282 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2364,RTMS_EX_H("manifest_array_type",19,1326410085));
}

/* {ET_ECF_OPTION_NAMES}.msil_application_optimize_option_name */

EIF_REFERENCE F25_283 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2366,RTMS_EX_H("msil_application_optimize",25,667769189));
}

/* {ET_ECF_OPTION_NAMES}.optimize_option_name */

EIF_REFERENCE F25_285 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2367,RTMS_EX_H("optimize",8,479566181));
}

/* {ET_ECF_OPTION_NAMES}.profile_option_name */

EIF_REFERENCE F25_286 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2368,RTMS_EX_H("profile",7,332661605));
}

/* {ET_ECF_OPTION_NAMES}.syntax_option_name */

EIF_REFERENCE F25_287 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2369,RTMS_EX_H("syntax",6,2080149368));
}

/* {ET_ECF_OPTION_NAMES}.syntax_level_option_name */

EIF_REFERENCE F25_288 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2392,RTMS_EX_H("syntax_level",12,1690338668));
}

/* {ET_ECF_OPTION_NAMES}.trace_option_name */

EIF_REFERENCE F25_289 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (363,RTMS_EX_H("trace",5,1919875941));
}

/* {ET_ECF_OPTION_NAMES}.void_safety_option_name */

EIF_REFERENCE F25_290 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2393,RTMS_EX_H("void_safety",11,1966795897));
}

/* {ET_ECF_OPTION_NAMES}.warning_option_name */

EIF_REFERENCE F25_291 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2370,RTMS_EX_H("warning",7,1809215079));
}

/* {ET_ECF_OPTION_NAMES}.warning_export_class_missing_option_name */

EIF_REFERENCE F25_292 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2372,RTMS_EX_H("export_class_missing",20,2052986983));
}

/* {ET_ECF_OPTION_NAMES}.warning_manifest_array_type_name */

EIF_REFERENCE F25_293 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2373,RTMS_EX_H("manifest_array_type",19,1326410085));
}

/* {ET_ECF_OPTION_NAMES}.warning_obsolete_class_option_name */

EIF_REFERENCE F25_294 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2374,RTMS_EX_H("obsolete_class",14,1102600563));
}

/* {ET_ECF_OPTION_NAMES}.warning_obsolete_feature_option_name */

EIF_REFERENCE F25_295 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2375,RTMS_EX_H("obsolete_feature",16,995561829));
}

/* {ET_ECF_OPTION_NAMES}.warning_old_verbatim_strings_option_name */

EIF_REFERENCE F25_296 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2376,RTMS_EX_H("old_verbatim_strings",20,301586803));
}

/* {ET_ECF_OPTION_NAMES}.warning_once_in_generic_option_name */

EIF_REFERENCE F25_297 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2377,RTMS_EX_H("once_in_generic",15,384858723));
}

/* {ET_ECF_OPTION_NAMES}.warning_option_unknown_class_option_name */

EIF_REFERENCE F25_298 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2378,RTMS_EX_H("option_unknown_class",20,2049985907));
}

/* {ET_ECF_OPTION_NAMES}.warning_renaming_unknown_class_option_name */

EIF_REFERENCE F25_299 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2379,RTMS_EX_H("renaming_unknown_class",22,527017075));
}

/* {ET_ECF_OPTION_NAMES}.warning_same_uuid_option_name */

EIF_REFERENCE F25_300 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2380,RTMS_EX_H("same_uuid",9,1559839332));
}

/* {ET_ECF_OPTION_NAMES}.warning_syntax_option_name */

EIF_REFERENCE F25_301 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2381,RTMS_EX_H("syntax",6,2080149368));
}

/* {ET_ECF_OPTION_NAMES}.warning_unused_local_option_name */

EIF_REFERENCE F25_302 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2382,RTMS_EX_H("unused_local",12,2107775852));
}

/* {ET_ECF_OPTION_NAMES}.warning_vjrv_option_name */

EIF_REFERENCE F25_303 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2383,RTMS_EX_H("vjrv",4,1986687606));
}

/* {ET_ECF_OPTION_NAMES}.warning_vwab_option_name */

EIF_REFERENCE F25_304 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2384,RTMS_EX_H("vwab",4,1987535202));
}

/* {ET_ECF_OPTION_NAMES}.warning_vweq_option_name */

EIF_REFERENCE F25_305 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2385,RTMS_EX_H("vweq",4,1987536241));
}

/* {ET_ECF_OPTION_NAMES}.all_option_value */

EIF_REFERENCE F25_306 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2394,RTMS_EX_H("all",3,6384748));
}

/* {ET_ECF_OPTION_NAMES}.false_option_value */

EIF_REFERENCE F25_309 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2361,RTMS_EX_H("false",5,1635280741));
}

/* {ET_ECF_OPTION_NAMES}.mismatch_warning_option_value */

EIF_REFERENCE F25_312 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2386,RTMS_EX_H("mismatch_warning",16,1759222119));
}

/* {ET_ECF_OPTION_NAMES}.none_option_value */

EIF_REFERENCE F25_313 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2371,RTMS_EX_H("none",4,1852796517));
}

/* {ET_ECF_OPTION_NAMES}.obsolete_option_value */

EIF_REFERENCE F25_314 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2388,RTMS_EX_H("obsolete",8,2004093797));
}

/* {ET_ECF_OPTION_NAMES}.standard_option_value */

EIF_REFERENCE F25_316 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2365,RTMS_EX_H("standard",8,157435492));
}

/* {ET_ECF_OPTION_NAMES}.transitional_option_value */

EIF_REFERENCE F25_317 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2387,RTMS_EX_H("transitional",12,1290118508));
}

/* {ET_ECF_OPTION_NAMES}.true_option_value */

EIF_REFERENCE F25_318 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2363,RTMS_EX_H("true",4,1953658213));
}

/* {ET_ECF_OPTION_NAMES}.warning_option_value */

EIF_REFERENCE F25_319 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2395,RTMS_EX_H("warning",7,1809215079));
}

void EIF_Minit21 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
