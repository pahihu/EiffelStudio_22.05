
#ifndef _C1_ut31_
#define _C1_ut31_

#ifdef __cplusplus
extern "C" {
#endif

extern void F35_442(EIF_REFERENCE);
extern EIF_BOOLEAN F35_444(EIF_REFERENCE);
extern void F35_447(EIF_REFERENCE);
extern void F35_448(EIF_REFERENCE);
extern void EIF_Minit31(void);

#ifdef __cplusplus
}
#endif

#endif
