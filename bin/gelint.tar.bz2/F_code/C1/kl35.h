
#ifndef _C1_kl35_
#define _C1_kl35_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F46_606_body(EIF_REFERENCE);
extern EIF_REFERENCE F46_606(EIF_REFERENCE);
static EIF_REFERENCE F46_607_body(EIF_REFERENCE);
extern EIF_REFERENCE F46_607(EIF_REFERENCE);
static EIF_REFERENCE F46_608_body(EIF_REFERENCE);
extern EIF_REFERENCE F46_608(EIF_REFERENCE);
extern void EIF_Minit35(void);
extern void F1229_11095(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
