/*
 * Code for class ET_SYSTEM_PROCESSOR_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et46.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_SYSTEM_PROCESSOR_FACTORY}.new_system_processor */
EIF_REFERENCE F69_937 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 1L))) {
		tb1 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_thread_capable__b;
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(1295, 0x01).id, 1295, _OBJSIZ_17_21_0_2_0_0_0_0_);
		F1296_12914(RTCW(tr1), arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(1294, 0x01).id, 1294, _OBJSIZ_16_21_0_2_0_0_0_0_);
		F1295_12758(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

void EIF_Minit46 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
