/*
 * Code for class ET_ECF_CAPABILITY_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et37.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ECF_CAPABILITY_NAMES}.catcall_detection_capability_name */

EIF_REFERENCE F48_644 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (59,RTMS_EX_H("catcall_detection",17,492669806));
}

/* {ET_ECF_CAPABILITY_NAMES}.concurrency_capability_name */

EIF_REFERENCE F48_645 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (62,RTMS_EX_H("concurrency",11,300205945));
}

/* {ET_ECF_CAPABILITY_NAMES}.void_safety_capability_name */

EIF_REFERENCE F48_646 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (65,RTMS_EX_H("void_safety",11,1966795897));
}

/* {ET_ECF_CAPABILITY_NAMES}.all_capability_value */

EIF_REFERENCE F48_647 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (58,RTMS_EX_H("all",3,6384748));
}

/* {ET_ECF_CAPABILITY_NAMES}.conformance_capability_value */

EIF_REFERENCE F48_648 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (57,RTMS_EX_H("conformance",11,1508810597));
}

/* {ET_ECF_CAPABILITY_NAMES}.initialization_capability_value */

EIF_REFERENCE F48_649 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (63,RTMS_EX_H("initialization",14,1686604654));
}

/* {ET_ECF_CAPABILITY_NAMES}.none_capability_value */

EIF_REFERENCE F48_650 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (56,RTMS_EX_H("none",4,1852796517));
}

/* {ET_ECF_CAPABILITY_NAMES}.scoop_capability_value */

EIF_REFERENCE F48_651 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (61,RTMS_EX_H("scoop",5,1669130608));
}

/* {ET_ECF_CAPABILITY_NAMES}.thread_capability_value */

EIF_REFERENCE F48_652 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (60,RTMS_EX_H("thread",6,630884));
}

/* {ET_ECF_CAPABILITY_NAMES}.transitional_capability_value */

EIF_REFERENCE F48_653 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (64,RTMS_EX_H("transitional",12,1290118508));
}

/* {ET_ECF_CAPABILITY_NAMES}.value_separators */

EIF_REFERENCE F48_655 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (349,RTMS_EX_H(" ",1,32));
}

void EIF_Minit37 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
