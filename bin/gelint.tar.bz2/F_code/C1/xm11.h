
#ifndef _C1_xm11_
#define _C1_xm11_

#ifdef __cplusplus
extern "C" {
#endif

extern void F11_110(EIF_REFERENCE);
extern EIF_REFERENCE F11_111(EIF_REFERENCE);
extern EIF_REFERENCE F11_112(EIF_REFERENCE);
extern void F11_117(EIF_REFERENCE, EIF_REFERENCE);
extern void F11_118(EIF_REFERENCE, EIF_REFERENCE);
extern void F11_119(EIF_REFERENCE, EIF_BOOLEAN);
extern void F11_120(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit11(void);
extern char *(*R2688[])();

#ifdef __cplusplus
}
#endif

#endif
