
#ifndef _C1_et24_
#define _C1_et24_

#ifdef __cplusplus
extern "C" {
#endif

extern void F28_393(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F28_394(EIF_REFERENCE);
extern void EIF_Minit24(void);
extern EIF_BOOLEAN F1182_10292(EIF_REFERENCE);
extern EIF_BOOLEAN F1188_10551(EIF_REFERENCE);
extern EIF_REFERENCE F1248_11722(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F26_352(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
