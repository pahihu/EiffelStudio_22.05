
#ifndef _C1_dt38_
#define _C1_dt38_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F49_656_body(EIF_REFERENCE);
extern EIF_REFERENCE F49_656(EIF_REFERENCE);
extern void EIF_Minit38(void);

#ifdef __cplusplus
}
#endif

#endif
