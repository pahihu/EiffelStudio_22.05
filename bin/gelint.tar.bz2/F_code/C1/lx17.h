
#ifndef _C1_lx17_
#define _C1_lx17_

#ifdef __cplusplus
extern "C" {
#endif

extern void F21_189(EIF_REFERENCE);
extern void F21_219(EIF_REFERENCE, EIF_BOOLEAN);
extern void F21_220(EIF_REFERENCE, EIF_INTEGER_32);
extern void F21_223(EIF_REFERENCE, EIF_BOOLEAN);
extern void F21_224(EIF_REFERENCE, EIF_BOOLEAN);
extern void F21_225(EIF_REFERENCE, EIF_BOOLEAN);
extern void F21_252(EIF_REFERENCE, EIF_REFERENCE);
extern void F21_253(EIF_REFERENCE, EIF_BOOLEAN);
extern void F21_254(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit17(void);
extern void F1539_13942(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1542_14023(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
