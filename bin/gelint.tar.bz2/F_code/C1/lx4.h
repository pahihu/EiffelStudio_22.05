
#ifndef _C1_lx4_
#define _C1_lx4_

#ifdef __cplusplus
extern "C" {
#endif

extern void F4_37(EIF_REFERENCE);
extern void EIF_Minit4(void);

#ifdef __cplusplus
}
#endif

#endif
