
#ifndef _C1_kl26_
#define _C1_kl26_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F30_406(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit26(void);

#ifdef __cplusplus
}
#endif

#endif
