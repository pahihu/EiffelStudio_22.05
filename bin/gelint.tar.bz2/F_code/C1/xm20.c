/*
 * Code for class XM_POSITION_TABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm20.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_POSITION_TABLE}.make */
void F24_265 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1511,0xFF01,244,0xFF01,1301,0xFF01,2003,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1512_13706(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_POSITION_TABLE}.has */
EIF_BOOLEAN F24_266 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10794[Dtype(RTCW(tr1))-1480])(tr1);
	F1337_13187(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		tr1 = F1414_13275(RTCW(loc1));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(tr1 == arg1)) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1337_13190(RTCW(loc1));
		} else {
			F1337_13188(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {XM_POSITION_TABLE}.item */
EIF_REFERENCE F24_267 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10794[Dtype(RTCW(tr1))-1480])(tr1);
	F1337_13187(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		tr1 = F1414_13275(RTCW(loc1));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(tr1 == arg1)) {
			tr1 = F1414_13275(RTCW(loc1));
			loc2 = *(EIF_REFERENCE *)(RTCW(tr1));
			F1337_13190(RTCW(loc1));
		} else {
			F1337_13188(RTCW(loc1));
		}
	}
	RTCT0("has", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc2;
	RTLE;
	return Result;
}

/* {XM_POSITION_TABLE}.put */
void F24_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,244,0xFF01,1301,0xFF01,2003,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 244, _OBJSIZ_2_0_0_0_0_0_0_0_);
	}
	F245_2387(RTCW(loc1), arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10853[Dtype(RTCW(tr1))-1511])(tr1, loc1);
	RTLE;
}

void EIF_Minit20 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
