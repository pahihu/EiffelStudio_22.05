/*
 * Code for class XM_XPATH_TOKENIZE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1018.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_TOKENIZE}.make */
void F1946_19315 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("tokenize",8,2123933285);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_39_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1894L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_39_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_39_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_38_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_TOKENIZE}.item_type */
EIF_REFERENCE F1946_19316 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10254,F1235_10254, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_TOKENIZE}.required_type */
EIF_REFERENCE F1946_19317 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	switch (arg1) {
		case 1L:
			Result = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
			F1801_16783(RTCW(Result));
			break;
		case 2L:
			Result = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
			F1801_16782(RTCW(Result));
			break;
		case 3L:
			Result = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
			F1801_16782(RTCW(Result));
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_TOKENIZE}.simplify */
void F1946_19318 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	F1927_19193(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 3L))) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
		}
		F1568_12803(Current, loc1, *(EIF_REFERENCE *)(Current + _REFACS_9_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F210_1915(RTCW(arg1), NULL);
			tr1 = RTLNS(eif_new_type(1881, 0x01).id, 1881, _OBJSIZ_7_37_0_1_0_0_0_0_);
			F1882_18293(RTCW(tr1), loc2);
			F1868_17969(Current, arg1, tr1);
		}
	}
	RTLE;
}

/* {XM_XPATH_TOKENIZE}.create_iterator */
void F1946_19319 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(17);
	RTLR(0,Current);
	RTLR(1,loc7);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc8);
	RTLR(5,loc9);
	RTLR(6,loc2);
	RTLR(7,loc6);
	RTLR(8,loc1);
	RTLR(9,loc10);
	RTLR(10,loc3);
	RTLR(11,loc5);
	RTLR(12,loc11);
	RTLR(13,tr2);
	RTLR(14,tr3);
	RTLR(15,loc4);
	RTLR(16,tr4);
	RTLIU(17);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) NULL;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,209,1818,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc7 = RTLNS(typres0.id, 209, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F210_1916(RTCW(loc7), NULL);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, loc7, arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc7));
	loc8 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc8)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1694,0xFF01,1852,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNS(typres0.id, 1694, _OBJSIZ_3_1_0_1_0_0_0_0_);
		}
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13396[Dtype(loc8)-1819])(loc8);
		loc9 = tr1;
		if (EIF_TEST(loc9)) {
			tr1 = RTLNS(eif_new_type(1664, 0x01).id, 1664, _OBJSIZ_2_1_0_1_0_0_0_0_);
			F1665_14084(RTCW(tr1), loc9);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
		} else {
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(loc8)-1819])(loc8);
			loc6 = *(EIF_REFERENCE *)(Current);
			if ((EIF_BOOLEAN)(loc6 == NULL)) {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,209,1818,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					loc7 = RTLNS(typres0.id, 209, _OBJSIZ_1_0_0_0_0_0_0_0_);
				}
				F210_1916(RTCW(loc7), NULL);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
				tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, loc7, arg1);
				loc1 = *(EIF_REFERENCE *)(RTCW(loc7));
				RTCT0("pattern_not_void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13396[Dtype(RTCW(loc1))-1819])(loc1);
				loc10 = tr1;
				if (EIF_TEST(loc10)) {
					tr1 = RTLNS(eif_new_type(1664, 0x01).id, 1664, _OBJSIZ_2_1_0_1_0_0_0_0_);
					F1665_14084(RTCW(tr1), loc10);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(RTCW(loc1))-1819])(loc1);
					loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(tr1))-1819])(tr1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
						loc5 = RTMS_EX_H("",0,0);
					} else {
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFF01,209,1818,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							loc7 = RTLNS(typres0.id, 209, _OBJSIZ_1_0_0_0_0_0_0_0_);
						}
						F210_1916(RTCW(loc7), NULL);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
						tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 3L));
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, loc7, arg1);
						loc1 = *(EIF_REFERENCE *)(RTCW(loc7));
						RTCT0("attached l_item", EX_CHECK);
						if ((EIF_BOOLEAN)(loc1 != NULL)) {
							RTCK0;
						} else {
							RTCF0;
						}
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13396[Dtype(RTCW(loc1))-1819])(loc1);
						loc11 = tr1;
						if (EIF_TEST(loc11)) {
							tr1 = RTLNS(eif_new_type(1664, 0x01).id, 1664, _OBJSIZ_2_1_0_1_0_0_0_0_);
							F1665_14084(RTCW(tr1), loc11);
							RTAR(Current, tr1);
							*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(RTCW(loc1))-1819])(loc1);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(tr1))-1819])(tr1);
							loc5 = F1223_9740(Current, tr1);
						}
					}
					if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
					} else {
						if ((EIF_BOOLEAN)(loc5 == NULL)) {
							tr1 = RTMS_EX_H("Unknown flags in regular expression",35,985519214);
							tr2 = RTOSCF(9827,F1230_9827, (Current));
							tr3 = RTMS_EX_H("FORX0001",8,2093852209);
							F1868_17968(Current, tr1, tr2, tr3, ((EIF_INTEGER_32) 1L));
						} else {
							tr1 = RTOSCF(4521,F954_4521, (Current));
							tr1 = F1138_8299(RTCW(tr1), loc3);
							loc3 = (EIF_REFERENCE) tr1;
							loc4 = F1223_9741(Current, loc3, loc5);
							tr1 = RTOSCF(2083,F238_2083, (Current));
							loc6 = F1224_9744(RTCW(tr1), loc4);
							if ((EIF_BOOLEAN)(loc6 == NULL)) {
								loc6 = RTLNSMART(eif_new_type(1224, 0).id);
								F1225_9747(RTCW(loc6), loc3, loc5);
								tb1 = *(EIF_BOOLEAN *)(RTCW(loc6)+ _CHROFF_2_0_);
								if ((EIF_BOOLEAN) !tb1) {
									tr1 = RTOSCF(2083,F238_2083, (Current));
									F1224_9745(RTCW(tr1), loc6, loc4);
								}
							}
							tb1 = *(EIF_BOOLEAN *)(RTCW(loc6)+ _CHROFF_2_0_);
							if ((EIF_BOOLEAN) !tb1) {
								tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
								tr2 = RTMS_EX_H("",0,0);
								tb1 = F1607_13386(RTCW(tr1), tr2);
								if (tb1) {
									tr1 = RTLNS(eif_new_type(1664, 0x01).id, 1664, _OBJSIZ_2_1_0_1_0_0_0_0_);
									tr2 = RTMS_EX_H("Regular expression matches zero-length string",45,1995422311);
									tr3 = RTOSCF(9827,F1230_9827, (Current));
									tr4 = RTMS_EX_H("FORX0003",8,2093852211);
									F1665_14085(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
									RTAR(Current, tr1);
									*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
								} else {
									tr1 = RTOSCF(4521,F954_4521, (Current));
									tr1 = F1138_8299(RTCW(tr1), loc2);
									loc2 = (EIF_REFERENCE) tr1;
									tr1 = RTLNS(eif_new_type(1638, 0x01).id, 1638, _OBJSIZ_6_1_0_2_0_0_0_0_);
									F1639_13792(RTCW(tr1), loc2, loc6);
									RTAR(Current, tr1);
									*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
								}
							} else {
								tr1 = RTLNS(eif_new_type(1664, 0x01).id, 1664, _OBJSIZ_2_1_0_1_0_0_0_0_);
								tr2 = RTMS_EX_H("Invalid regular expression",26,1449583982);
								tr3 = RTOSCF(9827,F1230_9827, (Current));
								tr4 = RTMS_EX_H("FORX0002",8,2093852210);
								F1665_14085(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
								RTAR(Current, tr1);
								*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
							}
						}
					}
				}
			} else {
				tr1 = RTOSCF(4521,F954_4521, (Current));
				tr1 = F1138_8299(RTCW(tr1), loc2);
				loc2 = (EIF_REFERENCE) tr1;
				tr1 = RTLNS(eif_new_type(1638, 0x01).id, 1638, _OBJSIZ_6_1_0_2_0_0_0_0_);
				F1639_13792(RTCW(tr1), loc2, loc6);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
			}
		}
	}
	RTLE;
}

/* {XM_XPATH_TOKENIZE}.compute_cardinality */
void F1946_19320 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8086(Current);
}

void EIF_Minit1018 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
