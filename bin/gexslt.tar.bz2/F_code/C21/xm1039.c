/*
 * Code for class XM_XPATH_NORMALIZE_UNICODE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1039.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_NORMALIZE_UNICODE}.make */
void F1967_19450 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("normalize-unicode",17,1064000869);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1862L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_NORMALIZE_UNICODE}.item_type */
EIF_REFERENCE F1967_19451 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10254,F1235_10254, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_NORMALIZE_UNICODE}.required_type */
EIF_REFERENCE F1967_19452 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16783(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16782(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {XM_XPATH_NORMALIZE_UNICODE}.evaluate_item */
void F1967_19453 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc6);
	RTLR(5,tr2);
	RTLR(6,loc5);
	RTLR(7,loc7);
	RTLR(8,loc2);
	RTLR(9,loc3);
	RTLR(10,tr3);
	RTLR(11,loc4);
	RTLIU(12);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc6 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc6)) {
		tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
		tr2 = RTMS_EX_H("",0,0);
		F1884_18322(RTCW(tr1), tr2);
		F210_1915(RTCW(arg1), tr1);
	} else {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc6)-1819])(loc6);
		if (tb1) {
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
				loc5 = (EIF_REFERENCE) loc6;
				F210_1915(RTCW(arg1), NULL);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13948[Dtype(RTCW(tr1))-1868])(tr1, arg2);
				RTCT0("postcondition_of_evaluate_as_string", EX_CHECK);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13839[Dtype(tr1)-1867]);
				loc7 = tr1;
				if (EIF_TEST(loc7)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tb1 = F1868_17865(loc7);
				if (tb1) {
					F210_1915(RTCW(arg1), loc7);
				} else {
					loc2 = F1884_18326(loc7);
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					F1148_8385(RTCW(tr1), loc2);
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					F1148_8386(RTCW(tr1), loc2);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5053[Dtype(RTCW(loc2))-1112])(loc2);
					loc2 = (EIF_REFERENCE) tr1;
					tb1 = F772_3900(RTCW(loc2));
					if (tb1) {
						F210_1915(RTCW(arg1), loc5);
					} else {
						tr1 = RTOSCF(8530,F1163_8530, (Current));
						tr2 = RTMS_EX_H("NFC",3,5129795);
						tb1 = F1148_8369(RTCW(tr1), tr2, loc2);
						if (tb1) {
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						} else {
							tr1 = RTOSCF(8530,F1163_8530, (Current));
							tr2 = RTMS_EX_H("NFKC",4,1313229635);
							tb1 = F1148_8369(RTCW(tr1), tr2, loc2);
							if (tb1) {
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
							} else {
								tr1 = RTOSCF(8530,F1163_8530, (Current));
								tr2 = RTMS_EX_H("NFD",3,5129796);
								tb1 = F1148_8369(RTCW(tr1), tr2, loc2);
								if (tb1) {
									loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								} else {
									tr1 = RTOSCF(8530,F1163_8530, (Current));
									tr2 = RTMS_EX_H("NFKD",4,1313229636);
									tb1 = F1148_8369(RTCW(tr1), tr2, loc2);
									if (tb1) {
										loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
									} else {
										tr1 = RTOSCF(8530,F1163_8530, (Current));
										tr2 = RTMS_EX_H("Requested normalization form ",29,326644768);
										loc3 = F1148_8367(RTCW(tr1), tr2, loc2);
										tr1 = RTOSCF(8530,F1163_8530, (Current));
										tr2 = RTMS_EX_H(" is not supported",17,510528612);
										tr1 = F1148_8377(RTCW(tr1), loc3, tr2);
										loc3 = (EIF_REFERENCE) tr1;
										tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
										tr2 = RTOSCF(9827,F1230_9827, (Current));
										tr3 = RTMS_EX_H("FOCH0003",8,2064238131);
										F1820_17199(RTCW(tr1), loc3, tr2, tr3, ((EIF_INTEGER_32) 3L));
										F210_1915(RTCW(arg1), tr1);
									}
								}
							}
						}
						tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
						if ((EIF_BOOLEAN)(tr1 == NULL)) {
							switch (loc1) {
								case 0L:
									tr1 = RTOSCF(1436,F157_1436, (Current));
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(loc5))-1819])(loc5);
									loc4 = F1207_9122(RTCW(tr1), tr2);
									break;
								case 2L:
									tr1 = RTOSCF(1436,F157_1436, (Current));
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(loc5))-1819])(loc5);
									loc4 = F1207_9123(RTCW(tr1), tr2);
									break;
								case 1L:
									tr1 = RTOSCF(1436,F157_1436, (Current));
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(loc5))-1819])(loc5);
									loc4 = F1207_9118(RTCW(tr1), tr2);
									break;
								case 3L:
									tr1 = RTOSCF(1436,F157_1436, (Current));
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(loc5))-1819])(loc5);
									loc4 = F1207_9120(RTCW(tr1), tr2);
									break;
								default:
									RTEC(EN_WHEN);
							}
						}
					}
				}
			} else {
				tr1 = RTOSCF(1436,F157_1436, (Current));
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(loc6)-1819])(loc6);
				loc4 = F1207_9122(RTCW(tr1), tr2);
			}
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
				F1884_18322(RTCW(tr1), loc4);
				F210_1915(RTCW(arg1), tr1);
			}
		}
	}
	RTLE;
}

/* {XM_XPATH_NORMALIZE_UNICODE}.compute_cardinality */
void F1967_19454 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8089(Current);
}

void EIF_Minit1039 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
