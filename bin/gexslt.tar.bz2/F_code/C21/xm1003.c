/*
 * Code for class XM_XPATH_AVG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1003.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_AVG}.make */
void F1931_19221 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("avg",3,6387303);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1797L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_AVG}.item_type */
EIF_REFERENCE F1931_19222 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	loc1 = F1868_17859(RTCW(tr1), (EIF_BOOLEAN) 0);
	tr1 = RTOSCF(10261,F1235_10261, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(loc1 == tr1)) {
		Result = RTOSCF(10264,F1235_10264, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	} else {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9465[Dtype(RTCW(loc1))-1403])(loc1);
		tr1 = RTOSCF(10265,F1235_10265, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_1_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
			Result = RTOSCF(10262,F1235_10262, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
		} else {
			Result = (EIF_REFERENCE) loc1;
		}
	}
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_AVG}.required_type */
EIF_REFERENCE F1931_19223 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
	F1801_16795(RTCW(tr1));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_XPATH_AVG}.evaluate_item */
void F1931_19224 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(17);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,loc7);
	RTLR(4,loc1);
	RTLR(5,loc8);
	RTLR(6,arg1);
	RTLR(7,loc9);
	RTLR(8,loc2);
	RTLR(9,loc3);
	RTLR(10,loc4);
	RTLR(11,loc10);
	RTLR(12,loc5);
	RTLR(13,tr2);
	RTLR(14,tr3);
	RTLR(15,tr4);
	RTLR(16,loc6);
	RTLIU(17);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13949[Dtype(RTCW(tr1))-1868])(tr1, arg2);
	RTCT0("postcondition_of_create_iterator", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13841[Dtype(tr1)-1867]);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = (EIF_REFERENCE) loc7;
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O10835[Dtype(loc1)-1635]);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
		F1820_17198(RTCW(tr1), loc8);
		F210_1915(RTCW(arg1), tr1);
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10853[Dtype(RTCW(loc1))-1636])(loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O10835[Dtype(loc1)-1635]);
		loc9 = tr1;
		if (EIF_TEST(loc9)) {
			tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			F1820_17198(RTCW(tr1), loc9);
			F210_1915(RTCW(arg1), tr1);
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10840[Dtype(RTCW(loc1))-1636])(loc1);
			if (tb1) {
				F210_1915(RTCW(arg1), NULL);
			} else {
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10833[Dtype(RTCW(loc1))-1636])(loc1);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(RTCW(loc2))-1819])(loc2);
				if (tb1) {
					F210_1915(RTCW(arg1), loc2);
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(RTCW(loc2))-1819])(loc2);
					loc3 = F1878_18228(RTCW(tr1));
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13896[Dtype(RTCW(loc3))-1868])(loc3);
					if (tb1) {
						loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13995[Dtype(RTCW(loc3))-1868])(loc3);
						tr1 = RTOSCF(10264,F1235_10264, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R14087[Dtype(RTCW(loc4))-1878])(loc4, tr1);
						if (tb1) {
							tr1 = RTOSCF(10264,F1235_10264, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14089[Dtype(RTCW(loc4))-1878])(loc4, tr1);
							RTCT0("postcondition_of_convert_to_type", EX_CHECK);
							tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_6_);
							loc10 = tr1;
							if (EIF_TEST(loc10)) {
								RTCK0;
							} else {
								RTCF0;
							}
							loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14024[Dtype(loc10)-1868])(loc10);
						} else {
							tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
							tr2 = RTMS_EX_H("Input to avg() contains a value that is neither numeric, nor a duration",71,246537838);
							tr3 = RTOSCF(9827,F1230_9827, (Current));
							tr4 = RTMS_EX_H("FORG0006",8,2093721654);
							F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
							F210_1915(RTCW(arg1), tr1);
						}
					} else {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13891[Dtype(RTCW(loc3))-1868])(loc3);
						if (tb1) {
							loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13990[Dtype(RTCW(loc3))-1868])(loc3);
							tb1 = '\0';
							tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13893[Dtype(RTCW(loc6))-1868])(loc6);
							if ((EIF_BOOLEAN) !tb2) {
								tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13892[Dtype(RTCW(loc6))-1868])(loc6);
								tb1 = (EIF_BOOLEAN) !tb2;
							}
							if (tb1) {
								tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
								tr2 = RTMS_EX_H("Input to avg() contains a duration value that is neither xs:yearMonthDuration nor xs:dayTimeDuration",100,1329410670);
								tr3 = RTOSCF(9827,F1230_9827, (Current));
								tr4 = RTMS_EX_H("FORG0006",8,2093721654);
								F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
								F210_1915(RTCW(arg1), tr1);
							}
						} else {
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13877[Dtype(RTCW(loc3))-1868])(loc3);
							if (tb1) {
								loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14024[Dtype(RTCW(loc3))-1868])(loc3);
							} else {
								tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
								tr2 = RTMS_EX_H("Input to avg() contains a value that is neither numeric, nor a duration",71,246537838);
								tr3 = RTOSCF(9827,F1230_9827, (Current));
								tr4 = RTMS_EX_H("FORG0006",8,2093721654);
								F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
								F210_1915(RTCW(arg1), tr1);
							}
						}
					}
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
					if ((EIF_BOOLEAN)(tr1 == NULL)) {
						if ((EIF_BOOLEAN)(loc5 != NULL)) {
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14156[Dtype(RTCW(loc5))-1898])(loc5);
							if (tb1) {
								F210_1915(RTCW(arg1), loc5);
							} else {
								F1931_19227(Current, arg1, loc5, loc1);
							}
						} else {
							RTCT0("attached l_duration_value", EX_CHECK);
							if ((EIF_BOOLEAN)(loc6 != NULL)) {
								RTCK0;
							} else {
								RTCF0;
							}
							F1931_19228(Current, arg1, loc6, loc1);
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_XPATH_AVG}.compute_cardinality */
void F1931_19225 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8085(Current);
}

/* {XM_XPATH_AVG}.check_arguments */
void F1931_19226 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	F1927_19199(Current, arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,209,1867,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNS(typres0.id, 209, _OBJSIZ_1_0_0_0_0_0_0_0_);
		}
		F210_1916(RTCW(loc1), NULL);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R14031[Dtype(RTCW(tr1))-1868])(tr1, loc1, (EIF_BOOLEAN) 1);
		RTCT0("postcondition_of_set_unsorted", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN)(tr1 != loc2)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			F1506_12176(RTCW(tr1), loc2, ((EIF_INTEGER_32) 1L));
		}
	}
	RTLE;
}

/* {XM_XPATH_AVG}.evaluate_numeric_average */
void F1931_19227 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(15);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLR(7,Current);
	RTLR(8,loc7);
	RTLR(9,loc2);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,tr4);
	RTLR(13,loc8);
	RTLR(14,loc3);
	RTLIU(15);
	
	RTGC;
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc1 = (EIF_REFERENCE) arg2;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10854[Dtype(RTCW(arg3))-1636])(arg3);
	for (;;) {
		tb1 = '\01';
		tb2 = '\01';
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg3) + O10843[Dtype(arg3)-1635]);
		if (!tb3) {
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10840[Dtype(RTCW(arg3))-1636])(arg3);
			tb2 = tb3;
		}
		if (!tb2) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			tb1 = (EIF_BOOLEAN)(tr1 != NULL);
		}
		if (tb1) break;
		loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10833[Dtype(RTCW(arg3))-1636])(arg3);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(RTCW(loc5))-1819])(loc5);
		if (tb2) {
			F210_1915(RTCW(arg1), loc5);
		} else {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13403[Dtype(RTCW(loc5))-1819])(loc5);
			if (tb2) {
				loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13420[Dtype(RTCW(loc5))-1819])(loc5);
				tr1 = RTOSCF(10264,F1235_10264, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R14087[Dtype(RTCW(loc6))-1878])(loc6, tr1);
				if (tb2) {
					tr1 = RTOSCF(10264,F1235_10264, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14089[Dtype(RTCW(loc6))-1878])(loc6, tr1);
					RTCT0("postcondition_of_convert_to_type", EX_CHECK);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc6) + _REFACS_6_);
					loc7 = tr1;
					if (EIF_TEST(loc7)) {
						RTCK0;
					} else {
						RTCF0;
					}
					loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14024[Dtype(loc7)-1868])(loc7);
				} else {
					tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
					tr2 = RTMS_EX_H("Input to avg() contains a value that is neither numeric, nor a duration",71,246537838);
					tr3 = RTOSCF(9827,F1230_9827, (Current));
					tr4 = RTMS_EX_H("FORG0006",8,2093721654);
					F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
					F210_1915(RTCW(arg1), tr1);
				}
			} else {
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13404[Dtype(RTCW(loc5))-1819])(loc5);
				if ((EIF_BOOLEAN) !tb2) {
					tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
					tr2 = RTMS_EX_H("Input to avg() contains mixed numeric and non-numeric values",60,547093107);
					tr3 = RTOSCF(9827,F1230_9827, (Current));
					tr4 = RTMS_EX_H("FORG0006",8,2093721654);
					F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
					F210_1915(RTCW(arg1), tr1);
				} else {
					loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13421[Dtype(RTCW(loc5))-1819])(loc5);
				}
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				RTCT0("attached l_numeric_value", EX_CHECK);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14156[Dtype(RTCW(loc2))-1898])(loc2);
				if (tb2) {
					F210_1915(RTCW(arg1), loc2);
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) R14164[Dtype(RTCW(loc1))-1898])(loc1, ((EIF_INTEGER_32) 15L), loc2);
					loc1 = (EIF_REFERENCE) tr1;
					tb2 = '\01';
					tb3 = F1868_17865(RTCW(loc1));
					if (!tb3) {
						tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14156[Dtype(RTCW(loc1))-1898])(loc1);
						tb2 = tb3;
					}
					if (tb2) {
						F210_1915(RTCW(arg1), loc1);
					}
				}
			}
		}
		loc4++;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10854[Dtype(RTCW(arg3))-1636])(arg3);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + O10835[Dtype(arg3)-1635]);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
		F1820_17198(RTCW(tr1), loc8);
		F210_1915(RTCW(arg1), tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc3 = RTLNS(eif_new_type(1899, 0x01).id, 1899, _OBJSIZ_8_37_0_1_0_0_0_0_);
			F1900_18618(RTCW(loc3), loc4);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) R14164[Dtype(RTCW(loc1))-1898])(loc1, ((EIF_INTEGER_32) 18L), loc3);
			F210_1915(RTCW(arg1), tr1);
		}
	}
	RTLE;
}

/* {XM_XPATH_AVG}.evaluate_duration_average */
void F1931_19228 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(12);
	RTLR(0,arg2);
	RTLR(1,loc1);
	RTLR(2,arg3);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLR(7,Current);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLR(10,loc2);
	RTLR(11,loc6);
	RTLIU(12);
	
	RTGC;
	loc5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13893[Dtype(RTCW(arg2))-1868])(arg2);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc1 = (EIF_REFERENCE) arg2;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10854[Dtype(RTCW(arg3))-1636])(arg3);
	for (;;) {
		tb1 = '\01';
		tb2 = '\01';
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg3) + O10843[Dtype(arg3)-1635]);
		if (!tb3) {
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10840[Dtype(RTCW(arg3))-1636])(arg3);
			tb2 = tb3;
		}
		if (!tb2) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			tb1 = (EIF_BOOLEAN)(tr1 != NULL);
		}
		if (tb1) break;
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10833[Dtype(RTCW(arg3))-1636])(arg3);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(RTCW(loc4))-1819])(loc4);
		if (tb2) {
			F210_1915(RTCW(arg1), loc4);
		} else {
			tb2 = '\01';
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13399[Dtype(RTCW(loc4))-1819])(loc4);
			if (!(EIF_BOOLEAN) !tb3) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(RTCW(loc4))-1819])(loc4);
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13891[Dtype(RTCW(tr1))-1868])(tr1);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("Input to avg() contains mixed duration and non-duration values",62,1589868915);
				tr3 = RTOSCF(9827,F1230_9827, (Current));
				tr4 = RTMS_EX_H("FORG0006",8,2093721654);
				F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
				F210_1915(RTCW(arg1), tr1);
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(RTCW(loc4))-1819])(loc4);
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13990[Dtype(RTCW(tr1))-1868])(tr1);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13893[Dtype(RTCW(loc2))-1868])(loc2);
				if ((EIF_BOOLEAN)(tb2 != loc5)) {
					tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
					tr2 = RTMS_EX_H("Input to avg() contains mixed xs:yearMonthDuration and xs:dayTimeDuration values",80,293578867);
					tr3 = RTOSCF(9827,F1230_9827, (Current));
					tr4 = RTMS_EX_H("FORG0006",8,2093721654);
					F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
					F210_1915(RTCW(arg1), tr1);
				}
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				RTCT0("attached l_duration_value", EX_CHECK);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R14123[Dtype(RTCW(loc1))-1885])(loc1, loc2);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(RTCW(loc4))-1819])(loc4);
				if (tb2) {
					F210_1915(RTCW(arg1), loc4);
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(RTCW(loc4))-1819])(loc4);
					loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13990[Dtype(RTCW(tr1))-1868])(tr1);
				}
			}
		}
		loc3++;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10854[Dtype(RTCW(arg3))-1636])(arg3);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + O10835[Dtype(arg3)-1635]);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
		F1820_17198(RTCW(tr1), loc6);
		F210_1915(RTCW(arg1), tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			tr8_1 = (EIF_REAL_64) (loc3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REAL_64)) R14125[Dtype(RTCW(loc1))-1885])(loc1, (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) 1.0) /  (EIF_REAL_64) (tr8_1)));
			F210_1915(RTCW(arg1), tr1);
		}
	}
	RTLE;
}

void EIF_Minit1003 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
