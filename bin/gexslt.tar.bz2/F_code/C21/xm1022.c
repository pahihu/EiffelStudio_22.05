/*
 * Code for class XM_XPATH_SUBSTRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1022.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_SUBSTRING}.make */
void F1950_19339 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("substring",9,299495271);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1887L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_SUBSTRING}.item_type */
EIF_REFERENCE F1950_19340 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10254,F1235_10254, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_SUBSTRING}.required_type */
EIF_REFERENCE F1950_19341 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16783(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16792(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {XM_XPATH_SUBSTRING}.evaluate_item */
void F1950_19342 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc7);
	RTLR(5,tr2);
	RTLR(6,loc1);
	RTLR(7,loc8);
	RTLR(8,loc9);
	RTLR(9,loc10);
	RTLR(10,loc2);
	RTLR(11,loc11);
	RTLR(12,loc12);
	RTLR(13,loc13);
	RTLIU(14);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc7 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc7)) {
		tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
		tr2 = RTMS_EX_H("",0,0);
		F1884_18322(RTCW(tr1), tr2);
		F210_1915(RTCW(arg1), tr1);
	} else {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc7)-1819])(loc7);
		if ((EIF_BOOLEAN) !tb1) {
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(loc7)-1819])(loc7);
			F210_1915(RTCW(arg1), NULL);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc8)-1819])(loc8);
				tb1 = tb2;
			}
			if (tb1) {
			} else {
				RTCT0("second_argument_convertible_to_double", EX_CHECK);
				tb1 = '\0';
				tb2 = '\0';
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
				loc9 = tr1;
				if (EIF_TEST(loc9)) {
					tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13399[Dtype(loc9)-1819])(loc9);
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(loc9)-1819])(loc9);
					tr2 = RTOSCF(10264,F1235_10264, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R14087[Dtype(RTCW(tr1))-1878])(tr1, tr2);
					tb1 = tb2;
				}
				if (tb1) {
					RTCK0;
				} else {
					RTCF0;
				}
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(loc9)-1819])(loc9);
				tr2 = RTOSCF(10264,F1235_10264, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14089[Dtype(RTCW(tr1))-1878])(tr1, tr2);
				RTCT0("postcondition_of_convert_to_type", EX_CHECK);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(loc9)-1819])(loc9);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O14088[Dtype(tr1)-1877]);
				loc10 = tr1;
				if (EIF_TEST(loc10)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13424[Dtype(loc10)-1819])(loc10);
				loc2 = F1902_18697(RTCW(tr1));
				tb1 = F1902_18692(RTCW(loc2));
				if (tb1) {
					tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
					tr2 = RTMS_EX_H("",0,0);
					F1884_18322(RTCW(tr1), tr2);
					F210_1915(RTCW(arg1), tr1);
				} else {
					tb1 = '\01';
					tb2 = F1902_18690(RTCW(loc2));
					if (!tb2) {
						tr8_1 = *(EIF_REAL_64 *)(RTCW(loc2)+ _R64OFF_7_39_0_1_0_0_0_0_);
						tr8_2 = RTOSCF(1570,F174_1570, (RTCV(RTOSCF(2592,F334_2592, (Current)))));
						tb1 = (EIF_BOOLEAN) eif_is_equal_real_64 (tr8_1, tr8_2);
					}
					if (tb1) {
						tr8_1 = *(EIF_REAL_64 *)(RTCW(loc2)+ _R64OFF_7_39_0_1_0_0_0_0_);
						tr8_2 = RTOSCF(1570,F174_1570, (RTCV(RTOSCF(2592,F334_2592, (Current)))));
						if ((EIF_BOOLEAN) eif_is_equal_real_64 (tr8_1, tr8_2)) {
							loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							loc3 = RTOSCF(2036,F228_2036, (RTCV(RTOSCF(1557,F173_1557, (Current)))));
						} else {
							tr1 = RTOSCF(2592,F334_2592, (Current));
							tr8_1 = *(EIF_REAL_64 *)(RTCW(loc2)+ _R64OFF_7_39_0_1_0_0_0_0_);
							loc3 = F174_1563(RTCW(tr1), tr8_1);
						}
						F210_1915(RTCW(arg1), NULL);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
						if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 3L))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
							tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 3L));
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
							tb1 = '\0';
							tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
							loc11 = tr1;
							if (EIF_TEST(loc11)) {
								tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc11)-1819])(loc11);
								tb1 = tb2;
							}
							if (tb1) {
							} else {
								RTCT0("third_argument_convertible_to_double", EX_CHECK);
								tb1 = '\0';
								tb2 = '\0';
								tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
								loc12 = tr1;
								if (EIF_TEST(loc12)) {
									tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13399[Dtype(loc12)-1819])(loc12);
									tb2 = tb3;
								}
								if (tb2) {
									tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(loc12)-1819])(loc12);
									tr2 = RTOSCF(10264,F1235_10264, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
									tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R14087[Dtype(RTCW(tr1))-1878])(tr1, tr2);
									tb1 = tb2;
								}
								if (tb1) {
									RTCK0;
								} else {
									RTCF0;
								}
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(loc12)-1819])(loc12);
								tr2 = RTOSCF(10264,F1235_10264, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14089[Dtype(RTCW(tr1))-1878])(tr1, tr2);
								RTCT0("postcondition_of_convert_to_type", EX_CHECK);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(loc12)-1819])(loc12);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O14088[Dtype(tr1)-1877]);
								loc13 = tr1;
								if (EIF_TEST(loc13)) {
									RTCK0;
								} else {
									RTCF0;
								}
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13424[Dtype(loc13)-1819])(loc13);
								loc2 = F1902_18697(RTCW(tr1));
								tb1 = F1902_18692(RTCW(loc2));
								if (tb1) {
									tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
									tr2 = RTMS_EX_H("",0,0);
									F1884_18322(RTCW(tr1), tr2);
									F210_1915(RTCW(arg1), tr1);
								} else {
									tb1 = F1902_18690(RTCW(loc2));
									if (tb1) {
										tr1 = RTOSCF(2592,F334_2592, (Current));
										tr8_1 = *(EIF_REAL_64 *)(RTCW(loc2)+ _R64OFF_7_39_0_1_0_0_0_0_);
										loc5 = F174_1563(RTCW(tr1), tr8_1);
										if ((EIF_BOOLEAN) (loc5 < ((EIF_INTEGER_32) 1L))) {
											loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
										}
										loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc3) - ((EIF_INTEGER_32) 1L));
										ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
										if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
											loc4 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
										}
										F210_1915(RTCW(arg1), NULL);
									} else {
										tr8_1 = *(EIF_REAL_64 *)(RTCW(loc2)+ _R64OFF_7_39_0_1_0_0_0_0_);
										tr8_2 = RTOSCF(1569,F174_1569, (RTCV(RTOSCF(2592,F334_2592, (Current)))));
										if ((EIF_BOOLEAN) eif_is_equal_real_64 (tr8_1, tr8_2)) {
											if (loc6) {
												tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
												tr2 = RTMS_EX_H("",0,0);
												F1884_18322(RTCW(tr1), tr2);
												F210_1915(RTCW(arg1), tr1);
											} else {
												loc4 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
												F210_1915(RTCW(arg1), NULL);
											}
										} else {
											tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
											tr2 = RTMS_EX_H("",0,0);
											F1884_18322(RTCW(tr1), tr2);
											F210_1915(RTCW(arg1), tr1);
										}
									}
								}
							}
						} else {
							loc4 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						}
					} else {
						tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
						tr2 = RTMS_EX_H("",0,0);
						F1884_18322(RTCW(tr1), tr2);
						F210_1915(RTCW(arg1), tr1);
					}
				}
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 1L))) {
					loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				}
				if ((EIF_BOOLEAN) (loc4 < loc3)) {
					tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
					tr2 = RTMS_EX_H("",0,0);
					F1884_18322(RTCW(tr1), tr2);
					F210_1915(RTCW(arg1), tr1);
				} else {
					tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, loc3, loc4);
					F1884_18322(RTCW(tr1), tr2);
					F210_1915(RTCW(arg1), tr1);
				}
			}
		}
	}
	RTLE;
}

/* {XM_XPATH_SUBSTRING}.compute_cardinality */
void F1950_19343 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8089(Current);
}

void EIF_Minit1022 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
