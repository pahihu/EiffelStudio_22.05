/*
 * Code for class XM_XPATH_ROOT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1030.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_ROOT}.make */
void F1958_19384 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("root",4,1919905652);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1874L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_ROOT}.item_type */
EIF_REFERENCE F1958_19385 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(4537,F958_4537, (Current));
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_ROOT}.required_type */
EIF_REFERENCE F1958_19386 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
	F1801_16790(RTCW(tr1));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_XPATH_ROOT}.simplify */
void F1958_19387 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1927_19193(Current, arg1);
	F1927_19194(Current);
	RTLE;
}

/* {XM_XPATH_ROOT}.evaluate_item */
void F1958_19388 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc1)-1819])(loc1);
		if ((EIF_BOOLEAN) !tb1) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13398[Dtype(loc1)-1819])(loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("The context item is not a node",30,895444325);
				tr3 = RTOSCF(9827,F1230_9827, (Current));
				tr4 = RTMS_EX_H("FOTY0011",8,2097792305);
				F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
				F210_1915(RTCW(arg1), tr1);
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13416[Dtype(loc1)-1819])(loc1);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13628[Dtype(RTCW(tr1))-1853])(tr1);
				F210_1915(RTCW(arg1), tr1);
			}
		}
	}
	RTLE;
}

/* {XM_XPATH_ROOT}.compute_cardinality */
void F1958_19389 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8085(Current);
}

/* {XM_XPATH_ROOT}.compute_special_properties */
void F1958_19390 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1124_8100(Current);
	F1124_8105(Current);
	F1124_8114(Current);
	F1124_8112(Current);
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		tb2 = *(EIF_BOOLEAN *)(RTCW(tr1) + O6564[Dtype(tr1)-1123]);
		tb1 = tb2;
	}
	if (tb1) {
		F1124_8103(Current);
	}
	RTLE;
}

void EIF_Minit1030 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
