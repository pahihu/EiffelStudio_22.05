/*
 * Code for class XM_XPATH_SUM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1021.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_SUM}.make */
void F1949_19331 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("sum",3,7566701);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1890L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_SUM}.item_type */
EIF_REFERENCE F1949_19332 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	loc1 = F1868_17859(RTCW(tr1), (EIF_BOOLEAN) 0);
	tr1 = RTOSCF(10261,F1235_10261, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(loc1 == tr1)) {
		loc1 = RTOSCF(10264,F1235_10264, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O6542[Dtype(tr1)-1123]);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			tr1 = RTOSCF(10265,F1235_10265, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
			Result = F1782_16532(Current, loc1, tr1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13827[Dtype(RTCW(tr1))-1868])(tr1);
			Result = F1782_16532(Current, loc1, tr1);
		}
	} else {
		RTLE;
		return (EIF_REFERENCE) loc1;
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_SUM}.required_type */
EIF_REFERENCE F1949_19333 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	switch (arg1) {
		case 1L:
			Result = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
			F1801_16795(RTCW(Result));
			break;
		case 2L:
			Result = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
			F1801_16777(RTCW(Result));
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_SUM}.evaluate_item */
void F1949_19334 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,loc4);
	RTLR(4,loc1);
	RTLR(5,loc5);
	RTLR(6,arg1);
	RTLR(7,loc6);
	RTLR(8,loc2);
	RTLR(9,loc7);
	RTLR(10,loc3);
	RTLR(11,tr2);
	RTLR(12,tr3);
	RTLR(13,tr4);
	RTLIU(14);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13949[Dtype(RTCW(tr1))-1868])(tr1, arg2);
	RTCT0("postcondition_of_create_iterator", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13841[Dtype(tr1)-1867]);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = (EIF_REFERENCE) loc4;
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O10835[Dtype(loc1)-1635]);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
		F1820_17198(RTCW(tr1), loc5);
		F210_1915(RTCW(arg1), tr1);
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10853[Dtype(RTCW(loc1))-1636])(loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O10835[Dtype(loc1)-1635]);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			F1820_17198(RTCW(tr1), loc6);
			F210_1915(RTCW(arg1), tr1);
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10840[Dtype(RTCW(loc1))-1636])(loc1);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
					tr1 = RTLNS(eif_new_type(1902, 0x01).id, 1902, _OBJSIZ_7_37_0_1_0_0_1_0_);
					F1903_18707(RTCW(tr1), (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L));
					F210_1915(RTCW(arg1), tr1);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
					tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
				}
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10833[Dtype(RTCW(loc1))-1636])(loc1);
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(RTCW(tr1))-1819])(tr1);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13896[Dtype(RTCW(loc2))-1868])(loc2);
				if (tb1) {
					tr1 = RTOSCF(10264,F1235_10264, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14089[Dtype(RTCW(loc2))-1878])(loc2, tr1);
					RTCT0("postcondition_of_convert_to_type", EX_CHECK);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + O14088[Dtype(loc2)-1877]);
					loc7 = tr1;
					if (EIF_TEST(loc7)) {
						RTCK0;
					} else {
						RTCF0;
					}
					loc2 = (EIF_REFERENCE) loc7;
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13891[Dtype(RTCW(loc2))-1868])(loc2);
					if (tb1) {
						loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13990[Dtype(RTCW(loc2))-1868])(loc2);
						tb1 = '\0';
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13893[Dtype(RTCW(loc3))-1868])(loc3);
						if ((EIF_BOOLEAN) !tb2) {
							tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13892[Dtype(RTCW(loc3))-1868])(loc3);
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) {
							tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
							tr2 = RTMS_EX_H("Input to sum() contains a duration value that is neither xs:yearMonthDuration nor xs:dayTimeDuration",100,124536686);
							tr3 = RTOSCF(9827,F1230_9827, (Current));
							tr4 = RTMS_EX_H("FORG0006",8,2093721654);
							F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
							F210_1915(RTCW(arg1), tr1);
						}
					}
				}
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13877[Dtype(RTCW(loc2))-1868])(loc2);
				if (tb1) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14024[Dtype(RTCW(loc2))-1868])(loc2);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14156[Dtype(RTCW(tr1))-1898])(tr1);
					if (tb1) {
						F210_1915(RTCW(arg1), loc2);
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14024[Dtype(RTCW(loc2))-1868])(loc2);
						F1949_19337(Current, arg1, tr1, loc1);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13891[Dtype(RTCW(loc2))-1868])(loc2);
					if (tb1) {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13990[Dtype(RTCW(loc2))-1868])(loc2);
						F1949_19338(Current, arg1, tr1, loc1);
					} else {
						tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("Input to sum() contains a value that is neither numeric nor a duration",70,2130726510);
						tr3 = RTMS_EX_H("",0,0);
						tr4 = RTMS_EX_H("FORG0006",8,2093721654);
						F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
						F210_1915(RTCW(arg1), tr1);
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_XPATH_SUM}.check_arguments */
void F1949_19335 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	F1927_19199(Current, arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,209,1867,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNS(typres0.id, 209, _OBJSIZ_1_0_0_0_0_0_0_0_);
		}
		F210_1916(RTCW(loc1), NULL);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R14031[Dtype(RTCW(tr1))-1868])(tr1, loc1, (EIF_BOOLEAN) 1);
		RTCT0("postcondition_of_set_unsorted", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN)(tr1 != loc2)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			F1506_12176(RTCW(tr1), loc2, ((EIF_INTEGER_32) 1L));
		}
	}
	RTLE;
}

/* {XM_XPATH_SUM}.compute_cardinality */
void F1949_19336 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8089(Current);
}

/* {XM_XPATH_SUM}.evaluate_numeric_total */
void F1949_19337 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc2);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,tr1);
	RTLR(6,Current);
	RTLR(7,tr2);
	RTLR(8,loc5);
	RTLR(9,loc1);
	RTLR(10,tr3);
	RTLR(11,tr4);
	RTLR(12,loc6);
	RTLIU(13);
	
	RTGC;
	loc2 = (EIF_REFERENCE) arg2;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10854[Dtype(RTCW(arg3))-1636])(arg3);
	for (;;) {
		tb1 = '\01';
		tb2 = '\01';
		if (!loc4) {
			tb3 = *(EIF_BOOLEAN *)(RTCW(arg3) + O10843[Dtype(arg3)-1635]);
			tb2 = tb3;
		}
		if (!tb2) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10840[Dtype(RTCW(arg3))-1636])(arg3);
			tb1 = tb2;
		}
		if (tb1) break;
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10833[Dtype(RTCW(arg3))-1636])(arg3);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(RTCW(loc3))-1819])(loc3);
		if (tb2) {
			F210_1915(RTCW(arg1), loc3);
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13403[Dtype(RTCW(loc3))-1819])(loc3);
			if (tb2) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13420[Dtype(RTCW(loc3))-1819])(loc3);
				tr2 = RTOSCF(10264,F1235_10264, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14089[Dtype(RTCW(tr1))-1878])(tr1, tr2);
				RTCT0("postcondition_of_convert_to_type", EX_CHECK);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13420[Dtype(RTCW(loc3))-1819])(loc3);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_6_);
				loc5 = tr1;
				if (EIF_TEST(loc5)) {
					RTCK0;
				} else {
					RTCF0;
				}
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14024[Dtype(loc5)-1868])(loc5);
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(RTCW(loc3))-1819])(loc3);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13877[Dtype(RTCW(tr1))-1868])(tr1);
				if ((EIF_BOOLEAN) !tb2) {
					tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
					tr2 = RTMS_EX_H("Input to sum() contains a mix of numeric and non-numeric values",63,550065267);
					tr3 = RTMS_EX_H("",0,0);
					tr4 = RTMS_EX_H("FORG0006",8,2093721654);
					F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
					F210_1915(RTCW(arg1), tr1);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(RTCW(loc3))-1819])(loc3);
					loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14024[Dtype(RTCW(tr1))-1868])(tr1);
				}
			}
		}
		if ((EIF_BOOLEAN) !loc4) {
			RTCT0("attached l_sum", EX_CHECK);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14156[Dtype(RTCW(loc1))-1898])(loc1);
			if (tb2) {
				F210_1915(RTCW(arg1), loc1);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) R14164[Dtype(RTCW(loc2))-1898])(loc2, ((EIF_INTEGER_32) 15L), loc1);
				loc2 = (EIF_REFERENCE) tr1;
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14156[Dtype(RTCW(loc2))-1898])(loc2);
				if (tb2) {
					F210_1915(RTCW(arg1), loc2);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			}
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10854[Dtype(RTCW(arg3))-1636])(arg3);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + O10835[Dtype(arg3)-1635]);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
		F1820_17198(RTCW(tr1), loc6);
		F210_1915(RTCW(arg1), tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			F210_1915(RTCW(arg1), loc2);
		}
	}
	RTLE;
}

/* {XM_XPATH_SUM}.evaluate_duration_total */
void F1949_19338 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(12);
	RTLR(0,arg2);
	RTLR(1,loc1);
	RTLR(2,arg3);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,Current);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLR(10,loc2);
	RTLR(11,loc5);
	RTLIU(12);
	
	RTGC;
	loc4 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13893[Dtype(RTCW(arg2))-1868])(arg2);
	loc1 = (EIF_REFERENCE) arg2;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10854[Dtype(RTCW(arg3))-1636])(arg3);
	for (;;) {
		tb1 = '\01';
		tb2 = '\01';
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg3) + O10843[Dtype(arg3)-1635]);
		if (!tb3) {
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10840[Dtype(RTCW(arg3))-1636])(arg3);
			tb2 = tb3;
		}
		if (!tb2) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			tb1 = (EIF_BOOLEAN)(tr1 != NULL);
		}
		if (tb1) break;
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10833[Dtype(RTCW(arg3))-1636])(arg3);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(RTCW(loc3))-1819])(loc3);
		if (tb2) {
			F210_1915(RTCW(arg1), loc3);
		} else {
			tb2 = '\01';
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13399[Dtype(RTCW(loc3))-1819])(loc3);
			if (!(EIF_BOOLEAN) !tb3) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(RTCW(loc3))-1819])(loc3);
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13891[Dtype(RTCW(tr1))-1868])(tr1);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("Input to sum() contains mixed duration and non-duration values",62,1340350323);
				tr3 = RTOSCF(9827,F1230_9827, (Current));
				tr4 = RTMS_EX_H("FORG0006",8,2093721654);
				F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
				F210_1915(RTCW(arg1), tr1);
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(RTCW(loc3))-1819])(loc3);
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13990[Dtype(RTCW(tr1))-1868])(tr1);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13893[Dtype(RTCW(loc2))-1868])(loc2);
				if ((EIF_BOOLEAN)(tb2 != loc4)) {
					tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
					tr2 = RTMS_EX_H("Input to sum() contains mixed xs:yearMonthDuration and xs:dayTimeDuration values",80,495027059);
					tr3 = RTOSCF(9827,F1230_9827, (Current));
					tr4 = RTMS_EX_H("FORG0006",8,2093721654);
					F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
					F210_1915(RTCW(arg1), tr1);
				} else {
					loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R14123[Dtype(RTCW(loc1))-1885])(loc1, loc2);
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(RTCW(loc3))-1819])(loc3);
					if (tb2) {
						F210_1915(RTCW(arg1), loc3);
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(RTCW(loc3))-1819])(loc3);
						loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13990[Dtype(RTCW(tr1))-1868])(tr1);
					}
				}
			}
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10854[Dtype(RTCW(arg3))-1636])(arg3);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + O10835[Dtype(arg3)-1635]);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
		F1820_17198(RTCW(tr1), loc5);
		F210_1915(RTCW(arg1), tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			F210_1915(RTCW(arg1), loc1);
		}
	}
	RTLE;
}

void EIF_Minit1021 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
