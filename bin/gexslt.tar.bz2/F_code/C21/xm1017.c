/*
 * Code for class XM_XPATH_TRACE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1017.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_TRACE}.make */
void F1945_19306 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("trace",5,1919875941);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1895L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_TRACE}.item_type */
EIF_REFERENCE F1945_19307 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13827[Dtype(RTCW(tr1))-1868])(tr1);
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_TRACE}.required_type */
EIF_REFERENCE F1945_19308 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16773(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16782(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {XM_XPATH_TRACE}.pre_evaluate */
void F1945_19309 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F210_1915(RTCW(arg1), Current);
}

/* {XM_XPATH_TRACE}.evaluate_item */
void F1945_19310 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc4);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12554[Dtype(RTCW(arg2))-1766])(arg2);
	loc3 = *(EIF_BOOLEAN *)(RTCW(tr1) + O12168[Dtype(tr1)-1748]);
	if ((EIF_BOOLEAN) !loc3) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13948[Dtype(RTCW(tr1))-1868])(tr1, arg2);
		RTCT0("postcondition_of_evaluate_as_string", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13839[Dtype(tr1)-1867]);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc1 = (EIF_REFERENCE) loc4;
		tb1 = F1868_17865(RTCW(loc1));
		if (tb1) {
			F210_1915(RTCW(arg1), loc1);
		} else {
			loc2 = F1884_18326(RTCW(loc1));
		}
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
		if ((EIF_BOOLEAN) !loc3) {
			RTCT0("attached l_label", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			F1212_9664(Current, loc2, tr1, arg2);
		}
	}
	RTLE;
}

/* {XM_XPATH_TRACE}.create_iterator */
void F1945_19311 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc4);
	RTLR(4,loc5);
	RTLR(5,loc6);
	RTLR(6,loc1);
	RTLR(7,loc3);
	RTLR(8,loc7);
	RTLR(9,loc2);
	RTLIU(10);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13949[Dtype(RTCW(tr1))-1868])(tr1, arg1);
	RTCT0("postcondition_of_create_iterator", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13841[Dtype(tr1)-1867]);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTAR(Current, loc4);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc4;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12554[Dtype(RTCW(arg1))-1766])(arg1);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O12168[Dtype(tr1)-1748]);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(loc4 + O10835[Dtype(loc4)-1635]);
		loc5 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc5)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13948[Dtype(RTCW(tr1))-1868])(tr1, arg1);
			RTCT0("postcondition_of_evaluate_as_string", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13839[Dtype(tr1)-1867]);
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				RTCK0;
			} else {
				RTCF0;
			}
			loc1 = (EIF_REFERENCE) loc6;
			tb1 = F1868_17865(RTCW(loc1));
			if ((EIF_BOOLEAN) !tb1) {
				loc3 = F1884_18326(RTCW(loc1));
			} else {
				loc3 = RTMS_EX_H("",0,0);
			}
			tr1 = RTLNS(eif_new_type(1637, 0x01).id, 1637, _OBJSIZ_6_2_0_1_0_0_0_0_);
			F1638_13782(RTCW(tr1), loc4, loc3, arg1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13948[Dtype(RTCW(tr1))-1868])(tr1, arg1);
			RTCT0("postcondition_of_evaluate_as_string", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13839[Dtype(tr1)-1867]);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				RTCK0;
			} else {
				RTCF0;
			}
			loc1 = (EIF_REFERENCE) loc7;
			tb1 = F1868_17865(RTCW(loc1));
			if ((EIF_BOOLEAN) !tb1) {
				loc3 = F1884_18326(RTCW(loc1));
			} else {
				loc3 = RTMS_EX_H("",0,0);
			}
			loc2 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			F1820_17198(RTCW(loc2), loc5);
			F1212_9664(Current, loc3, loc2, arg1);
		}
	}
	RTLE;
}

/* {XM_XPATH_TRACE}.create_node_iterator */
void F1945_19312 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc4);
	RTLR(4,loc5);
	RTLR(5,loc6);
	RTLR(6,loc1);
	RTLR(7,loc3);
	RTLR(8,loc7);
	RTLR(9,loc2);
	RTLIU(10);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13950[Dtype(RTCW(tr1))-1868])(tr1, arg1);
	RTCT0("postcondition_of_create_node_iterator", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13842[Dtype(tr1)-1867]);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTAR(Current, loc4);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) loc4;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12554[Dtype(RTCW(arg1))-1766])(arg1);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O12168[Dtype(tr1)-1748]);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(loc4 + O10835[Dtype(loc4)-1635]);
		loc5 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc5)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13948[Dtype(RTCW(tr1))-1868])(tr1, arg1);
			RTCT0("postcondition_of_evaluate_as_string", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13839[Dtype(tr1)-1867]);
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				RTCK0;
			} else {
				RTCF0;
			}
			loc1 = (EIF_REFERENCE) loc6;
			tb1 = F1868_17865(RTCW(loc1));
			if ((EIF_BOOLEAN) !tb1) {
				loc3 = F1884_18326(RTCW(loc1));
			} else {
				loc3 = RTMS_EX_H("",0,0);
			}
			tr1 = RTLNS(eif_new_type(1636, 0x01).id, 1636, _OBJSIZ_6_2_0_1_0_0_0_0_);
			F1637_13772(RTCW(tr1), loc4, loc3, arg1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13948[Dtype(RTCW(tr1))-1868])(tr1, arg1);
			RTCT0("postcondition_of_evaluate_as_string", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13839[Dtype(tr1)-1867]);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				RTCK0;
			} else {
				RTCF0;
			}
			loc1 = (EIF_REFERENCE) loc7;
			tb1 = F1868_17865(RTCW(loc1));
			if ((EIF_BOOLEAN) !tb1) {
				loc3 = F1884_18326(RTCW(loc1));
			} else {
				loc3 = RTMS_EX_H("",0,0);
			}
			loc2 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			F1820_17198(RTCW(loc2), loc5);
			F1212_9664(Current, loc3, loc2, arg1);
		}
	}
	RTLE;
}

/* {XM_XPATH_TRACE}.compute_cardinality */
void F1945_19313 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13907[Dtype(RTCW(tr1))-1868])(tr1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O6478[Dtype(tr1)-1123]);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13988[Dtype(RTCW(tr1))-1868])(tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R14218[Dtype(RTCW(tr1))-1904])(tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	F1124_8082(Current, tr1);
	RTLE;
}

/* {XM_XPATH_TRACE}.compute_special_properties */
void F1945_19314 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13907[Dtype(RTCW(tr1))-1868])(tr1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O6479[Dtype(tr1)-1123]);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13988[Dtype(RTCW(tr1))-1868])(tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R14219[Dtype(RTCW(tr1))-1904])(tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	F1124_8101(Current, tr1);
	RTLE;
}

void EIF_Minit1017 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
