/*
 * Code for class XM_XPATH_NAME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1008.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_NAME}.make */
void F1936_19255 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("name",4,1851878757);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1855L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = RTMS_EX_H("XPTY0004",8,457775924);
	F1927_19196(Current, tr1);
	RTLE;
}

/* {XM_XPATH_NAME}.item_type */
EIF_REFERENCE F1936_19256 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10254,F1235_10254, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_NAME}.required_type */
EIF_REFERENCE F1936_19257 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
	F1801_16790(RTCW(tr1));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_XPATH_NAME}.simplify */
void F1936_19258 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1927_19194(Current);
	F1927_19193(Current, arg1);
	RTLE;
}

/* {XM_XPATH_NAME}.evaluate_item */
void F1936_19259 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc2)-1819])(loc2);
		if ((EIF_BOOLEAN) !tb1) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13398[Dtype(loc2)-1819])(loc2);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
				tr2 = RTMS_EX_H("",0,0);
				F1884_18322(RTCW(tr1), tr2);
				F210_1915(RTCW(arg1), tr1);
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13416[Dtype(loc2)-1819])(loc2);
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13626[Dtype(RTCW(tr1))-1853])(tr1);
				if ((EIF_BOOLEAN)(loc1 == NULL)) {
					loc1 = RTMS_EX_H("",0,0);
				}
				tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
				F1884_18322(RTCW(tr1), loc1);
				F210_1915(RTCW(arg1), tr1);
			}
		}
	}
	RTLE;
}

/* {XM_XPATH_NAME}.compute_cardinality */
void F1936_19260 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8089(Current);
}

void EIF_Minit1008 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
