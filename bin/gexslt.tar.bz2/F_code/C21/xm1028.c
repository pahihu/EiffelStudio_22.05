/*
 * Code for class XM_XPATH_ROUND_HALF_EVEN
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1028.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_ROUND_HALF_EVEN}.make */
void F1956_19374 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("round-half-to-even",18,1483393390);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1876L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_ROUND_HALF_EVEN}.item_type */
EIF_REFERENCE F1956_19375 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13827[Dtype(RTCW(tr1))-1868])(tr1);
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_ROUND_HALF_EVEN}.required_type */
EIF_REFERENCE F1956_19376 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16793(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16785(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {XM_XPATH_ROUND_HALF_EVEN}.evaluate_item */
void F1956_19377 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_64 ti8_1;
	EIF_INTEGER_64 ti8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc4);
	RTLR(5,loc1);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,tr4);
	RTLR(9,loc5);
	RTLIU(10);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
		RTCT0("integer_precision", EX_CHECK);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13406[Dtype(loc4)-1819])(loc4);
			tb1 = tb2;
		}
		if (tb1) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13423[Dtype(loc4)-1819])(loc4);
		ti8_1 = *(EIF_INTEGER_64 *)(RTCW(loc1)+ _I64OFF_7_37_0_1_0_0_0_);
		ti8_1 = eif_abs_int64 (ti8_1);
		ti4_1 = RTOSCF(2037,F228_2037, (RTCV(RTOSCF(1557,F173_1557, (Current)))));
		ti8_2 = (EIF_INTEGER_64) ti4_1;
		if ((EIF_BOOLEAN) (ti8_1 <= ti8_2)) {
			ti8_1 = *(EIF_INTEGER_64 *)(RTCW(loc1)+ _I64OFF_7_37_0_1_0_0_0_);
			loc2 = (EIF_INTEGER_32) ti8_1;
		} else {
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("Precision specified in round-to-half-even is outside the supported range.",73,417092910);
			tr3 = RTOSCF(9829,F1230_9829, (Current));
			tr4 = RTMS_EX_H("PRECISION_OUT_OF_RANGE",22,1724570437);
			F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
			F210_1915(RTCW(arg1), tr1);
		}
	}
	if ((EIF_BOOLEAN) !loc3) {
		F210_1915(RTCW(arg1), NULL);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc5)-1819])(loc5);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(loc5)-1819])(loc5);
			tr1 = F1878_18228(RTCW(tr1));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14024[Dtype(RTCW(tr1))-1868])(tr1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14166[Dtype(RTCW(tr1))-1898])(tr1, loc2);
			F210_1915(RTCW(arg1), tr1);
		}
	}
	RTLE;
}

/* {XM_XPATH_ROUND_HALF_EVEN}.compute_cardinality */
void F1956_19378 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8085(Current);
}

void EIF_Minit1028 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
