/*
 * Code for class XM_XPATH_NAMESPACE_URI_FOR_PREFIX
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1042.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_NAMESPACE_URI_FOR_PREFIX}.make */
void F1970_19471 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("namespace-uri-for-prefix",24,1516827000);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1857L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_NAMESPACE_URI_FOR_PREFIX}.item_type */
EIF_REFERENCE F1970_19472 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10254,F1235_10254, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_NAMESPACE_URI_FOR_PREFIX}.required_type */
EIF_REFERENCE F1970_19473 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16782(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		loc1 = RTLNS(eif_new_type(1832, 0x01).id, 1832, _OBJSIZ_1_0_0_1_0_0_0_0_);
		F1833_17346(RTCW(loc1));
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16770(RTCW(tr1), loc1, ((EIF_INTEGER_32) 3L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {XM_XPATH_NAMESPACE_URI_FOR_PREFIX}.evaluate_item */
void F1970_19474 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc4);
	RTLR(5,loc3);
	RTLR(6,loc5);
	RTLR(7,loc1);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,tr4);
	RTLIU(11);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
	RTCT0("attached a_result.item as a_result_item_2", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc4)-1819])(loc4);
	if ((EIF_BOOLEAN) !tb1) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13401[Dtype(loc4)-1819])(loc4);
		if (tb1) {
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13418[Dtype(loc4)-1819])(loc4);
			F210_1915(RTCW(arg1), NULL);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
			RTCT0("attached a_result.item as a_result_item_1", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			loc5 = tr1;
			if (EIF_TEST(loc5)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc5)-1819])(loc5);
			if ((EIF_BOOLEAN) !tb1) {
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(loc5)-1819])(loc5);
				F210_1915(RTCW(arg1), NULL);
				loc2 = F1862_17688(RTCW(loc3), loc1);
				tr1 = RTOSCF(4950,F991_4950, (Current));
				tb1 = F1242_10424(RTCW(tr1), loc2);
				if (tb1) {
					tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
					tr2 = RTOSCF(4950,F991_4950, (Current));
					tr2 = F1242_10454(RTCW(tr2), loc2);
					F1884_18322(RTCW(tr1), tr2);
					F210_1915(RTCW(arg1), tr1);
				}
			}
		} else {
			tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("Second argument is not an element",33,1960867188);
			tr3 = RTOSCF(9827,F1230_9827, (Current));
			tr4 = RTMS_EX_H("FORG0006",8,2093721654);
			F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
			F210_1915(RTCW(arg1), tr1);
		}
	}
	RTLE;
}

/* {XM_XPATH_NAMESPACE_URI_FOR_PREFIX}.compute_cardinality */
void F1970_19475 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8089(Current);
}

void EIF_Minit1042 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
