/*
 * Code for class XM_XPATH_POSITION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1037.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_POSITION}.make */
void F1965_19435 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("position",8,91951726);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1867L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_POSITION}.is_position_function */
EIF_BOOLEAN F1965_19436 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_XPATH_POSITION}.item_type */
EIF_REFERENCE F1965_19437 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10265,F1235_10265, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_POSITION}.required_type */
EIF_REFERENCE F1965_19438 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	RTCT0("False", EX_CHECK);
		RTCF0;
	return (EIF_REFERENCE) 0;
}

/* {XM_XPATH_POSITION}.compute_intrinsic_dependencies */
void F1965_19439 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8046(Current);
}

/* {XM_XPATH_POSITION}.evaluate_item */
void F1965_19440 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_64 ti8_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == NULL)) {
		tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("Dynamic context is Void",23,2075073380);
		tr3 = RTOSCF(9827,F1230_9827, (Current));
		tr4 = RTMS_EX_H("FONC0001",8,2085826609);
		F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
		F210_1915(RTCW(arg1), tr1);
	} else {
		tb1 = F1766_16119(RTCW(arg2));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("Context position is not available",33,1375998565);
			tr3 = RTOSCF(9827,F1230_9827, (Current));
			tr4 = RTMS_EX_H("FONC0001",8,2085826609);
			F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
			F210_1915(RTCW(arg1), tr1);
		} else {
			loc1 = F1766_16108(RTCW(arg2));
			if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
				tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("Context position cannot be zero",31,863872623);
				tr3 = RTOSCF(9827,F1230_9827, (Current));
				tr4 = RTMS_EX_H("FONC0001",8,2085826609);
				F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
				F210_1915(RTCW(arg1), tr1);
			} else {
				tr1 = RTLNS(eif_new_type(1902, 0x01).id, 1902, _OBJSIZ_7_37_0_1_0_0_1_0_);
				ti8_1 = (EIF_INTEGER_64) loc1;
				F1903_18707(RTCW(tr1), ti8_1);
				F210_1915(RTCW(arg1), tr1);
			}
		}
	}
	RTLE;
}

/* {XM_XPATH_POSITION}.pre_evaluate */
void F1965_19441 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F210_1915(RTCW(arg1), Current);
}

/* {XM_XPATH_POSITION}.compute_cardinality */
void F1965_19442 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8089(Current);
}

void EIF_Minit1037 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
