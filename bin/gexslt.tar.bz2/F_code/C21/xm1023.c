/*
 * Code for class XM_XPATH_STRING_JOIN
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1023.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_STRING_JOIN}.make */
void F1951_19344 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("string-join",11,1817329262);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1883L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_STRING_JOIN}.item_type */
EIF_REFERENCE F1951_19345 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10254,F1235_10254, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_STRING_JOIN}.required_type */
EIF_REFERENCE F1951_19346 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		Result = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		tr1 = RTOSCF(10254,F1235_10254, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
		F1801_16770(RTCW(Result), tr1, ((EIF_INTEGER_32) 5L));
	} else {
		Result = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16782(RTCW(Result));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_STRING_JOIN}.optimize */
void F1951_19347 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	F1925_19148(Current, arg1, arg2, arg3);
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F1868_17865(Current)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		tb1 = (EIF_BOOLEAN)(tr1 == Current);
	}
	if (tb1) {
		loc1 = F1951_19350(Current);
		if ((EIF_BOOLEAN)(loc1 != Current)) {
			F210_1915(RTCW(arg1), NULL);
			F1868_17969(Current, arg1, loc1);
		}
	}
	RTLE;
}

/* {XM_XPATH_STRING_JOIN}.evaluate_item */
void F1951_19348 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,loc5);
	RTLR(4,loc1);
	RTLR(5,loc6);
	RTLR(6,arg1);
	RTLR(7,loc7);
	RTLR(8,tr2);
	RTLR(9,loc3);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLR(12,loc4);
	RTLR(13,loc2);
	RTLR(14,loc10);
	RTLIU(15);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13949[Dtype(RTCW(tr1))-1868])(tr1, arg2);
	RTCT0("postcondition_of_create_iterator", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13841[Dtype(tr1)-1867]);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = (EIF_REFERENCE) loc5;
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O10835[Dtype(loc1)-1635]);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
		F1820_17198(RTCW(tr1), loc6);
		F210_1915(RTCW(arg1), tr1);
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10853[Dtype(RTCW(loc1))-1636])(loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O10835[Dtype(loc1)-1635]);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			F1820_17198(RTCW(tr1), loc7);
			F210_1915(RTCW(arg1), tr1);
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10840[Dtype(RTCW(loc1))-1636])(loc1);
			if (tb1) {
				tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
				tr2 = RTMS_EX_H("",0,0);
				F1884_18322(RTCW(tr1), tr2);
				F210_1915(RTCW(arg1), tr1);
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10833[Dtype(RTCW(loc1))-1636])(loc1);
				loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(tr1))-1819])(tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R10854[Dtype(RTCW(loc1))-1636])(loc1);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O10835[Dtype(loc1)-1635]);
				loc8 = tr1;
				if (EIF_TEST(loc8)) {
					tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
					F1820_17198(RTCW(tr1), loc8);
					F210_1915(RTCW(arg1), tr1);
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10840[Dtype(RTCW(loc1))-1636])(loc1);
					if (tb1) {
						tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
						F1884_18322(RTCW(tr1), loc3);
						F210_1915(RTCW(arg1), tr1);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
						tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
						RTCT0("second_string_not_void", EX_CHECK);
						tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
						loc9 = tr1;
						if (EIF_TEST(loc9)) {
							RTCK0;
						} else {
							RTCF0;
						}
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc9)-1819])(loc9);
						if (tb1) {
						} else {
							loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(loc9)-1819])(loc9);
							tr1 = RTOSCF(8530,F1163_8530, (Current));
							loc2 = F1148_8376(RTCW(tr1), loc3);
							for (;;) {
								tb1 = '\01';
								tb2 = *(EIF_BOOLEAN *)(RTCW(loc1) + O10843[Dtype(loc1)-1635]);
								if (!tb2) {
									tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10840[Dtype(RTCW(loc1))-1636])(loc1);
									tb1 = tb2;
								}
								if (tb1) break;
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10833[Dtype(RTCW(loc1))-1636])(loc1);
								loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(tr1))-1819])(tr1);
								tr1 = RTOSCF(8530,F1163_8530, (Current));
								tr1 = F1148_8377(RTCW(tr1), loc2, loc4);
								loc2 = (EIF_REFERENCE) tr1;
								tr1 = RTOSCF(8530,F1163_8530, (Current));
								tr1 = F1148_8377(RTCW(tr1), loc2, loc3);
								loc2 = (EIF_REFERENCE) tr1;
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R10854[Dtype(RTCW(loc1))-1636])(loc1);
							}
							tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O10835[Dtype(loc1)-1635]);
							loc10 = tr1;
							if (EIF_TEST(loc10)) {
								tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
								F1820_17198(RTCW(tr1), loc10);
								F210_1915(RTCW(arg1), tr1);
							} else {
								tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
								F1884_18322(RTCW(tr1), loc2);
								F210_1915(RTCW(arg1), tr1);
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_XPATH_STRING_JOIN}.compute_cardinality */
void F1951_19349 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8089(Current);
}

/* {XM_XPATH_STRING_JOIN}.simplified_singleton */
EIF_REFERENCE F1951_19350 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O6544[Dtype(tr1)-1123]);
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) Current;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		Result = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	}
	RTLE;
	return Result;
}

void EIF_Minit1023 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
