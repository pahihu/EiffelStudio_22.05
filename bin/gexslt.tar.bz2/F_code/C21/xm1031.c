/*
 * Code for class XM_XPATH_RESOLVE_URI
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1031.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_RESOLVE_URI}.make */
void F1959_19391 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("resolve-uri",11,1011499369);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1872L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_RESOLVE_URI}.item_type */
EIF_REFERENCE F1959_19392 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10259,F1235_10259, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_RESOLVE_URI}.required_type */
EIF_REFERENCE F1959_19393 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16783(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16782(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {XM_XPATH_RESOLVE_URI}.check_static_type */
void F1959_19394 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8483[Dtype(RTCW(arg2))-1240])(arg2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	}
	F1925_19147(Current, arg1, arg2, arg3);
	RTLE;
}

/* {XM_XPATH_RESOLVE_URI}.evaluate_item */
void F1959_19395 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc4);
	RTLR(5,loc1);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,tr4);
	RTLR(9,loc3);
	RTLR(10,loc5);
	RTLR(11,loc2);
	RTLIU(12);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
		RTCT0("attached a_result.item as a_result_item_2", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc4)-1819])(loc4);
		if ((EIF_BOOLEAN) !tb1) {
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(loc4)-1819])(loc4);
			F210_1915(RTCW(arg1), NULL);
			tb1 = F772_3900(RTCW(loc1));
			if (tb1) {
				tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("Second argument to fn:resolve-uri() is the empty string",55,1657374567);
				tr3 = RTOSCF(9827,F1230_9827, (Current));
				tr4 = RTMS_EX_H("FORG0002",8,2093721650);
				F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
				F210_1915(RTCW(arg1), tr1);
			} else {
				tr1 = RTOSCF(3597,F478_3597, (Current));
				tb1 = F1753_15784(RTCW(tr1), loc1);
				if (tb1) {
					tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
					tr2 = RTMS_EX_H("Second argument to fn:resolve-uri() has invalid characters",58,1381641075);
					tr3 = RTOSCF(9827,F1230_9827, (Current));
					tr4 = RTMS_EX_H("FORG0002",8,2093721650);
					F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
					F210_1915(RTCW(arg1), tr1);
				} else {
					tc1 = (EIF_CHARACTER_8) '#';
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R3400[Dtype(RTCW(loc1))-1112])(loc1, (EIF_REFERENCE) &tc1);
					if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
						tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("Second argument to fn:resolve-uri() has more than 1 #",53,1699241507);
						tr3 = RTOSCF(9827,F1230_9827, (Current));
						tr4 = RTMS_EX_H("FORG0002",8,2093721650);
						F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
						F210_1915(RTCW(arg1), tr1);
					} else {
						loc3 = RTLNSMART(eif_new_type(1706, 0).id);
						F1707_14586(RTCW(loc3), loc1);
						RTAR(Current, loc3);
						*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) loc3;
						tb1 = F1707_14593(RTCW(loc3));
						if ((EIF_BOOLEAN) !tb1) {
							tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
							tr2 = RTMS_EX_H("Second argument to fn:resolve-uri() is not an absolute URI",58,58401353);
							tr3 = RTOSCF(9827,F1230_9827, (Current));
							tr4 = RTMS_EX_H("FORG0002",8,2093721650);
							F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
							F210_1915(RTCW(arg1), tr1);
						}
					}
				}
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		loc3 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		RTCT0("attached l_base_uri", EX_CHECK);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tb1 = F1707_14593(RTCW(loc3));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("Base URI supplied as second argument of fn:resolve-uri() is not absolute",72,363311205);
			tr3 = RTOSCF(9827,F1230_9827, (Current));
			tr4 = RTMS_EX_H("FORG0009",8,2093721657);
			F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
			F210_1915(RTCW(arg1), tr1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			loc5 = tr1;
			if (EIF_TEST(loc5)) {
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc5)-1819])(loc5);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(loc5)-1819])(loc5);
				F210_1915(RTCW(arg1), NULL);
				tb1 = F772_3900(RTCW(loc1));
				if (tb1) {
					loc2 = (EIF_REFERENCE) loc3;
				} else {
					tr1 = RTOSCF(3597,F478_3597, (Current));
					tb1 = F1753_15784(RTCW(tr1), loc1);
					if (tb1) {
						tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("First argument to fn:resolve-uri() has invalid characters",57,203462771);
						tr3 = RTOSCF(9827,F1230_9827, (Current));
						tr4 = RTMS_EX_H("FORG0002",8,2093721650);
						F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
						F210_1915(RTCW(arg1), tr1);
					} else {
						tc1 = (EIF_CHARACTER_8) '#';
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R3400[Dtype(RTCW(loc1))-1112])(loc1, (EIF_REFERENCE) &tc1);
						if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
							tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
							tr2 = RTMS_EX_H("First argument to fn:resolve-uri() has more than 1 #",52,237881379);
							tr3 = RTOSCF(9827,F1230_9827, (Current));
							tr4 = RTMS_EX_H("FORG0002",8,2093721650);
							F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
							F210_1915(RTCW(arg1), tr1);
						} else {
							loc2 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
							F1707_14587(RTCW(loc2), loc3, loc1);
							tb1 = F1707_14593(RTCW(loc2));
							if ((EIF_BOOLEAN) !tb1) {
								tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
								tr2 = RTMS_EX_H("URI resolution process failed",29,9008996);
								tr3 = RTOSCF(9827,F1230_9827, (Current));
								tr4 = RTMS_EX_H("FORG0009",8,2093721657);
								F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
								F210_1915(RTCW(arg1), tr1);
							}
						}
					}
				}
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
				if ((EIF_BOOLEAN)(tr1 == NULL)) {
					RTCT0("attached l_uri", EX_CHECK);
					if ((EIF_BOOLEAN)(loc2 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					tr1 = RTLNS(eif_new_type(1884, 0x01).id, 1884, _OBJSIZ_10_38_0_1_0_0_0_0_);
					tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
					F1885_18342(RTCW(tr1), tr2);
					F210_1915(RTCW(arg1), tr1);
				}
			}
		}
	}
	RTLE;
}

/* {XM_XPATH_RESOLVE_URI}.compute_cardinality */
void F1959_19396 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8085(Current);
}

void EIF_Minit1031 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
