/*
 * Code for class XM_XPATH_TRANSLATE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1016.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_TRANSLATE}.make */
void F1944_19299 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("translate",9,1890925669);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1896L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_TRANSLATE}.item_type */
EIF_REFERENCE F1944_19300 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10254,F1235_10254, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_TRANSLATE}.required_type */
EIF_REFERENCE F1944_19301 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	switch (arg1) {
		case 1L:
			Result = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
			F1801_16783(RTCW(Result));
			break;
		case 2L:
			Result = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
			F1801_16782(RTCW(Result));
			break;
		case 3L:
			Result = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
			F1801_16782(RTCW(Result));
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_TRANSLATE}.evaluate_item */
void F1944_19302 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,loc1);
	RTLR(7,tr2);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc2);
	RTLR(11,loc8);
	RTLR(12,loc9);
	RTLR(13,loc3);
	RTLR(14,tr3);
	RTLIU(15);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc4)-1819])(loc4);
		tb1 = tb2;
	}
	if (tb1) {
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(loc5)-1819])(loc5);
		}
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
			tr2 = RTMS_EX_H("",0,0);
			F1884_18322(RTCW(tr1), tr2);
			F210_1915(RTCW(arg1), tr1);
		} else {
			F210_1915(RTCW(arg1), NULL);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc6)-1819])(loc6);
				tb1 = tb2;
			}
			if (tb1) {
			} else {
				RTCT0("source_map", EX_CHECK);
				tb1 = '\0';
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
				loc7 = tr1;
				if (EIF_TEST(loc7)) {
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13409[Dtype(loc7)-1819])(loc7);
					tb1 = tb2;
				}
				if (tb1) {
					RTCK0;
				} else {
					RTCF0;
				}
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13428[Dtype(loc7)-1819])(loc7);
				F210_1915(RTCW(arg1), NULL);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 3L));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
				tb1 = '\0';
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
				loc8 = tr1;
				if (EIF_TEST(loc8)) {
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc8)-1819])(loc8);
					tb1 = tb2;
				}
				if (tb1) {
				} else {
					RTCT0("target_map", EX_CHECK);
					tb1 = '\0';
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
					loc9 = tr1;
					if (EIF_TEST(loc9)) {
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13409[Dtype(loc9)-1819])(loc9);
						tb1 = tb2;
					}
					if (tb1) {
						RTCK0;
					} else {
						RTCF0;
					}
					loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13428[Dtype(loc9)-1819])(loc9);
					tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
					tr2 = F1884_18326(RTCW(loc2));
					tr3 = F1884_18326(RTCW(loc3));
					tr2 = F1944_19304(Current, loc1, tr2, tr3);
					F1884_18322(RTCW(tr1), tr2);
					F210_1915(RTCW(arg1), tr1);
				}
			}
		}
	}
	RTLE;
}

/* {XM_XPATH_TRANSLATE}.compute_cardinality */
void F1944_19303 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8089(Current);
}

/* {XM_XPATH_TRANSLATE}.translated_string */
EIF_REFERENCE F1944_19304 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,Result);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLR(6,Current);
	RTLR(7,tr1);
	RTLIU(8);
	
	RTGC;
	Result = RTMS_EX_H("",0,0);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, loc1);
		loc4 = F1944_19305(Current, loc3, arg2, arg3);
		if ((EIF_BOOLEAN)(loc4 == NULL)) {
			loc4 = (EIF_REFERENCE) loc3;
		}
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr1 = F1148_8377(RTCW(tr1), Result, loc4);
		Result = (EIF_REFERENCE) tr1;
		loc1++;
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_TRANSLATE}.translated_character */
EIF_REFERENCE F1944_19305 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLR(4,arg3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	loc1 = F1148_8365(RTCW(tr1), arg2, arg1, ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc1 <= ti4_1)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg3))-1111])(arg3, loc1, loc1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			Result = RTMS_EX_H("",0,0);
		}
	} else {
		RTLE;
		return (EIF_REFERENCE) NULL;
	}
	RTLE;
	return Result;
}

void EIF_Minit1016 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
