/*
 * Code for class XM_XPATH_TRUE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1015.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_TRUE}.make */
void F1943_19293 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("true",4,1953658213);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1897L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_TRUE}.item_type */
EIF_REFERENCE F1943_19294 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10255,F1235_10255, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_TRUE}.required_type */
EIF_REFERENCE F1943_19295 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
	RTCT0("False", EX_CHECK);
		RTCF0;
	return (EIF_REFERENCE) 0;
}

/* {XM_XPATH_TRUE}.calculate_effective_boolean_value */
void F1943_19296 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1882, 0).id);
	F1883_18308(RTCW(tr1), (EIF_BOOLEAN) 1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XPATH_TRUE}.evaluate_item */
void F1943_19297 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	F1943_19296(Current, arg2);
	F210_1915(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTLE;
}

/* {XM_XPATH_TRUE}.compute_cardinality */
void F1943_19298 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8089(Current);
}

void EIF_Minit1015 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
