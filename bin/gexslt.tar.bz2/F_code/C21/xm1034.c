/*
 * Code for class XM_XPATH_REPLACE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1034.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_REPLACE}.make */
void F1962_19411 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("replace",7,1413879909);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_15_40_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1870L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_15_40_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_15_40_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_15_38_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_REPLACE}.item_type */
EIF_REFERENCE F1962_19412 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10254,F1235_10254, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_REPLACE}.required_type */
EIF_REFERENCE F1962_19413 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	switch (arg1) {
		case 1L:
			Result = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
			F1801_16783(RTCW(Result));
			break;
		default:
			Result = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
			F1801_16782(RTCW(Result));
			break;
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_REPLACE}.simplify */
void F1962_19414 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	F1927_19193(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 4L))) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
		}
		F1568_12803(Current, loc1, *(EIF_REFERENCE *)(Current + _REFACS_9_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F210_1915(RTCW(arg1), NULL);
			tr1 = RTLNS(eif_new_type(1881, 0x01).id, 1881, _OBJSIZ_7_37_0_1_0_0_0_0_);
			F1882_18293(RTCW(tr1), loc2);
			F1868_17969(Current, arg1, tr1);
		}
	}
	RTLE;
}

/* {XM_XPATH_REPLACE}.evaluate_item */
void F1962_19415 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc4);
	RTLR(5,loc1);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLR(8,loc2);
	RTLR(9,loc3);
	RTLR(10,loc7);
	RTLR(11,tr2);
	RTLR(12,tr3);
	RTLR(13,tr4);
	RTLIU(14);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc4 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc4)) {
		loc1 = RTMS_EX_H("",0,0);
		F210_1915(RTCW(arg1), NULL);
	} else {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc4)-1819])(loc4);
		if (tb1) {
			loc1 = RTMS_EX_H("",0,0);
		} else {
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(loc4)-1819])(loc4);
			tr1 = RTOSCF(4521,F954_4521, (Current));
			tr1 = F1138_8299(RTCW(tr1), loc1);
			loc1 = (EIF_REFERENCE) tr1;
			F210_1915(RTCW(arg1), NULL);
		}
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc5)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
			RTCT0("pattern_not_empty", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc6)-1819])(loc6);
			if (tb1) {
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(loc6)-1819])(loc6);
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(tr1))-1819])(tr1);
				tr1 = RTOSCF(4521,F954_4521, (Current));
				tr1 = F1138_8299(RTCW(tr1), loc2);
				loc2 = (EIF_REFERENCE) tr1;
				F210_1915(RTCW(arg1), NULL);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 3L))) {
					loc3 = RTMS_EX_H("",0,0);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
					tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 4L));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
					RTCT0("flags_not_empty", EX_CHECK);
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
					loc7 = tr1;
					if (EIF_TEST(loc7)) {
						RTCK0;
					} else {
						RTCF0;
					}
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc7)-1819])(loc7);
					if (tb1) {
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(loc7)-1819])(loc7);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(tr1))-1819])(tr1);
						loc3 = F1223_9740(Current, tr1);
					}
				}
				if ((EIF_BOOLEAN)(loc3 == NULL)) {
					tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
					tr2 = RTMS_EX_H("Unknown flags in regular expression",35,985519214);
					tr3 = RTOSCF(9827,F1230_9827, (Current));
					tr4 = RTMS_EX_H("FORX0001",8,2093852209);
					F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 1L));
					F210_1915(RTCW(arg1), tr1);
				} else {
					F210_1915(RTCW(arg1), NULL);
					F1962_19423(Current, arg1, loc2, loc3);
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
					if ((EIF_BOOLEAN)(tr1 == NULL)) {
						F1962_19424(Current, arg1, arg2);
					}
				}
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(loc5);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
			F1962_19424(Current, arg1, arg2);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			F1962_19422(Current, arg1, loc1);
		}
	}
	RTLE;
}

/* {XM_XPATH_REPLACE}.compute_cardinality */
void F1962_19416 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8089(Current);
}

/* {XM_XPATH_REPLACE}.check_replacement_string */
void F1962_19420 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	RTCT0("precondition_replacement_string_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
		}
		if (tb1) break;
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(loc3)-1112])(loc3, loc1);
		switch (loc2) {
			case 36L:
				tb2 = '\0';
				if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L))) {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(loc3)-1112])(loc3, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
					tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 92L));
				}
				if (tb2) {
				} else {
					ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (loc1 < ti4_1)) {
						loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(loc3)-1112])(loc3, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 48L)) || (EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 57L)))) {
							tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
							tr2 = RTMS_EX_H("Invalid replacement string in fn:replace(): $ sign must be followed by digit 0-9",80,493549369);
							tr3 = RTOSCF(9827,F1230_9827, (Current));
							tr4 = RTMS_EX_H("FORX0004",8,2093852212);
							F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
							F210_1915(RTCW(arg1), tr1);
						} else {
							*(EIF_BOOLEAN *)(Current+ _CHROFF_15_39_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						}
					} else {
						tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("Invalid replacement string in fn:replace(): $ sign at end of string",67,1325969511);
						tr3 = RTOSCF(9827,F1230_9827, (Current));
						tr4 = RTMS_EX_H("FORX0004",8,2093852212);
						F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
						F210_1915(RTCW(arg1), tr1);
					}
				}
				break;
			case 92L:
				tb2 = '\0';
				if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L))) {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(loc3)-1112])(loc3, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
					tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 92L));
				}
				if (tb2) {
				} else {
					tb2 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (loc1 < ti4_1)) {
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(loc3)-1112])(loc3, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 36L));
					}
					if (tb2) {
					} else {
						tb2 = '\0';
						ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_1_0_2_);
						if ((EIF_BOOLEAN) (loc1 < ti4_1)) {
							ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(loc3)-1112])(loc3, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
							tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 92L));
						}
						if (tb2) {
						} else {
							ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_1_0_2_);
							if ((EIF_BOOLEAN) (loc1 < ti4_1)) {
								tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
								tr2 = RTMS_EX_H("Invalid replacement string in fn:replace(): \\ must be followed by \\ or $",72,576900900);
								tr3 = RTOSCF(9827,F1230_9827, (Current));
								tr4 = RTMS_EX_H("FORX0004",8,2093852212);
								F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
								F210_1915(RTCW(arg1), tr1);
							} else {
								tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
								tr2 = RTMS_EX_H("Invalid replacement string in fn:replace(): single \\ sign at end of string",74,335176807);
								tr3 = RTOSCF(9827,F1230_9827, (Current));
								tr4 = RTMS_EX_H("FORX0004",8,2093852212);
								F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
								F210_1915(RTCW(arg1), tr1);
							}
						}
					}
				}
				break;
		}
		loc1++;
	}
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tb2 = *(EIF_BOOLEAN *)(Current+ _CHROFF_15_39_);
	}
	if (tb2) {
		F1962_19421(Current);
	}
	RTLE;
}

/* {XM_XPATH_REPLACE}.perform_replacement_string_substitution */
void F1962_19421 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	RTCT0("precondition_replacement_string_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(loc5)-1112])(loc5, loc1);
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 36L))) {
			tb1 = '\0';
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN) !loc4)) {
				ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(loc5)-1112])(loc5, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
				tb1 = (EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 92L));
			}
			if (tb1) {
				loc1 += ((EIF_INTEGER_32) 2L);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H("\\",1,92);
				tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(loc5)-1111])(loc5, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
				loc3 = F1148_8367(RTCW(tr1), tr2, tr3);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H("\\",1,92);
				tr1 = F1148_8377(RTCW(tr1), loc3, tr2);
				loc3 = (EIF_REFERENCE) tr1;
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr1 = F1148_8379(RTCW(tr1), loc5, loc3, loc1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
				loc1 += ((EIF_INTEGER_32) 3L);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		} else {
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc1++;
		}
	}
	RTLE;
}

/* {XM_XPATH_REPLACE}.evaluate_replacement */
void F1962_19422 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc6);
	RTLR(8,arg1);
	RTLIU(9);
	
	RTGC;
	RTCT0("precondition_replacement_string_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = RTOSCF(8225,F1134_8225, (Current));
	tr2 = RTMS_EX_H("",0,0);
	loc2 = F32_265(RTCW(tr1), arg2, tr2);
	tr1 = RTOSCF(8225,F1134_8225, (Current));
	tr2 = RTMS_EX_H("",0,0);
	loc1 = F32_265(RTCW(tr1), loc5, tr2);
	if ((EIF_BOOLEAN)(loc2 == loc1)) {
		loc3 = (EIF_REFERENCE) arg2;
		loc4 = (EIF_REFERENCE) loc5;
	} else {
		if (loc2) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
			loc3 = F1148_8360(RTCW(tr1), loc5, ti4_1);
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr1 = F1148_8377(RTCW(tr1), loc3, arg2);
			loc3 = (EIF_REFERENCE) tr1;
			loc4 = (EIF_REFERENCE) loc5;
		} else {
			loc3 = (EIF_REFERENCE) arg2;
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
			loc4 = F1148_8360(RTCW(tr1), arg2, ti4_1);
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr1 = F1148_8377(RTCW(tr1), loc4, loc5);
			loc4 = (EIF_REFERENCE) tr1;
		}
	}
	tr1 = RTOSCF(4521,F954_4521, (Current));
	tr1 = F1138_8299(RTCW(tr1), loc3);
	loc3 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(4521,F954_4521, (Current));
	tr1 = F1138_8299(RTCW(tr1), loc4);
	loc4 = (EIF_REFERENCE) tr1;
	RTCT0("attached regexp as l_regexp", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1607_13399(loc6, loc3);
	tr1 = RTLNS(eif_new_type(1883, 0x01).id, 1883, _OBJSIZ_10_38_0_1_0_0_0_0_);
	tr2 = F1608_13412(loc6, loc4);
	tr2 = F1162_8521(Current, tr2);
	F1884_18322(RTCW(tr1), tr2);
	F210_1915(RTCW(arg1), tr1);
	RTLE;
}

/* {XM_XPATH_REPLACE}.fetch_regular_expression */
void F1962_19423 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLR(5,tr1);
	RTLR(6,loc3);
	RTLR(7,arg1);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,tr4);
	RTLIU(11);
	
	RTGC;
	loc1 = F1223_9741(Current, arg2, arg3);
	tr1 = RTOSCF(2083,F238_2083, (Current));
	loc2 = F1224_9744(RTCW(tr1), loc1);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		loc2 = RTLNSMART(eif_new_type(1224, 0).id);
		F1225_9747(RTCW(loc2), arg2, arg3);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_2_0_);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = RTOSCF(2083,F238_2083, (Current));
			F1224_9745(RTCW(tr1), loc2, loc1);
		}
	}
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_2_0_);
	if ((EIF_BOOLEAN) !tb1) {
		RTCT0("invariant_of_xm_xpath_regexp_cache_entry", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		loc3 = tr1;
		if ((EIF_TRUE)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) loc3;
		tr1 = RTMS_EX_H("",0,0);
		tb1 = F1607_13386(loc3, tr1);
		if (tb1) {
			tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("Regular expression matches zero-length string",45,1995422311);
			tr3 = RTOSCF(9827,F1230_9827, (Current));
			tr4 = RTMS_EX_H("FORX0003",8,2093852211);
			F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
			F210_1915(RTCW(arg1), tr1);
		}
	} else {
		tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("Invalid regular expression",26,1449583982);
		tr3 = RTOSCF(9827,F1230_9827, (Current));
		tr4 = RTMS_EX_H("FORX0002",8,2093852210);
		F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
		F210_1915(RTCW(arg1), tr1);
	}
	RTLE;
}

/* {XM_XPATH_REPLACE}.fetch_replacement_string */
void F1962_19424 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
	RTCT0("replacement_string_present", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc1)-1819])(loc1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(loc1)-1819])(loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
		F210_1915(RTCW(arg1), NULL);
		F1962_19420(Current, arg1);
	}
	RTLE;
}

void EIF_Minit1034 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
