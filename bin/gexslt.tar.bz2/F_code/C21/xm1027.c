/*
 * Code for class XM_XPATH_SECONDS_FROM_DATETIME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1027.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_SECONDS_FROM_DATETIME}.make */
void F1955_19368 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("seconds-from-dateTime",21,1141213285);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1877L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_SECONDS_FROM_DATETIME}.item_type */
EIF_REFERENCE F1955_19369 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10262,F1235_10262, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	if ((EIF_BOOLEAN)(Result != NULL)) {
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_SECONDS_FROM_DATETIME}.required_type */
EIF_REFERENCE F1955_19370 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
	F1801_16797(RTCW(tr1));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_XPATH_SECONDS_FROM_DATETIME}.evaluate_item */
void F1955_19371 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc5);
	RTLR(5,loc1);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,loc6);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc5)-1819])(loc5);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13417[Dtype(loc5)-1819])(loc5);
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14002[Dtype(RTCW(tr1))-1868])(tr1);
		loc3 = RTLNS(eif_new_type(1898, 0x01).id, 1898, _OBJSIZ_8_37_0_1_0_0_0_0_);
		tr1 = F1288_11162(RTCW(loc1));
		ti4_1 = F1616_13527(RTCW(tr1));
		F1899_18587(RTCW(loc3), ti4_1);
		tr1 = F1288_11162(RTCW(loc1));
		loc2 = F1616_13528(RTCW(tr1));
		if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L))) {
			loc4 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
			F1748_15536(RTCW(loc4), loc2);
			RTCT0("attached l_decimal_value.value as l_decimal_value_value", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_7_);
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTOSCF(19373,F1955_19373, (Current));
			tr1 = F1748_15575(RTCW(loc4), tr1);
			loc4 = (EIF_REFERENCE) tr1;
			loc3 = RTLNS(eif_new_type(1898, 0x01).id, 1898, _OBJSIZ_8_37_0_1_0_0_0_0_);
			tr1 = F1748_15572(loc6, loc4);
			F1899_18586(RTCW(loc3), tr1);
		}
		F210_1915(RTCW(arg1), loc3);
	}
	RTLE;
}

/* {XM_XPATH_SECONDS_FROM_DATETIME}.compute_cardinality */
void F1955_19372 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8085(Current);
}

/* {XM_XPATH_SECONDS_FROM_DATETIME}.one_thousand */
static EIF_REFERENCE F1955_19373_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (19373);
#define Result RTOSR(19373)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1748_15536(RTCW(tr1), ((EIF_INTEGER_32) 1000L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (19373);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1955_19373 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(19373,F1955_19373_body,(Current));
}

void EIF_Minit1027 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
