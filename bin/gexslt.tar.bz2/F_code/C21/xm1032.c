/*
 * Code for class XM_XPATH_RESOLVE_QNAME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1032.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_RESOLVE_QNAME}.make */
void F1960_19398 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("resolve-qname",13,1148297573);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9826,F1230_9826, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1871L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_38_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12159(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(3563,F459_3563, (Current));
	F1439_11749(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_RESOLVE_QNAME}.item_type */
EIF_REFERENCE F1960_19399 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10260,F1235_10260, (RTCV(RTOSCF(3581,F463_3581, (Current)))));
	RTLE;
	return Result;
}

/* {XM_XPATH_RESOLVE_QNAME}.required_type */
EIF_REFERENCE F1960_19400 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		F1801_16783(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		Result = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_1_37_0_0_0_0_0_0_);
		tr1 = RTOSCF(17520,F1850_17520, (Current));
		F1801_16770(RTCW(Result), tr1, ((EIF_INTEGER_32) 3L));
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_RESOLVE_QNAME}.evaluate_item */
void F1960_19401 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc8);
	RTLR(5,loc1);
	RTLR(6,loc5);
	RTLR(7,loc4);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,tr4);
	RTLR(11,loc2);
	RTLR(12,loc3);
	RTLR(13,loc9);
	RTLR(14,loc7);
	RTLIU(15);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc8)-1819])(loc8);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(loc8)-1819])(loc8);
		loc5 = RTLNS(eif_new_type(1263, 0x01).id, 1263, _OBJSIZ_2_2_0_0_0_0_0_0_);
		F1264_10634(RTCW(loc5));
		tr1 = RTMS_EX_H(":",1,58);
		F1264_10640(RTCW(loc5), tr1);
		loc4 = F1264_10644(RTCW(loc5), loc1);
		loc6 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9566[Dtype(RTCW(loc4))-1481])(loc4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 1L)) || (EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 2L)))) {
			tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("First argument of resolve-qname() is not a lexical QName",56,1326725989);
			tr3 = RTOSCF(9827,F1230_9827, (Current));
			tr4 = RTMS_EX_H("FOCA0002",8,2064184370);
			F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
			F210_1915(RTCW(arg1), tr1);
		} else {
			if ((EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 1L))) {
				loc2 = RTMS_EX_H("",0,0);
				loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(loc4))-1481])(loc4, ((EIF_INTEGER_32) 1L));
			} else {
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(loc4))-1481])(loc4, ((EIF_INTEGER_32) 1L));
				loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(loc4))-1481])(loc4, ((EIF_INTEGER_32) 2L));
			}
			F210_1915(RTCW(arg1), NULL);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1506_12165(RTCW(tr1), ((EIF_INTEGER_32) 2L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13947[Dtype(RTCW(tr1))-1868])(tr1, arg1, arg2);
			RTCT0("attached a_result.item as a_result_item_2", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13397[Dtype(loc9)-1819])(loc9);
			if ((EIF_BOOLEAN) !tb1) {
				loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13418[Dtype(loc9)-1819])(loc9);
				tr1 = RTOSCF(4950,F991_4950, (Current));
				tb1 = F1242_10426(RTCW(tr1), loc2);
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
					tr2 = RTMS_EX_H("Prefix is not declared during resolve-qname()",45,1150416937);
					tr3 = RTOSCF(9827,F1230_9827, (Current));
					tr4 = RTMS_EX_H("FONS0004",8,2085949492);
					F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
					F210_1915(RTCW(arg1), tr1);
				} else {
					if (F179_1654(Current, loc3)) {
						F210_1915(RTCW(arg1), NULL);
						F1960_19403(Current, arg1, loc7, loc2, loc3);
					} else {
						tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("Invalid local name in resolve-qname()",37,521157417);
						tr3 = RTOSCF(9827,F1230_9827, (Current));
						tr4 = RTMS_EX_H("FOCA0002",8,2064184370);
						F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
						F210_1915(RTCW(arg1), tr1);
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_XPATH_RESOLVE_QNAME}.compute_cardinality */
void F1960_19402 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1124_8085(Current);
}

/* {XM_XPATH_RESOLVE_QNAME}.resolve_qname */
void F1960_19403 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLR(3,loc6);
	RTLR(4,arg2);
	RTLR(5,arg4);
	RTLR(6,tr2);
	RTLR(7,arg1);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLIU(10);
	
	RTGC;
	tr1 = RTOSCF(4950,F991_4950, (Current));
	loc4 = F1242_10409(RTCW(tr1), arg3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13689[Dtype(RTCW(arg2))-2140])(arg2);
	loc6 = F1507_12168(RTCW(tr1));
	F1321_11363(RTCW(loc6));
	for (;;) {
		tb1 = '\01';
		if (!loc1) {
			tb2 = F1385_11438(RTCW(loc6));
			tb1 = tb2;
		}
		if (tb1) break;
		loc3 = F1308_11343(RTCW(loc6));
		if ((EIF_BOOLEAN)(loc4 == F1227_9773(Current, loc3))) {
			loc5 = F1227_9774(Current, loc3);
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			F1321_11364(RTCW(loc6));
		}
	}
	if (loc1) {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tb2 = F1242_10431(RTCW(tr1), arg3, loc5, arg4);
		if (tb2) {
			tr1 = RTOSCF(4950,F991_4950, (Current));
			tr2 = RTOSCF(4950,F991_4950, (Current));
			tr2 = F1242_10454(RTCW(tr2), loc5);
			loc2 = F1242_10413(RTCW(tr1), arg3, tr2, arg4);
		} else {
			tr1 = RTOSCF(4950,F991_4950, (Current));
			F1242_10445(RTCW(tr1), arg3, loc5, arg4);
			loc2 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(4950,F991_4950, (Current)))+ _LNGOFF_4_0_0_0_);
		}
		tr1 = RTLNS(eif_new_type(1878, 0x01).id, 1878, _OBJSIZ_7_37_0_2_0_0_0_0_);
		F1879_18248(RTCW(tr1), loc2);
		F210_1915(RTCW(arg1), tr1);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			tr1 = RTOSCF(4950,F991_4950, (Current));
			tr2 = RTOSCF(9820,F1230_9820, (Current));
			tb2 = F1242_10430(RTCW(tr1), arg3, tr2, arg4);
			if (tb2) {
				tr1 = RTOSCF(4950,F991_4950, (Current));
				tr2 = RTOSCF(9820,F1230_9820, (Current));
				loc2 = F1242_10413(RTCW(tr1), arg3, tr2, arg4);
			} else {
				tr1 = RTOSCF(4950,F991_4950, (Current));
				tr2 = RTOSCF(9820,F1230_9820, (Current));
				F1242_10444(RTCW(tr1), arg3, tr2, arg4);
				loc2 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(4950,F991_4950, (Current)))+ _LNGOFF_4_0_0_0_);
			}
			tr1 = RTLNS(eif_new_type(1878, 0x01).id, 1878, _OBJSIZ_7_37_0_2_0_0_0_0_);
			F1879_18248(RTCW(tr1), loc2);
			F210_1915(RTCW(arg1), tr1);
		} else {
			tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("Prefix is not declared during resolve-qname()",45,1150416937);
			tr3 = RTOSCF(9827,F1230_9827, (Current));
			tr4 = RTMS_EX_H("FONS0004",8,2085949492);
			F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
			F210_1915(RTCW(arg1), tr1);
		}
	}
	RTLE;
}

void EIF_Minit1032 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
