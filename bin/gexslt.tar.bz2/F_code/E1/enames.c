

#ifdef __cplusplus
extern "C" {
#endif

char *names2 [] =
{
"other_sets",
"is_empty",
"is_negated",
"is_reverted",
"first_set",
"second_set",
"third_set",
"fourth_set",
};

char *names3 [] =
{
"table",
};

char *names4 [] =
{
"tokens",
};

char *names7 [] =
{
"internal_item",
"is_utc",
"microseconds_now",
};

char *names8 [] =
{
"item_result",
"sequence_result",
"is_sequence",
};

char *names9 [] =
{
"value",
"message",
"code",
"is_error",
};

char *names10 [] =
{
"cache",
"converted_pair",
};

char *names11 [] =
{
"start_string",
"target_uri",
"count",
};

char *names12 [] =
{
"suffix_string",
"target_uri",
"count",
};

char *names13 [] =
{
"local_name",
"next",
"uri_code",
};

char *names15 [] =
{
"result_type",
"first_operand_type",
"second_operand_type",
"operation",
};

char *names16 [] =
{
"range_variable",
"sequence",
"line_number",
};

char *names17 [] =
{
"version",
"encoding",
"stand_alone",
};

char *names18 [] =
{
"sequence_numbers",
"line_numbers",
};

char *names19 [] =
{
"version",
};

char *names21 [] =
{
"value",
};

char *names22 [] =
{
"slot_manager",
"variables",
};

char *names23 [] =
{
"decimal_format",
"list",
"is_list",
"is_decimal_format",
};

char *names24 [] =
{
"template_value",
"is_boolean",
"is_template",
"boolean_value",
};

char *names25 [] =
{
"pattern",
"handler",
"priority",
"next_rule",
"precedence",
"priority_rank",
"sequence_number",
};

char *names26 [] =
{
"key_definitions",
"is_backwards_compatible",
"fingerprint",
};

char *names27 [] =
{
"map",
"is_under_construction",
};

char *names28 [] =
{
"number_of_variables",
};

char *names31 [] =
{
"code_page",
"encoding_i",
};

char *names37 [] =
{
"outputter",
};

char *names38 [] =
{
"uri",
"mime_type",
"character_set",
"title",
"applicable_media",
"is_alternate",
};

char *names39 [] =
{
"map",
};

char *names40 [] =
{
"format_map",
"default_format",
"using_original_default",
};

char *names53 [] =
{
"flatten_when_closing",
"keep_calls_records",
"recording_values",
"maximum_record_count",
};

char *names70 [] =
{
"default_output",
};

char *names72 [] =
{
"emitter",
"stream",
"receiver",
"principal_receiver",
"system_id",
"response_stream",
"error_message",
"output_stream",
"is_emitter",
"is_stream",
"is_receiver",
};

char *names80 [] =
{
"origin",
};

char *names83 [] =
{
"utc_clock",
"local_clock",
"millisecond",
"second",
"minute",
"hour",
"day",
"month",
"year",
};

char *names84 [] =
{
"last_decimal",
};

char *names88 [] =
{
"root_object",
"on_processing_object_action",
"on_processing_reference_action",
"object_action",
"visited_objects",
"visited_types",
"has_failed",
"has_reference_with_copy_semantics",
"is_skip_transient",
"is_skip_copy_semantics_reference",
"is_exception_on_copy_suppressed",
"is_exception_propagated",
};

char *names89 [] =
{
"root_object",
"on_processing_object_action",
"on_processing_reference_action",
"object_action",
"visited_objects",
"visited_types",
"has_failed",
"has_reference_with_copy_semantics",
"is_skip_transient",
"is_skip_copy_semantics_reference",
"is_exception_on_copy_suppressed",
"is_exception_propagated",
};

char *names91 [] =
{
"target_uri",
};

char *names92 [] =
{
"target_uri",
"prefer_public",
};

char *names93 [] =
{
"start_string",
"target_uri",
"count",
};

char *names94 [] =
{
"start_string",
"target_uri",
"prefer_public",
"count",
};

char *names101 [] =
{
"comparator",
};

char *names102 [] =
{
"comparator",
};

char *names103 [] =
{
"comparator",
};

char *names104 [] =
{
"comparator",
};

char *names105 [] =
{
"comparator",
};

char *names106 [] =
{
"item",
};

char *names107 [] =
{
"item",
};

char *names108 [] =
{
"item",
"right",
};

char *names109 [] =
{
"right",
"item",
};

char *names119 [] =
{
"uri",
};

char *names132 [] =
{
"basic_xslt_processor",
"basic_xquery_processor",
"xquery_processor",
"schema_aware_processor",
"customized_host_language",
"is_full_type_scheme",
};

char *names135 [] =
{
"security_manager",
"output_destinations",
"http_method",
"error_message",
};

char *names139 [] =
{
"item",
};

char *names140 [] =
{
"item",
};

char *names141 [] =
{
"item",
};

char *names142 [] =
{
"item",
};

char *names143 [] =
{
"item",
"right",
};

char *names144 [] =
{
"right",
"item",
};

char *names147 [] =
{
"element",
"character_data",
"processing_instruction",
"document",
"comment",
"xml_attribute",
"composite",
};

char *names148 [] =
{
"events",
"in_attributes",
};

char *names156 [] =
{
"managed_pointer",
"shared",
"internal_item",
};

char *names165 [] =
{
"last_mapped_sequence",
};

char *names166 [] =
{
"last_mapped_sequence",
"base_iterator",
"context",
"matching_block",
"non_matching_block",
};

char *names182 [] =
{
"encoding",
"outputter",
"is_error",
};

char *names187 [] =
{
"is_highly_secure",
};

char *names196 [] =
{
"deltas",
"deltas_array",
};

char *names197 [] =
{
"deltas",
"deltas_array",
};

char *names198 [] =
{
"deltas",
"deltas_array",
};

char *names200 [] =
{
"integer_overflow_state1",
"integer_overflow_state2",
"natural_overflow_state1",
"natural_overflow_state2",
};

char *names201 [] =
{
"leading_separators",
"trailing_separators",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"conversion_type",
"last_state",
"sign",
};

char *names202 [] =
{
"leading_separators",
"trailing_separators",
"internal_lookahead",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"internal_overflowed",
"conversion_type",
"last_state",
"sign",
"part1",
"part2",
};

char *names203 [] =
{
"leading_separators",
"trailing_separators",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"internal_overflowed",
"conversion_type",
"last_state",
"sign",
"part1",
"part2",
};

char *names204 [] =
{
"leading_separators",
"trailing_separators",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"is_negative",
"has_negative_exponent",
"has_fractional_part",
"needs_digit",
"conversion_type",
"last_state",
"sign",
"exponent",
"natural_part",
"fractional_part",
"fractional_divider",
};

char *names210 [] =
{
"item",
};

char *names211 [] =
{
"item",
};

char *names212 [] =
{
"item",
};

char *names213 [] =
{
"item",
};

char *names214 [] =
{
"item",
};

char *names215 [] =
{
"item",
"right",
};

char *names216 [] =
{
"right",
"item",
};

char *names217 [] =
{
"right",
"item",
};

char *names218 [] =
{
"item",
"right",
"left",
};

char *names219 [] =
{
"first",
"second",
};

char *names220 [] =
{
"first",
"second",
};

char *names221 [] =
{
"first",
"second",
};

char *names222 [] =
{
"first",
"second",
};

char *names232 [] =
{
"content",
"beginning_of_line",
"filled",
"interactive",
"count",
"capacity",
"position",
"line",
"column",
"index",
};

char *names233 [] =
{
"content",
"beginning_of_line",
"filled",
"interactive",
"count",
"capacity",
"position",
"line",
"column",
"index",
};

char *names234 [] =
{
"content",
"beginning_of_line",
"filled",
"interactive",
"count",
"capacity",
"position",
"line",
"column",
"index",
};

char *names241 [] =
{
"time_zone",
};

char *names247 [] =
{
"error_message",
"http_method",
"last_result",
};

char *names256 [] =
{
"callbacks",
};

char *names258 [] =
{
"next",
};

char *names259 [] =
{
"next",
"document",
"last_position_table",
"current_element",
"namespace_cache",
"source_parser",
};

char *names260 [] =
{
"next",
"last_error",
"has_error",
};

char *names261 [] =
{
"next",
"last_error",
"parser",
"has_error",
};

char *names263 [] =
{
"evaluated",
};

char *names265 [] =
{
"active",
"after",
"before",
};

char *names266 [] =
{
"active",
"after",
"before",
};

char *names267 [] =
{
"position",
};

char *names268 [] =
{
"index",
};

char *names271 [] =
{
"content",
"file",
"beginning_of_line",
"filled",
"interactive",
"end_of_file",
"count",
"capacity",
"position",
"line",
"column",
"index",
};

char *names272 [] =
{
"content",
"file",
"beginning_of_line",
"filled",
"interactive",
"end_of_file",
"count",
"capacity",
"position",
"line",
"column",
"index",
"default_encoding",
"encoding",
};

char *names273 [] =
{
"content",
"file",
"beginning_of_line",
"filled",
"interactive",
"end_of_file",
"has_utf8_bom",
"count",
"capacity",
"position",
"line",
"column",
"index",
"default_encoding",
"encoding",
};

char *names277 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names278 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names279 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names280 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names281 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names282 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names283 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names284 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"exception_information",
"internal_is_ignorable",
"line_number",
"hresult",
"hresult_code",
};

char *names285 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"error_code",
};

char *names286 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"signal_code",
};

char *names287 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names288 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names289 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names290 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names291 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names292 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names293 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"internal_code",
};

char *names294 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names295 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names296 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"internal_code",
};

char *names297 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names298 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names299 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names300 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names301 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"error_code",
"internal_code",
};

char *names302 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names303 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names304 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names305 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names306 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"routine_name",
"class_name",
"internal_is_ignorable",
"line_number",
};

char *names307 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names308 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names309 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names310 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names311 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names312 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names313 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"is_entry",
"line_number",
};

char *names314 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names315 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names316 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names323 [] =
{
"dtd_callbacks",
};

char *names325 [] =
{
"next",
};

char *names327 [] =
{
"executable",
"body",
"system_id",
"slot_manager",
"initialized",
"line_number",
};

char *names328 [] =
{
"executable",
"body",
"system_id",
"slot_manager",
"used_attribute_sets",
"initialized",
"line_number",
"name_code",
};

char *names329 [] =
{
"variable_name",
"last_evaluated_binding",
};

char *names330 [] =
{
"variable_name",
"last_evaluated_binding",
"value",
};

char *names333 [] =
{
"target",
"actual_parameters",
"tunnel_parameters",
"execution_context",
};

char *names337 [] =
{
"is_shared",
"count",
"item",
"counter",
};

char *names342 [] =
{
"dynamic_type",
};

char *names346 [] =
{
"referring_object",
"dynamic_type",
"physical_offset",
"referring_physical_offset",
};

char *names347 [] =
{
"enclosing_object",
"dynamic_type",
"physical_offset",
};

char *names348 [] =
{
"area",
};

char *names349 [] =
{
"area",
};

char *names350 [] =
{
"area",
};

char *names351 [] =
{
"area",
};

char *names352 [] =
{
"area",
};

char *names353 [] =
{
"area",
};

char *names354 [] =
{
"area",
};

char *names355 [] =
{
"area",
};

char *names356 [] =
{
"area",
};

char *names357 [] =
{
"area",
};

char *names358 [] =
{
"area",
};

char *names359 [] =
{
"area",
};

char *names360 [] =
{
"area",
};

char *names362 [] =
{
"last_generated_serial_number",
};

char *names364 [] =
{
"managed_data",
"unit_count",
};

char *names365 [] =
{
"return_code",
};

char *names366 [] =
{
"buffered_file_info",
"internal_file_name",
"internal_name_pointer",
"exists",
"is_following_symlinks",
};

char *names367 [] =
{
"buffered_file_info",
"internal_file_name",
"internal_name_pointer",
"exists",
"is_following_symlinks",
};

char *names368 [] =
{
"lastentry",
"internal_name",
"internal_detachable_name_pointer",
"mode",
"directory_pointer",
"last_entry_pointer",
};

char *names369 [] =
{
"slot_manager",
};

char *names372 [] =
{
"error_change_stack",
"warnings_are_recoverable_errors",
"recovered",
"recovery_policy",
"warning_threshold",
"recoverable_error_threshold",
};

char *names374 [] =
{
"last_mapped_item",
};

char *names375 [] =
{
"last_mapped_item",
};

char *names376 [] =
{
"last_mapped_item",
"context",
"action",
"slot_number",
};

char *names380 [] =
{
"area",
"unicode_area",
"as_unicode_special",
"invalid_character",
"invalid_unicode_character",
};

char *names381 [] =
{
"area",
"as_special",
};

char *names382 [] =
{
"managed_data",
"count",
};

char *names383 [] =
{
"last_string",
"last_character",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"last_real",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names385 [] =
{
"recorder",
"object",
"breakable_info",
"parent",
"steps",
"call_records",
"value_records",
"last_position",
"rt_information_available",
"is_expanded",
"is_flat",
"is_closed",
"class_type_id",
"feature_rout_id",
"depth",
};

char *names387 [] =
{
"breakable_info",
"position",
"type",
};

char *names388 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names389 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names390 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names391 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names392 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names393 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names394 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names395 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names396 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names397 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names398 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names399 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names400 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names401 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names402 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names403 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names404 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names405 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names406 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names407 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names408 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names409 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names410 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"value",
"callstack_depth",
};

char *names411 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names412 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names413 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names414 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names415 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names416 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names417 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names418 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names419 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names420 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names421 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names422 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names423 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names424 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names425 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names426 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names427 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names428 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names429 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names430 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names431 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names432 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names448 [] =
{
"area",
"area_index",
"remaining_count",
};

char *names449 [] =
{
"byte",
"file_pointer",
};

char *names455 [] =
{
"starting_node",
"node_test",
"next_node",
};

char *names461 [] =
{
"start_time",
"build_start_time",
"build_finish_time",
"finish_compiling_time",
"finish_time",
};

char *names477 [] =
{
"parser",
"resolver",
};

char *names484 [] =
{
"collator",
"comparer",
};

char *names485 [] =
{
"base_comparer",
};

char *names486 [] =
{
"comparator",
};

char *names487 [] =
{
"comparator",
};

char *names508 [] =
{
"target",
"target_index",
"start_index",
"end_index",
};

char *names510 [] =
{
"program_name",
};

char *names542 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names543 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names544 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names545 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names546 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names547 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names548 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names549 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names550 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names551 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names552 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names553 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names554 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names555 [] =
{
"target",
"active",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names556 [] =
{
"target",
"active",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names557 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names558 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names559 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names560 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names561 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names562 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names563 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names564 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names565 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names566 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names567 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names568 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names569 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names570 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names571 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names572 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names573 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names574 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names575 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names576 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names577 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names578 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names579 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names580 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names581 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names582 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names583 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names584 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names585 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names586 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names587 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names588 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"area_first_index",
};

char *names589 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"area_first_index",
};

char *names590 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names591 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names592 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names593 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names594 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names595 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names596 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names597 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names598 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names599 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names600 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names601 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names602 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names603 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names604 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names605 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names606 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names607 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names608 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names609 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names610 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names611 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names612 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names613 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names614 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names615 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names616 [] =
{
"object_comparison",
};

char *names617 [] =
{
"object_comparison",
};

char *names618 [] =
{
"object_comparison",
};

char *names619 [] =
{
"object_comparison",
};

char *names620 [] =
{
"object_comparison",
};

char *names621 [] =
{
"object_comparison",
};

char *names622 [] =
{
"object_comparison",
};

char *names623 [] =
{
"object_comparison",
};

char *names624 [] =
{
"object_comparison",
};

char *names625 [] =
{
"object_comparison",
};

char *names626 [] =
{
"object_comparison",
};

char *names627 [] =
{
"object_comparison",
};

char *names628 [] =
{
"object_comparison",
};

char *names629 [] =
{
"object_comparison",
};

char *names630 [] =
{
"object_comparison",
};

char *names631 [] =
{
"object_comparison",
};

char *names632 [] =
{
"object_comparison",
};

char *names633 [] =
{
"object_comparison",
};

char *names634 [] =
{
"object_comparison",
};

char *names635 [] =
{
"object_comparison",
};

char *names636 [] =
{
"object_comparison",
};

char *names637 [] =
{
"object_comparison",
};

char *names638 [] =
{
"object_comparison",
};

char *names639 [] =
{
"object_comparison",
};

char *names640 [] =
{
"object_comparison",
};

char *names641 [] =
{
"object_comparison",
};

char *names642 [] =
{
"object_comparison",
};

char *names643 [] =
{
"object_comparison",
};

char *names644 [] =
{
"object_comparison",
};

char *names645 [] =
{
"object_comparison",
};

char *names646 [] =
{
"object_comparison",
};

char *names647 [] =
{
"object_comparison",
};

char *names648 [] =
{
"object_comparison",
};

char *names649 [] =
{
"object_comparison",
};

char *names650 [] =
{
"object_comparison",
};

char *names651 [] =
{
"object_comparison",
};

char *names652 [] =
{
"object_comparison",
};

char *names653 [] =
{
"object_comparison",
};

char *names654 [] =
{
"object_comparison",
};

char *names655 [] =
{
"object_comparison",
};

char *names656 [] =
{
"object_comparison",
};

char *names657 [] =
{
"object_comparison",
};

char *names658 [] =
{
"object_comparison",
};

char *names659 [] =
{
"object_comparison",
};

char *names660 [] =
{
"object_comparison",
};

char *names661 [] =
{
"object_comparison",
};

char *names662 [] =
{
"object_comparison",
};

char *names663 [] =
{
"object_comparison",
};

char *names664 [] =
{
"object_comparison",
};

char *names665 [] =
{
"object_comparison",
};

char *names666 [] =
{
"object_comparison",
};

char *names667 [] =
{
"object_comparison",
};

char *names668 [] =
{
"object_comparison",
};

char *names669 [] =
{
"object_comparison",
};

char *names670 [] =
{
"object_comparison",
};

char *names671 [] =
{
"object_comparison",
};

char *names672 [] =
{
"object_comparison",
};

char *names673 [] =
{
"object_comparison",
};

char *names674 [] =
{
"object_comparison",
};

char *names675 [] =
{
"object_comparison",
};

char *names676 [] =
{
"object_comparison",
};

char *names677 [] =
{
"object_comparison",
};

char *names678 [] =
{
"object_comparison",
};

char *names679 [] =
{
"object_comparison",
};

char *names680 [] =
{
"object_comparison",
};

char *names681 [] =
{
"object_comparison",
};

char *names682 [] =
{
"object_comparison",
};

char *names683 [] =
{
"object_comparison",
};

char *names684 [] =
{
"object_comparison",
};

char *names685 [] =
{
"object_comparison",
};

char *names686 [] =
{
"object_comparison",
};

char *names687 [] =
{
"object_comparison",
};

char *names688 [] =
{
"object_comparison",
};

char *names689 [] =
{
"object_comparison",
};

char *names690 [] =
{
"object_comparison",
};

char *names691 [] =
{
"object_comparison",
};

char *names692 [] =
{
"object_comparison",
};

char *names693 [] =
{
"object_comparison",
};

char *names694 [] =
{
"object_comparison",
};

char *names695 [] =
{
"object_comparison",
};

char *names696 [] =
{
"object_comparison",
};

char *names697 [] =
{
"object_comparison",
};

char *names698 [] =
{
"object_comparison",
};

char *names699 [] =
{
"object_comparison",
};

char *names700 [] =
{
"object_comparison",
};

char *names701 [] =
{
"object_comparison",
};

char *names702 [] =
{
"object_comparison",
};

char *names703 [] =
{
"object_comparison",
};

char *names704 [] =
{
"object_comparison",
};

char *names705 [] =
{
"object_comparison",
};

char *names706 [] =
{
"object_comparison",
};

char *names707 [] =
{
"object_comparison",
};

char *names708 [] =
{
"object_comparison",
};

char *names709 [] =
{
"object_comparison",
};

char *names710 [] =
{
"object_comparison",
};

char *names711 [] =
{
"object_comparison",
};

char *names712 [] =
{
"object_comparison",
};

char *names713 [] =
{
"object_comparison",
};

char *names714 [] =
{
"object_comparison",
};

char *names715 [] =
{
"object_comparison",
};

char *names716 [] =
{
"object_comparison",
};

char *names717 [] =
{
"object_comparison",
};

char *names718 [] =
{
"object_comparison",
};

char *names719 [] =
{
"object_comparison",
};

char *names720 [] =
{
"object_comparison",
};

char *names721 [] =
{
"object_comparison",
};

char *names722 [] =
{
"object_comparison",
};

char *names723 [] =
{
"object_comparison",
};

char *names724 [] =
{
"object_comparison",
};

char *names725 [] =
{
"object_comparison",
};

char *names726 [] =
{
"object_comparison",
};

char *names727 [] =
{
"object_comparison",
};

char *names728 [] =
{
"object_comparison",
};

char *names729 [] =
{
"object_comparison",
};

char *names730 [] =
{
"object_comparison",
};

char *names731 [] =
{
"object_comparison",
};

char *names732 [] =
{
"object_comparison",
};

char *names733 [] =
{
"object_comparison",
};

char *names734 [] =
{
"object_comparison",
};

char *names735 [] =
{
"object_comparison",
};

char *names736 [] =
{
"object_comparison",
};

char *names737 [] =
{
"object_comparison",
};

char *names738 [] =
{
"object_comparison",
};

char *names739 [] =
{
"object_comparison",
};

char *names740 [] =
{
"object_comparison",
};

char *names741 [] =
{
"object_comparison",
};

char *names742 [] =
{
"object_comparison",
};

char *names743 [] =
{
"object_comparison",
};

char *names744 [] =
{
"object_comparison",
};

char *names745 [] =
{
"object_comparison",
};

char *names746 [] =
{
"object_comparison",
};

char *names747 [] =
{
"object_comparison",
};

char *names748 [] =
{
"object_comparison",
};

char *names749 [] =
{
"object_comparison",
};

char *names750 [] =
{
"object_comparison",
};

char *names751 [] =
{
"object_comparison",
};

char *names752 [] =
{
"object_comparison",
};

char *names753 [] =
{
"object_comparison",
};

char *names754 [] =
{
"object_comparison",
};

char *names755 [] =
{
"object_comparison",
};

char *names756 [] =
{
"object_comparison",
};

char *names757 [] =
{
"object_comparison",
};

char *names758 [] =
{
"object_comparison",
};

char *names759 [] =
{
"object_comparison",
};

char *names760 [] =
{
"object_comparison",
};

char *names761 [] =
{
"object_comparison",
};

char *names762 [] =
{
"object_comparison",
};

char *names763 [] =
{
"object_comparison",
};

char *names764 [] =
{
"object_comparison",
};

char *names765 [] =
{
"object_comparison",
};

char *names766 [] =
{
"object_comparison",
};

char *names767 [] =
{
"object_comparison",
};

char *names768 [] =
{
"object_comparison",
"index",
};

char *names769 [] =
{
"object_comparison",
"index",
};

char *names770 [] =
{
"object_comparison",
};

char *names771 [] =
{
"object_comparison",
};

char *names772 [] =
{
"object_comparison",
};

char *names773 [] =
{
"object_comparison",
};

char *names774 [] =
{
"object_comparison",
};

char *names775 [] =
{
"object_comparison",
};

char *names776 [] =
{
"object_comparison",
};

char *names777 [] =
{
"object_comparison",
};

char *names778 [] =
{
"object_comparison",
};

char *names779 [] =
{
"object_comparison",
};

char *names780 [] =
{
"object_comparison",
};

char *names781 [] =
{
"object_comparison",
};

char *names782 [] =
{
"object_comparison",
};

char *names783 [] =
{
"object_comparison",
};

char *names784 [] =
{
"object_comparison",
};

char *names785 [] =
{
"object_comparison",
};

char *names786 [] =
{
"object_comparison",
};

char *names787 [] =
{
"object_comparison",
};

char *names788 [] =
{
"object_comparison",
};

char *names789 [] =
{
"object_comparison",
};

char *names790 [] =
{
"object_comparison",
};

char *names791 [] =
{
"object_comparison",
};

char *names792 [] =
{
"object_comparison",
};

char *names793 [] =
{
"object_comparison",
};

char *names794 [] =
{
"object_comparison",
};

char *names795 [] =
{
"object_comparison",
};

char *names796 [] =
{
"object_comparison",
};

char *names797 [] =
{
"object_comparison",
};

char *names798 [] =
{
"object_comparison",
};

char *names799 [] =
{
"object_comparison",
};

char *names800 [] =
{
"object_comparison",
};

char *names801 [] =
{
"object_comparison",
};

char *names802 [] =
{
"object_comparison",
};

char *names803 [] =
{
"object_comparison",
};

char *names804 [] =
{
"object_comparison",
};

char *names805 [] =
{
"object_comparison",
};

char *names806 [] =
{
"object_comparison",
};

char *names807 [] =
{
"object_comparison",
};

char *names808 [] =
{
"object_comparison",
};

char *names809 [] =
{
"object_comparison",
};

char *names810 [] =
{
"object_comparison",
};

char *names811 [] =
{
"object_comparison",
};

char *names812 [] =
{
"object_comparison",
};

char *names813 [] =
{
"object_comparison",
};

char *names814 [] =
{
"object_comparison",
};

char *names815 [] =
{
"object_comparison",
};

char *names816 [] =
{
"object_comparison",
};

char *names817 [] =
{
"object_comparison",
};

char *names818 [] =
{
"object_comparison",
};

char *names819 [] =
{
"object_comparison",
};

char *names820 [] =
{
"object_comparison",
};

char *names821 [] =
{
"object_comparison",
};

char *names822 [] =
{
"object_comparison",
};

char *names823 [] =
{
"object_comparison",
};

char *names824 [] =
{
"object_comparison",
};

char *names825 [] =
{
"object_comparison",
};

char *names826 [] =
{
"object_comparison",
};

char *names827 [] =
{
"object_comparison",
};

char *names828 [] =
{
"object_comparison",
};

char *names829 [] =
{
"object_comparison",
};

char *names830 [] =
{
"object_comparison",
};

char *names831 [] =
{
"object_comparison",
};

char *names832 [] =
{
"object_comparison",
};

char *names833 [] =
{
"object_comparison",
};

char *names834 [] =
{
"object_comparison",
};

char *names835 [] =
{
"object_comparison",
};

char *names836 [] =
{
"object_comparison",
};

char *names837 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names838 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names839 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"last_string_32",
"internal_encoding",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"is_sequence_an_expected_numeric",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names866 [] =
{
"object_comparison",
};

char *names867 [] =
{
"object_comparison",
};

char *names868 [] =
{
"object_comparison",
};

char *names869 [] =
{
"object_comparison",
};

char *names870 [] =
{
"object_comparison",
};

char *names871 [] =
{
"object_comparison",
};

char *names872 [] =
{
"object_comparison",
};

char *names873 [] =
{
"object_comparison",
};

char *names874 [] =
{
"object_comparison",
};

char *names875 [] =
{
"object_comparison",
};

char *names876 [] =
{
"object_comparison",
};

char *names877 [] =
{
"object_comparison",
};

char *names878 [] =
{
"object_comparison",
};

char *names879 [] =
{
"object_comparison",
"upper",
"lower",
};

char *names880 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names881 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names882 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names883 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names884 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names885 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names886 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names887 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names888 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names889 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names890 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names891 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names892 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names893 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names894 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names895 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names896 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names897 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names898 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names899 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names900 [] =
{
"object_comparison",
};

char *names901 [] =
{
"object_comparison",
};

char *names902 [] =
{
"object_comparison",
};

char *names903 [] =
{
"object_comparison",
};

char *names904 [] =
{
"object_comparison",
};

char *names905 [] =
{
"object_comparison",
};

char *names906 [] =
{
"object_comparison",
};

char *names907 [] =
{
"object_comparison",
};

char *names908 [] =
{
"object_comparison",
};

char *names909 [] =
{
"object_comparison",
};

char *names910 [] =
{
"object_comparison",
};

char *names911 [] =
{
"object_comparison",
};

char *names912 [] =
{
"object_comparison",
};

char *names913 [] =
{
"object_comparison",
};

char *names914 [] =
{
"object_comparison",
};

char *names915 [] =
{
"object_comparison",
};

char *names916 [] =
{
"object_comparison",
};

char *names917 [] =
{
"object_comparison",
};

char *names918 [] =
{
"object_comparison",
};

char *names919 [] =
{
"object_comparison",
};

char *names920 [] =
{
"object_comparison",
};

char *names921 [] =
{
"object_comparison",
};

char *names922 [] =
{
"object_comparison",
};

char *names923 [] =
{
"object_comparison",
};

char *names924 [] =
{
"object_comparison",
};

char *names925 [] =
{
"object_comparison",
};

char *names926 [] =
{
"object_comparison",
};

char *names927 [] =
{
"object_comparison",
};

char *names928 [] =
{
"object_comparison",
};

char *names929 [] =
{
"object_comparison",
};

char *names930 [] =
{
"object_comparison",
};

char *names931 [] =
{
"object_comparison",
};

char *names932 [] =
{
"object_comparison",
};

char *names933 [] =
{
"object_comparison",
};

char *names934 [] =
{
"object_comparison",
};

char *names935 [] =
{
"object_comparison",
};

char *names936 [] =
{
"object_comparison",
};

char *names937 [] =
{
"object_comparison",
};

char *names938 [] =
{
"object_comparison",
};

char *names939 [] =
{
"object_comparison",
};

char *names940 [] =
{
"object_comparison",
};

char *names941 [] =
{
"object_comparison",
};

char *names942 [] =
{
"object_comparison",
};

char *names943 [] =
{
"object_comparison",
};

char *names944 [] =
{
"object_comparison",
};

char *names945 [] =
{
"object_comparison",
};

char *names946 [] =
{
"object_comparison",
};

char *names947 [] =
{
"object_comparison",
};

char *names948 [] =
{
"object_comparison",
};

char *names949 [] =
{
"object_comparison",
};

char *names950 [] =
{
"object_comparison",
};

char *names951 [] =
{
"object_comparison",
};

char *names952 [] =
{
"first_element",
"active",
"object_comparison",
"before",
"after",
"count",
};

char *names953 [] =
{
"first_element",
"active",
"object_comparison",
"before",
"after",
"count",
};

char *names956 [] =
{
"base_iterator",
"context",
"matching_block",
"non_matching_block",
"last_node_iterator",
};

char *names957 [] =
{
"context",
"action",
"last_node_iterator",
"slot_number",
};

char *names960 [] =
{
"optional_prefix",
"local_name",
"is_valid",
"too_many_colons",
};

char *names962 [] =
{
"area",
"object_comparison",
"out_index",
"count",
};

char *names963 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names964 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names965 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names966 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names967 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names968 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names969 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names970 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names971 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names972 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names973 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names974 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names975 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names976 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names977 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_key",
"count",
};

char *names978 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"found_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_item",
"count",
};

char *names979 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"object_comparison",
"hash_table_version_64",
"has_default",
"found_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_item",
"ht_deleted_key",
"count",
};

char *names980 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
"found_item",
"ht_deleted_item",
};

char *names981 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"is_case_insensitive",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names982 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"is_case_insensitive",
"found_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_item",
"count",
};

char *names983 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"ht_deleted_key",
"stored_version",
"current_version",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names992 [] =
{
"attribute_set_table",
};

char *names996 [] =
{
"first",
"second",
};

char *names997 [] =
{
"high_word",
"low_word",
};

char *names998 [] =
{
"storage",
"internal_name",
"is_normalized",
};

char *names999 [] =
{
"internal_name_32",
"internal_name",
};

char *names1000 [] =
{
"internal_name_32",
"internal_name",
};

char *names1001 [] =
{
"internal_name_32",
"internal_name",
};

char *names1002 [] =
{
"internal_name_32",
"internal_name",
};

char *names1003 [] =
{
"internal_name_32",
"internal_name",
};

char *names1004 [] =
{
"internal_name_32",
"internal_name",
};

char *names1005 [] =
{
"internal_name_32",
"internal_name",
};

char *names1006 [] =
{
"internal_name_32",
"internal_name",
};

char *names1007 [] =
{
"internal_name_32",
"internal_name",
};

char *names1008 [] =
{
"internal_name_32",
"internal_name",
};

char *names1009 [] =
{
"internal_name_32",
"internal_name",
};

char *names1010 [] =
{
"internal_name_32",
"internal_name",
};

char *names1011 [] =
{
"internal_name_32",
"internal_name",
};

char *names1012 [] =
{
"internal_name_32",
"internal_name",
};

char *names1013 [] =
{
"internal_name_32",
"internal_name",
};

char *names1014 [] =
{
"internal_name_32",
"internal_name",
};

char *names1015 [] =
{
"internal_name_32",
"internal_name",
};

char *names1016 [] =
{
"internal_name_32",
"internal_name",
};

char *names1017 [] =
{
"internal_name_32",
"internal_name",
};

char *names1018 [] =
{
"internal_name_32",
"internal_name",
};

char *names1019 [] =
{
"internal_name_32",
"internal_name",
};

char *names1020 [] =
{
"internal_name_32",
"internal_name",
};

char *names1021 [] =
{
"internal_name_32",
"internal_name",
};

char *names1022 [] =
{
"internal_name_32",
"internal_name",
};

char *names1023 [] =
{
"internal_name_32",
"internal_name",
};

char *names1024 [] =
{
"internal_name_32",
"internal_name",
};

char *names1025 [] =
{
"internal_name_32",
"internal_name",
};

char *names1026 [] =
{
"internal_name_32",
"internal_name",
};

char *names1027 [] =
{
"internal_name_32",
"internal_name",
};

char *names1028 [] =
{
"internal_name_32",
"internal_name",
};

char *names1029 [] =
{
"internal_name_32",
"internal_name",
};

char *names1031 [] =
{
"item",
};

char *names1032 [] =
{
"item",
};

char *names1033 [] =
{
"item",
};

char *names1034 [] =
{
"item",
};

char *names1035 [] =
{
"item",
};

char *names1036 [] =
{
"item",
};

char *names1037 [] =
{
"item",
};

char *names1038 [] =
{
"item",
};

char *names1039 [] =
{
"item",
};

char *names1040 [] =
{
"item",
};

char *names1041 [] =
{
"item",
};

char *names1042 [] =
{
"item",
};

char *names1043 [] =
{
"item",
};

char *names1044 [] =
{
"item",
};

char *names1045 [] =
{
"item",
};

char *names1046 [] =
{
"item",
};

char *names1047 [] =
{
"item",
};

char *names1048 [] =
{
"item",
};

char *names1049 [] =
{
"item",
};

char *names1050 [] =
{
"item",
};

char *names1051 [] =
{
"item",
};

char *names1052 [] =
{
"item",
};

char *names1053 [] =
{
"item",
};

char *names1054 [] =
{
"item",
};

char *names1055 [] =
{
"item",
};

char *names1056 [] =
{
"item",
};

char *names1057 [] =
{
"item",
};

char *names1058 [] =
{
"item",
};

char *names1059 [] =
{
"item",
};

char *names1060 [] =
{
"item",
};

char *names1061 [] =
{
"item",
};

char *names1062 [] =
{
"item",
};

char *names1063 [] =
{
"item",
};

char *names1064 [] =
{
"item",
};

char *names1065 [] =
{
"item",
};

char *names1066 [] =
{
"item",
};

char *names1067 [] =
{
"item",
};

char *names1068 [] =
{
"item",
};

char *names1069 [] =
{
"item",
};

char *names1070 [] =
{
"item",
};

char *names1071 [] =
{
"to_pointer",
};

char *names1072 [] =
{
"to_pointer",
};

char *names1073 [] =
{
"to_pointer",
};

char *names1074 [] =
{
"to_pointer",
};

char *names1075 [] =
{
"to_pointer",
};

char *names1076 [] =
{
"to_pointer",
};

char *names1077 [] =
{
"to_pointer",
};

char *names1078 [] =
{
"to_pointer",
};

char *names1079 [] =
{
"to_pointer",
};

char *names1080 [] =
{
"to_pointer",
};

char *names1081 [] =
{
"to_pointer",
};

char *names1082 [] =
{
"to_pointer",
};

char *names1083 [] =
{
"to_pointer",
};

char *names1084 [] =
{
"to_pointer",
};

char *names1085 [] =
{
"to_pointer",
};

char *names1086 [] =
{
"to_pointer",
};

char *names1087 [] =
{
"to_pointer",
};

char *names1088 [] =
{
"to_pointer",
};

char *names1089 [] =
{
"to_pointer",
};

char *names1090 [] =
{
"to_pointer",
};

char *names1091 [] =
{
"to_pointer",
};

char *names1092 [] =
{
"to_pointer",
};

char *names1093 [] =
{
"to_pointer",
};

char *names1094 [] =
{
"to_pointer",
};

char *names1095 [] =
{
"to_pointer",
};

char *names1096 [] =
{
"to_pointer",
};

char *names1097 [] =
{
"to_pointer",
};

char *names1098 [] =
{
"to_pointer",
};

char *names1099 [] =
{
"to_pointer",
};

char *names1100 [] =
{
"to_pointer",
};

char *names1101 [] =
{
"item",
};

char *names1102 [] =
{
"item",
};

char *names1103 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names1104 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names1105 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"last_result",
"is_target_closed",
"is_basic",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names1106 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"last_result",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names1107 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"last_result",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names1108 [] =
{
"internal_hash_code",
"internal_case_insensitive_hash_code",
};

char *names1109 [] =
{
"internal_hash_code",
"internal_case_insensitive_hash_code",
};

char *names1110 [] =
{
"internal_hash_code",
"internal_case_insensitive_hash_code",
};

char *names1111 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names1112 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
"area_lower",
};

char *names1113 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names1114 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names1115 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names1116 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
"area_lower",
};

char *names1117 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names1119 [] =
{
"digits",
"capacity",
"count",
};

char *names1123 [] =
{
"comparer",
"is_upper_first",
};

char *names1124 [] =
{
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
};

char *names1126 [] =
{
"uris",
"schemes",
"last_resolver",
};

char *names1127 [] =
{
"name_pool",
"global_slot_manager",
"function_library",
"rule_manager",
"key_manager",
"decimal_format_manager",
"default_output_properties",
"compiled_templates_index",
"character_map_index",
"static_context",
"attribute_set_manager",
"collation_map",
"stripper_rules",
"module_list",
"output_properties_map",
"required_parameters",
"is_strips_type_annotation",
"is_strips_whitespace",
"are_slots_allocated",
"largest_pattern_stack_frame",
"isolation_level",
};

char *names1129 [] =
{
"executable",
"body",
"system_id",
"slot_manager",
"initialized",
"has_required_parameters",
"line_number",
"template_fingerprint",
"precedence",
"minimum_import_precedence",
};

char *names1131 [] =
{
"next",
"strings",
};

char *names1132 [] =
{
"next",
"prefixes",
"local_parts",
};

char *names1139 [] =
{
"time_zone",
"time",
};

char *names1140 [] =
{
"time_zone",
"date",
};

char *names1153 [] =
{
"time_zone",
"date_time",
};

char *names1154 [] =
{
"time_zone",
"date_time",
};

char *names1157 [] =
{
"base_stream",
};

char *names1164 [] =
{
"ns_prefix",
"uri",
};

char *names1165 [] =
{
"next",
"context",
"last_unique_prefix",
};

char *names1166 [] =
{
"next",
"is_space_preserved",
"last_content",
};

char *names1167 [] =
{
"utf_queue",
"impl",
"last_string",
"encoding",
};

char *names1168 [] =
{
"filename",
};

char *names1170 [] =
{
"code",
};

char *names1171 [] =
{
"last_decimal",
"last_parsed",
"is_comma_allowed",
"decimal_point_is_comma",
"sign",
"exponent_sign",
"state",
"error_code",
"coefficient_begin",
"coefficient_end",
"exponent_begin",
"exponent_end",
"exponent_significant_digits",
"decimal_point_index",
"exponent_as_double",
};

char *names1172 [] =
{
"base_stream",
"decoded_triplet",
"codes",
"last_string",
"last_character",
"equal_sign_read",
"end_of_input",
"triplet_position",
};

char *names1173 [] =
{
"input",
"internal_last_lexical_error",
"current_token_value",
"is_lexical_error",
"is_whitespace_reporting",
"was_whitespace_found",
"input_length",
"input_index",
"current_token",
};

char *names1175 [] =
{
"input",
"next_token_value",
"internal_last_lexical_error",
"current_token_value",
"is_lexical_error",
"next_token_start_index",
"input_length",
"line_number",
"next_token",
"input_index",
"next_line_number",
"current_token",
"preceding_token",
};

char *names1176 [] =
{
"source",
};

char *names1177 [] =
{
"first",
"second",
"tail",
"use_namespaces",
"count",
};

char *names1178 [] =
{
"item",
"changed",
};

char *names1179 [] =
{
"error_message",
"http_method",
"last_result",
};

char *names1180 [] =
{
"error_message",
"http_method",
"last_result",
};

char *names1181 [] =
{
"error_message",
"http_method",
"last_result",
};

char *names1182 [] =
{
"code",
};

char *names1184 [] =
{
"encoding",
"outputter",
"is_error",
};

char *names1185 [] =
{
"encoding",
"outputter",
"is_error",
};

char *names1186 [] =
{
"encoding",
"outputter",
"is_error",
};

char *names1187 [] =
{
"encoding",
"outputter",
"is_error",
"is_utf16_be",
"is_utf16_le",
};

char *names1188 [] =
{
"encoding",
"outputter",
"is_error",
"is_utf32_be",
"is_utf32_le",
};

char *names1189 [] =
{
"executable",
"body",
"system_id",
"slot_manager",
"match",
"collator",
"collation_uri",
"initialized",
"is_backwards_compatible_mode",
"line_number",
};

char *names1190 [] =
{
"shorthand",
"scheme_sequence",
"scheme_data",
"error_message",
"error_code",
"current_scheme_name",
"current_scheme_data",
"is_shorthand",
"is_error",
"last_token",
};

char *names1191 [] =
{
"bindings",
};

char *names1192 [] =
{
"binding_list",
"containing_expression",
"accepted_expression",
"promoted_expression",
"may_promote_document_dependent",
"must_eliminate_duplicates",
"may_promote_xslt_functions",
"action",
};

char *names1193 [] =
{
"container",
"namespace_uri",
"error_code",
"kind",
"operand",
};

char *names1194 [] =
{
"namespace_code_list",
};

char *names1195 [] =
{
"string",
"last_string",
"last_character",
"end_of_input",
"location",
};

char *names1197 [] =
{
"is_highly_secure",
};

char *names1198 [] =
{
"security_manager",
"output_destinations",
"http_method",
"error_message",
"scheme_resolvers",
"last_result",
};

char *names1199 [] =
{
"callbacks",
"dtd_callbacks",
"media_type",
"error_message",
"attribute_types",
"current_element_name",
"pending_namespace",
"pending_prefix",
"pending_local_part",
"pending_attribute_namespaces",
"pending_attribute_prefixes",
"pending_attribute_local_parts",
"pending_attribute_values",
"default_media_type",
"resolver",
"shorthand",
"acceptable_media_types",
"namespace_bindings_stack",
"namespace_bindings",
"is_filtering",
"generic_xml_types_allowed",
"are_media_type_ignored",
"is_forwarding",
"is_forwarding_processing_instructions",
"is_shorthand_found",
"is_shorthand_element",
"is_error",
};

char *names1200 [] =
{
"callbacks",
"dtd_callbacks",
"other_pi",
"is_disallowed",
"is_doubtful",
};

char *names1201 [] =
{
"next",
"last_content",
};

char *names1202 [] =
{
"next",
"dtd_callbacks",
"defaults",
"names",
"values",
"tokens",
"element_tokens",
};

char *names1203 [] =
{
"next",
"context",
"element_prefix",
"element_local_part",
"attributes_prefix",
"attributes_local_part",
"attributes_value",
"forward_xmlns",
};

char *names1204 [] =
{
"stylesheets",
"error_message",
"error_collector",
"uri",
"mime_type",
"title",
"charset",
"applicable_media",
"is_error",
"alternate",
"alternate_seen",
};

char *names1205 [] =
{
"character_buffer",
"last_string",
"last_character",
"end_of_file",
};

char *names1206 [] =
{
"name",
};

char *names1214 [] =
{
"base_stream",
};

char *names1215 [] =
{
"base_stream",
"triplet",
"is_line_breaking",
"is_normalizing",
"is_pending_line_break",
"line_count",
"triplet_count",
};

char *names1221 [] =
{
"name",
};

char *names1224 [] =
{
"regexp_cache",
};

char *names1225 [] =
{
"regexp",
"match_records",
"is_error",
};

char *names1228 [] =
{
"last_found_template",
"mode_for_default_mode",
"omni_mode",
"mode_map",
"priority_ranks",
};

char *names1229 [] =
{
"string",
};

char *names1231 [] =
{
"attribute_ids",
"attribute_name_codes",
"attribute_type_codes",
"attribute_values",
"internal_attribute_properties",
};

char *names1232 [] =
{
"function_library",
"value",
"evaluated",
"is_w3c",
"is_error",
"were_resources_found",
};

char *names1233 [] =
{
"reporter",
"start_time",
"is_timing",
"is_tracing",
"indentation",
};

char *names1235 [] =
{
"types_created",
};

char *names1236 [] =
{
"types_created",
};

char *names1237 [] =
{
"types_created",
};

char *names1239 [] =
{
"scheme",
};

char *names1240 [] =
{
"configuration",
"known_collations",
"internal_last_bound_variable",
"is_restricted",
"bound_variables_count",
};

char *names1241 [] =
{
"configuration",
"known_collations",
"internal_last_bound_variable",
"node_factory",
"cached_function_manager",
"default_collation_name",
"default_element_namespace",
"namespace_resolver",
"system_id",
"base_uri",
"is_restricted",
"is_backwards_compatible_mode",
"bound_variables_count",
"line_number",
};

char *names1242 [] =
{
"hash_slots",
"prefixes",
"uris",
"prefixes_for_uri",
"last_name_code",
"last_uri_code",
"last_prefix_code",
"last_namespace_code",
"prefixes_used",
"uris_used",
};

char *names1244 [] =
{
"byte_code",
"character_sets",
"count",
"capacity",
};

char *names1246 [] =
{
"document",
"context",
"last_node_iterator",
"key_fingerprint",
};

char *names1247 [] =
{
"start",
"whitespace",
"content",
"attributes",
"error",
"emitter",
"tree",
};

char *names1248 [] =
{
"tree",
"mapping_table",
};

char *names1250 [] =
{
"last_parsed_duration",
"last_cached_duration",
"is_negative",
"any_designator_found",
"current_year",
"current_month",
"current_day",
"current_hour",
"current_minute",
};

char *names1251 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"last_string_32",
"internal_encoding",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"is_sequence_an_expected_numeric",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1252 [] =
{
"encoded",
"decoded_impl",
"decoded_utf8_impl",
};

char *names1253 [] =
{
"host",
"port",
};

char *names1255 [] =
{
"may_use_xpointer",
"may_use_id",
};

char *names1264 [] =
{
"separators",
"separator_codes",
"escape_character",
"has_escape_character",
};

char *names1265 [] =
{
"input_buffer",
"last_character",
"last_unicode_character",
"last_token",
};

char *names1266 [] =
{
"input_buffer",
"yy_content",
"yy_content_area",
"yy_unicode_content_area",
"yy_pushed_start_conditions",
"last_character",
"yy_more_flag",
"last_unicode_character",
"last_token",
"yy_start_state",
"yy_end",
"yy_start",
"yy_line",
"yy_column",
"yy_position",
"yy_more_len",
"yy_last_accepting_state",
"yy_last_accepting_cpos",
"pushed_start_condition_count",
"position",
"column",
"line",
};

char *names1267 [] =
{
"input_buffer",
"yy_content",
"yy_content_area",
"yy_unicode_content_area",
"yy_pushed_start_conditions",
"yy_nxt",
"yy_chk",
"yy_base",
"yy_def",
"yy_ec",
"yy_meta",
"yy_accept",
"yy_acclist",
"yy_state_stack",
"last_character",
"yy_more_flag",
"yy_rejected",
"last_unicode_character",
"last_token",
"yy_start_state",
"yy_end",
"yy_start",
"yy_line",
"yy_column",
"yy_position",
"yy_more_len",
"yy_last_accepting_state",
"yy_last_accepting_cpos",
"pushed_start_condition_count",
"position",
"column",
"line",
"yy_state_count",
"yy_full_match",
"yy_lp",
"yy_looking_for_trail_begin",
"yy_full_lp",
"yy_full_state",
};

char *names1269 [] =
{
"item",
"key_list",
"record_number",
};

char *names1270 [] =
{
"item",
"key_list",
"current_grouping_key",
"current_group_iterator",
"record_number",
};

char *names1271 [] =
{
"item",
"key_list",
"record_number",
};

char *names1272 [] =
{
"item",
"key_list",
"current_grouping_key",
"current_group_iterator",
"record_number",
};

char *names1280 [] =
{
"fixed_offset",
"name",
};

char *names1285 [] =
{
"last_cached_date_string",
"last_cached_date",
"last_cached_zoned_date_string",
"last_cached_zoned_date",
"last_cached_time_string",
"last_cached_time",
"last_cached_zoned_time_string",
"last_cached_zoned_time",
"last_cached_date_time_string",
"last_cached_date_time",
"last_cached_zoned_date_time_string",
"last_cached_zoned_date_time",
"is_year_zero_valid",
"last_time_carry",
};

char *names1286 [] =
{
"last_cached_date_string",
"last_cached_date",
"last_cached_zoned_date_string",
"last_cached_zoned_date",
"last_cached_time_string",
"last_cached_time",
"last_cached_zoned_time_string",
"last_cached_zoned_time",
"last_cached_date_time_string",
"last_cached_date_time",
"last_cached_zoned_date_time_string",
"last_cached_zoned_date_time",
"is_year_zero_valid",
"last_time_carry",
};

char *names1287 [] =
{
"zoned",
};

char *names1288 [] =
{
"zoned_date_time",
"local_date_time",
"zoned",
};

char *names1289 [] =
{
"zoned_time",
"local_time",
"zoned",
};

char *names1290 [] =
{
"zoned_date",
"local_date",
"zoned",
};

char *names1291 [] =
{
"sort_key",
"order_expression",
"case_order_expression",
"language_expression",
"data_type_expression",
"collation_name_expression",
"collation_name",
"order",
"language",
"case_order",
"data_type",
};

char *names1292 [] =
{
"code",
};

char *names1293 [] =
{
"code",
};

char *names1294 [] =
{
"code",
};

char *names1295 [] =
{
"last_converted_string",
"last_conversion_successful",
"last_was_wide_string",
};

char *names1296 [] =
{
"last_converted_string",
"last_conversion_successful",
"last_was_wide_string",
};

char *names1297 [] =
{
"last_converted_string",
"last_conversion_successful",
"last_was_wide_string",
};

char *names1300 [] =
{
"source_name",
"row",
"column",
"byte_index",
};

char *names1301 [] =
{
"are_media_type_ignored",
};

char *names1302 [] =
{
"default_media_type",
"source_text",
"xpointer_filter",
"oasis_xml_catalog_filter",
"content_emitter",
"start",
"namespace_resolver",
"attributes",
"content",
"error",
"media_type",
"fragment_identifier",
"system_id",
"are_media_type_ignored",
};

char *names1304 [] =
{
"collator",
"dynamic_context",
};

char *names1305 [] =
{
"collator",
"dynamic_context",
};

char *names1307 [] =
{
"next_cursor",
};

char *names1308 [] =
{
"next_cursor",
};

char *names1309 [] =
{
"next_cursor",
};

char *names1310 [] =
{
"next_cursor",
};

char *names1311 [] =
{
"next_cursor",
};

char *names1312 [] =
{
"next_cursor",
};

char *names1313 [] =
{
"next_cursor",
};

char *names1314 [] =
{
"next_cursor",
};

char *names1315 [] =
{
"next_cursor",
};

char *names1316 [] =
{
"next_cursor",
};

char *names1317 [] =
{
"next_cursor",
};

char *names1318 [] =
{
"next_cursor",
};

char *names1319 [] =
{
"next_cursor",
};

char *names1320 [] =
{
"next_cursor",
};

char *names1321 [] =
{
"next_cursor",
};

char *names1322 [] =
{
"next_cursor",
};

char *names1323 [] =
{
"next_cursor",
};

char *names1324 [] =
{
"next_cursor",
};

char *names1325 [] =
{
"next_cursor",
};

char *names1326 [] =
{
"next_cursor",
};

char *names1327 [] =
{
"next_cursor",
};

char *names1328 [] =
{
"next_cursor",
};

char *names1329 [] =
{
"next_cursor",
};

char *names1330 [] =
{
"next_cursor",
};

char *names1331 [] =
{
"next_cursor",
};

char *names1332 [] =
{
"next_cursor",
};

char *names1333 [] =
{
"next_cursor",
};

char *names1334 [] =
{
"next_cursor",
};

char *names1335 [] =
{
"next_cursor",
"table_cursor",
"container",
};

char *names1336 [] =
{
"next_cursor",
"table_cursor",
"container",
};

char *names1337 [] =
{
"next_cursor",
"table_cursor",
"container",
};

char *names1338 [] =
{
"next_cursor",
"table_cursor",
"container",
};

char *names1339 [] =
{
"next_cursor",
"table_cursor",
"container",
};

char *names1340 [] =
{
"next_cursor",
"table_cursor",
"container",
};

char *names1341 [] =
{
"next_cursor",
};

char *names1342 [] =
{
"next_cursor",
};

char *names1343 [] =
{
"next_cursor",
};

char *names1344 [] =
{
"next_cursor",
};

char *names1345 [] =
{
"next_cursor",
};

char *names1346 [] =
{
"next_cursor",
};

char *names1347 [] =
{
"next_cursor",
"container",
"position",
};

char *names1348 [] =
{
"next_cursor",
"container",
"position",
};

char *names1349 [] =
{
"next_cursor",
"container",
"position",
};

char *names1350 [] =
{
"next_cursor",
"container",
"position",
};

char *names1351 [] =
{
"next_cursor",
"container",
"position",
};

char *names1352 [] =
{
"next_cursor",
"container",
"position",
};

char *names1353 [] =
{
"next_cursor",
"container",
"position",
};

char *names1354 [] =
{
"next_cursor",
"container",
"position",
};

char *names1355 [] =
{
"next_cursor",
"container",
"position",
};

char *names1356 [] =
{
"next_cursor",
"container",
"position",
};

char *names1357 [] =
{
"next_cursor",
"container",
"position",
};

char *names1358 [] =
{
"next_cursor",
"container",
"position",
};

char *names1359 [] =
{
"next_cursor",
"container",
"position",
};

char *names1360 [] =
{
"next_cursor",
"container",
"position",
};

char *names1361 [] =
{
"next_cursor",
"container",
"position",
};

char *names1362 [] =
{
"next_cursor",
"container",
"position",
};

char *names1363 [] =
{
"next_cursor",
"container",
"position",
};

char *names1364 [] =
{
"next_cursor",
"container",
"position",
};

char *names1365 [] =
{
"next_cursor",
"container",
"position",
};

char *names1366 [] =
{
"next_cursor",
"container",
"position",
};

char *names1367 [] =
{
"next_cursor",
"container",
"position",
};

char *names1368 [] =
{
"next_cursor",
"container",
"position",
};

char *names1369 [] =
{
"next_cursor",
"container",
"position",
};

char *names1370 [] =
{
"next_cursor",
"container",
"position",
};

char *names1371 [] =
{
"next_cursor",
"container",
"position",
};

char *names1372 [] =
{
"next_cursor",
"container",
"position",
};

char *names1373 [] =
{
"next_cursor",
"container",
"position",
};

char *names1374 [] =
{
"next_cursor",
"container",
"position",
};

char *names1375 [] =
{
"next_cursor",
"container",
"position",
};

char *names1376 [] =
{
"next_cursor",
"container",
"position",
};

char *names1377 [] =
{
"next_cursor",
"container",
"position",
};

char *names1378 [] =
{
"next_cursor",
"container",
"position",
};

char *names1379 [] =
{
"next_cursor",
"container",
"position",
};

char *names1380 [] =
{
"next_cursor",
"container",
"position",
};

char *names1381 [] =
{
"next_cursor",
};

char *names1382 [] =
{
"next_cursor",
};

char *names1383 [] =
{
"next_cursor",
};

char *names1384 [] =
{
"next_cursor",
"container",
"position",
};

char *names1385 [] =
{
"next_cursor",
"container",
"position",
};

char *names1386 [] =
{
"next_cursor",
"container",
"position",
};

char *names1387 [] =
{
"next_cursor",
"current_cell",
"container",
"before",
"after",
};

char *names1388 [] =
{
"next_cursor",
"current_cell",
"container",
"before",
"after",
};

char *names1389 [] =
{
"next_cursor",
"current_cell",
"container",
"before",
"after",
};

char *names1391 [] =
{
"normalizer_factory",
"extension_emitter_factories",
};

char *names1393 [] =
{
"data",
"last_media_type",
"last_stream",
"last_error",
"is_base_64",
"has_error",
};

char *names1394 [] =
{
"last_error",
"last_stream",
};

char *names1395 [] =
{
"last_media_type",
"last_error",
"last_stream",
};

char *names1402 [] =
{
"local_name",
"namespace_uri",
"base_type",
"fingerprint",
};

char *names1403 [] =
{
"local_name",
"namespace_uri",
"base_type",
"is_abstract",
"fingerprint",
};

char *names1404 [] =
{
"local_name",
"namespace_uri",
"base_type",
"is_abstract",
"fingerprint",
};

char *names1405 [] =
{
"local_name",
"namespace_uri",
"base_type",
"is_abstract",
"fingerprint",
};

char *names1406 [] =
{
"local_name",
"namespace_uri",
"base_type",
"fingerprint",
};

char *names1407 [] =
{
"local_name",
"namespace_uri",
"base_type",
"fingerprint",
};

char *names1408 [] =
{
"string_mode",
};

char *names1409 [] =
{
"dtd_resolver",
"entity_resolver",
"string_mode",
};

char *names1410 [] =
{
"dtd_resolver",
"entity_resolver",
"string_mode",
};

char *names1414 [] =
{
"variable_name",
"last_evaluated_binding",
"required_type",
"reference_count",
"slot_number",
};

char *names1439 [] =
{
"equality_tester",
};

char *names1440 [] =
{
"equality_tester",
};

char *names1441 [] =
{
"equality_tester",
};

char *names1442 [] =
{
"equality_tester",
};

char *names1443 [] =
{
"equality_tester",
};

char *names1444 [] =
{
"equality_tester",
};

char *names1445 [] =
{
"equality_tester",
};

char *names1446 [] =
{
"equality_tester",
};

char *names1447 [] =
{
"equality_tester",
};

char *names1448 [] =
{
"equality_tester",
};

char *names1449 [] =
{
"equality_tester",
};

char *names1450 [] =
{
"equality_tester",
};

char *names1451 [] =
{
"equality_tester",
};

char *names1452 [] =
{
"equality_tester",
};

char *names1453 [] =
{
"equality_tester",
};

char *names1454 [] =
{
"equality_tester",
};

char *names1455 [] =
{
"equality_tester",
};

char *names1456 [] =
{
"equality_tester",
};

char *names1457 [] =
{
"equality_tester",
"table",
"internal_cursor",
};

char *names1458 [] =
{
"equality_tester",
"table",
"internal_cursor",
};

char *names1459 [] =
{
"equality_tester",
"table",
"internal_cursor",
};

char *names1460 [] =
{
"equality_tester",
"table",
"internal_cursor",
};

char *names1461 [] =
{
"equality_tester",
"table",
"internal_cursor",
};

char *names1462 [] =
{
"equality_tester",
"table",
"internal_cursor",
};

char *names1463 [] =
{
"equality_tester",
};

char *names1464 [] =
{
"equality_tester",
};

char *names1465 [] =
{
"equality_tester",
};

char *names1466 [] =
{
"equality_tester",
};

char *names1467 [] =
{
"equality_tester",
};

char *names1468 [] =
{
"equality_tester",
};

char *names1469 [] =
{
"equality_tester",
};

char *names1470 [] =
{
"equality_tester",
};

char *names1471 [] =
{
"equality_tester",
};

char *names1472 [] =
{
"equality_tester",
};

char *names1473 [] =
{
"equality_tester",
};

char *names1474 [] =
{
"equality_tester",
};

char *names1475 [] =
{
"equality_tester",
};

char *names1476 [] =
{
"equality_tester",
};

char *names1477 [] =
{
"equality_tester",
};

char *names1478 [] =
{
"equality_tester",
};

char *names1479 [] =
{
"equality_tester",
};

char *names1480 [] =
{
"equality_tester",
};

char *names1481 [] =
{
"equality_tester",
};

char *names1482 [] =
{
"equality_tester",
"first_cell",
"last_cell",
"internal_cursor",
"count",
};

char *names1483 [] =
{
"equality_tester",
"first_cell",
"last_cell",
"internal_cursor",
"count",
};

char *names1484 [] =
{
"equality_tester",
"first_cell",
"last_cell",
"internal_cursor",
"count",
};

char *names1485 [] =
{
"equality_tester",
"first_cell",
"last_cell",
"internal_cursor",
"count",
};

char *names1486 [] =
{
"equality_tester",
};

char *names1487 [] =
{
"equality_tester",
};

char *names1488 [] =
{
"equality_tester",
};

char *names1489 [] =
{
"equality_tester",
};

char *names1490 [] =
{
"equality_tester",
};

char *names1491 [] =
{
"equality_tester",
};

char *names1492 [] =
{
"equality_tester",
"first_cell",
"last_cell",
"count",
};

char *names1493 [] =
{
"equality_tester",
"first_cell",
"last_cell",
"count",
};

char *names1494 [] =
{
"equality_tester",
};

char *names1495 [] =
{
"equality_tester",
};

char *names1496 [] =
{
"equality_tester",
};

char *names1497 [] =
{
"equality_tester",
"first_cell",
"count",
};

char *names1503 [] =
{
"equality_tester",
"storage",
"special_routines",
"capacity",
"count",
};

char *names1504 [] =
{
"equality_tester",
"storage",
"special_routines",
"capacity",
"count",
};

char *names1505 [] =
{
"equality_tester",
"storage",
"special_routines",
"capacity",
"count",
};

char *names1506 [] =
{
"equality_tester",
"storage",
"special_routines",
"internal_cursor",
"capacity",
"count",
};

char *names1507 [] =
{
"equality_tester",
"storage",
"special_routines",
"internal_cursor",
"capacity",
"count",
};

char *names1508 [] =
{
"equality_tester",
"storage",
"special_routines",
"internal_cursor",
"capacity",
"count",
};

char *names1509 [] =
{
"equality_tester",
"internal_cursor",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1510 [] =
{
"equality_tester",
"internal_cursor",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1511 [] =
{
"equality_tester",
"internal_cursor",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1512 [] =
{
"equality_tester",
"internal_cursor",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1513 [] =
{
"equality_tester",
"internal_cursor",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1514 [] =
{
"equality_tester",
"internal_cursor",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1515 [] =
{
"equality_tester",
"internal_cursor",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1516 [] =
{
"equality_tester",
"internal_cursor",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1517 [] =
{
"equality_tester",
"internal_cursor",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1518 [] =
{
"equality_tester",
"internal_cursor",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1519 [] =
{
"equality_tester",
"internal_cursor",
"item_storage",
"clashes",
"slots",
"special_item_routines",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1520 [] =
{
"equality_tester",
"internal_cursor",
"item_storage",
"clashes",
"slots",
"special_item_routines",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1521 [] =
{
"equality_tester",
"internal_cursor",
"item_storage",
"clashes",
"slots",
"special_item_routines",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1522 [] =
{
"equality_tester",
"internal_cursor",
"item_storage",
"clashes",
"slots",
"special_item_routines",
"hash_function",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1523 [] =
{
"equality_tester",
"internal_cursor",
"item_storage",
"clashes",
"slots",
"special_item_routines",
"hash_function",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1524 [] =
{
"equality_tester",
"internal_cursor",
"item_storage",
"clashes",
"slots",
"special_item_routines",
"hash_function",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1525 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1526 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1527 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1528 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1529 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1530 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1531 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"item_storage",
"key_storage",
"clashes",
"slots",
"special_item_routines",
"special_key_routines",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1532 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"item_storage",
"key_storage",
"clashes",
"slots",
"special_item_routines",
"special_key_routines",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1533 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"item_storage",
"key_storage",
"clashes",
"slots",
"special_item_routines",
"special_key_routines",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1534 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"item_storage",
"key_storage",
"clashes",
"slots",
"special_item_routines",
"special_key_routines",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1535 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"item_storage",
"key_storage",
"clashes",
"slots",
"special_item_routines",
"special_key_routines",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1536 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"item_storage",
"key_storage",
"clashes",
"slots",
"special_item_routines",
"special_key_routines",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1537 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"item_storage",
"key_storage",
"clashes",
"slots",
"special_item_routines",
"special_key_routines",
"hash_function",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1538 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"item_storage",
"key_storage",
"clashes",
"slots",
"special_item_routines",
"special_key_routines",
"hash_function",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1539 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"item_storage",
"key_storage",
"clashes",
"slots",
"special_item_routines",
"special_key_routines",
"hash_function",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1540 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"item_storage",
"key_storage",
"clashes",
"slots",
"special_item_routines",
"special_key_routines",
"hash_function",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1541 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"item_storage",
"key_storage",
"clashes",
"slots",
"special_item_routines",
"special_key_routines",
"hash_function",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1542 [] =
{
"equality_tester",
"internal_cursor",
"internal_keys",
"key_equality_tester",
"item_storage",
"key_storage",
"clashes",
"slots",
"special_item_routines",
"special_key_routines",
"hash_function",
"last_position",
"modulus",
"free_slot",
"position",
"slots_position",
"clashes_previous_position",
"found_position",
"capacity",
"count",
};

char *names1544 [] =
{
"uri_scheme_resolver",
"well_known_system_ids",
"well_known_public_ids",
"well_known_uri_references",
"last_media_type",
"last_system_id",
"last_uri_reference_stream",
"last_stream",
"has_media_type",
};

char *names1545 [] =
{
"lastentry",
"internal_name",
"internal_detachable_name_pointer",
"entry_buffer",
"last_entry",
"name",
"old_end_of_input",
"end_of_input",
"mode",
"directory_pointer",
"last_entry_pointer",
};

char *names1546 [] =
{
"last_system_id",
};

char *names1547 [] =
{
"default_media_type",
"xpointer_filter",
"oasis_xml_catalog_filter",
"content_emitter",
"start",
"namespace_resolver",
"attributes",
"content",
"error",
"media_type",
"fragment_identifier",
"system_id",
"are_media_type_ignored",
};

char *names1548 [] =
{
"initial_template_name",
"initial_mode_name",
"initial_context",
"error_handler",
"error_listener",
"uris",
"parameters",
"xpath_parameters",
"output_destination",
"configuration",
"trace_file",
"medium",
"title",
"transformer_factory",
"user_name",
"password",
"use_processing_instruction",
"is_tiny_tree_model",
"is_reporting_document_statistics",
"is_line_numbering",
"is_tracing",
"is_timed_tracing",
"is_timing",
"highly_secure",
"suppress_output_extensions",
"suppress_extension_functions",
"suppress_network_protocols",
"estimated_nodes",
"estimated_attributes",
"estimated_namespaces",
"estimated_characters",
"digits",
};

char *names1549 [] =
{
"name",
};

char *names1550 [] =
{
"name",
"character_buffer",
"last_string",
"last_character",
"end_of_file",
};

char *names1551 [] =
{
"internal_name",
"internal_detachable_name_pointer",
"last_string_32",
"internal_encoding",
"name",
"character_buffer",
"last_string",
"separator",
"last_character",
"object_comparison",
"descriptor_available",
"is_sequence_an_expected_numeric",
"end_of_file",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1552 [] =
{
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"name",
"character_buffer",
"last_string",
"separator",
"last_character",
"object_comparison",
"descriptor_available",
"end_of_file",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1553 [] =
{
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"name",
"character_buffer",
"last_string",
"separator",
"last_character",
"object_comparison",
"descriptor_available",
"end_of_file",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1554 [] =
{
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"name",
"character_buffer",
"last_string",
"separator",
"last_character",
"object_comparison",
"descriptor_available",
"end_of_file",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1555 [] =
{
"name",
};

char *names1556 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"last_string_32",
"internal_encoding",
"name",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"is_sequence_an_expected_numeric",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1557 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"name",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1558 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"name",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1559 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"name",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1561 [] =
{
"last_node_iterator",
};

char *names1563 [] =
{
"error_listener",
"configuration",
};

char *names1564 [] =
{
"error_change_stack",
"error_reporter",
"warnings_are_recoverable_errors",
"recovered",
"recovery_policy",
"warning_threshold",
"recoverable_error_threshold",
"warnings",
"errors",
"fatal_errors",
};

char *names1565 [] =
{
"components",
"value",
"evaluated",
"is_error",
"were_resources_found",
};

char *names1566 [] =
{
"value",
"registered_schemes",
"namespace_bindings",
"is_reporting_scheme_errors",
};

char *names1568 [] =
{
"regexp_cache_entry",
"regexp_error_value",
"is_empty_match_ok",
};

char *names1569 [] =
{
"use_character_maps",
"cdata_section_expanded_names",
"cdata_validation_error",
};

char *names1570 [] =
{
"lower_table",
"flip_table",
};

char *names1572 [] =
{
"managed_pointer",
"shared",
"type",
"internal_item",
};

char *names1573 [] =
{
"managed_pointer",
"shared",
"type",
"internal_item",
};

char *names1574 [] =
{
"sequence_numbers",
"uris",
};

char *names1575 [] =
{
"base",
"system_id",
"public_id",
};

char *names1576 [] =
{
"decimal_separator",
"grouping_separator",
"infinity",
"minus_sign",
"nan",
"percent",
"per_mille",
"zero_digit",
"digit_sign",
"pattern_separator",
"fingerprint",
"precedence",
};

char *names1579 [] =
{
"document_name_map",
"collection_name_map",
"media_type_name_map",
"isolation_level",
};

char *names1580 [] =
{
"top_callstack_record",
"bottom_callstack_record",
"replayed_call",
"replay_stack",
"flatten_when_closing",
"keep_calls_records",
"recording_values",
"is_replaying",
"last_replay_operation_failed",
"record_count",
"maximum_record_count",
};

char *names1581 [] =
{
"error_file",
"warning_file",
"info_file",
};

char *names1588 [] =
{
"schemes",
"last_error",
"last_collection",
};

char *names1590 [] =
{
"next",
};

char *names1591 [] =
{
"last_output",
"output_stream",
};

char *names1592 [] =
{
"next",
"last_output",
"output_stream",
"empty_element_tags_enabled",
"last_call_was_start_tag_finish",
"is_tag_end_pending",
};

char *names1593 [] =
{
"next",
"last_output",
"output_stream",
"indent",
"space_preserved",
"empty_element_tags_enabled",
"last_call_was_start_tag_finish",
"is_tag_end_pending",
"has_content",
"is_root",
"depth",
};

char *names1594 [] =
{
"next",
"last_output",
"output_stream",
"empty_element_tags_enabled",
"last_call_was_start_tag_finish",
"is_tag_end_pending",
};

char *names1596 [] =
{
"parent",
};

char *names1597 [] =
{
"parent",
};

char *names1598 [] =
{
"parent",
};

char *names1599 [] =
{
"parent",
"target",
"data",
};

char *names1600 [] =
{
"parent",
"data",
};

char *names1601 [] =
{
"parent",
"content",
};

char *names1602 [] =
{
"parent",
"name",
"namespace",
};

char *names1603 [] =
{
"parent",
"name",
"namespace",
"value",
};

char *names1604 [] =
{
"children",
};

char *names1605 [] =
{
"parent",
"name",
"namespace",
"children",
};

char *names1606 [] =
{
"children",
"root_element",
};

char *names1607 [] =
{
"subject",
"subject_start",
"subject_end",
"match_count",
};

char *names1608 [] =
{
"subject",
"subject_start",
"subject_end",
"match_count",
};

char *names1610 [] =
{
"namespace_uri",
};

char *names1611 [] =
{
"namespace_uri",
};

char *names1613 [] =
{
"day",
"month",
"year",
};

char *names1614 [] =
{
"storage",
};

char *names1616 [] =
{
"storage",
};

char *names1617 [] =
{
"millisecond",
"second",
"minute",
"hour",
};

char *names1619 [] =
{
"day",
"month",
"year",
"millisecond",
"second",
"minute",
"hour",
};

char *names1620 [] =
{
"date_storage",
"time_storage",
};

char *names1621 [] =
{
"last_bound_function",
"last_established_fingerprint",
};

char *names1622 [] =
{
"last_bound_function",
"function_table",
"last_established_fingerprint",
};

char *names1623 [] =
{
"last_bound_function",
"stylesheet",
"is_overriding",
"last_established_fingerprint",
};

char *names1624 [] =
{
"last_bound_function",
"libraries",
"last_established_fingerprint",
};

char *names1625 [] =
{
"last_bound_function",
"last_established_fingerprint",
};

char *names1626 [] =
{
"last_bound_function",
"last_established_fingerprint",
};

char *names1627 [] =
{
"last_bound_function",
"last_established_fingerprint",
};

char *names1628 [] =
{
"last_bound_function",
"last_established_fingerprint",
};

char *names1630 [] =
{
"formatting_tokens",
"formatting_separators",
"starts_with_separator",
};

char *names1632 [] =
{
"document",
"last_node_iterator",
};

char *names1633 [] =
{
"sort_key",
"order_expression",
"case_order_expression",
"language_expression",
"data_type_expression",
"collation_name_expression",
"collation_name",
"order",
"language",
"case_order",
"data_type",
"collator",
"comparer",
"error_value",
"is_error",
};

char *names1634 [] =
{
"configuration",
"executable",
"node_factory",
"last_loaded_module",
"error_listener",
"load_stylesheet_module_error",
"load_stylesheet_module_failed",
"counter",
};

char *names1635 [] =
{
"parsed_error_value",
"last_created_closure",
"internal_parsed_expression",
"is_parse_error",
};

char *names1636 [] =
{
"error_value",
"last_realized_value",
"is_error",
"index",
};

char *names1637 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"label",
"context",
"internal_item",
"is_error",
"is_empty_sequence",
"index",
};

char *names1638 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"label",
"context",
"internal_item",
"is_error",
"is_empty_sequence",
"index",
};

char *names1639 [] =
{
"error_value",
"last_realized_value",
"input",
"regexp_cache_entry",
"tokens",
"internal_item",
"is_error",
"index",
"token_count",
};

char *names1640 [] =
{
"error_value",
"last_realized_value",
"base_sequence",
"internal_item",
"is_error",
"index",
"removal_position",
};

char *names1641 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"insertion_iterator",
"internal_item",
"is_error",
"is_inserting",
"index",
"insert_position",
};

char *names1642 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"insertion_iterator",
"internal_item",
"is_error",
"is_inserting",
"index",
"insert_position",
};

char *names1643 [] =
{
"error_value",
"last_realized_value",
"base_sequence",
"search_value",
"atomic_comparer",
"internal_item",
"is_error",
"index",
"last_position_index",
};

char *names1644 [] =
{
"error_value",
"last_realized_value",
"base_sequence",
"atomic_comparer",
"values_seen",
"internal_item",
"is_error",
"index",
};

char *names1645 [] =
{
"error_value",
"last_realized_value",
"comparer",
"first_iterator",
"second_iterator",
"current_node",
"is_error",
"index",
};

char *names1646 [] =
{
"error_value",
"last_realized_value",
"first_iterator",
"second_iterator",
"comparer",
"first_node",
"second_node",
"internal_item",
"is_error",
"index",
};

char *names1647 [] =
{
"error_value",
"last_realized_value",
"first_iterator",
"second_iterator",
"comparer",
"cached_first_node",
"cached_second_node",
"first_node",
"second_node",
"internal_item",
"is_error",
"index",
};

char *names1648 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"mapping_function",
"internal_item",
"is_error",
"index",
};

char *names1649 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"mapping_function",
"internal_item",
"is_error",
"index",
};

char *names1650 [] =
{
"error_value",
"last_realized_value",
"mapping_function",
"context",
"base_iterator",
"results_iterator",
"internal_item",
"is_error",
"index",
};

char *names1651 [] =
{
"error_value",
"last_realized_value",
"child_list",
"context",
"child_iterator",
"internal_item",
"is_error",
"index",
"child_index",
};

char *names1652 [] =
{
"error_value",
"last_realized_value",
"child_list",
"context",
"child_iterator",
"internal_item",
"is_error",
"index",
"child_index",
};

char *names1653 [] =
{
"error_value",
"last_realized_value",
"is_error",
"index",
"minimum",
"maximum",
};

char *names1654 [] =
{
"error_value",
"last_realized_value",
"comparer",
"current_node",
"sequence",
"is_error",
"index",
};

char *names1655 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"is_error",
"index",
"start_position",
};

char *names1656 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"is_error",
"index",
"start_position",
};

char *names1657 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"results",
"mapping_function",
"context",
"internal_item",
"is_error",
"index",
};

char *names1658 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"results",
"mapping_function",
"context",
"internal_item",
"is_error",
"index",
};

char *names1659 [] =
{
"error_value",
"last_realized_value",
"reservoir",
"base_iterator",
"closure",
"is_error",
"index",
};

char *names1660 [] =
{
"error_value",
"last_realized_value",
"reservoir",
"base_iterator",
"closure",
"is_error",
"index",
};

char *names1661 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"role_locator",
"is_error",
"index",
"required_cardinality",
};

char *names1662 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"role_locator",
"is_error",
"index",
"required_cardinality",
};

char *names1663 [] =
{
"error_value",
"last_realized_value",
"internal_item",
"input",
"regexp",
"next_subject",
"is_error",
"was_last_match",
"after",
"index",
};

char *names1664 [] =
{
"error_value",
"last_realized_value",
"is_error",
"index",
};

char *names1665 [] =
{
"error_value",
"last_realized_value",
"is_error",
"index",
};

char *names1666 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"is_error",
"index",
"minimum",
"maximum",
};

char *names1667 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"is_error",
"index",
"minimum",
"maximum",
};

char *names1668 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"sort_keys",
"context",
"key_comparers",
"node_keys",
"is_error",
"count_determined",
"index",
"count",
};

char *names1669 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"sort_keys",
"context",
"key_comparers",
"node_keys",
"is_error",
"count_determined",
"index",
"count",
};

char *names1670 [] =
{
"error_value",
"last_realized_value",
"list",
"cursor",
"is_error",
"index",
"first_item",
"last_item",
};

char *names1671 [] =
{
"error_value",
"last_realized_value",
"list",
"cursor",
"is_error",
"index",
"first_item",
"last_item",
};

char *names1672 [] =
{
"error_value",
"last_realized_value",
"list",
"cursor",
"is_error",
"index",
"first_item",
"last_item",
};

char *names1673 [] =
{
"error_value",
"last_realized_value",
"value",
"is_error",
"gone",
"index",
};

char *names1674 [] =
{
"error_value",
"last_realized_value",
"is_error",
"index",
};

char *names1675 [] =
{
"error_value",
"last_realized_value",
"population",
"key_expression",
"key_context",
"comparer",
"groups",
"group_keys",
"stored_collator",
"is_error",
"indexed_groups_built",
"index",
};

char *names1676 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"sort_keys",
"context",
"key_comparers",
"node_keys",
"group_iterator",
"is_error",
"count_determined",
"index",
"count",
};

char *names1677 [] =
{
"error_value",
"last_realized_value",
"internal_item",
"population",
"key_pattern",
"base_context",
"running_context",
"next_candidate",
"current_members",
"locator",
"is_error",
"after_pending",
"after",
"index",
};

char *names1678 [] =
{
"error_value",
"last_realized_value",
"internal_item",
"population",
"key_pattern",
"base_context",
"running_context",
"next_candidate",
"current_members",
"locator",
"is_error",
"index",
};

char *names1679 [] =
{
"error_value",
"last_realized_value",
"population",
"key_expression",
"base_context",
"running_context",
"comparer",
"stored_collator",
"current_members",
"next_item",
"current_key",
"next_key",
"is_error",
"after",
"index",
};

char *names1680 [] =
{
"error_value",
"last_realized_value",
"current_item",
"is_error",
"index",
};

char *names1681 [] =
{
"starting_node",
"node_test",
"next_node",
"error_value",
"last_realized_value",
"current_item",
"is_error",
"include_self",
"index",
};

char *names1682 [] =
{
"starting_node",
"node_test",
"next_node",
"error_value",
"last_realized_value",
"current_item",
"is_error",
"index",
};

char *names1683 [] =
{
"starting_node",
"node_test",
"next_node",
"error_value",
"last_realized_value",
"current_item",
"next_ancestor",
"is_error",
"index",
};

char *names1684 [] =
{
"starting_node",
"node_test",
"next_node",
"error_value",
"last_realized_value",
"current_item",
"is_error",
"include_self",
"index",
};

char *names1685 [] =
{
"starting_node",
"node_test",
"next_node",
"error_value",
"last_realized_value",
"current_item",
"is_error",
"index",
};

char *names1686 [] =
{
"starting_node",
"node_test",
"next_node",
"error_value",
"last_realized_value",
"current_item",
"is_error",
"index",
};

char *names1687 [] =
{
"error_value",
"last_realized_value",
"current_item",
"document",
"starting_node",
"parent_node",
"node_test",
"is_error",
"get_children",
"need_to_advance",
"index",
"next_node_number",
};

char *names1688 [] =
{
"error_value",
"last_realized_value",
"current_item",
"document",
"starting_node",
"parent_node",
"node_test",
"is_error",
"index",
"next_node_number",
};

char *names1689 [] =
{
"error_value",
"last_realized_value",
"current_item",
"document",
"starting_node",
"node_test",
"is_error",
"include_ancestors",
"index",
"next_ancestor_depth",
};

char *names1690 [] =
{
"error_value",
"last_realized_value",
"current_item",
"document",
"starting_node",
"node_test",
"is_error",
"include_descendants",
"index",
};

char *names1691 [] =
{
"error_value",
"last_realized_value",
"current_item",
"starting_node",
"node_test",
"is_error",
"include_self",
"index",
};

char *names1692 [] =
{
"error_value",
"last_realized_value",
"current_item",
"starting_node",
"base_iterator",
"is_error",
"index",
};

char *names1693 [] =
{
"starting_node",
"node_test",
"next_node",
"error_value",
"last_realized_value",
"current_item",
"is_error",
"index",
};

char *names1694 [] =
{
"error_value",
"last_realized_value",
"list",
"cursor",
"current_item",
"is_error",
"index",
"first_item",
"last_item",
};

char *names1695 [] =
{
"error_value",
"last_realized_value",
"current_item",
"is_error",
"index",
};

char *names1696 [] =
{
"error_value",
"last_realized_value",
"value",
"current_item",
"is_error",
"gone",
"index",
};

char *names1697 [] =
{
"error_value",
"last_realized_value",
"is_error",
"index",
};

char *names1698 [] =
{
"error_value",
"last_realized_value",
"internal_item",
"population",
"key_pattern",
"base_context",
"running_context",
"next_candidate",
"current_members",
"locator",
"is_error",
"index",
};

char *names1699 [] =
{
"error_value",
"last_realized_value",
"internal_item",
"population",
"key_pattern",
"base_context",
"running_context",
"next_candidate",
"current_members",
"locator",
"is_error",
"after_pending",
"after",
"index",
};

char *names1700 [] =
{
"error_value",
"last_realized_value",
"population",
"key_expression",
"base_context",
"running_context",
"comparer",
"stored_collator",
"current_members",
"next_item",
"current_key",
"next_key",
"is_error",
"after",
"index",
};

char *names1701 [] =
{
"error_value",
"last_realized_value",
"base_iterator",
"sort_keys",
"context",
"key_comparers",
"node_keys",
"group_iterator",
"is_error",
"count_determined",
"index",
"count",
};

char *names1702 [] =
{
"error_value",
"last_realized_value",
"population",
"key_expression",
"key_context",
"comparer",
"groups",
"group_keys",
"stored_collator",
"is_error",
"indexed_groups_built",
"index",
};

char *names1703 [] =
{
"default_namespaces",
"prefixes",
"element_prefixes",
"last_item",
};

char *names1704 [] =
{
"name",
"default_value",
"enumeration_list",
"type",
"value",
"is_list_type",
};

char *names1705 [] =
{
"context",
};

char *names1706 [] =
{
"type",
"subtype",
"parameters",
};

char *names1707 [] =
{
"full_reference",
"scheme",
"authority_item",
"path_items",
"path_base_item",
"query_item",
"query_items",
"fragment_item",
"user_info",
"host_port",
"query_item_name",
"has_absolute_path",
"start_query_part",
};

char *names1709 [] =
{
"namespace_uri",
"code",
"description",
"value",
"system_id",
"type",
"line_number",
};

char *names1710 [] =
{
"last_error",
"is_error",
};

char *names1712 [] =
{
"yytranslate",
"yyr1",
"yydefact",
"yydefgoto",
"yypact",
"yypgoto",
"yytable",
"yycheck",
"yytypes1",
"yytypes2",
"yyss",
"yy_lookahead_needed",
"yy_suspended_yystacksize",
"yy_suspended_yystate",
"yy_suspended_yyn",
"yy_suspended_yychar1",
"yy_suspended_index",
"yy_suspended_yyss_top",
"yy_suspended_yy_goto",
"yyssp",
"yyerrstatus",
"yy_parsing_status",
"error_count",
};

char *names1713 [] =
{
"last_detachable_any_value",
"last_string_value",
};

char *names1714 [] =
{
"input_buffer",
"yy_content",
"yy_content_area",
"yy_unicode_content_area",
"yy_pushed_start_conditions",
"yy_nxt",
"yy_chk",
"yy_base",
"yy_def",
"yy_ec",
"yy_meta",
"yy_accept",
"yy_acclist",
"yy_state_stack",
"last_detachable_any_value",
"last_string_value",
"input_stream",
"input_resolver",
"input_filter",
"last_error",
"input_name",
"last_value",
"character_entity",
"last_character",
"yy_more_flag",
"yy_rejected",
"last_unicode_character",
"last_token",
"yy_start_state",
"yy_end",
"yy_start",
"yy_line",
"yy_column",
"yy_position",
"yy_more_len",
"yy_last_accepting_state",
"yy_last_accepting_cpos",
"pushed_start_condition_count",
"position",
"column",
"line",
"yy_state_count",
"yy_full_match",
"yy_lp",
"yy_looking_for_trail_begin",
"yy_full_lp",
"yy_full_state",
};

char *names1715 [] =
{
"input_buffer",
"yy_content",
"yy_content_area",
"yy_unicode_content_area",
"yy_pushed_start_conditions",
"yy_nxt",
"yy_chk",
"yy_base",
"yy_def",
"yy_ec",
"yy_meta",
"yy_accept",
"yy_acclist",
"yy_state_stack",
"last_detachable_any_value",
"last_string_value",
"input_stream",
"input_resolver",
"input_filter",
"last_error",
"input_name",
"last_value",
"character_entity",
"last_character",
"yy_more_flag",
"yy_rejected",
"last_unicode_character",
"last_token",
"yy_start_state",
"yy_end",
"yy_start",
"yy_line",
"yy_column",
"yy_position",
"yy_more_len",
"yy_last_accepting_state",
"yy_last_accepting_cpos",
"pushed_start_condition_count",
"position",
"column",
"line",
"yy_state_count",
"yy_full_match",
"yy_lp",
"yy_looking_for_trail_begin",
"yy_full_lp",
"yy_full_state",
};

char *names1716 [] =
{
"input_buffer",
"yy_content",
"yy_content_area",
"yy_unicode_content_area",
"yy_pushed_start_conditions",
"yy_nxt",
"yy_chk",
"yy_base",
"yy_def",
"yy_ec",
"yy_meta",
"yy_accept",
"yy_acclist",
"yy_state_stack",
"last_detachable_any_value",
"last_string_value",
"input_stream",
"input_resolver",
"input_filter",
"last_error",
"input_name",
"last_value",
"character_entity",
"last_character",
"yy_more_flag",
"yy_rejected",
"decl_start_sent",
"decl_end_sent",
"last_unicode_character",
"last_token",
"yy_start_state",
"yy_end",
"yy_start",
"yy_line",
"yy_column",
"yy_position",
"yy_more_len",
"yy_last_accepting_state",
"yy_last_accepting_cpos",
"pushed_start_condition_count",
"position",
"column",
"line",
"yy_state_count",
"yy_full_match",
"yy_lp",
"yy_looking_for_trail_begin",
"yy_full_lp",
"yy_full_state",
};

char *names1717 [] =
{
"input_buffer",
"yy_content",
"yy_content_area",
"yy_unicode_content_area",
"yy_pushed_start_conditions",
"yy_nxt",
"yy_chk",
"yy_base",
"yy_def",
"yy_ec",
"yy_meta",
"yy_accept",
"yy_acclist",
"yy_state_stack",
"last_detachable_any_value",
"last_string_value",
"input_stream",
"input_resolver",
"input_filter",
"last_error",
"input_name",
"last_value",
"character_entity",
"resolver",
"literal_name",
"value",
"external_id",
"last_character",
"yy_more_flag",
"yy_rejected",
"in_use",
"last_unicode_character",
"last_token",
"yy_start_state",
"yy_end",
"yy_start",
"yy_line",
"yy_column",
"yy_position",
"yy_more_len",
"yy_last_accepting_state",
"yy_last_accepting_cpos",
"pushed_start_condition_count",
"position",
"column",
"line",
"yy_state_count",
"yy_full_match",
"yy_lp",
"yy_looking_for_trail_begin",
"yy_full_lp",
"yy_full_state",
};

char *names1718 [] =
{
"input_buffer",
"yy_content",
"yy_content_area",
"yy_unicode_content_area",
"yy_pushed_start_conditions",
"yy_nxt",
"yy_chk",
"yy_base",
"yy_def",
"yy_ec",
"yy_meta",
"yy_accept",
"yy_acclist",
"yy_state_stack",
"last_detachable_any_value",
"last_string_value",
"input_stream",
"input_resolver",
"input_filter",
"last_error",
"input_name",
"last_value",
"character_entity",
"resolver",
"literal_name",
"value",
"external_id",
"last_character",
"yy_more_flag",
"yy_rejected",
"in_use",
"pre_sent",
"post_sent",
"last_unicode_character",
"last_token",
"yy_start_state",
"yy_end",
"yy_start",
"yy_line",
"yy_column",
"yy_position",
"yy_more_len",
"yy_last_accepting_state",
"yy_last_accepting_cpos",
"pushed_start_condition_count",
"position",
"column",
"line",
"yy_state_count",
"yy_full_match",
"yy_lp",
"yy_looking_for_trail_begin",
"yy_full_lp",
"yy_full_state",
};

char *names1719 [] =
{
"callbacks",
"dtd_callbacks",
"dtd_resolver",
"entity_resolver",
"yytranslate",
"yyr1",
"yydefact",
"yydefgoto",
"yypact",
"yypgoto",
"yytable",
"yycheck",
"yytypes1",
"yytypes2",
"yyss",
"last_detachable_any_value",
"last_string_value",
"internal_last_error_description",
"error_positions",
"entities",
"pe_entities",
"scanner",
"scanners",
"yy_lookahead_needed",
"use_namespaces",
"in_external_dtd",
"string_mode",
"yy_suspended_yystacksize",
"yy_suspended_yystate",
"yy_suspended_yyn",
"yy_suspended_yychar1",
"yy_suspended_index",
"yy_suspended_yyss_top",
"yy_suspended_yy_goto",
"yyssp",
"yyerrstatus",
"yy_parsing_status",
"error_count",
"last_token",
};

char *names1720 [] =
{
"callbacks",
"dtd_callbacks",
"dtd_resolver",
"entity_resolver",
"yytranslate",
"yyr1",
"yydefact",
"yydefgoto",
"yypact",
"yypgoto",
"yytable",
"yycheck",
"yytypes1",
"yytypes2",
"yyss",
"last_detachable_any_value",
"last_string_value",
"internal_last_error_description",
"error_positions",
"entities",
"pe_entities",
"scanner",
"scanners",
"yyvs1",
"yyspecial_routines1",
"yyvs2",
"yyspecial_routines2",
"yyvs3",
"yyspecial_routines3",
"yyvs4",
"yyspecial_routines4",
"yyvs5",
"yyspecial_routines5",
"yyvs6",
"yyspecial_routines6",
"yyvs7",
"yyspecial_routines7",
"yyvs8",
"yyspecial_routines8",
"yyvs9",
"yyspecial_routines9",
"yyvs10",
"yyspecial_routines10",
"yyvs11",
"yyspecial_routines11",
"yy_lookahead_needed",
"use_namespaces",
"in_external_dtd",
"string_mode",
"yy_suspended_yystacksize",
"yy_suspended_yystate",
"yy_suspended_yyn",
"yy_suspended_yychar1",
"yy_suspended_index",
"yy_suspended_yyss_top",
"yy_suspended_yy_goto",
"yyssp",
"yyerrstatus",
"yy_parsing_status",
"error_count",
"last_token",
"yyvsc1",
"yyvsp1",
"yyvsc2",
"yyvsp2",
"yyvsc3",
"yyvsp3",
"yyvsc4",
"yyvsp4",
"yyvsc5",
"yyvsp5",
"yyvsc6",
"yyvsp6",
"yyvsc7",
"yyvsp7",
"yyvsc8",
"yyvsp8",
"yyvsc9",
"yyvsp9",
"yyvsc10",
"yyvsp10",
"yyvsc11",
"yyvsp11",
};

char *names1722 [] =
{
"utc_clock",
"local_clock",
"millisecond",
"second",
"minute",
"hour",
"day",
"month",
"year",
};

char *names1723 [] =
{
"utc_clock",
"local_clock",
"millisecond",
"second",
"minute",
"hour",
"day",
"month",
"year",
};

char *names1724 [] =
{
"normalizer",
"serializer",
"output_properties",
};

char *names1729 [] =
{
"document_uri",
"base_uri",
"is_open",
"is_document_started",
"is_written",
};

char *names1730 [] =
{
"document_uri",
"base_uri",
"current_root",
"last_error",
"locator",
"start_time",
"is_open",
"is_document_started",
"is_written",
"has_error",
"is_timing",
"is_line_numbering",
};

char *names1731 [] =
{
"document_uri",
"base_uri",
"is_open",
"is_document_started",
"is_written",
"previous_atomic",
};

char *names1732 [] =
{
"document_uri",
"base_uri",
"outputter",
"output_properties",
"serializer",
"is_open",
"is_document_started",
"is_written",
"is_error",
"is_no_declaration_on_close",
};

char *names1733 [] =
{
"document_uri",
"base_uri",
"outputter",
"output_properties",
"serializer",
"is_open",
"is_document_started",
"is_written",
"is_error",
"is_no_declaration_on_close",
};

char *names1734 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"is_open",
"is_document_started",
"is_written",
};

char *names1735 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"attributes",
"encoding",
"media_type",
"is_open",
"is_document_started",
"is_written",
"is_xhtml",
"is_seeking_head",
"found_head",
"in_meta_tag",
"matching_uri_code",
"meta_name_code",
"http_equiv_name_code",
"content_name_code",
"dropping_meta_tags_level",
"level",
};

char *names1736 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"character_map",
"is_open",
"is_document_started",
"is_written",
"are_null_characters_used",
};

char *names1737 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"buffered_attributes",
"namespace_count_stack",
"namespaces_stack",
"is_open",
"is_document_started",
"is_written",
"accepting_attributes",
"nesting_depth",
"element_name_code",
"element_type_code",
"element_properties",
"attribute_count",
"namespaces_stack_size",
"last_checked_namecode",
};

char *names1738 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"character_buffer",
"is_open",
"is_document_started",
"is_written",
};

char *names1739 [] =
{
"parsed_error_value",
"last_created_closure",
"internal_parsed_expression",
"document_uri",
"base_uri",
"base_receiver",
"locator",
"node_factory",
"configuration",
"start_tag_buffer",
"default_namespace_stack",
"is_parse_error",
"is_open",
"is_document_started",
"is_written",
"is_excluded_stylesheet_module",
"last_use_when_value",
"use_when_fingerprint",
"xpath_default_namespace_fingerprint",
"excluded_elements_nest_count",
};

char *names1740 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"namespaces_in_scope",
"count_stack",
"pending_undeclarations",
"disinherit_stack",
"is_open",
"is_document_started",
"is_written",
"stack_depth",
};

char *names1741 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"emitter",
"is_open",
"is_document_started",
"is_written",
"is_same_line",
"is_after_tag",
"is_allwhite",
"indent_spaces",
"line",
"column",
"level",
"suppressed_at_level",
"xml_space_code",
};

char *names1742 [] =
{
"normalizer",
"serializer",
"output_properties",
"document_uri",
"base_uri",
"base_receiver",
"emitter",
"output_encoder",
"element_fingerprints",
"cdata_names",
"character_buffer",
"is_open",
"is_document_started",
"is_written",
};

char *names1743 [] =
{
"normalizer",
"serializer",
"output_properties",
"document_uri",
"base_uri",
"base_receiver",
"is_open",
"is_document_started",
"is_written",
};

char *names1744 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"next_destination",
"transformer",
"builder",
"is_open",
"is_document_started",
"is_written",
};

char *names1745 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"property_stack",
"is_open",
"is_document_started",
"is_written",
"same_line",
"is_inline_tag",
"in_formatted_tag",
"is_after_inline",
"is_after_formatted",
"indent_spaces",
"level",
};

char *names1746 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"property_stack",
"is_open",
"is_document_started",
"is_written",
"same_line",
"is_inline_tag",
"in_formatted_tag",
"is_after_inline",
"is_after_formatted",
"indent_spaces",
"level",
};

char *names1748 [] =
{
"coefficient",
"is_negative",
"exponent",
"special",
};

char *names1749 [] =
{
"product_name",
"product_version",
"vendor_name",
"vendor_url",
"system_properties",
"cache_collection_resolver",
"initialized",
"is_tracing_suppressed",
};

char *names1750 [] =
{
"product_name",
"product_version",
"vendor_name",
"vendor_url",
"system_properties",
"cache_collection_resolver",
"trace_listener",
"error_reporter",
"entity_resolver",
"uri_resolver",
"output_resolver",
"encoder_factory",
"extension_functions",
"media_type_map",
"error_listener",
"message_emitter_factory",
"saved_base_uri",
"initialized",
"is_tracing_suppressed",
"is_line_numbering",
"is_tiny_tree_model",
"is_reporting_tiny_tree_statistics",
"is_timing",
"assume_html_is_xhtml",
"warns_on_default_action",
"default_action_suppressed",
"is_explaining",
"is_dtd_suppressed",
"string_mode",
"final_execution_phase",
"estimated_nodes",
"estimated_attributes",
"estimated_namespaces",
"estimated_characters",
};

char *names1752 [] =
{
"prefix_string",
"suffix_string",
"integral_part_positions",
"integral_grouping_separator_positions",
"fractional_part_positions",
"fractional_grouping_separator_positions",
"error_value",
"is_percent",
"is_per_mille",
"is_digit",
"is_error",
"maximum_integral_part_size",
"minimum_integral_part_size",
"maximum_fractional_part_size",
"minimum_fractional_part_size",
"phase",
};

char *names1754 [] =
{
"base_uri",
"group_base",
"system_id",
"element_name_stack",
"attribute_namespaces",
"attribute_local_parts",
"attribute_values",
"local_catalog_files",
"public_delegates",
"system_delegates",
"uri_delegates",
"system_rewrite_rules",
"uri_rewrite_rules",
"system_suffix_rules",
"uri_suffix_rules",
"public_entries",
"system_entries",
"uri_entries",
"prefer_public_entries",
"is_error",
"delegated",
"prefer_public",
"group_prefer_public",
"in_catalog",
"string_mode",
"ignoring_depth",
"group_depth",
};

char *names1755 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"normalizer",
"is_open",
"is_document_started",
"is_written",
"is_xhtml",
"current_element",
};

char *names1756 [] =
{
"bootstrap_resolver",
"system_catalog_files",
"pi_catalog_files",
"all_known_catalogs",
"prefer_public",
"search_chain_truncated",
"are_processing_instructions_allowed",
"are_catalogs_disabled",
"is_system_default_catalog_suppressed",
"debug_level",
};

char *names1757 [] =
{
"last_evaluated_document",
"last_evaluated_media_type",
};

char *names1758 [] =
{
"last_evaluated_document",
"last_evaluated_media_type",
"base_uri",
"stylesheet_base_uri",
"transformer",
"fragment_error_value",
"configuration",
"last_node_iterator",
};

char *names1759 [] =
{
"document_uri",
"base_uri",
"outputter",
"output_properties",
"serializer",
"element_qname_stack",
"raw_outputter",
"encoder_factory",
"encoding",
"name_lookup_table",
"is_open",
"is_document_started",
"is_written",
"is_error",
"is_no_declaration_on_close",
"is_well_formed_document_required",
"is_output_open",
"is_declaration_written",
"is_empty",
"is_open_start_tag",
"is_hex_preferred",
"allow_undeclare_prefixes",
"warning_issued",
"current_element_name_code",
"name_lookup_table_size",
};

char *names1760 [] =
{
"document_uri",
"base_uri",
"outputter",
"output_properties",
"serializer",
"element_qname_stack",
"raw_outputter",
"encoder_factory",
"encoding",
"name_lookup_table",
"is_open",
"is_document_started",
"is_written",
"is_error",
"is_no_declaration_on_close",
"is_well_formed_document_required",
"is_output_open",
"is_declaration_written",
"is_empty",
"is_open_start_tag",
"is_hex_preferred",
"allow_undeclare_prefixes",
"warning_issued",
"current_element_name_code",
"name_lookup_table_size",
};

char *names1761 [] =
{
"document_uri",
"base_uri",
"outputter",
"output_properties",
"serializer",
"element_qname_stack",
"raw_outputter",
"encoder_factory",
"encoding",
"name_lookup_table",
"media_type",
"element_name",
"is_open",
"is_document_started",
"is_written",
"is_error",
"is_no_declaration_on_close",
"is_well_formed_document_required",
"is_output_open",
"is_declaration_written",
"is_empty",
"is_open_start_tag",
"is_hex_preferred",
"allow_undeclare_prefixes",
"warning_issued",
"escape_uri_attributes",
"current_element_name_code",
"name_lookup_table_size",
"non_ascii_representation",
"excluded_representation",
"in_script",
"element_uri_code",
};

char *names1762 [] =
{
"document_uri",
"base_uri",
"outputter",
"output_properties",
"serializer",
"element_qname_stack",
"raw_outputter",
"encoder_factory",
"encoding",
"name_lookup_table",
"is_open",
"is_document_started",
"is_written",
"is_error",
"is_no_declaration_on_close",
"is_well_formed_document_required",
"is_output_open",
"is_declaration_written",
"is_empty",
"is_open_start_tag",
"is_hex_preferred",
"allow_undeclare_prefixes",
"warning_issued",
"current_element_name_code",
"name_lookup_table_size",
};

char *names1763 [] =
{
"name",
"items",
"type",
"repetition",
"is_character_data_allowed",
};

char *names1764 [] =
{
"configuration",
"created_transformer",
"last_error_message",
"stylesheet_cache",
"was_error",
"is_caching",
};

char *names1766 [] =
{
"current_iterator",
"current_receiver",
"internal_date_time",
"collation_map",
"is_restricted",
"is_temporary_destination",
"is_build_document_error",
"cached_last",
};

char *names1767 [] =
{
"current_iterator",
"current_receiver",
"internal_date_time",
"collation_map",
"uri_resolver",
"last_build_error",
"implicit_timezone",
"security_manager",
"last_parsed_media_type",
"last_parsed_document",
"available_documents",
"available_functions",
"local_variable_frame",
"configuration",
"is_restricted",
"is_temporary_destination",
"is_build_document_error",
"is_process_error",
"is_minor",
"has_push_processing",
"string_mode",
"cached_last",
};

char *names1768 [] =
{
"current_iterator",
"current_receiver",
"internal_date_time",
"collation_map",
"caller",
"transformer",
"static_context",
"tail_call_function",
"saved_receiver",
"internal_local_variable_frame",
"internal_local_parameters",
"internal_current_group_iterator",
"internal_current_mode",
"internal_current_template",
"internal_current_regexp_iterator",
"internal_tunnel_parameters",
"internal_implicit_timezone",
"last_build_error",
"last_parsed_media_type",
"last_parsed_document",
"configuration",
"is_restricted",
"is_temporary_destination",
"is_build_document_error",
"is_pattern",
"is_minor",
"cached_last",
};

char *names1769 [] =
{
"parameters",
};

char *names1770 [] =
{
"parameters",
};

char *names1771 [] =
{
"parameters",
};

char *names1772 [] =
{
"parameters",
};

char *names1773 [] =
{
"parameters",
};

char *names1774 [] =
{
"parameters",
};

char *names1775 [] =
{
"reason",
"flags",
"traps",
"is_extended",
"exception_on_trap",
"digits",
"rounding_mode",
"exponent_limit",
};

char *names1776 [] =
{
"primary_modifier",
"is_traditional",
"is_ordinal",
"minimum_width",
"maximum_width",
};

char *names1778 [] =
{
"components",
"sharename",
"hostname",
"drive",
"is_relative",
"count",
};

char *names1780 [] =
{
"executable",
"body",
"system_id",
"slot_manager",
"function_name",
"result_type",
"parameter_definitions",
"initialized",
"is_memo_function",
"is_tail_recursive",
"line_number",
"parameter_count",
"cached_evaluation_mode",
};

char *names1781 [] =
{
"use_character_maps",
"cdata_section_expanded_names",
"cdata_validation_error",
"method",
"encoding",
"cdata_section_elements",
"standalone",
"doctype_public",
"doctype_system",
"normalization_form",
"next_in_chain",
"next_in_chain_base_uri",
"used_character_maps",
"extension_attributes",
"error_message",
"duplicate_attribute_name",
"string_property_map",
"boolean_property_map",
"precedence_property_map",
"default_version",
"default_media_type",
"default_character_representation",
"omit_xml_declaration",
"include_content_type",
"undeclare_prefixes",
"escape_uri_attributes",
"byte_order_mark_required",
"is_error",
"is_duplication_error",
"is_encoding_set",
"is_byte_order_mark_set",
"is_escape_uri_attributes_set",
"is_include_content_type_set",
"is_omit_xml_declaration_set",
"is_standalone_set",
"is_undeclare_prefixes_set",
"default_indent",
"last_yes_no_value",
"any_compile_errors",
"indent_spaces",
};

char *names1783 [] =
{
"value",
"collation_key",
"is_nan",
"category",
};

char *names1784 [] =
{
"local_name",
"namespace_uri",
"base_type",
"is_built_in",
"fingerprint",
};

char *names1785 [] =
{
"last_type_error",
"is_comparison_type_error",
"last_check_result",
};

char *names1786 [] =
{
"content",
"name",
"node_type",
"properties",
};

char *names1787 [] =
{
"error_value",
"last_realized_value",
"current_item",
"parent_element",
"node_test",
"is_error",
"index",
"attribute_index",
};

char *names1788 [] =
{
"starting_node",
"node_test",
"next_node",
"error_value",
"last_realized_value",
"current_item",
"root",
"is_error",
"index",
};

char *names1789 [] =
{
"error_value",
"last_realized_value",
"current_item",
"document",
"starting_node",
"node_test",
"is_error",
"include_self",
"index",
"next_node_number",
"starting_depth",
};

char *names1790 [] =
{
"error_value",
"last_realized_value",
"current_item",
"document",
"node_test",
"is_error",
"index",
"parent_element",
"attribute_index",
};

char *names1791 [] =
{
"error_value",
"last_realized_value",
"current_item",
"internal_item",
"element",
"node_test",
"cursor",
"is_error",
"index",
"position",
};

char *names1792 [] =
{
"checked_expression",
"static_type_check_error",
"required_item_type",
"required_type",
"supplied_item_type",
"function_library",
"static_context",
"is_static_type_check_error",
"allows_many",
"cardinality_ok",
"item_type_ok",
"supplied_cardinality",
};

char *names1793 [] =
{
"components",
"error_value",
"avt",
"static_context",
"are_all_nodes_untyped",
};

char *names1795 [] =
{
"document_uri",
"base_uri",
"outputter",
"output_properties",
"serializer",
"element_qname_stack",
"raw_outputter",
"encoder_factory",
"encoding",
"name_lookup_table",
"is_open",
"is_document_started",
"is_written",
"is_error",
"is_no_declaration_on_close",
"is_well_formed_document_required",
"is_output_open",
"is_declaration_written",
"is_empty",
"is_open_start_tag",
"is_hex_preferred",
"allow_undeclare_prefixes",
"warning_issued",
"current_element_name_code",
"name_lookup_table_size",
};

char *names1796 [] =
{
"document_uri",
"base_uri",
"encoder",
"output_properties",
"serializer",
"emitter_factory",
"base_receiver",
"base_emitter",
"outputter",
"character_map_index",
"pending_event_list",
"is_open",
"is_document_started",
"is_written",
"is_error",
"is_no_declaration_on_close",
"committed",
};

char *names1797 [] =
{
"local_name",
"namespace_uri",
"base_type",
"is_built_in",
"fingerprint",
};

char *names1798 [] =
{
"required_type",
"references",
"variable_name",
"variable_fingerprint",
};

char *names1799 [] =
{
"last_matched_rule",
"rule_dictionary",
"most_recent_rule",
"internal_name",
"is_stripper",
};

char *names1800 [] =
{
"configuration",
"known_collations",
"internal_last_bound_variable",
"namespaces",
"variables",
"default_collation_name",
"system_id",
"base_uri",
"available_functions",
"basic_xslt_processor",
"basic_xquery_processor",
"xquery_processor",
"schema_aware_processor",
"customized_host_language",
"is_full_type_scheme",
"is_restricted",
"warnings_to_std_error",
"is_backwards_compatible_mode",
"bound_variables_count",
"line_number",
};

char *names1801 [] =
{
"primary_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
};

char *names1802 [] =
{
"character_buffer",
"comment_buffer",
"entity_table",
"document_list",
"root_indices",
"system_id_map",
"line_number_map",
"element_type_map",
"node_kinds",
"depth",
"next_sibling_indices",
"alpha",
"beta",
"name_codes",
"attribute_parents",
"attribute_codes",
"attribute_values",
"attribute_type_codes",
"prior_nodes_index",
"namespace_parents",
"namespace_codes",
"are_namespaces_used",
"number_of_nodes",
"number_of_attributes",
"number_of_namespaces",
"last_node_added",
"document_number",
"estimated_node_count",
"estimated_attribute_count",
"estimated_namespace_count",
"estimated_character_count",
"root_index",
};

char *names1803 [] =
{
"next",
"receiver",
"current_element_name",
"attribute_types",
"before_dtd",
};

char *names1804 [] =
{
"last_binding_failure",
"global_parameters",
"global_variables",
"busy_globals",
"is_circularity_error",
"global_variable_count",
};

char *names1805 [] =
{
"configuration",
"known_collations",
"internal_last_bound_variable",
"style_element",
"internal_default_function_namespace_uri",
"cached_function_manager",
"default_collation_name",
"base_uri",
"is_restricted",
"bound_variables_count",
};

char *names1806 [] =
{
"document_uri",
"base_uri",
"current_root",
"last_error",
"locator",
"start_time",
"tree_document",
"last_xpath_error",
"node_factory",
"current_composite_node",
"saved_current_composite_node",
"pending_namespaces",
"pending_attributes",
"is_open",
"is_document_started",
"is_written",
"has_error",
"is_timing",
"is_line_numbering",
"current_depth",
"next_node_number",
"pending_element_name_code",
};

char *names1807 [] =
{
"document_uri",
"base_uri",
"current_root",
"last_error",
"locator",
"start_time",
"tree",
"tiny_document",
"previously_at_depth",
"is_open",
"is_document_started",
"is_written",
"has_error",
"is_timing",
"is_line_numbering",
"is_reporting_sizes",
"defaults_overridden",
"estimated_node_count",
"estimated_attribute_count",
"estimated_namespace_count",
"estimated_character_count",
"current_depth",
"node_number",
};

char *names1808 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"transformer",
"strip_stack",
"stripper_mode",
"orphan",
"context",
"is_open",
"is_document_started",
"is_written",
"strip_all",
"preserve_all",
"found_space_preserving_mode",
};

char *names1809 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"transformer",
"strip_stack",
"stripper_mode",
"orphan",
"context",
"specials",
"is_open",
"is_document_started",
"is_written",
"strip_all",
"preserve_all",
"found_space_preserving_mode",
"xsl_text_fingerprint",
};

char *names1811 [] =
{
"last_collection",
"protection_code",
"type_code",
"size_code",
"inode_code",
"user_code",
"group_code",
"date_code",
"access_date_code",
"change_date_code",
"device_code",
"device_type_code",
"links_code",
"owner_name_code",
"group_name_code",
};

char *names1812 [] =
{
"scheme",
"last_collection",
"last_error",
"protection_code",
"type_code",
"size_code",
"inode_code",
"user_code",
"group_code",
"date_code",
"access_date_code",
"change_date_code",
"device_code",
"device_type_code",
"links_code",
"owner_name_code",
"group_name_code",
};

char *names1813 [] =
{
"scheme",
"last_collection",
"last_error",
"protection_code",
"type_code",
"size_code",
"inode_code",
"user_code",
"group_code",
"date_code",
"access_date_code",
"change_date_code",
"device_code",
"device_type_code",
"links_code",
"owner_name_code",
"group_name_code",
};

char *names1814 [] =
{
"filter",
"filter_context",
"base_iterator",
"is_singleton_boolean_filter",
"non_numeric",
"last_match_test",
};

char *names1815 [] =
{
"error_value",
"last_realized_value",
"filter",
"filter_context",
"base_iterator",
"current_item",
"is_error",
"is_singleton_boolean_filter",
"non_numeric",
"last_match_test",
"index",
};

char *names1816 [] =
{
"error_value",
"last_realized_value",
"filter",
"filter_context",
"base_iterator",
"current_item",
"is_error",
"is_singleton_boolean_filter",
"non_numeric",
"last_match_test",
"index",
};

char *names1820 [] =
{
"error_value",
"is_error",
};

char *names1821 [] =
{
"system_id",
"error_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
};

char *names1822 [] =
{
"system_id",
"error_value",
"id_expression",
"static_context",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
};

char *names1823 [] =
{
"system_id",
"error_value",
"key_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
"key_fingerprint",
};

char *names1824 [] =
{
"system_id",
"error_value",
"left_hand_side",
"right_hand_side",
"static_context",
"original_text",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
"node_type",
};

char *names1825 [] =
{
"original_text",
};

char *names1826 [] =
{
"original_text",
};

char *names1827 [] =
{
"original_text",
};

char *names1828 [] =
{
"original_text",
"local_name",
"node_kind",
};

char *names1829 [] =
{
"original_text",
"node_test_one",
"node_test_two",
"operator",
};

char *names1830 [] =
{
"original_text",
"content_type",
"is_nillable",
"node_kind",
};

char *names1831 [] =
{
"original_text",
"uri_code",
"node_kind",
};

char *names1832 [] =
{
"original_text",
"node_kind",
"fingerprint",
};

char *names1833 [] =
{
"original_text",
"node_kind",
};

char *names1834 [] =
{
"system_id",
"error_value",
"original_text",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
};

char *names1835 [] =
{
"system_id",
"error_value",
"original_text",
"content_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"is_nillable",
"line_number",
"node_kind",
};

char *names1836 [] =
{
"system_id",
"error_value",
"original_text",
"node_test_one",
"node_test_two",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
"operator",
};

char *names1837 [] =
{
"system_id",
"error_value",
"original_text",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
"uri_code",
"node_kind",
};

char *names1838 [] =
{
"system_id",
"error_value",
"original_text",
"local_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
"node_kind",
};

char *names1839 [] =
{
"system_id",
"error_value",
"original_text",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
};

char *names1840 [] =
{
"system_id",
"error_value",
"original_text",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
};

char *names1841 [] =
{
"system_id",
"error_value",
"original_text",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
};

char *names1842 [] =
{
"system_id",
"error_value",
"original_text",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
"node_kind",
"fingerprint",
};

char *names1843 [] =
{
"system_id",
"error_value",
"original_text",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
"node_kind",
};

char *names1845 [] =
{
"document_uri",
"base_uri",
"base_receiver",
"is_open",
"is_document_started",
"is_written",
"previous_atomic",
};

char *names1846 [] =
{
"document_uri",
"base_uri",
"transformer",
"last_popped_item",
"output_list",
"tree",
"builder",
"cached_sequence",
"is_open",
"is_document_started",
"is_written",
"previous_atomic",
"in_start_tag",
"level",
};

char *names1847 [] =
{
"document_uri",
"base_uri",
"next_receiver",
"is_element_in_null_namespace",
"pending_attributes_name_codes",
"pending_attributes_type_codes",
"pending_attributes_values",
"pending_attributes_properties",
"pending_namespaces",
"is_open",
"is_document_started",
"is_written",
"previous_atomic",
"suppress_attributes",
"is_top_level",
"pending_start_tag",
"start_element_properties",
"pending_attributes_lists_size",
"pending_namespaces_list_size",
"current_simple_type",
"last_checked_namecode",
};

char *names1848 [] =
{
"original_text",
"element_test",
};

char *names1849 [] =
{
"system_id",
"error_value",
"original_text",
"element_test",
"default_priority",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"line_number",
};

char *names1851 [] =
{
"mapping_table",
};

char *names1852 [] =
{
"components",
"value",
"evaluated",
"is_shorthand",
"is_error",
"were_resources_found",
};

char *names1853 [] =
{
"generated_id",
"error_value",
"is_error",
"node_type",
};

char *names1854 [] =
{
"generated_id",
"error_value",
"parent",
"system_id",
"string_value",
"document",
"is_error",
"is_possible_child",
"node_type",
"name_code",
"document_number",
};

char *names1855 [] =
{
"generated_id",
"error_value",
"parent",
"system_id",
"string_value",
"is_error",
"node_type",
"name_code",
"document_number",
};

char *names1856 [] =
{
"generated_id",
"error_value",
"element",
"is_error",
"node_type",
"namespace_code",
"position",
"name_code",
};

char *names1857 [] =
{
"generated_id",
"error_value",
"is_error",
"node_type",
};

char *names1858 [] =
{
"generated_id",
"error_value",
"is_error",
"node_type",
};

char *names1859 [] =
{
"generated_id",
"error_value",
"is_error",
"node_type",
};

char *names1860 [] =
{
"generated_id",
"error_value",
"is_error",
"node_type",
};

char *names1861 [] =
{
"generated_id",
"error_value",
"is_error",
"node_type",
};

char *names1862 [] =
{
"generated_id",
"error_value",
"is_error",
"node_type",
};

char *names1863 [] =
{
"generated_id",
"error_value",
"is_error",
"node_type",
"document_number",
};

char *names1864 [] =
{
"generated_id",
"error_value",
"text",
"cached_text_node",
"system_id",
"base_uri",
"is_error",
"node_type",
"document_number",
"line_number",
};

char *names1865 [] =
{
"last_key_sequence",
"key_map",
"collation_map",
"document_map",
"last_built_index",
};

char *names1866 [] =
{
"tokenizer",
"first_parse_error_code",
"environment",
"function_library",
"internal_last_parse_error",
"internal_last_parsed_expression",
"internal_last_parsed_sequence",
"internal_last_parsed_node_test",
"internal_last_parsed_node_kind",
"range_variable_stack",
"is_pattern_parser",
"is_parse_error",
"first_parse_error_line_number",
"last_generated_name_code",
};

char *names1867 [] =
{
"tokenizer",
"first_parse_error_code",
"environment",
"function_library",
"internal_last_parse_error",
"internal_last_parsed_expression",
"internal_last_parsed_sequence",
"internal_last_parsed_node_test",
"internal_last_parsed_node_kind",
"range_variable_stack",
"internal_last_parsed_pattern",
"last_parsed_pattern_step",
"is_pattern_parser",
"is_parse_error",
"first_parse_error_line_number",
"last_generated_name_code",
};

char *names1868 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1869 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"pattern",
"container",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1870 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1871 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"node",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1872 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1873 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
"minimum",
"maximum",
};

char *names1874 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1875 [] =
{
"equality_tester",
"storage",
"special_routines",
"internal_cursor",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"cached_item_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"capacity",
"count",
"last_slot_number",
};

char *names1876 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"base_expression",
"saved_xpath_context",
"input_iterator",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
"depth",
};

char *names1877 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"base_expression",
"saved_xpath_context",
"input_iterator",
"reservoir",
"node_reservoir",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_node_sequence",
"last_slot_number",
"depth",
"state",
};

char *names1878 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1879 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
"name_code",
};

char *names1880 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"binary_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1881 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"binary_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1882 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1883 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"value",
"last_slot_number",
};

char *names1884 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"value",
"double_value",
"last_decimal",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_untyped_atomic",
"last_slot_number",
};

char *names1885 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"value",
"double_value",
"last_decimal",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_untyped_atomic",
"last_slot_number",
};

char *names1886 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"duration",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1887 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"duration",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1888 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"duration",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1889 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"zoned",
"last_slot_number",
};

char *names1890 [] =
{
"zoned_date_time",
"local_date_time",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"cached_utc_date_time",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"zoned",
"last_slot_number",
};

char *names1891 [] =
{
"zoned_time",
"local_time",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"cached_utc_time",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"zoned",
"last_slot_number",
};

char *names1892 [] =
{
"zoned_date",
"local_date",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"cached_utc_date",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"zoned",
"last_slot_number",
};

char *names1893 [] =
{
"zoned_date",
"local_date",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"cached_utc_date",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"zoned",
"last_slot_number",
};

char *names1894 [] =
{
"zoned_date",
"local_date",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"cached_utc_date",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"zoned",
"last_slot_number",
};

char *names1895 [] =
{
"zoned_date",
"local_date",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"cached_utc_date",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"zoned",
"last_slot_number",
};

char *names1896 [] =
{
"zoned_date",
"local_date",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"cached_utc_date",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"zoned",
"last_slot_number",
};

char *names1897 [] =
{
"zoned_date",
"local_date",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"cached_utc_date",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"zoned",
"last_slot_number",
};

char *names1898 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1899 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1900 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
};

char *names1901 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"internal_is_nan",
"is_negative_zero",
"last_slot_number",
"value",
};

char *names1902 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"internal_is_nan",
"is_negative_zero",
"last_slot_number",
"value",
};

char *names1903 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"last_reduced_value",
"converted_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"last_slot_number",
"value",
};

char *names1904 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names1905 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"value",
"minimum_bound",
"maximum_bound",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names1906 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"select_expression",
"sort_key_list",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names1907 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"slot_number",
};

char *names1908 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"select_expression",
"separator_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_singleton",
"last_slot_number",
"location_identifier",
};

char *names1909 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"source",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names1910 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"condition",
"else_expression",
"then_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names1911 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"item_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_current_replacement",
"last_slot_number",
"location_identifier",
};

char *names1912 [] =
{
"last_mapped_sequence",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"start",
"step",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_hybrid",
"last_slot_number",
"location_identifier",
};

char *names1913 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"filter",
"base_expression",
"start_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"filter_is_positional",
"is_singleton_boolean_filter",
"last_slot_number",
"location_identifier",
};

char *names1914 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"node_test",
"known_item_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"axis",
};

char *names1915 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"binding",
"last_evaluated_binding",
"display_name",
"static_type",
"constant_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names1916 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"condition",
"last_slot_number",
"location_identifier",
};

char *names1917 [] =
{
"last_mapped_item",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"start",
"step",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"analysis_state",
};

char *names1918 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"start",
};

char *names1919 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"minimum_position",
"maximum_position",
};

char *names1920 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"instruction_name",
"error",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names1921 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"children",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names1922 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names1923 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names1924 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names1925 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
};

char *names1926 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"function",
"static_type",
"argument_evaluation_modes",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_tail_callable",
"is_type_error",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
};

char *names1927 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1928 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1929 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1930 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1931 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1932 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1933 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1934 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1935 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1936 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1937 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1938 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1939 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1940 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1941 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1942 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1943 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1944 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1945 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1946 [] =
{
"regexp_cache_entry",
"regexp_error_value",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_empty_match_ok",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1947 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1948 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1949 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1950 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1951 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1952 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1953 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1954 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1955 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1956 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1957 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1958 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1959 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"base_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1960 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1961 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1962 [] =
{
"regexp_cache_entry",
"regexp_error_value",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"regexp",
"replacement_string",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_empty_match_ok",
"initialized",
"any_captures",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1963 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1964 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1965 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1966 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1967 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1968 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1969 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1970 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1971 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1972 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1973 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1974 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1975 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1976 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1977 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1978 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1979 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1980 [] =
{
"regexp_cache_entry",
"regexp_error_value",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"regexp",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_empty_match_ok",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1981 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1982 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1983 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1984 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1985 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1986 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1987 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1988 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1989 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1990 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1991 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_singleton_id",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1992 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1993 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1994 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1995 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1996 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1997 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1998 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names1999 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"reserved_character_set",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2000 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2001 [] =
{
"last_evaluated_document",
"last_evaluated_media_type",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"base_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2002 [] =
{
"last_evaluated_document",
"last_evaluated_media_type",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"base_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2003 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2004 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2005 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2006 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2007 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2008 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2009 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2010 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"base_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2011 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2012 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"base_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2013 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"base_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2014 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2015 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2016 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"namespace_resolver",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2017 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"namespace_context",
"product_name",
"product_version",
"vendor_name",
"vendor_url",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2018 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2019 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"namespace_context",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"arguments_checked",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
"key_fingerprint",
};

char *names2020 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2021 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"namespace_context",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"namespaces_needed",
"checked",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2022 [] =
{
"primary_modifier",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_traditional",
"is_ordinal",
"initialized",
"minimum_width",
"maximum_width",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2023 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"node_factory",
"namespace_context",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"checked",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2024 [] =
{
"last_evaluated_document",
"last_evaluated_media_type",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"stylesheet_base_uri",
"transformer",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2025 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2026 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2027 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2028 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_test_for_zero",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2029 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2030 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2031 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2032 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2033 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_test_for_zero",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2034 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2035 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2036 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"namespace_resolver",
"decimal_format",
"picture",
"sub_pictures",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"are_arguments_checked",
"is_fixup_required",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2037 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"static_context",
"last_error",
"transformer",
"initial_context",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2038 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2039 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2040 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2041 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2042 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2043 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2044 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2045 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2046 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2047 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_test_for_zero",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2048 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_test_for_zero",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2049 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2050 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2051 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2052 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2053 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2054 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_test_for_zero",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2055 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
};

char *names2056 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"local_comparer",
"atomic_value",
"second_atomic_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_max",
"already_finished",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
"primitive_type",
"second_primitive_type",
};

char *names2057 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"local_comparer",
"atomic_value",
"second_atomic_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_max",
"already_finished",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
"primitive_type",
"second_primitive_type",
};

char *names2058 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"arguments",
"argument_error_code",
"name",
"namespace_uri",
"default_collation_name",
"local_comparer",
"atomic_value",
"second_atomic_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_max",
"already_finished",
"last_slot_number",
"location_identifier",
"fingerprint",
"augmented_argument_count",
"minimum_argument_count",
"maximum_argument_count",
"primitive_type",
"second_primitive_type",
};

char *names2059 [] =
{
"variable_name",
"last_evaluated_binding",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"sequence",
"action",
"declaration",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"simplified",
"last_slot_number",
"location_identifier",
"operator",
"slot_number",
};

char *names2060 [] =
{
"variable_name",
"last_evaluated_binding",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"sequence",
"action",
"declaration",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"simplified",
"last_slot_number",
"location_identifier",
"operator",
"slot_number",
};

char *names2061 [] =
{
"variable_name",
"last_evaluated_binding",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"sequence",
"action",
"declaration",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"simplified",
"last_slot_number",
"location_identifier",
"operator",
"slot_number",
};

char *names2062 [] =
{
"variable_name",
"last_evaluated_binding",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"sequence",
"action",
"declaration",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"simplified",
"last_slot_number",
"location_identifier",
"operator",
"slot_number",
"reference_count",
"evaluation_mode",
};

char *names2063 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2064 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2065 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"atomic_comparer",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2066 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2067 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"generate_id_emulation_mode",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2068 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"function_library",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"operator",
"not_function_fingerprint",
};

char *names2069 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"atomic_comparer",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_check_result",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2070 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"atomic_comparer",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"operator",
"singleton_operator",
};

char *names2071 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"atomic_comparer",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"atomize_first_operand",
"atomize_second_operand",
"maybe_first_operand_boolean",
"maybe_second_operand_boolean",
"last_slot_number",
"location_identifier",
"operator",
"singleton_operator",
};

char *names2072 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2073 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2074 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_backwards_compatible_mode",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2075 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_backwards_compatible_mode",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2076 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_backwards_compatible_mode",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2077 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_backwards_compatible_mode",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2078 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_backwards_compatible_mode",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2079 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_backwards_compatible_mode",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2080 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"first_operand",
"second_operand",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_backwards_compatible_mode",
"last_slot_number",
"location_identifier",
"operator",
};

char *names2081 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2082 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"error_code",
"target_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2083 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"required_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2084 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2085 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"target_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2086 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"target_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_empty_allowed",
"last_slot_number",
"location_identifier",
};

char *names2087 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2088 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"comparer",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2089 [] =
{
"last_mapped_item",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"required_type",
};

char *names2090 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"target_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_empty_allowed",
"last_slot_number",
"location_identifier",
};

char *names2091 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"containing_function",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2092 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_always_untyped",
"last_slot_number",
"location_identifier",
};

char *names2093 [] =
{
"last_mapped_item",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"required_item_type",
"role_locator",
"error_code",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2094 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"role",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_always_untyped",
"allows_empty",
"last_slot_number",
"location_identifier",
};

char *names2095 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2096 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"base_expression",
"role_locator",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"required_cardinality",
};

char *names2097 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2098 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"terminate",
"select_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2099 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"global_property_set",
"local_property_set",
"href",
"base_uri",
"http_method",
"schema_type",
"formatting_attributes",
"namespace_resolver",
"content",
"format",
"computed_property_set",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"validation_action",
};

char *names2100 [] =
{
"last_mapped_item",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"default_collation_name",
"select_expression",
"action",
"key_expression",
"sort_keys",
"collation_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"algorithm",
};

char *names2101 [] =
{
"last_mapped_item",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"action",
"select_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2102 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"content",
"constant_text",
"base_uri",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_text_only",
"last_slot_number",
"location_identifier",
};

char *names2103 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"base_uri",
"select_expression",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"copy_namespaces",
"last_slot_number",
"location_identifier",
};

char *names2104 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"conditions",
"actions",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2105 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"target",
"actual_parameter_list",
"tunnel_parameter_list",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"use_tail_recursion",
"last_slot_number",
"location_identifier",
};

char *names2106 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"regex_expression",
"flags_expression",
"regexp_cache_entry",
"matching_block",
"non_matching_block",
"context_item_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2107 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"attribute_sets",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2108 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"children",
"executable",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2109 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"child",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2110 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"child",
"trace_details",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2111 [] =
{
"variable_name",
"last_evaluated_binding",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"required_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_required_parameter",
"is_implicitly_required_parameter",
"is_tunnel_parameter",
"last_slot_number",
"location_identifier",
"variable_fingerprint",
"slot_number",
};

char *names2112 [] =
{
"variable_name",
"last_evaluated_binding",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"required_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_required_parameter",
"is_implicitly_required_parameter",
"is_tunnel_parameter",
"last_slot_number",
"location_identifier",
"variable_fingerprint",
"slot_number",
};

char *names2113 [] =
{
"variable_name",
"last_evaluated_binding",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"required_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_required_parameter",
"is_implicitly_required_parameter",
"is_tunnel_parameter",
"last_slot_number",
"location_identifier",
"variable_fingerprint",
"slot_number",
};

char *names2114 [] =
{
"variable_name",
"last_evaluated_binding",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"required_type",
"slot_manager",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_required_parameter",
"is_implicitly_required_parameter",
"is_tunnel_parameter",
"last_slot_number",
"location_identifier",
"variable_fingerprint",
"slot_number",
};

char *names2115 [] =
{
"variable_name",
"last_evaluated_binding",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"required_type",
"slot_manager",
"static_context",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_required_parameter",
"is_implicitly_required_parameter",
"is_tunnel_parameter",
"last_slot_number",
"location_identifier",
"variable_fingerprint",
"slot_number",
};

char *names2116 [] =
{
"variable_name",
"last_evaluated_binding",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"required_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_required_parameter",
"is_implicitly_required_parameter",
"is_tunnel_parameter",
"last_slot_number",
"location_identifier",
"variable_fingerprint",
"slot_number",
};

char *names2117 [] =
{
"variable_name",
"last_evaluated_binding",
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"required_type",
"conversion",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_required_parameter",
"is_implicitly_required_parameter",
"is_tunnel_parameter",
"last_slot_number",
"location_identifier",
"variable_fingerprint",
"slot_number",
};

char *names2118 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"base_uri",
"type",
"attribute_sets",
"content",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_inherit_namespaces",
"last_slot_number",
"location_identifier",
"validation_action",
};

char *names2119 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"base_uri",
"type",
"attribute_sets",
"content",
"element_name",
"namespace",
"namespace_context",
"internal_item_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_inherit_namespaces",
"last_slot_number",
"location_identifier",
"validation_action",
};

char *names2120 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"base_uri",
"type",
"attribute_sets",
"content",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_inherit_namespaces",
"is_copy_namespaces",
"last_slot_number",
"location_identifier",
"validation_action",
};

char *names2121 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"base_uri",
"type",
"attribute_sets",
"content",
"namespace_code_list",
"internal_item_type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_inherit_namespaces",
"last_slot_number",
"location_identifier",
"validation_action",
"fixed_name_code",
};

char *names2122 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"last_string_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"last_name_code",
};

char *names2123 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"last_string_value",
"name",
"evaluated_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"last_name_code",
};

char *names2124 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"last_string_value",
"name",
"last_evaluated_prefix",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"last_name_code",
};

char *names2125 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"last_string_value",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"last_name_code",
};

char *names2126 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"last_string_value",
"attribute_name",
"namespace",
"type",
"namespace_context",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"last_name_code",
"validation_action",
"type_annotation",
"options",
};

char *names2127 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"last_string_value",
"type",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"last_name_code",
"name_code",
"validation_action",
"type_annotation",
"options",
};

char *names2128 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"last_string_value",
"instruction_name",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
"last_name_code",
"receiver_options",
};

char *names2130 [] =
{
"selected_nodes",
"mode",
"actual_parameters",
"tunnel_parameters",
"execution_context",
};

char *names2131 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"actual_parameters",
"tunnel_parameters",
"mode",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_select_defaulted",
"is_current_mode_used",
"is_tail_recursion_used",
"last_slot_number",
"location_identifier",
};

char *names2132 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"actual_parameters",
"tunnel_parameters",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2133 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"actual_parameters",
"tunnel_parameters",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"last_slot_number",
"location_identifier",
};

char *names2134 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"is_error",
"node_type",
"child_index",
};

char *names2135 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"string_value",
"is_error",
"node_type",
"child_index",
"name_code",
};

char *names2136 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"string_value",
"system_id",
"is_error",
"node_type",
"child_index",
"name_code",
"line_number",
};

char *names2137 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"string_value",
"is_error",
"node_type",
"child_index",
};

char *names2138 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"string_value",
"is_error",
"node_type",
"child_index",
};

char *names2139 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"is_error",
"node_type",
"child_index",
"sequence_number_high_word",
};

char *names2140 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"element_list",
"entity_table",
"cached_id_table",
"cached_attribute_idref_table",
"system_id_map",
"line_number_map",
"closing_line_number_map",
"document_uri",
"document_element",
"base_uri",
"is_error",
"node_type",
"document_number",
"child_index",
"sequence_number_high_word",
};

char *names2141 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"is_error",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
};

char *names2142 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"is_error",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
};

char *names2143 [] =
{
"generated_id",
"error_value",
"tree",
"cached_parent_node",
"is_error",
"node_type",
"node_number",
};

char *names2144 [] =
{
"generated_id",
"error_value",
"tree",
"cached_parent_node",
"is_error",
"node_type",
"node_number",
};

char *names2145 [] =
{
"generated_id",
"error_value",
"tree",
"cached_parent_node",
"is_error",
"node_type",
"node_number",
};

char *names2146 [] =
{
"generated_id",
"error_value",
"tree",
"cached_parent_node",
"is_error",
"node_type",
"node_number",
};

char *names2147 [] =
{
"generated_id",
"error_value",
"tree",
"cached_parent_node",
"is_error",
"node_type",
"node_number",
};

char *names2148 [] =
{
"generated_id",
"error_value",
"tree",
"cached_parent_node",
"is_error",
"node_type",
"node_number",
};

char *names2149 [] =
{
"generated_id",
"error_value",
"tree",
"cached_parent_node",
"is_error",
"node_type",
"node_number",
};

char *names2150 [] =
{
"system_id",
"error_value",
"parent_pattern",
"ancestor_pattern",
"filters",
"equivalent_expression",
"original_node_test",
"refined_node_test",
"variable_binding",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"is_error",
"internal_last_match_result",
"is_constructed",
"is_first_element_pattern",
"is_last_element_pattern",
"is_special_filter",
"line_number",
};

char *names2151 [] =
{
"generated_id",
"error_value",
"tree",
"cached_parent_node",
"id_table",
"element_list",
"entity_table",
"attribute_idref_table",
"document_uri",
"base_uri",
"is_error",
"node_type",
"document_number",
"node_number",
};

char *names2152 [] =
{
"last_error",
"executable",
"configuration",
"transformer_factory",
"timer",
"current_date_time",
"bindery",
"initial_template",
"output_resolver",
"principal_result",
"principal_result_uri",
"principal_receiver",
"rule_manager",
"decimal_format_manager",
"trace_listener",
"implicit_timezone",
"last_context_node",
"parser_factory",
"principal_source_document",
"initial_context",
"initial_context_expression",
"parameters",
"user_data_table",
"xpath_parameters",
"next_resolved_destination",
"last_unparsed_text_uri",
"last_unparsed_text",
"last_unparsed_encoding",
"cached_static_context",
"remembered_numbers",
"response_streams",
"error_listener",
"document_pool",
"is_error",
"recovery_policy",
"initial_mode",
"temporary_destination_depth",
};

char *names2153 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2154 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"isolation_level_attribute_value",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"parsed_isolation_level",
};

char *names2155 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"collation_name",
"collator",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2156 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"condition",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2157 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2158 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2159 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"terminate",
"select_expression",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2160 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2161 [] =
{
"use_character_maps",
"cdata_section_expanded_names",
"cdata_validation_error",
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"http_method",
"href",
"format_expression",
"formatting_attributes",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"output_fingerprint",
"validation_action",
};

char *names2162 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"elements",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2163 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2164 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"replacement_string",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"code",
};

char *names2165 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"condition",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2166 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"value_expression",
"count_pattern",
"from_pattern",
"format",
"grouping_size",
"grouping_separator",
"language",
"letter_value",
"ordinal",
"formatter",
"numberer",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"has_variables_in_patterns",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"level",
};

char *names2167 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2168 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"collation_name",
"group_by",
"group_adjacent",
"group_starting_with",
"group_ending_with",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2169 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2170 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"element_name",
"namespace",
"use_attribute_sets",
"qname_prefix",
"local_name",
"qname",
"namespace_uri",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"is_inherit_namespaces",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"validation_action",
};

char *names2171 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2172 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"copy_namespaces",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2173 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"use",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"is_copy_namespaces",
"is_inherit_namespaces",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"validation",
};

char *names2174 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"otherwise",
"top_stylesheet",
"compiled_conditions",
"compiled_actions",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"has_compile_loop_finished",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"number_of_whens",
"compiled_actions_count",
};

char *names2175 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"template",
"called_template_name",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"use_tail_recursion",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"called_template_fingerprint",
};

char *names2176 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"regex_expression",
"flags_expression",
"regexp_cache_entry",
"matching_substring",
"non_matching_substring",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2177 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2178 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"mode",
"select_expression",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"use_current_mode",
"use_tail_recursion",
"is_select_defaulted",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"mode_name_code",
};

char *names2179 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2180 [] =
{
"use_character_maps",
"cdata_section_expanded_names",
"cdata_validation_error",
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"method",
"output_version",
"encoding",
"omit_xml_declaration",
"standalone",
"doctype_public",
"doctype_system",
"cdata_section_elements",
"indent",
"include_content_type",
"media_type",
"escape_uri_attributes",
"undeclare_prefixes",
"normalization_form",
"character_representation",
"indent_spaces",
"next_in_chain",
"byte_order_mark",
"extension_attributes",
"method_qname_parser",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"is_chain",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"output_fingerprint",
};

char *names2181 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"name",
"decimal_separator",
"grouping_separator",
"infinity",
"minus_sign",
"nan",
"percent",
"per_mille",
"zero_digit",
"digit",
"pattern_separator",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2182 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2183 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2184 [] =
{
"slot_manager",
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"key_name",
"match",
"use",
"collation_uri",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"key_fingerprint",
};

char *names2185 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"sort_key_definition",
"stable_attribute_value",
"select_expression",
"order",
"case_order",
"data_type",
"language",
"collation_name",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2186 [] =
{
"slot_manager",
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"use",
"attribute_set_elements",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"attribute_set_name_code",
"reference_count",
};

char *names2187 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2188 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"stylesheet_uri_code",
"result_namespace_code",
};

char *names2189 [] =
{
"slot_manager",
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"priority",
"match",
"required_type",
"compiled_template",
"mode_name_codes",
"role_identifier",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"redundant_named_template",
"is_priority_specified",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"internal_fingerprint",
};

char *names2190 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"used_character_maps",
"character_maps_used",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"is_redundant",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"character_map_fingerprint",
};

char *names2191 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"attribute_name_codes",
"attribute_values",
"attribute_clean_flags",
"namespace_codes",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"is_inherit_namespaces",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"result_name_code",
"validation",
"excluded_namespace_count",
};

char *names2192 [] =
{
"slot_manager",
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"imports",
"collation_map",
"importer",
"top_level_elements",
"rule_manager",
"key_manager",
"decimal_format_manager",
"stripper_rules",
"function_library",
"executable",
"overriding_runtime_library",
"non_overriding_runtime_library",
"named_templates_index",
"variables_index",
"namespace_alias_list",
"namespace_alias_uri_codes",
"namespace_alias_namespace_codes",
"stylesheet_module_map",
"module_list",
"stylesheet_compiler",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"includes_processed",
"was_included",
"indices_built",
"is_all_explaining",
"needs_dynamic_output_properties",
"any_compile_errors",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"import_precedence",
"minimum_import_precedence",
"default_validation",
"input_type_annotations",
"largest_pattern_stack_frame",
};

char *names2193 [] =
{
"slot_manager",
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"references",
"compiled_function",
"function_name",
"result_type",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"is_overriding",
"is_memo_function",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"internal_function_fingerprint",
};

char *names2194 [] =
{
"slot_manager",
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"references",
"compiled_function",
"function_name",
"result_type",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"is_overriding",
"is_memo_function",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"internal_function_fingerprint",
};

char *names2195 [] =
{
"slot_manager",
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"as_type",
"select_expression",
"constant_text",
"internal_variable_name",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"allows_tunnel",
"is_redundant_variable",
"is_required_parameter",
"is_implicitly_required_parameter",
"is_tunnel_parameter",
"is_text_only",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"cached_variable_fingerprint",
};

char *names2196 [] =
{
"slot_manager",
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"as_type",
"select_expression",
"constant_text",
"internal_variable_name",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"allows_tunnel",
"is_redundant_variable",
"is_required_parameter",
"is_implicitly_required_parameter",
"is_tunnel_parameter",
"is_text_only",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"cached_variable_fingerprint",
};

char *names2197 [] =
{
"slot_manager",
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"as_type",
"select_expression",
"constant_text",
"internal_variable_name",
"references",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"allows_tunnel",
"is_redundant_variable",
"is_required_parameter",
"is_implicitly_required_parameter",
"is_tunnel_parameter",
"is_text_only",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"cached_variable_fingerprint",
"internal_slot_number",
};

char *names2198 [] =
{
"slot_manager",
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"as_type",
"select_expression",
"constant_text",
"internal_variable_name",
"references",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"allows_tunnel",
"is_redundant_variable",
"is_required_parameter",
"is_implicitly_required_parameter",
"is_tunnel_parameter",
"is_text_only",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"cached_variable_fingerprint",
"internal_slot_number",
};

char *names2199 [] =
{
"slot_manager",
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"as_type",
"select_expression",
"constant_text",
"internal_variable_name",
"references",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"allows_tunnel",
"is_redundant_variable",
"is_required_parameter",
"is_implicitly_required_parameter",
"is_tunnel_parameter",
"is_text_only",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"cached_variable_fingerprint",
"internal_slot_number",
"preparation_state",
};

char *names2200 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"href",
"included_document",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2201 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"href",
"included_document",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2202 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"href",
"included_document",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2203 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2204 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"value",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2205 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"name",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2206 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"name",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2207 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2208 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"attribute_name",
"namespace",
"separator_expression",
"qname_prefix",
"namespace_uri",
"local_name",
"qname",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
"validation_action",
};

char *names2209 [] =
{
"generated_id",
"error_value",
"parent_node",
"document",
"children",
"saved_sequence_number",
"attribute_collection",
"accumulated_namespace_codes",
"namespace_code_list",
"configuration",
"error_listener",
"local_default_xpath_namespace",
"version",
"static_context",
"used_attribute_sets",
"sort_keys",
"validation_error",
"last_generated_expression",
"last_generated_pattern",
"last_generated_sequence_type",
"name_code_error_value",
"local_default_collation_name",
"excluded_namespaces",
"extension_namespaces",
"select_expression",
"separator_expression",
"is_error",
"is_instruction",
"attributes_prepared",
"validated",
"post_validated",
"children_validated",
"version_attribute_processed",
"is_explaining",
"node_type",
"child_index",
"sequence_number_high_word",
"name_code",
"reporting_circumstances",
"last_generated_name_code",
};

char *names2210 [] =
{
"error_value",
"last_evaluated_string",
"last_boolean_value",
"last_iterator",
"last_node_iterator",
"parent",
"cached_slots_used",
"executable",
"select_expression",
"count_pattern",
"from_pattern",
"value_expression",
"format",
"grouping_size",
"grouping_separator",
"letter_value",
"ordinal",
"language",
"formatter",
"numberer",
"atomic_vector",
"transformer",
"group_separator",
"ordinal_value",
"multi_level_number",
"are_intrinsic_dependencies_computed",
"are_dependencies_computed",
"are_cardinalities_computed",
"are_special_properties_computed",
"depends_upon_current_item",
"depends_upon_context_item",
"depends_upon_position",
"depends_upon_last",
"depends_upon_context_document",
"depends_upon_current_group",
"depends_upon_regexp_group",
"depends_upon_local_variables",
"depends_upon_user_functions",
"depends_upon_implicit_timezone",
"depends_upon_xslt_context",
"intrinsically_depends_upon_current_item",
"intrinsically_depends_upon_context_item",
"intrinsically_depends_upon_position",
"intrinsically_depends_upon_last",
"intrinsically_depends_upon_context_document",
"intrinsically_depends_upon_current_group",
"intrinsically_depends_upon_regexp_group",
"intrinsically_depends_upon_local_variables",
"intrinsically_depends_upon_user_functions",
"intrinsically_depends_upon_implicit_timezone",
"intrinsically_depends_upon_xslt_context",
"cardinality_allows_zero",
"cardinality_allows_one",
"cardinality_allows_many",
"context_document_nodeset",
"ordered_nodeset",
"reverse_document_order",
"peer_nodeset",
"subtree_nodeset",
"attribute_ns_nodeset",
"non_creating",
"single_document_nodeset",
"initialized",
"is_backwards_compatible",
"has_variables_in_patterns",
"last_slot_number",
"location_identifier",
"level",
"group_size",
"hash_code",
"value",
"last_single_number",
};

char *names2211 [] =
{
"pattern",
"byte_code",
"character_case_mapping",
"word_set",
"error_message",
"pattern_buffer",
"internal_start_bits",
"start_bits",
"is_caseless",
"is_extended",
"is_greedy",
"is_multiline",
"is_dotall",
"is_empty_allowed",
"is_dollar_endonly",
"is_bol",
"is_eol",
"is_anchored",
"is_strict",
"is_startline",
"is_ichanged",
"optchanged",
"error_code",
"error_position",
"code_index",
"pattern_position",
"pattern_count",
"subexpression_count",
"maxbackrefs",
"regexp_countlits",
"first_character",
"required_character",
};

char *names2212 [] =
{
"subject",
"pattern",
"byte_code",
"character_case_mapping",
"word_set",
"error_message",
"pattern_buffer",
"internal_start_bits",
"start_bits",
"offset_vector",
"brastart_vector",
"eptr_vector",
"is_caseless",
"is_extended",
"is_greedy",
"is_multiline",
"is_dotall",
"is_empty_allowed",
"is_dollar_endonly",
"is_bol",
"is_eol",
"is_anchored",
"is_strict",
"is_startline",
"is_ichanged",
"is_matching_caseless",
"is_matching_multiline",
"is_matching_dotall",
"optchanged",
"subject_start",
"subject_end",
"match_count",
"error_code",
"error_position",
"code_index",
"pattern_position",
"pattern_count",
"subexpression_count",
"maxbackrefs",
"regexp_countlits",
"subject_next_start",
"first_matched_index",
"eptr",
"offset_vector_count",
"offset_top",
"brastart_lower",
"brastart_count",
"brastart_capacity",
"eptr_lower",
"eptr_upper",
"eptr_capacity",
"first_character",
"required_character",
};

char *names2213 [] =
{
"subject",
"pattern",
"byte_code",
"character_case_mapping",
"word_set",
"error_message",
"pattern_buffer",
"internal_start_bits",
"start_bits",
"offset_vector",
"brastart_vector",
"eptr_vector",
"is_caseless",
"is_extended",
"is_greedy",
"is_multiline",
"is_dotall",
"is_empty_allowed",
"is_dollar_endonly",
"is_bol",
"is_eol",
"is_anchored",
"is_strict",
"is_startline",
"is_ichanged",
"is_matching_caseless",
"is_matching_multiline",
"is_matching_dotall",
"optchanged",
"subject_start",
"subject_end",
"match_count",
"error_code",
"error_position",
"code_index",
"pattern_position",
"pattern_count",
"subexpression_count",
"maxbackrefs",
"regexp_countlits",
"subject_next_start",
"first_matched_index",
"eptr",
"offset_vector_count",
"offset_top",
"brastart_lower",
"brastart_count",
"brastart_capacity",
"eptr_lower",
"eptr_upper",
"eptr_capacity",
"first_character",
"required_character",
};

char *names2214 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
"byte_count",
"last_byte_index_input",
"last_byte_index_result",
};

char *names2215 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
"byte_count",
"last_byte_index_input",
"last_byte_index_result",
};



#ifdef __cplusplus
}
#endif
