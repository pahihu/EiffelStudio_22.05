#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* DESCRIPTOR_CACHE c_iconv_close */
void _A10_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_p);
}

	/* DESCRIPTOR_CACHE c_iconv_close */
void __A10_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* XM_XSLT_KEY_DEFINITION set_backwards_compatible */
void _A486_45_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1189_8876)(open [1].it_r);
}

	/* XM_XSLT_KEY_DEFINITION set_backwards_compatible */
void __A486_45_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1189_8876)(op_1);
}

	/* XM_XSLT_WITH_PARAM_ROUTINES promote_parameter */
void _A251_41_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* XM_XSLT_WITH_PARAM_ROUTINES promote_parameter */
void __A251_41_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* XM_XSLT_WITH_PARAM_ROUTINES optimize_parameter */
void _A251_40_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* XM_XSLT_WITH_PARAM_ROUTINES optimize_parameter */
void __A251_40_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* XM_XSLT_WITH_PARAM_ROUTINES check_parameter_static_type */
void _A251_39_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* XM_XSLT_WITH_PARAM_ROUTINES check_parameter_static_type */
void __A251_39_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* XM_XSLT_WITH_PARAM_ROUTINES simplify_parameter */
void _A251_38_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* XM_XSLT_WITH_PARAM_ROUTINES simplify_parameter */
void __A251_38_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* MISMATCH_INFORMATION wipe_out */
void A354_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F976_4742)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A354_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F983_4815)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A354_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F983_4816)(Current, arg1, arg2);
}

	/* UC_UTF8_STRING append_item_code */
void _A1287_285_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* UC_UTF8_STRING append_item_code */
void __A1287_285_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* XM_DTD_ATTRIBUTE_CONTENT has_default_value */
EIF_BOOLEAN _A777_55_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1704_14535)(open [1].it_r);
}

	/* XM_DTD_ATTRIBUTE_CONTENT has_default_value */
EIF_BOOLEAN __A777_55_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1704_14535)(op_1);
}

	/* DS_LIST [G#1] for_all */
EIF_BOOLEAN _A1428_72_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_LIST [INTEGER_32] for_all */
EIF_BOOLEAN _A1987_72_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_LIST [BOOLEAN] for_all */
EIF_BOOLEAN _A2048_72_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_LIST [G#1] for_all */
EIF_BOOLEAN __A1428_72_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_LIST [INTEGER_32] for_all */
EIF_BOOLEAN __A1987_72_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_LIST [BOOLEAN] for_all */
EIF_BOOLEAN __A2048_72_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* XM_XSLT_USE_WHEN_STATIC_CONTEXT add_function_library */
void _A538_461_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r);
}

	/* XM_XSLT_USE_WHEN_STATIC_CONTEXT add_function_library */
void __A538_461_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3);
}

	/* XM_XSLT_OUTPUT_ROUTINES extend_expanded_names */
void _A650_439_6 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_r, open [1].it_r);
}

	/* XM_XSLT_OUTPUT_ROUTINES extend_expanded_names */
void __A650_439_6 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_6)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_r, op_6);
}

	/* XM_XSLT_OUTPUT_ROUTINES no_compile_error_yet */
EIF_BOOLEAN _A650_440_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* XM_XSLT_OUTPUT_ROUTINES no_compile_error_yet */
EIF_BOOLEAN __A650_440_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN _A417_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F772_3900)(open [1].it_r);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN __A417_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F772_3900)(op_1);
}

	/* XM_XPATH_RANGE_VARIABLE_DECLARATION refine_type */
void _A871_499_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* XM_XPATH_RANGE_VARIABLE_DECLARATION refine_type */
void __A871_499_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* XM_XPATH_RANGE_VARIABLE_DECLARATION fix_up_reference */
void _A871_501_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r);
}

	/* XM_XPATH_RANGE_VARIABLE_DECLARATION fix_up_reference */
void __A871_501_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3);
}

	/* XM_XSLT_EXPRESSION_CONTEXT add_function_library */
void _A878_516_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r);
}

	/* XM_XSLT_EXPRESSION_CONTEXT add_function_library */
void __A878_516_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3);
}

	/* XM_XPATH_DIRECTORY_COLLECTION_ROUTINES add_file */
void _A884_527_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r, closed [3].it_r);
}

	/* XM_XPATH_DIRECTORY_COLLECTION_ROUTINES add_file */
void __A884_527_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3, closed [3].it_r);
}

	/* XM_XPATH_DIRECTORY_COLLECTION_ROUTINES add_directory */
void _A884_528_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r, closed [3].it_r);
}

	/* XM_XPATH_DIRECTORY_COLLECTION_ROUTINES add_directory */
void __A884_528_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3, closed [3].it_r);
}

	/* XM_XSLT_SORT_EXPRESSION check_sort_key */
void _A978_874_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r, closed [3].it_r, closed [4].it_r);
}

	/* XM_XSLT_SORT_EXPRESSION check_sort_key */
void __A978_874_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3, closed [3].it_r, closed [4].it_r);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION adopt_child_expression */
void _A993_848_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION adopt_child_expression */
void __A993_848_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION compute_child_cardinality */
void _A993_881_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION compute_child_cardinality */
void __A993_881_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION promote_child */
void _A993_886_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r, open [2].it_i4);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION promote_child */
void __A993_886_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3, EIF_INTEGER_32 op_4)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3, op_4);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION optimize_child */
void _A993_885_5_6 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, open [1].it_r, open [2].it_i4);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION optimize_child */
void __A993_885_5_6 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_5, EIF_INTEGER_32 op_6)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, op_5, op_6);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION check_child_type */
void _A993_884_6_7 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_r, open [1].it_r, open [2].it_i4);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION check_child_type */
void __A993_884_6_7 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_6, EIF_INTEGER_32 op_7)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_r, op_6, op_7);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION simplify_child */
void _A993_882_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, open [1].it_r, open [2].it_i4);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION simplify_child */
void __A993_882_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_4, EIF_INTEGER_32 op_5)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, op_4, op_5);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION add_atomic_value */
void _A993_883_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r);
}

	/* XM_XPATH_SEQUENCE_EXPRESSION add_atomic_value */
void __A993_883_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3);
}

	/* XM_XPATH_EXPRESSION display */
void _A940_654_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R13847[Dtype(open [1].it_r) - 1868])(open [1].it_r, closed [1].it_i4);
}

	/* XM_XPATH_EXPRESSION display */
void __A940_654_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R13847[Dtype(op_1) - 1868])(op_1, closed [1].it_i4);
}

	/* XM_XPATH_EXPRESSION mark_tail_function_calls */
void _A940_747_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R13940[Dtype(open [1].it_r) - 1868])(open [1].it_r);
}

	/* XM_XPATH_EXPRESSION mark_tail_function_calls */
void __A940_747_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R13940[Dtype(op_1) - 1868])(op_1);
}

	/* XM_XSLT_USER_FUNCTION_CALL evaluate_argument */
void _A998_914_5_6 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, open [1].it_r, open [2].it_i4);
}

	/* XM_XSLT_USER_FUNCTION_CALL evaluate_argument */
void __A998_914_5_6 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_5, EIF_INTEGER_32 op_6)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, op_5, op_6);
}

	/* XM_XSLT_USER_FUNCTION_CALL is_no_error */
EIF_BOOLEAN _A998_913_3_4 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r, open [2].it_i4);
}

	/* XM_XSLT_USER_FUNCTION_CALL is_no_error */
EIF_BOOLEAN __A998_913_3_4 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3, EIF_INTEGER_32 op_4)
{
	return f_ptr (closed [1].it_r, closed [2].it_r, op_3, op_4);
}

	/* XM_XSLT_COMPILED_FOR_EACH_GROUP check_sort_key */
void _A1172_882_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r, closed [3].it_r, closed [4].it_r);
}

	/* XM_XSLT_COMPILED_FOR_EACH_GROUP check_sort_key */
void __A1172_882_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3, closed [3].it_r, closed [4].it_r);
}

	/* XM_XSLT_STYLE_ELEMENT exclude_namespace */
void _A1225_1052_2_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4);
}

	/* XM_XSLT_STYLE_ELEMENT exclude_namespace */
void __A1225_1052_2_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3)
{
	f_ptr (closed [1].it_r, op_2, op_3);
}

	/* XM_XPATH_VARIABLE_REFERENCE fix_up */
void _A987_878_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1915_18977)(open [1].it_r, closed [1].it_r);
}

	/* XM_XPATH_VARIABLE_REFERENCE fix_up */
void __A987_878_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1915_18977)(op_1, closed [1].it_r);
}

	/* XM_XPATH_VARIABLE_REFERENCE set_static_type */
void _A987_877_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1915_18976)(open [1].it_r, closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* XM_XPATH_VARIABLE_REFERENCE set_static_type */
void __A987_877_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1915_18976)(op_1, closed [1].it_r, closed [2].it_r, closed [3].it_r);
}


#ifdef __cplusplus
}
#endif
