#include "eif_eiffel.h"
#include "eif_rout_obj.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void F983_4815(EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER);
extern void F1915_18976(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1189_8876(EIF_REFERENCE);
extern void F976_4742(EIF_REFERENCE);
extern EIF_BOOLEAN F1704_14535(EIF_REFERENCE);
extern void F983_4816(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern void F1915_18977(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F772_3900(EIF_REFERENCE);
extern char *(*R13940[])();
extern char *(*R13847[])();

#ifdef __cplusplus
}
#endif
