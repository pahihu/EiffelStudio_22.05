/*
 * Code for class XM_XSLT_GEXSLT_NULL_EMITTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm806.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_GEXSLT_NULL_EMITTER}.make */
void F1733_15300 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg2;
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_GEXSLT_NULL_EMITTER}.open */
void F1733_15301 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_XSLT_GEXSLT_NULL_EMITTER}.start_document */
void F1733_15302 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_XSLT_GEXSLT_NULL_EMITTER}.end_document */
void F1733_15303 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {XM_XSLT_GEXSLT_NULL_EMITTER}.close */
void F1733_15304 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {XM_XSLT_GEXSLT_NULL_EMITTER}.start_element */
void F1733_15305 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_GEXSLT_NULL_EMITTER}.notify_namespace */
void F1733_15306 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_GEXSLT_NULL_EMITTER}.notify_attribute */
void F1733_15307 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_GEXSLT_NULL_EMITTER}.start_content */
void F1733_15308 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_GEXSLT_NULL_EMITTER}.end_element */
void F1733_15309 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_GEXSLT_NULL_EMITTER}.notify_characters */
void F1733_15310 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_GEXSLT_NULL_EMITTER}.notify_processing_instruction */
void F1733_15311 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_GEXSLT_NULL_EMITTER}.notify_comment */
void F1733_15312 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	F1729_15248(Current);
}

void EIF_Minit806 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
