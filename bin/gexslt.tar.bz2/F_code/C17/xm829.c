/*
 * Code for class XM_CATALOG_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm829.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_CATALOG_MANAGER}.make */
void F1756_15897 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1756_15921(Current);
	tr1 = RTLNSMART(eif_new_type(1543, 1).id);
	F1544_12483(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_CATALOG_MANAGER}.system_default_catalog */

EIF_REFERENCE F1756_15898 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15898,RTMS_EX_H("file:///etc/xml/catalog",23,2019545191));
}

/* {XM_CATALOG_MANAGER}.unescaped_uri_characters */
static EIF_REFERENCE F1756_15899_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOSP (15899);
#define Result RTOSR(15899)
	RTOC_NEW(Result);
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(15778,F1753_15778, (Current));
	tr3 = RTOSCF(15779,F1753_15779, (Current));
	loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(15780,F1753_15780, (Current));
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(15781,F1753_15781, (Current));
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(15782,F1753_15782, (Current));
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(15783,F1753_15783, (Current));
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("#",1,35);
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("%",1,37);
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	Result = F1753_15776(Current, loc1);
	RTOSE (15899);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1756_15899 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15899,F1756_15899_body,(Current));
}

/* {XM_CATALOG_MANAGER}.resolved_external_entity */
EIF_REFERENCE F1756_15901 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLR(6,loc2);
	RTLR(7,loc1);
	RTLR(8,loc4);
	RTLIU(9);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_5_0_0_) > ((EIF_INTEGER_32) 2L))) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("PUBLIC ",7,910695456);
		loc3 = F1148_8367(RTCW(tr1), tr2, arg1);
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H(", SYSTEM ",9,870236704);
		loc3 = F1148_8377(RTCW(tr1), tr2, arg2);
		tr1 = RTMS_EX_H("Resolving external entity",25,1550251897);
		F1756_15920(Current, ((EIF_INTEGER_32) 3L), tr1, loc3);
	}
	tr1 = RTMS_EX_H("urn:publicid:",13,1644142138);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5041[Dtype(RTCW(arg1))-1111])(arg1, tr1, ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		loc2 = F178_1650(Current, arg1);
	} else {
		loc2 = (EIF_REFERENCE) arg1;
	}
	tr1 = RTMS_EX_H("urn:publicid:",13,1644142138);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5041[Dtype(RTCW(arg2))-1111])(arg2, tr1, ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		loc1 = F178_1650(Current, arg2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tb1 = F1148_8369(RTCW(tr1), loc1, loc2);
			if (tb1) {
				loc4 = F1756_15923(Current, loc1, (EIF_BOOLEAN) 0);
			} else {
				tr1 = RTMS_EX_H("SYSTEM id is a publicid URN, but differs from PUBLIC id",55,1165784164);
				F1756_15920(Current, ((EIF_INTEGER_32) 2L), tr1, arg2);
				loc4 = F1756_15923(Current, loc2, (EIF_BOOLEAN) 0);
			}
		} else {
			loc4 = F1756_15923(Current, loc1, (EIF_BOOLEAN) 0);
		}
	} else {
		loc1 = (EIF_REFERENCE) loc2;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			loc4 = F1756_15923(Current, loc1, (EIF_BOOLEAN) 0);
		} else {
			loc4 = F1756_15924(Current, arg2);
			if ((EIF_BOOLEAN)(loc4 == NULL)) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
					loc4 = F1756_15923(Current, loc1, (EIF_BOOLEAN) 1);
				}
			}
		}
	}
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTLE;
		return (EIF_REFERENCE) loc4;
	} else {
		RTLE;
		return (EIF_REFERENCE) arg2;
	}/* NOTREACHED */
	
}

/* {XM_CATALOG_MANAGER}.resolved_uri_reference */
EIF_REFERENCE F1756_15902 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = RTMS_EX_H("Resolving URI reference",23,39036517);
	F1756_15920(Current, ((EIF_INTEGER_32) 3L), tr1, arg1);
	tr1 = RTMS_EX_H("urn:publicid:",13,1644142138);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5041[Dtype(RTCW(arg1))-1111])(arg1, tr1, ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		loc1 = F178_1650(Current, arg1);
		loc2 = F1756_15923(Current, loc1, (EIF_BOOLEAN) 0);
	} else {
		loc2 = F1756_15925(Current, arg1);
	}
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTLE;
		return (EIF_REFERENCE) loc2;
	} else {
		RTLE;
		return (EIF_REFERENCE) arg1;
	}/* NOTREACHED */
	
}

/* {XM_CATALOG_MANAGER}.suppress_default_system_catalog_file */
void F1756_15910 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F1756_15921(Current);
	tr1 = RTMS_EX_H("System default catalog suppressed",33,98517860);
	tr2 = RTOSCF(15898,F1756_15898, (Current));
	F1756_15920(Current, ((EIF_INTEGER_32) 2L), tr1, tr2);
	RTLE;
}

/* {XM_CATALOG_MANAGER}.set_prefer_system */
void F1756_15911 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = RTMS_EX_H("System/public preference",24,950117733);
	tr2 = RTMS_EX_H("system",6,16556653);
	F1756_15920(Current, ((EIF_INTEGER_32) 3L), tr1, tr2);
	RTLE;
}

/* {XM_CATALOG_MANAGER}.suppress_catalogs */
void F1756_15912 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_CATALOG_MANAGER}.suppress_processing_instructions */
void F1756_15913 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = RTMS_EX_H("Per-document catalogs",21,366849907);
	tr2 = RTMS_EX_H("<suppressed>",12,575172414);
	F1756_15920(Current, ((EIF_INTEGER_32) 3L), tr1, tr2);
	RTLE;
}

/* {XM_CATALOG_MANAGER}.set_debug_level */
void F1756_15914 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_5_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {XM_CATALOG_MANAGER}.set_search_chain_truncated */
void F1756_15915 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_CATALOG_MANAGER}.reset_pi_catalogs */
void F1756_15916 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1506_12211(RTCW(tr1));
	tr1 = RTMS_EX_H("Per-document catalogs reset to",30,1135031407);
	tr2 = RTMS_EX_H("<empty>",7,72884286);
	F1756_15920(Current, ((EIF_INTEGER_32) 2L), tr1, tr2);
	RTLE;
}

/* {XM_CATALOG_MANAGER}.add_pi_catalog */
void F1756_15917 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1506_12183(RTCW(tr1), arg1);
	tr1 = RTMS_EX_H("Per-document catalog added",26,923741540);
	F1756_15920(Current, ((EIF_INTEGER_32) 2L), tr1, arg1);
	RTLE;
}

/* {XM_CATALOG_MANAGER}.parse_catalog_file */
void F1756_15918 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1));
	tr1 = RTMS_EX_H("Catalog\'s SYSTEM id is",22,803512435);
	F1756_15920(Current, ((EIF_INTEGER_32) 7L), tr1, loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F1525_12411(RTCW(tr1), loc2);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2011[Dtype(RTCW(tr1))-252])(tr1, loc2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2015[Dtype(RTCW(tr1))-1125])(tr1);
		if (tb1) {
			tr1 = RTMS_EX_H("Catalog does not exist",22,690798196);
			F1756_15920(Current, ((EIF_INTEGER_32) 3L), tr1, loc2);
		} else {
			loc1 = RTLNS(eif_new_type(1753, 0x01).id, 1753, _OBJSIZ_19_5_0_3_0_0_0_0_);
			F1754_15787(RTCW(loc1), arg1);
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_19_0_);
			if (tb1) {
				tr1 = RTMS_EX_H("Failed to parse catalog",23,130505831);
				F1756_15920(Current, ((EIF_INTEGER_32) 1L), tr1, loc2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1525_12419(RTCW(tr1), NULL, loc2);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1525_12419(RTCW(tr1), loc1, loc2);
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG_MANAGER}.debug_message */
void F1756_15920 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_5_0_0_))) {
		tr1 = RTOSCF(418,F36_418, (RTCV(RTOSCF(4949,F990_4949, (Current)))));
		F1219_9721(RTCW(tr1), arg2);
		tr1 = RTOSCF(418,F36_418, (RTCV(RTOSCF(4949,F990_4949, (Current)))));
		tr2 = RTMS_EX_H(": ",2,14880);
		F1219_9721(RTCW(tr1), tr2);
		tr1 = RTOSCF(418,F36_418, (RTCV(RTOSCF(4949,F990_4949, (Current)))));
		F1219_9721(RTCW(tr1), arg3);
		tr1 = RTOSCF(418,F36_418, (RTCV(RTOSCF(4949,F990_4949, (Current)))));
		F1218_9714(RTCW(tr1));
	}
	RTLE;
}

/* {XM_CATALOG_MANAGER}.reinit */
void F1756_15921 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1481,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 1481, _OBJSIZ_4_0_0_1_0_0_0_0_);
	}
	F1482_11932(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1439_11749(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12163(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1439_11749(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1536,1753,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1525_12401(RTCW(tr1), ((EIF_INTEGER_32) 10L), NULL, tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	F1756_15930(Current);
	RTLE;
}

/* {XM_CATALOG_MANAGER}.retrieved_catalog */
EIF_REFERENCE F1756_15922 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
	tr1 = RTOSCF(15929,F1756_15929, (Current));
	F1707_14587(RTCW(loc1), tr1, arg1);
	loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F1525_12411(RTCW(tr1), loc2);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		Result = F1525_12403(RTCW(tr1), loc2);
	} else {
		tr1 = RTMS_EX_H("Loading catalog",15,897777255);
		F1756_15920(Current, ((EIF_INTEGER_32) 2L), tr1, arg1);
		F1756_15918(Current, loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tb1 = F1525_12411(RTCW(tr1), loc2);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			Result = F1525_12403(RTCW(tr1), loc2);
		}
	}
	RTLE;
	return Result;
}

/* {XM_CATALOG_MANAGER}.resolved_fpi */
EIF_REFERENCE F1756_15923 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,loc4);
	RTLR(7,Result);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	loc1 = F178_1649(Current, arg1);
	tr1 = RTMS_EX_H("Fpi normalized to",17,513585263);
	F1756_15920(Current, ((EIF_INTEGER_32) 8L), tr1, loc1);
	tr1 = RTMS_EX_H("Number of system catalogs",25,167776883);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9566[Dtype(RTCW(tr2))-1481])(tr2);
	tr2 = eif_out__i4_s1(ti4_1);
	F1756_15920(Current, ((EIF_INTEGER_32) 8L), tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
	F1320_11363(RTCW(loc2));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3187[Dtype(RTCW(loc2))-556])(loc2);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3186[Dtype(RTCW(loc2))-556])(loc2);
		loc4 = F1756_15922(Current, tr1);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tr1 = RTMS_EX_H("Retrieved catalog is ",21,1239317280);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3186[Dtype(RTCW(loc2))-556])(loc2);
			F1756_15920(Current, ((EIF_INTEGER_32) 7L), tr1, tr2);
			Result = F1754_15788(RTCW(loc4), loc1, arg2);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_))) {
				F1320_11364(RTCW(loc2));
			} else {
				F1320_11366(RTCW(loc2));
			}
		} else {
			tr1 = RTMS_EX_H("Retrieved catalog failed parsing",32,311085415);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3186[Dtype(RTCW(loc2))-556])(loc2);
			F1756_15920(Current, ((EIF_INTEGER_32) 7L), tr1, tr2);
			F1320_11364(RTCW(loc2));
		}
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && *(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = F1506_12168(RTCW(tr1));
		F1320_11363(RTCW(loc3));
		for (;;) {
			tb2 = F1384_11438(RTCW(loc3));
			if (tb2) break;
			tr1 = F1307_11343(RTCW(loc3));
			loc4 = F1756_15922(Current, tr1);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				tr1 = RTMS_EX_H("Retrieved catalog is ",21,1239317280);
				tr2 = F1307_11343(RTCW(loc3));
				F1756_15920(Current, ((EIF_INTEGER_32) 7L), tr1, tr2);
				Result = F1754_15788(RTCW(loc4), loc1, arg2);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_))) {
					F1320_11364(RTCW(loc3));
				} else {
					F1320_11366(RTCW(loc3));
				}
			} else {
				tr1 = RTMS_EX_H("Retrieved catalog failed parsing",32,311085415);
				tr2 = F1307_11343(RTCW(loc3));
				F1756_15920(Current, ((EIF_INTEGER_32) 7L), tr1, tr2);
				F1320_11364(RTCW(loc3));
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
	return Result;
}

/* {XM_CATALOG_MANAGER}.resolved_fsi */
EIF_REFERENCE F1756_15924 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,loc4);
	RTLR(7,Result);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	tr1 = RTOSCF(4521,F954_4521, (Current));
	tr1 = F1138_8299(RTCW(tr1), arg1);
	tr2 = RTOSCF(15899,F1756_15899, (Current));
	loc1 = F1753_15774(Current, tr1, tr2, (EIF_BOOLEAN) 0);
	tr1 = RTMS_EX_H("Fsi normalized to",17,1391790191);
	F1756_15920(Current, ((EIF_INTEGER_32) 8L), tr1, loc1);
	tr1 = RTMS_EX_H("Number of system catalogs",25,167776883);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9566[Dtype(RTCW(tr2))-1481])(tr2);
	tr2 = eif_out__i4_s1(ti4_1);
	F1756_15920(Current, ((EIF_INTEGER_32) 8L), tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
	F1320_11363(RTCW(loc2));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3187[Dtype(RTCW(loc2))-556])(loc2);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3186[Dtype(RTCW(loc2))-556])(loc2);
		loc4 = F1756_15922(Current, tr1);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tr1 = RTMS_EX_H("Retrieved catalog is ",21,1239317280);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3186[Dtype(RTCW(loc2))-556])(loc2);
			F1756_15920(Current, ((EIF_INTEGER_32) 7L), tr1, tr2);
			Result = F1754_15789(RTCW(loc4), loc1);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_))) {
				F1320_11364(RTCW(loc2));
			} else {
				F1320_11366(RTCW(loc2));
			}
		} else {
			tr1 = RTMS_EX_H("Retrieved catalog failed parsing",32,311085415);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3186[Dtype(RTCW(loc2))-556])(loc2);
			F1756_15920(Current, ((EIF_INTEGER_32) 7L), tr1, tr2);
			F1320_11364(RTCW(loc2));
		}
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && *(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = F1506_12168(RTCW(tr1));
		F1320_11363(RTCW(loc3));
		for (;;) {
			tb2 = F1384_11438(RTCW(loc3));
			if (tb2) break;
			tr1 = F1307_11343(RTCW(loc3));
			loc4 = F1756_15922(Current, tr1);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				tr1 = RTMS_EX_H("Retrieved catalog is ",21,1239317280);
				tr2 = F1307_11343(RTCW(loc3));
				F1756_15920(Current, ((EIF_INTEGER_32) 7L), tr1, tr2);
				Result = F1754_15789(RTCW(loc4), loc1);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_))) {
					F1320_11364(RTCW(loc3));
				} else {
					F1320_11366(RTCW(loc3));
				}
			} else {
				tr1 = RTMS_EX_H("Retrieved catalog failed parsing",32,311085415);
				tr2 = F1307_11343(RTCW(loc3));
				F1756_15920(Current, ((EIF_INTEGER_32) 7L), tr1, tr2);
				F1320_11364(RTCW(loc3));
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
	return Result;
}

/* {XM_CATALOG_MANAGER}.resolved_uri */
EIF_REFERENCE F1756_15925 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,loc4);
	RTLR(7,Result);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	tr1 = RTOSCF(4521,F954_4521, (Current));
	tr1 = F1138_8299(RTCW(tr1), arg1);
	tr2 = RTOSCF(15899,F1756_15899, (Current));
	loc1 = F1753_15774(Current, tr1, tr2, (EIF_BOOLEAN) 0);
	tr1 = RTMS_EX_H("URI normalized to",17,1255231599);
	F1756_15920(Current, ((EIF_INTEGER_32) 8L), tr1, loc1);
	tr1 = RTMS_EX_H("Number of system catalogs",25,167776883);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9566[Dtype(RTCW(tr2))-1481])(tr2);
	tr2 = eif_out__i4_s1(ti4_1);
	F1756_15920(Current, ((EIF_INTEGER_32) 8L), tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
	F1320_11363(RTCW(loc2));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3187[Dtype(RTCW(loc2))-556])(loc2);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3186[Dtype(RTCW(loc2))-556])(loc2);
		loc4 = F1756_15922(Current, tr1);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tr1 = RTMS_EX_H("Retrieved catalog is ",21,1239317280);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3186[Dtype(RTCW(loc2))-556])(loc2);
			F1756_15920(Current, ((EIF_INTEGER_32) 7L), tr1, tr2);
			Result = F1754_15790(RTCW(loc4), loc1);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_))) {
				F1320_11364(RTCW(loc2));
			} else {
				F1320_11366(RTCW(loc2));
			}
		} else {
			tr1 = RTMS_EX_H("Retrieved catalog failed parsing",32,311085415);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3186[Dtype(RTCW(loc2))-556])(loc2);
			F1756_15920(Current, ((EIF_INTEGER_32) 7L), tr1, tr2);
			F1320_11364(RTCW(loc2));
		}
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && *(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = F1506_12168(RTCW(tr1));
		F1320_11363(RTCW(loc3));
		for (;;) {
			tb2 = F1384_11438(RTCW(loc3));
			if (tb2) break;
			tr1 = F1307_11343(RTCW(loc3));
			loc4 = F1756_15922(Current, tr1);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				tr1 = RTMS_EX_H("Retrieved catalog is ",21,1239317280);
				tr2 = F1307_11343(RTCW(loc3));
				F1756_15920(Current, ((EIF_INTEGER_32) 7L), tr1, tr2);
				Result = F1754_15790(RTCW(loc4), loc1);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_))) {
					F1320_11364(RTCW(loc3));
				} else {
					F1320_11366(RTCW(loc3));
				}
			} else {
				tr1 = RTMS_EX_H("Retrieved catalog failed parsing",32,311085415);
				tr2 = F1307_11343(RTCW(loc3));
				F1756_15920(Current, ((EIF_INTEGER_32) 7L), tr1, tr2);
				F1320_11364(RTCW(loc3));
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
	return Result;
}

/* {XM_CATALOG_MANAGER}.current_directory_base */
static EIF_REFERENCE F1756_15929_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (15929);
#define Result RTOSR(15929)
	RTOC_NEW(Result);
	tr1 = RTOSCF(12479,F1543_12479, (Current));
	tr2 = F1583_13107(RTCV(RTOSCF(12479,F1543_12479, (Current))));
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R10383[Dtype(RTCW(tr1))-1583])(tr1, tr2);
	tr1 = RTOSCF(3598,F479_3598, (Current));
	Result = F1578_12941(RTCW(tr1), loc1);
	RTOSE (15929);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1756_15929 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15929,F1756_15929_body,(Current));
}

/* {XM_CATALOG_MANAGER}.establish_system_catalog_files */
void F1756_15930 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,loc4);
	RTLR(7,loc6);
	RTLR(8,loc5);
	RTLR(9,tr3);
	RTLIU(10);
	
	RTGC;
	tr1 = RTOSCF(2100,F246_2100, (Current));
	tr2 = RTMS_EX_H("XML_CATALOG_FILES",17,746454355);
	loc1 = F1211_9660(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc3 = RTLNS(eif_new_type(1263, 0x01).id, 1263, _OBJSIZ_2_2_0_0_0_0_0_0_);
		F1264_10634(RTCW(loc3));
		tb1 = RTOSCF(172,F20_172, (RTCV(RTOSCF(1181,F131_1181, (Current)))));
		if (tb1) {
			loc2 = RTMS_EX_H(";",1,59);
		} else {
			loc2 = RTMS_EX_H(":",1,58);
		}
		F1264_10640(RTCW(loc3), loc2);
		loc4 = F1264_10644(RTCW(loc3), loc1);
	}
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc4;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = RTOSCF(8115,F1125_8115, (Current));
		F1439_11749(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
		F1320_11363(RTCW(loc6));
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3187[Dtype(RTCW(loc6))-556])(loc6);
			if (tb1) break;
			loc5 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			tr1 = RTOSCF(15929,F1756_15929, (Current));
			tr2 = RTOSCF(3598,F479_3598, (Current));
			tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3186[Dtype(RTCW(loc6))-556])(loc6);
			tr2 = F1578_12939(RTCW(tr2), tr3);
			F1707_14588(RTCW(loc5), tr1, tr2);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9332[Dtype(RTCW(loc6))-1374])(loc6, tr1);
			F1320_11364(RTCW(loc6));
		}
	}
	tb2 = '\0';
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9566[Dtype(RTCW(tr1))-1481])(tr1);
		tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
	}
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = RTOSCF(15898,F1756_15898, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9658[Dtype(RTCW(tr1))-1481])(tr1, tr2);
	}
	tr1 = RTMS_EX_H("Number of system catalog files is",33,645154419);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9566[Dtype(RTCW(tr2))-1481])(tr2);
	tr2 = eif_out__i4_s1(ti4_1);
	F1756_15920(Current, ((EIF_INTEGER_32) 8L), tr1, tr2);
	RTLE;
}

void EIF_Minit829 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
