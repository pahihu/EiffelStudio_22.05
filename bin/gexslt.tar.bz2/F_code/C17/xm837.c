/*
 * Code for class XM_XSLT_TRANSFORMER_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm837.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_TRANSFORMER_FACTORY}.make */
void F1764_16071 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1536,0xFF01,1126,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1525_12401(RTCW(tr1), ((EIF_INTEGER_32) 10L), NULL, tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XSLT_TRANSFORMER_FACTORY}.is_stylesheet_cached */
EIF_BOOLEAN F1764_16074 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1525_12411(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {XM_XSLT_TRANSFORMER_FACTORY}.cached_stylesheet */
EIF_REFERENCE F1764_16075 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1525_12403(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {XM_XSLT_TRANSFORMER_FACTORY}.create_new_transformer */
void F1764_16080 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc1);
	RTLR(9,loc4);
	RTLIU(10);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
	tr1 = F1301_11307(RTCW(arg1));
	F1707_14587(RTCW(loc2), arg2, tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_17_5_);
	if (tb1) {
		loc3 = RTLNS(eif_new_type(460, 0x01).id, 460, _OBJSIZ_5_0_0_0_0_0_0_0_);
		F461_3566(RTCW(loc3));
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
	if (F1764_16074(Current, tr1)) {
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			F461_3576(RTCW(loc3));
		}
		tr1 = RTLNSMART(eif_new_type(2151, 0).id);
		tr2 = *(EIF_REFERENCE *)(Current);
		tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
		tr3 = F1764_16075(Current, tr3);
		F2152_21368(RTCW(tr1), tr2, tr3, Current, loc3);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	} else {
		loc1 = RTLNS(eif_new_type(1633, 0x01).id, 1633, _OBJSIZ_6_1_0_1_0_0_0_0_);
		F1634_13714(RTCW(loc1), *(EIF_REFERENCE *)(Current));
		F1634_13726(RTCW(loc1), arg1, arg2);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_6_0_);
		if (tb1) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		} else {
			RTCT0("attached l_compiler.executable as l_compiler_executable", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				RTCK0;
			} else {
				RTCF0;
			}
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
				F1525_12424(RTCW(tr1), loc4, tr2);
			}
			tr1 = F1634_13730(RTCW(loc1), Current, loc3);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		}
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			F461_3576(RTCW(loc3));
		}
	}
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_7_);
		tr2 = RTMS_EX_H("Compiling all modules lasted for ",33,2141271072);
		tr3 = F461_3572(RTCW(loc3));
		tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10671[Dtype(RTCW(tr3))-1615])(tr3);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr2)-1111])(tr2, tr3);
		tr3 = RTMS_EX_H("seconds",7,1968280435);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr2))-1111])(tr2, tr3);
		F1581_13014(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {XM_XSLT_TRANSFORMER_FACTORY}.associated_stylesheet */
EIF_REFERENCE F1764_16081 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLR(5,arg1);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc14);
	RTLR(9,loc13);
	RTLR(10,loc6);
	RTLR(11,loc7);
	RTLR(12,arg2);
	RTLR(13,tr2);
	RTLR(14,arg3);
	RTLR(15,loc10);
	RTLIU(16);
	
	RTGC;
	loc2 = F124_1134(Current);
	loc3 = F1409_11646(RTCW(loc2));
	loc1 = RTLNS(eif_new_type(1203, 0x01).id, 1203, _OBJSIZ_8_3_0_0_0_0_0_0_);
	F1204_9066(RTCW(loc1), loc3);
	F256_2145(RTCW(loc2), loc1);
	F323_2439(RTCW(loc2), loc1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_8_);
	F1409_11634(RTCW(loc2), tr1);
	F1719_15020(RTCW(loc2), arg1);
	loc4 = *(EIF_REFERENCE *)(RTCW(loc1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,37,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc5 = RTLNS(typres0.id, 1505, _OBJSIZ_4_0_0_2_0_0_0_0_);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
		F1506_12159(RTCW(loc5), ti4_1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1112,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc14 = RTLNS(typres0.id, 1505, _OBJSIZ_4_0_0_2_0_0_0_0_);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
		F1506_12159(RTCW(loc14), ti4_1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1506,1035,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc13 = RTLNS(typres0.id, 1506, _OBJSIZ_4_0_0_2_0_0_0_0_);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
		F1507_12159(RTCW(loc13), ti4_1);
		loc6 = F1506_12168(RTCW(loc4));
		F1320_11363(RTCW(loc6));
		for (;;) {
			tb1 = F1384_11438(RTCW(loc6));
			if (tb1) break;
			loc7 = F1307_11343(RTCW(loc6));
			loc8 = '\01';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_4_);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9611[Dtype(RTCW(tr1))-1481])(tr1, arg2);
			if (!tb2) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_4_);
				tr2 = RTMS_EX_H("all",3,6384748);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9611[Dtype(RTCW(tr1))-1481])(tr1, tr2);
				loc8 = tb2;
			}
			if (loc8) {
				tb2 = *(EIF_BOOLEAN *)(RTCW(loc7)+ _CHROFF_5_0_);
				if (tb2) {
					loc11++;
					F1506_12178(RTCW(loc5), loc7);
					F1507_12178(RTCW(loc13), loc11);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_3_);
					F1506_12178(RTCW(loc14), tr1);
				} else {
					tb2 = F38_430(RTCW(loc7));
					if (tb2) {
						if ((EIF_BOOLEAN) !loc9) {
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							loc11++;
							F1506_12178(RTCW(loc5), loc7);
							F1507_12177(RTCW(loc13), loc11);
							tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_3_);
							F1506_12177(RTCW(loc14), tr1);
						}
					} else {
						loc11++;
						F1506_12178(RTCW(loc5), loc7);
					}
				}
			}
			F1320_11364(RTCW(loc6));
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc14)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
			loc12 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R1944[Dtype(RTCW(arg3))-230])(arg3, loc14);
			F1507_12199(RTCW(loc13), loc12);
			F1764_16086(Current, loc5, loc13);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			loc10 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_8_);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2019[Dtype(RTCW(tr1))-1125])(tr1);
			F1707_14587(RTCW(loc10), tr1, arg1);
			RTLE;
			return (EIF_REFERENCE) F1764_16085(Current, loc10, loc5);
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {XM_XSLT_TRANSFORMER_FACTORY}.composite_stylesheet */
EIF_REFERENCE F1764_16085 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(10);
	RTLR(0,arg2);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLR(5,loc2);
	RTLR(6,Current);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,loc3);
	RTLIU(10);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		loc1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
		tr1 = F1506_12165(RTCW(arg2), ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		F1707_14587(RTCW(loc1), arg1, tr1);
		Result = RTLNS(eif_new_type(1546, 0x01).id, 1546, _OBJSIZ_12_1_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		F1547_12569(RTCW(Result), tr1);
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("<xsl:transform version=\'2.0\' xmlns:xsl=\'",40,1791446823);
		tr3 = RTOSCF(9822,F1230_9822, (Current));
		loc2 = F1148_8367(RTCW(tr1), tr2, tr3);
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("\' xml:base=\'",12,1246207527);
		tr1 = F1148_8377(RTCW(tr1), loc2, tr2);
		loc2 = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
		tr1 = F1148_8377(RTCW(tr1), loc2, tr2);
		loc2 = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("\'>",2,10046);
		tr1 = F1148_8377(RTCW(tr1), loc2, tr2);
		loc2 = (EIF_REFERENCE) tr1;
		loc3 = F1506_12168(RTCW(arg2));
		F1320_11363(RTCW(loc3));
		for (;;) {
			tb1 = F1384_11438(RTCW(loc3));
			if (tb1) break;
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H(" <xsl:import href=\'",19,1713937191);
			tr1 = F1148_8377(RTCW(tr1), loc2, tr2);
			loc2 = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = F1307_11343(RTCW(loc3));
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
			tr1 = F1148_8377(RTCW(tr1), loc2, tr2);
			loc2 = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("\'/>",3,2567998);
			tr1 = F1148_8377(RTCW(tr1), loc2, tr2);
			loc2 = (EIF_REFERENCE) tr1;
			F1320_11364(RTCW(loc3));
		}
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("</xsl:transform>",16,279072574);
		tr1 = F1148_8377(RTCW(tr1), loc2, tr2);
		loc2 = (EIF_REFERENCE) tr1;
		Result = RTLNS(eif_new_type(1301, 0x01).id, 1301, _OBJSIZ_13_1_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		F1302_11313(RTCW(Result), tr1, loc2);
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_TRANSFORMER_FACTORY}.trim_selected_stylesheets */
void F1764_16086 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1507_12168(RTCW(arg2));
	F1330_11374(RTCW(loc1));
	for (;;) {
		tb1 = F1385_11439(RTCW(loc1));
		if (tb1) break;
		ti4_1 = F1308_11343(RTCW(loc1));
		F1506_12199(RTCW(arg1), ti4_1);
		F1330_11375(RTCW(loc1));
	}
	RTLE;
}

void EIF_Minit837 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
