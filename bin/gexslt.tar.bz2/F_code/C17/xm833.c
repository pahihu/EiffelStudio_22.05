/*
 * Code for class XM_XSLT_TEXT_EMITTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm833.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_TEXT_EMITTER}.start_document */
void F1760_15994 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_XSLT_TEXT_EMITTER}.open */
void F1760_15995 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F1759_15989(Current);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_6_)) {
		RTCT0("is_output_open", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1640[Dtype(loc1)-1183])(loc1);
		if (tb1) {
			tb1 = '\01';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_22_4_);
			if (!tb2) {
				tb2 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tb3 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_22_8_);
				if ((EIF_BOOLEAN) !tb3) {
					tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1641[Dtype(loc1)-1183])(loc1);
					tb2 = tb3;
				}
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1638[Dtype(loc1)-1183])(loc1);
				F1759_15984(Current, tr1);
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XSLT_TEXT_EMITTER}.notify_characters */
void F1760_15996 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_10_3_)) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_10_6_)) {
			F1759_15989(Current);
		}
		if ((EIF_BOOLEAN) !F1412_11673(Current, arg2)) {
			loc1 = F1759_15991(Current, arg1);
			if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
				F1759_15983(Current, arg1);
			} else {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H("Output character not available in this encoding (decimal ",57,1992991520);
				tr3 = eif_out__i4_s1(loc1);
				loc2 = F1148_8367(RTCW(tr1), tr2, tr3);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H(")",1,41);
				tr1 = F1148_8377(RTCW(tr1), loc2, tr2);
				loc2 = (EIF_REFERENCE) tr1;
				loc3 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
				tr1 = RTOSCF(9827,F1230_9827, (Current));
				tr2 = RTMS_EX_H("XTDE1190",8,308796208);
				F1709_14669(RTCW(loc3), loc2, tr1, tr2, ((EIF_INTEGER_32) 3L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tb1 = F772_3900(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb1) {
					F1709_14683(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), ((EIF_INTEGER_32) 0L));
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				F1710_14691(RTCW(tr1), loc3);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_10_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		} else {
			F1759_15983(Current, arg1);
		}
	}
	F1729_15248(Current);
	RTLE;
}

/* {XM_XSLT_TEXT_EMITTER}.start_element */
void F1760_15997 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_TEXT_EMITTER}.end_element */
void F1760_15998 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_TEXT_EMITTER}.notify_namespace */
void F1760_15999 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_TEXT_EMITTER}.notify_attribute */
void F1760_16000 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_TEXT_EMITTER}.notify_processing_instruction */
void F1760_16001 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_TEXT_EMITTER}.notify_comment */
void F1760_16002 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_TEXT_EMITTER}.write_declaration */
void F1760_16003 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit833 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
