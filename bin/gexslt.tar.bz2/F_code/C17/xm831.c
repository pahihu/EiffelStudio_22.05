/*
 * Code for class XM_XSLT_DOCUMENT_INFORMATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm831.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_DOCUMENT_INFORMATION}.make */
void F1758_15937 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg3;
	RTLE;
}

/* {XM_XSLT_DOCUMENT_INFORMATION}.last_node_iterator */
EIF_REFERENCE F1758_15941 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_7_);
}


/* {XM_XSLT_DOCUMENT_INFORMATION}.map_nodes */
void F1758_15942 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTCFDT;
	RTLD;
	
	RTLI(17);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc8);
	RTLR(5,loc1);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,loc6);
	RTLR(11,loc2);
	RTLR(12,arg2);
	RTLR(13,loc9);
	RTLR(14,loc10);
	RTLR(15,loc3);
	RTLR(16,loc11);
	RTLIU(17);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc7 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc7)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13398[Dtype(RTCW(arg1))-1819])(arg1);
		if (tb1) {
			RTCT0("attached a_item.as_node.base_uri as l_node_base_uri", EX_CHECK);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13416[Dtype(RTCW(arg1))-1819])(arg1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13623[Dtype(RTCW(tr1))-1853])(tr1);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				RTCK0;
			} else {
				RTCF0;
			}
			loc1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			F1707_14586(RTCW(loc1), loc8);
		} else {
			loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		}
	} else {
		loc1 = (EIF_REFERENCE) loc7;
	}
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(arg1))-1819])(arg1);
	tr1 = RTOSCF(15934,F1757_15934, (Current));
	tb1 = F1753_15784(RTCW(tr1), loc4);
	if (tb1) {
		tr1 = F1757_15935(Current, loc4);
		loc4 = (EIF_REFERENCE) tr1;
	}
	tc1 = (EIF_CHARACTER_8) '#';
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R3400[Dtype(RTCW(loc4))-1112])(loc4, (EIF_REFERENCE) &tc1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
		loc5 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
		tr1 = RTMS_EX_H("Argument to fn:document is not a valid URI",42,382400329);
		tr2 = RTOSCF(9827,F1230_9827, (Current));
		tr3 = RTMS_EX_H("FODC0005",8,2066165813);
		F1709_14669(RTCW(loc5), tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1710_14690(RTCW(tr1), loc5);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1694,0xFF01,1852,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc6 = RTLNS(typres0.id, 1694, _OBJSIZ_3_1_0_1_0_0_0_0_);
		}
		RTAR(Current, loc6);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc6;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_33_0_);
		if (tb1) {
			F1636_13762(RTCW(loc6), loc5);
		}
	} else {
		loc2 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
		F1707_14587(RTCW(loc2), loc1, loc4);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(arg1))-1819])(arg1);
		F1757_15933(Current, tr1, loc1, arg2);
		RTCT0("attached last_evaluated_document as l_last_evaluated_document", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc9 = tr1;
		if (EIF_TEST(loc9)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13396[Dtype(loc9)-1819])(loc9);
		loc10 = tr1;
		if (EIF_TEST(loc10)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			F1710_14690(RTCW(tr1), loc10);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1694,0xFF01,1852,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNS(typres0.id, 1694, _OBJSIZ_3_1_0_1_0_0_0_0_);
			}
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
		} else {
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13419[Dtype(loc9)-1819])(loc9);
			tb1 = F1707_14603(RTCW(loc2));
			if (tb1) {
				tr1 = F1758_15945(Current, loc2, loc3);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) == NULL)) {
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1694,0xFF01,1852,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						loc6 = RTLNS(typres0.id, 1694, _OBJSIZ_3_1_0_1_0_0_0_0_);
					}
					RTAR(Current, loc6);
					*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc6;
					RTCT0("attached fragment_error_value as l_fragment_error_value", EX_CHECK);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					loc11 = tr1;
					if (EIF_TEST(loc11)) {
						RTCK0;
					} else {
						RTCF0;
					}
					F1636_13762(RTCW(loc6), loc11);
				}
			} else {
				tr1 = RTLNS(eif_new_type(1695, 0x01).id, 1695, _OBJSIZ_4_2_0_1_0_0_0_0_);
				F1673_14197(RTCW(tr1), loc3);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
			}
		}
	}
	RTLE;
}

/* {XM_XSLT_DOCUMENT_INFORMATION}.fragment */
EIF_REFERENCE F1758_15945 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(14);
	RTLR(0,loc8);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc6);
	RTLR(5,Current);
	RTLR(6,loc1);
	RTLR(7,loc3);
	RTLR(8,arg2);
	RTLR(9,Result);
	RTLR(10,loc4);
	RTLR(11,loc7);
	RTLR(12,tr2);
	RTLR(13,tr3);
	RTLIU(14);
	
	RTGC;
	RTCT0("precondition_has_fragment", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = F1252_10618(loc8);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		loc6 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		if ((EIF_BOOLEAN)(loc6 == NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			loc6 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
			RTAR(Current, loc6);
			*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc6;
		}
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			tr1 = F1707_14605(RTCW(arg1));
			loc1 = RTOSCF(15701,F1750_15701, (RTCW(loc6), tr1));
		}
		loc3 = *(EIF_REFERENCE *)(RTCW(loc6) + _REFACS_13_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc6)+ _CHROFF_17_6_);
		F1255_10631(RTCW(loc3), loc1, tb1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_0_0_);
		if (tb1) {
			Result = F1758_15946(Current, loc2, arg2);
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN)(Result == NULL);
		} else {
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_0_1_);
			if (tb1) {
				loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R13698[Dtype(RTCW(arg2))-1863])(arg2, loc2);
				if ((EIF_BOOLEAN)(loc4 == NULL)) {
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					Result = RTLNS(eif_new_type(1695, 0x01).id, 1695, _OBJSIZ_4_2_0_1_0_0_0_0_);
					F1673_14197(RTCW(Result), loc4);
				}
			} else {
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	if (loc5) {
		loc7 = RTLNSMART(eif_new_type(1708, 0).id);
		tr1 = RTMS_EX_H("Media-type is not recognized, or the fragment identifier does not conform to the rules for the media-type",105,216773221);
		tr2 = RTOSCF(9827,F1230_9827, (Current));
		tr3 = RTMS_EX_H("XTRE1160",8,336320560);
		F1709_14669(RTCW(loc7), tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
		RTAR(Current, loc7);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc7;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1710_14690(RTCW(tr1), loc7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_33_0_);
		if ((EIF_BOOLEAN) !tb1) {
			Result = RTLNS(eif_new_type(1695, 0x01).id, 1695, _OBJSIZ_4_2_0_1_0_0_0_0_);
			F1673_14197(RTCW(Result), arg2);
		}
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_DOCUMENT_INFORMATION}.xpointer_fragment */
EIF_REFERENCE F1758_15946 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(17);
	RTLR(0,loc1);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLR(6,loc10);
	RTLR(7,tr1);
	RTLR(8,loc5);
	RTLR(9,loc8);
	RTLR(10,Current);
	RTLR(11,tr2);
	RTLR(12,tr3);
	RTLR(13,loc7);
	RTLR(14,loc6);
	RTLR(15,loc9);
	RTLR(16,Result);
	RTLIU(17);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1565, 0x01).id, 1565, _OBJSIZ_3_1_0_0_0_0_0_0_);
	F1566_12783(RTCW(loc1), (EIF_BOOLEAN) 0);
	loc2 = RTLNS(eif_new_type(1851, 0x01).id, 1851, _OBJSIZ_2_4_0_0_0_0_0_0_);
	loc3 = RTLNS(eif_new_type(1231, 0x01).id, 1231, _OBJSIZ_2_4_0_0_0_0_0_0_);
	F1232_10157(RTCW(loc3));
	loc4 = RTLNS(eif_new_type(1564, 0x01).id, 1564, _OBJSIZ_2_3_0_0_0_0_0_0_);
	F1566_12790(RTCW(loc1), loc2);
	F1566_12790(RTCW(loc1), loc4);
	F1566_12790(RTCW(loc1), loc3);
	F1566_12789(RTCW(loc1), arg1, arg2);
	RTCT0("postcondition_of_evaluate", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc5 = (EIF_REFERENCE) loc10;
	tb1 = '\01';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13834[Dtype(RTCW(loc5))-1868])(loc5);
	if (!tb2) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13902[Dtype(RTCW(loc5))-1868])(loc5);
		tb1 = tb2;
	}
	if (tb1) {
		loc8 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
		tr1 = RTMS_EX_H("XPointer reported an error",26,812541298);
		tr2 = RTOSCF(9827,F1230_9827, (Current));
		tr3 = RTMS_EX_H("XTRE1160",8,336320560);
		F1709_14669(RTCW(loc8), tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1710_14690(RTCW(tr1), loc8);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_33_0_);
		if ((EIF_BOOLEAN) !tb1) {
			loc7 = (EIF_REFERENCE) arg2;
		}
	} else {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13903[Dtype(RTCW(loc5))-1868])(loc5);
		if ((EIF_BOOLEAN) !tb1) {
			loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13985[Dtype(RTCW(loc5))-1868])(loc5);
			tb1 = F1875_18173(RTCW(loc6));
			if (tb1) {
				loc9 = F1875_18180(RTCW(loc6), (EIF_BOOLEAN) 0);
			} else {
				loc8 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
				tr1 = RTMS_EX_H("XPointer returned something other than a sequence of nodes",58,340154483);
				tr2 = RTOSCF(9827,F1230_9827, (Current));
				tr3 = RTMS_EX_H("XTRE1160",8,336320560);
				F1709_14669(RTCW(loc8), tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				F1710_14690(RTCW(tr1), loc8);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_33_0_);
				if ((EIF_BOOLEAN) !tb1) {
					loc7 = (EIF_REFERENCE) arg2;
				}
			}
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13984[Dtype(RTCW(loc5))-1868])(loc5);
			loc7 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_6_);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_33_0_);
	if ((EIF_BOOLEAN) !tb1) {
		if ((EIF_BOOLEAN)(loc9 == NULL)) {
			Result = RTLNS(eif_new_type(1695, 0x01).id, 1695, _OBJSIZ_4_2_0_1_0_0_0_0_);
			F1673_14197(RTCW(Result), loc7);
		} else {
			Result = (EIF_REFERENCE) loc9;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit831 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
