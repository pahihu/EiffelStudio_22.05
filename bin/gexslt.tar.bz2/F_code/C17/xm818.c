/*
 * Code for class XM_XSLT_HTML_INDENTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm818.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_HTML_INDENTER}.make */
void F1745_15476 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_22_17_0_0_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_8_0_0_) = (EIF_INTEGER_32) ti4_1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O11855[Dtype(tr1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O11856[Dtype(tr1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1503,1035,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1504_12127(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_HTML_INDENTER}.start_element */
void F1745_15477 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R12012[Dtype(Current)-1744])(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1504_12140(RTCW(tr1), loc1);
	tb1 = F1745_15496(Current, loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_) = (EIF_BOOLEAN) tb1;
	tb1 = '\01';
	if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_)) {
		tb1 = F1745_15497(Current, loc1);
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_) = (EIF_BOOLEAN) tb1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_6_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_))) {
		F1745_15494(Current);
	}
	F1734_15320(Current, arg1, arg2, arg3);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_8_0_1_))++;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {XM_XSLT_HTML_INDENTER}.end_element */
void F1745_15478 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_8_0_1_))--;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = F1504_12132(RTCW(tr1));
	loc2 = F1745_15496(Current, loc1);
	loc3 = F1745_15497(Current, loc1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc2 && (EIF_BOOLEAN) !loc3) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_6_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_))) {
		F1745_15494(Current);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_) = (EIF_BOOLEAN) loc3;
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_6_) = (EIF_BOOLEAN) loc2;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1504_12144(RTCW(tr1));
	F1734_15324(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_) && (EIF_BOOLEAN) !loc3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {XM_XSLT_HTML_INDENTER}.notify_characters */
void F1745_15479 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\01';
	if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_)) {
		tb1 = F1412_11674(Current, arg2);
	}
	if (tb1) {
		F1734_15325(Current, arg1, arg2);
	} else {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (loc2 > ti4_1)) break;
			tb1 = '\01';
			ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc2);
			if (!(EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 10L))) {
				tb2 = '\0';
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 - loc1) > ((EIF_INTEGER_32) 120L))) {
					ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc2);
					tb2 = (EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 32L));
				}
				tb1 = tb2;
			}
			if (tb1) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
				F1734_15325(Current, tr1, arg2);
				F1745_15494(Current);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				for (;;) {
					tb1 = '\01';
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
					if (!(EIF_BOOLEAN) (loc1 > ti4_2)) {
						ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc1);
						tb1 = (EIF_BOOLEAN)(ti4_2 != ((EIF_INTEGER_32) 32L));
					}
					if (tb1) break;
					loc1++;
				}
			}
			loc2++;
		}
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc1 <= ti4_2)) {
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, ti4_2);
			F1734_15325(Current, tr1, arg2);
		}
	}
	F1734_15315(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {XM_XSLT_HTML_INDENTER}.notify_comment */
void F1745_15480 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1745_15494(Current);
	F1734_15327(Current, arg1, arg2);
	RTLE;
}

/* {XM_XSLT_HTML_INDENTER}.indentation_characters */

EIF_REFERENCE F1745_15487 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15487,RTMS_EX_H("                                                                                   ",83,1325751072));
}

/* {XM_XSLT_HTML_INDENTER}.inline_tags */
static EIF_REFERENCE F1745_15492_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15492);
#define Result RTOSR(15492)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1521,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1521, _OBJSIZ_7_0_0_9_0_0_0_0_);
	}
	F1509_12240(RTCW(tr1), ((EIF_INTEGER_32) 40L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8115,F1125_8115, (Current));
	F1439_11749(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("tt",2,29812);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("i",1,105);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("b",1,98);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("u",1,117);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("s",1,115);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("strike",6,2146501477);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("big",3,6449511);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("small",5,1835984492);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("em",2,25965);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("strong",6,2146895463);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("dfn",3,6579822);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("code",4,1668244581);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("samp",4,1935764848);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("kbd",3,7037540);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("var",3,7758194);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("cite",4,1667855461);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("abbr",4,1633837682);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("acronym",7,1494691437);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("a",1,97);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("img",3,6909287);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("applet",6,2077721972);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("object",6,2004017012);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("font",4,1718578804);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("basefont",8,1397695860);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("br",2,25202);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("script",6,2146372212);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("map",3,7168368);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("q",1,113);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("sub",3,7566690);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("sup",3,7566704);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("span",4,1936744814);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("bdo",3,6448239);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("iframe",6,2126209381);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("input",5,1853670260);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("select",6,2045458804);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("textarea",8,1193882977);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("label",5,1634667884);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("button",6,2147362158);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("ins",3,6909555);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("del",3,6579564);
	F1516_12342(RTCW(Result), tr1);
	RTOSE (15492);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1745_15492 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15492,F1745_15492_body,(Current));
}

/* {XM_XSLT_HTML_INDENTER}.formatted_tags */
static EIF_REFERENCE F1745_15493_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15493);
#define Result RTOSR(15493)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1521,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1521, _OBJSIZ_7_0_0_9_0_0_0_0_);
	}
	F1509_12240(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8115,F1125_8115, (Current));
	F1439_11749(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("pre",3,7369317);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("script",6,2146372212);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("style",5,1954997861);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("textarea",8,1193882977);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("xmp",3,7892336);
	F1516_12342(RTCW(Result), tr1);
	RTOSE (15493);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1745_15493 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15493,F1745_15493_body,(Current));
}

/* {XM_XSLT_HTML_INDENTER}.indent */
void F1745_15494 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_8_0_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_8_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 * ti4_1);
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(15487,F1745_15487, (Current)))+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc1 <= ti4_1)) break;
		tr1 = RTOSCF(15487,F1745_15487, (Current));
		tr2 = RTOSCF(15487,F1745_15487, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(tr1))-1112])(tr1, tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTMS_EX_H("\012",1,10);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, tr2, ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTOSCF(15487,F1745_15487, (Current));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(tr2))-1111])(tr2, ((EIF_INTEGER_32) 1L), loc1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, tr2, ((EIF_INTEGER_32) 0L));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {XM_XSLT_HTML_INDENTER}.tag_properties */
EIF_INTEGER_32 F1745_15495 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(4950,F991_4950, (Current));
	ti4_1 = F1242_10447(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tr1 = F1242_10450(RTCW(tr1), arg1);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(tr1))-1112])(tr1);
		tr1 = RTOSCF(15492,F1745_15492, (Current));
		loc2 = F1516_12336(RTCW(tr1), loc3);
		tr1 = RTOSCF(15493,F1745_15493, (Current));
		loc1 = F1516_12336(RTCW(tr1), loc3);
		if (loc2) {
			Result += ((EIF_INTEGER_32) 1L);
		}
		if (loc1) {
			RTLE;
			return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 2L));
		}
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_HTML_INDENTER}.is_inline_property */
EIF_BOOLEAN F1745_15496 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L)) || (EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + ((EIF_INTEGER_32) 2L))));
}

/* {XM_XSLT_HTML_INDENTER}.is_formatted_property */
EIF_BOOLEAN F1745_15497 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + ((EIF_INTEGER_32) 2L))));
}

void EIF_Minit818 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
