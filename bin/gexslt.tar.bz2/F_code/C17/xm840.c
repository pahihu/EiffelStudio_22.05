/*
 * Code for class XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm840.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.make */
void F1767_16145 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLR(6,arg3);
	RTLR(7,loc1);
	RTLR(8,loc2);
	RTLIU(9);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1748, 1).id);
	F1749_15655(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1279, 1).id);
	tr2 = F1721_15176(RTCV(RTOSCF(3564,F460_3564, (Current))));
	tr3 = F1721_15176(RTCV(RTOSCF(3565,F460_3565, (Current))));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R10685[Dtype(RTCW(tr2))-1615])(tr2, tr3);
	F1280_10995(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	F1766_16096(Current, arg1);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg3;
	tr1 = RTLNS(eif_new_type(185, 0x01).id, 185, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1125, 1).id);
	F1126_8116(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(1393, 0x01).id, 1393, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1394_11501(RTCW(loc1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1126_8123(RTCW(tr1), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1536,0xFF01,1576,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1525_12401(RTCW(tr1), ((EIF_INTEGER_32) 1L), NULL, tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	loc2 = RTLNS(eif_new_type(1576, 0x01).id, 1576, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOSCF(9833,F1230_9833, (Current));
	F1525_12420(RTCW(tr1), loc2, tr2);
	RTLE;
}

/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.make_restricted */
void F1767_16146 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,arg1);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_14_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = RTLNSMART(eif_new_type(1748, 1).id);
	F1749_15655(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1279, 1).id);
	tr2 = F1721_15176(RTCV(RTOSCF(3564,F460_3564, (Current))));
	tr3 = F1721_15176(RTCV(RTOSCF(3565,F460_3565, (Current))));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R10685[Dtype(RTCW(tr2))-1615])(tr2, tr3);
	F1280_10995(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(1619, 0x01).id, 1619, _OBJSIZ_0_0_0_2_0_0_0_0_);
	F1620_13634(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	tr1 = RTOSCF(3565,F460_3565, (Current));
	F1722_15184(RTCW(tr1), loc1);
	loc2 = RTLNS(eif_new_type(1279, 0x01).id, 1279, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
	F1280_10995(RTCW(loc2), tr1);
	tr1 = RTLNSMART(eif_new_type(1153, 0).id);
	F1153_8477(RTCW(tr1), loc1, loc2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	F1766_16142(Current);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) NULL;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg1;
	tr1 = RTLNS(eif_new_type(185, 0x01).id, 185, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1125, 1).id);
	F1126_8116(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	loc3 = RTLNS(eif_new_type(1393, 0x01).id, 1393, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1394_11501(RTCW(loc3));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1126_8123(RTCW(tr1), loc3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1536,0xFF01,1576,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1525_12401(RTCW(tr1), ((EIF_INTEGER_32) 1L), NULL, tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	loc4 = RTLNS(eif_new_type(1576, 0x01).id, 1576, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOSCF(9833,F1230_9833, (Current));
	F1525_12420(RTCW(tr1), loc4, tr2);
	RTLE;
}

/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.configuration */
EIF_REFERENCE F1767_16147 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_13_);
}


/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.local_variable_frame */
EIF_REFERENCE F1767_16148 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_12_);
}


/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.available_functions */
EIF_REFERENCE F1767_16149 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_11_);
}


/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.available_documents */
EIF_REFERENCE F1767_16150 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_10_);
}


/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.last_parsed_document */
EIF_REFERENCE F1767_16151 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_9_);
}


/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.last_parsed_media_type */
EIF_REFERENCE F1767_16152 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_8_);
}


/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.security_manager */
EIF_REFERENCE F1767_16153 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_7_);
}


/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.implicit_timezone */
EIF_REFERENCE F1767_16154 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_6_);
}


/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.has_push_processing */
EIF_BOOLEAN F1767_16155 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_14_5_);
}


/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.last_build_error */
EIF_REFERENCE F1767_16157 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_5_);
}


/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.is_process_error */
EIF_BOOLEAN F1767_16158 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_14_3_);
}


/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.new_minor_context */
EIF_REFERENCE F1767_16159 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	RTCT0("False", EX_CHECK);
		RTCF0;
	return (EIF_REFERENCE) 0;
}

/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.set_stack_frame */
void F1767_16162 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) arg1;
}

/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.open_stack_frame */
void F1767_16163 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,1869,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	F880_4366(RTCW(loc1), NULL, ((EIF_INTEGER_32) 1L), ti4_1);
	tr1 = RTLNSMART(eif_new_type(21, 0).id);
	F22_188(RTCW(tr1), arg1, loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.build_document */
void F1767_16165 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc5);
	RTLR(4,loc6);
	RTLR(5,loc7);
	RTLR(6,loc1);
	RTLR(7,loc2);
	RTLR(8,loc4);
	RTLR(9,loc3);
	RTLR(10,loc8);
	RTLIU(11);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_14_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1126_8127(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tb1 = F1126_8136(RTCW(tr1));
	if (tb1) {
		RTCT0("invariant_of_uri_resolver", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr1 = F1126_8137(RTCW(tr1));
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1767_16169(Current, loc5);
	} else {
		RTCT0("invariant_of_uri_resolver", EX_CHECK);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr1 = F1126_8135(RTCW(tr1));
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr1 = F1126_8134(RTCW(tr1));
			loc7 = tr1;
			tb1 = EIF_TEST(loc7);
		}
		if (tb1) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb1 = F1126_8138(RTCW(tr1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr1 = F1126_8139(RTCW(tr1));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
		}
		loc1 = F1725_15195(Current);
		loc2 = RTLNS(eif_new_type(1719, 0x01).id, 1719, _OBJSIZ_45_3_0_35_0_0_0_0_);
		F1719_15014(RTCW(loc2));
		F1408_11618(RTCW(loc2), Current);
		F1409_11634(RTCW(loc2), loc1);
		loc4 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
		F1707_14586(RTCW(loc4), arg1);
		loc3 = RTLNS(eif_new_type(1246, 0x01).id, 1246, _OBJSIZ_7_0_0_0_0_0_0_0_);
		F1247_10506(RTCW(loc3), loc2, (EIF_BOOLEAN) 1, arg1, loc4);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
		F256_2145(RTCW(loc2), tr1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_5_);
		F323_2439(RTCW(loc2), tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2020[Dtype(RTCW(loc1))-1125])(loc1, loc6);
		F1719_15018(RTCW(loc2), loc7);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_3_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2013[Dtype(RTCW(tr1))-252])(tr1);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1672[Dtype(loc7)-1166])(loc7);
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R1679[Dtype(loc7)-1166])(loc7);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_6_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		loc8 = tr1;
		if (EIF_TEST(loc8)) {
			F1767_16169(Current, loc8);
		} else {
			tr1 = F1247_10514(RTCW(loc3));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.change_to_sequence_output_destination */
void F1767_16166 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.report_fatal_error */
void F1767_16167 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {XM_XPATH_STAND_ALONE_DYNAMIC_CONTEXT}.set_build_error */
void F1767_16169 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_14_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

void EIF_Minit840 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
