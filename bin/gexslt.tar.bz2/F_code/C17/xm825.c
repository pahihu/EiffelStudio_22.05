/*
 * Code for class XM_XSLT_SUB_PICTURE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm825.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_SUB_PICTURE}.make */
void F1752_15742 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1506,1035,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1507_12159(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1506,1035,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1507_12159(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F1752_15761(Current, arg1, arg2);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_3_)) {
		F1752_15762(Current);
	}
	RTLE;
}

/* {XM_XSLT_SUB_PICTURE}.formatted_number */
EIF_REFERENCE F1752_15753 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLR(5,Result);
	RTLR(6,arg3);
	RTLR(7,loc2);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14156[Dtype(RTCW(arg1))-1898])(arg1);
	if (tb1) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_4_);
		Result = F1148_8367(RTCW(tr1), *(EIF_REFERENCE *)(Current), tr2);
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr1 = F1148_8377(RTCW(tr1), Result, *(EIF_REFERENCE *)(Current + _REFACS_1_));
		Result = (EIF_REFERENCE) tr1;
	} else {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14159[Dtype(RTCW(arg1))-1898])(arg1);
		if (tb1) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			Result = F1148_8367(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg3);
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
			tr1 = F1148_8377(RTCW(tr1), Result, tr2);
			Result = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr1 = F1148_8377(RTCW(tr1), Result, *(EIF_REFERENCE *)(Current + _REFACS_1_));
			Result = (EIF_REFERENCE) tr1;
		} else {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_)) {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100L);
			} else {
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_)) {
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1000L);
				}
			}
			if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 1L))) {
				loc2 = (EIF_REFERENCE) arg1;
			} else {
				loc3 = RTLNS(eif_new_type(1899, 0x01).id, 1899, _OBJSIZ_8_37_0_1_0_0_0_0_);
				F1900_18618(RTCW(loc3), loc1);
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) R14164[Dtype(RTCW(arg1))-1898])(arg1, ((EIF_INTEGER_32) 17L), loc3);
			}
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13407[Dtype(RTCW(loc2))-1819])(loc2);
			if (tb1) {
				tr8_1 = (FUNCTION_CAST(EIF_REAL_64, (EIF_REFERENCE)) R14155[Dtype(RTCW(loc2))-1898])(loc2);
				Result = F1752_15765(Current, tr8_1);
			} else {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13879[Dtype(RTCW(loc2))-1868])(loc2);
				if (tb1) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14026[Dtype(RTCW(loc2))-1868])(loc2);
					Result = F1752_15764(Current, tr1);
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13998[Dtype(RTCW(loc2))-1868])(loc2);
					Result = F1752_15763(Current, tr1);
				}
			}
			tr1 = F1752_15766(Current, Result, arg2);
			Result = (EIF_REFERENCE) tr1;
			tr1 = F1752_15767(Current, Result, arg2);
			Result = (EIF_REFERENCE) tr1;
			tr1 = F1752_15769(Current, Result, arg2);
			Result = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr1 = F1148_8367(RTCW(tr1), *(EIF_REFERENCE *)(Current), Result);
			Result = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr1 = F1148_8367(RTCW(tr1), arg3, Result);
			Result = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr1 = F1148_8377(RTCW(tr1), Result, *(EIF_REFERENCE *)(Current + _REFACS_1_));
			Result = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_SUB_PICTURE}.set_last_error_from_string */
void F1752_15760 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1708, 0).id);
	F1709_14669(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XSLT_SUB_PICTURE}.scan_picture_string */
void F1752_15761 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_6_);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(tr1))-1112])(tr1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_5_);
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(tr1))-1112])(tr1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
	loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(tr1))-1112])(tr1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
	loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(tr1))-1112])(tr1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_8_);
	loc6 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(tr1))-1112])(tr1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_7_);
	loc7 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(tr1))-1112])(tr1, ((EIF_INTEGER_32) 1L));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_7_3_)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
		}
		if (tb1) break;
		loc8 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc1);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc8 == loc2) || (EIF_BOOLEAN)(loc8 == loc3))) {
			if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_))) {
				tr1 = RTMS_EX_H("Cannot have more than one percent or per-mille character in a sub-picture",73,840641381);
				tr2 = RTOSCF(9827,F1230_9827, (Current));
				tr3 = RTMS_EX_H("XTDE1310",8,308925232);
				F1752_15760(Current, tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
			}
			*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc8 == loc3);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc8 == loc2);
			switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_)) {
				case 0L:
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = *(EIF_REFERENCE *)(Current);
					tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, loc1);
					tr1 = F1148_8377(RTCW(tr1), tr2, tr3);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
					break;
				case 1L:
				case 2L:
				case 3L:
				case 4L:
				case 5L:
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, loc1);
					tr1 = F1148_8377(RTCW(tr1), tr2, tr3);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
					break;
				default:
					RTEC(EN_WHEN);
			}
		} else {
			if ((EIF_BOOLEAN)(loc8 == loc6)) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_)) {
					case 0L:
					case 1L:
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_0_))++;
						break;
					case 2L:
						tr1 = RTMS_EX_H("Digit sign must not appear after a zero-digit sign in the integer part of a sub-picture",87,1994180453);
						tr2 = RTOSCF(9827,F1230_9827, (Current));
						tr3 = RTMS_EX_H("XTDE1310",8,308925232);
						F1752_15760(Current, tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
						break;
					case 3L:
					case 4L:
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_2_))++;
						break;
					case 5L:
						tr1 = RTMS_EX_H("Passive character must not appear between active characters in a sub-picture",76,835191397);
						tr2 = RTOSCF(9827,F1230_9827, (Current));
						tr3 = RTMS_EX_H("XTDE1310",8,308925232);
						F1752_15760(Current, tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
						break;
					default:
						RTEC(EN_WHEN);
				}
			} else {
				if ((EIF_BOOLEAN)(loc8 == loc7)) {
					*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_)) {
						case 0L:
						case 1L:
						case 2L:
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_0_))++;
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_1_))++;
							break;
						case 3L:
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_2_))++;
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_3_))++;
							break;
						case 4L:
							tr1 = RTMS_EX_H("Zero digit sign must not appear after a digit sign in the fractional part of a sub-picture",90,1466549605);
							tr2 = RTOSCF(9827,F1230_9827, (Current));
							tr3 = RTMS_EX_H("XTDE1310",8,308925232);
							F1752_15760(Current, tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
							break;
						case 5L:
							tr1 = RTMS_EX_H("Passive character must not appear between active characters in a sub-picture",76,835191397);
							tr2 = RTOSCF(9827,F1230_9827, (Current));
							tr3 = RTMS_EX_H("XTDE1310",8,308925232);
							F1752_15760(Current, tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
							break;
						default:
							RTEC(EN_WHEN);
					}
				} else {
					if ((EIF_BOOLEAN)(loc8 == loc4)) {
						switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_)) {
							case 0L:
							case 1L:
							case 2L:
								*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
								break;
							case 3L:
							case 4L:
							case 5L:
								tr1 = RTMS_EX_H("There must only be one decimal separator in a sub-picture",57,870548325);
								tr2 = RTOSCF(9827,F1230_9827, (Current));
								tr3 = RTMS_EX_H("XTDE1310",8,308925232);
								F1752_15760(Current, tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
								break;
							default:
								RTEC(EN_WHEN);
						}
					} else {
						if ((EIF_BOOLEAN)(loc8 == loc5)) {
							switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_)) {
								case 0L:
								case 1L:
								case 2L:
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									F1507_12183(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_0_));
									break;
								case 3L:
								case 4L:
									if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_2_) == ((EIF_INTEGER_32) 0L))) {
										tr1 = RTMS_EX_H("Grouping separator cannot be adjacent to decimal separator",58,910152050);
										tr2 = RTOSCF(9827,F1230_9827, (Current));
										tr3 = RTMS_EX_H("XTDE1310",8,308925232);
										F1752_15760(Current, tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
									} else {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
										F1507_12183(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_2_));
									}
									break;
								case 5L:
									tr1 = RTMS_EX_H("Grouping separator found in suffix of sub-picture",49,1041387109);
									tr2 = RTOSCF(9827,F1230_9827, (Current));
									tr3 = RTMS_EX_H("XTDE1310",8,308925232);
									F1752_15760(Current, tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
									break;
								default:
									RTEC(EN_WHEN);
							}
						} else {
							switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_)) {
								case 0L:
									tr1 = RTOSCF(8530,F1163_8530, (Current));
									tr2 = *(EIF_REFERENCE *)(Current);
									tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, loc1);
									tr1 = F1148_8377(RTCW(tr1), tr2, tr3);
									RTAR(Current, tr1);
									*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
									break;
								case 1L:
								case 2L:
								case 3L:
								case 4L:
								case 5L:
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
									tr1 = RTOSCF(8530,F1163_8530, (Current));
									tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, loc1);
									tr1 = F1148_8377(RTCW(tr1), tr2, tr3);
									RTAR(Current, tr1);
									*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
									break;
								default:
									RTEC(EN_WHEN);
							}
						}
					}
				}
			}
		}
		loc1++;
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_3_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_))) {
		tr1 = RTMS_EX_H("Sub-picture must contain at least one digit sign or zero digit sign\?",68,1598168895);
		tr2 = RTOSCF(9827,F1230_9827, (Current));
		tr3 = RTMS_EX_H("XTDE1310",8,308925232);
		F1752_15760(Current, tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
	}
	RTLE;
}

/* {XM_XSLT_SUB_PICTURE}.calculate_grouping_positions */
void F1752_15762 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc5);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc6);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		{
			static EIF_TYPE_INDEX typarr0[] = {880,1035,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc5 = RTLNSMART(typres0.id);
		}
		F881_4366(RTCW(loc5), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), loc1);
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc5;
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc2 > loc1)) break;
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			ti4_2 = F1507_12165(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - loc2) + ((EIF_INTEGER_32) 1L)));
			F881_4390(RTCW(loc5), (EIF_INTEGER_32) (ti4_1 - ti4_2), loc2);
			loc2++;
		}
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L))) {
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc3 = F881_4371(RTCW(loc5), ((EIF_INTEGER_32) 1L));
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc4 || (EIF_BOOLEAN) (loc2 > loc1))) break;
				ti4_1 = F881_4371(RTCW(loc5), loc2);
				if ((EIF_BOOLEAN)(ti4_1 != (EIF_INTEGER_32) (loc3 * loc2))) {
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
				loc2++;
			}
			if (loc4) {
				{
					static EIF_TYPE_INDEX typarr0[] = {880,1035,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					loc5 = RTLNSMART(typres0.id);
				}
				F881_4366(RTCW(loc5), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
				RTAR(Current, loc5);
				*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc5;
				F881_4390(RTCW(loc5), loc3, ((EIF_INTEGER_32) 1L));
			}
		}
		ti4_1 = F881_4371(RTCW(loc5), ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			tr1 = RTMS_EX_H("Grouping separator cannot be adjacent to decimal separator",58,910152050);
			tr2 = RTOSCF(9827,F1230_9827, (Current));
			tr3 = RTMS_EX_H("XTDE1310",8,308925232);
			F1752_15760(Current, tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		{
			static EIF_TYPE_INDEX typarr0[] = {880,1035,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc6 = RTLNSMART(typres0.id);
		}
		F881_4366(RTCW(loc6), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), loc1);
		RTAR(Current, loc6);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc6;
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			ti4_1 = F881_4378(RTCW(loc6));
			if ((EIF_BOOLEAN) (loc2 > ti4_1)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			ti4_2 = F1507_12165(RTCW(tr1), loc2);
			F881_4390(RTCW(loc6), ti4_2, loc2);
			loc2++;
		}
	}
	RTLE;
}

/* {XM_XSLT_SUB_PICTURE}.formatted_decimal */
EIF_REFERENCE F1752_15763 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	loc1 = F1899_18612(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_2_));
	Result = F1899_18598(RTCW(loc1));
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(Result))-1111])(Result, (EIF_CHARACTER_8) '.', ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ti4_1);
	} else {
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - loc3) + ((EIF_INTEGER_32) 1L));
	}
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		loc4 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1111_6439(RTCW(loc4), (EIF_CHARACTER_8) '0', loc2);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(loc4))-1111])(loc4, Result);
		Result = (EIF_REFERENCE) tr1;
		loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(Result))-1111])(Result, (EIF_CHARACTER_8) '.', ((EIF_INTEGER_32) 1L));
	}
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_3_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - (EIF_INTEGER_32) (ti4_1 - loc3));
	} else {
		tr1 = RTMS_EX_H(".",1,46);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
		Result = (EIF_REFERENCE) tr1;
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_3_);
	}
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		loc4 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1111_6439(RTCW(loc4), (EIF_CHARACTER_8) '0', loc2);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, loc4);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_SUB_PICTURE}.formatted_integer */
EIF_REFERENCE F1752_15764 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	Result = F1903_18715(RTCW(arg1));
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		loc2 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1111_6439(RTCW(loc2), (EIF_CHARACTER_8) '0', loc1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(loc2))-1111])(loc2, Result);
		Result = (EIF_REFERENCE) tr1;
	}
	loc2 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1111_6439(RTCW(loc2), (EIF_CHARACTER_8) '0', *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_3_));
	tr1 = RTMS_EX_H(".",1,46);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, loc2);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {XM_XSLT_SUB_PICTURE}.formatted_double */
EIF_REFERENCE F1752_15765 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLR(5,loc5);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	tr1 = eif_out__r8_s1(arg1);
	F1748_15539(RTCW(loc1), tr1);
	loc2 = RTLNS(eif_new_type(1898, 0x01).id, 1898, _OBJSIZ_8_37_0_1_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_2_);
	tr1 = RTOSCF(15739,F1751_15739, (Current));
	tr1 = F1748_15595(RTCW(loc1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 0L) - ti4_1), tr1);
	F1899_18586(RTCW(loc2), tr1);
	Result = F1899_18598(RTCW(loc2));
	loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(Result))-1111])(Result, (EIF_CHARACTER_8) '.', ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ti4_1);
	} else {
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_1_);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - loc4) + ((EIF_INTEGER_32) 1L));
	}
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		loc5 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1111_6439(RTCW(loc5), (EIF_CHARACTER_8) '0', loc3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, loc5);
		Result = (EIF_REFERENCE) tr1;
	}
	if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_3_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - ti4_1) + loc4);
	} else {
		tr1 = RTMS_EX_H(".",1,46);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
		Result = (EIF_REFERENCE) tr1;
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_3_);
	}
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		loc5 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1111_6439(RTCW(loc5), (EIF_CHARACTER_8) '0', loc3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, loc5);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_SUB_PICTURE}.mapped_formatted_number */
EIF_REFERENCE F1752_15766 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg1))-1111])(arg1, (EIF_CHARACTER_8) '.', ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_2_) == ((EIF_INTEGER_32) 0L))) {
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
	} else {
		Result = (EIF_REFERENCE) arg1;
	}
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = *(EIF_REFERENCE *)(RTCW(arg2));
	tr3 = RTMS_EX_H(".",1,46);
	tb1 = F1148_8369(RTCW(tr1), tr2, tr3);
	if ((EIF_BOOLEAN) !tb1) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc1 <= ti4_1)) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(arg2));
			tr1 = F1148_8379(RTCW(tr1), Result, tr2, loc1, loc1);
			Result = (EIF_REFERENCE) tr1;
		}
	}
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_7_);
	tr3 = RTMS_EX_H("0",1,48);
	tb1 = F1148_8369(RTCW(tr1), tr2, tr3);
	if ((EIF_BOOLEAN) !tb1) {
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc5 = RTMS_EX_H("",0,0);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_7_);
		loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(tr1))-1112])(tr1, ((EIF_INTEGER_32) 1L));
		for (;;) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (loc2 > ti4_1)) break;
			loc6 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(Result))-852])(Result, loc2));
			loc3 = (EIF_INTEGER_32) (loc6);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 >= ((EIF_INTEGER_32) 48L)) && (EIF_BOOLEAN) (loc3 <= ((EIF_INTEGER_32) 57L)))) {
				loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 48L)));
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(4819,F984_4819, (Current));
				tr2 = F1708_14666(RTCW(tr2), loc3);
				tr1 = F1148_8377(RTCW(tr1), loc5, tr2);
				loc5 = (EIF_REFERENCE) tr1;
			} else {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(Result))-1111])(Result, loc2, loc2);
				tr1 = F1148_8377(RTCW(tr1), loc5, tr2);
				loc5 = (EIF_REFERENCE) tr1;
			}
			loc2++;
		}
		Result = (EIF_REFERENCE) loc5;
	}
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(Result))-852])(Result, ti4_2));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
	tc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(tr1))-852])(tr1, ((EIF_INTEGER_32) 1L)));
	if ((EIF_BOOLEAN)(tc1 == tc2)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5117[Dtype(RTCW(Result))-1112])(Result, ((EIF_INTEGER_32) 1L));
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_SUB_PICTURE}.grouped_formatted_number */
EIF_REFERENCE F1752_15767 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,loc7);
	RTLR(4,Current);
	RTLR(5,loc6);
	RTLR(6,tr2);
	RTLR(7,Result);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
	tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(tr1))-852])(tr1, ((EIF_INTEGER_32) 1L)));
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg1))-1111])(arg1, tc1, ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		ti4_1 = F881_4378(loc7);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc3 = F881_4371(loc7, ((EIF_INTEGER_32) 1L));
			loc6 = RTMS_EX_H("",0,0);
			for (;;) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
				tb1 = '\0';
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN) (loc1 < loc2)) && (EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L)))) {
					tr1 = RTOSCF(6771,F1118_6771, (Current));
					ti4_2 = F1174_8736(RTCW(tr1), (EIF_INTEGER_32) (loc2 - loc1), loc3);
					tb1 = (EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 0L));
				}
				if (tb1) {
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
					tr1 = F1148_8377(RTCW(tr1), loc6, tr2);
					loc6 = (EIF_REFERENCE) tr1;
				}
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, loc1);
				tr1 = F1148_8377(RTCW(tr1), loc6, tr2);
				loc6 = (EIF_REFERENCE) tr1;
				if ((EIF_BOOLEAN) (loc1 < loc2)) {
					loc5++;
				}
				loc1++;
			}
			Result = (EIF_REFERENCE) loc6;
		} else {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc3 = F881_4378(loc7);
			loc6 = RTMS_EX_H("",0,0);
			for (;;) {
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (loc1 > ti4_2)) break;
				if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
					loc4 = F881_4371(loc7, loc3);
				} else {
					loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				}
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 < loc2) && (EIF_BOOLEAN)((EIF_INTEGER_32) (loc2 - loc1) == loc4))) {
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
					tr1 = F1148_8377(RTCW(tr1), loc6, tr2);
					loc6 = (EIF_REFERENCE) tr1;
					loc4++;
					if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
						loc3--;
					}
				}
				if ((EIF_BOOLEAN) (loc1 < loc2)) {
					loc5++;
				}
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, loc1);
				tr1 = F1148_8377(RTCW(tr1), loc6, tr2);
				loc6 = (EIF_REFERENCE) tr1;
				loc1++;
			}
			Result = (EIF_REFERENCE) loc6;
		}
	} else {
		loc5 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - loc2);
		Result = (EIF_REFERENCE) arg1;
	}
	if ((EIF_BOOLEAN) (loc5 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_0_))) {
		RTLE;
		return (EIF_REFERENCE) F1752_15768(Current, Result, loc5, arg2);
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_SUB_PICTURE}.truncated_leading_zeros */
EIF_REFERENCE F1752_15768 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg3);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_7_);
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(tr1))-1112])(tr1, ((EIF_INTEGER_32) 1L));
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	F1111_6438(RTCW(Result), ti4_1);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_0_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - loc2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 == (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)))) {
			ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc1);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_1_);
			ti4_3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(tr1))-1112])(tr1, ((EIF_INTEGER_32) 1L));
			tb1 = (EIF_BOOLEAN)(ti4_2 == ti4_3);
		}
		if (tb1) {
		} else {
			if ((EIF_BOOLEAN) (loc1 > loc2)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, loc1);
				tr1 = F1148_8377(RTCW(tr1), Result, tr2);
				Result = (EIF_REFERENCE) tr1;
			} else {
				ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc1);
				if ((EIF_BOOLEAN)(ti4_2 == loc3)) {
				} else {
					ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc1);
					tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_1_);
					ti4_3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(tr1))-1112])(tr1, ((EIF_INTEGER_32) 1L));
					if ((EIF_BOOLEAN)(ti4_2 == ti4_3)) {
						loc2++;
					} else {
						tr1 = RTOSCF(8530,F1163_8530, (Current));
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, loc1);
						tr1 = F1148_8377(RTCW(tr1), Result, tr2);
						Result = (EIF_REFERENCE) tr1;
						loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					}
				}
			}
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_SUB_PICTURE}.fractional_grouped_formatted_number */
EIF_REFERENCE F1752_15769 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,Current);
	RTLR(5,loc5);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
	tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(tr1))-852])(tr1, ((EIF_INTEGER_32) 1L)));
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg1))-1111])(arg1, tc1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc5 = RTMS_EX_H("",0,0);
		for (;;) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
			loc4 = F881_4371(loc6, loc3);
			loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + loc2);
			if ((EIF_BOOLEAN)(loc1 == loc4)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
				tr1 = F1148_8377(RTCW(tr1), loc5, tr2);
				loc5 = (EIF_REFERENCE) tr1;
				loc4++;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, loc1);
			tr1 = F1148_8377(RTCW(tr1), loc5, tr2);
			loc5 = (EIF_REFERENCE) tr1;
			loc1++;
		}
		RTLE;
		return (EIF_REFERENCE) loc5;
	} else {
		RTLE;
		return (EIF_REFERENCE) arg1;
	}/* NOTREACHED */
	
}

void EIF_Minit825 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
