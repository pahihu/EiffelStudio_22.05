/*
 * Code for class XM_XSLT_NAMESPACE_REDUCER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm813.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_NAMESPACE_REDUCER}.make */
void F1740_15418 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O11855[Dtype(tr1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O11856[Dtype(tr1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1506,1035,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1507_12163(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1506,1035,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1507_12163(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1507,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1508_12163(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1507_12179(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1508_12179(RTCW(tr1), (EIF_BOOLEAN) 0, ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {XM_XSLT_NAMESPACE_REDUCER}.start_element */
void F1740_15419 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1734_15320(Current, arg1, arg2, arg3);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) > ((EIF_INTEGER_32) 1L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tb2 = F1508_12165(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) - ((EIF_INTEGER_32) 1L)));
		tb1 = tb2;
	}
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1506,1035,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		F1507_12161(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	} else {
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) NULL;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) <= ti4_1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1507_12176(RTCW(tr1), ((EIF_INTEGER_32) 0L), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tb1 = F1412_11670(Current, arg3);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_);
		F1508_12176(RTCW(tr1), tb1, ti4_1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1507_12179(RTCW(tr1), ((EIF_INTEGER_32) 0L), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tb1 = F1412_11670(Current, arg3);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_);
		F1508_12179(RTCW(tr1), tb1, ti4_1);
	}
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_))++;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1507_12212(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) * ((EIF_INTEGER_32) 2L)));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F1508_12212(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) * ((EIF_INTEGER_32) 2L)));
	}
	if ((EIF_BOOLEAN) !F1412_11669(Current, arg3)) {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tb1 = F1242_10429(RTCW(tr1), arg1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = RTOSCF(4950,F991_4950, (Current));
			F1242_10441(RTCW(tr1), arg1);
		}
		tr1 = RTOSCF(4950,F991_4950, (Current));
		ti4_1 = F1242_10447(RTCW(tr1), arg1);
		F1740_15420(Current, ti4_1, ((EIF_INTEGER_32) 0L));
	}
	RTLE;
}

/* {XM_XSLT_NAMESPACE_REDUCER}.notify_namespace */
void F1740_15420 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc1 = F1227_9773(Current, arg1);
	F1740_15429(Current, loc1);
	if (F1740_15430(Current, arg1, loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1507_12183(RTCW(tr1), arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = F1507_12165(RTCW(tr2), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) - ((EIF_INTEGER_32) 1L)));
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_);
		F1507_12176(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (ti4_2 - ((EIF_INTEGER_32) 1L)));
		F1734_15321(Current, arg1, arg2);
	}
	F1734_15315(Current);
	RTLE;
}

/* {XM_XSLT_NAMESPACE_REDUCER}.notify_attribute */
void F1740_15421 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	if (F1412_11671(Current, arg4)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg3))-1111])(arg3, (EIF_CHARACTER_8) ' ', ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			F1740_15431(Current, arg3);
		} else {
			loc2 = RTLNS(eif_new_type(1263, 0x01).id, 1263, _OBJSIZ_2_2_0_0_0_0_0_0_);
			F1264_10634(RTCW(loc2));
			tr1 = RTMS_EX_H(" ",1,32);
			F1264_10640(RTCW(loc2), tr1);
			loc3 = F1264_10644(RTCW(loc2), arg3);
			loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(loc3))-1481])(loc3);
			F1320_11363(RTCW(loc4));
			for (;;) {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3187[Dtype(RTCW(loc4))-556])(loc4);
				if (tb1) break;
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3186[Dtype(RTCW(loc4))-556])(loc4);
				F1740_15431(Current, tr1);
				F1320_11364(RTCW(loc4));
			}
		}
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg4 - ((EIF_INTEGER_32) 4L));
	} else {
		loc1 = (EIF_INTEGER_32) arg4;
	}
	F1734_15322(Current, arg1, arg2, arg3, loc1);
	RTLE;
}

/* {XM_XSLT_NAMESPACE_REDUCER}.start_content */
void F1740_15422 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		loc1 = F1507_12168(loc3);
		F1321_11363(RTCW(loc1));
		for (;;) {
			tb1 = F1385_11438(RTCW(loc1));
			if (tb1) break;
			loc2 = F1308_11343(RTCW(loc1));
			if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) -1L))) {
				F1740_15420(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 / ((EIF_INTEGER_32) 65536L)) * ((EIF_INTEGER_32) 65536L)), ((EIF_INTEGER_32) 0L));
			}
			F1321_11364(RTCW(loc1));
		}
	}
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) NULL;
	F1734_15323(Current);
	RTLE;
}

/* {XM_XSLT_NAMESPACE_REDUCER}.end_element */
void F1740_15423 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_))--;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = F1507_12165(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1507_12204(RTCW(tr1), loc1);
	F1734_15324(Current);
	RTLE;
}

/* {XM_XSLT_NAMESPACE_REDUCER}.cancel_pending_undeclarations */
void F1740_15429 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = F1507_12168(loc2);
		F1321_11363(RTCW(loc1));
		for (;;) {
			tb1 = F1385_11438(RTCW(loc1));
			if (tb1) break;
			ti4_1 = F1308_11343(RTCW(loc1));
			if ((EIF_BOOLEAN)(arg1 == F1227_9773(Current, ti4_1))) {
				F1385_11440(RTCW(loc1), ((EIF_INTEGER_32) -1L));
			}
			F1321_11364(RTCW(loc1));
		}
	}
	RTLE;
}

/* {XM_XSLT_NAMESPACE_REDUCER}.is_needed */
EIF_BOOLEAN F1740_15430 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != RTOSCF(9845,F1230_9845, (Current)))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc1 = F1507_12168(RTCW(tr1));
		F1330_11374(RTCW(loc1));
		for (;;) {
			tb1 = F1385_11439(RTCW(loc1));
			if (tb1) break;
			ti4_1 = F1308_11343(RTCW(loc1));
			if ((EIF_BOOLEAN)(arg1 == ti4_1)) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				F1330_11377(RTCW(loc1));
			} else {
				ti4_1 = F1308_11343(RTCW(loc1));
				if ((EIF_BOOLEAN)(arg2 == F1227_9773(Current, ti4_1))) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					F1330_11377(RTCW(loc1));
				} else {
					F1330_11375(RTCW(loc1));
				}
			}
		}
		if ((EIF_BOOLEAN) !loc2) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 != ((EIF_INTEGER_32) 0L));
		}
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_NAMESPACE_REDUCER}.check_qname_prefix */
void F1740_15431 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,arg1);
	RTLR(4,Current);
	RTLR(5,tr2);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1263, 0x01).id, 1263, _OBJSIZ_2_2_0_0_0_0_0_0_);
	F1264_10634(RTCW(loc1));
	tr1 = RTMS_EX_H(":",1,58);
	F1264_10640(RTCW(loc1), tr1);
	loc2 = F1264_10644(RTCW(loc1), arg1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9566[Dtype(RTCW(loc2))-1481])(loc2);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(loc2))-1481])(loc2, ((EIF_INTEGER_32) 1L));
		loc3 = F1242_10409(RTCW(tr1), tr2);
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("Unknown prefix in QName content: ",33,96394016);
			tr1 = F1148_8367(RTCW(tr1), tr2, arg1);
			F1734_15316(Current, tr1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			loc4 = F1507_12168(RTCW(tr1));
			F1330_11374(RTCW(loc4));
			for (;;) {
				tb1 = F1385_11439(RTCW(loc4));
				if (tb1) break;
				ti4_1 = F1308_11343(RTCW(loc4));
				if ((EIF_BOOLEAN)(loc3 == F1227_9773(Current, ti4_1))) {
					F1330_11377(RTCW(loc4));
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					F1330_11375(RTCW(loc4));
				}
			}
			if ((EIF_BOOLEAN) !loc5) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H("namespace not declared for prefix in QName content: ",52,2088139040);
				tr1 = F1148_8367(RTCW(tr1), tr2, arg1);
				F1734_15316(Current, tr1);
			}
		}
	}
	RTLE;
}

void EIF_Minit813 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
