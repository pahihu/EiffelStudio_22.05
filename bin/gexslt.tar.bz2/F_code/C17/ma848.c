/*
 * Code for class MA_DECIMAL_CONTEXT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ma848.h"
#include "eif_built_in.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MA_DECIMAL_CONTEXT}.make_default */
void F1775_16257 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = RTOSCF(15523,F1747_15523, (Current));
	F1775_16261(Current, ((EIF_INTEGER_32) 9L), ti4_1);
	loc1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(15522,F1747_15522, (Current)))+ _LNGOFF_1_1_0_1_);
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(15522,F1747_15522, (Current)))+ _LNGOFF_1_1_0_0_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		tr1 = RTOSCF(15522,F1747_15522, (Current));
		ti4_2 = F881_4371(RTCW(tr1), loc1);
		F1775_16278(Current, ti4_2);
		loc1++;
	}
	RTLE;
}

/* {MA_DECIMAL_CONTEXT}.make_double */
void F1775_16258 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1775_16257(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ((EIF_INTEGER_32) 9L)) + ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {MA_DECIMAL_CONTEXT}.make_extended */
void F1775_16259 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1775_16261(Current, ((EIF_INTEGER_32) 9L), ((EIF_INTEGER_32) 6L));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {MA_DECIMAL_CONTEXT}.make_double_extended */
void F1775_16260 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1775_16259(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ((EIF_INTEGER_32) 9L)) + ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {MA_DECIMAL_CONTEXT}.make */
void F1775_16261 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_1_) = (EIF_INTEGER_32) arg2;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,883,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F884_4366(RTCW(tr1), (EIF_BOOLEAN) 0, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 8L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,883,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F884_4366(RTCW(tr1), (EIF_BOOLEAN) 0, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 8L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 999999999L);
	RTLE;
}

/* {MA_DECIMAL_CONTEXT}.e_tiny */
EIF_INTEGER_32 F1775_16267 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) -*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_2_) - (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_) - ((EIF_INTEGER_32) 1L)));
}

/* {MA_DECIMAL_CONTEXT}.is_flagged */
EIF_BOOLEAN F1775_16269 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F884_4371(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {MA_DECIMAL_CONTEXT}.is_trapped */
EIF_BOOLEAN F1775_16270 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = F884_4371(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {MA_DECIMAL_CONTEXT}.set_digits */
void F1775_16274 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {MA_DECIMAL_CONTEXT}.set_exponent_limit */
void F1775_16275 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_2_) = (EIF_INTEGER_32) arg1;
}

/* {MA_DECIMAL_CONTEXT}.enable_trap */
void F1775_16278 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F884_4390(RTCW(tr1), (EIF_BOOLEAN) 1, arg1);
	RTLE;
}

/* {MA_DECIMAL_CONTEXT}.disable_trap */
void F1775_16279 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F884_4390(RTCW(tr1), (EIF_BOOLEAN) 0, arg1);
	RTLE;
}

/* {MA_DECIMAL_CONTEXT}.set_flag */
void F1775_16280 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F884_4390(RTCW(tr1), (EIF_BOOLEAN) 1, arg1);
	RTLE;
}

/* {MA_DECIMAL_CONTEXT}.reset_flag */
void F1775_16281 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F884_4390(RTCW(tr1), (EIF_BOOLEAN) 0, arg1);
	RTLE;
}

/* {MA_DECIMAL_CONTEXT}.reset_flags */
void F1775_16282 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F884_4390(RTCW(tr1), (EIF_BOOLEAN) 0, loc1);
		loc1++;
	}
	RTLE;
}

/* {MA_DECIMAL_CONTEXT}.out */
EIF_REFERENCE F1775_16286 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1111_6438(RTCW(Result), ((EIF_INTEGER_32) 30L));
	tr1 = RTMS_EX_H("digits=",7,768601405);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_);
	tr1 = eif_out__i4_s1(ti4_1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
	tr1 = RTMS_EX_H(" rounding_mode=",15,18743101);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
	tr1 = RTOSCF(15529,F1747_15529, (Current));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(15529,F1747_15529, (Current)))+ _LNGOFF_1_1_0_1_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_1_);
	tr1 = F880_4371(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ti4_2));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
	RTLE;
	return Result;
}

/* {MA_DECIMAL_CONTEXT}.is_equal */
EIF_BOOLEAN F1775_16287 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	tb1 = '\0';
	if (Result) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_1_);
		tb1 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) == tb2);
	}
	Result = (EIF_BOOLEAN) tb1;
	tb1 = '\0';
	if (Result) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_2_);
		tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_2_) == ti4_1);
	}
	Result = (EIF_BOOLEAN) tb1;
	tb1 = '\0';
	if (Result) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		tb2 = F884_4381(RTCW(tr1), tr2);
		tb1 = tb2;
	}
	Result = (EIF_BOOLEAN) tb1;
	tb1 = '\0';
	if (Result) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_0_);
		tb1 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) == tb2);
	}
	Result = (EIF_BOOLEAN) tb1;
	tb1 = '\0';
	if (Result) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_1_);
		tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_1_) == ti4_1);
	}
	Result = (EIF_BOOLEAN) tb1;
	tb1 = '\0';
	if (Result) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		tb2 = F884_4381(RTCW(tr1), tr2);
		tb1 = tb2;
	}
	Result = (EIF_BOOLEAN) tb1;
	RTLE;
	return Result;
}

/* {MA_DECIMAL_CONTEXT}.signal */
void F1775_16288 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	F1775_16280(Current, arg1);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	tb1 = '\0';
	if (F1775_16270(Current, arg1)) {
		tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_);
	}
	if (tb1) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15531,F1747_15531, (Current));
		tr2 = F880_4371(RTCW(tr2), arg1);
		loc1 = F1148_8376(RTCW(tr1), tr2);
		tr1 = RTMS_EX_H(" : ",3,2112032);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(loc1))-1112])(loc1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(loc1))-1112])(loc1, arg2);
		tr1 = RTOSCF(2994,F361_2994, (Current));
		F275_2285(RTCW(tr1), loc1);
	}
	RTLE;
}

/* {MA_DECIMAL_CONTEXT}.copy */
void F1775_16289 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	eif_builtin_ANY_standard_copy__o_ (Current, arg1);
	tr1 = RTOSCF(4823,F986_4823, (Current));
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	tr1 = F1143_8349(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(4823,F986_4823, (Current));
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	tr1 = F1143_8349(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {MA_DECIMAL_CONTEXT}.force_digits */
void F1775_16292 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_) = (EIF_INTEGER_32) arg1;
}

void EIF_Minit848 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
