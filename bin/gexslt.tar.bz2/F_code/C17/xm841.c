/*
 * Code for class XM_XSLT_EVALUATION_CONTEXT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm841.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_EVALUATION_CONTEXT}.make */
void F1768_16170 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1768_16171(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_21_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = RTLNSMART(eif_new_type(38, 0).id);
	F39_432(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(21, 0).id);
	F22_189(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.make_minor */
void F1768_16171 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	F1766_16142(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_11_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_21_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.make_restricted */
void F1768_16172 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc3);
	RTLR(5,tr1);
	RTLR(6,tr2);
	RTLR(7,loc1);
	RTLR(8,loc2);
	RTLIU(9);
	
	RTGC;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) arg3;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_21_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F1766_16142(Current);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg2;
	loc3 = RTLNSMART(eif_new_type(1279, 0).id);
	tr1 = F1721_15176(RTCV(RTOSCF(3564,F460_3564, (Current))));
	tr2 = F1721_15176(RTCV(RTOSCF(3565,F460_3565, (Current))));
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R10685[Dtype(RTCW(tr1))-1615])(tr1, tr2);
	F1280_10995(RTCW(loc3), tr1);
	RTAR(Current, loc3);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) loc3;
	loc1 = RTLNS(eif_new_type(1619, 0x01).id, 1619, _OBJSIZ_0_0_0_2_0_0_0_0_);
	F1620_13634(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	tr1 = RTOSCF(3565,F460_3565, (Current));
	F1722_15184(RTCW(tr1), loc1);
	loc2 = RTLNS(eif_new_type(1279, 0x01).id, 1279, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
	F1280_10995(RTCW(loc2), tr1);
	tr1 = RTLNSMART(eif_new_type(1153, 0).id);
	F1153_8477(RTCW(tr1), loc1, loc2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(21, 0).id);
	F22_189(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(38, 0).id);
	F39_432(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.configuration */
EIF_REFERENCE F1768_16173 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_20_);
}


/* {XM_XSLT_EVALUATION_CONTEXT}.local_variable_frame */
EIF_REFERENCE F1768_16176 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_4_)) {
		RTCT0("attached caller as l_caller", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = F1768_16176(loc1);
	} else {
		Result = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.current_mode */
EIF_REFERENCE F1768_16177 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_4_)) {
		RTCT0("attached caller as l_caller", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = F1768_16177(loc1);
	} else {
		Result = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.current_template */
EIF_REFERENCE F1768_16178 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_4_)) {
		RTCT0("attached caller as l_caller", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = F1768_16178(loc1);
	} else {
		Result = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.current_group_iterator */
EIF_REFERENCE F1768_16179 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_4_)) {
		RTCT0("attached caller as l_caller", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = F1768_16179(loc1);
	} else {
		Result = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.current_regexp_iterator */
EIF_REFERENCE F1768_16180 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_3_)) {
		RTLE;
		return (EIF_REFERENCE) NULL;
	} else {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_4_)) {
			RTCT0("attached caller as l_caller", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				RTCK0;
			} else {
				RTCF0;
			}
			Result = F1768_16180(loc1);
		} else {
			Result = *(EIF_REFERENCE *)(Current + _REFACS_14_);
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.tunnel_parameters */
EIF_REFERENCE F1768_16181 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_4_)) {
		RTCT0("attached caller as l_caller", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = F1768_16181(loc1);
	} else {
		Result = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.local_parameters */
EIF_REFERENCE F1768_16182 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_4_)) {
		RTCT0("attached caller as l_caller", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = F1768_16182(loc1);
	} else {
		RTCT0("attached internal_local_parameters as l_internal_local_parameters", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = (EIF_REFERENCE) loc2;
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.is_local_parameter_supplied */
EIF_BOOLEAN F1768_16183 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if (arg2) {
		loc1 = F1768_16181(Current);
	} else {
		loc1 = F1768_16182(Current);
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb1 = F39_435(RTCW(loc1), arg1);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.last_parsed_document */
EIF_REFERENCE F1768_16185 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_19_);
}


/* {XM_XSLT_EVALUATION_CONTEXT}.last_parsed_media_type */
EIF_REFERENCE F1768_16186 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_18_);
}


/* {XM_XSLT_EVALUATION_CONTEXT}.available_functions */
EIF_REFERENCE F1768_16187 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_0_)) {
		RTCT0("invariant_static_context_not_void", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8493[Dtype(loc1)-1240])(loc1);
	} else {
		RTCT0("attached transformer as l_transformer", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_1_);
		Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.available_documents */
EIF_REFERENCE F1768_16188 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_21_0_)) {
		RTCT0("attached transformer as l_transformer", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = *(EIF_REFERENCE *)(loc1 + _REFACS_32_);
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.implicit_timezone */
EIF_REFERENCE F1768_16189 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_0_)) {
		RTCT0("attached internal_implicit_timezone as l_internal_implicit_timezone", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = (EIF_REFERENCE) loc1;
	} else {
		RTCT0("attached transformer as l_transformer", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = *(EIF_REFERENCE *)(loc2 + _REFACS_15_);
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.security_manager */
EIF_REFERENCE F1768_16190 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("attached transformer as l_transformer", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_10_);
	Result = *(EIF_REFERENCE *)(RTCW(tr1));
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.current_date_time */
EIF_REFERENCE F1768_16191 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_21_0_)) {
		RTCT0("attached transformer as l_transformer", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = *(EIF_REFERENCE *)(loc1 + _REFACS_5_);
	} else {
		RTCT0("attached internal_date_time as l_internal_date_time", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = (EIF_REFERENCE) loc2;
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.last_build_error */
EIF_REFERENCE F1768_16194 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_17_);
}


/* {XM_XSLT_EVALUATION_CONTEXT}.is_minor */
EIF_BOOLEAN F1768_16195 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_21_4_);
}


/* {XM_XSLT_EVALUATION_CONTEXT}.has_push_processing */
EIF_BOOLEAN F1768_16197 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.is_process_error */
EIF_BOOLEAN F1768_16198 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTCT0("attached transformer as l_transformer", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = *(EIF_BOOLEAN *)(loc1+ _CHROFF_33_0_);
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.is_uri_written */
EIF_BOOLEAN F1768_16199 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	RTCT0("attached transformer as l_transformer", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTCT0("attached l_transformer.principal_result_uri as l_principal_result_uri", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_10_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = '\01';
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tb1 = F1148_8369(RTCW(tr1), arg1, loc2);
	if (!tb1) {
		Result = F1766_16125(Current, arg1);
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.set_pattern */
void F1768_16200 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_21_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.new_context */
EIF_REFERENCE F1768_16201 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_4_)) {
		RTLE;
		return (EIF_REFERENCE) F1768_16202(Current, Current);
	} else {
		RTLE;
		return (EIF_REFERENCE) F1766_16126(Current);
	}/* NOTREACHED */
	
}

/* {XM_XSLT_EVALUATION_CONTEXT}.new_major_context */
EIF_REFERENCE F1768_16202 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	RTCT0("attached a_minor_context.transformer as l_minor_context_transformer", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = RTLNSMART(Dftype(Current));
	F1768_16170(RTCW(Result), loc1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	F1766_16130(RTCW(Result), tr1);
	tr1 = F1768_16182(RTCW(arg1));
	F1768_16216(RTCW(Result), tr1);
	RTCT0("attached a_minor_context.local_variable_frame as l_local_variable_frame", EX_CHECK);
	tr1 = F1768_16176(RTCW(arg1));
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1768_16206(RTCW(Result), loc2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_21_5_0_0_);
	F1768_16213(RTCW(Result), ti4_1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	F1766_16131(RTCW(Result), tr1);
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_21_1_);
	F1766_16132(RTCW(Result), tb1);
	F1768_16212(RTCW(Result), arg1);
	tr1 = F1768_16181(RTCW(arg1));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		F1768_16217(RTCW(Result), loc3);
	}
	tr1 = F1768_16177(RTCW(arg1));
	F1768_16220(RTCW(Result), tr1);
	tr1 = F1768_16178(RTCW(arg1));
	F1768_16221(RTCW(Result), tr1);
	tr1 = F1768_16179(RTCW(arg1));
	F1768_16218(RTCW(Result), tr1);
	tr1 = F1768_16180(RTCW(arg1));
	F1768_16219(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.new_minor_context */
EIF_REFERENCE F1768_16203 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("attached transformer as l_transformer", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = RTLNSMART(Dftype(Current));
	F1768_16171(RTCW(Result), loc1);
	F1768_16212(RTCW(Result), Current);
	F1766_16130(RTCW(Result), *(EIF_REFERENCE *)(Current));
	F1766_16131(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	F1766_16132(RTCW(Result), *(EIF_BOOLEAN *)(Current+ _CHROFF_21_1_));
	F1768_16213(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_5_0_0_));
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_3_)) {
		F1768_16200(RTCW(Result));
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.new_pattern_context */
EIF_REFERENCE F1768_16204 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F1768_16203(Current);
	F1768_16200(RTCW(Result));
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.new_clean_context */
EIF_REFERENCE F1768_16205 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("attached transformer as l_transformer", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = RTLNSMART(Dftype(Current));
	F1768_16170(RTCW(Result), loc1);
	RTLE;
	return Result;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.set_stack_frame */
void F1768_16206 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) arg1;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.reset_stack_frame_map */
void F1768_16207 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	RTCT0("attached local_variable_frame as l_local_variable_frame", EX_CHECK);
	tr1 = F1768_16176(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F22_195(loc1, arg1, arg2);
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.set_tail_call */
void F1768_16208 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg1;
	RTCT0("attached local_variable_frame as l_local_variable_frame", EX_CHECK);
	tr1 = F1768_16176(Current);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTCK0;
	} else {
		RTCF0;
	}
	ti4_1 = F880_4378(RTCW(arg2));
	tr1 = *(EIF_REFERENCE *)(loc3 + _REFACS_1_);
	ti4_2 = F880_4378(RTCW(tr1));
	if ((EIF_BOOLEAN)(ti4_1 != ti4_2)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,1869,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc2 = RTLNSMART(RTCA(arg2, typres0).id);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_0_0_);
		F880_4366(RTCW(loc2), NULL, ((EIF_INTEGER_32) 1L), ti4_1);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			ti4_1 = F880_4378(RTCW(arg2));
			if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
			tr1 = F880_4371(RTCW(arg2), loc1);
			F880_4390(RTCW(loc2), tr1, loc1);
			loc1++;
		}
		F22_194(loc3, loc2);
	} else {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			ti4_2 = F880_4378(RTCW(arg2));
			if ((EIF_BOOLEAN) (loc1 > ti4_2)) break;
			tr1 = *(EIF_REFERENCE *)(loc3 + _REFACS_1_);
			tr2 = F880_4371(RTCW(arg2), loc1);
			F880_4390(RTCW(tr1), tr2, loc1);
			loc1++;
		}
	}
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.clear_tail_call_function */
void F1768_16209 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.open_stack_frame */
void F1768_16210 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,1869,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	F880_4366(RTCW(loc1), NULL, ((EIF_INTEGER_32) 1L), ti4_1);
	tr1 = RTLNSMART(eif_new_type(21, 0).id);
	F22_188(RTCW(tr1), arg1, loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.open_sized_stack_frame */
void F1768_16211 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,1869,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F880_4366(RTCW(loc1), NULL, ((EIF_INTEGER_32) 1L), arg1);
	loc2 = RTLNS(eif_new_type(27, 0x01).id, 27, _OBJSIZ_0_0_0_1_0_0_0_0_);
	F28_233(RTCW(loc2), arg1);
	tr1 = RTLNSMART(eif_new_type(21, 0).id);
	F22_188(RTCW(tr1), loc2, loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.set_caller */
void F1768_16212 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.set_last */
void F1768_16213 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_5_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.set_local_variable */
void F1768_16214 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_4_)) {
		RTCT0("attached caller as l_caller", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1768_16214(loc1, arg1, arg2);
	} else {
		F1766_16133(Current, arg1, arg2);
	}
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.ensure_local_parameter_set */
void F1768_16215 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_4_)) {
		RTCT0("attached caller as l_caller", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1768_16215(loc3, arg1, arg2, arg3);
	} else {
		if (arg2) {
			loc1 = F1768_16181(Current);
		} else {
			loc1 = F1768_16182(Current);
		}
		RTCT0("a_parameter_set /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc2 = F39_433(RTCW(loc1), arg1);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTCT0("attached local_variable_frame as l_local_variable_frame", EX_CHECK);
			tr1 = F1768_16176(Current);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_1_);
			F880_4390(RTCW(tr1), loc2, arg3);
		}
	}
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.set_local_parameters */
void F1768_16216 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) arg1;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.set_tunnel_parameters */
void F1768_16217 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) arg1;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.set_current_group_iterator */
void F1768_16218 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg1;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.set_current_regexp_iterator */
void F1768_16219 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) arg1;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.set_current_mode */
void F1768_16220 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tb1 = '\01';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb3 = F1799_16726(RTCW(arg1));
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (!tb2) {
		tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_12_) != NULL);
	}
	if (tb1) {
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) arg1;
	}
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.set_current_template */
void F1768_16221 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) arg1;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.build_document */
void F1768_16222 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(19);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc8);
	RTLR(4,loc6);
	RTLR(5,arg1);
	RTLR(6,loc1);
	RTLR(7,loc9);
	RTLR(8,loc2);
	RTLR(9,loc10);
	RTLR(10,loc3);
	RTLR(11,loc4);
	RTLR(12,loc11);
	RTLR(13,loc12);
	RTLR(14,loc13);
	RTLR(15,loc5);
	RTLR(16,loc14);
	RTLR(17,tr2);
	RTLR(18,tr3);
	RTLIU(19);
	
	RTGC;
	RTCT0("attached transformer as l_transformer", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(loc7 + _REFACS_4_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		F461_3578(loc8);
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_21_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) NULL;
	loc6 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
	F1707_14586(RTCW(loc6), arg1);
	tr1 = *(EIF_REFERENCE *)(loc7 + _REFACS_2_);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_9_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1648[Dtype(RTCW(loc1))-1125])(loc1, arg1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1652[Dtype(RTCW(loc1))-1125])(loc1);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		F1768_16227(Current, loc9);
	} else {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1646[Dtype(RTCW(loc1))-1125])(loc1);
		if (tb1) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1647[Dtype(RTCW(loc1))-1125])(loc1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
		}
		loc2 = F2152_21400(loc7);
		RTCT0("attached l_uri_resolver.last_system_id as l_uri_resolver_last_system_id", EX_CHECK);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1650[Dtype(RTCW(loc1))-1125])(loc1);
		loc10 = tr1;
		if (EIF_TEST(loc10)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = F1707_14605(loc10);
		loc3 = F2152_21401(loc7, loc2, tr1, loc6);
		loc4 = RTLNS(eif_new_type(1546, 0x01).id, 1546, _OBJSIZ_12_1_0_0_0_0_0_0_);
		tr1 = F1707_14605(loc10);
		F1547_12569(RTCW(loc4), tr1);
		RTCT0("attached l_uri_resolver.last_uri_reference_stream as l_uri_resolver_last_uri_reference_stream", EX_CHECK);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1649[Dtype(RTCW(loc1))-1125])(loc1);
		loc11 = tr1;
		if (EIF_TEST(loc11)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1547_12575(RTCW(loc4), loc11, loc10, loc2, loc3, (EIF_BOOLEAN) 0);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_3_);
		loc12 = tr1;
		if (EIF_TEST(loc12)) {
			F1768_16227(Current, loc12);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
			loc13 = tr1;
			loc13 = RTRV(eif_new_type(1862, 0x01),loc13);
			if (EIF_TEST(loc13)) {
				RTAR(Current, loc13);
				*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) loc13;
				loc5 = *(EIF_REFERENCE *)(loc7 + _REFACS_1_);
			} else {
				*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) NULL;
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(loc7 + _REFACS_4_);
	loc14 = tr1;
	if (EIF_TEST(loc14)) {
		F461_3579(loc14);
		tr1 = *(EIF_REFERENCE *)(loc7 + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_7_);
		tr2 = RTMS_EX_H("Time to build ",14,727403296);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr2)-1111])(tr2, arg1);
		tr3 = RTMS_EX_H(" was ",5,2003120928);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr2))-1111])(tr2, tr3);
		tr3 = F461_3573(loc14);
		tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10671[Dtype(RTCW(tr3))-1615])(tr3);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr2))-1111])(tr2, tr3);
		tr3 = RTMS_EX_H(" seconds",8,1975653235);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr2))-1111])(tr2, tr3);
		F1581_13014(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(loc7 + _REFACS_2_);
	F1750_15716(RTCW(tr1));
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.change_to_sequence_output_destination */
void F1768_16223 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1766_16137(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_21_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O11857[Dtype(arg1)-1728]);
	if ((EIF_BOOLEAN) !tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11865[Dtype(RTCW(arg1))-1732])(arg1);
	}
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.change_output_destination */
void F1768_16224 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3, EIF_INTEGER_32 arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc6);
	RTLR(6,arg1);
	RTLR(7,loc2);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,arg2);
	RTLR(11,loc3);
	RTLR(12,loc4);
	RTLR(13,loc1);
	RTLIU(14);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg3 && *(EIF_BOOLEAN *)(Current+ _CHROFF_21_1_))) {
		loc5 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
		tr1 = RTMS_EX_H("Cannot switch to a final result destination while writing a temporary tree",74,859472997);
		tr2 = RTOSCF(9827,F1230_9827, (Current));
		tr3 = RTMS_EX_H("XTDE1480",8,308992560);
		F1709_14669(RTCW(loc5), tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
		RTCT0("attached transformer as l_transformer", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1710_14691(loc6, loc5);
	} else {
		if ((EIF_BOOLEAN)(arg1 == NULL)) {
			loc2 = RTLNS(eif_new_type(1780, 0x01).id, 1780, _OBJSIZ_22_17_0_1_0_0_0_0_);
			F1781_16417(RTCW(loc2), ((EIF_INTEGER_32) 0L));
		} else {
			loc2 = (EIF_REFERENCE) arg1;
		}
		RTCT0("attached transformer as l_transformer", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTCT0("attached l_transformer.selected_receiver (a_result, some_properties) as l_selected_receiver", EX_CHECK);
		tr1 = F2152_21439(loc7, arg2, loc2);
		loc8 = tr1;
		if (EIF_TEST(loc8)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc3 = (EIF_REFERENCE) loc8;
		F72_759(RTCW(arg2), loc3);
		tb1 = '\0';
		tb2 = *(EIF_BOOLEAN *)(loc7+ _CHROFF_33_0_);
		if ((EIF_BOOLEAN) !tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(loc3) + O11857[Dtype(loc3)-1728]);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			loc4 = RTLNS(eif_new_type(1739, 0x01).id, 1739, _OBJSIZ_7_3_0_1_0_0_0_0_);
			F1740_15418(RTCW(loc4), loc3);
			loc1 = RTLNS(eif_new_type(1846, 0x01).id, 1846, _OBJSIZ_9_6_0_6_0_0_0_0_);
			F1847_17466(RTCW(loc1), loc4);
			F1847_17471(RTCW(loc1));
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
		}
	}
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.report_fatal_error */
void F1768_16225 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	RTCT0("attached transformer as l_transformer", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1710_14691(loc1, arg1);
	RTLE;
}

/* {XM_XSLT_EVALUATION_CONTEXT}.set_build_error */
void F1768_16227 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_21_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

void EIF_Minit841 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
