/*
 * Code for class XM_XSLT_XML_INDENTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm814.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_XML_INDENTER}.make */
void F1741_15432 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11898[Dtype(RTCW(arg2))-1732])(arg2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_22_17_0_0_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_0_) = (EIF_INTEGER_32) ti4_1;
	tr1 = RTOSCF(4950,F991_4950, (Current));
	tr2 = RTMS_EX_H("xml",3,7892332);
	tr3 = RTOSCF(9821,F1230_9821, (Current));
	tr4 = RTMS_EX_H("space",5,1886313829);
	tb1 = F1242_10430(RTCW(tr1), tr2, tr3, tr4);
	if (tb1) {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tr2 = RTMS_EX_H("xml",3,7892332);
		tr3 = RTOSCF(9821,F1230_9821, (Current));
		tr4 = RTMS_EX_H("space",5,1886313829);
		ti4_1 = F1242_10413(RTCW(tr1), tr2, tr3, tr4);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_5_) = (EIF_INTEGER_32) ti4_1;
	} else {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tr2 = RTMS_EX_H("xml",3,7892332);
		tr3 = RTOSCF(9821,F1230_9821, (Current));
		tr4 = RTMS_EX_H("space",5,1886313829);
		F1242_10444(RTCW(tr1), tr2, tr3, tr4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(4950,F991_4950, (Current)))+ _LNGOFF_4_0_0_0_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_5_) = (EIF_INTEGER_32) ti4_1;
	}
	ti4_1 = F1227_9769(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_5_));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_5_) = (EIF_INTEGER_32) ti4_1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O11855[Dtype(tr1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O11856[Dtype(tr1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_XML_INDENTER}.start_element */
void F1741_15433 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_)) {
		F1741_15450(Current);
	}
	F1734_15320(Current, arg1, arg2, arg3);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_3_))++;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {XM_XSLT_XML_INDENTER}.end_element */
void F1741_15434 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_3_))--;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_))) {
		F1741_15450(Current);
	}
	F1734_15324(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_3_) == (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_4_) - ((EIF_INTEGER_32) 1L)))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTLE;
}

/* {XM_XSLT_XML_INDENTER}.notify_attribute */
void F1741_15435 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(F1227_9769(Current, arg1) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_5_))) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("preserve",8,1323386213);
		tb2 = F1148_8369(RTCW(tr1), arg3, tr2);
		tb1 = tb2;
	}
	if (tb1) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_4_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_3_);
	}
	F1734_15322(Current, arg1, arg2, arg3, arg4);
	RTLE;
}

/* {XM_XSLT_XML_INDENTER}.notify_processing_instruction */
void F1741_15436 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	F1734_15326(Current, arg1, arg2, arg3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XSLT_XML_INDENTER}.notify_characters */
void F1741_15437 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc1);
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 10L))) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_1_))++;
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		} else {
			if ((EIF_BOOLEAN) !F1741_15451(Current, loc2)) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_2_))++;
		loc1++;
	}
	F1734_15325(Current, arg1, arg2);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {XM_XSLT_XML_INDENTER}.notify_comment */
void F1741_15438 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1734_15327(Current, arg1, arg2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XSLT_XML_INDENTER}.indentation_characters */

EIF_REFERENCE F1741_15446 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15446,RTMS_EX_H("                                                                                   ",83,1325751072));
}

/* {XM_XSLT_XML_INDENTER}.indent */
void F1741_15450 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_4_) < ((EIF_INTEGER_32) 0L))) {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_3_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 * ti4_1);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_1_) == ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_0_2_) <= loc1))) {
			for (;;) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(15446,F1741_15446, (Current)))+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (loc1 <= ti4_1)) break;
				tr1 = RTOSCF(15446,F1741_15446, (Current));
				tr2 = RTOSCF(15446,F1741_15446, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(tr1))-1112])(tr1, tr2);
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr2 = RTMS_EX_H("\012",1,10);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, tr2, ((EIF_INTEGER_32) 0L));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr2 = RTOSCF(15446,F1741_15446, (Current));
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(tr2))-1111])(tr2, ((EIF_INTEGER_32) 1L), loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, tr2, ((EIF_INTEGER_32) 16L));
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}
	RTLE;
}

/* {XM_XSLT_XML_INDENTER}.is_whitespace */
EIF_BOOLEAN F1741_15451 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 13L))) || (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 9L))) || (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 32L)));
}

void EIF_Minit814 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
