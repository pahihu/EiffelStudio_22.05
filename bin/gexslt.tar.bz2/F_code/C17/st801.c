/*
 * Code for class ST_XSLT_NUMBERER_EN
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st801.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ST_XSLT_NUMBERER_EN}.formatted_string */
EIF_REFERENCE F1728_15212 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,arg2);
	RTLR(5,arg4);
	RTLR(6,arg6);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTGC;
	tr1 = RTOSCF(1577,F176_1577, (RTCV(RTOSCF(3556,F456_3556, (Current)))));
	tb1 = F1748_15579(RTCW(arg1), tr1);
	if (tb1) {
		tr1 = F1748_15587(RTCW(arg1));
		Result = F1162_8520(Current, tr1);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			tr1 = F1748_15587(RTCW(arg1));
			Result = F1162_8520(Current, tr1);
		} else {
			tb1 = '\01';
			if (!F1726_15205(Current, arg2)) {
				tb2 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg2))-1112])(arg2, ((EIF_INTEGER_32) 1L));
					tb2 = F1726_15207(Current, ti4_1);
				}
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = F1726_15206(Current, arg2);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
				Result = F1728_15223(Current, arg1, tr1, ti4_1, arg3, arg4, arg6);
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
					loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg2))-1112])(arg2, ((EIF_INTEGER_32) 1L));
					switch (loc1) {
						case 105L:
							tb1 = F1748_15568(RTCW(arg1));
							if (tb1) {
								tr1 = RTMS_EX_H("0",1,48);
								Result = F1162_8520(Current, tr1);
							} else {
								Result = F1728_15224(Current, arg1);
							}
							break;
						case 73L:
							tb1 = F1748_15568(RTCW(arg1));
							if (tb1) {
								tr1 = RTMS_EX_H("0",1,48);
								Result = F1162_8520(Current, tr1);
							} else {
								Result = F1728_15224(Current, arg1);
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R5194[Dtype(RTCW(Result))-1112])(Result);
							}
							break;
						case 65L:
							tb1 = F1748_15557(RTCW(arg1));
							if (tb1) {
								ti4_1 = F1748_15584(RTCW(arg1));
								tr1 = RTOSCF(15216,F1728_15216, (Current));
								Result = F1728_15225(Current, ti4_1, tr1);
							} else {
								tr1 = RTOSCF(15218,F1728_15218, (Current));
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
								Result = F1728_15223(Current, arg1, tr1, ti4_1, arg3, arg4, arg6);
							}
							break;
						case 97L:
							tb1 = F1748_15557(RTCW(arg1));
							if (tb1) {
								ti4_1 = F1748_15584(RTCW(arg1));
								tr1 = RTOSCF(15217,F1728_15217, (Current));
								Result = F1728_15225(Current, ti4_1, tr1);
							} else {
								tr1 = RTOSCF(15218,F1728_15218, (Current));
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
								Result = F1728_15223(Current, arg1, tr1, ti4_1, arg3, arg4, arg6);
							}
							break;
						case 87L:
							tb1 = F1748_15557(RTCW(arg1));
							if (tb1) {
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg6)+ _LNGOFF_1_1_0_2_);
								if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
									ti4_1 = F1748_15584(RTCW(arg1));
									Result = F1728_15228(Current, ti4_1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1);
								} else {
									ti4_1 = F1748_15584(RTCW(arg1));
									Result = F1728_15226(Current, ti4_1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1);
								}
							} else {
								tr1 = RTOSCF(15218,F1728_15218, (Current));
								Result = F1728_15223(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), arg3, arg4, arg6);
							}
							break;
						case 119L:
							tb1 = F1748_15557(RTCW(arg1));
							if (tb1) {
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg6)+ _LNGOFF_1_1_0_2_);
								if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
									ti4_1 = F1748_15584(RTCW(arg1));
									Result = F1728_15228(Current, ti4_1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
								} else {
									ti4_1 = F1748_15584(RTCW(arg1));
									Result = F1728_15226(Current, ti4_1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
								}
							} else {
								tr1 = RTOSCF(15218,F1728_15218, (Current));
								Result = F1728_15223(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), arg3, arg4, arg6);
							}
							break;
						default:
							tr1 = RTOSCF(15218,F1728_15218, (Current));
							Result = F1728_15223(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), arg3, arg4, arg6);
							break;
					}
				} else {
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTMS_EX_H("Ww",2,22391);
					tb1 = F1148_8369(RTCW(tr1), arg2, tr2);
					if (tb1) {
						tb1 = F1748_15557(RTCW(arg1));
						if (tb1) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg6)+ _LNGOFF_1_1_0_2_);
							if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
								ti4_1 = F1748_15584(RTCW(arg1));
								Result = F1728_15228(Current, ti4_1, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
							} else {
								ti4_1 = F1748_15584(RTCW(arg1));
								Result = F1728_15226(Current, ti4_1, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
							}
						} else {
							tr1 = RTOSCF(15218,F1728_15218, (Current));
							Result = F1728_15223(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), arg3, arg4, arg6);
						}
					} else {
						tr1 = RTOSCF(15218,F1728_15218, (Current));
						Result = F1728_15223(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), arg3, arg4, arg6);
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_NUMBERER_EN}.month_name */
EIF_REFERENCE F1728_15213 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(15234,F1728_15234, (Current));
	tr2 = F880_4371(RTCW(tr2), arg1);
	Result = F1148_8376(RTCW(tr1), tr2);
	loc1 = (EIF_INTEGER_32) arg3;
	if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 3L))) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 > loc1)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(Result))-1111])(Result, ((EIF_INTEGER_32) 1L), loc1);
		Result = (EIF_REFERENCE) tr1;
	}
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 >= arg2)) break;
		tr1 = RTMS_EX_H(" ",1,32);
		tr1 = F1162_8520(Current, tr1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
		Result = (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_NUMBERER_EN}.day_name */
EIF_REFERENCE F1728_15214 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(15235,F1728_15235, (Current));
	tr2 = F880_4371(RTCW(tr2), arg1);
	Result = F1148_8376(RTCW(tr1), tr2);
	loc1 = (EIF_INTEGER_32) arg3;
	if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 2L))) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 > loc1)) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15236,F1728_15236, (Current));
		tr2 = F880_4371(RTCW(tr2), arg1);
		Result = F1148_8376(RTCW(tr1), tr2);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 > loc1)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(Result))-1111])(Result, ((EIF_INTEGER_32) 1L), loc1);
		Result = (EIF_REFERENCE) tr1;
	}
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 >= arg2)) break;
		tr1 = RTMS_EX_H(" ",1,32);
		tr1 = F1162_8520(Current, tr1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
		Result = (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_NUMBERER_EN}.half_day_name */
EIF_REFERENCE F1728_15215 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < (EIF_INTEGER_32) (((EIF_INTEGER_32) 12L) * ((EIF_INTEGER_32) 60L)))) {
		switch (arg3) {
			case 1L:
				tr1 = RTMS_EX_H("A",1,65);
				Result = F1162_8520(Current, tr1);
				break;
			case 2L:
			case 3L:
				tr1 = RTMS_EX_H("Am",2,16749);
				Result = F1162_8520(Current, tr1);
				break;
			default:
				tr1 = RTMS_EX_H("A.M.",4,1093553454);
				Result = F1162_8520(Current, tr1);
				break;
		}
	} else {
		switch (arg3) {
			case 1L:
				tr1 = RTMS_EX_H("P",1,80);
				Result = F1162_8520(Current, tr1);
				break;
			case 2L:
			case 3L:
				tr1 = RTMS_EX_H("Pm",2,20589);
				Result = F1162_8520(Current, tr1);
				break;
			default:
				tr1 = RTMS_EX_H("P.M.",4,1345211694);
				Result = F1162_8520(Current, tr1);
				break;
		}
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_NUMBERER_EN}.latin_upper_case_letters */
static EIF_REFERENCE F1728_15216_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15216);
#define Result RTOSR(15216)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,680947802);
	Result = F1162_8520(Current, tr1);
	RTOSE (15216);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15216 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15216,F1728_15216_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.latin_lower_case_letters */
static EIF_REFERENCE F1728_15217_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15217);
#define Result RTOSR(15217)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("abcdefghijklmnopqrstuvwxyz",26,1741663354);
	Result = F1162_8520(Current, tr1);
	RTOSE (15217);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15217 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15217,F1728_15217_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.european_digits */
static EIF_REFERENCE F1728_15218_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15218);
#define Result RTOSR(15218)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("0123456789",10,593348409);
	Result = F1162_8520(Current, tr1);
	RTOSE (15218);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15218 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15218,F1728_15218_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.roman_thousands */
static EIF_REFERENCE F1728_15219_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15219);
#define Result RTOSR(15219)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = F1162_8524(Current);
	F880_4366(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 3L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("m",1,109);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("mm",2,28013);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("mmmm",4,1835887981);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 3L));
	RTOSE (15219);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15219 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15219,F1728_15219_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.roman_hundreds */
static EIF_REFERENCE F1728_15220_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15220);
#define Result RTOSR(15220)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = F1162_8524(Current);
	F880_4366(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 9L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("c",1,99);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("cc",2,25443);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("ccc",3,6513507);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 3L));
	tr1 = RTMS_EX_H("cd",2,25444);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("d",1,100);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 5L));
	tr1 = RTMS_EX_H("dc",2,25699);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 6L));
	tr1 = RTMS_EX_H("dcc",3,6579043);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 7L));
	tr1 = RTMS_EX_H("dccc",4,1684235107);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 8L));
	tr1 = RTMS_EX_H("cm",2,25453);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 9L));
	RTOSE (15220);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15220 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15220,F1728_15220_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.roman_tens */
static EIF_REFERENCE F1728_15221_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15221);
#define Result RTOSR(15221)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = F1162_8524(Current);
	F880_4366(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 9L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("x",1,120);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("xx",2,30840);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("xxx",3,7895160);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 3L));
	tr1 = RTMS_EX_H("xl",2,30828);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("l",1,108);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 5L));
	tr1 = RTMS_EX_H("lx",2,27768);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 6L));
	tr1 = RTMS_EX_H("lxx",3,7108728);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 7L));
	tr1 = RTMS_EX_H("lxxx",4,1819834488);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 8L));
	tr1 = RTMS_EX_H("xc",2,30819);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 9L));
	RTOSE (15221);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15221 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15221,F1728_15221_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.roman_units */
static EIF_REFERENCE F1728_15222_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15222);
#define Result RTOSR(15222)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = F1162_8524(Current);
	F880_4366(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 9L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("i",1,105);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("ii",2,26985);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("iii",3,6908265);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 3L));
	tr1 = RTMS_EX_H("iv",2,26998);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("v",1,118);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 5L));
	tr1 = RTMS_EX_H("vi",2,30313);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 6L));
	tr1 = RTMS_EX_H("vii",3,7760233);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 7L));
	tr1 = RTMS_EX_H("viii",4,1986619753);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 8L));
	tr1 = RTMS_EX_H("ix",2,27000);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 9L));
	RTOSE (15222);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15222 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15222,F1728_15222_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.converted_number */
EIF_REFERENCE F1728_15223 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc4);
	RTLR(6,tr1);
	RTLR(7,loc2);
	RTLR(8,arg2);
	RTLR(9,tr2);
	RTLR(10,arg5);
	RTLR(11,arg6);
	RTLIU(12);
	
	RTGC;
	Result = F1162_8524(Current);
	loc1 = F1162_8524(Current);
	loc3 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1748_15533(RTCW(loc3), arg1);
	loc4 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1748_15536(RTCW(loc4), ((EIF_INTEGER_32) 10L));
	for (;;) {
		tb1 = F1748_15568(RTCW(loc3));
		if (tb1) break;
		tr1 = F172_1553(Current);
		tr1 = F1748_15594(RTCW(loc3), loc4, tr1);
		loc5 = F1748_15584(RTCW(tr1));
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L));
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg2))-1111])(arg2, loc5, loc5);
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr1 = F1148_8377(RTCW(tr1), loc2, loc1);
		loc1 = (EIF_REFERENCE) tr1;
		tr1 = F172_1553(Current);
		tr1 = F1748_15593(RTCW(loc3), loc4, tr1);
		loc3 = (EIF_REFERENCE) tr1;
	}
	loc2 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1111_6438(RTCW(loc2), ((EIF_INTEGER_32) 0L));
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc5 > (EIF_INTEGER_32) (arg3 - ti4_1))) break;
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg2))-1111])(arg2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
		tr1 = F1148_8377(RTCW(tr1), loc2, tr2);
		loc2 = (EIF_REFERENCE) tr1;
		loc5++;
	}
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr1 = F1148_8377(RTCW(tr1), loc2, loc1);
	loc2 = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN) (arg4 > ((EIF_INTEGER_32) 0L))) {
		loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (loc5 > ti4_2)) break;
			tb2 = '\0';
			if ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 1L))) {
				ti4_3 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
				tb2 = (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_3 + ((EIF_INTEGER_32) 1L)) - loc5) % arg4) == ((EIF_INTEGER_32) 0L));
			}
			if (tb2) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr1 = F1148_8377(RTCW(tr1), Result, arg5);
				Result = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc2))-1111])(loc2, loc5, loc5);
			tr1 = F1148_8377(RTCW(tr1), Result, tr2);
			Result = (EIF_REFERENCE) tr1;
			loc5++;
		}
	} else {
		Result = (EIF_REFERENCE) loc2;
	}
	ti4_3 = *(EIF_INTEGER_32 *)(RTCW(arg6)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_3 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = F1728_15237(Current, arg1);
		tr1 = F1148_8377(RTCW(tr1), Result, tr2);
		Result = (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_NUMBERER_EN}.converted_roman_numerals */
EIF_REFERENCE F1728_15224 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1748_15536(RTCW(loc1), ((EIF_INTEGER_32) 4000L));
	tr1 = F172_1553(Current);
	tr1 = F1748_15605(RTCW(arg1), loc1, tr1);
	tb1 = F1748_15562(RTCW(tr1));
	if (tb1) {
		tr1 = F1748_15587(RTCW(arg1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tr1 = RTOSCF(15219,F1728_15219, (Current));
		ti4_1 = F1748_15584(RTCW(arg1));
		tr1 = F880_4371(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 / ((EIF_INTEGER_32) 1000L)));
		F1111_6440(RTCW(Result), tr1);
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15220,F1728_15220, (Current));
		ti4_1 = F1748_15584(RTCW(arg1));
		tr2 = F880_4371(RTCW(tr2), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 / ((EIF_INTEGER_32) 100L)) % ((EIF_INTEGER_32) 10L)));
		tr1 = F1148_8377(RTCW(tr1), Result, tr2);
		Result = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15221,F1728_15221, (Current));
		ti4_1 = F1748_15584(RTCW(arg1));
		tr2 = F880_4371(RTCW(tr2), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 / ((EIF_INTEGER_32) 10L)) % ((EIF_INTEGER_32) 10L)));
		tr1 = F1148_8377(RTCW(tr1), Result, tr2);
		Result = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15222,F1728_15222, (Current));
		ti4_1 = F1748_15584(RTCW(arg1));
		tr2 = F880_4371(RTCW(tr2), (EIF_INTEGER_32) (ti4_1 % ((EIF_INTEGER_32) 10L)));
		tr1 = F1148_8377(RTCW(tr1), Result, tr2);
		Result = (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_NUMBERER_EN}.alphabetic_number */
EIF_REFERENCE F1728_15225 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,arg2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS_EX_H("0",1,48);
		Result = F1162_8520(Current, tr1);
	} else {
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)) % loc1) + ((EIF_INTEGER_32) 1L));
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg2))-1111])(arg2, loc2, loc2);
		if ((EIF_BOOLEAN) (arg1 > loc1)) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = F1728_15225(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)) / loc1), arg2);
			Result = F1148_8377(RTCW(tr1), tr2, loc3);
		} else {
			RTLE;
			return (EIF_REFERENCE) loc3;
		}
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_NUMBERER_EN}.cased_words_number */
EIF_REFERENCE F1728_15226 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS_EX_H("Zero",4,1516597871);
		Result = F1162_8520(Current, tr1);
	} else {
		Result = F1728_15227(Current, arg1);
	}
	if ((EIF_BOOLEAN) !arg2) {
		if (arg3) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5053[Dtype(RTCW(Result))-1112])(Result);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(Result))-1112])(Result);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_NUMBERER_EN}.words_number */
EIF_REFERENCE F1728_15227 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 1000000000L))) {
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 1000000000L));
		tr1 = F1728_15227(Current, (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1000000000L)));
		tr2 = RTMS_EX_H(" Billion",8,892700526);
		tr2 = F1162_8520(Current, tr2);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
		if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 100L))) {
				tr1 = RTMS_EX_H(" and ",5,1634870304);
				tr1 = F1162_8520(Current, tr1);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
				Result = (EIF_REFERENCE) tr1;
			} else {
				tr1 = RTMS_EX_H(" ",1,32);
				tr1 = F1162_8520(Current, tr1);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
				Result = (EIF_REFERENCE) tr1;
			}
			tr1 = F1728_15227(Current, loc1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
			Result = (EIF_REFERENCE) tr1;
		}
	} else {
		if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 1000000L))) {
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 1000000L));
			tr1 = F1728_15227(Current, (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1000000L)));
			tr2 = RTMS_EX_H(" Million",8,2134222190);
			tr2 = F1162_8520(Current, tr2);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
			if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
				if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 100L))) {
					tr1 = RTMS_EX_H(" and ",5,1634870304);
					tr1 = F1162_8520(Current, tr1);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
					Result = (EIF_REFERENCE) tr1;
				} else {
					tr1 = RTMS_EX_H(" ",1,32);
					tr1 = F1162_8520(Current, tr1);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
					Result = (EIF_REFERENCE) tr1;
				}
				tr1 = F1728_15227(Current, loc1);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
				Result = (EIF_REFERENCE) tr1;
			}
		} else {
			if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 1000L))) {
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 1000L));
				tr1 = F1728_15227(Current, (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1000L)));
				tr2 = RTMS_EX_H(" Thousand",9,572127844);
				tr2 = F1162_8520(Current, tr2);
				Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
				if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
					if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 100L))) {
						tr1 = RTMS_EX_H(" and ",5,1634870304);
						tr1 = F1162_8520(Current, tr1);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
						Result = (EIF_REFERENCE) tr1;
					} else {
						tr1 = RTMS_EX_H(" ",1,32);
						tr1 = F1162_8520(Current, tr1);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
						Result = (EIF_REFERENCE) tr1;
					}
					tr1 = F1728_15227(Current, loc1);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
					Result = (EIF_REFERENCE) tr1;
				}
			} else {
				if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 100L))) {
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L));
					tr1 = F1728_15227(Current, (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 100L)));
					tr2 = RTMS_EX_H(" Hundred",8,1655097444);
					tr2 = F1162_8520(Current, tr2);
					Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
					if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
						if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
							tr1 = RTMS_EX_H(" and ",5,1634870304);
							tr1 = F1162_8520(Current, tr1);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
							Result = (EIF_REFERENCE) tr1;
						}
						tr1 = F1728_15227(Current, loc1);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
						Result = (EIF_REFERENCE) tr1;
					}
				} else {
					if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 20L))) {
						tr1 = RTOSCF(15231,F1728_15231, (Current));
						Result = F880_4371(RTCW(tr1), arg1);
					} else {
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L));
						tr1 = RTOSCF(15230,F1728_15230, (Current));
						Result = F880_4371(RTCW(tr1), (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 10L)));
						if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
							tr1 = RTMS_EX_H(" ",1,32);
							tr1 = F1162_8520(Current, tr1);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
							tr2 = RTOSCF(15231,F1728_15231, (Current));
							tr2 = F880_4371(RTCW(tr2), loc1);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
							Result = (EIF_REFERENCE) tr1;
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_NUMBERER_EN}.cased_ordinal_number */
EIF_REFERENCE F1728_15228 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS_EX_H("Zeroth",6,2097629800);
		Result = F1162_8520(Current, tr1);
	} else {
		Result = F1728_15229(Current, arg1);
	}
	if ((EIF_BOOLEAN) !arg2) {
		if (arg3) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5053[Dtype(RTCW(Result))-1112])(Result);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(Result))-1112])(Result);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_NUMBERER_EN}.ordinal_number */
EIF_REFERENCE F1728_15229 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 1000000000L))) {
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 1000000000L));
		tr1 = F1728_15227(Current, (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1000000000L)));
		tr2 = RTMS_EX_H(" Billion",8,892700526);
		tr2 = F1162_8520(Current, tr2);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
			tr1 = RTMS_EX_H("th",2,29800);
			tr1 = F1162_8520(Current, tr1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
			Result = (EIF_REFERENCE) tr1;
		} else {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 100L))) {
				tr1 = RTMS_EX_H(" and ",5,1634870304);
				tr1 = F1162_8520(Current, tr1);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
				Result = (EIF_REFERENCE) tr1;
			} else {
				tr1 = RTMS_EX_H(" ",1,32);
				tr1 = F1162_8520(Current, tr1);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
				Result = (EIF_REFERENCE) tr1;
			}
			tr1 = F1728_15229(Current, loc1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
			Result = (EIF_REFERENCE) tr1;
		}
	} else {
		if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 1000000L))) {
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 1000000L));
			tr1 = F1728_15227(Current, (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1000000L)));
			tr2 = RTMS_EX_H(" Million",8,2134222190);
			tr2 = F1162_8520(Current, tr2);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
			if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
				tr1 = RTMS_EX_H("th",2,29800);
				tr1 = F1162_8520(Current, tr1);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
				Result = (EIF_REFERENCE) tr1;
			} else {
				if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 100L))) {
					tr1 = RTMS_EX_H(" and ",5,1634870304);
					tr1 = F1162_8520(Current, tr1);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
					Result = (EIF_REFERENCE) tr1;
				} else {
					tr1 = RTMS_EX_H(" ",1,32);
					tr1 = F1162_8520(Current, tr1);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
					Result = (EIF_REFERENCE) tr1;
				}
				tr1 = F1728_15229(Current, loc1);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
				Result = (EIF_REFERENCE) tr1;
			}
		} else {
			if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 1000L))) {
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 1000L));
				tr1 = F1728_15227(Current, (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1000L)));
				tr2 = RTMS_EX_H(" Thousand",9,572127844);
				tr2 = F1162_8520(Current, tr2);
				Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
				if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
					tr1 = RTMS_EX_H("th",2,29800);
					tr1 = F1162_8520(Current, tr1);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
					Result = (EIF_REFERENCE) tr1;
				} else {
					if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 100L))) {
						tr1 = RTMS_EX_H(" and ",5,1634870304);
						tr1 = F1162_8520(Current, tr1);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
						Result = (EIF_REFERENCE) tr1;
					} else {
						tr1 = RTMS_EX_H(" ",1,32);
						tr1 = F1162_8520(Current, tr1);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
						Result = (EIF_REFERENCE) tr1;
					}
					tr1 = F1728_15229(Current, loc1);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
					Result = (EIF_REFERENCE) tr1;
				}
			} else {
				if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 100L))) {
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L));
					tr1 = F1728_15227(Current, (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 100L)));
					tr2 = RTMS_EX_H(" Hundred",8,1655097444);
					tr2 = F1162_8520(Current, tr2);
					Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
						tr1 = RTMS_EX_H("th",2,29800);
						tr1 = F1162_8520(Current, tr1);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
						Result = (EIF_REFERENCE) tr1;
					} else {
						if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
							tr1 = RTMS_EX_H(" and ",5,1634870304);
							tr1 = F1162_8520(Current, tr1);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
							Result = (EIF_REFERENCE) tr1;
						}
						tr1 = F1728_15229(Current, loc1);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(Result))-1111])(Result, tr1);
						Result = (EIF_REFERENCE) tr1;
					}
				} else {
					if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 20L))) {
						tr1 = RTOSCF(15233,F1728_15233, (Current));
						Result = F880_4371(RTCW(tr1), arg1);
					} else {
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L));
						if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
							tr1 = RTOSCF(15232,F1728_15232, (Current));
							Result = F880_4371(RTCW(tr1), (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 10L)));
						} else {
							tr1 = RTOSCF(15230,F1728_15230, (Current));
							tr1 = F880_4371(RTCW(tr1), (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 10L)));
							tr2 = RTMS_EX_H("-",1,45);
							tr2 = F1162_8520(Current, tr2);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
							tr2 = RTOSCF(15233,F1728_15233, (Current));
							tr2 = F880_4371(RTCW(tr2), loc1);
							Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_NUMBERER_EN}.english_tens */
static EIF_REFERENCE F1728_15230_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15230);
#define Result RTOSR(15230)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = F1162_8524(Current);
	F880_4366(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 9L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("Ten",3,5530990);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("Twenty",6,1867802233);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("Thirty",6,1935058041);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 3L));
	tr1 = RTMS_EX_H("Forty",5,1870309497);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("Fifty",5,1768859769);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 5L));
	tr1 = RTMS_EX_H("Sixty",5,1770139257);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 6L));
	tr1 = RTMS_EX_H("Seventy",7,726889593);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 7L));
	tr1 = RTMS_EX_H("Eighty",6,1871364729);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 8L));
	tr1 = RTMS_EX_H("Ninety",6,2006303353);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 9L));
	RTOSE (15230);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15230 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15230,F1728_15230_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.english_units */
static EIF_REFERENCE F1728_15231_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15231);
#define Result RTOSR(15231)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = RTMS_EX_H("",0,0);
	F880_4366(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 19L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("One",3,5205605);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("Two",3,5535599);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("Three",5,1752972645);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 3L));
	tr1 = RTMS_EX_H("Four",4,1181709682);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("Five",4,1181316709);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 5L));
	tr1 = RTMS_EX_H("Six",3,5466488);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 6L));
	tr1 = RTMS_EX_H("Seven",5,1702895470);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 7L));
	tr1 = RTMS_EX_H("Eight",5,1768914548);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 8L));
	tr1 = RTMS_EX_H("Nine",4,1315532389);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 9L));
	tr1 = RTMS_EX_H("Ten",3,5530990);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 10L));
	tr1 = RTMS_EX_H("Eleven",6,1838746990);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 11L));
	tr1 = RTMS_EX_H("Twelve",6,1867671653);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 12L));
	tr1 = RTMS_EX_H("Thirteen",8,837388398);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 13L));
	tr1 = RTMS_EX_H("Fourteen",8,86011502);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 14L));
	tr1 = RTMS_EX_H("Fifteen",7,885020782);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 15L));
	tr1 = RTMS_EX_H("Sixteen",7,985833838);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 16L));
	tr1 = RTMS_EX_H("Seventeen",9,2037981038);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 17L));
	tr1 = RTMS_EX_H("Eighteen",8,1333239918);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 18L));
	tr1 = RTMS_EX_H("Nineteen",8,1349053038);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 19L));
	RTOSE (15231);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15231 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15231,F1728_15231_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.english_ordinal_tens */
static EIF_REFERENCE F1728_15232_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15232);
#define Result RTOSR(15232)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = F1162_8524(Current);
	F880_4366(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 9L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("Tenth",5,1702382696);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("Twentieth",9,1967844968);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("Thirtieth",9,1838039400);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 3L));
	tr1 = RTMS_EX_H("Fortieth",8,2043062888);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("Fiftieth",8,1147050856);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 5L));
	tr1 = RTMS_EX_H("Sixtieth",8,1185435496);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 6L));
	tr1 = RTMS_EX_H("Seventieth",10,2100142696);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 7L));
	tr1 = RTMS_EX_H("Eightieth",9,2074719848);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 8L));
	tr1 = RTMS_EX_H("Ninetieth",9,1827918952);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 9L));
	RTOSE (15232);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15232 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15232,F1728_15232_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.english_ordinal_units */
static EIF_REFERENCE F1728_15233_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15233);
#define Result RTOSR(15233)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = RTMS_EX_H("",0,0);
	F880_4366(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 19L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("First",5,1769645940);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("Second",6,1832207460);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("Third",5,1752386148);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 3L));
	tr1 = RTMS_EX_H("Fourth",6,2108913256);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("Fifth",5,1768859752);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 5L));
	tr1 = RTMS_EX_H("Sixth",5,1770139240);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 6L));
	tr1 = RTMS_EX_H("Seventh",7,726889576);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 7L));
	tr1 = RTMS_EX_H("Eighth",6,1871364712);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 8L));
	tr1 = RTMS_EX_H("Ninth",5,1769445480);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 9L));
	tr1 = RTMS_EX_H("Tenth",5,1702382696);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 10L));
	tr1 = RTMS_EX_H("Eleventh",8,440820328);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 11L));
	tr1 = RTMS_EX_H("Twelfth",7,1382381160);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 12L));
	tr1 = RTMS_EX_H("Thirteenth",10,239587688);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 13L));
	tr1 = RTMS_EX_H("Fourteenth",10,1862808680);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 14L));
	tr1 = RTMS_EX_H("Fifteenth",9,1587344488);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 15L));
	tr1 = RTMS_EX_H("Sixteenth",9,676413288);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 16L));
	tr1 = RTMS_EX_H("Seventeenth",11,766157416);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 17L));
	tr1 = RTMS_EX_H("Eighteenth",10,700347752);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 18L));
	tr1 = RTMS_EX_H("Nineteenth",10,1943712616);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 19L));
	RTOSE (15233);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15233 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15233,F1728_15233_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.english_months */
static EIF_REFERENCE F1728_15234_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15234);
#define Result RTOSR(15234)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = RTMS_EX_H("",0,0);
	F880_4366(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 12L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("January",7,751658105);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("February",8,1474449017);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("March",5,1635477864);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 3L));
	tr1 = RTMS_EX_H("April",5,1887045484);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("May",3,5071225);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 5L));
	tr1 = RTMS_EX_H("June",4,1249209957);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 6L));
	tr1 = RTMS_EX_H("July",4,1249209465);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 7L));
	tr1 = RTMS_EX_H("August",6,1864444276);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 8L));
	tr1 = RTMS_EX_H("September",9,1077346930);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 9L));
	tr1 = RTMS_EX_H("October",7,1024137842);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 10L));
	tr1 = RTMS_EX_H("November",8,2119563634);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 11L));
	tr1 = RTMS_EX_H("December",8,1341698930);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 12L));
	RTOSE (15234);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15234 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15234,F1728_15234_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.english_days */
static EIF_REFERENCE F1728_15235_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15235);
#define Result RTOSR(15235)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = RTMS_EX_H("",0,0);
	F880_4366(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 7L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("Sunday",6,2016155513);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 7L));
	tr1 = RTMS_EX_H("Monday",6,2004312953);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("Tuesday",7,1495753593);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("Wednesday",9,1804915065);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 3L));
	tr1 = RTMS_EX_H("Thursday",8,844137593);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("Friday",6,1906687353);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 5L));
	tr1 = RTMS_EX_H("Saturday",8,1596931193);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 6L));
	RTOSE (15235);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15235 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15235,F1728_15235_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.english_day_abbreviations */
static EIF_REFERENCE F1728_15236_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15236);
#define Result RTOSR(15236)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = RTMS_EX_H("",0,0);
	F880_4366(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 7L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("Sun",3,5469550);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 7L));
	tr1 = RTMS_EX_H("Mon",3,5074798);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTMS_EX_H("Tues",4,1416979827);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	tr1 = RTMS_EX_H("Weds",4,1466262643);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 3L));
	tr1 = RTMS_EX_H("Thurs",5,1753172595);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 4L));
	tr1 = RTMS_EX_H("Fri",3,4616809);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 5L));
	tr1 = RTMS_EX_H("Sat",3,5464436);
	tr1 = F1162_8520(Current, tr1);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 6L));
	RTOSE (15236);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15236 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15236,F1728_15236_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.ordinal_suffix */
EIF_REFERENCE F1728_15237 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(15238,F1728_15238, (Current));
	tr1 = F1748_15576(RTCW(arg1), tr1);
	loc1 = F1748_15584(RTCW(tr1));
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 / ((EIF_INTEGER_32) 10L));
	tr1 = RTOSCF(15239,F1728_15239, (Current));
	tr1 = F1748_15576(RTCW(arg1), tr1);
	loc2 = F1748_15584(RTCW(tr1));
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 1L))) {
		tr1 = RTMS_EX_H("th",2,29800);
		Result = F1162_8520(Current, tr1);
	} else {
		switch (loc2) {
			case 1L:
				tr1 = RTMS_EX_H("st",2,29556);
				Result = F1162_8520(Current, tr1);
				break;
			case 2L:
				tr1 = RTMS_EX_H("nd",2,28260);
				Result = F1162_8520(Current, tr1);
				break;
			case 3L:
				tr1 = RTMS_EX_H("rd",2,29284);
				Result = F1162_8520(Current, tr1);
				break;
			default:
				tr1 = RTMS_EX_H("th",2,29800);
				Result = F1162_8520(Current, tr1);
				break;
		}
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_NUMBERER_EN}.hundred */
static EIF_REFERENCE F1728_15238_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (15238);
#define Result RTOSR(15238)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1748_15536(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15238);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15238 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15238,F1728_15238_body,(Current));
}

/* {ST_XSLT_NUMBERER_EN}.ten */
static EIF_REFERENCE F1728_15239_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (15239);
#define Result RTOSR(15239)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1748_15536(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15239);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_15239 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15239,F1728_15239_body,(Current));
}

void EIF_Minit801 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
