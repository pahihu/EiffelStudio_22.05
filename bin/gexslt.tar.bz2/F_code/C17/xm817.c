/*
 * Code for class XM_XSLT_TRANSFORMER_RECEIVER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm817.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_TRANSFORMER_RECEIVER}.make */
void F1744_15470 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,loc1);
	RTLR(4,arg3);
	RTLR(5,tr1);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	loc1 = RTLNSMART(eif_new_type(1706, 0).id);
	F1707_14586(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg3;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = F2152_21400(RTCW(tr2));
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = F2152_21401(RTCW(tr1), tr2, tr3, loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1729_15264(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1729_15263(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F2152_21399(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_TRANSFORMER_RECEIVER}.document_pool */
EIF_REFERENCE F1744_15474 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_32_);
	RTLE;
	return Result;
}

/* {XM_XSLT_TRANSFORMER_RECEIVER}.close */
void F1744_15475 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	F1734_15329(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1862, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTCT0("attached document_uri as l_document_uri", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = F1744_15474(Current);
		tr2 = *(EIF_REFERENCE *)(loc2);
		tb1 = F1579_12950(RTCW(tr1), tr2);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(loc2);
			F209_1912(Current, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_2_);
		tr3 = F1707_14605(loc2);
		tr2 = RTOSCF(15701,F1750_15701, (RTCW(tr2), tr3));
		tr3 = F1707_14605(loc2);
		F2152_21411(RTCW(tr1), loc1, tr2, tr3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F2152_21420(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + _REFACS_3_));
	}
	RTLE;
}

void EIF_Minit817 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
