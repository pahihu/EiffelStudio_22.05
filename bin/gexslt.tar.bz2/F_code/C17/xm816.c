/*
 * Code for class XM_XSLT_NORMALIZING_FILTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm816.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_NORMALIZING_FILTER}.make */
void F1743_15467 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O11856[Dtype(arg1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	F1724_15188(Current, arg2, arg3);
	RTLE;
}

/* {XM_XSLT_NORMALIZING_FILTER}.notify_attribute */
void F1743_15468 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1412_11675(Current, arg4)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9435[Dtype(loc2)-1396])(loc2, arg3);
		} else {
			loc1 = (EIF_REFERENCE) arg3;
		}
		F1734_15322(Current, arg1, arg2, loc1, arg4);
	} else {
		F1734_15322(Current, arg1, arg2, arg3, arg4);
	}
	RTLE;
}

/* {XM_XSLT_NORMALIZING_FILTER}.notify_characters */
void F1743_15469 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1412_11675(Current, arg2)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9435[Dtype(loc2)-1396])(loc2, arg1);
		} else {
			loc1 = (EIF_REFERENCE) arg1;
		}
		F1734_15325(Current, loc1, arg2);
	} else {
		F1734_15325(Current, arg1, arg2);
	}
	RTLE;
}

void EIF_Minit816 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
