/*
 * Code for class XM_XSLT_USE_WHEN_FILTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm812.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_USE_WHEN_FILTER}.make */
void F1739_15395 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg3;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O11856[Dtype(tr1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O11855[Dtype(tr1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg2;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1496,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1439_11749(RTCW(tr1), tr2);
	RTLE;
}

/* {XM_XSLT_USE_WHEN_FILTER}.set_tag_buffer */
void F1739_15398 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) arg1;
}

/* {XM_XSLT_USE_WHEN_FILTER}.open */
void F1739_15399 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_9_) == NULL)) {
		tr1 = RTMS_EX_H("Configuration error in use-when filter - no start tag buffer",60,951547762);
		F1734_15316(Current, tr1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_6_) == NULL)) {
			tr1 = RTMS_EX_H("Configuration error in use-when filter - no document locator",60,806062962);
			F1734_15316(Current, tr1);
		} else {
			tr1 = RTOSCF(4950,F991_4950, (Current));
			tr2 = RTOSCF(9820,F1230_9820, (Current));
			tr3 = RTOSCF(9820,F1230_9820, (Current));
			tr4 = RTOSCF(2579,F331_2579, (Current));
			tb1 = F1242_10430(RTCW(tr1), tr2, tr3, tr4);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = RTOSCF(4950,F991_4950, (Current));
				tr2 = RTOSCF(9820,F1230_9820, (Current));
				tr3 = RTOSCF(9820,F1230_9820, (Current));
				tr4 = RTOSCF(2579,F331_2579, (Current));
				F1242_10444(RTCW(tr1), tr2, tr3, tr4);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(4950,F991_4950, (Current)))+ _LNGOFF_4_0_0_0_);
				ti4_1 = F1227_9769(Current, ti4_1);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_0_) = (EIF_INTEGER_32) ti4_1;
			} else {
				tr1 = RTOSCF(4950,F991_4950, (Current));
				tr2 = RTOSCF(9820,F1230_9820, (Current));
				tr3 = RTOSCF(9820,F1230_9820, (Current));
				tr4 = RTOSCF(2579,F331_2579, (Current));
				ti4_1 = F1242_10413(RTCW(tr1), tr2, tr3, tr4);
				ti4_1 = F1227_9769(Current, ti4_1);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_0_) = (EIF_INTEGER_32) ti4_1;
			}
			tr1 = RTOSCF(4950,F991_4950, (Current));
			tr2 = RTOSCF(9820,F1230_9820, (Current));
			tr3 = RTOSCF(9820,F1230_9820, (Current));
			tr4 = RTOSCF(2583,F331_2583, (Current));
			tb1 = F1242_10430(RTCW(tr1), tr2, tr3, tr4);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = RTOSCF(4950,F991_4950, (Current));
				tr2 = RTOSCF(9820,F1230_9820, (Current));
				tr3 = RTOSCF(9820,F1230_9820, (Current));
				tr4 = RTOSCF(2583,F331_2583, (Current));
				F1242_10444(RTCW(tr1), tr2, tr3, tr4);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(4950,F991_4950, (Current)))+ _LNGOFF_4_0_0_0_);
				ti4_1 = F1227_9769(Current, ti4_1);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_1_) = (EIF_INTEGER_32) ti4_1;
			} else {
				tr1 = RTOSCF(4950,F991_4950, (Current));
				tr2 = RTOSCF(9820,F1230_9820, (Current));
				tr3 = RTOSCF(9820,F1230_9820, (Current));
				tr4 = RTOSCF(2583,F331_2583, (Current));
				ti4_1 = F1242_10413(RTCW(tr1), tr2, tr3, tr4);
				ti4_1 = F1227_9769(Current, ti4_1);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_1_) = (EIF_INTEGER_32) ti4_1;
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11865[Dtype(RTCW(tr1))-1732])(tr1);
	RTLE;
}

/* {XM_XSLT_USE_WHEN_FILTER}.start_element */
void F1739_15400 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc8);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc9);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,loc5);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTGC;
	RTCT0("start_tag_buffer_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTCT0("locator_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1734_15315(Current);
	tr1 = RTOSCF(4950,F991_4950, (Current));
	loc1 = F1242_10449(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 5L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		tr2 = F1737_15360(loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_1_));
		F1497_12105(RTCW(tr1), tr2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		tr2 = F1737_15360(loc8, ((EIF_INTEGER_32) 1330L));
		F1497_12105(RTCW(tr1), tr2);
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_4_)) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_2_))++;
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_2_) == ((EIF_INTEGER_32) 0L))) {
			if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 5L))) {
				loc3 = F1737_15360(loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_0_));
			} else {
				loc3 = F1737_15360(loc8, ((EIF_INTEGER_32) 1335L));
			}
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				loc5 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3236[Dtype(loc9)-475])(loc9);
				F1707_14586(RTCW(loc5), tr1);
				loc4 = F1737_15360(loc8, ((EIF_INTEGER_32) 257L));
				if ((EIF_BOOLEAN)(loc4 != NULL)) {
					tr1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
					F1707_14587(RTCW(tr1), loc5, loc4);
					loc5 = (EIF_REFERENCE) tr1;
				}
				F1739_15417(Current, loc3, loc5, loc6);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_5_)) {
					loc2 = F1227_9769(Current, arg1);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1322L)) || (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1325L)))) {
						*(EIF_BOOLEAN *)(Current+ _CHROFF_11_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
			}
			if ((EIF_BOOLEAN) !loc7) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R11868[Dtype(RTCW(tr1))-1732])(tr1, arg1, arg2, arg3);
			}
		} else {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_2_))++;
		}
	}
	RTLE;
}

/* {XM_XSLT_USE_WHEN_FILTER}.notify_namespace */
void F1739_15401 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1734_15315(Current);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_2_) == ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11869[Dtype(RTCW(tr1))-1732])(tr1, arg1, arg2);
	}
	RTLE;
}

/* {XM_XSLT_USE_WHEN_FILTER}.notify_attribute */
void F1739_15402 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTGC;
	F1734_15315(Current);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_2_) == ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_INTEGER_32)) R11870[Dtype(RTCW(tr1))-1732])(tr1, arg1, arg2, arg3, arg4);
	}
	RTLE;
}

/* {XM_XSLT_USE_WHEN_FILTER}.start_content */
void F1739_15403 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1734_15315(Current);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_2_) == ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11871[Dtype(RTCW(tr1))-1732])(tr1);
	}
	RTLE;
}

/* {XM_XSLT_USE_WHEN_FILTER}.end_element */
void F1739_15404 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1734_15315(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1497_12110(RTCW(tr1));
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_2_) > ((EIF_INTEGER_32) 0L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_2_))--;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11872[Dtype(RTCW(tr1))-1732])(tr1);
	}
	RTLE;
}

/* {XM_XSLT_USE_WHEN_FILTER}.notify_characters */
void F1739_15405 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	F1734_15315(Current);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_6_0_2_) == ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, arg1, arg2);
	}
	RTLE;
}

/* {XM_XSLT_USE_WHEN_FILTER}.notify_processing_instruction */
void F1739_15406 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	RTGC;
}

/* {XM_XSLT_USE_WHEN_FILTER}.notify_comment */
void F1739_15407 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	RTGC;
}

/* {XM_XSLT_USE_WHEN_FILTER}.set_document_locator */
void F1739_15408 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11880[Dtype(RTCW(tr1))-1732])(tr1, arg1);
	RTLE;
}

/* {XM_XSLT_USE_WHEN_FILTER}.evaluate_use_when */
void F1739_15417 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(20);
	RTLR(0,loc9);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc10);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,loc1);
	RTLR(7,arg2);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,arg1);
	RTLR(11,loc11);
	RTLR(12,loc5);
	RTLR(13,loc8);
	RTLR(14,loc12);
	RTLR(15,loc13);
	RTLR(16,loc6);
	RTLR(17,loc7);
	RTLR(18,loc14);
	RTLR(19,loc15);
	RTLIU(20);
	
	RTGC;
	RTCT0("precondition_locator_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTCT0("precondition_start_tag_buffer_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		RTCK0;
	} else {
		RTCF0;
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1496,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc2 = RTLNSMART(typres0.id);
	}
	F1497_12103(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	for (;;) {
		tb1 = '\01';
		tb2 = F1418_11697(RTCW(loc2));
		if (!tb2) {
			tb1 = loc4;
		}
		if (tb1) break;
		loc3 = F1497_12100(RTCW(loc2));
		F1497_12110(RTCW(loc2));
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		loc3 = RTMS_EX_H("",0,0);
	}
	loc1 = RTLNS(eif_new_type(1240, 0x01).id, 1240, _OBJSIZ_10_2_0_2_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3236[Dtype(loc9)-475])(loc9);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R3237[Dtype(loc9)-475])(loc9);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1241_10383(RTCW(loc1), tr1, loc10, arg2, tr2, ti4_1, loc3, arg3, tr3);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R3237[Dtype(loc9)-475])(loc9);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3236[Dtype(loc9)-475])(loc9);
	F1635_13735(Current, arg1, loc1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 0L), ti4_1, tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		tr1 = F1709_14679(loc11);
		F1734_15316(Current, tr1);
	} else {
		loc5 = F1635_13733(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,209,1867,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc8 = RTLNS(typres0.id, 209, _OBJSIZ_1_0_0_0_0_0_0_0_);
		}
		F210_1916(RTCW(loc8), NULL);
		tr1 = RTOSCF(2593,F335_2593, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13942[Dtype(RTCW(loc5))-1868])(loc5, loc8, loc1, tr1);
		RTCT0("postcondition_of_check_static_type", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc8));
		loc12 = tr1;
		if (EIF_TEST(loc12)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc5 = (EIF_REFERENCE) loc12;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + O13838[Dtype(loc5)-1867]);
		loc13 = tr1;
		if (EIF_TEST(loc13)) {
			tr1 = F1709_14679(loc13);
			F1734_15316(Current, tr1);
		} else {
			loc6 = RTLNS(eif_new_type(27, 0x01).id, 27, _OBJSIZ_0_0_0_1_0_0_0_0_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) R13953[Dtype(RTCW(loc5))-1868])(loc5, ((EIF_INTEGER_32) 1L), loc6);
			loc7 = F1241_10400(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R12590[Dtype(RTCW(loc7))-1766])(loc7, loc6);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13946[Dtype(RTCW(loc5))-1868])(loc5, loc7);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + O13838[Dtype(loc5)-1867]);
			loc14 = tr1;
			if (EIF_TEST(loc14)) {
				tr1 = F1709_14679(loc14);
				F1734_15316(Current, tr1);
			} else {
				RTCT0("postcondition_of_calculate_effective_boolean_value", EX_CHECK);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + O13840[Dtype(loc5)-1867]);
				loc15 = tr1;
				if (EIF_TEST(loc15)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tb2 = *(EIF_BOOLEAN *)(loc15+ _CHROFF_7_37_);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_11_5_) = (EIF_BOOLEAN) tb2;
			}
		}
	}
	RTLE;
}

void EIF_Minit812 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
