/*
 * Code for class XM_XPATH_CONTEXT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm839.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_CONTEXT}.make_dynamic_context */
void F1766_16096 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1619, 0x01).id, 1619, _OBJSIZ_0_0_0_2_0_0_0_0_);
	F1620_13634(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	tr1 = RTOSCF(3565,F460_3565, (Current));
	F1722_15184(RTCW(tr1), loc1);
	loc2 = RTLNS(eif_new_type(1279, 0x01).id, 1279, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12561[Dtype(Current)-1766])(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
	F1280_10995(RTCW(loc2), tr1);
	tr1 = RTLNSMART(eif_new_type(1153, 0).id);
	F1153_8477(RTCW(tr1), loc1, loc2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	F1766_16142(Current);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13398[Dtype(RTCW(arg1))-1819])(arg1);
	if (tb1) {
		loc3 = RTLNS(eif_new_type(1695, 0x01).id, 1695, _OBJSIZ_4_2_0_1_0_0_0_0_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13416[Dtype(RTCW(arg1))-1819])(arg1);
		F1673_14197(RTCW(loc3), tr1);
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1672,0xFF01,1818,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc3 = RTLNS(typres0.id, 1672, _OBJSIZ_3_2_0_1_0_0_0_0_);
		}
		F1673_14197(RTCW(loc3), arg1);
	}
	RTAR(Current, loc3);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc3;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10853[Dtype(RTCW(loc3))-1636])(loc3);
	RTLE;
}

/* {XM_XPATH_CONTEXT}.current_date_time */
EIF_REFERENCE F1766_16105 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("attached internal_date_time as l_internal_date_time", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {XM_XPATH_CONTEXT}.context_item */
EIF_REFERENCE F1766_16107 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10839[Dtype(loc1)-1636])(loc1);
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R10853[Dtype(loc1)-1636])(loc1);
		}
		tr1 = *(EIF_REFERENCE *)(loc1 + O10835[Dtype(loc1)-1635]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			F1820_17198(RTCW(tr1), loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10840[Dtype(loc1)-1636])(loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10833[Dtype(loc1)-1636])(loc1);
				RTLE;
				return (EIF_REFERENCE) tr1;
			}
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {XM_XPATH_CONTEXT}.context_position */
EIF_INTEGER_32 F1766_16108 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTCT0("precondition_context_position_set", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = *(EIF_INTEGER_32 *)(loc1 + O10834[Dtype(loc1)-1635]);
	RTLE;
	return Result;
}

/* {XM_XPATH_CONTEXT}.last */
EIF_INTEGER_32 F1766_16109 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	RTCT0("precondition_context_position_set", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12596[dtype-1765]) == ((EIF_INTEGER_32) -1L))) {
		tb1 = *(EIF_BOOLEAN *)(loc2 + O10843[Dtype(loc2)-1635]);
		if ((EIF_BOOLEAN) !tb1) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10851[Dtype(loc2)-1636])(loc2);
			if (tb1) {
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10837[Dtype(loc2)-1636])(loc2);
				*(EIF_INTEGER_32 *)(Current + O12596[dtype-1765]) = (EIF_INTEGER_32) ti4_1;
			} else {
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10860[Dtype(loc2)-1636])(loc2);
				*(EIF_INTEGER_32 *)(Current + O12596[dtype-1765]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R10853[Dtype(RTCW(loc1))-1636])(loc1);
				for (;;) {
					tb1 = '\01';
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc1) + O10843[Dtype(loc1)-1635]);
					if (!tb2) {
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10840[Dtype(RTCW(loc1))-1636])(loc1);
						tb1 = tb2;
					}
					if (tb1) break;
					(*(EIF_INTEGER_32 *)(Current + O12596[dtype-1765]))++;
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R10854[Dtype(RTCW(loc1))-1636])(loc1);
				}
			}
		}
	}
	Result = *(EIF_INTEGER_32 *)(Current + O12596[dtype-1765]);
	RTLE;
	return Result;
}

/* {XM_XPATH_CONTEXT}.collator */
EIF_REFERENCE F1766_16110 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1525_12403(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {XM_XPATH_CONTEXT}.unicode_codepoint_collator */
EIF_REFERENCE F1766_16111 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(9833,F1230_9833, (Current));
	Result = F1766_16110(Current, tr1);
	RTLE;
	return Result;
}

/* {XM_XPATH_CONTEXT}.is_known_collation */
EIF_BOOLEAN F1766_16118 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1525_12411(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {XM_XPATH_CONTEXT}.is_context_position_set */
EIF_BOOLEAN F1766_16119 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = *(EIF_BOOLEAN *)(loc1 + O10843[Dtype(loc1)-1635]);
		Result = (EIF_BOOLEAN) !tb1;
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_CONTEXT}.is_at_last */
EIF_BOOLEAN F1766_16121 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1766_16108(Current);
	ti4_2 = F1766_16109(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

/* {XM_XPATH_CONTEXT}.is_uri_written */
EIF_BOOLEAN F1766_16125 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12554[Dtype(Current)-1766])(Current);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R12170[Dtype(RTCW(tr1))-1748])(tr1, arg1);
	RTLE;
	return Result;
}

/* {XM_XPATH_CONTEXT}.new_context */
EIF_REFERENCE F1766_16126 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1415_11685(Current);
}

/* {XM_XPATH_CONTEXT}.evaluated_local_variable */
EIF_REFERENCE F1766_16129 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	RTCT0("precondition_local_variables_frame_not_void", EX_CHECK);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12555[Dtype(Current)-1766])(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTCT0("attached l_local_variable_frame.variables.item (a_slot_number) as l_variable", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
	tr1 = F880_4371(RTCW(tr1), arg1);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc2;
	RTLE;
	return Result;
}

/* {XM_XPATH_CONTEXT}.set_current_iterator */
void F1766_16130 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	F1766_16142(Current);
	RTLE;
}

/* {XM_XPATH_CONTEXT}.set_current_receiver */
void F1766_16131 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {XM_XPATH_CONTEXT}.set_temporary_destination */
void F1766_16132 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O12570[Dtype(Current)-1765]) = (EIF_BOOLEAN) arg1;
}

/* {XM_XPATH_CONTEXT}.set_local_variable */
void F1766_16133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	RTCT0("precondition_local_variables_frame_not_void", EX_CHECK);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12555[Dtype(Current)-1766])(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F22_193(loc1, arg1, arg2);
	RTLE;
}

/* {XM_XPATH_CONTEXT}.set_receiver */
void F1766_16137 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {XM_XPATH_CONTEXT}.clear_last_cache */
void F1766_16142 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O12596[Dtype(Current)-1765]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
}

void EIF_Minit839 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
