/*
 * Code for class XM_XSLT_HTML_EMITTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm834.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_HTML_EMITTER}.make */
void F1761_16004 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	F1759_15947(Current, arg1, arg2, arg3);
	RTOSCP(16026,F1761_16026, (Current));
	RTLE;
}

/* {XM_XSLT_HTML_EMITTER}.start_element */
void F1761_16005 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	F1759_15954(Current, arg1, arg2, arg3);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr1 = F1503_12132(RTCW(tr1));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(tr1))-1112])(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(4950,F991_4950, (Current));
		ti4_1 = F1242_10449(RTCW(tr1), arg1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_5_) = (EIF_INTEGER_32) ti4_1;
		RTCT0("attached element_name as l_element_name", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tb1 = '\0';
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_5_) == ((EIF_INTEGER_32) 0L))) {
			tb2 = '\01';
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("script",6,2146372212);
			tb3 = F1148_8369(RTCW(tr1), loc1, tr2);
			if (!tb3) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H("style",5,1954997861);
				tb3 = F1148_8369(RTCW(tr1), loc1, tr2);
				tb2 = tb3;
			}
			tb1 = tb2;
		}
		if (tb1) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_4_))++;
	}
	RTLE;
}

/* {XM_XSLT_HTML_EMITTER}.start_content */
void F1761_16006 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_9_)) {
		tr1 = RTMS_EX_H("",0,0);
		F1759_15992(Current, tr1, (EIF_BOOLEAN) 0);
	}
	F1729_15248(Current);
	RTLE;
}

/* {XM_XSLT_HTML_EMITTER}.end_element */
void F1761_16007 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_4_))--;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_4_) <= ((EIF_INTEGER_32) 0L))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1000000L);
	}
	RTCT0("attached element_name as l_element_name", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tb1 = '\0';
	if (F1759_15978(Current, loc1)) {
		tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_5_) == ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F1503_12144(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr1 = F1503_12132(RTCW(tr1));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(tr1))-1112])(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	} else {
		F1759_15958(Current);
	}
	F1729_15248(Current);
	RTLE;
}

/* {XM_XSLT_HTML_EMITTER}.notify_characters */
void F1761_16008 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_4_) > ((EIF_INTEGER_32) 0L))) {
		tb1 = (EIF_BOOLEAN) !F1412_11675(Current, arg2);
	}
	if (tb1) {
		tr1 = RTOSCF(6771,F1118_6771, (Current));
		tr2 = RTOSCF(6771,F1118_6771, (Current));
		ti4_1 = F1174_8741(RTCW(tr2), ((EIF_INTEGER_32) 16L));
		loc1 = F1174_8738(RTCW(tr1), arg2, ti4_1);
		loc1 += ((EIF_INTEGER_32) 64L);
	} else {
		loc1 = (EIF_INTEGER_32) arg2;
	}
	F1759_15959(Current, arg1, loc1);
	RTLE;
}

/* {XM_XSLT_HTML_EMITTER}.notify_processing_instruction */
void F1761_16009 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLR(7,loc1);
	RTLR(8,arg1);
	RTLIU(9);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_)) {
		tc1 = (EIF_CHARACTER_8) '>';
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R3363[Dtype(RTCW(arg2))-768])(arg2, (EIF_REFERENCE) &tc1);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
			tr3 = RTMS_EX_H("HTML processing instructions may not conatina \'>\'",49,1272295975);
			tr4 = RTOSCF(9827,F1230_9827, (Current));
			tr5 = RTMS_EX_H("SERE0015",8,1358496565);
			F1709_14669(RTCW(tr2), tr3, tr4, tr5, ((EIF_INTEGER_32) 3L));
			F1710_14691(RTCW(tr1), tr2);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_6_)) {
				F1761_16027(Current);
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("<\?",2,15423);
			loc1 = F1148_8367(RTCW(tr1), tr2, arg1);
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H(" ",1,32);
			tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr1 = F1148_8377(RTCW(tr1), loc1, arg2);
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H(">",1,62);
			tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
			loc1 = (EIF_REFERENCE) tr1;
			F1759_15983(Current, loc1);
		}
	}
	F1729_15248(Current);
	RTLE;
}

/* {XM_XSLT_HTML_EMITTER}.boolean_attributes_set */
static EIF_REFERENCE F1761_16010_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (16010);
#define Result RTOSR(16010)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1521,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1521, _OBJSIZ_7_0_0_9_0_0_0_0_);
	}
	F1509_12240(RTCW(tr1), ((EIF_INTEGER_32) 17L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8115,F1125_8115, (Current));
	F1439_11749(RTCW(Result), tr1);
	RTOSE (16010);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1761_16010 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16010,F1761_16010_body,(Current));
}

/* {XM_XSLT_HTML_EMITTER}.boolean_combinations_set */
static EIF_REFERENCE F1761_16011_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (16011);
#define Result RTOSR(16011)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1521,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1521, _OBJSIZ_7_0_0_9_0_0_0_0_);
	}
	F1509_12240(RTCW(tr1), ((EIF_INTEGER_32) 24L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8115,F1125_8115, (Current));
	F1439_11749(RTCW(Result), tr1);
	RTOSE (16011);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1761_16011 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16011,F1761_16011_body,(Current));
}

/* {XM_XSLT_HTML_EMITTER}.latin1_entities */
static EIF_REFERENCE F1761_16023_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (16023);
#define Result RTOSR(16023)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 879, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = RTMS_EX_H("",0,0);
	F880_4366(RTCW(tr1), tr2, ((EIF_INTEGER_32) 161L), ((EIF_INTEGER_32) 255L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("iexcl",5,1703194988);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 161L));
	tr1 = RTMS_EX_H("cent",4,1667591796);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 162L));
	tr1 = RTMS_EX_H("pound",5,1870827108);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 163L));
	tr1 = RTMS_EX_H("curren",6,2115640174);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 164L));
	tr1 = RTMS_EX_H("yen",3,7955822);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 165L));
	tr1 = RTMS_EX_H("brvbar",6,32230514);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 166L));
	tr1 = RTMS_EX_H("sect",4,1936024436);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 167L));
	tr1 = RTMS_EX_H("uml",3,7695724);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 168L));
	tr1 = RTMS_EX_H("copy",4,1668247673);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 169L));
	tr1 = RTMS_EX_H("ordf",4,1869767782);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 170L));
	tr1 = RTMS_EX_H("laquo",5,1635655023);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 171L));
	tr1 = RTMS_EX_H("not",3,7237492);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 172L));
	tr1 = RTMS_EX_H("shy",3,7563385);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 173L));
	tr1 = RTMS_EX_H("reg",3,7497063);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 174L));
	tr1 = RTMS_EX_H("macr",4,1835098994);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 175L));
	tr1 = RTMS_EX_H("deg",3,6579559);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 176L));
	tr1 = RTMS_EX_H("plusmn",6,44049518);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 177L));
	tr1 = RTMS_EX_H("sup2",4,1937076274);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 178L));
	tr1 = RTMS_EX_H("sup3",4,1937076275);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 179L));
	tr1 = RTMS_EX_H("acute",5,1669386853);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 180L));
	tr1 = RTMS_EX_H("micro",5,1768962159);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 181L));
	tr1 = RTMS_EX_H("para",4,1885434465);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 182L));
	tr1 = RTMS_EX_H("middot",6,1899412852);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 183L));
	tr1 = RTMS_EX_H("cedil",5,1701839724);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 184L));
	tr1 = RTMS_EX_H("sup1",4,1937076273);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 185L));
	tr1 = RTMS_EX_H("ordm",4,1869767789);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 186L));
	tr1 = RTMS_EX_H("raquo",5,1635701103);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 187L));
	tr1 = RTMS_EX_H("frac14",6,1835306292);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 188L));
	tr1 = RTMS_EX_H("frac12",6,1835306290);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 189L));
	tr1 = RTMS_EX_H("frac34",6,1835306804);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 190L));
	tr1 = RTMS_EX_H("iquest",6,29409396);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 191L));
	tr1 = RTMS_EX_H("Agrave",6,2047576165);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 192L));
	tr1 = RTMS_EX_H("Aacute",6,1797182053);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 193L));
	tr1 = RTMS_EX_H("Acirc",5,1668354147);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 194L));
	tr1 = RTMS_EX_H("Atilde",6,1897397349);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 195L));
	tr1 = RTMS_EX_H("Auml",4,1098214764);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 196L));
	tr1 = RTMS_EX_H("Aring",5,1920011367);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 197L));
	tr1 = RTMS_EX_H("AElig",5,1165231975);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 198L));
	tr1 = RTMS_EX_H("Ccedil",6,1833567084);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 199L));
	tr1 = RTMS_EX_H("Egrave",6,2055440485);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 200L));
	tr1 = RTMS_EX_H("Eacute",6,1805046373);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 201L));
	tr1 = RTMS_EX_H("Ecirc",5,1668384867);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 202L));
	tr1 = RTMS_EX_H("Euml",4,1165323628);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 203L));
	tr1 = RTMS_EX_H("Igrave",6,2063304805);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 204L));
	tr1 = RTMS_EX_H("Iacute",6,1812910693);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 205L));
	tr1 = RTMS_EX_H("Icirc",5,1668415587);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 206L));
	tr1 = RTMS_EX_H("Iuml",4,1232432492);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 207L));
	tr1 = RTMS_EX_H("ETH",3,4543560);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 208L));
	tr1 = RTMS_EX_H("Ntilde",6,1922956389);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 209L));
	tr1 = RTMS_EX_H("Ograve",6,2075101285);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 210L));
	tr1 = RTMS_EX_H("Oacute",6,1824707173);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 211L));
	tr1 = RTMS_EX_H("Ocirc",5,1668461667);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 212L));
	tr1 = RTMS_EX_H("Otilde",6,1924922469);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 213L));
	tr1 = RTMS_EX_H("Ouml",4,1333095788);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 214L));
	tr1 = RTMS_EX_H("times",5,1769667955);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 215L));
	tr1 = RTMS_EX_H("Oslash",6,1974529384);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 216L));
	tr1 = RTMS_EX_H("Ugrave",6,2086897765);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 217L));
	tr1 = RTMS_EX_H("Uacute",6,1836503653);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 218L));
	tr1 = RTMS_EX_H("Ucirc",5,1668507747);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 219L));
	tr1 = RTMS_EX_H("Uuml",4,1433759084);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 220L));
	tr1 = RTMS_EX_H("Yacute",6,1844367973);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 221L));
	tr1 = RTMS_EX_H("THORN",5,1213803086);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 222L));
	tr1 = RTMS_EX_H("szlig",5,2054808423);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 223L));
	tr1 = RTMS_EX_H("agrave",6,2110490725);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 224L));
	tr1 = RTMS_EX_H("aacute",6,1860096613);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 225L));
	tr1 = RTMS_EX_H("acirc",5,1668599907);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 226L));
	tr1 = RTMS_EX_H("atilde",6,1960311909);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 227L));
	tr1 = RTMS_EX_H("auml",4,1635085676);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 228L));
	tr1 = RTMS_EX_H("aring",5,1920257127);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 229L));
	tr1 = RTMS_EX_H("aelig",5,1702348647);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 230L));
	tr1 = RTMS_EX_H("ccedil",6,1896481644);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 231L));
	tr1 = RTMS_EX_H("egrave",6,2118355045);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 232L));
	tr1 = RTMS_EX_H("eacute",6,1867960933);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 233L));
	tr1 = RTMS_EX_H("ecirc",5,1668630627);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 234L));
	tr1 = RTMS_EX_H("euml",4,1702194540);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 235L));
	tr1 = RTMS_EX_H("igrave",6,2126219365);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 236L));
	tr1 = RTMS_EX_H("iacute",6,1875825253);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 237L));
	tr1 = RTMS_EX_H("icirc",5,1668661347);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 238L));
	tr1 = RTMS_EX_H("iuml",4,1769303404);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 239L));
	tr1 = RTMS_EX_H("eth",3,6648936);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 240L));
	tr1 = RTMS_EX_H("ntilde",6,1985870949);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 241L));
	tr1 = RTMS_EX_H("ograve",6,2138015845);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 242L));
	tr1 = RTMS_EX_H("oacute",6,1887621733);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 243L));
	tr1 = RTMS_EX_H("ocirc",5,1668707427);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 244L));
	tr1 = RTMS_EX_H("otilde",6,1987837029);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 245L));
	tr1 = RTMS_EX_H("ouml",4,1869966700);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 246L));
	tr1 = RTMS_EX_H("divide",6,36553061);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 247L));
	tr1 = RTMS_EX_H("oslash",6,2037443944);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 248L));
	tr1 = RTMS_EX_H("ugrave",6,2332517);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 249L));
	tr1 = RTMS_EX_H("uacute",6,1899418213);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 250L));
	tr1 = RTMS_EX_H("ucirc",5,1668753507);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 251L));
	tr1 = RTMS_EX_H("uuml",4,1970629996);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 252L));
	tr1 = RTMS_EX_H("yacute",6,1907282533);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 253L));
	tr1 = RTMS_EX_H("thorn",5,1753025134);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 254L));
	tr1 = RTMS_EX_H("yuml",4,2037738860);
	F880_4390(RTCW(Result), tr1, ((EIF_INTEGER_32) 255L));
	RTOSE (16023);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1761_16023 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16023,F1761_16023_body,(Current));
}

/* {XM_XSLT_HTML_EMITTER}.set_boolean_attribute */
void F1761_16024 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(16010,F1761_16010, (Current));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(arg2))-1112])(arg2);
	tb1 = F1516_12336(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(16010,F1761_16010, (Current));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(arg2))-1112])(arg2);
		F1516_12342(RTCW(tr1), tr2);
	}
	tr1 = RTOSCF(16011,F1761_16011, (Current));
	tr2 = RTMS_EX_H("+",1,43);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(arg1))-1111])(arg1, tr2);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr2))-1111])(tr2, arg2);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(tr2))-1112])(tr2);
	F1516_12342(RTCW(tr1), tr2);
	RTLE;
}

/* {XM_XSLT_HTML_EMITTER}.is_boolean_attribute */
EIF_BOOLEAN F1761_16025 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,tr2);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tb1 = F1148_8370(RTCW(tr1), arg2, arg3);
	if (tb1) {
		tr1 = RTOSCF(16010,F1761_16010, (Current));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(arg2))-1112])(arg2);
		tb1 = F1516_12336(RTCW(tr1), tr2);
		if (tb1) {
			tr1 = RTOSCF(16011,F1761_16011, (Current));
			tr2 = RTMS_EX_H("+",1,43);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(arg1))-1111])(arg1, tr2);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr2))-1111])(tr2, arg2);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(tr2))-1112])(tr2);
			Result = F1516_12336(RTCW(tr1), tr2);
		}
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_HTML_EMITTER}.make_boolean_attributes */
static void F1761_16026_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (16026);
	tr1 = RTMS_EX_H("area",4,1634887009);
	tr2 = RTMS_EX_H("nohref",6,1969448806);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("button",6,2147362158);
	tr2 = RTMS_EX_H("disabled",8,1062390372);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("dir",3,6580594);
	tr2 = RTMS_EX_H("compact",7,393318772);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("dl",2,25708);
	tr2 = RTMS_EX_H("compact",7,393318772);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("frame",5,1919770981);
	tr2 = RTMS_EX_H("noresize",8,72719717);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("hr",2,26738);
	tr2 = RTMS_EX_H("noshade",7,1500669029);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("img",3,6909287);
	tr2 = RTMS_EX_H("ismap",5,1937354608);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("input",5,1853670260);
	tr2 = RTMS_EX_H("checked",7,162046820);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("input",5,1853670260);
	tr2 = RTMS_EX_H("disabled",8,1062390372);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("input",5,1853670260);
	tr2 = RTMS_EX_H("readonly",8,1382700153);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("menu",4,1835363957);
	tr2 = RTMS_EX_H("compact",7,393318772);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("object",6,2004017012);
	tr2 = RTMS_EX_H("declare",7,809792613);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("ol",2,28524);
	tr2 = RTMS_EX_H("compact",7,393318772);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("optgroup",8,563828848);
	tr2 = RTMS_EX_H("disabled",8,1062390372);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("option",6,24682094);
	tr2 = RTMS_EX_H("selected",8,1203629924);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("option",6,24682094);
	tr2 = RTMS_EX_H("disabled",8,1062390372);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("script",6,2146372212);
	tr2 = RTMS_EX_H("defer",5,1701977458);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("select",6,2045458804);
	tr2 = RTMS_EX_H("multiple",8,765910117);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("select",6,2045458804);
	tr2 = RTMS_EX_H("disabled",8,1062390372);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("td",2,29796);
	tr2 = RTMS_EX_H("nowrap",6,73626224);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("textarea",8,1193882977);
	tr2 = RTMS_EX_H("disabled",8,1062390372);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("textarea",8,1193882977);
	tr2 = RTMS_EX_H("readonly",8,1382700153);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("th",2,29800);
	tr2 = RTMS_EX_H("nowrap",6,73626224);
	F1761_16024(Current, tr1, tr2);
	tr1 = RTMS_EX_H("ul",2,30060);
	tr2 = RTMS_EX_H("compact",7,393318772);
	F1761_16024(Current, tr1, tr2);
	RTOSE (16026);
	RTLE;
	RTEE;
#undef Result
}

void F1761_16026 (EIF_REFERENCE Current)
{
	GTCX
	RTOSCP(16026,F1761_16026_body,(Current));
}

/* {XM_XSLT_HTML_EMITTER}.open_document */
void F1761_16027 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLR(6,loc8);
	RTLR(7,loc9);
	RTLR(8,loc7);
	RTLR(9,loc1);
	RTLR(10,loc2);
	RTLR(11,loc3);
	RTLR(12,loc4);
	RTLR(13,loc5);
	RTLIU(14);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = F1781_16420(RTCW(tr2));
	tr3 = RTMS_EX_H("4.0",3,3419696);
	tb1 = F1148_8369(RTCW(tr1), tr2, tr3);
	if (tb1) {
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = F1781_16420(RTCW(tr2));
		tr3 = RTMS_EX_H("4.01",4,875442225);
		tb1 = F1148_8369(RTCW(tr1), tr2, tr3);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
			tr3 = RTMS_EX_H("Only versions 4.0 and 4.01 of HTML are supported",48,2110979684);
			tr4 = RTOSCF(9827,F1230_9827, (Current));
			tr5 = RTMS_EX_H("SESU0013",8,1360585523);
			F1709_14669(RTCW(tr2), tr3, tr4, tr5, ((EIF_INTEGER_32) 3L));
			F1710_14691(RTCW(tr1), tr2);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	loc8 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5053[Dtype(RTCW(tr1))-1112])(tr1);
	RTAR(Current, loc8);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc8;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1254_10627(RTCW(tr1), loc8, *(EIF_REFERENCE *)(Current + _REFACS_6_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc9 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc9)) {
		loc7 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("Trying UTF-8 as unable to open output stream in encoding ",57,1852672544);
		tr1 = F1148_8367(RTCW(tr1), tr2, loc8);
		tr2 = RTOSCF(9827,F1230_9827, (Current));
		tr3 = RTMS_EX_H("SESU0007",8,1360585271);
		F1709_14669(RTCW(loc7), tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1710_14690(RTCW(tr1), loc7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_33_0_);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1254_10627(RTCW(tr1), loc8, *(EIF_REFERENCE *)(Current + _REFACS_6_));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) == NULL)) {
				loc7 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
				tr1 = RTMS_EX_H("Failed to recover",17,1156012146);
				tr2 = RTOSCF(9827,F1230_9827, (Current));
				tr3 = RTMS_EX_H("SESU0007",8,1360585271);
				F1709_14669(RTCW(loc7), tr1, tr2, tr3, ((EIF_INTEGER_32) 3L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				F1710_14691(RTCW(tr1), loc7);
			}
		}
	} else {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_12_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = F1781_16428(RTCW(tr2));
		tr1 = F1148_8376(RTCW(tr1), tr2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1640[Dtype(loc9)-1183])(loc9);
		if (tb1) {
			tb1 = '\01';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_22_4_);
			if (!tb2) {
				tb2 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tb3 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_22_8_);
				if ((EIF_BOOLEAN) !tb3) {
					tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1641[Dtype(loc9)-1183])(loc9);
					tb2 = tb3;
				}
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1638[Dtype(loc9)-1183])(loc9);
				F1759_15984(Current, tr1);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_22_3_);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_12_13_) = (EIF_BOOLEAN) tb1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_8_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_7_);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) || (EIF_BOOLEAN)(loc2 != NULL))) {
			tr1 = RTMS_EX_H("html",4,1752460652);
			F1759_15990(Current, tr1, loc1, loc2);
		}
		*(EIF_BOOLEAN *)(Current+ _CHROFF_12_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1000000L);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc3 = F1781_16440(RTCW(tr1));
		loc6 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(loc3))-1111])(loc3, (EIF_CHARACTER_8) ';', ((EIF_INTEGER_32) 1L));
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 0L))) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN)(loc6 == ti4_1);
		}
		if (tb1) {
			loc4 = (EIF_REFERENCE) loc3;
			loc5 = (EIF_REFERENCE) loc3;
		} else {
			loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc3))-1111])(loc3, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 1L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5111[Dtype(RTCW(loc4))-1112])(loc4);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5112[Dtype(RTCW(loc4))-1112])(loc4);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
			loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc3))-1111])(loc3, (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)), ti4_1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5111[Dtype(RTCW(loc5))-1112])(loc5);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5112[Dtype(RTCW(loc5))-1112])(loc5);
		}
		ti4_1 = F1761_16028(Current, loc4, (EIF_BOOLEAN) 0);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_2_) = (EIF_INTEGER_32) ti4_1;
		ti4_1 = F1761_16028(Current, loc5, (EIF_BOOLEAN) 1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_33_0_);
	if (tb1) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
}

/* {XM_XSLT_HTML_EMITTER}.representation_code */
EIF_INTEGER_32 F1761_16028 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("decimal",7,760243052);
	tb1 = F1148_8369(RTCW(tr1), arg1, tr2);
	if (tb1) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("hex",3,6841720);
		tb1 = F1148_8369(RTCW(tr1), arg1, tr2);
		if (tb1) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
		} else {
			tb1 = '\0';
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("native",6,22602597);
			tb2 = F1148_8369(RTCW(tr1), arg1, tr2);
			if (tb2) {
				tb1 = (EIF_BOOLEAN) !arg2;
			}
			if (tb1) {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			} else {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H("entity",6,5007225);
				tb1 = F1148_8369(RTCW(tr1), arg1, tr2);
				if (tb1) {
					RTLE;
					return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
				} else {
					tr1 = RTMS_EX_H("Illegal value for gexslt:character-representation: ",51,2028363552);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr1)-1111])(tr1, arg1);
					F1732_15293(Current, tr1);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_HTML_EMITTER}.output_attribute */
void F1761_16029 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_5_) == ((EIF_INTEGER_32) 0L))) {
		RTCT0("attached element_name as l_element_name", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		if (F1761_16025(Current, loc1, arg2, arg3)) {
			F1759_15983(Current, arg2);
		} else {
			F1759_15985(Current, arg1, arg2, arg3, arg4);
		}
	} else {
		F1759_15985(Current, arg1, arg2, arg3, arg4);
	}
	RTLE;
}

/* {XM_XSLT_HTML_EMITTER}.output_escape */
void F1761_16031 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLR(8,tr5);
	RTLIU(9);
	
	RTGC;
	RTCT0("precondition_document_opened", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		RTCK0;
	} else {
		RTCF0;
	}
	if (arg2) {
		loc6 = RTOSCF(15980,F1759_15980, (Current));
	} else {
		loc6 = RTOSCF(15979,F1759_15979, (Current));
	}
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (loc2 > ti4_1);
		}
		if (tb1) break;
		loc3 = F1761_16034(Current, arg1, loc2, loc6);
		if ((EIF_BOOLEAN) (loc3 > loc2)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc2, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
			F1759_15983(Current, tr1);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc3 <= ti4_1)) {
			loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc3);
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc1;
			} else {
				if (loc1) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc3, loc3);
					F1759_15983(Current, tr1);
				} else {
					if ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 127L))) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
						if ((EIF_BOOLEAN)(loc3 == ti4_1)) {
							loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						} else {
							loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
						}
						F1761_16032(Current, loc4, loc5, arg2);
					} else {
						if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 160L))) {
							tr1 = RTMS_EX_H("&nbsp;",6,1727288379);
							F1759_15983(Current, tr1);
						} else {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 127L)) && (EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 160L)))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
								tr2 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
								tr3 = RTMS_EX_H("Characters between x7F and x9F inclusive are not allowed in HTML",64,826886476);
								tr4 = RTOSCF(9827,F1230_9827, (Current));
								tr5 = RTMS_EX_H("SERE0014",8,1358496564);
								F1709_14669(RTCW(tr2), tr3, tr4, tr5, ((EIF_INTEGER_32) 3L));
								F1710_14691(RTCW(tr1), tr2);
								*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 55296L)) && (EIF_BOOLEAN) (loc4 <= ((EIF_INTEGER_32) 56319L)))) {
									tr1 = RTMS_EX_H("output_escape (surrogates)",26,1287423273);
									F1631_13692(Current, tr1, (EIF_BOOLEAN) 1);
								} else {
									tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R1642[Dtype(loc7)-1183])(loc7, loc4);
									if ((EIF_BOOLEAN) !tb2) {
										F1761_16033(Current, loc4, arg2);
									} else {
										*(EIF_BOOLEAN *)(Current+ _CHROFF_12_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_3_) == ((EIF_INTEGER_32) 4L));
										F1759_15988(Current, loc4);
									}
								}
							}
						}
					}
				}
			}
		}
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
	}
	RTLE;
}

/* {XM_XSLT_HTML_EMITTER}.output_special_ascii */
void F1761_16032 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if (arg3) {
		if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 60L))) {
			tr1 = RTMS_EX_H("<",1,60);
			F1759_15983(Current, tr1);
		} else {
			if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 62L))) {
				tr1 = RTMS_EX_H("&gt;",4,644314171);
				F1759_15983(Current, tr1);
			} else {
				if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 38L))) {
					if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 40L))) {
						tr1 = RTMS_EX_H("&",1,38);
						F1759_15983(Current, tr1);
					} else {
						tr1 = RTMS_EX_H("&amp;",5,1634853947);
						F1759_15983(Current, tr1);
					}
				} else {
					if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 34L))) {
						tr1 = RTMS_EX_H("&#34;",5,590850107);
						F1759_15983(Current, tr1);
					} else {
						if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 10L))) {
							tr1 = RTMS_EX_H("&#xA;",5,595375419);
							F1759_15983(Current, tr1);
						} else {
							if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 13L))) {
								tr1 = RTMS_EX_H("&#xD;",5,595376187);
								F1759_15983(Current, tr1);
							} else {
								if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 9L))) {
									tr1 = RTMS_EX_H("&#9;",4,639842619);
									F1759_15983(Current, tr1);
								}
							}
						}
					}
				}
			}
		}
	} else {
		if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 60L))) {
			tr1 = RTMS_EX_H("&lt;",4,644641851);
			F1759_15983(Current, tr1);
		} else {
			if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 62L))) {
				tr1 = RTMS_EX_H("&gt;",4,644314171);
				F1759_15983(Current, tr1);
			} else {
				if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 38L))) {
					tr1 = RTMS_EX_H("&amp;",5,1634853947);
					F1759_15983(Current, tr1);
				} else {
					if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 13L))) {
						tr1 = RTMS_EX_H("&#xD;",5,595376187);
						F1759_15983(Current, tr1);
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_XSLT_HTML_EMITTER}.output_non_ascii */
void F1761_16033 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_2_)) {
		case 1L:
			tr1 = RTOSCF(4819,F984_4819, (Current));
			tr1 = F1708_14666(RTCW(tr1), arg1);
			F1759_15983(Current, tr1);
			break;
		case 2L:
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 160L)) && (EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 255L)))) {
				tr1 = RTMS_EX_H("&",1,38);
				F1759_15983(Current, tr1);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_)) {
					tr1 = RTOSCF(16023,F1761_16023, (Current));
					tr1 = F880_4371(RTCW(tr1), arg1);
					F1759_15983(Current, tr1);
				}
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_12_3_)) {
					tr1 = RTMS_EX_H(";",1,59);
					F1759_15983(Current, tr1);
				}
			} else {
				F1759_15988(Current, arg1);
			}
			break;
		case 3L:
			*(EIF_BOOLEAN *)(Current+ _CHROFF_12_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			F1759_15988(Current, arg1);
			break;
		case 4L:
			*(EIF_BOOLEAN *)(Current+ _CHROFF_12_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1759_15988(Current, arg1);
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
}

/* {XM_XSLT_HTML_EMITTER}.maximal_ordinary_string */
EIF_INTEGER_32 F1761_16034 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	RTCT0("precondition_document_opened", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = (EIF_INTEGER_32) arg2;
	for (;;) {
		tb1 = '\01';
		if (!loc3) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
		}
		if (tb1) break;
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc1);
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 128L))) {
			tb2 = F884_4371(RTCW(arg3), loc2);
			if (tb2) {
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				loc1++;
			}
		} else {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R1642[Dtype(loc4)-1183])(loc4, loc2);
			if ((EIF_BOOLEAN) !tb2) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_14_0_2_) == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 160L)))) {
					loc1++;
				} else {
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	Result = (EIF_INTEGER_32) loc1;
	RTLE;
	return Result;
}

void EIF_Minit834 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
