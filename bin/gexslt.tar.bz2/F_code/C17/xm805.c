/*
 * Code for class XM_XSLT_EMITTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm805.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_EMITTER}.as_xml_emitter */
EIF_REFERENCE F1732_15291 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	RTCT0("xml_emitter", EX_CHECK);
		RTCF0;
	return (EIF_REFERENCE) 0;
}

/* {XM_XSLT_EMITTER}.on_error */
void F1732_15293 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(10);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,loc1);
	RTLR(9,loc7);
	RTLIU(10);
	
	RTGC;
	loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg1))-1111])(arg1, (EIF_CHARACTER_8) ':', ((EIF_INTEGER_32) 1L));
	tb1 = '\0';
	tb2 = '\0';
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 > (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L)))) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
		tr3 = RTMS_EX_H("X",1,88);
		tb3 = F1148_8369(RTCW(tr1), tr2, tr3);
		tb2 = tb3;
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		loc2 = RTOSCF(9827,F1230_9827, (Current));
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L)));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 2L)), ti4_1);
	} else {
		tb1 = '\0';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg1))-1111])(arg1, (EIF_CHARACTER_8) '#', ((EIF_INTEGER_32) 2L));
			tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		if (tb1) {
			loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg1))-1111])(arg1, (EIF_CHARACTER_8) '#', ((EIF_INTEGER_32) 2L));
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L)));
			loc6 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg1))-1111])(arg1, (EIF_CHARACTER_8) ':', (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L)));
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 1L)));
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			F1148_8385(RTCW(tr1), loc3);
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			F1148_8386(RTCW(tr1), loc3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)), ti4_1);
		} else {
			loc4 = (EIF_REFERENCE) arg1;
			loc2 = RTOSCF(9829,F1230_9829, (Current));
			loc3 = RTMS_EX_H("SERIALIZATION_ERROR",19,866779986);
		}
	}
	loc1 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
	F1709_14669(RTCW(loc1), loc4, loc2, loc3, ((EIF_INTEGER_32) 3L));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		tr1 = *(EIF_REFERENCE *)(loc7);
		F1709_14683(RTCW(loc1), tr1, ((EIF_INTEGER_32) 0L));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = F772_3900(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			F1709_14683(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_1_), ((EIF_INTEGER_32) 0L));
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1710_14691(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current + O11899[Dtype(Current)-1731]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XSLT_EMITTER}.set_unparsed_entity */
void F1732_15294 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_EMITTER}.set_document_locator */
void F1732_15295 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {XM_XSLT_EMITTER}.set_output_properties */
void F1732_15296 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		loc2 = *(EIF_REFERENCE *)(loc3 + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr1 = F2152_21392(RTCW(tr1));
		tr1 = F1254_10627(RTCW(tr1), loc1, loc2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {XM_XSLT_EMITTER}.suppress_late_open */
void F1732_15297 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O11903[Dtype(Current)-1731]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit805 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
