
#ifndef _C17_xm802_
#define _C17_xm802_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1729_15248(EIF_REFERENCE);
extern void F1729_15263(EIF_REFERENCE, EIF_REFERENCE);
extern void F1729_15264(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1729_15266(EIF_REFERENCE);
extern void EIF_Minit802(void);
extern long O11855[];
extern long O11856[];
extern long O11859[];

#ifdef __cplusplus
}
#endif

#endif
