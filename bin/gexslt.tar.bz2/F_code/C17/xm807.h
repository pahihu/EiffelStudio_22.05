
#ifndef _C17_xm807_
#define _C17_xm807_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1734_15315(EIF_REFERENCE);
extern void F1734_15316(EIF_REFERENCE, EIF_REFERENCE);
extern void F1734_15317(EIF_REFERENCE);
extern void F1734_15318(EIF_REFERENCE);
extern void F1734_15319(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1734_15320(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1734_15321(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1734_15322(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1734_15323(EIF_REFERENCE);
extern void F1734_15324(EIF_REFERENCE);
extern void F1734_15325(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1734_15326(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1734_15327(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1734_15328(EIF_REFERENCE);
extern void F1734_15329(EIF_REFERENCE);
extern void F1734_15330(EIF_REFERENCE, EIF_REFERENCE);
extern void F1734_15331(EIF_REFERENCE, EIF_REFERENCE);
extern void F1734_15332(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit807(void);
extern void F1729_15263(EIF_REFERENCE, EIF_REFERENCE);
extern void F1729_15264(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R11880[])();
extern char *(*R11863[])();
extern char *(*R11864[])();
extern char *(*R11865[])();
extern char *(*R11866[])();
extern char *(*R11867[])();
extern char *(*R11868[])();
extern char *(*R11869[])();
extern char *(*R11870[])();
extern char *(*R11871[])();
extern char *(*R11872[])();
extern char *(*R11873[])();
extern char *(*R11874[])();
extern char *(*R11875[])();
extern char *(*R11876[])();
extern char *(*R11877[])();
extern char *(*R11878[])();
extern char *(*R11879[])();
extern long O11857[];
extern long O11858[];
extern long O11859[];
extern long O11905[];

#ifdef __cplusplus
}
#endif

#endif
