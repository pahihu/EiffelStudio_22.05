/*
 * Code for class XM_XSLT_CHARACTER_MAP_EXPANDER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm809.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_CHARACTER_MAP_EXPANDER}.make */
void F1736_15353 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O11856[Dtype(arg1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_) = (EIF_BOOLEAN) arg3;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		tr1 = F1506_12165(RTCW(arg2), ((EIF_INTEGER_32) 1L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1538,0xFF01,1112,1035,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		tr2 = RTOSCF(8115,F1125_8115, (Current));
		F1527_12401(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, NULL);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		loc1 = F1506_12168(RTCW(arg2));
		F1320_11363(RTCW(loc1));
		for (;;) {
			tb1 = F1384_11438(RTCW(loc1));
			if (tb1) break;
			ti4_1 = F1381_11418(RTCW(loc1));
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr2 = F1307_11343(RTCW(loc1));
				F1527_12427(RTCW(tr1), tr2);
			} else {
				loc2 = F1307_11343(RTCW(loc1));
				loc3 = F1539_12475(RTCW(loc2));
				F1320_11363(RTCW(loc3));
				for (;;) {
					tb2 = F1349_11391(RTCW(loc3));
					if (tb2) break;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					tr2 = F1307_11343(RTCW(loc3));
					ti4_1 = F1365_11410(RTCW(loc3));
					F1527_12423(RTCW(tr1), tr2, ti4_1);
					F1320_11364(RTCW(loc3));
				}
			}
			F1320_11364(RTCW(loc1));
		}
	}
	RTLE;
}

/* {XM_XSLT_CHARACTER_MAP_EXPANDER}.notify_attribute */
void F1736_15354 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg3);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1412_11675(Current, arg4)) {
		loc1 = F1736_15358(Current, arg3);
		if ((EIF_BOOLEAN)(loc1 == arg3)) {
			F1734_15322(Current, arg1, arg2, arg3, arg4);
		} else {
			tr1 = RTOSCF(6771,F1118_6771, (Current));
			tr2 = RTOSCF(6771,F1118_6771, (Current));
			ti4_1 = F1174_8739(RTCW(tr2), arg4, ((EIF_INTEGER_32) 32L));
			tr2 = RTOSCF(6771,F1118_6771, (Current));
			ti4_2 = F1174_8741(RTCW(tr2), ((EIF_INTEGER_32) 16L));
			ti4_1 = F1174_8738(RTCW(tr1), ti4_1, ti4_2);
			F1734_15322(Current, arg1, arg2, loc1, ti4_1);
		}
	} else {
		F1734_15322(Current, arg1, arg2, arg3, arg4);
	}
	RTLE;
}

/* {XM_XSLT_CHARACTER_MAP_EXPANDER}.notify_characters */
void F1736_15355 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1412_11675(Current, arg2)) {
		loc1 = F1736_15358(Current, arg1);
		if ((EIF_BOOLEAN)(loc1 == arg1)) {
			F1734_15325(Current, arg1, arg2);
		} else {
			tr1 = RTOSCF(6771,F1118_6771, (Current));
			tr2 = RTOSCF(6771,F1118_6771, (Current));
			ti4_1 = F1174_8739(RTCW(tr2), arg2, ((EIF_INTEGER_32) 32L));
			tr2 = RTOSCF(6771,F1118_6771, (Current));
			ti4_2 = F1174_8741(RTCW(tr2), ((EIF_INTEGER_32) 16L));
			ti4_1 = F1174_8738(RTCW(tr1), ti4_1, ti4_2);
			F1734_15325(Current, loc1, ti4_1);
		}
	} else {
		F1734_15325(Current, arg1, arg2);
	}
	RTLE;
}

/* {XM_XSLT_CHARACTER_MAP_EXPANDER}.mapped_string */
EIF_REFERENCE F1736_15358 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	F1111_6438(RTCW(Result), ti4_1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc1);
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc4;
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("\000",1,0);
			tr1 = F1148_8377(RTCW(tr1), Result, tr2);
			Result = (EIF_REFERENCE) tr1;
		} else {
			tb1 = '\0';
			if ((EIF_BOOLEAN) !loc4) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tb2 = F1527_12411(RTCW(tr1), loc2);
				tb1 = tb2;
			}
			if (tb1) {
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_)) {
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTMS_EX_H("\000",1,0);
					tr1 = F1148_8377(RTCW(tr1), Result, tr2);
					Result = (EIF_REFERENCE) tr1;
				}
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr2 = F1527_12403(RTCW(tr2), loc2);
				tr1 = F1148_8377(RTCW(tr1), Result, tr2);
				Result = (EIF_REFERENCE) tr1;
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_)) {
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTMS_EX_H("\000",1,0);
					tr1 = F1148_8377(RTCW(tr1), Result, tr2);
					Result = (EIF_REFERENCE) tr1;
				}
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, loc1);
				tr1 = F1148_8377(RTCW(tr1), Result, tr2);
				Result = (EIF_REFERENCE) tr1;
			}
		}
		loc1++;
	}
	if ((EIF_BOOLEAN) !loc3) {
		RTLE;
		return (EIF_REFERENCE) arg1;
	}
	RTLE;
	return Result;
}

void EIF_Minit809 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
