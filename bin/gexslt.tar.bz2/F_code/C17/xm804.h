
#ifndef _C17_xm804_
#define _C17_xm804_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1731_15284(EIF_REFERENCE);
extern void F1731_15286(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit804(void);
extern long O11894[];
extern long O11857[];

#ifdef __cplusplus
}
#endif

#endif
