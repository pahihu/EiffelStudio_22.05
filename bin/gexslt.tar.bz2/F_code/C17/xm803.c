/*
 * Code for class XM_XPATH_BUILDER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm803.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_BUILDER}.show_size */
void F1730_15274 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {XM_XPATH_BUILDER}.set_line_numbering */
void F1730_15275 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O11887[Dtype(Current)-1729]) = (EIF_BOOLEAN) arg1;
}

/* {XM_XPATH_BUILDER}.open */
void F1730_15277 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O11857[dtype-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	if (*(EIF_BOOLEAN *)(Current + O11886[dtype-1729])) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			loc1 = *(EIF_REFERENCE *)(loc2);
		} else {
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
				loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			} else {
				loc1 = RTMS_EX_H("unknown document",16,1508920180);
			}
		}
		tr1 = RTOSCF(418,F36_418, (RTCV(RTOSCF(4949,F990_4949, (Current)))));
		tr2 = RTMS_EX_H("Building tree for ",18,2072135200);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr2)-1111])(tr2, loc1);
		F1219_9721(RTCW(tr1), tr2);
		tr1 = RTOSCF(418,F36_418, (RTCV(RTOSCF(4949,F990_4949, (Current)))));
		F1218_9714(RTCW(tr1));
		tr1 = F1721_15176(RTCV(RTOSCF(3565,F460_3565, (Current))));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {XM_XPATH_BUILDER}.close */
void F1730_15278 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O11857[dtype-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if (*(EIF_BOOLEAN *)(Current + O11886[dtype-1729])) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			loc1 = *(EIF_REFERENCE *)(loc2);
		} else {
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
				loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			} else {
				loc1 = RTMS_EX_H("unknown document",16,1508920180);
			}
		}
		RTCT0("attached start_time as l_start_time", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = RTOSCF(418,F36_418, (RTCV(RTOSCF(4949,F990_4949, (Current)))));
		tr2 = RTMS_EX_H("Tree build for ",15,2084570400);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr2)-1111])(tr2, loc1);
		tr3 = RTMS_EX_H(" took ",6,1933378336);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr2))-1111])(tr2, tr3);
		tr3 = F1721_15176(RTCV(RTOSCF(3565,F460_3565, (Current))));
		tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R10685[Dtype(RTCW(tr3))-1615])(tr3, loc3);
		tr3 = F1615_13515(RTCW(tr3));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr2))-1111])(tr2, tr3);
		F1219_9721(RTCW(tr1), tr2);
		tr1 = RTOSCF(418,F36_418, (RTCV(RTOSCF(4949,F990_4949, (Current)))));
		F1218_9714(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11888[dtype-1805])(Current);
	}
	RTLE;
}

/* {XM_XPATH_BUILDER}.set_document_locator */
void F1730_15279 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {XM_XPATH_BUILDER}.as_builder */
EIF_REFERENCE F1730_15280 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

void EIF_Minit803 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
