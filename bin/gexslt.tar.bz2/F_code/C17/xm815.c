/*
 * Code for class XM_XSLT_CDATA_FILTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm815.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_CDATA_FILTER}.make */
void F1742_15452 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,arg4);
	RTLIU(6);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1503,1035,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1504_12129(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1112, 1).id);
	F1111_6438(RTCW(tr1), ((EIF_INTEGER_32) 80L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O11855[Dtype(arg1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O11856[Dtype(arg1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg2;
	F1724_15188(Current, arg3, arg4);
	tr1 = F1742_15462(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_CDATA_FILTER}.start_element */
void F1742_15453 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1742_15464(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	ti4_1 = F1227_9769(Current, arg1);
	F1504_12140(RTCW(tr1), ti4_1);
	F1734_15320(Current, arg1, arg2, arg3);
	RTLE;
}

/* {XM_XSLT_CDATA_FILTER}.end_element */
void F1742_15454 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1742_15464(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F1504_12144(RTCW(tr1));
	F1734_15324(Current);
	RTLE;
}

/* {XM_XSLT_CDATA_FILTER}.notify_comment */
void F1742_15455 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1742_15464(Current);
	F1734_15327(Current, arg1, arg2);
	RTLE;
}

/* {XM_XSLT_CDATA_FILTER}.notify_characters */
void F1742_15456 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr1 = F1148_8377(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_10_), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	F1734_15315(Current);
	RTLE;
}

/* {XM_XSLT_CDATA_FILTER}.notify_processing_instruction */
void F1742_15457 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	F1742_15464(Current);
	F1734_15326(Current, arg1, arg2, arg3);
	RTLE;
}

/* {XM_XSLT_CDATA_FILTER}.cdata_section_names */
EIF_REFERENCE F1742_15462 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1506,1035,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1506, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_7_0_0_8_);
	F1507_12159(RTCW(Result), ti4_1);
	loc2 = F1522_12391(RTCW(loc1));
	F1320_11363(RTCW(loc2));
	for (;;) {
		tb1 = F1347_11391(RTCW(loc2));
		if (tb1) break;
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tr2 = F1307_11343(RTCW(loc2));
		ti4_1 = F1242_10415(RTCW(tr1), tr2);
		F1507_12178(RTCW(Result), ti4_1);
		F1320_11364(RTCW(loc2));
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_CDATA_FILTER}.conditionally_flush */
void F1742_15464 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) != NULL)) {
		F1742_15465(Current);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) != NULL)) {
			F1742_15465(Current);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_10_), ((EIF_INTEGER_32) 0L));
			tr1 = RTLNSMART(eif_new_type(1112, 1).id);
			F1111_6438(RTCW(tr1), ((EIF_INTEGER_32) 80L));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {XM_XSLT_CDATA_FILTER}.flush */
void F1742_15465 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc6);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc7);
	RTLR(5,loc5);
	RTLIU(6);
	
	RTGC;
	RTCT0("precondition_output_encoder_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tb1 = F772_3900(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tb1 = F1419_11697(RTCW(tr1));
		if (tb1) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			ti4_1 = F1504_12132(RTCW(tr2));
			loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9611[Dtype(RTCW(tr1))-1481])(tr1, (EIF_REFERENCE) &ti4_1);
		}
		if (loc1) {
			tr1 = *(EIF_REFERENCE *)(Current);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9435[Dtype(loc7)-1396])(loc7, *(EIF_REFERENCE *)(Current + _REFACS_10_));
			} else {
				loc5 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
			}
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc4 = (EIF_INTEGER_32) loc3;
			for (;;) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (loc3 > ti4_1)) break;
				loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(loc5))-1112])(loc5, loc3);
				if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc5))-1111])(loc5, loc4, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
					F1742_15466(Current, tr1);
					loc3++;
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R1642[Dtype(loc6)-1183])(loc6, loc2);
					if (tb1) {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc5))-1111])(loc5, loc4, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
						F1742_15466(Current, tr1);
						loc4 = (EIF_INTEGER_32) loc3;
						for (;;) {
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R1642[Dtype(loc6)-1183])(loc6, loc2);
							if ((EIF_BOOLEAN) !tb1) break;
							if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
								tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc5))-1111])(loc5, loc3, loc3);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, tr2, ((EIF_INTEGER_32) 0L));
							}
							loc3++;
							loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(loc5))-1112])(loc5, loc3);
						}
					} else {
						loc3++;
					}
				}
			}
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc5))-1111])(loc5, loc4, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
			F1742_15466(Current, tr1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_10_), ((EIF_INTEGER_32) 0L));
		}
		tr1 = RTLNSMART(eif_new_type(1112, 1).id);
		F1111_6438(RTCW(tr1), ((EIF_INTEGER_32) 80L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {XM_XSLT_CDATA_FILTER}.flush_cdata */
void F1742_15466 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = RTMS_EX_H("<![CDATA[",9,1184601691);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, tr2, ((EIF_INTEGER_32) 64L));
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc2);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, tr2, ((EIF_INTEGER_32) 64L));
		} else {
			tb1 = '\0';
			tb2 = '\0';
			tb3 = '\0';
			if ((EIF_BOOLEAN) (loc2 <= (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 2L)))) {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(arg1))-852])(arg1, loc2));
				tb3 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) ']');
			}
			if (tb3) {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(arg1))-852])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L))));
				tb2 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) ']');
			}
			if (tb2) {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(arg1))-852])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L))));
				tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '>');
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, tr2, ((EIF_INTEGER_32) 64L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				tr2 = RTMS_EX_H("]]]]><![CDATA[",14,1334969179);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, tr2, ((EIF_INTEGER_32) 64L));
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L));
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
			}
		}
		loc2++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, tr2, ((EIF_INTEGER_32) 64L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = RTMS_EX_H("]]>",3,6118718);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, tr2, ((EIF_INTEGER_32) 64L));
	RTLE;
}

void EIF_Minit815 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
