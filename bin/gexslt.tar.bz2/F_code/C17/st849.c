/*
 * Code for class ST_XSLT_FORMAT_DATE_TIME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st849.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ST_XSLT_FORMAT_DATE_TIME}.default_language */

EIF_REFERENCE F1776_16293 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (16293,RTMS_EX_H("en",2,25966));
}

/* {ST_XSLT_FORMAT_DATE_TIME}.default_calendar */

EIF_REFERENCE F1776_16294 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (16294,RTMS_EX_H("CE",2,17221));
}

/* {ST_XSLT_FORMAT_DATE_TIME}.default_country */

EIF_REFERENCE F1776_16295 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (16295,RTMS_EX_H("US",2,21843));
}

/* {ST_XSLT_FORMAT_DATE_TIME}.iso_calendar */

EIF_REFERENCE F1776_16296 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (16296,RTMS_EX_H("ISO",3,4805455));
}

/* {ST_XSLT_FORMAT_DATE_TIME}.ad_calendar */

EIF_REFERENCE F1776_16297 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (16297,RTMS_EX_H("AD",2,16708));
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_date_time */
void F1776_16298 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(12);
	RTLR(0,arg3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,Current);
	RTLR(6,arg4);
	RTLR(7,loc2);
	RTLR(8,arg5);
	RTLR(9,loc3);
	RTLR(10,arg2);
	RTLR(11,arg6);
	RTLIU(12);
	
	RTGC;
	tb1 = F772_3900(RTCW(arg3));
	if (tb1) {
		tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("",0,0);
		F9_109(RTCW(tr1), tr2);
		F210_1915(RTCW(arg1), tr1);
	} else {
		loc1 = F1162_8523(Current, ((EIF_INTEGER_32) 32L));
		if ((EIF_BOOLEAN) !F1776_16334(Current, arg4)) {
			loc2 = F1776_16335(Current, arg4);
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = F1776_16336(Current, arg4);
			tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
			loc1 = (EIF_REFERENCE) tr1;
		} else {
			loc2 = (EIF_REFERENCE) arg4;
		}
		if ((EIF_BOOLEAN) !F1776_16337(Current, arg5)) {
			loc3 = F1776_16338(Current, arg5);
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = F1776_16339(Current, arg5, loc2);
			tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
			loc1 = (EIF_REFERENCE) tr1;
		} else {
			loc3 = (EIF_REFERENCE) arg5;
		}
		F1776_16304(Current, arg1, loc1, arg2, arg3, loc2, loc3, arg6);
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.parse_picture_string */
void F1776_16304 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(11);
	RTLR(0,arg4);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,arg3);
	RTLR(7,arg5);
	RTLR(8,arg6);
	RTLR(9,arg7);
	RTLR(10,Current);
	RTLIU(11);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg4)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		if (loc5) break;
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || loc6)) break;
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg4))-1111])(arg4, (EIF_CHARACTER_8) '[', loc1);
			if ((EIF_BOOLEAN)(ti4_1 == loc1)) {
				loc3 = (EIF_INTEGER_32) loc1;
				loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(arg4))-852])(arg4, loc1));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5184[Dtype(RTCW(arg2))-1112])(arg2, tc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg4))-1111])(arg4, (EIF_CHARACTER_8) ']', loc1);
				if ((EIF_BOOLEAN)(ti4_1 == loc1)) {
					loc1++;
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg4))-1111])(arg4, (EIF_CHARACTER_8) ']', loc1);
					if ((EIF_BOOLEAN)(ti4_1 != loc1)) {
						tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("] must be doubled in picture string",35,1433140071);
						tr3 = RTMS_EX_H("XTDE1340",8,308926000);
						F9_110(RTCW(tr1), tr2, tr3);
						F210_1915(RTCW(arg1), tr1);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
			}
			loc1++;
		}
		if ((EIF_BOOLEAN) (loc1 > loc2)) {
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L)))) {
				tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("] not found after [ in picture string",37,565938023);
				tr3 = RTMS_EX_H("XTDE1340",8,308926000);
				F9_110(RTCW(tr1), tr2, tr3);
				F210_1915(RTCW(arg1), tr1);
			}
		} else {
			if ((EIF_BOOLEAN) !loc5) {
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg4))-1111])(arg4, (EIF_CHARACTER_8) '[', loc1);
				if ((EIF_BOOLEAN)(ti4_1 == loc1)) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5184[Dtype(RTCW(arg2))-1112])(arg2, (EIF_CHARACTER_8) '[', (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
					loc1++;
				} else {
					loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg4))-1111])(arg4, (EIF_CHARACTER_8) ']', loc1);
					if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
						tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("] not found after [ in picture string",37,565938023);
						tr3 = RTMS_EX_H("XTDE1340",8,308926000);
						F9_110(RTCW(tr1), tr2, tr3);
						F210_1915(RTCW(arg1), tr1);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg4))-1111])(arg4, (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L)));
						F1776_16305(Current, arg1, arg2, arg3, tr1, arg5, arg6, arg7);
						tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
						if ((EIF_BOOLEAN)(tr1 != NULL)) {
							loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
						}
					}
				}
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
		F9_109(RTCW(tr1), arg2);
		F210_1915(RTCW(arg1), tr1);
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_marker */
void F1776_16305 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(12);
	RTLR(0,arg4);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,loc2);
	RTLR(7,arg2);
	RTLR(8,arg3);
	RTLR(9,arg5);
	RTLR(10,arg6);
	RTLR(11,arg7);
	RTLIU(12);
	
	RTGC;
	tb1 = '\01';
	tb2 = F772_3900(RTCW(arg4));
	if (!tb2) {
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(arg4))-852])(arg4, ((EIF_INTEGER_32) 1L)));
		tb1 = (EIF_BOOLEAN) !F1776_16333(Current, tc1);
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
		tr2 = RTOSCF(8530,F1163_8530, (Current));
		tr3 = RTMS_EX_H("The picture string has an invalid variable marker: ",51,6438944);
		tr2 = F1148_8367(RTCW(tr2), tr3, arg4);
		tr3 = RTMS_EX_H("XTDE1340",8,308926000);
		F9_110(RTCW(tr1), tr2, tr3);
		F210_1915(RTCW(arg1), tr1);
	} else {
		loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(arg4))-852])(arg4, ((EIF_INTEGER_32) 1L)));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg4)+ _LNGOFF_1_1_0_2_);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg4))-1111])(arg4, ((EIF_INTEGER_32) 2L), ti4_1);
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		F1148_8385(RTCW(tr1), loc2);
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		F1148_8386(RTCW(tr1), loc2);
		F1776_16306(Current, arg1, arg2, arg3, loc1, loc2, arg5, arg6, arg7);
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.parse_and_format_marker */
void F1776_16306 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_CHARACTER_8 arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7, EIF_REFERENCE arg8)
{
	GTCX
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,arg5);
	RTLR(4,arg6);
	RTLR(5,arg7);
	RTLR(6,arg8);
	RTLR(7,Current);
	RTLIU(8);
	
	RTGC;
	switch (arg4) {
		case (EIF_CHARACTER_8) 'Y':
			F1776_16311(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'M':
			F1776_16312(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'D':
			F1776_16313(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'd':
			F1776_16314(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'F':
			F1776_16315(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'W':
			F1776_16316(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'w':
			F1776_16317(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'H':
			F1776_16318(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'h':
			F1776_16319(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'P':
			F1776_16320(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'm':
			F1776_16321(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 's':
			F1776_16322(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'f':
			F1776_16323(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'Z':
			F1776_16325(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'z':
			F1776_16326(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'C':
			F1776_16327(Current, arg1, arg2, arg5, arg6, arg7, arg8);
			break;
		case (EIF_CHARACTER_8) 'E':
			F1776_16328(Current, arg1, arg2, arg3, arg5, arg6, arg7, arg8);
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.check_not_date_value */
void F1776_16307 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9157[Dtype(RTCW(arg2))-1889])(arg2);
	if (tb1) {
		tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("XTDE1350",8,308926256);
		F9_110(RTCW(tr1), arg3, tr2);
		F210_1915(RTCW(arg1), tr1);
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.check_not_time_value */
void F1776_16308 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9156[Dtype(RTCW(arg2))-1889])(arg2);
	if (tb1) {
		tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("XTDE1350",8,308926256);
		F9_110(RTCW(tr1), arg3, tr2);
		F210_1915(RTCW(arg1), tr1);
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.ordinal_attribute_value */
EIF_REFERENCE F1776_16309 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_38_)) {
		Result = RTMS_EX_H("yes",3,7955827);
	} else {
		Result = RTMS_EX_H("",0,0);
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.letter_attribute_value */
EIF_REFERENCE F1776_16310 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_37_)) {
		Result = RTMS_EX_H("traditional",11,426852716);
	} else {
		Result = RTMS_EX_H("",0,0);
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_year */
void F1776_16311 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(13);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg5);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLR(9,loc1);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	tr1 = RTMS_EX_H("Y specifier not allowed for format-time()",41,1769719849);
	F1776_16308(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("1",1,49);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 0);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc2 = F1726_15204(Current, arg5);
			loc3 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
			ti4_1 = F1287_11133(RTCW(arg3));
			F1748_15536(RTCW(loc3), ti4_1);
			loc4 = *(EIF_REFERENCE *)(Current);
			RTCT0("selected_numberer_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTCT0("primary_modifier_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTMS_EX_H("",0,0);
			tr2 = F1776_16310(Current);
			tr3 = F1776_16309(Current);
			loc1 = F1728_15212(RTCW(loc2), loc3, loc4, ((EIF_INTEGER_32) 0L), tr1, tr2, tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
				if (F1776_16329(Current)) {
					tr1 = F1776_16345(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					tr1 = F1776_16346(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				}
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
					loc1 = (EIF_REFERENCE) tr1;
				}
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_month */
void F1776_16312 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg5);
	RTLR(7,loc1);
	RTLR(8,loc4);
	RTLR(9,loc5);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	tr1 = RTMS_EX_H("M specifier not allowed for format-time()",41,2006624297);
	F1776_16308(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("1",1,49);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 1);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc2 = F1726_15204(Current, arg5);
			RTCT0("selected_numberer_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			loc3 = F1287_11134(RTCW(arg3));
			if (F1776_16342(Current)) {
				tr1 = F1728_15213(RTCW(loc2), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_));
				loc1 = F1776_16343(Current, tr1);
			} else {
				loc4 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
				F1748_15536(RTCW(loc4), loc3);
				loc5 = *(EIF_REFERENCE *)(Current);
				RTCT0("primary_modifier_not_void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc5 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tr1 = RTMS_EX_H("",0,0);
				tr2 = F1776_16310(Current);
				tr3 = F1776_16309(Current);
				loc1 = F1728_15212(RTCW(loc2), loc4, loc5, ((EIF_INTEGER_32) 0L), tr1, tr2, tr3);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
					if (F1776_16329(Current)) {
						tr1 = F1776_16345(Current, loc1);
						loc1 = (EIF_REFERENCE) tr1;
					} else {
						tr1 = F1776_16346(Current, loc1);
						loc1 = (EIF_REFERENCE) tr1;
					}
				} else {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
						loc1 = (EIF_REFERENCE) tr1;
					}
				}
			}
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tb1 = F32_265(RTCW(tr1), arg2, loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F1162_8520(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_day_in_month */
void F1776_16313 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(13);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg5);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLR(9,loc1);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	tr1 = RTMS_EX_H("D specifier not allowed for format-time()",41,36822825);
	F1776_16308(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("1",1,49);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 0);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc2 = F1726_15204(Current, arg5);
			loc3 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
			ti4_1 = F1287_11135(RTCW(arg3));
			F1748_15536(RTCW(loc3), ti4_1);
			loc4 = *(EIF_REFERENCE *)(Current);
			RTCT0("selected_numberer_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTCT0("primary_modifier_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTMS_EX_H("",0,0);
			tr2 = F1776_16310(Current);
			tr3 = F1776_16309(Current);
			loc1 = F1728_15212(RTCW(loc2), loc3, loc4, ((EIF_INTEGER_32) 0L), tr1, tr2, tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
				if (F1776_16329(Current)) {
					tr1 = F1776_16345(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					tr1 = F1776_16346(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				}
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
					loc1 = (EIF_REFERENCE) tr1;
				}
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_day_in_year */
void F1776_16314 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg5);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLR(9,loc1);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	tr1 = RTMS_EX_H("d specifier not allowed for format-time()",41,120904233);
	F1776_16308(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("1",1,49);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 0);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc2 = F1726_15204(Current, arg5);
			loc3 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
			ti4_1 = F1287_11136(RTCW(arg3));
			F1748_15536(RTCW(loc3), ti4_1);
			loc4 = *(EIF_REFERENCE *)(Current);
			RTCT0("selected_numberer_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTCT0("primary_modifier_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTMS_EX_H("",0,0);
			tr2 = F1776_16310(Current);
			tr3 = F1776_16309(Current);
			loc1 = F1728_15212(RTCW(loc2), loc3, loc4, ((EIF_INTEGER_32) 0L), tr1, tr2, tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
				if (F1776_16329(Current)) {
					tr1 = F1776_16345(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					tr1 = F1776_16346(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				}
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
					loc1 = (EIF_REFERENCE) tr1;
				}
			}
		}
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tb1 = F32_265(RTCW(tr1), arg2, loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F1162_8520(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_day_of_week */
void F1776_16315 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(15);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg5);
	RTLR(7,loc1);
	RTLR(8,loc3);
	RTLR(9,arg6);
	RTLR(10,arg7);
	RTLR(11,loc5);
	RTLR(12,tr2);
	RTLR(13,tr3);
	RTLR(14,arg2);
	RTLIU(15);
	
	RTGC;
	tr1 = RTMS_EX_H("F specifier not allowed for format-time()",41,713165353);
	F1776_16308(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("n",1,110);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 1);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc2 = F1726_15204(Current, arg5);
			RTCT0("selected_numberer_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			loc4 = F1287_11137(RTCW(arg3));
			if (F1776_16342(Current)) {
				tr1 = F1728_15214(RTCW(loc2), loc4, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_));
				loc1 = F1776_16343(Current, tr1);
			} else {
				loc3 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
				ti4_1 = F1776_16341(Current, loc4, arg6, arg7);
				F1748_15536(RTCW(loc3), ti4_1);
				loc5 = *(EIF_REFERENCE *)(Current);
				RTCT0("primary_modifier_not_void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc5 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tr1 = RTMS_EX_H("",0,0);
				tr2 = F1776_16310(Current);
				tr3 = F1776_16309(Current);
				loc1 = F1728_15212(RTCW(loc2), loc3, loc5, ((EIF_INTEGER_32) 0L), tr1, tr2, tr3);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
					if (F1776_16329(Current)) {
						tr1 = F1776_16345(Current, loc1);
						loc1 = (EIF_REFERENCE) tr1;
					} else {
						tr1 = F1776_16346(Current, loc1);
						loc1 = (EIF_REFERENCE) tr1;
					}
				} else {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
						loc1 = (EIF_REFERENCE) tr1;
					}
				}
			}
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tb1 = F32_265(RTCW(tr1), arg2, loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F1162_8520(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_week_in_year */
void F1776_16316 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg5);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLR(9,loc1);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	tr1 = RTMS_EX_H("W specifier not allowed for format-time()",41,1093377321);
	F1776_16308(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("1",1,49);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 0);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc2 = F1726_15204(Current, arg5);
			loc3 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
			ti4_1 = F1287_11138(RTCW(arg3));
			F1748_15536(RTCW(loc3), ti4_1);
			loc4 = *(EIF_REFERENCE *)(Current);
			RTCT0("selected_numberer_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTCT0("primary_modifier_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTMS_EX_H("",0,0);
			tr2 = F1776_16310(Current);
			tr3 = F1776_16309(Current);
			loc1 = F1728_15212(RTCW(loc2), loc3, loc4, ((EIF_INTEGER_32) 0L), tr1, tr2, tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
				if (F1776_16329(Current)) {
					tr1 = F1776_16345(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					tr1 = F1776_16346(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				}
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
					loc1 = (EIF_REFERENCE) tr1;
				}
			}
		}
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tb1 = F32_265(RTCW(tr1), arg2, loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F1162_8520(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_week_in_month */
void F1776_16317 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg5);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLR(9,loc1);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	tr1 = RTMS_EX_H("w specifier not allowed for format-time()",41,1177458729);
	F1776_16308(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("1",1,49);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 0);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc2 = F1726_15204(Current, arg5);
			loc3 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
			ti4_1 = F1287_11139(RTCW(arg3));
			F1748_15536(RTCW(loc3), ti4_1);
			loc4 = *(EIF_REFERENCE *)(Current);
			RTCT0("selected_numberer_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTCT0("primary_modifier_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTMS_EX_H("",0,0);
			tr2 = F1776_16310(Current);
			tr3 = F1776_16309(Current);
			loc1 = F1728_15212(RTCW(loc2), loc3, loc4, ((EIF_INTEGER_32) 0L), tr1, tr2, tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
				if (F1776_16329(Current)) {
					tr1 = F1776_16345(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					tr1 = F1776_16346(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				}
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
					loc1 = (EIF_REFERENCE) tr1;
				}
			}
		}
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tb1 = F32_265(RTCW(tr1), arg2, loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F1162_8520(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_hour */
void F1776_16318 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg5);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLR(9,loc1);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	tr1 = RTMS_EX_H("H specifier not allowed for format-date()",41,1475429673);
	F1776_16307(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("1",1,49);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 0);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc2 = F1726_15204(Current, arg5);
			loc3 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
			ti4_1 = F1287_11140(RTCW(arg3));
			F1748_15536(RTCW(loc3), ti4_1);
			loc4 = *(EIF_REFERENCE *)(Current);
			RTCT0("selected_numberer_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTCT0("primary_modifier_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTMS_EX_H("",0,0);
			tr2 = F1776_16310(Current);
			tr3 = F1776_16309(Current);
			loc1 = F1728_15212(RTCW(loc2), loc3, loc4, ((EIF_INTEGER_32) 0L), tr1, tr2, tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
				if (F1776_16329(Current)) {
					tr1 = F1776_16345(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					tr1 = F1776_16346(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				}
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
					loc1 = (EIF_REFERENCE) tr1;
				}
			}
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tb1 = F32_265(RTCW(tr1), arg2, loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F1162_8520(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_hour_in_half_day */
void F1776_16319 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg5);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLR(9,loc1);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	tr1 = RTMS_EX_H("h specifier not allowed for format-date()",41,1559511081);
	F1776_16307(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("1",1,49);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 0);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc2 = F1726_15204(Current, arg5);
			loc3 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
			ti4_1 = F1287_11141(RTCW(arg3));
			F1748_15536(RTCW(loc3), ti4_1);
			loc4 = *(EIF_REFERENCE *)(Current);
			RTCT0("selected_numberer_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTCT0("primary_modifier_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTMS_EX_H("",0,0);
			tr2 = F1776_16310(Current);
			tr3 = F1776_16309(Current);
			loc1 = F1728_15212(RTCW(loc2), loc3, loc4, ((EIF_INTEGER_32) 0L), tr1, tr2, tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
				if (F1776_16329(Current)) {
					tr1 = F1776_16345(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					tr1 = F1776_16346(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				}
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
					loc1 = (EIF_REFERENCE) tr1;
				}
			}
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tb1 = F32_265(RTCW(tr1), arg2, loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F1162_8520(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_am_pm */
void F1776_16320 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg5);
	RTLR(7,loc1);
	RTLR(8,arg2);
	RTLIU(9);
	
	RTGC;
	tr1 = RTMS_EX_H("P specifier not allowed for format-date()",41,2033319977);
	F1776_16307(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("n",1,110);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 1);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			if ((EIF_BOOLEAN) !F1776_16342(Current)) {
				tr1 = RTMS_EX_H("n",1,110);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
			}
			loc2 = F1726_15204(Current, arg5);
			RTCT0("selected_numberer_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			ti4_1 = F1287_11142(RTCW(arg3));
			ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_);
			ti4_3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_);
			tr1 = F1728_15215(RTCW(loc2), ti4_1, ti4_2, ti4_3);
			loc1 = F1776_16343(Current, tr1);
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tb1 = F32_265(RTCW(tr1), arg2, loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F1162_8520(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_minute */
void F1776_16321 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg5);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLR(9,loc1);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	tr1 = RTMS_EX_H("m specifier not allowed for format-date()",41,29147689);
	F1776_16307(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("01",2,12337);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 0);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc2 = F1726_15204(Current, arg5);
			loc3 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
			ti4_1 = F1287_11143(RTCW(arg3));
			F1748_15536(RTCW(loc3), ti4_1);
			loc4 = *(EIF_REFERENCE *)(Current);
			RTCT0("selected_numberer_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTCT0("primary_modifier_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTMS_EX_H("",0,0);
			tr2 = F1776_16310(Current);
			tr3 = F1776_16309(Current);
			loc1 = F1728_15212(RTCW(loc2), loc3, loc4, ((EIF_INTEGER_32) 0L), tr1, tr2, tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
				if (F1776_16329(Current)) {
					tr1 = F1776_16345(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					tr1 = F1776_16346(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				}
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
					loc1 = (EIF_REFERENCE) tr1;
				}
			}
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tb1 = F32_265(RTCW(tr1), arg2, loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F1162_8520(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_second */
void F1776_16322 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg5);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLR(9,loc1);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	tr1 = RTMS_EX_H("s specifier not allowed for format-date()",41,2058175273);
	F1776_16307(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("01",2,12337);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 0);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc2 = F1726_15204(Current, arg5);
			loc3 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
			ti4_1 = F1287_11144(RTCW(arg3));
			F1748_15536(RTCW(loc3), ti4_1);
			loc4 = *(EIF_REFERENCE *)(Current);
			RTCT0("selected_numberer_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTCT0("primary_modifier_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTMS_EX_H("",0,0);
			tr2 = F1776_16310(Current);
			tr3 = F1776_16309(Current);
			loc1 = F1728_15212(RTCW(loc2), loc3, loc4, ((EIF_INTEGER_32) 0L), tr1, tr2, tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
				if (F1776_16329(Current)) {
					tr1 = F1776_16345(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					tr1 = F1776_16346(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				}
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
					loc1 = (EIF_REFERENCE) tr1;
				}
			}
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tb1 = F32_265(RTCW(tr1), arg2, loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F1162_8520(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_millisecond */
void F1776_16323 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg5);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLR(9,loc1);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	tr1 = RTMS_EX_H("f specifier not allowed for format-date()",41,883168553);
	F1776_16307(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("1",1,49);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 0);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			loc2 = F1726_15204(Current, arg5);
			loc3 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
			ti4_1 = F1287_11145(RTCW(arg3));
			F1748_15536(RTCW(loc3), ti4_1);
			loc4 = *(EIF_REFERENCE *)(Current);
			RTCT0("selected_numberer_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTCT0("primary_modifier_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTMS_EX_H("",0,0);
			tr2 = F1776_16310(Current);
			tr3 = F1776_16309(Current);
			loc1 = F1728_15212(RTCW(loc2), loc3, loc4, ((EIF_INTEGER_32) 0L), tr1, tr2, tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
				tr1 = F1776_16347(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
					tr1 = RTOSCF(16324,F1776_16324, (Current));
					tr1 = F1748_15575(RTCW(loc3), tr1);
					loc3 = (EIF_REFERENCE) tr1;
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_);
					tr1 = RTOSCF(16348,F1776_16348, (Current));
					tr1 = F1748_15595(RTCW(loc3), (EIF_INTEGER_32) (((EIF_INTEGER_32) 0L) - ti4_1), tr1);
					loc3 = (EIF_REFERENCE) tr1;
					loc1 = F1748_15587(RTCW(loc3));
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, ((EIF_INTEGER_32) 3L), ti4_1);
						loc1 = (EIF_REFERENCE) tr1;
					}
				}
			}
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tb1 = F32_265(RTCW(tr1), arg2, loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F1162_8520(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.one_thousand */
static EIF_REFERENCE F1776_16324_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (16324);
#define Result RTOSR(16324)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1748_15536(RTCW(tr1), ((EIF_INTEGER_32) 1000L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (16324);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1776_16324 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16324,F1776_16324_body,(Current));
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_time_zone */
void F1776_16325 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg3);
	RTLR(1,arg1);
	RTLR(2,arg4);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLR(5,loc1);
	RTLR(6,arg2);
	RTLIU(7);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg3)+ _CHROFF_10_37_);
	if (tb1) {
		tr1 = RTMS_EX_H("1",1,49);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 1);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			if (F1776_16329(Current)) {
				loc1 = F1287_11146(RTCW(arg3));
			} else {
				loc1 = RTMS_EX_H("\?\?\?",3,4144959);
			}
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
				if (F1776_16329(Current)) {
					tr1 = F1776_16345(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					tr1 = F1776_16346(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				}
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
					loc1 = (EIF_REFERENCE) tr1;
				}
			}
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tb1 = F32_265(RTCW(tr1), arg2, loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F1162_8520(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_gmt_offset */
void F1776_16326 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg3);
	RTLR(1,arg1);
	RTLR(2,arg4);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLR(5,loc1);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,arg2);
	RTLIU(9);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg3)+ _CHROFF_10_37_);
	if (tb1) {
		tr1 = RTMS_EX_H("1",1,49);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 0);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("GMT",3,4672852);
			tr3 = F1287_11146(RTCW(arg3));
			loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
				tr1 = F1776_16346(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
					loc1 = (EIF_REFERENCE) tr1;
				}
			}
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tb1 = F32_265(RTCW(tr1), arg2, loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = F1162_8520(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_calendar_name */
void F1776_16327 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc1);
	RTLR(5,arg5);
	RTLR(6,arg2);
	RTLIU(7);
	
	RTGC;
	tr1 = RTMS_EX_H("n",1,110);
	F1776_16330(Current, arg1, arg3, tr1, (EIF_BOOLEAN) 1);
	if ((EIF_BOOLEAN) !F1776_16342(Current)) {
		tr1 = RTMS_EX_H("n",1,110);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_) <= ((EIF_INTEGER_32) 2L))) {
			loc1 = (EIF_REFERENCE) arg5;
		} else {
			loc1 = F1776_16340(Current, arg5);
		}
		tr1 = F1776_16343(Current, loc1);
		loc1 = (EIF_REFERENCE) tr1;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
			tr1 = F1776_16346(Current, loc1);
			loc1 = (EIF_REFERENCE) tr1;
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_))) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_)) + ((EIF_INTEGER_32) 1L)), ti4_2);
				loc1 = (EIF_REFERENCE) tr1;
			}
		}
		tr1 = RTOSCF(8225,F1134_8225, (Current));
		tb1 = F32_265(RTCW(tr1), arg2, loc1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = F1162_8520(Current, loc1);
			loc1 = (EIF_REFERENCE) tr1;
		}
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.format_era */
void F1776_16328 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(12);
	RTLR(0,arg1);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg4);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,loc1);
	RTLR(8,arg5);
	RTLR(9,arg6);
	RTLR(10,arg7);
	RTLR(11,arg2);
	RTLIU(12);
	
	RTGC;
	tr1 = RTMS_EX_H("E specifier not allowed for format-time()",41,1448733993);
	F1776_16308(Current, arg1, arg3, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = RTMS_EX_H("n",1,110);
		F1776_16330(Current, arg1, arg4, tr1, (EIF_BOOLEAN) 1);
		if ((EIF_BOOLEAN) !F1776_16342(Current)) {
			tr1 = RTMS_EX_H("n",1,110);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9156[Dtype(RTCW(arg3))-1889])(arg3);
			if (tb1) {
				tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("Era is not available with time values",37,1763476339);
				tr3 = RTMS_EX_H("XTDE1350",8,308926256);
				F9_110(RTCW(tr1), tr2, tr3);
				F210_1915(RTCW(arg1), tr1);
			} else {
				loc1 = F1776_16344(Current, arg3, arg5, arg6, arg7);
				tr1 = F1776_16343(Current, loc1);
				loc1 = (EIF_REFERENCE) tr1;
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_))) {
					tr1 = F1776_16346(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				}
				tr1 = RTOSCF(8225,F1134_8225, (Current));
				tb1 = F32_265(RTCW(tr1), arg2, loc1);
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = F1162_8520(Current, loc1);
					loc1 = (EIF_REFERENCE) tr1;
				}
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				F1148_8380(RTCW(tr1), arg2, loc1, ((EIF_INTEGER_32) 1L), ti4_1);
			}
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.is_decimal_format */
EIF_BOOLEAN F1776_16329 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	RTCT0("primary_modifier_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = '\01';
	if (!F1726_15205(Current, loc1)) {
		tb1 = '\0';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(loc1))-1112])(loc1, ((EIF_INTEGER_32) 1L));
			tb1 = F1726_15207(Current, ti4_1);
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.check_modifiers */
void F1776_16330 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,arg1);
	RTLR(8,loc2);
	RTLR(9,arg3);
	RTLIU(10);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_12_38_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	ti4_1 = RTOSCF(2037,F228_2037, (RTCV(RTOSCF(1557,F173_1557, (Current)))));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_) = (EIF_INTEGER_32) ti4_1;
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	tb1 = F772_3900(RTCW(arg2));
	if ((EIF_BOOLEAN) !tb1) {
		loc1 = RTLNS(eif_new_type(1263, 0x01).id, 1263, _OBJSIZ_2_2_0_0_0_0_0_0_);
		tr1 = RTMS_EX_H(",",1,44);
		F1264_10635(RTCW(loc1), tr1);
		loc4 = F1264_10645(RTCW(loc1), arg2);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9566[Dtype(RTCW(loc4))-1481])(loc4);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("More than one comma present in \'",32,752063271);
			loc3 = F1148_8367(RTCW(tr1), tr2, arg2);
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("\'",1,39);
			tr1 = F1148_8377(RTCW(tr1), loc3, tr2);
			loc3 = (EIF_REFERENCE) tr1;
			tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("XTDE1340",8,308926000);
			F9_110(RTCW(tr1), loc3, tr2);
			F210_1915(RTCW(arg1), tr1);
		} else {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9566[Dtype(RTCW(loc4))-1481])(loc4);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(loc4))-1481])(loc4, ((EIF_INTEGER_32) 1L));
				tb1 = '\01';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
				if (!(EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 1L))) {
					tb2 = '\0';
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(loc2))-852])(loc2, ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) 'i')) {
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(loc2))-852])(loc2, ((EIF_INTEGER_32) 1L)));
						tb2 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) 'I');
					}
					tb1 = tb2;
				}
				if (tb1) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(loc4))-1481])(loc4, ((EIF_INTEGER_32) 2L));
					F1776_16332(Current, arg1, tr1);
				}
			} else {
				loc2 = (EIF_REFERENCE) arg2;
				if (F1726_15205(Current, loc2)) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_) = (EIF_INTEGER_32) ti4_1;
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_) = (EIF_INTEGER_32) ti4_1;
				} else {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					ti4_1 = RTOSCF(2037,F228_2037, (RTCV(RTOSCF(1557,F173_1557, (Current)))));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_) = (EIF_INTEGER_32) ti4_1;
				}
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				F1148_8385(RTCW(tr1), loc2);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				F1148_8386(RTCW(tr1), loc2);
				loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(loc2))-1111])(loc2, (EIF_CHARACTER_8) 't', ((EIF_INTEGER_32) 1L));
				if ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(loc5 == ti4_1)) {
						*(EIF_BOOLEAN *)(Current+ _CHROFF_12_37_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = RTOSCF(8530,F1163_8530, (Current));
						tr2 = RTMS_EX_H("Misplaced \'t\' in \'",18,642431271);
						loc3 = F1148_8367(RTCW(tr1), tr2, loc2);
						tr1 = RTOSCF(8530,F1163_8530, (Current));
						tr2 = RTMS_EX_H("\'",1,39);
						tr1 = F1148_8377(RTCW(tr1), loc3, tr2);
						loc3 = (EIF_REFERENCE) tr1;
						tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("XTDE1340",8,308926000);
						F9_110(RTCW(tr1), loc3, tr2);
						F210_1915(RTCW(arg1), tr1);
					}
				}
				loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(loc2))-1111])(loc2, (EIF_CHARACTER_8) 'o', ((EIF_INTEGER_32) 1L));
				if ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(loc5 == ti4_1)) {
						*(EIF_BOOLEAN *)(Current+ _CHROFF_12_38_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = RTOSCF(8530,F1163_8530, (Current));
						tr2 = RTMS_EX_H("Misplaced \'o\' in \'",18,273328679);
						loc3 = F1148_8367(RTCW(tr1), tr2, loc2);
						tr1 = RTOSCF(8530,F1163_8530, (Current));
						tr2 = RTMS_EX_H("\'",1,39);
						tr1 = F1148_8377(RTCW(tr1), loc3, tr2);
						loc3 = (EIF_REFERENCE) tr1;
						tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("XTDE1340",8,308926000);
						F9_110(RTCW(tr1), loc3, tr2);
						F210_1915(RTCW(arg1), tr1);
					}
				}
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_12_37_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_12_38_))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc2))-1111])(loc2, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
					loc2 = (EIF_REFERENCE) tr1;
				}
				tb1 = F772_3900(RTCW(loc2));
				if ((EIF_BOOLEAN) !tb1) {
					F1776_16331(Current, loc2, arg4);
				}
			}
		}
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == NULL);
	}
	if (tb1) {
		RTAR(Current, arg3);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg3;
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.set_primary_modifier */
void F1776_16331 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_BOOLEAN tb7;
	EIF_BOOLEAN tb8;
	EIF_BOOLEAN tb9;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\01';
	tb4 = '\01';
	tb5 = '\01';
	tb6 = '\01';
	tb7 = '\01';
	tb8 = '\01';
	if (!F1726_15205(Current, arg1)) {
		tb9 = '\0';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, ((EIF_INTEGER_32) 1L));
			tb9 = F1726_15207(Current, ti4_1);
		}
		tb8 = tb9;
	}
	if (!tb8) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("A",1,65);
		tb8 = F1148_8369(RTCW(tr1), arg1, tr2);
		tb7 = tb8;
	}
	if (!tb7) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("a",1,97);
		tb7 = F1148_8369(RTCW(tr1), arg1, tr2);
		tb6 = tb7;
	}
	if (!tb6) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("I",1,73);
		tb6 = F1148_8369(RTCW(tr1), arg1, tr2);
		tb5 = tb6;
	}
	if (!tb5) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("i",1,105);
		tb5 = F1148_8369(RTCW(tr1), arg1, tr2);
		tb4 = tb5;
	}
	if (!tb4) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("W",1,87);
		tb4 = F1148_8369(RTCW(tr1), arg1, tr2);
		tb3 = tb4;
	}
	if (!tb3) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("w",1,119);
		tb3 = F1148_8369(RTCW(tr1), arg1, tr2);
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("Ww",2,22391);
		tb2 = F1148_8369(RTCW(tr1), arg1, tr2);
		tb1 = tb2;
	}
	if (tb1) {
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	} else {
		tb1 = '\01';
		tb2 = '\01';
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("Nn",2,20078);
		tb3 = F1148_8369(RTCW(tr1), arg1, tr2);
		if (!tb3) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("N",1,78);
			tb3 = F1148_8369(RTCW(tr1), arg1, tr2);
			tb2 = tb3;
		}
		if (!tb2) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("n",1,110);
			tb2 = F1148_8369(RTCW(tr1), arg1, tr2);
			tb1 = tb2;
		}
		if (tb1) {
			if (arg2) {
				RTAR(Current, arg1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
			}
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.set_widths */
void F1776_16332 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLR(5,tr2);
	RTLR(6,arg1);
	RTLR(7,loc4);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1263, 0x01).id, 1263, _OBJSIZ_2_2_0_0_0_0_0_0_);
	tr1 = RTMS_EX_H("-",1,45);
	F1264_10635(RTCW(loc1), tr1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg2))-1111])(arg2, (EIF_CHARACTER_8) '+', ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("Plus sign present in \'",22,794874919);
		loc2 = F1148_8367(RTCW(tr1), tr2, arg2);
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("\'",1,39);
		tr1 = F1148_8377(RTCW(tr1), loc2, tr2);
		loc2 = (EIF_REFERENCE) tr1;
		tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("XTDE1340",8,308926000);
		F9_110(RTCW(tr1), loc2, tr2);
		F210_1915(RTCW(arg1), tr1);
	} else {
		loc4 = F1264_10645(RTCW(loc1), arg2);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9566[Dtype(RTCW(loc4))-1481])(loc4);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("Two many hyphens in \'",21,1488393255);
			loc2 = F1148_8367(RTCW(tr1), tr2, arg2);
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("\'",1,39);
			tr1 = F1148_8377(RTCW(tr1), loc2, tr2);
			loc2 = (EIF_REFERENCE) tr1;
			tr1 = RTLNS(eif_new_type(8, 0x01).id, 8, _OBJSIZ_3_1_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("XTDE1340",8,308926000);
			F9_110(RTCW(tr1), loc2, tr2);
			F210_1915(RTCW(arg1), tr1);
		} else {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9566[Dtype(RTCW(loc4))-1481])(loc4);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
				loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(loc4))-1481])(loc4, ((EIF_INTEGER_32) 1L));
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				F1148_8385(RTCW(tr1), loc3);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				F1148_8386(RTCW(tr1), loc3);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H("*",1,42);
				tb1 = F1148_8369(RTCW(tr1), loc3, tr2);
				if (tb1) {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				} else {
					tb1 = F1108_6339(RTCW(loc3));
					if (tb1) {
						ti4_1 = F1108_6373(RTCW(loc3));
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_) = (EIF_INTEGER_32) ti4_1;
					}
				}
				loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(loc4))-1481])(loc4, ((EIF_INTEGER_32) 2L));
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				F1148_8385(RTCW(tr1), loc3);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				F1148_8386(RTCW(tr1), loc3);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H("*",1,42);
				tb1 = F1148_8369(RTCW(tr1), loc3, tr2);
				if (tb1) {
					ti4_1 = RTOSCF(2037,F228_2037, (RTCV(RTOSCF(1557,F173_1557, (Current)))));
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_) = (EIF_INTEGER_32) ti4_1;
				} else {
					tb1 = F1108_6339(RTCW(loc3));
					if (tb1) {
						ti4_1 = F1108_6373(RTCW(loc3));
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_) = (EIF_INTEGER_32) ti4_1;
					}
				}
			} else {
				loc3 = (EIF_REFERENCE) arg2;
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				F1148_8385(RTCW(tr1), loc3);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				F1148_8386(RTCW(tr1), loc3);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H("*",1,42);
				tb1 = F1148_8369(RTCW(tr1), loc3, tr2);
				if (tb1) {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				} else {
					tb1 = F1108_6339(RTCW(loc3));
					if (tb1) {
						ti4_1 = F1108_6373(RTCW(loc3));
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_) = (EIF_INTEGER_32) ti4_1;
					}
				}
				ti4_1 = RTOSCF(2037,F228_2037, (RTCV(RTOSCF(1557,F173_1557, (Current)))));
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_) = (EIF_INTEGER_32) ti4_1;
			}
		}
	}
	RTLE;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.is_valid_specifier */
EIF_BOOLEAN F1776_16333 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	switch (arg1) {
		case (EIF_CHARACTER_8) 'C':
		case (EIF_CHARACTER_8) 'D':
		case (EIF_CHARACTER_8) 'E':
		case (EIF_CHARACTER_8) 'F':
		case (EIF_CHARACTER_8) 'H':
		case (EIF_CHARACTER_8) 'M':
		case (EIF_CHARACTER_8) 'P':
		case (EIF_CHARACTER_8) 'W':
		case (EIF_CHARACTER_8) 'Y':
		case (EIF_CHARACTER_8) 'Z':
		case (EIF_CHARACTER_8) 'd':
		case (EIF_CHARACTER_8) 'f':
		case (EIF_CHARACTER_8) 'h':
		case (EIF_CHARACTER_8) 'm':
		case (EIF_CHARACTER_8) 's':
		case (EIF_CHARACTER_8) 'w':
		case (EIF_CHARACTER_8) 'z':
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			break;
		default:
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			break;
	}
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.is_language_supported */
EIF_BOOLEAN F1776_16334 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(16293,F1776_16293, (Current));
	Result = F1148_8369(RTCW(tr1), arg1, tr2);
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.language */
EIF_REFERENCE F1776_16335 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) RTOSCF(16293,F1776_16293, (Current));
}

/* {ST_XSLT_FORMAT_DATE_TIME}.language_prefix */
EIF_REFERENCE F1776_16336 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTMS_EX_H("[Language: en]",14,592123485);
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.is_calendar_supported */
EIF_BOOLEAN F1776_16337 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\01';
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(16294,F1776_16294, (Current));
	tb1 = F1148_8369(RTCW(tr1), arg1, tr2);
	if (!tb1) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(16297,F1776_16297, (Current));
		tb1 = F1148_8369(RTCW(tr1), arg1, tr2);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.calendar */
EIF_REFERENCE F1776_16338 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) RTOSCF(16294,F1776_16294, (Current));
}

/* {ST_XSLT_FORMAT_DATE_TIME}.calendar_prefix */
EIF_REFERENCE F1776_16339 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTMS_EX_H("[Calendar: CE]",14,383411037);
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.calendar_name */
EIF_REFERENCE F1776_16340 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(16294,F1776_16294, (Current));
	tb1 = F1148_8369(RTCW(tr1), arg1, tr2);
	if (tb1) {
		loc1 = RTMS_EX_H("Common Era",10,120378977);
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(16297,F1776_16297, (Current));
		tb1 = F1148_8369(RTCW(tr1), arg1, tr2);
		if (tb1) {
			loc1 = RTMS_EX_H("Christian Era",13,649698657);
		}
	}
	RTCT0("l_result /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.week_day_number */
EIF_INTEGER_32 F1776_16341 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(16296,F1776_16296, (Current));
	tb1 = F1148_8369(RTCW(tr1), arg2, tr2);
	if (tb1) {
		RTLE;
		return (EIF_INTEGER_32) arg1;
	} else {
		tr1 = RTOSCF(2427,F320_2427, (Current));
		tr1 = F1282_11030(RTCW(tr1), arg1);
		tr1 = F1293_11240(RTCW(tr1));
		Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_0_0_);
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.is_name_modifier */
EIF_BOOLEAN F1776_16342 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	RTCT0("primary_modifier_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tb1 = '\01';
	tb2 = '\01';
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("n",1,110);
	tb3 = F1148_8369(RTCW(tr1), loc1, tr2);
	if (!tb3) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("N",1,78);
		tb3 = F1148_8369(RTCW(tr1), loc1, tr2);
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("Nn",2,20078);
		tb2 = F1148_8369(RTCW(tr1), loc1, tr2);
		tb1 = tb2;
	}
	if (tb1) {
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.correctly_cased_name */
EIF_REFERENCE F1776_16343 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	RTCT0("primary_modifier_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("n",1,110);
	tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
	if (tb1) {
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(arg1))-1112])(arg1);
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("N",1,78);
		tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
		if (tb1) {
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5053[Dtype(RTCW(arg1))-1112])(arg1);
		} else {
			Result = (EIF_REFERENCE) arg1;
		}
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.era */
EIF_REFERENCE F1776_16344 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,tr2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = F1287_11132(RTCW(arg1));
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(16294,F1776_16294, (Current));
	tb1 = F1148_8369(RTCW(tr1), arg3, tr2);
	if (tb1) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_) >= ((EIF_INTEGER_32) 10L))) {
				Result = RTMS_EX_H("Common Era",10,120378977);
			} else {
				Result = RTMS_EX_H("CE",2,17221);
			}
		} else {
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_) >= ((EIF_INTEGER_32) 17L))) {
				Result = RTMS_EX_H("Before Common Era",17,729394017);
			} else {
				Result = RTMS_EX_H("BCE",3,4342597);
			}
		}
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(16297,F1776_16297, (Current));
		tb1 = F1148_8369(RTCW(tr1), arg3, tr2);
		if (tb1) {
			if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_) >= ((EIF_INTEGER_32) 11L))) {
					Result = RTMS_EX_H("Anno Domini",11,211952489);
				} else {
					Result = RTMS_EX_H("AD",2,16708);
				}
			} else {
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_1_) >= ((EIF_INTEGER_32) 13L))) {
					Result = RTMS_EX_H("Before Christ",13,1111198324);
				} else {
					Result = RTMS_EX_H("BC",2,16963);
				}
			}
		} else {
			Result = RTMS_EX_H("Unknown",7,1902194030);
		}
	}
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.prepended_with_zeros */
EIF_REFERENCE F1776_16345 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	F1111_6439(RTCW(Result), (EIF_CHARACTER_8) '0', (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_) - ti4_1));
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr1 = F1148_8377(RTCW(tr1), Result, arg1);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.appended_with_blanks */
EIF_REFERENCE F1776_16346 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	F1111_6439(RTCW(Result), (EIF_CHARACTER_8) ' ', (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_) - ti4_1));
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr1 = F1148_8367(RTCW(tr1), arg1, Result);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.appended_with_zeros */
EIF_REFERENCE F1776_16347 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	F1111_6439(RTCW(Result), (EIF_CHARACTER_8) '0', (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_40_0_0_) - ti4_1));
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr1 = F1148_8367(RTCW(tr1), arg1, Result);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {ST_XSLT_FORMAT_DATE_TIME}.shared_half_even_context */
static EIF_REFERENCE F1776_16348_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (16348);
#define Result RTOSR(16348)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1774, 0x01).id, 1774, _OBJSIZ_3_2_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F172_1553(Current))+ _LNGOFF_3_2_0_0_);
	F1775_16261(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 6L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (16348);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1776_16348 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(16348,F1776_16348_body,(Current));
}

void EIF_Minit849 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
