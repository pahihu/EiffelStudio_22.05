/*
 * Code for class XM_XPATH_DOC_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm830.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_DOC_ROUTINES}.parse_document */
void F1757_15933 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLR(10,loc4);
	RTLR(11,loc5);
	RTLR(12,loc2);
	RTLR(13,loc6);
	RTLR(14,loc7);
	RTLR(15,loc8);
	RTLIU(16);
	
	RTGC;
	loc3 = F1757_15935(Current, arg1);
	loc1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
	F1707_14587(RTCW(loc1), arg2, loc3);
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg3) + O12569[Dtype(arg3)-1765]);
	if (tb1) {
		tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("No documents are available during use-when processing",53,1141644391);
		tr3 = RTOSCF(9827,F1230_9827, (Current));
		tr4 = RTMS_EX_H("FODC0005",8,2066165813);
		F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12559[Dtype(RTCW(arg3))-1766])(arg3);
		tb1 = F186_1694(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
			tr2 = RTOSCF(8530,F1163_8530, (Current));
			tr3 = RTMS_EX_H("Security manager refused permission to read from ",49,1442756896);
			tr4 = F1707_14605(RTCW(loc1));
			tr2 = F1148_8367(RTCW(tr2), tr3, tr4);
			tr3 = RTOSCF(9829,F1230_9829, (Current));
			tr4 = RTMS_EX_H("SECURITY",8,1901200985);
			F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		} else {
			tb1 = '\0';
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12558[Dtype(RTCW(arg3))-1766])(arg3);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				tr1 = F1707_14605(RTCW(loc1));
				tb2 = F1579_12950(loc4, tr1);
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = F1707_14605(RTCW(loc1));
				tr1 = F1579_12952(loc4, tr1);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
				tr1 = F1707_14605(RTCW(loc1));
				tr1 = F1579_12953(loc4, tr1);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			} else {
				tr1 = F1707_14605(RTCW(loc1));
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R12580[Dtype(RTCW(arg3))-1766])(arg3, tr1);
				if (tb1) {
					tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
					tr2 = RTOSCF(8530,F1163_8530, (Current));
					tr3 = F1707_14605(RTCW(loc1));
					tr4 = RTMS_EX_H(" has already been written to, so reading is not permitted",57,533659236);
					tr2 = F1148_8367(RTCW(tr2), tr3, tr4);
					tr3 = RTOSCF(9827,F1230_9827, (Current));
					tr4 = RTMS_EX_H("XTRE1500",8,336581168);
					F1820_17199(RTCW(tr1), tr2, tr3, tr4, ((EIF_INTEGER_32) 3L));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
				} else {
					tr1 = F1707_14605(RTCW(loc1));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R12593[Dtype(RTCW(arg3))-1766])(arg3, tr1);
					tb1 = *(EIF_BOOLEAN *)(RTCW(arg3) + O12577[Dtype(arg3)-1765]);
					if (tb1) {
						RTCT0("postcondition_of_build_document", EX_CHECK);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12578[Dtype(RTCW(arg3))-1766])(arg3);
						loc5 = tr1;
						if (EIF_TEST(loc5)) {
							RTCK0;
						} else {
							RTCF0;
						}
						tr1 = RTOSCF(8530,F1163_8530, (Current));
						tr2 = RTMS_EX_H("Failed to parse ",16,2106347808);
						tr3 = F1707_14605(RTCW(loc1));
						loc2 = F1148_8367(RTCW(tr1), tr2, tr3);
						tr1 = RTOSCF(8530,F1163_8530, (Current));
						tr2 = RTMS_EX_H(". ",2,11808);
						tr1 = F1148_8377(RTCW(tr1), loc2, tr2);
						loc2 = (EIF_REFERENCE) tr1;
						tr1 = RTOSCF(8530,F1163_8530, (Current));
						tr1 = F1148_8377(RTCW(tr1), loc2, loc5);
						loc2 = (EIF_REFERENCE) tr1;
						tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_1_1_0_0_0_0_0_0_);
						tr2 = RTOSCF(9827,F1230_9827, (Current));
						tr3 = RTMS_EX_H("FODC0005",8,2066165813);
						F1820_17199(RTCW(tr1), loc2, tr2, tr3, ((EIF_INTEGER_32) 3L));
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
						tb1 = '\0';
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12558[Dtype(RTCW(arg3))-1766])(arg3);
						loc6 = tr1;
						if (EIF_TEST(loc6)) {
							ti4_1 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_3_0_0_0_);
							tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 4L));
						}
						if (tb1) {
							tr1 = F1707_14605(RTCW(loc1));
							F1579_12955(loc6, NULL, NULL, tr1);
						}
					} else {
						RTCT0("postcondition_of_build_document", EX_CHECK);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12567[Dtype(RTCW(arg3))-1766])(arg3);
						loc7 = tr1;
						if (EIF_TEST(loc7)) {
							RTCK0;
						} else {
							RTCF0;
						}
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12568[Dtype(RTCW(arg3))-1766])(arg3);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
						RTAR(Current, loc7);
						*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc7;
						tb1 = '\0';
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12558[Dtype(RTCW(arg3))-1766])(arg3);
						loc8 = tr1;
						if (EIF_TEST(loc8)) {
							ti4_1 = *(EIF_INTEGER_32 *)(loc8+ _LNGOFF_3_0_0_0_);
							tb1 = (EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 3L));
						}
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							tr2 = F1707_14605(RTCW(loc1));
							F1579_12955(loc8, loc7, tr1, tr2);
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_XPATH_DOC_ROUTINES}.uri_encoding */
static EIF_REFERENCE F1757_15934_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (15934);
#define Result RTOSR(15934)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1752, 0x01).id, 1752, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15934);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1757_15934 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15934,F1757_15934_body,(Current));
}

/* {XM_XPATH_DOC_ROUTINES}.escaped_uri */
EIF_REFERENCE F1757_15935 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(4521,F954_4521, (Current));
	tr1 = F1138_8299(RTCW(tr1), arg1);
	tr2 = RTOSCF(15936,F1757_15936, (Current));
	Result = F1753_15774(Current, tr1, tr2, (EIF_BOOLEAN) 0);
	RTLE;
	return Result;
}

/* {XM_XPATH_DOC_ROUTINES}.unescaped_iri_characters */
static EIF_REFERENCE F1757_15936_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOSP (15936);
#define Result RTOSR(15936)
	RTOC_NEW(Result);
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(15778,F1753_15778, (Current));
	tr3 = RTOSCF(15779,F1753_15779, (Current));
	loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(15780,F1753_15780, (Current));
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(15781,F1753_15781, (Current));
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(15782,F1753_15782, (Current));
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(15783,F1753_15783, (Current));
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("#",1,35);
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("%",1,37);
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	Result = F1753_15776(Current, loc1);
	RTOSE (15936);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1757_15936 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15936,F1757_15936_body,(Current));
}

void EIF_Minit830 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
