/*
 * Code for class XM_XPATH_SHARED_DECIMAL_CONTEXTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm824.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_SHARED_DECIMAL_CONTEXTS}.shared_integer_context */
static EIF_REFERENCE F1751_15736_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15736);
#define Result RTOSR(15736)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1774, 0x01).id, 1774, _OBJSIZ_3_2_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F172_1553(Current))+ _LNGOFF_3_2_0_0_);
	F1775_16261(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 1L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15736);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1751_15736 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15736,F1751_15736_body,(Current));
}

/* {XM_XPATH_SHARED_DECIMAL_CONTEXTS}.shared_round_context */
static EIF_REFERENCE F1751_15737_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15737);
#define Result RTOSR(15737)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1774, 0x01).id, 1774, _OBJSIZ_3_2_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F172_1553(Current))+ _LNGOFF_3_2_0_0_);
	F1775_16261(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 4L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15737);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1751_15737 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15737,F1751_15737_body,(Current));
}

/* {XM_XPATH_SHARED_DECIMAL_CONTEXTS}.shared_negative_round_context */
static EIF_REFERENCE F1751_15738_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15738);
#define Result RTOSR(15738)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1774, 0x01).id, 1774, _OBJSIZ_3_2_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F172_1553(Current))+ _LNGOFF_3_2_0_0_);
	F1775_16261(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15738);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1751_15738 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15738,F1751_15738_body,(Current));
}

/* {XM_XPATH_SHARED_DECIMAL_CONTEXTS}.shared_half_even_context */
static EIF_REFERENCE F1751_15739_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15739);
#define Result RTOSR(15739)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1774, 0x01).id, 1774, _OBJSIZ_3_2_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F172_1553(Current))+ _LNGOFF_3_2_0_0_);
	F1775_16261(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 6L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15739);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1751_15739 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15739,F1751_15739_body,(Current));
}

/* {XM_XPATH_SHARED_DECIMAL_CONTEXTS}.shared_floor_context */
static EIF_REFERENCE F1751_15740_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15740);
#define Result RTOSR(15740)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1774, 0x01).id, 1774, _OBJSIZ_3_2_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F172_1553(Current))+ _LNGOFF_3_2_0_0_);
	F1775_16261(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 3L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15740);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1751_15740 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15740,F1751_15740_body,(Current));
}

/* {XM_XPATH_SHARED_DECIMAL_CONTEXTS}.shared_ceiling_context */
static EIF_REFERENCE F1751_15741_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15741);
#define Result RTOSR(15741)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1774, 0x01).id, 1774, _OBJSIZ_3_2_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F172_1553(Current))+ _LNGOFF_3_2_0_0_);
	F1775_16261(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15741);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1751_15741 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15741,F1751_15741_body,(Current));
}

void EIF_Minit824 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
