/*
 * Code for class XM_XPATH_CONFIGURATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm822.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_CONFIGURATION}.make_configuration */
void F1749_15655 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1536,0xFF01,1536,0xFF01,1112,0xFF01,1112,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1525_12401(RTCW(tr1), ((EIF_INTEGER_32) 3L), NULL, tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1536,0xFF01,1112,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 1536, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	tr1 = RTOSCF(8115,F1125_8115, (Current));
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1525_12401(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1, tr2);
	tr1 = RTOSCF(9829,F1230_9829, (Current));
	F1749_15678(Current, loc1, tr1);
	tr1 = F172_1553(Current);
	F1775_16274(RTCW(tr1), ((EIF_INTEGER_32) 18L));
	*(EIF_BOOLEAN *)(Current + O12166[Dtype(Current)-1748]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XPATH_CONFIGURATION}.standard_file_collection */

EIF_REFERENCE F1749_15656 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15656,RTMS_EX_H("standard-file-collection",24,1805513582));
}

/* {XM_XPATH_CONFIGURATION}.collection_resolver */
EIF_REFERENCE F1749_15659 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = RTLNS(eif_new_type(1587, 0x01).id, 1587, _OBJSIZ_3_0_0_0_0_0_0_0_);
		F1588_13179(RTCW(loc1), Current);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc1;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {XM_XPATH_CONFIGURATION}.is_tracing */
EIF_BOOLEAN F1749_15666 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {XM_XPATH_CONFIGURATION}.are_all_nodes_untyped */
EIF_BOOLEAN F1749_15668 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_XPATH_CONFIGURATION}.is_uri_written */
EIF_BOOLEAN F1749_15669 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {XM_XPATH_CONFIGURATION}.suppress_trace_output */
void F1749_15670 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O12168[Dtype(Current)-1748]) = (EIF_BOOLEAN) arg1;
}

/* {XM_XPATH_CONFIGURATION}.set_digits */
void F1749_15676 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F172_1553(Current);
	F1775_16274(RTCW(tr1), arg1);
	RTLE;
}

/* {XM_XPATH_CONFIGURATION}.trace */
void F1749_15677 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {XM_XPATH_CONFIGURATION}.register_property_namespace_table */
void F1749_15678 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1525_12424(RTCW(tr1), arg1, arg2);
	RTLE;
}

void EIF_Minit822 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
