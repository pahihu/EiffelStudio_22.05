/*
 * Code for class XM_XPATH_PROXY_RECEIVER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm807.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_PROXY_RECEIVER}.mark_as_written */
void F1734_15315 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O11859[dtype-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = *(EIF_REFERENCE *)(Current + O11905[dtype-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11863[Dtype(RTCW(tr1))-1732])(tr1);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.on_error */
void F1734_15316 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O11905[Dtype(Current)-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11864[Dtype(RTCW(tr1))-1732])(tr1, arg1);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.open */
void F1734_15317 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O11857[dtype-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = *(EIF_REFERENCE *)(Current + O11905[dtype-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11865[Dtype(RTCW(tr1))-1732])(tr1);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.start_document */
void F1734_15318 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O11858[dtype-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = *(EIF_REFERENCE *)(Current + O11905[dtype-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11866[Dtype(RTCW(tr1))-1732])(tr1);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.set_unparsed_entity */
void F1734_15319 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	F1734_15315(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O11905[Dtype(Current)-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R11867[Dtype(RTCW(tr1))-1732])(tr1, arg1, arg2, arg3);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.start_element */
void F1734_15320 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1734_15315(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O11905[Dtype(Current)-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R11868[Dtype(RTCW(tr1))-1732])(tr1, arg1, arg2, arg3);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.notify_namespace */
void F1734_15321 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1734_15315(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O11905[Dtype(Current)-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11869[Dtype(RTCW(tr1))-1732])(tr1, arg1, arg2);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.notify_attribute */
void F1734_15322 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTGC;
	F1734_15315(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O11905[Dtype(Current)-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_INTEGER_32)) R11870[Dtype(RTCW(tr1))-1732])(tr1, arg1, arg2, arg3, arg4);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.start_content */
void F1734_15323 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1734_15315(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O11905[Dtype(Current)-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11871[Dtype(RTCW(tr1))-1732])(tr1);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.end_element */
void F1734_15324 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1734_15315(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O11905[Dtype(Current)-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11872[Dtype(RTCW(tr1))-1732])(tr1);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.notify_characters */
void F1734_15325 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	F1734_15315(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O11905[Dtype(Current)-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, arg1, arg2);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.notify_processing_instruction */
void F1734_15326 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	F1734_15315(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O11905[Dtype(Current)-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11874[Dtype(RTCW(tr1))-1732])(tr1, arg1, arg2, arg3);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.notify_comment */
void F1734_15327 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	F1734_15315(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O11905[Dtype(Current)-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11875[Dtype(RTCW(tr1))-1732])(tr1, arg1, arg2);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.end_document */
void F1734_15328 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O11858[dtype-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + O11905[dtype-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11876[Dtype(RTCW(tr1))-1732])(tr1);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.close */
void F1734_15329 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O11905[dtype-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11877[Dtype(RTCW(tr1))-1732])(tr1);
	*(EIF_BOOLEAN *)(Current + O11857[dtype-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.set_document_uri */
void F1734_15330 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1729_15263(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O11905[Dtype(Current)-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11878[Dtype(RTCW(tr1))-1732])(tr1, arg1);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.set_base_uri */
void F1734_15331 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1729_15264(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O11905[Dtype(Current)-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11879[Dtype(RTCW(tr1))-1732])(tr1, arg1);
	RTLE;
}

/* {XM_XPATH_PROXY_RECEIVER}.set_document_locator */
void F1734_15332 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O11905[Dtype(Current)-1733]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11880[Dtype(RTCW(tr1))-1732])(tr1, arg1);
	RTLE;
}

void EIF_Minit807 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
