/*
 * Code for class UT_URL_ENCODING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut826.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_URL_ENCODING}.unescape_string */
EIF_REFERENCE F1753_15770 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,loc4);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	Result = F1148_8376(RTCW(tr1), arg1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(Result))-852])(Result, loc1));
		if ((EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) '+')) {
			tc1 = (EIF_CHARACTER_8) ' ';
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3404[Dtype(RTCW(Result))-879])(Result, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc1);
		} else {
			if ((EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) '%')) {
				if ((EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)))) {
					loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(Result))-1111])(Result, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tb1 = F1148_8358(RTCW(tr1), loc4);
					if (tb1) {
						tr1 = RTOSCF(6771,F1118_6771, (Current));
						tr2 = RTOSCF(8530,F1163_8530, (Current));
						ti4_1 = F1148_8384(RTCW(tr2), loc4);
						tc1 = F1174_8726(RTCW(tr1), ti4_1);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3404[Dtype(RTCW(Result))-879])(Result, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc1);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5114[Dtype(RTCW(Result))-1112])(Result, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5114[Dtype(RTCW(Result))-1112])(Result, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
						loc2 -= ((EIF_INTEGER_32) 2L);
					}
				}
			}
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {UT_URL_ENCODING}.unescape_utf8 */
EIF_REFERENCE F1753_15771 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = F1753_15770(Current, arg1);
	loc1 = F1753_15775(Current, Result);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 255L))) {
		RTLE;
		return (EIF_REFERENCE) NULL;
	} else {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 127L))) {
			tr1 = RTOSCF(8225,F1134_8225, (Current));
			tr2 = RTMS_EX_H("",0,0);
			tb1 = F32_265(RTCW(tr1), arg1, tr2);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5133[Dtype(RTCW(Result))-1111])(Result);
				Result = (EIF_REFERENCE) tr1;
			}
			tr1 = RTOSCF(4521,F954_4521, (Current));
			tb1 = F1138_8268(RTCW(tr1), Result);
			if (tb1) {
				RTLE;
				return (EIF_REFERENCE) F1162_8521(Current, Result);
			} else {
				RTLE;
				return (EIF_REFERENCE) NULL;
			}
		}
	}
	RTLE;
	return Result;
}

/* {UT_URL_ENCODING}.escape_utf8 */
EIF_REFERENCE F1753_15773 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = RTOSCF(15777,F1753_15777, (Current));
	tr1 = RTOSCF(4521,F954_4521, (Current));
	tr1 = F1138_8299(RTCW(tr1), arg1);
	Result = F1753_15774(Current, tr1, loc1, (EIF_BOOLEAN) 1);
	RTLE;
	return Result;
}

/* {UT_URL_ENCODING}.escape_custom */
EIF_REFERENCE F1753_15774 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	Result = F1148_8376(RTCW(tr1), arg1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(Result))-852])(Result, loc1));
		if ((EIF_BOOLEAN) (arg3 && (EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) ' '))) {
			tc1 = (EIF_CHARACTER_8) '+';
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3404[Dtype(RTCW(Result))-879])(Result, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc1);
		} else {
			tb1 = F1518_12336(RTCW(arg2), loc3);
			if (tb1) {
			} else {
				tc1 = (EIF_CHARACTER_8) '%';
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3404[Dtype(RTCW(Result))-879])(Result, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc1);
				loc1++;
				tr1 = RTOSCF(6771,F1118_6771, (Current));
				ti4_1 = (EIF_INTEGER_32) (loc3);
				tr1 = F1174_8727(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 / ((EIF_INTEGER_32) 16L)) % ((EIF_INTEGER_32) 16L)), (EIF_BOOLEAN) 1);
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(tr1))-852])(tr1, ((EIF_INTEGER_32) 1L)));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5184[Dtype(RTCW(Result))-1112])(Result, tc1, loc1);
				loc1++;
				tr1 = RTOSCF(6771,F1118_6771, (Current));
				ti4_1 = (EIF_INTEGER_32) (loc3);
				tr1 = F1174_8727(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 % ((EIF_INTEGER_32) 16L)), (EIF_BOOLEAN) 1);
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(tr1))-852])(tr1, ((EIF_INTEGER_32) 1L)));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5184[Dtype(RTCW(Result))-1112])(Result, tc1, loc1);
				loc2 += ((EIF_INTEGER_32) 2L);
			}
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {UT_URL_ENCODING}.maximum_character_code_in_string */
EIF_INTEGER_32 F1753_15775 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc1);
		if ((EIF_BOOLEAN) (loc3 > Result)) {
			Result = (EIF_INTEGER_32) loc3;
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {UT_URL_ENCODING}.new_character_set */
EIF_REFERENCE F1753_15776 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1523,1065,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1523, _OBJSIZ_7_0_0_9_0_0_0_0_);
	}
	F1518_12332(RTCW(Result));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(arg1))-852])(arg1, loc1));
		F1518_12345(RTCW(Result), tc1);
		loc1++;
	}
	RTLE;
	return Result;
}

/* {UT_URL_ENCODING}.default_unescaped */
static EIF_REFERENCE F1753_15777_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTLD;
	

	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTEV;
	RTGC;
	RTOSP (15777);
#define Result RTOSR(15777)
	RTOC_NEW(Result);
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(8530,F1163_8530, (Current));
	tr3 = RTOSCF(15778,F1753_15778, (Current));
	tr4 = RTOSCF(15779,F1753_15779, (Current));
	tr2 = F1148_8367(RTCW(tr2), tr3, tr4);
	tr3 = RTOSCF(8530,F1163_8530, (Current));
	tr4 = RTOSCF(15780,F1753_15780, (Current));
	tr5 = RTOSCF(15781,F1753_15781, (Current));
	tr3 = F1148_8367(RTCW(tr3), tr4, tr5);
	tr1 = F1148_8367(RTCW(tr1), tr2, tr3);
	loc1 = F1753_15776(Current, tr1);
	Result = (EIF_REFERENCE) loc1;
	RTOSE (15777);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1753_15777 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15777,F1753_15777_body,(Current));
}

/* {UT_URL_ENCODING}.rfc_lowalpha_characters */

EIF_REFERENCE F1753_15778 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15778,RTMS_EX_H("abcdefghijklmnopqrstuvwxyz",26,1741663354));
}

/* {UT_URL_ENCODING}.rfc_upalpha_characters */

EIF_REFERENCE F1753_15779 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15779,RTMS_EX_H("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,680947802));
}

/* {UT_URL_ENCODING}.rfc_digit_characters */

EIF_REFERENCE F1753_15780 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15780,RTMS_EX_H("0123456789",10,593348409));
}

/* {UT_URL_ENCODING}.rfc_mark_characters */

EIF_REFERENCE F1753_15781 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15781,RTMS_EX_H("-_.!~*\'()",9,831953961));
}

/* {UT_URL_ENCODING}.rfc_reserved_characters */

EIF_REFERENCE F1753_15782 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15782,RTMS_EX_H(";/\?:@&=+$,",10,585254444));
}

/* {UT_URL_ENCODING}.rfc_extra_reserved_characters */

EIF_REFERENCE F1753_15783 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15783,RTMS_EX_H("[]",2,23389));
}

/* {UT_URL_ENCODING}.has_excluded_characters */
EIF_BOOLEAN F1753_15784 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(arg1))-852])(arg1, loc1));
		switch (loc3) {
			case (EIF_CHARACTER_8) '\000':
			case (EIF_CHARACTER_8) '\001':
			case (EIF_CHARACTER_8) '\002':
			case (EIF_CHARACTER_8) '\003':
			case (EIF_CHARACTER_8) '\004':
			case (EIF_CHARACTER_8) '\005':
			case (EIF_CHARACTER_8) '\006':
			case (EIF_CHARACTER_8) '\007':
			case (EIF_CHARACTER_8) '\010':
			case (EIF_CHARACTER_8) '\011':
			case (EIF_CHARACTER_8) '\012':
			case (EIF_CHARACTER_8) '\013':
			case (EIF_CHARACTER_8) '\014':
			case (EIF_CHARACTER_8) '\015':
			case (EIF_CHARACTER_8) '\016':
			case (EIF_CHARACTER_8) '\017':
			case (EIF_CHARACTER_8) '\020':
			case (EIF_CHARACTER_8) '\021':
			case (EIF_CHARACTER_8) '\022':
			case (EIF_CHARACTER_8) '\023':
			case (EIF_CHARACTER_8) '\024':
			case (EIF_CHARACTER_8) '\025':
			case (EIF_CHARACTER_8) '\026':
			case (EIF_CHARACTER_8) '\027':
			case (EIF_CHARACTER_8) '\030':
			case (EIF_CHARACTER_8) '\031':
			case (EIF_CHARACTER_8) '\032':
			case (EIF_CHARACTER_8) '\033':
			case (EIF_CHARACTER_8) '\034':
			case (EIF_CHARACTER_8) '\035':
			case (EIF_CHARACTER_8) '\036':
			case (EIF_CHARACTER_8) '\037':
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				break;
			case (EIF_CHARACTER_8) ' ':
			case (EIF_CHARACTER_8) '\200':
			case (EIF_CHARACTER_8) '\201':
			case (EIF_CHARACTER_8) '\202':
			case (EIF_CHARACTER_8) '\203':
			case (EIF_CHARACTER_8) '\204':
			case (EIF_CHARACTER_8) '\205':
			case (EIF_CHARACTER_8) '\206':
			case (EIF_CHARACTER_8) '\207':
			case (EIF_CHARACTER_8) '\210':
			case (EIF_CHARACTER_8) '\211':
			case (EIF_CHARACTER_8) '\212':
			case (EIF_CHARACTER_8) '\213':
			case (EIF_CHARACTER_8) '\214':
			case (EIF_CHARACTER_8) '\215':
			case (EIF_CHARACTER_8) '\216':
			case (EIF_CHARACTER_8) '\217':
			case (EIF_CHARACTER_8) '\220':
			case (EIF_CHARACTER_8) '\221':
			case (EIF_CHARACTER_8) '\222':
			case (EIF_CHARACTER_8) '\223':
			case (EIF_CHARACTER_8) '\224':
			case (EIF_CHARACTER_8) '\225':
			case (EIF_CHARACTER_8) '\226':
			case (EIF_CHARACTER_8) '\227':
			case (EIF_CHARACTER_8) '\230':
			case (EIF_CHARACTER_8) '\231':
			case (EIF_CHARACTER_8) '\232':
			case (EIF_CHARACTER_8) '\233':
			case (EIF_CHARACTER_8) '\234':
			case (EIF_CHARACTER_8) '\235':
			case (EIF_CHARACTER_8) '\236':
			case (EIF_CHARACTER_8) '\237':
			case (EIF_CHARACTER_8) '\240':
			case (EIF_CHARACTER_8) '\241':
			case (EIF_CHARACTER_8) '\242':
			case (EIF_CHARACTER_8) '\243':
			case (EIF_CHARACTER_8) '\244':
			case (EIF_CHARACTER_8) '\245':
			case (EIF_CHARACTER_8) '\246':
			case (EIF_CHARACTER_8) '\247':
			case (EIF_CHARACTER_8) '\250':
			case (EIF_CHARACTER_8) '\251':
			case (EIF_CHARACTER_8) '\252':
			case (EIF_CHARACTER_8) '\253':
			case (EIF_CHARACTER_8) '\254':
			case (EIF_CHARACTER_8) '\255':
			case (EIF_CHARACTER_8) '\256':
			case (EIF_CHARACTER_8) '\257':
			case (EIF_CHARACTER_8) '\260':
			case (EIF_CHARACTER_8) '\261':
			case (EIF_CHARACTER_8) '\262':
			case (EIF_CHARACTER_8) '\263':
			case (EIF_CHARACTER_8) '\264':
			case (EIF_CHARACTER_8) '\265':
			case (EIF_CHARACTER_8) '\266':
			case (EIF_CHARACTER_8) '\267':
			case (EIF_CHARACTER_8) '\270':
			case (EIF_CHARACTER_8) '\271':
			case (EIF_CHARACTER_8) '\272':
			case (EIF_CHARACTER_8) '\273':
			case (EIF_CHARACTER_8) '\274':
			case (EIF_CHARACTER_8) '\275':
			case (EIF_CHARACTER_8) '\276':
			case (EIF_CHARACTER_8) '\277':
			case (EIF_CHARACTER_8) '\300':
			case (EIF_CHARACTER_8) '\301':
			case (EIF_CHARACTER_8) '\302':
			case (EIF_CHARACTER_8) '\303':
			case (EIF_CHARACTER_8) '\304':
			case (EIF_CHARACTER_8) '\305':
			case (EIF_CHARACTER_8) '\306':
			case (EIF_CHARACTER_8) '\307':
			case (EIF_CHARACTER_8) '\310':
			case (EIF_CHARACTER_8) '\311':
			case (EIF_CHARACTER_8) '\312':
			case (EIF_CHARACTER_8) '\313':
			case (EIF_CHARACTER_8) '\314':
			case (EIF_CHARACTER_8) '\315':
			case (EIF_CHARACTER_8) '\316':
			case (EIF_CHARACTER_8) '\317':
			case (EIF_CHARACTER_8) '\320':
			case (EIF_CHARACTER_8) '\321':
			case (EIF_CHARACTER_8) '\322':
			case (EIF_CHARACTER_8) '\323':
			case (EIF_CHARACTER_8) '\324':
			case (EIF_CHARACTER_8) '\325':
			case (EIF_CHARACTER_8) '\326':
			case (EIF_CHARACTER_8) '\327':
			case (EIF_CHARACTER_8) '\330':
			case (EIF_CHARACTER_8) '\331':
			case (EIF_CHARACTER_8) '\332':
			case (EIF_CHARACTER_8) '\333':
			case (EIF_CHARACTER_8) '\334':
			case (EIF_CHARACTER_8) '\335':
			case (EIF_CHARACTER_8) '\336':
			case (EIF_CHARACTER_8) '\337':
			case (EIF_CHARACTER_8) '\340':
			case (EIF_CHARACTER_8) '\341':
			case (EIF_CHARACTER_8) '\342':
			case (EIF_CHARACTER_8) '\343':
			case (EIF_CHARACTER_8) '\344':
			case (EIF_CHARACTER_8) '\345':
			case (EIF_CHARACTER_8) '\346':
			case (EIF_CHARACTER_8) '\347':
			case (EIF_CHARACTER_8) '\350':
			case (EIF_CHARACTER_8) '\351':
			case (EIF_CHARACTER_8) '\352':
			case (EIF_CHARACTER_8) '\353':
			case (EIF_CHARACTER_8) '\354':
			case (EIF_CHARACTER_8) '\355':
			case (EIF_CHARACTER_8) '\356':
			case (EIF_CHARACTER_8) '\357':
			case (EIF_CHARACTER_8) '\360':
			case (EIF_CHARACTER_8) '\361':
			case (EIF_CHARACTER_8) '\362':
			case (EIF_CHARACTER_8) '\363':
			case (EIF_CHARACTER_8) '\364':
			case (EIF_CHARACTER_8) '\365':
			case (EIF_CHARACTER_8) '\366':
			case (EIF_CHARACTER_8) '\367':
			case (EIF_CHARACTER_8) '\370':
			case (EIF_CHARACTER_8) '\371':
			case (EIF_CHARACTER_8) '\372':
			case (EIF_CHARACTER_8) '\373':
			case (EIF_CHARACTER_8) '\374':
			case (EIF_CHARACTER_8) '\375':
			case (EIF_CHARACTER_8) '\376':
			case (EIF_CHARACTER_8) '\377':
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				break;
			case (EIF_CHARACTER_8) '\"':
			case (EIF_CHARACTER_8) '<':
			case (EIF_CHARACTER_8) '>':
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				break;
			case (EIF_CHARACTER_8) '\\':
			case (EIF_CHARACTER_8) '^':
			case (EIF_CHARACTER_8) '`':
			case (EIF_CHARACTER_8) '{':
			case (EIF_CHARACTER_8) '|':
			case (EIF_CHARACTER_8) '}':
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				break;
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {UT_URL_ENCODING}.is_valid_scheme */
EIF_BOOLEAN F1753_15786 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(arg1))-852])(arg1, loc1));
			switch (loc3) {
				case (EIF_CHARACTER_8) 'A':
				case (EIF_CHARACTER_8) 'B':
				case (EIF_CHARACTER_8) 'C':
				case (EIF_CHARACTER_8) 'D':
				case (EIF_CHARACTER_8) 'E':
				case (EIF_CHARACTER_8) 'F':
				case (EIF_CHARACTER_8) 'G':
				case (EIF_CHARACTER_8) 'H':
				case (EIF_CHARACTER_8) 'I':
				case (EIF_CHARACTER_8) 'J':
				case (EIF_CHARACTER_8) 'K':
				case (EIF_CHARACTER_8) 'L':
				case (EIF_CHARACTER_8) 'M':
				case (EIF_CHARACTER_8) 'N':
				case (EIF_CHARACTER_8) 'O':
				case (EIF_CHARACTER_8) 'P':
				case (EIF_CHARACTER_8) 'Q':
				case (EIF_CHARACTER_8) 'R':
				case (EIF_CHARACTER_8) 'S':
				case (EIF_CHARACTER_8) 'T':
				case (EIF_CHARACTER_8) 'U':
				case (EIF_CHARACTER_8) 'V':
				case (EIF_CHARACTER_8) 'W':
				case (EIF_CHARACTER_8) 'X':
				case (EIF_CHARACTER_8) 'Y':
				case (EIF_CHARACTER_8) 'Z':
				case (EIF_CHARACTER_8) 'a':
				case (EIF_CHARACTER_8) 'b':
				case (EIF_CHARACTER_8) 'c':
				case (EIF_CHARACTER_8) 'd':
				case (EIF_CHARACTER_8) 'e':
				case (EIF_CHARACTER_8) 'f':
				case (EIF_CHARACTER_8) 'g':
				case (EIF_CHARACTER_8) 'h':
				case (EIF_CHARACTER_8) 'i':
				case (EIF_CHARACTER_8) 'j':
				case (EIF_CHARACTER_8) 'k':
				case (EIF_CHARACTER_8) 'l':
				case (EIF_CHARACTER_8) 'm':
				case (EIF_CHARACTER_8) 'n':
				case (EIF_CHARACTER_8) 'o':
				case (EIF_CHARACTER_8) 'p':
				case (EIF_CHARACTER_8) 'q':
				case (EIF_CHARACTER_8) 'r':
				case (EIF_CHARACTER_8) 's':
				case (EIF_CHARACTER_8) 't':
				case (EIF_CHARACTER_8) 'u':
				case (EIF_CHARACTER_8) 'v':
				case (EIF_CHARACTER_8) 'w':
				case (EIF_CHARACTER_8) 'x':
				case (EIF_CHARACTER_8) 'y':
				case (EIF_CHARACTER_8) 'z':
					break;
				case (EIF_CHARACTER_8) '+':
				case (EIF_CHARACTER_8) '-':
				case (EIF_CHARACTER_8) '.':
				case (EIF_CHARACTER_8) '0':
				case (EIF_CHARACTER_8) '1':
				case (EIF_CHARACTER_8) '2':
				case (EIF_CHARACTER_8) '3':
				case (EIF_CHARACTER_8) '4':
				case (EIF_CHARACTER_8) '5':
				case (EIF_CHARACTER_8) '6':
				case (EIF_CHARACTER_8) '7':
				case (EIF_CHARACTER_8) '8':
				case (EIF_CHARACTER_8) '9':
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 1L))) {
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					}
					break;
				default:
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					break;
			}
			loc1++;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit826 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
