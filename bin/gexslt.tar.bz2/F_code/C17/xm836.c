/*
 * Code for class XM_DTD_ELEMENT_CONTENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm836.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_DTD_ELEMENT_CONTENT}.make_name */
void F1763_16036 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	F1763_16038(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.make_list */
void F1763_16037 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1484,0xFF01,1762,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1484, _OBJSIZ_4_0_0_1_0_0_0_0_);
	}
	F1482_11928(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F1763_16038(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.set_default */
void F1763_16038 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1763_16063(Current);
	F1763_16054(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.make_empty */
void F1763_16039 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1763_16037(Current);
	F1763_16067(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.make_any */
void F1763_16040 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1763_16037(Current);
	F1763_16066(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.make_choice */
void F1763_16041 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1763_16037(Current);
	F1763_16062(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.make_sequence */
void F1763_16042 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1763_16037(Current);
	F1763_16063(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.make_mixed */
void F1763_16043 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1763_16037(Current);
	F1763_16069(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.out */
EIF_REFERENCE F1763_16048 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTGC;
	if (F1763_16049(Current)) {
		RTCT0("attached name as l_name", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = (EIF_REFERENCE) loc2;
		if ((EIF_BOOLEAN) !F1763_16050(Current)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5181[Dtype(RTCW(Result))-1112])(Result, *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_1_));
		}
	} else {
		if (F1763_16064(Current)) {
			Result = RTMS_EX_H("ANY",3,4279897);
		} else {
			if (F1763_16065(Current)) {
				Result = RTMS_EX_H("EMPTY",5,1297640025);
			} else {
				RTCT0("attached items as l_items", EX_CHECK);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H("(",1,40);
				Result = F1148_8376(RTCW(tr1), tr2);
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(loc3)-1481])(loc3);
				F1320_11363(RTCW(loc1));
				for (;;) {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3187[Dtype(RTCW(loc1))-556])(loc1);
					if (tb1) break;
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3186[Dtype(RTCW(loc1))-556])(loc1);
					tr2 = F1763_16048(RTCW(tr2));
					tr1 = F1148_8377(RTCW(tr1), Result, tr2);
					Result = (EIF_REFERENCE) tr1;
					F1320_11364(RTCW(loc1));
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3187[Dtype(RTCW(loc1))-556])(loc1);
					if ((EIF_BOOLEAN) !tb2) {
						if (F1763_16068(Current)) {
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5181[Dtype(RTCW(Result))-1112])(Result, (EIF_CHARACTER_8) '|');
						} else {
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5181[Dtype(RTCW(Result))-1112])(Result, *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_));
						}
					}
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5181[Dtype(RTCW(Result))-1112])(Result, (EIF_CHARACTER_8) ')');
				if ((EIF_BOOLEAN) !F1763_16050(Current)) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5181[Dtype(RTCW(Result))-1112])(Result, *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_1_));
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {XM_DTD_ELEMENT_CONTENT}.is_name */
EIF_BOOLEAN F1763_16049 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL);
}

/* {XM_DTD_ELEMENT_CONTENT}.is_one */
EIF_BOOLEAN F1763_16050 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_1_) == (EIF_CHARACTER_8) ' ');
}

/* {XM_DTD_ELEMENT_CONTENT}.set_one */
void F1763_16054 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_1_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) ' ';
}

/* {XM_DTD_ELEMENT_CONTENT}.set_one_or_more */
void F1763_16055 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_1_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '+';
}

/* {XM_DTD_ELEMENT_CONTENT}.set_zero_or_one */
void F1763_16056 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_1_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\?';
}

/* {XM_DTD_ELEMENT_CONTENT}.set_zero_or_more */
void F1763_16057 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_1_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '*';
}

/* {XM_DTD_ELEMENT_CONTENT}.is_choice */
EIF_BOOLEAN F1763_16060 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) == (EIF_CHARACTER_8) '|');
}

/* {XM_DTD_ELEMENT_CONTENT}.set_choice */
void F1763_16062 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '|';
}

/* {XM_DTD_ELEMENT_CONTENT}.set_sequence */
void F1763_16063 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) ',';
}

/* {XM_DTD_ELEMENT_CONTENT}.is_content_any */
EIF_BOOLEAN F1763_16064 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) == (EIF_CHARACTER_8) '\?');
}

/* {XM_DTD_ELEMENT_CONTENT}.is_content_empty */
EIF_BOOLEAN F1763_16065 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) == (EIF_CHARACTER_8) '0');
}

/* {XM_DTD_ELEMENT_CONTENT}.set_content_any */
void F1763_16066 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\?';
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.set_content_empty */
void F1763_16067 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '0';
}

/* {XM_DTD_ELEMENT_CONTENT}.is_content_mixed */
EIF_BOOLEAN F1763_16068 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if (F1763_16060(Current)) {
		Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_);
	}
	RTLE;
	return Result;
}

/* {XM_DTD_ELEMENT_CONTENT}.set_content_mixed */
void F1763_16069 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1763_16062(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

void EIF_Minit836 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
