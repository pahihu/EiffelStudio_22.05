/*
 * Code for class XM_XSLT_START_TAG_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm810.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_START_TAG_BUFFER}.make */
void F1737_15359 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1230, 1).id);
	F1231_10132(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1506,1035,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1507_12163(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1506,1035,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1507_12163(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O11856[Dtype(tr1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O11855[Dtype(tr1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_START_TAG_BUFFER}.attribute_value */
EIF_REFERENCE F1737_15360 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1231_10133(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {XM_XSLT_START_TAG_BUFFER}.uri_for_defaulted_prefix */
EIF_REFERENCE F1737_15361 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	tb2 = F772_3900(RTCW(arg1));
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !arg2;
	}
	if (tb1) {
		Result = RTMS_EX_H("",0,0);
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("xml",3,7892332);
		tb1 = F1148_8369(RTCW(tr1), arg1, tr2);
		if (tb1) {
			Result = RTOSCF(9821,F1230_9821, (Current));
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			tr1 = RTOSCF(4950,F991_4950, (Current));
			tb1 = F1242_10426(RTCW(tr1), arg1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = RTOSCF(4950,F991_4950, (Current));
				F1242_10443(RTCW(tr1), arg1);
				loc2 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(4950,F991_4950, (Current)))+ _LNGOFF_4_0_0_2_);
			} else {
				tr1 = RTOSCF(4950,F991_4950, (Current));
				loc2 = F1242_10409(RTCW(tr1), arg1);
			}
			loc1 = F1737_15383(Current, loc2);
			if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
				RTLE;
				return (EIF_REFERENCE) NULL;
			} else {
				tr1 = RTOSCF(4950,F991_4950, (Current));
				Result = F1242_10454(RTCW(tr1), loc1);
			}
		}
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_START_TAG_BUFFER}.fingerprint */
EIF_INTEGER_32 F1737_15362 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,Current);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(959, 0x01).id, 959, _OBJSIZ_2_2_0_0_0_0_0_0_);
	F960_4582(RTCW(loc1), arg1);
	RTCT0("attached l_parser.optional_prefix as l_optional_prefix", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = F1737_15361(Current, loc3, arg2);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -2L);
	} else {
		RTCT0("attached l_parser.local_name as l_local_name", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = RTOSCF(4950,F991_4950, (Current));
		Result = F1242_10414(RTCW(tr1), loc2, loc4);
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_START_TAG_BUFFER}.close */
void F1737_15363 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O11858[Dtype(tr1)-1728]);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11876[Dtype(RTCW(tr1))-1732])(tr1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11877[Dtype(RTCW(tr1))-1732])(tr1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {XM_XSLT_START_TAG_BUFFER}.start_document */
void F1737_15364 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_0_) == ((EIF_INTEGER_32) 0L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_0_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11866[Dtype(RTCW(tr1))-1732])(tr1);
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {XM_XSLT_START_TAG_BUFFER}.end_document */
void F1737_15365 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_0_) == ((EIF_INTEGER_32) 1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_0_))--;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11876[Dtype(RTCW(tr1))-1732])(tr1);
	}
	RTLE;
}

/* {XM_XSLT_START_TAG_BUFFER}.start_element */
void F1737_15366 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1734_15315(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_1_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_2_) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_3_) = (EIF_INTEGER_32) arg3;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1231_10145(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1507_12184(RTCW(tr1), ((EIF_INTEGER_32) 0L), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_0_));
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_0_))++;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	if ((EIF_BOOLEAN) !F1412_11669(Current, arg3)) {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tb1 = F1242_10429(RTCW(tr1), arg1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = RTOSCF(4950,F991_4950, (Current));
			F1242_10441(RTCW(tr1), arg1);
		}
		tr1 = RTOSCF(4950,F991_4950, (Current));
		ti4_1 = F1242_10447(RTCW(tr1), arg1);
		F1737_15368(Current, ti4_1, ((EIF_INTEGER_32) 0L));
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {XM_XSLT_START_TAG_BUFFER}.end_element */
void F1737_15367 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1734_15315(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11872[Dtype(RTCW(tr1))-1732])(tr1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_0_))--;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = F1507_12165(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_0_));
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_5_)) -= ti4_1;
	RTLE;
}

/* {XM_XSLT_START_TAG_BUFFER}.notify_namespace */
void F1737_15368 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1734_15315(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc3 = F1507_12165(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_0_) - ((EIF_INTEGER_32) 1L)));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 || (EIF_BOOLEAN) (loc2 >= loc3))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = F1507_12165(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_5_) - loc2));
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == arg1);
		loc2++;
	}
	if ((EIF_BOOLEAN) !loc1) {
		F1737_15382(Current, arg1);
	}
	RTLE;
}

/* {XM_XSLT_START_TAG_BUFFER}.notify_attribute */
void F1737_15369 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTGC;
	F1734_15315(Current);
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F1412_11669(Current, arg4)) {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		ti4_1 = F1242_10411(RTCW(tr1), arg1);
		tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		F1737_15385(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_4_));
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_4_))++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1231_10144(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTLE;
}

/* {XM_XSLT_START_TAG_BUFFER}.start_content */
void F1737_15370 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	F1734_15315(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_1_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_2_);
	tr2 = RTOSCF(6771,F1118_6771, (Current));
	ti4_3 = F1174_8739(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_3_), ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R11868[Dtype(RTCW(tr1))-1732])(tr1, ti4_1, ti4_2, ti4_3);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_5_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = F1507_12165(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_0_) - ((EIF_INTEGER_32) 1L)));
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) + ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_5_))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = F1507_12165(RTCW(tr2), loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11869[Dtype(RTCW(tr1))-1732])(tr1, ti4_1, ((EIF_INTEGER_32) 0L));
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = F1231_10141(RTCW(tr1));
	F1321_11363(RTCW(loc2));
	for (;;) {
		tb1 = F1385_11438(RTCW(loc2));
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		ti4_1 = F1382_11418(RTCW(loc2));
		loc3 = F1231_10135(RTCW(tr1), ti4_1);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			ti4_1 = F1308_11343(RTCW(loc2));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			ti4_2 = F1382_11418(RTCW(loc2));
			ti4_2 = F1231_10137(RTCW(tr2), ti4_2);
			tr2 = RTOSCF(6771,F1118_6771, (Current));
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			ti4_3 = F1382_11418(RTCW(loc2));
			ti4_3 = F1231_10138(RTCW(tr3), ti4_3);
			ti4_3 = F1174_8739(RTCW(tr2), ti4_3, ((EIF_INTEGER_32) 1L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_INTEGER_32)) R11870[Dtype(RTCW(tr1))-1732])(tr1, ti4_1, ti4_2, loc3, ti4_3);
		}
		F1321_11364(RTCW(loc2));
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11871[Dtype(RTCW(tr1))-1732])(tr1);
	RTLE;
}

/* {XM_XSLT_START_TAG_BUFFER}.add_to_stack */
void F1737_15382 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_5_))++;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1507_12184(RTCW(tr1), arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_5_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = F1507_12165(RTCW(tr2), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_0_) - ((EIF_INTEGER_32) 1L)));
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_0_);
	F1507_12184(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (ti4_2 - ((EIF_INTEGER_32) 1L)));
	RTLE;
}

/* {XM_XSLT_START_TAG_BUFFER}.uri_code_for_prefix_code */
EIF_INTEGER_32 F1737_15383 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_5_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L)))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = F1507_12165(RTCW(tr1), loc1);
		loc2 = F1227_9773(Current, ti4_1);
		if ((EIF_BOOLEAN)(loc2 == arg1)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			ti4_1 = F1507_12165(RTCW(tr1), loc1);
			Result = F1227_9774(Current, ti4_1);
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		loc1--;
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc3 && (EIF_BOOLEAN)(arg1 != ((EIF_INTEGER_32) 0L)))) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_START_TAG_BUFFER}.check_proposed_prefix */
void F1737_15385 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc4);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_6_) = (EIF_INTEGER_32) arg1;
	tr1 = RTOSCF(4950,F991_4950, (Current));
	tb1 = F1242_10429(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		F1242_10441(RTCW(tr1), arg1);
	}
	tr1 = RTOSCF(4950,F991_4950, (Current));
	loc1 = F1242_10447(RTCW(tr1), arg1);
	loc2 = F1227_9773(Current, loc1);
	loc3 = F1737_15383(Current, loc2);
	if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
		F1737_15368(Current, loc1, ((EIF_INTEGER_32) 0L));
	} else {
		if ((EIF_BOOLEAN)(F1227_9774(Current, loc1) != loc3)) {
			loc4 = F1737_15386(Current, loc1, arg2);
			tr1 = RTOSCF(4950,F991_4950, (Current));
			tr2 = RTOSCF(4950,F991_4950, (Current));
			tr2 = F1242_10448(RTCW(tr2), arg1);
			tr3 = RTOSCF(4950,F991_4950, (Current));
			tr3 = F1242_10450(RTCW(tr3), arg1);
			F1242_10444(RTCW(tr1), loc4, tr2, tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(4950,F991_4950, (Current)))+ _LNGOFF_4_0_0_0_);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_4_0_6_) = (EIF_INTEGER_32) ti4_1;
		}
	}
	RTLE;
}

/* {XM_XSLT_START_TAG_BUFFER}.substituted_prefix */
EIF_REFERENCE F1737_15386 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(4950,F991_4950, (Current));
	loc1 = F1242_10455(RTCW(tr1), arg1);
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("_",1,95);
	Result = F1148_8367(RTCW(tr1), loc1, tr2);
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = eif_out__i4_s1(arg2);
	tr1 = F1148_8377(RTCW(tr1), Result, tr2);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

void EIF_Minit810 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
