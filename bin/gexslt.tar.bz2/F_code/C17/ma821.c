/*
 * Code for class MA_DECIMAL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ma821.h"
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MA_DECIMAL}.make */
void F1748_15532 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1118, 0x01).id, 1118, _OBJSIZ_1_0_0_2_0_0_0_0_);
	F1119_6772(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	F1748_15608(Current);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1119_6783(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {MA_DECIMAL}.make_copy */
void F1748_15533 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tb1 = F1748_15564(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		ti4_1 = F1748_15580(RTCW(arg1));
		F1748_15532(Current, ti4_1);
		F1748_15588(Current, arg1);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_1_);
		F1748_15540(Current, ti4_1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) tb1;
	}
	RTLE;
}

/* {MA_DECIMAL}.make_zero */
void F1748_15534 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(15654,F1748_15654, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {MA_DECIMAL}.make_one */
void F1748_15535 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1748_15532(Current, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current);
	F1119_6783(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {MA_DECIMAL}.make_from_integer */
void F1748_15536 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) arg1;
	if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 0L))) {
		F1748_15608(Current);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) -loc1;
	} else {
		F1748_15607(Current);
	}
	loc2 = (EIF_INTEGER_32) loc1;
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) break;
		tr1 = RTOSCF(6771,F1118_6771, (Current));
		ti4_1 = F1174_8735(RTCW(tr1), loc2, ((EIF_INTEGER_32) 10L));
		loc2 = (EIF_INTEGER_32) ti4_1;
		if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L))) {
			loc4++;
		}
	}
	tr1 = RTLNS(eif_new_type(1118, 0x01).id, 1118, _OBJSIZ_1_0_0_2_0_0_0_0_);
	F1119_6772(RTCW(tr1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		F1119_6783(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	} else {
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc2 = (EIF_INTEGER_32) loc1;
		for (;;) {
			if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) break;
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = RTOSCF(6771,F1118_6771, (Current));
			ti4_1 = F1174_8736(RTCW(tr2), loc2, ((EIF_INTEGER_32) 10L));
			F1119_6783(RTCW(tr1), (EIF_INTEGER_32) -ti4_1, loc3);
			tr1 = RTOSCF(6771,F1118_6771, (Current));
			ti4_1 = F1174_8735(RTCW(tr1), loc2, ((EIF_INTEGER_32) 10L));
			loc2 = (EIF_INTEGER_32) ti4_1;
			if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L))) {
				loc3++;
			}
		}
	}
	RTLE;
}

/* {MA_DECIMAL}.make_from_string_ctx */
void F1748_15537 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	loc1 = RTOSCF(15651,F1748_15651, (Current));
	F1171_8653(RTCW(loc1), arg1);
	F1748_15538(Current, loc1, arg2);
	RTLE;
}

/* {MA_DECIMAL}.make_from_parser */
void F1748_15538 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc1))) {
		tb2 = F1171_8641(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_0_);
		if (tb1) {
			F1748_15541(Current);
		} else {
			F1748_15542(Current);
		}
	} else {
		tb1 = F1171_8643(RTCW(arg1));
		if (tb1) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(15651,F1748_15651, (Current)))+ _LNGOFF_2_2_0_0_);
			F1748_15543(Current, ti4_1);
		} else {
			tb1 = F1171_8645(RTCW(arg1));
			if (tb1) {
				F1748_15542(Current);
			} else {
				tb1 = F1171_8644(RTCW(arg1));
				if (tb1) {
					F1748_15541(Current);
				} else {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_2_0_0_);
					if ((EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 0L))) {
						F1748_15607(Current);
					} else {
						F1748_15608(Current);
					}
					tb1 = F1171_8647(RTCW(arg1));
					if (tb1) {
						tr8_1 = *(EIF_REAL_64 *)(RTCW(arg1)+ _R64OFF_2_2_0_10_0_0_0_0_);
						ti4_1 = RTOSCF(2037,F228_2037, (RTCV(RTOSCF(1557,F173_1557, (Current)))));
						tr8_2 = (EIF_REAL_64) (ti4_1);
						if ((EIF_BOOLEAN) eif_is_greater_real_64 (tr8_1, tr8_2)) {
							ti4_1 = ((EIF_INTEGER_32) 999999999L);
							ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
							ti4_3 = F1171_8638(RTCW(arg1));
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ti4_3) + ((EIF_INTEGER_32) 2L));
						} else {
							tr1 = RTOSCF(2592,F334_2592, (Current));
							tr8_1 = *(EIF_REAL_64 *)(RTCW(arg1)+ _R64OFF_2_2_0_10_0_0_0_0_);
							ti4_1 = F174_1563(RTCW(tr1), tr8_1);
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ti4_1;
						}
						ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(15651,F1748_15651, (Current)))+ _LNGOFF_2_2_0_1_);
						if ((EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 0L))) {
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) -*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
						}
					} else {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					}
					tb1 = F1171_8646(RTCW(arg1));
					if (tb1) {
						ti4_1 = F1171_8633(RTCW(arg1));
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_)) -= ti4_1;
					}
					tr1 = RTLNS(eif_new_type(1118, 0x01).id, 1118, _OBJSIZ_1_0_0_2_0_0_0_0_);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
					ti4_2 = F1171_8632(RTCW(arg1));
					ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)),ti4_2);
					F1119_6772(RTCW(tr1), ti4_1);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
					tr1 = *(EIF_REFERENCE *)(Current);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_2_0_4_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_2_0_5_);
					F1119_6781(RTCW(tr1), loc1, ti4_1, ti4_2);
					F1748_15638(Current, arg2);
				}
			}
		}
	}
	RTLE;
}

/* {MA_DECIMAL}.make_from_string */
void F1748_15539 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F172_1553(Current);
	F1748_15537(Current, arg1, tr1);
	RTLE;
}

/* {MA_DECIMAL}.make_special */
void F1748_15540 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(15654,F1748_15654, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {MA_DECIMAL}.make_nan */
void F1748_15541 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1748_15540(Current, ((EIF_INTEGER_32) 3L));
}

/* {MA_DECIMAL}.make_snan */
void F1748_15542 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1748_15540(Current, ((EIF_INTEGER_32) 2L));
}

/* {MA_DECIMAL}.make_infinity */
void F1748_15543 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1748_15540(Current, ((EIF_INTEGER_32) 1L));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {MA_DECIMAL}.sign */
EIF_INTEGER_32 F1748_15544 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}/* NOTREACHED */
	
}

/* {MA_DECIMAL}.hash_code */
EIF_INTEGER_32 F1748_15546 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc5 = F1748_15568(Current);
	Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_);
	tr1 = RTOSCF(6771,F1118_6771, (Current));
	ti4_1 = F1174_8742(RTCW(tr1), Result, ((EIF_INTEGER_32) 10L));
	Result += ti4_1;
	tr1 = RTOSCF(6771,F1118_6771, (Current));
	tr2 = RTOSCF(6771,F1118_6771, (Current));
	ti4_1 = F1174_8743(RTCW(tr2), Result, ((EIF_INTEGER_32) 6L));
	ti4_1 = F1174_8740(RTCW(tr1), Result, ti4_1);
	Result = (EIF_INTEGER_32) ti4_1;
	if ((EIF_BOOLEAN) !loc5) {
		Result += F1748_15544(Current);
	}
	tr1 = RTOSCF(6771,F1118_6771, (Current));
	ti4_1 = F1174_8742(RTCW(tr1), Result, ((EIF_INTEGER_32) 10L));
	Result += ti4_1;
	tr1 = RTOSCF(6771,F1118_6771, (Current));
	tr2 = RTOSCF(6771,F1118_6771, (Current));
	ti4_1 = F1174_8743(RTCW(tr2), Result, ((EIF_INTEGER_32) 6L));
	ti4_1 = F1174_8740(RTCW(tr1), Result, ti4_1);
	Result = (EIF_INTEGER_32) ti4_1;
	if ((EIF_BOOLEAN) !F1748_15564(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc4 = F1119_6775(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current);
		loc3 = F1119_6778(RTCW(tr1));
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc3 > loc4)) {
				tr1 = *(EIF_REFERENCE *)(Current);
				ti4_1 = F1119_6774(RTCW(tr1), loc3);
				tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
			}
			if (tb1) break;
			loc3++;
			loc2++;
		}
		if ((EIF_BOOLEAN) !loc5) {
			Result += loc2;
		}
		tr1 = RTOSCF(6771,F1118_6771, (Current));
		ti4_1 = F1174_8742(RTCW(tr1), Result, ((EIF_INTEGER_32) 10L));
		Result += ti4_1;
		tr1 = RTOSCF(6771,F1118_6771, (Current));
		tr2 = RTOSCF(6771,F1118_6771, (Current));
		ti4_1 = F1174_8743(RTCW(tr2), Result, ((EIF_INTEGER_32) 6L));
		ti4_1 = F1174_8740(RTCW(tr1), Result, ti4_1);
		Result = (EIF_INTEGER_32) ti4_1;
		loc1 = (EIF_INTEGER_32) loc3;
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc4)) break;
			tr1 = *(EIF_REFERENCE *)(Current);
			ti4_1 = F1119_6774(RTCW(tr1), loc1);
			Result += ti4_1;
			tr1 = RTOSCF(6771,F1118_6771, (Current));
			ti4_1 = F1174_8742(RTCW(tr1), Result, ((EIF_INTEGER_32) 10L));
			Result += ti4_1;
			tr1 = RTOSCF(6771,F1118_6771, (Current));
			tr2 = RTOSCF(6771,F1118_6771, (Current));
			ti4_1 = F1174_8743(RTCW(tr2), Result, ((EIF_INTEGER_32) 6L));
			ti4_1 = F1174_8740(RTCW(tr1), Result, ti4_1);
			Result = (EIF_INTEGER_32) ti4_1;
			loc1++;
		}
	}
	tr1 = RTOSCF(6771,F1118_6771, (Current));
	ti4_1 = F1174_8742(RTCW(tr1), Result, ((EIF_INTEGER_32) 3L));
	Result += ti4_1;
	tr1 = RTOSCF(6771,F1118_6771, (Current));
	tr2 = RTOSCF(6771,F1118_6771, (Current));
	ti4_1 = F1174_8743(RTCW(tr2), Result, ((EIF_INTEGER_32) 11L));
	ti4_1 = F1174_8740(RTCW(tr1), Result, ti4_1);
	Result = (EIF_INTEGER_32) ti4_1;
	tr1 = RTOSCF(6771,F1118_6771, (Current));
	ti4_1 = F1174_8742(RTCW(tr1), Result, ((EIF_INTEGER_32) 15L));
	Result += ti4_1;
	tr1 = RTOSCF(6771,F1118_6771, (Current));
	ti4_1 = RTOSCF(2037,F228_2037, (RTCV(RTOSCF(1557,F173_1557, (Current)))));
	ti4_1 = F1174_8738(RTCW(tr1), Result, ti4_1);
	Result = (EIF_INTEGER_32) ti4_1;
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.one */
EIF_REFERENCE F1748_15547 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) RTOSCF(15653,F1748_15653, (Current));
}

/* {MA_DECIMAL}.minus_one */
static EIF_REFERENCE F1748_15548_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15548);
#define Result RTOSR(15548)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	tr2 = F1748_15547(Current);
	F1748_15533(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	F1748_15607(RTCW(Result));
	RTOSE (15548);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1748_15548 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15548,F1748_15548_body,(Current));
}

/* {MA_DECIMAL}.zero */
EIF_REFERENCE F1748_15549 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) RTOSCF(15652,F1748_15652, (Current));
}

/* {MA_DECIMAL}.negative_zero */
static EIF_REFERENCE F1748_15550_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (15550);
#define Result RTOSR(15550)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1748_15534(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1748_15607(RTCW(Result));
	RTOSE (15550);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1748_15550 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15550,F1748_15550_body,(Current));
}

/* {MA_DECIMAL}.nan */
static EIF_REFERENCE F1748_15551_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (15551);
#define Result RTOSR(15551)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1748_15541(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15551);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1748_15551 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15551,F1748_15551_body,(Current));
}

/* {MA_DECIMAL}.infinity */
static EIF_REFERENCE F1748_15553_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (15553);
#define Result RTOSR(15553)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1748_15543(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15553);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1748_15553 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15553,F1748_15553_body,(Current));
}

/* {MA_DECIMAL}.negative_infinity */
static EIF_REFERENCE F1748_15554_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (15554);
#define Result RTOSR(15554)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1748_15543(RTCW(tr1), ((EIF_INTEGER_32) -1L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15554);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1748_15554 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15554,F1748_15554_body,(Current));
}

/* {MA_DECIMAL}.adjusted_exponent */
EIF_INTEGER_32 F1748_15555 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
	ti4_1 = F1748_15580(Current);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result + ti4_1) - ((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.is_integer */
EIF_BOOLEAN F1748_15557 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (F1748_15568(Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) < ((EIF_INTEGER_32) 0L))) {
			if ((EIF_BOOLEAN) (F1748_15555(Current) >= ((EIF_INTEGER_32) 0L))) {
				loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) -loc1;
				ti4_1 = F1748_15580(Current);
				loc2 = eif_min_int32 (loc1,ti4_1);
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (loc2 <= ((EIF_INTEGER_32) 0L))) {
						tr1 = *(EIF_REFERENCE *)(Current);
						ti4_1 = F1119_6774(RTCW(tr1), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
						tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
					}
					if (tb1) break;
					loc2--;
				}
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L));
			} else {
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
		} else {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}/* NOTREACHED */
	
}

/* {MA_DECIMAL}.is_double */
EIF_BOOLEAN F1748_15558 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1748_15587(Current);
	tb1 = F1108_6334(RTCW(loc1));
	RTLE;
	return (EIF_BOOLEAN) tb1;
}

/* {MA_DECIMAL}.is_positive */
EIF_BOOLEAN F1748_15562 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_);
}

/* {MA_DECIMAL}.is_nan */
EIF_BOOLEAN F1748_15563 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F1748_15565(Current)) {
		Result = F1748_15566(Current);
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.is_special */
EIF_BOOLEAN F1748_15564 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_) != ((EIF_INTEGER_32) 0L));
}

/* {MA_DECIMAL}.is_signaling_nan */
EIF_BOOLEAN F1748_15565 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_) == ((EIF_INTEGER_32) 2L));
}

/* {MA_DECIMAL}.is_quiet_nan */
EIF_BOOLEAN F1748_15566 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_) == ((EIF_INTEGER_32) 3L));
}

/* {MA_DECIMAL}.is_infinity */
EIF_BOOLEAN F1748_15567 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_) == ((EIF_INTEGER_32) 1L));
}

/* {MA_DECIMAL}.is_zero */
EIF_BOOLEAN F1748_15568 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F1748_15564(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tb2 = F226_1952(RTCW(tr1));
		tb1 = tb2;
	}
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {MA_DECIMAL}.product */
EIF_REFERENCE F1748_15570 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F172_1553(Current);
	Result = F1748_15591(Current, arg1, tr1);
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.binary_plus */
EIF_REFERENCE F1748_15572 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F172_1553(Current);
	Result = F1748_15589(Current, arg1, tr1);
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.opposite */
EIF_REFERENCE F1748_15573 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = F172_1553(Current);
	Result = F1748_15600(Current, tr1);
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.binary_minus */
EIF_REFERENCE F1748_15574 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F172_1553(Current);
	Result = F1748_15590(Current, arg1, tr1);
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.quotient */
EIF_REFERENCE F1748_15575 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F172_1553(Current);
	Result = F1748_15592(Current, arg1, tr1);
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.integer_remainder */
EIF_REFERENCE F1748_15576 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F172_1553(Current);
	Result = F1748_15594(Current, arg1, tr1);
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.integer_quotient */
EIF_REFERENCE F1748_15577 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F172_1553(Current);
	Result = F1748_15593(Current, arg1, tr1);
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.is_less */
EIF_BOOLEAN F1748_15579 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tr1 = F172_1553(Current);
	loc1 = F1748_15605(Current, arg1, tr1);
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_1_0_);
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {MA_DECIMAL}.count */
EIF_INTEGER_32 F1748_15580 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (F1748_15564(Current)) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_1_);
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.is_equal */
EIF_BOOLEAN F1748_15581 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	if (F1748_15563(Current)) {
		tb2 = F1748_15563(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		if (F1748_15566(Current)) {
			tb1 = F1748_15566(RTCW(arg1));
			RTLE;
			return (EIF_BOOLEAN) tb1;
		} else {
			if (F1748_15565(Current)) {
				tb1 = F1748_15565(RTCW(arg1));
				RTLE;
				return (EIF_BOOLEAN) tb1;
			}
		}
	} else {
		tb1 = '\0';
		if (F1748_15567(Current)) {
			tb2 = F1748_15567(RTCW(arg1));
			tb1 = tb2;
		}
		if (tb1) {
			ti4_1 = F1748_15544(Current);
			ti4_2 = F1748_15544(RTCW(arg1));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
		} else {
			tr1 = F172_1553(Current);
			loc1 = F1748_15605(Current, arg1, tr1);
			tb1 = F1748_15568(RTCW(loc1));
			if (tb1) {
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.out */
EIF_REFERENCE F1748_15582 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1111_6438(RTCW(Result), ((EIF_INTEGER_32) 0L));
	tr1 = RTMS_EX_H("[",1,91);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		tr1 = RTMS_EX_H("1",1,49);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
	} else {
		tr1 = RTMS_EX_H("0",1,48);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
	}
	tr1 = RTMS_EX_H(",",1,44);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
	if (F1748_15567(Current)) {
		tr1 = RTMS_EX_H("inf",3,6909542);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
	} else {
		if (F1748_15565(Current)) {
			tr1 = RTMS_EX_H("sNaN",4,1934516558);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
		} else {
			if (F1748_15566(Current)) {
				tr1 = RTMS_EX_H("qNaN",4,1900962126);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current);
				tr1 = F1119_6785(RTCW(tr1));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
				tr1 = RTMS_EX_H(",",1,44);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
				tr1 = eif_out__i4_s1(ti4_1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
			}
		}
	}
	tr1 = RTMS_EX_H("]",1,93);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.to_double */
EIF_REAL_64 F1748_15583 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REAL_64 tr8_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1748_15587(Current);
	tr8_1 = F1108_6383(RTCW(loc1));
	RTLE;
	return (EIF_REAL_64) tr8_1;
}

/* {MA_DECIMAL}.to_integer */
EIF_INTEGER_32 F1748_15584 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1774, 0x01).id, 1774, _OBJSIZ_3_2_0_3_0_0_0_0_);
	F1775_16258(RTCW(loc1));
	RTLE;
	return (EIF_INTEGER_32) F1748_15585(Current, loc1);
}

/* {MA_DECIMAL}.to_integer_ctx */
EIF_INTEGER_32 F1748_15585 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = F1748_15597(Current, arg1);
	loc2 = F1748_15580(RTCW(loc1));
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		ti4_1 = F1119_6774(RTCW(tr1), loc2);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 10L)) + ti4_1);
		loc2--;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) -Result;
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.to_scientific_string */
EIF_REFERENCE F1748_15587 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1748_15650(Current, (EIF_BOOLEAN) 0);
}

/* {MA_DECIMAL}.copy */
void F1748_15588 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			tb1 = (EIF_BOOLEAN)(tr1 == RTOSCF(15654,F1748_15654, (Current)));
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			tr1 = F1119_6787(RTCW(tr1));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
			F1119_6786(RTCW(tr1), tr2);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ti4_1;
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) tb1;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_1_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {MA_DECIMAL}.add */
EIF_REFERENCE F1748_15589 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tb1 = '\01';
	if (!F1748_15564(Current)) {
		tb2 = F1748_15564(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) F1748_15616(Current, arg1, arg2);
	} else {
		loc1 = RTLNSMART(dftype);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
		F1748_15532(RTCW(loc1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		F1748_15588(RTCW(loc1), Current);
		loc2 = RTLNSMART(dftype);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
		F1748_15532(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		F1748_15588(RTCW(loc2), arg1);
		tb1 = '\0';
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
			tb2 = F1748_15562(RTCW(arg1));
			tb1 = tb2;
		}
		if (tb1) {
			F1748_15619(RTCW(loc2), loc1, arg2);
			Result = (EIF_REFERENCE) loc2;
		} else {
			tb1 = '\0';
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
				tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
				tb1 = tb2;
			}
			if (tb1) {
				F1748_15618(RTCW(loc1), loc2, arg2);
				Result = (EIF_REFERENCE) loc1;
				F1748_15607(RTCW(Result));
			} else {
				tb1 = '\0';
				if (F1748_15562(Current)) {
					tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
					tb1 = tb2;
				}
				if (tb1) {
					F1748_15619(RTCW(loc1), loc2, arg2);
					Result = (EIF_REFERENCE) loc1;
				} else {
					F1748_15618(RTCW(loc1), loc2, arg2);
					Result = (EIF_REFERENCE) loc1;
				}
			}
		}
		tb1 = F1748_15568(RTCW(Result));
		if (tb1) {
			tb1 = '\01';
			tb2 = '\0';
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
				tb3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
				tb2 = tb3;
			}
			if (!tb2) {
				tb2 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_1_);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 3L))) {
					ti4_1 = F1748_15544(RTCW(arg1));
					tb2 = (EIF_BOOLEAN)(F1748_15544(Current) != ti4_1);
				}
				tb1 = tb2;
			}
			if (tb1) {
				F1748_15607(RTCW(Result));
			} else {
				F1748_15608(RTCW(Result));
			}
		}
		F1748_15638(RTCW(Result), arg2);
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.subtract */
EIF_REFERENCE F1748_15590 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tb1 = '\01';
	if (!F1748_15564(Current)) {
		tb2 = F1748_15564(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) F1748_15617(Current, arg1, arg2);
	} else {
		loc1 = RTLNSMART(Dftype(Current));
		F1748_15533(RTCW(loc1), arg1);
		tb1 = F1748_15562(RTCW(loc1));
		if (tb1) {
			F1748_15607(RTCW(loc1));
		} else {
			F1748_15608(RTCW(loc1));
		}
		RTLE;
		return (EIF_REFERENCE) F1748_15589(Current, loc1, arg2);
	}/* NOTREACHED */
	
}

/* {MA_DECIMAL}.multiply */
EIF_REFERENCE F1748_15591 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLIU(9);
	
	RTGC;
	tb1 = '\01';
	if (!F1748_15564(Current)) {
		tb2 = F1748_15564(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\01';
		if (!F1748_15563(Current)) {
			tb2 = F1748_15563(RTCW(arg1));
			tb1 = tb2;
		}
		if (tb1) {
			tb1 = '\01';
			if (!F1748_15565(Current)) {
				tb2 = F1748_15565(RTCW(arg1));
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = RTMS_EX_H("sNan in multiply",16,1487660921);
				F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
			}
			RTLE;
			return (EIF_REFERENCE) RTOSCF(15551,F1748_15551, (Current));
		} else {
			tb1 = '\01';
			if (!F1748_15567(Current)) {
				tb2 = F1748_15567(RTCW(arg1));
				tb1 = tb2;
			}
			if (tb1) {
				tb1 = '\01';
				if (!F1748_15568(Current)) {
					tb2 = F1748_15568(RTCW(arg1));
					tb1 = tb2;
				}
				if (tb1) {
					tr1 = RTMS_EX_H("0 * Inf",7,1141833574);
					F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
					RTLE;
					return (EIF_REFERENCE) RTOSCF(15551,F1748_15551, (Current));
				} else {
					ti4_1 = F1748_15544(RTCW(arg1));
					if ((EIF_BOOLEAN)(F1748_15544(Current) == ti4_1)) {
						RTLE;
						return (EIF_REFERENCE) RTOSCF(15553,F1748_15553, (Current));
					} else {
						RTLE;
						return (EIF_REFERENCE) RTOSCF(15554,F1748_15554, (Current));
					}
				}
			} else {
				RTLE;
				return (EIF_REFERENCE) RTOSCF(15551,F1748_15551, (Current));
			}
		}
	} else {
		tb1 = '\01';
		if (!F1748_15568(Current)) {
			tb2 = F1748_15568(RTCW(arg1));
			tb1 = tb2;
		}
		if (tb1) {
			Result = RTLNSMART(dftype);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
			F1748_15532(RTCW(Result), ti4_1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
			F1748_15606(RTCW(Result), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) + ti4_1));
			ti4_1 = F1748_15544(RTCW(arg1));
			if ((EIF_BOOLEAN)(F1748_15544(Current) == ti4_1)) {
				F1748_15608(RTCW(Result));
			} else {
				F1748_15607(RTCW(Result));
			}
		} else {
			loc1 = (EIF_REFERENCE) Current;
			loc2 = (EIF_REFERENCE) arg1;
			Result = RTLNSMART(dftype);
			ti4_1 = F1748_15580(RTCW(loc1));
			ti4_2 = F1748_15580(RTCW(loc2));
			F1748_15532(RTCW(Result), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 2L)));
			tr1 = *(EIF_REFERENCE *)(RTCW(Result));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc1));
			tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
			F1119_6793(RTCW(tr1), tr2, tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_0_);
			F1748_15606(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ti4_2));
			ti4_1 = F1748_15544(RTCW(arg1));
			if ((EIF_BOOLEAN)(F1748_15544(Current) == ti4_1)) {
				F1748_15608(RTCW(Result));
			} else {
				F1748_15607(RTCW(Result));
			}
			F1748_15638(RTCW(Result), arg2);
		}
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.divide */
EIF_REFERENCE F1748_15592 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1748_15647(Current, arg1, arg2, ((EIF_INTEGER_32) 1L));
}

/* {MA_DECIMAL}.divide_integer */
EIF_REFERENCE F1748_15593 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1748_15647(Current, arg1, arg2, ((EIF_INTEGER_32) 2L));
}

/* {MA_DECIMAL}.remainder */
EIF_REFERENCE F1748_15594 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tb1 = '\01';
	if (!F1748_15564(Current)) {
		tb2 = F1748_15564(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\01';
		if (!F1748_15563(Current)) {
			tb2 = F1748_15563(RTCW(arg1));
			tb1 = tb2;
		}
		if (tb1) {
			tb1 = '\01';
			if (!F1748_15565(Current)) {
				tb2 = F1748_15565(RTCW(arg1));
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = RTMS_EX_H("sNan in remainder",17,1460372594);
				F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
			}
			RTLE;
			return (EIF_REFERENCE) RTOSCF(15551,F1748_15551, (Current));
		} else {
			if (F1748_15567(Current)) {
				tr1 = RTMS_EX_H("[+-] Inf dividend in remainder",30,918751090);
				F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
				Result = RTOSCF(15551,F1748_15551, (Current));
			} else {
				tb1 = F1748_15567(RTCW(arg1));
				if (tb1) {
					Result = RTLNSMART(dftype);
					F1748_15533(RTCW(Result), Current);
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
						F1748_15607(RTCW(Result));
					}
				} else {
					Result = RTOSCF(15551,F1748_15551, (Current));
					RTLE;
					return (EIF_REFERENCE) Result;
				}
			}
		}
	} else {
		tb1 = F1748_15568(RTCW(arg1));
		if (tb1) {
			tr1 = RTMS_EX_H("Zero divisor in remainder",25,993764722);
			F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
			Result = RTOSCF(15551,F1748_15551, (Current));
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			if (F1748_15568(Current)) {
				Result = RTLNSMART(dftype);
				F1748_15534(RTCW(Result));
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) < ((EIF_INTEGER_32) 0L))) {
					F1748_15606(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_));
				} else {
					F1748_15606(RTCW(Result), ((EIF_INTEGER_32) 0L));
				}
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
					F1748_15607(RTCW(Result));
				}
			} else {
				Result = F1748_15648(Current, arg1, arg2, ((EIF_INTEGER_32) 3L));
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
					F1748_15607(RTCW(Result));
				}
				F1748_15638(RTCW(Result), arg2);
			}
		}
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.rescale */
EIF_REFERENCE F1748_15595 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_2_);
	if ((EIF_BOOLEAN) (arg1 <= ti4_1)) {
		ti4_1 = F1775_16267(RTCW(arg2));
		tb1 = (EIF_BOOLEAN) (arg1 >= ti4_1);
	}
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTMS_EX_H("new exponent is not within limits [Etiny..Emax]",47,1826148957);
		F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
		RTLE;
		return (EIF_REFERENCE) RTOSCF(15551,F1748_15551, (Current));
	} else {
		if (F1748_15564(Current)) {
			Result = RTLNSMART(dftype);
			F1748_15533(RTCW(Result), Current);
			F1748_15649(RTCW(Result), arg2);
		} else {
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) < arg1)) {
				if ((EIF_BOOLEAN) !F1748_15568(Current)) {
					loc1 = F1748_15555(Current);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - arg1) + ((EIF_INTEGER_32) 1L));
					if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
						loc5 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
						ti4_1 = F1748_15580(Current);
						loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + ti4_1) + ((EIF_INTEGER_32) 1L));
					} else {
						if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
							loc5 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
							ti4_1 = F1748_15580(Current);
							loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ti4_1);
						} else {
							loc5 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
							ti4_1 = F1748_15580(Current);
							loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + (EIF_INTEGER_32) (ti4_1 - loc1));
						}
					}
					Result = RTLNSMART(dftype);
					F1748_15532(RTCW(Result), loc5);
					F1748_15588(RTCW(Result), Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(Result));
					F1119_6799(RTCW(tr1), loc5);
					F1748_15620(RTCW(Result), arg2);
					F1748_15639(RTCW(Result));
					tb1 = F1748_15637(RTCW(Result), arg2);
					if (tb1) {
						F1748_15643(RTCW(Result), arg2);
					}
					tb1 = '\0';
					tb2 = F1775_16269(RTCW(arg2), ((EIF_INTEGER_32) 8L));
					if (tb2) {
						tb2 = F1775_16269(RTCW(arg2), ((EIF_INTEGER_32) 2L));
						tb1 = tb2;
					}
					if (tb1) {
						tr1 = RTMS_EX_H("Underflow when rescaling",24,1775083111);
						F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 7L), tr1);
					}
					tb1 = F1748_15636(RTCW(Result), arg2);
					if (tb1) {
						F1748_15642(RTCW(Result), arg2);
					}
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) > arg1)) {
						F1748_15624(RTCW(Result), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) - arg1));
					}
				} else {
					Result = RTLNSMART(dftype);
					F1748_15533(RTCW(Result), Current);
				}
				F1748_15606(RTCW(Result), arg1);
			} else {
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) > arg1)) {
					if ((EIF_BOOLEAN) !F1748_15568(Current)) {
						loc2 = F1748_15555(Current);
						loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - arg1) + ((EIF_INTEGER_32) 1L));
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
						if ((EIF_BOOLEAN) (loc2 > ti4_1)) {
							Result = RTLNSMART(dftype);
							ti4_1 = F1748_15580(Current);
							F1748_15532(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
							F1748_15588(RTCW(Result), Current);
							F1748_15624(RTCW(Result), ((EIF_INTEGER_32) 1L));
							loc4 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_2_);
							ti4_1 = F1748_15580(Current);
							F1775_16275(RTCW(arg2), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
							F1748_15606(RTCW(Result), ((EIF_INTEGER_32) 1L));
							F1748_15642(RTCW(Result), arg2);
							tb1 = F1748_15564(RTCW(Result));
							if ((EIF_BOOLEAN) !tb1) {
								F1748_15606(RTCW(Result), arg1);
							}
							F1775_16275(RTCW(arg2), loc4);
						} else {
							loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
							loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - arg1);
							Result = RTLNSMART(dftype);
							ti4_1 = F1748_15580(Current);
							F1748_15532(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + loc3));
							F1748_15588(RTCW(Result), Current);
							F1748_15624(RTCW(Result), loc3);
						}
					} else {
						tb1 = '\0';
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) < ((EIF_INTEGER_32) 0L)))) {
							tb1 = (EIF_BOOLEAN) (F1748_15580(Current) > ((EIF_INTEGER_32) 1L));
						}
						if (tb1) {
							loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) -arg1 + ((EIF_INTEGER_32) 1L));
						} else {
							loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						}
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
						if ((EIF_BOOLEAN) (loc2 > ti4_1)) {
							Result = RTLNSMART(dftype);
							ti4_1 = F1748_15580(Current);
							F1748_15532(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
							F1748_15588(RTCW(Result), Current);
							F1748_15624(RTCW(Result), ((EIF_INTEGER_32) 1L));
							loc4 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_2_);
							ti4_1 = F1748_15555(RTCW(Result));
							F1775_16275(RTCW(arg2), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
							F1748_15642(RTCW(Result), arg2);
							F1775_16275(RTCW(arg2), loc4);
						} else {
							if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 1L))) {
								loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
								loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - arg1);
								Result = RTLNSMART(dftype);
								ti4_1 = F1748_15580(Current);
								F1748_15532(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + loc3));
								F1748_15588(RTCW(Result), Current);
								F1748_15624(RTCW(Result), loc3);
							} else {
								Result = RTLNSMART(dftype);
								F1748_15533(RTCW(Result), Current);
							}
							F1748_15606(RTCW(Result), arg1);
						}
					}
					F1748_15638(RTCW(Result), arg2);
				} else {
					Result = RTLNSMART(dftype);
					F1748_15533(RTCW(Result), Current);
					F1748_15638(RTCW(Result), arg2);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.round_to_integer */
EIF_REFERENCE F1748_15597 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1748_15595(Current, ((EIF_INTEGER_32) 0L), arg1);
}

/* {MA_DECIMAL}.minus */
EIF_REFERENCE F1748_15600 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNSMART(Dftype(Current));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
	F1748_15532(RTCW(loc1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	F1748_15606(RTCW(loc1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_));
	tr1 = F1748_15590(RTCW(loc1), Current, arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {MA_DECIMAL}.compare */
EIF_REFERENCE F1748_15605 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	tb1 = '\01';
	if (!F1748_15564(Current)) {
		tb2 = F1748_15564(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\01';
		if (!F1748_15563(Current)) {
			tb2 = F1748_15563(RTCW(arg1));
			tb1 = tb2;
		}
		if (tb1) {
			Result = RTOSCF(15551,F1748_15551, (Current));
			tb1 = '\01';
			if (!F1748_15565(Current)) {
				tb2 = F1748_15565(RTCW(arg1));
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = RTMS_EX_H("sNaN in \'compare\'",17,1951204135);
				F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
			}
		} else {
			if (F1748_15567(Current)) {
				tb1 = '\0';
				tb2 = F1748_15567(RTCW(arg1));
				if (tb2) {
					tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
					tb1 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) == tb2);
				}
				if (tb1) {
					Result = F1748_15549(Current);
				} else {
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
						Result = RTOSCF(15548,F1748_15548, (Current));
					} else {
						Result = F1748_15547(Current);
					}
				}
			} else {
				tb1 = F1748_15567(RTCW(arg1));
				if (tb1) {
					tb1 = '\0';
					if (F1748_15567(Current)) {
						tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
						tb1 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) == tb2);
					}
					if (tb1) {
						Result = F1748_15549(Current);
						RTLE;
						return (EIF_REFERENCE) Result;
					} else {
						tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
						if (tb1) {
							Result = F1748_15547(Current);
							RTLE;
							return (EIF_REFERENCE) Result;
						} else {
							Result = RTOSCF(15548,F1748_15548, (Current));
							RTLE;
							return (EIF_REFERENCE) Result;
						}
					}
				} else {
					Result = RTOSCF(15551,F1748_15551, (Current));
					RTLE;
					return (EIF_REFERENCE) Result;
				}
			}
		}
	} else {
		loc1 = RTLNSMART(dftype);
		F1748_15533(RTCW(loc1), Current);
		loc2 = RTLNSMART(dftype);
		F1748_15533(RTCW(loc2), arg1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
		if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) != tb1)) {
			if (F1748_15568(Current)) {
				loc1 = RTLNSMART(dftype);
				F1748_15534(RTCW(loc1));
			} else {
				loc1 = RTLNSMART(dftype);
				F1748_15535(RTCW(loc1));
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
					F1748_15607(RTCW(loc1));
				}
			}
			tb1 = F1748_15568(RTCW(arg1));
			if (tb1) {
				loc2 = RTLNSMART(dftype);
				F1748_15534(RTCW(loc2));
			} else {
				loc2 = RTLNSMART(dftype);
				F1748_15535(RTCW(loc2));
				tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
				if (tb1) {
					F1748_15607(RTCW(loc2));
				}
			}
		}
		loc3 = F1415_11685(RTCW(arg2));
		F1775_16282(RTCW(loc3));
		Result = F1748_15590(RTCW(loc1), loc2, loc3);
		tb1 = '\0';
		tb2 = F1748_15568(RTCW(Result));
		if (tb2) {
			tb2 = F1775_16269(RTCW(loc3), ((EIF_INTEGER_32) 8L));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			Result = F1748_15549(Current);
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			tb1 = *(EIF_BOOLEAN *)(RTCW(Result)+ _CHROFF_1_0_);
			if (tb1) {
				Result = RTOSCF(15548,F1748_15548, (Current));
				RTLE;
				return (EIF_REFERENCE) Result;
			} else {
				Result = F1748_15547(Current);
				RTLE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.set_exponent */
void F1748_15606 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {MA_DECIMAL}.set_negative */
void F1748_15607 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {MA_DECIMAL}.set_positive */
void F1748_15608 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {MA_DECIMAL}.set_quiet_nan */
void F1748_15615 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1748_15541(Current);
}

/* {MA_DECIMAL}.add_special */
EIF_REFERENCE F1748_15616 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tb1 = '\01';
	if (!F1748_15563(Current)) {
		tb2 = F1748_15563(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\01';
		if (!F1748_15565(Current)) {
			tb2 = F1748_15565(RTCW(arg1));
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = RTMS_EX_H("sNaN operand in add",19,667875428);
			F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
		}
		RTLE;
		return (EIF_REFERENCE) RTOSCF(15551,F1748_15551, (Current));
	} else {
		tb1 = '\0';
		if (F1748_15567(Current)) {
			tb2 = F1748_15567(RTCW(arg1));
			tb1 = tb2;
		}
		if (tb1) {
			ti4_1 = F1748_15544(RTCW(arg1));
			if ((EIF_BOOLEAN)(F1748_15544(Current) != ti4_1)) {
				tr1 = RTMS_EX_H("+Inf and -Inf operands in add",29,1456613732);
				F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
				Result = RTOSCF(15551,F1748_15551, (Current));
			} else {
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
					Result = RTOSCF(15554,F1748_15554, (Current));
				} else {
					Result = RTOSCF(15553,F1748_15553, (Current));
				}
			}
		} else {
			tb1 = '\01';
			if (!F1748_15567(Current)) {
				tb2 = F1748_15567(RTCW(arg1));
				tb1 = tb2;
			}
			if (tb1) {
				if (F1748_15567(Current)) {
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
						Result = RTOSCF(15554,F1748_15554, (Current));
						RTLE;
						return (EIF_REFERENCE) Result;
					} else {
						Result = RTOSCF(15553,F1748_15553, (Current));
						RTLE;
						return (EIF_REFERENCE) Result;
					}
				} else {
					tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
					if (tb1) {
						Result = RTOSCF(15554,F1748_15554, (Current));
						RTLE;
						return (EIF_REFERENCE) Result;
					} else {
						Result = RTOSCF(15553,F1748_15553, (Current));
						RTLE;
						return (EIF_REFERENCE) Result;
					}
				}
			} else {
				Result = RTOSCF(15551,F1748_15551, (Current));
				RTLE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.subtract_special */
EIF_REFERENCE F1748_15617 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tb1 = '\01';
	if (!F1748_15563(Current)) {
		tb2 = F1748_15563(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\01';
		if (!F1748_15565(Current)) {
			tb2 = F1748_15565(RTCW(arg1));
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = RTMS_EX_H("sNaN operand in subtract",24,404634484);
			F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
		}
		RTLE;
		return (EIF_REFERENCE) RTOSCF(15551,F1748_15551, (Current));
	} else {
		tb1 = '\0';
		if (F1748_15567(Current)) {
			tb2 = F1748_15567(RTCW(arg1));
			tb1 = tb2;
		}
		if (tb1) {
			ti4_1 = F1748_15544(RTCW(arg1));
			if ((EIF_BOOLEAN)(F1748_15544(Current) == ti4_1)) {
				tr1 = RTMS_EX_H("Inf and Inf operands in subtract",32,1318973300);
				F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
				Result = RTOSCF(15551,F1748_15551, (Current));
			} else {
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
					Result = RTOSCF(15554,F1748_15554, (Current));
				} else {
					Result = RTOSCF(15553,F1748_15553, (Current));
				}
			}
		} else {
			tb1 = '\01';
			if (!F1748_15567(Current)) {
				tb2 = F1748_15567(RTCW(arg1));
				tb1 = tb2;
			}
			if (tb1) {
				Result = RTOSCF(15553,F1748_15553, (Current));
				if (F1748_15567(Current)) {
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
						Result = RTOSCF(15554,F1748_15554, (Current));
						RTLE;
						return (EIF_REFERENCE) Result;
					}
				} else {
					tb1 = F1748_15562(RTCW(arg1));
					if (tb1) {
						Result = RTOSCF(15554,F1748_15554, (Current));
						RTLE;
						return (EIF_REFERENCE) Result;
					} else {
						Result = RTOSCF(15553,F1748_15553, (Current));
						RTLE;
						return (EIF_REFERENCE) Result;
					}
				}
			} else {
				Result = RTOSCF(15551,F1748_15551, (Current));
				RTLE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.unsigned_add */
void F1748_15618 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
	loc1 = F1748_15621(Current, arg1, ti4_1);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 1L))) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
		ti4_2 = F1748_15580(Current);
		F1748_15624(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)) - ti4_2));
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
		tr3 = *(EIF_REFERENCE *)(RTCW(arg1));
		ti4_1 = F1119_6775(RTCW(tr3));
		ti4_1 = F1119_6774(RTCW(tr2), ti4_1);
		F1119_6783(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 0L));
		tr1 = RTMS_EX_H("",0,0);
		F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 2L), tr1);
	} else {
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 2L))) {
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = *(EIF_REFERENCE *)(Current);
			ti4_1 = F1119_6775(RTCW(tr2));
			loc2 = F1119_6774(RTCW(tr1), ti4_1);
			F1748_15588(Current, arg1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
			ti4_2 = F1748_15580(Current);
			F1748_15624(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)) - ti4_2));
			tr1 = *(EIF_REFERENCE *)(Current);
			F1119_6783(RTCW(tr1), loc2, ((EIF_INTEGER_32) 0L));
			tr1 = RTMS_EX_H("",0,0);
			F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 2L), tr1);
		} else {
			if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 5L))) {
				F1748_15588(Current, arg1);
			} else {
				if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 4L))) {
				} else {
					tr1 = *(EIF_REFERENCE *)(Current);
					tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
					F1119_6792(RTCW(tr1), tr2);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
					ti4_1 = eif_min_int32 (ti4_1,ti4_2);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ti4_1;
				}
			}
		}
	}
	RTLE;
}

/* {MA_DECIMAL}.unsigned_subtract */
void F1748_15619 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
	loc2 = F1748_15621(Current, arg1, ti4_1);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L))) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
		ti4_2 = F1748_15580(Current);
		F1748_15624(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)) - ti4_2));
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_1_0_0_1_);
		F1119_6796(RTCW(tr1), ((EIF_INTEGER_32) 1L), ti4_1);
	} else {
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 2L))) {
			F1748_15588(Current, arg1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
			ti4_2 = F1748_15580(Current);
			F1748_15624(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)) - ti4_2));
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = *(EIF_REFERENCE *)(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_1_0_0_1_);
			F1119_6796(RTCW(tr1), ((EIF_INTEGER_32) 1L), ti4_1);
			F1748_15607(Current);
		} else {
			if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 4L))) {
			} else {
				if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 5L))) {
					F1748_15588(Current, arg1);
					F1748_15607(Current);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current);
					tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
					loc1 = F1119_6784(RTCW(tr1), tr2);
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
						tr1 = *(EIF_REFERENCE *)(Current);
						F1119_6788(RTCW(tr1), ((EIF_INTEGER_32) 1L));
						tr1 = *(EIF_REFERENCE *)(Current);
						F1119_6783(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
					} else {
						if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
							F1119_6795(RTCW(tr1), tr2);
						} else {
							tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
							F1119_6795(RTCW(tr1), *(EIF_REFERENCE *)(Current));
							tr1 = *(EIF_REFERENCE *)(Current);
							tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
							F1119_6786(RTCW(tr1), tr2);
							F1748_15607(Current);
						}
					}
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
					ti4_1 = eif_min_int32 (ti4_1,ti4_2);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ti4_1;
				}
			}
		}
	}
	RTLE;
}

/* {MA_DECIMAL}.round */
void F1748_15620 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (F1748_15564(Current)) {
		if (F1748_15565(Current)) {
			tr1 = RTMS_EX_H("sNaN in \'round\'",15,142702375);
			F1775_16288(RTCW(arg1), ((EIF_INTEGER_32) 3L), tr1);
		}
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
		if ((EIF_BOOLEAN) (F1748_15580(Current) > ti4_1)) {
			tr1 = RTMS_EX_H("Argument rounded",16,2117652836);
			F1775_16288(RTCW(arg1), ((EIF_INTEGER_32) 6L), tr1);
			if (F1748_15635(Current, arg1)) {
				tr1 = RTMS_EX_H("Inexact when rouding",20,1448171367);
				F1775_16288(RTCW(arg1), ((EIF_INTEGER_32) 2L), tr1);
			}
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_1_);
			switch (ti4_1) {
				case 0L:
					F1748_15627(Current, arg1);
					break;
				case 1L:
					F1748_15628(Current, arg1);
					break;
				case 2L:
					F1748_15629(Current, arg1);
					break;
				case 3L:
					F1748_15630(Current, arg1);
					break;
				case 4L:
					F1748_15631(Current, arg1);
					break;
				case 5L:
					F1748_15632(Current, arg1);
					break;
				case 6L:
					F1748_15634(Current, arg1);
					break;
			}
		}
	}
	RTLE;
}

/* {MA_DECIMAL}.align_and_hint */
EIF_INTEGER_32 F1748_15621 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (arg2 > ((EIF_INTEGER_32) 0L));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) == ti4_1)) {
		ti4_1 = F1748_15580(Current);
		ti4_2 = F1748_15580(RTCW(arg1));
		loc1 = eif_max_int32 (ti4_1,ti4_2);
		if ((EIF_BOOLEAN) (loc1 > F1748_15580(Current))) {
			F1748_15626(Current, loc1);
		}
		ti4_1 = F1748_15580(RTCW(arg1));
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) {
			F1748_15626(RTCW(arg1), loc1);
		}
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) > ti4_1)) {
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
			ti4_2 = F1748_15555(Current);
			loc2 = eif_min_int32 (ti4_1,(EIF_INTEGER_32) (ti4_2 - (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L))));
			ti4_1 = F1748_15555(RTCW(arg1));
			if ((EIF_BOOLEAN) (loc2 > ti4_1)) {
				if (F1748_15568(Current)) {
					RTLE;
					return (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				} else {
					if (loc3) {
						tb1 = F1748_15568(RTCW(arg1));
						if (tb1) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
						} else {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						}
						loc4 = F1748_15580(Current);
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)) - loc4);
						if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
							F1748_15624(Current, loc4);
						}
					}
				}
			} else {
				if (loc3) {
					F1748_15622(Current, arg1, arg2);
				} else {
					F1748_15623(Current, arg1);
				}
				RTLE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			}
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
			ti4_2 = F1748_15555(RTCW(arg1));
			loc2 = eif_min_int32 (ti4_1,(EIF_INTEGER_32) (ti4_2 - (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L))));
			if ((EIF_BOOLEAN) (loc2 > F1748_15555(Current))) {
				tb1 = F1748_15568(RTCW(arg1));
				if (tb1) {
					RTLE;
					return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
				} else {
					if (loc3) {
						if (F1748_15568(Current)) {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
						} else {
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
						}
						loc4 = F1748_15580(RTCW(arg1));
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)) - loc4);
						if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
							F1748_15624(RTCW(arg1), loc4);
						}
					}
				}
			} else {
				if (loc3) {
					F1748_15622(RTCW(arg1), Current, arg2);
				} else {
					F1748_15623(RTCW(arg1), Current);
				}
				RTLE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			}
		}
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.align_overlapped */
void F1748_15622 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		F1748_15624(Current, loc1);
	}
	ti4_1 = F1748_15580(Current);
	ti4_2 = F1748_15580(RTCW(arg1));
	loc2 = eif_max_int32 (ti4_1,ti4_2);
	ti4_1 = F1748_15580(RTCW(arg1));
	if ((EIF_BOOLEAN) (loc2 > ti4_1)) {
		F1748_15626(RTCW(arg1), loc2);
	}
	if ((EIF_BOOLEAN) (loc2 > F1748_15580(Current))) {
		F1748_15626(Current, loc2);
	}
	RTLE;
}

/* {MA_DECIMAL}.align_unlimited */
void F1748_15623 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
	F1748_15624(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) - ti4_1));
	loc1 = F1748_15580(Current);
	ti4_1 = F1748_15580(RTCW(arg1));
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F1748_15580(Current);
		F1748_15626(RTCW(arg1), ti4_1);
	} else {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
			ti4_1 = F1748_15580(RTCW(arg1));
			F1748_15626(Current, ti4_1);
		}
	}
	RTLE;
}

/* {MA_DECIMAL}.shift_left */
void F1748_15624 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1119_6790(RTCW(tr1), arg1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_)) -= arg1;
	RTLE;
}

/* {MA_DECIMAL}.shift_right */
void F1748_15625 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1119_6791(RTCW(tr1), arg1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_)) += arg1;
	RTLE;
}

/* {MA_DECIMAL}.grow */
void F1748_15626 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1119_6782(RTCW(tr1), arg1);
	RTLE;
}

/* {MA_DECIMAL}.do_round_up */
void F1748_15627 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (F1748_15635(Current, arg1)) {
		loc1 = F1748_15580(Current);
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
		F1119_6794(RTCW(tr1), ((EIF_INTEGER_32) 1L), ti4_1);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - loc2);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_)) += loc2;
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
	if ((EIF_BOOLEAN) (F1748_15580(Current) > ti4_1)) {
		ti4_1 = F1748_15580(Current);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
		F1748_15625(Current, (EIF_INTEGER_32) (ti4_1 - ti4_2));
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
		F1119_6788(RTCW(tr1), ti4_1);
	}
	RTLE;
}

/* {MA_DECIMAL}.do_round_down */
void F1748_15628 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc2 = F1748_15580(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1119_6791(RTCW(tr1), loc2);
	loc1 = (EIF_INTEGER_32) loc2;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_)) += loc1;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
	F1119_6788(RTCW(tr1), ti4_1);
	RTLE;
}

/* {MA_DECIMAL}.do_round_ceiling */
void F1748_15629 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\01';
	if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		tb1 = (EIF_BOOLEAN) !F1748_15635(Current, arg1);
	}
	if (tb1) {
		F1748_15628(Current, arg1);
	} else {
		F1748_15627(Current, arg1);
	}
	RTLE;
}

/* {MA_DECIMAL}.do_round_floor */
void F1748_15630 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\01';
	if (!F1748_15562(Current)) {
		tb1 = (EIF_BOOLEAN) !F1748_15635(Current, arg1);
	}
	if (tb1) {
		F1748_15628(Current, arg1);
	} else {
		F1748_15627(Current, arg1);
	}
	RTLE;
}

/* {MA_DECIMAL}.do_round_half_up */
void F1748_15631 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	switch (F1748_15633(Current, arg1)) {
		case 0L:
		case 1L:
			F1748_15627(Current, arg1);
			break;
		default:
			F1748_15628(Current, arg1);
			break;
	}
	RTLE;
}

/* {MA_DECIMAL}.do_round_half_down */
void F1748_15632 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	switch (F1748_15633(Current, arg1)) {
		case -1L:
			F1748_15628(Current, arg1);
			break;
		case 1L:
			F1748_15627(Current, arg1);
			break;
		default:
			F1748_15628(Current, arg1);
			break;
	}
	RTLE;
}

/* {MA_DECIMAL}.three_way_compare_discarded_to_half */
EIF_INTEGER_32 F1748_15633 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = F1748_15580(Current);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
	loc1 = F1119_6774(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - ti4_2) - ((EIF_INTEGER_32) 1L)));
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 5L))) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 5L))) {
			RTLE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		} else {
			loc2 = F1748_15580(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - ti4_1) - ((EIF_INTEGER_32) 2L));
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) {
					tr1 = *(EIF_REFERENCE *)(Current);
					ti4_1 = F1119_6774(RTCW(tr1), loc2);
					tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
				}
				if (tb1) break;
				loc2--;
			}
			if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 0L))) {
				RTLE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			} else {
				RTLE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			}
		}
	}/* NOTREACHED */
	
}

/* {MA_DECIMAL}.do_round_half_even */
void F1748_15634 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	switch (F1748_15633(Current, arg1)) {
		case -1L:
			F1748_15628(Current, arg1);
			break;
		case 1L:
			F1748_15627(Current, arg1);
			break;
		default:
			tr1 = *(EIF_REFERENCE *)(Current);
			ti4_1 = F1748_15580(Current);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
			ti4_1 = F1119_6774(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ti4_2));
			if ((EIF_BOOLEAN)((EIF_INTEGER_32) (ti4_1 % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 0L))) {
				F1748_15628(Current, arg1);
			} else {
				F1748_15627(Current, arg1);
			}
			break;
	}
	RTLE;
}

/* {MA_DECIMAL}.lost_digits */
EIF_BOOLEAN F1748_15635 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1748_15580(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) - ((EIF_INTEGER_32) 1L));
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current);
			ti4_1 = F1119_6774(RTCW(tr1), loc1);
			tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
		}
		if (tb1) break;
		loc1--;
	}
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (loc1 >= ((EIF_INTEGER_32) 0L));
}

/* {MA_DECIMAL}.is_overflow */
EIF_BOOLEAN F1748_15636 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = F1748_15555(Current);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_2_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.is_underflow */
EIF_BOOLEAN F1748_15637 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = F1748_15555(Current);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_2_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 < (EIF_INTEGER_32) -ti4_2);
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.clean_up */
void F1748_15638 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1748_15564(Current)) {
		loc1 = F1775_16270(RTCW(arg1), ((EIF_INTEGER_32) 4L));
		loc2 = F1775_16269(RTCW(arg1), ((EIF_INTEGER_32) 4L));
		F1775_16279(RTCW(arg1), ((EIF_INTEGER_32) 4L));
		F1775_16281(RTCW(arg1), ((EIF_INTEGER_32) 4L));
		F1748_15639(Current);
		if (F1748_15637(Current, arg1)) {
			F1748_15643(Current, arg1);
		} else {
			tb1 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
				tb1 = (EIF_BOOLEAN) (F1748_15580(Current) > ti4_1);
			}
			if (tb1) {
				F1748_15620(Current, arg1);
			}
			if (F1748_15636(Current, arg1)) {
				F1748_15642(Current, arg1);
			}
		}
		if (loc1) {
			F1775_16278(RTCW(arg1), ((EIF_INTEGER_32) 4L));
		}
		tb1 = '\01';
		if (!loc2) {
			tb2 = F1775_16269(RTCW(arg1), ((EIF_INTEGER_32) 4L));
			tb1 = tb2;
		}
		if (tb1) {
			F1775_16280(RTCW(arg1), ((EIF_INTEGER_32) 4L));
		} else {
			F1775_16281(RTCW(arg1), ((EIF_INTEGER_32) 4L));
		}
	}
	RTLE;
}

/* {MA_DECIMAL}.strip_leading_zeroes */
void F1748_15639 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F226_1967(RTCW(tr1));
	RTLE;
}

/* {MA_DECIMAL}.set_largest */
void F1748_15640 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
	if ((EIF_BOOLEAN) (F1748_15580(Current) < ti4_1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
		F1748_15626(Current, ti4_1);
	}
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 >= F1748_15580(Current))) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		F1119_6783(RTCW(tr1), ((EIF_INTEGER_32) 9L), loc1);
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
	F1119_6788(RTCW(tr1), ti4_1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) < ((EIF_INTEGER_32) 0L))) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_2_);
		ti4_2 = F1748_15580(Current);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) -ti4_1 + (EIF_INTEGER_32) (ti4_2 - ((EIF_INTEGER_32) 1L)));
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_2_);
		ti4_2 = F1748_15580(Current);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - (EIF_INTEGER_32) (ti4_2 - ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
}

/* {MA_DECIMAL}.promote_to_infinity */
void F1748_15641 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1748_15543(Current, arg1);
}

/* {MA_DECIMAL}.do_overflow */
void F1748_15642 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1748_15568(Current)) {
		tr1 = RTMS_EX_H("",0,0);
		F1775_16288(RTCW(arg1), ((EIF_INTEGER_32) 5L), tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_1_);
		switch (ti4_1) {
			case 0L:
			case 4L:
			case 5L:
			case 6L:
				ti4_1 = F1748_15544(Current);
				F1748_15641(Current, ti4_1);
				break;
			case 1L:
				F1748_15640(Current, arg1);
				break;
			case 2L:
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
					F1748_15640(Current, arg1);
				} else {
					ti4_1 = F1748_15544(Current);
					F1748_15641(Current, ti4_1);
				}
				break;
			case 3L:
				if (F1748_15562(Current)) {
					F1748_15640(Current, arg1);
				} else {
					ti4_1 = F1748_15544(Current);
					F1748_15641(Current, ti4_1);
				}
				break;
			default:
				RTEC(EN_WHEN);
		}
		tr1 = RTMS_EX_H("do_overflow",11,2067033207);
		F1775_16288(RTCW(arg1), ((EIF_INTEGER_32) 2L), tr1);
		tr1 = RTMS_EX_H("do_overflow",11,2067033207);
		F1775_16288(RTCW(arg1), ((EIF_INTEGER_32) 6L), tr1);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_2_);
		F1748_15606(Current, ti4_1);
	}
	RTLE;
}

/* {MA_DECIMAL}.do_underflow */
void F1748_15643 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc8);
	RTLIU(4);
	
	RTGC;
	loc6 = F1748_15568(Current);
	if ((EIF_BOOLEAN) !loc6) {
		tr1 = RTMS_EX_H("",0,0);
		F1775_16288(RTCW(arg1), ((EIF_INTEGER_32) 8L), tr1);
	} else {
		loc7 = F1775_16269(RTCW(arg1), ((EIF_INTEGER_32) 6L));
		loc8 = *(EIF_REFERENCE *)(RTCW(arg1));
	}
	loc1 = F1775_16267(RTCW(arg1));
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) < loc1)) {
		loc5 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
		loc2 = F1748_15555(Current);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - loc1) + ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) {
			loc5 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_1_);
			F1775_16292(RTCW(arg1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
			loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_1_);
			switch (ti4_1) {
				case 0L:
					loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					break;
				case 2L:
					tb1 = '\0';
					if (F1748_15562(Current)) {
						tb1 = F1748_15635(Current, arg1);
					}
					if (tb1) {
						loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					}
					break;
				case 3L:
					tb1 = '\01';
					if (!F1748_15562(Current)) {
						tb1 = (EIF_BOOLEAN) !F1748_15635(Current, arg1);
					}
					if (tb1) {
						loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					} else {
						loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					}
					break;
				default:
					loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					break;
			}
			F1775_16274(RTCW(arg1), loc5);
			tr1 = *(EIF_REFERENCE *)(Current);
			F1119_6783(RTCW(tr1), loc9, ((EIF_INTEGER_32) 0L));
			tr1 = *(EIF_REFERENCE *)(Current);
			F1119_6788(RTCW(tr1), ((EIF_INTEGER_32) 1L));
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) loc1;
			tr1 = RTMS_EX_H("Rescaling to e_tiny",19,1576160121);
			F1775_16288(RTCW(arg1), ((EIF_INTEGER_32) 2L), tr1);
			tr1 = RTMS_EX_H("Rescaling to e_tiny",19,1576160121);
			F1775_16288(RTCW(arg1), ((EIF_INTEGER_32) 6L), tr1);
			tr1 = RTMS_EX_H("Rescaling to e_tiny",19,1576160121);
			F1775_16288(RTCW(arg1), ((EIF_INTEGER_32) 7L), tr1);
		} else {
			if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
				F1775_16274(RTCW(arg1), ((EIF_INTEGER_32) 1L));
				ti4_1 = F1748_15580(Current);
				F1748_15626(Current, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
			} else {
				loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_2_);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
				loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) -loc4 - ti4_1) + ((EIF_INTEGER_32) 1L));
				if ((EIF_BOOLEAN) (F1748_15580(Current) < loc4)) {
					F1748_15626(Current, loc4);
				}
				loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_2_);
				loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) -loc3 - loc1) + ((EIF_INTEGER_32) 1L));
				F1775_16274(RTCW(arg1), loc3);
			}
			F1748_15620(Current, arg1);
			F1775_16274(RTCW(arg1), loc5);
			F1748_15639(Current);
			tb1 = '\0';
			tb2 = F1775_16269(RTCW(arg1), ((EIF_INTEGER_32) 8L));
			if (tb2) {
				tb2 = F1775_16269(RTCW(arg1), ((EIF_INTEGER_32) 2L));
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = RTMS_EX_H("Underflow when rescaling",24,1775083111);
				F1775_16288(RTCW(arg1), ((EIF_INTEGER_32) 7L), tr1);
			}
			if (F1748_15636(Current, arg1)) {
				F1748_15642(Current, arg1);
			}
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) loc1;
		if (loc6) {
			if ((EIF_BOOLEAN) (loc7 && (EIF_BOOLEAN)(loc8 != NULL))) {
				F1775_16288(RTCW(arg1), ((EIF_INTEGER_32) 6L), loc8);
			} else {
				F1775_16281(RTCW(arg1), ((EIF_INTEGER_32) 6L));
			}
		}
	}
	RTLE;
}

/* {MA_DECIMAL}.do_divide */
EIF_REFERENCE F1748_15647 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 3L)));
	tb1 = '\01';
	if (!F1748_15564(Current)) {
		tb2 = F1748_15564(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\01';
		if (!F1748_15563(Current)) {
			tb2 = F1748_15563(RTCW(arg1));
			tb1 = tb2;
		}
		if (tb1) {
			tb1 = '\01';
			if (!F1748_15565(Current)) {
				tb2 = F1748_15565(RTCW(arg1));
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = RTMS_EX_H("sNan in divide",14,2043698789);
				F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
			}
			RTLE;
			return (EIF_REFERENCE) RTOSCF(15551,F1748_15551, (Current));
		} else {
			tb1 = '\0';
			if (F1748_15567(Current)) {
				tb2 = F1748_15567(RTCW(arg1));
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = RTMS_EX_H("[+-] Inf / [+-] Inf",19,343116390);
				F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
				Result = RTOSCF(15551,F1748_15551, (Current));
			} else {
				if (F1748_15567(Current)) {
					ti4_1 = F1748_15544(RTCW(arg1));
					if ((EIF_BOOLEAN)(F1748_15544(Current) == ti4_1)) {
						Result = RTOSCF(15553,F1748_15553, (Current));
					} else {
						Result = RTOSCF(15554,F1748_15554, (Current));
					}
					tb1 = F1748_15568(RTCW(arg1));
					if (tb1) {
						tr1 = RTMS_EX_H("[+-] Inf / [+-] 0",17,739381040);
						F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 1L), tr1);
					}
				} else {
					tb1 = F1748_15567(RTCW(arg1));
					if (tb1) {
						ti4_1 = F1748_15544(RTCW(arg1));
						if ((EIF_BOOLEAN)(F1748_15544(Current) == ti4_1)) {
							Result = F1748_15549(Current);
							RTLE;
							return (EIF_REFERENCE) Result;
						} else {
							Result = RTOSCF(15550,F1748_15550, (Current));
							RTLE;
							return (EIF_REFERENCE) Result;
						}
					} else {
						Result = RTOSCF(15551,F1748_15551, (Current));
						RTLE;
						return (EIF_REFERENCE) Result;
					}
				}
			}
		}
	} else {
		tb1 = F1748_15568(RTCW(arg1));
		if (tb1) {
			if (F1748_15568(Current)) {
				tr1 = RTMS_EX_H("Division Undefined : O/O",24,2072290895);
				F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
				Result = RTOSCF(15551,F1748_15551, (Current));
				RTLE;
				return (EIF_REFERENCE) Result;
			} else {
				tr1 = RTMS_EX_H("Division by zero",16,625366895);
				F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 1L), tr1);
				ti4_1 = F1748_15544(RTCW(arg1));
				if ((EIF_BOOLEAN)(F1748_15544(Current) == ti4_1)) {
					Result = RTOSCF(15553,F1748_15553, (Current));
					RTLE;
					return (EIF_REFERENCE) Result;
				} else {
					Result = RTOSCF(15554,F1748_15554, (Current));
					RTLE;
					return (EIF_REFERENCE) Result;
				}
			}
		} else {
			if (F1748_15568(Current)) {
				Result = RTLNSMART(Dftype(Current));
				F1748_15534(RTCW(Result));
				if (loc1) {
					F1748_15606(RTCW(Result), ((EIF_INTEGER_32) 0L));
				} else {
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
					ti4_2 = F1748_15555(RTCW(arg1));
					F1748_15606(RTCW(Result), (EIF_INTEGER_32) (ti4_1 - ti4_2));
				}
				ti4_1 = F1748_15544(RTCW(arg1));
				if ((EIF_BOOLEAN)(F1748_15544(Current) == ti4_1)) {
					F1748_15608(RTCW(Result));
				} else {
					F1748_15607(RTCW(Result));
				}
				F1748_15638(RTCW(Result), arg2);
			} else {
				Result = F1748_15648(Current, arg1, arg2, arg3);
				ti4_1 = F1748_15544(RTCW(arg1));
				if ((EIF_BOOLEAN)(F1748_15544(Current) == ti4_1)) {
					F1748_15608(RTCW(Result));
				} else {
					F1748_15607(RTCW(Result));
				}
				F1748_15638(RTCW(Result), arg2);
			}
		}
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.internal_divide */
EIF_REFERENCE F1748_15648 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc12 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc14 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc15 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc16 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,Result);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN)(arg3 != ((EIF_INTEGER_32) 1L));
	loc1 = RTLNSMART(dftype);
	F1748_15533(RTCW(loc1), Current);
	loc2 = RTLNSMART(dftype);
	F1748_15533(RTCW(loc2), arg1);
	loc10 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_0_);
	loc9 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_0_);
	tb1 = F1748_15568(RTCW(loc1));
	if (tb1) {
		loc16 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	Result = RTLNSMART(dftype);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
	F1748_15532(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
		tb1 = F224_1937(RTCW(tr1), tr2);
		if (tb1) break;
		F1748_15624(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		loc4++;
		loc6++;
	}
	F1748_15624(RTCW(loc2), ((EIF_INTEGER_32) 1L));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
		tb2 = F226_1956(RTCW(tr1), tr2);
		if (tb2) break;
		loc4--;
		F1748_15624(RTCW(loc2), ((EIF_INTEGER_32) 1L));
		loc5++;
	}
	F1748_15625(RTCW(loc2), ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
	tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_1_0_0_1_);
	F1119_6788(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
	if (loc13) {
		loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 - (EIF_INTEGER_32) (loc10 + loc4));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
		loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 >= ti4_1);
		loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 < ((EIF_INTEGER_32) 0L));
		loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc15 || loc14);
	} else {
		loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	if ((EIF_BOOLEAN) !loc12) {
		tr1 = *(EIF_REFERENCE *)(RTCW(Result));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
		F1119_6782(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		tr1 = *(EIF_REFERENCE *)(RTCW(Result));
		F1119_6788(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	}
	for (;;) {
		if (loc12) break;
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc1));
			tb3 = F226_1957(RTCW(tr1), tr2);
			if (tb3) break;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
			F1119_6795(RTCW(tr1), tr2);
			tr1 = *(EIF_REFERENCE *)(RTCW(Result));
			ti4_1 = F1748_15580(RTCW(Result));
			F1119_6794(RTCW(tr1), ((EIF_INTEGER_32) 1L), ti4_1);
		}
		switch (arg3) {
			case 1L:
				tb4 = '\01';
				tb5 = '\0';
				tb6 = F1748_15568(RTCW(loc1));
				if (tb6) {
					tb5 = (EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 0L));
				}
				if (!tb5) {
					ti4_1 = F1748_15580(RTCW(Result));
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_2_0_0_);
					tb4 = (EIF_BOOLEAN)(ti4_1 == ti4_2);
				}
				if (tb4) {
					loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
				break;
			default:
				if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 0L))) {
					loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
				break;
		}
		if ((EIF_BOOLEAN) !loc12) {
			tr1 = *(EIF_REFERENCE *)(RTCW(Result));
			F1119_6790(RTCW(tr1), ((EIF_INTEGER_32) 1L));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			F1119_6790(RTCW(tr1), ((EIF_INTEGER_32) 1L));
			loc4++;
			loc7--;
		}
	}
	if (loc14) {
		F1748_15615(RTCW(Result));
		tr1 = RTMS_EX_H("Division impossible",19,1915827557);
		F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 3L), tr1);
	} else {
		loc3 = (EIF_REFERENCE) loc1;
		switch (arg3) {
			case 1L:
				tb4 = F1748_15568(RTCW(loc3));
				if (tb4) {
					if ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 0L))) {
						tr1 = RTMS_EX_H("Artificial rounding in division where remainder is zero",55,1295062383);
						F1775_16288(RTCW(arg2), ((EIF_INTEGER_32) 6L), tr1);
					}
				} else {
					tr1 = *(EIF_REFERENCE *)(RTCW(Result));
					F1119_6790(RTCW(tr1), ((EIF_INTEGER_32) 1L));
					loc4++;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
					tr2 = *(EIF_REFERENCE *)(RTCW(loc3));
					F1119_6795(RTCW(tr1), tr2);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
					tr2 = *(EIF_REFERENCE *)(RTCW(loc3));
					ti4_1 = F1119_6784(RTCW(tr1), tr2);
					switch (ti4_1) {
						case 0L:
							tr1 = *(EIF_REFERENCE *)(RTCW(Result));
							F1119_6783(RTCW(tr1), ((EIF_INTEGER_32) 5L), ((EIF_INTEGER_32) 0L));
							break;
						case 1L:
							tr1 = *(EIF_REFERENCE *)(RTCW(Result));
							F1119_6783(RTCW(tr1), ((EIF_INTEGER_32) 4L), ((EIF_INTEGER_32) 0L));
							break;
						default:
							tr1 = *(EIF_REFERENCE *)(RTCW(Result));
							F1119_6783(RTCW(tr1), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 0L));
							break;
					}
				}
				tb4 = F1748_15568(RTCW(loc1));
				if (tb4) {
					F1748_15606(RTCW(Result), (EIF_INTEGER_32) (loc9 - (EIF_INTEGER_32) (loc10 + loc4)));
				} else {
					F1748_15606(RTCW(Result), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) - (EIF_INTEGER_32) (loc10 + loc4)));
				}
				break;
			case 2L:
				F1748_15606(RTCW(Result), ((EIF_INTEGER_32) 0L));
				break;
			default:
				Result = (EIF_REFERENCE) loc3;
				if (loc15) {
					Result = RTLNSMART(dftype);
					F1748_15533(RTCW(Result), Current);
				} else {
					loc8 = eif_min_int32 (loc9,loc10);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_0_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_0_);
					loc11 = eif_min_int32 (ti4_1,ti4_2);
					loc11 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 - loc11);
					tb4 = F1748_15568(RTCW(Result));
					if (tb4) {
						if (loc16) {
							loc8 = (EIF_INTEGER_32) loc9;
						} else {
							if ((EIF_BOOLEAN) (loc8 >= ((EIF_INTEGER_32) 0L))) {
								loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
							} else {
								loc8 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
								loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 - (EIF_INTEGER_32) (loc10 + loc4));
							}
						}
					} else {
						if ((EIF_BOOLEAN)(loc11 != ((EIF_INTEGER_32) 0L))) {
							tr1 = *(EIF_REFERENCE *)(RTCW(Result));
							ti4_1 = eif_abs_int32 (loc11);
							F1119_6791(RTCW(tr1), ti4_1);
						}
					}
					F1748_15606(RTCW(Result), loc8);
				}
				break;
		}
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.do_rescale_special */
void F1748_15649 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (F1748_15566(Current)) {
	} else {
		if (F1748_15565(Current)) {
			tr1 = RTMS_EX_H("sNaN as operand in rescale",26,767991653);
			F1775_16288(RTCW(arg1), ((EIF_INTEGER_32) 3L), tr1);
			F1748_15615(Current);
		} else {
			if (F1748_15567(Current)) {
			}
		}
	}
	RTLE;
}

/* {MA_DECIMAL}.to_string_general */
EIF_REFERENCE F1748_15650 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1111_6438(RTCW(Result), ((EIF_INTEGER_32) 0L));
	if (F1748_15564(Current)) {
		if (F1748_15566(Current)) {
			tr1 = RTMS_EX_H("NaN",3,5136718);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
		} else {
			if (F1748_15565(Current)) {
				tr1 = RTMS_EX_H("sNaN",4,1934516558);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
			} else {
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
					tr1 = RTMS_EX_H("-",1,45);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
				}
				tr1 = RTMS_EX_H("Infinity",8,1600908409);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
			}
		}
	} else {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
			tr1 = RTMS_EX_H("-",1,45);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
		}
		loc1 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = F1748_15580(Current);
		F1111_6438(RTCW(loc1), ti4_1);
		loc3 = F1748_15580(Current);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) break;
			tr1 = RTOSCF(6771,F1118_6771, (Current));
			ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '0');
			tr2 = *(EIF_REFERENCE *)(Current);
			ti4_2 = F1119_6774(RTCW(tr2), loc3);
			tc1 = F1174_8726(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ti4_2));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5181[Dtype(RTCW(loc1))-1112])(loc1, tc1);
			loc3--;
		}
		loc5 = F1748_15555(Current);
		loc9 = '\0';
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) <= ((EIF_INTEGER_32) 0L))) {
			loc9 = (EIF_BOOLEAN) (F1748_15555(Current) >= ((EIF_INTEGER_32) -6L));
		}
		loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc9;
		if (loc9) {
			loc6 = (EIF_INTEGER_32) loc5;
			if (arg1) {
				for (;;) {
					if ((EIF_BOOLEAN)((EIF_INTEGER_32) (loc6 % ((EIF_INTEGER_32) 3L)) == ((EIF_INTEGER_32) 0L))) break;
					loc6--;
				}
				loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - loc6);
				if ((EIF_BOOLEAN) !F1748_15568(Current)) {
					loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + loc7);
					for (;;) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						if ((EIF_BOOLEAN) (ti4_1 >= loc8)) break;
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5181[Dtype(RTCW(loc1))-1112])(loc1, (EIF_CHARACTER_8) '0');
					}
				} else {
					loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				}
			} else {
				loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			}
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_2 > loc8)) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, ((EIF_INTEGER_32) 1L), loc8);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5181[Dtype(RTCW(Result))-1112])(Result, (EIF_CHARACTER_8) '.');
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)), ti4_2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
			} else {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, loc1);
			}
			if ((EIF_BOOLEAN)(loc6 != ((EIF_INTEGER_32) 0L))) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5181[Dtype(RTCW(Result))-1112])(Result, (EIF_CHARACTER_8) 'E');
				if ((EIF_BOOLEAN) (loc5 < ((EIF_INTEGER_32) 0L))) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5181[Dtype(RTCW(Result))-1112])(Result, (EIF_CHARACTER_8) '-');
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5181[Dtype(RTCW(Result))-1112])(Result, (EIF_CHARACTER_8) '+');
				}
				ti4_2 = eif_abs_int32 (loc6);
				tr1 = eif_out__i4_s1(ti4_2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
			}
		} else {
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) < ((EIF_INTEGER_32) 0L))) {
				ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
				loc4 = eif_abs_int32 (ti4_2);
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (loc4 > ti4_2)) {
					loc2 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					F1111_6439(RTCW(loc2), (EIF_CHARACTER_8) '0', (EIF_INTEGER_32) (loc4 - ti4_2));
					tr1 = RTMS_EX_H("0.",2,12334);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, loc1);
				} else {
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(loc4 == ti4_2)) {
						tr1 = RTMS_EX_H("0.",2,12334);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, loc1);
					} else {
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_2 - loc4));
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
						tr1 = RTMS_EX_H(".",1,46);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						ti4_3 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(loc1))-1111])(loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 - loc4) + ((EIF_INTEGER_32) 1L)), ti4_3);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
					}
				}
			} else {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, loc1);
			}
		}
	}
	RTLE;
	return Result;
}

/* {MA_DECIMAL}.parser */
static EIF_REFERENCE F1748_15651_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (15651);
#define Result RTOSR(15651)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1170, 0x01).id, 1170, _OBJSIZ_2_2_0_10_0_0_0_1_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15651);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1748_15651 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15651,F1748_15651_body,(Current));
}

/* {MA_DECIMAL}.once_zero */
static EIF_REFERENCE F1748_15652_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (15652);
#define Result RTOSR(15652)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1748_15534(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15652);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1748_15652 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15652,F1748_15652_body,(Current));
}

/* {MA_DECIMAL}.once_one */
static EIF_REFERENCE F1748_15653_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (15653);
#define Result RTOSR(15653)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1747, 0x01).id, 1747, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1748_15535(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15653);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1748_15653 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15653,F1748_15653_body,(Current));
}

/* {MA_DECIMAL}.special_coefficient */
static EIF_REFERENCE F1748_15654_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (15654);
#define Result RTOSR(15654)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1118, 0x01).id, 1118, _OBJSIZ_1_0_0_2_0_0_0_0_);
	F1119_6772(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	Result = (EIF_REFERENCE) tr1;
	F1119_6783(RTCW(Result), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	RTOSE (15654);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1748_15654 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15654,F1748_15654_body,(Current));
}

void EIF_Minit821 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
