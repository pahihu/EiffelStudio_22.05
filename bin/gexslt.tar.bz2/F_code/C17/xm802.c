/*
 * Code for class XM_XPATH_RECEIVER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm802.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_RECEIVER}.mark_as_written */
void F1729_15248 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O11859[Dtype(Current)-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_XPATH_RECEIVER}.set_document_uri */
void F1729_15263 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O11855[Dtype(Current)-1728]) = (EIF_REFERENCE) arg1;
}

/* {XM_XPATH_RECEIVER}.set_base_uri */
void F1729_15264 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O11856[Dtype(Current)-1728]) = (EIF_REFERENCE) arg1;
}

/* {XM_XPATH_RECEIVER}.as_builder */
EIF_REFERENCE F1729_15266 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	RTCT0("precondition_is_builder", EX_CHECK);
		RTCF0;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit802 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
