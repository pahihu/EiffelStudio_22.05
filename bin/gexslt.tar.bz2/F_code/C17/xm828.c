/*
 * Code for class XM_XSLT_URI_ESCAPER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm828.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_URI_ESCAPER}.make */
void F1755_15882 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O11856[Dtype(tr1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_) = (EIF_BOOLEAN) arg2;
	tr1 = RTLNSMART(eif_new_type(1399, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTOSCP(15895,F1755_15895, (Current));
	RTLE;
}

/* {XM_XSLT_URI_ESCAPER}.start_element */
void F1755_15883 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_4_0_0_) = (EIF_INTEGER_32) arg1;
	F1734_15320(Current, arg1, arg2, arg3);
	RTLE;
}

/* {XM_XSLT_URI_ESCAPER}.notify_attribute */
void F1755_15884 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F1412_11675(Current, arg4)) {
		tb1 = F1755_15893(Current, arg1);
	}
	if (tb1) {
		tr1 = RTOSCF(6771,F1118_6771, (Current));
		tr2 = RTOSCF(6771,F1118_6771, (Current));
		ti4_1 = F1174_8741(RTCW(tr2), ((EIF_INTEGER_32) 16L));
		loc1 = F1174_8738(RTCW(tr1), arg4, ti4_1);
		tr1 = F1755_15891(Current, arg3);
		tr2 = RTOSCF(6771,F1118_6771, (Current));
		ti4_1 = F1174_8739(RTCW(tr2), loc1, ((EIF_INTEGER_32) 64L));
		F1734_15322(Current, arg1, arg2, tr1, ti4_1);
	} else {
		F1734_15322(Current, arg1, arg2, arg3, arg4);
	}
	RTLE;
}

/* {XM_XSLT_URI_ESCAPER}.url_attributes_set */
static EIF_REFERENCE F1755_15888_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15888);
#define Result RTOSR(15888)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1521,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1521, _OBJSIZ_7_0_0_9_0_0_0_0_);
	}
	F1509_12240(RTCW(tr1), ((EIF_INTEGER_32) 15L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8115,F1125_8115, (Current));
	F1439_11749(RTCW(Result), tr1);
	RTOSE (15888);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1755_15888 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15888,F1755_15888_body,(Current));
}

/* {XM_XSLT_URI_ESCAPER}.url_combinations_set */
static EIF_REFERENCE F1755_15889_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15889);
#define Result RTOSR(15889)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1521,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1521, _OBJSIZ_7_0_0_9_0_0_0_0_);
	}
	F1509_12240(RTCW(tr1), ((EIF_INTEGER_32) 37L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8115,F1125_8115, (Current));
	F1439_11749(RTCW(Result), tr1);
	RTOSE (15889);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1755_15889 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15889,F1755_15889_body,(Current));
}

/* {XM_XSLT_URI_ESCAPER}.unescaped_html_characters */
static EIF_REFERENCE F1755_15890_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15890);
#define Result RTOSR(15890)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1523,1065,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1523, _OBJSIZ_7_0_0_9_0_0_0_0_);
	}
	F1515_12240(RTCW(tr1), ((EIF_INTEGER_32) 95L));
	Result = (EIF_REFERENCE) tr1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 126L))) break;
		tr1 = RTOSCF(6771,F1118_6771, (Current));
		tc1 = F1174_8726(RTCW(tr1), loc1);
		F1518_12345(RTCW(Result), tc1);
		loc1++;
	}
	RTOSE (15890);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1755_15890 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15890,F1755_15890_body,(Current));
}

/* {XM_XSLT_URI_ESCAPER}.escaped_url */
EIF_REFERENCE F1755_15891 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,Result);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = F1400_11533(RTCW(tr1), arg1);
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("\000",1,0);
	tr3 = RTOSCF(4521,F954_4521, (Current));
	tr3 = F1138_8299(RTCW(tr3), loc1);
	tr4 = RTOSCF(15890,F1755_15890, (Current));
	tr3 = F1753_15774(Current, tr3, tr4, (EIF_BOOLEAN) 0);
	Result = F1148_8367(RTCW(tr1), tr2, tr3);
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("\000",1,0);
	tr1 = F1148_8377(RTCW(tr1), Result, tr2);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return (EIF_REFERENCE) F1755_15892(Current, Result);
}

/* {XM_XSLT_URI_ESCAPER}.escaped_xml */
EIF_REFERENCE F1755_15892 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	Result = RTMS_EX_H("",0,0);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(arg1))-852])(arg1, loc1));
		if ((EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) '<')) {
			tr1 = RTMS_EX_H("&lt;",4,644641851);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
		} else {
			if ((EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) '>')) {
				tr1 = RTMS_EX_H("&gt;",4,644314171);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
			} else {
				if ((EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) '&')) {
					tr1 = RTMS_EX_H("&amp;",5,1634853947);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
				} else {
					if ((EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) '\"')) {
						tr1 = RTMS_EX_H("&quot;",6,2045817403);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(Result))-1112])(Result, tr1);
					} else {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5181[Dtype(RTCW(Result))-1112])(Result, loc3);
					}
				}
			}
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_URI_ESCAPER}.is_url_attribute */
EIF_BOOLEAN F1755_15893 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTOSCF(4950,F991_4950, (Current));
	tr2 = F1242_10448(RTCW(tr2), arg1);
	tr3 = RTOSCF(9820,F1230_9820, (Current));
	tb1 = F1148_8369(RTCW(tr1), tr2, tr3);
	if (tb1) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(4950,F991_4950, (Current));
		tr2 = F1242_10448(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_4_0_0_));
		tr3 = F1755_15894(Current);
		tb1 = F1148_8369(RTCW(tr1), tr2, tr3);
		if (tb1) {
			tr1 = RTOSCF(4950,F991_4950, (Current));
			loc1 = F1242_10450(RTCW(tr1), arg1);
			tr1 = RTOSCF(15888,F1755_15888, (Current));
			tb1 = F1516_12336(RTCW(tr1), loc1);
			if (tb1) {
				tr1 = RTOSCF(15889,F1755_15889, (Current));
				tr2 = RTOSCF(4950,F991_4950, (Current));
				tr2 = F1242_10450(RTCW(tr2), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_4_0_0_));
				tr3 = RTMS_EX_H("+",1,43);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr2))-1111])(tr2, tr3);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr2))-1111])(tr2, loc1);
				Result = F1516_12336(RTCW(tr1), tr2);
			}
		}
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_URI_ESCAPER}.html_uri */
EIF_REFERENCE F1755_15894 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_)) {
		RTLE;
		return (EIF_REFERENCE) RTOSCF(9828,F1230_9828, (Current));
	} else {
		RTLE;
		return (EIF_REFERENCE) RTOSCF(9820,F1230_9820, (Current));
	}/* NOTREACHED */
	
}

/* {XM_XSLT_URI_ESCAPER}.make_url_attributes */
static void F1755_15895_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15895);
	tr1 = RTMS_EX_H("form",4,1718579821);
	tr2 = RTMS_EX_H("action",6,2144536942);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("body",4,1651467385);
	tr2 = RTMS_EX_H("background",10,1679743332);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("q",1,113);
	tr2 = RTMS_EX_H("cite",4,1667855461);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("blockquote",10,560390757);
	tr2 = RTMS_EX_H("cite",4,1667855461);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("del",3,6579564);
	tr2 = RTMS_EX_H("cite",4,1667855461);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("ins",3,6909555);
	tr2 = RTMS_EX_H("cite",4,1667855461);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("object",6,2004017012);
	tr2 = RTMS_EX_H("classid",7,438841188);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("object",6,2004017012);
	tr2 = RTMS_EX_H("codebase",8,1904401253);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("applet",6,2077721972);
	tr2 = RTMS_EX_H("codebase",8,1904401253);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("object",6,2004017012);
	tr2 = RTMS_EX_H("data",4,1684108385);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("object",6,2004017012);
	tr2 = RTMS_EX_H("datasrc",7,618689123);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("button",6,2147362158);
	tr2 = RTMS_EX_H("datasrc",7,618689123);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("div",3,6580598);
	tr2 = RTMS_EX_H("datasrc",7,618689123);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("input",5,1853670260);
	tr2 = RTMS_EX_H("datasrc",7,618689123);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("select",6,2045458804);
	tr2 = RTMS_EX_H("datasrc",7,618689123);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("span",4,1936744814);
	tr2 = RTMS_EX_H("datasrc",7,618689123);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("table",5,1634731109);
	tr2 = RTMS_EX_H("datasrc",7,618689123);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("textarea",8,1193882977);
	tr2 = RTMS_EX_H("datasrc",7,618689123);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("a",1,97);
	tr2 = RTMS_EX_H("href",4,1752327526);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("a",1,97);
	tr2 = RTMS_EX_H("name",4,1851878757);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("area",4,1634887009);
	tr2 = RTMS_EX_H("href",4,1752327526);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("link",4,1818848875);
	tr2 = RTMS_EX_H("href",4,1752327526);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("base",4,1650553701);
	tr2 = RTMS_EX_H("href",4,1752327526);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("img",3,6909287);
	tr2 = RTMS_EX_H("longdesc",8,1959967587);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("frame",5,1919770981);
	tr2 = RTMS_EX_H("longdesc",8,1959967587);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("iframe",6,2126209381);
	tr2 = RTMS_EX_H("longdesc",8,1959967587);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("head",4,1751474532);
	tr2 = RTMS_EX_H("profile",7,332661605);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("script",6,2146372212);
	tr2 = RTMS_EX_H("src",3,7565923);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("script",6,2146372212);
	tr2 = RTMS_EX_H("for",3,6713202);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("input",5,1853670260);
	tr2 = RTMS_EX_H("src",3,7565923);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("frame",5,1919770981);
	tr2 = RTMS_EX_H("src",3,7565923);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("iframe",6,2126209381);
	tr2 = RTMS_EX_H("src",3,7565923);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("img",3,6909287);
	tr2 = RTMS_EX_H("src",3,7565923);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("img",3,6909287);
	tr2 = RTMS_EX_H("usemap",6,1932581744);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("input",5,1853670260);
	tr2 = RTMS_EX_H("usemap",6,1932581744);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("object",6,2004017012);
	tr2 = RTMS_EX_H("usemap",6,1932581744);
	F1755_15896(Current, tr1, tr2);
	tr1 = RTMS_EX_H("object",6,2004017012);
	tr2 = RTMS_EX_H("archive",7,1406298469);
	F1755_15896(Current, tr1, tr2);
	RTOSE (15895);
	RTLE;
	RTEE;
#undef Result
}

void F1755_15895 (EIF_REFERENCE Current)
{
	GTCX
	RTOSCP(15895,F1755_15895_body,(Current));
}

/* {XM_XSLT_URI_ESCAPER}.set_url_attribute */
void F1755_15896 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(15888,F1755_15888, (Current));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(arg2))-1112])(arg2);
	tb1 = F1516_12336(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(15888,F1755_15888, (Current));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(arg2))-1112])(arg2);
		F1516_12342(RTCW(tr1), tr2);
	}
	tr1 = RTOSCF(15889,F1755_15889, (Current));
	tr2 = RTMS_EX_H("+",1,43);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(arg1))-1111])(arg1, tr2);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr2))-1111])(tr2, arg2);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(tr2))-1112])(tr2);
	F1516_12342(RTCW(tr1), tr2);
	RTLE;
}

void EIF_Minit828 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
