/*
 * Code for class XM_XSLT_XHTML_INDENTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm819.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_XHTML_INDENTER}.tag_properties */
EIF_INTEGER_32 F1746_15498 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(4950,F991_4950, (Current));
	ti4_1 = F1242_10447(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 8L))) {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		loc3 = F1242_10450(RTCW(tr1), arg1);
		tr1 = RTOSCF(15492,F1745_15492, (Current));
		loc2 = F1516_12336(RTCW(tr1), loc3);
		tr1 = RTOSCF(15493,F1745_15493, (Current));
		loc1 = F1516_12336(RTCW(tr1), loc3);
		if (loc2) {
			Result += ((EIF_INTEGER_32) 1L);
		}
		if (loc1) {
			RTLE;
			return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 2L));
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit819 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
