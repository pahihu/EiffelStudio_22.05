/*
 * Code for class XM_XSLT_CONFIGURATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm823.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_CONFIGURATION}.make */
void F1750_15681 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg6);
	RTLR(3,arg5);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLR(6,arg3);
	RTLR(7,arg4);
	RTLIU(8);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(36, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN)(arg6 == NULL)) {
		tr1 = RTLNSMART(eif_new_type(1580, 1).id);
		F1581_13010(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	} else {
		RTAR(Current, arg6);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg6;
	}
	F1749_15655(Current);
	RTAR(Current, arg5);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg5;
	F1408_11616(Current);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) arg3;
	F1750_15724(Current, arg4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2019[Dtype(RTCW(tr1))-1125])(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1620,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12163(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1254, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_17_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XSLT_CONFIGURATION}.make_with_defaults */
void F1750_15682 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc5);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	loc3 = F1725_15199(Current);
	loc2 = RTLNS(eif_new_type(1253, 0x01).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTLNSMART(eif_new_type(1580, 1).id);
	F1581_13009(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(1563, 0x01).id, 1563, _OBJSIZ_2_2_0_6_0_0_0_0_);
	F1564_12766(RTCW(loc1), ((EIF_INTEGER_32) 2L), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	loc5 = RTLNS(eif_new_type(1196, 0x01).id, 1196, _OBJSIZ_0_1_0_0_0_0_0_0_);
	loc4 = RTLNS(eif_new_type(1197, 0x01).id, 1197, _OBJSIZ_6_0_0_0_0_0_0_0_);
	F1198_8948(RTCW(loc4), loc5);
	F1750_15681(Current, loc3, loc3, loc4, loc1, loc2, *(EIF_REFERENCE *)(Current + _REFACS_7_));
	RTLE;
}

/* {XM_XSLT_CONFIGURATION}.is_tracing */
EIF_BOOLEAN F1750_15697 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_6_) != NULL);
}

/* {XM_XSLT_CONFIGURATION}.default_media_type */
static EIF_REFERENCE F1750_15701_body (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (15701);
#define Result RTOSR(15701)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1705, 0x01).id, 1705, _OBJSIZ_3_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("application",11,1097909614);
	tr3 = RTMS_EX_H("xml",3,7892332);
	F1706_14576(RTCW(tr1), tr2, tr3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15701);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1750_15701 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	return RTOSCF(15701,F1750_15701_body,(Current,arg1));
}

/* {XM_XSLT_CONFIGURATION}.is_uri_written */
EIF_BOOLEAN F1750_15710 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	Result = F1525_12411(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {XM_XSLT_CONFIGURATION}.new_message_emitter */
EIF_REFERENCE F1750_15711 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	Result = F37_421(RTCW(tr1), arg1, arg2);
	RTLE;
	return Result;
}

/* {XM_XSLT_CONFIGURATION}.force_explaining */
void F1750_15712 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_17_9_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_XSLT_CONFIGURATION}.set_warns_on_default_action */
void F1750_15713 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_17_7_) = (EIF_BOOLEAN) arg1;
	if (arg1) {
		F1750_15714(Current, (EIF_BOOLEAN) 0);
	}
	RTLE;
}

/* {XM_XSLT_CONFIGURATION}.set_default_action_suppressed */
void F1750_15714 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_17_8_) = (EIF_BOOLEAN) arg1;
	if (arg1) {
		F1750_15713(Current, (EIF_BOOLEAN) 0);
	}
	RTLE;
}

/* {XM_XSLT_CONFIGURATION}.add_extension_function_library */
void F1750_15715 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	F1506_12183(RTCW(tr1), arg1);
	RTLE;
}

/* {XM_XSLT_CONFIGURATION}.reset_entity_resolver */
void F1750_15716 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F254_2126(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_16_));
	RTLE;
}

/* {XM_XSLT_CONFIGURATION}.set_line_numbering */
void F1750_15717 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_17_2_) = (EIF_BOOLEAN) arg1;
}

/* {XM_XSLT_CONFIGURATION}.set_trace_listener */
void F1750_15718 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
}

/* {XM_XSLT_CONFIGURATION}.set_recovery_policy */
void F1750_15723 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	F372_3196(RTCW(tr1), arg1);
	RTLE;
}

/* {XM_XSLT_CONFIGURATION}.set_error_listener */
void F1750_15724 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) arg1;
}

/* {XM_XSLT_CONFIGURATION}.use_tiny_tree_model */
void F1750_15725 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_17_3_) = (EIF_BOOLEAN) arg1;
}

/* {XM_XSLT_CONFIGURATION}.report_tiny_tree_statistics */
void F1750_15726 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_17_4_) = (EIF_BOOLEAN) arg1;
}

/* {XM_XSLT_CONFIGURATION}.do_not_assume_xhtml */
void F1750_15727 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_17_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {XM_XSLT_CONFIGURATION}.trace */
void F1750_15728 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	RTCT0("precondition_tracing_enabled", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tb1 = *(EIF_BOOLEAN *)(loc1+ _CHROFF_2_1_);
	if (tb1) {
		F1233_10180(loc1, arg1, arg2);
	}
	RTLE;
}

/* {XM_XSLT_CONFIGURATION}.set_final_execution_phase */
void F1750_15729 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_17_11_0_1_) = (EIF_INTEGER_32) arg1;
}

/* {XM_XSLT_CONFIGURATION}.set_tiny_tree_estimates */
void F1750_15730 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_17_11_0_2_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_17_11_0_3_) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_17_11_0_4_) = (EIF_INTEGER_32) arg3;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_17_11_0_5_) = (EIF_INTEGER_32) arg4;
	RTLE;
}

/* {XM_XSLT_CONFIGURATION}.suppress_dtd */
void F1750_15731 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_17_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_XSLT_CONFIGURATION}.set_timing */
void F1750_15732 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_17_5_) = (EIF_BOOLEAN) arg1;
}

/* {XM_XSLT_CONFIGURATION}.element_validator */
EIF_REFERENCE F1750_15733 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	
	
	return (EIF_REFERENCE) arg1;
}

/* {XM_XSLT_CONFIGURATION}.document_validator */
EIF_REFERENCE F1750_15734 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	return (EIF_REFERENCE) arg1;
}

void EIF_Minit823 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
