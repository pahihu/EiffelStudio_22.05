/*
 * Code for class UT_VERSION_NUMBER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut844.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_VERSION_NUMBER}.make */
void F1771_16245 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(16241,F1769_16241, (Current));
	F880_4366(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	F880_4390(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {UT_VERSION_NUMBER}.default_template */

EIF_REFERENCE F1771_16246 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (16246,RTMS_EX_H("$0 version $1",13,1723896113));
}

void EIF_Minit844 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
