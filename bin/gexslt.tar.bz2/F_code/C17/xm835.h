
#ifndef _C17_xm835_
#define _C17_xm835_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1762_16035(EIF_REFERENCE);
extern void EIF_Minit835(void);
extern void F1759_15952(EIF_REFERENCE);
extern void F1759_15983(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
