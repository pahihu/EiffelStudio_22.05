/*
 * Code for class XM_XSLT_XML_EMITTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm832.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_XML_EMITTER}.make */
void F1759_15947 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg3;
	*(EIF_BOOLEAN *)(Current + O12442[dtype-1758]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1502,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1503_12129(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1439_11749(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,879,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F880_4366(RTCW(tr1), NULL, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O12451[dtype-1758]) - ((EIF_INTEGER_32) 1L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTOSCP(15981,F1759_15981, (Current));
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F2152_21392(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.as_xml_emitter */
EIF_REFERENCE F1759_15949 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {XM_XSLT_XML_EMITTER}.open */
void F1759_15950 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O11857[Dtype(Current)-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_XSLT_XML_EMITTER}.start_document */
void F1759_15951 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O11858[Dtype(Current)-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_XSLT_XML_EMITTER}.end_document */
void F1759_15952 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O11858[Dtype(Current)-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {XM_XSLT_XML_EMITTER}.close */
void F1759_15953 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O12440[dtype-1758])) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11903[dtype-1731]))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R12465[dtype-1758])(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
		F1591_13204(RTCW(tr1));
	}
	*(EIF_BOOLEAN *)(Current + O11857[dtype-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.start_element */
void F1759_15954 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLR(6,loc1);
	RTLR(7,loc5);
	RTLR(8,loc2);
	RTLR(9,loc3);
	RTLIU(10);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O12440[dtype-1758])) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R12465[dtype-1758])(Current);
		}
		tb1 = '\0';
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O12439[dtype-1758]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O12442[dtype-1758]))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tb2 = F1418_11697(RTCW(tr1));
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
			tr3 = RTMS_EX_H("More than one document element present",38,542946676);
			tr4 = RTOSCF(9827,F1230_9827, (Current));
			tr5 = RTMS_EX_H("SEPM0004",8,1354625588);
			F1709_14669(RTCW(tr2), tr3, tr4, tr5, ((EIF_INTEGER_32) 3L));
			F1710_14691(RTCW(tr1), tr2);
		}
		if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current + O12451[dtype-1758]))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc1 = F880_4371(RTCW(tr1), arg1);
		}
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			tr1 = RTOSCF(4950,F991_4950, (Current));
			loc1 = F1242_10452(RTCW(tr1), arg1);
			if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current + O12451[dtype-1758]))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
				F880_4390(RTCW(tr1), loc1, arg1);
			}
			loc4 = F1759_15991(Current, loc1);
			if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
				tr1 = RTMS_EX_H("Element name contains a character (decimal",42,2137700716);
				tr2 = eif_out__i4_s1(loc4);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr1)-1111])(tr1, tr2);
				tr2 = RTMS_EX_H(") not available in the selected encoding",40,1360477031);
				loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tr2 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
				tr3 = RTOSCF(9827,F1230_9827, (Current));
				tr4 = RTMS_EX_H("SERE0008",8,1358496312);
				F1709_14669(RTCW(tr2), loc5, tr3, tr4, ((EIF_INTEGER_32) 3L));
				F1710_14691(RTCW(tr1), tr2);
			}
		}
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			F1503_12140(RTCW(tr1), loc1);
			*(EIF_INTEGER_32 *)(Current + O12447[dtype-1758]) = (EIF_INTEGER_32) arg1;
			if (*(EIF_BOOLEAN *)(Current + O12442[dtype-1758])) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_8_);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_7_);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					*(EIF_BOOLEAN *)(Current + O12439[dtype-1758]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					F1759_15990(Current, loc1, loc2, loc3);
				}
				*(EIF_BOOLEAN *)(Current + O12442[dtype-1758]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			if (*(EIF_BOOLEAN *)(Current + O12443[dtype-1758])) {
				F1759_15992(Current, loc1, (EIF_BOOLEAN) 0);
			}
			tr1 = RTMS_EX_H("<",1,60);
			F1759_15983(Current, tr1);
			F1759_15983(Current, loc1);
			*(EIF_BOOLEAN *)(Current + O12443[dtype-1758]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	F1729_15248(Current);
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.notify_namespace */
void F1759_15955 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,tr2);
	RTLR(6,loc5);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O12440[dtype-1758]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731]))) {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		loc1 = F1242_10455(RTCW(tr1), arg1);
		tr1 = RTOSCF(4950,F991_4950, (Current));
		loc2 = F1242_10453(RTCW(tr1), arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			tr1 = RTMS_EX_H(" ",1,32);
			F1759_15983(Current, tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(Current + O12447[dtype-1758]);
			tr1 = RTMS_EX_H("xmlns",5,1836744307);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R12461[dtype-1758])(Current, ti4_1, tr1, loc2, ((EIF_INTEGER_32) 0L));
		} else {
			loc3 = F1759_15991(Current, loc1);
			if ((EIF_BOOLEAN)(loc3 != ((EIF_INTEGER_32) 0L))) {
				tr1 = RTMS_EX_H("Namespace prefix contains a character (decimal + ",49,2101806880);
				tr2 = eif_out__i4_s1(loc3);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr1)-1111])(tr1, tr2);
				tr2 = RTMS_EX_H(") not available in the selected encoding",40,1360477031);
				loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
				loc5 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
				tr1 = RTOSCF(9827,F1230_9827, (Current));
				tr2 = RTMS_EX_H("SERE0008",8,1358496312);
				F1709_14669(RTCW(loc5), loc4, tr1, tr2, ((EIF_INTEGER_32) 3L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				F1710_14691(RTCW(tr1), loc5);
			} else {
				tb1 = '\01';
				if (!*(EIF_BOOLEAN *)(Current + O12449[dtype-1758])) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
					tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
				}
				if (tb1) {
					tr1 = RTMS_EX_H(" ",1,32);
					F1759_15983(Current, tr1);
					ti4_1 = *(EIF_INTEGER_32 *)(Current + O12447[dtype-1758]);
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTMS_EX_H("xmlns:",6,2055944506);
					tr1 = F1148_8367(RTCW(tr1), tr2, loc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R12461[dtype-1758])(Current, ti4_1, tr1, loc2, ((EIF_INTEGER_32) 0L));
				}
			}
		}
	}
	F1729_15248(Current);
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.notify_attribute */
void F1759_15956 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLR(5,loc4);
	RTLR(6,arg3);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O12440[dtype-1758]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731]))) {
		if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current + O12451[dtype-1758]))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc1 = F880_4371(RTCW(tr1), arg1);
		}
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			tr1 = RTOSCF(4950,F991_4950, (Current));
			loc1 = F1242_10452(RTCW(tr1), arg1);
			if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current + O12451[dtype-1758]))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
				F880_4390(RTCW(tr1), loc1, arg1);
			}
			loc2 = F1759_15991(Current, loc1);
			if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L))) {
				tr1 = RTMS_EX_H("Attribute name contains a character (decimal + ",47,1630020128);
				tr2 = eif_out__i4_s1(loc2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr1)-1111])(tr1, tr2);
				tr2 = RTMS_EX_H(") not available in the selected encoding",40,1360477031);
				loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
				loc4 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
				tr1 = RTOSCF(9827,F1230_9827, (Current));
				tr2 = RTMS_EX_H("SERE0008",8,1358496312);
				F1709_14669(RTCW(loc4), loc3, tr1, tr2, ((EIF_INTEGER_32) 3L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				F1710_14691(RTCW(tr1), loc4);
			}
		}
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
			tr1 = RTMS_EX_H(" ",1,32);
			F1759_15983(Current, tr1);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R12461[dtype-1758])(Current, *(EIF_INTEGER_32 *)(Current + O12447[dtype-1758]), loc1, arg3, arg4);
			}
		}
	}
	F1729_15248(Current);
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.start_content */
void F1759_15957 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1729_15248(Current);
}

/* {XM_XSLT_XML_EMITTER}.end_element */
void F1759_15958 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O12440[dtype-1758]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731]))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = F1503_12132(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F1503_12144(RTCW(tr1));
		if (*(EIF_BOOLEAN *)(Current + O12443[dtype-1758])) {
			F1759_15992(Current, loc1, (EIF_BOOLEAN) 1);
		} else {
			tr1 = RTMS_EX_H("</",2,15407);
			F1759_15983(Current, tr1);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
				F1759_15983(Current, loc1);
			}
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
				tr1 = RTMS_EX_H(">",1,62);
				F1759_15983(Current, tr1);
			}
		}
	}
	F1729_15248(Current);
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.notify_characters */
void F1759_15959 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O12440[dtype-1758])) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R12465[dtype-1758])(Current);
			if ((EIF_BOOLEAN) !F1629_13679(Current, arg1)) {
				tb1 = '\01';
				if (!*(EIF_BOOLEAN *)(Current + O12439[dtype-1758])) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_8_);
					tb1 = (EIF_BOOLEAN)(tr1 != NULL);
				}
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
					tr2 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
					tr3 = RTMS_EX_H("Topl-level text node present when well-formed document is required",66,848761956);
					tr4 = RTOSCF(9827,F1230_9827, (Current));
					tr5 = RTMS_EX_H("SEPM0004",8,1354625588);
					F1709_14669(RTCW(tr2), tr3, tr4, tr5, ((EIF_INTEGER_32) 3L));
					F1710_14691(RTCW(tr1), tr2);
				}
			}
		}
		tb1 = '\0';
		tb2 = '\0';
		if (*(EIF_BOOLEAN *)(Current + O12439[dtype-1758])) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tb3 = F1418_11697(RTCW(tr1));
			tb2 = tb3;
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN) !F1629_13679(Current, arg1);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
			tr3 = RTMS_EX_H("Topl-level text node present when well-formed document is required",66,848761956);
			tr4 = RTOSCF(9827,F1230_9827, (Current));
			tr5 = RTMS_EX_H("SEPM0004",8,1354625588);
			F1709_14669(RTCW(tr2), tr3, tr4, tr5, ((EIF_INTEGER_32) 3L));
			F1710_14691(RTCW(tr1), tr2);
		}
		if (*(EIF_BOOLEAN *)(Current + O12443[dtype-1758])) {
			tr1 = RTMS_EX_H("",0,0);
			F1759_15992(Current, tr1, (EIF_BOOLEAN) 0);
		}
		if (F1412_11673(Current, arg2)) {
			F1759_15983(Current, arg1);
		} else {
			if ((EIF_BOOLEAN) !F1412_11675(Current, arg2)) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R12462[dtype-1758])(Current, arg1, (EIF_BOOLEAN) 0);
			} else {
				loc1 = F1759_15991(Current, arg1);
				if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
					F1759_15983(Current, arg1);
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R12462[dtype-1758])(Current, arg1, (EIF_BOOLEAN) 0);
				}
			}
		}
	}
	F1729_15248(Current);
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.notify_processing_instruction */
void F1759_15960 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc4);
	RTLR(6,loc1);
	RTLR(7,arg2);
	RTLIU(8);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O12440[dtype-1758])) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R12465[dtype-1758])(Current);
		}
		if (*(EIF_BOOLEAN *)(Current + O12443[dtype-1758])) {
			tr1 = RTMS_EX_H("",0,0);
			F1759_15992(Current, tr1, (EIF_BOOLEAN) 0);
		}
		loc3 = F1759_15991(Current, arg1);
		if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
			tr1 = RTMS_EX_H("Processing instruction target contains a character (decimal",59,856589932);
			tr2 = eif_out__i4_s1(loc3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr1)-1111])(tr1, tr2);
			tr2 = RTMS_EX_H(") not available in the selected encoding",40,1360477031);
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
			loc4 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
			tr1 = RTOSCF(9827,F1230_9827, (Current));
			tr2 = RTMS_EX_H("SERE0008",8,1358496312);
			F1709_14669(RTCW(loc4), loc2, tr1, tr2, ((EIF_INTEGER_32) 3L));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			F1710_14691(RTCW(tr1), loc4);
		} else {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("<\?",2,15423);
			loc1 = F1148_8367(RTCW(tr1), tr2, arg1);
			loc3 = F1759_15991(Current, arg2);
			if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
				tr1 = RTMS_EX_H("Processing instruction data contains a character (decimal",57,1754374764);
				tr2 = eif_out__i4_s1(loc3);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr1)-1111])(tr1, tr2);
				tr2 = RTMS_EX_H(") not available in the selected encoding",40,1360477031);
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
				loc4 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
				tr1 = RTOSCF(9827,F1230_9827, (Current));
				tr2 = RTMS_EX_H("SERE0008",8,1358496312);
				F1709_14669(RTCW(loc4), loc2, tr1, tr2, ((EIF_INTEGER_32) 3L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				F1710_14691(RTCW(tr1), loc4);
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTMS_EX_H(" ",1,32);
					tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
					loc1 = (EIF_REFERENCE) tr1;
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr1 = F1148_8377(RTCW(tr1), loc1, arg2);
					loc1 = (EIF_REFERENCE) tr1;
				}
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H("\?>",2,16190);
				tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
				loc1 = (EIF_REFERENCE) tr1;
				F1759_15983(Current, loc1);
			}
		}
	}
	F1729_15248(Current);
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.notify_comment */
void F1759_15961 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O12440[dtype-1758])) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R12465[dtype-1758])(Current);
		}
		if (*(EIF_BOOLEAN *)(Current + O12443[dtype-1758])) {
			tr1 = RTMS_EX_H("",0,0);
			F1759_15992(Current, tr1, (EIF_BOOLEAN) 0);
		}
		tr1 = RTMS_EX_H("<!--",4,1008807213);
		F1759_15983(Current, tr1);
		loc1 = F1759_15991(Current, arg1);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = RTMS_EX_H("Comment contains a character (decimal",37,1376079468);
			tr2 = eif_out__i4_s1(loc1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr1)-1111])(tr1, tr2);
			tr2 = RTMS_EX_H(") not available in the selected encoding",40,1360477031);
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
			loc3 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
			tr1 = RTOSCF(9827,F1230_9827, (Current));
			tr2 = RTMS_EX_H("SERE0008",8,1358496312);
			F1709_14669(RTCW(loc3), loc2, tr1, tr2, ((EIF_INTEGER_32) 3L));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			F1710_14691(RTCW(tr1), loc3);
		} else {
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
				F1759_15983(Current, arg1);
			}
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
				tr1 = RTMS_EX_H("-->",3,2960702);
				F1759_15983(Current, tr1);
			}
		}
	}
	F1729_15248(Current);
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.empty_tags_set */
static EIF_REFERENCE F1759_15977_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15977);
#define Result RTOSR(15977)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1521,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1521, _OBJSIZ_7_0_0_9_0_0_0_0_);
	}
	F1509_12240(RTCW(tr1), ((EIF_INTEGER_32) 13L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(8115,F1125_8115, (Current));
	F1439_11749(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("area",4,1634887009);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("base",4,1650553701);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("basefont",8,1397695860);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("br",2,25202);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("col",3,6516588);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("frame",5,1919770981);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("hr",2,26738);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("img",3,6909287);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("input",5,1853670260);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("isindex",7,1240214136);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("link",4,1818848875);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("meta",4,1835365473);
	F1516_12342(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("param",5,1635746157);
	F1516_12342(RTCW(Result), tr1);
	RTOSE (15977);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1759_15977 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15977,F1759_15977_body,(Current));
}

/* {XM_XSLT_XML_EMITTER}.is_empty_tag */
EIF_BOOLEAN F1759_15978 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(15977,F1759_15977, (Current));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5052[Dtype(RTCW(arg1))-1112])(arg1);
	Result = F1516_12336(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {XM_XSLT_XML_EMITTER}.specials_in_text */
static EIF_REFERENCE F1759_15979_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15979);
#define Result RTOSR(15979)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,883,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 883, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F884_4366(RTCW(tr1), (EIF_BOOLEAN) 0, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 127L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15979);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1759_15979 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15979,F1759_15979_body,(Current));
}

/* {XM_XSLT_XML_EMITTER}.specials_in_attributes */
static EIF_REFERENCE F1759_15980_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15980);
#define Result RTOSR(15980)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,883,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 883, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F884_4366(RTCW(tr1), (EIF_BOOLEAN) 0, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 127L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15980);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1759_15980 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15980,F1759_15980_body,(Current));
}

/* {XM_XSLT_XML_EMITTER}.make_specials */
static void F1759_15981_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (15981);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 32L))) break;
		tr1 = RTOSCF(15979,F1759_15979, (Current));
		F884_4390(RTCW(tr1), (EIF_BOOLEAN) 1, loc1);
		tr1 = RTOSCF(15980,F1759_15980, (Current));
		F884_4390(RTCW(tr1), (EIF_BOOLEAN) 1, loc1);
		loc1++;
	}
	tr1 = RTOSCF(15979,F1759_15979, (Current));
	F884_4390(RTCW(tr1), (EIF_BOOLEAN) 0, ((EIF_INTEGER_32) 9L));
	tr1 = RTOSCF(15979,F1759_15979, (Current));
	F884_4390(RTCW(tr1), (EIF_BOOLEAN) 0, ((EIF_INTEGER_32) 10L));
	tr1 = RTOSCF(15979,F1759_15979, (Current));
	F884_4390(RTCW(tr1), (EIF_BOOLEAN) 1, ((EIF_INTEGER_32) 60L));
	tr1 = RTOSCF(15979,F1759_15979, (Current));
	F884_4390(RTCW(tr1), (EIF_BOOLEAN) 1, ((EIF_INTEGER_32) 62L));
	tr1 = RTOSCF(15979,F1759_15979, (Current));
	F884_4390(RTCW(tr1), (EIF_BOOLEAN) 1, ((EIF_INTEGER_32) 38L));
	tr1 = RTOSCF(15980,F1759_15980, (Current));
	F884_4390(RTCW(tr1), (EIF_BOOLEAN) 1, ((EIF_INTEGER_32) 60L));
	tr1 = RTOSCF(15980,F1759_15980, (Current));
	F884_4390(RTCW(tr1), (EIF_BOOLEAN) 1, ((EIF_INTEGER_32) 62L));
	tr1 = RTOSCF(15980,F1759_15980, (Current));
	F884_4390(RTCW(tr1), (EIF_BOOLEAN) 1, ((EIF_INTEGER_32) 38L));
	tr1 = RTOSCF(15980,F1759_15980, (Current));
	F884_4390(RTCW(tr1), (EIF_BOOLEAN) 1, ((EIF_INTEGER_32) 34L));
	RTOSE (15981);
	RTLE;
	RTEE;
#undef Result
}

void F1759_15981 (EIF_REFERENCE Current)
{
	GTCX
	RTOSCP(15981,F1759_15981_body,(Current));
}

/* {XM_XSLT_XML_EMITTER}.write_declaration */
void F1759_15982 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTCDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLR(8,tr5);
	RTLR(9,loc5);
	RTLIU(10);
	
	RTGC;
	RTCT0("attached outputter as l_outputter", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTCT0("attached encoding as l_encoding", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1640[Dtype(loc3)-1183])(loc3);
	if (tb1) {
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_22_4_);
		if (!tb2) {
			tb2 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tb3 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_22_8_);
			if ((EIF_BOOLEAN) !tb3) {
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1641[Dtype(loc3)-1183])(loc3);
				tb2 = tb3;
			}
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1638[Dtype(loc3)-1183])(loc3);
			F1759_15984(Current, tr1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_22_0_);
	tb1 = '\0';
	if (loc1) {
		tb2 = '\01';
		tb3 = '\01';
		tb4 = '\01';
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("UTF-8",5,1414538040);
		tb5 = F1148_8369(RTCW(tr1), loc4, tr2);
		if (!tb5) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("UTF-16",6,1345128758);
			tb5 = F1148_8369(RTCW(tr1), loc4, tr2);
			tb4 = tb5;
		}
		if (!tb4) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("US-ASCII",8,331147081);
			tb4 = F1148_8369(RTCW(tr1), loc4, tr2);
			tb3 = tb4;
		}
		if (!tb3) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("ASCII",5,1397417801);
			tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
			tb2 = tb3;
		}
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = F1781_16420(RTCW(tr1));
	tb1 = '\0';
	tr1 = RTMS_EX_H("1.0",3,3223088);
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5138[Dtype(RTCW(loc2))-1111])(loc2, tr1);
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_22_2_);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr2 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
		tr3 = RTMS_EX_H("XML version 1.0 does not permit undeclaring namespaces",54,493961587);
		tr4 = RTOSCF(9827,F1230_9827, (Current));
		tr5 = RTMS_EX_H("SEPM0010",8,1354625840);
		F1709_14669(RTCW(tr2), tr3, tr4, tr5, ((EIF_INTEGER_32) 3L));
		F1710_14691(RTCW(tr1), tr2);
	} else {
		if ((EIF_BOOLEAN) !loc1) {
			tb1 = '\01';
			tr1 = RTMS_EX_H("1.0",3,3223088);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5138[Dtype(RTCW(loc2))-1111])(loc2, tr1);
			if (!tb2) {
				tr1 = RTMS_EX_H("1.1",3,3223089);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5138[Dtype(RTCW(loc2))-1111])(loc2, tr1);
				tb1 = tb2;
			}
			if (tb1) {
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tr2 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
				tr3 = RTMS_EX_H("XML version must be 1.0 or 1.1",30,1140430385);
				tr4 = RTOSCF(9827,F1230_9827, (Current));
				tr5 = RTMS_EX_H("SEUS0013",8,1364502323);
				F1709_14669(RTCW(tr2), tr3, tr4, tr5, ((EIF_INTEGER_32) 3L));
				F1710_14691(RTCW(tr1), tr2);
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_33_0_);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = RTMS_EX_H("<\?xml version=\"",15,1919210530);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr1)-1111])(tr1, loc2);
				tr2 = RTMS_EX_H("\" ",2,8736);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
				tr2 = RTMS_EX_H("encoding=\"",10,342553378);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, loc4);
				tr2 = RTMS_EX_H("\"",1,34);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
				F1759_15983(Current, tr1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_6_);
				loc5 = tr1;
				if (EIF_TEST(loc5)) {
					*(EIF_BOOLEAN *)(Current + O12439[dtype-1758]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					tr1 = RTMS_EX_H(" standalone=\"",13,1939783202);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr1)-1111])(tr1, loc5);
					tr2 = RTMS_EX_H("\"",1,34);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
					F1759_15983(Current, tr1);
				}
				tr1 = RTMS_EX_H("\?>",2,16190);
				F1759_15983(Current, tr1);
			}
		} else {
			tb1 = '\0';
			tr1 = RTMS_EX_H("1.0",3,3223088);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5138[Dtype(RTCW(loc2))-1111])(loc2, tr1);
			if ((EIF_BOOLEAN) !tb2) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_8_);
				tb1 = (EIF_BOOLEAN)(tr1 != NULL);
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tr2 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
				tr3 = RTMS_EX_H("XML declaration may not be omitted when version is not 1.0 and a DOCTYPE has been requested",91,1860538724);
				tr4 = RTOSCF(9827,F1230_9827, (Current));
				tr5 = RTMS_EX_H("SEPM0009",8,1354625593);
				F1709_14669(RTCW(tr2), tr3, tr4, tr5, ((EIF_INTEGER_32) 3L));
				F1710_14691(RTCW(tr1), tr2);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_6_);
				if ((EIF_BOOLEAN)(tr1 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
					tr2 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
					tr3 = RTMS_EX_H("XML declaration may not be omitted when standalone=yes",54,1076127859);
					tr4 = RTOSCF(9827,F1230_9827, (Current));
					tr5 = RTMS_EX_H("SEPM0009",8,1354625593);
					F1709_14669(RTCW(tr2), tr3, tr4, tr5, ((EIF_INTEGER_32) 3L));
					F1710_14691(RTCW(tr1), tr2);
				}
			}
		}
	}
	*(EIF_BOOLEAN *)(Current + O12441[dtype-1758]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.output */
void F1759_15983 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	RTCT0("precondition_document_opened", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[Dtype(Current)-1731])) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1644[Dtype(loc2)-1183])(loc2, arg1);
		tb1 = *(EIF_BOOLEAN *)(loc2+ _CHROFF_2_0_);
		if (tb1) {
			tr1 = RTMS_EX_H("Failed to write to output stream",32,1425661805);
			F1732_15293(Current, tr1);
		}
	}
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.output_ignoring_error */
void F1759_15984 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	RTCT0("precondition_is_output_open", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1645[Dtype(loc2)-1183])(loc2, arg1);
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.output_attribute */
void F1759_15985 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
		F1759_15983(Current, arg2);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
			if (F1412_11673(Current, arg4)) {
				tr1 = RTMS_EX_H("=",1,61);
				F1759_15983(Current, tr1);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
					tr1 = RTMS_EX_H("\"",1,34);
					F1759_15983(Current, tr1);
				}
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
					F1759_15983(Current, arg3);
				}
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
					tr1 = RTMS_EX_H("\"",1,34);
					F1759_15983(Current, tr1);
				}
			} else {
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R5131[Dtype(RTCW(arg3))-1111])(arg3, (EIF_CHARACTER_8) '\"', ((EIF_INTEGER_32) 1L));
				if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
					loc1 = RTMS_EX_H("\'",1,39);
				} else {
					loc1 = RTMS_EX_H("\"",1,34);
				}
				tr1 = RTMS_EX_H("=",1,61);
				F1759_15983(Current, tr1);
				F1759_15983(Current, loc1);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R12462[dtype-1758])(Current, arg3, (EIF_BOOLEAN) 1);
				}
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
					F1759_15983(Current, loc1);
				}
			}
		}
	}
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.output_escape */
void F1759_15986 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if (arg2) {
		loc5 = RTOSCF(15980,F1759_15980, (Current));
	} else {
		loc5 = RTOSCF(15979,F1759_15979, (Current));
	}
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc2 > ti4_1)) break;
		loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) R12463[Dtype(Current)-1758])(Current, arg1, loc2, loc5);
		if ((EIF_BOOLEAN) (loc3 > loc2)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc2, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
			F1759_15983(Current, tr1);
		}
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc3 <= ti4_2)) {
			loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc3);
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc1;
			} else {
				if (loc1) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, loc3, loc3);
					F1759_15983(Current, tr1);
				} else {
					if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 127L))) {
						F1759_15988(Current, loc4);
					} else {
						if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 60L))) {
							tr1 = RTMS_EX_H("&lt;",4,644641851);
							F1759_15983(Current, tr1);
						} else {
							if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 62L))) {
								tr1 = RTMS_EX_H("&gt;",4,644314171);
								F1759_15983(Current, tr1);
							} else {
								if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 38L))) {
									tr1 = RTMS_EX_H("&amp;",5,1634853947);
									F1759_15983(Current, tr1);
								} else {
									if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 34L))) {
										tr1 = RTMS_EX_H("&#34;",5,590850107);
										F1759_15983(Current, tr1);
									} else {
										if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 10L))) {
											tr1 = RTMS_EX_H("&#xA;",5,595375419);
											F1759_15983(Current, tr1);
										} else {
											if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 13L))) {
												tr1 = RTMS_EX_H("&#xD;",5,595376187);
												F1759_15983(Current, tr1);
											} else {
												if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 9L))) {
													tr1 = RTMS_EX_H("&#9;",4,639842619);
													F1759_15983(Current, tr1);
												} else {
													F1759_15988(Current, loc4);
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
	}
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.maximal_ordinary_string */
EIF_INTEGER_32 F1759_15987 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	RTCT0("attached outputter as l_outputter", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = (EIF_INTEGER_32) arg2;
	for (;;) {
		tb1 = '\01';
		if (!loc3) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
		}
		if (tb1) break;
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc1);
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 127L))) {
			tb2 = F884_4371(RTCW(arg3), loc2);
			if (tb2) {
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				loc1++;
			}
		} else {
			if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 160L))) {
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 8232L))) {
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R1642[Dtype(loc4)-1183])(loc4, loc2);
					if (tb2) {
						loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						loc1++;
					}
				}
			}
		}
	}
	Result = (EIF_INTEGER_32) loc1;
	RTLE;
	return Result;
}

/* {XM_XSLT_XML_EMITTER}.output_character_reference */
void F1759_15988 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
		loc1 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1111_6438(RTCW(loc1), ((EIF_INTEGER_32) 10L));
		if (*(EIF_BOOLEAN *)(Current + O12448[dtype-1758])) {
			loc1 = RTMS_EX_H("&#x",3,2499448);
			tr1 = RTOSCF(6771,F1118_6771, (Current));
			tr1 = F1174_8727(RTCW(tr1), arg1, (EIF_BOOLEAN) 1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(loc1))-1112])(loc1, tr1);
		} else {
			loc1 = RTMS_EX_H("&#",2,9763);
			tr1 = eif_out__i4_s1(arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5179[Dtype(RTCW(loc1))-1112])(loc1, tr1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5181[Dtype(RTCW(loc1))-1112])(loc1, (EIF_CHARACTER_8) ';');
		F1759_15983(Current, loc1);
	}
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.open_document */
void F1759_15989 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLR(7,loc1);
	RTLIU(8);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O12439[dtype-1758]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5053[Dtype(RTCW(tr1))-1112])(tr1);
	RTAR(Current, loc2);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc2;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1254_10627(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + _REFACS_6_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr2 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
		tr3 = RTOSCF(8530,F1163_8530, (Current));
		tr4 = RTMS_EX_H("Trying UTF-8 as unable to open output stream in encoding ",57,1852672544);
		tr3 = F1148_8367(RTCW(tr3), tr4, loc2);
		tr4 = RTOSCF(9827,F1230_9827, (Current));
		tr5 = RTMS_EX_H("SESU0007",8,1360585271);
		F1709_14669(RTCW(tr2), tr3, tr4, tr5, ((EIF_INTEGER_32) 3L));
		F1710_14690(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_33_0_);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1254_10627(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + _REFACS_6_));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) == NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tr2 = RTLNS(eif_new_type(1708, 0x01).id, 1708, _OBJSIZ_5_0_0_2_0_0_0_0_);
				tr3 = RTMS_EX_H("Failed to recover",17,1156012146);
				tr4 = RTOSCF(9827,F1230_9827, (Current));
				tr5 = RTMS_EX_H("SESU0007",8,1360585271);
				F1709_14669(RTCW(tr2), tr3, tr4, tr5, ((EIF_INTEGER_32) 3L));
				F1710_14691(RTCW(tr1), tr2);
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_33_0_);
	if (tb1) {
		*(EIF_BOOLEAN *)(Current + O11899[dtype-1731]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		*(EIF_BOOLEAN *)(Current + O12440[dtype-1758]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = F1781_16420(RTCW(tr2));
		tr3 = RTMS_EX_H("1.1",3,3223089);
		tb1 = F1148_8369(RTCW(tr1), tr2, tr3);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_22_2_);
			*(EIF_BOOLEAN *)(Current + O12449[dtype-1758]) = (EIF_BOOLEAN) tb1;
		}
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O12441[dtype-1758])) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R12458[dtype-1758])(Current);
		}
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11899[dtype-1731])) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			loc1 = F1781_16440(RTCW(tr1));
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("hex",3,6841720);
			tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
			if (tb1) {
				*(EIF_BOOLEAN *)(Current + O12448[dtype-1758]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H("decimal",7,760243052);
				tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
				if (tb1) {
					tr1 = RTMS_EX_H("Illegal value for gexslt:character-representation: ",51,2028363552);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr1)-1111])(tr1, loc1);
					F1732_15293(Current, tr1);
				}
			}
		}
	}
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.write_doctype */
void F1759_15990 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O12441[Dtype(Current)-1758])) {
		tr1 = RTMS_EX_H("\012",1,10);
		F1759_15983(Current, tr1);
	}
	tr1 = RTMS_EX_H("<!DOCTYPE ",10,138482464);
	F1759_15983(Current, tr1);
	F1759_15983(Current, arg1);
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		if ((EIF_BOOLEAN)(arg3 == NULL)) {
			tr1 = RTMS_EX_H(" SYSTEM \"",9,783683106);
			F1759_15983(Current, tr1);
			F1759_15983(Current, arg2);
			tr1 = RTMS_EX_H("\">\012",3,2244106);
			F1759_15983(Current, tr1);
		} else {
			tr1 = RTMS_EX_H(" PUBLIC \"",9,950174498);
			F1759_15983(Current, tr1);
			F1759_15983(Current, arg3);
			tr1 = RTMS_EX_H("\" \"",3,2236450);
			F1759_15983(Current, tr1);
			F1759_15983(Current, arg2);
			tr1 = RTMS_EX_H("\">\012",3,2244106);
			F1759_15983(Current, tr1);
		}
	} else {
		if ((EIF_BOOLEAN)(arg3 != NULL)) {
			tr1 = RTMS_EX_H(" PUBLIC \"",9,950174498);
			F1759_15983(Current, tr1);
			F1759_15983(Current, arg3);
			tr1 = RTMS_EX_H("\">\012",3,2244106);
			F1759_15983(Current, tr1);
		}
	}
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.bad_character_code */
EIF_INTEGER_32 F1759_15991 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc4);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tb1 = '\01';
		if (!loc3) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
		}
		if (tb1) break;
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5129[Dtype(RTCW(arg1))-1112])(arg1, loc1);
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 127L))) {
			RTCT0("attached outputter as l_outputter", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R1642[Dtype(loc4)-1183])(loc4, loc2);
			if (tb2) {
				Result = (EIF_INTEGER_32) loc2;
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_XML_EMITTER}.close_start_tag */
void F1759_15992 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (arg2) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R12469[dtype-1758])(Current, arg1, *(EIF_INTEGER_32 *)(Current + O12447[dtype-1758]));
		F1759_15983(Current, tr1);
	} else {
		tr1 = RTMS_EX_H(">",1,62);
		F1759_15983(Current, tr1);
	}
	*(EIF_BOOLEAN *)(Current + O12443[dtype-1758]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {XM_XSLT_XML_EMITTER}.empty_element_tag_closer */
EIF_REFERENCE F1759_15993 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTMS_EX_H("/>",2,12094);
	RTLE;
	return Result;
}

void EIF_Minit832 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
