/*
 * Code for class XM_XSLT_META_TAG_INSERTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm808.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_META_TAG_INSERTER}.make */
void F1735_15334 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg2);
	RTLIU(7);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O11855[Dtype(tr1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O11856[Dtype(tr1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_) = (EIF_BOOLEAN) arg3;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_)) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	} else {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = RTOSCF(4950,F991_4950, (Current));
	tr2 = RTOSCF(9820,F1230_9820, (Current));
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_0_);
	tr3 = RTMS_EX_H("meta",4,1835365473);
	tb1 = F1242_10431(RTCW(tr1), tr2, ti4_1, tr3);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tr2 = RTOSCF(9820,F1230_9820, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_0_);
		tr3 = RTMS_EX_H("meta",4,1835365473);
		F1242_10445(RTCW(tr1), tr2, ti4_1, tr3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(4950,F991_4950, (Current)))+ _LNGOFF_4_0_0_0_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_1_) = (EIF_INTEGER_32) ti4_1;
	} else {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tr2 = RTOSCF(9820,F1230_9820, (Current));
		tr3 = RTOSCF(4950,F991_4950, (Current));
		tr3 = F1242_10454(RTCW(tr3), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_0_));
		tr4 = RTMS_EX_H("meta",4,1835365473);
		ti4_1 = F1242_10413(RTCW(tr1), tr2, tr3, tr4);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	tr1 = RTOSCF(4950,F991_4950, (Current));
	tr2 = RTOSCF(9820,F1230_9820, (Current));
	tr3 = RTOSCF(9820,F1230_9820, (Current));
	tr4 = RTMS_EX_H("http-equiv",10,1348183670);
	tb1 = F1242_10430(RTCW(tr1), tr2, tr3, tr4);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tr2 = RTOSCF(9820,F1230_9820, (Current));
		tr3 = RTOSCF(9820,F1230_9820, (Current));
		tr4 = RTMS_EX_H("http-equiv",10,1348183670);
		F1242_10444(RTCW(tr1), tr2, tr3, tr4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(4950,F991_4950, (Current)))+ _LNGOFF_4_0_0_0_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_2_) = (EIF_INTEGER_32) ti4_1;
	} else {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tr2 = RTOSCF(9820,F1230_9820, (Current));
		tr3 = RTOSCF(9820,F1230_9820, (Current));
		tr4 = RTMS_EX_H("http-equiv",10,1348183670);
		ti4_1 = F1242_10413(RTCW(tr1), tr2, tr3, tr4);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	tr1 = RTOSCF(4950,F991_4950, (Current));
	tr2 = RTOSCF(9820,F1230_9820, (Current));
	tr3 = RTOSCF(9820,F1230_9820, (Current));
	tr4 = RTMS_EX_H("content",7,460700276);
	tb1 = F1242_10430(RTCW(tr1), tr2, tr3, tr4);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tr2 = RTOSCF(9820,F1230_9820, (Current));
		tr3 = RTOSCF(9820,F1230_9820, (Current));
		tr4 = RTMS_EX_H("content",7,460700276);
		F1242_10444(RTCW(tr1), tr2, tr3, tr4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(4950,F991_4950, (Current)))+ _LNGOFF_4_0_0_0_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_) = (EIF_INTEGER_32) ti4_1;
	} else {
		tr1 = RTOSCF(4950,F991_4950, (Current));
		tr2 = RTOSCF(9820,F1230_9820, (Current));
		tr3 = RTOSCF(9820,F1230_9820, (Current));
		tr4 = RTMS_EX_H("content",7,460700276);
		ti4_1 = F1242_10413(RTCW(tr1), tr2, tr3, tr4);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	tr1 = F1781_16428(RTCW(arg2));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_4_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_META_TAG_INSERTER}.start_element */
void F1735_15335 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(4950,F991_4950, (Current));
	loc3 = F1242_10449(RTCW(tr1), arg1);
	tr1 = RTOSCF(4950,F991_4950, (Current));
	loc2 = F1242_10450(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_5_))) {
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc3 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_0_))) {
			tr1 = RTMS_EX_H("meta",4,1835365473);
			tb1 = F1735_15352(Current, loc2, tr1);
		}
		if (tb1) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_6_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = RTLNSMART(eif_new_type(1230, 0).id);
			F1231_10132(RTCW(tr1));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		}
	}
	if ((EIF_BOOLEAN) !loc1) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_5_))++;
		F1734_15320(Current, arg1, arg2, arg3);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_4_)) {
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc3 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_0_))) {
				tr1 = RTMS_EX_H("head",4,1751474532);
				tb1 = F1735_15352(Current, loc2, tr1);
			}
			if (tb1) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_6_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	F1734_15315(Current);
	RTLE;
}

/* {XM_XSLT_META_TAG_INSERTER}.notify_attribute */
void F1735_15336 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_6_)) {
		RTCT0("attached attributes as l_attributes", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1231_10144(loc1, arg1, arg2, arg3, arg4);
	} else {
		F1734_15322(Current, arg1, arg2, arg3, arg4);
	}
	F1734_15315(Current);
	RTLE;
}

/* {XM_XSLT_META_TAG_INSERTER}.start_content */
void F1735_15337 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_5_)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		F1734_15323(Current);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R11868[Dtype(RTCW(tr1))-1732])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_1_), ((EIF_INTEGER_32) 559L), ((EIF_INTEGER_32) 0L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_2_);
		tr2 = RTMS_EX_H("Content-Type",12,1604261989);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_INTEGER_32)) R11870[Dtype(RTCW(tr1))-1732])(tr1, ti4_1, ((EIF_INTEGER_32) 560L), tr2, ((EIF_INTEGER_32) 0L));
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr3 = RTMS_EX_H("; charset=",10,214348605);
		loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr1 = F1148_8377(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + _REFACS_4_));
		loc1 = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_INTEGER_32)) R11870[Dtype(RTCW(tr1))-1732])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_), ((EIF_INTEGER_32) 560L), loc1, ((EIF_INTEGER_32) 0L));
		F1734_15323(Current);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_5_);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = RTLNSMART(eif_new_type(1230, 0).id);
		F1231_10132(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11872[Dtype(RTCW(tr1))-1732])(tr1);
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_6_)) {
		F1734_15323(Current);
	}
	F1734_15315(Current);
	RTLE;
}

/* {XM_XSLT_META_TAG_INSERTER}.end_element */
void F1735_15338 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_6_)) {
		RTCT0("attached attributes as l_attributes", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTCK0;
		} else {
			RTCF0;
		}
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc2 = F1231_10141(loc5);
		F1321_11363(RTCW(loc2));
		for (;;) {
			tb1 = '\01';
			if (!loc1) {
				tb2 = F1385_11438(RTCW(loc2));
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = RTOSCF(4950,F991_4950, (Current));
			ti4_1 = F1308_11343(RTCW(loc2));
			tr1 = F1242_10450(RTCW(tr1), ti4_1);
			tr2 = RTMS_EX_H("http-equiv",10,1348183670);
			if (F1735_15352(Current, tr1, tr2)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				ti4_1 = F1382_11418(RTCW(loc2));
				tr2 = F1231_10135(loc5, ti4_1);
				loc3 = F1148_8376(RTCW(tr1), tr2);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				F1148_8385(RTCW(tr1), loc3);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				F1148_8386(RTCW(tr1), loc3);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTMS_EX_H("Content-Type",12,1604261989);
				tb2 = F1148_8370(RTCW(tr1), tr2, loc3);
				if (tb2) {
					loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			}
			F1321_11364(RTCW(loc2));
		}
		if ((EIF_BOOLEAN) !loc1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R11868[Dtype(RTCW(tr1))-1732])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_1_), ((EIF_INTEGER_32) 559L), ((EIF_INTEGER_32) 0L));
			loc2 = F1231_10141(loc5);
			F1321_11363(RTCW(loc2));
			for (;;) {
				tb2 = F1385_11438(RTCW(loc2));
				if (tb2) break;
				loc4 = F1382_11418(RTCW(loc2));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				ti4_1 = F1308_11343(RTCW(loc2));
				ti4_2 = F1231_10137(loc5, loc4);
				tr2 = F1231_10135(loc5, loc4);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_INTEGER_32)) R11870[Dtype(RTCW(tr1))-1732])(tr1, ti4_1, ti4_2, tr2, ((EIF_INTEGER_32) 0L));
				F1321_11364(RTCW(loc2));
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R11871[Dtype(RTCW(tr1))-1732])(tr1);
			F1734_15324(Current);
		}
	} else {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_5_))--;
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_) == (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_5_) + ((EIF_INTEGER_32) 1L)))) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		}
		F1734_15324(Current);
	}
	F1734_15315(Current);
	RTLE;
}

/* {XM_XSLT_META_TAG_INSERTER}.matches_name */
EIF_BOOLEAN F1735_15352 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_)) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		Result = F1148_8369(RTCW(tr1), arg1, arg2);
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		Result = F1148_8370(RTCW(tr1), arg1, arg2);
	}
	RTLE;
	return Result;
}

void EIF_Minit808 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
