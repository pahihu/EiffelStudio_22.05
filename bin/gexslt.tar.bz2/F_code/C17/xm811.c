/*
 * Code for class XM_XSLT_COMMENT_STRIPPER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm811.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_COMMENT_STRIPPER}.make */
void F1738_15387 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O11855[Dtype(arg1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O11856[Dtype(arg1)-1728]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1112, 1).id);
	F1111_6438(RTCW(tr1), ((EIF_INTEGER_32) 80L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_XSLT_COMMENT_STRIPPER}.start_element */
void F1738_15388 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1738_15394(Current);
	F1734_15320(Current, arg1, arg2, arg3);
	RTLE;
}

/* {XM_XSLT_COMMENT_STRIPPER}.end_element */
void F1738_15389 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1738_15394(Current);
	F1734_15324(Current);
	RTLE;
}

/* {XM_XSLT_COMMENT_STRIPPER}.notify_characters */
void F1738_15390 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr1 = F1148_8377(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	F1734_15315(Current);
	RTLE;
}

/* {XM_XSLT_COMMENT_STRIPPER}.notify_comment */
void F1738_15391 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	F1734_15315(Current);
}

/* {XM_XSLT_COMMENT_STRIPPER}.notify_processing_instruction */
void F1738_15392 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	F1734_15315(Current);
}

/* {XM_XSLT_COMMENT_STRIPPER}.flush */
void F1738_15394 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tb2 = F772_3900(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R11873[Dtype(RTCW(tr1))-1732])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_3_), ((EIF_INTEGER_32) 0L));
	}
	tr1 = RTLNSMART(eif_new_type(1112, 1).id);
	F1111_6438(RTCW(tr1), ((EIF_INTEGER_32) 80L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit811 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
