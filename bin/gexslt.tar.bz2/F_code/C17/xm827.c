/*
 * Code for class XM_CATALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm827.h"
#include "eif_plug.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_CATALOG}.make */
void F1754_15787 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	F1408_11616(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12163(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1439_11749(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1481,0xFF01,10,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1482_11932(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1481,0xFF01,10,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1482_11932(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1481,0xFF01,11,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1482_11932(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1481,0xFF01,11,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1482_11932(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1481,0xFF01,92,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1482_11932(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1481,0xFF01,92,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1482_11932(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1481,0xFF01,93,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1482_11932(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tb1 = *(EIF_BOOLEAN *)(RTCV(RTOSCF(3203,F373_3203, (Current)))+ _CHROFF_4_0_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_19_2_) = (EIF_BOOLEAN) tb1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1536,0xFF01,90,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1525_12401(RTCW(tr1), ((EIF_INTEGER_32) 10L), NULL, tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1536,0xFF01,90,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1525_12401(RTCW(tr1), ((EIF_INTEGER_32) 10L), NULL, tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1536,0xFF01,91,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1525_12401(RTCW(tr1), ((EIF_INTEGER_32) 10L), NULL, tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1536,0xFF01,91,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1525_12401(RTCW(tr1), ((EIF_INTEGER_32) 10L), NULL, tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1502,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1503_12129(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOSCF(8115,F1125_8115, (Current));
	F1439_11749(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12163(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12163(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1112,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1506_12163(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	F1754_15826(Current);
	RTLE;
}

/* {XM_CATALOG}.resolved_fpi */
EIF_REFERENCE F1754_15788 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLR(5,tr3);
	RTLR(6,Result);
	RTLR(7,loc1);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	tb1 = F1525_12411(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Public entry found in catalog",29,1639675751);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		loc2 = F1525_12403(RTCW(tr1), arg1);
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Public entry is prefer=public\?",30,456933695);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_1_0_);
		tr3 = (tb1 ? makestr ("True", 4) : makestr ("False", 5));
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, tr3);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) !arg2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_1_0_);
			tb1 = tb2;
		}
		if (tb1) {
			Result = F91_1035(RTCW(loc2));
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Public entry found in prefer=system list",40,203426164);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, arg1);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Public entry resolves to",24,1458719599);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, Result);
		} else {
			tb1 = '\0';
			if (arg2) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
				tb2 = F1525_12411(RTCW(tr1), arg1);
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
				tr1 = F1525_12403(RTCW(tr1), arg1);
				Result = F91_1035(RTCW(tr1));
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("Public entry found in prefer=public list",40,903208308);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, arg1);
			}
		}
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Checking for delegates for",26,955441522);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
		Result = F1754_15848(Current, arg1, arg2);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_1_))) {
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Checking next catalogs for",26,771085426);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		loc1 = F1506_12168(RTCW(tr1));
		F1320_11363(RTCW(loc1));
		for (;;) {
			tb1 = F1384_11438(RTCW(loc1));
			if (tb1) break;
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = F1307_11343(RTCW(loc1));
			loc3 = F1756_15922(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				Result = F1754_15788(RTCW(loc3), arg1, arg2);
			}
			if ((EIF_BOOLEAN)(Result == NULL)) {
				F1320_11364(RTCW(loc1));
			} else {
				F1320_11366(RTCW(loc1));
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_19_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
	return Result;
}

/* {XM_CATALOG}.resolved_fsi */
EIF_REFERENCE F1754_15789 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,Result);
	RTLR(6,loc2);
	RTLR(7,loc5);
	RTLR(8,tr3);
	RTLR(9,loc1);
	RTLR(10,loc4);
	RTLIU(11);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
	tb1 = F1525_12411(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("System entry found in catalog",29,24938343);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
		loc3 = F1525_12403(RTCW(tr1), arg1);
		Result = F91_1035(RTCW(loc3));
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("System entry resolves to",24,1610255215);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, Result);
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Checking for system rewrite rules for",37,1407657586);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
		F1320_11363(RTCW(loc2));
		for (;;) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_3_1_);
			if (tb1) break;
			loc5 = F1387_11451(RTCW(loc2));
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Next rewrite rule matches",25,1264386931);
			tr3 = *(EIF_REFERENCE *)(RTCW(loc5));
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, tr3);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5));
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5041[Dtype(RTCW(arg1))-1111])(arg1, tr1, ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				Result = F1148_8376(RTCW(tr1), arg1);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = F11_129(RTCW(loc5));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_2_0_0_0_);
				tr1 = F1148_8379(RTCW(tr1), Result, tr2, ((EIF_INTEGER_32) 1L), ti4_1);
				Result = (EIF_REFERENCE) tr1;
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("Rewrite rule resolved to",24,3803759);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, Result);
				F1320_11366(RTCW(loc2));
			} else {
				F1320_11364(RTCW(loc2));
			}
		}
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Checking for system suffixes for",32,1706650994);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
		Result = F1754_15844(Current, arg1);
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Checking for system delegates for",33,180068210);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
		Result = F1754_15846(Current, arg1);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_1_))) {
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Checking next catalogs for",26,771085426);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		loc1 = F1506_12168(RTCW(tr1));
		F1320_11363(RTCW(loc1));
		for (;;) {
			tb2 = F1384_11438(RTCW(loc1));
			if (tb2) break;
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = F1307_11343(RTCW(loc1));
			loc4 = F1756_15922(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				Result = F1754_15789(RTCW(loc4), arg1);
			}
			if ((EIF_BOOLEAN)(Result == NULL)) {
				F1320_11364(RTCW(loc1));
			} else {
				F1320_11366(RTCW(loc1));
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_19_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
	return Result;
}

/* {XM_CATALOG}.resolved_uri */
EIF_REFERENCE F1754_15790 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,Result);
	RTLR(6,loc2);
	RTLR(7,loc5);
	RTLR(8,tr3);
	RTLR(9,loc1);
	RTLR(10,loc4);
	RTLIU(11);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	tb1 = F1525_12411(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Uri entry found in catalog",26,1719836007);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		loc3 = F1525_12403(RTCW(tr1), arg1);
		Result = F91_1035(RTCW(loc3));
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Uri entry resolves to",21,1977827183);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, Result);
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Checking for uri rewrite rules for",34,1139264114);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
		F1320_11363(RTCW(loc2));
		for (;;) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_3_1_);
			if (tb1) break;
			loc5 = F1387_11451(RTCW(loc2));
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Next rewrite rule matches",25,1264386931);
			tr3 = *(EIF_REFERENCE *)(RTCW(loc5));
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, tr3);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5));
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5041[Dtype(RTCW(arg1))-1111])(arg1, tr1, ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				Result = F1148_8376(RTCW(tr1), arg1);
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = F11_129(RTCW(loc5));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_2_0_0_0_);
				tr1 = F1148_8379(RTCW(tr1), Result, tr2, ((EIF_INTEGER_32) 1L), ti4_1);
				Result = (EIF_REFERENCE) tr1;
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("Rewrite rule resolved to",24,3803759);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, Result);
				F1320_11366(RTCW(loc2));
			} else {
				F1320_11364(RTCW(loc2));
			}
		}
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Checking for uri suffixes for",29,924025714);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
		Result = F1754_15845(Current, arg1);
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Checking for uri delegates for",30,1691098482);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
		Result = F1754_15847(Current, arg1);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_1_))) {
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Checking next catalogs for",26,771085426);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		loc1 = F1506_12168(RTCW(tr1));
		F1320_11363(RTCW(loc1));
		for (;;) {
			tb2 = F1384_11438(RTCW(loc1));
			if (tb2) break;
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = F1307_11343(RTCW(loc1));
			loc4 = F1756_15922(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				Result = F1754_15790(RTCW(loc4), arg1);
			}
			if ((EIF_BOOLEAN)(Result == NULL)) {
				F1320_11364(RTCW(loc1));
			} else {
				F1320_11366(RTCW(loc1));
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_19_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
	return Result;
}

/* {XM_CATALOG}.on_start_tag */
void F1754_15793 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,tr3);
	RTLR(7,arg3);
	RTLIU(8);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_)) {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_1_) == ((EIF_INTEGER_32) 0L))) {
			tb1 = '\0';
			if ((EIF_BOOLEAN)(arg1 != NULL)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15811,F1754_15811, (Current));
				tb2 = F1148_8369(RTCW(tr1), arg1, tr2);
				tb1 = tb2;
			}
			if (tb1) {
				tb1 = '\01';
				tb2 = '\01';
				tr1 = F1754_15807(Current);
				loc1 = tr1;
				if (!((EIF_BOOLEAN) !EIF_TEST(loc1))) {
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTOSCF(15855,F1754_15855, (Current));
					tb3 = F1148_8369(RTCW(tr1), loc1, tr2);
					tb2 = tb3;
				}
				if (!tb2) {
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTOSCF(15857,F1754_15857, (Current));
					tb2 = F1148_8369(RTCW(tr1), loc1, tr2);
					tb1 = tb2;
				}
				if (tb1) {
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,1112,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr1 = RTLNSMART(typres0.id);
					}
					F1506_12163(RTCW(tr1));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1112,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr1 = RTLNSMART(typres0.id);
					}
					F1506_12163(RTCW(tr1));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,1112,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr1 = RTLNSMART(typres0.id);
					}
					F1506_12163(RTCW(tr1));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
				} else {
					*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("Element must be empty",21,662262905);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, loc1);
				}
			} else {
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_4_)) {
					*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					tr1 = F1754_15807(Current);
					loc2 = tr1;
					if (EIF_TEST(loc2)) {
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("Document element is not catalog",31,890875495);
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, loc2);
					} else {
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("Document element is not catalog",31,890875495);
						tr3 = RTMS_EX_H("",0,0);
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
					}
				} else {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				}
			}
		} else {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_1_))++;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1503_12140(RTCW(tr1), arg3);
	}
	RTLE;
}

/* {XM_CATALOG}.on_start_tag_finish */
void F1754_15794 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_1_) == ((EIF_INTEGER_32) 0L)))) {
		tr1 = F1754_15807(Current);
		loc1 = tr1;
		tb1 = EIF_TEST(loc1);
	}
	if (tb1) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15855,F1754_15855, (Current));
		tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
		if (tb1) {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_19_4_)) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("Nested catalog elements not allowed",35,1644319332);
				tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_19_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				F1754_15827(Current, (EIF_BOOLEAN) 1);
			}
		} else {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTOSCF(15857,F1754_15857, (Current));
			tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
			if (tb1) {
				F1754_15827(Current, (EIF_BOOLEAN) 0);
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_2_) == ((EIF_INTEGER_32) 0L))) {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				} else {
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("Nested group elements not allowed",33,2031068260);
					tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
				}
			} else {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15858,F1754_15858, (Current));
				tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
				if (tb1) {
					F1754_15828(Current);
				} else {
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTOSCF(15859,F1754_15859, (Current));
					tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
					if (tb1) {
						F1754_15830(Current);
					} else {
						tr1 = RTOSCF(8530,F1163_8530, (Current));
						tr2 = RTOSCF(15860,F1754_15860, (Current));
						tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
						if (tb1) {
							F1754_15829(Current);
						} else {
							tr1 = RTOSCF(8530,F1163_8530, (Current));
							tr2 = RTOSCF(15867,F1754_15867, (Current));
							tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
							if (tb1) {
								F1754_15832(Current, (EIF_BOOLEAN) 1);
							} else {
								tr1 = RTOSCF(8530,F1163_8530, (Current));
								tr2 = RTOSCF(15868,F1754_15868, (Current));
								tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
								if (tb1) {
									F1754_15832(Current, (EIF_BOOLEAN) 0);
								} else {
									tr1 = RTOSCF(8530,F1163_8530, (Current));
									tr2 = RTOSCF(15874,F1754_15874, (Current));
									tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
									if (tb1) {
										F1754_15836(Current);
									} else {
										tr1 = RTOSCF(8530,F1163_8530, (Current));
										tr2 = RTOSCF(15872,F1754_15872, (Current));
										tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
										if (tb1) {
											F1754_15834(Current);
										} else {
											tr1 = RTOSCF(8530,F1163_8530, (Current));
											tr2 = RTOSCF(15873,F1754_15873, (Current));
											tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
											if (tb1) {
												F1754_15835(Current);
											} else {
												tr1 = RTOSCF(8530,F1163_8530, (Current));
												tr2 = RTOSCF(15864,F1754_15864, (Current));
												tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
												if (tb1) {
													F1754_15833(Current, (EIF_BOOLEAN) 1);
												} else {
													tr1 = RTOSCF(8530,F1163_8530, (Current));
													tr2 = RTOSCF(15862,F1754_15862, (Current));
													tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
													if (tb1) {
														F1754_15833(Current, (EIF_BOOLEAN) 0);
													} else {
														tr1 = RTOSCF(8530,F1163_8530, (Current));
														tr2 = RTOSCF(15875,F1754_15875, (Current));
														tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
														if (tb1) {
															F1754_15831(Current);
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.on_attribute */
void F1754_15795 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_1_) == ((EIF_INTEGER_32) 0L)))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1506_12183(RTCW(tr1), arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F1506_12183(RTCW(tr1), arg3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F1506_12183(RTCW(tr1), arg4);
	}
	RTLE;
}

/* {XM_CATALOG}.on_end_tag */
void F1754_15796 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_)) {
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_1_) > ((EIF_INTEGER_32) 0L))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_1_))--;
		}
		tr1 = F1754_15807(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTOSCF(15857,F1754_15857, (Current));
			tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
			if (tb1) {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			} else {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15855,F1754_15855, (Current));
				tb1 = F1148_8369(RTCW(tr1), loc1, tr2);
				if (tb1) {
					*(EIF_BOOLEAN *)(Current+ _CHROFF_19_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1503_12144(RTCW(tr1));
		}
	}
	RTLE;
}

/* {XM_CATALOG}.on_content */
void F1754_15797 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) && *(EIF_BOOLEAN *)(Current+ _CHROFF_19_4_)) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_1_) == ((EIF_INTEGER_32) 0L)))) {
		tr1 = F1754_15807(Current);
		loc1 = tr1;
		tb1 = EIF_TEST(loc1);
	}
	if (tb1) {
		tb1 = '\01';
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15855,F1754_15855, (Current));
		tb2 = F1148_8369(RTCW(tr1), loc1, tr2);
		if (!tb2) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTOSCF(15857,F1754_15857, (Current));
			tb2 = F1148_8369(RTCW(tr1), loc1, tr2);
			tb1 = tb2;
		}
		if (tb1) {
		} else {
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Character content is not allowed",32,417064548);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, loc1);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTLE;
}

/* {XM_CATALOG}.current_element_name */
EIF_REFERENCE F1754_15807 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F1418_11697(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		Result = F1503_12132(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {XM_CATALOG}.oasis_etrc_namespace */

EIF_REFERENCE F1754_15811 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15811,RTMS_EX_H("urn:oasis:names:tc:entity:xmlns:xml:catalog",43,468242791));
}

/* {XM_CATALOG}.xml_namespace */

EIF_REFERENCE F1754_15812 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15812,RTMS_EX_H("http://www.w3.org/XML/1998/namespace",36,212418405));
}

/* {XM_CATALOG}.parser */
EIF_REFERENCE F1754_15813 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1719, 0x01).id, 1719, _OBJSIZ_45_3_0_35_0_0_0_0_);
	F1719_15014(RTCW(Result));
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(3203,F373_3203, (Current))));
	F1409_11634(RTCW(Result), tr1);
	F1408_11618(RTCW(Result), Current);
	loc1 = RTLNS(eif_new_type(1202, 0x01).id, 1202, _OBJSIZ_7_1_0_0_0_0_0_0_);
	F258_2170(RTCW(loc1), Current);
	F256_2145(RTCW(Result), loc1);
	RTLE;
	return Result;
}

/* {XM_CATALOG}.read */
void F1754_15826 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = F1754_15813(Current);
	F1719_15020(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTLE;
}

/* {XM_CATALOG}.set_catalog_attributes */
void F1754_15827 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) !arg1) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_19_3_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_19_2_);
		tr1 = *(EIF_REFERENCE *)(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = F1506_12168(RTCW(tr1));
	F1320_11363(RTCW(loc1));
	for (;;) {
		tb1 = F1384_11438(RTCW(loc1));
		if (tb1) break;
		loc2 = F1307_11343(RTCW(loc1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = F1381_11418(RTCW(loc1));
		loc3 = F1506_12165(RTCW(tr1), ti4_1);
		tb2 = '\0';
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15876,F1754_15876, (Current));
		tb3 = F1148_8369(RTCW(tr1), loc2, tr2);
		if (tb3) {
			tb3 = '\0';
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15812,F1754_15812, (Current));
				tb4 = F1148_8369(RTCW(tr1), loc3, tr2);
				tb3 = tb4;
			}
			tb2 = tb3;
		}
		if (tb2) {
			if (arg1) {
				tr1 = RTLNSMART(eif_new_type(1706, 1).id);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				ti4_1 = F1381_11418(RTCW(loc1));
				tr2 = F1506_12165(RTCW(tr2), ti4_1);
				F1707_14586(RTCW(tr1), tr2);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("xml:base set to",15,2041105263);
				tr3 = *(EIF_REFERENCE *)(Current);
				tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, tr3);
			} else {
				tr1 = RTLNSMART(eif_new_type(1706, 1).id);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				ti4_1 = F1381_11418(RTCW(loc1));
				tr2 = F1506_12165(RTCW(tr2), ti4_1);
				F1707_14586(RTCW(tr1), tr2);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			}
		} else {
			tb2 = '\0';
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTOSCF(15877,F1754_15877, (Current));
			tb3 = F1148_8369(RTCW(tr1), loc2, tr2);
			if (tb3) {
				tb2 = (EIF_BOOLEAN)(loc3 == NULL);
			}
			if (tb2) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				ti4_1 = F1381_11418(RTCW(loc1));
				tr2 = F1506_12165(RTCW(tr2), ti4_1);
				tr3 = RTOSCF(15858,F1754_15858, (Current));
				tb2 = F1148_8369(RTCW(tr1), tr2, tr3);
				if (tb2) {
					if (arg1) {
						*(EIF_BOOLEAN *)(Current+ _CHROFF_19_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					} else {
						*(EIF_BOOLEAN *)(Current+ _CHROFF_19_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
				} else {
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					ti4_1 = F1381_11418(RTCW(loc1));
					tr2 = F1506_12165(RTCW(tr2), ti4_1);
					tr3 = RTOSCF(15859,F1754_15859, (Current));
					tb2 = F1148_8369(RTCW(tr1), tr2, tr3);
					if (tb2) {
						if (arg1) {
							*(EIF_BOOLEAN *)(Current+ _CHROFF_19_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							*(EIF_BOOLEAN *)(Current+ _CHROFF_19_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						}
					} else {
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("Invalid prefer: must be \'system\' or \'public\'",44,788083495);
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						ti4_1 = F1381_11418(RTCW(loc1));
						tr3 = F1506_12165(RTCW(tr3), ti4_1);
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
						*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
			} else {
				tb2 = '\0';
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15878,F1754_15878, (Current));
				tb3 = F1148_8369(RTCW(tr1), loc2, tr2);
				if (tb3) {
					tb2 = (EIF_BOOLEAN)(loc3 == NULL);
				}
				if (tb2) {
				} else {
					if ((EIF_BOOLEAN)(loc3 == NULL)) {
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("Reserved attribute in the per-element-partition",47,1148666478);
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 2L), tr2, loc2);
					}
				}
			}
		}
		F1320_11364(RTCW(loc1));
	}
	RTLE;
}

/* {XM_CATALOG}.add_system_entry */
void F1754_15828 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc2);
	RTLR(11,loc8);
	RTLIU(12);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_2_) == ((EIF_INTEGER_32) 1L))) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	} else {
		loc1 = *(EIF_REFERENCE *)(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = F1506_12168(RTCW(tr1));
	F1320_11363(RTCW(loc3));
	for (;;) {
		tb1 = F1384_11438(RTCW(loc3));
		if (tb1) break;
		loc4 = F1307_11343(RTCW(loc3));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = F1381_11418(RTCW(loc3));
		loc5 = F1506_12165(RTCW(tr1), ti4_1);
		tb2 = '\0';
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15876,F1754_15876, (Current));
		tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
		if (tb3) {
			tb3 = '\0';
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15812,F1754_15812, (Current));
				tb4 = F1148_8369(RTCW(tr1), loc5, tr2);
				tb3 = tb4;
			}
			tb2 = tb3;
		}
		if (tb2) {
			loc1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			ti4_1 = F1381_11418(RTCW(loc3));
			tr1 = F1506_12165(RTCW(tr1), ti4_1);
			F1707_14586(RTCW(loc1), tr1);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("xml:base set to",15,2041105263);
			tr3 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, tr3);
		} else {
			tb2 = '\0';
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTOSCF(15878,F1754_15878, (Current));
			tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
			if (tb3) {
				tb3 = '\01';
				if (!(EIF_BOOLEAN)(loc5 == NULL)) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
					tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				}
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				tb2 = '\0';
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15879,F1754_15879, (Current));
				tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
				if (tb3) {
					tb3 = '\01';
					if (!(EIF_BOOLEAN)(loc5 == NULL)) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
						tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
					}
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					ti4_1 = F1381_11418(RTCW(loc3));
					loc6 = F1506_12165(RTCW(tr1), ti4_1);
				} else {
					tb2 = '\0';
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTOSCF(15861,F1754_15861, (Current));
					tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
					if (tb3) {
						tb3 = '\01';
						if (!(EIF_BOOLEAN)(loc5 == NULL)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
							tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
						}
						tb2 = tb3;
					}
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						ti4_1 = F1381_11418(RTCW(loc3));
						loc7 = F1506_12165(RTCW(tr1), ti4_1);
					} else {
						if ((EIF_BOOLEAN)(loc5 == NULL)) {
							tr1 = RTOSCF(3203,F373_3203, (Current));
							tr2 = RTMS_EX_H("Reserved attribute in the per-element-partition of \'system\'",59,372794919);
							tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 2L), tr2, tr3);
						}
					}
				}
			}
		}
		F1320_11364(RTCW(loc3));
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc6 == NULL) || (EIF_BOOLEAN)(loc7 == NULL))) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		if ((EIF_BOOLEAN)(loc6 == NULL)) {
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Missing \'systemId\' attribute from \'system\'",42,301292327);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
		}
		if ((EIF_BOOLEAN)(loc7 == NULL)) {
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Missing \'uri\' attribute from \'system\'",37,1098386983);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
		}
	} else {
		tr1 = RTOSCF(4521,F954_4521, (Current));
		tr1 = F1138_8299(RTCW(tr1), loc6);
		tr2 = RTOSCF(15899,F1756_15899, (RTCV(RTOSCF(3203,F373_3203, (Current)))));
		tr1 = F1753_15774(Current, tr1, tr2, (EIF_BOOLEAN) 0);
		loc6 = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(4521,F954_4521, (Current));
		tr1 = F1138_8299(RTCW(tr1), loc7);
		tr2 = RTOSCF(15899,F1756_15899, (RTCV(RTOSCF(3203,F373_3203, (Current)))));
		tr1 = F1753_15774(Current, tr1, tr2, (EIF_BOOLEAN) 0);
		loc7 = (EIF_REFERENCE) tr1;
		loc2 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
		F1707_14587(RTCW(loc2), loc1, loc7);
		tb2 = F1707_14603(RTCW(loc2));
		if (tb2) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Fragment identifier present in  \'uri\' attribute from \'system\'",61,174552359);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
		} else {
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
				tb2 = F1525_12411(RTCW(tr1), loc6);
				if ((EIF_BOOLEAN) !tb2) {
					loc8 = RTLNS(eif_new_type(90, 0x01).id, 90, _OBJSIZ_1_0_0_0_0_0_0_0_);
					F91_1034(RTCW(loc8), loc2);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
					F1525_12424(RTCW(tr1), loc8, loc6);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("System URI added is",19,718284403);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, loc6);
				} else {
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("System URI is a duplicate",25,1495112293);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, loc6);
				}
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.add_uri_entry */
void F1754_15829 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc2);
	RTLR(11,loc8);
	RTLIU(12);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_2_) == ((EIF_INTEGER_32) 1L))) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	} else {
		loc1 = *(EIF_REFERENCE *)(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = F1506_12168(RTCW(tr1));
	F1320_11363(RTCW(loc3));
	for (;;) {
		tb1 = F1384_11438(RTCW(loc3));
		if (tb1) break;
		loc4 = F1307_11343(RTCW(loc3));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = F1381_11418(RTCW(loc3));
		loc5 = F1506_12165(RTCW(tr1), ti4_1);
		tb2 = '\0';
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15876,F1754_15876, (Current));
		tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
		if (tb3) {
			tb3 = '\0';
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15812,F1754_15812, (Current));
				tb4 = F1148_8369(RTCW(tr1), loc5, tr2);
				tb3 = tb4;
			}
			tb2 = tb3;
		}
		if (tb2) {
			loc1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			ti4_1 = F1381_11418(RTCW(loc3));
			tr1 = F1506_12165(RTCW(tr1), ti4_1);
			F1707_14586(RTCW(loc1), tr1);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("xml:base set to",15,2041105263);
			tr3 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, tr3);
		} else {
			tb2 = '\0';
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTOSCF(15878,F1754_15878, (Current));
			tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
			if (tb3) {
				tb3 = '\01';
				if (!(EIF_BOOLEAN)(loc5 == NULL)) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
					tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				}
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				tb2 = '\0';
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15881,F1754_15881, (Current));
				tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
				if (tb3) {
					tb3 = '\01';
					if (!(EIF_BOOLEAN)(loc5 == NULL)) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
						tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
					}
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					ti4_1 = F1381_11418(RTCW(loc3));
					loc6 = F1506_12165(RTCW(tr1), ti4_1);
				} else {
					tb2 = '\0';
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTOSCF(15861,F1754_15861, (Current));
					tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
					if (tb3) {
						tb3 = '\01';
						if (!(EIF_BOOLEAN)(loc5 == NULL)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
							tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
						}
						tb2 = tb3;
					}
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						ti4_1 = F1381_11418(RTCW(loc3));
						loc7 = F1506_12165(RTCW(tr1), ti4_1);
					} else {
						if ((EIF_BOOLEAN)(loc5 == NULL)) {
							tr1 = RTOSCF(3203,F373_3203, (Current));
							tr2 = RTMS_EX_H("Reserved attribute in the per-element-partition of \'uri\'",56,481504807);
							tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 2L), tr2, tr3);
						}
					}
				}
			}
		}
		F1320_11364(RTCW(loc3));
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc6 == NULL) || (EIF_BOOLEAN)(loc7 == NULL))) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		if ((EIF_BOOLEAN)(loc6 == NULL)) {
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Missing \'name\' attribute from \'uri\'",35,1701446695);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
		}
		if ((EIF_BOOLEAN)(loc7 == NULL)) {
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Missing \'uri\' attribute from \'uri\'",34,2080509735);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
		}
	} else {
		tr1 = RTOSCF(4521,F954_4521, (Current));
		tr1 = F1138_8299(RTCW(tr1), loc6);
		tr2 = RTOSCF(15899,F1756_15899, (RTCV(RTOSCF(3203,F373_3203, (Current)))));
		tr1 = F1753_15774(Current, tr1, tr2, (EIF_BOOLEAN) 0);
		loc6 = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(4521,F954_4521, (Current));
		tr1 = F1138_8299(RTCW(tr1), loc7);
		tr2 = RTOSCF(15899,F1756_15899, (RTCV(RTOSCF(3203,F373_3203, (Current)))));
		tr1 = F1753_15774(Current, tr1, tr2, (EIF_BOOLEAN) 0);
		loc7 = (EIF_REFERENCE) tr1;
		loc2 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
		F1707_14587(RTCW(loc2), loc1, loc7);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
			tb2 = F1525_12411(RTCW(tr1), loc6);
			if ((EIF_BOOLEAN) !tb2) {
				loc8 = RTLNS(eif_new_type(90, 0x01).id, 90, _OBJSIZ_1_0_0_0_0_0_0_0_);
				F91_1034(RTCW(loc8), loc2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
				F1525_12424(RTCW(tr1), loc8, loc6);
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("URI added is",12,1685934963);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, loc6);
			} else {
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("URI is a duplicate",18,503814245);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, loc6);
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.add_public_entry */
void F1754_15830 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc2);
	RTLR(11,loc8);
	RTLIU(12);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_2_) == ((EIF_INTEGER_32) 1L))) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc9 = *(EIF_BOOLEAN *)(Current+ _CHROFF_19_3_);
	} else {
		loc1 = *(EIF_REFERENCE *)(Current);
		loc9 = *(EIF_BOOLEAN *)(Current+ _CHROFF_19_2_);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = F1506_12168(RTCW(tr1));
	F1320_11363(RTCW(loc3));
	for (;;) {
		tb1 = F1384_11438(RTCW(loc3));
		if (tb1) break;
		loc4 = F1307_11343(RTCW(loc3));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = F1381_11418(RTCW(loc3));
		loc5 = F1506_12165(RTCW(tr1), ti4_1);
		tb2 = '\0';
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15876,F1754_15876, (Current));
		tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
		if (tb3) {
			tb3 = '\0';
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15812,F1754_15812, (Current));
				tb4 = F1148_8369(RTCW(tr1), loc5, tr2);
				tb3 = tb4;
			}
			tb2 = tb3;
		}
		if (tb2) {
			loc1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			ti4_1 = F1381_11418(RTCW(loc3));
			tr1 = F1506_12165(RTCW(tr1), ti4_1);
			F1707_14586(RTCW(loc1), tr1);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("xml:base set to",15,2041105263);
			tr3 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, tr3);
		} else {
			tb2 = '\0';
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTOSCF(15878,F1754_15878, (Current));
			tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
			if (tb3) {
				tb3 = '\01';
				if (!(EIF_BOOLEAN)(loc5 == NULL)) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
					tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				}
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				tb2 = '\0';
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15880,F1754_15880, (Current));
				tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
				if (tb3) {
					tb3 = '\01';
					if (!(EIF_BOOLEAN)(loc5 == NULL)) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
						tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
					}
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					ti4_1 = F1381_11418(RTCW(loc3));
					loc6 = F1506_12165(RTCW(tr1), ti4_1);
				} else {
					tb2 = '\0';
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTOSCF(15861,F1754_15861, (Current));
					tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
					if (tb3) {
						tb3 = '\01';
						if (!(EIF_BOOLEAN)(loc5 == NULL)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
							tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
						}
						tb2 = tb3;
					}
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						ti4_1 = F1381_11418(RTCW(loc3));
						loc7 = F1506_12165(RTCW(tr1), ti4_1);
					} else {
						if ((EIF_BOOLEAN)(loc5 == NULL)) {
							tr1 = RTOSCF(3203,F373_3203, (Current));
							tr2 = RTMS_EX_H("Reserved attribute in the per-element-partition of \'public\'",59,868372263);
							tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 2L), tr2, tr3);
						}
					}
				}
			}
		}
		F1320_11364(RTCW(loc3));
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc6 == NULL) || (EIF_BOOLEAN)(loc7 == NULL))) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		if ((EIF_BOOLEAN)(loc6 == NULL)) {
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Missing \'publicId\' attribute from \'public\'",42,284271911);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
		}
		if ((EIF_BOOLEAN)(loc7 == NULL)) {
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Missing \'uri\' attribute from \'public\'",37,1593964327);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
		}
	} else {
		tr1 = F178_1649(Current, loc6);
		loc6 = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(4521,F954_4521, (Current));
		tr1 = F1138_8299(RTCW(tr1), loc7);
		tr2 = RTOSCF(15899,F1756_15899, (RTCV(RTOSCF(3203,F373_3203, (Current)))));
		tr1 = F1753_15774(Current, tr1, tr2, (EIF_BOOLEAN) 0);
		loc7 = (EIF_REFERENCE) tr1;
		loc2 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
		F1707_14587(RTCW(loc2), loc1, loc7);
		tb2 = F1707_14603(RTCW(loc2));
		if (tb2) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Fragment identifier present in  \'uri\' attribute from \'public\'",61,670129703);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
		} else {
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
				F1525_12414(RTCW(tr1), loc6);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
				tb2 = F1509_12249(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb2) {
					loc8 = RTLNS(eif_new_type(91, 0x01).id, 91, _OBJSIZ_1_1_0_0_0_0_0_0_);
					F92_1037(RTCW(loc8), loc2, loc9);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
					F1525_12424(RTCW(tr1), loc8, loc6);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("Public URI added is",19,703814003);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, loc6);
				} else {
					if (loc9) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
						loc8 = F1509_12241(RTCW(tr1));
						tb2 = '\0';
						tb3 = *(EIF_BOOLEAN *)(RTCW(loc8)+ _CHROFF_1_0_);
						if ((EIF_BOOLEAN) !tb3) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
							tb3 = F1525_12411(RTCW(tr1), loc6);
							tb2 = (EIF_BOOLEAN) !tb3;
						}
						if (tb2) {
							loc8 = RTLNS(eif_new_type(91, 0x01).id, 91, _OBJSIZ_1_1_0_0_0_0_0_0_);
							F92_1037(RTCW(loc8), loc2, (EIF_BOOLEAN) 1);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
							F1525_12424(RTCW(tr1), loc8, loc6);
							tr1 = RTOSCF(3203,F373_3203, (Current));
							tr2 = RTMS_EX_H("Public URI added is",19,703814003);
							F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, loc6);
						} else {
							tr1 = RTOSCF(3203,F373_3203, (Current));
							tr2 = RTMS_EX_H("Public URI is a duplicate",25,1356631141);
							F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, loc6);
						}
					} else {
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("Public URI is a duplicate",25,1356631141);
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, loc6);
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.add_next_catalog */
void F1754_15831 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc6);
	RTLR(9,loc2);
	RTLIU(10);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_2_) == ((EIF_INTEGER_32) 1L))) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	} else {
		loc1 = *(EIF_REFERENCE *)(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = F1506_12168(RTCW(tr1));
	F1320_11363(RTCW(loc3));
	for (;;) {
		tb1 = F1384_11438(RTCW(loc3));
		if (tb1) break;
		loc4 = F1307_11343(RTCW(loc3));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = F1381_11418(RTCW(loc3));
		loc5 = F1506_12165(RTCW(tr1), ti4_1);
		tb2 = '\0';
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15876,F1754_15876, (Current));
		tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
		if (tb3) {
			tb3 = '\0';
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15812,F1754_15812, (Current));
				tb4 = F1148_8369(RTCW(tr1), loc5, tr2);
				tb3 = tb4;
			}
			tb2 = tb3;
		}
		if (tb2) {
			loc1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			ti4_1 = F1381_11418(RTCW(loc3));
			tr1 = F1506_12165(RTCW(tr1), ti4_1);
			F1707_14586(RTCW(loc1), tr1);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("xml:base set to",15,2041105263);
			tr3 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, tr3);
		} else {
			tb2 = '\0';
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTOSCF(15878,F1754_15878, (Current));
			tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
			if (tb3) {
				tb3 = '\01';
				if (!(EIF_BOOLEAN)(loc5 == NULL)) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
					tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				}
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				tb2 = '\0';
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15856,F1754_15856, (Current));
				tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
				if (tb3) {
					tb3 = '\01';
					if (!(EIF_BOOLEAN)(loc5 == NULL)) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
						tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
					}
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					ti4_1 = F1381_11418(RTCW(loc3));
					loc6 = F1506_12165(RTCW(tr1), ti4_1);
				} else {
					if ((EIF_BOOLEAN)(loc5 == NULL)) {
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("Reserved attribute in the per-element-partition of \'nextCatalog\'",64,1344657447);
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 2L), tr2, tr3);
					}
				}
			}
		}
		F1320_11364(RTCW(loc3));
	}
	if ((EIF_BOOLEAN)(loc6 == NULL)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Missing \'catalog\' attribute from \'nextCatalog\'",46,393856551);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
	} else {
		loc2 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
		F1707_14587(RTCW(loc2), loc1, loc6);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
			F1506_12183(RTCW(tr1), tr2);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Next catalog URI added is",25,1306501235);
			tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
		}
	}
	RTLE;
}

/* {XM_CATALOG}.add_rewrite_rule */
void F1754_15832 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc6);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,loc5);
	RTLR(11,loc2);
	RTLIU(12);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_2_) == ((EIF_INTEGER_32) 1L))) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	} else {
		loc1 = *(EIF_REFERENCE *)(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = F1506_12168(RTCW(tr1));
	F1320_11363(RTCW(loc3));
	for (;;) {
		tb1 = F1384_11438(RTCW(loc3));
		if (tb1) break;
		loc4 = F1307_11343(RTCW(loc3));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = F1381_11418(RTCW(loc3));
		loc6 = F1506_12165(RTCW(tr1), ti4_1);
		tb2 = '\0';
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15876,F1754_15876, (Current));
		tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
		if (tb3) {
			tb3 = '\0';
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15812,F1754_15812, (Current));
				tb4 = F1148_8369(RTCW(tr1), loc6, tr2);
				tb3 = tb4;
			}
			tb2 = tb3;
		}
		if (tb2) {
			loc1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			ti4_1 = F1381_11418(RTCW(loc3));
			tr1 = F1506_12165(RTCW(tr1), ti4_1);
			F1707_14586(RTCW(loc1), tr1);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("xml:base set to",15,2041105263);
			tr3 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, tr3);
		} else {
			tb2 = '\0';
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTOSCF(15878,F1754_15878, (Current));
			tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
			if (tb3) {
				tb3 = '\01';
				if (!(EIF_BOOLEAN)(loc6 == NULL)) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
					tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				}
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				tb2 = '\0';
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15866,F1754_15866, (Current));
				tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
				if (tb3) {
					tb3 = '\01';
					if (!(EIF_BOOLEAN)(loc6 == NULL)) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
						tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
					}
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					ti4_1 = F1381_11418(RTCW(loc3));
					loc7 = F1506_12165(RTCW(tr1), ti4_1);
				} else {
					tb2 = '\0';
					tb3 = '\0';
					if (arg1) {
						tr1 = RTOSCF(8530,F1163_8530, (Current));
						tr2 = RTOSCF(15869,F1754_15869, (Current));
						tb4 = F1148_8369(RTCW(tr1), loc4, tr2);
						tb3 = tb4;
					}
					if (tb3) {
						tb3 = '\01';
						if (!(EIF_BOOLEAN)(loc6 == NULL)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
							tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
						}
						tb2 = tb3;
					}
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						ti4_1 = F1381_11418(RTCW(loc3));
						loc8 = F1506_12165(RTCW(tr1), ti4_1);
					} else {
						tb2 = '\0';
						tb3 = '\0';
						if ((EIF_BOOLEAN) !arg1) {
							tr1 = RTOSCF(8530,F1163_8530, (Current));
							tr2 = RTOSCF(15870,F1754_15870, (Current));
							tb4 = F1148_8369(RTCW(tr1), loc4, tr2);
							tb3 = tb4;
						}
						if (tb3) {
							tb3 = '\01';
							if (!(EIF_BOOLEAN)(loc6 == NULL)) {
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
								tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
							}
							tb2 = tb3;
						}
						if (tb2) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
							ti4_1 = F1381_11418(RTCW(loc3));
							loc8 = F1506_12165(RTCW(tr1), ti4_1);
						} else {
							if ((EIF_BOOLEAN)(loc6 == NULL)) {
								loc5 = RTMS_EX_H("Reserved attribute in the per-element-partition of \'",52,687950375);
								if (arg1) {
									tr1 = RTOSCF(8530,F1163_8530, (Current));
									tr2 = RTOSCF(15867,F1754_15867, (Current));
									tr1 = F1148_8367(RTCW(tr1), loc5, tr2);
									loc5 = (EIF_REFERENCE) tr1;
								} else {
									tr1 = RTOSCF(8530,F1163_8530, (Current));
									tr2 = RTOSCF(15868,F1754_15868, (Current));
									tr1 = F1148_8367(RTCW(tr1), loc5, tr2);
									loc5 = (EIF_REFERENCE) tr1;
								}
								tr1 = RTOSCF(3203,F373_3203, (Current));
								tr2 = RTOSCF(8530,F1163_8530, (Current));
								tr3 = RTMS_EX_H("\'",1,39);
								tr2 = F1148_8377(RTCW(tr2), loc5, tr3);
								tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 2L), tr2, tr3);
							}
						}
					}
				}
			}
		}
		F1320_11364(RTCW(loc3));
	}
	if ((EIF_BOOLEAN)(loc7 == NULL)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		F1754_15849(Current, arg1);
	} else {
		if ((EIF_BOOLEAN)(loc8 == NULL)) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1754_15850(Current, arg1);
		} else {
			tr1 = RTOSCF(4521,F954_4521, (Current));
			tr1 = F1138_8299(RTCW(tr1), loc8);
			tr2 = RTOSCF(15899,F1756_15899, (RTCV(RTOSCF(3203,F373_3203, (Current)))));
			tr1 = F1753_15774(Current, tr1, tr2, (EIF_BOOLEAN) 0);
			loc8 = (EIF_REFERENCE) tr1;
			loc2 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			F1707_14587(RTCW(loc2), loc1, loc7);
			F1754_15851(Current, loc8, loc2, arg1);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_)) {
				if (arg1) {
					F1754_15840(Current, loc8, loc2);
				} else {
					F1754_15841(Current, loc8, loc2);
				}
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.add_suffix */
void F1754_15833 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc6);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc8);
	RTLR(9,loc7);
	RTLR(10,loc5);
	RTLR(11,loc2);
	RTLIU(12);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_2_) == ((EIF_INTEGER_32) 1L))) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	} else {
		loc1 = *(EIF_REFERENCE *)(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = F1506_12168(RTCW(tr1));
	F1320_11363(RTCW(loc3));
	for (;;) {
		tb1 = F1384_11438(RTCW(loc3));
		if (tb1) break;
		loc4 = F1307_11343(RTCW(loc3));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = F1381_11418(RTCW(loc3));
		loc6 = F1506_12165(RTCW(tr1), ti4_1);
		tb2 = '\0';
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15876,F1754_15876, (Current));
		tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
		if (tb3) {
			tb3 = '\0';
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15812,F1754_15812, (Current));
				tb4 = F1148_8369(RTCW(tr1), loc6, tr2);
				tb3 = tb4;
			}
			tb2 = tb3;
		}
		if (tb2) {
			loc1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			ti4_1 = F1381_11418(RTCW(loc3));
			tr1 = F1506_12165(RTCW(tr1), ti4_1);
			F1707_14586(RTCW(loc1), tr1);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("xml:base set to",15,2041105263);
			tr3 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, tr3);
		} else {
			tb2 = '\0';
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTOSCF(15878,F1754_15878, (Current));
			tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
			if (tb3) {
				tb3 = '\01';
				if (!(EIF_BOOLEAN)(loc6 == NULL)) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
					tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				}
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				tb2 = '\0';
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15861,F1754_15861, (Current));
				tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
				if (tb3) {
					tb3 = '\01';
					if (!(EIF_BOOLEAN)(loc6 == NULL)) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
						tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
					}
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					ti4_1 = F1381_11418(RTCW(loc3));
					loc8 = F1506_12165(RTCW(tr1), ti4_1);
				} else {
					tb2 = '\0';
					tb3 = '\0';
					if (arg1) {
						tr1 = RTOSCF(8530,F1163_8530, (Current));
						tr2 = RTOSCF(15865,F1754_15865, (Current));
						tb4 = F1148_8369(RTCW(tr1), loc4, tr2);
						tb3 = tb4;
					}
					if (tb3) {
						tb3 = '\01';
						if (!(EIF_BOOLEAN)(loc6 == NULL)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
							tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
						}
						tb2 = tb3;
					}
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						ti4_1 = F1381_11418(RTCW(loc3));
						loc7 = F1506_12165(RTCW(tr1), ti4_1);
					} else {
						tb2 = '\0';
						tb3 = '\0';
						if ((EIF_BOOLEAN) !arg1) {
							tr1 = RTOSCF(8530,F1163_8530, (Current));
							tr2 = RTOSCF(15863,F1754_15863, (Current));
							tb4 = F1148_8369(RTCW(tr1), loc4, tr2);
							tb3 = tb4;
						}
						if (tb3) {
							tb3 = '\01';
							if (!(EIF_BOOLEAN)(loc6 == NULL)) {
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
								tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
							}
							tb2 = tb3;
						}
						if (tb2) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
							ti4_1 = F1381_11418(RTCW(loc3));
							loc7 = F1506_12165(RTCW(tr1), ti4_1);
						} else {
							if ((EIF_BOOLEAN)(loc6 == NULL)) {
								loc5 = RTMS_EX_H("Reserved attribute in the per-element-partition of \'",52,687950375);
								if (arg1) {
									tr1 = RTOSCF(8530,F1163_8530, (Current));
									tr2 = RTOSCF(15864,F1754_15864, (Current));
									tr1 = F1148_8367(RTCW(tr1), loc5, tr2);
									loc5 = (EIF_REFERENCE) tr1;
								} else {
									tr1 = RTOSCF(8530,F1163_8530, (Current));
									tr2 = RTOSCF(15862,F1754_15862, (Current));
									tr1 = F1148_8367(RTCW(tr1), loc5, tr2);
									loc5 = (EIF_REFERENCE) tr1;
								}
								tr1 = RTOSCF(3203,F373_3203, (Current));
								tr2 = RTOSCF(8530,F1163_8530, (Current));
								tr3 = RTMS_EX_H("\'",1,39);
								tr2 = F1148_8377(RTCW(tr2), loc5, tr3);
								tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 2L), tr2, tr3);
							}
						}
					}
				}
			}
		}
		F1320_11364(RTCW(loc3));
	}
	if ((EIF_BOOLEAN)(loc8 == NULL)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		F1754_15852(Current, arg1);
	} else {
		if ((EIF_BOOLEAN)(loc7 == NULL)) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1754_15853(Current, arg1);
		} else {
			tr1 = RTOSCF(4521,F954_4521, (Current));
			tr1 = F1138_8299(RTCW(tr1), loc7);
			tr2 = RTOSCF(15899,F1756_15899, (RTCV(RTOSCF(3203,F373_3203, (Current)))));
			tr1 = F1753_15774(Current, tr1, tr2, (EIF_BOOLEAN) 0);
			loc7 = (EIF_REFERENCE) tr1;
			loc2 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			F1707_14587(RTCW(loc2), loc1, loc8);
			F1754_15854(Current, loc7, loc2, arg1);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_)) {
				if (arg1) {
					F1754_15842(Current, loc7, loc2);
				} else {
					F1754_15843(Current, loc7, loc2);
				}
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.add_system_delegate */
void F1754_15834 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc2);
	RTLIU(11);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_2_) == ((EIF_INTEGER_32) 1L))) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	} else {
		loc1 = *(EIF_REFERENCE *)(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = F1506_12168(RTCW(tr1));
	F1320_11363(RTCW(loc3));
	for (;;) {
		tb1 = F1384_11438(RTCW(loc3));
		if (tb1) break;
		loc4 = F1307_11343(RTCW(loc3));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = F1381_11418(RTCW(loc3));
		loc5 = F1506_12165(RTCW(tr1), ti4_1);
		tb2 = '\0';
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15876,F1754_15876, (Current));
		tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
		if (tb3) {
			tb3 = '\0';
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15812,F1754_15812, (Current));
				tb4 = F1148_8369(RTCW(tr1), loc5, tr2);
				tb3 = tb4;
			}
			tb2 = tb3;
		}
		if (tb2) {
			loc1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			ti4_1 = F1381_11418(RTCW(loc3));
			tr1 = F1506_12165(RTCW(tr1), ti4_1);
			F1707_14586(RTCW(loc1), tr1);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("xml:base set to",15,2041105263);
			tr3 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, tr3);
		} else {
			tb2 = '\0';
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTOSCF(15878,F1754_15878, (Current));
			tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
			if (tb3) {
				tb3 = '\01';
				if (!(EIF_BOOLEAN)(loc5 == NULL)) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
					tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				}
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				tb2 = '\0';
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15856,F1754_15856, (Current));
				tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
				if (tb3) {
					tb3 = '\01';
					if (!(EIF_BOOLEAN)(loc5 == NULL)) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
						tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
					}
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					ti4_1 = F1381_11418(RTCW(loc3));
					loc6 = F1506_12165(RTCW(tr1), ti4_1);
				} else {
					tb2 = '\0';
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTOSCF(15869,F1754_15869, (Current));
					tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
					if (tb3) {
						tb3 = '\01';
						if (!(EIF_BOOLEAN)(loc5 == NULL)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
							tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
						}
						tb2 = tb3;
					}
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						ti4_1 = F1381_11418(RTCW(loc3));
						loc7 = F1506_12165(RTCW(tr1), ti4_1);
					} else {
						if ((EIF_BOOLEAN)(loc5 == NULL)) {
							tr1 = RTOSCF(3203,F373_3203, (Current));
							tr2 = RTMS_EX_H("Reserved attribute in the per-element-partition of \'delagateSystem\'",67,1840914983);
							tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 2L), tr2, tr3);
						}
					}
				}
			}
		}
		F1320_11364(RTCW(loc3));
	}
	if ((EIF_BOOLEAN)(loc6 == NULL)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Missing \'catalog\' attribute from \'delegateSystem\'",49,1869574183);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
	} else {
		if ((EIF_BOOLEAN)(loc7 == NULL)) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Missing \'systemIdStartString\' attribute from \'delegateSystem\'",61,304732711);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
		} else {
			tr1 = RTOSCF(4521,F954_4521, (Current));
			tr1 = F1138_8299(RTCW(tr1), loc7);
			tr2 = RTOSCF(15899,F1756_15899, (RTCV(RTOSCF(3203,F373_3203, (Current)))));
			tr1 = F1753_15774(Current, tr1, tr2, (EIF_BOOLEAN) 0);
			loc7 = (EIF_REFERENCE) tr1;
			loc2 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			F1707_14587(RTCW(loc2), loc1, loc6);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Catalog name from \'delegateSystem\'",34,2018465575);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, loc6);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_)) {
				F1754_15837(Current, loc7, loc2);
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.add_uri_delegate */
void F1754_15835 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc2);
	RTLIU(11);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_2_) == ((EIF_INTEGER_32) 1L))) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	} else {
		loc1 = *(EIF_REFERENCE *)(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = F1506_12168(RTCW(tr1));
	F1320_11363(RTCW(loc3));
	for (;;) {
		tb1 = F1384_11438(RTCW(loc3));
		if (tb1) break;
		loc4 = F1307_11343(RTCW(loc3));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = F1381_11418(RTCW(loc3));
		loc5 = F1506_12165(RTCW(tr1), ti4_1);
		tb2 = '\0';
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15876,F1754_15876, (Current));
		tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
		if (tb3) {
			tb3 = '\0';
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15812,F1754_15812, (Current));
				tb4 = F1148_8369(RTCW(tr1), loc5, tr2);
				tb3 = tb4;
			}
			tb2 = tb3;
		}
		if (tb2) {
			loc1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			ti4_1 = F1381_11418(RTCW(loc3));
			tr1 = F1506_12165(RTCW(tr1), ti4_1);
			F1707_14586(RTCW(loc1), tr1);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("xml:base set to",15,2041105263);
			tr3 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, tr3);
		} else {
			tb2 = '\0';
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTMS_EX_H("id",2,26980);
			tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
			if (tb3) {
				tb3 = '\01';
				if (!(EIF_BOOLEAN)(loc5 == NULL)) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
					tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				}
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				tb2 = '\0';
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15856,F1754_15856, (Current));
				tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
				if (tb3) {
					tb3 = '\01';
					if (!(EIF_BOOLEAN)(loc5 == NULL)) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
						tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
					}
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					ti4_1 = F1381_11418(RTCW(loc3));
					loc6 = F1506_12165(RTCW(tr1), ti4_1);
				} else {
					tb2 = '\0';
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTOSCF(15870,F1754_15870, (Current));
					tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
					if (tb3) {
						tb3 = '\01';
						if (!(EIF_BOOLEAN)(loc5 == NULL)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
							tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
						}
						tb2 = tb3;
					}
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						ti4_1 = F1381_11418(RTCW(loc3));
						loc7 = F1506_12165(RTCW(tr1), ti4_1);
					} else {
						if ((EIF_BOOLEAN)(loc5 == NULL)) {
							tr1 = RTOSCF(3203,F373_3203, (Current));
							tr2 = RTMS_EX_H("Reserved attribute in the per-element-partition of \'delagateUri\'",64,673607463);
							tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 2L), tr2, tr3);
						}
					}
				}
			}
		}
		F1320_11364(RTCW(loc3));
	}
	if ((EIF_BOOLEAN)(loc6 == NULL)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Missing \'catalog\' attribute from \'delegateSystem\'",49,1869574183);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
	} else {
		if ((EIF_BOOLEAN)(loc7 == NULL)) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Missing \'uriStartString\' attribute from \'delegateSystem\'",56,1566790439);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
		} else {
			tr1 = RTOSCF(4521,F954_4521, (Current));
			tr1 = F1138_8299(RTCW(tr1), loc7);
			tr2 = RTOSCF(15899,F1756_15899, (RTCV(RTOSCF(3203,F373_3203, (Current)))));
			tr1 = F1753_15774(Current, tr1, tr2, (EIF_BOOLEAN) 0);
			loc7 = (EIF_REFERENCE) tr1;
			loc2 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			F1707_14587(RTCW(loc2), loc1, loc6);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Catalog name from \'delegateSystem\'",34,2018465575);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, loc6);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_)) {
				F1754_15838(Current, loc7, loc2);
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.add_public_delegate */
void F1754_15836 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc2);
	RTLIU(11);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_19_5_0_2_) == ((EIF_INTEGER_32) 1L))) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc8 = *(EIF_BOOLEAN *)(Current+ _CHROFF_19_3_);
	} else {
		loc1 = *(EIF_REFERENCE *)(Current);
		loc8 = *(EIF_BOOLEAN *)(Current+ _CHROFF_19_2_);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = F1506_12168(RTCW(tr1));
	F1320_11363(RTCW(loc3));
	for (;;) {
		tb1 = F1384_11438(RTCW(loc3));
		if (tb1) break;
		loc4 = F1307_11343(RTCW(loc3));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = F1381_11418(RTCW(loc3));
		loc5 = F1506_12165(RTCW(tr1), ti4_1);
		tb2 = '\0';
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15876,F1754_15876, (Current));
		tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
		if (tb3) {
			tb3 = '\0';
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15812,F1754_15812, (Current));
				tb4 = F1148_8369(RTCW(tr1), loc5, tr2);
				tb3 = tb4;
			}
			tb2 = tb3;
		}
		if (tb2) {
			loc1 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			ti4_1 = F1381_11418(RTCW(loc3));
			tr1 = F1506_12165(RTCW(tr1), ti4_1);
			F1707_14586(RTCW(loc1), tr1);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("xml:base set to",15,2041105263);
			tr3 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, tr3);
		} else {
			tb2 = '\0';
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = RTOSCF(15878,F1754_15878, (Current));
			tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
			if (tb3) {
				tb3 = '\01';
				if (!(EIF_BOOLEAN)(loc5 == NULL)) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
					tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				}
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				tb2 = '\0';
				tr1 = RTOSCF(8530,F1163_8530, (Current));
				tr2 = RTOSCF(15856,F1754_15856, (Current));
				tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
				if (tb3) {
					tb3 = '\01';
					if (!(EIF_BOOLEAN)(loc5 == NULL)) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
						tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
					}
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					ti4_1 = F1381_11418(RTCW(loc3));
					loc6 = F1506_12165(RTCW(tr1), ti4_1);
				} else {
					tb2 = '\0';
					tr1 = RTOSCF(8530,F1163_8530, (Current));
					tr2 = RTOSCF(15871,F1754_15871, (Current));
					tb3 = F1148_8369(RTCW(tr1), loc4, tr2);
					if (tb3) {
						tb3 = '\01';
						if (!(EIF_BOOLEAN)(loc5 == NULL)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
							tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
						}
						tb2 = tb3;
					}
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						ti4_1 = F1381_11418(RTCW(loc3));
						loc7 = F1506_12165(RTCW(tr1), ti4_1);
					} else {
						if ((EIF_BOOLEAN)(loc5 == NULL)) {
							tr1 = RTOSCF(3203,F373_3203, (Current));
							tr2 = RTMS_EX_H("Reserved attribute in the per-element-partition of \'delegateSystem\'",67,328883751);
							tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 2L), tr2, tr3);
						}
					}
				}
			}
		}
		F1320_11364(RTCW(loc3));
	}
	if ((EIF_BOOLEAN)(loc6 == NULL)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Missing \'catalog\' attribute from \'delegatePublic\'",49,217671719);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
	} else {
		if ((EIF_BOOLEAN)(loc7 == NULL)) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Missing \'publicIdStartString\' attribute from \'delegatePublic\'",61,529030183);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
		} else {
			tr1 = F178_1649(Current, loc7);
			loc7 = (EIF_REFERENCE) tr1;
			loc2 = RTLNS(eif_new_type(1706, 0x01).id, 1706, _OBJSIZ_11_1_0_1_0_0_0_0_);
			F1707_14587(RTCW(loc2), loc1, loc6);
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Catalog name from \'delegatePublic\'",34,366563111);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, loc6);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_19_0_)) {
				F1754_15839(Current, loc7, loc2, loc8);
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.insert_system_delegate */
void F1754_15837 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,loc3);
	RTLR(8,loc2);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		loc1 = RTLNS(eif_new_type(92, 0x01).id, 92, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F93_1039(RTCW(loc1), arg1, arg2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		F1482_11952(RTCW(tr1), loc1);
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("System delegation catalog URI added is",38,1695824499);
		tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
	} else {
		loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
		F1320_11363(RTCW(loc3));
		for (;;) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
			if (tb1) break;
			loc2 = F1387_11451(RTCW(loc3));
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
			tb2 = F1148_8369(RTCW(tr1), tr2, arg1);
			if (tb2) {
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("System delegation catalog is a duplicate for systemIdStartString",64,2096091751);
				tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, tr3);
				F1320_11366(RTCW(loc3));
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O1041[Dtype(loc2)-92]);
				if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
					loc1 = RTLNS(eif_new_type(92, 0x01).id, 92, _OBJSIZ_2_0_0_1_0_0_0_0_);
					F93_1039(RTCW(loc1), arg1, arg2);
					F1381_11424(RTCW(loc3), loc1);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("System delegation catalog URI added is",38,1695824499);
					tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("System delegation prefix string is",34,1030956147);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, arg1);
					F1320_11366(RTCW(loc3));
				} else {
					F1320_11364(RTCW(loc3));
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
					if (tb2) {
						loc1 = RTLNS(eif_new_type(92, 0x01).id, 92, _OBJSIZ_2_0_0_1_0_0_0_0_);
						F93_1039(RTCW(loc1), arg1, arg2);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
						F1482_11954(RTCW(tr1), loc1);
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("System delegation catalog URI added is",38,1695824499);
						tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.insert_uri_delegate */
void F1754_15838 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,loc3);
	RTLR(8,loc2);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		loc1 = RTLNS(eif_new_type(92, 0x01).id, 92, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F93_1039(RTCW(loc1), arg1, arg2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		F1482_11952(RTCW(tr1), loc1);
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Uri delegation catalog URI added is",35,1138044019);
		tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
	} else {
		loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
		F1320_11363(RTCW(loc3));
		for (;;) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
			if (tb1) break;
			loc2 = F1387_11451(RTCW(loc3));
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
			tb2 = F1148_8369(RTCW(tr1), tr2, arg1);
			if (tb2) {
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("Uri delegation catalog is a duplicate for uriStartString",56,1665157479);
				tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, tr3);
				F1320_11366(RTCW(loc3));
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O1041[Dtype(loc2)-92]);
				if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
					loc1 = RTLNS(eif_new_type(92, 0x01).id, 92, _OBJSIZ_2_0_0_1_0_0_0_0_);
					F93_1039(RTCW(loc1), arg1, arg2);
					F1381_11424(RTCW(loc3), loc1);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("Uri delegation catalog URI added is",35,1138044019);
					tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("Uri delegation prefix string is",31,882685043);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, arg1);
					F1320_11366(RTCW(loc3));
				} else {
					F1320_11364(RTCW(loc3));
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
					if (tb2) {
						loc1 = RTLNS(eif_new_type(92, 0x01).id, 92, _OBJSIZ_2_0_0_1_0_0_0_0_);
						F93_1039(RTCW(loc1), arg1, arg2);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
						F1482_11954(RTCW(tr1), loc1);
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("Uri delegation catalog URI added is",35,1138044019);
						tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.insert_public_delegate */
void F1754_15839 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,loc3);
	RTLR(8,loc2);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		loc1 = RTLNS(eif_new_type(93, 0x01).id, 93, _OBJSIZ_2_1_0_1_0_0_0_0_);
		F94_1044(RTCW(loc1), arg1, arg2, arg3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1482_11952(RTCW(tr1), loc1);
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Public delegation catalog URI added is",38,1470778483);
		tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
	} else {
		loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
		F1320_11363(RTCW(loc3));
		for (;;) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
			if (tb1) break;
			loc2 = F1387_11451(RTCW(loc3));
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
			tb2 = F1148_8369(RTCW(tr1), tr2, arg1);
			if (tb2) {
				tb2 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_2_0_);
				if ((EIF_BOOLEAN)((EIF_BOOLEAN) !tb2 == arg3)) {
					loc1 = RTLNS(eif_new_type(93, 0x01).id, 93, _OBJSIZ_2_1_0_1_0_0_0_0_);
					F94_1044(RTCW(loc1), arg1, arg2, arg3);
					if (arg3) {
						F1381_11423(RTCW(loc3), loc1);
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("Public delegation catalog URI added is",38,1470778483);
						tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("Public delegation prefix string is",34,802197875);
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, arg1);
					} else {
						F1381_11422(RTCW(loc3), loc1);
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("Public delegation catalog URI added is",38,1470778483);
						tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("Public delegation prefix string is",34,802197875);
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, arg1);
					}
				} else {
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("Public delegation catalog is a duplicate for publicIdStartString",64,1961695335);
					tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, tr3);
				}
				F1320_11366(RTCW(loc3));
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_1_0_0_);
				if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
					loc1 = RTLNS(eif_new_type(93, 0x01).id, 93, _OBJSIZ_2_1_0_1_0_0_0_0_);
					F94_1044(RTCW(loc1), arg1, arg2, arg3);
					F1381_11424(RTCW(loc3), loc1);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("Public delegation catalog URI added is",38,1470778483);
					tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("Public delegation prefix string is",34,802197875);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, arg1);
					F1320_11366(RTCW(loc3));
				} else {
					F1320_11364(RTCW(loc3));
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
					if (tb2) {
						loc1 = RTLNS(eif_new_type(93, 0x01).id, 93, _OBJSIZ_2_1_0_1_0_0_0_0_);
						F94_1044(RTCW(loc1), arg1, arg2, arg3);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
						F1482_11954(RTCW(tr1), loc1);
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("Public delegation catalog URI added is",38,1470778483);
						tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.insert_system_rewrite_rule */
void F1754_15840 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,loc3);
	RTLR(8,loc2);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		loc1 = RTLNS(eif_new_type(10, 0x01).id, 10, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F11_126(RTCW(loc1), arg1, arg2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		F1482_11952(RTCW(tr1), loc1);
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("System rewrite rule added towards",33,431550067);
		tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
	} else {
		loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
		F1320_11363(RTCW(loc3));
		for (;;) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
			if (tb1) break;
			loc2 = F1387_11451(RTCW(loc3));
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
			tb2 = F1148_8369(RTCW(tr1), tr2, arg1);
			if (tb2) {
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("System rewrite rule is a duplicate for systemIdStartString",58,1894906983);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, arg1);
				F1320_11366(RTCW(loc3));
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
				if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
					loc1 = RTLNS(eif_new_type(10, 0x01).id, 10, _OBJSIZ_2_0_0_1_0_0_0_0_);
					F11_126(RTCW(loc1), arg1, arg2);
					F1381_11424(RTCW(loc3), loc1);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("System rewrite rule added targetted on",38,190211950);
					tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("System rewrite prefix string is",31,1671009907);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, arg1);
					F1320_11366(RTCW(loc3));
				} else {
					F1320_11364(RTCW(loc3));
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
					if (tb2) {
						loc1 = RTLNS(eif_new_type(10, 0x01).id, 10, _OBJSIZ_2_0_0_1_0_0_0_0_);
						F11_126(RTCW(loc1), arg1, arg2);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
						F1482_11954(RTCW(tr1), loc1);
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("System rewrite rule added towards",33,431550067);
						tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.insert_uri_rewrite_rule */
void F1754_15841 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,loc3);
	RTLR(8,loc2);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		loc1 = RTLNS(eif_new_type(10, 0x01).id, 10, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F11_126(RTCW(loc1), arg1, arg2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		F1482_11952(RTCW(tr1), loc1);
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Uri rewrite rule added towards",30,1370493299);
		tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
	} else {
		loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
		F1320_11363(RTCW(loc3));
		for (;;) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
			if (tb1) break;
			loc2 = F1387_11451(RTCW(loc3));
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
			tb2 = F1148_8369(RTCW(tr1), tr2, arg1);
			if (tb2) {
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("Uri rewrite rule is a duplicate for uriStartString",50,1256783463);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, arg1);
				F1320_11366(RTCW(loc3));
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
				if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
					loc1 = RTLNS(eif_new_type(10, 0x01).id, 10, _OBJSIZ_2_0_0_1_0_0_0_0_);
					F11_126(RTCW(loc1), arg1, arg2);
					F1381_11424(RTCW(loc3), loc1);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("Uri rewrite rule added targetted on",35,1779911278);
					tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("Uri rewrite prefix string is",28,91249011);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, arg1);
					F1320_11366(RTCW(loc3));
				} else {
					F1320_11364(RTCW(loc3));
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
					if (tb2) {
						loc1 = RTLNS(eif_new_type(10, 0x01).id, 10, _OBJSIZ_2_0_0_1_0_0_0_0_);
						F11_126(RTCW(loc1), arg1, arg2);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
						F1482_11954(RTCW(tr1), loc1);
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("Uri rewrite rule added towards",30,1370493299);
						tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.insert_system_suffix_rule */
void F1754_15842 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,loc3);
	RTLR(8,loc2);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		loc1 = RTLNS(eif_new_type(11, 0x01).id, 11, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F12_131(RTCW(loc1), arg1, arg2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		F1482_11952(RTCW(tr1), loc1);
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("System suffix rule added towards",32,1858372211);
		tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
	} else {
		loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
		F1320_11363(RTCW(loc3));
		for (;;) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
			if (tb1) break;
			loc2 = F1387_11451(RTCW(loc3));
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
			tb2 = F1148_8369(RTCW(tr1), tr2, arg1);
			if (tb2) {
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("System suffix rule is a duplicate for systemIdSuffix",52,67843960);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, arg1);
				F1320_11366(RTCW(loc3));
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
				if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
					loc1 = RTLNS(eif_new_type(11, 0x01).id, 11, _OBJSIZ_2_0_0_1_0_0_0_0_);
					F12_131(RTCW(loc1), arg1, arg2);
					F1381_11424(RTCW(loc3), loc1);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("System suffix rule added targetted on",37,240336494);
					tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("System suffix string is",23,959480435);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, arg1);
					F1320_11366(RTCW(loc3));
				} else {
					F1320_11364(RTCW(loc3));
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
					if (tb2) {
						loc1 = RTLNS(eif_new_type(11, 0x01).id, 11, _OBJSIZ_2_0_0_1_0_0_0_0_);
						F12_131(RTCW(loc1), arg1, arg2);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
						F1482_11954(RTCW(tr1), loc1);
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("System suffix rule added towards",32,1858372211);
						tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.insert_uri_suffix_rule */
void F1754_15843 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,loc3);
	RTLR(8,loc2);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		loc1 = RTLNS(eif_new_type(11, 0x01).id, 11, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F12_131(RTCW(loc1), arg1, arg2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		F1482_11952(RTCW(tr1), loc1);
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("URI suffix rule added towards",29,1093463155);
		tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
	} else {
		loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
		F1320_11363(RTCW(loc3));
		for (;;) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
			if (tb1) break;
			loc2 = F1387_11451(RTCW(loc3));
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
			tb2 = F1148_8369(RTCW(tr1), tr2, arg1);
			if (tb2) {
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("URI suffix rule is a duplicate for systemIdSuffix",49,697851000);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 6L), tr2, arg1);
				F1320_11366(RTCW(loc3));
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
				if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
					loc1 = RTLNS(eif_new_type(11, 0x01).id, 11, _OBJSIZ_2_0_0_1_0_0_0_0_);
					F12_131(RTCW(loc1), arg1, arg2);
					F1381_11424(RTCW(loc3), loc1);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("URI suffix rule added targetted on",34,1510618990);
					tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("URI suffix string is",20,258101107);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, arg1);
					F1320_11366(RTCW(loc3));
				} else {
					F1320_11364(RTCW(loc3));
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
					if (tb2) {
						loc1 = RTLNS(eif_new_type(11, 0x01).id, 11, _OBJSIZ_2_0_0_1_0_0_0_0_);
						F12_131(RTCW(loc1), arg1, arg2);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
						F1482_11954(RTCW(tr1), loc1);
						tr1 = RTOSCF(3203,F373_3203, (Current));
						tr2 = RTMS_EX_H("URI suffix rule added towards",29,1093463155);
						tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
						F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 4L), tr2, tr3);
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_CATALOG}.resolved_suffixed_fsi */
EIF_REFERENCE F1754_15844 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,arg1);
	RTLR(7,Result);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
	F1320_11363(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		loc2 = F1387_11451(RTCW(loc1));
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Next suffix rule matches",24,1384368755);
		tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, tr3);
		tb2 = '\0';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN) (ti4_1 >= ti4_2)) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
			ti4_3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - ti4_2) + ((EIF_INTEGER_32) 1L)), ti4_3);
			tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
			tb3 = F1148_8369(RTCW(tr1), tr2, tr3);
			tb2 = tb3;
		}
		if (tb2) {
			Result = F12_134(RTCW(loc2));
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Suffix rule provisionally resolved to",37,162589807);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, Result);
			F1320_11366(RTCW(loc1));
		} else {
			F1320_11364(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {XM_CATALOG}.resolved_suffixed_uri */
EIF_REFERENCE F1754_15845 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,arg1);
	RTLR(7,Result);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
	F1320_11363(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		loc2 = F1387_11451(RTCW(loc1));
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Next suffix rule matches",24,1384368755);
		tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, tr3);
		tb2 = '\0';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN) (ti4_1 >= ti4_2)) {
			tr1 = RTOSCF(8530,F1163_8530, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
			ti4_3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(arg1))-1111])(arg1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - ti4_2) + ((EIF_INTEGER_32) 1L)), ti4_3);
			tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
			tb3 = F1148_8369(RTCW(tr1), tr2, tr3);
			tb2 = tb3;
		}
		if (tb2) {
			Result = F12_134(RTCW(loc2));
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Suffix rule provisionally resolved to",37,162589807);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), tr2, Result);
			F1320_11366(RTCW(loc1));
		} else {
			F1320_11364(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {XM_CATALOG}.resolved_delegated_fsi */
EIF_REFERENCE F1754_15846 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,arg1);
	RTLR(7,loc3);
	RTLR(8,Result);
	RTLIU(9);
	
	RTGC;
	tr1 = RTOSCF(3203,F373_3203, (Current));
	tr2 = RTMS_EX_H("Number of system delegate catalogs is",37,1675679091);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3)+ _LNGOFF_4_0_0_0_);
	tr3 = eif_out__i4_s1(ti4_1);
	F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 8L), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
	F1320_11363(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		loc2 = F1387_11451(RTCW(loc1));
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Examining system delegation with systemIdStartString",52,2033913191);
		tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, tr3);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5041[Dtype(RTCW(arg1))-1111])(arg1, tr1, ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Candidate match for systemIdStartString against",47,789833844);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, arg1);
			F1756_15915(RTCV(RTOSCF(3203,F373_3203, (Current))));
			*(EIF_BOOLEAN *)(Current+ _CHROFF_19_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = F93_1042(RTCW(loc2));
			loc3 = F1756_15922(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				Result = F1754_15789(RTCW(loc3), arg1);
			}
			if ((EIF_BOOLEAN)(Result == NULL)) {
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("No delegated match found for",28,2066989682);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
				F1320_11364(RTCW(loc1));
			} else {
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("Delegated match found for",25,2083533170);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
				F1320_11366(RTCW(loc1));
			}
		} else {
			F1320_11364(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {XM_CATALOG}.resolved_delegated_uri */
EIF_REFERENCE F1754_15847 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,arg1);
	RTLR(7,loc3);
	RTLR(8,Result);
	RTLIU(9);
	
	RTGC;
	tr1 = RTOSCF(3203,F373_3203, (Current));
	tr2 = RTMS_EX_H("Number of uri delegate catalogs is",34,659481203);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3)+ _LNGOFF_4_0_0_0_);
	tr3 = eif_out__i4_s1(ti4_1);
	F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 8L), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
	F1320_11363(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		loc2 = F1387_11451(RTCW(loc1));
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Examining uri delegation with uriStartString",44,705932647);
		tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, tr3);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5041[Dtype(RTCW(arg1))-1111])(arg1, tr1, ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Candidate match for uriStartString against",42,406762612);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, arg1);
			F1756_15915(RTCV(RTOSCF(3203,F373_3203, (Current))));
			*(EIF_BOOLEAN *)(Current+ _CHROFF_19_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = F93_1042(RTCW(loc2));
			loc3 = F1756_15922(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				Result = F1754_15789(RTCW(loc3), arg1);
			}
			if ((EIF_BOOLEAN)(Result == NULL)) {
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("No delegated match found for",28,2066989682);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
				F1320_11364(RTCW(loc1));
			} else {
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("Delegated match found for",25,2083533170);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
				F1320_11366(RTCW(loc1));
			}
		} else {
			F1320_11364(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {XM_CATALOG}.resolved_delegated_fpi */
EIF_REFERENCE F1754_15848 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,arg1);
	RTLR(7,loc3);
	RTLR(8,Result);
	RTLIU(9);
	
	RTGC;
	tr1 = RTOSCF(3203,F373_3203, (Current));
	tr2 = RTMS_EX_H("Number of public delegate catalogs is",37,1424570227);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3)+ _LNGOFF_4_0_0_0_);
	tr3 = eif_out__i4_s1(ti4_1);
	F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 8L), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
	F1320_11363(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		loc2 = F1387_11451(RTCW(loc1));
		tr1 = RTOSCF(3203,F373_3203, (Current));
		tr2 = RTMS_EX_H("Examining public delegation with publicIdStartString",52,239805543);
		tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
		F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, tr3);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5041[Dtype(RTCW(arg1))-1111])(arg1, tr1, ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			tr1 = RTOSCF(3203,F373_3203, (Current));
			tr2 = RTMS_EX_H("Candidate match for publicIdStartString against",47,538724980);
			F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, arg1);
			tb2 = '\01';
			if (!(EIF_BOOLEAN) !arg2) {
				tb3 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_2_0_);
				tb2 = tb3;
			}
			if (tb2) {
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = RTMS_EX_H("Match for publicIdStartString against",37,1443754612);
				F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 10L), tr2, arg1);
				F1756_15915(RTCV(RTOSCF(3203,F373_3203, (Current))));
				*(EIF_BOOLEAN *)(Current+ _CHROFF_19_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				tr1 = RTOSCF(3203,F373_3203, (Current));
				tr2 = F93_1042(RTCW(loc2));
				loc3 = F1756_15922(RTCW(tr1), tr2);
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					Result = F1754_15788(RTCW(loc3), arg1, arg2);
				}
				if ((EIF_BOOLEAN)(Result == NULL)) {
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("No delegated match found for",28,2066989682);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
					F1320_11364(RTCW(loc1));
				} else {
					tr1 = RTOSCF(3203,F373_3203, (Current));
					tr2 = RTMS_EX_H("Delegated match found for",25,2083533170);
					F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 9L), tr2, arg1);
					F1320_11366(RTCW(loc1));
				}
			}
		} else {
			F1320_11364(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {XM_CATALOG}.write_missing_rewrite_prefix_attribute */
void F1754_15849 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("Missing \'",9,101995559);
	tr3 = RTOSCF(15866,F1754_15866, (Current));
	loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("\' attribute from \'",18,403635751);
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	if (arg1) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15867,F1754_15867, (Current));
		tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15868,F1754_15868, (Current));
		tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
	}
	tr1 = RTOSCF(3203,F373_3203, (Current));
	tr2 = RTOSCF(8530,F1163_8530, (Current));
	tr3 = RTMS_EX_H("\'",1,39);
	tr2 = F1148_8377(RTCW(tr2), loc1, tr3);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
	RTLE;
}

/* {XM_CATALOG}.write_missing_start_string_attribute */
void F1754_15850 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	if (arg1) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("Missing \'",9,101995559);
		tr3 = RTOSCF(15869,F1754_15869, (Current));
		loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("Missing \'",9,101995559);
		tr3 = RTOSCF(15870,F1754_15870, (Current));
		loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
	}
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("\' attribute from \'",18,403635751);
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	if (arg1) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15867,F1754_15867, (Current));
		tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15868,F1754_15868, (Current));
		tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
	}
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("\'",1,39);
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3203,F373_3203, (Current));
	F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), loc1, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTLE;
}

/* {XM_CATALOG}.write_rewrite_rule_debug_message */
void F1754_15851 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLR(5,tr3);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc1 = RTMS_EX_H("Rewrite prefix from \'",21,1030887975);
	if (arg3) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15867,F1754_15867, (Current));
		tr1 = F1148_8367(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15868,F1754_15868, (Current));
		tr1 = F1148_8367(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
	}
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("\'",1,39);
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3203,F373_3203, (Current));
	tr2 = *(EIF_REFERENCE *)(RTCW(arg2));
	F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), loc1, tr2);
	if (arg3) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("SystemIdStartString from \'",26,441867047);
		tr3 = RTOSCF(15867,F1754_15867, (Current));
		loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("UriStartString from \'",21,1209009191);
		tr3 = RTOSCF(15868,F1754_15868, (Current));
		loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
	}
	tr1 = RTOSCF(3203,F373_3203, (Current));
	F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), loc1, arg1);
	RTLE;
}

/* {XM_CATALOG}.write_missing_suffix_reference_attribute */
void F1754_15852 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("Missing \'",9,101995559);
	tr3 = RTOSCF(15861,F1754_15861, (Current));
	loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("\' attribute from \'",18,403635751);
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	if (arg1) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15864,F1754_15864, (Current));
		tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15862,F1754_15862, (Current));
		tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
	}
	tr1 = RTOSCF(3203,F373_3203, (Current));
	tr2 = RTOSCF(8530,F1163_8530, (Current));
	tr3 = RTMS_EX_H("\'",1,39);
	tr2 = F1148_8377(RTCW(tr2), loc1, tr3);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
	RTLE;
}

/* {XM_CATALOG}.write_missing_suffix_string_attribute */
void F1754_15853 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	if (arg1) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("Missing \'",9,101995559);
		tr3 = RTOSCF(15865,F1754_15865, (Current));
		loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("Missing \'",9,101995559);
		tr3 = RTOSCF(15863,F1754_15863, (Current));
		loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
	}
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("\' attribute from \'",18,403635751);
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	if (arg1) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15864,F1754_15864, (Current));
		tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15862,F1754_15862, (Current));
		tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
	}
	tr1 = RTOSCF(3203,F373_3203, (Current));
	tr2 = RTOSCF(8530,F1163_8530, (Current));
	tr3 = RTMS_EX_H("\'",1,39);
	tr2 = F1148_8377(RTCW(tr2), loc1, tr3);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 1L), tr2, tr3);
	RTLE;
}

/* {XM_CATALOG}.write_suffix_debug_message */
void F1754_15854 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLR(5,tr3);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc1 = RTMS_EX_H("Rewrite suffix from \'",21,1651033895);
	if (arg3) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15864,F1754_15864, (Current));
		tr1 = F1148_8367(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTOSCF(15862,F1754_15862, (Current));
		tr1 = F1148_8367(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
	}
	tr1 = RTOSCF(8530,F1163_8530, (Current));
	tr2 = RTMS_EX_H("\'",1,39);
	tr1 = F1148_8377(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3203,F373_3203, (Current));
	tr2 = *(EIF_REFERENCE *)(RTCW(arg2));
	F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), loc1, tr2);
	if (arg3) {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("SystemIdSuffix from \'",21,1867004711);
		tr3 = RTOSCF(15864,F1754_15864, (Current));
		loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
	} else {
		tr1 = RTOSCF(8530,F1163_8530, (Current));
		tr2 = RTMS_EX_H("UriSuffix from \'",16,1827516455);
		tr3 = RTOSCF(15862,F1754_15862, (Current));
		loc1 = F1148_8367(RTCW(tr1), tr2, tr3);
	}
	tr1 = RTOSCF(3203,F373_3203, (Current));
	F1756_15920(RTCW(tr1), ((EIF_INTEGER_32) 5L), loc1, arg1);
	RTLE;
}

/* {XM_CATALOG}.catalog_entry */

EIF_REFERENCE F1754_15855 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15855,RTMS_EX_H("catalog",7,114913127));
}

/* {XM_CATALOG}.catalog_attribute */

EIF_REFERENCE F1754_15856 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15856,RTMS_EX_H("catalog",7,114913127));
}

/* {XM_CATALOG}.group_entry */

EIF_REFERENCE F1754_15857 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15857,RTMS_EX_H("group",5,1920698224));
}

/* {XM_CATALOG}.system_entry */

EIF_REFERENCE F1754_15858 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15858,RTMS_EX_H("system",6,16556653));
}

/* {XM_CATALOG}.public_entry */

EIF_REFERENCE F1754_15859 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15859,RTMS_EX_H("public",6,1872371555));
}

/* {XM_CATALOG}.uri_entry */

EIF_REFERENCE F1754_15860 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15860,RTMS_EX_H("uri",3,7697001));
}

/* {XM_CATALOG}.uri_attribute */

EIF_REFERENCE F1754_15861 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15861,RTMS_EX_H("uri",3,7697001));
}

/* {XM_CATALOG}.uri_suffix_entry */

EIF_REFERENCE F1754_15862 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15862,RTMS_EX_H("uriSuffix",9,1528073080));
}

/* {XM_CATALOG}.uri_suffix_attribute */

EIF_REFERENCE F1754_15863 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15863,RTMS_EX_H("uriSuffix",9,1528073080));
}

/* {XM_CATALOG}.system_suffix_entry */

EIF_REFERENCE F1754_15864 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15864,RTMS_EX_H("systemSuffix",12,777623160));
}

/* {XM_CATALOG}.system_id_suffix_attribute */

EIF_REFERENCE F1754_15865 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15865,RTMS_EX_H("systemIdSuffix",14,410600568));
}

/* {XM_CATALOG}.rewrite_prefix_attribute */

EIF_REFERENCE F1754_15866 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15866,RTMS_EX_H("rewritePrefix",13,1118097016));
}

/* {XM_CATALOG}.rewrite_system_entry */

EIF_REFERENCE F1754_15867 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15867,RTMS_EX_H("rewriteSystem",13,1359846509));
}

/* {XM_CATALOG}.rewrite_uri_entry */

EIF_REFERENCE F1754_15868 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15868,RTMS_EX_H("rewriteURI",10,2056779593));
}

/* {XM_CATALOG}.system_id_start_string_attribute */

EIF_REFERENCE F1754_15869 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15869,RTMS_EX_H("systemIdStartString",19,2127646311));
}

/* {XM_CATALOG}.uri_start_string_attribute */

EIF_REFERENCE F1754_15870 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15870,RTMS_EX_H("uriStartString",14,989550439));
}

/* {XM_CATALOG}.public_id_start_string_attribute */

EIF_REFERENCE F1754_15871 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15871,RTMS_EX_H("publicIdStartString",19,2113175911));
}

/* {XM_CATALOG}.delegate_system_entry */

EIF_REFERENCE F1754_15872 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15872,RTMS_EX_H("delegateSystem",14,522002541));
}

/* {XM_CATALOG}.delegate_uri_entry */

EIF_REFERENCE F1754_15873 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15873,RTMS_EX_H("delegateUri",11,1026702441));
}

/* {XM_CATALOG}.delegate_public_entry */

EIF_REFERENCE F1754_15874 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15874,RTMS_EX_H("delegatePublic",14,230337635));
}

/* {XM_CATALOG}.next_catalog_entry */

EIF_REFERENCE F1754_15875 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15875,RTMS_EX_H("nextCatalog",11,801910119));
}

/* {XM_CATALOG}.base_attribute */

EIF_REFERENCE F1754_15876 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15876,RTMS_EX_H("base",4,1650553701));
}

/* {XM_CATALOG}.prefer_attribute */

EIF_REFERENCE F1754_15877 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15877,RTMS_EX_H("prefer",6,1922285938));
}

/* {XM_CATALOG}.id_attribute */

EIF_REFERENCE F1754_15878 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15878,RTMS_EX_H("id",2,26980));
}

/* {XM_CATALOG}.system_id_attribute */

EIF_REFERENCE F1754_15879 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15879,RTMS_EX_H("systemId",8,579526756));
}

/* {XM_CATALOG}.public_id_attribute */

EIF_REFERENCE F1754_15880 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15880,RTMS_EX_H("publicId",8,746018148));
}

/* {XM_CATALOG}.name_attribute */

EIF_REFERENCE F1754_15881 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15881,RTMS_EX_H("name",4,1851878757));
}

void EIF_Minit827 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
