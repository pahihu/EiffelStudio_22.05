/*
 * Code for class CONTAINER [NATURAL_16]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1698.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F623_3802 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O3366[Dtype(Current)-615]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit1698 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
