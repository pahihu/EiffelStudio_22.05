/*
 * Code for class CONTAINER [INTEGER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1659.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F622_3802 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O3366[Dtype(Current)-615]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit1659 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
