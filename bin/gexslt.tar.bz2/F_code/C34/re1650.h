
#ifndef _C34_re1650_
#define _C34_re1650_

#ifdef __cplusplus
extern "C" {
#endif

extern void F548_3715(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F548_3717(EIF_REFERENCE);
extern EIF_INTEGER_32 F548_3718(EIF_REFERENCE);
extern EIF_INTEGER_32 F548_3719(EIF_REFERENCE);
extern EIF_INTEGER_32 F548_3720(EIF_REFERENCE);
extern EIF_BOOLEAN F548_3728(EIF_REFERENCE);
extern EIF_BOOLEAN F548_3729(EIF_REFERENCE);
extern void F548_3734(EIF_REFERENCE);
extern void EIF_Minit1650(void);
extern char *(*R3639[])();
extern char *(*R3640[])();

#ifdef __cplusplus
}
#endif

#endif
