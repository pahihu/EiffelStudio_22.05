
#ifndef _C34_fi1699_
#define _C34_fi1699_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F777_3900(EIF_REFERENCE);
extern void EIF_Minit1699(void);
extern EIF_INTEGER_32 F886_4378(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
