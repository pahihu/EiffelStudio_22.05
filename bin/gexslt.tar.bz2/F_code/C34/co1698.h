
#ifndef _C34_co1698_
#define _C34_co1698_

#ifdef __cplusplus
extern "C" {
#endif

extern void F623_3802(EIF_REFERENCE);
extern void EIF_Minit1698(void);
extern long O3366[];

#ifdef __cplusplus
}
#endif

#endif
