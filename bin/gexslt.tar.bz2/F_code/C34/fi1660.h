
#ifndef _C34_fi1660_
#define _C34_fi1660_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F776_3900(EIF_REFERENCE);
extern void EIF_Minit1660(void);
extern EIF_INTEGER_32 F885_4378(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
