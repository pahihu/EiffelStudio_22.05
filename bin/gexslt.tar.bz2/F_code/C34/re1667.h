
#ifndef _C34_re1667_
#define _C34_re1667_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F803_3913(EIF_REFERENCE);
extern void EIF_Minit1667(void);
extern EIF_INTEGER_32 F885_4379(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
