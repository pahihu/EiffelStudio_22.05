
#ifndef _C34_to1665_
#define _C34_to1665_

#ifdef __cplusplus
extern "C" {
#endif

extern void F353_2986(EIF_REFERENCE, EIF_INTEGER_32);
extern void F353_2987(EIF_REFERENCE, EIF_INTEGER_8, EIF_INTEGER_32);
extern void F353_2993(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1665(void);
extern void F858_4278(EIF_REFERENCE, EIF_INTEGER_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2709[];
extern EIF_TYPE_INDEX *Y2709_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
