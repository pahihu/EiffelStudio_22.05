
#ifndef _C34_co1659_
#define _C34_co1659_

#ifdef __cplusplus
extern "C" {
#endif

extern void F622_3802(EIF_REFERENCE);
extern void EIF_Minit1659(void);
extern long O3366[];

#ifdef __cplusplus
}
#endif

#endif
