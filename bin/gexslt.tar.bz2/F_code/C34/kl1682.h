
#ifndef _C34_kl1682_
#define _C34_kl1682_

#ifdef __cplusplus
extern "C" {
#endif

extern void F897_4424(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1682(void);

#ifdef __cplusplus
}
#endif

#endif
