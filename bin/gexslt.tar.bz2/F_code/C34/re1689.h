
#ifndef _C34_re1689_
#define _C34_re1689_

#ifdef __cplusplus
extern "C" {
#endif

extern void F549_3715(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F549_3717(EIF_REFERENCE);
extern EIF_INTEGER_32 F549_3718(EIF_REFERENCE);
extern EIF_INTEGER_32 F549_3719(EIF_REFERENCE);
extern EIF_INTEGER_32 F549_3720(EIF_REFERENCE);
extern EIF_BOOLEAN F549_3728(EIF_REFERENCE);
extern EIF_BOOLEAN F549_3729(EIF_REFERENCE);
extern void F549_3734(EIF_REFERENCE);
extern void EIF_Minit1689(void);
extern char *(*R3639[])();
extern char *(*R3640[])();

#ifdef __cplusplus
}
#endif

#endif
