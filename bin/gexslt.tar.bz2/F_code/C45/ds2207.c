/*
 * Code for class DS_QUICK_SORTER [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2207.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_QUICK_SORTER}.subsort_with_comparator */
void F105_1071 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc11);
	RTLR(1,Current);
	RTLR(2,loc12);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg4 - arg3) + ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 0L))) break;
		loc5 /= ((EIF_INTEGER_32) 2L);
		loc4++;
	}
	loc4 += ((EIF_INTEGER_32) 10L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,880,1035,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc11 = RTLNS(typres0.id, 880, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F881_4366(RTCW(loc11), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), loc4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,880,1035,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc12 = RTLNS(typres0.id, 880, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F881_4366(RTCW(loc12), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), loc4);
	F881_4390(RTCW(loc11), arg3, ((EIF_INTEGER_32) 1L));
	F881_4390(RTCW(loc12), arg4, ((EIF_INTEGER_32) 1L));
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) break;
		loc9 = F881_4371(RTCW(loc11), loc4);
		loc10 = F881_4371(RTCW(loc12), loc4);
		loc4--;
		loc1 = (EIF_INTEGER_32) loc9;
		loc2 = (EIF_INTEGER_32) loc10;
		if ((EIF_BOOLEAN) (loc1 < loc2)) {
			if ((EIF_BOOLEAN)(loc2 == (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)))) {
				loc7 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(arg1))-1481])(arg1, loc1));
				loc8 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(arg1))-1481])(arg1, loc2));
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3243[Dtype(RTCW(arg2))-482])(arg2, (EIF_REFERENCE) &loc8, (EIF_REFERENCE) &loc7);
				if (tb1) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R9689[Dtype(RTCW(arg1))-1481])(arg1, (EIF_REFERENCE) &loc7, loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R9689[Dtype(RTCW(arg1))-1481])(arg1, (EIF_REFERENCE) &loc8, loc1);
				}
			} else {
				loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc2) / ((EIF_INTEGER_32) 2L));
				loc6 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(arg1))-1481])(arg1, loc3));
				ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(arg1))-1481])(arg1, loc10));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R9689[Dtype(RTCW(arg1))-1481])(arg1, (EIF_REFERENCE) &ti4_1, loc3);
				for (;;) {
					if ((EIF_BOOLEAN) (loc1 >= loc2)) break;
					for (;;) {
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (loc1 >= loc2)) {
							ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(arg1))-1481])(arg1, loc1));
							tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3243[Dtype(RTCW(arg2))-482])(arg2, (EIF_REFERENCE) &ti4_1, (EIF_REFERENCE) &loc6);
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) break;
						loc1++;
					}
					loc2--;
					for (;;) {
						tb2 = '\01';
						if (!(EIF_BOOLEAN) (loc2 <= loc1)) {
							ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(arg1))-1481])(arg1, loc2));
							tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3243[Dtype(RTCW(arg2))-482])(arg2, (EIF_REFERENCE) &loc6, (EIF_REFERENCE) &ti4_1);
							tb2 = (EIF_BOOLEAN) !tb3;
						}
						if (tb2) break;
						loc2--;
					}
					if ((EIF_BOOLEAN) (loc1 < loc2)) {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R9690[Dtype(RTCW(arg1))-1481])(arg1, loc1, loc2);
						loc1++;
					}
				}
				ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9682[Dtype(RTCW(arg1))-1481])(arg1, loc1));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R9689[Dtype(RTCW(arg1))-1481])(arg1, (EIF_REFERENCE) &ti4_1, loc10);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R9689[Dtype(RTCW(arg1))-1481])(arg1, (EIF_REFERENCE) &loc6, loc1);
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)) > loc9)) {
					loc4++;
					F881_4392(RTCW(loc11), loc9, loc4);
					F881_4392(RTCW(loc12), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)), loc4);
				}
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) < loc10)) {
					loc4++;
					F881_4392(RTCW(loc11), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), loc4);
					F881_4392(RTCW(loc12), loc10, loc4);
				}
			}
		}
	}
	RTLE;
}

void EIF_Minit2207 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
