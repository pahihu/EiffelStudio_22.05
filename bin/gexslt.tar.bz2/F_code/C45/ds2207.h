
#ifndef _C45_ds2207_
#define _C45_ds2207_

#ifdef __cplusplus
extern "C" {
#endif

extern void F105_1071(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit2207(void);
extern void F881_4390(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F881_4392(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F881_4371(EIF_REFERENCE, EIF_INTEGER_32);
extern void F881_4366(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R3243[])();
extern char *(*R9682[])();
extern char *(*R9689[])();
extern char *(*R9690[])();

#ifdef __cplusplus
}
#endif

#endif
