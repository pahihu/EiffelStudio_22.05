
#ifndef _C45_ha2202_
#define _C45_ha2202_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F559_3743(EIF_REFERENCE);
extern EIF_REFERENCE F559_3744(EIF_REFERENCE);
extern EIF_BOOLEAN F559_3746(EIF_REFERENCE);
extern void F559_3747(EIF_REFERENCE);
extern EIF_REFERENCE F559_3748(EIF_REFERENCE);
extern void EIF_Minit2202(void);
extern EIF_BOOLEAN F543_3729(EIF_REFERENCE);
extern char *(*R3638[])();
extern char *(*R3136[])();
extern char *(*R3896[])();
extern char *(*R3897[])();

#ifdef __cplusplus
}
#endif

#endif
