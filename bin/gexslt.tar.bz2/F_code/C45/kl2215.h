
#ifndef _C45_kl2215_
#define _C45_kl2215_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F491_3626(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F491_3629(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2215(void);
extern char *(*R3245[])();
extern char *(*R3260[])();

#ifdef __cplusplus
}
#endif

#endif
