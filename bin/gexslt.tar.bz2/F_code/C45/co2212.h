
#ifndef _C45_co2212_
#define _C45_co2212_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F768_3870(EIF_REFERENCE);
extern EIF_BOOLEAN F768_3872(EIF_REFERENCE);
extern void F768_3878(EIF_REFERENCE);
extern void EIF_Minit2212(void);

#ifdef __cplusplus
}
#endif

#endif
