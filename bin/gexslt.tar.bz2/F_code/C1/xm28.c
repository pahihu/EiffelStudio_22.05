/*
 * Code for class XM_XPATH_SLOT_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm28.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_SLOT_MANAGER}.make */
void F28_231 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {XM_XPATH_SLOT_MANAGER}.set_number_of_variables */
void F28_233 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {XM_XPATH_SLOT_MANAGER}.allocate_slot_number */
void F28_234 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_))++;
}

void EIF_Minit28 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
