
#ifndef _C1_xm15_
#define _C1_xm15_

#ifdef __cplusplus
extern "C" {
#endif

extern void F15_142(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE);
extern void EIF_Minit15(void);

#ifdef __cplusplus
}
#endif

#endif
