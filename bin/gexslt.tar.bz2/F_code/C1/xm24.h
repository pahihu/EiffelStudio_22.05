
#ifndef _C1_xm24_
#define _C1_xm24_

#ifdef __cplusplus
extern "C" {
#endif

extern void F24_202(EIF_REFERENCE, EIF_REFERENCE);
extern void F24_203(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F24_204(EIF_REFERENCE);
extern EIF_REFERENCE F24_205(EIF_REFERENCE);
extern void EIF_Minit24(void);

#ifdef __cplusplus
}
#endif

#endif
