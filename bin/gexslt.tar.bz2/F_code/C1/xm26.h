
#ifndef _C1_xm26_
#define _C1_xm26_

#ifdef __cplusplus
extern "C" {
#endif

extern void F26_221(EIF_REFERENCE, EIF_INTEGER_32);
extern void F26_225(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit26(void);
extern void F1506_12163(EIF_REFERENCE);
extern void F1506_12212(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE __A486_45_1();
extern void F1506_12178(EIF_REFERENCE, EIF_REFERENCE);
extern void F1476_11885(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1506_12173(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE _A486_45_1();

#ifdef __cplusplus
}
#endif

#endif
