
#ifndef _C1_st9_
#define _C1_st9_

#ifdef __cplusplus
extern "C" {
#endif

extern void F9_109(EIF_REFERENCE, EIF_REFERENCE);
extern void F9_110(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit9(void);

#ifdef __cplusplus
}
#endif

#endif
