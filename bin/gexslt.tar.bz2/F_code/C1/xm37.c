/*
 * Code for class XM_XSLT_MESSAGE_EMITTER_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm37.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_MESSAGE_EMITTER_FACTORY}.new_message_emitter */
EIF_REFERENCE F37_421 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = RTLNSMART(eif_new_type(1590, 0).id);
		F1591_13202(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	}
	tr1 = RTLNS(eif_new_type(1761, 0x01).id, 1761, _OBJSIZ_10_13_0_2_0_0_0_0_);
	F1759_15947(RTCW(tr1), arg1, loc1, arg2);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit37 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
