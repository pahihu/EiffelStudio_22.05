
#ifndef _C1_ut21_
#define _C1_ut21_

#ifdef __cplusplus
extern "C" {
#endif

extern void F21_178(EIF_REFERENCE);
extern void F21_179(EIF_REFERENCE);
extern void F21_180(EIF_REFERENCE);
extern EIF_BOOLEAN F21_181(EIF_REFERENCE);
extern EIF_BOOLEAN F21_182(EIF_REFERENCE);
extern EIF_BOOLEAN F21_183(EIF_REFERENCE);
extern void F21_184(EIF_REFERENCE);
extern void F21_185(EIF_REFERENCE);
extern void F21_186(EIF_REFERENCE);
extern void EIF_Minit21(void);

#ifdef __cplusplus
}
#endif

#endif
