
#ifndef _C1_xm37_
#define _C1_xm37_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F37_421(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit37(void);
extern void F1591_13202(EIF_REFERENCE);
extern void F1759_15947(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
