/*
 * Code for class XM_XPATH_REGEXP_MATCH_RECORD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm4.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_REGEXP_MATCH_RECORD}.make */
void F4_59 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F4_62(Current, arg1);
}

/* {XM_XPATH_REGEXP_MATCH_RECORD}.add_split */
void F4_62 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

void EIF_Minit4 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
