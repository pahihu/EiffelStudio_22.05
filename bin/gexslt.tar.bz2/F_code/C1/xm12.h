
#ifndef _C1_xm12_
#define _C1_xm12_

#ifdef __cplusplus
extern "C" {
#endif

extern void F12_131(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F12_134(EIF_REFERENCE);
extern void EIF_Minit12(void);

#ifdef __cplusplus
}
#endif

#endif
