/*
 * Code for class SYSTEM_ENCODINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy30.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYSTEM_ENCODINGS}.console_encoding */
static EIF_REFERENCE F30_244_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (244);
#define Result RTOSR(244)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(30, 0x01).id, 30, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = F162_1507(RTCV(RTOSCF(249,F30_249, (Current))));
	F31_250(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (244);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F30_244 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(244,F30_244_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf8 */
static EIF_REFERENCE F30_245_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (245);
#define Result RTOSR(245)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(30, 0x01).id, 30, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(236,F29_236, (Current));
	F31_250(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (245);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F30_245 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(245,F30_245_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf32 */
static EIF_REFERENCE F30_247_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (247);
#define Result RTOSR(247)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(30, 0x01).id, 30, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(238,F29_238, (Current));
	F31_250(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (247);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F30_247 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(247,F30_247_body,(Current));
}

/* {SYSTEM_ENCODINGS}.system_encodings_i */
static EIF_REFERENCE F30_249_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (249);
#define Result RTOSR(249)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(161, 0x01).id, 161, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (249);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F30_249 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(249,F30_249_body,(Current));
}

void EIF_Minit30 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
