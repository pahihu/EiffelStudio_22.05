
#ifndef _C1_xm11_
#define _C1_xm11_

#ifdef __cplusplus
extern "C" {
#endif

extern void F11_126(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F11_129(EIF_REFERENCE);
extern void EIF_Minit11(void);

#ifdef __cplusplus
}
#endif

#endif
