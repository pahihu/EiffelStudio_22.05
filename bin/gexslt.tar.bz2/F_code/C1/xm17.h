
#ifndef _C1_xm17_
#define _C1_xm17_

#ifdef __cplusplus
extern "C" {
#endif

extern void F17_151(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 152)


extern EIF_REFERENCE F17_152(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 153)


extern EIF_REFERENCE F17_153(EIF_REFERENCE);
extern void F17_158(EIF_REFERENCE, EIF_REFERENCE);
extern void F17_159(EIF_REFERENCE, EIF_REFERENCE);
extern void F17_160(EIF_REFERENCE, EIF_BOOLEAN);
extern void F17_161(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit17(void);
extern char *(*R2027[])();

#ifdef __cplusplus
}
#endif

#endif
