
#ifndef _C1_op47_
#define _C1_op47_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F71_741(EIF_REFERENCE);
extern void EIF_Minit47(void);

#ifdef __cplusplus
}
#endif

#endif
