/*
 * Code for class STD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st46.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STD_FILES}.input */
static EIF_REFERENCE F70_657_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (657);
#define Result RTOSR(657)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1250, 0x01).id, 1250, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdin",5,1953620846);
	F1251_10550(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (657);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F70_657 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(657,F70_657_body,(Current));
}

/* {STD_FILES}.output */
static EIF_REFERENCE F70_658_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (658);
#define Result RTOSR(658)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1250, 0x01).id, 1250, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdout",6,1912016244);
	F1251_10551(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (658);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F70_658 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(658,F70_658_body,(Current));
}

/* {STD_FILES}.error */
static EIF_REFERENCE F70_659_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (659);
#define Result RTOSR(659)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1250, 0x01).id, 1250, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stderr",6,1911360114);
	F1251_10552(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (659);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F70_659 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(659,F70_659_body,(Current));
}

/* {STD_FILES}.standard_default */
EIF_REFERENCE F70_661 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		Result = RTOSCF(658,F70_658, (Current));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {STD_FILES}.set_output_default */
void F70_685 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(658,F70_658, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {STD_FILES}.put_string */
void F70_688 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = F70_661(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3025[Dtype(RTCW(tr1))-837])(tr1, arg1);
	RTLE;
}

/* {STD_FILES}.put_string_32 */
void F70_690 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = F70_661(Current);
	F839_4230(RTCW(tr1), arg1);
	RTLE;
}

/* {STD_FILES}.put_new_line */
void F70_710 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F70_661(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R3023[Dtype(RTCW(tr1))-837])(tr1);
	RTLE;
}

void EIF_Minit46 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
