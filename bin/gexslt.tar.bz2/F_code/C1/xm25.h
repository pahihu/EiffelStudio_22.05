
#ifndef _C1_xm25_
#define _C1_xm25_

#ifdef __cplusplus
extern "C" {
#endif

extern void F25_210(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_INTEGER_32);
extern void F25_211(EIF_REFERENCE, EIF_REFERENCE);
extern void F25_219(EIF_REFERENCE, EIF_REFERENCE);
extern void F25_220(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit25(void);

#ifdef __cplusplus
}
#endif

#endif
