
#ifndef _C1_xm28_
#define _C1_xm28_

#ifdef __cplusplus
extern "C" {
#endif

extern void F28_231(EIF_REFERENCE);
extern void F28_233(EIF_REFERENCE, EIF_INTEGER_32);
extern void F28_234(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit28(void);

#ifdef __cplusplus
}
#endif

#endif
