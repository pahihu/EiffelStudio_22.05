/*
 * Code for class XM_XSLT_DECIMAL_FORMAT_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm40.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_DECIMAL_FORMAT_MANAGER}.make */
void F40_438 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1538,0xFF01,22,1035,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1527_12398(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_XSLT_DECIMAL_FORMAT_MANAGER}.default_decimal_format */
EIF_REFERENCE F40_439 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTLE;
		return (EIF_REFERENCE) RTOSCF(453,F40_453, (Current));
	}/* NOTREACHED */
	
}

/* {XM_XSLT_DECIMAL_FORMAT_MANAGER}.named_format */
EIF_REFERENCE F40_440 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("attached format_map.item (a_fingerprint).decimal_format as l_decimal_format", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F1527_12403(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {XM_XSLT_DECIMAL_FORMAT_MANAGER}.has_named_format */
EIF_BOOLEAN F40_441 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (F40_442(Current, arg1)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F1527_12403(RTCW(tr1), arg1);
		Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_2_1_);
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_DECIMAL_FORMAT_MANAGER}.has */
EIF_BOOLEAN F40_442 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1527_12411(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {XM_XSLT_DECIMAL_FORMAT_MANAGER}.is_default_format_set */
EIF_BOOLEAN F40_443 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL);
}

/* {XM_XSLT_DECIMAL_FORMAT_MANAGER}.is_different_from_default_format */
EIF_BOOLEAN F40_444 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = F1576_12921(RTCW(arg1), loc1);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	}/* NOTREACHED */
	
}

/* {XM_XSLT_DECIMAL_FORMAT_MANAGER}.is_duplicate_format */
EIF_BOOLEAN F40_445 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_10_0_0_0_);
	tr1 = F40_440(Current, ti4_1);
	Result = F1576_12921(RTCW(arg1), tr1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {XM_XSLT_DECIMAL_FORMAT_MANAGER}.set_default_format */
void F40_446 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F40_447(Current, arg1);
	RTLE;
}

/* {XM_XSLT_DECIMAL_FORMAT_MANAGER}.set_named_format */
void F40_447 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_10_0_0_0_);
	if (F40_442(Current, ti4_1)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_10_0_0_0_);
		loc1 = F1527_12403(RTCW(tr1), ti4_1);
		RTCT0("entry_is_list", EX_CHECK);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_2_0_);
		if (tb1) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTCT0("attached an_entry.list as l_entity_list", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc2 = (EIF_REFERENCE) loc4;
		loc3 = F1506_12168(RTCW(loc2));
		F1320_11363(RTCW(loc3));
		for (;;) {
			tb1 = F1384_11438(RTCW(loc3));
			if (tb1) break;
			tr1 = F1307_11343(RTCW(loc3));
			F2036_19957(RTCW(tr1), arg1);
			F1320_11364(RTCW(loc3));
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_10_0_0_0_);
		F1511_12261(RTCW(tr1), ti4_1);
	}
	loc1 = RTLNS(eif_new_type(22, 0x01).id, 22, _OBJSIZ_2_2_0_0_0_0_0_0_);
	F23_196(RTCW(loc1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_10_0_0_0_);
	F1527_12420(RTCW(tr1), loc1, ti4_1);
	RTLE;
}

/* {XM_XSLT_DECIMAL_FORMAT_MANAGER}.fixup_default_default */
void F40_448 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_)) {
		tr1 = F40_439(Current);
		F40_447(Current, tr1);
	}
	RTLE;
}

/* {XM_XSLT_DECIMAL_FORMAT_MANAGER}.register_usage */
void F40_449 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,arg2);
	RTLR(5,loc4);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1527_12414(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = F1511_12249(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = F1511_12241(RTCW(tr1));
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_2_0_);
		if (tb1) {
			RTCT0("attached l_entry.list as l_entity_list", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTCK0;
			} else {
				RTCF0;
			}
			F1506_12183(loc3, arg2);
		} else {
			RTCT0("attached l_entry.decimal_format as l_decimal_format", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				RTCK0;
			} else {
				RTCF0;
			}
			F2036_19957(RTCW(arg2), loc4);
		}
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1505,0xFF01,2035,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1505, _OBJSIZ_4_0_0_2_0_0_0_0_);
		}
		F1506_12163(RTCW(loc1));
		F1506_12178(RTCW(loc1), arg2);
		loc2 = RTLNS(eif_new_type(22, 0x01).id, 22, _OBJSIZ_2_2_0_0_0_0_0_0_);
		F23_197(RTCW(loc2), loc1);
		tr1 = *(EIF_REFERENCE *)(Current);
		F1527_12420(RTCW(tr1), loc2, arg1);
	}
	RTLE;
}

/* {XM_XSLT_DECIMAL_FORMAT_MANAGER}.all_defaults */
static EIF_REFERENCE F40_453_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (453);
#define Result RTOSR(453)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1575, 0x01).id, 1575, _OBJSIZ_10_0_0_2_0_0_0_0_);
	F1576_12908(RTCW(tr1), ((EIF_INTEGER_32) -1L), ((EIF_INTEGER_32) -1000000L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (453);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F40_453 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(453,F40_453_body,(Current));
}

void EIF_Minit40 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
