/*
 * Code for class KL_OPERATING_SYSTEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl20.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_OPERATING_SYSTEM}.is_windows */
static EIF_BOOLEAN F20_172_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTLD;
	

	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOSP (172);
#define Result RTOSR(172)
	tr1 = RTMS_EX_H("GOBO_OS",7,715786835);
	loc2 = F20_176(Current, tr1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tr1 = RTMS_EX_H("windows",7,1657536371);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc2))-1])(loc2, tr1);
		if (tb1) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		tr1 = RTMS_EX_H("OS",2,20307);
		loc3 = F20_176(Current, tr1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			tr1 = RTMS_EX_H("Windows_NT",10,121334100);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc3))-1])(loc3, tr1);
			tb1 = tb2;
		}
		if (tb1) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			loc1 = F20_175(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 3L))) {
				tb1 = '\0';
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(loc1))-852])(loc1, ((EIF_INTEGER_32) 2L)));
				if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) ':')) {
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(loc1))-852])(loc1, ((EIF_INTEGER_32) 3L)));
					tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\\');
				}
				if (tb1) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tb1 = '\0';
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(loc1))-852])(loc1, ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\\')) {
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(loc1))-852])(loc1, ((EIF_INTEGER_32) 2L)));
						tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\\');
					}
					if (tb1) {
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
			}
		}
	}
	RTOSE (172);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F20_172 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(172,F20_172_body,(Current));
}

/* {KL_OPERATING_SYSTEM}.is_unix */
static EIF_BOOLEAN F20_173_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	

	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (173);
#define Result RTOSR(173)
	tr1 = RTMS_EX_H("GOBO_OS",7,715786835);
	loc2 = F20_176(Current, tr1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tr1 = RTMS_EX_H("unix",4,1970170232);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc2))-1])(loc2, tr1);
		if (tb1) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		loc1 = F20_175(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3638[Dtype(RTCW(loc1))-852])(loc1, ((EIF_INTEGER_32) 1L)));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '/');
		}
	}
	RTOSE (173);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F20_173 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(173,F20_173_body,(Current));
}

/* {KL_OPERATING_SYSTEM}.current_working_directory */
EIF_REFERENCE F20_175 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = F365_3023(RTCV(RTOSCF(177,F20_177, (Current))));
	Result = F998_5023(RTCW(tr1));
	RTLE;
	return Result;
}

/* {KL_OPERATING_SYSTEM}.variable_value */
EIF_REFERENCE F20_176 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(177,F20_177, (Current));
	tr1 = F365_3027(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F1115_6636(loc1);
		if (tb1) {
			tr1 = F1108_6361(loc1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = RTLNS(eif_new_type(1137, 0x01).id, 1137, _OBJSIZ_0_0_0_0_0_0_0_0_);
			Result = F1138_8297(RTCW(tr1), loc1);
		}
	}
	RTLE;
	return Result;
}

/* {KL_OPERATING_SYSTEM}.execution_environment */
static EIF_REFERENCE F20_177_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (177);
#define Result RTOSR(177)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(364, 0x01).id, 364, _OBJSIZ_0_0_0_1_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (177);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F20_177 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(177,F20_177_body,(Current));
}

void EIF_Minit20 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
