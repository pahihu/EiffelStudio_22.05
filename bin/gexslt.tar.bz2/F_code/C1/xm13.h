
#ifndef _C1_xm13_
#define _C1_xm13_

#ifdef __cplusplus
extern "C" {
#endif

extern void F13_136(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern void F13_140(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit13(void);

#ifdef __cplusplus
}
#endif

#endif
