
#ifndef _C1_xm8_
#define _C1_xm8_

#ifdef __cplusplus
extern "C" {
#endif

extern void F8_102(EIF_REFERENCE, EIF_REFERENCE);
extern void F8_103(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F8_104(EIF_REFERENCE);
extern EIF_REFERENCE F8_105(EIF_REFERENCE);
extern void EIF_Minit8(void);

#ifdef __cplusplus
}
#endif

#endif
