/*
 * Code for class ENCODING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "en31.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ENCODING}.make */
void F31_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	tr1 = RTOSCF(264,F31_264, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ENCODING}.last_converted_stream */
EIF_REFERENCE F31_252 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1295_11249(RTCW(tr1));
	RTLE;
	return Result;
}

/* {ENCODING}.last_converted_string_8 */
EIF_REFERENCE F31_253 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F31_252(Current);
}

/* {ENCODING}.convert_to */
void F31_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc2 = RTOSCF(263,F31_263, (Current));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9245[Dtype(RTCW(loc2))-1295])(loc2, *(EIF_REFERENCE *)(Current), tr1);
	if (tb1) {
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc2;
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tr1 = RTOSCF(264,F31_264, (Current));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1295_11248(RTCW(tr1));
	if (loc1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9238[Dtype(RTCW(tr1))-1295])(tr1, *(EIF_REFERENCE *)(Current), arg2, tr2);
	} else {
		tb1 = '\0';
		tb2 = '\0';
		tb3 = F31_260(RTCW(arg1));
		if (tb3) {
			tb2 = F31_260(Current);
		}
		if (tb2) {
			tb1 = F31_261(Current, arg1);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9238[Dtype(RTCW(tr1))-1295])(tr1, *(EIF_REFERENCE *)(Current), arg2, tr2);
		}
	}
	RTLE;
}

/* {ENCODING}.last_conversion_successful */
EIF_BOOLEAN F31_257 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_1_0_);
	RTLE;
	return Result;
}

/* {ENCODING}.same_as */
EIF_BOOLEAN F31_259 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	Result = F1111_6464(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {ENCODING}.is_valid */
EIF_BOOLEAN F31_260 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(264,F31_264, (Current));
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9243[Dtype(RTCW(tr1))-1295])(tr1, *(EIF_REFERENCE *)(Current));
	RTLE;
	return Result;
}

/* {ENCODING}.is_conversion_possible */
EIF_BOOLEAN F31_261 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(264,F31_264, (Current));
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9245[Dtype(RTCW(tr1))-1295])(tr1, *(EIF_REFERENCE *)(Current), tr2);
	RTLE;
	return Result;
}

/* {ENCODING}.unicode_conversion */
static EIF_REFERENCE F31_263_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (263);
#define Result RTOSR(263)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1296, 0x01).id, 1296, _OBJSIZ_1_2_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (263);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F31_263 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(263,F31_263_body,(Current));
}

/* {ENCODING}.regular_encoding_imp */
static EIF_REFERENCE F31_264_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (264);
#define Result RTOSR(264)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1295, 0x01).id, 1295, _OBJSIZ_1_2_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (264);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F31_264 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(264,F31_264_body,(Current));
}

void EIF_Minit31 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
