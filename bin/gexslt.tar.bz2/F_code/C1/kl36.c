/*
 * Code for class KL_STANDARD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl36.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STANDARD_FILES}.input */
static EIF_REFERENCE F36_416_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (416);
#define Result RTOSR(416)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1204, 0x01).id, 1204, _OBJSIZ_2_2_0_0_0_0_0_0_);
	F1205_9093(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (416);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F36_416 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(416,F36_416_body,(Current));
}

/* {KL_STANDARD_FILES}.output */
static EIF_REFERENCE F36_417_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (417);
#define Result RTOSR(417)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1219, 0x01).id, 1219, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (417);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F36_417 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(417,F36_417_body,(Current));
}

/* {KL_STANDARD_FILES}.error */
static EIF_REFERENCE F36_418_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (418);
#define Result RTOSR(418)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1218, 0x01).id, 1218, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (418);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F36_418 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(418,F36_418_body,(Current));
}

void EIF_Minit36 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
