
#ifndef _C1_xm23_
#define _C1_xm23_

#ifdef __cplusplus
extern "C" {
#endif

extern void F23_196(EIF_REFERENCE, EIF_REFERENCE);
extern void F23_197(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit23(void);

#ifdef __cplusplus
}
#endif

#endif
