
#ifndef _C1_xm16_
#define _C1_xm16_

#ifdef __cplusplus
extern "C" {
#endif

extern void F16_147(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit16(void);

#ifdef __cplusplus
}
#endif

#endif
