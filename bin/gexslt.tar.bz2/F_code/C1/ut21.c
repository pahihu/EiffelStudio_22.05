/*
 * Code for class UT_TRISTATE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut21.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_TRISTATE}.make_true */
void F21_178 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F21_184(Current);
}

/* {UT_TRISTATE}.make_false */
void F21_179 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F21_185(Current);
}

/* {UT_TRISTATE}.make_undefined */
void F21_180 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F21_186(Current);
}

/* {UT_TRISTATE}.is_true */
EIF_BOOLEAN F21_181 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_0_0_) == (EIF_CHARACTER_8) 'T');
}

/* {UT_TRISTATE}.is_false */
EIF_BOOLEAN F21_182 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_0_0_) == (EIF_CHARACTER_8) 'F');
}

/* {UT_TRISTATE}.is_undefined */
EIF_BOOLEAN F21_183 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F21_181(Current)) {
		Result = F21_182(Current);
	}
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {UT_TRISTATE}.set_true */
void F21_184 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_0_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'T';
}

/* {UT_TRISTATE}.set_false */
void F21_185 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_0_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'F';
}

/* {UT_TRISTATE}.set_undefined */
void F21_186 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_0_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'U';
}

void EIF_Minit21 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
