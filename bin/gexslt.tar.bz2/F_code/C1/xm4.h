
#ifndef _C1_xm4_
#define _C1_xm4_

#ifdef __cplusplus
extern "C" {
#endif

extern void F4_59(EIF_REFERENCE, EIF_REFERENCE);
extern void F4_62(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit4(void);

#ifdef __cplusplus
}
#endif

#endif
