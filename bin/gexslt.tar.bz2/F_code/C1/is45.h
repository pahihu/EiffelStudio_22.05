
#ifndef _C1_is45_
#define _C1_is45_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F56_548(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F56_553(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F56_555(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F56_563(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit45(void);

#ifdef __cplusplus
}
#endif

#endif
