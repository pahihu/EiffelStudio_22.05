
#ifndef _C1_xm38_
#define _C1_xm38_

#ifdef __cplusplus
extern "C" {
#endif

extern void F38_422(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F38_429(EIF_REFERENCE);
extern EIF_BOOLEAN F38_430(EIF_REFERENCE);
extern void EIF_Minit38(void);

#ifdef __cplusplus
}
#endif

#endif
