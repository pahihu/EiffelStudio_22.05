/*
 * Code for class XM_XPATH_XSLT_STYLE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm35.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_XSLT_STYLE_CONSTANTS}.default_collation_attribute */

EIF_REFERENCE F35_409 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (409,RTMS_EX_H("default-collation",17,1575318894));
}

/* {XM_XPATH_XSLT_STYLE_CONSTANTS}.exclude_result_prefixes_attribute */

EIF_REFERENCE F35_410 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (410,RTMS_EX_H("exclude-result-prefixes",23,2028177011));
}

/* {XM_XPATH_XSLT_STYLE_CONSTANTS}.extension_element_prefixes_attribute */

EIF_REFERENCE F35_411 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (411,RTMS_EX_H("extension-element-prefixes",26,1451174515));
}

/* {XM_XPATH_XSLT_STYLE_CONSTANTS}.version_attribute */

EIF_REFERENCE F35_414 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (414,RTMS_EX_H("version",7,1397649262));
}

/* {XM_XPATH_XSLT_STYLE_CONSTANTS}.xpath_default_namespace_attribute */

EIF_REFERENCE F35_415 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (415,RTMS_EX_H("xpath-default-namespace",23,1696926821));
}

void EIF_Minit35 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
