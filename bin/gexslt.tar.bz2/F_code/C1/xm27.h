
#ifndef _C1_xm27_
#define _C1_xm27_

#ifdef __cplusplus
extern "C" {
#endif

extern void F27_226(EIF_REFERENCE, EIF_REFERENCE);
extern void F27_227(EIF_REFERENCE);
extern EIF_BOOLEAN F27_229(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit27(void);
extern EIF_BOOLEAN F1525_12411(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
