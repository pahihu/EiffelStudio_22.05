
#ifndef _C1_xm48_
#define _C1_xm48_

#ifdef __cplusplus
extern "C" {
#endif

extern void F72_744(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F72_745(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F72_747(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F72_758(EIF_REFERENCE);
extern void F72_759(EIF_REFERENCE, EIF_REFERENCE);
extern void F72_760(EIF_REFERENCE);
extern void F72_761(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit48(void);
extern void F1591_13204(EIF_REFERENCE);
extern char *(*R1131[])();
extern long O11855[];
extern long O11856[];
extern long O11859[];

#ifdef __cplusplus
}
#endif

#endif
