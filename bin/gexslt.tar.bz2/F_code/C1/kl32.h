
#ifndef _C1_kl32_
#define _C1_kl32_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F32_265(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F32_266(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit32(void);

#ifdef __cplusplus
}
#endif

#endif
