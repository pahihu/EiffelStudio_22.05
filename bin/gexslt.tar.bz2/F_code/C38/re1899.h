
#ifndef _C38_re1899_
#define _C38_re1899_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F808_3913(EIF_REFERENCE);
extern void EIF_Minit1899(void);
extern EIF_INTEGER_32 F890_4379(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
