/*
 * Code for class DS_RESIZABLE [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1866.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_RESIZABLE}.default_capacity */
EIF_INTEGER_32 F1500_12123 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
}

/* {DS_RESIZABLE}.is_full */
EIF_BOOLEAN F1500_12124 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9856[dtype-1508]) == *(EIF_INTEGER_32 *)(Current + O9855[dtype-1508]));
}

/* {DS_RESIZABLE}.new_capacity */
EIF_INTEGER_32 F1500_12126 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 3L)) / ((EIF_INTEGER_32) 2L));
}

void EIF_Minit1866 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
