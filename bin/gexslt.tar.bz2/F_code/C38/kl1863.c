/*
 * Code for class KL_EQUALITY_TESTER [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl1863.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_EQUALITY_TESTER}.test */
EIF_BOOLEAN F467_3582 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1, EIF_NATURAL_64 arg2)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		return (EIF_BOOLEAN) (arg1 == arg2);
	}/* NOTREACHED */
	
}

void EIF_Minit1863 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
