/*
 * Code for class DS_BILINEAR_CURSOR [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1856.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_BILINEAR_CURSOR}.is_last */
EIF_BOOLEAN F1332_11371 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1512_12318(RTCW(tr1), Current);
	RTLE;
	return Result;
}

/* {DS_BILINEAR_CURSOR}.off */
EIF_BOOLEAN F1332_11373 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F1350_11391(Current)) {
		Result = F1350_11392(Current);
	}
	RTLE;
	return Result;
}

/* {DS_BILINEAR_CURSOR}.finish */
void F1332_11374 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1512_12321(RTCW(tr1), Current);
	RTLE;
}

/* {DS_BILINEAR_CURSOR}.back */
void F1332_11375 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1512_12323(RTCW(tr1), Current);
	RTLE;
}

/* {DS_BILINEAR_CURSOR}.go_before */
void F1332_11377 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1512_12327(RTCW(tr1), Current);
	RTLE;
}

void EIF_Minit1856 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
