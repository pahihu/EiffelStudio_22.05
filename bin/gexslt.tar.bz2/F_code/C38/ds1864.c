/*
 * Code for class DS_SPARSE_CONTAINER [NATURAL_64, NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1864.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_CONTAINER}.make */
void F1512_12240 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O9855[dtype-1508]) = (EIF_INTEGER_32) arg1;
	F1534_12446(Current, arg1);
	F1534_12452(Current, arg1);
	F1534_12459(Current, arg1);
	ti4_1 = F1512_12330(Current, arg1);
	*(EIF_INTEGER_32 *)(Current + O9840[dtype-1508]) = (EIF_INTEGER_32) ti4_1;
	F1534_12465(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O9840[dtype-1508]) + ((EIF_INTEGER_32) 1L)));
	*(EIF_INTEGER_32 *)(Current + O9805[dtype-1508]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current + O9841[dtype-1508]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	F1512_12259(Current);
	tr1 = F1540_12475(Current);
	F1512_12310(Current, tr1);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.found_item */
EIF_NATURAL_64 F1512_12241 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_64) F1534_12441(Current, *(EIF_INTEGER_32 *)(Current + O9845[Dtype(Current)-1508]));
}

/* {DS_SPARSE_CONTAINER}.count */
EIF_INTEGER_32 F1512_12245 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O9856[Dtype(Current)-1508]);
}


/* {DS_SPARSE_CONTAINER}.capacity */
EIF_INTEGER_32 F1512_12246 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O9855[Dtype(Current)-1508]);
}


/* {DS_SPARSE_CONTAINER}.found */
EIF_BOOLEAN F1512_12249 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9845[Dtype(Current)-1508]) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_CONTAINER}.unset_found_item */
void F1512_12259 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O9845[Dtype(Current)-1508]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
}

/* {DS_SPARSE_CONTAINER}.copy */
void F1512_12260 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1512_12312(Current);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = F1436_11732(Current, loc1);
		}
		if (tb1) {
			F1512_12310(Current, loc1);
		} else {
			tr1 = F1540_12475(Current);
			F1512_12310(Current, tr1);
		}
		F1512_12259(Current);
		F1534_12447(Current);
		F1534_12454(Current);
		F1534_12468(Current);
		F1534_12461(Current);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.remove */
void F1512_12261 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1512_12259(Current);
	F1512_12273(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]) != ((EIF_INTEGER_32) -1L))) {
		F1512_12278(Current, *(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]));
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.wipe_out */
void F1512_12263 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1512_12312(Current);
	F1512_12259(Current);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O9856[dtype-1508]) > ((EIF_INTEGER_32) 0L))) {
		F1534_12449(Current);
		F1534_12456(Current);
		F1534_12463(Current);
		F1534_12470(Current);
		*(EIF_INTEGER_32 *)(Current + O9805[dtype-1508]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		*(EIF_INTEGER_32 *)(Current + O9841[dtype-1508]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		*(EIF_INTEGER_32 *)(Current + O9856[dtype-1508]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	*(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.resize */
void F1512_12264 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1512_12259(Current);
	loc1 = F1512_12330(Current, arg1);
	F1534_12469(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
	loc2 = *(EIF_INTEGER_32 *)(Current + O9840[dtype-1508]);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		F1534_12467(Current, ((EIF_INTEGER_32) -1L), loc2);
		loc2--;
	}
	*(EIF_INTEGER_32 *)(Current + O9840[dtype-1508]) = (EIF_INTEGER_32) loc1;
	loc2 = *(EIF_INTEGER_32 *)(Current + O9805[dtype-1508]);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		if ((EIF_BOOLEAN) (F1534_12444(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
			tu4_1 = F1534_12443(Current, loc2);
			loc3 = F1540_12478(Current, tu4_1);
			ti4_1 = F1534_12466(Current, loc3);
			F1534_12460(Current, ti4_1, loc2);
			F1534_12467(Current, loc2, loc3);
		}
		loc2--;
	}
	F1534_12448(Current, arg1);
	F1534_12455(Current, arg1);
	F1534_12462(Current, arg1);
	*(EIF_INTEGER_32 *)(Current + O9855[dtype-1508]) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.search_position */
void F1512_12273 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (EIF_FALSE) {
		ti4_1 = F1534_12466(Current, *(EIF_INTEGER_32 *)(Current + O9840[dtype-1508]));
		*(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]) = (EIF_INTEGER_32) ti4_1;
		*(EIF_INTEGER_32 *)(Current + O9843[dtype-1508]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O9840[dtype-1508]);
		*(EIF_INTEGER_32 *)(Current + O9844[dtype-1508]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		loc3 = *(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			loc4 = *(EIF_INTEGER_32 *)(Current + O9843[dtype-1508]);
			loc2 = *(EIF_INTEGER_32 *)(Current + O9844[dtype-1508]);
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) (F1534_12444(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				tu4_1 = F1534_12443(Current, loc3);
				tb2 = F466_3582(loc5, arg1, tu4_1);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				loc4 = F1540_12478(Current, arg1);
				loc1 = F1534_12466(Current, loc4);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					tu4_1 = F1534_12443(Current, loc1);
					tb1 = F466_3582(loc5, arg1, tu4_1);
					if (tb1) {
						loc3 = (EIF_INTEGER_32) loc1;
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 = (EIF_INTEGER_32) loc1;
						ti4_1 = F1534_12444(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
			}
			*(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]) = (EIF_INTEGER_32) loc3;
			*(EIF_INTEGER_32 *)(Current + O9843[dtype-1508]) = (EIF_INTEGER_32) loc4;
			*(EIF_INTEGER_32 *)(Current + O9844[dtype-1508]) = (EIF_INTEGER_32) loc2;
		} else {
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) (F1534_12444(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				tb1 = (EIF_BOOLEAN)(arg1 != F1534_12443(Current, loc3));
			}
			if (tb1) {
				loc4 = F1540_12478(Current, arg1);
				loc1 = F1534_12466(Current, loc4);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					if ((EIF_BOOLEAN)(arg1 == F1534_12443(Current, loc1))) {
						loc3 = (EIF_INTEGER_32) loc1;
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 = (EIF_INTEGER_32) loc1;
						ti4_1 = F1534_12444(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
				*(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]) = (EIF_INTEGER_32) loc3;
				*(EIF_INTEGER_32 *)(Current + O9843[dtype-1508]) = (EIF_INTEGER_32) loc4;
				*(EIF_INTEGER_32 *)(Current + O9844[dtype-1508]) = (EIF_INTEGER_32) loc2;
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.position_of_key */
EIF_INTEGER_32 F1512_12274 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (EIF_FALSE) {
		RTLE;
		return (EIF_INTEGER_32) F1534_12466(Current, *(EIF_INTEGER_32 *)(Current + O9840[Dtype(Current)-1508]));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			loc3 = F1540_12478(Current, arg1);
			loc1 = F1534_12466(Current, loc3);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
				tu4_1 = F1534_12443(Current, loc1);
				tb1 = F466_3582(loc4, arg1, tu4_1);
				if (tb1) {
					loc2 = (EIF_INTEGER_32) loc1;
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				} else {
					ti4_1 = F1534_12444(Current, loc1);
					loc1 = (EIF_INTEGER_32) ti4_1;
				}
			}
		} else {
			loc3 = F1540_12478(Current, arg1);
			loc1 = F1534_12466(Current, loc3);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
				if ((EIF_BOOLEAN)(arg1 == F1534_12443(Current, loc1))) {
					loc2 = (EIF_INTEGER_32) loc1;
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				} else {
					ti4_1 = F1534_12444(Current, loc1);
					loc1 = (EIF_INTEGER_32) ti4_1;
				}
			}
		}
		RTLE;
		return (EIF_INTEGER_32) loc2;
	}/* NOTREACHED */
	
}

/* {DS_SPARSE_CONTAINER}.remove_position */
void F1512_12278 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]))) {
		loc1 = F1534_12443(Current, arg1);
		loc2 = F1540_12478(Current, loc1);
		if ((EIF_BOOLEAN)(F1534_12466(Current, loc2) == arg1)) {
			*(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]) = (EIF_INTEGER_32) arg1;
			*(EIF_INTEGER_32 *)(Current + O9843[dtype-1508]) = (EIF_INTEGER_32) loc2;
			*(EIF_INTEGER_32 *)(Current + O9844[dtype-1508]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		} else {
			loc3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1528_12436(Current, NULL);
			F1512_12273(Current, loc1);
			F1528_12436(Current, loc3);
		}
	}
	F1512_12315(Current, *(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]));
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9844[dtype-1508]) == ((EIF_INTEGER_32) -1L))) {
		ti4_1 = F1534_12444(Current, *(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]));
		ti4_2 = *(EIF_INTEGER_32 *)(Current + O9843[dtype-1508]);
		F1534_12467(Current, ti4_1, ti4_2);
	} else {
		ti4_1 = F1534_12444(Current, *(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]));
		ti4_2 = *(EIF_INTEGER_32 *)(Current + O9844[dtype-1508]);
		F1534_12460(Current, ti4_1, ti4_2);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9841[dtype-1508]) == ((EIF_INTEGER_32) -1L)) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]) == *(EIF_INTEGER_32 *)(Current + O9805[dtype-1508])))) {
		F1534_12450(Current, *(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]));
		F1534_12457(Current, *(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]));
		F1534_12460(Current, ((EIF_INTEGER_32) -1L), *(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]));
		*(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		(*(EIF_INTEGER_32 *)(Current + O9805[dtype-1508]))--;
	} else {
		tr1 = RTLNTY2(eif_final_id(Y9575,Y9575_gen_type,dftype,1417), 0x00);
		tb1 = (EIF_BOOLEAN) eif_builtin_TYPE_has_default__b (tr1);
		if (tb1) {
			tr1 = RTLNTY2(eif_final_id(Y9575,Y9575_gen_type,dftype,1417), 0x00);
			tu8_1 = F1008_5062(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]);
			F1534_12442(Current, tu8_1, ti4_1);
		}
		tr1 = RTLNTY2(eif_final_id(Y9857,Y9857_gen_type,dftype,1508), 0x00);
		tb1 = (EIF_BOOLEAN) eif_builtin_TYPE_has_default__b (tr1);
		if (tb1) {
			tr1 = RTLNTY2(eif_final_id(Y9857,Y9857_gen_type,dftype,1508), 0x00);
			tu4_1 = F1007_5062(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]);
			F1534_12453(Current, tu4_1, ti4_1);
		}
		F1534_12460(Current, (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - *(EIF_INTEGER_32 *)(Current + O9841[dtype-1508])), *(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]));
		*(EIF_INTEGER_32 *)(Current + O9841[dtype-1508]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O9842[dtype-1508]);
	}
	(*(EIF_INTEGER_32 *)(Current + O9856[dtype-1508]))--;
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.set_internal_cursor */
void F1512_12310 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {DS_SPARSE_CONTAINER}.internal_cursor */
EIF_REFERENCE F1512_12311 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {DS_SPARSE_CONTAINER}.move_all_cursors_after */
void F1512_12312 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		F1350_11396(RTCW(loc1));
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		F1310_11352(RTCW(loc1), NULL);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.move_cursors_forth */
void F1512_12315 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == arg1)) {
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
				loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
				loc5 = *(EIF_INTEGER_32 *)(Current + O9805[Dtype(Current)-1508]);
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (loc4 > loc5)) {
						tb1 = (EIF_BOOLEAN) (F1534_12444(Current, loc4) > ((EIF_INTEGER_32) -2L));
					}
					if (tb1) break;
					loc4++;
				}
			}
			if ((EIF_BOOLEAN) (loc4 > loc5)) {
				F1350_11396(RTCW(loc1));
				if ((EIF_BOOLEAN)(loc3 == NULL)) {
					loc3 = (EIF_REFERENCE) loc1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
					F1310_11352(RTCW(loc3), loc2);
					F1310_11352(RTCW(loc1), NULL);
					loc1 = (EIF_REFERENCE) loc2;
				}
			} else {
				F1350_11395(RTCW(loc1), loc4);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				loc1 = (EIF_REFERENCE) tr1;
			}
		} else {
			loc3 = (EIF_REFERENCE) loc1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_item */
EIF_NATURAL_64 F1512_12316 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	Result = F1534_12441(Current, ti4_1);
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_is_first */
EIF_BOOLEAN F1512_12317 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1421_11697(Current)) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) (F1534_12444(Current, loc1) > ((EIF_INTEGER_32) -2L))) break;
			loc1++;
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == loc1);
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_is_last */
EIF_BOOLEAN F1512_12318 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1421_11697(Current)) {
		loc1 = *(EIF_INTEGER_32 *)(Current + O9805[Dtype(Current)-1508]);
		for (;;) {
			if ((EIF_BOOLEAN) (F1534_12444(Current, loc1) > ((EIF_INTEGER_32) -2L))) break;
			loc1--;
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == loc1);
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_same_position */
EIF_BOOLEAN F1512_12319 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_start */
void F1512_12320 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if (F1421_11697(Current)) {
		F1350_11396(RTCW(arg1));
	} else {
		loc3 = F1436_11737(Current, arg1);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc2 = *(EIF_INTEGER_32 *)(Current + O9805[Dtype(Current)-1508]);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 > loc2)) {
				tb1 = (EIF_BOOLEAN) (F1534_12444(Current, loc1) > ((EIF_INTEGER_32) -2L));
			}
			if (tb1) break;
			loc1++;
		}
		if ((EIF_BOOLEAN) (loc1 > loc2)) {
			F1350_11396(RTCW(arg1));
			if ((EIF_BOOLEAN) !loc3) {
				F1436_11741(Current, arg1);
			}
		} else {
			F1350_11395(RTCW(arg1), loc1);
			if (loc3) {
				F1436_11740(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_finish */
void F1512_12321 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if (F1421_11697(Current)) {
		F1350_11397(RTCW(arg1));
	} else {
		loc2 = F1436_11737(Current, arg1);
		loc1 = *(EIF_INTEGER_32 *)(Current + O9805[Dtype(Current)-1508]);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
				tb1 = (EIF_BOOLEAN) (F1534_12444(Current, loc1) > ((EIF_INTEGER_32) -2L));
			}
			if (tb1) break;
			loc1--;
		}
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
			F1350_11397(RTCW(arg1));
			if ((EIF_BOOLEAN) !loc2) {
				F1436_11741(Current, arg1);
			}
		} else {
			F1350_11395(RTCW(arg1), loc1);
			if (loc2) {
				F1436_11740(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_forth */
void F1512_12322 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_1 = ((EIF_INTEGER_32) -2L);
	if ((EIF_BOOLEAN)(loc4 == ti4_1)) {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
	}
	loc2 = *(EIF_INTEGER_32 *)(Current + O9805[Dtype(Current)-1508]);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > loc2)) {
			tb1 = (EIF_BOOLEAN) (F1534_12444(Current, loc1) > ((EIF_INTEGER_32) -2L));
		}
		if (tb1) break;
		loc1++;
	}
	if ((EIF_BOOLEAN) (loc1 > loc2)) {
		F1350_11396(RTCW(arg1));
		if ((EIF_BOOLEAN) !loc3) {
			F1436_11741(Current, arg1);
		}
	} else {
		F1350_11395(RTCW(arg1), loc1);
		if (loc3) {
			F1436_11740(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_back */
void F1512_12323 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_1 = ((EIF_INTEGER_32) -3L);
	if ((EIF_BOOLEAN)(loc3 == ti4_1)) {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = *(EIF_INTEGER_32 *)(Current + O9805[Dtype(Current)-1508]);
	} else {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
	}
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
			tb1 = (EIF_BOOLEAN) (F1534_12444(Current, loc1) > ((EIF_INTEGER_32) -2L));
		}
		if (tb1) break;
		loc1--;
	}
	if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
		F1350_11397(RTCW(arg1));
		if ((EIF_BOOLEAN) !loc2) {
			F1436_11741(Current, arg1);
		}
	} else {
		F1350_11395(RTCW(arg1), loc1);
		if (loc2) {
			F1436_11740(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_search_forth */
void F1512_12324 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_64 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		for (;;) {
			tb1 = '\01';
			if (!F1448_11769(Current, arg1)) {
				tu8_1 = F1512_12316(Current, arg1);
				tb2 = F467_3582(loc1, tu8_1, arg2);
				tb1 = tb2;
			}
			if (tb1) break;
			F1512_12322(Current, arg1);
		}
	} else {
		for (;;) {
			tb2 = '\01';
			if (!F1448_11769(Current, arg1)) {
				tb2 = (EIF_BOOLEAN)(F1512_12316(Current, arg1) == arg2);
			}
			if (tb2) break;
			F1512_12322(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_go_after */
void F1512_12326 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1436_11737(Current, arg1);
	F1350_11396(RTCW(arg1));
	if ((EIF_BOOLEAN) !loc1) {
		F1436_11741(Current, arg1);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_go_before */
void F1512_12327 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1436_11737(Current, arg1);
	F1350_11397(RTCW(arg1));
	if ((EIF_BOOLEAN) !loc1) {
		F1436_11741(Current, arg1);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.new_capacity */
EIF_INTEGER_32 F1512_12329 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * arg1);
}

/* {DS_SPARSE_CONTAINER}.new_modulus */
EIF_INTEGER_32 F1512_12330 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 3L)) / ((EIF_INTEGER_32) 2L));
}

void EIF_Minit1864 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
