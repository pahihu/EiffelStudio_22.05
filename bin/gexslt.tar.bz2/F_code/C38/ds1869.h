
#ifndef _C38_ds1869_
#define _C38_ds1869_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1378_11416(EIF_REFERENCE);
extern void EIF_Minit1869(void);

#ifdef __cplusplus
}
#endif

#endif
