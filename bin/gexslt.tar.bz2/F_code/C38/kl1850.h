
#ifndef _C38_kl1850_
#define _C38_kl1850_

#ifdef __cplusplus
extern "C" {
#endif

extern void F899_4424(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1850(void);

#ifdef __cplusplus
}
#endif

#endif
