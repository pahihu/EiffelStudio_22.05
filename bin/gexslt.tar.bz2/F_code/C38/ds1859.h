
#ifndef _C38_ds1859_
#define _C38_ds1859_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1323_11360(EIF_REFERENCE);
extern void F1323_11363(EIF_REFERENCE);
extern void F1323_11364(EIF_REFERENCE);
extern void F1323_11366(EIF_REFERENCE);
extern void EIF_Minit1859(void);
extern EIF_BOOLEAN F1512_12317(EIF_REFERENCE, EIF_REFERENCE);
extern void F1512_12322(EIF_REFERENCE, EIF_REFERENCE);
extern void F1512_12320(EIF_REFERENCE, EIF_REFERENCE);
extern void F1512_12326(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
