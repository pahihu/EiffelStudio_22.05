
#ifndef _C38_re1888_
#define _C38_re1888_

#ifdef __cplusplus
extern "C" {
#endif

extern void F552_3715(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F552_3717(EIF_REFERENCE);
extern EIF_INTEGER_32 F552_3718(EIF_REFERENCE);
extern EIF_INTEGER_32 F552_3719(EIF_REFERENCE);
extern EIF_INTEGER_32 F552_3720(EIF_REFERENCE);
extern EIF_BOOLEAN F552_3728(EIF_REFERENCE);
extern EIF_BOOLEAN F552_3729(EIF_REFERENCE);
extern void F552_3734(EIF_REFERENCE);
extern void EIF_Minit1888(void);
extern char *(*R3639[])();
extern char *(*R3640[])();

#ifdef __cplusplus
}
#endif

#endif
