
#ifndef _C38_to1893_
#define _C38_to1893_

#ifdef __cplusplus
extern "C" {
#endif

extern void F358_2986(EIF_REFERENCE, EIF_INTEGER_32);
extern void F358_2987(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void F358_2993(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1893(void);
extern void F863_4278(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2709[];
extern EIF_TYPE_INDEX *Y2709_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
