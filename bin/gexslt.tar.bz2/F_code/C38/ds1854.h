
#ifndef _C38_ds1854_
#define _C38_ds1854_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1421_11697(EIF_REFERENCE);
extern void EIF_Minit1854(void);
extern long O9856[];

#ifdef __cplusplus
}
#endif

#endif
