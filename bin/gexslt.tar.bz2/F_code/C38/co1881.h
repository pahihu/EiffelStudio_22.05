
#ifndef _C38_co1881_
#define _C38_co1881_

#ifdef __cplusplus
extern "C" {
#endif

extern void F626_3802(EIF_REFERENCE);
extern void EIF_Minit1881(void);
extern long O3366[];

#ifdef __cplusplus
}
#endif

#endif
