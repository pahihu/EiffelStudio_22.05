
#ifndef _C38_kl1863_
#define _C38_kl1863_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F467_3582(EIF_REFERENCE, EIF_NATURAL_64, EIF_NATURAL_64);
extern void EIF_Minit1863(void);

#ifdef __cplusplus
}
#endif

#endif
