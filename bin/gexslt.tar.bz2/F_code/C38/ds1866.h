
#ifndef _C38_ds1866_
#define _C38_ds1866_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1500_12123(EIF_REFERENCE);
extern EIF_BOOLEAN F1500_12124(EIF_REFERENCE);
extern EIF_INTEGER_32 F1500_12126(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1866(void);
extern long O9855[];
extern long O9856[];

#ifdef __cplusplus
}
#endif

#endif
