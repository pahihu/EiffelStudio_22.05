
#ifndef _C38_fi1882_
#define _C38_fi1882_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F780_3900(EIF_REFERENCE);
extern void EIF_Minit1882(void);
extern char *(*R3428[])();

#ifdef __cplusplus
}
#endif

#endif
