
#ifndef _C38_ds1862_
#define _C38_ds1862_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1442_11745(EIF_REFERENCE, EIF_REFERENCE);
extern void F1442_11749(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1862(void);

#ifdef __cplusplus
}
#endif

#endif
