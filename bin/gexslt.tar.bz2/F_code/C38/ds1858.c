/*
 * Code for class DS_LINEAR [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1858.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINEAR}.new_iterator */
EIF_REFERENCE F1448_11752 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F1540_12475(Current);
	F1323_11363(RTCW(Result));
	RTLE;
	return Result;
}

/* {DS_LINEAR}.after */
EIF_BOOLEAN F1448_11754 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F1448_11769(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
}

/* {DS_LINEAR}.start */
void F1448_11757 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1512_12320(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
}

/* {DS_LINEAR}.forth */
void F1448_11758 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1512_12322(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
}

/* {DS_LINEAR}.search_forth */
void F1448_11759 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	
	
	F1512_12324(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1);
}

/* {DS_LINEAR}.cursor_after */
EIF_BOOLEAN F1448_11769 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	
	
	tb1 = F1350_11391(RTCW(arg1));
	return (EIF_BOOLEAN) tb1;
}

void EIF_Minit1858 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
