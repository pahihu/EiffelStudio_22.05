/*
 * Code for class DS_TRAVERSABLE [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1861.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_TRAVERSABLE}.item_for_iteration */
EIF_NATURAL_64 F1436_11728 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_64) F1512_12316(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
}

/* {DS_TRAVERSABLE}.valid_cursor */
EIF_BOOLEAN F1436_11732 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == Current);
	RTLE;
	return Result;
}

/* {DS_TRAVERSABLE}.cursor_off */
EIF_BOOLEAN F1436_11737 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	
	
	tb1 = F1350_11393(RTCW(arg1));
	return (EIF_BOOLEAN) tb1;
}

/* {DS_TRAVERSABLE}.add_traversing_cursor */
void F1436_11740 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + _REFACS_1_))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		F1310_11352(RTCW(arg1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1310_11352(RTCW(tr1), arg1);
	}
	RTLE;
}

/* {DS_TRAVERSABLE}.remove_traversing_cursor */
void F1436_11741 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + _REFACS_1_))) {
		loc2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = *(EIF_REFERENCE *)(RTCW(loc2));
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == arg1) || (EIF_BOOLEAN)(loc1 == NULL))) break;
			loc2 = (EIF_REFERENCE) loc1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
		if ((EIF_BOOLEAN)(loc1 == arg1)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			F1310_11352(RTCW(loc2), tr1);
			F1310_11352(RTCW(arg1), NULL);
		}
	}
	RTLE;
}

void EIF_Minit1861 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
