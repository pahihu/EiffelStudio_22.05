
#ifndef _C11_ki510_
#define _C11_ki510_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1213_9667(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1213_9671(EIF_REFERENCE, EIF_INTEGER_64);
extern void F1213_9674(EIF_REFERENCE, EIF_NATURAL_32);
extern void F1213_9675(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit510(void);
extern char *(*R1126[])();

#ifdef __cplusplus
}
#endif

#endif
