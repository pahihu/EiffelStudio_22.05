/*
 * Code for class XM_XPATH_TYPE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm531.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_TYPE_FACTORY}.standard_uri_code */
EIF_INTEGER_32 F1234_10185 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 256L));
}

/* {XM_XPATH_TYPE_FACTORY}.standard_uri */
EIF_REFERENCE F1234_10187 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	switch ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 256L))) {
		case 0L:
			Result = RTOSCF(9820,F1230_9820, (Current));
			break;
		case 1L:
			Result = RTOSCF(9821,F1230_9821, (Current));
			break;
		case 2L:
			Result = RTOSCF(9823,F1230_9823, (Current));
			break;
		case 4L:
			Result = RTOSCF(9829,F1230_9829, (Current));
			break;
		case 5L:
			Result = RTOSCF(9822,F1230_9822, (Current));
			break;
		case 6L:
			Result = RTOSCF(9824,F1230_9824, (Current));
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_TYPE_FACTORY}.standard_prefix */
EIF_REFERENCE F1234_10188 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = F1234_10244(Current, arg1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5071[Dtype(RTCW(Result))-1111])(Result, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
		Result = (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

/* {XM_XPATH_TYPE_FACTORY}.is_built_in_fingerprint */
EIF_BOOLEAN F1234_10242 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 256L) < arg1) && (EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 2048L)));
}

/* {XM_XPATH_TYPE_FACTORY}.is_primitive_type */
EIF_BOOLEAN F1234_10243 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 532L))) || (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1025L))) || (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 560L))) || (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 561L))) || (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 563L))) || (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 562L))) || (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 558L)));
}

/* {XM_XPATH_TYPE_FACTORY}.conventional_prefix */
EIF_REFERENCE F1234_10244 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 256L));
	switch (loc1) {
		case 0L:
			Result = RTMS_EX_H("",0,0);
			break;
		case 1L:
			Result = RTMS_EX_H("xml:",4,2020437050);
			break;
		case 2L:
			Result = RTMS_EX_H("xs:",3,7893818);
			break;
		case 4L:
			Result = RTMS_EX_H("gexslt:",7,290585402);
			break;
		case 5L:
			Result = RTMS_EX_H("xsl:",4,2020830266);
			break;
		case 6L:
			Result = RTMS_EX_H("xsi:",4,2020829498);
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
	return Result;
}

void EIF_Minit531 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
