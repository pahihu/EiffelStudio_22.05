/*
 * Code for class XM_XSLT_DEFAULT_TRACE_LISTENER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm530.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_DEFAULT_TRACE_LISTENER}.make */
void F1233_10167 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) arg2;
	RTLE;
}

/* {XM_XSLT_DEFAULT_TRACE_LISTENER}.opening_namespace_declarations */
EIF_REFERENCE F1233_10169 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTMS_EX_H("xmlns=\"http://www.gobosoft.com/eiffel/gobo/gexslt/trace\" xmlns:xsl=\"",68,68341282);
	tr2 = RTOSCF(9822,F1230_9822, (Current));
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(tr1)-1111])(tr1, tr2);
	tr2 = RTMS_EX_H("\"",1,34);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5143[Dtype(RTCW(tr1))-1111])(tr1, tr2);
	RTLE;
	return Result;
}

/* {XM_XSLT_DEFAULT_TRACE_LISTENER}.is_tracing */
EIF_BOOLEAN F1233_10173 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
}


/* {XM_XSLT_DEFAULT_TRACE_LISTENER}.start_tracing */
void F1233_10174 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = RTMS_EX_H("<trace ",7,1997116192);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = F1233_10169(Current);
	F1581_13016(RTCW(tr1), tr2);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_)) {
		tr1 = F1721_15176(RTCV(RTOSCF(3565,F460_3565, (Current))));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTMS_EX_H(" timing=\"true\">",15,243431486);
		F1581_13016(RTCW(tr1), tr2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTMS_EX_H(" timing=\"false\">",16,1790806846);
		F1581_13016(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {XM_XSLT_DEFAULT_TRACE_LISTENER}.stop_tracing */
void F1233_10175 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_)) {
		RTCT0("attached start_time as l_start_time", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc2 = F1721_15176(RTCV(RTOSCF(3565,F460_3565, (Current))));
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R10685[Dtype(RTCW(loc2))-1615])(loc2, loc3);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTMS_EX_H(" <end time=\"",12,453316386);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		ti4_1 = F1617_13573(RTCW(loc1));
		tr2 = eif_out__i4_s1(ti4_1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTMS_EX_H("\"/>",3,2240318);
		F1581_13016(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTMS_EX_H("</trace>",8,1910265406);
	F1581_13016(RTCW(tr1), tr2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {XM_XSLT_DEFAULT_TRACE_LISTENER}.trace_instruction_entry */
void F1233_10176 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,loc4);
	RTLR(5,loc1);
	RTLR(6,loc5);
	RTLR(7,loc3);
	RTLR(8,loc2);
	RTLIU(9);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))++;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = F1233_10181(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = RTMS_EX_H("<",1,60);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = F1233_10182(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = RTMS_EX_H(" ",1,32);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8583[Dtype(RTCW(arg1))-2153])(arg1);
	if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2000L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTOSCF(10129,F1230_10129, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTMS_EX_H("=\"",2,15650);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTOSCF(10129,F1230_10129, (Current));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8584[Dtype(RTCW(arg1))-2153])(arg1, tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTMS_EX_H("\" ",2,8736);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	}
	tr1 = F2153_21447(RTCW(arg1));
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9598[Dtype(RTCW(tr1))-1481])(tr1);
	F1320_11363(RTCW(loc4));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3187[Dtype(RTCW(loc4))-556])(loc4);
		if (tb1) break;
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3186[Dtype(RTCW(loc4))-556])(loc4);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = F1227_9771(Current, loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTMS_EX_H("=\"",2,15650);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R8584[Dtype(RTCW(arg1))-2153])(arg1, loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTMS_EX_H("\" ",2,8736);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		F1320_11364(RTCW(loc4));
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = RTMS_EX_H(" line=\"",7,991560482);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	ti4_1 = F2141_21197(RTCW(arg1));
	tr2 = eif_out__i4_s1(ti4_1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = RTMS_EX_H("\" base_uri=\"",12,1098635042);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = F2141_21196(RTCW(arg1));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_)) {
		RTCT0("attached start_time as l_start_time", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc3 = F1721_15176(RTCV(RTOSCF(3565,F460_3565, (Current))));
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R10685[Dtype(RTCW(loc3))-1615])(loc3, loc5);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTMS_EX_H("\" time=\"",8,998345506);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		ti4_1 = F1617_13573(RTCW(loc2));
		tr2 = eif_out__i4_s1(ti4_1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTMS_EX_H("\">",2,8766);
	F1581_13016(RTCW(tr1), tr2);
	RTLE;
}

/* {XM_XSLT_DEFAULT_TRACE_LISTENER}.trace_instruction_exit */
void F1233_10177 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_)) {
		RTCT0("attached start_time as l_start_time", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc2 = F1721_15176(RTCV(RTOSCF(3565,F460_3565, (Current))));
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R10685[Dtype(RTCW(loc2))-1615])(loc2, loc3);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = F1233_10181(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) + ((EIF_INTEGER_32) 1L)));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTMS_EX_H("<end time=\"",11,1812167202);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		ti4_1 = F1617_13573(RTCW(loc1));
		tr2 = eif_out__i4_s1(ti4_1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTMS_EX_H("\"/>",3,2240318);
		F1581_13016(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = F1233_10181(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = RTMS_EX_H("</",2,15407);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = F1233_10182(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTMS_EX_H(">",1,62);
	F1581_13016(RTCW(tr1), tr2);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))--;
	RTLE;
}

/* {XM_XSLT_DEFAULT_TRACE_LISTENER}.trace_current_item_start */
void F1233_10178 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLR(6,arg1);
	RTLR(7,loc1);
	RTLR(8,loc5);
	RTLIU(9);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_)) {
		RTCT0("attached start_time as l_start_time", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc3 = F1721_15176(RTCV(RTOSCF(3565,F460_3565, (Current))));
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R10685[Dtype(RTCW(loc3))-1615])(loc3, loc4);
	}
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))++;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = F1233_10181(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13398[Dtype(RTCW(arg1))-1819])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_)) {
			RTCT0("a_duration /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
			tr2 = RTMS_EX_H("<item time=\"",12,1395804962);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
			ti4_1 = F1617_13573(RTCW(loc2));
			tr2 = eif_out__i4_s1(ti4_1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = RTMS_EX_H("\">",2,8766);
			F1581_13016(RTCW(tr1), tr2);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = RTMS_EX_H("<item>",6,2071575358);
			F1581_13016(RTCW(tr1), tr2);
		}
	} else {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13416[Dtype(RTCW(arg1))-1819])(arg1);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTMS_EX_H("<node path=\"",12,1143572002);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13634[Dtype(RTCW(loc1))-1853])(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTMS_EX_H("\" line=\"",8,999394082);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R3237[Dtype(RTCW(loc1))-475])(loc1);
		tr2 = eif_out__i4_s1(ti4_1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTMS_EX_H("\" base_uri=\"",12,1098635042);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		RTCT0("attached a_node.base_uri as l_base_uri", EX_CHECK);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13623[Dtype(RTCW(loc1))-1853])(loc1);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, loc5);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_)) {
			RTCT0("a_duration /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
			tr2 = RTMS_EX_H("\" time=\"",8,998345506);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
			ti4_1 = F1617_13573(RTCW(loc2));
			tr2 = eif_out__i4_s1(ti4_1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTMS_EX_H("\">",2,8766);
		F1581_13016(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {XM_XSLT_DEFAULT_TRACE_LISTENER}.trace_current_item_finish */
void F1233_10179 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc3);
	RTLR(4,loc2);
	RTLR(5,loc1);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = F1233_10181(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) + ((EIF_INTEGER_32) 1L)));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_)) {
		RTCT0("attached start_time as l_start_time", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc2 = F1721_15176(RTCV(RTOSCF(3565,F460_3565, (Current))));
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R10685[Dtype(RTCW(loc2))-1615])(loc2, loc3);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTMS_EX_H("<end time=\"",11,1812167202);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		ti4_1 = F1617_13573(RTCW(loc1));
		tr2 = eif_out__i4_s1(ti4_1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTMS_EX_H("\"/>",3,2240318);
		F1581_13016(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = F1233_10181(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13398[Dtype(RTCW(arg1))-1819])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTMS_EX_H("</item>",7,32807998);
		F1581_13016(RTCW(tr1), tr2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = RTMS_EX_H("</node><!-- ",12,163748640);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13416[Dtype(RTCW(arg1))-1819])(arg1);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13634[Dtype(RTCW(tr2))-1853])(tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTMS_EX_H(" -->",4,539831614);
		F1581_13016(RTCW(tr1), tr2);
	}
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))--;
	RTLE;
}

/* {XM_XSLT_DEFAULT_TRACE_LISTENER}.trace_user_entry */
void F1233_10180 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = F1233_10181(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) + ((EIF_INTEGER_32) 1L)));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = RTMS_EX_H("<user-entry label=\"",19,242514722);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr2 = RTMS_EX_H("\" value=\"",9,1288312866);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7914[Dtype(RTCW(tr1))-1214])(tr1, arg2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTMS_EX_H("\"/>",3,2240318);
	F1581_13016(RTCW(tr1), tr2);
	RTLE;
}

/* {XM_XSLT_DEFAULT_TRACE_LISTENER}.spaces */
EIF_REFERENCE F1233_10181 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1111_6439(RTCW(tr1), (EIF_CHARACTER_8) ' ', arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_XSLT_DEFAULT_TRACE_LISTENER}.tag_name */
EIF_REFERENCE F1233_10182 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8583[Dtype(RTCW(arg1))-2153])(arg1);
	switch (ti4_1) {
		case 2001L:
			Result = RTMS_EX_H("LRE",3,5001797);
			break;
		case 2002L:
			Result = RTMS_EX_H("XPath expression",16,1446755182);
			break;
		default:
			tr1 = RTOSCF(4950,F991_4950, (Current));
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8583[Dtype(RTCW(arg1))-2153])(arg1);
			Result = F1242_10452(RTCW(tr1), ti4_1);
			break;
	}
	RTLE;
	return Result;
}

void EIF_Minit530 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
