#include "epoly17.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5086[1103])();
void R5086_init () {
	R5086[0] = (char *(*)()) F1113_6600;
	R5086[4] = (char *(*)()) F1117_6768;
	{long i; for (i = 1101; i < 1103; i++) R5086[i] = (char *(*)()) F1113_6600;}
}

char *(*R5089[1103])();
void R5089_init () {
	R5089[0] = (char *(*)()) F1113_6539;
	R5089[4] = (char *(*)()) F1117_6707;
	{long i; for (i = 1101; i < 1103; i++) R5089[i] = (char *(*)()) F2214_22551;}
}

char *(*R5090[1103])();
void R5090_init () {
	R5090[0] = (char *(*)()) F1110_6408;
	R5090[4] = (char *(*)()) F1110_6408;
	{long i; for (i = 1101; i < 1103; i++) R5090[i] = (char *(*)()) F2214_22552;}
}

char *(*R5101[1103])();
void R5101_init () {
	R5101[0] = (char *(*)()) F1113_6550;
	R5101[4] = (char *(*)()) F1117_6718;
	{long i; for (i = 1101; i < 1103; i++) R5101[i] = (char *(*)()) F2214_22474;}
}

char *(*R5109[1103])();
void R5109_init () {
	R5109[0] = (char *(*)()) F1113_6533;
	{long i; for (i = 1101; i < 1103; i++) R5109[i] = (char *(*)()) F2214_22498;}
}

char *(*R5110[1103])();
void R5110_init () {
	R5110[0] = (char *(*)()) F1113_6534;
	{long i; for (i = 1101; i < 1103; i++) R5110[i] = (char *(*)()) F2214_22499;}
}

char *(*R5111[1103])();
void R5111_init () {
	R5111[0] = (char *(*)()) F1113_6535;
	{long i; for (i = 1101; i < 1103; i++) R5111[i] = (char *(*)()) F2214_22547;}
}

char *(*R5112[1103])();
void R5112_init () {
	R5112[0] = (char *(*)()) F1113_6536;
	{long i; for (i = 1101; i < 1103; i++) R5112[i] = (char *(*)()) F2214_22548;}
}

char *(*R5114[1103])();
void R5114_init () {
	R5114[0] = (char *(*)()) F1113_6572;
	{long i; for (i = 1101; i < 1103; i++) R5114[i] = (char *(*)()) F2214_22502;}
}

char *(*R5115[1103])();
void R5115_init () {
	R5115[0] = (char *(*)()) F1113_6573;
	{long i; for (i = 1101; i < 1103; i++) R5115[i] = (char *(*)()) F2214_22500;}
}


#ifdef __cplusplus
}
#endif
