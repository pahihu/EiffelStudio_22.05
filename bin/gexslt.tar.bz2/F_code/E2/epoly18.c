#include "epoly18.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5117[1103])();
void R5117_init () {
	R5117[0] = (char *(*)()) F1113_6575;
	{long i; for (i = 1101; i < 1103; i++) R5117[i] = (char *(*)()) F2214_22501;}
}

char *(*R5118[1103])();
void R5118_init () {
	R5118[0] = (char *(*)()) F1113_6580;
	R5118[4] = (char *(*)()) F1117_6748;
	{long i; for (i = 1101; i < 1103; i++) R5118[i] = (char *(*)()) F2214_22545;}
}

char *(*R5119[1103])();
void R5119_init () {
	R5119[0] = (char *(*)()) F1113_6583;
	R5119[4] = (char *(*)()) F1117_6751;
	{long i; for (i = 1101; i < 1103; i++) R5119[i] = (char *(*)()) F1113_6583;}
}

char *(*R5129[1103])();
void R5129_init () {
	R5129[0] = (char *(*)()) F1113_6521;
	{long i; for (i = 1101; i < 1103; i++) R5129[i] = (char *(*)()) F2214_22435;}
}

char *(*R5131[1104])();
void R5131_init () {
	{long i; for (i = 0; i < 2; i++) R5131[i] = (char *(*)()) F1111_6451;}
	{long i; for (i = 1102; i < 1104; i++) R5131[i] = (char *(*)()) F2214_22446;}
}

char *(*R5133[1104])();
void R5133_init () {
	{long i; for (i = 0; i < 2; i++) R5133[i] = (char *(*)()) F1111_6454;}
	{long i; for (i = 1102; i < 1104; i++) R5133[i] = (char *(*)()) F2214_22441;}
}

char *(*R5138[1104])();
void R5138_init () {
	{long i; for (i = 0; i < 2; i++) R5138[i] = (char *(*)()) F1111_6466;}
	{long i; for (i = 1102; i < 1104; i++) R5138[i] = (char *(*)()) F2214_22464;}
}

char *(*R5143[1104])();
void R5143_init () {
	R5143[0] = (char *(*)()) F1112_6500;
	R5143[1] = (char *(*)()) F1113_6570;
	{long i; for (i = 1102; i < 1104; i++) R5143[i] = (char *(*)()) F2214_22442;}
}

char *(*R5151[1104])();
void R5151_init () {
	R5151[0] = (char *(*)()) F1112_6511;
	R5151[1] = (char *(*)()) F1111_6490;
	{long i; for (i = 1102; i < 1104; i++) R5151[i] = (char *(*)()) F1111_6490;}
}

char *(*R5165[1103])();
void R5165_init () {
	R5165[0] = (char *(*)()) F1113_6527;
	{long i; for (i = 1101; i < 1103; i++) R5165[i] = (char *(*)()) F2214_22495;}
}


#ifdef __cplusplus
}
#endif
