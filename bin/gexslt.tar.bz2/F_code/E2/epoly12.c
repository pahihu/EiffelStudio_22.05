#include "epoly12.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R3330[5])();
void R3330_init () {
	{long i; for (i = 0; i < 2; i++) R3330[i] = (char *(*)()) F542_3729;}
	{long i; for (i = 2; i < 4; i++) R3330[i] = (char *(*)()) F543_3729;}
	R3330[4] = (char *(*)()) F552_3729;
}

char *(*R3333[5])();
void R3333_init () {
	{long i; for (i = 0; i < 2; i++) R3333[i] = (char *(*)()) F542_3734;}
	{long i; for (i = 2; i < 4; i++) R3333[i] = (char *(*)()) F543_3734;}
	R3333[4] = (char *(*)()) F552_3734;
}

char *(*R3336[5])();
void R3336_init () {
	{long i; for (i = 0; i < 2; i++) R3336[i] = (char *(*)()) F542_3715;}
	{long i; for (i = 2; i < 4; i++) R3336[i] = (char *(*)()) F543_3715;}
	R3336[4] = (char *(*)()) F552_3715;
}

char *(*R3363[1447])();
void R3363_init () {
	R3363[0] = (char *(*)()) F769_3893_3363_2;
	R3363[344] = (char *(*)()) F1111_6473_3363_2;
	{long i; for (i = 1445; i < 1447; i++) R3363[i] = (char *(*)()) F2214_22457_3363_2;}
}
static EIF_BOOLEAN F769_3893_3363_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F769_3893(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1111_6473_3363_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1111_6473(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F2214_22457_3363_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F2214_22457(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R3368[1447])();
void R3368_init () {
	R3368[0] = (char *(*)()) F617_3802;
	R3368[69] = (char *(*)()) F618_3802;
	R3368[111] = (char *(*)()) F616_3802;
	R3368[112] = (char *(*)()) F617_3802;
	R3368[113] = (char *(*)()) F620_3802;
	R3368[114] = (char *(*)()) F618_3802;
	R3368[115] = (char *(*)()) F621_3802;
	R3368[116] = (char *(*)()) F622_3802;
	R3368[117] = (char *(*)()) F623_3802;
	R3368[118] = (char *(*)()) F624_3802;
	R3368[119] = (char *(*)()) F619_3802;
	R3368[120] = (char *(*)()) F625_3802;
	R3368[121] = (char *(*)()) F626_3802;
	R3368[122] = (char *(*)()) F627_3802;
	R3368[123] = (char *(*)()) F628_3802;
	R3368[124] = (char *(*)()) F616_3802;
	R3368[125] = (char *(*)()) F617_3802;
	R3368[126] = (char *(*)()) F621_3802;
	R3368[127] = (char *(*)()) F618_3802;
	R3368[128] = (char *(*)()) F622_3802;
	R3368[129] = (char *(*)()) F625_3802;
	R3368[130] = (char *(*)()) F620_3802;
	{long i; for (i = 207; i < 209; i++) R3368[i] = (char *(*)()) F616_3802;}
	{long i; for (i = 209; i < 211; i++) R3368[i] = (char *(*)()) F617_3802;}
	R3368[211] = (char *(*)()) F626_3802;
	R3368[212] = (char *(*)()) F616_3802;
	R3368[213] = (char *(*)()) F617_3802;
	R3368[214] = (char *(*)()) F616_3802;
	R3368[344] = (char *(*)()) F618_3802;
	R3368[348] = (char *(*)()) F619_3802;
	R3368[482] = (char *(*)()) F618_3802;
	{long i; for (i = 782; i < 784; i++) R3368[i] = (char *(*)()) F618_3802;}
	R3368[787] = (char *(*)()) F618_3802;
	{long i; for (i = 789; i < 791; i++) R3368[i] = (char *(*)()) F618_3802;}
	{long i; for (i = 1445; i < 1447; i++) R3368[i] = (char *(*)()) F618_3802;}
}

char *(*R3400[1103])();
void R3400_init () {
	R3400[0] = (char *(*)()) F1111_6461_3400_33;
	{long i; for (i = 1101; i < 1103; i++) R3400[i] = (char *(*)()) F2214_22451_3400_33;}
}
static EIF_INTEGER_32 F1111_6461_3400_33 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1111_6461(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_INTEGER_32 F2214_22451_3400_33 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F2214_22451(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R3401[1336])();
void R3401_init () {
	R3401[0] = (char *(*)()) F880_4371_3401_5;
	R3401[1] = (char *(*)()) F881_4371_3401_5;
	R3401[2] = (char *(*)()) F882_4371_3401_5;
	R3401[3] = (char *(*)()) F883_4371_3401_5;
	R3401[4] = (char *(*)()) F884_4371_3401_5;
	R3401[5] = (char *(*)()) F885_4371_3401_5;
	R3401[6] = (char *(*)()) F886_4371_3401_5;
	R3401[7] = (char *(*)()) F887_4371_3401_5;
	R3401[8] = (char *(*)()) F888_4371_3401_5;
	R3401[9] = (char *(*)()) F889_4371_3401_5;
	R3401[10] = (char *(*)()) F890_4371_3401_5;
	R3401[11] = (char *(*)()) F891_4371_3401_5;
	R3401[12] = (char *(*)()) F892_4371_3401_5;
	R3401[13] = (char *(*)()) F880_4371_3401_5;
	R3401[14] = (char *(*)()) F881_4371_3401_5;
	R3401[15] = (char *(*)()) F884_4371_3401_5;
	R3401[16] = (char *(*)()) F883_4371_3401_5;
	R3401[17] = (char *(*)()) F885_4371_3401_5;
	R3401[18] = (char *(*)()) F889_4371_3401_5;
	R3401[19] = (char *(*)()) F882_4371_3401_5;
	R3401[233] = (char *(*)()) F1113_6517_3401_5;
	R3401[237] = (char *(*)()) F1117_6686_3401_5;
	{long i; for (i = 1334; i < 1336; i++) R3401[i] = (char *(*)()) F2214_22436_3401_5;}
}
static EIF_REFERENCE F880_4371_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F880_4371(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F881_4371_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F881_4371(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F882_4371_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F882_4371(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1044, 0x00).id, 1044, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F883_4371_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F883_4371(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F884_4371_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F884_4371(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1068, 0x00).id, 1068, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F885_4371_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F885_4371(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F886_4371_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F886_4371(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1050, 0x00).id, 1050, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F887_4371_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F887_4371(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1053, 0x00).id, 1053, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F888_4371_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F888_4371(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F889_4371_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F889_4371(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1047, 0x00).id, 1047, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F890_4371_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F890_4371(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1101, 0x00).id, 1101, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F891_4371_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F891_4371(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1056, 0x00).id, 1056, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F892_4371_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F892_4371(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1059, 0x00).id, 1059, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1113_6517_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1113_6517(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1117_6686_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1117_6686(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F2214_22436_3401_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F2214_22436(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R3404[1336])();
void R3404_init () {
	R3404[0] = (char *(*)()) F880_4390_3404_13;
	R3404[1] = (char *(*)()) F881_4390_3404_13;
	R3404[2] = (char *(*)()) F882_4390_3404_13;
	R3404[3] = (char *(*)()) F883_4390_3404_13;
	R3404[4] = (char *(*)()) F884_4390_3404_13;
	R3404[5] = (char *(*)()) F885_4390_3404_13;
	R3404[6] = (char *(*)()) F886_4390_3404_13;
	R3404[7] = (char *(*)()) F887_4390_3404_13;
	R3404[8] = (char *(*)()) F888_4390_3404_13;
	R3404[9] = (char *(*)()) F889_4390_3404_13;
	R3404[10] = (char *(*)()) F890_4390_3404_13;
	R3404[11] = (char *(*)()) F891_4390_3404_13;
	R3404[12] = (char *(*)()) F892_4390_3404_13;
	R3404[13] = (char *(*)()) F880_4390_3404_13;
	R3404[14] = (char *(*)()) F881_4390_3404_13;
	R3404[15] = (char *(*)()) F884_4390_3404_13;
	R3404[16] = (char *(*)()) F883_4390_3404_13;
	R3404[17] = (char *(*)()) F885_4390_3404_13;
	R3404[18] = (char *(*)()) F889_4390_3404_13;
	R3404[19] = (char *(*)()) F882_4390_3404_13;
	R3404[96] = (char *(*)()) F976_4734;
	R3404[97] = (char *(*)()) F977_4734_3404_13;
	R3404[98] = (char *(*)()) F978_4734_3404_13;
	R3404[99] = (char *(*)()) F979_4734_3404_13;
	R3404[100] = (char *(*)()) F980_4734_3404_13;
	R3404[101] = (char *(*)()) F976_4734;
	R3404[102] = (char *(*)()) F978_4734_3404_13;
	R3404[103] = (char *(*)()) F976_4734;
	R3404[233] = (char *(*)()) F1113_6538_3404_13;
	{long i; for (i = 1334; i < 1336; i++) R3404[i] = (char *(*)()) F2214_22471_3404_13;}
}
static void F880_4390_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F880_4390(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F881_4390_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F881_4390(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F882_4390_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F882_4390(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F883_4390_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F883_4390(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F884_4390_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F884_4390(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F885_4390_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F885_4390(Current, *(EIF_INTEGER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F886_4390_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F886_4390(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F887_4390_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F887_4390(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F888_4390_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F888_4390(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F889_4390_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F889_4390(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F890_4390_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F890_4390(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F891_4390_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F891_4390(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F892_4390_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F892_4390(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F977_4734_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F977_4734(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F978_4734_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F978_4734(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F979_4734_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F979_4734(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F980_4734_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F980_4734(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1113_6538_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1113_6538(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F2214_22471_3404_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F2214_22471(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y3406_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype32[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype33[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype34[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype35[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype36[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype37[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype38[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype39[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype40[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype41[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype42[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype43[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype44[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype45[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype46[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype47[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype48[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype49[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype50[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype51[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype52[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype53[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype54[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype55[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype56[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype57[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype58[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype59[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype60[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype61[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype62[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype63[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype64[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype65[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype66[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype67[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype68[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype69[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype70[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype71[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype72[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype73[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype74[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype75[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype76[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype77[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype78[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype79[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype80[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype81[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype82[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype83[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype84[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype85[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype86[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype87[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype88[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype89[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype90[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype91[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype92[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype93[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype94[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype95[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype96[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype97[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype98[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype99[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype100[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype101[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype102[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype103[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype104[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype105[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype106[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype107[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype108[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype109[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype110[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype111[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype112[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype113[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype114[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype115[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype116[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype117[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype118[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype119[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype120[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype121[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype122[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype123[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype124[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype125[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype126[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype127[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype128[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype129[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype130[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype131[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype132[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype133[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype134[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype135[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype136[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype137[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype138[] = {0xFF01,1107,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype139[] = {0xFF01,1107,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype140[] = {0xFF01,1112,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype141[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype142[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype143[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype144[] = {1035,0xFFFF};
static EIF_TYPE_INDEX Y3406_pgtype145[] = {1035,0xFFFF};
EIF_TYPE_INDEX *Y3406_gen_type [1521];
EIF_TYPE_INDEX Y3406 [1521];
void Y3406_init (void)
{
	egc_routines_types [3406] = Y3406;
	egc_routines_gen_types [3406] = Y3406_gen_type;
	egc_routines_offset [3406] = 694;
	Y3406_gen_type [0] = Y3406_pgtype0;
	Y3406_gen_type [1] = Y3406_pgtype1;
	Y3406_gen_type [2] = Y3406_pgtype2;
	Y3406_gen_type [3] = Y3406_pgtype3;
	Y3406_gen_type [4] = Y3406_pgtype4;
	Y3406_gen_type [5] = Y3406_pgtype5;
	Y3406_gen_type [6] = Y3406_pgtype6;
	Y3406_gen_type [7] = Y3406_pgtype7;
	Y3406_gen_type [8] = Y3406_pgtype8;
	Y3406_gen_type [9] = Y3406_pgtype9;
	Y3406_gen_type [10] = Y3406_pgtype10;
	Y3406_gen_type [11] = Y3406_pgtype11;
	Y3406_gen_type [12] = Y3406_pgtype12;
	Y3406_gen_type [13] = Y3406_pgtype13;
	Y3406_gen_type [14] = Y3406_pgtype14;
	Y3406_gen_type [15] = Y3406_pgtype15;
	Y3406_gen_type [16] = Y3406_pgtype16;
	Y3406_gen_type [17] = Y3406_pgtype17;
	Y3406_gen_type [18] = Y3406_pgtype18;
	Y3406_gen_type [19] = Y3406_pgtype19;
	Y3406_gen_type [20] = Y3406_pgtype20;
	Y3406_gen_type [21] = Y3406_pgtype21;
	Y3406_gen_type [22] = Y3406_pgtype22;
	Y3406_gen_type [23] = Y3406_pgtype23;
	Y3406_gen_type [24] = Y3406_pgtype24;
	Y3406_gen_type [25] = Y3406_pgtype25;
	Y3406_gen_type [26] = Y3406_pgtype26;
	Y3406_gen_type [27] = Y3406_pgtype27;
	Y3406_gen_type [28] = Y3406_pgtype28;
	Y3406_gen_type [29] = Y3406_pgtype29;
	Y3406_gen_type [30] = Y3406_pgtype30;
	Y3406_gen_type [31] = Y3406_pgtype31;
	Y3406_gen_type [171] = Y3406_pgtype32;
	Y3406_gen_type [172] = Y3406_pgtype33;
	Y3406_gen_type [173] = Y3406_pgtype34;
	Y3406_gen_type [174] = Y3406_pgtype35;
	Y3406_gen_type [175] = Y3406_pgtype36;
	Y3406_gen_type [176] = Y3406_pgtype37;
	Y3406_gen_type [177] = Y3406_pgtype38;
	Y3406_gen_type [178] = Y3406_pgtype39;
	Y3406_gen_type [179] = Y3406_pgtype40;
	Y3406_gen_type [180] = Y3406_pgtype41;
	Y3406_gen_type [181] = Y3406_pgtype42;
	Y3406_gen_type [182] = Y3406_pgtype43;
	Y3406_gen_type [183] = Y3406_pgtype44;
	Y3406_gen_type [184] = Y3406_pgtype45;
	Y3406_gen_type [185] = Y3406_pgtype46;
	Y3406_gen_type [186] = Y3406_pgtype47;
	Y3406_gen_type [187] = Y3406_pgtype48;
	Y3406_gen_type [188] = Y3406_pgtype49;
	Y3406_gen_type [189] = Y3406_pgtype50;
	Y3406_gen_type [190] = Y3406_pgtype51;
	Y3406_gen_type [191] = Y3406_pgtype52;
	Y3406_gen_type [192] = Y3406_pgtype53;
	Y3406_gen_type [193] = Y3406_pgtype54;
	Y3406_gen_type [194] = Y3406_pgtype55;
	Y3406_gen_type [195] = Y3406_pgtype56;
	Y3406_gen_type [196] = Y3406_pgtype57;
	Y3406_gen_type [197] = Y3406_pgtype58;
	Y3406_gen_type [198] = Y3406_pgtype59;
	Y3406_gen_type [199] = Y3406_pgtype60;
	Y3406_gen_type [200] = Y3406_pgtype61;
	Y3406_gen_type [201] = Y3406_pgtype62;
	Y3406_gen_type [202] = Y3406_pgtype63;
	Y3406_gen_type [203] = Y3406_pgtype64;
	Y3406_gen_type [204] = Y3406_pgtype65;
	Y3406_gen_type [205] = Y3406_pgtype66;
	Y3406_gen_type [206] = Y3406_pgtype67;
	Y3406_gen_type [207] = Y3406_pgtype68;
	Y3406_gen_type [208] = Y3406_pgtype69;
	Y3406_gen_type [209] = Y3406_pgtype70;
	Y3406_gen_type [210] = Y3406_pgtype71;
	Y3406_gen_type [211] = Y3406_pgtype72;
	Y3406_gen_type [212] = Y3406_pgtype73;
	Y3406_gen_type [213] = Y3406_pgtype74;
	Y3406_gen_type [214] = Y3406_pgtype75;
	Y3406_gen_type [215] = Y3406_pgtype76;
	Y3406_gen_type [216] = Y3406_pgtype77;
	Y3406_gen_type [217] = Y3406_pgtype78;
	Y3406_gen_type [218] = Y3406_pgtype79;
	Y3406_gen_type [219] = Y3406_pgtype80;
	Y3406_gen_type [220] = Y3406_pgtype81;
	Y3406_gen_type [221] = Y3406_pgtype82;
	Y3406_gen_type [222] = Y3406_pgtype83;
	Y3406_gen_type [223] = Y3406_pgtype84;
	Y3406_gen_type [224] = Y3406_pgtype85;
	Y3406_gen_type [225] = Y3406_pgtype86;
	Y3406_gen_type [226] = Y3406_pgtype87;
	Y3406_gen_type [227] = Y3406_pgtype88;
	Y3406_gen_type [228] = Y3406_pgtype89;
	Y3406_gen_type [229] = Y3406_pgtype90;
	Y3406_gen_type [230] = Y3406_pgtype91;
	Y3406_gen_type [231] = Y3406_pgtype92;
	Y3406_gen_type [232] = Y3406_pgtype93;
	Y3406_gen_type [233] = Y3406_pgtype94;
	Y3406_gen_type [234] = Y3406_pgtype95;
	Y3406_gen_type [235] = Y3406_pgtype96;
	Y3406_gen_type [236] = Y3406_pgtype97;
	Y3406_gen_type [237] = Y3406_pgtype98;
	Y3406_gen_type [238] = Y3406_pgtype99;
	Y3406_gen_type [239] = Y3406_pgtype100;
	Y3406_gen_type [240] = Y3406_pgtype101;
	Y3406_gen_type [241] = Y3406_pgtype102;
	Y3406_gen_type [242] = Y3406_pgtype103;
	Y3406_gen_type [243] = Y3406_pgtype104;
	Y3406_gen_type [244] = Y3406_pgtype105;
	Y3406_gen_type [245] = Y3406_pgtype106;
	Y3406_gen_type [246] = Y3406_pgtype107;
	Y3406_gen_type [247] = Y3406_pgtype108;
	Y3406_gen_type [248] = Y3406_pgtype109;
	Y3406_gen_type [249] = Y3406_pgtype110;
	Y3406_gen_type [250] = Y3406_pgtype111;
	Y3406_gen_type [251] = Y3406_pgtype112;
	Y3406_gen_type [252] = Y3406_pgtype113;
	Y3406_gen_type [253] = Y3406_pgtype114;
	Y3406_gen_type [254] = Y3406_pgtype115;
	Y3406_gen_type [255] = Y3406_pgtype116;
	Y3406_gen_type [256] = Y3406_pgtype117;
	Y3406_gen_type [257] = Y3406_pgtype118;
	Y3406_gen_type [258] = Y3406_pgtype119;
	Y3406_gen_type [268] = Y3406_pgtype120;
	Y3406_gen_type [269] = Y3406_pgtype121;
	Y3406_gen_type [270] = Y3406_pgtype122;
	Y3406_gen_type [271] = Y3406_pgtype123;
	Y3406_gen_type [272] = Y3406_pgtype124;
	Y3406_gen_type [273] = Y3406_pgtype125;
	Y3406_gen_type [274] = Y3406_pgtype126;
	Y3406_gen_type [275] = Y3406_pgtype127;
	Y3406_gen_type [276] = Y3406_pgtype128;
	Y3406_gen_type [277] = Y3406_pgtype129;
	Y3406_gen_type [278] = Y3406_pgtype130;
	Y3406_gen_type [279] = Y3406_pgtype131;
	Y3406_gen_type [280] = Y3406_pgtype132;
	Y3406_gen_type [281] = Y3406_pgtype133;
	Y3406_gen_type [282] = Y3406_pgtype134;
	Y3406_gen_type [283] = Y3406_pgtype135;
	Y3406_gen_type [284] = Y3406_pgtype136;
	Y3406_gen_type [285] = Y3406_pgtype137;
	Y3406_gen_type [286] = Y3406_pgtype138;
	Y3406_gen_type [287] = Y3406_pgtype139;
	Y3406_gen_type [288] = Y3406_pgtype140;
	Y3406_gen_type [418] = Y3406_pgtype141;
	Y3406_gen_type [419] = Y3406_pgtype142;
	Y3406_gen_type [422] = Y3406_pgtype143;
	Y3406_gen_type [1519] = Y3406_pgtype144;
	Y3406_gen_type [1520] = Y3406_pgtype145;
	{long i; for (i = 171; i < 259; i++) Y3406[i] = 1035;};
	{long i; for (i = 268; i < 281; i++) Y3406[i] = 1035;};
	{long i; for (i = 286; i < 288; i++) Y3406[i] = 1107;};
	Y3406[288] = 1112;
	{long i; for (i = 418; i < 420; i++) Y3406[i] = 1035;};
	Y3406[422] = 1035;
	{long i; for (i = 1519; i < 1521; i++) Y3406[i] = 1035;};
}

char *(*R3428[1378])();
void R3428_init () {
	R3428[0] = (char *(*)()) F837_3956;
	R3428[42] = (char *(*)()) F880_4378;
	R3428[43] = (char *(*)()) F881_4378;
	R3428[44] = (char *(*)()) F882_4378;
	R3428[45] = (char *(*)()) F883_4378;
	R3428[46] = (char *(*)()) F884_4378;
	R3428[47] = (char *(*)()) F885_4378;
	R3428[48] = (char *(*)()) F886_4378;
	R3428[49] = (char *(*)()) F887_4378;
	R3428[50] = (char *(*)()) F888_4378;
	R3428[51] = (char *(*)()) F889_4378;
	R3428[52] = (char *(*)()) F890_4378;
	R3428[53] = (char *(*)()) F891_4378;
	R3428[54] = (char *(*)()) F892_4378;
	R3428[55] = (char *(*)()) F880_4378;
	R3428[56] = (char *(*)()) F881_4378;
	R3428[57] = (char *(*)()) F884_4378;
	R3428[58] = (char *(*)()) F883_4378;
	R3428[59] = (char *(*)()) F885_4378;
	R3428[60] = (char *(*)()) F889_4378;
	R3428[61] = (char *(*)()) F882_4378;
	R3428[138] = (char *(*)()) F976_4706;
	R3428[139] = (char *(*)()) F977_4706;
	R3428[140] = (char *(*)()) F978_4706;
	R3428[141] = (char *(*)()) F979_4706;
	R3428[142] = (char *(*)()) F980_4706;
	R3428[143] = (char *(*)()) F976_4706;
	R3428[144] = (char *(*)()) F978_4706;
	R3428[145] = (char *(*)()) F976_4706;
	R3428[275] = (char *(*)()) F1111_6460;
	R3428[279] = (char *(*)()) F1115_6625;
	R3428[413] = (char *(*)()) F1251_10557;
	{long i; for (i = 713; i < 715; i++) R3428[i] = (char *(*)()) F837_3956;}
	R3428[718] = (char *(*)()) F837_3956;
	{long i; for (i = 720; i < 722; i++) R3428[i] = (char *(*)()) F837_3956;}
	{long i; for (i = 1376; i < 1378; i++) R3428[i] = (char *(*)()) F2214_22452;}
}

char *(*R3431[1336])();
void R3431_init () {
	R3431[0] = (char *(*)()) F880_4379;
	R3431[1] = (char *(*)()) F881_4379;
	R3431[2] = (char *(*)()) F882_4379;
	R3431[3] = (char *(*)()) F883_4379;
	R3431[4] = (char *(*)()) F884_4379;
	R3431[5] = (char *(*)()) F885_4379;
	R3431[6] = (char *(*)()) F886_4379;
	R3431[7] = (char *(*)()) F887_4379;
	R3431[8] = (char *(*)()) F888_4379;
	R3431[9] = (char *(*)()) F889_4379;
	R3431[10] = (char *(*)()) F890_4379;
	R3431[11] = (char *(*)()) F891_4379;
	R3431[12] = (char *(*)()) F892_4379;
	R3431[13] = (char *(*)()) F880_4379;
	R3431[14] = (char *(*)()) F881_4379;
	R3431[15] = (char *(*)()) F884_4379;
	R3431[16] = (char *(*)()) F883_4379;
	R3431[17] = (char *(*)()) F885_4379;
	R3431[18] = (char *(*)()) F889_4379;
	R3431[19] = (char *(*)()) F882_4379;
	R3431[233] = (char *(*)()) F1111_6459;
	R3431[237] = (char *(*)()) F1115_6624;
	{long i; for (i = 1334; i < 1336; i++) R3431[i] = (char *(*)()) F2214_22454;}
}


#ifdef __cplusplus
}
#endif
