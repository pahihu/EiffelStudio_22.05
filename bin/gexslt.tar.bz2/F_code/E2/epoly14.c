#include "epoly14.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R3644[13])();
void R3644_init () {
	R3644[0] = (char *(*)()) F853_4278;
	R3644[1] = (char *(*)()) F854_4278_3644_31;
	R3644[2] = (char *(*)()) F855_4278_3644_31;
	R3644[3] = (char *(*)()) F856_4278_3644_31;
	R3644[4] = (char *(*)()) F857_4278_3644_31;
	R3644[5] = (char *(*)()) F858_4278_3644_31;
	R3644[6] = (char *(*)()) F859_4278_3644_31;
	R3644[7] = (char *(*)()) F860_4278_3644_31;
	R3644[8] = (char *(*)()) F861_4278_3644_31;
	R3644[9] = (char *(*)()) F862_4278_3644_31;
	R3644[10] = (char *(*)()) F863_4278_3644_31;
	R3644[11] = (char *(*)()) F864_4278_3644_31;
	R3644[12] = (char *(*)()) F865_4278_3644_31;
}
static void F854_4278_3644_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F854_4278(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F855_4278_3644_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F855_4278(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F856_4278_3644_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F856_4278(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F857_4278_3644_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F857_4278(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F858_4278_3644_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F858_4278(Current, *(EIF_INTEGER_8 *)arg1, arg2);
}
static void F859_4278_3644_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F859_4278(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F860_4278_3644_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F860_4278(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F861_4278_3644_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F861_4278(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F862_4278_3644_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F862_4278(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F863_4278_3644_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F863_4278(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F864_4278_3644_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F864_4278(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F865_4278_3644_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F865_4278(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3653[13])();
void R3653_init () {
	R3653[0] = (char *(*)()) F853_4293;
	R3653[1] = (char *(*)()) F854_4293;
	R3653[2] = (char *(*)()) F855_4293;
	R3653[3] = (char *(*)()) F856_4293;
	R3653[4] = (char *(*)()) F857_4293;
	R3653[5] = (char *(*)()) F858_4293;
	R3653[6] = (char *(*)()) F859_4293;
	R3653[7] = (char *(*)()) F860_4293;
	R3653[8] = (char *(*)()) F861_4293;
	R3653[9] = (char *(*)()) F862_4293;
	R3653[10] = (char *(*)()) F863_4293;
	R3653[11] = (char *(*)()) F864_4293;
	R3653[12] = (char *(*)()) F865_4293;
}

char *(*R3654[13])();
void R3654_init () {
	R3654[0] = (char *(*)()) F853_4295;
	R3654[1] = (char *(*)()) F854_4295_3654_31;
	R3654[2] = (char *(*)()) F855_4295_3654_31;
	R3654[3] = (char *(*)()) F856_4295_3654_31;
	R3654[4] = (char *(*)()) F857_4295_3654_31;
	R3654[5] = (char *(*)()) F858_4295_3654_31;
	R3654[6] = (char *(*)()) F859_4295_3654_31;
	R3654[7] = (char *(*)()) F860_4295_3654_31;
	R3654[8] = (char *(*)()) F861_4295_3654_31;
	R3654[9] = (char *(*)()) F862_4295_3654_31;
	R3654[10] = (char *(*)()) F863_4295_3654_31;
	R3654[11] = (char *(*)()) F864_4295_3654_31;
	R3654[12] = (char *(*)()) F865_4295_3654_31;
}
static void F854_4295_3654_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F854_4295(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F855_4295_3654_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F855_4295(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F856_4295_3654_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F856_4295(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F857_4295_3654_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F857_4295(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F858_4295_3654_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F858_4295(Current, *(EIF_INTEGER_8 *)arg1, arg2);
}
static void F859_4295_3654_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F859_4295(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F860_4295_3654_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F860_4295(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F861_4295_3654_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F861_4295(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F862_4295_3654_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F862_4295(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F863_4295_3654_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F863_4295(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F864_4295_3654_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F864_4295(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F865_4295_3654_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F865_4295(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3655[13])();
void R3655_init () {
	R3655[0] = (char *(*)()) F853_4296;
	R3655[1] = (char *(*)()) F854_4296_3655_31;
	R3655[2] = (char *(*)()) F855_4296_3655_31;
	R3655[3] = (char *(*)()) F856_4296_3655_31;
	R3655[4] = (char *(*)()) F857_4296_3655_31;
	R3655[5] = (char *(*)()) F858_4296_3655_31;
	R3655[6] = (char *(*)()) F859_4296_3655_31;
	R3655[7] = (char *(*)()) F860_4296_3655_31;
	R3655[8] = (char *(*)()) F861_4296_3655_31;
	R3655[9] = (char *(*)()) F862_4296_3655_31;
	R3655[10] = (char *(*)()) F863_4296_3655_31;
	R3655[11] = (char *(*)()) F864_4296_3655_31;
	R3655[12] = (char *(*)()) F865_4296_3655_31;
}
static void F854_4296_3655_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F854_4296(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F855_4296_3655_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F855_4296(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F856_4296_3655_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F856_4296(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F857_4296_3655_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F857_4296(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F858_4296_3655_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F858_4296(Current, *(EIF_INTEGER_8 *)arg1, arg2);
}
static void F859_4296_3655_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F859_4296(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F860_4296_3655_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F860_4296(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F861_4296_3655_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F861_4296(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F862_4296_3655_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F862_4296(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F863_4296_3655_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F863_4296(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F864_4296_3655_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F864_4296(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F865_4296_3655_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F865_4296(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3656[13])();
void R3656_init () {
	R3656[0] = (char *(*)()) F853_4297;
	R3656[1] = (char *(*)()) F854_4297_3656_4;
	R3656[2] = (char *(*)()) F855_4297_3656_4;
	R3656[3] = (char *(*)()) F856_4297_3656_4;
	R3656[4] = (char *(*)()) F857_4297_3656_4;
	R3656[5] = (char *(*)()) F858_4297_3656_4;
	R3656[6] = (char *(*)()) F859_4297_3656_4;
	R3656[7] = (char *(*)()) F860_4297_3656_4;
	R3656[8] = (char *(*)()) F861_4297_3656_4;
	R3656[9] = (char *(*)()) F862_4297_3656_4;
	R3656[10] = (char *(*)()) F863_4297_3656_4;
	R3656[11] = (char *(*)()) F864_4297_3656_4;
	R3656[12] = (char *(*)()) F865_4297_3656_4;
}
static void F854_4297_3656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F854_4297(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F855_4297_3656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F855_4297(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F856_4297_3656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F856_4297(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F857_4297_3656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_4297(Current, *(EIF_BOOLEAN *)arg1);
}
static void F858_4297_3656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F858_4297(Current, *(EIF_INTEGER_8 *)arg1);
}
static void F859_4297_3656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F859_4297(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F860_4297_3656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F860_4297(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F861_4297_3656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F861_4297(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F862_4297_3656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F862_4297(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F863_4297_3656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F863_4297(Current, *(EIF_POINTER *)arg1);
}
static void F864_4297_3656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F864_4297(Current, *(EIF_REAL_32 *)arg1);
}
static void F865_4297_3656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F865_4297(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R3658[13])();
void R3658_init () {
	R3658[0] = (char *(*)()) F853_4299;
	R3658[1] = (char *(*)()) F854_4299_3658_57;
	R3658[2] = (char *(*)()) F855_4299_3658_57;
	R3658[3] = (char *(*)()) F856_4299_3658_57;
	R3658[4] = (char *(*)()) F857_4299_3658_57;
	R3658[5] = (char *(*)()) F858_4299_3658_57;
	R3658[6] = (char *(*)()) F859_4299_3658_57;
	R3658[7] = (char *(*)()) F860_4299_3658_57;
	R3658[8] = (char *(*)()) F861_4299_3658_57;
	R3658[9] = (char *(*)()) F862_4299_3658_57;
	R3658[10] = (char *(*)()) F863_4299_3658_57;
	R3658[11] = (char *(*)()) F864_4299_3658_57;
	R3658[12] = (char *(*)()) F865_4299_3658_57;
}
static void F854_4299_3658_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F854_4299(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F855_4299_3658_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F855_4299(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F856_4299_3658_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F856_4299(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F857_4299_3658_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F857_4299(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F858_4299_3658_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F858_4299(Current, *(EIF_INTEGER_8 *)arg1, arg2, arg3);
}
static void F859_4299_3658_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F859_4299(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F860_4299_3658_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F860_4299(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F861_4299_3658_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F861_4299(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F862_4299_3658_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F862_4299(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F863_4299_3658_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F863_4299(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F864_4299_3658_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F864_4299(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F865_4299_3658_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F865_4299(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R3661[13])();
void R3661_init () {
	R3661[0] = (char *(*)()) F853_4302;
	R3661[1] = (char *(*)()) F854_4302;
	R3661[2] = (char *(*)()) F855_4302;
	R3661[3] = (char *(*)()) F856_4302;
	R3661[4] = (char *(*)()) F857_4302;
	R3661[5] = (char *(*)()) F858_4302;
	R3661[6] = (char *(*)()) F859_4302;
	R3661[7] = (char *(*)()) F860_4302;
	R3661[8] = (char *(*)()) F861_4302;
	R3661[9] = (char *(*)()) F862_4302;
	R3661[10] = (char *(*)()) F863_4302;
	R3661[11] = (char *(*)()) F864_4302;
	R3661[12] = (char *(*)()) F865_4302;
}

char *(*R3662[13])();
void R3662_init () {
	R3662[0] = (char *(*)()) F853_4303;
	R3662[1] = (char *(*)()) F854_4303;
	R3662[2] = (char *(*)()) F855_4303;
	R3662[3] = (char *(*)()) F856_4303;
	R3662[4] = (char *(*)()) F857_4303;
	R3662[5] = (char *(*)()) F858_4303;
	R3662[6] = (char *(*)()) F859_4303;
	R3662[7] = (char *(*)()) F860_4303;
	R3662[8] = (char *(*)()) F861_4303;
	R3662[9] = (char *(*)()) F862_4303;
	R3662[10] = (char *(*)()) F863_4303;
	R3662[11] = (char *(*)()) F864_4303;
	R3662[12] = (char *(*)()) F865_4303;
}

char *(*R3663[13])();
void R3663_init () {
	R3663[0] = (char *(*)()) F853_4304;
	R3663[1] = (char *(*)()) F854_4304;
	R3663[2] = (char *(*)()) F855_4304;
	R3663[3] = (char *(*)()) F856_4304;
	R3663[4] = (char *(*)()) F857_4304;
	R3663[5] = (char *(*)()) F858_4304;
	R3663[6] = (char *(*)()) F859_4304;
	R3663[7] = (char *(*)()) F860_4304;
	R3663[8] = (char *(*)()) F861_4304;
	R3663[9] = (char *(*)()) F862_4304;
	R3663[10] = (char *(*)()) F863_4304;
	R3663[11] = (char *(*)()) F864_4304;
	R3663[12] = (char *(*)()) F865_4304;
}

char *(*R3664[13])();
void R3664_init () {
	R3664[0] = (char *(*)()) F853_4305;
	R3664[1] = (char *(*)()) F854_4305;
	R3664[2] = (char *(*)()) F855_4305;
	R3664[3] = (char *(*)()) F856_4305;
	R3664[4] = (char *(*)()) F857_4305;
	R3664[5] = (char *(*)()) F858_4305;
	R3664[6] = (char *(*)()) F859_4305;
	R3664[7] = (char *(*)()) F860_4305;
	R3664[8] = (char *(*)()) F861_4305;
	R3664[9] = (char *(*)()) F862_4305;
	R3664[10] = (char *(*)()) F863_4305;
	R3664[11] = (char *(*)()) F864_4305;
	R3664[12] = (char *(*)()) F865_4305;
}

char *(*R3665[13])();
void R3665_init () {
	R3665[0] = (char *(*)()) F853_4306;
	R3665[1] = (char *(*)()) F854_4306;
	R3665[2] = (char *(*)()) F855_4306;
	R3665[3] = (char *(*)()) F856_4306;
	R3665[4] = (char *(*)()) F857_4306;
	R3665[5] = (char *(*)()) F858_4306;
	R3665[6] = (char *(*)()) F859_4306;
	R3665[7] = (char *(*)()) F860_4306;
	R3665[8] = (char *(*)()) F861_4306;
	R3665[9] = (char *(*)()) F862_4306;
	R3665[10] = (char *(*)()) F863_4306;
	R3665[11] = (char *(*)()) F864_4306;
	R3665[12] = (char *(*)()) F865_4306;
}

char *(*R3669[13])();
void R3669_init () {
	R3669[0] = (char *(*)()) F853_4310;
	R3669[1] = (char *(*)()) F854_4310;
	R3669[2] = (char *(*)()) F855_4310;
	R3669[3] = (char *(*)()) F856_4310;
	R3669[4] = (char *(*)()) F857_4310;
	R3669[5] = (char *(*)()) F858_4310;
	R3669[6] = (char *(*)()) F859_4310;
	R3669[7] = (char *(*)()) F860_4310;
	R3669[8] = (char *(*)()) F861_4310;
	R3669[9] = (char *(*)()) F862_4310;
	R3669[10] = (char *(*)()) F863_4310;
	R3669[11] = (char *(*)()) F864_4310;
	R3669[12] = (char *(*)()) F865_4310;
}

char *(*R3671[13])();
void R3671_init () {
	R3671[0] = (char *(*)()) F853_4312;
	R3671[1] = (char *(*)()) F854_4312;
	R3671[2] = (char *(*)()) F855_4312;
	R3671[3] = (char *(*)()) F856_4312;
	R3671[4] = (char *(*)()) F857_4312;
	R3671[5] = (char *(*)()) F858_4312;
	R3671[6] = (char *(*)()) F859_4312;
	R3671[7] = (char *(*)()) F860_4312;
	R3671[8] = (char *(*)()) F861_4312;
	R3671[9] = (char *(*)()) F862_4312;
	R3671[10] = (char *(*)()) F863_4312;
	R3671[11] = (char *(*)()) F864_4312;
	R3671[12] = (char *(*)()) F865_4312;
}

char *(*R3672[13])();
void R3672_init () {
	R3672[0] = (char *(*)()) F853_4313;
	R3672[1] = (char *(*)()) F854_4313_3672_45;
	R3672[2] = (char *(*)()) F855_4313_3672_45;
	R3672[3] = (char *(*)()) F856_4313_3672_45;
	R3672[4] = (char *(*)()) F857_4313_3672_45;
	R3672[5] = (char *(*)()) F858_4313_3672_45;
	R3672[6] = (char *(*)()) F859_4313_3672_45;
	R3672[7] = (char *(*)()) F860_4313_3672_45;
	R3672[8] = (char *(*)()) F861_4313_3672_45;
	R3672[9] = (char *(*)()) F862_4313_3672_45;
	R3672[10] = (char *(*)()) F863_4313_3672_45;
	R3672[11] = (char *(*)()) F864_4313_3672_45;
	R3672[12] = (char *(*)()) F865_4313_3672_45;
}
static EIF_REFERENCE F854_4313_3672_45 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F854_4313(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F855_4313_3672_45 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F855_4313(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F856_4313_3672_45 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F856_4313(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F857_4313_3672_45 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F857_4313(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F858_4313_3672_45 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F858_4313(Current, *(EIF_INTEGER_8 *)arg1, arg2);
}
static EIF_REFERENCE F859_4313_3672_45 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F859_4313(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F860_4313_3672_45 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F860_4313(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F861_4313_3672_45 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F861_4313(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F862_4313_3672_45 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F862_4313(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F863_4313_3672_45 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F863_4313(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F864_4313_3672_45 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F864_4313(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F865_4313_3672_45 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F865_4313(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3674[13])();
void R3674_init () {
	R3674[0] = (char *(*)()) F853_4315;
	R3674[1] = (char *(*)()) F854_4315;
	R3674[2] = (char *(*)()) F855_4315;
	R3674[3] = (char *(*)()) F856_4315;
	R3674[4] = (char *(*)()) F857_4315;
	R3674[5] = (char *(*)()) F858_4315;
	R3674[6] = (char *(*)()) F859_4315;
	R3674[7] = (char *(*)()) F860_4315;
	R3674[8] = (char *(*)()) F861_4315;
	R3674[9] = (char *(*)()) F862_4315;
	R3674[10] = (char *(*)()) F863_4315;
	R3674[11] = (char *(*)()) F864_4315;
	R3674[12] = (char *(*)()) F865_4315;
}

char *(*R3676[13])();
void R3676_init () {
	R3676[0] = (char *(*)()) F853_4317;
	R3676[1] = (char *(*)()) F854_4317;
	R3676[2] = (char *(*)()) F855_4317;
	R3676[3] = (char *(*)()) F856_4317;
	R3676[4] = (char *(*)()) F857_4317;
	R3676[5] = (char *(*)()) F858_4317;
	R3676[6] = (char *(*)()) F859_4317;
	R3676[7] = (char *(*)()) F860_4317;
	R3676[8] = (char *(*)()) F861_4317;
	R3676[9] = (char *(*)()) F862_4317;
	R3676[10] = (char *(*)()) F863_4317;
	R3676[11] = (char *(*)()) F864_4317;
	R3676[12] = (char *(*)()) F865_4317;
}

char *(*R3683[13])();
void R3683_init () {
	R3683[0] = (char *(*)()) F853_4325;
	R3683[1] = (char *(*)()) F854_4325;
	R3683[2] = (char *(*)()) F855_4325;
	R3683[3] = (char *(*)()) F856_4325;
	R3683[4] = (char *(*)()) F857_4325;
	R3683[5] = (char *(*)()) F858_4325;
	R3683[6] = (char *(*)()) F859_4325;
	R3683[7] = (char *(*)()) F860_4325;
	R3683[8] = (char *(*)()) F861_4325;
	R3683[9] = (char *(*)()) F862_4325;
	R3683[10] = (char *(*)()) F863_4325;
	R3683[11] = (char *(*)()) F864_4325;
	R3683[12] = (char *(*)()) F865_4325;
}

char *(*R3703[20])();
void R3703_init () {
	R3703[0] = (char *(*)()) F880_4365;
	R3703[1] = (char *(*)()) F881_4365;
	R3703[2] = (char *(*)()) F882_4365;
	R3703[3] = (char *(*)()) F883_4365;
	R3703[4] = (char *(*)()) F884_4365;
	R3703[5] = (char *(*)()) F885_4365;
	R3703[6] = (char *(*)()) F886_4365;
	R3703[7] = (char *(*)()) F887_4365;
	R3703[8] = (char *(*)()) F888_4365;
	R3703[9] = (char *(*)()) F889_4365;
	R3703[10] = (char *(*)()) F890_4365;
	R3703[11] = (char *(*)()) F891_4365;
	R3703[12] = (char *(*)()) F892_4365;
	R3703[13] = (char *(*)()) F880_4365;
	R3703[14] = (char *(*)()) F881_4365;
	R3703[15] = (char *(*)()) F884_4365;
	R3703[16] = (char *(*)()) F883_4365;
	R3703[17] = (char *(*)()) F885_4365;
	R3703[18] = (char *(*)()) F889_4365;
	R3703[19] = (char *(*)()) F882_4365;
}

char *(*R3706[20])();
void R3706_init () {
	R3706[0] = (char *(*)()) F880_4368;
	R3706[1] = (char *(*)()) F881_4368;
	R3706[2] = (char *(*)()) F882_4368;
	R3706[3] = (char *(*)()) F883_4368;
	R3706[4] = (char *(*)()) F884_4368;
	R3706[5] = (char *(*)()) F885_4368;
	R3706[6] = (char *(*)()) F886_4368;
	R3706[7] = (char *(*)()) F887_4368;
	R3706[8] = (char *(*)()) F888_4368;
	R3706[9] = (char *(*)()) F889_4368;
	R3706[10] = (char *(*)()) F890_4368;
	R3706[11] = (char *(*)()) F891_4368;
	R3706[12] = (char *(*)()) F892_4368;
	R3706[13] = (char *(*)()) F880_4368;
	R3706[14] = (char *(*)()) F881_4368;
	R3706[15] = (char *(*)()) F884_4368;
	R3706[16] = (char *(*)()) F883_4368;
	R3706[17] = (char *(*)()) F885_4368;
	R3706[18] = (char *(*)()) F889_4368;
	R3706[19] = (char *(*)()) F882_4368;
}

char *(*R3707[20])();
void R3707_init () {
	R3707[0] = (char *(*)()) F880_4369;
	R3707[1] = (char *(*)()) F881_4369;
	R3707[2] = (char *(*)()) F882_4369;
	R3707[3] = (char *(*)()) F883_4369;
	R3707[4] = (char *(*)()) F884_4369;
	R3707[5] = (char *(*)()) F885_4369;
	R3707[6] = (char *(*)()) F886_4369;
	R3707[7] = (char *(*)()) F887_4369;
	R3707[8] = (char *(*)()) F888_4369;
	R3707[9] = (char *(*)()) F889_4369;
	R3707[10] = (char *(*)()) F890_4369;
	R3707[11] = (char *(*)()) F891_4369;
	R3707[12] = (char *(*)()) F892_4369;
	R3707[13] = (char *(*)()) F880_4369;
	R3707[14] = (char *(*)()) F881_4369;
	R3707[15] = (char *(*)()) F884_4369;
	R3707[16] = (char *(*)()) F883_4369;
	R3707[17] = (char *(*)()) F885_4369;
	R3707[18] = (char *(*)()) F889_4369;
	R3707[19] = (char *(*)()) F882_4369;
}

char *(*R3717[20])();
void R3717_init () {
	R3717[0] = (char *(*)()) F880_4395;
	R3717[1] = (char *(*)()) F881_4395;
	R3717[2] = (char *(*)()) F882_4395;
	R3717[3] = (char *(*)()) F883_4395;
	R3717[4] = (char *(*)()) F884_4395;
	R3717[5] = (char *(*)()) F885_4395;
	R3717[6] = (char *(*)()) F886_4395;
	R3717[7] = (char *(*)()) F887_4395;
	R3717[8] = (char *(*)()) F888_4395;
	R3717[9] = (char *(*)()) F889_4395;
	R3717[10] = (char *(*)()) F890_4395;
	R3717[11] = (char *(*)()) F891_4395;
	R3717[12] = (char *(*)()) F892_4395;
	R3717[13] = (char *(*)()) F880_4395;
	R3717[14] = (char *(*)()) F881_4395;
	R3717[15] = (char *(*)()) F884_4395;
	R3717[16] = (char *(*)()) F883_4395;
	R3717[17] = (char *(*)()) F885_4395;
	R3717[18] = (char *(*)()) F889_4395;
	R3717[19] = (char *(*)()) F882_4395;
}

char *(*R3731[20])();
void R3731_init () {
	R3731[0] = (char *(*)()) F880_4411;
	R3731[1] = (char *(*)()) F881_4411_3731_57;
	R3731[2] = (char *(*)()) F882_4411_3731_57;
	R3731[3] = (char *(*)()) F883_4411_3731_57;
	R3731[4] = (char *(*)()) F884_4411_3731_57;
	R3731[5] = (char *(*)()) F885_4411_3731_57;
	R3731[6] = (char *(*)()) F886_4411_3731_57;
	R3731[7] = (char *(*)()) F887_4411_3731_57;
	R3731[8] = (char *(*)()) F888_4411_3731_57;
	R3731[9] = (char *(*)()) F889_4411_3731_57;
	R3731[10] = (char *(*)()) F890_4411_3731_57;
	R3731[11] = (char *(*)()) F891_4411_3731_57;
	R3731[12] = (char *(*)()) F892_4411_3731_57;
	R3731[13] = (char *(*)()) F880_4411;
	R3731[14] = (char *(*)()) F881_4411_3731_57;
	R3731[15] = (char *(*)()) F884_4411_3731_57;
	R3731[16] = (char *(*)()) F883_4411_3731_57;
	R3731[17] = (char *(*)()) F885_4411_3731_57;
	R3731[18] = (char *(*)()) F889_4411_3731_57;
	R3731[19] = (char *(*)()) F882_4411_3731_57;
}
static void F881_4411_3731_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F881_4411(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F882_4411_3731_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F882_4411(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F883_4411_3731_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F883_4411(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F884_4411_3731_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F884_4411(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F885_4411_3731_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F885_4411(Current, *(EIF_INTEGER_8 *)arg1, arg2, arg3);
}
static void F886_4411_3731_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F886_4411(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F887_4411_3731_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F887_4411(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F888_4411_3731_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F888_4411(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F889_4411_3731_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F889_4411(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F890_4411_3731_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F890_4411(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F891_4411_3731_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F891_4411(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F892_4411_3731_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F892_4411(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R3738[20])();
void R3738_init () {
	R3738[0] = (char *(*)()) F880_4423;
	R3738[1] = (char *(*)()) F881_4423;
	R3738[2] = (char *(*)()) F882_4423;
	R3738[3] = (char *(*)()) F883_4423;
	R3738[4] = (char *(*)()) F884_4423;
	R3738[5] = (char *(*)()) F885_4423;
	R3738[6] = (char *(*)()) F886_4423;
	R3738[7] = (char *(*)()) F887_4423;
	R3738[8] = (char *(*)()) F888_4423;
	R3738[9] = (char *(*)()) F889_4423;
	R3738[10] = (char *(*)()) F890_4423;
	R3738[11] = (char *(*)()) F891_4423;
	R3738[12] = (char *(*)()) F892_4423;
	R3738[13] = (char *(*)()) F880_4423;
	R3738[14] = (char *(*)()) F881_4423;
	R3738[15] = (char *(*)()) F884_4423;
	R3738[16] = (char *(*)()) F883_4423;
	R3738[17] = (char *(*)()) F885_4423;
	R3738[18] = (char *(*)()) F889_4423;
	R3738[19] = (char *(*)()) F882_4423;
}

char *(*R3741[7])();
void R3741_init () {
	R3741[0] = (char *(*)()) F893_4424;
	R3741[1] = (char *(*)()) F894_4424;
	R3741[2] = (char *(*)()) F895_4424;
	R3741[3] = (char *(*)()) F896_4424;
	R3741[4] = (char *(*)()) F897_4424;
	R3741[5] = (char *(*)()) F898_4424;
	R3741[6] = (char *(*)()) F899_4424;
}

char *(*R3774[1146])();
void R3774_init () {
	R3774[0] = (char *(*)()) F956_4525;
	R3774[1] = (char *(*)()) F957_4532;
	R3774[290] = (char *(*)()) F1246_10504;
	R3774[605] = (char *(*)()) F1561_12753;
	R3774[676] = (char *(*)()) F1632_13697;
	R3774[802] = (char *(*)()) F1758_15941;
	R3774[956] = (char *(*)()) F1868_17873;
	R3774[961] = (char *(*)()) F1868_17873;
	R3774[1137] = (char *(*)()) F1868_17873;
	{long i; for (i = 1144; i < 1146; i++) R3774[i] = (char *(*)()) F1868_17873;}
}

char *(*R3775[1146])();
void R3775_init () {
	R3775[0] = (char *(*)()) F956_4526;
	R3775[1] = (char *(*)()) F957_4533;
	R3775[290] = (char *(*)()) F1246_10505;
	R3775[605] = (char *(*)()) F1561_12754;
	R3775[676] = (char *(*)()) F1632_13698;
	R3775[802] = (char *(*)()) F1758_15942;
	R3775[956] = (char *(*)()) F1912_18897;
	R3775[961] = (char *(*)()) F1917_19017;
	R3775[1137] = (char *(*)()) F2093_20520;
	R3775[1144] = (char *(*)()) F2100_20633;
	R3775[1145] = (char *(*)()) F2101_20667;
}

char *(*R3838[1240])();
void R3838_init () {
	R3838[0] = (char *(*)()) F976_4747;
	R3838[1] = (char *(*)()) F977_4747;
	R3838[2] = (char *(*)()) F978_4747;
	R3838[3] = (char *(*)()) F979_4747;
	R3838[4] = (char *(*)()) F980_4747;
	R3838[5] = (char *(*)()) F976_4747;
	R3838[6] = (char *(*)()) F978_4747;
	R3838[7] = (char *(*)()) F976_4747;
	R3838[54] = (char *(*)()) F1030_5183;
	R3838[128] = (char *(*)()) F1103_6274;
	R3838[131] = (char *(*)()) F1103_6274;
	R3838[137] = (char *(*)()) F1113_6601;
	R3838[140] = (char *(*)()) F1116_6679;
	R3838[141] = (char *(*)()) F1117_6770;
	R3838[384] = (char *(*)()) F1347_11402;
	R3838[385] = (char *(*)()) F1351_11402;
	R3838[386] = (char *(*)()) F1353_11402;
	R3838[399] = (char *(*)()) F1347_11402;
	R3838[400] = (char *(*)()) F1348_11402;
	R3838[401] = (char *(*)()) F1349_11402;
	R3838[402] = (char *(*)()) F1350_11402;
	R3838[403] = (char *(*)()) F1351_11402;
	R3838[404] = (char *(*)()) F1352_11402;
	R3838[408] = (char *(*)()) F1384_11448;
	R3838[409] = (char *(*)()) F1385_11448;
	R3838[410] = (char *(*)()) F1386_11448;
	R3838[527] = (char *(*)()) F1503_12157;
	R3838[528] = (char *(*)()) F1504_12157;
	R3838[529] = (char *(*)()) F1505_12157;
	R3838[530] = (char *(*)()) F1506_12238;
	R3838[531] = (char *(*)()) F1507_12238;
	R3838[532] = (char *(*)()) F1508_12238;
	R3838[546] = (char *(*)()) F1519_12389;
	R3838[547] = (char *(*)()) F1520_12389;
	R3838[548] = (char *(*)()) F1521_12389;
	R3838[561] = (char *(*)()) F1531_12473;
	R3838[562] = (char *(*)()) F1532_12473;
	R3838[563] = (char *(*)()) F1533_12473;
	R3838[564] = (char *(*)()) F1534_12473;
	R3838[565] = (char *(*)()) F1535_12473;
	R3838[566] = (char *(*)()) F1536_12473;
	R3838[899] = (char *(*)()) F1506_12238;
	{long i; for (i = 1238; i < 1240; i++) R3838[i] = (char *(*)()) F1113_6601;}
}

char *(*R3865[8])();
void R3865_init () {
	R3865[0] = (char *(*)()) F976_4688;
	R3865[1] = (char *(*)()) F977_4688;
	R3865[2] = (char *(*)()) F978_4688;
	R3865[3] = (char *(*)()) F979_4688;
	R3865[4] = (char *(*)()) F980_4688;
	R3865[5] = (char *(*)()) F976_4688;
	R3865[6] = (char *(*)()) F978_4688;
	R3865[7] = (char *(*)()) F976_4688;
}

char *(*R3868[8])();
void R3868_init () {
	R3868[0] = (char *(*)()) F976_4691;
	R3868[1] = (char *(*)()) F977_4691;
	R3868[2] = (char *(*)()) F978_4691;
	R3868[3] = (char *(*)()) F979_4691;
	R3868[4] = (char *(*)()) F980_4691;
	R3868[5] = (char *(*)()) F976_4691;
	R3868[6] = (char *(*)()) F978_4691;
	R3868[7] = (char *(*)()) F976_4691;
}

char *(*R3869[8])();
void R3869_init () {
	R3869[0] = (char *(*)()) F976_4692;
	R3869[1] = (char *(*)()) F977_4692;
	R3869[2] = (char *(*)()) F978_4692_3869_1;
	R3869[3] = (char *(*)()) F979_4692_3869_1;
	R3869[4] = (char *(*)()) F980_4692_3869_1;
	R3869[5] = (char *(*)()) F976_4692;
	R3869[6] = (char *(*)()) F978_4692_3869_1;
	R3869[7] = (char *(*)()) F976_4692;
}
static EIF_REFERENCE F978_4692_3869_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F978_4692(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F979_4692_3869_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F979_4692(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F980_4692_3869_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F980_4692(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1101, 0x00).id, 1101, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R3877[8])();
void R3877_init () {
	R3877[0] = (char *(*)()) F976_4705;
	R3877[1] = (char *(*)()) F977_4705_3877_33;
	R3877[2] = (char *(*)()) F978_4705;
	R3877[3] = (char *(*)()) F979_4705_3877_33;
	R3877[4] = (char *(*)()) F980_4705;
	R3877[5] = (char *(*)()) F981_4802;
	R3877[6] = (char *(*)()) F982_4802;
	R3877[7] = (char *(*)()) F976_4705;
}
static EIF_INTEGER_32 F977_4705_3877_33 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F977_4705(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F979_4705_3877_33 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F979_4705(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3879[8])();
void R3879_init () {
	R3879[0] = (char *(*)()) F976_4712;
	R3879[1] = (char *(*)()) F977_4712_3879_3;
	R3879[2] = (char *(*)()) F978_4712;
	R3879[3] = (char *(*)()) F979_4712_3879_3;
	R3879[4] = (char *(*)()) F980_4712;
	R3879[5] = (char *(*)()) F981_4804;
	R3879[6] = (char *(*)()) F982_4804;
	R3879[7] = (char *(*)()) F976_4712;
}
static EIF_BOOLEAN F977_4712_3879_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F977_4712(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F979_4712_3879_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F979_4712(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R3885[8])();
void R3885_init () {
	R3885[0] = (char *(*)()) F976_4720;
	R3885[1] = (char *(*)()) F977_4720;
	R3885[2] = (char *(*)()) F978_4720;
	R3885[3] = (char *(*)()) F979_4720;
	R3885[4] = (char *(*)()) F980_4720;
	R3885[5] = (char *(*)()) F976_4720;
	R3885[6] = (char *(*)()) F978_4720;
	R3885[7] = (char *(*)()) F976_4720;
}

char *(*R3886[8])();
void R3886_init () {
	R3886[0] = (char *(*)()) F976_4721;
	R3886[1] = (char *(*)()) F977_4721;
	R3886[2] = (char *(*)()) F978_4721;
	R3886[3] = (char *(*)()) F979_4721;
	R3886[4] = (char *(*)()) F980_4721;
	R3886[5] = (char *(*)()) F976_4721;
	R3886[6] = (char *(*)()) F978_4721;
	R3886[7] = (char *(*)()) F976_4721;
}

char *(*R3894[8])();
void R3894_init () {
	R3894[0] = (char *(*)()) F976_4730;
	R3894[1] = (char *(*)()) F977_4730_3894_4;
	R3894[2] = (char *(*)()) F978_4730;
	R3894[3] = (char *(*)()) F979_4730_3894_4;
	R3894[4] = (char *(*)()) F980_4730;
	R3894[5] = (char *(*)()) F976_4730;
	R3894[6] = (char *(*)()) F978_4730;
	R3894[7] = (char *(*)()) F976_4730;
}
static void F977_4730_3894_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F977_4730(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F979_4730_3894_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F979_4730(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3896[8])();
void R3896_init () {
	R3896[0] = (char *(*)()) F976_4732;
	R3896[1] = (char *(*)()) F977_4732;
	R3896[2] = (char *(*)()) F978_4732;
	R3896[3] = (char *(*)()) F979_4732;
	R3896[4] = (char *(*)()) F980_4732;
	R3896[5] = (char *(*)()) F976_4732;
	R3896[6] = (char *(*)()) F978_4732;
	R3896[7] = (char *(*)()) F976_4732;
}

char *(*R3897[8])();
void R3897_init () {
	R3897[0] = (char *(*)()) F976_4733;
	R3897[1] = (char *(*)()) F977_4733;
	R3897[2] = (char *(*)()) F978_4733;
	R3897[3] = (char *(*)()) F979_4733;
	R3897[4] = (char *(*)()) F980_4733;
	R3897[5] = (char *(*)()) F976_4733;
	R3897[6] = (char *(*)()) F978_4733;
	R3897[7] = (char *(*)()) F976_4733;
}

char *(*R3903[8])();
void R3903_init () {
	R3903[0] = (char *(*)()) F976_4746;
	R3903[1] = (char *(*)()) F977_4746;
	R3903[2] = (char *(*)()) F978_4746;
	R3903[3] = (char *(*)()) F979_4746;
	R3903[4] = (char *(*)()) F980_4746;
	R3903[5] = (char *(*)()) F981_4806;
	R3903[6] = (char *(*)()) F982_4806;
	R3903[7] = (char *(*)()) F976_4746;
}

char *(*R3912[8])();
void R3912_init () {
	R3912[0] = (char *(*)()) F976_4756;
	R3912[1] = (char *(*)()) F977_4756;
	R3912[2] = (char *(*)()) F978_4756;
	R3912[3] = (char *(*)()) F979_4756;
	R3912[4] = (char *(*)()) F980_4756;
	R3912[5] = (char *(*)()) F976_4756;
	R3912[6] = (char *(*)()) F978_4756;
	R3912[7] = (char *(*)()) F976_4756;
}

char *(*R3913[8])();
void R3913_init () {
	R3913[0] = (char *(*)()) F976_4757;
	R3913[1] = (char *(*)()) F977_4757;
	R3913[2] = (char *(*)()) F978_4757;
	R3913[3] = (char *(*)()) F979_4757;
	R3913[4] = (char *(*)()) F980_4757;
	R3913[5] = (char *(*)()) F976_4757;
	R3913[6] = (char *(*)()) F978_4757;
	R3913[7] = (char *(*)()) F976_4757;
}

char *(*R3920[8])();
void R3920_init () {
	R3920[0] = (char *(*)()) F976_4764;
	R3920[1] = (char *(*)()) F977_4764;
	R3920[2] = (char *(*)()) F978_4764_3920_1;
	R3920[3] = (char *(*)()) F979_4764_3920_1;
	R3920[4] = (char *(*)()) F980_4764_3920_1;
	R3920[5] = (char *(*)()) F976_4764;
	R3920[6] = (char *(*)()) F978_4764_3920_1;
	R3920[7] = (char *(*)()) F976_4764;
}
static EIF_REFERENCE F978_4764_3920_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F978_4764(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F979_4764_3920_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F979_4764(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F980_4764_3920_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F980_4764(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1101, 0x00).id, 1101, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R3921[8])();
void R3921_init () {
	R3921[0] = (char *(*)()) F976_4765;
	R3921[1] = (char *(*)()) F977_4765_3921_1;
	R3921[2] = (char *(*)()) F978_4765;
	R3921[3] = (char *(*)()) F979_4765_3921_1;
	R3921[4] = (char *(*)()) F980_4765;
	R3921[5] = (char *(*)()) F976_4765;
	R3921[6] = (char *(*)()) F978_4765;
	R3921[7] = (char *(*)()) F976_4765;
}
static EIF_REFERENCE F977_4765_3921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F977_4765(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F979_4765_3921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F979_4765(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3922[8])();
void R3922_init () {
	R3922[0] = (char *(*)()) F976_4766;
	R3922[1] = (char *(*)()) F977_4766;
	R3922[2] = (char *(*)()) F978_4766;
	R3922[3] = (char *(*)()) F979_4766;
	R3922[4] = (char *(*)()) F980_4766;
	R3922[5] = (char *(*)()) F976_4766;
	R3922[6] = (char *(*)()) F978_4766;
	R3922[7] = (char *(*)()) F976_4766;
}

char *(*R3923[8])();
void R3923_init () {
	R3923[0] = (char *(*)()) F976_4767;
	R3923[1] = (char *(*)()) F977_4767;
	R3923[2] = (char *(*)()) F978_4767;
	R3923[3] = (char *(*)()) F979_4767;
	R3923[4] = (char *(*)()) F980_4767;
	R3923[5] = (char *(*)()) F976_4767;
	R3923[6] = (char *(*)()) F978_4767;
	R3923[7] = (char *(*)()) F976_4767;
}

char *(*R3925[8])();
void R3925_init () {
	R3925[0] = (char *(*)()) F976_4769;
	R3925[1] = (char *(*)()) F977_4769;
	R3925[2] = (char *(*)()) F978_4769;
	R3925[3] = (char *(*)()) F979_4769;
	R3925[4] = (char *(*)()) F980_4769;
	R3925[5] = (char *(*)()) F976_4769;
	R3925[6] = (char *(*)()) F978_4769;
	R3925[7] = (char *(*)()) F976_4769;
}

char *(*R3926[8])();
void R3926_init () {
	R3926[0] = (char *(*)()) F976_4770;
	R3926[1] = (char *(*)()) F977_4770;
	R3926[2] = (char *(*)()) F978_4770;
	R3926[3] = (char *(*)()) F979_4770;
	R3926[4] = (char *(*)()) F980_4770;
	R3926[5] = (char *(*)()) F976_4770;
	R3926[6] = (char *(*)()) F978_4770;
	R3926[7] = (char *(*)()) F976_4770;
}

char *(*R3928[8])();
void R3928_init () {
	R3928[0] = (char *(*)()) F976_4772;
	R3928[1] = (char *(*)()) F977_4772;
	R3928[2] = (char *(*)()) F978_4772;
	R3928[3] = (char *(*)()) F979_4772;
	R3928[4] = (char *(*)()) F980_4772;
	R3928[5] = (char *(*)()) F976_4772;
	R3928[6] = (char *(*)()) F978_4772;
	R3928[7] = (char *(*)()) F976_4772;
}

char *(*R3929[8])();
void R3929_init () {
	R3929[0] = (char *(*)()) F976_4773;
	R3929[1] = (char *(*)()) F977_4773;
	R3929[2] = (char *(*)()) F978_4773;
	R3929[3] = (char *(*)()) F979_4773;
	R3929[4] = (char *(*)()) F980_4773;
	R3929[5] = (char *(*)()) F976_4773;
	R3929[6] = (char *(*)()) F978_4773;
	R3929[7] = (char *(*)()) F976_4773;
}

char *(*R3930[8])();
void R3930_init () {
	R3930[0] = (char *(*)()) F976_4774;
	R3930[1] = (char *(*)()) F977_4774;
	R3930[2] = (char *(*)()) F978_4774;
	R3930[3] = (char *(*)()) F979_4774;
	R3930[4] = (char *(*)()) F980_4774;
	R3930[5] = (char *(*)()) F976_4774;
	R3930[6] = (char *(*)()) F978_4774;
	R3930[7] = (char *(*)()) F976_4774;
}

char *(*R3934[8])();
void R3934_init () {
	R3934[0] = (char *(*)()) F976_4778;
	R3934[1] = (char *(*)()) F977_4778_3934_4;
	R3934[2] = (char *(*)()) F978_4778;
	R3934[3] = (char *(*)()) F979_4778_3934_4;
	R3934[4] = (char *(*)()) F980_4778;
	R3934[5] = (char *(*)()) F976_4778;
	R3934[6] = (char *(*)()) F978_4778;
	R3934[7] = (char *(*)()) F976_4778;
}
static void F977_4778_3934_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F977_4778(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F979_4778_3934_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F979_4778(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3940[8])();
void R3940_init () {
	R3940[0] = (char *(*)()) F976_4784;
	R3940[1] = (char *(*)()) F977_4784;
	R3940[2] = (char *(*)()) F978_4784;
	R3940[3] = (char *(*)()) F979_4784;
	R3940[4] = (char *(*)()) F980_4784;
	R3940[5] = (char *(*)()) F976_4784;
	R3940[6] = (char *(*)()) F978_4784;
	R3940[7] = (char *(*)()) F976_4784;
}

char *(*R3953[8])();
void R3953_init () {
	R3953[0] = (char *(*)()) F976_4797;
	R3953[1] = (char *(*)()) F977_4797;
	R3953[2] = (char *(*)()) F978_4797;
	R3953[3] = (char *(*)()) F979_4797;
	R3953[4] = (char *(*)()) F980_4797;
	R3953[5] = (char *(*)()) F976_4797;
	R3953[6] = (char *(*)()) F978_4797;
	R3953[7] = (char *(*)()) F976_4797;
}

char *(*R3956[2])();
void R3956_init () {
	R3956[0] = (char *(*)()) F981_4800;
	R3956[1] = (char *(*)()) F982_4800;
}

char *(*R4102[607])();
void R4102_init () {
	R4102[0] = (char *(*)()) F1194_8927;
	R4102[543] = (char *(*)()) F1737_15361;
	R4102[606] = (char *(*)()) F1800_16752;
}

char *(*R4103[607])();
void R4103_init () {
	R4103[0] = (char *(*)()) F1194_8928;
	R4103[543] = (char *(*)()) F1737_15362;
	R4103[606] = (char *(*)()) F1800_16753;
}

char *(*R4112[1220])();
void R4112_init () {
	R4112[0] = (char *(*)()) F996_4968;
	R4112[1] = (char *(*)()) F997_4976;
	R4112[2] = (char *(*)()) F998_5007;
	R4112[3] = (char *(*)()) F999_5049;
	R4112[4] = (char *(*)()) F1000_5049;
	R4112[5] = (char *(*)()) F1001_5049;
	R4112[6] = (char *(*)()) F1002_5049;
	R4112[7] = (char *(*)()) F1003_5049;
	R4112[8] = (char *(*)()) F1004_5049;
	R4112[9] = (char *(*)()) F1005_5049;
	R4112[10] = (char *(*)()) F1006_5049;
	R4112[11] = (char *(*)()) F1007_5049;
	R4112[12] = (char *(*)()) F1008_5049;
	R4112[13] = (char *(*)()) F1009_5049;
	R4112[14] = (char *(*)()) F1010_5049;
	R4112[15] = (char *(*)()) F1011_5049;
	R4112[16] = (char *(*)()) F1012_5049;
	R4112[17] = (char *(*)()) F1013_5049;
	R4112[18] = (char *(*)()) F1014_5049;
	R4112[19] = (char *(*)()) F1015_5049;
	R4112[20] = (char *(*)()) F1016_5049;
	R4112[21] = (char *(*)()) F1017_5049;
	R4112[22] = (char *(*)()) F1018_5049;
	R4112[23] = (char *(*)()) F1019_5049;
	R4112[24] = (char *(*)()) F1020_5049;
	R4112[25] = (char *(*)()) F1021_5049;
	R4112[26] = (char *(*)()) F1022_5049;
	R4112[27] = (char *(*)()) F1023_5049;
	R4112[28] = (char *(*)()) F1024_5049;
	R4112[29] = (char *(*)()) F1025_5049;
	R4112[30] = (char *(*)()) F1026_5049;
	R4112[31] = (char *(*)()) F1027_5049;
	R4112[32] = (char *(*)()) F1028_5049;
	R4112[33] = (char *(*)()) F1029_5049;
	R4112[34] = (char *(*)()) F1030_5101;
	{long i; for (i = 36; i < 38; i++) R4112[i] = (char *(*)()) F1031_5208;}
	{long i; for (i = 39; i < 41; i++) R4112[i] = (char *(*)()) F1034_5306;}
	{long i; for (i = 42; i < 44; i++) R4112[i] = (char *(*)()) F1037_5405;}
	{long i; for (i = 45; i < 47; i++) R4112[i] = (char *(*)()) F1040_5504;}
	{long i; for (i = 48; i < 50; i++) R4112[i] = (char *(*)()) F1043_5603;}
	{long i; for (i = 51; i < 53; i++) R4112[i] = (char *(*)()) F1046_5697;}
	{long i; for (i = 54; i < 56; i++) R4112[i] = (char *(*)()) F1049_5791;}
	{long i; for (i = 57; i < 59; i++) R4112[i] = (char *(*)()) F1052_5886;}
	{long i; for (i = 60; i < 62; i++) R4112[i] = (char *(*)()) F1055_5981;}
	{long i; for (i = 63; i < 65; i++) R4112[i] = (char *(*)()) F1058_6047;}
	{long i; for (i = 66; i < 68; i++) R4112[i] = (char *(*)()) F1061_6114;}
	{long i; for (i = 69; i < 71; i++) R4112[i] = (char *(*)()) F1064_6155;}
	{long i; for (i = 72; i < 74; i++) R4112[i] = (char *(*)()) F1067_6203;}
	{long i; for (i = 75; i < 105; i++) R4112[i] = (char *(*)()) F1070_6224;}
	R4112[105] = (char *(*)()) F1101_6250;
	R4112[106] = (char *(*)()) F1102_6250;
	R4112[108] = (char *(*)()) F1103_6258;
	R4112[111] = (char *(*)()) F1103_6258;
	{long i; for (i = 116; i < 118; i++) R4112[i] = (char *(*)()) F1108_6317;}
	{long i; for (i = 120; i < 122; i++) R4112[i] = (char *(*)()) F1108_6317;}
	R4112[143] = (char *(*)()) F1139_8331;
	R4112[144] = (char *(*)()) F1140_8339;
	R4112[158] = (char *(*)()) F1153_8479;
	R4112[180] = (char *(*)()) F1152_8475;
	R4112[181] = (char *(*)()) F1177_8790;
	R4112[579] = (char *(*)()) F1575_12903;
	R4112[617] = (char *(*)()) F1613_13446;
	R4112[618] = (char *(*)()) F1614_13486;
	R4112[620] = (char *(*)()) F1616_13535;
	R4112[621] = (char *(*)()) F1617_13574;
	R4112[623] = (char *(*)()) F1619_13616;
	R4112[624] = (char *(*)()) F1620_13639;
	R4112[710] = (char *(*)()) F1706_14579;
	{long i; for (i = 721; i < 723; i++) R4112[i] = (char *(*)()) F1717_15002;}
	R4112[752] = (char *(*)()) F1748_15546;
	R4112[784] = (char *(*)()) F1780_16395;
	R4112[787] = (char *(*)()) F1783_16553;
	R4112[868] = (char *(*)()) F1863_17699;
	R4112[883] = (char *(*)()) F1878_18225;
	R4112[884] = (char *(*)()) F1880_18268;
	R4112[885] = (char *(*)()) F1881_18282;
	R4112[886] = (char *(*)()) F1878_18225;
	R4112[887] = (char *(*)()) F1883_18314;
	{long i; for (i = 888; i < 890; i++) R4112[i] = (char *(*)()) F1878_18225;}
	{long i; for (i = 890; i < 893; i++) R4112[i] = (char *(*)()) F1886_18356;}
	R4112[894] = (char *(*)()) F1890_18429;
	R4112[895] = (char *(*)()) F1891_18449;
	{long i; for (i = 896; i < 902; i++) R4112[i] = (char *(*)()) F1892_18470;}
	R4112[903] = (char *(*)()) F1899_18594;
	R4112[904] = (char *(*)()) F1900_18623;
	R4112[905] = (char *(*)()) F1901_18649;
	R4112[906] = (char *(*)()) F1902_18682;
	R4112[907] = (char *(*)()) F1903_18712;
	R4112[1144] = (char *(*)()) F1863_17699;
	R4112[1155] = (char *(*)()) F1863_17699;
	R4112[1214] = (char *(*)()) F2210_22238;
	{long i; for (i = 1218; i < 1220; i++) R4112[i] = (char *(*)()) F2214_22447;}
}

char *(*R4183[31])();
void R4183_init () {
	R4183[0] = (char *(*)()) F999_5045;
	R4183[1] = (char *(*)()) F1000_5045;
	R4183[2] = (char *(*)()) F1001_5045;
	R4183[3] = (char *(*)()) F1002_5045;
	R4183[4] = (char *(*)()) F1003_5045;
	R4183[5] = (char *(*)()) F1004_5045;
	R4183[6] = (char *(*)()) F1005_5045;
	R4183[7] = (char *(*)()) F1006_5045;
	R4183[8] = (char *(*)()) F1007_5045;
	R4183[9] = (char *(*)()) F1008_5045;
	R4183[10] = (char *(*)()) F1009_5045;
	R4183[11] = (char *(*)()) F1010_5045;
	R4183[12] = (char *(*)()) F1011_5045;
	R4183[13] = (char *(*)()) F1012_5045;
	R4183[14] = (char *(*)()) F1013_5045;
	R4183[15] = (char *(*)()) F1014_5045;
	R4183[16] = (char *(*)()) F1015_5045;
	R4183[17] = (char *(*)()) F1016_5045;
	R4183[18] = (char *(*)()) F1017_5045;
	R4183[19] = (char *(*)()) F1018_5045;
	R4183[20] = (char *(*)()) F1019_5045;
	R4183[21] = (char *(*)()) F1020_5045;
	R4183[22] = (char *(*)()) F1021_5045;
	R4183[23] = (char *(*)()) F1022_5045;
	R4183[24] = (char *(*)()) F1023_5045;
	R4183[25] = (char *(*)()) F1024_5045;
	R4183[26] = (char *(*)()) F1025_5045;
	R4183[27] = (char *(*)()) F1026_5045;
	R4183[28] = (char *(*)()) F1027_5045;
	R4183[29] = (char *(*)()) F1028_5045;
	R4183[30] = (char *(*)()) F1029_5045;
}

char *(*R4184[31])();
void R4184_init () {
	R4184[0] = (char *(*)()) F999_5046;
	R4184[1] = (char *(*)()) F1000_5046;
	R4184[2] = (char *(*)()) F1001_5046;
	R4184[3] = (char *(*)()) F1002_5046;
	R4184[4] = (char *(*)()) F1003_5046;
	R4184[5] = (char *(*)()) F1004_5046;
	R4184[6] = (char *(*)()) F1005_5046;
	R4184[7] = (char *(*)()) F1006_5046;
	R4184[8] = (char *(*)()) F1007_5046;
	R4184[9] = (char *(*)()) F1008_5046;
	R4184[10] = (char *(*)()) F1009_5046;
	R4184[11] = (char *(*)()) F1010_5046;
	R4184[12] = (char *(*)()) F1011_5046;
	R4184[13] = (char *(*)()) F1012_5046;
	R4184[14] = (char *(*)()) F1013_5046;
	R4184[15] = (char *(*)()) F1014_5046;
	R4184[16] = (char *(*)()) F1015_5046;
	R4184[17] = (char *(*)()) F1016_5046;
	R4184[18] = (char *(*)()) F1017_5046;
	R4184[19] = (char *(*)()) F1018_5046;
	R4184[20] = (char *(*)()) F1019_5046;
	R4184[21] = (char *(*)()) F1020_5046;
	R4184[22] = (char *(*)()) F1021_5046;
	R4184[23] = (char *(*)()) F1022_5046;
	R4184[24] = (char *(*)()) F1023_5046;
	R4184[25] = (char *(*)()) F1024_5046;
	R4184[26] = (char *(*)()) F1025_5046;
	R4184[27] = (char *(*)()) F1026_5046;
	R4184[28] = (char *(*)()) F1027_5046;
	R4184[29] = (char *(*)()) F1028_5046;
	R4184[30] = (char *(*)()) F1029_5046;
}

char *(*R4186[31])();
void R4186_init () {
	R4186[0] = (char *(*)()) F999_5048;
	R4186[1] = (char *(*)()) F1000_5048;
	R4186[2] = (char *(*)()) F1001_5048;
	R4186[3] = (char *(*)()) F1002_5048;
	R4186[4] = (char *(*)()) F1003_5048;
	R4186[5] = (char *(*)()) F1004_5048;
	R4186[6] = (char *(*)()) F1005_5048;
	R4186[7] = (char *(*)()) F1006_5048;
	R4186[8] = (char *(*)()) F1007_5048;
	R4186[9] = (char *(*)()) F1008_5048;
	R4186[10] = (char *(*)()) F1009_5048;
	R4186[11] = (char *(*)()) F1010_5048;
	R4186[12] = (char *(*)()) F1011_5048;
	R4186[13] = (char *(*)()) F1012_5048;
	R4186[14] = (char *(*)()) F1013_5048;
	R4186[15] = (char *(*)()) F1014_5048;
	R4186[16] = (char *(*)()) F1015_5048;
	R4186[17] = (char *(*)()) F1016_5048;
	R4186[18] = (char *(*)()) F1017_5048;
	R4186[19] = (char *(*)()) F1018_5048;
	R4186[20] = (char *(*)()) F1019_5048;
	R4186[21] = (char *(*)()) F1020_5048;
	R4186[22] = (char *(*)()) F1021_5048;
	R4186[23] = (char *(*)()) F1022_5048;
	R4186[24] = (char *(*)()) F1023_5048;
	R4186[25] = (char *(*)()) F1024_5048;
	R4186[26] = (char *(*)()) F1025_5048;
	R4186[27] = (char *(*)()) F1026_5048;
	R4186[28] = (char *(*)()) F1027_5048;
	R4186[29] = (char *(*)()) F1028_5048;
	R4186[30] = (char *(*)()) F1029_5048;
}

char *(*R4188[31])();
void R4188_init () {
	R4188[0] = (char *(*)()) F999_5051;
	R4188[1] = (char *(*)()) F1000_5051;
	R4188[2] = (char *(*)()) F1001_5051;
	R4188[3] = (char *(*)()) F1002_5051;
	R4188[4] = (char *(*)()) F1003_5051;
	R4188[5] = (char *(*)()) F1004_5051;
	R4188[6] = (char *(*)()) F1005_5051;
	R4188[7] = (char *(*)()) F1006_5051;
	R4188[8] = (char *(*)()) F1007_5051;
	R4188[9] = (char *(*)()) F1008_5051;
	R4188[10] = (char *(*)()) F1009_5051;
	R4188[11] = (char *(*)()) F1010_5051;
	R4188[12] = (char *(*)()) F1011_5051;
	R4188[13] = (char *(*)()) F1012_5051;
	R4188[14] = (char *(*)()) F1013_5051;
	R4188[15] = (char *(*)()) F1014_5051;
	R4188[16] = (char *(*)()) F1015_5051;
	R4188[17] = (char *(*)()) F1016_5051;
	R4188[18] = (char *(*)()) F1017_5051;
	R4188[19] = (char *(*)()) F1018_5051;
	R4188[20] = (char *(*)()) F1019_5051;
	R4188[21] = (char *(*)()) F1020_5051;
	R4188[22] = (char *(*)()) F1021_5051;
	R4188[23] = (char *(*)()) F1022_5051;
	R4188[24] = (char *(*)()) F1023_5051;
	R4188[25] = (char *(*)()) F1024_5051;
	R4188[26] = (char *(*)()) F1025_5051;
	R4188[27] = (char *(*)()) F1026_5051;
	R4188[28] = (char *(*)()) F1027_5051;
	R4188[29] = (char *(*)()) F1028_5051;
	R4188[30] = (char *(*)()) F1029_5051;
}

char *(*R4191[31])();
void R4191_init () {
	R4191[0] = (char *(*)()) F999_5054;
	R4191[1] = (char *(*)()) F1000_5054;
	R4191[2] = (char *(*)()) F1001_5054;
	R4191[3] = (char *(*)()) F1002_5054;
	R4191[4] = (char *(*)()) F1003_5054;
	R4191[5] = (char *(*)()) F1004_5054;
	R4191[6] = (char *(*)()) F1005_5054;
	R4191[7] = (char *(*)()) F1006_5054;
	R4191[8] = (char *(*)()) F1007_5054;
	R4191[9] = (char *(*)()) F1008_5054;
	R4191[10] = (char *(*)()) F1009_5054;
	R4191[11] = (char *(*)()) F1010_5054;
	R4191[12] = (char *(*)()) F1011_5054;
	R4191[13] = (char *(*)()) F1012_5054;
	R4191[14] = (char *(*)()) F1013_5054;
	R4191[15] = (char *(*)()) F1014_5054;
	R4191[16] = (char *(*)()) F1015_5054;
	R4191[17] = (char *(*)()) F1016_5054;
	R4191[18] = (char *(*)()) F1017_5054;
	R4191[19] = (char *(*)()) F1018_5054;
	R4191[20] = (char *(*)()) F1019_5054;
	R4191[21] = (char *(*)()) F1020_5054;
	R4191[22] = (char *(*)()) F1021_5054;
	R4191[23] = (char *(*)()) F1022_5054;
	R4191[24] = (char *(*)()) F1023_5054;
	R4191[25] = (char *(*)()) F1024_5054;
	R4191[26] = (char *(*)()) F1025_5054;
	R4191[27] = (char *(*)()) F1026_5054;
	R4191[28] = (char *(*)()) F1027_5054;
	R4191[29] = (char *(*)()) F1028_5054;
	R4191[30] = (char *(*)()) F1029_5054;
}

char *(*R4196[31])();
void R4196_init () {
	R4196[0] = (char *(*)()) F999_5062;
	R4196[1] = (char *(*)()) F1000_5062_4196_1;
	R4196[2] = (char *(*)()) F1001_5062_4196_1;
	R4196[3] = (char *(*)()) F1002_5062_4196_1;
	R4196[4] = (char *(*)()) F1003_5062_4196_1;
	R4196[5] = (char *(*)()) F1004_5062_4196_1;
	R4196[6] = (char *(*)()) F1005_5062_4196_1;
	R4196[7] = (char *(*)()) F1006_5062_4196_1;
	R4196[8] = (char *(*)()) F1007_5062_4196_1;
	R4196[9] = (char *(*)()) F1008_5062_4196_1;
	R4196[10] = (char *(*)()) F1009_5062_4196_1;
	R4196[11] = (char *(*)()) F1010_5062_4196_1;
	R4196[12] = (char *(*)()) F1011_5062_4196_1;
	R4196[13] = (char *(*)()) F1012_5062_4196_1;
	R4196[14] = (char *(*)()) F1013_5062_4196_1;
	R4196[15] = (char *(*)()) F1014_5062_4196_1;
	R4196[16] = (char *(*)()) F1015_5062;
	R4196[17] = (char *(*)()) F1016_5062_4196_1;
	R4196[18] = (char *(*)()) F1017_5062_4196_1;
	R4196[19] = (char *(*)()) F1018_5062_4196_1;
	R4196[20] = (char *(*)()) F1019_5062_4196_1;
	R4196[21] = (char *(*)()) F1020_5062_4196_1;
	R4196[22] = (char *(*)()) F1021_5062_4196_1;
	R4196[23] = (char *(*)()) F1022_5062_4196_1;
	R4196[24] = (char *(*)()) F1023_5062_4196_1;
	R4196[25] = (char *(*)()) F1024_5062_4196_1;
	R4196[26] = (char *(*)()) F1025_5062_4196_1;
	R4196[27] = (char *(*)()) F1026_5062_4196_1;
	R4196[28] = (char *(*)()) F1027_5062_4196_1;
	R4196[29] = (char *(*)()) F1028_5062_4196_1;
	R4196[30] = (char *(*)()) F1029_5062_4196_1;
}
static EIF_REFERENCE F1000_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1000_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1101, 0x00).id, 1101, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1001_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F1001_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1071, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1002_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1002_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1003_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1003_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1059, 0x00).id, 1059, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1004_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1004_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1056, 0x00).id, 1056, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1005_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1005_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1053, 0x00).id, 1053, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1006_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1006_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1050, 0x00).id, 1050, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1007_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1007_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1047, 0x00).id, 1047, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1008_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1008_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1044, 0x00).id, 1044, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1009_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1009_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1010_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1010_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1011_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1011_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1032, 0x00).id, 1032, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1012_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1012_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1013_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1013_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1068, 0x00).id, 1068, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1014_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1014_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1016_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F1016_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1073,1101,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1073, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1017_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F1017_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1075,1041,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1075, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1018_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F1018_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1077,1038,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1077, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1019_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F1019_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1079,1035,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1079, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1020_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F1020_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1081,1032,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1081, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1021_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F1021_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1083,1053,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1083, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1022_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F1022_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1085,1047,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1085, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1023_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F1023_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1087,1044,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1087, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1024_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F1024_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1089,1056,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1089, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1025_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F1025_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1091,1065,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1091, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1026_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F1026_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1093,1062,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1093, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1027_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F1027_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1095,1068,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1095, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1028_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F1028_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1097,1050,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1097, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1029_5062_4196_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F1029_5062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1099,1059,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1099, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}

char *(*R4206[31])();
void R4206_init () {
	R4206[0] = (char *(*)()) F999_5074;
	R4206[1] = (char *(*)()) F1000_5074;
	R4206[2] = (char *(*)()) F1001_5074;
	R4206[3] = (char *(*)()) F1002_5074;
	R4206[4] = (char *(*)()) F1003_5074;
	R4206[5] = (char *(*)()) F1004_5074;
	R4206[6] = (char *(*)()) F1005_5074;
	R4206[7] = (char *(*)()) F1006_5074;
	R4206[8] = (char *(*)()) F1007_5074;
	R4206[9] = (char *(*)()) F1008_5074;
	R4206[10] = (char *(*)()) F1009_5074;
	R4206[11] = (char *(*)()) F1010_5074;
	R4206[12] = (char *(*)()) F1011_5074;
	R4206[13] = (char *(*)()) F1012_5074;
	R4206[14] = (char *(*)()) F1013_5074;
	R4206[15] = (char *(*)()) F1014_5074;
	R4206[16] = (char *(*)()) F1015_5074;
	R4206[17] = (char *(*)()) F1016_5074;
	R4206[18] = (char *(*)()) F1017_5074;
	R4206[19] = (char *(*)()) F1018_5074;
	R4206[20] = (char *(*)()) F1019_5074;
	R4206[21] = (char *(*)()) F1020_5074;
	R4206[22] = (char *(*)()) F1021_5074;
	R4206[23] = (char *(*)()) F1022_5074;
	R4206[24] = (char *(*)()) F1023_5074;
	R4206[25] = (char *(*)()) F1024_5074;
	R4206[26] = (char *(*)()) F1025_5074;
	R4206[27] = (char *(*)()) F1026_5074;
	R4206[28] = (char *(*)()) F1027_5074;
	R4206[29] = (char *(*)()) F1028_5074;
	R4206[30] = (char *(*)()) F1029_5074;
}

char *(*R4351[2])();
void R4351_init () {
	R4351[0] = (char *(*)()) F1032_5289;
	R4351[1] = (char *(*)()) F1033_5289;
}

char *(*R4352[2])();
void R4352_init () {
	R4352[0] = (char *(*)()) F1032_5290;
	R4352[1] = (char *(*)()) F1033_5290;
}

char *(*R4355[2])();
void R4355_init () {
	R4355[0] = (char *(*)()) F1032_5293;
	R4355[1] = (char *(*)()) F1033_5293;
}

char *(*R4407[2])();
void R4407_init () {
	R4407[0] = (char *(*)()) F1035_5388;
	R4407[1] = (char *(*)()) F1036_5388;
}

char *(*R4408[2])();
void R4408_init () {
	R4408[0] = (char *(*)()) F1035_5389;
	R4408[1] = (char *(*)()) F1036_5389;
}

char *(*R4409[2])();
void R4409_init () {
	R4409[0] = (char *(*)()) F1035_5390;
	R4409[1] = (char *(*)()) F1036_5390;
}

char *(*R4412[2])();
void R4412_init () {
	R4412[0] = (char *(*)()) F1035_5393;
	R4412[1] = (char *(*)()) F1036_5393;
}

char *(*R4464[2])();
void R4464_init () {
	R4464[0] = (char *(*)()) F1038_5488;
	R4464[1] = (char *(*)()) F1039_5488;
}

char *(*R4467[2])();
void R4467_init () {
	R4467[0] = (char *(*)()) F1038_5491;
	R4467[1] = (char *(*)()) F1039_5491;
}

char *(*R4517[2])();
void R4517_init () {
	R4517[0] = (char *(*)()) F1041_5584;
	R4517[1] = (char *(*)()) F1042_5584;
}

char *(*R4520[2])();
void R4520_init () {
	R4520[0] = (char *(*)()) F1041_5587;
	R4520[1] = (char *(*)()) F1042_5587;
}

char *(*R4523[2])();
void R4523_init () {
	R4523[0] = (char *(*)()) F1041_5590;
	R4523[1] = (char *(*)()) F1042_5590;
}

char *(*R4577[2])();
void R4577_init () {
	R4577[0] = (char *(*)()) F1044_5684;
	R4577[1] = (char *(*)()) F1045_5684;
}

char *(*R4623[2])();
void R4623_init () {
	R4623[0] = (char *(*)()) F1047_5772;
	R4623[1] = (char *(*)()) F1048_5772;
}

char *(*R4624[2])();
void R4624_init () {
	R4624[0] = (char *(*)()) F1047_5773;
	R4624[1] = (char *(*)()) F1048_5773;
}

char *(*R4626[2])();
void R4626_init () {
	R4626[0] = (char *(*)()) F1047_5775;
	R4626[1] = (char *(*)()) F1048_5775;
}

char *(*R4629[2])();
void R4629_init () {
	R4629[0] = (char *(*)()) F1047_5778;
	R4629[1] = (char *(*)()) F1048_5778;
}

char *(*R4630[2])();
void R4630_init () {
	R4630[0] = (char *(*)()) F1047_5779;
	R4630[1] = (char *(*)()) F1048_5779;
}

char *(*R4678[2])();
void R4678_init () {
	R4678[0] = (char *(*)()) F1050_5869;
	R4678[1] = (char *(*)()) F1051_5869;
}

char *(*R4679[2])();
void R4679_init () {
	R4679[0] = (char *(*)()) F1050_5870;
	R4679[1] = (char *(*)()) F1051_5870;
}

char *(*R4682[2])();
void R4682_init () {
	R4682[0] = (char *(*)()) F1050_5873;
	R4682[1] = (char *(*)()) F1051_5873;
}

char *(*R4730[2])();
void R4730_init () {
	R4730[0] = (char *(*)()) F1053_5963;
	R4730[1] = (char *(*)()) F1054_5963;
}

char *(*R4731[2])();
void R4731_init () {
	R4731[0] = (char *(*)()) F1053_5964;
	R4731[1] = (char *(*)()) F1054_5964;
}

char *(*R4732[2])();
void R4732_init () {
	R4732[0] = (char *(*)()) F1053_5965;
	R4732[1] = (char *(*)()) F1054_5965;
}

char *(*R4733[2])();
void R4733_init () {
	R4733[0] = (char *(*)()) F1053_5966;
	R4733[1] = (char *(*)()) F1054_5966;
}

char *(*R4735[2])();
void R4735_init () {
	R4735[0] = (char *(*)()) F1053_5968;
	R4735[1] = (char *(*)()) F1054_5968;
}

char *(*R4781[2])();
void R4781_init () {
	R4781[0] = (char *(*)()) F1056_6026;
	R4781[1] = (char *(*)()) F1057_6026;
}

char *(*R4815[2])();
void R4815_init () {
	R4815[0] = (char *(*)()) F1059_6092;
	R4815[1] = (char *(*)()) F1060_6092;
}

char *(*R4822[2])();
void R4822_init () {
	R4822[0] = (char *(*)()) F1059_6096;
	R4822[1] = (char *(*)()) F1060_6096;
}

char *(*R4836[2])();
void R4836_init () {
	R4836[0] = (char *(*)()) F1062_6150;
	R4836[1] = (char *(*)()) F1063_6150;
}

char *(*R4984[1])();
void R4984_init () {
	R4984[0] = (char *(*)()) F1106_6297_4984_1;
}
static EIF_REFERENCE F1106_6297_4984_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1106_6297(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1068, 0x00).id, 1068, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R4989[1])();
void R4989_init () {
	R4989[0] = (char *(*)()) F1106_6306_4989_491;
}
static EIF_REFERENCE F1106_6306_4989_491 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1106_6306(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1068, 0x00).id, 1068, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y4990_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4990_pgtype2[] = {1068,0xFFFF};
EIF_TYPE_INDEX *Y4990_gen_type [3];
EIF_TYPE_INDEX Y4990 [3];
void Y4990_init (void)
{
	egc_routines_types [4990] = Y4990;
	egc_routines_gen_types [4990] = Y4990_gen_type;
	egc_routines_offset [4990] = 1104;
	Y4990_gen_type [0] = Y4990_pgtype0;
	Y4990_gen_type [1] = Y4990_pgtype1;
	Y4990_gen_type [2] = Y4990_pgtype2;
	Y4990[2] = 1068;
}

char *(*R4991[1104])();
void R4991_init () {
	{long i; for (i = 0; i < 2; i++) R4991[i] = (char *(*)()) F1111_6438;}
	{long i; for (i = 4; i < 6; i++) R4991[i] = (char *(*)()) F1115_6604;}
	{long i; for (i = 1102; i < 1104; i++) R4991[i] = (char *(*)()) F2214_22421;}
}

char *(*R4993[1104])();
void R4993_init () {
	R4993[0] = (char *(*)()) F1112_6498;
	R4993[1] = (char *(*)()) F1113_6520;
	R4993[4] = (char *(*)()) F1116_6665;
	R4993[5] = (char *(*)()) F1117_6688;
	{long i; for (i = 1102; i < 1104; i++) R4993[i] = (char *(*)()) F2214_22549;}
}

char *(*R4994[1104])();
void R4994_init () {
	R4994[0] = (char *(*)()) F1112_6497;
	R4994[1] = (char *(*)()) F1113_6519;
	R4994[4] = (char *(*)()) F1116_6663;
	R4994[5] = (char *(*)()) F1117_6686;
	{long i; for (i = 1102; i < 1104; i++) R4994[i] = (char *(*)()) F1113_6519;}
}


#ifdef __cplusplus
}
#endif
