#include "epoly16.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5005[1104])();
void R5005_init () {
	{long i; for (i = 0; i < 2; i++) R5005[i] = (char *(*)()) F1111_6469;}
	{long i; for (i = 4; i < 6; i++) R5005[i] = (char *(*)()) F1115_6634;}
	{long i; for (i = 1102; i < 1104; i++) R5005[i] = (char *(*)()) F1111_6469;}
}

char *(*R5007[1104])();
void R5007_init () {
	{long i; for (i = 0; i < 2; i++) R5007[i] = (char *(*)()) F1111_6471;}
	{long i; for (i = 4; i < 6; i++) R5007[i] = (char *(*)()) F1115_6636;}
	{long i; for (i = 1102; i < 1104; i++) R5007[i] = (char *(*)()) F1111_6471;}
}

char *(*R5008[1104])();
void R5008_init () {
	R5008[0] = (char *(*)()) F1112_6507;
	R5008[1] = (char *(*)()) F772_3900;
	R5008[4] = (char *(*)()) F1116_6675;
	R5008[5] = (char *(*)()) F773_3900;
	{long i; for (i = 1102; i < 1104; i++) R5008[i] = (char *(*)()) F772_3900;}
}

char *(*R5030[1104])();
void R5030_init () {
	{long i; for (i = 0; i < 2; i++) R5030[i] = (char *(*)()) F1111_6460;}
	{long i; for (i = 4; i < 6; i++) R5030[i] = (char *(*)()) F1115_6625;}
	{long i; for (i = 1102; i < 1104; i++) R5030[i] = (char *(*)()) F2214_22452;}
}

char *(*R5031[1104])();
void R5031_init () {
	{long i; for (i = 0; i < 2; i++) R5031[i] = (char *(*)()) F1111_6459;}
	{long i; for (i = 4; i < 6; i++) R5031[i] = (char *(*)()) F1115_6624;}
	{long i; for (i = 1102; i < 1104; i++) R5031[i] = (char *(*)()) F2214_22454;}
}

char *(*R5036[1104])();
void R5036_init () {
	{long i; for (i = 0; i < 2; i++) R5036[i] = (char *(*)()) F1108_6353;}
	{long i; for (i = 4; i < 6; i++) R5036[i] = (char *(*)()) F1108_6353;}
	{long i; for (i = 1102; i < 1104; i++) R5036[i] = (char *(*)()) F2214_22465;}
}

char *(*R5041[1104])();
void R5041_init () {
	{long i; for (i = 0; i < 2; i++) R5041[i] = (char *(*)()) F1111_6456;}
	{long i; for (i = 1102; i < 1104; i++) R5041[i] = (char *(*)()) F2214_22440;}
}

char *(*R5052[1103])();
void R5052_init () {
	R5052[0] = (char *(*)()) F1113_6586;
	R5052[3] = (char *(*)()) F1116_6670;
	{long i; for (i = 1101; i < 1103; i++) R5052[i] = (char *(*)()) F2214_22509;}
}

char *(*R5053[1103])();
void R5053_init () {
	R5053[0] = (char *(*)()) F1113_6587;
	{long i; for (i = 1101; i < 1103; i++) R5053[i] = (char *(*)()) F2214_22510;}
}

char *(*R5071[1104])();
void R5071_init () {
	R5071[0] = (char *(*)()) F1112_6505;
	R5071[1] = (char *(*)()) F1113_6598;
	R5071[4] = (char *(*)()) F1116_6672;
	R5071[5] = (char *(*)()) F1117_6766;
	{long i; for (i = 1102; i < 1104; i++) R5071[i] = (char *(*)()) F2214_22438;}
}


#ifdef __cplusplus
}
#endif
