#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O1041[2];
void O1041_init () {
	O1041[0] = + _LNGOFF_2_0_0_0_;
	O1041[1] = + _LNGOFF_2_1_0_0_;
}

long O1065[4];
void O1065_init () {
	O1065[0] = 0;
	O1065[1] = + _CHROFF_0_0_;
	O1065[2] = 0;
	O1065[3] = + _CHROFF_1_0_;
}

long O1174[1669];
void O1174_init () {
	O1174[0] = + _CHROFF_0_0_;
	O1174[1668] = + _CHROFF_9_0_;
}

long O1178[1669];
void O1178_init () {
	O1178[0] = + _CHROFF_0_4_;
	O1178[1668] = + _CHROFF_9_4_;
}

long O1262[6];
void O1262_init () {
	O1262[0] = 0;
	O1262[1] = + _LNGOFF_0_0_0_0_;
	O1262[2] = + _I64OFF_0_0_0_0_0_0_0_;
	O1262[3] = + _LNGOFF_0_0_0_0_;
	O1262[4] = 0;
	O1262[5] = + _LNGOFF_1_0_0_0_;
}

long O1763[4];
void O1763_init () {
	O1763[0] = + _CHROFF_2_0_;
	O1763[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O1763[i] = + _CHROFF_2_0_;}
}

long O1764[4];
void O1764_init () {
	O1764[0] = + _CHROFF_2_1_;
	O1764[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O1764[i] = + _CHROFF_2_1_;}
}

long O1841[787];
void O1841_init () {
	O1841[0] = 0;
	O1841[1] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 2; i < 4; i++) O1841[i] = + _CHROFF_0_0_;}
	O1841[4] = + _I64OFF_0_0_0_0_0_0_0_;
	O1841[5] = 0;
	O1841[6] = + _CHROFF_1_0_;
	O1841[7] = + _LNGOFF_1_0_0_0_;
	{long i; for (i = 8; i < 10; i++) O1841[i] = 0;}
	O1841[10] = + _LNGOFF_0_0_0_0_;
	O1841[11] = 0;
	O1841[12] = + _CHROFF_0_0_;
	O1841[786] = + _LNGOFF_0_0_0_0_;
}

long O1846[4];
void O1846_init () {
	O1846[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O1846[i] = 0;}
	O1846[3] =  + _REFACS_1_;
}

long O1855[778];
void O1855_init () {
	O1855[0] =  + _REFACS_1_;
	O1855[1] = + _LNGOFF_0_0_0_1_;
	O1855[2] = + _I64OFF_1_0_0_0_0_0_0_;
	O1855[3] = + _LNGOFF_0_1_0_0_;
	O1855[777] = + _LNGOFF_0_0_0_1_;
}

long O1950[42];
void O1950_init () {
	{long i; for (i = 0; i < 3; i++) O1950[i] = + _LNGOFF_1_3_0_0_;}
	{long i; for (i = 39; i < 41; i++) O1950[i] = + _LNGOFF_2_4_0_0_;}
	O1950[41] = + _LNGOFF_2_5_0_0_;
}

long O1951[42];
void O1951_init () {
	{long i; for (i = 0; i < 3; i++) O1951[i] = + _LNGOFF_1_3_0_1_;}
	{long i; for (i = 39; i < 41; i++) O1951[i] = + _LNGOFF_2_4_0_1_;}
	O1951[41] = + _LNGOFF_2_5_0_1_;
}

long O1952[42];
void O1952_init () {
	{long i; for (i = 0; i < 3; i++) O1952[i] = + _LNGOFF_1_3_0_2_;}
	{long i; for (i = 39; i < 41; i++) O1952[i] = + _LNGOFF_2_4_0_2_;}
	O1952[41] = + _LNGOFF_2_5_0_2_;
}

long O1953[42];
void O1953_init () {
	{long i; for (i = 0; i < 3; i++) O1953[i] = + _LNGOFF_1_3_0_3_;}
	{long i; for (i = 39; i < 41; i++) O1953[i] = + _LNGOFF_2_4_0_3_;}
	O1953[41] = + _LNGOFF_2_5_0_3_;
}

long O1954[42];
void O1954_init () {
	{long i; for (i = 0; i < 3; i++) O1954[i] = + _LNGOFF_1_3_0_4_;}
	{long i; for (i = 39; i < 41; i++) O1954[i] = + _LNGOFF_2_4_0_4_;}
	O1954[41] = + _LNGOFF_2_5_0_4_;
}

long O1955[42];
void O1955_init () {
	{long i; for (i = 0; i < 3; i++) O1955[i] = + _LNGOFF_1_3_0_5_;}
	{long i; for (i = 39; i < 41; i++) O1955[i] = + _LNGOFF_2_4_0_5_;}
	O1955[41] = + _LNGOFF_2_5_0_5_;
}

long O1956[42];
void O1956_init () {
	{long i; for (i = 0; i < 3; i++) O1956[i] = + _CHROFF_1_0_;}
	{long i; for (i = 39; i < 42; i++) O1956[i] = + _CHROFF_2_0_;}
}

long O1961[42];
void O1961_init () {
	{long i; for (i = 0; i < 3; i++) O1961[i] = + _CHROFF_1_1_;}
	{long i; for (i = 39; i < 42; i++) O1961[i] = + _CHROFF_2_1_;}
}

long O2225[1454];
void O2225_init () {
	O2225[0] = + _LNGOFF_4_1_0_0_;
	O2225[1] = + _LNGOFF_5_1_0_0_;
	O2225[802] = + _LNGOFF_4_2_0_0_;
	O2225[862] = + _LNGOFF_7_2_0_0_;
	O2225[1453] = + _LNGOFF_7_3_0_0_;
}

long O2228[1454];
void O2228_init () {
	O2228[0] = + _CHROFF_4_0_;
	O2228[1] = + _CHROFF_5_0_;
	O2228[802] = + _CHROFF_4_0_;
	O2228[862] = + _CHROFF_7_0_;
	O2228[1453] = + _CHROFF_7_0_;
}

static EIF_TYPE_INDEX Y2709_pgtype0[] = {0xFF01,852,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype1[] = {0xFF01,853,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype2[] = {0xFF01,854,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype3[] = {0xFF01,855,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype4[] = {0xFF01,856,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype5[] = {0xFF01,857,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype6[] = {0xFF01,858,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype7[] = {0xFF01,859,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype8[] = {0xFF01,860,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype9[] = {0xFF01,861,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype10[] = {0xFF01,862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype11[] = {0xFF01,863,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype12[] = {0xFF01,864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype13[] = {0xFF01,859,1053,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype14[] = {0xFF01,859,1053,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype15[] = {0xFF01,852,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype16[] = {0xFF01,853,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype17[] = {0xFF01,854,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype18[] = {0xFF01,855,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype19[] = {0xFF01,856,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype20[] = {0xFF01,857,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype21[] = {0xFF01,858,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype22[] = {0xFF01,859,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype23[] = {0xFF01,860,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype24[] = {0xFF01,861,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype25[] = {0xFF01,862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype26[] = {0xFF01,863,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype27[] = {0xFF01,864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype28[] = {0xFF01,852,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype29[] = {0xFF01,853,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype30[] = {0xFF01,856,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype31[] = {0xFF01,855,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype32[] = {0xFF01,857,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype33[] = {0xFF01,861,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype34[] = {0xFF01,854,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype35[] = {0xFF01,852,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype36[] = {0xFF01,853,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype37[] = {0xFF01,854,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype38[] = {0xFF01,855,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype39[] = {0xFF01,856,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype40[] = {0xFF01,857,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype41[] = {0xFF01,858,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype42[] = {0xFF01,859,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype43[] = {0xFF01,860,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype44[] = {0xFF01,861,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype45[] = {0xFF01,862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype46[] = {0xFF01,863,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype47[] = {0xFF01,864,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype48[] = {0xFF01,855,1065,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype49[] = {0xFF01,855,1065,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype50[] = {0xFF01,860,1062,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype51[] = {0xFF01,855,1065,0xFFFF};
static EIF_TYPE_INDEX Y2709_pgtype52[] = {0xFF01,855,1065,0xFFFF};
EIF_TYPE_INDEX *Y2709_gen_type [1868];
EIF_TYPE_INDEX Y2709 [1868];
void Y2709_init (void)
{
	egc_routines_types [2709] = Y2709;
	egc_routines_gen_types [2709] = Y2709_gen_type;
	egc_routines_offset [2709] = 347;
	Y2709_gen_type [0] = Y2709_pgtype0;
	Y2709_gen_type [1] = Y2709_pgtype1;
	Y2709_gen_type [2] = Y2709_pgtype2;
	Y2709_gen_type [3] = Y2709_pgtype3;
	Y2709_gen_type [4] = Y2709_pgtype4;
	Y2709_gen_type [5] = Y2709_pgtype5;
	Y2709_gen_type [6] = Y2709_pgtype6;
	Y2709_gen_type [7] = Y2709_pgtype7;
	Y2709_gen_type [8] = Y2709_pgtype8;
	Y2709_gen_type [9] = Y2709_pgtype9;
	Y2709_gen_type [10] = Y2709_pgtype10;
	Y2709_gen_type [11] = Y2709_pgtype11;
	Y2709_gen_type [12] = Y2709_pgtype12;
	Y2709_gen_type [18] = Y2709_pgtype13;
	Y2709_gen_type [19] = Y2709_pgtype14;
	Y2709_gen_type [532] = Y2709_pgtype15;
	Y2709_gen_type [533] = Y2709_pgtype16;
	Y2709_gen_type [534] = Y2709_pgtype17;
	Y2709_gen_type [535] = Y2709_pgtype18;
	Y2709_gen_type [536] = Y2709_pgtype19;
	Y2709_gen_type [537] = Y2709_pgtype20;
	Y2709_gen_type [538] = Y2709_pgtype21;
	Y2709_gen_type [539] = Y2709_pgtype22;
	Y2709_gen_type [540] = Y2709_pgtype23;
	Y2709_gen_type [541] = Y2709_pgtype24;
	Y2709_gen_type [542] = Y2709_pgtype25;
	Y2709_gen_type [543] = Y2709_pgtype26;
	Y2709_gen_type [544] = Y2709_pgtype27;
	Y2709_gen_type [545] = Y2709_pgtype28;
	Y2709_gen_type [546] = Y2709_pgtype29;
	Y2709_gen_type [547] = Y2709_pgtype30;
	Y2709_gen_type [548] = Y2709_pgtype31;
	Y2709_gen_type [549] = Y2709_pgtype32;
	Y2709_gen_type [550] = Y2709_pgtype33;
	Y2709_gen_type [551] = Y2709_pgtype34;
	Y2709_gen_type [615] = Y2709_pgtype35;
	Y2709_gen_type [616] = Y2709_pgtype36;
	Y2709_gen_type [617] = Y2709_pgtype37;
	Y2709_gen_type [618] = Y2709_pgtype38;
	Y2709_gen_type [619] = Y2709_pgtype39;
	Y2709_gen_type [620] = Y2709_pgtype40;
	Y2709_gen_type [621] = Y2709_pgtype41;
	Y2709_gen_type [622] = Y2709_pgtype42;
	Y2709_gen_type [623] = Y2709_pgtype43;
	Y2709_gen_type [624] = Y2709_pgtype44;
	Y2709_gen_type [625] = Y2709_pgtype45;
	Y2709_gen_type [626] = Y2709_pgtype46;
	Y2709_gen_type [627] = Y2709_pgtype47;
	Y2709_gen_type [765] = Y2709_pgtype48;
	Y2709_gen_type [766] = Y2709_pgtype49;
	Y2709_gen_type [769] = Y2709_pgtype50;
	Y2709_gen_type [1866] = Y2709_pgtype51;
	Y2709_gen_type [1867] = Y2709_pgtype52;
	Y2709[0] = 852;
	Y2709[1] = 853;
	Y2709[2] = 854;
	Y2709[3] = 855;
	Y2709[4] = 856;
	Y2709[5] = 857;
	Y2709[6] = 858;
	Y2709[7] = 859;
	Y2709[8] = 860;
	Y2709[9] = 861;
	Y2709[10] = 862;
	Y2709[11] = 863;
	Y2709[12] = 864;
	{long i; for (i = 18; i < 20; i++) Y2709[i] = 859;};
	Y2709[532] = 852;
	Y2709[533] = 853;
	Y2709[534] = 854;
	Y2709[535] = 855;
	Y2709[536] = 856;
	Y2709[537] = 857;
	Y2709[538] = 858;
	Y2709[539] = 859;
	Y2709[540] = 860;
	Y2709[541] = 861;
	Y2709[542] = 862;
	Y2709[543] = 863;
	Y2709[544] = 864;
	Y2709[545] = 852;
	Y2709[546] = 853;
	Y2709[547] = 856;
	Y2709[548] = 855;
	Y2709[549] = 857;
	Y2709[550] = 861;
	Y2709[551] = 854;
	Y2709[615] = 852;
	Y2709[616] = 853;
	Y2709[617] = 854;
	Y2709[618] = 855;
	Y2709[619] = 856;
	Y2709[620] = 857;
	Y2709[621] = 858;
	Y2709[622] = 859;
	Y2709[623] = 860;
	Y2709[624] = 861;
	Y2709[625] = 862;
	Y2709[626] = 863;
	Y2709[627] = 864;
	{long i; for (i = 765; i < 767; i++) Y2709[i] = 855;};
	Y2709[769] = 860;
	{long i; for (i = 1866; i < 1868; i++) Y2709[i] = 855;};
}


#ifdef __cplusplus
}
#endif
