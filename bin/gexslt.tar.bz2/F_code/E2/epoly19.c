#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O5084[1108];
void O5084_init () {
	{long i; for (i = 0; i < 3; i++) O5084[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O5084[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 5; i < 7; i++) O5084[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 7; i < 9; i++) O5084[i] = + _LNGOFF_1_0_0_1_;}
	O5084[9] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 1106; i < 1108; i++) O5084[i] = + _LNGOFF_1_1_0_1_;}
}

long O5153[1105];
void O5153_init () {
	{long i; for (i = 0; i < 2; i++) O5153[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O5153[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 1103; i < 1105; i++) O5153[i] = + _LNGOFF_1_1_0_2_;}
}

long O5228[3];
void O5228_init () {
	{long i; for (i = 0; i < 2; i++) O5228[i] = + _LNGOFF_1_0_0_2_;}
	O5228[2] = + _LNGOFF_1_1_0_2_;
}

long O6476[1087];
void O6476_init () {
	O6476[0] = + _CHROFF_0_0_;
	O6476[677] = + _CHROFF_1_0_;
	O6476[697] = + _CHROFF_2_0_;
	O6476[698] = + _CHROFF_4_0_;
	O6476[699] = + _CHROFF_3_0_;
	O6476[700] = + _CHROFF_6_0_;
	O6476[710] = + _CHROFF_3_0_;
	O6476[711] = + _CHROFF_4_0_;
	O6476[712] = + _CHROFF_5_0_;
	O6476[713] = + _CHROFF_3_0_;
	O6476[714] = + _CHROFF_4_0_;
	{long i; for (i = 715; i < 720; i++) O6476[i] = + _CHROFF_3_0_;}
	O6476[725] = + _CHROFF_5_0_;
	O6476[744] = + _CHROFF_5_0_;
	O6476[745] = + _CHROFF_7_0_;
	O6476[746] = + _CHROFF_6_0_;
	O6476[747] = + _CHROFF_7_0_;
	{long i; for (i = 748; i < 751; i++) O6476[i] = + _CHROFF_6_0_;}
	O6476[751] = + _CHROFF_11_0_;
	O6476[752] = + _CHROFF_9_0_;
	O6476[753] = + _CHROFF_11_0_;
	{long i; for (i = 754; i < 756; i++) O6476[i] = + _CHROFF_7_0_;}
	{long i; for (i = 756; i < 758; i++) O6476[i] = + _CHROFF_8_0_;}
	{long i; for (i = 758; i < 760; i++) O6476[i] = + _CHROFF_7_0_;}
	{long i; for (i = 760; i < 762; i++) O6476[i] = + _CHROFF_10_0_;}
	{long i; for (i = 762; i < 765; i++) O6476[i] = + _CHROFF_8_0_;}
	O6476[765] = + _CHROFF_7_0_;
	{long i; for (i = 766; i < 774; i++) O6476[i] = + _CHROFF_10_0_;}
	O6476[774] = + _CHROFF_7_0_;
	{long i; for (i = 775; i < 777; i++) O6476[i] = + _CHROFF_8_0_;}
	{long i; for (i = 777; i < 781; i++) O6476[i] = + _CHROFF_7_0_;}
	O6476[781] = + _CHROFF_10_0_;
	O6476[782] = + _CHROFF_9_0_;
	O6476[783] = + _CHROFF_7_0_;
	O6476[784] = + _CHROFF_9_0_;
	O6476[785] = + _CHROFF_8_0_;
	O6476[786] = + _CHROFF_10_0_;
	O6476[787] = + _CHROFF_8_0_;
	{long i; for (i = 788; i < 790; i++) O6476[i] = + _CHROFF_10_0_;}
	O6476[790] = + _CHROFF_9_0_;
	O6476[791] = + _CHROFF_12_0_;
	O6476[792] = + _CHROFF_7_0_;
	O6476[793] = + _CHROFF_10_0_;
	O6476[794] = + _CHROFF_8_0_;
	O6476[795] = + _CHROFF_7_0_;
	O6476[796] = + _CHROFF_9_0_;
	O6476[797] = + _CHROFF_8_0_;
	{long i; for (i = 798; i < 801; i++) O6476[i] = + _CHROFF_7_0_;}
	O6476[801] = + _CHROFF_8_0_;
	{long i; for (i = 802; i < 822; i++) O6476[i] = + _CHROFF_11_0_;}
	O6476[822] = + _CHROFF_13_0_;
	{long i; for (i = 823; i < 835; i++) O6476[i] = + _CHROFF_11_0_;}
	O6476[835] = + _CHROFF_12_0_;
	{long i; for (i = 836; i < 838; i++) O6476[i] = + _CHROFF_11_0_;}
	O6476[838] = + _CHROFF_15_0_;
	{long i; for (i = 839; i < 856; i++) O6476[i] = + _CHROFF_11_0_;}
	O6476[856] = + _CHROFF_14_0_;
	{long i; for (i = 857; i < 875; i++) O6476[i] = + _CHROFF_11_0_;}
	O6476[875] = + _CHROFF_12_0_;
	O6476[876] = + _CHROFF_11_0_;
	{long i; for (i = 877; i < 879; i++) O6476[i] = + _CHROFF_14_0_;}
	{long i; for (i = 879; i < 886; i++) O6476[i] = + _CHROFF_11_0_;}
	O6476[886] = + _CHROFF_12_0_;
	O6476[887] = + _CHROFF_11_0_;
	{long i; for (i = 888; i < 890; i++) O6476[i] = + _CHROFF_12_0_;}
	{long i; for (i = 890; i < 892; i++) O6476[i] = + _CHROFF_11_0_;}
	O6476[892] = + _CHROFF_12_0_;
	O6476[893] = + _CHROFF_16_0_;
	O6476[894] = + _CHROFF_11_0_;
	O6476[895] = + _CHROFF_12_0_;
	O6476[896] = + _CHROFF_11_0_;
	{long i; for (i = 897; i < 899; i++) O6476[i] = + _CHROFF_12_0_;}
	O6476[899] = + _CHROFF_13_0_;
	O6476[900] = + _CHROFF_15_0_;
	{long i; for (i = 901; i < 912; i++) O6476[i] = + _CHROFF_11_0_;}
	{long i; for (i = 912; i < 914; i++) O6476[i] = + _CHROFF_15_0_;}
	{long i; for (i = 914; i < 921; i++) O6476[i] = + _CHROFF_11_0_;}
	{long i; for (i = 921; i < 932; i++) O6476[i] = + _CHROFF_12_0_;}
	{long i; for (i = 932; i < 935; i++) O6476[i] = + _CHROFF_15_0_;}
	{long i; for (i = 935; i < 939; i++) O6476[i] = + _CHROFF_12_0_;}
	{long i; for (i = 939; i < 941; i++) O6476[i] = + _CHROFF_9_0_;}
	O6476[941] = + _CHROFF_10_0_;
	{long i; for (i = 942; i < 944; i++) O6476[i] = + _CHROFF_9_0_;}
	{long i; for (i = 944; i < 948; i++) O6476[i] = + _CHROFF_10_0_;}
	{long i; for (i = 948; i < 957; i++) O6476[i] = + _CHROFF_9_0_;}
	O6476[957] = + _CHROFF_8_0_;
	O6476[958] = + _CHROFF_10_0_;
	O6476[959] = + _CHROFF_9_0_;
	O6476[960] = + _CHROFF_8_0_;
	{long i; for (i = 961; i < 963; i++) O6476[i] = + _CHROFF_9_0_;}
	O6476[963] = + _CHROFF_8_0_;
	{long i; for (i = 964; i < 968; i++) O6476[i] = + _CHROFF_9_0_;}
	O6476[968] = + _CHROFF_8_0_;
	O6476[969] = + _CHROFF_12_0_;
	O6476[970] = + _CHROFF_9_0_;
	O6476[971] = + _CHROFF_8_0_;
	O6476[972] = + _CHROFF_9_0_;
	O6476[973] = + _CHROFF_8_0_;
	O6476[974] = + _CHROFF_10_0_;
	O6476[975] = + _CHROFF_19_0_;
	O6476[976] = + _CHROFF_15_0_;
	{long i; for (i = 977; i < 979; i++) O6476[i] = + _CHROFF_11_0_;}
	{long i; for (i = 979; i < 981; i++) O6476[i] = + _CHROFF_10_0_;}
	O6476[981] = + _CHROFF_11_0_;
	O6476[982] = + _CHROFF_15_0_;
	{long i; for (i = 983; i < 986; i++) O6476[i] = + _CHROFF_9_0_;}
	O6476[986] = + _CHROFF_10_0_;
	{long i; for (i = 987; i < 990; i++) O6476[i] = + _CHROFF_12_0_;}
	O6476[990] = + _CHROFF_13_0_;
	O6476[991] = + _CHROFF_14_0_;
	O6476[992] = + _CHROFF_12_0_;
	O6476[993] = + _CHROFF_13_0_;
	O6476[994] = + _CHROFF_12_0_;
	O6476[995] = + _CHROFF_16_0_;
	O6476[996] = + _CHROFF_12_0_;
	O6476[997] = + _CHROFF_14_0_;
	O6476[998] = + _CHROFF_10_0_;
	{long i; for (i = 999; i < 1001; i++) O6476[i] = + _CHROFF_12_0_;}
	O6476[1001] = + _CHROFF_10_0_;
	O6476[1002] = + _CHROFF_14_0_;
	{long i; for (i = 1003; i < 1005; i++) O6476[i] = + _CHROFF_11_0_;}
	O6476[1007] = + _CHROFF_12_0_;
	{long i; for (i = 1008; i < 1010; i++) O6476[i] = + _CHROFF_10_0_;}
	O6476[1026] = + _CHROFF_9_0_;
	O6476[1086] = + _CHROFF_25_0_;
}

long O6477[1087];
void O6477_init () {
	O6477[0] = + _CHROFF_0_1_;
	O6477[677] = + _CHROFF_1_1_;
	O6477[697] = + _CHROFF_2_1_;
	O6477[698] = + _CHROFF_4_1_;
	O6477[699] = + _CHROFF_3_1_;
	O6477[700] = + _CHROFF_6_1_;
	O6477[710] = + _CHROFF_3_1_;
	O6477[711] = + _CHROFF_4_1_;
	O6477[712] = + _CHROFF_5_1_;
	O6477[713] = + _CHROFF_3_1_;
	O6477[714] = + _CHROFF_4_1_;
	{long i; for (i = 715; i < 720; i++) O6477[i] = + _CHROFF_3_1_;}
	O6477[725] = + _CHROFF_5_1_;
	O6477[744] = + _CHROFF_5_1_;
	O6477[745] = + _CHROFF_7_1_;
	O6477[746] = + _CHROFF_6_1_;
	O6477[747] = + _CHROFF_7_1_;
	{long i; for (i = 748; i < 751; i++) O6477[i] = + _CHROFF_6_1_;}
	O6477[751] = + _CHROFF_11_1_;
	O6477[752] = + _CHROFF_9_1_;
	O6477[753] = + _CHROFF_11_1_;
	{long i; for (i = 754; i < 756; i++) O6477[i] = + _CHROFF_7_1_;}
	{long i; for (i = 756; i < 758; i++) O6477[i] = + _CHROFF_8_1_;}
	{long i; for (i = 758; i < 760; i++) O6477[i] = + _CHROFF_7_1_;}
	{long i; for (i = 760; i < 762; i++) O6477[i] = + _CHROFF_10_1_;}
	{long i; for (i = 762; i < 765; i++) O6477[i] = + _CHROFF_8_1_;}
	O6477[765] = + _CHROFF_7_1_;
	{long i; for (i = 766; i < 774; i++) O6477[i] = + _CHROFF_10_1_;}
	O6477[774] = + _CHROFF_7_1_;
	{long i; for (i = 775; i < 777; i++) O6477[i] = + _CHROFF_8_1_;}
	{long i; for (i = 777; i < 781; i++) O6477[i] = + _CHROFF_7_1_;}
	O6477[781] = + _CHROFF_10_1_;
	O6477[782] = + _CHROFF_9_1_;
	O6477[783] = + _CHROFF_7_1_;
	O6477[784] = + _CHROFF_9_1_;
	O6477[785] = + _CHROFF_8_1_;
	O6477[786] = + _CHROFF_10_1_;
	O6477[787] = + _CHROFF_8_1_;
	{long i; for (i = 788; i < 790; i++) O6477[i] = + _CHROFF_10_1_;}
	O6477[790] = + _CHROFF_9_1_;
	O6477[791] = + _CHROFF_12_1_;
	O6477[792] = + _CHROFF_7_1_;
	O6477[793] = + _CHROFF_10_1_;
	O6477[794] = + _CHROFF_8_1_;
	O6477[795] = + _CHROFF_7_1_;
	O6477[796] = + _CHROFF_9_1_;
	O6477[797] = + _CHROFF_8_1_;
	{long i; for (i = 798; i < 801; i++) O6477[i] = + _CHROFF_7_1_;}
	O6477[801] = + _CHROFF_8_1_;
	{long i; for (i = 802; i < 822; i++) O6477[i] = + _CHROFF_11_1_;}
	O6477[822] = + _CHROFF_13_1_;
	{long i; for (i = 823; i < 835; i++) O6477[i] = + _CHROFF_11_1_;}
	O6477[835] = + _CHROFF_12_1_;
	{long i; for (i = 836; i < 838; i++) O6477[i] = + _CHROFF_11_1_;}
	O6477[838] = + _CHROFF_15_1_;
	{long i; for (i = 839; i < 856; i++) O6477[i] = + _CHROFF_11_1_;}
	O6477[856] = + _CHROFF_14_1_;
	{long i; for (i = 857; i < 875; i++) O6477[i] = + _CHROFF_11_1_;}
	O6477[875] = + _CHROFF_12_1_;
	O6477[876] = + _CHROFF_11_1_;
	{long i; for (i = 877; i < 879; i++) O6477[i] = + _CHROFF_14_1_;}
	{long i; for (i = 879; i < 886; i++) O6477[i] = + _CHROFF_11_1_;}
	O6477[886] = + _CHROFF_12_1_;
	O6477[887] = + _CHROFF_11_1_;
	{long i; for (i = 888; i < 890; i++) O6477[i] = + _CHROFF_12_1_;}
	{long i; for (i = 890; i < 892; i++) O6477[i] = + _CHROFF_11_1_;}
	O6477[892] = + _CHROFF_12_1_;
	O6477[893] = + _CHROFF_16_1_;
	O6477[894] = + _CHROFF_11_1_;
	O6477[895] = + _CHROFF_12_1_;
	O6477[896] = + _CHROFF_11_1_;
	{long i; for (i = 897; i < 899; i++) O6477[i] = + _CHROFF_12_1_;}
	O6477[899] = + _CHROFF_13_1_;
	O6477[900] = + _CHROFF_15_1_;
	{long i; for (i = 901; i < 912; i++) O6477[i] = + _CHROFF_11_1_;}
	{long i; for (i = 912; i < 914; i++) O6477[i] = + _CHROFF_15_1_;}
	{long i; for (i = 914; i < 921; i++) O6477[i] = + _CHROFF_11_1_;}
	{long i; for (i = 921; i < 932; i++) O6477[i] = + _CHROFF_12_1_;}
	{long i; for (i = 932; i < 935; i++) O6477[i] = + _CHROFF_15_1_;}
	{long i; for (i = 935; i < 939; i++) O6477[i] = + _CHROFF_12_1_;}
	{long i; for (i = 939; i < 941; i++) O6477[i] = + _CHROFF_9_1_;}
	O6477[941] = + _CHROFF_10_1_;
	{long i; for (i = 942; i < 944; i++) O6477[i] = + _CHROFF_9_1_;}
	{long i; for (i = 944; i < 948; i++) O6477[i] = + _CHROFF_10_1_;}
	{long i; for (i = 948; i < 957; i++) O6477[i] = + _CHROFF_9_1_;}
	O6477[957] = + _CHROFF_8_1_;
	O6477[958] = + _CHROFF_10_1_;
	O6477[959] = + _CHROFF_9_1_;
	O6477[960] = + _CHROFF_8_1_;
	{long i; for (i = 961; i < 963; i++) O6477[i] = + _CHROFF_9_1_;}
	O6477[963] = + _CHROFF_8_1_;
	{long i; for (i = 964; i < 968; i++) O6477[i] = + _CHROFF_9_1_;}
	O6477[968] = + _CHROFF_8_1_;
	O6477[969] = + _CHROFF_12_1_;
	O6477[970] = + _CHROFF_9_1_;
	O6477[971] = + _CHROFF_8_1_;
	O6477[972] = + _CHROFF_9_1_;
	O6477[973] = + _CHROFF_8_1_;
	O6477[974] = + _CHROFF_10_1_;
	O6477[975] = + _CHROFF_19_1_;
	O6477[976] = + _CHROFF_15_1_;
	{long i; for (i = 977; i < 979; i++) O6477[i] = + _CHROFF_11_1_;}
	{long i; for (i = 979; i < 981; i++) O6477[i] = + _CHROFF_10_1_;}
	O6477[981] = + _CHROFF_11_1_;
	O6477[982] = + _CHROFF_15_1_;
	{long i; for (i = 983; i < 986; i++) O6477[i] = + _CHROFF_9_1_;}
	O6477[986] = + _CHROFF_10_1_;
	{long i; for (i = 987; i < 990; i++) O6477[i] = + _CHROFF_12_1_;}
	O6477[990] = + _CHROFF_13_1_;
	O6477[991] = + _CHROFF_14_1_;
	O6477[992] = + _CHROFF_12_1_;
	O6477[993] = + _CHROFF_13_1_;
	O6477[994] = + _CHROFF_12_1_;
	O6477[995] = + _CHROFF_16_1_;
	O6477[996] = + _CHROFF_12_1_;
	O6477[997] = + _CHROFF_14_1_;
	O6477[998] = + _CHROFF_10_1_;
	{long i; for (i = 999; i < 1001; i++) O6477[i] = + _CHROFF_12_1_;}
	O6477[1001] = + _CHROFF_10_1_;
	O6477[1002] = + _CHROFF_14_1_;
	{long i; for (i = 1003; i < 1005; i++) O6477[i] = + _CHROFF_11_1_;}
	O6477[1007] = + _CHROFF_12_1_;
	{long i; for (i = 1008; i < 1010; i++) O6477[i] = + _CHROFF_10_1_;}
	O6477[1026] = + _CHROFF_9_1_;
	O6477[1086] = + _CHROFF_25_1_;
}

long O6478[1087];
void O6478_init () {
	O6478[0] = + _CHROFF_0_2_;
	O6478[677] = + _CHROFF_1_2_;
	O6478[697] = + _CHROFF_2_2_;
	O6478[698] = + _CHROFF_4_2_;
	O6478[699] = + _CHROFF_3_2_;
	O6478[700] = + _CHROFF_6_2_;
	O6478[710] = + _CHROFF_3_2_;
	O6478[711] = + _CHROFF_4_2_;
	O6478[712] = + _CHROFF_5_2_;
	O6478[713] = + _CHROFF_3_2_;
	O6478[714] = + _CHROFF_4_2_;
	{long i; for (i = 715; i < 720; i++) O6478[i] = + _CHROFF_3_2_;}
	O6478[725] = + _CHROFF_5_2_;
	O6478[744] = + _CHROFF_5_2_;
	O6478[745] = + _CHROFF_7_2_;
	O6478[746] = + _CHROFF_6_2_;
	O6478[747] = + _CHROFF_7_2_;
	{long i; for (i = 748; i < 751; i++) O6478[i] = + _CHROFF_6_2_;}
	O6478[751] = + _CHROFF_11_2_;
	O6478[752] = + _CHROFF_9_2_;
	O6478[753] = + _CHROFF_11_2_;
	{long i; for (i = 754; i < 756; i++) O6478[i] = + _CHROFF_7_2_;}
	{long i; for (i = 756; i < 758; i++) O6478[i] = + _CHROFF_8_2_;}
	{long i; for (i = 758; i < 760; i++) O6478[i] = + _CHROFF_7_2_;}
	{long i; for (i = 760; i < 762; i++) O6478[i] = + _CHROFF_10_2_;}
	{long i; for (i = 762; i < 765; i++) O6478[i] = + _CHROFF_8_2_;}
	O6478[765] = + _CHROFF_7_2_;
	{long i; for (i = 766; i < 774; i++) O6478[i] = + _CHROFF_10_2_;}
	O6478[774] = + _CHROFF_7_2_;
	{long i; for (i = 775; i < 777; i++) O6478[i] = + _CHROFF_8_2_;}
	{long i; for (i = 777; i < 781; i++) O6478[i] = + _CHROFF_7_2_;}
	O6478[781] = + _CHROFF_10_2_;
	O6478[782] = + _CHROFF_9_2_;
	O6478[783] = + _CHROFF_7_2_;
	O6478[784] = + _CHROFF_9_2_;
	O6478[785] = + _CHROFF_8_2_;
	O6478[786] = + _CHROFF_10_2_;
	O6478[787] = + _CHROFF_8_2_;
	{long i; for (i = 788; i < 790; i++) O6478[i] = + _CHROFF_10_2_;}
	O6478[790] = + _CHROFF_9_2_;
	O6478[791] = + _CHROFF_12_2_;
	O6478[792] = + _CHROFF_7_2_;
	O6478[793] = + _CHROFF_10_2_;
	O6478[794] = + _CHROFF_8_2_;
	O6478[795] = + _CHROFF_7_2_;
	O6478[796] = + _CHROFF_9_2_;
	O6478[797] = + _CHROFF_8_2_;
	{long i; for (i = 798; i < 801; i++) O6478[i] = + _CHROFF_7_2_;}
	O6478[801] = + _CHROFF_8_2_;
	{long i; for (i = 802; i < 822; i++) O6478[i] = + _CHROFF_11_2_;}
	O6478[822] = + _CHROFF_13_2_;
	{long i; for (i = 823; i < 835; i++) O6478[i] = + _CHROFF_11_2_;}
	O6478[835] = + _CHROFF_12_2_;
	{long i; for (i = 836; i < 838; i++) O6478[i] = + _CHROFF_11_2_;}
	O6478[838] = + _CHROFF_15_2_;
	{long i; for (i = 839; i < 856; i++) O6478[i] = + _CHROFF_11_2_;}
	O6478[856] = + _CHROFF_14_2_;
	{long i; for (i = 857; i < 875; i++) O6478[i] = + _CHROFF_11_2_;}
	O6478[875] = + _CHROFF_12_2_;
	O6478[876] = + _CHROFF_11_2_;
	{long i; for (i = 877; i < 879; i++) O6478[i] = + _CHROFF_14_2_;}
	{long i; for (i = 879; i < 886; i++) O6478[i] = + _CHROFF_11_2_;}
	O6478[886] = + _CHROFF_12_2_;
	O6478[887] = + _CHROFF_11_2_;
	{long i; for (i = 888; i < 890; i++) O6478[i] = + _CHROFF_12_2_;}
	{long i; for (i = 890; i < 892; i++) O6478[i] = + _CHROFF_11_2_;}
	O6478[892] = + _CHROFF_12_2_;
	O6478[893] = + _CHROFF_16_2_;
	O6478[894] = + _CHROFF_11_2_;
	O6478[895] = + _CHROFF_12_2_;
	O6478[896] = + _CHROFF_11_2_;
	{long i; for (i = 897; i < 899; i++) O6478[i] = + _CHROFF_12_2_;}
	O6478[899] = + _CHROFF_13_2_;
	O6478[900] = + _CHROFF_15_2_;
	{long i; for (i = 901; i < 912; i++) O6478[i] = + _CHROFF_11_2_;}
	{long i; for (i = 912; i < 914; i++) O6478[i] = + _CHROFF_15_2_;}
	{long i; for (i = 914; i < 921; i++) O6478[i] = + _CHROFF_11_2_;}
	{long i; for (i = 921; i < 932; i++) O6478[i] = + _CHROFF_12_2_;}
	{long i; for (i = 932; i < 935; i++) O6478[i] = + _CHROFF_15_2_;}
	{long i; for (i = 935; i < 939; i++) O6478[i] = + _CHROFF_12_2_;}
	{long i; for (i = 939; i < 941; i++) O6478[i] = + _CHROFF_9_2_;}
	O6478[941] = + _CHROFF_10_2_;
	{long i; for (i = 942; i < 944; i++) O6478[i] = + _CHROFF_9_2_;}
	{long i; for (i = 944; i < 948; i++) O6478[i] = + _CHROFF_10_2_;}
	{long i; for (i = 948; i < 957; i++) O6478[i] = + _CHROFF_9_2_;}
	O6478[957] = + _CHROFF_8_2_;
	O6478[958] = + _CHROFF_10_2_;
	O6478[959] = + _CHROFF_9_2_;
	O6478[960] = + _CHROFF_8_2_;
	{long i; for (i = 961; i < 963; i++) O6478[i] = + _CHROFF_9_2_;}
	O6478[963] = + _CHROFF_8_2_;
	{long i; for (i = 964; i < 968; i++) O6478[i] = + _CHROFF_9_2_;}
	O6478[968] = + _CHROFF_8_2_;
	O6478[969] = + _CHROFF_12_2_;
	O6478[970] = + _CHROFF_9_2_;
	O6478[971] = + _CHROFF_8_2_;
	O6478[972] = + _CHROFF_9_2_;
	O6478[973] = + _CHROFF_8_2_;
	O6478[974] = + _CHROFF_10_2_;
	O6478[975] = + _CHROFF_19_2_;
	O6478[976] = + _CHROFF_15_2_;
	{long i; for (i = 977; i < 979; i++) O6478[i] = + _CHROFF_11_2_;}
	{long i; for (i = 979; i < 981; i++) O6478[i] = + _CHROFF_10_2_;}
	O6478[981] = + _CHROFF_11_2_;
	O6478[982] = + _CHROFF_15_2_;
	{long i; for (i = 983; i < 986; i++) O6478[i] = + _CHROFF_9_2_;}
	O6478[986] = + _CHROFF_10_2_;
	{long i; for (i = 987; i < 990; i++) O6478[i] = + _CHROFF_12_2_;}
	O6478[990] = + _CHROFF_13_2_;
	O6478[991] = + _CHROFF_14_2_;
	O6478[992] = + _CHROFF_12_2_;
	O6478[993] = + _CHROFF_13_2_;
	O6478[994] = + _CHROFF_12_2_;
	O6478[995] = + _CHROFF_16_2_;
	O6478[996] = + _CHROFF_12_2_;
	O6478[997] = + _CHROFF_14_2_;
	O6478[998] = + _CHROFF_10_2_;
	{long i; for (i = 999; i < 1001; i++) O6478[i] = + _CHROFF_12_2_;}
	O6478[1001] = + _CHROFF_10_2_;
	O6478[1002] = + _CHROFF_14_2_;
	{long i; for (i = 1003; i < 1005; i++) O6478[i] = + _CHROFF_11_2_;}
	O6478[1007] = + _CHROFF_12_2_;
	{long i; for (i = 1008; i < 1010; i++) O6478[i] = + _CHROFF_10_2_;}
	O6478[1026] = + _CHROFF_9_2_;
	O6478[1086] = + _CHROFF_25_2_;
}

long O6479[1087];
void O6479_init () {
	O6479[0] = + _CHROFF_0_3_;
	O6479[677] = + _CHROFF_1_3_;
	O6479[697] = + _CHROFF_2_3_;
	O6479[698] = + _CHROFF_4_3_;
	O6479[699] = + _CHROFF_3_3_;
	O6479[700] = + _CHROFF_6_3_;
	O6479[710] = + _CHROFF_3_3_;
	O6479[711] = + _CHROFF_4_3_;
	O6479[712] = + _CHROFF_5_3_;
	O6479[713] = + _CHROFF_3_3_;
	O6479[714] = + _CHROFF_4_3_;
	{long i; for (i = 715; i < 720; i++) O6479[i] = + _CHROFF_3_3_;}
	O6479[725] = + _CHROFF_5_3_;
	O6479[744] = + _CHROFF_5_3_;
	O6479[745] = + _CHROFF_7_3_;
	O6479[746] = + _CHROFF_6_3_;
	O6479[747] = + _CHROFF_7_3_;
	{long i; for (i = 748; i < 751; i++) O6479[i] = + _CHROFF_6_3_;}
	O6479[751] = + _CHROFF_11_3_;
	O6479[752] = + _CHROFF_9_3_;
	O6479[753] = + _CHROFF_11_3_;
	{long i; for (i = 754; i < 756; i++) O6479[i] = + _CHROFF_7_3_;}
	{long i; for (i = 756; i < 758; i++) O6479[i] = + _CHROFF_8_3_;}
	{long i; for (i = 758; i < 760; i++) O6479[i] = + _CHROFF_7_3_;}
	{long i; for (i = 760; i < 762; i++) O6479[i] = + _CHROFF_10_3_;}
	{long i; for (i = 762; i < 765; i++) O6479[i] = + _CHROFF_8_3_;}
	O6479[765] = + _CHROFF_7_3_;
	{long i; for (i = 766; i < 774; i++) O6479[i] = + _CHROFF_10_3_;}
	O6479[774] = + _CHROFF_7_3_;
	{long i; for (i = 775; i < 777; i++) O6479[i] = + _CHROFF_8_3_;}
	{long i; for (i = 777; i < 781; i++) O6479[i] = + _CHROFF_7_3_;}
	O6479[781] = + _CHROFF_10_3_;
	O6479[782] = + _CHROFF_9_3_;
	O6479[783] = + _CHROFF_7_3_;
	O6479[784] = + _CHROFF_9_3_;
	O6479[785] = + _CHROFF_8_3_;
	O6479[786] = + _CHROFF_10_3_;
	O6479[787] = + _CHROFF_8_3_;
	{long i; for (i = 788; i < 790; i++) O6479[i] = + _CHROFF_10_3_;}
	O6479[790] = + _CHROFF_9_3_;
	O6479[791] = + _CHROFF_12_3_;
	O6479[792] = + _CHROFF_7_3_;
	O6479[793] = + _CHROFF_10_3_;
	O6479[794] = + _CHROFF_8_3_;
	O6479[795] = + _CHROFF_7_3_;
	O6479[796] = + _CHROFF_9_3_;
	O6479[797] = + _CHROFF_8_3_;
	{long i; for (i = 798; i < 801; i++) O6479[i] = + _CHROFF_7_3_;}
	O6479[801] = + _CHROFF_8_3_;
	{long i; for (i = 802; i < 822; i++) O6479[i] = + _CHROFF_11_3_;}
	O6479[822] = + _CHROFF_13_3_;
	{long i; for (i = 823; i < 835; i++) O6479[i] = + _CHROFF_11_3_;}
	O6479[835] = + _CHROFF_12_3_;
	{long i; for (i = 836; i < 838; i++) O6479[i] = + _CHROFF_11_3_;}
	O6479[838] = + _CHROFF_15_3_;
	{long i; for (i = 839; i < 856; i++) O6479[i] = + _CHROFF_11_3_;}
	O6479[856] = + _CHROFF_14_3_;
	{long i; for (i = 857; i < 875; i++) O6479[i] = + _CHROFF_11_3_;}
	O6479[875] = + _CHROFF_12_3_;
	O6479[876] = + _CHROFF_11_3_;
	{long i; for (i = 877; i < 879; i++) O6479[i] = + _CHROFF_14_3_;}
	{long i; for (i = 879; i < 886; i++) O6479[i] = + _CHROFF_11_3_;}
	O6479[886] = + _CHROFF_12_3_;
	O6479[887] = + _CHROFF_11_3_;
	{long i; for (i = 888; i < 890; i++) O6479[i] = + _CHROFF_12_3_;}
	{long i; for (i = 890; i < 892; i++) O6479[i] = + _CHROFF_11_3_;}
	O6479[892] = + _CHROFF_12_3_;
	O6479[893] = + _CHROFF_16_3_;
	O6479[894] = + _CHROFF_11_3_;
	O6479[895] = + _CHROFF_12_3_;
	O6479[896] = + _CHROFF_11_3_;
	{long i; for (i = 897; i < 899; i++) O6479[i] = + _CHROFF_12_3_;}
	O6479[899] = + _CHROFF_13_3_;
	O6479[900] = + _CHROFF_15_3_;
	{long i; for (i = 901; i < 912; i++) O6479[i] = + _CHROFF_11_3_;}
	{long i; for (i = 912; i < 914; i++) O6479[i] = + _CHROFF_15_3_;}
	{long i; for (i = 914; i < 921; i++) O6479[i] = + _CHROFF_11_3_;}
	{long i; for (i = 921; i < 932; i++) O6479[i] = + _CHROFF_12_3_;}
	{long i; for (i = 932; i < 935; i++) O6479[i] = + _CHROFF_15_3_;}
	{long i; for (i = 935; i < 939; i++) O6479[i] = + _CHROFF_12_3_;}
	{long i; for (i = 939; i < 941; i++) O6479[i] = + _CHROFF_9_3_;}
	O6479[941] = + _CHROFF_10_3_;
	{long i; for (i = 942; i < 944; i++) O6479[i] = + _CHROFF_9_3_;}
	{long i; for (i = 944; i < 948; i++) O6479[i] = + _CHROFF_10_3_;}
	{long i; for (i = 948; i < 957; i++) O6479[i] = + _CHROFF_9_3_;}
	O6479[957] = + _CHROFF_8_3_;
	O6479[958] = + _CHROFF_10_3_;
	O6479[959] = + _CHROFF_9_3_;
	O6479[960] = + _CHROFF_8_3_;
	{long i; for (i = 961; i < 963; i++) O6479[i] = + _CHROFF_9_3_;}
	O6479[963] = + _CHROFF_8_3_;
	{long i; for (i = 964; i < 968; i++) O6479[i] = + _CHROFF_9_3_;}
	O6479[968] = + _CHROFF_8_3_;
	O6479[969] = + _CHROFF_12_3_;
	O6479[970] = + _CHROFF_9_3_;
	O6479[971] = + _CHROFF_8_3_;
	O6479[972] = + _CHROFF_9_3_;
	O6479[973] = + _CHROFF_8_3_;
	O6479[974] = + _CHROFF_10_3_;
	O6479[975] = + _CHROFF_19_3_;
	O6479[976] = + _CHROFF_15_3_;
	{long i; for (i = 977; i < 979; i++) O6479[i] = + _CHROFF_11_3_;}
	{long i; for (i = 979; i < 981; i++) O6479[i] = + _CHROFF_10_3_;}
	O6479[981] = + _CHROFF_11_3_;
	O6479[982] = + _CHROFF_15_3_;
	{long i; for (i = 983; i < 986; i++) O6479[i] = + _CHROFF_9_3_;}
	O6479[986] = + _CHROFF_10_3_;
	{long i; for (i = 987; i < 990; i++) O6479[i] = + _CHROFF_12_3_;}
	O6479[990] = + _CHROFF_13_3_;
	O6479[991] = + _CHROFF_14_3_;
	O6479[992] = + _CHROFF_12_3_;
	O6479[993] = + _CHROFF_13_3_;
	O6479[994] = + _CHROFF_12_3_;
	O6479[995] = + _CHROFF_16_3_;
	O6479[996] = + _CHROFF_12_3_;
	O6479[997] = + _CHROFF_14_3_;
	O6479[998] = + _CHROFF_10_3_;
	{long i; for (i = 999; i < 1001; i++) O6479[i] = + _CHROFF_12_3_;}
	O6479[1001] = + _CHROFF_10_3_;
	O6479[1002] = + _CHROFF_14_3_;
	{long i; for (i = 1003; i < 1005; i++) O6479[i] = + _CHROFF_11_3_;}
	O6479[1007] = + _CHROFF_12_3_;
	{long i; for (i = 1008; i < 1010; i++) O6479[i] = + _CHROFF_10_3_;}
	O6479[1026] = + _CHROFF_9_3_;
	O6479[1086] = + _CHROFF_25_3_;
}

long O6482[1087];
void O6482_init () {
	O6482[0] = + _CHROFF_0_4_;
	O6482[677] = + _CHROFF_1_4_;
	O6482[697] = + _CHROFF_2_4_;
	O6482[698] = + _CHROFF_4_4_;
	O6482[699] = + _CHROFF_3_4_;
	O6482[700] = + _CHROFF_6_4_;
	O6482[710] = + _CHROFF_3_4_;
	O6482[711] = + _CHROFF_4_4_;
	O6482[712] = + _CHROFF_5_4_;
	O6482[713] = + _CHROFF_3_4_;
	O6482[714] = + _CHROFF_4_4_;
	{long i; for (i = 715; i < 720; i++) O6482[i] = + _CHROFF_3_4_;}
	O6482[725] = + _CHROFF_5_4_;
	O6482[744] = + _CHROFF_5_4_;
	O6482[745] = + _CHROFF_7_4_;
	O6482[746] = + _CHROFF_6_4_;
	O6482[747] = + _CHROFF_7_4_;
	{long i; for (i = 748; i < 751; i++) O6482[i] = + _CHROFF_6_4_;}
	O6482[751] = + _CHROFF_11_4_;
	O6482[752] = + _CHROFF_9_4_;
	O6482[753] = + _CHROFF_11_4_;
	{long i; for (i = 754; i < 756; i++) O6482[i] = + _CHROFF_7_4_;}
	{long i; for (i = 756; i < 758; i++) O6482[i] = + _CHROFF_8_4_;}
	{long i; for (i = 758; i < 760; i++) O6482[i] = + _CHROFF_7_4_;}
	{long i; for (i = 760; i < 762; i++) O6482[i] = + _CHROFF_10_4_;}
	{long i; for (i = 762; i < 765; i++) O6482[i] = + _CHROFF_8_4_;}
	O6482[765] = + _CHROFF_7_4_;
	{long i; for (i = 766; i < 774; i++) O6482[i] = + _CHROFF_10_4_;}
	O6482[774] = + _CHROFF_7_4_;
	{long i; for (i = 775; i < 777; i++) O6482[i] = + _CHROFF_8_4_;}
	{long i; for (i = 777; i < 781; i++) O6482[i] = + _CHROFF_7_4_;}
	O6482[781] = + _CHROFF_10_4_;
	O6482[782] = + _CHROFF_9_4_;
	O6482[783] = + _CHROFF_7_4_;
	O6482[784] = + _CHROFF_9_4_;
	O6482[785] = + _CHROFF_8_4_;
	O6482[786] = + _CHROFF_10_4_;
	O6482[787] = + _CHROFF_8_4_;
	{long i; for (i = 788; i < 790; i++) O6482[i] = + _CHROFF_10_4_;}
	O6482[790] = + _CHROFF_9_4_;
	O6482[791] = + _CHROFF_12_4_;
	O6482[792] = + _CHROFF_7_4_;
	O6482[793] = + _CHROFF_10_4_;
	O6482[794] = + _CHROFF_8_4_;
	O6482[795] = + _CHROFF_7_4_;
	O6482[796] = + _CHROFF_9_4_;
	O6482[797] = + _CHROFF_8_4_;
	{long i; for (i = 798; i < 801; i++) O6482[i] = + _CHROFF_7_4_;}
	O6482[801] = + _CHROFF_8_4_;
	{long i; for (i = 802; i < 822; i++) O6482[i] = + _CHROFF_11_4_;}
	O6482[822] = + _CHROFF_13_4_;
	{long i; for (i = 823; i < 835; i++) O6482[i] = + _CHROFF_11_4_;}
	O6482[835] = + _CHROFF_12_4_;
	{long i; for (i = 836; i < 838; i++) O6482[i] = + _CHROFF_11_4_;}
	O6482[838] = + _CHROFF_15_4_;
	{long i; for (i = 839; i < 856; i++) O6482[i] = + _CHROFF_11_4_;}
	O6482[856] = + _CHROFF_14_4_;
	{long i; for (i = 857; i < 875; i++) O6482[i] = + _CHROFF_11_4_;}
	O6482[875] = + _CHROFF_12_4_;
	O6482[876] = + _CHROFF_11_4_;
	{long i; for (i = 877; i < 879; i++) O6482[i] = + _CHROFF_14_4_;}
	{long i; for (i = 879; i < 886; i++) O6482[i] = + _CHROFF_11_4_;}
	O6482[886] = + _CHROFF_12_4_;
	O6482[887] = + _CHROFF_11_4_;
	{long i; for (i = 888; i < 890; i++) O6482[i] = + _CHROFF_12_4_;}
	{long i; for (i = 890; i < 892; i++) O6482[i] = + _CHROFF_11_4_;}
	O6482[892] = + _CHROFF_12_4_;
	O6482[893] = + _CHROFF_16_4_;
	O6482[894] = + _CHROFF_11_4_;
	O6482[895] = + _CHROFF_12_4_;
	O6482[896] = + _CHROFF_11_4_;
	{long i; for (i = 897; i < 899; i++) O6482[i] = + _CHROFF_12_4_;}
	O6482[899] = + _CHROFF_13_4_;
	O6482[900] = + _CHROFF_15_4_;
	{long i; for (i = 901; i < 912; i++) O6482[i] = + _CHROFF_11_4_;}
	{long i; for (i = 912; i < 914; i++) O6482[i] = + _CHROFF_15_4_;}
	{long i; for (i = 914; i < 921; i++) O6482[i] = + _CHROFF_11_4_;}
	{long i; for (i = 921; i < 932; i++) O6482[i] = + _CHROFF_12_4_;}
	{long i; for (i = 932; i < 935; i++) O6482[i] = + _CHROFF_15_4_;}
	{long i; for (i = 935; i < 939; i++) O6482[i] = + _CHROFF_12_4_;}
	{long i; for (i = 939; i < 941; i++) O6482[i] = + _CHROFF_9_4_;}
	O6482[941] = + _CHROFF_10_4_;
	{long i; for (i = 942; i < 944; i++) O6482[i] = + _CHROFF_9_4_;}
	{long i; for (i = 944; i < 948; i++) O6482[i] = + _CHROFF_10_4_;}
	{long i; for (i = 948; i < 957; i++) O6482[i] = + _CHROFF_9_4_;}
	O6482[957] = + _CHROFF_8_4_;
	O6482[958] = + _CHROFF_10_4_;
	O6482[959] = + _CHROFF_9_4_;
	O6482[960] = + _CHROFF_8_4_;
	{long i; for (i = 961; i < 963; i++) O6482[i] = + _CHROFF_9_4_;}
	O6482[963] = + _CHROFF_8_4_;
	{long i; for (i = 964; i < 968; i++) O6482[i] = + _CHROFF_9_4_;}
	O6482[968] = + _CHROFF_8_4_;
	O6482[969] = + _CHROFF_12_4_;
	O6482[970] = + _CHROFF_9_4_;
	O6482[971] = + _CHROFF_8_4_;
	O6482[972] = + _CHROFF_9_4_;
	O6482[973] = + _CHROFF_8_4_;
	O6482[974] = + _CHROFF_10_4_;
	O6482[975] = + _CHROFF_19_4_;
	O6482[976] = + _CHROFF_15_4_;
	{long i; for (i = 977; i < 979; i++) O6482[i] = + _CHROFF_11_4_;}
	{long i; for (i = 979; i < 981; i++) O6482[i] = + _CHROFF_10_4_;}
	O6482[981] = + _CHROFF_11_4_;
	O6482[982] = + _CHROFF_15_4_;
	{long i; for (i = 983; i < 986; i++) O6482[i] = + _CHROFF_9_4_;}
	O6482[986] = + _CHROFF_10_4_;
	{long i; for (i = 987; i < 990; i++) O6482[i] = + _CHROFF_12_4_;}
	O6482[990] = + _CHROFF_13_4_;
	O6482[991] = + _CHROFF_14_4_;
	O6482[992] = + _CHROFF_12_4_;
	O6482[993] = + _CHROFF_13_4_;
	O6482[994] = + _CHROFF_12_4_;
	O6482[995] = + _CHROFF_16_4_;
	O6482[996] = + _CHROFF_12_4_;
	O6482[997] = + _CHROFF_14_4_;
	O6482[998] = + _CHROFF_10_4_;
	{long i; for (i = 999; i < 1001; i++) O6482[i] = + _CHROFF_12_4_;}
	O6482[1001] = + _CHROFF_10_4_;
	O6482[1002] = + _CHROFF_14_4_;
	{long i; for (i = 1003; i < 1005; i++) O6482[i] = + _CHROFF_11_4_;}
	O6482[1007] = + _CHROFF_12_4_;
	{long i; for (i = 1008; i < 1010; i++) O6482[i] = + _CHROFF_10_4_;}
	O6482[1026] = + _CHROFF_9_4_;
	O6482[1086] = + _CHROFF_25_4_;
}

long O6483[1087];
void O6483_init () {
	O6483[0] = + _CHROFF_0_5_;
	O6483[677] = + _CHROFF_1_5_;
	O6483[697] = + _CHROFF_2_5_;
	O6483[698] = + _CHROFF_4_5_;
	O6483[699] = + _CHROFF_3_5_;
	O6483[700] = + _CHROFF_6_5_;
	O6483[710] = + _CHROFF_3_5_;
	O6483[711] = + _CHROFF_4_5_;
	O6483[712] = + _CHROFF_5_5_;
	O6483[713] = + _CHROFF_3_5_;
	O6483[714] = + _CHROFF_4_5_;
	{long i; for (i = 715; i < 720; i++) O6483[i] = + _CHROFF_3_5_;}
	O6483[725] = + _CHROFF_5_5_;
	O6483[744] = + _CHROFF_5_5_;
	O6483[745] = + _CHROFF_7_5_;
	O6483[746] = + _CHROFF_6_5_;
	O6483[747] = + _CHROFF_7_5_;
	{long i; for (i = 748; i < 751; i++) O6483[i] = + _CHROFF_6_5_;}
	O6483[751] = + _CHROFF_11_5_;
	O6483[752] = + _CHROFF_9_5_;
	O6483[753] = + _CHROFF_11_5_;
	{long i; for (i = 754; i < 756; i++) O6483[i] = + _CHROFF_7_5_;}
	{long i; for (i = 756; i < 758; i++) O6483[i] = + _CHROFF_8_5_;}
	{long i; for (i = 758; i < 760; i++) O6483[i] = + _CHROFF_7_5_;}
	{long i; for (i = 760; i < 762; i++) O6483[i] = + _CHROFF_10_5_;}
	{long i; for (i = 762; i < 765; i++) O6483[i] = + _CHROFF_8_5_;}
	O6483[765] = + _CHROFF_7_5_;
	{long i; for (i = 766; i < 774; i++) O6483[i] = + _CHROFF_10_5_;}
	O6483[774] = + _CHROFF_7_5_;
	{long i; for (i = 775; i < 777; i++) O6483[i] = + _CHROFF_8_5_;}
	{long i; for (i = 777; i < 781; i++) O6483[i] = + _CHROFF_7_5_;}
	O6483[781] = + _CHROFF_10_5_;
	O6483[782] = + _CHROFF_9_5_;
	O6483[783] = + _CHROFF_7_5_;
	O6483[784] = + _CHROFF_9_5_;
	O6483[785] = + _CHROFF_8_5_;
	O6483[786] = + _CHROFF_10_5_;
	O6483[787] = + _CHROFF_8_5_;
	{long i; for (i = 788; i < 790; i++) O6483[i] = + _CHROFF_10_5_;}
	O6483[790] = + _CHROFF_9_5_;
	O6483[791] = + _CHROFF_12_5_;
	O6483[792] = + _CHROFF_7_5_;
	O6483[793] = + _CHROFF_10_5_;
	O6483[794] = + _CHROFF_8_5_;
	O6483[795] = + _CHROFF_7_5_;
	O6483[796] = + _CHROFF_9_5_;
	O6483[797] = + _CHROFF_8_5_;
	{long i; for (i = 798; i < 801; i++) O6483[i] = + _CHROFF_7_5_;}
	O6483[801] = + _CHROFF_8_5_;
	{long i; for (i = 802; i < 822; i++) O6483[i] = + _CHROFF_11_5_;}
	O6483[822] = + _CHROFF_13_5_;
	{long i; for (i = 823; i < 835; i++) O6483[i] = + _CHROFF_11_5_;}
	O6483[835] = + _CHROFF_12_5_;
	{long i; for (i = 836; i < 838; i++) O6483[i] = + _CHROFF_11_5_;}
	O6483[838] = + _CHROFF_15_5_;
	{long i; for (i = 839; i < 856; i++) O6483[i] = + _CHROFF_11_5_;}
	O6483[856] = + _CHROFF_14_5_;
	{long i; for (i = 857; i < 875; i++) O6483[i] = + _CHROFF_11_5_;}
	O6483[875] = + _CHROFF_12_5_;
	O6483[876] = + _CHROFF_11_5_;
	{long i; for (i = 877; i < 879; i++) O6483[i] = + _CHROFF_14_5_;}
	{long i; for (i = 879; i < 886; i++) O6483[i] = + _CHROFF_11_5_;}
	O6483[886] = + _CHROFF_12_5_;
	O6483[887] = + _CHROFF_11_5_;
	{long i; for (i = 888; i < 890; i++) O6483[i] = + _CHROFF_12_5_;}
	{long i; for (i = 890; i < 892; i++) O6483[i] = + _CHROFF_11_5_;}
	O6483[892] = + _CHROFF_12_5_;
	O6483[893] = + _CHROFF_16_5_;
	O6483[894] = + _CHROFF_11_5_;
	O6483[895] = + _CHROFF_12_5_;
	O6483[896] = + _CHROFF_11_5_;
	{long i; for (i = 897; i < 899; i++) O6483[i] = + _CHROFF_12_5_;}
	O6483[899] = + _CHROFF_13_5_;
	O6483[900] = + _CHROFF_15_5_;
	{long i; for (i = 901; i < 912; i++) O6483[i] = + _CHROFF_11_5_;}
	{long i; for (i = 912; i < 914; i++) O6483[i] = + _CHROFF_15_5_;}
	{long i; for (i = 914; i < 921; i++) O6483[i] = + _CHROFF_11_5_;}
	{long i; for (i = 921; i < 932; i++) O6483[i] = + _CHROFF_12_5_;}
	{long i; for (i = 932; i < 935; i++) O6483[i] = + _CHROFF_15_5_;}
	{long i; for (i = 935; i < 939; i++) O6483[i] = + _CHROFF_12_5_;}
	{long i; for (i = 939; i < 941; i++) O6483[i] = + _CHROFF_9_5_;}
	O6483[941] = + _CHROFF_10_5_;
	{long i; for (i = 942; i < 944; i++) O6483[i] = + _CHROFF_9_5_;}
	{long i; for (i = 944; i < 948; i++) O6483[i] = + _CHROFF_10_5_;}
	{long i; for (i = 948; i < 957; i++) O6483[i] = + _CHROFF_9_5_;}
	O6483[957] = + _CHROFF_8_5_;
	O6483[958] = + _CHROFF_10_5_;
	O6483[959] = + _CHROFF_9_5_;
	O6483[960] = + _CHROFF_8_5_;
	{long i; for (i = 961; i < 963; i++) O6483[i] = + _CHROFF_9_5_;}
	O6483[963] = + _CHROFF_8_5_;
	{long i; for (i = 964; i < 968; i++) O6483[i] = + _CHROFF_9_5_;}
	O6483[968] = + _CHROFF_8_5_;
	O6483[969] = + _CHROFF_12_5_;
	O6483[970] = + _CHROFF_9_5_;
	O6483[971] = + _CHROFF_8_5_;
	O6483[972] = + _CHROFF_9_5_;
	O6483[973] = + _CHROFF_8_5_;
	O6483[974] = + _CHROFF_10_5_;
	O6483[975] = + _CHROFF_19_5_;
	O6483[976] = + _CHROFF_15_5_;
	{long i; for (i = 977; i < 979; i++) O6483[i] = + _CHROFF_11_5_;}
	{long i; for (i = 979; i < 981; i++) O6483[i] = + _CHROFF_10_5_;}
	O6483[981] = + _CHROFF_11_5_;
	O6483[982] = + _CHROFF_15_5_;
	{long i; for (i = 983; i < 986; i++) O6483[i] = + _CHROFF_9_5_;}
	O6483[986] = + _CHROFF_10_5_;
	{long i; for (i = 987; i < 990; i++) O6483[i] = + _CHROFF_12_5_;}
	O6483[990] = + _CHROFF_13_5_;
	O6483[991] = + _CHROFF_14_5_;
	O6483[992] = + _CHROFF_12_5_;
	O6483[993] = + _CHROFF_13_5_;
	O6483[994] = + _CHROFF_12_5_;
	O6483[995] = + _CHROFF_16_5_;
	O6483[996] = + _CHROFF_12_5_;
	O6483[997] = + _CHROFF_14_5_;
	O6483[998] = + _CHROFF_10_5_;
	{long i; for (i = 999; i < 1001; i++) O6483[i] = + _CHROFF_12_5_;}
	O6483[1001] = + _CHROFF_10_5_;
	O6483[1002] = + _CHROFF_14_5_;
	{long i; for (i = 1003; i < 1005; i++) O6483[i] = + _CHROFF_11_5_;}
	O6483[1007] = + _CHROFF_12_5_;
	{long i; for (i = 1008; i < 1010; i++) O6483[i] = + _CHROFF_10_5_;}
	O6483[1026] = + _CHROFF_9_5_;
	O6483[1086] = + _CHROFF_25_5_;
}

long O6484[1087];
void O6484_init () {
	O6484[0] = + _CHROFF_0_6_;
	O6484[677] = + _CHROFF_1_6_;
	O6484[697] = + _CHROFF_2_6_;
	O6484[698] = + _CHROFF_4_6_;
	O6484[699] = + _CHROFF_3_6_;
	O6484[700] = + _CHROFF_6_6_;
	O6484[710] = + _CHROFF_3_6_;
	O6484[711] = + _CHROFF_4_6_;
	O6484[712] = + _CHROFF_5_6_;
	O6484[713] = + _CHROFF_3_6_;
	O6484[714] = + _CHROFF_4_6_;
	{long i; for (i = 715; i < 720; i++) O6484[i] = + _CHROFF_3_6_;}
	O6484[725] = + _CHROFF_5_6_;
	O6484[744] = + _CHROFF_5_6_;
	O6484[745] = + _CHROFF_7_6_;
	O6484[746] = + _CHROFF_6_6_;
	O6484[747] = + _CHROFF_7_6_;
	{long i; for (i = 748; i < 751; i++) O6484[i] = + _CHROFF_6_6_;}
	O6484[751] = + _CHROFF_11_6_;
	O6484[752] = + _CHROFF_9_6_;
	O6484[753] = + _CHROFF_11_6_;
	{long i; for (i = 754; i < 756; i++) O6484[i] = + _CHROFF_7_6_;}
	{long i; for (i = 756; i < 758; i++) O6484[i] = + _CHROFF_8_6_;}
	{long i; for (i = 758; i < 760; i++) O6484[i] = + _CHROFF_7_6_;}
	{long i; for (i = 760; i < 762; i++) O6484[i] = + _CHROFF_10_6_;}
	{long i; for (i = 762; i < 765; i++) O6484[i] = + _CHROFF_8_6_;}
	O6484[765] = + _CHROFF_7_6_;
	{long i; for (i = 766; i < 774; i++) O6484[i] = + _CHROFF_10_6_;}
	O6484[774] = + _CHROFF_7_6_;
	{long i; for (i = 775; i < 777; i++) O6484[i] = + _CHROFF_8_6_;}
	{long i; for (i = 777; i < 781; i++) O6484[i] = + _CHROFF_7_6_;}
	O6484[781] = + _CHROFF_10_6_;
	O6484[782] = + _CHROFF_9_6_;
	O6484[783] = + _CHROFF_7_6_;
	O6484[784] = + _CHROFF_9_6_;
	O6484[785] = + _CHROFF_8_6_;
	O6484[786] = + _CHROFF_10_6_;
	O6484[787] = + _CHROFF_8_6_;
	{long i; for (i = 788; i < 790; i++) O6484[i] = + _CHROFF_10_6_;}
	O6484[790] = + _CHROFF_9_6_;
	O6484[791] = + _CHROFF_12_6_;
	O6484[792] = + _CHROFF_7_6_;
	O6484[793] = + _CHROFF_10_6_;
	O6484[794] = + _CHROFF_8_6_;
	O6484[795] = + _CHROFF_7_6_;
	O6484[796] = + _CHROFF_9_6_;
	O6484[797] = + _CHROFF_8_6_;
	{long i; for (i = 798; i < 801; i++) O6484[i] = + _CHROFF_7_6_;}
	O6484[801] = + _CHROFF_8_6_;
	{long i; for (i = 802; i < 822; i++) O6484[i] = + _CHROFF_11_6_;}
	O6484[822] = + _CHROFF_13_6_;
	{long i; for (i = 823; i < 835; i++) O6484[i] = + _CHROFF_11_6_;}
	O6484[835] = + _CHROFF_12_6_;
	{long i; for (i = 836; i < 838; i++) O6484[i] = + _CHROFF_11_6_;}
	O6484[838] = + _CHROFF_15_6_;
	{long i; for (i = 839; i < 856; i++) O6484[i] = + _CHROFF_11_6_;}
	O6484[856] = + _CHROFF_14_6_;
	{long i; for (i = 857; i < 875; i++) O6484[i] = + _CHROFF_11_6_;}
	O6484[875] = + _CHROFF_12_6_;
	O6484[876] = + _CHROFF_11_6_;
	{long i; for (i = 877; i < 879; i++) O6484[i] = + _CHROFF_14_6_;}
	{long i; for (i = 879; i < 886; i++) O6484[i] = + _CHROFF_11_6_;}
	O6484[886] = + _CHROFF_12_6_;
	O6484[887] = + _CHROFF_11_6_;
	{long i; for (i = 888; i < 890; i++) O6484[i] = + _CHROFF_12_6_;}
	{long i; for (i = 890; i < 892; i++) O6484[i] = + _CHROFF_11_6_;}
	O6484[892] = + _CHROFF_12_6_;
	O6484[893] = + _CHROFF_16_6_;
	O6484[894] = + _CHROFF_11_6_;
	O6484[895] = + _CHROFF_12_6_;
	O6484[896] = + _CHROFF_11_6_;
	{long i; for (i = 897; i < 899; i++) O6484[i] = + _CHROFF_12_6_;}
	O6484[899] = + _CHROFF_13_6_;
	O6484[900] = + _CHROFF_15_6_;
	{long i; for (i = 901; i < 912; i++) O6484[i] = + _CHROFF_11_6_;}
	{long i; for (i = 912; i < 914; i++) O6484[i] = + _CHROFF_15_6_;}
	{long i; for (i = 914; i < 921; i++) O6484[i] = + _CHROFF_11_6_;}
	{long i; for (i = 921; i < 932; i++) O6484[i] = + _CHROFF_12_6_;}
	{long i; for (i = 932; i < 935; i++) O6484[i] = + _CHROFF_15_6_;}
	{long i; for (i = 935; i < 939; i++) O6484[i] = + _CHROFF_12_6_;}
	{long i; for (i = 939; i < 941; i++) O6484[i] = + _CHROFF_9_6_;}
	O6484[941] = + _CHROFF_10_6_;
	{long i; for (i = 942; i < 944; i++) O6484[i] = + _CHROFF_9_6_;}
	{long i; for (i = 944; i < 948; i++) O6484[i] = + _CHROFF_10_6_;}
	{long i; for (i = 948; i < 957; i++) O6484[i] = + _CHROFF_9_6_;}
	O6484[957] = + _CHROFF_8_6_;
	O6484[958] = + _CHROFF_10_6_;
	O6484[959] = + _CHROFF_9_6_;
	O6484[960] = + _CHROFF_8_6_;
	{long i; for (i = 961; i < 963; i++) O6484[i] = + _CHROFF_9_6_;}
	O6484[963] = + _CHROFF_8_6_;
	{long i; for (i = 964; i < 968; i++) O6484[i] = + _CHROFF_9_6_;}
	O6484[968] = + _CHROFF_8_6_;
	O6484[969] = + _CHROFF_12_6_;
	O6484[970] = + _CHROFF_9_6_;
	O6484[971] = + _CHROFF_8_6_;
	O6484[972] = + _CHROFF_9_6_;
	O6484[973] = + _CHROFF_8_6_;
	O6484[974] = + _CHROFF_10_6_;
	O6484[975] = + _CHROFF_19_6_;
	O6484[976] = + _CHROFF_15_6_;
	{long i; for (i = 977; i < 979; i++) O6484[i] = + _CHROFF_11_6_;}
	{long i; for (i = 979; i < 981; i++) O6484[i] = + _CHROFF_10_6_;}
	O6484[981] = + _CHROFF_11_6_;
	O6484[982] = + _CHROFF_15_6_;
	{long i; for (i = 983; i < 986; i++) O6484[i] = + _CHROFF_9_6_;}
	O6484[986] = + _CHROFF_10_6_;
	{long i; for (i = 987; i < 990; i++) O6484[i] = + _CHROFF_12_6_;}
	O6484[990] = + _CHROFF_13_6_;
	O6484[991] = + _CHROFF_14_6_;
	O6484[992] = + _CHROFF_12_6_;
	O6484[993] = + _CHROFF_13_6_;
	O6484[994] = + _CHROFF_12_6_;
	O6484[995] = + _CHROFF_16_6_;
	O6484[996] = + _CHROFF_12_6_;
	O6484[997] = + _CHROFF_14_6_;
	O6484[998] = + _CHROFF_10_6_;
	{long i; for (i = 999; i < 1001; i++) O6484[i] = + _CHROFF_12_6_;}
	O6484[1001] = + _CHROFF_10_6_;
	O6484[1002] = + _CHROFF_14_6_;
	{long i; for (i = 1003; i < 1005; i++) O6484[i] = + _CHROFF_11_6_;}
	O6484[1007] = + _CHROFF_12_6_;
	{long i; for (i = 1008; i < 1010; i++) O6484[i] = + _CHROFF_10_6_;}
	O6484[1026] = + _CHROFF_9_6_;
	O6484[1086] = + _CHROFF_25_6_;
}

long O6485[1087];
void O6485_init () {
	O6485[0] = + _CHROFF_0_7_;
	O6485[677] = + _CHROFF_1_7_;
	O6485[697] = + _CHROFF_2_7_;
	O6485[698] = + _CHROFF_4_7_;
	O6485[699] = + _CHROFF_3_7_;
	O6485[700] = + _CHROFF_6_7_;
	O6485[710] = + _CHROFF_3_7_;
	O6485[711] = + _CHROFF_4_7_;
	O6485[712] = + _CHROFF_5_7_;
	O6485[713] = + _CHROFF_3_7_;
	O6485[714] = + _CHROFF_4_7_;
	{long i; for (i = 715; i < 720; i++) O6485[i] = + _CHROFF_3_7_;}
	O6485[725] = + _CHROFF_5_7_;
	O6485[744] = + _CHROFF_5_7_;
	O6485[745] = + _CHROFF_7_7_;
	O6485[746] = + _CHROFF_6_7_;
	O6485[747] = + _CHROFF_7_7_;
	{long i; for (i = 748; i < 751; i++) O6485[i] = + _CHROFF_6_7_;}
	O6485[751] = + _CHROFF_11_7_;
	O6485[752] = + _CHROFF_9_7_;
	O6485[753] = + _CHROFF_11_7_;
	{long i; for (i = 754; i < 756; i++) O6485[i] = + _CHROFF_7_7_;}
	{long i; for (i = 756; i < 758; i++) O6485[i] = + _CHROFF_8_7_;}
	{long i; for (i = 758; i < 760; i++) O6485[i] = + _CHROFF_7_7_;}
	{long i; for (i = 760; i < 762; i++) O6485[i] = + _CHROFF_10_7_;}
	{long i; for (i = 762; i < 765; i++) O6485[i] = + _CHROFF_8_7_;}
	O6485[765] = + _CHROFF_7_7_;
	{long i; for (i = 766; i < 774; i++) O6485[i] = + _CHROFF_10_7_;}
	O6485[774] = + _CHROFF_7_7_;
	{long i; for (i = 775; i < 777; i++) O6485[i] = + _CHROFF_8_7_;}
	{long i; for (i = 777; i < 781; i++) O6485[i] = + _CHROFF_7_7_;}
	O6485[781] = + _CHROFF_10_7_;
	O6485[782] = + _CHROFF_9_7_;
	O6485[783] = + _CHROFF_7_7_;
	O6485[784] = + _CHROFF_9_7_;
	O6485[785] = + _CHROFF_8_7_;
	O6485[786] = + _CHROFF_10_7_;
	O6485[787] = + _CHROFF_8_7_;
	{long i; for (i = 788; i < 790; i++) O6485[i] = + _CHROFF_10_7_;}
	O6485[790] = + _CHROFF_9_7_;
	O6485[791] = + _CHROFF_12_7_;
	O6485[792] = + _CHROFF_7_7_;
	O6485[793] = + _CHROFF_10_7_;
	O6485[794] = + _CHROFF_8_7_;
	O6485[795] = + _CHROFF_7_7_;
	O6485[796] = + _CHROFF_9_7_;
	O6485[797] = + _CHROFF_8_7_;
	{long i; for (i = 798; i < 801; i++) O6485[i] = + _CHROFF_7_7_;}
	O6485[801] = + _CHROFF_8_7_;
	{long i; for (i = 802; i < 822; i++) O6485[i] = + _CHROFF_11_7_;}
	O6485[822] = + _CHROFF_13_7_;
	{long i; for (i = 823; i < 835; i++) O6485[i] = + _CHROFF_11_7_;}
	O6485[835] = + _CHROFF_12_7_;
	{long i; for (i = 836; i < 838; i++) O6485[i] = + _CHROFF_11_7_;}
	O6485[838] = + _CHROFF_15_7_;
	{long i; for (i = 839; i < 856; i++) O6485[i] = + _CHROFF_11_7_;}
	O6485[856] = + _CHROFF_14_7_;
	{long i; for (i = 857; i < 875; i++) O6485[i] = + _CHROFF_11_7_;}
	O6485[875] = + _CHROFF_12_7_;
	O6485[876] = + _CHROFF_11_7_;
	{long i; for (i = 877; i < 879; i++) O6485[i] = + _CHROFF_14_7_;}
	{long i; for (i = 879; i < 886; i++) O6485[i] = + _CHROFF_11_7_;}
	O6485[886] = + _CHROFF_12_7_;
	O6485[887] = + _CHROFF_11_7_;
	{long i; for (i = 888; i < 890; i++) O6485[i] = + _CHROFF_12_7_;}
	{long i; for (i = 890; i < 892; i++) O6485[i] = + _CHROFF_11_7_;}
	O6485[892] = + _CHROFF_12_7_;
	O6485[893] = + _CHROFF_16_7_;
	O6485[894] = + _CHROFF_11_7_;
	O6485[895] = + _CHROFF_12_7_;
	O6485[896] = + _CHROFF_11_7_;
	{long i; for (i = 897; i < 899; i++) O6485[i] = + _CHROFF_12_7_;}
	O6485[899] = + _CHROFF_13_7_;
	O6485[900] = + _CHROFF_15_7_;
	{long i; for (i = 901; i < 912; i++) O6485[i] = + _CHROFF_11_7_;}
	{long i; for (i = 912; i < 914; i++) O6485[i] = + _CHROFF_15_7_;}
	{long i; for (i = 914; i < 921; i++) O6485[i] = + _CHROFF_11_7_;}
	{long i; for (i = 921; i < 932; i++) O6485[i] = + _CHROFF_12_7_;}
	{long i; for (i = 932; i < 935; i++) O6485[i] = + _CHROFF_15_7_;}
	{long i; for (i = 935; i < 939; i++) O6485[i] = + _CHROFF_12_7_;}
	{long i; for (i = 939; i < 941; i++) O6485[i] = + _CHROFF_9_7_;}
	O6485[941] = + _CHROFF_10_7_;
	{long i; for (i = 942; i < 944; i++) O6485[i] = + _CHROFF_9_7_;}
	{long i; for (i = 944; i < 948; i++) O6485[i] = + _CHROFF_10_7_;}
	{long i; for (i = 948; i < 957; i++) O6485[i] = + _CHROFF_9_7_;}
	O6485[957] = + _CHROFF_8_7_;
	O6485[958] = + _CHROFF_10_7_;
	O6485[959] = + _CHROFF_9_7_;
	O6485[960] = + _CHROFF_8_7_;
	{long i; for (i = 961; i < 963; i++) O6485[i] = + _CHROFF_9_7_;}
	O6485[963] = + _CHROFF_8_7_;
	{long i; for (i = 964; i < 968; i++) O6485[i] = + _CHROFF_9_7_;}
	O6485[968] = + _CHROFF_8_7_;
	O6485[969] = + _CHROFF_12_7_;
	O6485[970] = + _CHROFF_9_7_;
	O6485[971] = + _CHROFF_8_7_;
	O6485[972] = + _CHROFF_9_7_;
	O6485[973] = + _CHROFF_8_7_;
	O6485[974] = + _CHROFF_10_7_;
	O6485[975] = + _CHROFF_19_7_;
	O6485[976] = + _CHROFF_15_7_;
	{long i; for (i = 977; i < 979; i++) O6485[i] = + _CHROFF_11_7_;}
	{long i; for (i = 979; i < 981; i++) O6485[i] = + _CHROFF_10_7_;}
	O6485[981] = + _CHROFF_11_7_;
	O6485[982] = + _CHROFF_15_7_;
	{long i; for (i = 983; i < 986; i++) O6485[i] = + _CHROFF_9_7_;}
	O6485[986] = + _CHROFF_10_7_;
	{long i; for (i = 987; i < 990; i++) O6485[i] = + _CHROFF_12_7_;}
	O6485[990] = + _CHROFF_13_7_;
	O6485[991] = + _CHROFF_14_7_;
	O6485[992] = + _CHROFF_12_7_;
	O6485[993] = + _CHROFF_13_7_;
	O6485[994] = + _CHROFF_12_7_;
	O6485[995] = + _CHROFF_16_7_;
	O6485[996] = + _CHROFF_12_7_;
	O6485[997] = + _CHROFF_14_7_;
	O6485[998] = + _CHROFF_10_7_;
	{long i; for (i = 999; i < 1001; i++) O6485[i] = + _CHROFF_12_7_;}
	O6485[1001] = + _CHROFF_10_7_;
	O6485[1002] = + _CHROFF_14_7_;
	{long i; for (i = 1003; i < 1005; i++) O6485[i] = + _CHROFF_11_7_;}
	O6485[1007] = + _CHROFF_12_7_;
	{long i; for (i = 1008; i < 1010; i++) O6485[i] = + _CHROFF_10_7_;}
	O6485[1026] = + _CHROFF_9_7_;
	O6485[1086] = + _CHROFF_25_7_;
}


#ifdef __cplusplus
}
#endif
