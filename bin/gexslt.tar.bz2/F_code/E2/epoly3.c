#include "epoly3.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R1675[386])();
void R1675_init () {
	R1675[0] = (char *(*)()) F1167_8587;
	R1675[5] = (char *(*)()) F1172_8692;
	R1675[28] = (char *(*)()) F1195_8931;
	R1675[38] = (char *(*)()) F1205_9099;
	R1675[378] = (char *(*)()) F1545_12523;
	{long i; for (i = 384; i < 386; i++) R1675[i] = (char *(*)()) F1158_8513;}
}

char *(*R1677[386])();
void R1677_init () {
	R1677[0] = (char *(*)()) F1167_8588;
	R1677[5] = (char *(*)()) F1157_8502;
	R1677[28] = (char *(*)()) F1195_8933;
	R1677[38] = (char *(*)()) F1205_9094;
	R1677[378] = (char *(*)()) F1545_12518;
	{long i; for (i = 384; i < 386; i++) R1677[i] = (char *(*)()) F1549_12660;}
}

char *(*R1678[386])();
void R1678_init () {
	R1678[0] = (char *(*)()) F1167_8589_1678_1;
	R1678[5] = (char *(*)()) F1172_8691_1678_1;
	R1678[28] = (char *(*)()) F1195_8934_1678_1;
	R1678[38] = (char *(*)()) F1205_9095_1678_1;
	R1678[378] = (char *(*)()) F1545_12519;
	R1678[384] = (char *(*)()) F1551_12711_1678_1;
	R1678[385] = (char *(*)()) F1552_12717_1678_1;
}
static EIF_REFERENCE F1167_8589_1678_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1167_8589(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1172_8691_1678_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1172_8691(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1195_8934_1678_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1195_8934(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1205_9095_1678_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1205_9095(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1551_12711_1678_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1551_12711(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1552_12717_1678_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1552_12717(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1679[386])();
void R1679_init () {
	R1679[0] = (char *(*)()) F191_1720;
	R1679[5] = (char *(*)()) F1172_8694;
	R1679[28] = (char *(*)()) F191_1720;
	R1679[38] = (char *(*)()) F191_1720;
	R1679[378] = (char *(*)()) F1545_12528;
	{long i; for (i = 384; i < 386; i++) R1679[i] = (char *(*)()) F1550_12700;}
}

char *(*R1839[409])();
void R1839_init () {
	R1839[0] = (char *(*)()) F1744_15474;
	R1839[408] = (char *(*)()) F2152_21381;
}

char *(*R1841[787])();
void R1841_init () {
	R1841[0] = (char *(*)()) F210_1913;
	R1841[1] = (char *(*)()) F211_1913_1841_1;
	R1841[2] = (char *(*)()) F212_1913_1841_1;
	R1841[3] = (char *(*)()) F213_1913_1841_1;
	R1841[4] = (char *(*)()) F214_1913_1841_1;
	R1841[5] = (char *(*)()) F210_1913;
	R1841[6] = (char *(*)()) F213_1913_1841_1;
	R1841[7] = (char *(*)()) F211_1913_1841_1;
	{long i; for (i = 8; i < 10; i++) R1841[i] = (char *(*)()) F210_1913;}
	R1841[10] = (char *(*)()) F211_1913_1841_1;
	R1841[11] = (char *(*)()) F210_1913;
	R1841[12] = (char *(*)()) F212_1913_1841_1;
	R1841[786] = (char *(*)()) F211_1913_1841_1;
}
static EIF_REFERENCE F211_1913_1841_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F211_1913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F212_1913_1841_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F212_1913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1068, 0x00).id, 1068, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F213_1913_1841_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F213_1913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F214_1913_1841_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F214_1913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1032, 0x00).id, 1032, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}

char *(*R1843[787])();
void R1843_init () {
	R1843[0] = (char *(*)()) F210_1915;
	R1843[1] = (char *(*)()) F211_1915_1843_4;
	R1843[2] = (char *(*)()) F212_1915_1843_4;
	R1843[3] = (char *(*)()) F213_1915_1843_4;
	R1843[4] = (char *(*)()) F214_1915_1843_4;
	R1843[5] = (char *(*)()) F210_1915;
	R1843[6] = (char *(*)()) F213_1915_1843_4;
	R1843[7] = (char *(*)()) F211_1915_1843_4;
	{long i; for (i = 8; i < 10; i++) R1843[i] = (char *(*)()) F210_1915;}
	R1843[10] = (char *(*)()) F211_1915_1843_4;
	R1843[11] = (char *(*)()) F210_1915;
	R1843[12] = (char *(*)()) F212_1915_1843_4;
	R1843[786] = (char *(*)()) F211_1915_1843_4;
}
static void F211_1915_1843_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F211_1915(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F212_1915_1843_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F212_1915(Current, *(EIF_BOOLEAN *)arg1);
}
static void F213_1915_1843_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F213_1915(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F214_1915_1843_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F214_1915(Current, *(EIF_INTEGER_64 *)arg1);
}

char *(*R1844[787])();
void R1844_init () {
	R1844[0] = (char *(*)()) F210_1916;
	R1844[1] = (char *(*)()) F211_1916_1844_4;
	R1844[2] = (char *(*)()) F212_1916_1844_4;
	R1844[3] = (char *(*)()) F213_1916_1844_4;
	R1844[4] = (char *(*)()) F214_1916_1844_4;
	R1844[5] = (char *(*)()) F210_1916;
	R1844[6] = (char *(*)()) F213_1916_1844_4;
	R1844[7] = (char *(*)()) F211_1916_1844_4;
	{long i; for (i = 8; i < 10; i++) R1844[i] = (char *(*)()) F210_1916;}
	R1844[10] = (char *(*)()) F211_1916_1844_4;
	R1844[11] = (char *(*)()) F210_1916;
	R1844[12] = (char *(*)()) F212_1916_1844_4;
	R1844[786] = (char *(*)()) F211_1916_1844_4;
}
static void F211_1916_1844_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F211_1916(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F212_1916_1844_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F212_1916(Current, *(EIF_BOOLEAN *)arg1);
}
static void F213_1916_1844_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F213_1916(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F214_1916_1844_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F214_1916(Current, *(EIF_INTEGER_64 *)arg1);
}

char *(*R1847[4])();
void R1847_init () {
	R1847[0] = (char *(*)()) F215_1918;
	R1847[1] = (char *(*)()) F216_1918;
	R1847[2] = (char *(*)()) F217_1918;
	R1847[3] = (char *(*)()) F218_1921;
}

char *(*R1848[4])();
void R1848_init () {
	R1848[0] = (char *(*)()) F215_1919;
	R1848[1] = (char *(*)()) F216_1919;
	R1848[2] = (char *(*)()) F217_1919;
	R1848[3] = (char *(*)()) F215_1919;
}

char *(*R1855[778])();
void R1855_init () {
	R1855[0] = (char *(*)()) F219_1927;
	R1855[1] = (char *(*)()) F220_1927_1855_1;
	R1855[2] = (char *(*)()) F221_1927_1855_1;
	R1855[3] = (char *(*)()) F222_1927_1855_1;
	R1855[777] = (char *(*)()) F220_1927_1855_1;
}
static EIF_REFERENCE F220_1927_1855_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F220_1927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F221_1927_1855_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F221_1927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1032, 0x00).id, 1032, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F222_1927_1855_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F222_1927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R1858[1218])();
void R1858_init () {
	R1858[0] = (char *(*)()) F998_5017;
	R1858[34] = (char *(*)()) F1032_5277_1858_2;
	R1858[35] = (char *(*)()) F1033_5277_1858_2;
	R1858[37] = (char *(*)()) F1035_5376_1858_2;
	R1858[38] = (char *(*)()) F1036_5376_1858_2;
	R1858[40] = (char *(*)()) F1038_5475_1858_2;
	R1858[41] = (char *(*)()) F1039_5475_1858_2;
	R1858[43] = (char *(*)()) F1041_5574_1858_2;
	R1858[44] = (char *(*)()) F1042_5574_1858_2;
	R1858[46] = (char *(*)()) F1044_5669_1858_2;
	R1858[47] = (char *(*)()) F1045_5669_1858_2;
	R1858[49] = (char *(*)()) F1047_5763_1858_2;
	R1858[50] = (char *(*)()) F1048_5763_1858_2;
	R1858[52] = (char *(*)()) F1050_5858_1858_2;
	R1858[53] = (char *(*)()) F1051_5858_1858_2;
	R1858[55] = (char *(*)()) F1053_5953_1858_2;
	R1858[56] = (char *(*)()) F1054_5953_1858_2;
	R1858[58] = (char *(*)()) F1056_6022_1858_2;
	R1858[59] = (char *(*)()) F1057_6022_1858_2;
	R1858[61] = (char *(*)()) F1059_6088_1858_2;
	R1858[62] = (char *(*)()) F1060_6088_1858_2;
	{long i; for (i = 64; i < 66; i++) R1858[i] = (char *(*)()) F1061_6119;}
	{long i; for (i = 67; i < 69; i++) R1858[i] = (char *(*)()) F1064_6159;}
	{long i; for (i = 114; i < 116; i++) R1858[i] = (char *(*)()) F1111_6468;}
	{long i; for (i = 118; i < 120; i++) R1858[i] = (char *(*)()) F1115_6633;}
	R1858[121] = (char *(*)()) F226_1956;
	R1858[141] = (char *(*)()) F1139_8332;
	R1858[156] = (char *(*)()) F1153_8480;
	R1858[616] = (char *(*)()) F1614_13500;
	R1858[618] = (char *(*)()) F1616_13553;
	R1858[622] = (char *(*)()) F1620_13645;
	{long i; for (i = 1216; i < 1218; i++) R1858[i] = (char *(*)()) F2214_22463;}
}
static EIF_BOOLEAN F1032_5277_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1032_5277(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1033_5277_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1033_5277(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1035_5376_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1035_5376(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1036_5376_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1036_5376(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1038_5475_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1038_5475(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1039_5475_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1039_5475(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1041_5574_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1041_5574(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1042_5574_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1042_5574(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1044_5669_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1044_5669(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1045_5669_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1045_5669(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1047_5763_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1047_5763(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1048_5763_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1048_5763(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1050_5858_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1050_5858(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1051_5858_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1051_5858(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1053_5953_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1053_5953(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1054_5953_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1054_5953(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1056_6022_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1056_6022(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1057_6022_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1057_6022(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1059_6088_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1059_6088(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1060_6088_1858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1060_6088(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R1944[976])();
void R1944_init () {
	R1944[0] = (char *(*)()) F231_2043;
	R1944[975] = (char *(*)()) F1206_9112;
}

char *(*R1948[40])();
void R1948_init () {
	R1948[0] = (char *(*)()) F232_2046;
	R1948[39] = (char *(*)()) F271_2230;
}

char *(*R1964[40])();
void R1964_init () {
	R1964[0] = (char *(*)()) F232_2062;
	R1964[39] = (char *(*)()) F271_2237;
}

char *(*R1996[402])();
void R1996_init () {
	R1996[0] = (char *(*)()) F1798_16706;
	{long i; for (i = 400; i < 402; i++) R1996[i] = (char *(*)()) F2195_22125;}
}

char *(*R1998[402])();
void R1998_init () {
	R1998[0] = (char *(*)()) F1798_16710;
	{long i; for (i = 400; i < 402; i++) R1998[i] = (char *(*)()) F2197_22151;}
}

char *(*R2005[3])();
void R2005_init () {
	R2005[0] = (char *(*)()) F1179_8811;
	R2005[1] = (char *(*)()) F1180_8814;
	R2005[2] = (char *(*)()) F1181_8817;
}

char *(*R2011[1294])();
void R2011_init () {
	R2011[0] = (char *(*)()) F253_2117;
	R2011[873] = (char *(*)()) F1126_8126;
	R2011[1291] = (char *(*)()) F1544_12504;
	R2011[1293] = (char *(*)()) F1546_12557;
}

char *(*R2012[1294])();
void R2012_init () {
	R2012[0] = (char *(*)()) F252_2112;
	R2012[873] = (char *(*)()) F252_2112;
	R2012[1291] = (char *(*)()) F1544_12505;
	R2012[1293] = (char *(*)()) F1546_12558;
}


#ifdef __cplusplus
}
#endif
