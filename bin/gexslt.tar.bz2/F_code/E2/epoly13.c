#include "epoly13.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R3435[1336])();
void R3435_init () {
	R3435[0] = (char *(*)()) F798_3913;
	R3435[1] = (char *(*)()) F799_3913;
	R3435[2] = (char *(*)()) F800_3913;
	R3435[3] = (char *(*)()) F801_3913;
	R3435[4] = (char *(*)()) F802_3913;
	R3435[5] = (char *(*)()) F803_3913;
	R3435[6] = (char *(*)()) F804_3913;
	R3435[7] = (char *(*)()) F805_3913;
	R3435[8] = (char *(*)()) F806_3913;
	R3435[9] = (char *(*)()) F807_3913;
	R3435[10] = (char *(*)()) F808_3913;
	R3435[11] = (char *(*)()) F809_3913;
	R3435[12] = (char *(*)()) F810_3913;
	R3435[13] = (char *(*)()) F798_3913;
	R3435[14] = (char *(*)()) F799_3913;
	R3435[15] = (char *(*)()) F802_3913;
	R3435[16] = (char *(*)()) F801_3913;
	R3435[17] = (char *(*)()) F803_3913;
	R3435[18] = (char *(*)()) F807_3913;
	R3435[19] = (char *(*)()) F800_3913;
	R3435[233] = (char *(*)()) F801_3913;
	R3435[237] = (char *(*)()) F806_3913;
	{long i; for (i = 1334; i < 1336; i++) R3435[i] = (char *(*)()) F801_3913;}
}

char *(*R3442[722])();
void R3442_init () {
	R3442[0] = (char *(*)()) F837_3926;
	R3442[413] = (char *(*)()) F839_4207;
	R3442[713] = (char *(*)()) F839_4207;
	R3442[714] = (char *(*)()) F837_3926;
	R3442[718] = (char *(*)()) F839_4207;
	{long i; for (i = 720; i < 722; i++) R3442[i] = (char *(*)()) F837_3926;}
}

char *(*R3467[722])();
void R3467_init () {
	R3467[0] = (char *(*)()) F837_3960;
	R3467[413] = (char *(*)()) F1251_10555;
	{long i; for (i = 713; i < 715; i++) R3467[i] = (char *(*)()) F837_3960;}
	R3467[718] = (char *(*)()) F837_3960;
	{long i; for (i = 720; i < 722; i++) R3467[i] = (char *(*)()) F837_3960;}
}

char *(*R3536[722])();
void R3536_init () {
	R3536[0] = (char *(*)()) F838_4201;
	R3536[413] = (char *(*)()) F837_4084;
	R3536[713] = (char *(*)()) F837_4084;
	R3536[714] = (char *(*)()) F838_4201;
	R3536[718] = (char *(*)()) F837_4084;
	{long i; for (i = 720; i < 722; i++) R3536[i] = (char *(*)()) F838_4201;}
}

char *(*R3537[722])();
void R3537_init () {
	R3537[0] = (char *(*)()) F837_4085;
	R3537[413] = (char *(*)()) F1251_10611;
	{long i; for (i = 713; i < 715; i++) R3537[i] = (char *(*)()) F837_4085;}
	R3537[718] = (char *(*)()) F837_4085;
	{long i; for (i = 720; i < 722; i++) R3537[i] = (char *(*)()) F837_4085;}
}

char *(*R3620[306])();
void R3620_init () {
	R3620[0] = (char *(*)()) F1251_10553;
	R3620[300] = (char *(*)()) F839_4253;
	R3620[305] = (char *(*)()) F839_4253;
}

char *(*R3638[1363])();
void R3638_init () {
	R3638[0] = (char *(*)()) F853_4280;
	R3638[1] = (char *(*)()) F854_4280_3638_40;
	R3638[2] = (char *(*)()) F855_4280_3638_40;
	R3638[3] = (char *(*)()) F856_4280_3638_40;
	R3638[4] = (char *(*)()) F857_4280_3638_40;
	R3638[5] = (char *(*)()) F858_4280_3638_40;
	R3638[6] = (char *(*)()) F859_4280_3638_40;
	R3638[7] = (char *(*)()) F860_4280_3638_40;
	R3638[8] = (char *(*)()) F861_4280_3638_40;
	R3638[9] = (char *(*)()) F862_4280_3638_40;
	R3638[10] = (char *(*)()) F863_4280_3638_40;
	R3638[11] = (char *(*)()) F864_4280_3638_40;
	R3638[12] = (char *(*)()) F865_4280_3638_40;
	R3638[27] = (char *(*)()) F880_4371;
	R3638[28] = (char *(*)()) F881_4371_3638_40;
	R3638[29] = (char *(*)()) F882_4371_3638_40;
	R3638[30] = (char *(*)()) F883_4371_3638_40;
	R3638[31] = (char *(*)()) F884_4371_3638_40;
	R3638[32] = (char *(*)()) F885_4371_3638_40;
	R3638[33] = (char *(*)()) F886_4371_3638_40;
	R3638[34] = (char *(*)()) F887_4371_3638_40;
	R3638[35] = (char *(*)()) F888_4371_3638_40;
	R3638[36] = (char *(*)()) F889_4371_3638_40;
	R3638[37] = (char *(*)()) F890_4371_3638_40;
	R3638[38] = (char *(*)()) F891_4371_3638_40;
	R3638[39] = (char *(*)()) F892_4371_3638_40;
	R3638[40] = (char *(*)()) F880_4371;
	R3638[41] = (char *(*)()) F881_4371_3638_40;
	R3638[42] = (char *(*)()) F884_4371_3638_40;
	R3638[43] = (char *(*)()) F883_4371_3638_40;
	R3638[44] = (char *(*)()) F885_4371_3638_40;
	R3638[45] = (char *(*)()) F889_4371_3638_40;
	R3638[46] = (char *(*)()) F882_4371_3638_40;
	R3638[177] = (char *(*)()) F1030_5075;
	R3638[259] = (char *(*)()) F1112_6495_3638_40;
	R3638[260] = (char *(*)()) F1113_6517_3638_40;
	R3638[263] = (char *(*)()) F1116_6663_3638_40;
	R3638[264] = (char *(*)()) F1117_6686_3638_40;
	{long i; for (i = 1361; i < 1363; i++) R3638[i] = (char *(*)()) F2214_22436_3638_40;}
}
static EIF_REFERENCE F854_4280_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F854_4280(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_4280_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F855_4280(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1044, 0x00).id, 1044, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_4280_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F856_4280(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_4280_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F857_4280(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1068, 0x00).id, 1068, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_4280_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F858_4280(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_4280_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F859_4280(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1050, 0x00).id, 1050, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F860_4280_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F860_4280(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1053, 0x00).id, 1053, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F861_4280_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F861_4280(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F862_4280_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F862_4280(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1047, 0x00).id, 1047, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F863_4280_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F863_4280(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1101, 0x00).id, 1101, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F864_4280_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F864_4280(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1056, 0x00).id, 1056, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F865_4280_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F865_4280(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1059, 0x00).id, 1059, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F881_4371_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F881_4371(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F882_4371_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F882_4371(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1044, 0x00).id, 1044, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F883_4371_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F883_4371(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F884_4371_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F884_4371(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1068, 0x00).id, 1068, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F885_4371_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F885_4371(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F886_4371_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F886_4371(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1050, 0x00).id, 1050, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F887_4371_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F887_4371(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1053, 0x00).id, 1053, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F888_4371_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F888_4371(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F889_4371_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F889_4371(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1047, 0x00).id, 1047, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F890_4371_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F890_4371(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1101, 0x00).id, 1101, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F891_4371_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F891_4371(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1056, 0x00).id, 1056, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F892_4371_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F892_4371(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1059, 0x00).id, 1059, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1112_6495_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1112_6495(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1113_6517_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1113_6517(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1116_6663_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1116_6663(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1117_6686_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1117_6686(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F2214_22436_3638_40 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F2214_22436(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R3639[1363])();
void R3639_init () {
	R3639[0] = (char *(*)()) F853_4288;
	R3639[1] = (char *(*)()) F854_4288;
	R3639[2] = (char *(*)()) F855_4288;
	R3639[3] = (char *(*)()) F856_4288;
	R3639[4] = (char *(*)()) F857_4288;
	R3639[5] = (char *(*)()) F858_4288;
	R3639[6] = (char *(*)()) F859_4288;
	R3639[7] = (char *(*)()) F860_4288;
	R3639[8] = (char *(*)()) F861_4288;
	R3639[9] = (char *(*)()) F862_4288;
	R3639[10] = (char *(*)()) F863_4288;
	R3639[11] = (char *(*)()) F864_4288;
	R3639[12] = (char *(*)()) F865_4288;
	R3639[27] = (char *(*)()) F880_4376;
	R3639[28] = (char *(*)()) F881_4376;
	R3639[29] = (char *(*)()) F882_4376;
	R3639[30] = (char *(*)()) F883_4376;
	R3639[31] = (char *(*)()) F884_4376;
	R3639[32] = (char *(*)()) F885_4376;
	R3639[33] = (char *(*)()) F886_4376;
	R3639[34] = (char *(*)()) F887_4376;
	R3639[35] = (char *(*)()) F888_4376;
	R3639[36] = (char *(*)()) F889_4376;
	R3639[37] = (char *(*)()) F890_4376;
	R3639[38] = (char *(*)()) F891_4376;
	R3639[39] = (char *(*)()) F892_4376;
	R3639[40] = (char *(*)()) F880_4376;
	R3639[41] = (char *(*)()) F881_4376;
	R3639[42] = (char *(*)()) F884_4376;
	R3639[43] = (char *(*)()) F883_4376;
	R3639[44] = (char *(*)()) F885_4376;
	R3639[45] = (char *(*)()) F889_4376;
	R3639[46] = (char *(*)()) F882_4376;
	R3639[123] = (char *(*)()) F976_4709;
	R3639[124] = (char *(*)()) F977_4709;
	R3639[125] = (char *(*)()) F978_4709;
	R3639[126] = (char *(*)()) F979_4709;
	R3639[127] = (char *(*)()) F980_4709;
	R3639[128] = (char *(*)()) F976_4709;
	R3639[129] = (char *(*)()) F978_4709;
	R3639[130] = (char *(*)()) F976_4709;
	R3639[177] = (char *(*)()) F1030_5105;
	{long i; for (i = 259; i < 261; i++) R3639[i] = (char *(*)()) F1111_6462;}
	{long i; for (i = 263; i < 265; i++) R3639[i] = (char *(*)()) F1115_6627;}
	{long i; for (i = 1361; i < 1363; i++) R3639[i] = (char *(*)()) F1111_6462;}
}

EIF_TYPE_INDEX *Y3639_gen_type [1376];
EIF_TYPE_INDEX Y3639 [1376];
void Y3639_init (void)
{
	egc_routines_types [3639] = Y3639;
	egc_routines_gen_types [3639] = Y3639_gen_type;
	egc_routines_offset [3639] = 839;
	{long i; for (i = 0; i < 114; i++) Y3639[i] = 1035;};
	{long i; for (i = 123; i < 144; i++) Y3639[i] = 1035;};
	Y3639[190] = 1035;
	{long i; for (i = 271; i < 278; i++) Y3639[i] = 1035;};
	{long i; for (i = 1374; i < 1376; i++) Y3639[i] = 1035;};
}

char *(*R3640[1363])();
void R3640_init () {
	R3640[0] = (char *(*)()) F853_4289;
	R3640[1] = (char *(*)()) F854_4289;
	R3640[2] = (char *(*)()) F855_4289;
	R3640[3] = (char *(*)()) F856_4289;
	R3640[4] = (char *(*)()) F857_4289;
	R3640[5] = (char *(*)()) F858_4289;
	R3640[6] = (char *(*)()) F859_4289;
	R3640[7] = (char *(*)()) F860_4289;
	R3640[8] = (char *(*)()) F861_4289;
	R3640[9] = (char *(*)()) F862_4289;
	R3640[10] = (char *(*)()) F863_4289;
	R3640[11] = (char *(*)()) F864_4289;
	R3640[12] = (char *(*)()) F865_4289;
	R3640[27] = (char *(*)()) F880_4377;
	R3640[28] = (char *(*)()) F881_4377;
	R3640[29] = (char *(*)()) F882_4377;
	R3640[30] = (char *(*)()) F883_4377;
	R3640[31] = (char *(*)()) F884_4377;
	R3640[32] = (char *(*)()) F885_4377;
	R3640[33] = (char *(*)()) F886_4377;
	R3640[34] = (char *(*)()) F887_4377;
	R3640[35] = (char *(*)()) F888_4377;
	R3640[36] = (char *(*)()) F889_4377;
	R3640[37] = (char *(*)()) F890_4377;
	R3640[38] = (char *(*)()) F891_4377;
	R3640[39] = (char *(*)()) F892_4377;
	R3640[40] = (char *(*)()) F880_4377;
	R3640[41] = (char *(*)()) F881_4377;
	R3640[42] = (char *(*)()) F884_4377;
	R3640[43] = (char *(*)()) F883_4377;
	R3640[44] = (char *(*)()) F885_4377;
	R3640[45] = (char *(*)()) F889_4377;
	R3640[46] = (char *(*)()) F882_4377;
	R3640[123] = (char *(*)()) F976_4710;
	R3640[124] = (char *(*)()) F977_4710;
	R3640[125] = (char *(*)()) F978_4710;
	R3640[126] = (char *(*)()) F979_4710;
	R3640[127] = (char *(*)()) F980_4710;
	R3640[128] = (char *(*)()) F976_4710;
	R3640[129] = (char *(*)()) F978_4710;
	R3640[130] = (char *(*)()) F976_4710;
	R3640[177] = (char *(*)()) F1030_5104;
	{long i; for (i = 259; i < 261; i++) R3640[i] = (char *(*)()) F1111_6460;}
	{long i; for (i = 263; i < 265; i++) R3640[i] = (char *(*)()) F1115_6625;}
	{long i; for (i = 1361; i < 1363; i++) R3640[i] = (char *(*)()) F2214_22452;}
}

char *(*R3643[13])();
void R3643_init () {
	R3643[0] = (char *(*)()) F853_4277;
	R3643[1] = (char *(*)()) F854_4277;
	R3643[2] = (char *(*)()) F855_4277;
	R3643[3] = (char *(*)()) F856_4277;
	R3643[4] = (char *(*)()) F857_4277;
	R3643[5] = (char *(*)()) F858_4277;
	R3643[6] = (char *(*)()) F859_4277;
	R3643[7] = (char *(*)()) F860_4277;
	R3643[8] = (char *(*)()) F861_4277;
	R3643[9] = (char *(*)()) F862_4277;
	R3643[10] = (char *(*)()) F863_4277;
	R3643[11] = (char *(*)()) F864_4277;
	R3643[12] = (char *(*)()) F865_4277;
}


#ifdef __cplusplus
}
#endif
