#include "epoly10.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2923[1727])();
void R2923_init () {
	R2923[0] = (char *(*)()) F375_3208;
	R2923[1] = (char *(*)()) F376_3210;
	R2923[1542] = (char *(*)()) F1917_19016;
	R2923[1714] = (char *(*)()) F2089_20468;
	R2923[1718] = (char *(*)()) F2093_20519;
	R2923[1725] = (char *(*)()) F2100_20632;
	R2923[1726] = (char *(*)()) F2101_20665;
}

char *(*R3012[722])();
void R3012_init () {
	R3012[0] = (char *(*)()) F837_3961;
	R3012[413] = (char *(*)()) F1251_10556;
	{long i; for (i = 713; i < 715; i++) R3012[i] = (char *(*)()) F837_3961;}
	R3012[718] = (char *(*)()) F837_3961;
	{long i; for (i = 720; i < 722; i++) R3012[i] = (char *(*)()) F837_3961;}
}

char *(*R3023[722])();
void R3023_init () {
	R3023[0] = (char *(*)()) F837_4040;
	R3023[413] = (char *(*)()) F1251_10587;
	{long i; for (i = 713; i < 715; i++) R3023[i] = (char *(*)()) F837_4040;}
	R3023[718] = (char *(*)()) F837_4040;
	{long i; for (i = 720; i < 722; i++) R3023[i] = (char *(*)()) F837_4040;}
}

char *(*R3025[722])();
void R3025_init () {
	R3025[0] = (char *(*)()) F837_4035;
	R3025[413] = (char *(*)()) F1251_10579;
	{long i; for (i = 713; i < 715; i++) R3025[i] = (char *(*)()) F837_4035;}
	R3025[718] = (char *(*)()) F837_4035;
	{long i; for (i = 720; i < 722; i++) R3025[i] = (char *(*)()) F837_4035;}
}

char *(*R3027[722])();
void R3027_init () {
	R3027[0] = (char *(*)()) F837_4038;
	R3027[413] = (char *(*)()) F1251_10577;
	{long i; for (i = 713; i < 715; i++) R3027[i] = (char *(*)()) F837_4038;}
	R3027[718] = (char *(*)()) F837_4038;
	{long i; for (i = 720; i < 722; i++) R3027[i] = (char *(*)()) F837_4038;}
}

char *(*R3055[722])();
void R3055_init () {
	R3055[0] = (char *(*)()) F837_4068;
	R3055[413] = (char *(*)()) F1251_10574;
	{long i; for (i = 713; i < 715; i++) R3055[i] = (char *(*)()) F837_4068;}
	R3055[718] = (char *(*)()) F837_4068;
	{long i; for (i = 720; i < 722; i++) R3055[i] = (char *(*)()) F837_4068;}
}

char *(*R3068[722])();
void R3068_init () {
	R3068[0] = (char *(*)()) F837_4075;
	R3068[413] = (char *(*)()) F1251_10568;
	{long i; for (i = 713; i < 715; i++) R3068[i] = (char *(*)()) F837_4075;}
	R3068[718] = (char *(*)()) F837_4075;
	{long i; for (i = 720; i < 722; i++) R3068[i] = (char *(*)()) F837_4075;}
}

char *(*R3136[13])();
void R3136_init () {
	R3136[0] = (char *(*)()) F853_4290;
	R3136[1] = (char *(*)()) F854_4290;
	R3136[2] = (char *(*)()) F855_4290;
	R3136[3] = (char *(*)()) F856_4290;
	R3136[4] = (char *(*)()) F857_4290;
	R3136[5] = (char *(*)()) F858_4290;
	R3136[6] = (char *(*)()) F859_4290;
	R3136[7] = (char *(*)()) F860_4290;
	R3136[8] = (char *(*)()) F861_4290;
	R3136[9] = (char *(*)()) F862_4290;
	R3136[10] = (char *(*)()) F863_4290;
	R3136[11] = (char *(*)()) F864_4290;
	R3136[12] = (char *(*)()) F865_4290;
}

char *(*R3137[13])();
void R3137_init () {
	R3137[0] = (char *(*)()) F853_4291;
	R3137[1] = (char *(*)()) F854_4291;
	R3137[2] = (char *(*)()) F855_4291;
	R3137[3] = (char *(*)()) F856_4291;
	R3137[4] = (char *(*)()) F857_4291;
	R3137[5] = (char *(*)()) F858_4291;
	R3137[6] = (char *(*)()) F859_4291;
	R3137[7] = (char *(*)()) F860_4291;
	R3137[8] = (char *(*)()) F861_4291;
	R3137[9] = (char *(*)()) F862_4291;
	R3137[10] = (char *(*)()) F863_4291;
	R3137[11] = (char *(*)()) F864_4291;
	R3137[12] = (char *(*)()) F865_4291;
}

char *(*R3185[717])();
void R3185_init () {
	R3185[0] = (char *(*)()) F1032_5283_3185_1;
	R3185[1] = (char *(*)()) F1033_5283_3185_1;
	R3185[3] = (char *(*)()) F1035_5382_3185_1;
	R3185[4] = (char *(*)()) F1036_5382_3185_1;
	R3185[6] = (char *(*)()) F1038_5481_3185_1;
	R3185[7] = (char *(*)()) F1039_5481_3185_1;
	R3185[9] = (char *(*)()) F1041_5580_3185_1;
	R3185[10] = (char *(*)()) F1042_5580_3185_1;
	R3185[27] = (char *(*)()) F1059_6103_3185_1;
	R3185[28] = (char *(*)()) F1060_6103_3185_1;
	R3185[716] = (char *(*)()) F1748_15573;
}
static EIF_REFERENCE F1032_5283_3185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1032_5283(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1032, 0x00).id, 1032, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1033_5283_3185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1033_5283(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1032, 0x00).id, 1032, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1035_5382_3185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1035_5382(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1036_5382_3185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1036_5382(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1038_5481_3185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1038_5481(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1039_5481_3185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1039_5481(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1041_5580_3185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1041_5580(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1042_5580_3185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1042_5580(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1059_6103_3185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1059_6103(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1059, 0x00).id, 1059, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1060_6103_3185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1060_6103(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1059, 0x00).id, 1059, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R3186[833])();
void R3186_init () {
	R3186[0] = (char *(*)()) F557_3743;
	R3186[1] = (char *(*)()) F558_3743;
	R3186[2] = (char *(*)()) F559_3743_3186_1;
	R3186[3] = (char *(*)()) F560_3743_3186_1;
	R3186[4] = (char *(*)()) F561_3743_3186_1;
	R3186[803] = (char *(*)()) F1307_11343;
	R3186[804] = (char *(*)()) F1308_11343_3186_1;
	R3186[805] = (char *(*)()) F1312_11343_3186_1;
	R3186[818] = (char *(*)()) F1307_11343;
	R3186[819] = (char *(*)()) F1308_11343_3186_1;
	R3186[820] = (char *(*)()) F1307_11343;
	R3186[821] = (char *(*)()) F1310_11343_3186_1;
	R3186[822] = (char *(*)()) F1308_11343_3186_1;
	R3186[823] = (char *(*)()) F1311_11343_3186_1;
	R3186[827] = (char *(*)()) F1307_11343;
	R3186[828] = (char *(*)()) F1308_11343_3186_1;
	R3186[829] = (char *(*)()) F1311_11343_3186_1;
	R3186[830] = (char *(*)()) F1387_11451;
	R3186[831] = (char *(*)()) F1388_11451_3186_1;
	R3186[832] = (char *(*)()) F1387_11451;
}
static EIF_REFERENCE F559_3743_3186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F559_3743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F560_3743_3186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F560_3743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F561_3743_3186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F561_3743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1101, 0x00).id, 1101, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1308_11343_3186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1308_11343(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1312_11343_3186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1312_11343(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1310_11343_3186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1310_11343(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1044, 0x00).id, 1044, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1311_11343_3186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1311_11343(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1068, 0x00).id, 1068, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1388_11451_3186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1388_11451(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3187[833])();
void R3187_init () {
	R3187[0] = (char *(*)()) F557_3746;
	R3187[1] = (char *(*)()) F558_3746;
	R3187[2] = (char *(*)()) F559_3746;
	R3187[3] = (char *(*)()) F560_3746;
	R3187[4] = (char *(*)()) F561_3746;
	R3187[212] = (char *(*)()) F768_3872;
	R3187[803] = (char *(*)()) F1347_11391;
	R3187[804] = (char *(*)()) F1351_11391;
	R3187[805] = (char *(*)()) F1353_11391;
	R3187[818] = (char *(*)()) F1347_11391;
	R3187[819] = (char *(*)()) F1348_11391;
	R3187[820] = (char *(*)()) F1349_11391;
	R3187[821] = (char *(*)()) F1350_11391;
	R3187[822] = (char *(*)()) F1351_11391;
	R3187[823] = (char *(*)()) F1352_11391;
	R3187[827] = (char *(*)()) F1384_11438;
	R3187[828] = (char *(*)()) F1385_11438;
	R3187[829] = (char *(*)()) F1386_11438;
	R3187[830] = (char *(*)()) F1387_11453;
	R3187[831] = (char *(*)()) F1388_11453;
	R3187[832] = (char *(*)()) F1387_11453;
}

char *(*R3188[833])();
void R3188_init () {
	R3188[0] = (char *(*)()) F557_3747;
	R3188[1] = (char *(*)()) F558_3747;
	R3188[2] = (char *(*)()) F559_3747;
	R3188[3] = (char *(*)()) F560_3747;
	R3188[4] = (char *(*)()) F561_3747;
	R3188[212] = (char *(*)()) F768_3878;
	R3188[803] = (char *(*)()) F1320_11364;
	R3188[804] = (char *(*)()) F1321_11364;
	R3188[805] = (char *(*)()) F1325_11364;
	R3188[818] = (char *(*)()) F1320_11364;
	R3188[819] = (char *(*)()) F1321_11364;
	R3188[820] = (char *(*)()) F1320_11364;
	R3188[821] = (char *(*)()) F1323_11364;
	R3188[822] = (char *(*)()) F1321_11364;
	R3188[823] = (char *(*)()) F1324_11364;
	R3188[827] = (char *(*)()) F1320_11364;
	R3188[828] = (char *(*)()) F1321_11364;
	R3188[829] = (char *(*)()) F1324_11364;
	R3188[830] = (char *(*)()) F1320_11364;
	R3188[831] = (char *(*)()) F1321_11364;
	R3188[832] = (char *(*)()) F1320_11364;
}

char *(*R3199[5])();
void R3199_init () {
	R3199[0] = (char *(*)()) F557_3744;
	R3199[1] = (char *(*)()) F558_3744_3199_1;
	R3199[2] = (char *(*)()) F559_3744;
	R3199[3] = (char *(*)()) F560_3744_3199_1;
	R3199[4] = (char *(*)()) F561_3744;
}
static EIF_REFERENCE F558_3744_3199_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F558_3744(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F560_3744_3199_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F560_3744(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3206[108])();
void R3206_init () {
	R3206[0] = (char *(*)()) F1681_14306;
	R3206[1] = (char *(*)()) F1682_14312;
	R3206[2] = (char *(*)()) F1683_14319;
	R3206[3] = (char *(*)()) F1684_14328;
	R3206[4] = (char *(*)()) F1685_14334;
	R3206[5] = (char *(*)()) F1686_14340;
	R3206[12] = (char *(*)()) F1693_14407;
	R3206[107] = (char *(*)()) F1788_16592;
}

char *(*R3207[108])();
void R3207_init () {
	{long i; for (i = 0; i < 2; i++) R3207[i] = (char *(*)()) F455_3555;}
	R3207[2] = (char *(*)()) F1683_14320;
	{long i; for (i = 3; i < 6; i++) R3207[i] = (char *(*)()) F455_3555;}
	R3207[12] = (char *(*)()) F455_3555;
	R3207[107] = (char *(*)()) F455_3555;
}

char *(*R3234[1114])();
void R3234_init () {
	R3234[0] = (char *(*)()) F464_3582;
	R3234[1] = (char *(*)()) F465_3582_3234_3;
	R3234[2] = (char *(*)()) F466_3582_3234_3;
	R3234[3] = (char *(*)()) F467_3582_3234_3;
	R3234[4] = (char *(*)()) F468_3582_3234_3;
	R3234[5] = (char *(*)()) F469_3582_3234_3;
	R3234[6] = (char *(*)()) F470_3583;
	R3234[7] = (char *(*)()) F471_3584;
	R3234[8] = (char *(*)()) F472_3585;
	R3234[10] = (char *(*)()) F474_3587;
	R3234[29] = (char *(*)()) F492_3629_3234_3;
	R3234[705] = (char *(*)()) F1169_8613;
	R3234[732] = (char *(*)()) F1196_8944;
	R3234[745] = (char *(*)()) F492_3629_3234_3;
	R3234[1113] = (char *(*)()) F491_3629;
}
static EIF_BOOLEAN F465_3582_3234_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F465_3582(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F466_3582_3234_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F466_3582(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static EIF_BOOLEAN F467_3582_3234_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F467_3582(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_NATURAL_64 *)arg2);
}
static EIF_BOOLEAN F468_3582_3234_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F468_3582(Current, *(EIF_BOOLEAN *)arg1, *(EIF_BOOLEAN *)arg2);
}
static EIF_BOOLEAN F469_3582_3234_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F469_3582(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_CHARACTER_8 *)arg2);
}
static EIF_BOOLEAN F492_3629_3234_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F492_3629(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}


#ifdef __cplusplus
}
#endif
