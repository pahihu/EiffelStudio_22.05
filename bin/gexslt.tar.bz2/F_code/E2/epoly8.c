#include "epoly8.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2234[704])();
void R2234_init () {
	R2234[0] = (char *(*)()) F1414_11679;
	R2234[646] = (char *(*)()) F2060_20132;
	R2234[647] = (char *(*)()) F2061_20144;
	R2234[648] = (char *(*)()) F2062_20160;
	R2234[698] = (char *(*)()) F2111_20800;
	{long i; for (i = 700; i < 704; i++) R2234[i] = (char *(*)()) F2111_20800;}
}

char *(*R2236[704])();
void R2236_init () {
	R2236[0] = (char *(*)()) F1414_11681;
	{long i; for (i = 646; i < 649; i++) R2236[i] = (char *(*)()) F2059_20114;}
	R2236[698] = (char *(*)()) F2111_20802;
	{long i; for (i = 700; i < 704; i++) R2236[i] = (char *(*)()) F2111_20802;}
}

char *(*R2238[704])();
void R2238_init () {
	R2238[0] = (char *(*)()) F1414_11682;
	{long i; for (i = 646; i < 649; i++) R2238[i] = (char *(*)()) F2059_20118;}
	R2238[698] = (char *(*)()) F2111_20808;
	{long i; for (i = 700; i < 702; i++) R2238[i] = (char *(*)()) F2114_20833;}
	{long i; for (i = 702; i < 704; i++) R2238[i] = (char *(*)()) F2111_20808;}
}

char *(*R2239[704])();
void R2239_init () {
	R2239[0] = (char *(*)()) F1414_11683;
	{long i; for (i = 646; i < 649; i++) R2239[i] = (char *(*)()) F2059_20121;}
	R2239[698] = (char *(*)()) F2112_20829;
	R2239[700] = (char *(*)()) F2114_20836;
	R2239[701] = (char *(*)()) F2115_20845;
	{long i; for (i = 702; i < 704; i++) R2239[i] = (char *(*)()) F2116_20848;}
}

char *(*R2325[1878])();
void R2325_init () {
	R2325[0] = (char *(*)()) F333_2587;
	R2325[1729] = (char *(*)()) F2062_20172;
	R2325[1765] = (char *(*)()) F2098_20582;
	R2325[1766] = (char *(*)()) F2099_20606;
	R2325[1767] = (char *(*)()) F2100_20629;
	R2325[1768] = (char *(*)()) F2101_20663;
	R2325[1769] = (char *(*)()) F2102_20682;
	R2325[1770] = (char *(*)()) F2103_20700;
	R2325[1771] = (char *(*)()) F2104_20719;
	R2325[1772] = (char *(*)()) F2105_20733;
	R2325[1773] = (char *(*)()) F2106_20749;
	R2325[1774] = (char *(*)()) F2107_20769;
	R2325[1775] = (char *(*)()) F2108_20774;
	R2325[1777] = (char *(*)()) F2109_20791;
	R2325[1779] = (char *(*)()) F2112_20828;
	{long i; for (i = 1781; i < 1783; i++) R2325[i] = (char *(*)()) F2114_20835;}
	R2325[1783] = (char *(*)()) F2116_20847;
	R2325[1784] = (char *(*)()) F2117_20852;
	R2325[1786] = (char *(*)()) F2118_20866;
	R2325[1787] = (char *(*)()) F2120_20898;
	R2325[1788] = (char *(*)()) F2118_20866;
	R2325[1790] = (char *(*)()) F2123_20939;
	R2325[1791] = (char *(*)()) F2124_20955;
	R2325[1792] = (char *(*)()) F2125_20966;
	R2325[1793] = (char *(*)()) F2126_20977;
	R2325[1794] = (char *(*)()) F2127_20993;
	R2325[1795] = (char *(*)()) F2128_21008;
	R2325[1797] = (char *(*)()) F2130_21015;
	R2325[1798] = (char *(*)()) F2131_21032;
	R2325[1799] = (char *(*)()) F2132_21049;
	R2325[1800] = (char *(*)()) F2133_21052;
	R2325[1877] = (char *(*)()) F2210_22248;
}

char *(*R2707[1850])();
void R2707_init () {
	R2707[0] = (char *(*)()) F355_2986;
	R2707[514] = (char *(*)()) F348_2986;
	R2707[515] = (char *(*)()) F349_2986;
	R2707[516] = (char *(*)()) F350_2986;
	R2707[517] = (char *(*)()) F351_2986;
	R2707[518] = (char *(*)()) F352_2986;
	R2707[519] = (char *(*)()) F353_2986;
	R2707[520] = (char *(*)()) F354_2986;
	R2707[521] = (char *(*)()) F355_2986;
	R2707[522] = (char *(*)()) F356_2986;
	R2707[523] = (char *(*)()) F357_2986;
	R2707[524] = (char *(*)()) F358_2986;
	R2707[525] = (char *(*)()) F359_2986;
	R2707[526] = (char *(*)()) F360_2986;
	R2707[527] = (char *(*)()) F348_2986;
	R2707[528] = (char *(*)()) F349_2986;
	R2707[529] = (char *(*)()) F352_2986;
	R2707[530] = (char *(*)()) F351_2986;
	R2707[531] = (char *(*)()) F353_2986;
	R2707[532] = (char *(*)()) F357_2986;
	R2707[533] = (char *(*)()) F350_2986;
	R2707[747] = (char *(*)()) F351_2986;
	R2707[751] = (char *(*)()) F356_2986;
	{long i; for (i = 1848; i < 1850; i++) R2707[i] = (char *(*)()) F351_2986;}
}

char *(*R2708[1850])();
void R2708_init () {
	R2708[0] = (char *(*)()) F355_2987_2708_31;
	R2708[514] = (char *(*)()) F348_2987;
	R2708[515] = (char *(*)()) F349_2987_2708_31;
	R2708[516] = (char *(*)()) F350_2987_2708_31;
	R2708[517] = (char *(*)()) F351_2987_2708_31;
	R2708[518] = (char *(*)()) F352_2987_2708_31;
	R2708[519] = (char *(*)()) F353_2987_2708_31;
	R2708[520] = (char *(*)()) F354_2987_2708_31;
	R2708[521] = (char *(*)()) F355_2987_2708_31;
	R2708[522] = (char *(*)()) F356_2987_2708_31;
	R2708[523] = (char *(*)()) F357_2987_2708_31;
	R2708[524] = (char *(*)()) F358_2987_2708_31;
	R2708[525] = (char *(*)()) F359_2987_2708_31;
	R2708[526] = (char *(*)()) F360_2987_2708_31;
	R2708[527] = (char *(*)()) F348_2987;
	R2708[528] = (char *(*)()) F349_2987_2708_31;
	R2708[529] = (char *(*)()) F352_2987_2708_31;
	R2708[530] = (char *(*)()) F351_2987_2708_31;
	R2708[531] = (char *(*)()) F353_2987_2708_31;
	R2708[532] = (char *(*)()) F357_2987_2708_31;
	R2708[533] = (char *(*)()) F350_2987_2708_31;
	R2708[747] = (char *(*)()) F351_2987_2708_31;
	R2708[751] = (char *(*)()) F356_2987_2708_31;
	{long i; for (i = 1848; i < 1850; i++) R2708[i] = (char *(*)()) F351_2987_2708_31;}
}
static void F355_2987_2708_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F355_2987(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F349_2987_2708_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F349_2987(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F350_2987_2708_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F350_2987(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F351_2987_2708_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F351_2987(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F352_2987_2708_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F352_2987(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F353_2987_2708_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F353_2987(Current, *(EIF_INTEGER_8 *)arg1, arg2);
}
static void F354_2987_2708_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F354_2987(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F356_2987_2708_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F356_2987(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F357_2987_2708_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F357_2987(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F358_2987_2708_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F358_2987(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F359_2987_2708_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F359_2987(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F360_2987_2708_31 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F360_2987(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R2714[1850])();
void R2714_init () {
	R2714[0] = (char *(*)()) F355_2993;
	R2714[514] = (char *(*)()) F348_2993;
	R2714[515] = (char *(*)()) F349_2993;
	R2714[516] = (char *(*)()) F350_2993;
	R2714[517] = (char *(*)()) F351_2993;
	R2714[518] = (char *(*)()) F352_2993;
	R2714[519] = (char *(*)()) F353_2993;
	R2714[520] = (char *(*)()) F354_2993;
	R2714[521] = (char *(*)()) F355_2993;
	R2714[522] = (char *(*)()) F356_2993;
	R2714[523] = (char *(*)()) F357_2993;
	R2714[524] = (char *(*)()) F358_2993;
	R2714[525] = (char *(*)()) F359_2993;
	R2714[526] = (char *(*)()) F360_2993;
	R2714[527] = (char *(*)()) F348_2993;
	R2714[528] = (char *(*)()) F349_2993;
	R2714[529] = (char *(*)()) F352_2993;
	R2714[530] = (char *(*)()) F351_2993;
	R2714[531] = (char *(*)()) F353_2993;
	R2714[532] = (char *(*)()) F357_2993;
	R2714[533] = (char *(*)()) F350_2993;
	R2714[747] = (char *(*)()) F351_2993;
	R2714[751] = (char *(*)()) F356_2993;
	{long i; for (i = 1848; i < 1850; i++) R2714[i] = (char *(*)()) F351_2993;}
}


#ifdef __cplusplus
}
#endif
