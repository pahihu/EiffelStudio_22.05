#include "epoly1.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R11[2214])();
void R11_init () {
	R11[0] = (char *(*)()) F1_8;
	R11[2] = (char *(*)()) F1_8;
	{long i; for (i = 5; i < 12; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 13; i < 17; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 18; i < 31; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 32; i < 39; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 43; i < 50; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 52; i < 55; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 68; i < 71; i++) R11[i] = (char *(*)()) F1_8;}
	R11[78] = (char *(*)()) F1_8;
	{long i; for (i = 89; i < 93; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 101; i < 106; i++) R11[i] = (char *(*)()) F1_8;}
	R11[110] = (char *(*)()) F1_8;
	R11[122] = (char *(*)()) F1_8;
	R11[130] = (char *(*)()) F1_8;
	{long i; for (i = 135; i < 141; i++) R11[i] = (char *(*)()) F1_8;}
	R11[160] = (char *(*)()) F1_8;
	R11[164] = (char *(*)()) F1_8;
	{long i; for (i = 172; i < 176; i++) R11[i] = (char *(*)()) F1_8;}
	R11[178] = (char *(*)()) F1_8;
	R11[184] = (char *(*)()) F1_8;
	R11[195] = (char *(*)()) F1_8;
	{long i; for (i = 197; i < 199; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 200; i < 203; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 208; i < 221; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 225; i < 227; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 229; i < 231; i++) R11[i] = (char *(*)()) F1_8;}
	R11[251] = (char *(*)()) F1_8;
	R11[255] = (char *(*)()) F1_8;
	R11[259] = (char *(*)()) F1_8;
	R11[267] = (char *(*)()) F1_8;
	R11[269] = (char *(*)()) F1_8;
	{long i; for (i = 273; i < 278; i++) R11[i] = (char *(*)()) F1_8;}
	R11[280] = (char *(*)()) F1_8;
	{long i; for (i = 282; i < 285; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 286; i < 289; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 290; i < 292; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 294; i < 296; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 297; i < 300; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 301; i < 305; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 306; i < 308; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 309; i < 315; i++) R11[i] = (char *(*)()) F1_8;}
	R11[322] = (char *(*)()) F1_8;
	R11[326] = (char *(*)()) F1_8;
	R11[331] = (char *(*)()) F1_8;
	R11[335] = (char *(*)()) F337_2605;
	R11[337] = (char *(*)()) F1_8;
	R11[341] = (char *(*)()) F1_8;
	R11[360] = (char *(*)()) F1_8;
	R11[362] = (char *(*)()) F364_3014;
	R11[363] = (char *(*)()) F1_8;
	R11[364] = (char *(*)()) F366_3100;
	{long i; for (i = 373; i < 375; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 379; i < 381; i++) R11[i] = (char *(*)()) F1_8;}
	R11[459] = (char *(*)()) F1_8;
	{long i; for (i = 462; i < 471; i++) R11[i] = (char *(*)()) F1_8;}
	R11[472] = (char *(*)()) F1_8;
	{long i; for (i = 474; i < 476; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 481; i < 484; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 487; i < 489; i++) R11[i] = (char *(*)()) F1_8;}
	R11[491] = (char *(*)()) F1_8;
	R11[505] = (char *(*)()) F1_8;
	R11[508] = (char *(*)()) F1_8;
	{long i; for (i = 555; i < 560; i++) R11[i] = (char *(*)()) F1_8;}
	R11[767] = (char *(*)()) F1_8;
	R11[836] = (char *(*)()) F1_8;
	{long i; for (i = 851; i < 864; i++) R11[i] = (char *(*)()) F1_8;}
	R11[878] = (char *(*)()) F880_4381;
	R11[879] = (char *(*)()) F881_4381;
	R11[880] = (char *(*)()) F882_4381;
	R11[881] = (char *(*)()) F883_4381;
	R11[882] = (char *(*)()) F884_4381;
	R11[883] = (char *(*)()) F885_4381;
	R11[884] = (char *(*)()) F886_4381;
	R11[885] = (char *(*)()) F887_4381;
	R11[886] = (char *(*)()) F888_4381;
	R11[887] = (char *(*)()) F889_4381;
	R11[888] = (char *(*)()) F890_4381;
	R11[889] = (char *(*)()) F891_4381;
	R11[890] = (char *(*)()) F892_4381;
	R11[891] = (char *(*)()) F880_4381;
	R11[892] = (char *(*)()) F881_4381;
	R11[893] = (char *(*)()) F884_4381;
	R11[894] = (char *(*)()) F883_4381;
	R11[895] = (char *(*)()) F885_4381;
	R11[896] = (char *(*)()) F889_4381;
	R11[897] = (char *(*)()) F882_4381;
	{long i; for (i = 954; i < 956; i++) R11[i] = (char *(*)()) F1_8;}
	R11[958] = (char *(*)()) F1_8;
	R11[974] = (char *(*)()) F976_4711;
	R11[975] = (char *(*)()) F977_4711;
	R11[976] = (char *(*)()) F978_4711;
	R11[977] = (char *(*)()) F979_4711;
	R11[978] = (char *(*)()) F980_4711;
	R11[979] = (char *(*)()) F981_4805;
	R11[980] = (char *(*)()) F982_4805;
	R11[981] = (char *(*)()) F976_4711;
	R11[990] = (char *(*)()) F1_8;
	{long i; for (i = 994; i < 996; i++) R11[i] = (char *(*)()) F1_8;}
	R11[996] = (char *(*)()) F998_5018;
	R11[997] = (char *(*)()) F999_5055;
	R11[998] = (char *(*)()) F1000_5055;
	R11[999] = (char *(*)()) F1001_5055;
	R11[1000] = (char *(*)()) F1002_5055;
	R11[1001] = (char *(*)()) F1003_5055;
	R11[1002] = (char *(*)()) F1004_5055;
	R11[1003] = (char *(*)()) F1005_5055;
	R11[1004] = (char *(*)()) F1006_5055;
	R11[1005] = (char *(*)()) F1007_5055;
	R11[1006] = (char *(*)()) F1008_5055;
	R11[1007] = (char *(*)()) F1009_5055;
	R11[1008] = (char *(*)()) F1010_5055;
	R11[1009] = (char *(*)()) F1011_5055;
	R11[1010] = (char *(*)()) F1012_5055;
	R11[1011] = (char *(*)()) F1013_5055;
	R11[1012] = (char *(*)()) F1014_5055;
	R11[1013] = (char *(*)()) F1015_5055;
	R11[1014] = (char *(*)()) F1016_5055;
	R11[1015] = (char *(*)()) F1017_5055;
	R11[1016] = (char *(*)()) F1018_5055;
	R11[1017] = (char *(*)()) F1019_5055;
	R11[1018] = (char *(*)()) F1020_5055;
	R11[1019] = (char *(*)()) F1021_5055;
	R11[1020] = (char *(*)()) F1022_5055;
	R11[1021] = (char *(*)()) F1023_5055;
	R11[1022] = (char *(*)()) F1024_5055;
	R11[1023] = (char *(*)()) F1025_5055;
	R11[1024] = (char *(*)()) F1026_5055;
	R11[1025] = (char *(*)()) F1027_5055;
	R11[1026] = (char *(*)()) F1028_5055;
	R11[1027] = (char *(*)()) F1029_5055;
	R11[1028] = (char *(*)()) F1030_5098;
	{long i; for (i = 1030; i < 1032; i++) R11[i] = (char *(*)()) F1031_5216;}
	{long i; for (i = 1033; i < 1035; i++) R11[i] = (char *(*)()) F1034_5314;}
	{long i; for (i = 1036; i < 1038; i++) R11[i] = (char *(*)()) F1037_5413;}
	{long i; for (i = 1039; i < 1041; i++) R11[i] = (char *(*)()) F1040_5512;}
	{long i; for (i = 1042; i < 1044; i++) R11[i] = (char *(*)()) F1043_5611;}
	{long i; for (i = 1045; i < 1047; i++) R11[i] = (char *(*)()) F1046_5705;}
	{long i; for (i = 1048; i < 1050; i++) R11[i] = (char *(*)()) F1049_5799;}
	{long i; for (i = 1051; i < 1053; i++) R11[i] = (char *(*)()) F1052_5894;}
	{long i; for (i = 1054; i < 1056; i++) R11[i] = (char *(*)()) F1055_5993;}
	{long i; for (i = 1057; i < 1059; i++) R11[i] = (char *(*)()) F1058_6059;}
	{long i; for (i = 1060; i < 1062; i++) R11[i] = (char *(*)()) F1061_6120;}
	{long i; for (i = 1063; i < 1065; i++) R11[i] = (char *(*)()) F1064_6160;}
	{long i; for (i = 1066; i < 1068; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1069; i < 1101; i++) R11[i] = (char *(*)()) F1070_6226;}
	R11[1102] = (char *(*)()) F1103_6263;
	R11[1105] = (char *(*)()) F1106_6301;
	{long i; for (i = 1110; i < 1112; i++) R11[i] = (char *(*)()) F1111_6463;}
	{long i; for (i = 1114; i < 1116; i++) R11[i] = (char *(*)()) F1115_6628;}
	R11[1117] = (char *(*)()) F1119_6789;
	{long i; for (i = 1120; i < 1123; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1124; i < 1126; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1127] = (char *(*)()) F1_8;
	{long i; for (i = 1133; i < 1137; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1137] = (char *(*)()) F1139_8333;
	R11[1138] = (char *(*)()) F1140_8340;
	{long i; for (i = 1139; i < 1147; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1152] = (char *(*)()) F1153_8481;
	{long i; for (i = 1164; i < 1166; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1167] = (char *(*)()) F1_8;
	{long i; for (i = 1169; i < 1175; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1175] = (char *(*)()) F1177_8795;
	{long i; for (i = 1176; i < 1181; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1182; i < 1205; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1207] = (char *(*)()) F1_8;
	R11[1209] = (char *(*)()) F1_8;
	R11[1213] = (char *(*)()) F1_8;
	{long i; for (i = 1217; i < 1220; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1222; i < 1224; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1226; i < 1228; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1229; i < 1232; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1234; i < 1236; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1239; i < 1241; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1242] = (char *(*)()) F1_8;
	{long i; for (i = 1244; i < 1251; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1252; i < 1263; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1267; i < 1271; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1278; i < 1281; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1283; i < 1285; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1289] = (char *(*)()) F1_8;
	{long i; for (i = 1291; i < 1293; i++) R11[i] = (char *(*)()) F1292_11223;}
	{long i; for (i = 1294; i < 1296; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1298] = (char *(*)()) F1_8;
	R11[1300] = (char *(*)()) F1_8;
	{long i; for (i = 1302; i < 1304; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1358] = (char *(*)()) F1307_11350;
	R11[1359] = (char *(*)()) F1308_11350;
	R11[1360] = (char *(*)()) F1312_11350;
	R11[1373] = (char *(*)()) F1307_11350;
	R11[1374] = (char *(*)()) F1308_11350;
	R11[1375] = (char *(*)()) F1307_11350;
	R11[1376] = (char *(*)()) F1310_11350;
	R11[1377] = (char *(*)()) F1308_11350;
	R11[1378] = (char *(*)()) F1311_11350;
	R11[1382] = (char *(*)()) F1307_11350;
	R11[1383] = (char *(*)()) F1308_11350;
	R11[1384] = (char *(*)()) F1311_11350;
	R11[1385] = (char *(*)()) F1307_11350;
	R11[1386] = (char *(*)()) F1308_11350;
	R11[1387] = (char *(*)()) F1307_11350;
	R11[1389] = (char *(*)()) F1_8;
	{long i; for (i = 1391; i < 1394; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1395; i < 1399; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1402; i < 1404; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1405] = (char *(*)()) F1_8;
	R11[1412] = (char *(*)()) F1_8;
	R11[1480] = (char *(*)()) F1482_11951;
	R11[1481] = (char *(*)()) F1483_11951;
	R11[1483] = (char *(*)()) F1482_11951;
	R11[1490] = (char *(*)()) F1492_12075;
	R11[1491] = (char *(*)()) F1493_12075;
	R11[1495] = (char *(*)()) F1497_12104;
	R11[1501] = (char *(*)()) F1503_12138;
	R11[1502] = (char *(*)()) F1504_12138;
	R11[1503] = (char *(*)()) F1505_12138;
	R11[1504] = (char *(*)()) F1506_12175;
	R11[1505] = (char *(*)()) F1507_12175;
	R11[1506] = (char *(*)()) F1508_12175;
	R11[1520] = (char *(*)()) F1516_12341;
	R11[1521] = (char *(*)()) F1517_12341;
	R11[1522] = (char *(*)()) F1518_12341;
	R11[1535] = (char *(*)()) F1525_12415;
	R11[1536] = (char *(*)()) F1526_12415;
	R11[1537] = (char *(*)()) F1527_12415;
	R11[1538] = (char *(*)()) F1528_12415;
	R11[1539] = (char *(*)()) F1529_12415;
	R11[1540] = (char *(*)()) F1530_12415;
	{long i; for (i = 1542; i < 1547; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1549; i < 1551; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1554] = (char *(*)()) F1_8;
	{long i; for (i = 1556; i < 1558; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1559; i < 1565; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1568] = (char *(*)()) F1_8;
	{long i; for (i = 1572; i < 1578; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1579] = (char *(*)()) F1_8;
	{long i; for (i = 1582; i < 1584; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1586] = (char *(*)()) F1_8;
	{long i; for (i = 1588; i < 1590; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1608; i < 1610; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1611] = (char *(*)()) F1613_13464;
	R11[1612] = (char *(*)()) F1_8;
	R11[1614] = (char *(*)()) F1_8;
	R11[1615] = (char *(*)()) F1617_13593;
	R11[1617] = (char *(*)()) F1619_13626;
	R11[1618] = (char *(*)()) F1_8;
	{long i; for (i = 1620; i < 1627; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1628] = (char *(*)()) F1_8;
	{long i; for (i = 1630; i < 1634; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1635; i < 1672; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1673; i < 1678; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1679; i < 1695; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1696; i < 1701; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1702; i < 1708; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1713; i < 1717; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1718] = (char *(*)()) F1_8;
	{long i; for (i = 1720; i < 1722; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1723] = (char *(*)()) F1_8;
	R11[1726] = (char *(*)()) F1_8;
	R11[1731] = (char *(*)()) F1_8;
	{long i; for (i = 1733; i < 1745; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1746] = (char *(*)()) F1748_15581;
	{long i; for (i = 1747; i < 1749; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1750; i < 1755; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1756; i < 1764; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1765; i < 1767; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1768; i < 1772; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1773] = (char *(*)()) F1775_16287;
	R11[1776] = (char *(*)()) F1777_16364;
	{long i; for (i = 1777; i < 1780; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1781] = (char *(*)()) F1_8;
	{long i; for (i = 1783; i < 1808; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1810; i < 1812; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1813; i < 1815; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1818] = (char *(*)()) F1_8;
	{long i; for (i = 1820; i < 1823; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1824; i < 1832; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1833; i < 1842; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1843; i < 1848; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1849; i < 1851; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1852; i < 1855; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1862; i < 1866; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1867] = (char *(*)()) F1_8;
	R11[1869] = (char *(*)()) F1_8;
	{long i; for (i = 1871; i < 1873; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1873] = (char *(*)()) F1875_18171;
	{long i; for (i = 1874; i < 1876; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1877; i < 1887; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1888; i < 1896; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1897; i < 1902; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1903; i < 1920; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1921; i < 1923; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1924] = (char *(*)()) F1_8;
	{long i; for (i = 1926; i < 2037; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2038; i < 2043; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2044; i < 2054; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2055; i < 2057; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2058; i < 2061; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2062; i < 2079; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2080; i < 2095; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2096; i < 2107; i++) R11[i] = (char *(*)()) F1_8;}
	R11[2108] = (char *(*)()) F1_8;
	R11[2110] = (char *(*)()) F1_8;
	{long i; for (i = 2112; i < 2116; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2117; i < 2120; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2121; i < 2127; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2128; i < 2132; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2133; i < 2137; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2138; i < 2141; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2142; i < 2146; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2147; i < 2151; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2152; i < 2193; i++) R11[i] = (char *(*)()) F1_8;}
	R11[2194] = (char *(*)()) F1_8;
	{long i; for (i = 2196; i < 2198; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2199; i < 2201; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 2202; i < 2209; i++) R11[i] = (char *(*)()) F1_8;}
	R11[2211] = (char *(*)()) F1_8;
	{long i; for (i = 2212; i < 2214; i++) R11[i] = (char *(*)()) F2214_22462;}
}

char *(*R28[2214])();
void R28_init () {
	R28[0] = (char *(*)()) F1_25;
	R28[2] = (char *(*)()) F1_25;
	{long i; for (i = 5; i < 12; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 13; i < 17; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 18; i < 31; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 32; i < 39; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 43; i < 50; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 52; i < 55; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 68; i < 71; i++) R28[i] = (char *(*)()) F1_25;}
	R28[78] = (char *(*)()) F1_25;
	{long i; for (i = 89; i < 93; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 101; i < 106; i++) R28[i] = (char *(*)()) F1_25;}
	R28[110] = (char *(*)()) F1_25;
	R28[122] = (char *(*)()) F1_25;
	R28[130] = (char *(*)()) F1_25;
	{long i; for (i = 135; i < 141; i++) R28[i] = (char *(*)()) F1_25;}
	R28[160] = (char *(*)()) F1_25;
	R28[164] = (char *(*)()) F1_25;
	{long i; for (i = 172; i < 176; i++) R28[i] = (char *(*)()) F1_25;}
	R28[178] = (char *(*)()) F1_25;
	R28[184] = (char *(*)()) F1_25;
	R28[195] = (char *(*)()) F1_25;
	{long i; for (i = 197; i < 199; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 200; i < 203; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 208; i < 221; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 225; i < 227; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 229; i < 231; i++) R28[i] = (char *(*)()) F1_25;}
	R28[251] = (char *(*)()) F1_25;
	R28[255] = (char *(*)()) F1_25;
	R28[259] = (char *(*)()) F1_25;
	R28[267] = (char *(*)()) F1_25;
	R28[269] = (char *(*)()) F1_25;
	{long i; for (i = 273; i < 275; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 275; i < 278; i++) R28[i] = (char *(*)()) F277_2314;}
	R28[280] = (char *(*)()) F277_2314;
	{long i; for (i = 282; i < 285; i++) R28[i] = (char *(*)()) F277_2314;}
	{long i; for (i = 286; i < 289; i++) R28[i] = (char *(*)()) F277_2314;}
	{long i; for (i = 290; i < 292; i++) R28[i] = (char *(*)()) F277_2314;}
	{long i; for (i = 294; i < 296; i++) R28[i] = (char *(*)()) F277_2314;}
	{long i; for (i = 297; i < 300; i++) R28[i] = (char *(*)()) F277_2314;}
	{long i; for (i = 301; i < 305; i++) R28[i] = (char *(*)()) F277_2314;}
	{long i; for (i = 306; i < 308; i++) R28[i] = (char *(*)()) F277_2314;}
	{long i; for (i = 309; i < 315; i++) R28[i] = (char *(*)()) F277_2314;}
	R28[322] = (char *(*)()) F1_25;
	R28[326] = (char *(*)()) F1_25;
	R28[331] = (char *(*)()) F1_25;
	R28[335] = (char *(*)()) F1_25;
	R28[337] = (char *(*)()) F1_25;
	R28[341] = (char *(*)()) F1_25;
	R28[360] = (char *(*)()) F1_25;
	{long i; for (i = 362; i < 365; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 373; i < 375; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 379; i < 381; i++) R28[i] = (char *(*)()) F1_25;}
	R28[459] = (char *(*)()) F1_25;
	{long i; for (i = 462; i < 471; i++) R28[i] = (char *(*)()) F1_25;}
	R28[472] = (char *(*)()) F1_25;
	{long i; for (i = 474; i < 476; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 481; i < 484; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 487; i < 489; i++) R28[i] = (char *(*)()) F1_25;}
	R28[491] = (char *(*)()) F1_25;
	R28[505] = (char *(*)()) F1_25;
	R28[508] = (char *(*)()) F1_25;
	{long i; for (i = 555; i < 560; i++) R28[i] = (char *(*)()) F1_25;}
	R28[767] = (char *(*)()) F1_25;
	R28[836] = (char *(*)()) F1_25;
	{long i; for (i = 851; i < 864; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 878; i < 898; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 954; i < 956; i++) R28[i] = (char *(*)()) F1_25;}
	R28[958] = (char *(*)()) F1_25;
	{long i; for (i = 974; i < 981; i++) R28[i] = (char *(*)()) F1_25;}
	R28[981] = (char *(*)()) F983_4814;
	R28[990] = (char *(*)()) F1_25;
	{long i; for (i = 994; i < 996; i++) R28[i] = (char *(*)()) F1_25;}
	R28[996] = (char *(*)()) F998_5022;
	R28[997] = (char *(*)()) F999_5063;
	R28[998] = (char *(*)()) F1000_5063;
	R28[999] = (char *(*)()) F1001_5063;
	R28[1000] = (char *(*)()) F1002_5063;
	R28[1001] = (char *(*)()) F1003_5063;
	R28[1002] = (char *(*)()) F1004_5063;
	R28[1003] = (char *(*)()) F1005_5063;
	R28[1004] = (char *(*)()) F1006_5063;
	R28[1005] = (char *(*)()) F1007_5063;
	R28[1006] = (char *(*)()) F1008_5063;
	R28[1007] = (char *(*)()) F1009_5063;
	R28[1008] = (char *(*)()) F1010_5063;
	R28[1009] = (char *(*)()) F1011_5063;
	R28[1010] = (char *(*)()) F1012_5063;
	R28[1011] = (char *(*)()) F1013_5063;
	R28[1012] = (char *(*)()) F1014_5063;
	R28[1013] = (char *(*)()) F1015_5063;
	R28[1014] = (char *(*)()) F1016_5063;
	R28[1015] = (char *(*)()) F1017_5063;
	R28[1016] = (char *(*)()) F1018_5063;
	R28[1017] = (char *(*)()) F1019_5063;
	R28[1018] = (char *(*)()) F1020_5063;
	R28[1019] = (char *(*)()) F1021_5063;
	R28[1020] = (char *(*)()) F1022_5063;
	R28[1021] = (char *(*)()) F1023_5063;
	R28[1022] = (char *(*)()) F1024_5063;
	R28[1023] = (char *(*)()) F1025_5063;
	R28[1024] = (char *(*)()) F1026_5063;
	R28[1025] = (char *(*)()) F1027_5063;
	R28[1026] = (char *(*)()) F1028_5063;
	R28[1027] = (char *(*)()) F1029_5063;
	R28[1028] = (char *(*)()) F1_25;
	{long i; for (i = 1030; i < 1032; i++) R28[i] = (char *(*)()) F1031_5275;}
	{long i; for (i = 1033; i < 1035; i++) R28[i] = (char *(*)()) F1034_5374;}
	{long i; for (i = 1036; i < 1038; i++) R28[i] = (char *(*)()) F1037_5473;}
	{long i; for (i = 1039; i < 1041; i++) R28[i] = (char *(*)()) F1040_5572;}
	{long i; for (i = 1042; i < 1044; i++) R28[i] = (char *(*)()) F1043_5668;}
	{long i; for (i = 1045; i < 1047; i++) R28[i] = (char *(*)()) F1046_5762;}
	{long i; for (i = 1048; i < 1050; i++) R28[i] = (char *(*)()) F1049_5857;}
	{long i; for (i = 1051; i < 1053; i++) R28[i] = (char *(*)()) F1052_5952;}
	R28[1054] = (char *(*)()) F1056_6045;
	R28[1055] = (char *(*)()) F1057_6045;
	R28[1057] = (char *(*)()) F1059_6111;
	R28[1058] = (char *(*)()) F1060_6111;
	{long i; for (i = 1060; i < 1062; i++) R28[i] = (char *(*)()) F1061_6127;}
	{long i; for (i = 1063; i < 1065; i++) R28[i] = (char *(*)()) F1064_6167;}
	{long i; for (i = 1066; i < 1068; i++) R28[i] = (char *(*)()) F1067_6215;}
	{long i; for (i = 1069; i < 1099; i++) R28[i] = (char *(*)()) F1070_6241;}
	R28[1099] = (char *(*)()) F1101_6254;
	R28[1100] = (char *(*)()) F1102_6254;
	R28[1102] = (char *(*)()) F1_25;
	R28[1105] = (char *(*)()) F1_25;
	{long i; for (i = 1110; i < 1112; i++) R28[i] = (char *(*)()) F1111_6483;}
	{long i; for (i = 1114; i < 1116; i++) R28[i] = (char *(*)()) F1115_6648;}
	R28[1117] = (char *(*)()) F1119_6785;
	{long i; for (i = 1120; i < 1123; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1124; i < 1126; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1127] = (char *(*)()) F1_25;
	{long i; for (i = 1133; i < 1147; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1152] = (char *(*)()) F1_25;
	{long i; for (i = 1164; i < 1166; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1167] = (char *(*)()) F1_25;
	{long i; for (i = 1169; i < 1175; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1175] = (char *(*)()) F1177_8796;
	{long i; for (i = 1176; i < 1181; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1182; i < 1205; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1207] = (char *(*)()) F1_25;
	R28[1209] = (char *(*)()) F1_25;
	R28[1213] = (char *(*)()) F1_25;
	{long i; for (i = 1217; i < 1220; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1222; i < 1224; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1226; i < 1228; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1229; i < 1232; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1234; i < 1236; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1239; i < 1241; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1242] = (char *(*)()) F1_25;
	{long i; for (i = 1244; i < 1251; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1252; i < 1263; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1267; i < 1271; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1278; i < 1281; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1283; i < 1285; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1289] = (char *(*)()) F1_25;
	{long i; for (i = 1291; i < 1293; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1294; i < 1296; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1298] = (char *(*)()) F1298_11298;
	R28[1300] = (char *(*)()) F1_25;
	{long i; for (i = 1302; i < 1304; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1358; i < 1361; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1373; i < 1379; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1382; i < 1388; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1389] = (char *(*)()) F1_25;
	{long i; for (i = 1391; i < 1394; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1395; i < 1399; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1402; i < 1404; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1405] = (char *(*)()) F1_25;
	R28[1412] = (char *(*)()) F1_25;
	{long i; for (i = 1480; i < 1482; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1483] = (char *(*)()) F1_25;
	{long i; for (i = 1490; i < 1492; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1495] = (char *(*)()) F1_25;
	{long i; for (i = 1501; i < 1507; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1520; i < 1523; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1535; i < 1541; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1542; i < 1547; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1549; i < 1551; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1554] = (char *(*)()) F1_25;
	{long i; for (i = 1556; i < 1558; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1559; i < 1565; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1568] = (char *(*)()) F1_25;
	R28[1572] = (char *(*)()) F1_25;
	R28[1573] = (char *(*)()) F1575_12907;
	{long i; for (i = 1574; i < 1578; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1579] = (char *(*)()) F1_25;
	{long i; for (i = 1582; i < 1584; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1586] = (char *(*)()) F1_25;
	{long i; for (i = 1588; i < 1590; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1608; i < 1610; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1611; i < 1613; i++) R28[i] = (char *(*)()) F1612_13436;}
	{long i; for (i = 1614; i < 1616; i++) R28[i] = (char *(*)()) F1615_13512;}
	{long i; for (i = 1617; i < 1619; i++) R28[i] = (char *(*)()) F1618_13599;}
	{long i; for (i = 1620; i < 1627; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1628] = (char *(*)()) F1_25;
	{long i; for (i = 1630; i < 1634; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1635; i < 1672; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1673; i < 1678; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1679; i < 1695; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1696; i < 1701; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1702] = (char *(*)()) F1704_14528;
	{long i; for (i = 1703; i < 1708; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1713; i < 1717; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1718] = (char *(*)()) F1_25;
	{long i; for (i = 1720; i < 1722; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1723] = (char *(*)()) F1_25;
	R28[1726] = (char *(*)()) F1_25;
	R28[1731] = (char *(*)()) F1_25;
	{long i; for (i = 1733; i < 1745; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1746] = (char *(*)()) F1748_15582;
	{long i; for (i = 1747; i < 1749; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1750; i < 1755; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1756; i < 1761; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1761] = (char *(*)()) F1763_16048;
	{long i; for (i = 1762; i < 1764; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1765; i < 1767; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1768; i < 1772; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1773] = (char *(*)()) F1775_16286;
	{long i; for (i = 1776; i < 1780; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1781] = (char *(*)()) F1_25;
	{long i; for (i = 1783; i < 1808; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1810; i < 1812; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1813; i < 1815; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1818] = (char *(*)()) F1_25;
	{long i; for (i = 1820; i < 1823; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1824; i < 1832; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1833; i < 1842; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1843; i < 1848; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1849; i < 1851; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1852; i < 1855; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1862; i < 1866; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1867] = (char *(*)()) F1_25;
	R28[1869] = (char *(*)()) F1_25;
	{long i; for (i = 1871; i < 1876; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1877; i < 1887; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1888; i < 1896; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1897; i < 1902; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1903; i < 1920; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1921; i < 1923; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1924] = (char *(*)()) F1_25;
	{long i; for (i = 1926; i < 2037; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2038; i < 2043; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2044; i < 2054; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2055; i < 2057; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2058; i < 2061; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2062; i < 2079; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2080; i < 2095; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2096; i < 2107; i++) R28[i] = (char *(*)()) F1_25;}
	R28[2108] = (char *(*)()) F1_25;
	R28[2110] = (char *(*)()) F1_25;
	{long i; for (i = 2112; i < 2116; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2117; i < 2120; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2121; i < 2127; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2128; i < 2132; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2133; i < 2137; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2138; i < 2141; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2142; i < 2146; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2147; i < 2151; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2152; i < 2193; i++) R28[i] = (char *(*)()) F1_25;}
	R28[2194] = (char *(*)()) F1_25;
	{long i; for (i = 2196; i < 2198; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2199; i < 2201; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 2202; i < 2209; i++) R28[i] = (char *(*)()) F1_25;}
	R28[2211] = (char *(*)()) F1_25;
	{long i; for (i = 2212; i < 2214; i++) R28[i] = (char *(*)()) F2214_22507;}
}

char *(*R458[7])();
void R458_init () {
	R458[0] = (char *(*)()) F45_455;
	R458[1] = (char *(*)()) F46_455;
	R458[2] = (char *(*)()) F47_455;
	R458[3] = (char *(*)()) F48_455;
	R458[4] = (char *(*)()) F49_455;
	R458[5] = (char *(*)()) F50_455;
	R458[6] = (char *(*)()) F51_455;
}

char *(*R463[7])();
void R463_init () {
	R463[0] = (char *(*)()) F45_460;
	R463[1] = (char *(*)()) F46_460_463_25;
	R463[2] = (char *(*)()) F47_460_463_25;
	R463[3] = (char *(*)()) F48_460_463_25;
	R463[4] = (char *(*)()) F49_460_463_25;
	R463[5] = (char *(*)()) F50_460_463_25;
	R463[6] = (char *(*)()) F51_460_463_25;
}
static void F46_460_463_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F46_460(Current, arg1, *(EIF_INTEGER_32 *)arg2, arg3);
}
static void F47_460_463_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F47_460(Current, arg1, *(EIF_BOOLEAN *)arg2, arg3);
}
static void F48_460_463_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F48_460(Current, arg1, *(EIF_CHARACTER_8 *)arg2, arg3);
}
static void F49_460_463_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F49_460(Current, arg1, *(EIF_INTEGER_8 *)arg2, arg3);
}
static void F50_460_463_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F50_460(Current, arg1, *(EIF_NATURAL_64 *)arg2, arg3);
}
static void F51_460_463_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F51_460(Current, arg1, *(EIF_NATURAL_32 *)arg2, arg3);
}

char *(*R466[7])();
void R466_init () {
	R466[0] = (char *(*)()) F45_463;
	R466[1] = (char *(*)()) F46_463;
	R466[2] = (char *(*)()) F47_463;
	R466[3] = (char *(*)()) F48_463;
	R466[4] = (char *(*)()) F49_463;
	R466[5] = (char *(*)()) F50_463;
	R466[6] = (char *(*)()) F51_463;
}

char *(*R1053[3])();
void R1053_init () {
	R1053[0] = (char *(*)()) F102_1064;
	R1053[1] = (char *(*)()) F101_1064;
	R1053[2] = (char *(*)()) F102_1064;
}

char *(*R1055[3])();
void R1055_init () {
	R1055[0] = (char *(*)()) F102_1066;
	R1055[1] = (char *(*)()) F101_1066;
	R1055[2] = (char *(*)()) F102_1066;
}

char *(*R1061[3])();
void R1061_init () {
	R1061[0] = (char *(*)()) F102_1063;
	R1061[1] = (char *(*)()) F101_1063;
	R1061[2] = (char *(*)()) F102_1063;
}

char *(*R1064[3])();
void R1064_init () {
	R1064[0] = (char *(*)()) F103_1070;
	R1064[1] = (char *(*)()) F104_1071;
	R1064[2] = (char *(*)()) F105_1071;
}

char *(*R1065[2])();
void R1065_init () {
	R1065[0] = (char *(*)()) F106_1072;
	R1065[1] = (char *(*)()) F107_1072_1065_1;
}
static EIF_REFERENCE F107_1072_1065_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F107_1072(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1126[1001])();
void R1126_init () {
	R1126[0] = (char *(*)()) F1215_9694;
	R1126[4] = (char *(*)()) F1219_9720;
	R1126[5] = (char *(*)()) F1220_9728;
	R1126[6] = (char *(*)()) F1221_9733;
	R1126[14] = (char *(*)()) F1229_9801;
	R1126[341] = (char *(*)()) F1555_12727;
	{long i; for (i = 343; i < 345; i++) R1126[i] = (char *(*)()) F1555_12727;}
	{long i; for (i = 999; i < 1001; i++) R1126[i] = (char *(*)()) F2214_22477;}
}

char *(*R1128[1001])();
void R1128_init () {
	R1128[0] = (char *(*)()) F1214_9686;
	R1128[4] = (char *(*)()) F1219_9719;
	R1128[5] = (char *(*)()) F1220_9727;
	R1128[6] = (char *(*)()) F1221_9735;
	R1128[14] = (char *(*)()) F1229_9800;
	R1128[341] = (char *(*)()) F1555_12726;
	{long i; for (i = 343; i < 345; i++) R1128[i] = (char *(*)()) F1555_12726;}
	{long i; for (i = 999; i < 1001; i++) R1128[i] = (char *(*)()) F2214_22521;}
}

char *(*R1129[1001])();
void R1129_init () {
	R1129[0] = (char *(*)()) F1215_9693;
	{long i; for (i = 4; i < 7; i++) R1129[i] = (char *(*)()) F125_1138;}
	R1129[14] = (char *(*)()) F125_1138;
	R1129[341] = (char *(*)()) F163_1519;
	{long i; for (i = 343; i < 345; i++) R1129[i] = (char *(*)()) F163_1519;}
	{long i; for (i = 999; i < 1001; i++) R1129[i] = (char *(*)()) F125_1138;}
}

char *(*R1131[1001])();
void R1131_init () {
	R1131[0] = (char *(*)()) F1215_9696;
	{long i; for (i = 4; i < 7; i++) R1131[i] = (char *(*)()) F125_1140;}
	R1131[14] = (char *(*)()) F125_1140;
	R1131[341] = (char *(*)()) F1549_12667;
	{long i; for (i = 343; i < 345; i++) R1131[i] = (char *(*)()) F1549_12667;}
	{long i; for (i = 999; i < 1001; i++) R1131[i] = (char *(*)()) F125_1140;}
}

char *(*R1262[4])();
void R1262_init () {
	R1262[0] = (char *(*)()) F139_1281;
	R1262[1] = (char *(*)()) F140_1281_1262_1;
	R1262[2] = (char *(*)()) F141_1281_1262_1;
	R1262[3] = (char *(*)()) F142_1281_1262_1;
}
static EIF_REFERENCE F140_1281_1262_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F140_1281(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F141_1281_1262_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F141_1281(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1044, 0x00).id, 1044, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F142_1281_1262_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F142_1281(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1062, 0x00).id, 1062, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y1399_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype6[] = {0xFF01,1112,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype7[] = {0xFF01,1112,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype32[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype33[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype34[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype35[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype36[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1399_pgtype37[] = {0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y1399_gen_type [1393];
EIF_TYPE_INDEX Y1399 [1393];
void Y1399_init (void)
{
	egc_routines_types [1399] = Y1399;
	egc_routines_gen_types [1399] = Y1399_gen_type;
	egc_routines_offset [1399] = 149;
	Y1399_gen_type [0] = Y1399_pgtype0;
	Y1399_gen_type [1] = Y1399_pgtype1;
	Y1399_gen_type [2] = Y1399_pgtype2;
	Y1399_gen_type [3] = Y1399_pgtype3;
	Y1399_gen_type [4] = Y1399_pgtype4;
	Y1399_gen_type [5] = Y1399_pgtype5;
	Y1399_gen_type [1060] = Y1399_pgtype6;
	Y1399_gen_type [1061] = Y1399_pgtype7;
	Y1399_gen_type [1274] = Y1399_pgtype8;
	Y1399_gen_type [1275] = Y1399_pgtype9;
	Y1399_gen_type [1276] = Y1399_pgtype10;
	Y1399_gen_type [1277] = Y1399_pgtype11;
	Y1399_gen_type [1278] = Y1399_pgtype12;
	Y1399_gen_type [1279] = Y1399_pgtype13;
	Y1399_gen_type [1313] = Y1399_pgtype14;
	Y1399_gen_type [1314] = Y1399_pgtype15;
	Y1399_gen_type [1315] = Y1399_pgtype16;
	Y1399_gen_type [1316] = Y1399_pgtype17;
	Y1399_gen_type [1317] = Y1399_pgtype18;
	Y1399_gen_type [1318] = Y1399_pgtype19;
	Y1399_gen_type [1375] = Y1399_pgtype20;
	Y1399_gen_type [1376] = Y1399_pgtype21;
	Y1399_gen_type [1377] = Y1399_pgtype22;
	Y1399_gen_type [1378] = Y1399_pgtype23;
	Y1399_gen_type [1379] = Y1399_pgtype24;
	Y1399_gen_type [1380] = Y1399_pgtype25;
	Y1399_gen_type [1381] = Y1399_pgtype26;
	Y1399_gen_type [1382] = Y1399_pgtype27;
	Y1399_gen_type [1383] = Y1399_pgtype28;
	Y1399_gen_type [1384] = Y1399_pgtype29;
	Y1399_gen_type [1385] = Y1399_pgtype30;
	Y1399_gen_type [1386] = Y1399_pgtype31;
	Y1399_gen_type [1387] = Y1399_pgtype32;
	Y1399_gen_type [1388] = Y1399_pgtype33;
	Y1399_gen_type [1389] = Y1399_pgtype34;
	Y1399_gen_type [1390] = Y1399_pgtype35;
	Y1399_gen_type [1391] = Y1399_pgtype36;
	Y1399_gen_type [1392] = Y1399_pgtype37;
	{long i; for (i = 1060; i < 1062; i++) Y1399[i] = 1112;};
}

char *(*R1481[15])();
void R1481_init () {
	R1481[0] = (char *(*)()) F1545_12517;
	{long i; for (i = 6; i < 8; i++) R1481[i] = (char *(*)()) F1550_12689;}
	R1481[11] = (char *(*)()) F1549_12659;
	{long i; for (i = 13; i < 15; i++) R1481[i] = (char *(*)()) F1549_12659;}
}

char *(*R1484[15])();
void R1484_init () {
	R1484[0] = (char *(*)()) F1545_12522;
	{long i; for (i = 6; i < 8; i++) R1484[i] = (char *(*)()) F1550_12692;}
	R1484[11] = (char *(*)()) F1555_12726;
	{long i; for (i = 13; i < 15; i++) R1484[i] = (char *(*)()) F1555_12726;}
}

char *(*R1500[1747])();
void R1500_init () {
	R1500[0] = (char *(*)()) F166_1533;
	R1500[1746] = (char *(*)()) F1912_18896;
}


#ifdef __cplusplus
}
#endif
