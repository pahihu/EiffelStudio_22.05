#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2995[1177];
void O2995_init () {
	O2995[0] = + _CHROFF_1_0_;
	O2995[454] = + _CHROFF_3_0_;
	O2995[455] = + _CHROFF_4_0_;
	O2995[456] = + _CHROFF_5_0_;
	O2995[868] = + _CHROFF_5_0_;
	O2995[1168] = + _CHROFF_7_1_;
	{long i; for (i = 1169; i < 1172; i++) O2995[i] = + _CHROFF_6_1_;}
	O2995[1173] = + _CHROFF_6_0_;
	{long i; for (i = 1174; i < 1177; i++) O2995[i] = + _CHROFF_5_0_;}
}

long O2996[1177];
void O2996_init () {
	O2996[0] = 0;
	{long i; for (i = 454; i < 457; i++) O2996[i] = 0;}
	O2996[868] = 0;
	O2996[1168] =  + _REFACS_6_;
	{long i; for (i = 1169; i < 1172; i++) O2996[i] =  + _REFACS_5_;}
	{long i; for (i = 1173; i < 1177; i++) O2996[i] = 0;}
}

long O3366[1600];
void O3366_init () {
	{long i; for (i = 0; i < 221; i++) O3366[i] = + _CHROFF_0_0_;}
	O3366[221] = + _CHROFF_3_2_;
	O3366[222] = + _CHROFF_4_2_;
	O3366[223] = + _CHROFF_5_2_;
	{long i; for (i = 250; i < 264; i++) O3366[i] = + _CHROFF_0_0_;}
	{long i; for (i = 264; i < 284; i++) O3366[i] = + _CHROFF_1_0_;}
	{long i; for (i = 284; i < 336; i++) O3366[i] = + _CHROFF_0_0_;}
	{long i; for (i = 336; i < 338; i++) O3366[i] = + _CHROFF_2_0_;}
	{long i; for (i = 346; i < 360; i++) O3366[i] = + _CHROFF_1_0_;}
	O3366[360] = + _CHROFF_7_0_;
	O3366[361] = + _CHROFF_6_0_;
	O3366[362] = + _CHROFF_5_0_;
	O3366[363] = + _CHROFF_4_0_;
	O3366[364] = + _CHROFF_5_0_;
	O3366[365] = + _CHROFF_7_0_;
	O3366[366] = + _CHROFF_5_0_;
	O3366[367] = + _CHROFF_9_0_;
	{long i; for (i = 497; i < 499; i++) O3366[i] = + _CHROFF_1_0_;}
	O3366[501] = + _CHROFF_1_0_;
	O3366[635] = + _CHROFF_5_2_;
	O3366[935] = + _CHROFF_7_2_;
	{long i; for (i = 936; i < 939; i++) O3366[i] = + _CHROFF_6_2_;}
	O3366[940] = + _CHROFF_6_2_;
	{long i; for (i = 941; i < 944; i++) O3366[i] = + _CHROFF_5_2_;}
	{long i; for (i = 1598; i < 1600; i++) O3366[i] = + _CHROFF_1_0_;}
}

long O3455[723];
void O3455_init () {
	O3455[0] = + _PTROFF_3_6_2_4_1_0_;
	O3455[1] = + _PTROFF_4_6_2_4_1_0_;
	O3455[2] = + _PTROFF_5_7_2_4_1_0_;
	O3455[414] = + _PTROFF_5_7_2_4_1_0_;
	O3455[714] = + _PTROFF_7_8_2_4_1_0_;
	{long i; for (i = 715; i < 718; i++) O3455[i] = + _PTROFF_6_7_2_4_1_0_;}
	O3455[719] = + _PTROFF_6_7_2_4_1_0_;
	{long i; for (i = 720; i < 723; i++) O3455[i] = + _PTROFF_5_6_2_4_1_0_;}
}

long O3538[723];
void O3538_init () {
	{long i; for (i = 0; i < 3; i++) O3538[i] =  + _REFACS_1_;}
	O3538[414] =  + _REFACS_1_;
	{long i; for (i = 714; i < 718; i++) O3538[i] = 0;}
	{long i; for (i = 719; i < 723; i++) O3538[i] =  + _REFACS_1_;}
}

long O3540[723];
void O3540_init () {
	{long i; for (i = 0; i < 3; i++) O3540[i] =  + _REFACS_2_;}
	O3540[414] =  + _REFACS_2_;
	{long i; for (i = 714; i < 718; i++) O3540[i] =  + _REFACS_1_;}
	{long i; for (i = 719; i < 723; i++) O3540[i] =  + _REFACS_2_;}
}

long O3594[723];
void O3594_init () {
	O3594[0] = + _LNGOFF_3_6_2_3_;
	O3594[1] = + _LNGOFF_4_6_2_3_;
	O3594[2] = + _LNGOFF_5_7_2_3_;
	O3594[414] = + _LNGOFF_5_7_2_3_;
	O3594[714] = + _LNGOFF_7_8_2_3_;
	{long i; for (i = 715; i < 718; i++) O3594[i] = + _LNGOFF_6_7_2_3_;}
	O3594[719] = + _LNGOFF_6_7_2_3_;
	{long i; for (i = 720; i < 723; i++) O3594[i] = + _LNGOFF_5_6_2_3_;}
}

long O3603[723];
void O3603_init () {
	O3603[0] = + _CHROFF_3_3_;
	O3603[1] = + _CHROFF_4_3_;
	O3603[2] = + _CHROFF_5_3_;
	O3603[414] = + _CHROFF_5_3_;
	O3603[714] = + _CHROFF_7_3_;
	{long i; for (i = 715; i < 718; i++) O3603[i] = + _CHROFF_6_3_;}
	O3603[719] = + _CHROFF_6_3_;
	{long i; for (i = 720; i < 723; i++) O3603[i] = + _CHROFF_5_3_;}
}

long O3617[718];
void O3617_init () {
	O3617[0] =  + _REFACS_3_;
	O3617[412] =  + _REFACS_3_;
	O3617[712] =  + _REFACS_2_;
	O3617[717] =  + _REFACS_3_;
}

long O3625[718];
void O3625_init () {
	O3625[0] =  + _REFACS_4_;
	O3625[412] =  + _REFACS_4_;
	O3625[712] =  + _REFACS_3_;
	O3625[717] =  + _REFACS_4_;
}

EIF_TYPE_INDEX *Y3849_gen_type [1];
EIF_TYPE_INDEX Y3849 [1];
void Y3849_init (void)
{
	egc_routines_types [3849] = Y3849;
	egc_routines_gen_types [3849] = Y3849_gen_type;
	egc_routines_offset [3849] = 961;
	Y3849[0] = 1035;
}

long O3869[8];
void O3869_init () {
	{long i; for (i = 0; i < 2; i++) O3869[i] = 0;}
	O3869[2] = + _LNGOFF_5_3_0_0_;
	O3869[3] = + _LNGOFF_4_3_0_0_;
	O3869[4] = + _PTROFF_5_3_0_7_0_0_;
	O3869[5] = 0;
	O3869[6] = + _LNGOFF_5_4_0_0_;
	O3869[7] = 0;
}

long O3878[8];
void O3878_init () {
	O3878[0] = + _LNGOFF_7_3_0_0_;
	O3878[1] = + _LNGOFF_6_3_0_0_;
	O3878[2] = + _LNGOFF_5_3_0_1_;
	O3878[3] = + _LNGOFF_4_3_0_1_;
	O3878[4] = + _LNGOFF_5_3_0_0_;
	O3878[5] = + _LNGOFF_7_4_0_0_;
	O3878[6] = + _LNGOFF_5_4_0_1_;
	O3878[7] = + _LNGOFF_9_3_0_0_;
}

long O3905[8];
void O3905_init () {
	{long i; for (i = 0; i < 2; i++) O3905[i] =  + _REFACS_1_;}
	{long i; for (i = 2; i < 5; i++) O3905[i] = 0;}
	O3905[5] =  + _REFACS_1_;
	O3905[6] = 0;
	O3905[7] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y3905_pgtype0[] = {0xFF01,852,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3905_pgtype1[] = {0xFF01,852,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3905_pgtype2[] = {0xFF01,853,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3905_pgtype3[] = {0xFF01,853,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3905_pgtype4[] = {0xFF01,862,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3905_pgtype5[] = {0xFF01,852,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3905_pgtype6[] = {0xFF01,853,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3905_pgtype7[] = {0xFF01,852,0,0xFFFF};
EIF_TYPE_INDEX *Y3905_gen_type [8];
EIF_TYPE_INDEX Y3905 [8];
void Y3905_init (void)
{
	egc_routines_types [3905] = Y3905;
	egc_routines_gen_types [3905] = Y3905_gen_type;
	egc_routines_offset [3905] = 975;
	Y3905_gen_type [0] = Y3905_pgtype0;
	Y3905_gen_type [1] = Y3905_pgtype1;
	Y3905_gen_type [2] = Y3905_pgtype2;
	Y3905_gen_type [3] = Y3905_pgtype3;
	Y3905_gen_type [4] = Y3905_pgtype4;
	Y3905_gen_type [5] = Y3905_pgtype5;
	Y3905_gen_type [6] = Y3905_pgtype6;
	Y3905_gen_type [7] = Y3905_pgtype7;
	{long i; for (i = 0; i < 2; i++) Y3905[i] = 852;};
	{long i; for (i = 2; i < 4; i++) Y3905[i] = 853;};
	Y3905[4] = 862;
	Y3905[5] = 852;
	Y3905[6] = 853;
	Y3905[7] = 852;
}

long O3906[8];
void O3906_init () {
	{long i; for (i = 0; i < 2; i++) O3906[i] =  + _REFACS_2_;}
	{long i; for (i = 2; i < 5; i++) O3906[i] =  + _REFACS_1_;}
	O3906[5] =  + _REFACS_2_;
	O3906[6] =  + _REFACS_1_;
	O3906[7] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y3906_pgtype0[] = {0xFF01,852,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3906_pgtype1[] = {0xFF01,853,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3906_pgtype2[] = {0xFF01,852,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3906_pgtype3[] = {0xFF01,853,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3906_pgtype4[] = {0xFF01,852,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3906_pgtype5[] = {0xFF01,852,0xFF01,1107,0xFFFF};
static EIF_TYPE_INDEX Y3906_pgtype6[] = {0xFF01,852,0xFF01,1107,0xFFFF};
static EIF_TYPE_INDEX Y3906_pgtype7[] = {0xFF01,852,0xFF01,1112,0xFFFF};
EIF_TYPE_INDEX *Y3906_gen_type [8];
EIF_TYPE_INDEX Y3906 [8];
void Y3906_init (void)
{
	egc_routines_types [3906] = Y3906;
	egc_routines_gen_types [3906] = Y3906_gen_type;
	egc_routines_offset [3906] = 975;
	Y3906_gen_type [0] = Y3906_pgtype0;
	Y3906_gen_type [1] = Y3906_pgtype1;
	Y3906_gen_type [2] = Y3906_pgtype2;
	Y3906_gen_type [3] = Y3906_pgtype3;
	Y3906_gen_type [4] = Y3906_pgtype4;
	Y3906_gen_type [5] = Y3906_pgtype5;
	Y3906_gen_type [6] = Y3906_pgtype6;
	Y3906_gen_type [7] = Y3906_pgtype7;
	Y3906[0] = 852;
	Y3906[1] = 853;
	Y3906[2] = 852;
	Y3906[3] = 853;
	{long i; for (i = 4; i < 8; i++) Y3906[i] = 852;};
}

long O3907[8];
void O3907_init () {
	{long i; for (i = 0; i < 2; i++) O3907[i] =  + _REFACS_3_;}
	{long i; for (i = 2; i < 5; i++) O3907[i] =  + _REFACS_2_;}
	O3907[5] =  + _REFACS_3_;
	O3907[6] =  + _REFACS_2_;
	O3907[7] =  + _REFACS_3_;
}

long O3908[8];
void O3908_init () {
	{long i; for (i = 0; i < 2; i++) O3908[i] =  + _REFACS_4_;}
	{long i; for (i = 2; i < 5; i++) O3908[i] =  + _REFACS_3_;}
	O3908[5] =  + _REFACS_4_;
	O3908[6] =  + _REFACS_3_;
	O3908[7] =  + _REFACS_4_;
}

long O3909[8];
void O3909_init () {
	O3909[0] = + _LNGOFF_7_3_0_1_;
	O3909[1] = + _LNGOFF_6_3_0_1_;
	O3909[2] = + _LNGOFF_5_3_0_2_;
	O3909[3] = + _LNGOFF_4_3_0_2_;
	O3909[4] = + _LNGOFF_5_3_0_1_;
	O3909[5] = + _LNGOFF_7_4_0_1_;
	O3909[6] = + _LNGOFF_5_4_0_2_;
	O3909[7] = + _LNGOFF_9_3_0_1_;
}

long O3910[8];
void O3910_init () {
	O3910[0] = + _CHROFF_7_2_;
	O3910[1] = + _CHROFF_6_2_;
	O3910[2] = + _CHROFF_5_2_;
	O3910[3] = + _CHROFF_4_2_;
	O3910[4] = + _CHROFF_5_2_;
	O3910[5] = + _CHROFF_7_2_;
	O3910[6] = + _CHROFF_5_2_;
	O3910[7] = + _CHROFF_9_2_;
}

long O3911[8];
void O3911_init () {
	O3911[0] = + _LNGOFF_7_3_0_2_;
	O3911[1] = + _LNGOFF_6_3_0_2_;
	O3911[2] = + _LNGOFF_5_3_0_3_;
	O3911[3] = + _LNGOFF_4_3_0_3_;
	O3911[4] = + _LNGOFF_5_3_0_2_;
	O3911[5] = + _LNGOFF_7_4_0_2_;
	O3911[6] = + _LNGOFF_5_4_0_3_;
	O3911[7] = + _LNGOFF_9_3_0_2_;
}

long O3914[8];
void O3914_init () {
	O3914[0] = + _LNGOFF_7_3_0_3_;
	O3914[1] = + _LNGOFF_6_3_0_3_;
	O3914[2] = + _LNGOFF_5_3_0_4_;
	O3914[3] = + _LNGOFF_4_3_0_4_;
	O3914[4] = + _LNGOFF_5_3_0_3_;
	O3914[5] = + _LNGOFF_7_4_0_3_;
	O3914[6] = + _LNGOFF_5_4_0_4_;
	O3914[7] = + _LNGOFF_9_3_0_3_;
}

long O3915[8];
void O3915_init () {
	O3915[0] = + _LNGOFF_7_3_0_4_;
	O3915[1] = + _LNGOFF_6_3_0_4_;
	O3915[2] = + _LNGOFF_5_3_0_5_;
	O3915[3] = + _LNGOFF_4_3_0_5_;
	O3915[4] = + _LNGOFF_5_3_0_4_;
	O3915[5] = + _LNGOFF_7_4_0_4_;
	O3915[6] = + _LNGOFF_5_4_0_5_;
	O3915[7] = + _LNGOFF_9_3_0_4_;
}

long O3919[8];
void O3919_init () {
	O3919[0] = + _LNGOFF_7_3_0_5_;
	O3919[1] = + _LNGOFF_6_3_0_5_;
	O3919[2] = + _LNGOFF_5_3_0_6_;
	O3919[3] = + _LNGOFF_4_3_0_6_;
	O3919[4] = + _LNGOFF_5_3_0_5_;
	O3919[5] = + _LNGOFF_7_4_0_5_;
	O3919[6] = + _LNGOFF_5_4_0_6_;
	O3919[7] = + _LNGOFF_9_3_0_5_;
}

long O3920[8];
void O3920_init () {
	{long i; for (i = 0; i < 2; i++) O3920[i] =  + _REFACS_5_;}
	O3920[2] = + _LNGOFF_5_3_0_7_;
	O3920[3] = + _LNGOFF_4_3_0_7_;
	O3920[4] = + _PTROFF_5_3_0_7_0_1_;
	O3920[5] =  + _REFACS_5_;
	O3920[6] = + _LNGOFF_5_4_0_7_;
	O3920[7] =  + _REFACS_5_;
}

long O3921[8];
void O3921_init () {
	O3921[0] =  + _REFACS_6_;
	O3921[1] = + _LNGOFF_6_3_0_6_;
	O3921[2] =  + _REFACS_4_;
	O3921[3] = + _LNGOFF_4_3_0_8_;
	O3921[4] =  + _REFACS_4_;
	O3921[5] =  + _REFACS_6_;
	O3921[6] =  + _REFACS_4_;
	O3921[7] =  + _REFACS_6_;
}

long O3955[8];
void O3955_init () {
	O3955[0] = + _LNGOFF_7_3_0_6_;
	O3955[1] = + _LNGOFF_6_3_0_7_;
	O3955[2] = + _LNGOFF_5_3_0_8_;
	O3955[3] = + _LNGOFF_4_3_0_9_;
	O3955[4] = + _LNGOFF_5_3_0_6_;
	O3955[5] = + _LNGOFF_7_4_0_6_;
	O3955[6] = + _LNGOFF_5_4_0_8_;
	O3955[7] = + _LNGOFF_9_3_0_6_;
}

long O3958[2];
void O3958_init () {
	O3958[0] = + _CHROFF_7_3_;
	O3958[1] = + _CHROFF_5_3_;
}

long O4957[5];
void O4957_init () {
	{long i; for (i = 0; i < 2; i++) O4957[i] = + _LNGOFF_4_2_0_0_;}
	O4957[2] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 3; i < 5; i++) O4957[i] = + _LNGOFF_4_3_0_0_;}
}

long O4965[5];
void O4965_init () {
	{long i; for (i = 0; i < 2; i++) O4965[i] = + _PTROFF_4_2_0_3_0_0_;}
	O4965[2] = + _PTROFF_5_2_0_3_0_0_;
	{long i; for (i = 3; i < 5; i++) O4965[i] = + _PTROFF_4_3_0_3_0_0_;}
}

long O4966[5];
void O4966_init () {
	{long i; for (i = 0; i < 2; i++) O4966[i] = + _PTROFF_4_2_0_3_0_1_;}
	O4966[2] = + _PTROFF_5_2_0_3_0_1_;
	{long i; for (i = 3; i < 5; i++) O4966[i] = + _PTROFF_4_3_0_3_0_1_;}
}

long O4968[5];
void O4968_init () {
	{long i; for (i = 0; i < 2; i++) O4968[i] = + _PTROFF_4_2_0_3_0_2_;}
	O4968[2] = + _PTROFF_5_2_0_3_0_2_;
	{long i; for (i = 3; i < 5; i++) O4968[i] = + _PTROFF_4_3_0_3_0_2_;}
}

long O4969[5];
void O4969_init () {
	{long i; for (i = 0; i < 2; i++) O4969[i] = + _LNGOFF_4_2_0_1_;}
	O4969[2] = + _LNGOFF_5_2_0_1_;
	{long i; for (i = 3; i < 5; i++) O4969[i] = + _LNGOFF_4_3_0_1_;}
}

long O4971[5];
void O4971_init () {
	{long i; for (i = 0; i < 2; i++) O4971[i] = + _LNGOFF_4_2_0_2_;}
	O4971[2] = + _LNGOFF_5_2_0_2_;
	{long i; for (i = 3; i < 5; i++) O4971[i] = + _LNGOFF_4_3_0_2_;}
}

long O4984[3];
void O4984_init () {
	O4984[0] =  + _REFACS_4_;
	{long i; for (i = 1; i < 3; i++) O4984[i] = + _CHROFF_4_2_;}
}

long O5083[1108];
void O5083_init () {
	{long i; for (i = 0; i < 3; i++) O5083[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O5083[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 5; i < 7; i++) O5083[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 7; i < 9; i++) O5083[i] = + _LNGOFF_1_0_0_0_;}
	O5083[9] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 1106; i < 1108; i++) O5083[i] = + _LNGOFF_1_1_0_0_;}
}


#ifdef __cplusplus
}
#endif
