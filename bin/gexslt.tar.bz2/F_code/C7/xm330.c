/*
 * Code for class XM_XSLT_TEXT_COMPARER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm330.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_TEXT_COMPARER}.make_from_collator */
void F484_3608 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {XM_XSLT_TEXT_COMPARER}.less_than */
EIF_BOOLEAN F484_3609 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,loc2);
	RTLR(6,arg2);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(arg1))-1819])(arg1);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(arg2))-1819])(arg2);
		tb1 = F1577_12936(loc3, loc1, loc2);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTCT0("attached comparer as l_comparer", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3243[Dtype(loc4)-482])(loc4, arg1, arg2);
	}
	RTLE;
	return Result;
}

/* {XM_XSLT_TEXT_COMPARER}.attached_less_than */
EIF_BOOLEAN F484_3610 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,loc2);
	RTLR(6,arg2);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(arg1))-1819])(arg1);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(arg2))-1819])(arg2);
		tb1 = F1577_12936(loc3, loc1, loc2);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTCT0("attached comparer as l_comparer", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3243[Dtype(loc4)-482])(loc4, arg1, arg2);
	}
	RTLE;
	return Result;
}

void EIF_Minit330 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
