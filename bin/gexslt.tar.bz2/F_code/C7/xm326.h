
#ifndef _C7_xm326_
#define _C7_xm326_

#ifdef __cplusplus
extern "C" {
#endif

extern void F477_3592(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F477_3593(EIF_REFERENCE);
extern EIF_INTEGER_32 F477_3594(EIF_REFERENCE);
extern void EIF_Minit326(void);
extern EIF_REFERENCE F1719_15034(EIF_REFERENCE);
extern char *(*R2019[])();

#ifdef __cplusplus
}
#endif

#endif
