
#ifndef _C7_ut328_
#define _C7_ut328_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,3598)
static EIF_REFERENCE F479_3598_body(EIF_REFERENCE);
extern EIF_REFERENCE F479_3598(EIF_REFERENCE);
extern void EIF_Minit328(void);

#ifdef __cplusplus
}
#endif

#endif
