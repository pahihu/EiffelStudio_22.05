/*
 * Code for class PLAIN_TEXT_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pl344.h"
#include "eif_file.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PLAIN_TEXT_FILE}.make_with_name */
void F839_4207 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F837_3926(Current, arg1);
	tr1 = RTLNSMART(eif_new_type(1116, 1).id);
	F1108_6308(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O3617[Dtype(Current)-838]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {PLAIN_TEXT_FILE}.put_string_32 */
void F839_4230 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F839_4231(Current, arg1);
}

/* {PLAIN_TEXT_FILE}.put_string_general */
void F839_4231 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,loc1);
	RTLR(6,loc3);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTGC;
	loc4 = F839_4252(Current);
	tr1 = RTLNS(eif_new_type(29, 0x01).id, 29, _OBJSIZ_0_0_0_0_0_0_0_0_);
	loc2 = RTOSCF(247,F30_247, (RTCW(tr1)));
	F31_256(RTCW(loc2), loc4, arg1);
	tb1 = F31_257(RTCW(loc2));
	if (tb1) {
		loc1 = F31_253(RTCW(loc2));
	} else {
		tr1 = RTLNS(eif_new_type(29, 0x01).id, 29, _OBJSIZ_0_0_0_0_0_0_0_0_);
		loc3 = RTOSCF(245,F30_245, (RTCW(tr1)));
		F31_256(RTCW(loc2), loc3, arg1);
		tb1 = F31_257(RTCW(loc2));
		if (tb1) {
			loc1 = F31_253(RTCW(loc2));
			tb1 = F31_259(RTCW(loc3), loc4);
			if ((EIF_BOOLEAN) !tb1) {
				F31_256(RTCW(loc3), loc4, loc1);
				tb1 = F31_257(RTCW(loc3));
				if (tb1) {
					loc1 = F31_253(RTCW(loc3));
				}
			}
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5007[Dtype(RTCW(arg1))-1111])(arg1);
			if (tb1) {
				loc1 = F1108_6361(RTCW(arg1));
			} else {
				tr2 = F1108_6367(RTCW(arg1));
				tr1 = RTLNS(eif_new_type(54, 0x00).id, 54, _OBJSIZ_0_0_0_0_0_0_0_0_);
				loc1 = F55_484(RTCW(tr1), tr2);
			}
		}
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3025[Dtype(Current)-837])(Current, loc1);
	RTLE;
}

/* {PLAIN_TEXT_FILE}.read_to_string */
EIF_INTEGER_32 F839_4249 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O3455[Dtype(Current)-836]);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	/* INLINED CODE (SPECIAL.item_address) */
	tp2 = RTCW(tr1) + (rt_uint_ptr)(EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)) * sizeof(EIF_CHARACTER_8);
	/* END INLINED CODE */
	tp2 = tp2;
	Result = (EIF_INTEGER_32) eif_file_gss((FILE*) tp1, (char*) tp2, (EIF_INTEGER) arg3);
	F1110_6406(RTCW(arg1));
	RTLE;
	return Result;
}

/* {PLAIN_TEXT_FILE}.encoding */
EIF_REFERENCE F839_4252 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O3625[dtype-838]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3620[dtype-1250])(Current);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O3625[dtype-838]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {PLAIN_TEXT_FILE}.default_encoding */
static EIF_REFERENCE F839_4253_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	

	
	RTEV;
	RTOSP (4253);
#define Result RTOSR(4253)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(29, 0x01).id, 29, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = RTOSCF(245,F30_245, (RTCW(tr1)));
	RTOSE (4253);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F839_4253 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4253,F839_4253_body,(Current));
}

void EIF_Minit344 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
