
#ifndef _C7_xm321_
#define _C7_xm321_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F472_3585(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit321(void);
extern char *(*R14085[])();

#ifdef __cplusplus
}
#endif

#endif
