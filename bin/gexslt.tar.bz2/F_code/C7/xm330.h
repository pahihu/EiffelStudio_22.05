
#ifndef _C7_xm330_
#define _C7_xm330_

#ifdef __cplusplus
extern "C" {
#endif

extern void F484_3608(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F484_3609(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F484_3610(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit330(void);
extern EIF_BOOLEAN F1577_12936(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R13392[])();
extern char *(*R3243[])();

#ifdef __cplusplus
}
#endif

#endif
