
#ifndef _C7_xm331_
#define _C7_xm331_

#ifdef __cplusplus
extern "C" {
#endif

extern void F485_3613(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F485_3615(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F485_3616(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit331(void);
extern char *(*R3243[])();

#ifdef __cplusplus
}
#endif

#endif
