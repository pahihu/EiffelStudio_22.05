/*
 * Code for class ARGUMENTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar337.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENTS}.argument */
EIF_REFERENCE F509_3665 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(3688,F509_3688, (Current));
	tr1 = F507_3633(RTCW(tr1), arg1);
	Result = F1108_6364(RTCW(tr1));
	RTLE;
	return Result;
}

/* {ARGUMENTS}.argument_count */
EIF_INTEGER_32 F509_3683 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4;
	RTLE;
	return Result;
}

/* {ARGUMENTS}.internal_arguments */
static EIF_REFERENCE F509_3688_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3688);
#define Result RTOSR(3688)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(506, 0x01).id, 506, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3688);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F509_3688 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3688,F509_3688_body,(Current));
}

void EIF_Minit337 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
