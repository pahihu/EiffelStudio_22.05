
#ifndef _C7_xm319_
#define _C7_xm319_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F470_3583(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit319(void);
extern EIF_BOOLEAN F1783_16554(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
