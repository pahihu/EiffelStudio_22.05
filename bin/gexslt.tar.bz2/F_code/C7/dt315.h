
#ifndef _C7_dt315_
#define _C7_dt315_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,3564)
static EIF_REFERENCE F460_3564_body(EIF_REFERENCE);
extern EIF_REFERENCE F460_3564(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,3565)
static EIF_REFERENCE F460_3565_body(EIF_REFERENCE);
extern EIF_REFERENCE F460_3565(EIF_REFERENCE);
extern void EIF_Minit315(void);

#ifdef __cplusplus
}
#endif

#endif
