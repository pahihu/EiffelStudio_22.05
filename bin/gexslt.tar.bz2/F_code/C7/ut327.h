
#ifndef _C7_ut327_
#define _C7_ut327_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,3597)
static EIF_REFERENCE F478_3597_body(EIF_REFERENCE);
extern EIF_REFERENCE F478_3597(EIF_REFERENCE);
extern void EIF_Minit327(void);

#ifdef __cplusplus
}
#endif

#endif
