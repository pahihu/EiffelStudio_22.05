
#ifndef _C7_uc346_
#define _C7_uc346_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,4521)
static EIF_REFERENCE F954_4521_body(EIF_REFERENCE);
extern EIF_REFERENCE F954_4521(EIF_REFERENCE);
extern void EIF_Minit346(void);

#ifdef __cplusplus
}
#endif

#endif
