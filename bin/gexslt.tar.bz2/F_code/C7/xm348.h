
#ifndef _C7_xm348_
#define _C7_xm348_

#ifdef __cplusplus
extern "C" {
#endif

extern void F956_4524(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F956_4525(EIF_REFERENCE);
extern void F956_4526(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit348(void);
extern EIF_BOOLEAN F1663_14066(EIF_REFERENCE);
extern char *(*R13950[])();
extern long O13842[];

#ifdef __cplusplus
}
#endif

#endif
