
#ifndef _C7_kl338_
#define _C7_kl338_

#ifdef __cplusplus
extern "C" {
#endif

extern void F510_3689(EIF_REFERENCE);
extern void F510_3691(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit338(void);
extern EIF_REFERENCE F509_3665(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
