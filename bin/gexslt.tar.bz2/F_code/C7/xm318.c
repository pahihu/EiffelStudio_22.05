/*
 * Code for class XM_XPATH_SHARED_TYPE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm318.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_SHARED_TYPE_FACTORY}.type_factory */
static EIF_REFERENCE F463_3581_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3581);
#define Result RTOSR(3581)
	RTOC_NEW(Result);
	tr1 = RTOSCF(3580,F462_3580, (Current));
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O1174[Dtype(tr1)-131]);
	if (tb1) {
		tr1 = RTLNS(eif_new_type(1236, 0x01).id, 1236, _OBJSIZ_0_1_0_0_0_0_0_0_);
		F1235_10246(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(1235, 0x01).id, 1235, _OBJSIZ_0_1_0_0_0_0_0_0_);
		F1235_10246(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
	}
	RTOSE (3581);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F463_3581 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3581,F463_3581_body,(Current));
}

void EIF_Minit318 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
