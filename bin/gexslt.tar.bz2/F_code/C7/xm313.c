/*
 * Code for class XM_XPATH_SHARED_EXPRESSION_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm313.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_SHARED_EXPRESSION_FACTORY}.expression_factory */
static EIF_REFERENCE F458_3562_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3562);
#define Result RTOSR(3562)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1634, 0x01).id, 1634, _OBJSIZ_3_1_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3562);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F458_3562 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3562,F458_3562_body,(Current));
}

void EIF_Minit313 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
