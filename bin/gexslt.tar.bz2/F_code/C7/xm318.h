
#ifndef _C7_xm318_
#define _C7_xm318_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,3581)
static EIF_REFERENCE F463_3581_body(EIF_REFERENCE);
extern EIF_REFERENCE F463_3581(EIF_REFERENCE);
extern void EIF_Minit318(void);
extern void F1235_10246(EIF_REFERENCE);
extern EIF_REFERENCE F462_3580(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,3580)
extern long O1174[];

#ifdef __cplusplus
}
#endif

#endif
