
#ifndef _C7_xm323_
#define _C7_xm323_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F474_3587(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit323(void);
extern char *(*R13833[])();

#ifdef __cplusplus
}
#endif

#endif
