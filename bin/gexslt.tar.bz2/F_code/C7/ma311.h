
#ifndef _C7_ma311_
#define _C7_ma311_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,3556)
static EIF_REFERENCE F456_3556_body(EIF_REFERENCE);
extern EIF_REFERENCE F456_3556(EIF_REFERENCE);
extern void EIF_Minit311(void);

#ifdef __cplusplus
}
#endif

#endif
