
#ifndef _C7_xm320_
#define _C7_xm320_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F471_3584(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit320(void);

#ifdef __cplusplus
}
#endif

#endif
