/*
 * Code for class UT_SHARED_FILE_URI_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut328.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_SHARED_FILE_URI_ROUTINES}.file_uri */
static EIF_REFERENCE F479_3598_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3598);
#define Result RTOSR(3598)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1577, 0x01).id, 1577, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3598);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F479_3598 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3598,F479_3598_body,(Current));
}

void EIF_Minit328 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
