
#ifndef _C7_xm314_
#define _C7_xm314_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,3563)
static EIF_REFERENCE F459_3563_body(EIF_REFERENCE);
extern EIF_REFERENCE F459_3563(EIF_REFERENCE);
extern void EIF_Minit314(void);

#ifdef __cplusplus
}
#endif

#endif
