
#ifndef _C7_ra343_
#define _C7_ra343_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F838_4194(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_POINTER F838_4201(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void EIF_Minit343(void);
extern void F1110_6406(EIF_REFERENCE);
extern long O3455[];

#ifdef __cplusplus
}
#endif

#endif
