/*
 * Code for class XM_XPATH_DEFAULT_LOCATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm325.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_DEFAULT_LOCATOR}.system_id */

EIF_REFERENCE F476_3590 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3590,RTMS_EX_H("",0,0));
}

/* {XM_XPATH_DEFAULT_LOCATOR}.line_number */
EIF_INTEGER_32 F476_3591 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

void EIF_Minit325 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
