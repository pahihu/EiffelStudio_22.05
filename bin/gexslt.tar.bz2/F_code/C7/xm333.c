/*
 * Code for class XM_XPATH_GLOBAL_ORDER_COMPARER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm333.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_GLOBAL_ORDER_COMPARER}.three_way_comparison */
EIF_INTEGER_32 F489_3624 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R13622[Dtype(RTCW(arg1))-1853])(arg1);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R13622[Dtype(RTCW(arg2))-1853])(arg2);
	if ((EIF_BOOLEAN)(loc1 == loc2)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R13648[Dtype(RTCW(arg1))-1853])(arg1, arg2);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		tr1 = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)tr1 = (EIF_INTEGER_32) (loc1 - loc2);
		Result = F1034_5307(RTCW(tr1));
	}
	RTLE;
	return Result;
}

void EIF_Minit333 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
