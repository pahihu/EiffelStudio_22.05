/*
 * Code for class UC_IMPORTED_UTF8_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc346.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_IMPORTED_UTF8_ROUTINES}.utf8 */
static EIF_REFERENCE F954_4521_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (4521);
#define Result RTOSR(4521)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1137, 0x01).id, 1137, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (4521);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F954_4521 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4521,F954_4521_body,(Current));
}

void EIF_Minit346 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
