
#ifndef _C7_xm313_
#define _C7_xm313_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,3562)
static EIF_REFERENCE F458_3562_body(EIF_REFERENCE);
extern EIF_REFERENCE F458_3562(EIF_REFERENCE);
extern void EIF_Minit313(void);

#ifdef __cplusplus
}
#endif

#endif
