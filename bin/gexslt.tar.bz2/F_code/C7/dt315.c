/*
 * Code for class DT_SHARED_SYSTEM_CLOCK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dt315.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DT_SHARED_SYSTEM_CLOCK}.system_clock */
static EIF_REFERENCE F460_3564_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3564);
#define Result RTOSR(3564)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1722, 0x01).id, 1722, _OBJSIZ_2_0_0_7_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3564);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F460_3564 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3564,F460_3564_body,(Current));
}

/* {DT_SHARED_SYSTEM_CLOCK}.utc_system_clock */
static EIF_REFERENCE F460_3565_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3565);
#define Result RTOSR(3565)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1721, 0x01).id, 1721, _OBJSIZ_2_0_0_7_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3565);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F460_3565 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3565,F460_3565_body,(Current));
}

void EIF_Minit315 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
