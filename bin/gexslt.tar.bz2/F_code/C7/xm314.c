/*
 * Code for class XM_XPATH_SHARED_EXPRESSION_TESTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm314.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_SHARED_EXPRESSION_TESTER}.expression_tester */
static EIF_REFERENCE F459_3563_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3563);
#define Result RTOSR(3563)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(473, 0x01).id, 473, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3563);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F459_3563 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3563,F459_3563_body,(Current));
}

void EIF_Minit314 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
