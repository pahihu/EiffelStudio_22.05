
#ifndef _C7_xm329_
#define _C7_xm329_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F483_3605(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F483_3606(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit329(void);
extern EIF_BOOLEAN F1108_6334(EIF_REFERENCE);
extern EIF_REAL_64 F1108_6383(EIF_REFERENCE);
extern char *(*R13421[])();
extern char *(*R14162[])();
extern char *(*R13392[])();
extern char *(*R13404[])();
extern char *(*R14155[])();
extern char *(*R14156[])();

#ifdef __cplusplus
}
#endif

#endif
