/*
 * Code for class XM_XPATH_SHARED_CONFORMANCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm317.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XPATH_SHARED_CONFORMANCE}.conformance */
static EIF_REFERENCE F462_3580_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3580);
#define Result RTOSR(3580)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(131, 0x01).id, 131, _OBJSIZ_0_6_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3580);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F462_3580 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3580,F462_3580_body,(Current));
}

void EIF_Minit317 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
