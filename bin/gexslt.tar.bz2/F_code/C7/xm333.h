
#ifndef _C7_xm333_
#define _C7_xm333_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F489_3624(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit333(void);
extern EIF_INTEGER_32 F1034_5307(EIF_REFERENCE);
extern char *(*R13622[])();
extern char *(*R13648[])();

#ifdef __cplusplus
}
#endif

#endif
