
#ifndef _C7_xm316_
#define _C7_xm316_

#ifdef __cplusplus
extern "C" {
#endif

extern void F461_3566(EIF_REFERENCE);
extern EIF_REFERENCE F461_3572(EIF_REFERENCE);
extern EIF_REFERENCE F461_3573(EIF_REFERENCE);
extern EIF_REFERENCE F461_3574(EIF_REFERENCE);
extern void F461_3576(EIF_REFERENCE);
extern void F461_3577(EIF_REFERENCE);
extern void F461_3578(EIF_REFERENCE);
extern void F461_3579(EIF_REFERENCE);
extern void EIF_Minit316(void);
extern EIF_REFERENCE F1721_15176(EIF_REFERENCE);
extern EIF_REFERENCE F460_3564(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,3564)
extern char *(*R10685[])();

#ifdef __cplusplus
}
#endif

#endif
