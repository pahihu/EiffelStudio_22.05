/*
 * Code for class MA_SHARED_DECIMAL_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ma311.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MA_SHARED_DECIMAL_CONSTANTS}.decimal */
static EIF_REFERENCE F456_3556_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3556);
#define Result RTOSR(3556)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(175, 0x01).id, 175, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3556);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F456_3556 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3556,F456_3556_body,(Current));
}

void EIF_Minit311 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
