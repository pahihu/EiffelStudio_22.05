
#ifndef _C7_xm332_
#define _C7_xm332_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F488_3622(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F488_3623(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit332(void);
extern char *(*R3259[])();

#ifdef __cplusplus
}
#endif

#endif
