
#ifndef _C7_xm349_
#define _C7_xm349_

#ifdef __cplusplus
extern "C" {
#endif

extern void F957_4531(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern EIF_REFERENCE F957_4532(EIF_REFERENCE);
extern void F957_4533(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit349(void);
extern char *(*R12588[])();
extern char *(*R13950[])();
extern char *(*R13415[])();
extern long O13842[];

#ifdef __cplusplus
}
#endif

#endif
