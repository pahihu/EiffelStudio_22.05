
#ifndef _C7_xm325_
#define _C7_xm325_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 3590)


extern EIF_REFERENCE F476_3590(EIF_REFERENCE);
extern EIF_INTEGER_32 F476_3591(EIF_REFERENCE);
extern void EIF_Minit325(void);

#ifdef __cplusplus
}
#endif

#endif
