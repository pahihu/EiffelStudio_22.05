/*
 * Code for class XM_XSLT_NUMERIC_COMPARER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm329.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_NUMERIC_COMPARER}.less_than */
EIF_BOOLEAN F483_3605 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REAL_64 loc3 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc4 = (EIF_REAL_64) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13404[Dtype(RTCW(arg1))-1819])(arg1);
	if (tb1) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13421[Dtype(RTCW(arg1))-1819])(arg1);
		tb1 = '\0';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14162[Dtype(RTCW(loc2))-1898])(loc2);
		if (tb2) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14156[Dtype(RTCW(loc2))-1898])(loc2);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			loc3 = (FUNCTION_CAST(EIF_REAL_64, (EIF_REFERENCE)) R14155[Dtype(RTCW(loc2))-1898])(loc2);
		} else {
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(arg1))-1819])(arg1);
		tb1 = F1108_6334(RTCW(loc1));
		if (tb1) {
			loc3 = F1108_6383(RTCW(loc1));
		} else {
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13404[Dtype(RTCW(arg2))-1819])(arg2);
	if (tb1) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13421[Dtype(RTCW(arg2))-1819])(arg2);
		tb1 = '\0';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14162[Dtype(RTCW(loc2))-1898])(loc2);
		if (tb2) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14156[Dtype(RTCW(loc2))-1898])(loc2);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			loc4 = (FUNCTION_CAST(EIF_REAL_64, (EIF_REFERENCE)) R14155[Dtype(RTCW(loc2))-1898])(loc2);
		} else {
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(arg2))-1819])(arg2);
		tb1 = F1108_6334(RTCW(loc1));
		if (tb1) {
			loc4 = F1108_6383(RTCW(loc1));
		} else {
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	if (loc5) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) !loc6;
	} else {
		if (loc6) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) eif_is_less_real_64 (loc3, loc4);
		}
	}/* NOTREACHED */
	
}

/* {XM_XSLT_NUMERIC_COMPARER}.attached_less_than */
EIF_BOOLEAN F483_3606 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REAL_64 loc3 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc4 = (EIF_REAL_64) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13404[Dtype(RTCW(arg1))-1819])(arg1);
	if (tb1) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13421[Dtype(RTCW(arg1))-1819])(arg1);
		tb1 = '\0';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14162[Dtype(RTCW(loc2))-1898])(loc2);
		if (tb2) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14156[Dtype(RTCW(loc2))-1898])(loc2);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			loc3 = (FUNCTION_CAST(EIF_REAL_64, (EIF_REFERENCE)) R14155[Dtype(RTCW(loc2))-1898])(loc2);
		} else {
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(arg1))-1819])(arg1);
		tb1 = F1108_6334(RTCW(loc1));
		if (tb1) {
			loc3 = F1108_6383(RTCW(loc1));
		} else {
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13404[Dtype(RTCW(arg2))-1819])(arg2);
	if (tb1) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13421[Dtype(RTCW(arg2))-1819])(arg2);
		tb1 = '\0';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14162[Dtype(RTCW(loc2))-1898])(loc2);
		if (tb2) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14156[Dtype(RTCW(loc2))-1898])(loc2);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			loc4 = (FUNCTION_CAST(EIF_REAL_64, (EIF_REFERENCE)) R14155[Dtype(RTCW(loc2))-1898])(loc2);
		} else {
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13392[Dtype(RTCW(arg2))-1819])(arg2);
		tb1 = F1108_6334(RTCW(loc1));
		if (tb1) {
			loc4 = F1108_6383(RTCW(loc1));
		} else {
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	if (loc5) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) !loc6;
	} else {
		if (loc6) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) eif_is_less_real_64 (loc3, loc4);
		}
	}/* NOTREACHED */
	
}

void EIF_Minit329 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
