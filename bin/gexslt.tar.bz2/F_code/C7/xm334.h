
#ifndef _C7_xm334_
#define _C7_xm334_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F490_3625(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit334(void);
extern char *(*R13648[])();

#ifdef __cplusplus
}
#endif

#endif
