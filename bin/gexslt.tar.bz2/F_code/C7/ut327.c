/*
 * Code for class UT_SHARED_URL_ENCODING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut327.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_SHARED_URL_ENCODING}.url_encoding */
static EIF_REFERENCE F478_3597_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3597);
#define Result RTOSR(3597)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1752, 0x01).id, 1752, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3597);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F478_3597 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3597,F478_3597_body,(Current));
}

void EIF_Minit327 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
