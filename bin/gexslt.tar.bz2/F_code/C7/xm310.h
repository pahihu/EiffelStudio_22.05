
#ifndef _C7_xm310_
#define _C7_xm310_

#ifdef __cplusplus
extern "C" {
#endif

extern void F455_3549(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F455_3553(EIF_REFERENCE);
extern EIF_BOOLEAN F455_3555(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit310(void);
extern EIF_INTEGER_32 F1853_17548(EIF_REFERENCE);
extern char *(*R13629[])();
extern char *(*R3206[])();
extern char *(*R3207[])();
extern char *(*R13483[])();
extern long O13624[];

#ifdef __cplusplus
}
#endif

#endif
