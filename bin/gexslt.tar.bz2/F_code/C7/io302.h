
#ifndef _C7_io302_
#define _C7_io302_

#ifdef __cplusplus
extern "C" {
#endif

extern void F383_3339(EIF_REFERENCE);
extern void EIF_Minit302(void);
extern EIF_BOOLEAN F837_3985(EIF_REFERENCE);
extern void F837_4013(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
