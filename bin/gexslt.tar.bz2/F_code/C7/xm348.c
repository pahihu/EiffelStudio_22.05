/*
 * Code for class XM_XSLT_ANALYZE_NODE_MAPPING_FUNCTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm348.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XSLT_ANALYZE_NODE_MAPPING_FUNCTION}.make */
void F956_4524 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg3;
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg4;
	RTLE;
}

/* {XM_XSLT_ANALYZE_NODE_MAPPING_FUNCTION}.last_node_iterator */
EIF_REFERENCE F956_4525 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_4_);
}


/* {XM_XSLT_ANALYZE_NODE_MAPPING_FUNCTION}.map_nodes */
void F956_4526 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	tb2 = F1663_14066(RTCW(tr1));
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = tr1;
		tb1 = EIF_TEST(loc1);
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13950[Dtype(loc1)-1868])(loc1, *(EIF_REFERENCE *)(Current + _REFACS_1_));
		tr1 = *(EIF_REFERENCE *)(loc1 + O13842[Dtype(loc1)-1867]);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	} else {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current);
		tb2 = F1663_14066(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			loc2 = tr1;
			tb1 = EIF_TEST(loc2);
		}
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13950[Dtype(loc2)-1868])(loc2, *(EIF_REFERENCE *)(Current + _REFACS_1_));
			tr1 = *(EIF_REFERENCE *)(loc2 + O13842[Dtype(loc2)-1867]);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
		} else {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1694,0xFF01,1852,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr1 = RTLNS(typres0.id, 1694, _OBJSIZ_3_1_0_1_0_0_0_0_);
			}
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

void EIF_Minit348 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
