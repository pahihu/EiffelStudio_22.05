
#ifndef _C7_xm317_
#define _C7_xm317_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,3580)
static EIF_REFERENCE F462_3580_body(EIF_REFERENCE);
extern EIF_REFERENCE F462_3580(EIF_REFERENCE);
extern void EIF_Minit317(void);

#ifdef __cplusplus
}
#endif

#endif
