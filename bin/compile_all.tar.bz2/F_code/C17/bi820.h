
#ifndef _C17_bi820_
#define _C17_bi820_

#ifdef __cplusplus
extern "C" {
#endif

extern void F646_6170(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit820(void);
extern EIF_BOOLEAN F764_6292(EIF_REFERENCE);
extern void F634_6153(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R5478[])();
extern char *(*R5479[])();

#ifdef __cplusplus
}
#endif

#endif
