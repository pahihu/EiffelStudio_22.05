
#ifndef _C17_co845_
#define _C17_co845_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F282_3460(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit845(void);
extern char *(*R3916[])();

#ifdef __cplusplus
}
#endif

#endif
