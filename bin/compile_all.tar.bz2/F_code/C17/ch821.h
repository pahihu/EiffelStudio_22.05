
#ifndef _C17_ch821_
#define _C17_ch821_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F898_6953(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F898_6955(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F898_6958(EIF_REFERENCE);
extern EIF_BOOLEAN F898_6963(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F898_6964(EIF_REFERENCE);
extern EIF_BOOLEAN F898_6965(EIF_REFERENCE);
extern EIF_BOOLEAN F898_6966(EIF_REFERENCE);
extern void F898_6969(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F898_6970(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit821(void);
extern EIF_BOOLEAN F764_6292(EIF_REFERENCE);
extern EIF_BOOLEAN F634_6151(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern EIF_BOOLEAN F634_6157(EIF_REFERENCE);
extern char *(*R5485[])();
extern char *(*R5561[])();
extern char *(*R5498[])();
extern char *(*R5965[])();
extern char *(*R5465[])();
extern char *(*R5502[])();
extern char *(*R5504[])();
extern char *(*R5506[])();
extern char *(*R5472[])();
extern char *(*R5477[])();
extern char *(*R5478[])();

#ifdef __cplusplus
}
#endif

#endif
