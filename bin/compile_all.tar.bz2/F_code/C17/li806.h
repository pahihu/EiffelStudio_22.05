
#ifndef _C17_li806_
#define _C17_li806_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F634_6151(EIF_REFERENCE, EIF_INTEGER_32);
extern void F634_6153(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F634_6157(EIF_REFERENCE);
extern EIF_BOOLEAN F634_6159(EIF_REFERENCE);
extern EIF_REFERENCE F634_6166(EIF_REFERENCE);
extern void EIF_Minit806(void);
extern char *(*R5455[])();
extern char *(*R5463[])();
extern char *(*R5464[])();
extern char *(*R5465[])();
extern char *(*R5471[])();
extern char *(*R5476[])();
extern char *(*R5478[])();
extern long O5457[];

#ifdef __cplusplus
}
#endif

#endif
