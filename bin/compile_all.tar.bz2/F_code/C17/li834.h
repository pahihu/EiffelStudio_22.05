
#ifndef _C17_li834_
#define _C17_li834_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F555_6066(EIF_REFERENCE);
extern EIF_BOOLEAN F555_6067(EIF_REFERENCE);
extern void F555_6068(EIF_REFERENCE);
extern void F555_6069(EIF_REFERENCE);
extern EIF_REFERENCE F555_6070(EIF_REFERENCE);
extern void EIF_Minit834(void);
extern EIF_REFERENCE F523_6032(EIF_REFERENCE);
extern void F535_6057(EIF_REFERENCE);
extern EIF_BOOLEAN F535_6050(EIF_REFERENCE);
extern void F535_6058(EIF_REFERENCE);
extern char *(*R2464[])();
extern char *(*R5407[])();
extern long O2468[];

#ifdef __cplusplus
}
#endif

#endif
