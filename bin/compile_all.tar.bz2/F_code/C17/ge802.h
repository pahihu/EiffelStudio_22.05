
#ifndef _C17_ge802_
#define _C17_ge802_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F559_6072(EIF_REFERENCE);
extern EIF_INTEGER_32 F559_6074(EIF_REFERENCE);
extern EIF_BOOLEAN F559_6081(EIF_REFERENCE);
extern EIF_BOOLEAN F559_6085(EIF_REFERENCE);
extern void F559_6086(EIF_REFERENCE);
extern void F559_6087(EIF_REFERENCE);
extern EIF_REFERENCE F559_6088(EIF_REFERENCE);
extern void EIF_Minit802(void);
extern char *(*R5426[])();
extern char *(*R5399[])();
extern long O5425[];
extern long O5427[];

#ifdef __cplusplus
}
#endif

#endif
