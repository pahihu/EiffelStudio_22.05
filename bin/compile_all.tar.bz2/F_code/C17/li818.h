
#ifndef _C17_li818_
#define _C17_li818_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F922_6989(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F922_6990(EIF_REFERENCE);
extern EIF_BOOLEAN F922_6991(EIF_REFERENCE);
extern void EIF_Minit818(void);
extern EIF_BOOLEAN F764_6292(EIF_REFERENCE);
extern char *(*R5561[])();
extern char *(*R5498[])();
extern char *(*R5465[])();
extern char *(*R5504[])();
extern char *(*R5506[])();
extern char *(*R5472[])();
extern char *(*R5476[])();
extern char *(*R5478[])();
extern long O5457[];

#ifdef __cplusplus
}
#endif

#endif
