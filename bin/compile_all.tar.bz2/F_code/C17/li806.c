/*
 * Code for class LINEAR [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li806.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.has */
EIF_BOOLEAN F634_6151 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("has", 633, Current, 0, 1, 7070);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5465[dtype-759])(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5464[dtype-759])(Current)) {
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5471[dtype-759])(Current, (EIF_REFERENCE) &arg1);
	}
	RTHOOK(4);
	Result = F634_6157(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {LINEAR}.search */
void F634_6153 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 633, Current, 0, 1, 7072);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O5457[dtype-607])) {
		for (;;) {
			RTHOOK(2);
			tb1 = '\01';
			if (!F634_6157(Current)) {
				tb1 = (arg1 == (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5463[dtype-759])(Current)));
			}
			if (tb1) break;
			RTHOOK(3);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5478[dtype-759])(Current);
		}
	} else {
		for (;;) {
			RTHOOK(4);
			tb2 = '\01';
			if (!F634_6157(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5463[dtype-759])(Current)));
			}
			if (tb2) break;
			RTHOOK(5);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5478[dtype-759])(Current);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F634_6157 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("exhausted", 633, Current, 0, 0, 7075);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5464[Dtype(Current)-759])(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F634_6159 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 633, Current, 0, 0, 7076);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5455[dtype-759])(Current)) {
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5476[dtype-759])(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {LINEAR}.linear_representation */
EIF_REFERENCE F634_6166 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("linear_representation", 633, Current, 0, 0, 7081);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) Current;
}

void EIF_Minit806 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
