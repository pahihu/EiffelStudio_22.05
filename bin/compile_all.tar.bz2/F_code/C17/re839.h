
#ifndef _C17_re839_
#define _C17_re839_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F843_6716(EIF_REFERENCE);
extern void EIF_Minit839(void);
extern void F538_6038(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5410[])();
extern EIF_TYPE_INDEX Y5346[];
extern EIF_TYPE_INDEX *Y5346_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
