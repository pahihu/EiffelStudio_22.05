
#ifndef _C17_dy822_
#define _C17_dy822_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F910_6975(EIF_REFERENCE);
extern void EIF_Minit822(void);

#ifdef __cplusplus
}
#endif

#endif
