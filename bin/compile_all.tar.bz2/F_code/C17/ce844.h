
#ifndef _C17_ce844_
#define _C17_ce844_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F191_2534(EIF_REFERENCE);
extern void F191_2535(EIF_REFERENCE, EIF_NATURAL_64);
extern void F191_2536(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit844(void);

#ifdef __cplusplus
}
#endif

#endif
