
#ifndef _C17_ar829_
#define _C17_ar829_

#ifdef __cplusplus
extern "C" {
#endif

extern void F585_6110(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F585_6111(EIF_REFERENCE);
extern EIF_REFERENCE F585_6112(EIF_REFERENCE);
extern EIF_REFERENCE F585_6114(EIF_REFERENCE);
extern EIF_INTEGER_32 F585_6115(EIF_REFERENCE);
extern void EIF_Minit829(void);
extern EIF_TYPE_INDEX Y5317[];
extern EIF_TYPE_INDEX *Y5317_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
