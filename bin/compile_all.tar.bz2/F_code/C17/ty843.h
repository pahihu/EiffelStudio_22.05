
#ifndef _C17_ty843_
#define _C17_ty843_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F526_6032(EIF_REFERENCE);
extern void EIF_Minit843(void);
extern char *(*R5411[])();
extern char *(*R5398[])();
extern char *(*R5795[])();

#ifdef __cplusplus
}
#endif

#endif
