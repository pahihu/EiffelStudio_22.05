
#ifndef _C17_se819_
#define _C17_se819_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F806_6347(EIF_REFERENCE);
extern void F806_6349(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit819(void);
extern char *(*R5485[])();
extern char *(*R5464[])();

#ifdef __cplusplus
}
#endif

#endif
