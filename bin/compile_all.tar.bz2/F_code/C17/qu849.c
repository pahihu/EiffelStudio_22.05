/*
 * Code for class QUICK_SORTER [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "qu849.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {QUICK_SORTER}.subsort_with_comparator */
void F185_2454 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc11);
	RTLR(1,Current);
	RTLR(2,loc12);
	RTLR(3,loc7);
	RTLR(4,arg1);
	RTLR(5,loc8);
	RTLR(6,arg2);
	RTLR(7,tr1);
	RTLR(8,tr2);
	RTLR(9,loc6);
	RTLR(10,tr3);
	RTLIU(11);
	
	RTEAA("subsort_with_comparator", 184, Current, 12, 4, 2634);
	RTGC;
	RTHOOK(1);
	loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg4 - arg3) + ((EIF_INTEGER_32) 1L));
	for (;;) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 0L))) break;
		RTHOOK(3);
		loc5 /= ((EIF_INTEGER_32) 2L);
		RTHOOK(4);
		loc4++;
	}
	RTHOOK(5);
	loc4 += ((EIF_INTEGER_32) 10L);
	RTHOOK(6);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,880,1219,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc11 = RTLNS(typres0.id, 880, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F881_6892(RTCW(loc11), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), loc4);
	RTHOOK(7);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,880,1219,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc12 = RTLNS(typres0.id, 880, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F881_6892(RTCW(loc12), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), loc4);
	RTHOOK(8);
	F881_6916(RTCW(loc11), arg3, ((EIF_INTEGER_32) 1L));
	RTHOOK(9);
	F881_6916(RTCW(loc12), arg4, ((EIF_INTEGER_32) 1L));
	RTHOOK(10);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(11);
		if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) break;
		RTHOOK(12);
		loc9 = F881_6897(RTCW(loc11), loc4);
		RTHOOK(13);
		loc10 = F881_6897(RTCW(loc12), loc4);
		RTHOOK(14);
		loc4--;
		RTHOOK(15);
		loc1 = (EIF_INTEGER_32) loc9;
		RTHOOK(16);
		loc2 = (EIF_INTEGER_32) loc10;
		RTHOOK(17);
		if ((EIF_BOOLEAN) (loc1 < loc2)) {
			RTHOOK(18);
			if ((EIF_BOOLEAN)(loc2 == (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)))) {
				RTHOOK(19);
				loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5491[Dtype(RTCW(arg1))-877])(arg1, (EIF_REFERENCE) &loc1);
				RTHOOK(20);
				loc8 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5491[Dtype(RTCW(arg1))-877])(arg1, (EIF_REFERENCE) &loc2);
				RTHOOK(21);
				tr1 = RTCCL(loc8);
				tr2 = RTCCL(loc7);
				tb1 = F282_3460(RTCW(arg2), tr1, tr2);
				if (tb1) {
					RTHOOK(22);
					tr1 = RTCCL(loc7);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5494[Dtype(RTCW(arg1))-851])(arg1, tr1, (EIF_REFERENCE) &loc2);
					RTHOOK(23);
					tr1 = RTCCL(loc8);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5494[Dtype(RTCW(arg1))-851])(arg1, tr1, (EIF_REFERENCE) &loc1);
				}
			} else {
				RTHOOK(24);
				loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc2) / ((EIF_INTEGER_32) 2L));
				RTHOOK(25);
				loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5491[Dtype(RTCW(arg1))-877])(arg1, (EIF_REFERENCE) &loc3);
				RTHOOK(26);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5491[Dtype(RTCW(arg1))-877])(arg1, (EIF_REFERENCE) &loc10);
				tr2 = RTCCL(tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5494[Dtype(RTCW(arg1))-851])(arg1, tr2, (EIF_REFERENCE) &loc3);
				for (;;) {
					RTHOOK(27);
					if ((EIF_BOOLEAN) (loc1 >= loc2)) break;
					for (;;) {
						RTHOOK(28);
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (loc1 >= loc2)) {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5491[Dtype(RTCW(arg1))-877])(arg1, (EIF_REFERENCE) &loc1);
							tr2 = RTCCL(tr1);
							tr3 = RTCCL(loc6);
							tb2 = F282_3460(RTCW(arg2), tr2, tr3);
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) break;
						RTHOOK(29);
						loc1++;
					}
					RTHOOK(30);
					loc2--;
					for (;;) {
						RTHOOK(31);
						tb2 = '\01';
						if (!(EIF_BOOLEAN) (loc2 <= loc1)) {
							tr1 = RTCCL(loc6);
							tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5491[Dtype(RTCW(arg1))-877])(arg1, (EIF_REFERENCE) &loc2);
							tr3 = RTCCL(tr2);
							tb3 = F282_3460(RTCW(arg2), tr1, tr3);
							tb2 = (EIF_BOOLEAN) !tb3;
						}
						if (tb2) break;
						RTHOOK(32);
						loc2--;
					}
					RTHOOK(33);
					if ((EIF_BOOLEAN) (loc1 < loc2)) {
						RTHOOK(34);
						loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5491[Dtype(RTCW(arg1))-877])(arg1, (EIF_REFERENCE) &loc1);
						RTHOOK(35);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5491[Dtype(RTCW(arg1))-877])(arg1, (EIF_REFERENCE) &loc2);
						tr2 = RTCCL(tr1);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5494[Dtype(RTCW(arg1))-851])(arg1, tr2, (EIF_REFERENCE) &loc1);
						RTHOOK(36);
						tr1 = RTCCL(loc7);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5494[Dtype(RTCW(arg1))-851])(arg1, tr1, (EIF_REFERENCE) &loc2);
						RTHOOK(37);
						loc1++;
					}
				}
				RTHOOK(38);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5491[Dtype(RTCW(arg1))-877])(arg1, (EIF_REFERENCE) &loc1);
				tr2 = RTCCL(tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5494[Dtype(RTCW(arg1))-851])(arg1, tr2, (EIF_REFERENCE) &loc10);
				RTHOOK(39);
				tr1 = RTCCL(loc6);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5494[Dtype(RTCW(arg1))-851])(arg1, tr1, (EIF_REFERENCE) &loc1);
				RTHOOK(40);
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)) > loc9)) {
					RTHOOK(41);
					loc4++;
					RTHOOK(42);
					F881_6918(RTCW(loc11), loc9, loc4);
					RTHOOK(43);
					F881_6918(RTCW(loc12), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)), loc4);
				}
				RTHOOK(44);
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) < loc10)) {
					RTHOOK(45);
					loc4++;
					RTHOOK(46);
					F881_6918(RTCW(loc11), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), loc4);
					RTHOOK(47);
					F881_6918(RTCW(loc12), loc10, loc4);
				}
			}
		}
	}
	RTHOOK(48);
	RTLE;
	RTEE;
}

void EIF_Minit849 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
