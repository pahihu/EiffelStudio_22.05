
#ifndef _C17_co846_
#define _C17_co846_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F280_3451(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F280_3454(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit846(void);
extern EIF_BOOLEAN F282_3460(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
