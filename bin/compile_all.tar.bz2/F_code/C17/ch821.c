/*
 * Code for class CHAIN [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ch821.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CHAIN}.has */
EIF_BOOLEAN F898_6953 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("has", 897, Current, 1, 1, 9797);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5504[dtype-943])(Current);
	RTHOOK(2);
	Result = F634_6151(Current, arg1);
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5506[dtype-943])(Current, loc1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CHAIN}.i_th */
EIF_INTEGER_32 F898_6955 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("i_th", 897, Current, 1, 1, 9799);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5504[dtype-943])(Current);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5965[dtype-943])(Current, arg1);
	RTHOOK(3);
	Result = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5498[dtype-759])(Current));
	RTHOOK(4);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5506[dtype-943])(Current, loc1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CHAIN}.lower */
EIF_INTEGER_32 F898_6958 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {CHAIN}.valid_index */
EIF_BOOLEAN F898_6963 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("valid_index", 897, Current, 0, 1, 9807);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 1L))) {
		Result = (EIF_BOOLEAN) (arg1 <= (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5561[Dtype(Current)-800])(Current));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CHAIN}.isfirst */
EIF_BOOLEAN F898_6964 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("isfirst", 897, Current, 0, 0, 9808);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) !F764_6292(Current)) {
		Result = (EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5472[Dtype(Current)-759])(Current) == ((EIF_INTEGER_32) 1L));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CHAIN}.islast */
EIF_BOOLEAN F898_6965 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("islast", 897, Current, 0, 0, 9809);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) !F764_6292(Current)) {
		Result = (EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5472[dtype-759])(Current) == (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5561[dtype-800])(Current));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CHAIN}.off */
EIF_BOOLEAN F898_6966 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 897, Current, 0, 0, 9810);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!(EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5472[dtype-759])(Current) == ((EIF_INTEGER_32) 0L))) {
		Result = (EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5472[dtype-759])(Current) == (EIF_INTEGER_32) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5561[dtype-800])(Current) + ((EIF_INTEGER_32) 1L)));
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CHAIN}.put_i_th */
void F898_6969 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("put_i_th", 897, Current, 1, 2, 9813);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5504[dtype-943])(Current);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5965[dtype-943])(Current, arg2);
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5502[dtype-943])(Current, (EIF_REFERENCE) &arg1);
	RTHOOK(4);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5506[dtype-943])(Current, loc1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CHAIN}.append */
void F898_6970 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("append", 897, Current, 2, 1, 9814);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTHOOK(3);
		loc1 = F1_14(Current);
	}
	RTHOOK(4);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5504[dtype-943])(Current);
	RTHOOK(5);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5465[Dtype(RTCW(loc1))-759])(loc1);
	for (;;) {
		RTHOOK(6);
		tb1 = F634_6157(RTCW(loc1));
		if (tb1) break;
		RTHOOK(7);
		ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5498[Dtype(RTCW(loc1))-759])(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[dtype-759])(Current, (EIF_REFERENCE) &ti4_1);
		RTHOOK(8);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5477[dtype-943])(Current);
		RTHOOK(9);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5478[Dtype(RTCW(loc1))-759])(loc1);
	}
	RTHOOK(10);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5506[dtype-943])(Current, loc2);
	RTHOOK(11);
	RTLE;
	RTEE;
}

void EIF_Minit821 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
