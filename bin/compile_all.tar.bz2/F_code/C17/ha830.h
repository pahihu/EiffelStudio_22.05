
#ifndef _C17_ha830_
#define _C17_ha830_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F548_6060(EIF_REFERENCE);
extern EIF_INTEGER_32 F548_6061(EIF_REFERENCE);
extern EIF_BOOLEAN F548_6063(EIF_REFERENCE);
extern void F548_6064(EIF_REFERENCE);
extern EIF_REFERENCE F548_6065(EIF_REFERENCE);
extern void EIF_Minit830(void);
extern char *(*R5831[])();
extern char *(*R5832[])();
extern char *(*R5407[])();
extern char *(*R5795[])();
extern long O5840[];
extern long O5841[];

#ifdef __cplusplus
}
#endif

#endif
