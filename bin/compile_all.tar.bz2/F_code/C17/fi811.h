
#ifndef _C17_fi811_
#define _C17_fi811_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F764_6292(EIF_REFERENCE);
extern void EIF_Minit811(void);
extern char *(*R5561[])();

#ifdef __cplusplus
}
#endif

#endif
