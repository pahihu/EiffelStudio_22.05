
#ifndef _C17_to828_
#define _C17_to828_

#ifdef __cplusplus
extern "C" {
#endif

extern void F418_4946(EIF_REFERENCE, EIF_INTEGER_32);
extern void F418_4947(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F418_4953(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit828(void);
extern void F1143_9206(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4515[];
extern EIF_TYPE_INDEX *Y4515_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
