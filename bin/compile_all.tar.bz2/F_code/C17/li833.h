
#ifndef _C17_li833_
#define _C17_li833_

#ifdef __cplusplus
extern "C" {
#endif

extern void F944_7001(EIF_REFERENCE);
extern EIF_REFERENCE F944_7003(EIF_REFERENCE);
extern EIF_REFERENCE F944_7004(EIF_REFERENCE);
extern EIF_REFERENCE F944_7005(EIF_REFERENCE);
extern EIF_INTEGER_32 F944_7006(EIF_REFERENCE);
extern EIF_REFERENCE F944_7007(EIF_REFERENCE);
extern EIF_REFERENCE F944_7008(EIF_REFERENCE);
extern EIF_INTEGER_32 F944_7010(EIF_REFERENCE);
extern EIF_BOOLEAN F944_7012(EIF_REFERENCE);
extern EIF_BOOLEAN F944_7013(EIF_REFERENCE);
extern EIF_BOOLEAN F944_7014(EIF_REFERENCE);
extern EIF_BOOLEAN F944_7015(EIF_REFERENCE);
extern EIF_BOOLEAN F944_7016(EIF_REFERENCE);
extern void F944_7020(EIF_REFERENCE);
extern void F944_7021(EIF_REFERENCE);
extern void F944_7022(EIF_REFERENCE);
extern void F944_7023(EIF_REFERENCE);
extern void F944_7024(EIF_REFERENCE, EIF_INTEGER_32);
extern void F944_7025(EIF_REFERENCE, EIF_INTEGER_32);
extern void F944_7026(EIF_REFERENCE, EIF_REFERENCE);
extern void F944_7027(EIF_REFERENCE, EIF_REFERENCE);
extern void F944_7028(EIF_REFERENCE, EIF_REFERENCE);
extern void F944_7031(EIF_REFERENCE, EIF_REFERENCE);
extern void F944_7034(EIF_REFERENCE);
extern void F944_7037(EIF_REFERENCE);
extern void F944_7038(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F944_7040(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F944_7041(EIF_REFERENCE);
extern EIF_REFERENCE F944_7044(EIF_REFERENCE);
extern void F944_7045(EIF_REFERENCE, EIF_REFERENCE);
extern void F944_7046(EIF_REFERENCE);
extern void EIF_Minit833(void);
extern char *(*R5485[])();
extern char *(*R2464[])();
extern char *(*R2465[])();
extern char *(*R2469[])();
extern char *(*R2470[])();
extern char *(*R5410[])();
extern char *(*R5455[])();
extern char *(*R5413[])();
extern char *(*R3636[])();
extern char *(*R5964[])();
extern char *(*R5966[])();
extern char *(*R5967[])();
extern char *(*R5464[])();
extern char *(*R5465[])();
extern char *(*R5504[])();
extern char *(*R5506[])();
extern char *(*R5472[])();
extern char *(*R5498[])();
extern char *(*R5477[])();
extern char *(*R5478[])();
extern char *(*R5983[])();
extern char *(*R5984[])();
extern char *(*R5987[])();
extern char *(*R5988[])();
extern char *(*R5989[])();
extern long O2468[];
extern EIF_TYPE_INDEX Y5346[];
extern EIF_TYPE_INDEX *Y5346_gen_type [];
extern EIF_TYPE_INDEX Y5504[];
extern EIF_TYPE_INDEX *Y5504_gen_type [];
extern EIF_TYPE_INDEX Y5498[];
extern EIF_TYPE_INDEX *Y5498_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
