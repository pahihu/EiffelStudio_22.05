
#ifndef _C17_ar827_
#define _C17_ar827_

#ifdef __cplusplus
extern "C" {
#endif

extern void F571_6092(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F571_6093(EIF_REFERENCE);
extern EIF_REFERENCE F571_6094(EIF_REFERENCE);
extern EIF_REFERENCE F571_6096(EIF_REFERENCE);
extern EIF_INTEGER_32 F571_6097(EIF_REFERENCE);
extern void EIF_Minit827(void);
extern EIF_INTEGER_32 F951_7094(EIF_REFERENCE);
extern EIF_REFERENCE F951_7075(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5317[];
extern EIF_TYPE_INDEX *Y5317_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
