
#ifndef _C17_re825_
#define _C17_re825_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F788_6298(EIF_REFERENCE);
extern void F788_6300(EIF_REFERENCE);
extern void EIF_Minit825(void);
extern char *(*R5562[])();
extern char *(*R5568[])();

#ifdef __cplusplus
}
#endif

#endif
