/*
 * Code for class COLLECTION [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co813.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COLLECTION}.fill */
void F658_6176 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("fill", 657, Current, 1, 1, 7242);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5461[Dtype(RTCW(arg1))-759])(arg1);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5465[Dtype(RTCW(loc1))-759])(loc1);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5481[dtype-759])(Current)) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5464[Dtype(RTCW(loc1))-759])(loc1);
			tb1 = tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5463[Dtype(RTCW(loc1))-759])(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[dtype-759])(Current, (EIF_REFERENCE) &ti4_1);
		RTHOOK(5);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5478[Dtype(RTCW(loc1))-759])(loc1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

void EIF_Minit813 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
