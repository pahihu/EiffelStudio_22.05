
#ifndef _C17_ty801_
#define _C17_ty801_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F525_6032(EIF_REFERENCE);
extern void EIF_Minit801(void);
extern char *(*R5411[])();
extern char *(*R5398[])();
extern char *(*R5795[])();

#ifdef __cplusplus
}
#endif

#endif
