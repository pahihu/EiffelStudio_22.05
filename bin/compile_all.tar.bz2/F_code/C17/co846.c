/*
 * Code for class COMPARATOR [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co846.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COMPARATOR}.order_equal */
EIF_BOOLEAN F280_3451 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("order_equal", 279, Current, 0, 2, 3575);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tr1 = RTCCL(arg1);
	tr2 = RTCCL(arg2);
	if ((EIF_BOOLEAN) !F282_3460(Current, tr1, tr2)) {
		tr1 = RTCCL(arg2);
		tr2 = RTCCL(arg1);
		Result = (EIF_BOOLEAN) !F282_3460(Current, tr1, tr2);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {COMPARATOR}.test */
EIF_BOOLEAN F280_3454 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("test", 279, Current, 0, 2, 3578);
	RTGC;
	RTHOOK(1);
	if (RTCEQ(arg1, arg2)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(arg1 == NULL)) {
			RTHOOK(5);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN)(arg2 == NULL)) {
				RTHOOK(7);
				RTHOOK(8);
				RTLE;
				RTEE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				RTHOOK(9);
				tr1 = RTCCL(arg2);
				tr2 = RTCCL(arg1);
				Result = F280_3451(Current, tr1, tr2);
			}
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit846 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
