#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R3607[775])();
void R3607_init () {
	R3607[0] = (char *(*)()) F318_3918;
	R3607[773] = (char *(*)()) F1092_8705;
	R3607[774] = (char *(*)()) F1093_8723;
}

char *(*R3608[775])();
void R3608_init () {
	R3608[0] = (char *(*)()) F318_3919;
	R3608[773] = (char *(*)()) F1092_8707;
	R3608[774] = (char *(*)()) F1093_8727;
}

char *(*R3610[775])();
void R3610_init () {
	R3610[0] = (char *(*)()) F318_3921;
	R3610[773] = (char *(*)()) F1092_8709;
	R3610[774] = (char *(*)()) F1093_8729;
}

char *(*R3611[775])();
void R3611_init () {
	R3611[0] = (char *(*)()) F318_3922;
	R3611[773] = (char *(*)()) F1092_8710;
	R3611[774] = (char *(*)()) F1093_8730;
}

char *(*R3612[775])();
void R3612_init () {
	R3612[0] = (char *(*)()) F318_3923;
	R3612[773] = (char *(*)()) F1092_8711;
	R3612[774] = (char *(*)()) F1093_8731;
}

char *(*R3613[775])();
void R3613_init () {
	R3613[0] = (char *(*)()) F319_3927;
	{long i; for (i = 773; i < 775; i++) R3613[i] = (char *(*)()) F320_3930;}
}

char *(*R3614[775])();
void R3614_init () {
	R3614[0] = (char *(*)()) F319_3928;
	{long i; for (i = 773; i < 775; i++) R3614[i] = (char *(*)()) F320_3932;}
}

char *(*R3632[2])();
void R3632_init () {
	R3632[0] = (char *(*)()) F1092_8712;
	R3632[1] = (char *(*)()) F1093_8732;
}

char *(*R3633[2])();
void R3633_init () {
	R3633[0] = (char *(*)()) F1092_8714;
	R3633[1] = (char *(*)()) F1093_8738;
}

char *(*R3636[2])();
void R3636_init () {
	R3636[0] = (char *(*)()) F323_3936;
	R3636[1] = (char *(*)()) F324_3936;
}

char *(*R3689[41])();
void R3689_init () {
	R3689[0] = (char *(*)()) F330_3988;
	R3689[3] = (char *(*)()) F333_4012;
	R3689[5] = (char *(*)()) F335_4014;
	R3689[6] = (char *(*)()) F336_4020;
	R3689[7] = (char *(*)()) F337_4037;
	{long i; for (i = 8; i < 11; i++) R3689[i] = (char *(*)()) F338_4041;}
	R3689[12] = (char *(*)()) F342_4045;
	R3689[13] = (char *(*)()) F343_4047;
	R3689[14] = (char *(*)()) F344_4049;
	R3689[16] = (char *(*)()) F346_4051;
	R3689[17] = (char *(*)()) F347_4053;
	R3689[20] = (char *(*)()) F350_4057;
	R3689[21] = (char *(*)()) F351_4061;
	R3689[23] = (char *(*)()) F353_4063;
	R3689[24] = (char *(*)()) F354_4065;
	R3689[25] = (char *(*)()) F355_4067;
	R3689[27] = (char *(*)()) F357_4073;
	R3689[28] = (char *(*)()) F358_4077;
	R3689[29] = (char *(*)()) F359_4081;
	R3689[30] = (char *(*)()) F360_4083;
	R3689[32] = (char *(*)()) F362_4085;
	R3689[33] = (char *(*)()) F363_4087;
	R3689[35] = (char *(*)()) F365_4089;
	R3689[36] = (char *(*)()) F366_4091;
	R3689[37] = (char *(*)()) F367_4093;
	R3689[38] = (char *(*)()) F368_4095;
	R3689[39] = (char *(*)()) F369_4099;
	R3689[40] = (char *(*)()) F370_4101;
}

char *(*R3758[62])();
void R3758_init () {
	R3758[0] = (char *(*)()) F1101_9080;
	R3758[60] = (char *(*)()) F1161_9435;
	R3758[61] = (char *(*)()) F1162_9442;
}

char *(*R3916[966])();
void R3916_init () {
	R3916[0] = (char *(*)()) F386_4423;
	{long i; for (i = 645; i < 647; i++) R3916[i] = (char *(*)()) F1030_7976;}
	{long i; for (i = 648; i < 650; i++) R3916[i] = (char *(*)()) F1033_8016;}
	{long i; for (i = 696; i < 698; i++) R3916[i] = (char *(*)()) F1081_8325;}
	{long i; for (i = 700; i < 702; i++) R3916[i] = (char *(*)()) F1085_8490;}
	R3916[714] = (char *(*)()) F1100_8949;
	R3916[716] = (char *(*)()) F1102_9136;
	{long i; for (i = 770; i < 773; i++) R3916[i] = (char *(*)()) F1153_9292;}
	{long i; for (i = 774; i < 777; i++) R3916[i] = (char *(*)()) F1153_9292;}
	R3916[830] = (char *(*)()) F1216_9666_3916_2;
	R3916[831] = (char *(*)()) F1217_9666_3916_2;
	R3916[833] = (char *(*)()) F1219_9765_3916_2;
	R3916[834] = (char *(*)()) F1220_9765_3916_2;
	R3916[836] = (char *(*)()) F1222_9864_3916_2;
	R3916[837] = (char *(*)()) F1223_9864_3916_2;
	R3916[839] = (char *(*)()) F1225_9963_3916_2;
	R3916[840] = (char *(*)()) F1226_9963_3916_2;
	R3916[842] = (char *(*)()) F1228_10058_3916_2;
	R3916[843] = (char *(*)()) F1229_10058_3916_2;
	R3916[845] = (char *(*)()) F1231_10152_3916_2;
	R3916[846] = (char *(*)()) F1232_10152_3916_2;
	R3916[848] = (char *(*)()) F1234_10247_3916_2;
	R3916[849] = (char *(*)()) F1235_10247_3916_2;
	R3916[851] = (char *(*)()) F1237_10342_3916_2;
	R3916[852] = (char *(*)()) F1238_10342_3916_2;
	R3916[854] = (char *(*)()) F1240_10411_3916_2;
	R3916[855] = (char *(*)()) F1241_10411_3916_2;
	R3916[857] = (char *(*)()) F1243_10477_3916_2;
	R3916[858] = (char *(*)()) F1244_10477_3916_2;
	R3916[880] = (char *(*)()) F1266_10811;
	R3916[953] = (char *(*)()) F1339_12854;
	R3916[955] = (char *(*)()) F1341_12892;
	R3916[958] = (char *(*)()) F1344_12973;
	R3916[965] = (char *(*)()) F1351_13257;
}
static EIF_BOOLEAN F1216_9666_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1216_9666(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1217_9666_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1217_9666(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1219_9765_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1219_9765(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1220_9765_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1220_9765(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1222_9864_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1222_9864(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1223_9864_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1223_9864(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1225_9963_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1225_9963(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1226_9963_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1226_9963(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1228_10058_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1228_10058(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1229_10058_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1229_10058(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1231_10152_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1231_10152(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1232_10152_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1232_10152(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1234_10247_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1234_10247(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1235_10247_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1235_10247(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1237_10342_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1237_10342(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1238_10342_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1238_10342(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1240_10411_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1240_10411(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1241_10411_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1241_10411(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1243_10477_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1243_10477(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1244_10477_3916_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1244_10477(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R4500[7])();
void R4500_init () {
	{long i; for (i = 0; i < 2; i++) R4500[i] = (char *(*)()) F408_4924;}
	R4500[2] = (char *(*)()) F411_4941;
	{long i; for (i = 3; i < 7; i++) R4500[i] = (char *(*)()) F408_4924;}
}

char *(*R4513[919])();
void R4513_init () {
	R4513[0] = (char *(*)()) F424_4946;
	R4513[446] = (char *(*)()) F416_4946;
	R4513[447] = (char *(*)()) F417_4946;
	R4513[448] = (char *(*)()) F418_4946;
	R4513[449] = (char *(*)()) F419_4946;
	R4513[450] = (char *(*)()) F420_4946;
	R4513[451] = (char *(*)()) F421_4946;
	R4513[452] = (char *(*)()) F422_4946;
	R4513[453] = (char *(*)()) F423_4946;
	R4513[454] = (char *(*)()) F424_4946;
	R4513[455] = (char *(*)()) F425_4946;
	R4513[456] = (char *(*)()) F426_4946;
	R4513[457] = (char *(*)()) F427_4946;
	R4513[516] = (char *(*)()) F416_4946;
	R4513[517] = (char *(*)()) F417_4946;
	R4513[518] = (char *(*)()) F418_4946;
	R4513[519] = (char *(*)()) F419_4946;
	R4513[520] = (char *(*)()) F420_4946;
	R4513[521] = (char *(*)()) F421_4946;
	R4513[522] = (char *(*)()) F422_4946;
	R4513[523] = (char *(*)()) F423_4946;
	R4513[524] = (char *(*)()) F424_4946;
	R4513[525] = (char *(*)()) F425_4946;
	R4513[526] = (char *(*)()) F426_4946;
	R4513[527] = (char *(*)()) F427_4946;
	{long i; for (i = 528; i < 531; i++) R4513[i] = (char *(*)()) F416_4946;}
	R4513[531] = (char *(*)()) F418_4946;
	R4513[532] = (char *(*)()) F416_4946;
	R4513[650] = (char *(*)()) F420_4946;
	R4513[654] = (char *(*)()) F422_4946;
	R4513[918] = (char *(*)()) F420_4946;
}

char *(*R4514[919])();
void R4514_init () {
	R4514[0] = (char *(*)()) F424_4947_4514_69;
	R4514[446] = (char *(*)()) F416_4947;
	R4514[447] = (char *(*)()) F417_4947_4514_69;
	R4514[448] = (char *(*)()) F418_4947_4514_69;
	R4514[449] = (char *(*)()) F419_4947_4514_69;
	R4514[450] = (char *(*)()) F420_4947_4514_69;
	R4514[451] = (char *(*)()) F421_4947_4514_69;
	R4514[452] = (char *(*)()) F422_4947_4514_69;
	R4514[453] = (char *(*)()) F423_4947_4514_69;
	R4514[454] = (char *(*)()) F424_4947_4514_69;
	R4514[455] = (char *(*)()) F425_4947_4514_69;
	R4514[456] = (char *(*)()) F426_4947_4514_69;
	R4514[457] = (char *(*)()) F427_4947_4514_69;
	R4514[516] = (char *(*)()) F416_4947;
	R4514[517] = (char *(*)()) F417_4947_4514_69;
	R4514[518] = (char *(*)()) F418_4947_4514_69;
	R4514[519] = (char *(*)()) F419_4947_4514_69;
	R4514[520] = (char *(*)()) F420_4947_4514_69;
	R4514[521] = (char *(*)()) F421_4947_4514_69;
	R4514[522] = (char *(*)()) F422_4947_4514_69;
	R4514[523] = (char *(*)()) F423_4947_4514_69;
	R4514[524] = (char *(*)()) F424_4947_4514_69;
	R4514[525] = (char *(*)()) F425_4947_4514_69;
	R4514[526] = (char *(*)()) F426_4947_4514_69;
	R4514[527] = (char *(*)()) F427_4947_4514_69;
	{long i; for (i = 528; i < 531; i++) R4514[i] = (char *(*)()) F416_4947;}
	R4514[531] = (char *(*)()) F418_4947_4514_69;
	R4514[532] = (char *(*)()) F416_4947;
	R4514[650] = (char *(*)()) F420_4947_4514_69;
	R4514[654] = (char *(*)()) F422_4947_4514_69;
	R4514[918] = (char *(*)()) F420_4947_4514_69;
}
static void F424_4947_4514_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F424_4947(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F417_4947_4514_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F417_4947(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F418_4947_4514_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F418_4947(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F419_4947_4514_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F419_4947(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F420_4947_4514_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F420_4947(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F421_4947_4514_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F421_4947(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F422_4947_4514_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F422_4947(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F423_4947_4514_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F423_4947(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F425_4947_4514_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F425_4947(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F426_4947_4514_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F426_4947(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F427_4947_4514_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F427_4947(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4520[919])();
void R4520_init () {
	R4520[0] = (char *(*)()) F424_4953;
	R4520[446] = (char *(*)()) F416_4953;
	R4520[447] = (char *(*)()) F417_4953;
	R4520[448] = (char *(*)()) F418_4953;
	R4520[449] = (char *(*)()) F419_4953;
	R4520[450] = (char *(*)()) F420_4953;
	R4520[451] = (char *(*)()) F421_4953;
	R4520[452] = (char *(*)()) F422_4953;
	R4520[453] = (char *(*)()) F423_4953;
	R4520[454] = (char *(*)()) F424_4953;
	R4520[455] = (char *(*)()) F425_4953;
	R4520[456] = (char *(*)()) F426_4953;
	R4520[457] = (char *(*)()) F427_4953;
	R4520[516] = (char *(*)()) F416_4953;
	R4520[517] = (char *(*)()) F417_4953;
	R4520[518] = (char *(*)()) F418_4953;
	R4520[519] = (char *(*)()) F419_4953;
	R4520[520] = (char *(*)()) F420_4953;
	R4520[521] = (char *(*)()) F421_4953;
	R4520[522] = (char *(*)()) F422_4953;
	R4520[523] = (char *(*)()) F423_4953;
	R4520[524] = (char *(*)()) F424_4953;
	R4520[525] = (char *(*)()) F425_4953;
	R4520[526] = (char *(*)()) F426_4953;
	R4520[527] = (char *(*)()) F427_4953;
	{long i; for (i = 528; i < 531; i++) R4520[i] = (char *(*)()) F416_4953;}
	R4520[531] = (char *(*)()) F418_4953;
	R4520[532] = (char *(*)()) F416_4953;
	R4520[650] = (char *(*)()) F420_4953;
	R4520[654] = (char *(*)()) F422_4953;
	R4520[918] = (char *(*)()) F420_4953;
}

static EIF_TYPE_INDEX Y4521_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype12[] = {1237,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype13[] = {1237,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype44[] = {0xFF01,1300,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype47[] = {0xFF01,964,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype48[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype49[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype50[] = {1031,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype51[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y4521_pgtype52[] = {1034,0xFFFF};
EIF_TYPE_INDEX *Y4521_gen_type [937];
EIF_TYPE_INDEX Y4521 [937];
void Y4521_init (void)
{
	egc_routines_types [4521] = Y4521;
	egc_routines_gen_types [4521] = Y4521_gen_type;
	egc_routines_offset [4521] = 415;
	Y4521_gen_type [0] = Y4521_pgtype0;
	Y4521_gen_type [1] = Y4521_pgtype1;
	Y4521_gen_type [2] = Y4521_pgtype2;
	Y4521_gen_type [3] = Y4521_pgtype3;
	Y4521_gen_type [4] = Y4521_pgtype4;
	Y4521_gen_type [5] = Y4521_pgtype5;
	Y4521_gen_type [6] = Y4521_pgtype6;
	Y4521_gen_type [7] = Y4521_pgtype7;
	Y4521_gen_type [8] = Y4521_pgtype8;
	Y4521_gen_type [9] = Y4521_pgtype9;
	Y4521_gen_type [10] = Y4521_pgtype10;
	Y4521_gen_type [11] = Y4521_pgtype11;
	Y4521_gen_type [17] = Y4521_pgtype12;
	Y4521_gen_type [18] = Y4521_pgtype13;
	Y4521_gen_type [463] = Y4521_pgtype14;
	Y4521_gen_type [464] = Y4521_pgtype15;
	Y4521_gen_type [465] = Y4521_pgtype16;
	Y4521_gen_type [466] = Y4521_pgtype17;
	Y4521_gen_type [467] = Y4521_pgtype18;
	Y4521_gen_type [468] = Y4521_pgtype19;
	Y4521_gen_type [469] = Y4521_pgtype20;
	Y4521_gen_type [470] = Y4521_pgtype21;
	Y4521_gen_type [471] = Y4521_pgtype22;
	Y4521_gen_type [472] = Y4521_pgtype23;
	Y4521_gen_type [473] = Y4521_pgtype24;
	Y4521_gen_type [474] = Y4521_pgtype25;
	Y4521_gen_type [475] = Y4521_pgtype26;
	Y4521_gen_type [476] = Y4521_pgtype27;
	Y4521_gen_type [477] = Y4521_pgtype28;
	Y4521_gen_type [478] = Y4521_pgtype29;
	Y4521_gen_type [479] = Y4521_pgtype30;
	Y4521_gen_type [533] = Y4521_pgtype31;
	Y4521_gen_type [534] = Y4521_pgtype32;
	Y4521_gen_type [535] = Y4521_pgtype33;
	Y4521_gen_type [536] = Y4521_pgtype34;
	Y4521_gen_type [537] = Y4521_pgtype35;
	Y4521_gen_type [538] = Y4521_pgtype36;
	Y4521_gen_type [539] = Y4521_pgtype37;
	Y4521_gen_type [540] = Y4521_pgtype38;
	Y4521_gen_type [541] = Y4521_pgtype39;
	Y4521_gen_type [542] = Y4521_pgtype40;
	Y4521_gen_type [543] = Y4521_pgtype41;
	Y4521_gen_type [544] = Y4521_pgtype42;
	Y4521_gen_type [545] = Y4521_pgtype43;
	Y4521_gen_type [546] = Y4521_pgtype44;
	Y4521_gen_type [547] = Y4521_pgtype45;
	Y4521_gen_type [548] = Y4521_pgtype46;
	Y4521_gen_type [549] = Y4521_pgtype47;
	Y4521_gen_type [667] = Y4521_pgtype48;
	Y4521_gen_type [668] = Y4521_pgtype49;
	Y4521_gen_type [671] = Y4521_pgtype50;
	Y4521_gen_type [935] = Y4521_pgtype51;
	Y4521_gen_type [936] = Y4521_pgtype52;
	{long i; for (i = 17; i < 19; i++) Y4521[i] = 1237;};
	Y4521[546] = 1300;
	Y4521[549] = 964;
	{long i; for (i = 667; i < 669; i++) Y4521[i] = 1034;};
	Y4521[671] = 1031;
	{long i; for (i = 935; i < 937; i++) Y4521[i] = 1034;};
}


#ifdef __cplusplus
}
#endif
