#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5413[22])();
void R5413_init () {
	R5413[0] = (char *(*)()) F535_6038;
	R5413[1] = (char *(*)()) F536_6038;
	R5413[2] = (char *(*)()) F537_6038;
	R5413[3] = (char *(*)()) F538_6038;
	R5413[4] = (char *(*)()) F539_6038;
	R5413[5] = (char *(*)()) F540_6038;
	R5413[6] = (char *(*)()) F541_6038;
	R5413[7] = (char *(*)()) F542_6038;
	R5413[8] = (char *(*)()) F543_6038;
	R5413[9] = (char *(*)()) F544_6038;
	R5413[10] = (char *(*)()) F545_6038;
	R5413[11] = (char *(*)()) F546_6038;
	{long i; for (i = 12; i < 14; i++) R5413[i] = (char *(*)()) F535_6038;}
	R5413[14] = (char *(*)()) F536_6038;
	R5413[15] = (char *(*)()) F537_6038;
	R5413[16] = (char *(*)()) F540_6038;
	R5413[17] = (char *(*)()) F537_6038;
	R5413[18] = (char *(*)()) F543_6038;
	R5413[19] = (char *(*)()) F544_6038;
	R5413[20] = (char *(*)()) F535_6038;
	R5413[21] = (char *(*)()) F537_6038;
}

char *(*R5426[38])();
void R5426_init () {
	R5426[0] = (char *(*)()) F569_6097;
	R5426[1] = (char *(*)()) F570_6097;
	R5426[2] = (char *(*)()) F571_6097;
	R5426[3] = (char *(*)()) F572_6097;
	R5426[4] = (char *(*)()) F573_6097;
	R5426[5] = (char *(*)()) F574_6097;
	R5426[6] = (char *(*)()) F575_6097;
	R5426[7] = (char *(*)()) F576_6097;
	R5426[8] = (char *(*)()) F577_6097;
	R5426[9] = (char *(*)()) F578_6097;
	R5426[10] = (char *(*)()) F579_6097;
	R5426[11] = (char *(*)()) F580_6097;
	R5426[12] = (char *(*)()) F581_6103;
	R5426[13] = (char *(*)()) F582_6109;
	R5426[14] = (char *(*)()) F583_6115;
	R5426[15] = (char *(*)()) F584_6115;
	R5426[16] = (char *(*)()) F585_6115;
	R5426[17] = (char *(*)()) F586_6115;
	R5426[18] = (char *(*)()) F587_6115;
	R5426[19] = (char *(*)()) F588_6115;
	R5426[20] = (char *(*)()) F589_6115;
	R5426[21] = (char *(*)()) F590_6115;
	R5426[22] = (char *(*)()) F591_6115;
	R5426[23] = (char *(*)()) F592_6115;
	R5426[24] = (char *(*)()) F593_6115;
	R5426[25] = (char *(*)()) F594_6115;
	R5426[26] = (char *(*)()) F595_6119;
	R5426[27] = (char *(*)()) F596_6119;
	R5426[28] = (char *(*)()) F597_6119;
	R5426[29] = (char *(*)()) F598_6119;
	R5426[30] = (char *(*)()) F599_6119;
	R5426[31] = (char *(*)()) F600_6119;
	R5426[32] = (char *(*)()) F601_6119;
	R5426[33] = (char *(*)()) F602_6119;
	R5426[34] = (char *(*)()) F603_6119;
	R5426[35] = (char *(*)()) F604_6119;
	R5426[36] = (char *(*)()) F605_6119;
	R5426[37] = (char *(*)()) F606_6119;
}

char *(*R5428[12])();
void R5428_init () {
	R5428[0] = (char *(*)()) F569_6092;
	R5428[1] = (char *(*)()) F570_6092;
	R5428[2] = (char *(*)()) F571_6092;
	R5428[3] = (char *(*)()) F572_6092;
	R5428[4] = (char *(*)()) F573_6092;
	R5428[5] = (char *(*)()) F574_6092;
	R5428[6] = (char *(*)()) F575_6092;
	R5428[7] = (char *(*)()) F576_6092;
	R5428[8] = (char *(*)()) F577_6092;
	R5428[9] = (char *(*)()) F578_6092;
	R5428[10] = (char *(*)()) F579_6092;
	R5428[11] = (char *(*)()) F580_6092;
}

char *(*R5436[12])();
void R5436_init () {
	R5436[0] = (char *(*)()) F583_6110;
	R5436[1] = (char *(*)()) F584_6110;
	R5436[2] = (char *(*)()) F585_6110;
	R5436[3] = (char *(*)()) F586_6110;
	R5436[4] = (char *(*)()) F587_6110;
	R5436[5] = (char *(*)()) F588_6110;
	R5436[6] = (char *(*)()) F589_6110;
	R5436[7] = (char *(*)()) F590_6110;
	R5436[8] = (char *(*)()) F591_6110;
	R5436[9] = (char *(*)()) F592_6110;
	R5436[10] = (char *(*)()) F593_6110;
	R5436[11] = (char *(*)()) F594_6110;
}

char *(*R5439[12])();
void R5439_init () {
	R5439[0] = (char *(*)()) F595_6116;
	R5439[1] = (char *(*)()) F596_6116;
	R5439[2] = (char *(*)()) F597_6116;
	R5439[3] = (char *(*)()) F598_6116;
	R5439[4] = (char *(*)()) F599_6116;
	R5439[5] = (char *(*)()) F600_6116;
	R5439[6] = (char *(*)()) F601_6116;
	R5439[7] = (char *(*)()) F602_6116;
	R5439[8] = (char *(*)()) F603_6116;
	R5439[9] = (char *(*)()) F604_6116;
	R5439[10] = (char *(*)()) F605_6116;
	R5439[11] = (char *(*)()) F606_6116;
}

char *(*R5441[2])();
void R5441_init () {
	R5441[0] = (char *(*)()) F1089_8631;
	R5441[1] = (char *(*)()) F1090_8644;
}

char *(*R5445[2])();
void R5445_init () {
	R5445[0] = (char *(*)()) F1089_8632;
	R5445[1] = (char *(*)()) F1090_8646;
}

char *(*R5450[2])();
void R5450_init () {
	R5450[0] = (char *(*)()) F1089_8637;
	R5450[1] = (char *(*)()) F1090_8649;
}

char *(*R5454[592])();
void R5454_init () {
	R5454[0] = (char *(*)()) F760_6266_5454_2;
	R5454[1] = (char *(*)()) F761_6285_5454_2;
	{long i; for (i = 69; i < 71; i++) R5454[i] = (char *(*)()) F636_6151_5454_2;}
	R5454[119] = (char *(*)()) F879_6900;
	R5454[120] = (char *(*)()) F880_6900_5454_2;
	R5454[121] = (char *(*)()) F881_6900_5454_2;
	R5454[122] = (char *(*)()) F882_6900_5454_2;
	R5454[123] = (char *(*)()) F883_6900_5454_2;
	R5454[124] = (char *(*)()) F884_6900_5454_2;
	R5454[125] = (char *(*)()) F885_6900_5454_2;
	R5454[126] = (char *(*)()) F886_6900_5454_2;
	R5454[127] = (char *(*)()) F887_6900_5454_2;
	R5454[128] = (char *(*)()) F888_6900_5454_2;
	R5454[129] = (char *(*)()) F889_6900_5454_2;
	R5454[130] = (char *(*)()) F890_6900_5454_2;
	R5454[184] = (char *(*)()) F896_6953;
	R5454[185] = (char *(*)()) F898_6953_5454_2;
	R5454[186] = (char *(*)()) F896_6953;
	R5454[187] = (char *(*)()) F898_6953_5454_2;
	R5454[188] = (char *(*)()) F896_6953;
	R5454[189] = (char *(*)()) F949_7083;
	R5454[190] = (char *(*)()) F950_7083_5454_2;
	R5454[191] = (char *(*)()) F951_7083_5454_2;
	R5454[192] = (char *(*)()) F952_7083_5454_2;
	R5454[193] = (char *(*)()) F953_7083_5454_2;
	R5454[194] = (char *(*)()) F954_7083_5454_2;
	R5454[195] = (char *(*)()) F955_7083_5454_2;
	R5454[196] = (char *(*)()) F956_7083_5454_2;
	R5454[197] = (char *(*)()) F957_7083_5454_2;
	R5454[198] = (char *(*)()) F958_7083_5454_2;
	R5454[199] = (char *(*)()) F959_7083_5454_2;
	R5454[200] = (char *(*)()) F960_7083_5454_2;
	{long i; for (i = 201; i < 204; i++) R5454[i] = (char *(*)()) F949_7083;}
	R5454[204] = (char *(*)()) F951_7083_5454_2;
	R5454[205] = (char *(*)()) F949_7083;
	R5454[323] = (char *(*)()) F1081_8330_5454_2;
	R5454[327] = (char *(*)()) F1085_8495_5454_2;
	R5454[501] = (char *(*)()) F636_6151_5454_2;
	R5454[591] = (char *(*)()) F1351_13251_5454_2;
}
static EIF_BOOLEAN F760_6266_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F760_6266(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F761_6285_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F761_6285(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F636_6151_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F636_6151(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F880_6900_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F880_6900(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F881_6900_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F881_6900(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F882_6900_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F882_6900(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F883_6900_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F883_6900(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F884_6900_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F884_6900(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F885_6900_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F885_6900(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F886_6900_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F886_6900(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F887_6900_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F887_6900(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F888_6900_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F888_6900(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F889_6900_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F889_6900(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F890_6900_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F890_6900(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F898_6953_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F898_6953(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F950_7083_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F950_7083(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F951_7083_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F951_7083(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F952_7083_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F952_7083(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F953_7083_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F953_7083(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F954_7083_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F954_7083(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F955_7083_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F955_7083(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F956_7083_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F956_7083(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F957_7083_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F957_7083(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F958_7083_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F958_7083(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F959_7083_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F959_7083(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F960_7083_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F960_7083(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1081_8330_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1081_8330(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1085_8495_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1085_8495(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1351_13251_5454_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1351_13251(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R5455[592])();
void R5455_init () {
	{long i; for (i = 0; i < 2; i++) R5455[i] = (char *(*)()) F757_6237;}
	R5455[41] = (char *(*)()) F801_6319;
	{long i; for (i = 69; i < 71; i++) R5455[i] = (char *(*)()) F766_6292;}
	{long i; for (i = 92; i < 94; i++) R5455[i] = (char *(*)()) F762_6292;}
	R5455[94] = (char *(*)()) F763_6292;
	R5455[95] = (char *(*)()) F764_6292;
	R5455[96] = (char *(*)()) F767_6292;
	R5455[97] = (char *(*)()) F764_6292;
	R5455[98] = (char *(*)()) F770_6292;
	R5455[99] = (char *(*)()) F771_6292;
	{long i; for (i = 100; i < 102; i++) R5455[i] = (char *(*)()) F762_6292;}
	R5455[102] = (char *(*)()) F763_6292;
	R5455[103] = (char *(*)()) F764_6292;
	R5455[104] = (char *(*)()) F767_6292;
	R5455[105] = (char *(*)()) F770_6292;
	R5455[118] = (char *(*)()) F764_6292;
	R5455[119] = (char *(*)()) F762_6292;
	R5455[120] = (char *(*)()) F763_6292;
	R5455[121] = (char *(*)()) F764_6292;
	R5455[122] = (char *(*)()) F765_6292;
	R5455[123] = (char *(*)()) F766_6292;
	R5455[124] = (char *(*)()) F767_6292;
	R5455[125] = (char *(*)()) F768_6292;
	R5455[126] = (char *(*)()) F769_6292;
	R5455[127] = (char *(*)()) F770_6292;
	R5455[128] = (char *(*)()) F771_6292;
	R5455[129] = (char *(*)()) F772_6292;
	R5455[130] = (char *(*)()) F773_6292;
	R5455[184] = (char *(*)()) F762_6292;
	R5455[185] = (char *(*)()) F764_6292;
	R5455[186] = (char *(*)()) F762_6292;
	R5455[187] = (char *(*)()) F764_6292;
	{long i; for (i = 188; i < 190; i++) R5455[i] = (char *(*)()) F762_6292;}
	R5455[190] = (char *(*)()) F763_6292;
	R5455[191] = (char *(*)()) F764_6292;
	R5455[192] = (char *(*)()) F765_6292;
	R5455[193] = (char *(*)()) F766_6292;
	R5455[194] = (char *(*)()) F767_6292;
	R5455[195] = (char *(*)()) F768_6292;
	R5455[196] = (char *(*)()) F769_6292;
	R5455[197] = (char *(*)()) F770_6292;
	R5455[198] = (char *(*)()) F771_6292;
	R5455[199] = (char *(*)()) F772_6292;
	R5455[200] = (char *(*)()) F773_6292;
	{long i; for (i = 201; i < 204; i++) R5455[i] = (char *(*)()) F762_6292;}
	R5455[204] = (char *(*)()) F764_6292;
	R5455[205] = (char *(*)()) F762_6292;
	R5455[323] = (char *(*)()) F766_6292;
	R5455[327] = (char *(*)()) F768_6292;
	R5455[501] = (char *(*)()) F1261_10689;
	R5455[591] = (char *(*)()) F766_6292;
}

char *(*R5459[592])();
void R5459_init () {
	{long i; for (i = 0; i < 2; i++) R5459[i] = (char *(*)()) F610_6140;}
	R5459[41] = (char *(*)()) F608_6140;
	{long i; for (i = 69; i < 71; i++) R5459[i] = (char *(*)()) F612_6140;}
	{long i; for (i = 92; i < 94; i++) R5459[i] = (char *(*)()) F608_6140;}
	R5459[94] = (char *(*)()) F609_6140;
	R5459[95] = (char *(*)()) F610_6140;
	R5459[96] = (char *(*)()) F613_6140;
	R5459[97] = (char *(*)()) F610_6140;
	R5459[98] = (char *(*)()) F616_6140;
	R5459[99] = (char *(*)()) F617_6140;
	{long i; for (i = 100; i < 102; i++) R5459[i] = (char *(*)()) F608_6140;}
	R5459[102] = (char *(*)()) F609_6140;
	R5459[103] = (char *(*)()) F610_6140;
	R5459[104] = (char *(*)()) F613_6140;
	R5459[105] = (char *(*)()) F616_6140;
	R5459[118] = (char *(*)()) F610_6140;
	R5459[119] = (char *(*)()) F608_6140;
	R5459[120] = (char *(*)()) F609_6140;
	R5459[121] = (char *(*)()) F610_6140;
	R5459[122] = (char *(*)()) F611_6140;
	R5459[123] = (char *(*)()) F612_6140;
	R5459[124] = (char *(*)()) F613_6140;
	R5459[125] = (char *(*)()) F614_6140;
	R5459[126] = (char *(*)()) F615_6140;
	R5459[127] = (char *(*)()) F616_6140;
	R5459[128] = (char *(*)()) F617_6140;
	R5459[129] = (char *(*)()) F618_6140;
	R5459[130] = (char *(*)()) F619_6140;
	R5459[184] = (char *(*)()) F608_6140;
	R5459[185] = (char *(*)()) F610_6140;
	R5459[186] = (char *(*)()) F608_6140;
	R5459[187] = (char *(*)()) F610_6140;
	{long i; for (i = 188; i < 190; i++) R5459[i] = (char *(*)()) F608_6140;}
	R5459[190] = (char *(*)()) F609_6140;
	R5459[191] = (char *(*)()) F610_6140;
	R5459[192] = (char *(*)()) F611_6140;
	R5459[193] = (char *(*)()) F612_6140;
	R5459[194] = (char *(*)()) F613_6140;
	R5459[195] = (char *(*)()) F614_6140;
	R5459[196] = (char *(*)()) F615_6140;
	R5459[197] = (char *(*)()) F616_6140;
	R5459[198] = (char *(*)()) F617_6140;
	R5459[199] = (char *(*)()) F618_6140;
	R5459[200] = (char *(*)()) F619_6140;
	{long i; for (i = 201; i < 204; i++) R5459[i] = (char *(*)()) F608_6140;}
	R5459[204] = (char *(*)()) F610_6140;
	R5459[205] = (char *(*)()) F608_6140;
	R5459[323] = (char *(*)()) F612_6140;
	R5459[327] = (char *(*)()) F614_6140;
	R5459[501] = (char *(*)()) F612_6140;
	R5459[591] = (char *(*)()) F612_6140;
}

char *(*R5461[592])();
void R5461_init () {
	{long i; for (i = 0; i < 2; i++) R5461[i] = (char *(*)()) F759_6252;}
	R5461[41] = (char *(*)()) F801_6333;
	{long i; for (i = 69; i < 71; i++) R5461[i] = (char *(*)()) F636_6166;}
	R5461[92] = (char *(*)()) F852_6777;
	R5461[93] = (char *(*)()) F853_6777;
	R5461[94] = (char *(*)()) F854_6777;
	R5461[95] = (char *(*)()) F855_6777;
	R5461[96] = (char *(*)()) F856_6777;
	R5461[97] = (char *(*)()) F857_6777;
	R5461[98] = (char *(*)()) F858_6777;
	R5461[99] = (char *(*)()) F859_6777;
	{long i; for (i = 100; i < 102; i++) R5461[i] = (char *(*)()) F852_6777;}
	R5461[102] = (char *(*)()) F854_6777;
	R5461[103] = (char *(*)()) F855_6777;
	R5461[104] = (char *(*)()) F856_6777;
	R5461[105] = (char *(*)()) F858_6777;
	R5461[118] = (char *(*)()) F878_6879;
	R5461[119] = (char *(*)()) F879_6944;
	R5461[120] = (char *(*)()) F880_6944;
	R5461[121] = (char *(*)()) F881_6944;
	R5461[122] = (char *(*)()) F882_6944;
	R5461[123] = (char *(*)()) F883_6944;
	R5461[124] = (char *(*)()) F884_6944;
	R5461[125] = (char *(*)()) F885_6944;
	R5461[126] = (char *(*)()) F886_6944;
	R5461[127] = (char *(*)()) F887_6944;
	R5461[128] = (char *(*)()) F888_6944;
	R5461[129] = (char *(*)()) F889_6944;
	R5461[130] = (char *(*)()) F890_6944;
	R5461[184] = (char *(*)()) F632_6166;
	R5461[185] = (char *(*)()) F634_6166;
	R5461[186] = (char *(*)()) F946_7053;
	R5461[187] = (char *(*)()) F947_7053;
	{long i; for (i = 188; i < 190; i++) R5461[i] = (char *(*)()) F632_6166;}
	R5461[190] = (char *(*)()) F633_6166;
	R5461[191] = (char *(*)()) F634_6166;
	R5461[192] = (char *(*)()) F635_6166;
	R5461[193] = (char *(*)()) F636_6166;
	R5461[194] = (char *(*)()) F637_6166;
	R5461[195] = (char *(*)()) F638_6166;
	R5461[196] = (char *(*)()) F639_6166;
	R5461[197] = (char *(*)()) F640_6166;
	R5461[198] = (char *(*)()) F641_6166;
	R5461[199] = (char *(*)()) F642_6166;
	R5461[200] = (char *(*)()) F643_6166;
	{long i; for (i = 201; i < 203; i++) R5461[i] = (char *(*)()) F632_6166;}
	R5461[203] = (char *(*)()) F963_7154;
	R5461[204] = (char *(*)()) F964_7154;
	R5461[205] = (char *(*)()) F632_6166;
	R5461[323] = (char *(*)()) F1083_8451;
	R5461[327] = (char *(*)()) F1087_8619;
	R5461[501] = (char *(*)()) F636_6166;
	R5461[591] = (char *(*)()) F1083_8451;
}

char *(*R5463[502])();
void R5463_init () {
	{long i; for (i = 0; i < 2; i++) R5463[i] = (char *(*)()) F759_6241_5463_1;}
	{long i; for (i = 69; i < 71; i++) R5463[i] = (char *(*)()) F828_6367_5463_1;}
	R5463[184] = (char *(*)()) F944_7003;
	R5463[185] = (char *(*)()) F945_7003_5463_1;
	R5463[186] = (char *(*)()) F944_7003;
	R5463[187] = (char *(*)()) F945_7003_5463_1;
	R5463[188] = (char *(*)()) F944_7003;
	R5463[189] = (char *(*)()) F949_7076;
	R5463[190] = (char *(*)()) F950_7076_5463_1;
	R5463[191] = (char *(*)()) F951_7076_5463_1;
	R5463[192] = (char *(*)()) F952_7076_5463_1;
	R5463[193] = (char *(*)()) F953_7076_5463_1;
	R5463[194] = (char *(*)()) F954_7076_5463_1;
	R5463[195] = (char *(*)()) F955_7076_5463_1;
	R5463[196] = (char *(*)()) F956_7076_5463_1;
	R5463[197] = (char *(*)()) F957_7076_5463_1;
	R5463[198] = (char *(*)()) F958_7076_5463_1;
	R5463[199] = (char *(*)()) F959_7076_5463_1;
	R5463[200] = (char *(*)()) F960_7076_5463_1;
	{long i; for (i = 201; i < 204; i++) R5463[i] = (char *(*)()) F949_7076;}
	R5463[204] = (char *(*)()) F951_7076_5463_1;
	R5463[205] = (char *(*)()) F949_7076;
	R5463[501] = (char *(*)()) F828_6367_5463_1;
}
static EIF_REFERENCE F759_6241_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F759_6241(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F828_6367_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F828_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F945_7003_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F945_7003(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F950_7076_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F950_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_7076_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F951_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_7076_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F952_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7076_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F953_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7076_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F954_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7076_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F955_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7076_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F956_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1234, 0x00).id, 1234, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7076_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F957_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F958_7076_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F958_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7076_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F959_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7076_5463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F960_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5464[502])();
void R5464_init () {
	{long i; for (i = 0; i < 2; i++) R5464[i] = (char *(*)()) F634_6159;}
	{long i; for (i = 69; i < 71; i++) R5464[i] = (char *(*)()) F828_6388;}
	R5464[184] = (char *(*)()) F944_7014;
	R5464[185] = (char *(*)()) F945_7014;
	R5464[186] = (char *(*)()) F944_7014;
	R5464[187] = (char *(*)()) F945_7014;
	R5464[188] = (char *(*)()) F944_7014;
	R5464[189] = (char *(*)()) F896_6966;
	R5464[190] = (char *(*)()) F897_6966;
	R5464[191] = (char *(*)()) F898_6966;
	R5464[192] = (char *(*)()) F899_6966;
	R5464[193] = (char *(*)()) F900_6966;
	R5464[194] = (char *(*)()) F901_6966;
	R5464[195] = (char *(*)()) F902_6966;
	R5464[196] = (char *(*)()) F903_6966;
	R5464[197] = (char *(*)()) F904_6966;
	R5464[198] = (char *(*)()) F905_6966;
	R5464[199] = (char *(*)()) F906_6966;
	R5464[200] = (char *(*)()) F907_6966;
	{long i; for (i = 201; i < 204; i++) R5464[i] = (char *(*)()) F896_6966;}
	R5464[204] = (char *(*)()) F898_6966;
	R5464[205] = (char *(*)()) F896_6966;
	R5464[501] = (char *(*)()) F828_6388;
}

char *(*R5465[502])();
void R5465_init () {
	{long i; for (i = 0; i < 2; i++) R5465[i] = (char *(*)()) F759_6249;}
	{long i; for (i = 69; i < 71; i++) R5465[i] = (char *(*)()) F828_6443;}
	R5465[184] = (char *(*)()) F944_7020;
	R5465[185] = (char *(*)()) F945_7020;
	R5465[186] = (char *(*)()) F944_7020;
	R5465[187] = (char *(*)()) F945_7020;
	R5465[188] = (char *(*)()) F944_7020;
	R5465[189] = (char *(*)()) F949_7102;
	R5465[190] = (char *(*)()) F950_7102;
	R5465[191] = (char *(*)()) F951_7102;
	R5465[192] = (char *(*)()) F952_7102;
	R5465[193] = (char *(*)()) F953_7102;
	R5465[194] = (char *(*)()) F954_7102;
	R5465[195] = (char *(*)()) F955_7102;
	R5465[196] = (char *(*)()) F956_7102;
	R5465[197] = (char *(*)()) F957_7102;
	R5465[198] = (char *(*)()) F958_7102;
	R5465[199] = (char *(*)()) F959_7102;
	R5465[200] = (char *(*)()) F960_7102;
	{long i; for (i = 201; i < 204; i++) R5465[i] = (char *(*)()) F949_7102;}
	R5465[204] = (char *(*)()) F951_7102;
	R5465[205] = (char *(*)()) F949_7102;
	R5465[501] = (char *(*)()) F828_6443;
}

char *(*R5471[502])();
void R5471_init () {
	{long i; for (i = 0; i < 2; i++) R5471[i] = (char *(*)()) F634_6153_5471_4;}
	{long i; for (i = 69; i < 71; i++) R5471[i] = (char *(*)()) F648_6170_5471_4;}
	R5471[184] = (char *(*)()) F644_6170;
	R5471[185] = (char *(*)()) F646_6170_5471_4;
	R5471[186] = (char *(*)()) F644_6170;
	R5471[187] = (char *(*)()) F646_6170_5471_4;
	R5471[188] = (char *(*)()) F644_6170;
	R5471[189] = (char *(*)()) F949_7108;
	R5471[190] = (char *(*)()) F950_7108_5471_4;
	R5471[191] = (char *(*)()) F951_7108_5471_4;
	R5471[192] = (char *(*)()) F952_7108_5471_4;
	R5471[193] = (char *(*)()) F953_7108_5471_4;
	R5471[194] = (char *(*)()) F954_7108_5471_4;
	R5471[195] = (char *(*)()) F955_7108_5471_4;
	R5471[196] = (char *(*)()) F956_7108_5471_4;
	R5471[197] = (char *(*)()) F957_7108_5471_4;
	R5471[198] = (char *(*)()) F958_7108_5471_4;
	R5471[199] = (char *(*)()) F959_7108_5471_4;
	R5471[200] = (char *(*)()) F960_7108_5471_4;
	{long i; for (i = 201; i < 204; i++) R5471[i] = (char *(*)()) F949_7108;}
	R5471[204] = (char *(*)()) F951_7108_5471_4;
	R5471[205] = (char *(*)()) F949_7108;
	R5471[501] = (char *(*)()) F648_6170_5471_4;
}
static void F634_6153_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F634_6153(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F648_6170_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F648_6170(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F646_6170_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F646_6170(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F950_7108_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F950_7108(Current, *(EIF_BOOLEAN *)arg1);
}
static void F951_7108_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F951_7108(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F952_7108_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F952_7108(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F953_7108_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F953_7108(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F954_7108_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7108(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F955_7108_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F955_7108(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F956_7108_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F956_7108(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F957_7108_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F957_7108(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F958_7108_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F958_7108(Current, *(EIF_POINTER *)arg1);
}
static void F959_7108_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F959_7108(Current, *(EIF_REAL_32 *)arg1);
}
static void F960_7108_5471_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F960_7108(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R5472[502])();
void R5472_init () {
	{long i; for (i = 0; i < 2; i++) R5472[i] = (char *(*)()) F759_6240;}
	{long i; for (i = 69; i < 71; i++) R5472[i] = (char *(*)()) F828_6368;}
	R5472[184] = (char *(*)()) F944_7006;
	R5472[185] = (char *(*)()) F945_7006;
	R5472[186] = (char *(*)()) F944_7006;
	R5472[187] = (char *(*)()) F945_7006;
	R5472[188] = (char *(*)()) F944_7006;
	R5472[189] = (char *(*)()) F949_7081;
	R5472[190] = (char *(*)()) F950_7081;
	R5472[191] = (char *(*)()) F951_7081;
	R5472[192] = (char *(*)()) F952_7081;
	R5472[193] = (char *(*)()) F953_7081;
	R5472[194] = (char *(*)()) F954_7081;
	R5472[195] = (char *(*)()) F955_7081;
	R5472[196] = (char *(*)()) F956_7081;
	R5472[197] = (char *(*)()) F957_7081;
	R5472[198] = (char *(*)()) F958_7081;
	R5472[199] = (char *(*)()) F959_7081;
	R5472[200] = (char *(*)()) F960_7081;
	{long i; for (i = 201; i < 204; i++) R5472[i] = (char *(*)()) F949_7081;}
	R5472[204] = (char *(*)()) F951_7081;
	R5472[205] = (char *(*)()) F949_7081;
	R5472[501] = (char *(*)()) F828_6368;
}

char *(*R5475[502])();
void R5475_init () {
	{long i; for (i = 0; i < 2; i++) R5475[i] = (char *(*)()) F634_6157;}
	{long i; for (i = 69; i < 71; i++) R5475[i] = (char *(*)()) F636_6157;}
	R5475[184] = (char *(*)()) F632_6157;
	R5475[185] = (char *(*)()) F634_6157;
	R5475[186] = (char *(*)()) F632_6157;
	R5475[187] = (char *(*)()) F634_6157;
	{long i; for (i = 188; i < 190; i++) R5475[i] = (char *(*)()) F632_6157;}
	R5475[190] = (char *(*)()) F633_6157;
	R5475[191] = (char *(*)()) F634_6157;
	R5475[192] = (char *(*)()) F635_6157;
	R5475[193] = (char *(*)()) F636_6157;
	R5475[194] = (char *(*)()) F637_6157;
	R5475[195] = (char *(*)()) F638_6157;
	R5475[196] = (char *(*)()) F639_6157;
	R5475[197] = (char *(*)()) F640_6157;
	R5475[198] = (char *(*)()) F641_6157;
	R5475[199] = (char *(*)()) F642_6157;
	R5475[200] = (char *(*)()) F643_6157;
	{long i; for (i = 201; i < 204; i++) R5475[i] = (char *(*)()) F632_6157;}
	R5475[204] = (char *(*)()) F634_6157;
	R5475[205] = (char *(*)()) F632_6157;
	R5475[501] = (char *(*)()) F636_6157;
}

char *(*R5476[502])();
void R5476_init () {
	{long i; for (i = 0; i < 2; i++) R5476[i] = (char *(*)()) F759_6242;}
	{long i; for (i = 69; i < 71; i++) R5476[i] = (char *(*)()) F828_6386;}
	R5476[184] = (char *(*)()) F944_7012;
	R5476[185] = (char *(*)()) F945_7012;
	R5476[186] = (char *(*)()) F944_7012;
	R5476[187] = (char *(*)()) F945_7012;
	R5476[188] = (char *(*)()) F944_7012;
	R5476[189] = (char *(*)()) F920_6990;
	R5476[190] = (char *(*)()) F921_6990;
	R5476[191] = (char *(*)()) F922_6990;
	R5476[192] = (char *(*)()) F923_6990;
	R5476[193] = (char *(*)()) F924_6990;
	R5476[194] = (char *(*)()) F925_6990;
	R5476[195] = (char *(*)()) F926_6990;
	R5476[196] = (char *(*)()) F927_6990;
	R5476[197] = (char *(*)()) F928_6990;
	R5476[198] = (char *(*)()) F929_6990;
	R5476[199] = (char *(*)()) F930_6990;
	R5476[200] = (char *(*)()) F931_6990;
	{long i; for (i = 201; i < 204; i++) R5476[i] = (char *(*)()) F920_6990;}
	R5476[204] = (char *(*)()) F922_6990;
	R5476[205] = (char *(*)()) F920_6990;
	R5476[501] = (char *(*)()) F828_6386;
}

char *(*R5477[22])();
void R5477_init () {
	R5477[0] = (char *(*)()) F944_7021;
	R5477[1] = (char *(*)()) F945_7021;
	R5477[2] = (char *(*)()) F944_7021;
	R5477[3] = (char *(*)()) F945_7021;
	R5477[4] = (char *(*)()) F944_7021;
	R5477[5] = (char *(*)()) F949_7103;
	R5477[6] = (char *(*)()) F950_7103;
	R5477[7] = (char *(*)()) F951_7103;
	R5477[8] = (char *(*)()) F952_7103;
	R5477[9] = (char *(*)()) F953_7103;
	R5477[10] = (char *(*)()) F954_7103;
	R5477[11] = (char *(*)()) F955_7103;
	R5477[12] = (char *(*)()) F956_7103;
	R5477[13] = (char *(*)()) F957_7103;
	R5477[14] = (char *(*)()) F958_7103;
	R5477[15] = (char *(*)()) F959_7103;
	R5477[16] = (char *(*)()) F960_7103;
	{long i; for (i = 17; i < 20; i++) R5477[i] = (char *(*)()) F949_7103;}
	R5477[20] = (char *(*)()) F951_7103;
	R5477[21] = (char *(*)()) F949_7103;
}

char *(*R5478[502])();
void R5478_init () {
	{long i; for (i = 0; i < 2; i++) R5478[i] = (char *(*)()) F759_6248;}
	{long i; for (i = 69; i < 71; i++) R5478[i] = (char *(*)()) F828_6445;}
	R5478[184] = (char *(*)()) F944_7022;
	R5478[185] = (char *(*)()) F945_7022;
	R5478[186] = (char *(*)()) F944_7022;
	R5478[187] = (char *(*)()) F945_7022;
	R5478[188] = (char *(*)()) F944_7022;
	R5478[189] = (char *(*)()) F949_7104;
	R5478[190] = (char *(*)()) F950_7104;
	R5478[191] = (char *(*)()) F951_7104;
	R5478[192] = (char *(*)()) F952_7104;
	R5478[193] = (char *(*)()) F953_7104;
	R5478[194] = (char *(*)()) F954_7104;
	R5478[195] = (char *(*)()) F955_7104;
	R5478[196] = (char *(*)()) F956_7104;
	R5478[197] = (char *(*)()) F957_7104;
	R5478[198] = (char *(*)()) F958_7104;
	R5478[199] = (char *(*)()) F959_7104;
	R5478[200] = (char *(*)()) F960_7104;
	{long i; for (i = 201; i < 204; i++) R5478[i] = (char *(*)()) F949_7104;}
	R5478[204] = (char *(*)()) F951_7104;
	R5478[205] = (char *(*)()) F949_7104;
	R5478[501] = (char *(*)()) F828_6445;
}

char *(*R5479[433])();
void R5479_init () {
	{long i; for (i = 0; i < 2; i++) R5479[i] = (char *(*)()) F828_6387;}
	R5479[115] = (char *(*)()) F944_7013;
	R5479[116] = (char *(*)()) F945_7013;
	R5479[117] = (char *(*)()) F944_7013;
	R5479[118] = (char *(*)()) F945_7013;
	R5479[119] = (char *(*)()) F944_7013;
	R5479[120] = (char *(*)()) F920_6991;
	R5479[121] = (char *(*)()) F921_6991;
	R5479[122] = (char *(*)()) F922_6991;
	R5479[123] = (char *(*)()) F923_6991;
	R5479[124] = (char *(*)()) F924_6991;
	R5479[125] = (char *(*)()) F925_6991;
	R5479[126] = (char *(*)()) F926_6991;
	R5479[127] = (char *(*)()) F927_6991;
	R5479[128] = (char *(*)()) F928_6991;
	R5479[129] = (char *(*)()) F929_6991;
	R5479[130] = (char *(*)()) F930_6991;
	R5479[131] = (char *(*)()) F931_6991;
	{long i; for (i = 132; i < 135; i++) R5479[i] = (char *(*)()) F920_6991;}
	R5479[135] = (char *(*)()) F922_6991;
	R5479[136] = (char *(*)()) F920_6991;
	R5479[432] = (char *(*)()) F828_6387;
}

char *(*R5480[433])();
void R5480_init () {
	{long i; for (i = 0; i < 2; i++) R5480[i] = (char *(*)()) F828_6446;}
	R5480[115] = (char *(*)()) F944_7023;
	R5480[116] = (char *(*)()) F945_7023;
	R5480[117] = (char *(*)()) F944_7023;
	R5480[118] = (char *(*)()) F945_7023;
	R5480[119] = (char *(*)()) F944_7023;
	R5480[120] = (char *(*)()) F949_7105;
	R5480[121] = (char *(*)()) F950_7105;
	R5480[122] = (char *(*)()) F951_7105;
	R5480[123] = (char *(*)()) F952_7105;
	R5480[124] = (char *(*)()) F953_7105;
	R5480[125] = (char *(*)()) F954_7105;
	R5480[126] = (char *(*)()) F955_7105;
	R5480[127] = (char *(*)()) F956_7105;
	R5480[128] = (char *(*)()) F957_7105;
	R5480[129] = (char *(*)()) F958_7105;
	R5480[130] = (char *(*)()) F959_7105;
	R5480[131] = (char *(*)()) F960_7105;
	{long i; for (i = 132; i < 135; i++) R5480[i] = (char *(*)()) F949_7105;}
	R5480[135] = (char *(*)()) F951_7105;
	R5480[136] = (char *(*)()) F949_7105;
	R5480[432] = (char *(*)()) F1261_10659;
}

char *(*R5481[592])();
void R5481_init () {
	{long i; for (i = 0; i < 2; i++) R5481[i] = (char *(*)()) F759_6243;}
	R5481[41] = (char *(*)()) F801_6321;
	{long i; for (i = 69; i < 71; i++) R5481[i] = (char *(*)()) F828_6419;}
	R5481[92] = (char *(*)()) F852_6748;
	R5481[93] = (char *(*)()) F853_6748;
	R5481[94] = (char *(*)()) F854_6748;
	R5481[95] = (char *(*)()) F855_6748;
	R5481[96] = (char *(*)()) F856_6748;
	R5481[97] = (char *(*)()) F857_6748;
	R5481[98] = (char *(*)()) F858_6748;
	R5481[99] = (char *(*)()) F859_6748;
	{long i; for (i = 100; i < 102; i++) R5481[i] = (char *(*)()) F852_6748;}
	R5481[102] = (char *(*)()) F854_6748;
	R5481[103] = (char *(*)()) F855_6748;
	R5481[104] = (char *(*)()) F856_6748;
	R5481[105] = (char *(*)()) F858_6748;
	R5481[118] = (char *(*)()) F878_6868;
	R5481[119] = (char *(*)()) F879_6913;
	R5481[120] = (char *(*)()) F880_6913;
	R5481[121] = (char *(*)()) F881_6913;
	R5481[122] = (char *(*)()) F882_6913;
	R5481[123] = (char *(*)()) F883_6913;
	R5481[124] = (char *(*)()) F884_6913;
	R5481[125] = (char *(*)()) F885_6913;
	R5481[126] = (char *(*)()) F886_6913;
	R5481[127] = (char *(*)()) F887_6913;
	R5481[128] = (char *(*)()) F888_6913;
	R5481[129] = (char *(*)()) F889_6913;
	R5481[130] = (char *(*)()) F890_6913;
	R5481[184] = (char *(*)()) F908_6975;
	R5481[185] = (char *(*)()) F910_6975;
	R5481[186] = (char *(*)()) F908_6975;
	R5481[187] = (char *(*)()) F910_6975;
	{long i; for (i = 188; i < 190; i++) R5481[i] = (char *(*)()) F908_6975;}
	R5481[190] = (char *(*)()) F909_6975;
	R5481[191] = (char *(*)()) F910_6975;
	R5481[192] = (char *(*)()) F911_6975;
	R5481[193] = (char *(*)()) F912_6975;
	R5481[194] = (char *(*)()) F913_6975;
	R5481[195] = (char *(*)()) F914_6975;
	R5481[196] = (char *(*)()) F915_6975;
	R5481[197] = (char *(*)()) F916_6975;
	R5481[198] = (char *(*)()) F917_6975;
	R5481[199] = (char *(*)()) F918_6975;
	R5481[200] = (char *(*)()) F919_6975;
	{long i; for (i = 201; i < 204; i++) R5481[i] = (char *(*)()) F908_6975;}
	R5481[204] = (char *(*)()) F910_6975;
	R5481[205] = (char *(*)()) F908_6975;
	R5481[323] = (char *(*)()) F1083_8380;
	R5481[327] = (char *(*)()) F1087_8548;
	R5481[501] = (char *(*)()) F828_6419;
	R5481[591] = (char *(*)()) F1083_8380;
}

char *(*R5485[592])();
void R5485_init () {
	{long i; for (i = 0; i < 2; i++) R5485[i] = (char *(*)()) F759_6250_5485_4;}
	R5485[41] = (char *(*)()) F801_6323;
	{long i; for (i = 69; i < 71; i++) R5485[i] = (char *(*)()) F828_6452_5485_4;}
	R5485[92] = (char *(*)()) F852_6832;
	R5485[93] = (char *(*)()) F853_6832;
	R5485[94] = (char *(*)()) F854_6832_5485_4;
	R5485[95] = (char *(*)()) F855_6832_5485_4;
	R5485[96] = (char *(*)()) F856_6832_5485_4;
	R5485[97] = (char *(*)()) F857_6832_5485_4;
	R5485[98] = (char *(*)()) F858_6832_5485_4;
	R5485[99] = (char *(*)()) F859_6832_5485_4;
	{long i; for (i = 100; i < 102; i++) R5485[i] = (char *(*)()) F852_6832;}
	R5485[102] = (char *(*)()) F854_6832_5485_4;
	R5485[103] = (char *(*)()) F855_6832_5485_4;
	R5485[104] = (char *(*)()) F856_6832_5485_4;
	R5485[105] = (char *(*)()) F858_6832_5485_4;
	R5485[118] = (char *(*)()) F878_6870_5485_4;
	R5485[119] = (char *(*)()) F879_6948;
	R5485[120] = (char *(*)()) F880_6948_5485_4;
	R5485[121] = (char *(*)()) F881_6948_5485_4;
	R5485[122] = (char *(*)()) F882_6948_5485_4;
	R5485[123] = (char *(*)()) F883_6948_5485_4;
	R5485[124] = (char *(*)()) F884_6948_5485_4;
	R5485[125] = (char *(*)()) F885_6948_5485_4;
	R5485[126] = (char *(*)()) F886_6948_5485_4;
	R5485[127] = (char *(*)()) F887_6948_5485_4;
	R5485[128] = (char *(*)()) F888_6948_5485_4;
	R5485[129] = (char *(*)()) F889_6948_5485_4;
	R5485[130] = (char *(*)()) F890_6948_5485_4;
	R5485[184] = (char *(*)()) F944_7028;
	R5485[185] = (char *(*)()) F945_7028_5485_4;
	R5485[186] = (char *(*)()) F946_7050;
	R5485[187] = (char *(*)()) F947_7050_5485_4;
	R5485[188] = (char *(*)()) F948_7063;
	R5485[189] = (char *(*)()) F949_7112;
	R5485[190] = (char *(*)()) F950_7112_5485_4;
	R5485[191] = (char *(*)()) F951_7112_5485_4;
	R5485[192] = (char *(*)()) F952_7112_5485_4;
	R5485[193] = (char *(*)()) F953_7112_5485_4;
	R5485[194] = (char *(*)()) F954_7112_5485_4;
	R5485[195] = (char *(*)()) F955_7112_5485_4;
	R5485[196] = (char *(*)()) F956_7112_5485_4;
	R5485[197] = (char *(*)()) F957_7112_5485_4;
	R5485[198] = (char *(*)()) F958_7112_5485_4;
	R5485[199] = (char *(*)()) F959_7112_5485_4;
	R5485[200] = (char *(*)()) F960_7112_5485_4;
	R5485[201] = (char *(*)()) F961_7139;
	R5485[202] = (char *(*)()) F949_7112;
	R5485[203] = (char *(*)()) F963_7150;
	R5485[204] = (char *(*)()) F964_7150_5485_4;
	R5485[205] = (char *(*)()) F949_7112;
	R5485[323] = (char *(*)()) F1083_8422_5485_4;
	R5485[327] = (char *(*)()) F1087_8590_5485_4;
	R5485[501] = (char *(*)()) F828_6452_5485_4;
	R5485[591] = (char *(*)()) F1083_8422_5485_4;
}
static void F759_6250_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F759_6250(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F828_6452_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F828_6452(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F854_6832_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F854_6832(Current, *(EIF_BOOLEAN *)arg1);
}
static void F855_6832_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F855_6832(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F856_6832_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F856_6832(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F857_6832_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_6832(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F858_6832_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F858_6832(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F859_6832_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F859_6832(Current, *(EIF_POINTER *)arg1);
}
static void F878_6870_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F878_6870(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F880_6948_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F880_6948(Current, *(EIF_BOOLEAN *)arg1);
}
static void F881_6948_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F881_6948(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F882_6948_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F882_6948(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F883_6948_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F883_6948(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F884_6948_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F884_6948(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F885_6948_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F885_6948(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F886_6948_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F886_6948(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F887_6948_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F887_6948(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F888_6948_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F888_6948(Current, *(EIF_POINTER *)arg1);
}
static void F889_6948_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F889_6948(Current, *(EIF_REAL_32 *)arg1);
}
static void F890_6948_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F890_6948(Current, *(EIF_REAL_64 *)arg1);
}
static void F945_7028_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F945_7028(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F947_7050_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F947_7050(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F950_7112_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F950_7112(Current, *(EIF_BOOLEAN *)arg1);
}
static void F951_7112_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F951_7112(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F952_7112_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F952_7112(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F953_7112_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F953_7112(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F954_7112_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7112(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F955_7112_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F955_7112(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F956_7112_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F956_7112(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F957_7112_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F957_7112(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F958_7112_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F958_7112(Current, *(EIF_POINTER *)arg1);
}
static void F959_7112_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F959_7112(Current, *(EIF_REAL_32 *)arg1);
}
static void F960_7112_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F960_7112(Current, *(EIF_REAL_64 *)arg1);
}
static void F964_7150_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F964_7150(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1083_8422_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1083_8422(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1087_8590_5485_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1087_8590(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R5486[592])();
void R5486_init () {
	{long i; for (i = 0; i < 2; i++) R5486[i] = (char *(*)()) F658_6176;}
	R5486[41] = (char *(*)()) F656_6176;
	{long i; for (i = 69; i < 71; i++) R5486[i] = (char *(*)()) F660_6176;}
	{long i; for (i = 92; i < 94; i++) R5486[i] = (char *(*)()) F656_6176;}
	R5486[94] = (char *(*)()) F657_6176;
	R5486[95] = (char *(*)()) F658_6176;
	R5486[96] = (char *(*)()) F661_6176;
	R5486[97] = (char *(*)()) F658_6176;
	R5486[98] = (char *(*)()) F664_6176;
	R5486[99] = (char *(*)()) F665_6176;
	{long i; for (i = 100; i < 102; i++) R5486[i] = (char *(*)()) F656_6176;}
	R5486[102] = (char *(*)()) F657_6176;
	R5486[103] = (char *(*)()) F658_6176;
	R5486[104] = (char *(*)()) F661_6176;
	R5486[105] = (char *(*)()) F664_6176;
	R5486[118] = (char *(*)()) F658_6176;
	R5486[119] = (char *(*)()) F656_6176;
	R5486[120] = (char *(*)()) F657_6176;
	R5486[121] = (char *(*)()) F658_6176;
	R5486[122] = (char *(*)()) F659_6176;
	R5486[123] = (char *(*)()) F660_6176;
	R5486[124] = (char *(*)()) F661_6176;
	R5486[125] = (char *(*)()) F662_6176;
	R5486[126] = (char *(*)()) F663_6176;
	R5486[127] = (char *(*)()) F664_6176;
	R5486[128] = (char *(*)()) F665_6176;
	R5486[129] = (char *(*)()) F666_6176;
	R5486[130] = (char *(*)()) F667_6176;
	R5486[186] = (char *(*)()) F802_6346;
	R5486[187] = (char *(*)()) F803_6346;
	R5486[203] = (char *(*)()) F802_6346;
	R5486[204] = (char *(*)()) F803_6346;
	R5486[323] = (char *(*)()) F660_6176;
	R5486[327] = (char *(*)()) F662_6176;
	R5486[501] = (char *(*)()) F660_6176;
	R5486[591] = (char *(*)()) F660_6176;
}

char *(*R5491[474])();
void R5491_init () {
	R5491[0] = (char *(*)()) F878_6858_5491_5;
	R5491[1] = (char *(*)()) F879_6897_5491_5;
	R5491[2] = (char *(*)()) F880_6897_5491_5;
	R5491[3] = (char *(*)()) F881_6897_5491_5;
	R5491[4] = (char *(*)()) F882_6897_5491_5;
	R5491[5] = (char *(*)()) F883_6897_5491_5;
	R5491[6] = (char *(*)()) F884_6897_5491_5;
	R5491[7] = (char *(*)()) F885_6897_5491_5;
	R5491[8] = (char *(*)()) F886_6897_5491_5;
	R5491[9] = (char *(*)()) F887_6897_5491_5;
	R5491[10] = (char *(*)()) F888_6897_5491_5;
	R5491[11] = (char *(*)()) F889_6897_5491_5;
	R5491[12] = (char *(*)()) F890_6897_5491_5;
	R5491[66] = (char *(*)()) F896_6955_5491_5;
	R5491[67] = (char *(*)()) F898_6955_5491_5;
	R5491[68] = (char *(*)()) F896_6955_5491_5;
	R5491[69] = (char *(*)()) F898_6955_5491_5;
	R5491[70] = (char *(*)()) F896_6955_5491_5;
	R5491[71] = (char *(*)()) F949_7077_5491_5;
	R5491[72] = (char *(*)()) F950_7077_5491_5;
	R5491[73] = (char *(*)()) F951_7077_5491_5;
	R5491[74] = (char *(*)()) F952_7077_5491_5;
	R5491[75] = (char *(*)()) F953_7077_5491_5;
	R5491[76] = (char *(*)()) F954_7077_5491_5;
	R5491[77] = (char *(*)()) F955_7077_5491_5;
	R5491[78] = (char *(*)()) F956_7077_5491_5;
	R5491[79] = (char *(*)()) F957_7077_5491_5;
	R5491[80] = (char *(*)()) F958_7077_5491_5;
	R5491[81] = (char *(*)()) F959_7077_5491_5;
	R5491[82] = (char *(*)()) F960_7077_5491_5;
	{long i; for (i = 83; i < 86; i++) R5491[i] = (char *(*)()) F949_7077_5491_5;}
	R5491[86] = (char *(*)()) F951_7077_5491_5;
	R5491[87] = (char *(*)()) F949_7077_5491_5;
	R5491[205] = (char *(*)()) F1083_8374_5491_5;
	R5491[209] = (char *(*)()) F1087_8543_5491_5;
	R5491[473] = (char *(*)()) F1351_13230_5491_5;
}
static EIF_REFERENCE F878_6858_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F878_6858(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F879_6897_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F879_6897(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F880_6897_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F880_6897(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F881_6897_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F881_6897(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F882_6897_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F882_6897(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F883_6897_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F883_6897(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F884_6897_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F884_6897(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F885_6897_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F885_6897(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F886_6897_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F886_6897(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1234, 0x00).id, 1234, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F887_6897_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F887_6897(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F888_6897_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F888_6897(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F889_6897_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F889_6897(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F890_6897_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F890_6897(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_6955_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F896_6955(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F898_6955_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F898_6955(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F949_7077_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F949_7077(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F950_7077_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F950_7077(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_7077_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F951_7077(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_7077_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F952_7077(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7077_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F953_7077(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7077_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F954_7077(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7077_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F955_7077(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7077_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F956_7077(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1234, 0x00).id, 1234, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7077_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F957_7077(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F958_7077_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F958_7077(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7077_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F959_7077(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7077_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F960_7077(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1083_8374_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1083_8374(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1087_8543_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1087_8543(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1351_13230_5491_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1351_13230(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R5494[500])();
void R5494_init () {
	R5494[0] = (char *(*)()) F852_6767;
	R5494[1] = (char *(*)()) F853_6767_5494_9;
	R5494[2] = (char *(*)()) F854_6767_5494_9;
	R5494[3] = (char *(*)()) F855_6767_5494_9;
	R5494[4] = (char *(*)()) F856_6767_5494_9;
	R5494[5] = (char *(*)()) F857_6767_5494_9;
	R5494[6] = (char *(*)()) F858_6767_5494_9;
	R5494[7] = (char *(*)()) F859_6767_5494_9;
	{long i; for (i = 8; i < 10; i++) R5494[i] = (char *(*)()) F852_6767;}
	R5494[10] = (char *(*)()) F854_6767_5494_9;
	R5494[11] = (char *(*)()) F855_6767_5494_9;
	R5494[12] = (char *(*)()) F856_6767_5494_9;
	R5494[13] = (char *(*)()) F858_6767_5494_9;
	R5494[26] = (char *(*)()) F878_6888_5494_9;
	R5494[27] = (char *(*)()) F879_6916_5494_9;
	R5494[28] = (char *(*)()) F880_6916_5494_9;
	R5494[29] = (char *(*)()) F881_6916_5494_9;
	R5494[30] = (char *(*)()) F882_6916_5494_9;
	R5494[31] = (char *(*)()) F883_6916_5494_9;
	R5494[32] = (char *(*)()) F884_6916_5494_9;
	R5494[33] = (char *(*)()) F885_6916_5494_9;
	R5494[34] = (char *(*)()) F886_6916_5494_9;
	R5494[35] = (char *(*)()) F887_6916_5494_9;
	R5494[36] = (char *(*)()) F888_6916_5494_9;
	R5494[37] = (char *(*)()) F889_6916_5494_9;
	R5494[38] = (char *(*)()) F890_6916_5494_9;
	R5494[92] = (char *(*)()) F896_6969_5494_9;
	R5494[93] = (char *(*)()) F898_6969_5494_9;
	R5494[94] = (char *(*)()) F896_6969_5494_9;
	R5494[95] = (char *(*)()) F898_6969_5494_9;
	R5494[96] = (char *(*)()) F896_6969_5494_9;
	R5494[97] = (char *(*)()) F949_7110_5494_9;
	R5494[98] = (char *(*)()) F950_7110_5494_9;
	R5494[99] = (char *(*)()) F951_7110_5494_9;
	R5494[100] = (char *(*)()) F952_7110_5494_9;
	R5494[101] = (char *(*)()) F953_7110_5494_9;
	R5494[102] = (char *(*)()) F954_7110_5494_9;
	R5494[103] = (char *(*)()) F955_7110_5494_9;
	R5494[104] = (char *(*)()) F956_7110_5494_9;
	R5494[105] = (char *(*)()) F957_7110_5494_9;
	R5494[106] = (char *(*)()) F958_7110_5494_9;
	R5494[107] = (char *(*)()) F959_7110_5494_9;
	R5494[108] = (char *(*)()) F960_7110_5494_9;
	{long i; for (i = 109; i < 112; i++) R5494[i] = (char *(*)()) F949_7110_5494_9;}
	R5494[112] = (char *(*)()) F951_7110_5494_9;
	R5494[113] = (char *(*)()) F949_7110_5494_9;
	R5494[231] = (char *(*)()) F1083_8395_5494_9;
	R5494[235] = (char *(*)()) F1087_8563_5494_9;
	R5494[499] = (char *(*)()) F1351_13265_5494_9;
}
static void F853_6767_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F853_6767(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F854_6767_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F854_6767(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F855_6767_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F855_6767(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F856_6767_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F856_6767(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F857_6767_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F857_6767(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F858_6767_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F858_6767(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F859_6767_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F859_6767(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F878_6888_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F878_6888(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F879_6916_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F879_6916(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F880_6916_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F880_6916(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F881_6916_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F881_6916(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F882_6916_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F882_6916(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F883_6916_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F883_6916(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F884_6916_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F884_6916(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F885_6916_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F885_6916(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F886_6916_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F886_6916(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F887_6916_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F887_6916(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F888_6916_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F888_6916(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F889_6916_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F889_6916(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F890_6916_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F890_6916(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F896_6969_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F896_6969(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F898_6969_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F898_6969(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F949_7110_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F949_7110(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F950_7110_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F950_7110(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F951_7110_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F951_7110(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F952_7110_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F952_7110(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F953_7110_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F953_7110(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F954_7110_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F954_7110(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F955_7110_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F955_7110(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F956_7110_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F956_7110(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F957_7110_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F957_7110(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F958_7110_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F958_7110(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F959_7110_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F959_7110(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F960_7110_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F960_7110(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1083_8395_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1083_8395(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1087_8563_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1087_8563(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1351_13265_5494_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1351_13265(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}


#ifdef __cplusplus
}
#endif
