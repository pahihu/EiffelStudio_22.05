#include "epoly9.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R7042[270])();
void R7042_init () {
	{long i; for (i = 0; i < 2; i++) R7042[i] = (char *(*)()) F1081_8308;}
	R7042[269] = (char *(*)()) F1351_13240;
}

char *(*R7049[270])();
void R7049_init () {
	{long i; for (i = 0; i < 2; i++) R7049[i] = (char *(*)()) F1081_8323;}
	R7049[269] = (char *(*)()) F1351_13258;
}

char *(*R7054[270])();
void R7054_init () {
	R7054[0] = (char *(*)()) F1082_8357;
	R7054[1] = (char *(*)()) F1083_8427;
	R7054[269] = (char *(*)()) F1351_13236;
}

char *(*R7062[270])();
void R7062_init () {
	R7062[0] = (char *(*)()) F1082_8368;
	R7062[1] = (char *(*)()) F1081_8347;
	R7062[269] = (char *(*)()) F1081_8347;
}

char *(*R7077[269])();
void R7077_init () {
	R7077[0] = (char *(*)()) F1083_8385;
	R7077[268] = (char *(*)()) F1351_13291;
}

char *(*R7085[269])();
void R7085_init () {
	R7085[0] = (char *(*)()) F1083_8400;
	R7085[268] = (char *(*)()) F1351_13266;
}

char *(*R7088[269])();
void R7088_init () {
	R7088[0] = (char *(*)()) F1083_8408;
	R7088[268] = (char *(*)()) F1351_13274;
}

char *(*R7090[269])();
void R7090_init () {
	R7090[0] = (char *(*)()) F1083_8410;
	R7090[268] = (char *(*)()) F1351_13272;
}

char *(*R7092[269])();
void R7092_init () {
	R7092[0] = (char *(*)()) F1083_8421;
	R7092[268] = (char *(*)()) F1351_13271;
}

char *(*R7094[269])();
void R7094_init () {
	R7094[0] = (char *(*)()) F1083_8425;
	R7094[268] = (char *(*)()) F1351_13288;
}

char *(*R7104[269])();
void R7104_init () {
	R7104[0] = (char *(*)()) F1083_8449;
	R7104[268] = (char *(*)()) F1351_13305;
}

char *(*R7105[269])();
void R7105_init () {
	R7105[0] = (char *(*)()) F1083_8450;
	R7105[268] = (char *(*)()) F1351_13306;
}

char *(*R7129[2])();
void R7129_init () {
	R7129[0] = (char *(*)()) F1086_8524;
	R7129[1] = (char *(*)()) F1087_8595;
}

char *(*R7137[2])();
void R7137_init () {
	R7137[0] = (char *(*)()) F1086_8535;
	R7137[1] = (char *(*)()) F1085_8512;
}

char *(*R7675[36])();
void R7675_init () {
	R7675[0] = (char *(*)()) F1104_9171;
	R7675[1] = (char *(*)()) F1105_9171;
	R7675[2] = (char *(*)()) F1106_9171;
	R7675[3] = (char *(*)()) F1107_9171;
	R7675[4] = (char *(*)()) F1108_9171;
	R7675[5] = (char *(*)()) F1109_9171;
	R7675[6] = (char *(*)()) F1110_9171;
	R7675[7] = (char *(*)()) F1111_9171;
	R7675[8] = (char *(*)()) F1112_9171;
	R7675[9] = (char *(*)()) F1113_9171;
	R7675[10] = (char *(*)()) F1114_9171;
	R7675[11] = (char *(*)()) F1115_9171;
	R7675[12] = (char *(*)()) F1116_9171;
	R7675[13] = (char *(*)()) F1117_9171;
	R7675[14] = (char *(*)()) F1118_9171;
	R7675[15] = (char *(*)()) F1119_9171;
	R7675[16] = (char *(*)()) F1120_9171;
	R7675[17] = (char *(*)()) F1121_9171;
	R7675[18] = (char *(*)()) F1122_9171;
	R7675[19] = (char *(*)()) F1123_9171;
	R7675[20] = (char *(*)()) F1124_9171;
	R7675[21] = (char *(*)()) F1125_9171;
	R7675[22] = (char *(*)()) F1126_9171;
	R7675[23] = (char *(*)()) F1127_9171;
	R7675[24] = (char *(*)()) F1128_9171;
	R7675[25] = (char *(*)()) F1129_9171;
	R7675[26] = (char *(*)()) F1130_9171;
	R7675[27] = (char *(*)()) F1131_9171;
	R7675[28] = (char *(*)()) F1132_9171;
	R7675[29] = (char *(*)()) F1133_9171;
	R7675[30] = (char *(*)()) F1134_9171;
	R7675[31] = (char *(*)()) F1135_9171;
	R7675[32] = (char *(*)()) F1136_9171;
	R7675[33] = (char *(*)()) F1137_9171;
	R7675[34] = (char *(*)()) F1138_9171;
	R7675[35] = (char *(*)()) F1139_9171;
}

char *(*R7676[36])();
void R7676_init () {
	R7676[0] = (char *(*)()) F1104_9172;
	R7676[1] = (char *(*)()) F1105_9172;
	R7676[2] = (char *(*)()) F1106_9172;
	R7676[3] = (char *(*)()) F1107_9172;
	R7676[4] = (char *(*)()) F1108_9172;
	R7676[5] = (char *(*)()) F1109_9172;
	R7676[6] = (char *(*)()) F1110_9172;
	R7676[7] = (char *(*)()) F1111_9172;
	R7676[8] = (char *(*)()) F1112_9172;
	R7676[9] = (char *(*)()) F1113_9172;
	R7676[10] = (char *(*)()) F1114_9172;
	R7676[11] = (char *(*)()) F1115_9172;
	R7676[12] = (char *(*)()) F1116_9172;
	R7676[13] = (char *(*)()) F1117_9172;
	R7676[14] = (char *(*)()) F1118_9172;
	R7676[15] = (char *(*)()) F1119_9172;
	R7676[16] = (char *(*)()) F1120_9172;
	R7676[17] = (char *(*)()) F1121_9172;
	R7676[18] = (char *(*)()) F1122_9172;
	R7676[19] = (char *(*)()) F1123_9172;
	R7676[20] = (char *(*)()) F1124_9172;
	R7676[21] = (char *(*)()) F1125_9172;
	R7676[22] = (char *(*)()) F1126_9172;
	R7676[23] = (char *(*)()) F1127_9172;
	R7676[24] = (char *(*)()) F1128_9172;
	R7676[25] = (char *(*)()) F1129_9172;
	R7676[26] = (char *(*)()) F1130_9172;
	R7676[27] = (char *(*)()) F1131_9172;
	R7676[28] = (char *(*)()) F1132_9172;
	R7676[29] = (char *(*)()) F1133_9172;
	R7676[30] = (char *(*)()) F1134_9172;
	R7676[31] = (char *(*)()) F1135_9172;
	R7676[32] = (char *(*)()) F1136_9172;
	R7676[33] = (char *(*)()) F1137_9172;
	R7676[34] = (char *(*)()) F1138_9172;
	R7676[35] = (char *(*)()) F1139_9172;
}

char *(*R7678[36])();
void R7678_init () {
	R7678[0] = (char *(*)()) F1104_9174;
	R7678[1] = (char *(*)()) F1105_9174;
	R7678[2] = (char *(*)()) F1106_9174;
	R7678[3] = (char *(*)()) F1107_9174;
	R7678[4] = (char *(*)()) F1108_9174;
	R7678[5] = (char *(*)()) F1109_9174;
	R7678[6] = (char *(*)()) F1110_9174;
	R7678[7] = (char *(*)()) F1111_9174;
	R7678[8] = (char *(*)()) F1112_9174;
	R7678[9] = (char *(*)()) F1113_9174;
	R7678[10] = (char *(*)()) F1114_9174;
	R7678[11] = (char *(*)()) F1115_9174;
	R7678[12] = (char *(*)()) F1116_9174;
	R7678[13] = (char *(*)()) F1117_9174;
	R7678[14] = (char *(*)()) F1118_9174;
	R7678[15] = (char *(*)()) F1119_9174;
	R7678[16] = (char *(*)()) F1120_9174;
	R7678[17] = (char *(*)()) F1121_9174;
	R7678[18] = (char *(*)()) F1122_9174;
	R7678[19] = (char *(*)()) F1123_9174;
	R7678[20] = (char *(*)()) F1124_9174;
	R7678[21] = (char *(*)()) F1125_9174;
	R7678[22] = (char *(*)()) F1126_9174;
	R7678[23] = (char *(*)()) F1127_9174;
	R7678[24] = (char *(*)()) F1128_9174;
	R7678[25] = (char *(*)()) F1129_9174;
	R7678[26] = (char *(*)()) F1130_9174;
	R7678[27] = (char *(*)()) F1131_9174;
	R7678[28] = (char *(*)()) F1132_9174;
	R7678[29] = (char *(*)()) F1133_9174;
	R7678[30] = (char *(*)()) F1134_9174;
	R7678[31] = (char *(*)()) F1135_9174;
	R7678[32] = (char *(*)()) F1136_9174;
	R7678[33] = (char *(*)()) F1137_9174;
	R7678[34] = (char *(*)()) F1138_9174;
	R7678[35] = (char *(*)()) F1139_9174;
}

char *(*R7683[36])();
void R7683_init () {
	R7683[0] = (char *(*)()) F1104_9180;
	R7683[1] = (char *(*)()) F1105_9180;
	R7683[2] = (char *(*)()) F1106_9180;
	R7683[3] = (char *(*)()) F1107_9180;
	R7683[4] = (char *(*)()) F1108_9180;
	R7683[5] = (char *(*)()) F1109_9180;
	R7683[6] = (char *(*)()) F1110_9180;
	R7683[7] = (char *(*)()) F1111_9180;
	R7683[8] = (char *(*)()) F1112_9180;
	R7683[9] = (char *(*)()) F1113_9180;
	R7683[10] = (char *(*)()) F1114_9180;
	R7683[11] = (char *(*)()) F1115_9180;
	R7683[12] = (char *(*)()) F1116_9180;
	R7683[13] = (char *(*)()) F1117_9180;
	R7683[14] = (char *(*)()) F1118_9180;
	R7683[15] = (char *(*)()) F1119_9180;
	R7683[16] = (char *(*)()) F1120_9180;
	R7683[17] = (char *(*)()) F1121_9180;
	R7683[18] = (char *(*)()) F1122_9180;
	R7683[19] = (char *(*)()) F1123_9180;
	R7683[20] = (char *(*)()) F1124_9180;
	R7683[21] = (char *(*)()) F1125_9180;
	R7683[22] = (char *(*)()) F1126_9180;
	R7683[23] = (char *(*)()) F1127_9180;
	R7683[24] = (char *(*)()) F1128_9180;
	R7683[25] = (char *(*)()) F1129_9180;
	R7683[26] = (char *(*)()) F1130_9180;
	R7683[27] = (char *(*)()) F1131_9180;
	R7683[28] = (char *(*)()) F1132_9180;
	R7683[29] = (char *(*)()) F1133_9180;
	R7683[30] = (char *(*)()) F1134_9180;
	R7683[31] = (char *(*)()) F1135_9180;
	R7683[32] = (char *(*)()) F1136_9180;
	R7683[33] = (char *(*)()) F1137_9180;
	R7683[34] = (char *(*)()) F1138_9180;
	R7683[35] = (char *(*)()) F1139_9180;
}

char *(*R7688[36])();
void R7688_init () {
	R7688[0] = (char *(*)()) F1104_9188;
	R7688[1] = (char *(*)()) F1105_9188_7688_1;
	R7688[2] = (char *(*)()) F1106_9188_7688_1;
	R7688[3] = (char *(*)()) F1107_9188_7688_1;
	R7688[4] = (char *(*)()) F1108_9188_7688_1;
	R7688[5] = (char *(*)()) F1109_9188_7688_1;
	R7688[6] = (char *(*)()) F1110_9188_7688_1;
	R7688[7] = (char *(*)()) F1111_9188_7688_1;
	R7688[8] = (char *(*)()) F1112_9188_7688_1;
	R7688[9] = (char *(*)()) F1113_9188_7688_1;
	R7688[10] = (char *(*)()) F1114_9188_7688_1;
	R7688[11] = (char *(*)()) F1115_9188_7688_1;
	R7688[12] = (char *(*)()) F1116_9188_7688_1;
	R7688[13] = (char *(*)()) F1117_9188_7688_1;
	R7688[14] = (char *(*)()) F1118_9188_7688_1;
	R7688[15] = (char *(*)()) F1119_9188_7688_1;
	R7688[16] = (char *(*)()) F1120_9188_7688_1;
	R7688[17] = (char *(*)()) F1121_9188;
	R7688[18] = (char *(*)()) F1122_9188;
	R7688[19] = (char *(*)()) F1123_9188;
	R7688[20] = (char *(*)()) F1124_9188;
	R7688[21] = (char *(*)()) F1125_9188;
	R7688[22] = (char *(*)()) F1126_9188;
	R7688[23] = (char *(*)()) F1127_9188_7688_1;
	R7688[24] = (char *(*)()) F1128_9188_7688_1;
	R7688[25] = (char *(*)()) F1129_9188_7688_1;
	R7688[26] = (char *(*)()) F1130_9188_7688_1;
	R7688[27] = (char *(*)()) F1131_9188_7688_1;
	R7688[28] = (char *(*)()) F1132_9188_7688_1;
	R7688[29] = (char *(*)()) F1133_9188_7688_1;
	R7688[30] = (char *(*)()) F1134_9188_7688_1;
	R7688[31] = (char *(*)()) F1135_9188_7688_1;
	R7688[32] = (char *(*)()) F1136_9188_7688_1;
	R7688[33] = (char *(*)()) F1137_9188_7688_1;
	R7688[34] = (char *(*)()) F1138_9188_7688_1;
	R7688[35] = (char *(*)()) F1139_9188_7688_1;
}
static EIF_REFERENCE F1105_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F1105_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1041,1070,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1106_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1106_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1107_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F1107_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1042,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1042, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1108_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1108_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1109_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1109_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1110_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1110_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1111_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1111_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1234, 0x00).id, 1234, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1112_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1112_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1113_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1113_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1114_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1114_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1225, 0x00).id, 1225, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1115_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1115_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1222, 0x00).id, 1222, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1116_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1116_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1117_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1117_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1118_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1118_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1119_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1119_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1120_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1120_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1127_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F1127_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1044,1237,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1044, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1128_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F1128_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1046,1240,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1046, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1129_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F1129_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1048,1243,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1048, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1130_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F1130_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1050,1037,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1050, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1131_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F1131_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1052,1228,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1052, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1132_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F1132_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1054,1031,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1054, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1133_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F1133_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1056,1219,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1056, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1134_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F1134_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1058,1216,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1058, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1135_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F1135_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1060,1222,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1060, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1136_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F1136_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1062,1231,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1062, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1137_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F1137_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1064,1234,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1064, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1138_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F1138_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1066,1225,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1066, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1139_9188_7688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F1139_9188(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1068,1034,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1068, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}

char *(*R7698[36])();
void R7698_init () {
	R7698[0] = (char *(*)()) F1104_9200;
	R7698[1] = (char *(*)()) F1105_9200;
	R7698[2] = (char *(*)()) F1106_9200;
	R7698[3] = (char *(*)()) F1107_9200;
	R7698[4] = (char *(*)()) F1108_9200;
	R7698[5] = (char *(*)()) F1109_9200;
	R7698[6] = (char *(*)()) F1110_9200;
	R7698[7] = (char *(*)()) F1111_9200;
	R7698[8] = (char *(*)()) F1112_9200;
	R7698[9] = (char *(*)()) F1113_9200;
	R7698[10] = (char *(*)()) F1114_9200;
	R7698[11] = (char *(*)()) F1115_9200;
	R7698[12] = (char *(*)()) F1116_9200;
	R7698[13] = (char *(*)()) F1117_9200;
	R7698[14] = (char *(*)()) F1118_9200;
	R7698[15] = (char *(*)()) F1119_9200;
	R7698[16] = (char *(*)()) F1120_9200;
	R7698[17] = (char *(*)()) F1121_9200;
	R7698[18] = (char *(*)()) F1122_9200;
	R7698[19] = (char *(*)()) F1123_9200;
	R7698[20] = (char *(*)()) F1124_9200;
	R7698[21] = (char *(*)()) F1125_9200;
	R7698[22] = (char *(*)()) F1126_9200;
	R7698[23] = (char *(*)()) F1127_9200;
	R7698[24] = (char *(*)()) F1128_9200;
	R7698[25] = (char *(*)()) F1129_9200;
	R7698[26] = (char *(*)()) F1130_9200;
	R7698[27] = (char *(*)()) F1131_9200;
	R7698[28] = (char *(*)()) F1132_9200;
	R7698[29] = (char *(*)()) F1133_9200;
	R7698[30] = (char *(*)()) F1134_9200;
	R7698[31] = (char *(*)()) F1135_9200;
	R7698[32] = (char *(*)()) F1136_9200;
	R7698[33] = (char *(*)()) F1137_9200;
	R7698[34] = (char *(*)()) F1138_9200;
	R7698[35] = (char *(*)()) F1139_9200;
}

char *(*R7700[12])();
void R7700_init () {
	R7700[0] = (char *(*)()) F1141_9218;
	R7700[1] = (char *(*)()) F1142_9218;
	R7700[2] = (char *(*)()) F1143_9218;
	R7700[3] = (char *(*)()) F1144_9218;
	R7700[4] = (char *(*)()) F1145_9218;
	R7700[5] = (char *(*)()) F1146_9218;
	R7700[6] = (char *(*)()) F1147_9218;
	R7700[7] = (char *(*)()) F1148_9218;
	R7700[8] = (char *(*)()) F1149_9218;
	R7700[9] = (char *(*)()) F1150_9218;
	R7700[10] = (char *(*)()) F1151_9218;
	R7700[11] = (char *(*)()) F1152_9218;
}

char *(*R7701[12])();
void R7701_init () {
	R7701[0] = (char *(*)()) F1141_9219;
	R7701[1] = (char *(*)()) F1142_9219;
	R7701[2] = (char *(*)()) F1143_9219;
	R7701[3] = (char *(*)()) F1144_9219;
	R7701[4] = (char *(*)()) F1145_9219;
	R7701[5] = (char *(*)()) F1146_9219;
	R7701[6] = (char *(*)()) F1147_9219;
	R7701[7] = (char *(*)()) F1148_9219;
	R7701[8] = (char *(*)()) F1149_9219;
	R7701[9] = (char *(*)()) F1150_9219;
	R7701[10] = (char *(*)()) F1151_9219;
	R7701[11] = (char *(*)()) F1152_9219;
}

char *(*R7703[12])();
void R7703_init () {
	R7703[0] = (char *(*)()) F1141_9205;
	R7703[1] = (char *(*)()) F1142_9205;
	R7703[2] = (char *(*)()) F1143_9205;
	R7703[3] = (char *(*)()) F1144_9205;
	R7703[4] = (char *(*)()) F1145_9205;
	R7703[5] = (char *(*)()) F1146_9205;
	R7703[6] = (char *(*)()) F1147_9205;
	R7703[7] = (char *(*)()) F1148_9205;
	R7703[8] = (char *(*)()) F1149_9205;
	R7703[9] = (char *(*)()) F1150_9205;
	R7703[10] = (char *(*)()) F1151_9205;
	R7703[11] = (char *(*)()) F1152_9205;
}

char *(*R7704[12])();
void R7704_init () {
	R7704[0] = (char *(*)()) F1141_9206;
	R7704[1] = (char *(*)()) F1142_9206_7704_69;
	R7704[2] = (char *(*)()) F1143_9206_7704_69;
	R7704[3] = (char *(*)()) F1144_9206_7704_69;
	R7704[4] = (char *(*)()) F1145_9206_7704_69;
	R7704[5] = (char *(*)()) F1146_9206_7704_69;
	R7704[6] = (char *(*)()) F1147_9206_7704_69;
	R7704[7] = (char *(*)()) F1148_9206_7704_69;
	R7704[8] = (char *(*)()) F1149_9206_7704_69;
	R7704[9] = (char *(*)()) F1150_9206_7704_69;
	R7704[10] = (char *(*)()) F1151_9206_7704_69;
	R7704[11] = (char *(*)()) F1152_9206_7704_69;
}
static void F1142_9206_7704_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1142_9206(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1143_9206_7704_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1143_9206(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1144_9206_7704_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1144_9206(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1145_9206_7704_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1145_9206(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1146_9206_7704_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1146_9206(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1147_9206_7704_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1147_9206(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1148_9206_7704_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1148_9206(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1149_9206_7704_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1149_9206(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1150_9206_7704_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1150_9206(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1151_9206_7704_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1151_9206(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1152_9206_7704_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1152_9206(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7713[12])();
void R7713_init () {
	R7713[0] = (char *(*)()) F1141_9221;
	R7713[1] = (char *(*)()) F1142_9221;
	R7713[2] = (char *(*)()) F1143_9221;
	R7713[3] = (char *(*)()) F1144_9221;
	R7713[4] = (char *(*)()) F1145_9221;
	R7713[5] = (char *(*)()) F1146_9221;
	R7713[6] = (char *(*)()) F1147_9221;
	R7713[7] = (char *(*)()) F1148_9221;
	R7713[8] = (char *(*)()) F1149_9221;
	R7713[9] = (char *(*)()) F1150_9221;
	R7713[10] = (char *(*)()) F1151_9221;
	R7713[11] = (char *(*)()) F1152_9221;
}

char *(*R7714[12])();
void R7714_init () {
	R7714[0] = (char *(*)()) F1141_9223;
	R7714[1] = (char *(*)()) F1142_9223_7714_69;
	R7714[2] = (char *(*)()) F1143_9223_7714_69;
	R7714[3] = (char *(*)()) F1144_9223_7714_69;
	R7714[4] = (char *(*)()) F1145_9223_7714_69;
	R7714[5] = (char *(*)()) F1146_9223_7714_69;
	R7714[6] = (char *(*)()) F1147_9223_7714_69;
	R7714[7] = (char *(*)()) F1148_9223_7714_69;
	R7714[8] = (char *(*)()) F1149_9223_7714_69;
	R7714[9] = (char *(*)()) F1150_9223_7714_69;
	R7714[10] = (char *(*)()) F1151_9223_7714_69;
	R7714[11] = (char *(*)()) F1152_9223_7714_69;
}
static void F1142_9223_7714_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1142_9223(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1143_9223_7714_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1143_9223(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1144_9223_7714_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1144_9223(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1145_9223_7714_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1145_9223(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1146_9223_7714_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1146_9223(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1147_9223_7714_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1147_9223(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1148_9223_7714_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1148_9223(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1149_9223_7714_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1149_9223(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1150_9223_7714_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1150_9223(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1151_9223_7714_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1151_9223(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1152_9223_7714_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1152_9223(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7715[12])();
void R7715_init () {
	R7715[0] = (char *(*)()) F1141_9224;
	R7715[1] = (char *(*)()) F1142_9224_7715_69;
	R7715[2] = (char *(*)()) F1143_9224_7715_69;
	R7715[3] = (char *(*)()) F1144_9224_7715_69;
	R7715[4] = (char *(*)()) F1145_9224_7715_69;
	R7715[5] = (char *(*)()) F1146_9224_7715_69;
	R7715[6] = (char *(*)()) F1147_9224_7715_69;
	R7715[7] = (char *(*)()) F1148_9224_7715_69;
	R7715[8] = (char *(*)()) F1149_9224_7715_69;
	R7715[9] = (char *(*)()) F1150_9224_7715_69;
	R7715[10] = (char *(*)()) F1151_9224_7715_69;
	R7715[11] = (char *(*)()) F1152_9224_7715_69;
}
static void F1142_9224_7715_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1142_9224(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1143_9224_7715_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1143_9224(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1144_9224_7715_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1144_9224(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1145_9224_7715_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1145_9224(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1146_9224_7715_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1146_9224(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1147_9224_7715_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1147_9224(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1148_9224_7715_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1148_9224(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1149_9224_7715_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1149_9224(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1150_9224_7715_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1150_9224(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1151_9224_7715_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1151_9224(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1152_9224_7715_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1152_9224(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7716[12])();
void R7716_init () {
	R7716[0] = (char *(*)()) F1141_9225;
	R7716[1] = (char *(*)()) F1142_9225_7716_4;
	R7716[2] = (char *(*)()) F1143_9225_7716_4;
	R7716[3] = (char *(*)()) F1144_9225_7716_4;
	R7716[4] = (char *(*)()) F1145_9225_7716_4;
	R7716[5] = (char *(*)()) F1146_9225_7716_4;
	R7716[6] = (char *(*)()) F1147_9225_7716_4;
	R7716[7] = (char *(*)()) F1148_9225_7716_4;
	R7716[8] = (char *(*)()) F1149_9225_7716_4;
	R7716[9] = (char *(*)()) F1150_9225_7716_4;
	R7716[10] = (char *(*)()) F1151_9225_7716_4;
	R7716[11] = (char *(*)()) F1152_9225_7716_4;
}
static void F1142_9225_7716_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1142_9225(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1143_9225_7716_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1143_9225(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1144_9225_7716_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1144_9225(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F1145_9225_7716_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1145_9225(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1146_9225_7716_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1146_9225(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1147_9225_7716_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1147_9225(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1148_9225_7716_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1148_9225(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F1149_9225_7716_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1149_9225(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F1150_9225_7716_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1150_9225(Current, *(EIF_POINTER *)arg1);
}
static void F1151_9225_7716_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1151_9225(Current, *(EIF_REAL_32 *)arg1);
}
static void F1152_9225_7716_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1152_9225(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R7718[12])();
void R7718_init () {
	R7718[0] = (char *(*)()) F1141_9227;
	R7718[1] = (char *(*)()) F1142_9227_7718_20;
	R7718[2] = (char *(*)()) F1143_9227_7718_20;
	R7718[3] = (char *(*)()) F1144_9227_7718_20;
	R7718[4] = (char *(*)()) F1145_9227_7718_20;
	R7718[5] = (char *(*)()) F1146_9227_7718_20;
	R7718[6] = (char *(*)()) F1147_9227_7718_20;
	R7718[7] = (char *(*)()) F1148_9227_7718_20;
	R7718[8] = (char *(*)()) F1149_9227_7718_20;
	R7718[9] = (char *(*)()) F1150_9227_7718_20;
	R7718[10] = (char *(*)()) F1151_9227_7718_20;
	R7718[11] = (char *(*)()) F1152_9227_7718_20;
}
static void F1142_9227_7718_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1142_9227(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F1143_9227_7718_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1143_9227(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F1144_9227_7718_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1144_9227(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F1145_9227_7718_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1145_9227(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F1146_9227_7718_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1146_9227(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F1147_9227_7718_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1147_9227(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F1148_9227_7718_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1148_9227(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F1149_9227_7718_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1149_9227(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F1150_9227_7718_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1150_9227(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F1151_9227_7718_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1151_9227(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F1152_9227_7718_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1152_9227(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R7719[12])();
void R7719_init () {
	R7719[0] = (char *(*)()) F1141_9228;
	R7719[1] = (char *(*)()) F1142_9228;
	R7719[2] = (char *(*)()) F1143_9228;
	R7719[3] = (char *(*)()) F1144_9228;
	R7719[4] = (char *(*)()) F1145_9228;
	R7719[5] = (char *(*)()) F1146_9228;
	R7719[6] = (char *(*)()) F1147_9228;
	R7719[7] = (char *(*)()) F1148_9228;
	R7719[8] = (char *(*)()) F1149_9228;
	R7719[9] = (char *(*)()) F1150_9228;
	R7719[10] = (char *(*)()) F1151_9228;
	R7719[11] = (char *(*)()) F1152_9228;
}

char *(*R7721[12])();
void R7721_init () {
	R7721[0] = (char *(*)()) F1141_9230;
	R7721[1] = (char *(*)()) F1142_9230;
	R7721[2] = (char *(*)()) F1143_9230;
	R7721[3] = (char *(*)()) F1144_9230;
	R7721[4] = (char *(*)()) F1145_9230;
	R7721[5] = (char *(*)()) F1146_9230;
	R7721[6] = (char *(*)()) F1147_9230;
	R7721[7] = (char *(*)()) F1148_9230;
	R7721[8] = (char *(*)()) F1149_9230;
	R7721[9] = (char *(*)()) F1150_9230;
	R7721[10] = (char *(*)()) F1151_9230;
	R7721[11] = (char *(*)()) F1152_9230;
}

char *(*R7722[12])();
void R7722_init () {
	R7722[0] = (char *(*)()) F1141_9231;
	R7722[1] = (char *(*)()) F1142_9231;
	R7722[2] = (char *(*)()) F1143_9231;
	R7722[3] = (char *(*)()) F1144_9231;
	R7722[4] = (char *(*)()) F1145_9231;
	R7722[5] = (char *(*)()) F1146_9231;
	R7722[6] = (char *(*)()) F1147_9231;
	R7722[7] = (char *(*)()) F1148_9231;
	R7722[8] = (char *(*)()) F1149_9231;
	R7722[9] = (char *(*)()) F1150_9231;
	R7722[10] = (char *(*)()) F1151_9231;
	R7722[11] = (char *(*)()) F1152_9231;
}

char *(*R7723[12])();
void R7723_init () {
	R7723[0] = (char *(*)()) F1141_9232;
	R7723[1] = (char *(*)()) F1142_9232;
	R7723[2] = (char *(*)()) F1143_9232;
	R7723[3] = (char *(*)()) F1144_9232;
	R7723[4] = (char *(*)()) F1145_9232;
	R7723[5] = (char *(*)()) F1146_9232;
	R7723[6] = (char *(*)()) F1147_9232;
	R7723[7] = (char *(*)()) F1148_9232;
	R7723[8] = (char *(*)()) F1149_9232;
	R7723[9] = (char *(*)()) F1150_9232;
	R7723[10] = (char *(*)()) F1151_9232;
	R7723[11] = (char *(*)()) F1152_9232;
}

char *(*R7724[12])();
void R7724_init () {
	R7724[0] = (char *(*)()) F1141_9233;
	R7724[1] = (char *(*)()) F1142_9233;
	R7724[2] = (char *(*)()) F1143_9233;
	R7724[3] = (char *(*)()) F1144_9233;
	R7724[4] = (char *(*)()) F1145_9233;
	R7724[5] = (char *(*)()) F1146_9233;
	R7724[6] = (char *(*)()) F1147_9233;
	R7724[7] = (char *(*)()) F1148_9233;
	R7724[8] = (char *(*)()) F1149_9233;
	R7724[9] = (char *(*)()) F1150_9233;
	R7724[10] = (char *(*)()) F1151_9233;
	R7724[11] = (char *(*)()) F1152_9233;
}

char *(*R7725[12])();
void R7725_init () {
	R7725[0] = (char *(*)()) F1141_9234;
	R7725[1] = (char *(*)()) F1142_9234;
	R7725[2] = (char *(*)()) F1143_9234;
	R7725[3] = (char *(*)()) F1144_9234;
	R7725[4] = (char *(*)()) F1145_9234;
	R7725[5] = (char *(*)()) F1146_9234;
	R7725[6] = (char *(*)()) F1147_9234;
	R7725[7] = (char *(*)()) F1148_9234;
	R7725[8] = (char *(*)()) F1149_9234;
	R7725[9] = (char *(*)()) F1150_9234;
	R7725[10] = (char *(*)()) F1151_9234;
	R7725[11] = (char *(*)()) F1152_9234;
}

char *(*R7728[12])();
void R7728_init () {
	R7728[0] = (char *(*)()) F1141_9237;
	R7728[1] = (char *(*)()) F1142_9237;
	R7728[2] = (char *(*)()) F1143_9237;
	R7728[3] = (char *(*)()) F1144_9237;
	R7728[4] = (char *(*)()) F1145_9237;
	R7728[5] = (char *(*)()) F1146_9237;
	R7728[6] = (char *(*)()) F1147_9237;
	R7728[7] = (char *(*)()) F1148_9237;
	R7728[8] = (char *(*)()) F1149_9237;
	R7728[9] = (char *(*)()) F1150_9237;
	R7728[10] = (char *(*)()) F1151_9237;
	R7728[11] = (char *(*)()) F1152_9237;
}

char *(*R7731[12])();
void R7731_init () {
	R7731[0] = (char *(*)()) F1141_9240;
	R7731[1] = (char *(*)()) F1142_9240;
	R7731[2] = (char *(*)()) F1143_9240;
	R7731[3] = (char *(*)()) F1144_9240;
	R7731[4] = (char *(*)()) F1145_9240;
	R7731[5] = (char *(*)()) F1146_9240;
	R7731[6] = (char *(*)()) F1147_9240;
	R7731[7] = (char *(*)()) F1148_9240;
	R7731[8] = (char *(*)()) F1149_9240;
	R7731[9] = (char *(*)()) F1150_9240;
	R7731[10] = (char *(*)()) F1151_9240;
	R7731[11] = (char *(*)()) F1152_9240;
}

char *(*R7732[12])();
void R7732_init () {
	R7732[0] = (char *(*)()) F1141_9241;
	R7732[1] = (char *(*)()) F1142_9241_7732_8;
	R7732[2] = (char *(*)()) F1143_9241_7732_8;
	R7732[3] = (char *(*)()) F1144_9241_7732_8;
	R7732[4] = (char *(*)()) F1145_9241_7732_8;
	R7732[5] = (char *(*)()) F1146_9241_7732_8;
	R7732[6] = (char *(*)()) F1147_9241_7732_8;
	R7732[7] = (char *(*)()) F1148_9241_7732_8;
	R7732[8] = (char *(*)()) F1149_9241_7732_8;
	R7732[9] = (char *(*)()) F1150_9241_7732_8;
	R7732[10] = (char *(*)()) F1151_9241_7732_8;
	R7732[11] = (char *(*)()) F1152_9241_7732_8;
}
static EIF_REFERENCE F1142_9241_7732_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1142_9241(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F1143_9241_7732_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1143_9241(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F1144_9241_7732_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1144_9241(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F1145_9241_7732_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1145_9241(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F1146_9241_7732_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1146_9241(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F1147_9241_7732_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1147_9241(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F1148_9241_7732_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1148_9241(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F1149_9241_7732_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1149_9241(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F1150_9241_7732_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1150_9241(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F1151_9241_7732_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1151_9241(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F1152_9241_7732_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1152_9241(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7734[12])();
void R7734_init () {
	R7734[0] = (char *(*)()) F1141_9243;
	R7734[1] = (char *(*)()) F1142_9243;
	R7734[2] = (char *(*)()) F1143_9243;
	R7734[3] = (char *(*)()) F1144_9243;
	R7734[4] = (char *(*)()) F1145_9243;
	R7734[5] = (char *(*)()) F1146_9243;
	R7734[6] = (char *(*)()) F1147_9243;
	R7734[7] = (char *(*)()) F1148_9243;
	R7734[8] = (char *(*)()) F1149_9243;
	R7734[9] = (char *(*)()) F1150_9243;
	R7734[10] = (char *(*)()) F1151_9243;
	R7734[11] = (char *(*)()) F1152_9243;
}

char *(*R7736[12])();
void R7736_init () {
	R7736[0] = (char *(*)()) F1141_9245;
	R7736[1] = (char *(*)()) F1142_9245;
	R7736[2] = (char *(*)()) F1143_9245;
	R7736[3] = (char *(*)()) F1144_9245;
	R7736[4] = (char *(*)()) F1145_9245;
	R7736[5] = (char *(*)()) F1146_9245;
	R7736[6] = (char *(*)()) F1147_9245;
	R7736[7] = (char *(*)()) F1148_9245;
	R7736[8] = (char *(*)()) F1149_9245;
	R7736[9] = (char *(*)()) F1150_9245;
	R7736[10] = (char *(*)()) F1151_9245;
	R7736[11] = (char *(*)()) F1152_9245;
}

char *(*R7739[12])();
void R7739_init () {
	R7739[0] = (char *(*)()) F1141_9248;
	R7739[1] = (char *(*)()) F1142_9248;
	R7739[2] = (char *(*)()) F1143_9248;
	R7739[3] = (char *(*)()) F1144_9248;
	R7739[4] = (char *(*)()) F1145_9248;
	R7739[5] = (char *(*)()) F1146_9248;
	R7739[6] = (char *(*)()) F1147_9248;
	R7739[7] = (char *(*)()) F1148_9248;
	R7739[8] = (char *(*)()) F1149_9248;
	R7739[9] = (char *(*)()) F1150_9248;
	R7739[10] = (char *(*)()) F1151_9248;
	R7739[11] = (char *(*)()) F1152_9248;
}

char *(*R7743[12])();
void R7743_init () {
	R7743[0] = (char *(*)()) F1141_9253;
	R7743[1] = (char *(*)()) F1142_9253;
	R7743[2] = (char *(*)()) F1143_9253;
	R7743[3] = (char *(*)()) F1144_9253;
	R7743[4] = (char *(*)()) F1145_9253;
	R7743[5] = (char *(*)()) F1146_9253;
	R7743[6] = (char *(*)()) F1147_9253;
	R7743[7] = (char *(*)()) F1148_9253;
	R7743[8] = (char *(*)()) F1149_9253;
	R7743[9] = (char *(*)()) F1150_9253;
	R7743[10] = (char *(*)()) F1151_9253;
	R7743[11] = (char *(*)()) F1152_9253;
}

char *(*R7747[7])();
void R7747_init () {
	{long i; for (i = 0; i < 3; i++) R7747[i] = (char *(*)()) F1153_9257;}
	R7747[4] = (char *(*)()) F1160_9393;
	{long i; for (i = 5; i < 7; i++) R7747[i] = (char *(*)()) F1153_9257;}
}

char *(*R7750[7])();
void R7750_init () {
	{long i; for (i = 0; i < 3; i++) R7750[i] = (char *(*)()) F1153_9260;}
	{long i; for (i = 4; i < 6; i++) R7750[i] = (char *(*)()) F1153_9260;}
	R7750[6] = (char *(*)()) F1162_9439;
}

char *(*R7774[7])();
void R7774_init () {
	{long i; for (i = 0; i < 3; i++) R7774[i] = (char *(*)()) F1156_9347;}
	R7774[4] = (char *(*)()) F1160_9406;
	{long i; for (i = 5; i < 7; i++) R7774[i] = (char *(*)()) F1161_9427;}
}

char *(*R7775[7])();
void R7775_init () {
	{long i; for (i = 0; i < 3; i++) R7775[i] = (char *(*)()) F1156_9348;}
	R7775[4] = (char *(*)()) F1160_9407;
	{long i; for (i = 5; i < 7; i++) R7775[i] = (char *(*)()) F1153_9286;}
}

char *(*R7921[37])();
void R7921_init () {
	R7921[0] = (char *(*)()) F1210_9521;
	R7921[1] = (char *(*)()) F1211_9526;
	R7921[2] = (char *(*)()) F1212_9544;
	R7921[3] = (char *(*)()) F1213_9570;
	R7921[35] = (char *(*)()) F1245_10507;
	R7921[36] = (char *(*)()) F1246_10550;
}

char *(*R7980[29])();
void R7980_init () {
	R7980[0] = (char *(*)()) F1216_9672_7980_1;
	R7980[1] = (char *(*)()) F1217_9672_7980_1;
	R7980[3] = (char *(*)()) F1219_9771_7980_1;
	R7980[4] = (char *(*)()) F1220_9771_7980_1;
	R7980[6] = (char *(*)()) F1222_9870_7980_1;
	R7980[7] = (char *(*)()) F1223_9870_7980_1;
	R7980[9] = (char *(*)()) F1225_9969_7980_1;
	R7980[10] = (char *(*)()) F1226_9969_7980_1;
	R7980[27] = (char *(*)()) F1243_10492_7980_1;
	R7980[28] = (char *(*)()) F1244_10492_7980_1;
}
static EIF_REFERENCE F1216_9672_7980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1216_9672(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1217_9672_7980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1217_9672(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1219_9771_7980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1219_9771(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1220_9771_7980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1220_9771(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1222_9870_7980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1222_9870(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1222, 0x00).id, 1222, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1223_9870_7980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1223_9870(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1222, 0x00).id, 1222, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1225_9969_7980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1225_9969(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1225, 0x00).id, 1225, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1226_9969_7980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1226_9969(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1225, 0x00).id, 1225, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1243_10492_7980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1243_10492(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1244_10492_7980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1244_10492(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R7999[2])();
void R7999_init () {
	R7999[0] = (char *(*)()) F1216_9678;
	R7999[1] = (char *(*)()) F1217_9678;
}

char *(*R8000[2])();
void R8000_init () {
	R8000[0] = (char *(*)()) F1216_9679;
	R8000[1] = (char *(*)()) F1217_9679;
}

char *(*R8003[2])();
void R8003_init () {
	R8003[0] = (char *(*)()) F1216_9682;
	R8003[1] = (char *(*)()) F1217_9682;
}

char *(*R8053[2])();
void R8053_init () {
	R8053[0] = (char *(*)()) F1219_9775;
	R8053[1] = (char *(*)()) F1220_9775;
}

char *(*R8055[2])();
void R8055_init () {
	R8055[0] = (char *(*)()) F1219_9777;
	R8055[1] = (char *(*)()) F1220_9777;
}

char *(*R8056[2])();
void R8056_init () {
	R8056[0] = (char *(*)()) F1219_9778;
	R8056[1] = (char *(*)()) F1220_9778;
}

char *(*R8060[2])();
void R8060_init () {
	R8060[0] = (char *(*)()) F1219_9782;
	R8060[1] = (char *(*)()) F1220_9782;
}

char *(*R8112[2])();
void R8112_init () {
	R8112[0] = (char *(*)()) F1222_9877;
	R8112[1] = (char *(*)()) F1223_9877;
}

char *(*R8115[2])();
void R8115_init () {
	R8115[0] = (char *(*)()) F1222_9880;
	R8115[1] = (char *(*)()) F1223_9880;
}

char *(*R8165[2])();
void R8165_init () {
	R8165[0] = (char *(*)()) F1225_9973;
	R8165[1] = (char *(*)()) F1226_9973;
}

char *(*R8168[2])();
void R8168_init () {
	R8168[0] = (char *(*)()) F1225_9976;
	R8168[1] = (char *(*)()) F1226_9976;
}

char *(*R8171[2])();
void R8171_init () {
	R8171[0] = (char *(*)()) F1225_9979;
	R8171[1] = (char *(*)()) F1226_9979;
}

char *(*R8225[2])();
void R8225_init () {
	R8225[0] = (char *(*)()) F1228_10073;
	R8225[1] = (char *(*)()) F1229_10073;
}

char *(*R8271[2])();
void R8271_init () {
	R8271[0] = (char *(*)()) F1231_10161;
	R8271[1] = (char *(*)()) F1232_10161;
}

char *(*R8272[2])();
void R8272_init () {
	R8272[0] = (char *(*)()) F1231_10162;
	R8272[1] = (char *(*)()) F1232_10162;
}

char *(*R8274[2])();
void R8274_init () {
	R8274[0] = (char *(*)()) F1231_10164;
	R8274[1] = (char *(*)()) F1232_10164;
}

char *(*R8277[2])();
void R8277_init () {
	R8277[0] = (char *(*)()) F1231_10167;
	R8277[1] = (char *(*)()) F1232_10167;
}

char *(*R8278[2])();
void R8278_init () {
	R8278[0] = (char *(*)()) F1231_10168;
	R8278[1] = (char *(*)()) F1232_10168;
}

char *(*R8326[2])();
void R8326_init () {
	R8326[0] = (char *(*)()) F1234_10258;
	R8326[1] = (char *(*)()) F1235_10258;
}

char *(*R8327[2])();
void R8327_init () {
	R8327[0] = (char *(*)()) F1234_10259;
	R8327[1] = (char *(*)()) F1235_10259;
}

char *(*R8330[2])();
void R8330_init () {
	R8330[0] = (char *(*)()) F1234_10262;
	R8330[1] = (char *(*)()) F1235_10262;
}

char *(*R8378[2])();
void R8378_init () {
	R8378[0] = (char *(*)()) F1237_10352;
	R8378[1] = (char *(*)()) F1238_10352;
}

char *(*R8379[2])();
void R8379_init () {
	R8379[0] = (char *(*)()) F1237_10353;
	R8379[1] = (char *(*)()) F1238_10353;
}

char *(*R8380[2])();
void R8380_init () {
	R8380[0] = (char *(*)()) F1237_10354;
	R8380[1] = (char *(*)()) F1238_10354;
}

char *(*R8381[2])();
void R8381_init () {
	R8381[0] = (char *(*)()) F1237_10355;
	R8381[1] = (char *(*)()) F1238_10355;
}

char *(*R8383[2])();
void R8383_init () {
	R8383[0] = (char *(*)()) F1237_10357;
	R8383[1] = (char *(*)()) F1238_10357;
}

char *(*R8429[2])();
void R8429_init () {
	R8429[0] = (char *(*)()) F1240_10415;
	R8429[1] = (char *(*)()) F1241_10415;
}

char *(*R8463[2])();
void R8463_init () {
	R8463[0] = (char *(*)()) F1243_10481;
	R8463[1] = (char *(*)()) F1244_10481;
}

char *(*R8470[2])();
void R8470_init () {
	R8470[0] = (char *(*)()) F1243_10485;
	R8470[1] = (char *(*)()) F1244_10485;
}

char *(*R8631[3])();
void R8631_init () {
	R8631[0] = (char *(*)()) F1262_10714;
	R8631[1] = (char *(*)()) F1263_10714;
	R8631[2] = (char *(*)()) F1264_10714;
}

char *(*R8633[3])();
void R8633_init () {
	R8633[0] = (char *(*)()) F1262_10716;
	R8633[1] = (char *(*)()) F1263_10716_8633_2;
	R8633[2] = (char *(*)()) F1264_10716_8633_2;
}
static EIF_BOOLEAN F1263_10716_8633_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1263_10716(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1264_10716_8633_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1264_10716(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R8638[3])();
void R8638_init () {
	R8638[0] = (char *(*)()) F1262_10721;
	R8638[1] = (char *(*)()) F1263_10721_8638_1;
	R8638[2] = (char *(*)()) F1264_10721_8638_1;
}
static EIF_REFERENCE F1263_10721_8638_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1263_10721(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1264_10721_8638_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1264_10721(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R8642[3])();
void R8642_init () {
	R8642[0] = (char *(*)()) F1262_10727;
	R8642[1] = (char *(*)()) F1263_10727_8642_3;
	R8642[2] = (char *(*)()) F1264_10727_8642_3;
}
static EIF_BOOLEAN F1263_10727_8642_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F1263_10727(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F1264_10727_8642_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F1264_10727(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_CHARACTER_32 *)arg2);
}

char *(*R8643[3])();
void R8643_init () {
	R8643[0] = (char *(*)()) F1262_10728;
	R8643[1] = (char *(*)()) F1263_10728_8643_4;
	R8643[2] = (char *(*)()) F1264_10728_8643_4;
}
static void F1263_10728_8643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1263_10728(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1264_10728_8643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1264_10728(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R8651[3])();
void R8651_init () {
	R8651[0] = (char *(*)()) F1262_10736;
	R8651[1] = (char *(*)()) F1263_10736;
	R8651[2] = (char *(*)()) F1264_10736;
}

char *(*R8653[3])();
void R8653_init () {
	R8653[0] = (char *(*)()) F1262_10739;
	R8653[1] = (char *(*)()) F1263_10739;
	R8653[2] = (char *(*)()) F1264_10739;
}

char *(*R8656[3])();
void R8656_init () {
	R8656[0] = (char *(*)()) F1262_10742;
	R8656[1] = (char *(*)()) F1263_10742_8656_4;
	R8656[2] = (char *(*)()) F1264_10742_8656_4;
}
static void F1263_10742_8656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1263_10742(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1264_10742_8656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1264_10742(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R8657[3])();
void R8657_init () {
	R8657[0] = (char *(*)()) F1262_10743;
	R8657[1] = (char *(*)()) F1263_10743;
	R8657[2] = (char *(*)()) F1264_10743;
}

char *(*R8659[3])();
void R8659_init () {
	R8659[0] = (char *(*)()) F1262_10745;
	R8659[1] = (char *(*)()) F1263_10745;
	R8659[2] = (char *(*)()) F1264_10745;
}

char *(*R8660[3])();
void R8660_init () {
	R8660[0] = (char *(*)()) F1262_10746;
	R8660[1] = (char *(*)()) F1263_10746_8660_2;
	R8660[2] = (char *(*)()) F1264_10746_8660_2;
}
static EIF_BOOLEAN F1263_10746_8660_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1263_10746(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1264_10746_8660_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1264_10746(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R8674[3])();
void R8674_init () {
	R8674[0] = (char *(*)()) F1262_10760;
	R8674[1] = (char *(*)()) F1263_10760;
	R8674[2] = (char *(*)()) F1264_10760;
}

char *(*R8675[3])();
void R8675_init () {
	R8675[0] = (char *(*)()) F1262_10761;
	R8675[1] = (char *(*)()) F1263_10761;
	R8675[2] = (char *(*)()) F1264_10761;
}

char *(*R9049[3])();
void R9049_init () {
	R9049[0] = (char *(*)()) F1284_11205;
	{long i; for (i = 1; i < 3; i++) R9049[i] = (char *(*)()) F1285_11233;}
}

char *(*R9054[3])();
void R9054_init () {
	R9054[0] = (char *(*)()) F1284_11206;
	{long i; for (i = 1; i < 3; i++) R9054[i] = (char *(*)()) F1285_11228;}
}

char *(*R9056[3])();
void R9056_init () {
	R9056[0] = (char *(*)()) F1284_11207;
	{long i; for (i = 1; i < 3; i++) R9056[i] = (char *(*)()) F1285_11229;}
}

char *(*R9964[4])();
void R9964_init () {
	R9964[0] = (char *(*)()) F1303_12162;
	R9964[1] = (char *(*)()) F1304_12163;
	R9964[2] = (char *(*)()) F1305_12164;
	R9964[3] = (char *(*)()) F1306_12165;
}

char *(*R10410[3])();
void R10410_init () {
	{long i; for (i = 0; i < 2; i++) R10410[i] = (char *(*)()) F1335_12772;}
	R10410[2] = (char *(*)()) F1337_12840;
}

char *(*R10608[2])();
void R10608_init () {
	R10608[0] = (char *(*)()) F1347_13174;
	R10608[1] = (char *(*)()) F1348_13175;
}

char *(*R2[1352])();
void R2_init () {
	R2[1258] = (char *(*)()) F1259_2;
}
char *(*R6[1352])();
void R6_init () {}

char *(*R3[1352])();
void R3_init () {
	R3[443] = (char *(*)()) F444_5130;
	R3[444] = (char *(*)()) F445_5228;
	R3[447] = (char *(*)()) F447_5270;
	R3[448] = (char *(*)()) F449_5377;
	R3[466] = (char *(*)()) F467_5827;
	R3[480] = (char *(*)()) F481_5929;
	{long i; for (i = 828; i < 830; i++) R3[i] = (char *(*)()) F466_5764;}
	R3[1260] = (char *(*)()) F1261_10658;
}

char *(*R4[1352])();
void R4_init () {
	R4[2] = (char *(*)()) F1_15;
	{long i; for (i = 8; i < 10; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 11; i < 23; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 24; i < 33; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 34; i < 36; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 37; i < 54; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 56; i < 60; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 61; i < 70; i++) R4[i] = (char *(*)()) F1_15;}
	R4[72] = (char *(*)()) F1_15;
	{long i; for (i = 85; i < 90; i++) R4[i] = (char *(*)()) F1_15;}
	R4[100] = (char *(*)()) F1_15;
	R4[105] = (char *(*)()) F1_15;
	R4[109] = (char *(*)()) F1_15;
	R4[123] = (char *(*)()) F1_15;
	R4[125] = (char *(*)()) F1_15;
	{long i; for (i = 135; i < 137; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 138; i < 140; i++) R4[i] = (char *(*)()) F1_15;}
	R4[143] = (char *(*)()) F1_15;
	{long i; for (i = 146; i < 148; i++) R4[i] = (char *(*)()) F1_15;}
	R4[155] = (char *(*)()) F1_15;
	R4[160] = (char *(*)()) F1_15;
	{long i; for (i = 165; i < 168; i++) R4[i] = (char *(*)()) F1_15;}
	R4[170] = (char *(*)()) F1_15;
	R4[172] = (char *(*)()) F1_15;
	{long i; for (i = 174; i < 176; i++) R4[i] = (char *(*)()) F1_15;}
	R4[178] = (char *(*)()) F1_15;
	R4[182] = (char *(*)()) F1_15;
	{long i; for (i = 184; i < 186; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 187; i < 197; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 204; i < 206; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 207; i < 209; i++) R4[i] = (char *(*)()) F1_15;}
	R4[212] = (char *(*)()) F1_15;
	{long i; for (i = 214; i < 216; i++) R4[i] = (char *(*)()) F1_15;}
	R4[218] = (char *(*)()) F1_15;
	R4[227] = (char *(*)()) F1_15;
	R4[236] = (char *(*)()) F1_15;
	R4[239] = (char *(*)()) F1_15;
	R4[241] = (char *(*)()) F1_15;
	{long i; for (i = 244; i < 246; i++) R4[i] = (char *(*)()) F1_15;}
	R4[251] = (char *(*)()) F1_15;
	{long i; for (i = 257; i < 259; i++) R4[i] = (char *(*)()) F1_15;}
	R4[261] = (char *(*)()) F1_15;
	R4[263] = (char *(*)()) F1_15;
	{long i; for (i = 265; i < 269; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 270; i < 273; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 274; i < 276; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 281; i < 285; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 297; i < 299; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 300; i < 304; i++) R4[i] = (char *(*)()) F1_15;}
	R4[305] = (char *(*)()) F1_15;
	R4[311] = (char *(*)()) F1_15;
	{long i; for (i = 313; i < 315; i++) R4[i] = (char *(*)()) F1_15;}
	R4[318] = (char *(*)()) F1_15;
	{long i; for (i = 322; i < 326; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 328; i < 330; i++) R4[i] = (char *(*)()) F1_15;}
	R4[332] = (char *(*)()) F1_15;
	{long i; for (i = 334; i < 340; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 341; i < 344; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 345; i < 347; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 349; i < 351; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 352; i < 355; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 356; i < 360; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 361; i < 363; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 364; i < 370; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 371; i < 375; i++) R4[i] = (char *(*)()) F1_15;}
	R4[377] = (char *(*)()) F1_15;
	R4[385] = (char *(*)()) F1_15;
	R4[391] = (char *(*)()) F1_15;
	R4[397] = (char *(*)()) F1_15;
	R4[400] = (char *(*)()) F1_15;
	R4[402] = (char *(*)()) F1_15;
	{long i; for (i = 405; i < 407; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 408; i < 415; i++) R4[i] = (char *(*)()) F1_15;}
	R4[431] = (char *(*)()) F1_15;
	R4[432] = (char *(*)()) F433_5046;
	{long i; for (i = 434; i < 440; i++) R4[i] = (char *(*)()) F1_15;}
	R4[443] = (char *(*)()) F1_15;
	R4[444] = (char *(*)()) F445_5147;
	{long i; for (i = 447; i < 449; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 450; i < 452; i++) R4[i] = (char *(*)()) F1_15;}
	R4[453] = (char *(*)()) F1_15;
	{long i; for (i = 455; i < 457; i++) R4[i] = (char *(*)()) F1_15;}
	R4[460] = (char *(*)()) F1_15;
	R4[464] = (char *(*)()) F1_15;
	R4[466] = (char *(*)()) F1_15;
	{long i; for (i = 479; i < 484; i++) R4[i] = (char *(*)()) F1_15;}
	R4[509] = (char *(*)()) F1_15;
	{long i; for (i = 534; i < 556; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 568; i < 606; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 759; i < 761; i++) R4[i] = (char *(*)()) F1_15;}
	R4[800] = (char *(*)()) F801_6327;
	{long i; for (i = 828; i < 830; i++) R4[i] = (char *(*)()) F1_15;}
	R4[838] = (char *(*)()) F1_15;
	R4[851] = (char *(*)()) F852_6778;
	R4[852] = (char *(*)()) F853_6778;
	R4[853] = (char *(*)()) F854_6778;
	R4[854] = (char *(*)()) F855_6778;
	R4[855] = (char *(*)()) F856_6778;
	R4[856] = (char *(*)()) F857_6778;
	R4[857] = (char *(*)()) F858_6778;
	R4[858] = (char *(*)()) F859_6778;
	{long i; for (i = 859; i < 861; i++) R4[i] = (char *(*)()) F852_6778;}
	R4[861] = (char *(*)()) F854_6778;
	R4[862] = (char *(*)()) F855_6778;
	R4[863] = (char *(*)()) F856_6778;
	R4[864] = (char *(*)()) F858_6778;
	R4[877] = (char *(*)()) F878_6880;
	R4[878] = (char *(*)()) F879_6945;
	R4[879] = (char *(*)()) F880_6945;
	R4[880] = (char *(*)()) F881_6945;
	R4[881] = (char *(*)()) F882_6945;
	R4[882] = (char *(*)()) F883_6945;
	R4[883] = (char *(*)()) F884_6945;
	R4[884] = (char *(*)()) F885_6945;
	R4[885] = (char *(*)()) F886_6945;
	R4[886] = (char *(*)()) F887_6945;
	R4[887] = (char *(*)()) F888_6945;
	R4[888] = (char *(*)()) F889_6945;
	R4[889] = (char *(*)()) F890_6945;
	R4[943] = (char *(*)()) F944_7038;
	R4[944] = (char *(*)()) F945_7038;
	R4[945] = (char *(*)()) F944_7038;
	R4[946] = (char *(*)()) F945_7038;
	R4[947] = (char *(*)()) F944_7038;
	R4[948] = (char *(*)()) F949_7122;
	R4[949] = (char *(*)()) F950_7122;
	R4[950] = (char *(*)()) F951_7122;
	R4[951] = (char *(*)()) F952_7122;
	R4[952] = (char *(*)()) F953_7122;
	R4[953] = (char *(*)()) F954_7122;
	R4[954] = (char *(*)()) F955_7122;
	R4[955] = (char *(*)()) F956_7122;
	R4[956] = (char *(*)()) F957_7122;
	R4[957] = (char *(*)()) F958_7122;
	R4[958] = (char *(*)()) F959_7122;
	R4[959] = (char *(*)()) F960_7122;
	{long i; for (i = 960; i < 963; i++) R4[i] = (char *(*)()) F949_7122;}
	R4[963] = (char *(*)()) F951_7122;
	R4[964] = (char *(*)()) F949_7122;
	R4[966] = (char *(*)()) F1_15;
	R4[968] = (char *(*)()) F1_15;
	R4[969] = (char *(*)()) F970_7407;
	R4[970] = (char *(*)()) F971_7443;
	R4[984] = (char *(*)()) F1_15;
	R4[993] = (char *(*)()) F1_15;
	{long i; for (i = 1008; i < 1019; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1021; i < 1023; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1025; i < 1029; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1030; i < 1032; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1033; i < 1035; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1036; i < 1038; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1039; i < 1071; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1072] = (char *(*)()) F1072_8127;
	R4[1073] = (char *(*)()) F1074_8159;
	R4[1074] = (char *(*)()) F1075_8159;
	R4[1075] = (char *(*)()) F1076_8159;
	R4[1076] = (char *(*)()) F1075_8159;
	R4[1081] = (char *(*)()) F1082_8351;
	R4[1082] = (char *(*)()) F1081_8335;
	R4[1085] = (char *(*)()) F1086_8519;
	R4[1086] = (char *(*)()) F1085_8500;
	{long i; for (i = 1088; i < 1096; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1098; i < 1101; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1101] = (char *(*)()) F1102_9140;
	{long i; for (i = 1102; i < 1139; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1140; i < 1152; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1155; i < 1158; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1159; i < 1162; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1209; i < 1213; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1215; i < 1217; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1218; i < 1220; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1221; i < 1223; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1224; i < 1226; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1227; i < 1229; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1230; i < 1232; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1233; i < 1235; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1236; i < 1238; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1239; i < 1241; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1242; i < 1246; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1251; i < 1261; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1261] = (char *(*)()) F1262_10738;
	R4[1262] = (char *(*)()) F1263_10738;
	R4[1263] = (char *(*)()) F1264_10738;
	{long i; for (i = 1264; i < 1266; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1281] = (char *(*)()) F1_15;
	{long i; for (i = 1283; i < 1286; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1287; i < 1289; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1294] = (char *(*)()) F1_15;
	R4[1296] = (char *(*)()) F1_15;
	R4[1298] = (char *(*)()) F1_15;
	R4[1300] = (char *(*)()) F1_15;
	{long i; for (i = 1302; i < 1306; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1320; i < 1324; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1333; i < 1337; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1338] = (char *(*)()) F1_15;
	R4[1340] = (char *(*)()) F1_15;
	R4[1343] = (char *(*)()) F1344_12978;
	R4[1344] = (char *(*)()) F1_15;
	{long i; for (i = 1346; i < 1348; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1350] = (char *(*)()) F1351_13299;
}

char *(*R5[1352])();
void R5_init () {
	R5[2] = (char *(*)()) F1_8;
	{long i; for (i = 8; i < 10; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 11; i < 23; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 24; i < 33; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 34; i < 36; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 37; i < 54; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 56; i < 60; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 61; i < 66; i++) R5[i] = (char *(*)()) F1_8;}
	R5[66] = (char *(*)()) F67_983;
	{long i; for (i = 67; i < 70; i++) R5[i] = (char *(*)()) F1_8;}
	R5[72] = (char *(*)()) F1_8;
	{long i; for (i = 85; i < 90; i++) R5[i] = (char *(*)()) F1_8;}
	R5[100] = (char *(*)()) F1_8;
	R5[105] = (char *(*)()) F1_8;
	R5[109] = (char *(*)()) F1_8;
	R5[123] = (char *(*)()) F1_8;
	R5[125] = (char *(*)()) F1_8;
	{long i; for (i = 135; i < 137; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 138; i < 140; i++) R5[i] = (char *(*)()) F1_8;}
	R5[143] = (char *(*)()) F1_8;
	{long i; for (i = 146; i < 148; i++) R5[i] = (char *(*)()) F1_8;}
	R5[155] = (char *(*)()) F1_8;
	R5[160] = (char *(*)()) F1_8;
	{long i; for (i = 165; i < 168; i++) R5[i] = (char *(*)()) F1_8;}
	R5[170] = (char *(*)()) F1_8;
	R5[172] = (char *(*)()) F1_8;
	{long i; for (i = 174; i < 176; i++) R5[i] = (char *(*)()) F1_8;}
	R5[178] = (char *(*)()) F1_8;
	R5[182] = (char *(*)()) F1_8;
	{long i; for (i = 184; i < 186; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 187; i < 197; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 204; i < 206; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 207; i < 209; i++) R5[i] = (char *(*)()) F1_8;}
	R5[212] = (char *(*)()) F1_8;
	{long i; for (i = 214; i < 216; i++) R5[i] = (char *(*)()) F1_8;}
	R5[218] = (char *(*)()) F1_8;
	R5[227] = (char *(*)()) F1_8;
	R5[236] = (char *(*)()) F1_8;
	R5[239] = (char *(*)()) F1_8;
	R5[241] = (char *(*)()) F1_8;
	{long i; for (i = 244; i < 246; i++) R5[i] = (char *(*)()) F1_8;}
	R5[251] = (char *(*)()) F1_8;
	{long i; for (i = 257; i < 259; i++) R5[i] = (char *(*)()) F1_8;}
	R5[261] = (char *(*)()) F1_8;
	R5[263] = (char *(*)()) F1_8;
	{long i; for (i = 265; i < 269; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 270; i < 273; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 274; i < 276; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 281; i < 285; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 297; i < 299; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 300; i < 304; i++) R5[i] = (char *(*)()) F1_8;}
	R5[305] = (char *(*)()) F1_8;
	R5[311] = (char *(*)()) F1_8;
	{long i; for (i = 313; i < 315; i++) R5[i] = (char *(*)()) F1_8;}
	R5[318] = (char *(*)()) F1_8;
	{long i; for (i = 322; i < 326; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 328; i < 330; i++) R5[i] = (char *(*)()) F1_8;}
	R5[332] = (char *(*)()) F1_8;
	{long i; for (i = 334; i < 340; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 341; i < 344; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 345; i < 347; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 349; i < 351; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 352; i < 355; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 356; i < 360; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 361; i < 363; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 364; i < 370; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 371; i < 375; i++) R5[i] = (char *(*)()) F1_8;}
	R5[377] = (char *(*)()) F1_8;
	R5[385] = (char *(*)()) F385_4409;
	R5[391] = (char *(*)()) F1_8;
	R5[397] = (char *(*)()) F1_8;
	R5[400] = (char *(*)()) F1_8;
	R5[402] = (char *(*)()) F1_8;
	R5[405] = (char *(*)()) F406_4903;
	R5[406] = (char *(*)()) F1_8;
	{long i; for (i = 408; i < 415; i++) R5[i] = (char *(*)()) F1_8;}
	R5[431] = (char *(*)()) F432_4996;
	R5[432] = (char *(*)()) F433_5045;
	{long i; for (i = 434; i < 440; i++) R5[i] = (char *(*)()) F1_8;}
	R5[443] = (char *(*)()) F1_8;
	R5[444] = (char *(*)()) F445_5146;
	{long i; for (i = 447; i < 449; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 450; i < 452; i++) R5[i] = (char *(*)()) F1_8;}
	R5[453] = (char *(*)()) F1_8;
	{long i; for (i = 455; i < 457; i++) R5[i] = (char *(*)()) F1_8;}
	R5[460] = (char *(*)()) F1_8;
	R5[464] = (char *(*)()) F1_8;
	R5[466] = (char *(*)()) F1_8;
	{long i; for (i = 479; i < 484; i++) R5[i] = (char *(*)()) F1_8;}
	R5[509] = (char *(*)()) F1_8;
	{long i; for (i = 534; i < 556; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 568; i < 606; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 759; i < 761; i++) R5[i] = (char *(*)()) F1_8;}
	R5[800] = (char *(*)()) F801_6314;
	{long i; for (i = 828; i < 830; i++) R5[i] = (char *(*)()) F1_8;}
	R5[838] = (char *(*)()) F1_8;
	R5[851] = (char *(*)()) F852_6744;
	R5[852] = (char *(*)()) F853_6744;
	R5[853] = (char *(*)()) F854_6744;
	R5[854] = (char *(*)()) F855_6744;
	R5[855] = (char *(*)()) F856_6744;
	R5[856] = (char *(*)()) F857_6744;
	R5[857] = (char *(*)()) F858_6744;
	R5[858] = (char *(*)()) F859_6744;
	R5[859] = (char *(*)()) F852_6744;
	R5[860] = (char *(*)()) F861_6850;
	R5[861] = (char *(*)()) F862_6850;
	R5[862] = (char *(*)()) F863_6850;
	R5[863] = (char *(*)()) F864_6850;
	R5[864] = (char *(*)()) F865_6850;
	R5[877] = (char *(*)()) F878_6866;
	R5[878] = (char *(*)()) F879_6907;
	R5[879] = (char *(*)()) F880_6907;
	R5[880] = (char *(*)()) F881_6907;
	R5[881] = (char *(*)()) F882_6907;
	R5[882] = (char *(*)()) F883_6907;
	R5[883] = (char *(*)()) F884_6907;
	R5[884] = (char *(*)()) F885_6907;
	R5[885] = (char *(*)()) F886_6907;
	R5[886] = (char *(*)()) F887_6907;
	R5[887] = (char *(*)()) F888_6907;
	R5[888] = (char *(*)()) F889_6907;
	R5[889] = (char *(*)()) F890_6907;
	R5[943] = (char *(*)()) F920_6989;
	R5[944] = (char *(*)()) F922_6989;
	R5[945] = (char *(*)()) F920_6989;
	R5[946] = (char *(*)()) F922_6989;
	R5[947] = (char *(*)()) F920_6989;
	R5[948] = (char *(*)()) F949_7095;
	R5[949] = (char *(*)()) F950_7095;
	R5[950] = (char *(*)()) F951_7095;
	R5[951] = (char *(*)()) F952_7095;
	R5[952] = (char *(*)()) F953_7095;
	R5[953] = (char *(*)()) F954_7095;
	R5[954] = (char *(*)()) F955_7095;
	R5[955] = (char *(*)()) F956_7095;
	R5[956] = (char *(*)()) F957_7095;
	R5[957] = (char *(*)()) F958_7095;
	R5[958] = (char *(*)()) F959_7095;
	R5[959] = (char *(*)()) F960_7095;
	{long i; for (i = 960; i < 963; i++) R5[i] = (char *(*)()) F949_7095;}
	R5[963] = (char *(*)()) F951_7095;
	R5[964] = (char *(*)()) F949_7095;
	R5[966] = (char *(*)()) F1_8;
	R5[968] = (char *(*)()) F1_8;
	{long i; for (i = 969; i < 971; i++) R5[i] = (char *(*)()) F970_7408;}
	R5[984] = (char *(*)()) F1_8;
	R5[993] = (char *(*)()) F1_8;
	{long i; for (i = 1008; i < 1019; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1021; i < 1023; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1025] = (char *(*)()) F1026_7831;
	{long i; for (i = 1026; i < 1029; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1030; i < 1032; i++) R5[i] = (char *(*)()) F1030_7977;}
	{long i; for (i = 1033; i < 1035; i++) R5[i] = (char *(*)()) F1033_8017;}
	{long i; for (i = 1036; i < 1038; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1039; i < 1071; i++) R5[i] = (char *(*)()) F1039_8083;}
	R5[1072] = (char *(*)()) F1072_8120;
	R5[1073] = (char *(*)()) F1074_8158;
	R5[1074] = (char *(*)()) F1075_8158;
	R5[1075] = (char *(*)()) F1076_8158;
	R5[1076] = (char *(*)()) F1075_8158;
	{long i; for (i = 1081; i < 1083; i++) R5[i] = (char *(*)()) F1081_8320;}
	{long i; for (i = 1085; i < 1087; i++) R5[i] = (char *(*)()) F1085_8485;}
	{long i; for (i = 1088; i < 1090; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1090] = (char *(*)()) F1091_8664;
	{long i; for (i = 1091; i < 1094; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1094] = (char *(*)()) F1095_8789;
	R5[1095] = (char *(*)()) F1_8;
	{long i; for (i = 1098; i < 1101; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1101] = (char *(*)()) F1102_9137;
	R5[1102] = (char *(*)()) F1_8;
	R5[1103] = (char *(*)()) F1104_9181;
	R5[1104] = (char *(*)()) F1105_9181;
	R5[1105] = (char *(*)()) F1106_9181;
	R5[1106] = (char *(*)()) F1107_9181;
	R5[1107] = (char *(*)()) F1108_9181;
	R5[1108] = (char *(*)()) F1109_9181;
	R5[1109] = (char *(*)()) F1110_9181;
	R5[1110] = (char *(*)()) F1111_9181;
	R5[1111] = (char *(*)()) F1112_9181;
	R5[1112] = (char *(*)()) F1113_9181;
	R5[1113] = (char *(*)()) F1114_9181;
	R5[1114] = (char *(*)()) F1115_9181;
	R5[1115] = (char *(*)()) F1116_9181;
	R5[1116] = (char *(*)()) F1117_9181;
	R5[1117] = (char *(*)()) F1118_9181;
	R5[1118] = (char *(*)()) F1119_9181;
	R5[1119] = (char *(*)()) F1120_9181;
	R5[1120] = (char *(*)()) F1121_9181;
	R5[1121] = (char *(*)()) F1122_9181;
	R5[1122] = (char *(*)()) F1123_9181;
	R5[1123] = (char *(*)()) F1124_9181;
	R5[1124] = (char *(*)()) F1125_9181;
	R5[1125] = (char *(*)()) F1126_9181;
	R5[1126] = (char *(*)()) F1127_9181;
	R5[1127] = (char *(*)()) F1128_9181;
	R5[1128] = (char *(*)()) F1129_9181;
	R5[1129] = (char *(*)()) F1130_9181;
	R5[1130] = (char *(*)()) F1131_9181;
	R5[1131] = (char *(*)()) F1132_9181;
	R5[1132] = (char *(*)()) F1133_9181;
	R5[1133] = (char *(*)()) F1134_9181;
	R5[1134] = (char *(*)()) F1135_9181;
	R5[1135] = (char *(*)()) F1136_9181;
	R5[1136] = (char *(*)()) F1137_9181;
	R5[1137] = (char *(*)()) F1138_9181;
	R5[1138] = (char *(*)()) F1139_9181;
	{long i; for (i = 1140; i < 1152; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1155; i < 1158; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1159; i < 1162; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1209; i < 1211; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1211] = (char *(*)()) F1212_9548;
	R5[1212] = (char *(*)()) F1213_9580;
	{long i; for (i = 1215; i < 1217; i++) R5[i] = (char *(*)()) F1215_9605;}
	{long i; for (i = 1218; i < 1220; i++) R5[i] = (char *(*)()) F1218_9703;}
	{long i; for (i = 1221; i < 1223; i++) R5[i] = (char *(*)()) F1221_9802;}
	{long i; for (i = 1224; i < 1226; i++) R5[i] = (char *(*)()) F1224_9901;}
	{long i; for (i = 1227; i < 1229; i++) R5[i] = (char *(*)()) F1227_10000;}
	{long i; for (i = 1230; i < 1232; i++) R5[i] = (char *(*)()) F1230_10094;}
	{long i; for (i = 1233; i < 1235; i++) R5[i] = (char *(*)()) F1233_10188;}
	{long i; for (i = 1236; i < 1238; i++) R5[i] = (char *(*)()) F1236_10283;}
	{long i; for (i = 1239; i < 1241; i++) R5[i] = (char *(*)()) F1239_10382;}
	{long i; for (i = 1242; i < 1244; i++) R5[i] = (char *(*)()) F1242_10448;}
	{long i; for (i = 1244; i < 1246; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1251] = (char *(*)()) F1252_10563;
	{long i; for (i = 1252; i < 1254; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1254] = (char *(*)()) F1255_10604;
	{long i; for (i = 1255; i < 1261; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1261] = (char *(*)()) F1262_10725;
	R5[1262] = (char *(*)()) F1263_10725;
	R5[1263] = (char *(*)()) F1264_10725;
	{long i; for (i = 1264; i < 1266; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1281] = (char *(*)()) F1_8;
	{long i; for (i = 1283; i < 1286; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1287; i < 1289; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1294] = (char *(*)()) F1_8;
	R5[1296] = (char *(*)()) F1_8;
	R5[1298] = (char *(*)()) F1_8;
	R5[1300] = (char *(*)()) F1301_12153;
	{long i; for (i = 1302; i < 1306; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1320; i < 1322; i++) R5[i] = (char *(*)()) F1320_12301;}
	{long i; for (i = 1322; i < 1324; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1333; i < 1337; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1338] = (char *(*)()) F385_4409;
	R5[1340] = (char *(*)()) F385_4409;
	R5[1343] = (char *(*)()) F1344_12974;
	R5[1344] = (char *(*)()) F1_8;
	{long i; for (i = 1346; i < 1348; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1350] = (char *(*)()) F1351_13256;
}


#ifdef __cplusplus
}
#endif
