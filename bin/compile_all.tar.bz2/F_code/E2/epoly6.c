#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5495[500])();
void R5495_init () {
	R5495[0] = (char *(*)()) F852_6768;
	R5495[1] = (char *(*)()) F853_6768_5495_9;
	R5495[2] = (char *(*)()) F854_6768_5495_9;
	R5495[3] = (char *(*)()) F855_6768_5495_9;
	R5495[4] = (char *(*)()) F856_6768_5495_9;
	R5495[5] = (char *(*)()) F857_6768_5495_9;
	R5495[6] = (char *(*)()) F858_6768_5495_9;
	R5495[7] = (char *(*)()) F859_6768_5495_9;
	{long i; for (i = 8; i < 10; i++) R5495[i] = (char *(*)()) F852_6768;}
	R5495[10] = (char *(*)()) F854_6768_5495_9;
	R5495[11] = (char *(*)()) F855_6768_5495_9;
	R5495[12] = (char *(*)()) F856_6768_5495_9;
	R5495[13] = (char *(*)()) F858_6768_5495_9;
	R5495[26] = (char *(*)()) F878_6888_5495_9;
	R5495[27] = (char *(*)()) F879_6916_5495_9;
	R5495[28] = (char *(*)()) F880_6916_5495_9;
	R5495[29] = (char *(*)()) F881_6916_5495_9;
	R5495[30] = (char *(*)()) F882_6916_5495_9;
	R5495[31] = (char *(*)()) F883_6916_5495_9;
	R5495[32] = (char *(*)()) F884_6916_5495_9;
	R5495[33] = (char *(*)()) F885_6916_5495_9;
	R5495[34] = (char *(*)()) F886_6916_5495_9;
	R5495[35] = (char *(*)()) F887_6916_5495_9;
	R5495[36] = (char *(*)()) F888_6916_5495_9;
	R5495[37] = (char *(*)()) F889_6916_5495_9;
	R5495[38] = (char *(*)()) F890_6916_5495_9;
	R5495[92] = (char *(*)()) F896_6969_5495_9;
	R5495[93] = (char *(*)()) F898_6969_5495_9;
	R5495[94] = (char *(*)()) F896_6969_5495_9;
	R5495[95] = (char *(*)()) F898_6969_5495_9;
	R5495[96] = (char *(*)()) F896_6969_5495_9;
	R5495[97] = (char *(*)()) F949_7110_5495_9;
	R5495[98] = (char *(*)()) F950_7110_5495_9;
	R5495[99] = (char *(*)()) F951_7110_5495_9;
	R5495[100] = (char *(*)()) F952_7110_5495_9;
	R5495[101] = (char *(*)()) F953_7110_5495_9;
	R5495[102] = (char *(*)()) F954_7110_5495_9;
	R5495[103] = (char *(*)()) F955_7110_5495_9;
	R5495[104] = (char *(*)()) F956_7110_5495_9;
	R5495[105] = (char *(*)()) F957_7110_5495_9;
	R5495[106] = (char *(*)()) F958_7110_5495_9;
	R5495[107] = (char *(*)()) F959_7110_5495_9;
	R5495[108] = (char *(*)()) F960_7110_5495_9;
	{long i; for (i = 109; i < 112; i++) R5495[i] = (char *(*)()) F949_7110_5495_9;}
	R5495[112] = (char *(*)()) F951_7110_5495_9;
	R5495[113] = (char *(*)()) F949_7110_5495_9;
	R5495[231] = (char *(*)()) F1083_8395_5495_9;
	R5495[235] = (char *(*)()) F1087_8563_5495_9;
	R5495[499] = (char *(*)()) F1351_13265_5495_9;
}
static void F853_6768_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F853_6768(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F854_6768_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F854_6768(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F855_6768_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F855_6768(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F856_6768_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F856_6768(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F857_6768_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F857_6768(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F858_6768_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F858_6768(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F859_6768_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F859_6768(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F878_6888_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F878_6888(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F879_6916_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F879_6916(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F880_6916_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F880_6916(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F881_6916_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F881_6916(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F882_6916_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F882_6916(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F883_6916_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F883_6916(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F884_6916_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F884_6916(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F885_6916_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F885_6916(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F886_6916_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F886_6916(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F887_6916_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F887_6916(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F888_6916_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F888_6916(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F889_6916_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F889_6916(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F890_6916_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F890_6916(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F896_6969_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F896_6969(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F898_6969_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F898_6969(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F949_7110_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F949_7110(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F950_7110_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F950_7110(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F951_7110_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F951_7110(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F952_7110_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F952_7110(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F953_7110_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F953_7110(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F954_7110_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F954_7110(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F955_7110_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F955_7110(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F956_7110_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F956_7110(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F957_7110_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F957_7110(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F958_7110_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F958_7110(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F959_7110_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F959_7110(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F960_7110_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F960_7110(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1083_8395_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1083_8395(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1087_8563_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1087_8563(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1351_13265_5495_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1351_13265(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y5496_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype32[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype33[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype34[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype35[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype36[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype37[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype38[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype39[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype40[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype41[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype42[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype43[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype44[] = {0xFF01,1082,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype45[] = {0xFF01,1077,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype46[] = {0xFF01,1077,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype47[] = {0xFF01,1077,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype48[] = {0xFF01,1077,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype49[] = {0xFF01,1077,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype50[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype51[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype52[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype53[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype54[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype55[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype56[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype57[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype58[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype59[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype60[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype61[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype62[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype63[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype64[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype65[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype66[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype67[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype68[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype69[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype70[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype71[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype72[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype73[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype74[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype75[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype76[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype77[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype78[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype79[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype80[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype81[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype82[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype83[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype84[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype85[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype86[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype87[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype88[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype89[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype90[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype91[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype92[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype93[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype94[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype95[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype96[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype97[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype98[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype99[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype100[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype101[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype102[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype103[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype104[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype105[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype106[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype107[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype108[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype109[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype110[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype111[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype112[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype113[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype114[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype115[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype116[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype117[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype118[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype119[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype120[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype121[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype122[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype123[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype124[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype125[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype126[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype127[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype128[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype129[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype130[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype131[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype132[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype133[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype134[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype135[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype136[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype137[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype138[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype139[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype140[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype141[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype142[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype143[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype144[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype145[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype146[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype147[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype148[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype149[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype150[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype151[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype152[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype153[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5496_pgtype154[] = {1219,0xFFFF};
EIF_TYPE_INDEX *Y5496_gen_type [673];
EIF_TYPE_INDEX Y5496 [673];
void Y5496_init (void)
{
	egc_routines_types [5496] = Y5496;
	egc_routines_gen_types [5496] = Y5496_gen_type;
	egc_routines_offset [5496] = 679;
	Y5496_gen_type [0] = Y5496_pgtype0;
	Y5496_gen_type [1] = Y5496_pgtype1;
	Y5496_gen_type [2] = Y5496_pgtype2;
	Y5496_gen_type [3] = Y5496_pgtype3;
	Y5496_gen_type [4] = Y5496_pgtype4;
	Y5496_gen_type [5] = Y5496_pgtype5;
	Y5496_gen_type [6] = Y5496_pgtype6;
	Y5496_gen_type [7] = Y5496_pgtype7;
	Y5496_gen_type [8] = Y5496_pgtype8;
	Y5496_gen_type [9] = Y5496_pgtype9;
	Y5496_gen_type [10] = Y5496_pgtype10;
	Y5496_gen_type [11] = Y5496_pgtype11;
	Y5496_gen_type [12] = Y5496_pgtype12;
	Y5496_gen_type [13] = Y5496_pgtype13;
	Y5496_gen_type [14] = Y5496_pgtype14;
	Y5496_gen_type [15] = Y5496_pgtype15;
	Y5496_gen_type [16] = Y5496_pgtype16;
	Y5496_gen_type [17] = Y5496_pgtype17;
	Y5496_gen_type [18] = Y5496_pgtype18;
	Y5496_gen_type [19] = Y5496_pgtype19;
	Y5496_gen_type [20] = Y5496_pgtype20;
	Y5496_gen_type [21] = Y5496_pgtype21;
	Y5496_gen_type [22] = Y5496_pgtype22;
	Y5496_gen_type [23] = Y5496_pgtype23;
	Y5496_gen_type [24] = Y5496_pgtype24;
	Y5496_gen_type [25] = Y5496_pgtype25;
	Y5496_gen_type [26] = Y5496_pgtype26;
	Y5496_gen_type [27] = Y5496_pgtype27;
	Y5496_gen_type [28] = Y5496_pgtype28;
	Y5496_gen_type [29] = Y5496_pgtype29;
	Y5496_gen_type [30] = Y5496_pgtype30;
	Y5496_gen_type [31] = Y5496_pgtype31;
	Y5496_gen_type [32] = Y5496_pgtype32;
	Y5496_gen_type [33] = Y5496_pgtype33;
	Y5496_gen_type [34] = Y5496_pgtype34;
	Y5496_gen_type [35] = Y5496_pgtype35;
	Y5496_gen_type [172] = Y5496_pgtype36;
	Y5496_gen_type [173] = Y5496_pgtype37;
	Y5496_gen_type [174] = Y5496_pgtype38;
	Y5496_gen_type [175] = Y5496_pgtype39;
	Y5496_gen_type [176] = Y5496_pgtype40;
	Y5496_gen_type [177] = Y5496_pgtype41;
	Y5496_gen_type [178] = Y5496_pgtype42;
	Y5496_gen_type [179] = Y5496_pgtype43;
	Y5496_gen_type [180] = Y5496_pgtype44;
	Y5496_gen_type [181] = Y5496_pgtype45;
	Y5496_gen_type [182] = Y5496_pgtype46;
	Y5496_gen_type [183] = Y5496_pgtype47;
	Y5496_gen_type [184] = Y5496_pgtype48;
	Y5496_gen_type [185] = Y5496_pgtype49;
	Y5496_gen_type [186] = Y5496_pgtype50;
	Y5496_gen_type [187] = Y5496_pgtype51;
	Y5496_gen_type [188] = Y5496_pgtype52;
	Y5496_gen_type [189] = Y5496_pgtype53;
	Y5496_gen_type [190] = Y5496_pgtype54;
	Y5496_gen_type [191] = Y5496_pgtype55;
	Y5496_gen_type [192] = Y5496_pgtype56;
	Y5496_gen_type [193] = Y5496_pgtype57;
	Y5496_gen_type [194] = Y5496_pgtype58;
	Y5496_gen_type [195] = Y5496_pgtype59;
	Y5496_gen_type [196] = Y5496_pgtype60;
	Y5496_gen_type [197] = Y5496_pgtype61;
	Y5496_gen_type [198] = Y5496_pgtype62;
	Y5496_gen_type [199] = Y5496_pgtype63;
	Y5496_gen_type [200] = Y5496_pgtype64;
	Y5496_gen_type [201] = Y5496_pgtype65;
	Y5496_gen_type [202] = Y5496_pgtype66;
	Y5496_gen_type [203] = Y5496_pgtype67;
	Y5496_gen_type [204] = Y5496_pgtype68;
	Y5496_gen_type [205] = Y5496_pgtype69;
	Y5496_gen_type [206] = Y5496_pgtype70;
	Y5496_gen_type [207] = Y5496_pgtype71;
	Y5496_gen_type [208] = Y5496_pgtype72;
	Y5496_gen_type [209] = Y5496_pgtype73;
	Y5496_gen_type [210] = Y5496_pgtype74;
	Y5496_gen_type [211] = Y5496_pgtype75;
	Y5496_gen_type [212] = Y5496_pgtype76;
	Y5496_gen_type [213] = Y5496_pgtype77;
	Y5496_gen_type [214] = Y5496_pgtype78;
	Y5496_gen_type [215] = Y5496_pgtype79;
	Y5496_gen_type [216] = Y5496_pgtype80;
	Y5496_gen_type [217] = Y5496_pgtype81;
	Y5496_gen_type [218] = Y5496_pgtype82;
	Y5496_gen_type [219] = Y5496_pgtype83;
	Y5496_gen_type [220] = Y5496_pgtype84;
	Y5496_gen_type [221] = Y5496_pgtype85;
	Y5496_gen_type [222] = Y5496_pgtype86;
	Y5496_gen_type [223] = Y5496_pgtype87;
	Y5496_gen_type [224] = Y5496_pgtype88;
	Y5496_gen_type [225] = Y5496_pgtype89;
	Y5496_gen_type [226] = Y5496_pgtype90;
	Y5496_gen_type [227] = Y5496_pgtype91;
	Y5496_gen_type [228] = Y5496_pgtype92;
	Y5496_gen_type [229] = Y5496_pgtype93;
	Y5496_gen_type [230] = Y5496_pgtype94;
	Y5496_gen_type [231] = Y5496_pgtype95;
	Y5496_gen_type [232] = Y5496_pgtype96;
	Y5496_gen_type [233] = Y5496_pgtype97;
	Y5496_gen_type [234] = Y5496_pgtype98;
	Y5496_gen_type [235] = Y5496_pgtype99;
	Y5496_gen_type [236] = Y5496_pgtype100;
	Y5496_gen_type [237] = Y5496_pgtype101;
	Y5496_gen_type [238] = Y5496_pgtype102;
	Y5496_gen_type [239] = Y5496_pgtype103;
	Y5496_gen_type [240] = Y5496_pgtype104;
	Y5496_gen_type [241] = Y5496_pgtype105;
	Y5496_gen_type [242] = Y5496_pgtype106;
	Y5496_gen_type [243] = Y5496_pgtype107;
	Y5496_gen_type [244] = Y5496_pgtype108;
	Y5496_gen_type [245] = Y5496_pgtype109;
	Y5496_gen_type [246] = Y5496_pgtype110;
	Y5496_gen_type [247] = Y5496_pgtype111;
	Y5496_gen_type [248] = Y5496_pgtype112;
	Y5496_gen_type [249] = Y5496_pgtype113;
	Y5496_gen_type [250] = Y5496_pgtype114;
	Y5496_gen_type [251] = Y5496_pgtype115;
	Y5496_gen_type [252] = Y5496_pgtype116;
	Y5496_gen_type [253] = Y5496_pgtype117;
	Y5496_gen_type [254] = Y5496_pgtype118;
	Y5496_gen_type [255] = Y5496_pgtype119;
	Y5496_gen_type [256] = Y5496_pgtype120;
	Y5496_gen_type [257] = Y5496_pgtype121;
	Y5496_gen_type [258] = Y5496_pgtype122;
	Y5496_gen_type [259] = Y5496_pgtype123;
	Y5496_gen_type [260] = Y5496_pgtype124;
	Y5496_gen_type [261] = Y5496_pgtype125;
	Y5496_gen_type [262] = Y5496_pgtype126;
	Y5496_gen_type [263] = Y5496_pgtype127;
	Y5496_gen_type [264] = Y5496_pgtype128;
	Y5496_gen_type [265] = Y5496_pgtype129;
	Y5496_gen_type [266] = Y5496_pgtype130;
	Y5496_gen_type [267] = Y5496_pgtype131;
	Y5496_gen_type [268] = Y5496_pgtype132;
	Y5496_gen_type [269] = Y5496_pgtype133;
	Y5496_gen_type [270] = Y5496_pgtype134;
	Y5496_gen_type [271] = Y5496_pgtype135;
	Y5496_gen_type [272] = Y5496_pgtype136;
	Y5496_gen_type [273] = Y5496_pgtype137;
	Y5496_gen_type [274] = Y5496_pgtype138;
	Y5496_gen_type [275] = Y5496_pgtype139;
	Y5496_gen_type [276] = Y5496_pgtype140;
	Y5496_gen_type [277] = Y5496_pgtype141;
	Y5496_gen_type [278] = Y5496_pgtype142;
	Y5496_gen_type [279] = Y5496_pgtype143;
	Y5496_gen_type [280] = Y5496_pgtype144;
	Y5496_gen_type [281] = Y5496_pgtype145;
	Y5496_gen_type [282] = Y5496_pgtype146;
	Y5496_gen_type [283] = Y5496_pgtype147;
	Y5496_gen_type [284] = Y5496_pgtype148;
	Y5496_gen_type [285] = Y5496_pgtype149;
	Y5496_gen_type [403] = Y5496_pgtype150;
	Y5496_gen_type [404] = Y5496_pgtype151;
	Y5496_gen_type [407] = Y5496_pgtype152;
	Y5496_gen_type [671] = Y5496_pgtype153;
	Y5496_gen_type [672] = Y5496_pgtype154;
	Y5496[180] = 1082;
	{long i; for (i = 181; i < 186; i++) Y5496[i] = 1077;};
	{long i; for (i = 186; i < 286; i++) Y5496[i] = 1219;};
	{long i; for (i = 403; i < 405; i++) Y5496[i] = 1219;};
	Y5496[407] = 1219;
	{long i; for (i = 671; i < 673; i++) Y5496[i] = 1219;};
}

char *(*R5498[502])();
void R5498_init () {
	{long i; for (i = 0; i < 2; i++) R5498[i] = (char *(*)()) F759_6241_5498_1;}
	R5498[41] = (char *(*)()) F801_6311;
	{long i; for (i = 69; i < 71; i++) R5498[i] = (char *(*)()) F828_6367_5498_1;}
	R5498[184] = (char *(*)()) F944_7003;
	R5498[185] = (char *(*)()) F945_7003_5498_1;
	R5498[186] = (char *(*)()) F946_7048;
	R5498[187] = (char *(*)()) F947_7048_5498_1;
	R5498[188] = (char *(*)()) F944_7003;
	R5498[189] = (char *(*)()) F949_7076;
	R5498[190] = (char *(*)()) F950_7076_5498_1;
	R5498[191] = (char *(*)()) F951_7076_5498_1;
	R5498[192] = (char *(*)()) F952_7076_5498_1;
	R5498[193] = (char *(*)()) F953_7076_5498_1;
	R5498[194] = (char *(*)()) F954_7076_5498_1;
	R5498[195] = (char *(*)()) F955_7076_5498_1;
	R5498[196] = (char *(*)()) F956_7076_5498_1;
	R5498[197] = (char *(*)()) F957_7076_5498_1;
	R5498[198] = (char *(*)()) F958_7076_5498_1;
	R5498[199] = (char *(*)()) F959_7076_5498_1;
	R5498[200] = (char *(*)()) F960_7076_5498_1;
	{long i; for (i = 201; i < 204; i++) R5498[i] = (char *(*)()) F949_7076;}
	R5498[204] = (char *(*)()) F951_7076_5498_1;
	R5498[205] = (char *(*)()) F949_7076;
	R5498[501] = (char *(*)()) F828_6367_5498_1;
}
static EIF_REFERENCE F759_6241_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F759_6241(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F828_6367_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F828_6367(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F945_7003_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F945_7003(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F947_7048_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F947_7048(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F950_7076_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F950_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_7076_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F951_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_7076_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F952_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7076_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F953_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7076_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F954_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7076_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F955_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7076_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F956_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1234, 0x00).id, 1234, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7076_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F957_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F958_7076_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F958_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7076_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F959_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7076_5498_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F960_7076(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y5498_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype109[] = {0xFF01,1300,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5498_pgtype112[] = {0xFF01,964,0xFFFF};
EIF_TYPE_INDEX *Y5498_gen_type [604];
EIF_TYPE_INDEX Y5498 [604];
void Y5498_init (void)
{
	egc_routines_types [5498] = Y5498;
	egc_routines_gen_types [5498] = Y5498_gen_type;
	egc_routines_offset [5498] = 715;
	Y5498_gen_type [0] = Y5498_pgtype0;
	Y5498_gen_type [1] = Y5498_pgtype1;
	Y5498_gen_type [2] = Y5498_pgtype2;
	Y5498_gen_type [3] = Y5498_pgtype3;
	Y5498_gen_type [4] = Y5498_pgtype4;
	Y5498_gen_type [5] = Y5498_pgtype5;
	Y5498_gen_type [6] = Y5498_pgtype6;
	Y5498_gen_type [7] = Y5498_pgtype7;
	Y5498_gen_type [8] = Y5498_pgtype8;
	Y5498_gen_type [9] = Y5498_pgtype9;
	Y5498_gen_type [10] = Y5498_pgtype10;
	Y5498_gen_type [11] = Y5498_pgtype11;
	Y5498_gen_type [12] = Y5498_pgtype12;
	Y5498_gen_type [13] = Y5498_pgtype13;
	Y5498_gen_type [14] = Y5498_pgtype14;
	Y5498_gen_type [15] = Y5498_pgtype15;
	Y5498_gen_type [16] = Y5498_pgtype16;
	Y5498_gen_type [17] = Y5498_pgtype17;
	Y5498_gen_type [18] = Y5498_pgtype18;
	Y5498_gen_type [19] = Y5498_pgtype19;
	Y5498_gen_type [20] = Y5498_pgtype20;
	Y5498_gen_type [21] = Y5498_pgtype21;
	Y5498_gen_type [22] = Y5498_pgtype22;
	Y5498_gen_type [23] = Y5498_pgtype23;
	Y5498_gen_type [43] = Y5498_pgtype24;
	Y5498_gen_type [82] = Y5498_pgtype25;
	Y5498_gen_type [83] = Y5498_pgtype26;
	Y5498_gen_type [84] = Y5498_pgtype27;
	Y5498_gen_type [85] = Y5498_pgtype28;
	Y5498_gen_type [86] = Y5498_pgtype29;
	Y5498_gen_type [87] = Y5498_pgtype30;
	Y5498_gen_type [88] = Y5498_pgtype31;
	Y5498_gen_type [89] = Y5498_pgtype32;
	Y5498_gen_type [90] = Y5498_pgtype33;
	Y5498_gen_type [91] = Y5498_pgtype34;
	Y5498_gen_type [92] = Y5498_pgtype35;
	Y5498_gen_type [93] = Y5498_pgtype36;
	Y5498_gen_type [94] = Y5498_pgtype37;
	Y5498_gen_type [95] = Y5498_pgtype38;
	Y5498_gen_type [96] = Y5498_pgtype39;
	Y5498_gen_type [97] = Y5498_pgtype40;
	Y5498_gen_type [98] = Y5498_pgtype41;
	Y5498_gen_type [99] = Y5498_pgtype42;
	Y5498_gen_type [180] = Y5498_pgtype43;
	Y5498_gen_type [181] = Y5498_pgtype44;
	Y5498_gen_type [182] = Y5498_pgtype45;
	Y5498_gen_type [183] = Y5498_pgtype46;
	Y5498_gen_type [184] = Y5498_pgtype47;
	Y5498_gen_type [185] = Y5498_pgtype48;
	Y5498_gen_type [186] = Y5498_pgtype49;
	Y5498_gen_type [187] = Y5498_pgtype50;
	Y5498_gen_type [188] = Y5498_pgtype51;
	Y5498_gen_type [189] = Y5498_pgtype52;
	Y5498_gen_type [190] = Y5498_pgtype53;
	Y5498_gen_type [191] = Y5498_pgtype54;
	Y5498_gen_type [192] = Y5498_pgtype55;
	Y5498_gen_type [193] = Y5498_pgtype56;
	Y5498_gen_type [194] = Y5498_pgtype57;
	Y5498_gen_type [195] = Y5498_pgtype58;
	Y5498_gen_type [196] = Y5498_pgtype59;
	Y5498_gen_type [197] = Y5498_pgtype60;
	Y5498_gen_type [198] = Y5498_pgtype61;
	Y5498_gen_type [199] = Y5498_pgtype62;
	Y5498_gen_type [200] = Y5498_pgtype63;
	Y5498_gen_type [201] = Y5498_pgtype64;
	Y5498_gen_type [202] = Y5498_pgtype65;
	Y5498_gen_type [203] = Y5498_pgtype66;
	Y5498_gen_type [204] = Y5498_pgtype67;
	Y5498_gen_type [205] = Y5498_pgtype68;
	Y5498_gen_type [206] = Y5498_pgtype69;
	Y5498_gen_type [207] = Y5498_pgtype70;
	Y5498_gen_type [208] = Y5498_pgtype71;
	Y5498_gen_type [209] = Y5498_pgtype72;
	Y5498_gen_type [210] = Y5498_pgtype73;
	Y5498_gen_type [211] = Y5498_pgtype74;
	Y5498_gen_type [212] = Y5498_pgtype75;
	Y5498_gen_type [213] = Y5498_pgtype76;
	Y5498_gen_type [214] = Y5498_pgtype77;
	Y5498_gen_type [215] = Y5498_pgtype78;
	Y5498_gen_type [216] = Y5498_pgtype79;
	Y5498_gen_type [217] = Y5498_pgtype80;
	Y5498_gen_type [218] = Y5498_pgtype81;
	Y5498_gen_type [219] = Y5498_pgtype82;
	Y5498_gen_type [220] = Y5498_pgtype83;
	Y5498_gen_type [221] = Y5498_pgtype84;
	Y5498_gen_type [222] = Y5498_pgtype85;
	Y5498_gen_type [223] = Y5498_pgtype86;
	Y5498_gen_type [224] = Y5498_pgtype87;
	Y5498_gen_type [225] = Y5498_pgtype88;
	Y5498_gen_type [226] = Y5498_pgtype89;
	Y5498_gen_type [227] = Y5498_pgtype90;
	Y5498_gen_type [228] = Y5498_pgtype91;
	Y5498_gen_type [229] = Y5498_pgtype92;
	Y5498_gen_type [230] = Y5498_pgtype93;
	Y5498_gen_type [231] = Y5498_pgtype94;
	Y5498_gen_type [232] = Y5498_pgtype95;
	Y5498_gen_type [233] = Y5498_pgtype96;
	Y5498_gen_type [234] = Y5498_pgtype97;
	Y5498_gen_type [235] = Y5498_pgtype98;
	Y5498_gen_type [236] = Y5498_pgtype99;
	Y5498_gen_type [237] = Y5498_pgtype100;
	Y5498_gen_type [238] = Y5498_pgtype101;
	Y5498_gen_type [239] = Y5498_pgtype102;
	Y5498_gen_type [240] = Y5498_pgtype103;
	Y5498_gen_type [241] = Y5498_pgtype104;
	Y5498_gen_type [242] = Y5498_pgtype105;
	Y5498_gen_type [243] = Y5498_pgtype106;
	Y5498_gen_type [244] = Y5498_pgtype107;
	Y5498_gen_type [245] = Y5498_pgtype108;
	Y5498_gen_type [246] = Y5498_pgtype109;
	Y5498_gen_type [247] = Y5498_pgtype110;
	Y5498_gen_type [248] = Y5498_pgtype111;
	Y5498_gen_type [249] = Y5498_pgtype112;
	{long i; for (i = 44; i < 46; i++) Y5498[i] = 1219;};
	{long i; for (i = 112; i < 115; i++) Y5498[i] = 1034;};
	Y5498[246] = 1300;
	Y5498[249] = 964;
	Y5498[545] = 1034;
	{long i; for (i = 595; i < 598; i++) Y5498[i] = 1034;};
	{long i; for (i = 599; i < 604; i++) Y5498[i] = 1034;};
}

char *(*R5502[22])();
void R5502_init () {
	R5502[0] = (char *(*)()) F944_7031;
	R5502[1] = (char *(*)()) F945_7031_5502_4;
	R5502[2] = (char *(*)()) F944_7031;
	R5502[3] = (char *(*)()) F945_7031_5502_4;
	R5502[4] = (char *(*)()) F944_7031;
	R5502[5] = (char *(*)()) F949_7115;
	R5502[6] = (char *(*)()) F950_7115_5502_4;
	R5502[7] = (char *(*)()) F951_7115_5502_4;
	R5502[8] = (char *(*)()) F952_7115_5502_4;
	R5502[9] = (char *(*)()) F953_7115_5502_4;
	R5502[10] = (char *(*)()) F954_7115_5502_4;
	R5502[11] = (char *(*)()) F955_7115_5502_4;
	R5502[12] = (char *(*)()) F956_7115_5502_4;
	R5502[13] = (char *(*)()) F957_7115_5502_4;
	R5502[14] = (char *(*)()) F958_7115_5502_4;
	R5502[15] = (char *(*)()) F959_7115_5502_4;
	R5502[16] = (char *(*)()) F960_7115_5502_4;
	{long i; for (i = 17; i < 20; i++) R5502[i] = (char *(*)()) F949_7115;}
	R5502[20] = (char *(*)()) F951_7115_5502_4;
	R5502[21] = (char *(*)()) F949_7115;
}
static void F945_7031_5502_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F945_7031(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F950_7115_5502_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F950_7115(Current, *(EIF_BOOLEAN *)arg1);
}
static void F951_7115_5502_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F951_7115(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F952_7115_5502_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F952_7115(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F953_7115_5502_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F953_7115(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F954_7115_5502_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7115(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F955_7115_5502_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F955_7115(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F956_7115_5502_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F956_7115(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F957_7115_5502_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F957_7115(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F958_7115_5502_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F958_7115(Current, *(EIF_POINTER *)arg1);
}
static void F959_7115_5502_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F959_7115(Current, *(EIF_REAL_32 *)arg1);
}
static void F960_7115_5502_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F960_7115(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R5503[165])();
void R5503_init () {
	R5503[0] = (char *(*)()) F801_6328;
	R5503[143] = (char *(*)()) F944_7034;
	R5503[144] = (char *(*)()) F945_7034;
	R5503[145] = (char *(*)()) F946_7052;
	R5503[146] = (char *(*)()) F947_7052;
	R5503[147] = (char *(*)()) F944_7034;
	R5503[148] = (char *(*)()) F949_7125;
	R5503[149] = (char *(*)()) F950_7125;
	R5503[150] = (char *(*)()) F951_7125;
	R5503[151] = (char *(*)()) F952_7125;
	R5503[152] = (char *(*)()) F953_7125;
	R5503[153] = (char *(*)()) F954_7125;
	R5503[154] = (char *(*)()) F955_7125;
	R5503[155] = (char *(*)()) F956_7125;
	R5503[156] = (char *(*)()) F957_7125;
	R5503[157] = (char *(*)()) F958_7125;
	R5503[158] = (char *(*)()) F959_7125;
	R5503[159] = (char *(*)()) F960_7125;
	{long i; for (i = 160; i < 162; i++) R5503[i] = (char *(*)()) F949_7125;}
	R5503[162] = (char *(*)()) F963_7153;
	R5503[163] = (char *(*)()) F964_7153;
	R5503[164] = (char *(*)()) F949_7125;
}

char *(*R5504[22])();
void R5504_init () {
	R5504[0] = (char *(*)()) F944_7007;
	R5504[1] = (char *(*)()) F945_7007;
	R5504[2] = (char *(*)()) F944_7007;
	R5504[3] = (char *(*)()) F945_7007;
	R5504[4] = (char *(*)()) F944_7007;
	R5504[5] = (char *(*)()) F949_7082;
	R5504[6] = (char *(*)()) F950_7082;
	R5504[7] = (char *(*)()) F951_7082;
	R5504[8] = (char *(*)()) F952_7082;
	R5504[9] = (char *(*)()) F953_7082;
	R5504[10] = (char *(*)()) F954_7082;
	R5504[11] = (char *(*)()) F955_7082;
	R5504[12] = (char *(*)()) F956_7082;
	R5504[13] = (char *(*)()) F957_7082;
	R5504[14] = (char *(*)()) F958_7082;
	R5504[15] = (char *(*)()) F959_7082;
	R5504[16] = (char *(*)()) F960_7082;
	{long i; for (i = 17; i < 20; i++) R5504[i] = (char *(*)()) F949_7082;}
	R5504[20] = (char *(*)()) F951_7082;
	R5504[21] = (char *(*)()) F949_7082;
}

static EIF_TYPE_INDEX Y5504_pgtype0[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype1[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype2[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype3[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype4[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype5[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype6[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype7[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype8[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype9[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype10[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype11[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype12[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype13[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype14[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype15[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype16[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype17[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype18[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype19[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype20[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype21[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype22[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype23[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype24[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype25[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype26[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype27[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype28[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype29[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype30[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype31[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype32[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype33[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype34[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype35[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype36[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype37[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype38[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype39[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype40[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype41[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype42[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype43[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype44[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype45[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype46[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype47[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype48[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype49[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype50[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype51[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype52[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype53[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype54[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype55[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype56[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype57[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype58[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype59[] = {0xFF01,320,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype60[] = {0xFF01,322,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype61[] = {0xFF01,323,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype62[] = {0xFF01,322,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype63[] = {0xFF01,323,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype64[] = {0xFF01,322,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype65[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype66[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype67[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype68[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype69[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype70[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype71[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype72[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype73[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype74[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype75[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype76[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype77[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype78[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype79[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype80[] = {0xFF01,324,0xFFFF};
static EIF_TYPE_INDEX Y5504_pgtype81[] = {0xFF01,324,0xFFFF};
EIF_TYPE_INDEX *Y5504_gen_type [238];
EIF_TYPE_INDEX Y5504 [238];
void Y5504_init (void)
{
	egc_routines_types [5504] = Y5504;
	egc_routines_gen_types [5504] = Y5504_gen_type;
	egc_routines_offset [5504] = 727;
	Y5504_gen_type [0] = Y5504_pgtype0;
	Y5504_gen_type [1] = Y5504_pgtype1;
	Y5504_gen_type [2] = Y5504_pgtype2;
	Y5504_gen_type [3] = Y5504_pgtype3;
	Y5504_gen_type [4] = Y5504_pgtype4;
	Y5504_gen_type [5] = Y5504_pgtype5;
	Y5504_gen_type [6] = Y5504_pgtype6;
	Y5504_gen_type [7] = Y5504_pgtype7;
	Y5504_gen_type [8] = Y5504_pgtype8;
	Y5504_gen_type [9] = Y5504_pgtype9;
	Y5504_gen_type [10] = Y5504_pgtype10;
	Y5504_gen_type [11] = Y5504_pgtype11;
	Y5504_gen_type [168] = Y5504_pgtype12;
	Y5504_gen_type [169] = Y5504_pgtype13;
	Y5504_gen_type [170] = Y5504_pgtype14;
	Y5504_gen_type [171] = Y5504_pgtype15;
	Y5504_gen_type [172] = Y5504_pgtype16;
	Y5504_gen_type [173] = Y5504_pgtype17;
	Y5504_gen_type [174] = Y5504_pgtype18;
	Y5504_gen_type [175] = Y5504_pgtype19;
	Y5504_gen_type [176] = Y5504_pgtype20;
	Y5504_gen_type [177] = Y5504_pgtype21;
	Y5504_gen_type [178] = Y5504_pgtype22;
	Y5504_gen_type [179] = Y5504_pgtype23;
	Y5504_gen_type [180] = Y5504_pgtype24;
	Y5504_gen_type [181] = Y5504_pgtype25;
	Y5504_gen_type [182] = Y5504_pgtype26;
	Y5504_gen_type [183] = Y5504_pgtype27;
	Y5504_gen_type [184] = Y5504_pgtype28;
	Y5504_gen_type [185] = Y5504_pgtype29;
	Y5504_gen_type [186] = Y5504_pgtype30;
	Y5504_gen_type [187] = Y5504_pgtype31;
	Y5504_gen_type [188] = Y5504_pgtype32;
	Y5504_gen_type [189] = Y5504_pgtype33;
	Y5504_gen_type [190] = Y5504_pgtype34;
	Y5504_gen_type [191] = Y5504_pgtype35;
	Y5504_gen_type [192] = Y5504_pgtype36;
	Y5504_gen_type [193] = Y5504_pgtype37;
	Y5504_gen_type [194] = Y5504_pgtype38;
	Y5504_gen_type [195] = Y5504_pgtype39;
	Y5504_gen_type [196] = Y5504_pgtype40;
	Y5504_gen_type [197] = Y5504_pgtype41;
	Y5504_gen_type [198] = Y5504_pgtype42;
	Y5504_gen_type [199] = Y5504_pgtype43;
	Y5504_gen_type [200] = Y5504_pgtype44;
	Y5504_gen_type [201] = Y5504_pgtype45;
	Y5504_gen_type [202] = Y5504_pgtype46;
	Y5504_gen_type [203] = Y5504_pgtype47;
	Y5504_gen_type [204] = Y5504_pgtype48;
	Y5504_gen_type [205] = Y5504_pgtype49;
	Y5504_gen_type [206] = Y5504_pgtype50;
	Y5504_gen_type [207] = Y5504_pgtype51;
	Y5504_gen_type [208] = Y5504_pgtype52;
	Y5504_gen_type [209] = Y5504_pgtype53;
	Y5504_gen_type [210] = Y5504_pgtype54;
	Y5504_gen_type [211] = Y5504_pgtype55;
	Y5504_gen_type [212] = Y5504_pgtype56;
	Y5504_gen_type [213] = Y5504_pgtype57;
	Y5504_gen_type [214] = Y5504_pgtype58;
	Y5504_gen_type [215] = Y5504_pgtype59;
	Y5504_gen_type [216] = Y5504_pgtype60;
	Y5504_gen_type [217] = Y5504_pgtype61;
	Y5504_gen_type [218] = Y5504_pgtype62;
	Y5504_gen_type [219] = Y5504_pgtype63;
	Y5504_gen_type [220] = Y5504_pgtype64;
	Y5504_gen_type [221] = Y5504_pgtype65;
	Y5504_gen_type [222] = Y5504_pgtype66;
	Y5504_gen_type [223] = Y5504_pgtype67;
	Y5504_gen_type [224] = Y5504_pgtype68;
	Y5504_gen_type [225] = Y5504_pgtype69;
	Y5504_gen_type [226] = Y5504_pgtype70;
	Y5504_gen_type [227] = Y5504_pgtype71;
	Y5504_gen_type [228] = Y5504_pgtype72;
	Y5504_gen_type [229] = Y5504_pgtype73;
	Y5504_gen_type [230] = Y5504_pgtype74;
	Y5504_gen_type [231] = Y5504_pgtype75;
	Y5504_gen_type [232] = Y5504_pgtype76;
	Y5504_gen_type [233] = Y5504_pgtype77;
	Y5504_gen_type [234] = Y5504_pgtype78;
	Y5504_gen_type [235] = Y5504_pgtype79;
	Y5504_gen_type [236] = Y5504_pgtype80;
	Y5504_gen_type [237] = Y5504_pgtype81;
	{long i; for (i = 0; i < 12; i++) Y5504[i] = 320;};
	{long i; for (i = 168; i < 216; i++) Y5504[i] = 320;};
	Y5504[216] = 322;
	Y5504[217] = 323;
	Y5504[218] = 322;
	Y5504[219] = 323;
	Y5504[220] = 322;
	{long i; for (i = 221; i < 238; i++) Y5504[i] = 324;};
}

char *(*R5506[22])();
void R5506_init () {
	R5506[0] = (char *(*)()) F944_7026;
	R5506[1] = (char *(*)()) F945_7026;
	R5506[2] = (char *(*)()) F944_7026;
	R5506[3] = (char *(*)()) F945_7026;
	R5506[4] = (char *(*)()) F944_7026;
	R5506[5] = (char *(*)()) F949_7107;
	R5506[6] = (char *(*)()) F950_7107;
	R5506[7] = (char *(*)()) F951_7107;
	R5506[8] = (char *(*)()) F952_7107;
	R5506[9] = (char *(*)()) F953_7107;
	R5506[10] = (char *(*)()) F954_7107;
	R5506[11] = (char *(*)()) F955_7107;
	R5506[12] = (char *(*)()) F956_7107;
	R5506[13] = (char *(*)()) F957_7107;
	R5506[14] = (char *(*)()) F958_7107;
	R5506[15] = (char *(*)()) F959_7107;
	R5506[16] = (char *(*)()) F960_7107;
	{long i; for (i = 17; i < 20; i++) R5506[i] = (char *(*)()) F949_7107;}
	R5506[20] = (char *(*)()) F951_7107;
	R5506[21] = (char *(*)()) F949_7107;
}

char *(*R5532[2])();
void R5532_init () {
	R5532[0] = (char *(*)()) F760_6267;
	R5532[1] = (char *(*)()) F761_6286;
}

char *(*R5561[551])();
void R5561_init () {
	R5561[0] = (char *(*)()) F801_6315;
	{long i; for (i = 28; i < 30; i++) R5561[i] = (char *(*)()) F828_6385;}
	R5561[51] = (char *(*)()) F852_6739;
	R5561[52] = (char *(*)()) F853_6739;
	R5561[53] = (char *(*)()) F854_6739;
	R5561[54] = (char *(*)()) F855_6739;
	R5561[55] = (char *(*)()) F856_6739;
	R5561[56] = (char *(*)()) F857_6739;
	R5561[57] = (char *(*)()) F858_6739;
	R5561[58] = (char *(*)()) F859_6739;
	{long i; for (i = 59; i < 61; i++) R5561[i] = (char *(*)()) F852_6739;}
	R5561[61] = (char *(*)()) F854_6739;
	R5561[62] = (char *(*)()) F855_6739;
	R5561[63] = (char *(*)()) F856_6739;
	R5561[64] = (char *(*)()) F858_6739;
	R5561[77] = (char *(*)()) F878_6864;
	R5561[78] = (char *(*)()) F879_6904;
	R5561[79] = (char *(*)()) F880_6904;
	R5561[80] = (char *(*)()) F881_6904;
	R5561[81] = (char *(*)()) F882_6904;
	R5561[82] = (char *(*)()) F883_6904;
	R5561[83] = (char *(*)()) F884_6904;
	R5561[84] = (char *(*)()) F885_6904;
	R5561[85] = (char *(*)()) F886_6904;
	R5561[86] = (char *(*)()) F887_6904;
	R5561[87] = (char *(*)()) F888_6904;
	R5561[88] = (char *(*)()) F889_6904;
	R5561[89] = (char *(*)()) F890_6904;
	R5561[143] = (char *(*)()) F944_7010;
	R5561[144] = (char *(*)()) F945_7010;
	R5561[145] = (char *(*)()) F944_7010;
	R5561[146] = (char *(*)()) F945_7010;
	R5561[147] = (char *(*)()) F944_7010;
	R5561[148] = (char *(*)()) F949_7092;
	R5561[149] = (char *(*)()) F950_7092;
	R5561[150] = (char *(*)()) F951_7092;
	R5561[151] = (char *(*)()) F952_7092;
	R5561[152] = (char *(*)()) F953_7092;
	R5561[153] = (char *(*)()) F954_7092;
	R5561[154] = (char *(*)()) F955_7092;
	R5561[155] = (char *(*)()) F956_7092;
	R5561[156] = (char *(*)()) F957_7092;
	R5561[157] = (char *(*)()) F958_7092;
	R5561[158] = (char *(*)()) F959_7092;
	R5561[159] = (char *(*)()) F960_7092;
	{long i; for (i = 160; i < 163; i++) R5561[i] = (char *(*)()) F949_7092;}
	R5561[163] = (char *(*)()) F951_7092;
	R5561[164] = (char *(*)()) F949_7092;
	R5561[282] = (char *(*)()) F1081_8317;
	R5561[286] = (char *(*)()) F1085_8482;
	R5561[460] = (char *(*)()) F1261_10657;
	R5561[550] = (char *(*)()) F1351_13246;
}

char *(*R5562[551])();
void R5562_init () {
	R5562[0] = (char *(*)()) F801_6316;
	R5562[77] = (char *(*)()) F878_6863;
	R5562[78] = (char *(*)()) F879_6905;
	R5562[79] = (char *(*)()) F880_6905;
	R5562[80] = (char *(*)()) F881_6905;
	R5562[81] = (char *(*)()) F882_6905;
	R5562[82] = (char *(*)()) F883_6905;
	R5562[83] = (char *(*)()) F884_6905;
	R5562[84] = (char *(*)()) F885_6905;
	R5562[85] = (char *(*)()) F886_6905;
	R5562[86] = (char *(*)()) F887_6905;
	R5562[87] = (char *(*)()) F888_6905;
	R5562[88] = (char *(*)()) F889_6905;
	R5562[89] = (char *(*)()) F890_6905;
	R5562[148] = (char *(*)()) F949_7093;
	R5562[149] = (char *(*)()) F950_7093;
	R5562[150] = (char *(*)()) F951_7093;
	R5562[151] = (char *(*)()) F952_7093;
	R5562[152] = (char *(*)()) F953_7093;
	R5562[153] = (char *(*)()) F954_7093;
	R5562[154] = (char *(*)()) F955_7093;
	R5562[155] = (char *(*)()) F956_7093;
	R5562[156] = (char *(*)()) F957_7093;
	R5562[157] = (char *(*)()) F958_7093;
	R5562[158] = (char *(*)()) F959_7093;
	R5562[159] = (char *(*)()) F960_7093;
	{long i; for (i = 160; i < 163; i++) R5562[i] = (char *(*)()) F949_7093;}
	R5562[163] = (char *(*)()) F951_7093;
	R5562[164] = (char *(*)()) F949_7093;
	R5562[282] = (char *(*)()) F1081_8316;
	R5562[286] = (char *(*)()) F1085_8481;
	R5562[550] = (char *(*)()) F1351_13248;
}

char *(*R5566[551])();
void R5566_init () {
	R5566[0] = (char *(*)()) F786_6298;
	R5566[77] = (char *(*)()) F788_6298;
	R5566[78] = (char *(*)()) F786_6298;
	R5566[79] = (char *(*)()) F787_6298;
	R5566[80] = (char *(*)()) F788_6298;
	R5566[81] = (char *(*)()) F789_6298;
	R5566[82] = (char *(*)()) F790_6298;
	R5566[83] = (char *(*)()) F791_6298;
	R5566[84] = (char *(*)()) F792_6298;
	R5566[85] = (char *(*)()) F793_6298;
	R5566[86] = (char *(*)()) F794_6298;
	R5566[87] = (char *(*)()) F795_6298;
	R5566[88] = (char *(*)()) F796_6298;
	R5566[89] = (char *(*)()) F797_6298;
	R5566[148] = (char *(*)()) F786_6298;
	R5566[149] = (char *(*)()) F787_6298;
	R5566[150] = (char *(*)()) F788_6298;
	R5566[151] = (char *(*)()) F789_6298;
	R5566[152] = (char *(*)()) F790_6298;
	R5566[153] = (char *(*)()) F791_6298;
	R5566[154] = (char *(*)()) F792_6298;
	R5566[155] = (char *(*)()) F793_6298;
	R5566[156] = (char *(*)()) F794_6298;
	R5566[157] = (char *(*)()) F795_6298;
	R5566[158] = (char *(*)()) F796_6298;
	R5566[159] = (char *(*)()) F797_6298;
	{long i; for (i = 160; i < 163; i++) R5566[i] = (char *(*)()) F786_6298;}
	R5566[163] = (char *(*)()) F788_6298;
	R5566[164] = (char *(*)()) F786_6298;
	R5566[282] = (char *(*)()) F790_6298;
	R5566[286] = (char *(*)()) F792_6298;
	R5566[550] = (char *(*)()) F790_6298;
}

char *(*R5568[551])();
void R5568_init () {
	R5568[0] = (char *(*)()) F801_6338;
	R5568[77] = (char *(*)()) F878_6874;
	R5568[78] = (char *(*)()) F879_6935;
	R5568[79] = (char *(*)()) F880_6935;
	R5568[80] = (char *(*)()) F881_6935;
	R5568[81] = (char *(*)()) F882_6935;
	R5568[82] = (char *(*)()) F883_6935;
	R5568[83] = (char *(*)()) F884_6935;
	R5568[84] = (char *(*)()) F885_6935;
	R5568[85] = (char *(*)()) F886_6935;
	R5568[86] = (char *(*)()) F887_6935;
	R5568[87] = (char *(*)()) F888_6935;
	R5568[88] = (char *(*)()) F889_6935;
	R5568[89] = (char *(*)()) F890_6935;
	R5568[148] = (char *(*)()) F949_7119;
	R5568[149] = (char *(*)()) F950_7119;
	R5568[150] = (char *(*)()) F951_7119;
	R5568[151] = (char *(*)()) F952_7119;
	R5568[152] = (char *(*)()) F953_7119;
	R5568[153] = (char *(*)()) F954_7119;
	R5568[154] = (char *(*)()) F955_7119;
	R5568[155] = (char *(*)()) F956_7119;
	R5568[156] = (char *(*)()) F957_7119;
	R5568[157] = (char *(*)()) F958_7119;
	R5568[158] = (char *(*)()) F959_7119;
	R5568[159] = (char *(*)()) F960_7119;
	{long i; for (i = 160; i < 163; i++) R5568[i] = (char *(*)()) F949_7119;}
	R5568[163] = (char *(*)()) F951_7119;
	R5568[164] = (char *(*)()) F949_7119;
	R5568[282] = (char *(*)()) F1083_8441;
	R5568[286] = (char *(*)()) F1087_8609;
	R5568[550] = (char *(*)()) F1083_8441;
}

char *(*R5582[433])();
void R5582_init () {
	{long i; for (i = 0; i < 2; i++) R5582[i] = (char *(*)()) F808_6349_5582_4;}
	R5582[115] = (char *(*)()) F804_6349;
	R5582[116] = (char *(*)()) F806_6349_5582_4;
	R5582[117] = (char *(*)()) F946_7049;
	R5582[118] = (char *(*)()) F947_7049_5582_4;
	R5582[119] = (char *(*)()) F804_6349;
	R5582[120] = (char *(*)()) F949_7111;
	R5582[121] = (char *(*)()) F950_7111_5582_4;
	R5582[122] = (char *(*)()) F951_7111_5582_4;
	R5582[123] = (char *(*)()) F952_7111_5582_4;
	R5582[124] = (char *(*)()) F953_7111_5582_4;
	R5582[125] = (char *(*)()) F954_7111_5582_4;
	R5582[126] = (char *(*)()) F955_7111_5582_4;
	R5582[127] = (char *(*)()) F956_7111_5582_4;
	R5582[128] = (char *(*)()) F957_7111_5582_4;
	R5582[129] = (char *(*)()) F958_7111_5582_4;
	R5582[130] = (char *(*)()) F959_7111_5582_4;
	R5582[131] = (char *(*)()) F960_7111_5582_4;
	{long i; for (i = 132; i < 135; i++) R5582[i] = (char *(*)()) F949_7111;}
	R5582[135] = (char *(*)()) F951_7111_5582_4;
	R5582[136] = (char *(*)()) F949_7111;
	R5582[432] = (char *(*)()) F808_6349_5582_4;
}
static void F808_6349_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F808_6349(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F806_6349_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F806_6349(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F947_7049_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F947_7049(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F950_7111_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F950_7111(Current, *(EIF_BOOLEAN *)arg1);
}
static void F951_7111_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F951_7111(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F952_7111_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F952_7111(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F953_7111_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F953_7111(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F954_7111_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7111(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F955_7111_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F955_7111(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F956_7111_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F956_7111(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F957_7111_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F957_7111(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F958_7111_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F958_7111(Current, *(EIF_POINTER *)arg1);
}
static void F959_7111_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F959_7111(Current, *(EIF_REAL_32 *)arg1);
}
static void F960_7111_5582_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F960_7111(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R5583[22])();
void R5583_init () {
	R5583[0] = (char *(*)()) F896_6970;
	R5583[1] = (char *(*)()) F898_6970;
	R5583[2] = (char *(*)()) F798_6305;
	R5583[3] = (char *(*)()) F799_6305;
	R5583[4] = (char *(*)()) F896_6970;
	R5583[5] = (char *(*)()) F949_7118;
	R5583[6] = (char *(*)()) F950_7118;
	R5583[7] = (char *(*)()) F951_7118;
	R5583[8] = (char *(*)()) F952_7118;
	R5583[9] = (char *(*)()) F953_7118;
	R5583[10] = (char *(*)()) F954_7118;
	R5583[11] = (char *(*)()) F955_7118;
	R5583[12] = (char *(*)()) F956_7118;
	R5583[13] = (char *(*)()) F957_7118;
	R5583[14] = (char *(*)()) F958_7118;
	R5583[15] = (char *(*)()) F959_7118;
	R5583[16] = (char *(*)()) F960_7118;
	{long i; for (i = 17; i < 19; i++) R5583[i] = (char *(*)()) F949_7118;}
	R5583[19] = (char *(*)()) F798_6305;
	R5583[20] = (char *(*)()) F799_6305;
	R5583[21] = (char *(*)()) F949_7118;
}

char *(*R5585[433])();
void R5585_init () {
	R5585[0] = (char *(*)()) F828_6355;
	R5585[1] = (char *(*)()) F830_6636;
	R5585[432] = (char *(*)()) F830_6636;
}

char *(*R5610[433])();
void R5610_init () {
	{long i; for (i = 0; i < 2; i++) R5610[i] = (char *(*)()) F828_6389;}
	R5610[432] = (char *(*)()) F1261_10655;
}

char *(*R5679[433])();
void R5679_init () {
	R5679[0] = (char *(*)()) F829_6630;
	R5679[1] = (char *(*)()) F828_6513;
	R5679[432] = (char *(*)()) F828_6513;
}

char *(*R5680[433])();
void R5680_init () {
	{long i; for (i = 0; i < 2; i++) R5680[i] = (char *(*)()) F828_6514;}
	R5680[432] = (char *(*)()) F1261_10711;
}

char *(*R5763[432])();
void R5763_init () {
	R5763[0] = (char *(*)()) F830_6682;
	R5763[431] = (char *(*)()) F1261_10653;
}

char *(*R5769[432])();
void R5769_init () {
	R5769[0] = (char *(*)()) F830_6688;
	R5769[431] = (char *(*)()) F1261_10691;
}

char *(*R5773[432])();
void R5773_init () {
	R5773[0] = (char *(*)()) F830_6692;
	R5773[431] = (char *(*)()) F1261_10692;
}

char *(*R5795[500])();
void R5795_init () {
	R5795[0] = (char *(*)()) F852_6737;
	R5795[1] = (char *(*)()) F853_6737;
	R5795[2] = (char *(*)()) F854_6737_5795_10;
	R5795[3] = (char *(*)()) F855_6737_5795_10;
	R5795[4] = (char *(*)()) F856_6737_5795_10;
	R5795[5] = (char *(*)()) F857_6737_5795_10;
	R5795[6] = (char *(*)()) F858_6737_5795_10;
	R5795[7] = (char *(*)()) F859_6737_5795_10;
	{long i; for (i = 8; i < 10; i++) R5795[i] = (char *(*)()) F852_6737;}
	R5795[10] = (char *(*)()) F854_6737_5795_10;
	R5795[11] = (char *(*)()) F855_6737_5795_10;
	R5795[12] = (char *(*)()) F856_6737_5795_10;
	R5795[13] = (char *(*)()) F858_6737_5795_10;
	R5795[26] = (char *(*)()) F878_6858_5795_10;
	R5795[27] = (char *(*)()) F879_6897;
	R5795[28] = (char *(*)()) F880_6897_5795_10;
	R5795[29] = (char *(*)()) F881_6897_5795_10;
	R5795[30] = (char *(*)()) F882_6897_5795_10;
	R5795[31] = (char *(*)()) F883_6897_5795_10;
	R5795[32] = (char *(*)()) F884_6897_5795_10;
	R5795[33] = (char *(*)()) F885_6897_5795_10;
	R5795[34] = (char *(*)()) F886_6897_5795_10;
	R5795[35] = (char *(*)()) F887_6897_5795_10;
	R5795[36] = (char *(*)()) F888_6897_5795_10;
	R5795[37] = (char *(*)()) F889_6897_5795_10;
	R5795[38] = (char *(*)()) F890_6897_5795_10;
	R5795[92] = (char *(*)()) F896_6955;
	R5795[93] = (char *(*)()) F898_6955_5795_10;
	R5795[94] = (char *(*)()) F896_6955;
	R5795[95] = (char *(*)()) F898_6955_5795_10;
	R5795[96] = (char *(*)()) F896_6955;
	R5795[97] = (char *(*)()) F949_7077;
	R5795[98] = (char *(*)()) F950_7077_5795_10;
	R5795[99] = (char *(*)()) F951_7077_5795_10;
	R5795[100] = (char *(*)()) F952_7077_5795_10;
	R5795[101] = (char *(*)()) F953_7077_5795_10;
	R5795[102] = (char *(*)()) F954_7077_5795_10;
	R5795[103] = (char *(*)()) F955_7077_5795_10;
	R5795[104] = (char *(*)()) F956_7077_5795_10;
	R5795[105] = (char *(*)()) F957_7077_5795_10;
	R5795[106] = (char *(*)()) F958_7077_5795_10;
	R5795[107] = (char *(*)()) F959_7077_5795_10;
	R5795[108] = (char *(*)()) F960_7077_5795_10;
	{long i; for (i = 109; i < 112; i++) R5795[i] = (char *(*)()) F949_7077;}
	R5795[112] = (char *(*)()) F951_7077_5795_10;
	R5795[113] = (char *(*)()) F949_7077;
	R5795[174] = (char *(*)()) F1026_7808;
	R5795[230] = (char *(*)()) F1082_8352_5795_10;
	R5795[231] = (char *(*)()) F1083_8374_5795_10;
	R5795[234] = (char *(*)()) F1086_8520_5795_10;
	R5795[235] = (char *(*)()) F1087_8543_5795_10;
	R5795[289] = (char *(*)()) F1141_9208;
	R5795[290] = (char *(*)()) F1142_9208_5795_10;
	R5795[291] = (char *(*)()) F1143_9208_5795_10;
	R5795[292] = (char *(*)()) F1144_9208_5795_10;
	R5795[293] = (char *(*)()) F1145_9208_5795_10;
	R5795[294] = (char *(*)()) F1146_9208_5795_10;
	R5795[295] = (char *(*)()) F1147_9208_5795_10;
	R5795[296] = (char *(*)()) F1148_9208_5795_10;
	R5795[297] = (char *(*)()) F1149_9208_5795_10;
	R5795[298] = (char *(*)()) F1150_9208_5795_10;
	R5795[299] = (char *(*)()) F1151_9208_5795_10;
	R5795[300] = (char *(*)()) F1152_9208_5795_10;
	R5795[499] = (char *(*)()) F1351_13230_5795_10;
}
static EIF_REFERENCE F854_6737_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F854_6737(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_6737_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F855_6737(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_6737_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F856_6737(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6737_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F857_6737(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_6737_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F858_6737(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_6737_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F859_6737(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F878_6858_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F878_6858(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F880_6897_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F880_6897(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F881_6897_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F881_6897(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F882_6897_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F882_6897(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F883_6897_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F883_6897(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F884_6897_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F884_6897(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F885_6897_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F885_6897(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F886_6897_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F886_6897(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1234, 0x00).id, 1234, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F887_6897_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F887_6897(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F888_6897_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F888_6897(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F889_6897_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F889_6897(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F890_6897_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F890_6897(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_6955_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F898_6955(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F950_7077_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F950_7077(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_7077_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F951_7077(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_7077_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F952_7077(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7077_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F953_7077(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7077_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F954_7077(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7077_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F955_7077(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7077_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F956_7077(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1234, 0x00).id, 1234, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7077_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F957_7077(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F958_7077_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F958_7077(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7077_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F959_7077(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7077_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F960_7077(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1082_8352_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1082_8352(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1083_8374_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1083_8374(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1086_8520_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1086_8520(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1087_8543_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1087_8543(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1142_9208_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1142_9208(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1143_9208_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1143_9208(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1144_9208_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1144_9208(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1145_9208_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1145_9208(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1146_9208_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1146_9208(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1147_9208_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1147_9208(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1148_9208_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1148_9208(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1234, 0x00).id, 1234, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1149_9208_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1149_9208(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1150_9208_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1150_9208(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1151_9208_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1151_9208(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1152_9208_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1152_9208(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1351_13230_5795_10 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1351_13230(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R5796[500])();
void R5796_init () {
	R5796[0] = (char *(*)()) F852_6742;
	R5796[1] = (char *(*)()) F853_6742;
	R5796[2] = (char *(*)()) F854_6742;
	R5796[3] = (char *(*)()) F855_6742;
	R5796[4] = (char *(*)()) F856_6742;
	R5796[5] = (char *(*)()) F857_6742;
	R5796[6] = (char *(*)()) F858_6742;
	R5796[7] = (char *(*)()) F859_6742;
	{long i; for (i = 8; i < 10; i++) R5796[i] = (char *(*)()) F852_6742;}
	R5796[10] = (char *(*)()) F854_6742;
	R5796[11] = (char *(*)()) F855_6742;
	R5796[12] = (char *(*)()) F856_6742;
	R5796[13] = (char *(*)()) F858_6742;
	R5796[26] = (char *(*)()) F878_6855;
	R5796[27] = (char *(*)()) F879_6902;
	R5796[28] = (char *(*)()) F880_6902;
	R5796[29] = (char *(*)()) F881_6902;
	R5796[30] = (char *(*)()) F882_6902;
	R5796[31] = (char *(*)()) F883_6902;
	R5796[32] = (char *(*)()) F884_6902;
	R5796[33] = (char *(*)()) F885_6902;
	R5796[34] = (char *(*)()) F886_6902;
	R5796[35] = (char *(*)()) F887_6902;
	R5796[36] = (char *(*)()) F888_6902;
	R5796[37] = (char *(*)()) F889_6902;
	R5796[38] = (char *(*)()) F890_6902;
	R5796[92] = (char *(*)()) F896_6958;
	R5796[93] = (char *(*)()) F898_6958;
	R5796[94] = (char *(*)()) F896_6958;
	R5796[95] = (char *(*)()) F898_6958;
	{long i; for (i = 96; i < 98; i++) R5796[i] = (char *(*)()) F896_6958;}
	R5796[98] = (char *(*)()) F897_6958;
	R5796[99] = (char *(*)()) F898_6958;
	R5796[100] = (char *(*)()) F899_6958;
	R5796[101] = (char *(*)()) F900_6958;
	R5796[102] = (char *(*)()) F901_6958;
	R5796[103] = (char *(*)()) F902_6958;
	R5796[104] = (char *(*)()) F903_6958;
	R5796[105] = (char *(*)()) F904_6958;
	R5796[106] = (char *(*)()) F905_6958;
	R5796[107] = (char *(*)()) F906_6958;
	R5796[108] = (char *(*)()) F907_6958;
	{long i; for (i = 109; i < 112; i++) R5796[i] = (char *(*)()) F896_6958;}
	R5796[112] = (char *(*)()) F898_6958;
	R5796[113] = (char *(*)()) F896_6958;
	R5796[174] = (char *(*)()) F1026_7838;
	{long i; for (i = 230; i < 232; i++) R5796[i] = (char *(*)()) F1081_8319;}
	{long i; for (i = 234; i < 236; i++) R5796[i] = (char *(*)()) F1085_8484;}
	R5796[289] = (char *(*)()) F1141_9216;
	R5796[290] = (char *(*)()) F1142_9216;
	R5796[291] = (char *(*)()) F1143_9216;
	R5796[292] = (char *(*)()) F1144_9216;
	R5796[293] = (char *(*)()) F1145_9216;
	R5796[294] = (char *(*)()) F1146_9216;
	R5796[295] = (char *(*)()) F1147_9216;
	R5796[296] = (char *(*)()) F1148_9216;
	R5796[297] = (char *(*)()) F1149_9216;
	R5796[298] = (char *(*)()) F1150_9216;
	R5796[299] = (char *(*)()) F1151_9216;
	R5796[300] = (char *(*)()) F1152_9216;
	R5796[499] = (char *(*)()) F1081_8319;
}

EIF_TYPE_INDEX *Y5796_gen_type [513];
EIF_TYPE_INDEX Y5796 [513];
void Y5796_init (void)
{
	egc_routines_types [5796] = Y5796;
	egc_routines_gen_types [5796] = Y5796_gen_type;
	egc_routines_offset [5796] = 839;
	{long i; for (i = 0; i < 126; i++) Y5796[i] = 1219;};
	Y5796[186] = 1219;
	{long i; for (i = 241; i < 248; i++) Y5796[i] = 1219;};
	{long i; for (i = 301; i < 313; i++) Y5796[i] = 1219;};
	{long i; for (i = 511; i < 513; i++) Y5796[i] = 1219;};
}

char *(*R5797[500])();
void R5797_init () {
	R5797[0] = (char *(*)()) F852_6743;
	R5797[1] = (char *(*)()) F853_6743;
	R5797[2] = (char *(*)()) F854_6743;
	R5797[3] = (char *(*)()) F855_6743;
	R5797[4] = (char *(*)()) F856_6743;
	R5797[5] = (char *(*)()) F857_6743;
	R5797[6] = (char *(*)()) F858_6743;
	R5797[7] = (char *(*)()) F859_6743;
	{long i; for (i = 8; i < 10; i++) R5797[i] = (char *(*)()) F852_6743;}
	R5797[10] = (char *(*)()) F854_6743;
	R5797[11] = (char *(*)()) F855_6743;
	R5797[12] = (char *(*)()) F856_6743;
	R5797[13] = (char *(*)()) F858_6743;
	R5797[26] = (char *(*)()) F878_6857;
	R5797[27] = (char *(*)()) F879_6903;
	R5797[28] = (char *(*)()) F880_6903;
	R5797[29] = (char *(*)()) F881_6903;
	R5797[30] = (char *(*)()) F882_6903;
	R5797[31] = (char *(*)()) F883_6903;
	R5797[32] = (char *(*)()) F884_6903;
	R5797[33] = (char *(*)()) F885_6903;
	R5797[34] = (char *(*)()) F886_6903;
	R5797[35] = (char *(*)()) F887_6903;
	R5797[36] = (char *(*)()) F888_6903;
	R5797[37] = (char *(*)()) F889_6903;
	R5797[38] = (char *(*)()) F890_6903;
	R5797[92] = (char *(*)()) F944_7010;
	R5797[93] = (char *(*)()) F945_7010;
	R5797[94] = (char *(*)()) F944_7010;
	R5797[95] = (char *(*)()) F945_7010;
	R5797[96] = (char *(*)()) F944_7010;
	R5797[97] = (char *(*)()) F949_7092;
	R5797[98] = (char *(*)()) F950_7092;
	R5797[99] = (char *(*)()) F951_7092;
	R5797[100] = (char *(*)()) F952_7092;
	R5797[101] = (char *(*)()) F953_7092;
	R5797[102] = (char *(*)()) F954_7092;
	R5797[103] = (char *(*)()) F955_7092;
	R5797[104] = (char *(*)()) F956_7092;
	R5797[105] = (char *(*)()) F957_7092;
	R5797[106] = (char *(*)()) F958_7092;
	R5797[107] = (char *(*)()) F959_7092;
	R5797[108] = (char *(*)()) F960_7092;
	{long i; for (i = 109; i < 112; i++) R5797[i] = (char *(*)()) F949_7092;}
	R5797[112] = (char *(*)()) F951_7092;
	R5797[113] = (char *(*)()) F949_7092;
	R5797[174] = (char *(*)()) F1026_7837;
	{long i; for (i = 230; i < 232; i++) R5797[i] = (char *(*)()) F1081_8317;}
	{long i; for (i = 234; i < 236; i++) R5797[i] = (char *(*)()) F1085_8482;}
	R5797[289] = (char *(*)()) F1141_9217;
	R5797[290] = (char *(*)()) F1142_9217;
	R5797[291] = (char *(*)()) F1143_9217;
	R5797[292] = (char *(*)()) F1144_9217;
	R5797[293] = (char *(*)()) F1145_9217;
	R5797[294] = (char *(*)()) F1146_9217;
	R5797[295] = (char *(*)()) F1147_9217;
	R5797[296] = (char *(*)()) F1148_9217;
	R5797[297] = (char *(*)()) F1149_9217;
	R5797[298] = (char *(*)()) F1150_9217;
	R5797[299] = (char *(*)()) F1151_9217;
	R5797[300] = (char *(*)()) F1152_9217;
	R5797[499] = (char *(*)()) F1351_13246;
}


#ifdef __cplusplus
}
#endif
