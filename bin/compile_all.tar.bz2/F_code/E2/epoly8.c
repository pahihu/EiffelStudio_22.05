#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O5222[854];
void O5222_init () {
	O5222[0] = + _CHROFF_1_1_;
	O5222[1] = + _CHROFF_2_5_;
	O5222[362] = + _CHROFF_3_4_;
	O5222[363] = + _CHROFF_4_4_;
	O5222[364] = + _CHROFF_5_5_;
	O5222[795] = + _CHROFF_5_5_;
	{long i; for (i = 845; i < 848; i++) O5222[i] = + _CHROFF_5_4_;}
	O5222[849] = + _CHROFF_7_6_;
	{long i; for (i = 850; i < 854; i++) O5222[i] = + _CHROFF_6_5_;}
}

long O5223[854];
void O5223_init () {
	O5223[0] = + _R32OFF_1_3_2_3_0_;
	O5223[1] = + _R32OFF_2_7_2_5_0_;
	O5223[362] = + _R32OFF_3_6_2_4_0_;
	O5223[363] = + _R32OFF_4_6_2_4_0_;
	O5223[364] = + _R32OFF_5_7_2_4_0_;
	O5223[795] = + _R32OFF_5_7_2_4_0_;
	{long i; for (i = 845; i < 848; i++) O5223[i] = + _R32OFF_5_6_2_4_0_;}
	O5223[849] = + _R32OFF_7_8_2_4_0_;
	{long i; for (i = 850; i < 854; i++) O5223[i] = + _R32OFF_6_7_2_4_0_;}
}

long O5225[854];
void O5225_init () {
	O5225[0] = + _R64OFF_1_3_2_3_1_0_2_0_;
	O5225[1] = + _R64OFF_2_7_2_5_1_0_2_0_;
	O5225[362] = + _R64OFF_3_6_2_4_1_1_2_0_;
	O5225[363] = + _R64OFF_4_6_2_4_1_1_2_0_;
	O5225[364] = + _R64OFF_5_7_2_4_1_1_2_0_;
	O5225[795] = + _R64OFF_5_7_2_4_1_1_2_0_;
	{long i; for (i = 845; i < 848; i++) O5225[i] = + _R64OFF_5_6_2_4_1_1_2_0_;}
	O5225[849] = + _R64OFF_7_8_2_4_1_1_2_0_;
	{long i; for (i = 850; i < 854; i++) O5225[i] = + _R64OFF_6_7_2_4_1_1_2_0_;}
}

long O5335[850];
void O5335_init () {
	O5335[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 845; i < 847; i++) O5335[i] = + _LNGOFF_0_0_0_0_;}
	O5335[847] = + _LNGOFF_0_0_0_1_;
	O5335[848] = + _LNGOFF_5_1_0_1_;
	O5335[849] = + _LNGOFF_2_0_0_1_;
}

long O5414[22];
void O5414_init () {
	{long i; for (i = 0; i < 20; i++) O5414[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 20; i < 22; i++) O5414[i] = + _LNGOFF_2_1_0_0_;}
}

long O5418[22];
void O5418_init () {
	{long i; for (i = 0; i < 20; i++) O5418[i] = + _CHROFF_1_0_;}
	{long i; for (i = 20; i < 22; i++) O5418[i] = + _CHROFF_2_0_;}
}

long O5419[22];
void O5419_init () {
	{long i; for (i = 0; i < 20; i++) O5419[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 20; i < 22; i++) O5419[i] = + _LNGOFF_2_1_0_1_;}
}

long O5420[22];
void O5420_init () {
	{long i; for (i = 0; i < 20; i++) O5420[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 20; i < 22; i++) O5420[i] = + _LNGOFF_2_1_0_2_;}
}

long O5421[22];
void O5421_init () {
	{long i; for (i = 0; i < 20; i++) O5421[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 20; i < 22; i++) O5421[i] = + _LNGOFF_2_1_0_3_;}
}

long O5422[22];
void O5422_init () {
	{long i; for (i = 0; i < 20; i++) O5422[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 20; i < 22; i++) O5422[i] = + _LNGOFF_2_1_0_4_;}
}

long O5425[50];
void O5425_init () {
	{long i; for (i = 0; i < 12; i++) O5425[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 12; i < 38; i++) O5425[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 38; i < 50; i++) O5425[i] = + _LNGOFF_1_0_0_0_;}
}

long O5427[50];
void O5427_init () {
	{long i; for (i = 0; i < 12; i++) O5427[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 12; i < 38; i++) O5427[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 38; i < 50; i++) O5427[i] = + _LNGOFF_1_0_0_1_;}
}

static EIF_TYPE_INDEX Y5443_pgtype0[] = {0xFF01,495,0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y5443_pgtype1[] = {0xFF01,948,0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y5443_pgtype2[] = {0xFF01,948,0xFF01,1090,0xFFFF};
EIF_TYPE_INDEX *Y5443_gen_type [484];
EIF_TYPE_INDEX Y5443 [484];
void Y5443_init (void)
{
	egc_routines_types [5443] = Y5443;
	egc_routines_gen_types [5443] = Y5443_gen_type;
	egc_routines_offset [5443] = 606;
	Y5443_gen_type [0] = Y5443_pgtype0;
	Y5443_gen_type [482] = Y5443_pgtype1;
	Y5443_gen_type [483] = Y5443_pgtype2;
	Y5443[0] = 495;
	{long i; for (i = 482; i < 484; i++) Y5443[i] = 948;};
}

long O5457[745];
void O5457_init () {
	{long i; for (i = 0; i < 193; i++) O5457[i] = + _CHROFF_0_0_;}
	O5457[193] = + _CHROFF_1_0_;
	{long i; for (i = 194; i < 220; i++) O5457[i] = + _CHROFF_0_0_;}
	O5457[220] = + _CHROFF_3_2_;
	O5457[221] = + _CHROFF_4_2_;
	O5457[222] = + _CHROFF_5_2_;
	O5457[244] = + _CHROFF_7_0_;
	O5457[245] = + _CHROFF_6_0_;
	{long i; for (i = 246; i < 249; i++) O5457[i] = + _CHROFF_5_0_;}
	O5457[249] = + _CHROFF_4_0_;
	{long i; for (i = 250; i < 252; i++) O5457[i] = + _CHROFF_5_0_;}
	O5457[252] = + _CHROFF_9_0_;
	O5457[253] = + _CHROFF_7_0_;
	{long i; for (i = 254; i < 258; i++) O5457[i] = + _CHROFF_5_0_;}
	{long i; for (i = 258; i < 271; i++) O5457[i] = + _CHROFF_0_0_;}
	{long i; for (i = 271; i < 288; i++) O5457[i] = + _CHROFF_1_0_;}
	{long i; for (i = 288; i < 336; i++) O5457[i] = + _CHROFF_0_0_;}
	{long i; for (i = 336; i < 341; i++) O5457[i] = + _CHROFF_2_0_;}
	{long i; for (i = 341; i < 357; i++) O5457[i] = + _CHROFF_1_0_;}
	O5457[357] = + _CHROFF_5_0_;
	{long i; for (i = 475; i < 477; i++) O5457[i] = + _CHROFF_1_0_;}
	O5457[479] = + _CHROFF_1_0_;
	O5457[653] = + _CHROFF_5_2_;
	{long i; for (i = 703; i < 706; i++) O5457[i] = + _CHROFF_5_2_;}
	O5457[707] = + _CHROFF_7_2_;
	{long i; for (i = 708; i < 712; i++) O5457[i] = + _CHROFF_6_2_;}
	{long i; for (i = 743; i < 745; i++) O5457[i] = + _CHROFF_1_0_;}
}

EIF_TYPE_INDEX *Y5581_gen_type [1];
EIF_TYPE_INDEX Y5581 [1];
void Y5581_init (void)
{
	egc_routines_types [5581] = Y5581;
	egc_routines_gen_types [5581] = Y5581_gen_type;
	egc_routines_offset [5581] = 800;
	Y5581[0] = 1219;
}

long O5598[492];
void O5598_init () {
	O5598[0] = + _PTROFF_3_6_2_4_1_0_;
	O5598[1] = + _PTROFF_4_6_2_4_1_0_;
	O5598[2] = + _PTROFF_5_7_2_4_1_0_;
	O5598[433] = + _PTROFF_5_7_2_4_1_0_;
	{long i; for (i = 483; i < 486; i++) O5598[i] = + _PTROFF_5_6_2_4_1_0_;}
	O5598[487] = + _PTROFF_7_8_2_4_1_0_;
	{long i; for (i = 488; i < 492; i++) O5598[i] = + _PTROFF_6_7_2_4_1_0_;}
}

long O5737[492];
void O5737_init () {
	O5737[0] = + _LNGOFF_3_6_2_3_;
	O5737[1] = + _LNGOFF_4_6_2_3_;
	O5737[2] = + _LNGOFF_5_7_2_3_;
	O5737[433] = + _LNGOFF_5_7_2_3_;
	{long i; for (i = 483; i < 486; i++) O5737[i] = + _LNGOFF_5_6_2_3_;}
	O5737[487] = + _LNGOFF_7_8_2_3_;
	{long i; for (i = 488; i < 492; i++) O5737[i] = + _LNGOFF_6_7_2_3_;}
}

long O5746[492];
void O5746_init () {
	O5746[0] = + _CHROFF_3_3_;
	O5746[1] = + _CHROFF_4_3_;
	O5746[2] = + _CHROFF_5_3_;
	O5746[433] = + _CHROFF_5_3_;
	{long i; for (i = 483; i < 486; i++) O5746[i] = + _CHROFF_5_3_;}
	O5746[487] = + _CHROFF_7_3_;
	{long i; for (i = 488; i < 492; i++) O5746[i] = + _CHROFF_6_3_;}
}

long O5804[14];
void O5804_init () {
	{long i; for (i = 0; i < 2; i++) O5804[i] = 0;}
	O5804[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 5; i++) O5804[i] = + _LNGOFF_5_3_0_0_;}
	O5804[5] = + _LNGOFF_4_3_0_0_;
	O5804[6] = + _CHROFF_5_3_;
	O5804[7] = + _PTROFF_5_3_0_7_0_0_;
	{long i; for (i = 8; i < 10; i++) O5804[i] = 0;}
	O5804[10] = + _CHROFF_5_1_;
	{long i; for (i = 11; i < 13; i++) O5804[i] = + _LNGOFF_5_4_0_0_;}
	O5804[13] = + _CHROFF_5_4_;
}

long O5813[14];
void O5813_init () {
	O5813[0] = + _LNGOFF_7_3_0_0_;
	O5813[1] = + _LNGOFF_6_3_0_0_;
	O5813[2] = + _LNGOFF_5_5_0_0_;
	O5813[3] = + _LNGOFF_5_3_0_1_;
	O5813[4] = + _LNGOFF_5_3_0_2_;
	O5813[5] = + _LNGOFF_4_3_0_1_;
	O5813[6] = + _LNGOFF_5_5_0_0_;
	O5813[7] = + _LNGOFF_5_3_0_0_;
	O5813[8] = + _LNGOFF_9_3_0_0_;
	O5813[9] = + _LNGOFF_7_4_0_0_;
	O5813[10] = + _LNGOFF_5_6_0_0_;
	O5813[11] = + _LNGOFF_5_4_0_1_;
	O5813[12] = + _LNGOFF_5_4_0_2_;
	O5813[13] = + _LNGOFF_5_6_0_0_;
}

long O5840[14];
void O5840_init () {
	{long i; for (i = 0; i < 2; i++) O5840[i] =  + _REFACS_1_;}
	{long i; for (i = 2; i < 8; i++) O5840[i] = 0;}
	{long i; for (i = 8; i < 10; i++) O5840[i] =  + _REFACS_1_;}
	{long i; for (i = 10; i < 14; i++) O5840[i] = 0;}
}

static EIF_TYPE_INDEX Y5840_pgtype0[] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5840_pgtype1[] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5840_pgtype2[] = {0xFF01,1141,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5840_pgtype3[] = {0xFF01,1142,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5840_pgtype4[] = {0xFF01,1145,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5840_pgtype5[] = {0xFF01,1142,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5840_pgtype6[] = {0xFF01,1148,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5840_pgtype7[] = {0xFF01,1149,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5840_pgtype8[] = {0xFF01,1140,0,0xFFFF};
static EIF_TYPE_INDEX Y5840_pgtype9[] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5840_pgtype10[] = {0xFF01,1141,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5840_pgtype11[] = {0xFF01,1142,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5840_pgtype12[] = {0xFF01,1145,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5840_pgtype13[] = {0xFF01,1148,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5840_gen_type [14];
EIF_TYPE_INDEX Y5840 [14];
void Y5840_init (void)
{
	egc_routines_types [5840] = Y5840;
	egc_routines_gen_types [5840] = Y5840_gen_type;
	egc_routines_offset [5840] = 851;
	Y5840_gen_type [0] = Y5840_pgtype0;
	Y5840_gen_type [1] = Y5840_pgtype1;
	Y5840_gen_type [2] = Y5840_pgtype2;
	Y5840_gen_type [3] = Y5840_pgtype3;
	Y5840_gen_type [4] = Y5840_pgtype4;
	Y5840_gen_type [5] = Y5840_pgtype5;
	Y5840_gen_type [6] = Y5840_pgtype6;
	Y5840_gen_type [7] = Y5840_pgtype7;
	Y5840_gen_type [8] = Y5840_pgtype8;
	Y5840_gen_type [9] = Y5840_pgtype9;
	Y5840_gen_type [10] = Y5840_pgtype10;
	Y5840_gen_type [11] = Y5840_pgtype11;
	Y5840_gen_type [12] = Y5840_pgtype12;
	Y5840_gen_type [13] = Y5840_pgtype13;
	{long i; for (i = 0; i < 2; i++) Y5840[i] = 1140;};
	Y5840[2] = 1141;
	Y5840[3] = 1142;
	Y5840[4] = 1145;
	Y5840[5] = 1142;
	Y5840[6] = 1148;
	Y5840[7] = 1149;
	{long i; for (i = 8; i < 10; i++) Y5840[i] = 1140;};
	Y5840[10] = 1141;
	Y5840[11] = 1142;
	Y5840[12] = 1145;
	Y5840[13] = 1148;
}

long O5841[14];
void O5841_init () {
	{long i; for (i = 0; i < 2; i++) O5841[i] =  + _REFACS_2_;}
	{long i; for (i = 2; i < 8; i++) O5841[i] =  + _REFACS_1_;}
	{long i; for (i = 8; i < 10; i++) O5841[i] =  + _REFACS_2_;}
	{long i; for (i = 10; i < 14; i++) O5841[i] =  + _REFACS_1_;}
}

static EIF_TYPE_INDEX Y5841_pgtype0[] = {0xFF01,1140,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5841_pgtype1[] = {0xFF01,1142,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5841_pgtype2[] = {0xFF01,1140,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5841_pgtype3[] = {0xFF01,1140,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5841_pgtype4[] = {0xFF01,1140,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5841_pgtype5[] = {0xFF01,1142,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5841_pgtype6[] = {0xFF01,1140,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5841_pgtype7[] = {0xFF01,1140,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5841_pgtype8[] = {0xFF01,1140,0xFF01,1082,0xFFFF};
static EIF_TYPE_INDEX Y5841_pgtype9[] = {0xFF01,1140,0xFF01,1077,0xFFFF};
static EIF_TYPE_INDEX Y5841_pgtype10[] = {0xFF01,1140,0xFF01,1077,0xFFFF};
static EIF_TYPE_INDEX Y5841_pgtype11[] = {0xFF01,1140,0xFF01,1077,0xFFFF};
static EIF_TYPE_INDEX Y5841_pgtype12[] = {0xFF01,1140,0xFF01,1077,0xFFFF};
static EIF_TYPE_INDEX Y5841_pgtype13[] = {0xFF01,1140,0xFF01,1077,0xFFFF};
EIF_TYPE_INDEX *Y5841_gen_type [14];
EIF_TYPE_INDEX Y5841 [14];
void Y5841_init (void)
{
	egc_routines_types [5841] = Y5841;
	egc_routines_gen_types [5841] = Y5841_gen_type;
	egc_routines_offset [5841] = 851;
	Y5841_gen_type [0] = Y5841_pgtype0;
	Y5841_gen_type [1] = Y5841_pgtype1;
	Y5841_gen_type [2] = Y5841_pgtype2;
	Y5841_gen_type [3] = Y5841_pgtype3;
	Y5841_gen_type [4] = Y5841_pgtype4;
	Y5841_gen_type [5] = Y5841_pgtype5;
	Y5841_gen_type [6] = Y5841_pgtype6;
	Y5841_gen_type [7] = Y5841_pgtype7;
	Y5841_gen_type [8] = Y5841_pgtype8;
	Y5841_gen_type [9] = Y5841_pgtype9;
	Y5841_gen_type [10] = Y5841_pgtype10;
	Y5841_gen_type [11] = Y5841_pgtype11;
	Y5841_gen_type [12] = Y5841_pgtype12;
	Y5841_gen_type [13] = Y5841_pgtype13;
	Y5841[0] = 1140;
	Y5841[1] = 1142;
	{long i; for (i = 2; i < 5; i++) Y5841[i] = 1140;};
	Y5841[5] = 1142;
	{long i; for (i = 6; i < 14; i++) Y5841[i] = 1140;};
}

long O5842[14];
void O5842_init () {
	{long i; for (i = 0; i < 2; i++) O5842[i] =  + _REFACS_3_;}
	{long i; for (i = 2; i < 8; i++) O5842[i] =  + _REFACS_2_;}
	{long i; for (i = 8; i < 10; i++) O5842[i] =  + _REFACS_3_;}
	{long i; for (i = 10; i < 14; i++) O5842[i] =  + _REFACS_2_;}
}

long O5843[14];
void O5843_init () {
	{long i; for (i = 0; i < 2; i++) O5843[i] =  + _REFACS_4_;}
	{long i; for (i = 2; i < 8; i++) O5843[i] =  + _REFACS_3_;}
	{long i; for (i = 8; i < 10; i++) O5843[i] =  + _REFACS_4_;}
	{long i; for (i = 10; i < 14; i++) O5843[i] =  + _REFACS_3_;}
}

long O5844[14];
void O5844_init () {
	O5844[0] = + _LNGOFF_7_3_0_1_;
	O5844[1] = + _LNGOFF_6_3_0_1_;
	O5844[2] = + _LNGOFF_5_5_0_1_;
	O5844[3] = + _LNGOFF_5_3_0_2_;
	O5844[4] = + _LNGOFF_5_3_0_3_;
	O5844[5] = + _LNGOFF_4_3_0_2_;
	O5844[6] = + _LNGOFF_5_5_0_1_;
	O5844[7] = + _LNGOFF_5_3_0_1_;
	O5844[8] = + _LNGOFF_9_3_0_1_;
	O5844[9] = + _LNGOFF_7_4_0_1_;
	O5844[10] = + _LNGOFF_5_6_0_1_;
	O5844[11] = + _LNGOFF_5_4_0_2_;
	O5844[12] = + _LNGOFF_5_4_0_3_;
	O5844[13] = + _LNGOFF_5_6_0_1_;
}

long O5845[14];
void O5845_init () {
	O5845[0] = + _CHROFF_7_2_;
	O5845[1] = + _CHROFF_6_2_;
	O5845[2] = + _CHROFF_5_3_;
	{long i; for (i = 3; i < 5; i++) O5845[i] = + _CHROFF_5_2_;}
	O5845[5] = + _CHROFF_4_2_;
	{long i; for (i = 6; i < 8; i++) O5845[i] = + _CHROFF_5_2_;}
	O5845[8] = + _CHROFF_9_2_;
	O5845[9] = + _CHROFF_7_2_;
	O5845[10] = + _CHROFF_5_3_;
	{long i; for (i = 11; i < 14; i++) O5845[i] = + _CHROFF_5_2_;}
}

long O5846[14];
void O5846_init () {
	O5846[0] = + _LNGOFF_7_3_0_2_;
	O5846[1] = + _LNGOFF_6_3_0_2_;
	O5846[2] = + _LNGOFF_5_5_0_2_;
	O5846[3] = + _LNGOFF_5_3_0_3_;
	O5846[4] = + _LNGOFF_5_3_0_4_;
	O5846[5] = + _LNGOFF_4_3_0_3_;
	O5846[6] = + _LNGOFF_5_5_0_2_;
	O5846[7] = + _LNGOFF_5_3_0_2_;
	O5846[8] = + _LNGOFF_9_3_0_2_;
	O5846[9] = + _LNGOFF_7_4_0_2_;
	O5846[10] = + _LNGOFF_5_6_0_2_;
	O5846[11] = + _LNGOFF_5_4_0_3_;
	O5846[12] = + _LNGOFF_5_4_0_4_;
	O5846[13] = + _LNGOFF_5_6_0_2_;
}

long O5849[14];
void O5849_init () {
	O5849[0] = + _LNGOFF_7_3_0_3_;
	O5849[1] = + _LNGOFF_6_3_0_3_;
	O5849[2] = + _LNGOFF_5_5_0_3_;
	O5849[3] = + _LNGOFF_5_3_0_4_;
	O5849[4] = + _LNGOFF_5_3_0_5_;
	O5849[5] = + _LNGOFF_4_3_0_4_;
	O5849[6] = + _LNGOFF_5_5_0_3_;
	O5849[7] = + _LNGOFF_5_3_0_3_;
	O5849[8] = + _LNGOFF_9_3_0_3_;
	O5849[9] = + _LNGOFF_7_4_0_3_;
	O5849[10] = + _LNGOFF_5_6_0_3_;
	O5849[11] = + _LNGOFF_5_4_0_4_;
	O5849[12] = + _LNGOFF_5_4_0_5_;
	O5849[13] = + _LNGOFF_5_6_0_3_;
}

long O5850[14];
void O5850_init () {
	O5850[0] = + _LNGOFF_7_3_0_4_;
	O5850[1] = + _LNGOFF_6_3_0_4_;
	O5850[2] = + _LNGOFF_5_5_0_4_;
	O5850[3] = + _LNGOFF_5_3_0_5_;
	O5850[4] = + _LNGOFF_5_3_0_6_;
	O5850[5] = + _LNGOFF_4_3_0_5_;
	O5850[6] = + _LNGOFF_5_5_0_4_;
	O5850[7] = + _LNGOFF_5_3_0_4_;
	O5850[8] = + _LNGOFF_9_3_0_4_;
	O5850[9] = + _LNGOFF_7_4_0_4_;
	O5850[10] = + _LNGOFF_5_6_0_4_;
	O5850[11] = + _LNGOFF_5_4_0_5_;
	O5850[12] = + _LNGOFF_5_4_0_6_;
	O5850[13] = + _LNGOFF_5_6_0_4_;
}

long O5854[14];
void O5854_init () {
	O5854[0] = + _LNGOFF_7_3_0_5_;
	O5854[1] = + _LNGOFF_6_3_0_5_;
	O5854[2] = + _LNGOFF_5_5_0_5_;
	O5854[3] = + _LNGOFF_5_3_0_6_;
	O5854[4] = + _LNGOFF_5_3_0_7_;
	O5854[5] = + _LNGOFF_4_3_0_6_;
	O5854[6] = + _LNGOFF_5_5_0_5_;
	O5854[7] = + _LNGOFF_5_3_0_5_;
	O5854[8] = + _LNGOFF_9_3_0_5_;
	O5854[9] = + _LNGOFF_7_4_0_5_;
	O5854[10] = + _LNGOFF_5_6_0_5_;
	O5854[11] = + _LNGOFF_5_4_0_6_;
	O5854[12] = + _LNGOFF_5_4_0_7_;
	O5854[13] = + _LNGOFF_5_6_0_5_;
}

long O5855[14];
void O5855_init () {
	{long i; for (i = 0; i < 2; i++) O5855[i] =  + _REFACS_5_;}
	O5855[2] = + _CHROFF_5_4_;
	O5855[3] = + _LNGOFF_5_3_0_7_;
	O5855[4] = + _LNGOFF_5_3_0_1_;
	O5855[5] = + _LNGOFF_4_3_0_7_;
	O5855[6] = + _CHROFF_5_4_;
	O5855[7] = + _PTROFF_5_3_0_7_0_1_;
	{long i; for (i = 8; i < 10; i++) O5855[i] =  + _REFACS_5_;}
	O5855[10] = + _CHROFF_5_4_;
	O5855[11] = + _LNGOFF_5_4_0_7_;
	O5855[12] = + _LNGOFF_5_4_0_1_;
	O5855[13] = + _CHROFF_5_5_;
}

long O5856[14];
void O5856_init () {
	O5856[0] =  + _REFACS_6_;
	O5856[1] = + _LNGOFF_6_3_0_6_;
	{long i; for (i = 2; i < 5; i++) O5856[i] =  + _REFACS_4_;}
	O5856[5] = + _LNGOFF_4_3_0_8_;
	{long i; for (i = 6; i < 8; i++) O5856[i] =  + _REFACS_4_;}
	{long i; for (i = 8; i < 10; i++) O5856[i] =  + _REFACS_6_;}
	{long i; for (i = 10; i < 14; i++) O5856[i] =  + _REFACS_4_;}
}

long O5890[14];
void O5890_init () {
	O5890[0] = + _LNGOFF_7_3_0_6_;
	O5890[1] = + _LNGOFF_6_3_0_7_;
	O5890[2] = + _LNGOFF_5_5_0_6_;
	{long i; for (i = 3; i < 5; i++) O5890[i] = + _LNGOFF_5_3_0_8_;}
	O5890[5] = + _LNGOFF_4_3_0_9_;
	O5890[6] = + _LNGOFF_5_5_0_6_;
	O5890[7] = + _LNGOFF_5_3_0_6_;
	O5890[8] = + _LNGOFF_9_3_0_6_;
	O5890[9] = + _LNGOFF_7_4_0_6_;
	O5890[10] = + _LNGOFF_5_6_0_6_;
	{long i; for (i = 11; i < 13; i++) O5890[i] = + _LNGOFF_5_4_0_8_;}
	O5890[13] = + _LNGOFF_5_6_0_6_;
}

long O5903[5];
void O5903_init () {
	O5903[0] = + _CHROFF_7_3_;
	O5903[1] = + _CHROFF_5_5_;
	{long i; for (i = 2; i < 5; i++) O5903[i] = + _CHROFF_5_3_;}
}

long O6013[17];
void O6013_init () {
	{long i; for (i = 0; i < 16; i++) O6013[i] = + _LNGOFF_1_1_0_0_;}
	O6013[16] = + _LNGOFF_5_1_0_0_;
}

long O6174[2];
void O6174_init () {
	O6174[0] = + _CHROFF_12_0_;
	O6174[1] = + _CHROFF_18_0_;
}

long O6175[2];
void O6175_init () {
	O6175[0] = + _CHROFF_12_1_;
	O6175[1] = + _CHROFF_18_1_;
}

long O6176[2];
void O6176_init () {
	O6176[0] = + _CHROFF_12_2_;
	O6176[1] = + _CHROFF_18_2_;
}

long O6177[2];
void O6177_init () {
	O6177[0] = + _CHROFF_12_3_;
	O6177[1] = + _CHROFF_18_3_;
}

long O6178[2];
void O6178_init () {
	O6178[0] = + _CHROFF_12_4_;
	O6178[1] = + _CHROFF_18_4_;
}

long O6179[2];
void O6179_init () {
	O6179[0] = + _CHROFF_12_5_;
	O6179[1] = + _CHROFF_18_5_;
}

long O6180[2];
void O6180_init () {
	O6180[0] = + _CHROFF_12_6_;
	O6180[1] = + _CHROFF_18_6_;
}

long O6181[2];
void O6181_init () {
	O6181[0] = + _CHROFF_12_7_;
	O6181[1] = + _CHROFF_18_7_;
}

long O6182[2];
void O6182_init () {
	O6182[0] = + _CHROFF_12_8_;
	O6182[1] = + _CHROFF_18_8_;
}

long O6197[2];
void O6197_init () {
	O6197[0] = + _CHROFF_12_9_;
	O6197[1] = + _CHROFF_18_9_;
}

long O6198[2];
void O6198_init () {
	O6198[0] = + _CHROFF_12_10_;
	O6198[1] = + _CHROFF_18_10_;
}

long O6199[2];
void O6199_init () {
	O6199[0] = + _CHROFF_12_11_;
	O6199[1] = + _CHROFF_18_11_;
}

long O6200[2];
void O6200_init () {
	O6200[0] = + _CHROFF_12_12_;
	O6200[1] = + _CHROFF_18_12_;
}

long O6201[2];
void O6201_init () {
	O6201[0] = + _CHROFF_12_13_;
	O6201[1] = + _CHROFF_18_13_;
}

long O6202[2];
void O6202_init () {
	O6202[0] = + _CHROFF_12_14_;
	O6202[1] = + _CHROFF_18_14_;
}

long O6203[2];
void O6203_init () {
	O6203[0] = + _CHROFF_12_15_;
	O6203[1] = + _CHROFF_18_15_;
}

long O6204[2];
void O6204_init () {
	O6204[0] = + _CHROFF_12_16_;
	O6204[1] = + _CHROFF_18_16_;
}

long O6205[2];
void O6205_init () {
	O6205[0] = + _CHROFF_12_17_;
	O6205[1] = + _CHROFF_18_17_;
}

long O6564[8];
void O6564_init () {
	{long i; for (i = 0; i < 3; i++) O6564[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 3; i < 6; i++) O6564[i] = + _LNGOFF_3_0_0_0_;}
	{long i; for (i = 6; i < 8; i++) O6564[i] = + _LNGOFF_2_0_0_0_;}
}

long O6565[8];
void O6565_init () {
	{long i; for (i = 0; i < 3; i++) O6565[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 3; i < 6; i++) O6565[i] = + _LNGOFF_3_0_0_1_;}
	{long i; for (i = 6; i < 8; i++) O6565[i] = + _LNGOFF_2_0_0_1_;}
}

long O6566[8];
void O6566_init () {
	{long i; for (i = 0; i < 3; i++) O6566[i] = + _LNGOFF_2_0_0_2_;}
	{long i; for (i = 3; i < 6; i++) O6566[i] = + _LNGOFF_3_0_0_2_;}
	{long i; for (i = 6; i < 8; i++) O6566[i] = + _LNGOFF_2_0_0_2_;}
}

long O6723[3];
void O6723_init () {
	O6723[0] = + _LNGOFF_3_4_0_0_;
	{long i; for (i = 1; i < 3; i++) O6723[i] = + _LNGOFF_5_5_0_0_;}
}

long O6725[3];
void O6725_init () {
	O6725[0] = + _CHROFF_3_0_;
	{long i; for (i = 1; i < 3; i++) O6725[i] = + _CHROFF_5_0_;}
}

long O6726[3];
void O6726_init () {
	O6726[0] = + _CHROFF_3_1_;
	{long i; for (i = 1; i < 3; i++) O6726[i] = + _CHROFF_5_1_;}
}

long O6727[3];
void O6727_init () {
	O6727[0] = + _CHROFF_3_2_;
	{long i; for (i = 1; i < 3; i++) O6727[i] = + _CHROFF_5_2_;}
}

long O6728[3];
void O6728_init () {
	O6728[0] = + _CHROFF_3_3_;
	{long i; for (i = 1; i < 3; i++) O6728[i] = + _CHROFF_5_3_;}
}

long O6867[6];
void O6867_init () {
	{long i; for (i = 0; i < 2; i++) O6867[i] = + _CHROFF_4_0_;}
	O6867[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 6; i++) O6867[i] = + _CHROFF_4_0_;}
}

long O6868[6];
void O6868_init () {
	{long i; for (i = 0; i < 2; i++) O6868[i] = + _LNGOFF_4_2_0_0_;}
	O6868[2] = + _LNGOFF_5_2_0_0_;
	O6868[3] = + _LNGOFF_4_3_0_0_;
	O6868[4] = + _LNGOFF_4_2_0_0_;
	O6868[5] = + _LNGOFF_4_3_0_0_;
}

long O6876[6];
void O6876_init () {
	{long i; for (i = 0; i < 2; i++) O6876[i] = + _PTROFF_4_2_0_3_0_0_;}
	O6876[2] = + _PTROFF_5_2_0_3_0_0_;
	O6876[3] = + _PTROFF_4_3_0_3_0_0_;
	O6876[4] = + _PTROFF_4_2_0_4_0_0_;
	O6876[5] = + _PTROFF_4_3_0_3_0_0_;
}

long O6877[6];
void O6877_init () {
	{long i; for (i = 0; i < 2; i++) O6877[i] = + _PTROFF_4_2_0_3_0_1_;}
	O6877[2] = + _PTROFF_5_2_0_3_0_1_;
	O6877[3] = + _PTROFF_4_3_0_3_0_1_;
	O6877[4] = + _PTROFF_4_2_0_4_0_1_;
	O6877[5] = + _PTROFF_4_3_0_3_0_1_;
}

long O6879[6];
void O6879_init () {
	{long i; for (i = 0; i < 2; i++) O6879[i] = + _PTROFF_4_2_0_3_0_2_;}
	O6879[2] = + _PTROFF_5_2_0_3_0_2_;
	O6879[3] = + _PTROFF_4_3_0_3_0_2_;
	O6879[4] = + _PTROFF_4_2_0_4_0_2_;
	O6879[5] = + _PTROFF_4_3_0_3_0_2_;
}

long O6880[6];
void O6880_init () {
	{long i; for (i = 0; i < 2; i++) O6880[i] = + _LNGOFF_4_2_0_1_;}
	O6880[2] = + _LNGOFF_5_2_0_1_;
	O6880[3] = + _LNGOFF_4_3_0_1_;
	O6880[4] = + _LNGOFF_4_2_0_1_;
	O6880[5] = + _LNGOFF_4_3_0_1_;
}

long O6881[6];
void O6881_init () {
	{long i; for (i = 0; i < 2; i++) O6881[i] = + _CHROFF_4_1_;}
	O6881[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 6; i++) O6881[i] = + _CHROFF_4_1_;}
}

long O6882[6];
void O6882_init () {
	{long i; for (i = 0; i < 2; i++) O6882[i] = + _LNGOFF_4_2_0_2_;}
	O6882[2] = + _LNGOFF_5_2_0_2_;
	O6882[3] = + _LNGOFF_4_3_0_2_;
	O6882[4] = + _LNGOFF_4_2_0_2_;
	O6882[5] = + _LNGOFF_4_3_0_2_;
}

long O6895[4];
void O6895_init () {
	O6895[0] =  + _REFACS_4_;
	O6895[1] = + _CHROFF_4_2_;
	O6895[2] = + _LNGOFF_4_2_0_3_;
	O6895[3] = + _CHROFF_4_2_;
}

long O6994[275];
void O6994_init () {
	{long i; for (i = 0; i < 3; i++) O6994[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O6994[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 5; i < 7; i++) O6994[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 7; i < 9; i++) O6994[i] = + _LNGOFF_1_0_0_0_;}
	O6994[9] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 273; i < 275; i++) O6994[i] = + _LNGOFF_1_1_0_0_;}
}

long O6995[275];
void O6995_init () {
	{long i; for (i = 0; i < 3; i++) O6995[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O6995[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 5; i < 7; i++) O6995[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 7; i < 9; i++) O6995[i] = + _LNGOFF_1_0_0_1_;}
	O6995[9] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 273; i < 275; i++) O6995[i] = + _LNGOFF_1_1_0_1_;}
}

long O7064[272];
void O7064_init () {
	{long i; for (i = 0; i < 2; i++) O7064[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O7064[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 270; i < 272; i++) O7064[i] = + _LNGOFF_1_1_0_2_;}
}

long O7139[3];
void O7139_init () {
	{long i; for (i = 0; i < 2; i++) O7139[i] = + _LNGOFF_1_0_0_2_;}
	O7139[2] = + _LNGOFF_1_1_0_2_;
}

long O7748[10];
void O7748_init () {
	{long i; for (i = 0; i < 2; i++) O7748[i] = + _CHROFF_16_0_;}
	O7748[2] = + _CHROFF_18_0_;
	{long i; for (i = 3; i < 5; i++) O7748[i] = + _CHROFF_27_0_;}
	O7748[5] = + _CHROFF_29_0_;
	O7748[6] = + _CHROFF_18_0_;
	O7748[7] = + _CHROFF_23_0_;
	O7748[8] = + _CHROFF_21_0_;
	O7748[9] = + _CHROFF_22_0_;
}

long O7759[10];
void O7759_init () {
	{long i; for (i = 0; i < 3; i++) O7759[i] =  + _REFACS_3_;}
	{long i; for (i = 3; i < 6; i++) O7759[i] =  + _REFACS_5_;}
	{long i; for (i = 6; i < 8; i++) O7759[i] =  + _REFACS_3_;}
	{long i; for (i = 8; i < 10; i++) O7759[i] =  + _REFACS_5_;}
}

static EIF_TYPE_INDEX Y7759_pgtype0[] = {0xFF01,1084,0xFFFF};
static EIF_TYPE_INDEX Y7759_pgtype1[] = {0xFF01,1084,0xFFFF};
static EIF_TYPE_INDEX Y7759_pgtype2[] = {0xFF01,1084,0xFFFF};
static EIF_TYPE_INDEX Y7759_pgtype3[] = {0xFF01,1084,0xFFFF};
static EIF_TYPE_INDEX Y7759_pgtype4[] = {0xFF01,1084,0xFFFF};
static EIF_TYPE_INDEX Y7759_pgtype5[] = {0xFF01,1084,0xFFFF};
static EIF_TYPE_INDEX Y7759_pgtype6[] = {0xFF01,1084,0xFFFF};
static EIF_TYPE_INDEX Y7759_pgtype7[] = {0xFF01,1084,0xFFFF};
static EIF_TYPE_INDEX Y7759_pgtype8[] = {0xFF01,1084,0xFFFF};
static EIF_TYPE_INDEX Y7759_pgtype9[] = {0xFF01,1084,0xFFFF};
EIF_TYPE_INDEX *Y7759_gen_type [10];
EIF_TYPE_INDEX Y7759 [10];
void Y7759_init (void)
{
	egc_routines_types [7759] = Y7759;
	egc_routines_gen_types [7759] = Y7759_gen_type;
	egc_routines_offset [7759] = 1152;
	Y7759_gen_type [0] = Y7759_pgtype0;
	Y7759_gen_type [1] = Y7759_pgtype1;
	Y7759_gen_type [2] = Y7759_pgtype2;
	Y7759_gen_type [3] = Y7759_pgtype3;
	Y7759_gen_type [4] = Y7759_pgtype4;
	Y7759_gen_type [5] = Y7759_pgtype5;
	Y7759_gen_type [6] = Y7759_pgtype6;
	Y7759_gen_type [7] = Y7759_pgtype7;
	Y7759_gen_type [8] = Y7759_pgtype8;
	Y7759_gen_type [9] = Y7759_pgtype9;
	{long i; for (i = 0; i < 10; i++) Y7759[i] = 1084;};
}

long O7760[10];
void O7760_init () {
	{long i; for (i = 0; i < 3; i++) O7760[i] =  + _REFACS_4_;}
	{long i; for (i = 3; i < 6; i++) O7760[i] =  + _REFACS_6_;}
	{long i; for (i = 6; i < 8; i++) O7760[i] =  + _REFACS_4_;}
	{long i; for (i = 8; i < 10; i++) O7760[i] =  + _REFACS_6_;}
}

long O7761[10];
void O7761_init () {
	{long i; for (i = 0; i < 3; i++) O7761[i] =  + _REFACS_5_;}
	{long i; for (i = 3; i < 6; i++) O7761[i] =  + _REFACS_7_;}
	{long i; for (i = 6; i < 8; i++) O7761[i] =  + _REFACS_5_;}
	{long i; for (i = 8; i < 10; i++) O7761[i] =  + _REFACS_7_;}
}

static EIF_TYPE_INDEX Y7761_pgtype0[] = {0xFF01,1319,0xFFFF};
static EIF_TYPE_INDEX Y7761_pgtype1[] = {0xFF01,1319,0xFFFF};
static EIF_TYPE_INDEX Y7761_pgtype2[] = {0xFF01,1319,0xFFFF};
static EIF_TYPE_INDEX Y7761_pgtype3[] = {0xFF01,1320,0xFFFF};
static EIF_TYPE_INDEX Y7761_pgtype4[] = {0xFF01,1320,0xFFFF};
static EIF_TYPE_INDEX Y7761_pgtype5[] = {0xFF01,1320,0xFFFF};
static EIF_TYPE_INDEX Y7761_pgtype6[] = {0xFF01,1319,0xFFFF};
static EIF_TYPE_INDEX Y7761_pgtype7[] = {0xFF01,1321,0xFFFF};
static EIF_TYPE_INDEX Y7761_pgtype8[] = {0xFF01,1319,0xFFFF};
static EIF_TYPE_INDEX Y7761_pgtype9[] = {0xFF01,1319,0xFFFF};
EIF_TYPE_INDEX *Y7761_gen_type [10];
EIF_TYPE_INDEX Y7761 [10];
void Y7761_init (void)
{
	egc_routines_types [7761] = Y7761;
	egc_routines_gen_types [7761] = Y7761_gen_type;
	egc_routines_offset [7761] = 1152;
	Y7761_gen_type [0] = Y7761_pgtype0;
	Y7761_gen_type [1] = Y7761_pgtype1;
	Y7761_gen_type [2] = Y7761_pgtype2;
	Y7761_gen_type [3] = Y7761_pgtype3;
	Y7761_gen_type [4] = Y7761_pgtype4;
	Y7761_gen_type [5] = Y7761_pgtype5;
	Y7761_gen_type [6] = Y7761_pgtype6;
	Y7761_gen_type [7] = Y7761_pgtype7;
	Y7761_gen_type [8] = Y7761_pgtype8;
	Y7761_gen_type [9] = Y7761_pgtype9;
	{long i; for (i = 0; i < 3; i++) Y7761[i] = 1319;};
	{long i; for (i = 3; i < 6; i++) Y7761[i] = 1320;};
	Y7761[6] = 1319;
	Y7761[7] = 1321;
	{long i; for (i = 8; i < 10; i++) Y7761[i] = 1319;};
}

long O7763[10];
void O7763_init () {
	{long i; for (i = 0; i < 3; i++) O7763[i] =  + _REFACS_6_;}
	{long i; for (i = 3; i < 6; i++) O7763[i] =  + _REFACS_8_;}
	{long i; for (i = 6; i < 8; i++) O7763[i] =  + _REFACS_6_;}
	{long i; for (i = 8; i < 10; i++) O7763[i] =  + _REFACS_8_;}
}

long O7765[10];
void O7765_init () {
	{long i; for (i = 0; i < 3; i++) O7765[i] =  + _REFACS_8_;}
	{long i; for (i = 3; i < 6; i++) O7765[i] =  + _REFACS_10_;}
	{long i; for (i = 6; i < 8; i++) O7765[i] =  + _REFACS_8_;}
	{long i; for (i = 8; i < 10; i++) O7765[i] =  + _REFACS_10_;}
}

long O7796[10];
void O7796_init () {
	{long i; for (i = 0; i < 2; i++) O7796[i] = + _CHROFF_16_1_;}
	O7796[2] = + _CHROFF_18_1_;
	{long i; for (i = 3; i < 5; i++) O7796[i] = + _CHROFF_27_1_;}
	O7796[5] = + _CHROFF_29_1_;
	O7796[6] = + _CHROFF_18_1_;
	O7796[7] = + _CHROFF_23_1_;
	O7796[8] = + _CHROFF_21_1_;
	O7796[9] = + _CHROFF_22_1_;
}

long O7797[10];
void O7797_init () {
	{long i; for (i = 0; i < 3; i++) O7797[i] =  + _REFACS_9_;}
	{long i; for (i = 3; i < 6; i++) O7797[i] =  + _REFACS_11_;}
	{long i; for (i = 6; i < 8; i++) O7797[i] =  + _REFACS_9_;}
	{long i; for (i = 8; i < 10; i++) O7797[i] =  + _REFACS_11_;}
}

long O7799[10];
void O7799_init () {
	{long i; for (i = 0; i < 3; i++) O7799[i] =  + _REFACS_11_;}
	{long i; for (i = 3; i < 6; i++) O7799[i] =  + _REFACS_13_;}
	{long i; for (i = 6; i < 8; i++) O7799[i] =  + _REFACS_11_;}
	{long i; for (i = 8; i < 10; i++) O7799[i] =  + _REFACS_13_;}
}

long O7807[10];
void O7807_init () {
	{long i; for (i = 0; i < 2; i++) O7807[i] = + _LNGOFF_16_3_0_0_;}
	O7807[2] = + _LNGOFF_18_3_0_0_;
	{long i; for (i = 3; i < 5; i++) O7807[i] = + _LNGOFF_27_5_0_0_;}
	O7807[5] = + _LNGOFF_29_5_0_0_;
	O7807[6] = + _LNGOFF_18_3_0_0_;
	O7807[7] = + _LNGOFF_23_4_0_0_;
	O7807[8] = + _LNGOFF_21_4_0_0_;
	O7807[9] = + _LNGOFF_22_4_0_0_;
}

long O7808[10];
void O7808_init () {
	{long i; for (i = 0; i < 3; i++) O7808[i] =  + _REFACS_14_;}
	{long i; for (i = 3; i < 6; i++) O7808[i] =  + _REFACS_16_;}
	{long i; for (i = 6; i < 8; i++) O7808[i] =  + _REFACS_14_;}
	{long i; for (i = 8; i < 10; i++) O7808[i] =  + _REFACS_16_;}
}

long O7810[10];
void O7810_init () {
	{long i; for (i = 0; i < 2; i++) O7810[i] = + _CHROFF_16_2_;}
	O7810[2] = + _CHROFF_18_2_;
	{long i; for (i = 3; i < 5; i++) O7810[i] = + _CHROFF_27_2_;}
	O7810[5] = + _CHROFF_29_2_;
	O7810[6] = + _CHROFF_18_2_;
	O7810[7] = + _CHROFF_23_2_;
	O7810[8] = + _CHROFF_21_2_;
	O7810[9] = + _CHROFF_22_2_;
}

long O7815[3];
void O7815_init () {
	{long i; for (i = 0; i < 2; i++) O7815[i] = + _CHROFF_27_3_;}
	O7815[2] = + _CHROFF_29_3_;
}

long O7816[3];
void O7816_init () {
	{long i; for (i = 0; i < 2; i++) O7816[i] = + _CHROFF_27_4_;}
	O7816[2] = + _CHROFF_29_4_;
}

static EIF_TYPE_INDEX Y7818_pgtype0[] = {948,0xFF01,1155,0xFFFF};
static EIF_TYPE_INDEX Y7818_pgtype1[] = {948,0xFF01,1156,0xFFFF};
static EIF_TYPE_INDEX Y7818_pgtype2[] = {948,0xFF01,1157,0xFFFF};
EIF_TYPE_INDEX *Y7818_gen_type [3];
EIF_TYPE_INDEX Y7818 [3];
void Y7818_init (void)
{
	egc_routines_types [7818] = Y7818;
	egc_routines_gen_types [7818] = Y7818_gen_type;
	egc_routines_offset [7818] = 1155;
	Y7818_gen_type [0] = Y7818_pgtype0;
	Y7818_gen_type [1] = Y7818_pgtype1;
	Y7818_gen_type [2] = Y7818_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y7818[i] = 948;};
}

long O7850[4];
void O7850_init () {
	{long i; for (i = 0; i < 2; i++) O7850[i] =  + _REFACS_16_;}
	{long i; for (i = 2; i < 4; i++) O7850[i] =  + _REFACS_18_;}
}

long O7851[4];
void O7851_init () {
	{long i; for (i = 0; i < 2; i++) O7851[i] =  + _REFACS_17_;}
	{long i; for (i = 2; i < 4; i++) O7851[i] =  + _REFACS_19_;}
}

long O7867[2];
void O7867_init () {
	O7867[0] = + _CHROFF_21_3_;
	O7867[1] = + _CHROFF_22_3_;
}

long O8638[3];
void O8638_init () {
	O8638[0] = 0;
	{long i; for (i = 1; i < 3; i++) O8638[i] = + _LNGOFF_3_1_0_0_;}
}

long O8640[3];
void O8640_init () {
	O8640[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O8640[i] = 0;}
}

long O8652[3];
void O8652_init () {
	O8652[0] = + _LNGOFF_4_1_0_0_;
	{long i; for (i = 1; i < 3; i++) O8652[i] = + _LNGOFF_3_1_0_1_;}
}

long O8655[3];
void O8655_init () {
	O8655[0] = + _LNGOFF_4_1_0_1_;
	{long i; for (i = 1; i < 3; i++) O8655[i] = + _LNGOFF_3_1_0_2_;}
}

long O8662[3];
void O8662_init () {
	O8662[0] = + _LNGOFF_4_1_0_2_;
	{long i; for (i = 1; i < 3; i++) O8662[i] = + _LNGOFF_3_1_0_3_;}
}

long O8669[3];
void O8669_init () {
	O8669[0] = + _CHROFF_4_0_;
	{long i; for (i = 1; i < 3; i++) O8669[i] = + _CHROFF_3_0_;}
}

long O8670[3];
void O8670_init () {
	O8670[0] = + _LNGOFF_4_1_0_3_;
	{long i; for (i = 1; i < 3; i++) O8670[i] = + _LNGOFF_3_1_0_4_;}
}

long O8671[3];
void O8671_init () {
	O8671[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 3; i++) O8671[i] =  + _REFACS_1_;}
}

long O8672[3];
void O8672_init () {
	O8672[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 3; i++) O8672[i] =  + _REFACS_2_;}
}

long O8681[3];
void O8681_init () {
	O8681[0] = + _LNGOFF_4_1_0_4_;
	{long i; for (i = 1; i < 3; i++) O8681[i] = + _LNGOFF_3_1_0_5_;}
}

long O9124[3];
void O9124_init () {
	O9124[0] = + _CHROFF_2_1_;
	O9124[1] = + _CHROFF_5_1_;
	O9124[2] = + _CHROFF_16_1_;
}

long O9126[3];
void O9126_init () {
	{long i; for (i = 0; i < 2; i++) O9126[i] = 0;}
	O9126[2] =  + _REFACS_1_;
}

long O9127[3];
void O9127_init () {
	{long i; for (i = 0; i < 2; i++) O9127[i] =  + _REFACS_1_;}
	O9127[2] =  + _REFACS_2_;
}

long O9129[3];
void O9129_init () {
	O9129[0] = + _LNGOFF_2_2_0_0_;
	O9129[1] = + _LNGOFF_5_2_0_0_;
	O9129[2] = + _LNGOFF_16_4_0_1_;
}

long O10386[3];
void O10386_init () {
	{long i; for (i = 0; i < 2; i++) O10386[i] = + _CHROFF_6_0_;}
	O10386[2] = + _CHROFF_7_0_;
}

long O10387[3];
void O10387_init () {
	{long i; for (i = 0; i < 2; i++) O10387[i] = + _CHROFF_6_1_;}
	O10387[2] = + _CHROFF_7_1_;
}

long O10397[3];
void O10397_init () {
	{long i; for (i = 0; i < 2; i++) O10397[i] = + _LNGOFF_6_2_0_0_;}
	O10397[2] = + _LNGOFF_7_3_0_0_;
}


#ifdef __cplusplus
}
#endif
