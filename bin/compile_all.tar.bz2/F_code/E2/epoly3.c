#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

EIF_TYPE_INDEX *Y1497_gen_type [2];
EIF_TYPE_INDEX Y1497 [2];
void Y1497_init (void)
{
	egc_routines_types [1497] = Y1497;
	egc_routines_gen_types [1497] = Y1497_gen_type;
	egc_routines_offset [1497] = 108;
	Y1497[0] = 211;
	Y1497[1] = 212;
}

long O1843[2];
void O1843_init () {
	O1843[0] = 0;
	O1843[1] =  + _REFACS_22_;
}

long O1844[2];
void O1844_init () {
	O1844[0] = + _LNGOFF_12_0_0_0_;
	O1844[1] = + _LNGOFF_35_0_0_1_;
}

long O1848[2];
void O1848_init () {
	O1848[0] =  + _REFACS_1_;
	O1848[1] =  + _REFACS_23_;
}

long O1849[2];
void O1849_init () {
	O1849[0] = + _LNGOFF_12_0_0_1_;
	O1849[1] = + _LNGOFF_35_0_0_2_;
}

long O1850[2];
void O1850_init () {
	O1850[0] =  + _REFACS_2_;
	O1850[1] =  + _REFACS_24_;
}

long O1851[2];
void O1851_init () {
	O1851[0] =  + _REFACS_3_;
	O1851[1] =  + _REFACS_25_;
}

long O1852[2];
void O1852_init () {
	O1852[0] =  + _REFACS_4_;
	O1852[1] =  + _REFACS_26_;
}

long O1853[2];
void O1853_init () {
	O1853[0] =  + _REFACS_5_;
	O1853[1] =  + _REFACS_27_;
}

long O1854[2];
void O1854_init () {
	O1854[0] =  + _REFACS_6_;
	O1854[1] =  + _REFACS_28_;
}

long O1855[2];
void O1855_init () {
	O1855[0] =  + _REFACS_7_;
	O1855[1] =  + _REFACS_29_;
}

long O1856[2];
void O1856_init () {
	O1856[0] = + _LNGOFF_12_0_0_2_;
	O1856[1] = + _LNGOFF_35_0_0_3_;
}

long O1860[2];
void O1860_init () {
	O1860[0] =  + _REFACS_8_;
	O1860[1] =  + _REFACS_30_;
}

long O1861[2];
void O1861_init () {
	O1861[0] = + _LNGOFF_12_0_0_3_;
	O1861[1] = + _LNGOFF_35_0_0_4_;
}

long O1862[2];
void O1862_init () {
	O1862[0] =  + _REFACS_9_;
	O1862[1] =  + _REFACS_31_;
}

long O1863[2];
void O1863_init () {
	O1863[0] =  + _REFACS_10_;
	O1863[1] =  + _REFACS_32_;
}

long O1864[2];
void O1864_init () {
	O1864[0] =  + _REFACS_11_;
	O1864[1] =  + _REFACS_33_;
}

long O1941[3];
void O1941_init () {
	O1941[0] = + _CHROFF_2_0_;
	O1941[1] = + _CHROFF_4_0_;
	O1941[2] = + _CHROFF_6_0_;
}

long O1946[3];
void O1946_init () {
	O1946[0] = + _LNGOFF_2_1_0_0_;
	O1946[1] = + _LNGOFF_4_2_0_0_;
	O1946[2] = + _LNGOFF_6_2_0_2_;
}

long O1950[2];
void O1950_init () {
	O1950[0] = + _CHROFF_4_1_;
	O1950[1] = + _CHROFF_6_1_;
}

long O2464[7];
void O2464_init () {
	O2464[0] = 0;
	O2464[1] = + _I64OFF_0_0_0_0_0_0_0_;
	O2464[2] = + _CHROFF_0_0_;
	{long i; for (i = 3; i < 5; i++) O2464[i] = + _LNGOFF_0_0_0_0_;}
	O2464[5] = 0;
	O2464[6] = + _LNGOFF_1_0_0_0_;
}

long O2468[2];
void O2468_init () {
	O2468[0] =  + _REFACS_1_;
	O2468[1] = 0;
}

long O2548[3];
void O2548_init () {
	O2548[0] = + _CHROFF_3_0_;
	O2548[1] = + _CHROFF_5_0_;
	O2548[2] = + _CHROFF_4_0_;
}

long O2625[3];
void O2625_init () {
	O2625[0] = + _LNGOFF_1_0_0_0_;
	O2625[1] = + _LNGOFF_2_0_0_0_;
	O2625[2] = + _LNGOFF_1_0_0_0_;
}

long O2629[3];
void O2629_init () {
	O2629[0] = + _LNGOFF_1_0_0_1_;
	O2629[1] = + _LNGOFF_2_0_0_1_;
	O2629[2] = + _LNGOFF_1_0_0_1_;
}

long O2754[1118];
void O2754_init () {
	O2754[0] = + _R64OFF_0_0_0_1_0_0_0_0_;
	{long i; for (i = 1111; i < 1113; i++) O2754[i] = + _R64OFF_0_0_0_1_0_0_0_0_;}
	O2754[1115] = + _R64OFF_0_0_0_2_0_0_0_0_;
	O2754[1116] = + _R64OFF_5_1_0_8_0_0_0_0_;
	O2754[1117] = + _R64OFF_2_0_0_2_0_0_0_0_;
}

long O2755[1118];
void O2755_init () {
	O2755[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 1111; i < 1113; i++) O2755[i] = + _LNGOFF_0_0_0_0_;}
	O2755[1115] = + _LNGOFF_0_0_0_0_;
	O2755[1116] = + _LNGOFF_5_1_0_0_;
	O2755[1117] = + _LNGOFF_2_0_0_0_;
}

static EIF_TYPE_INDEX Y2787_pgtype0[] = {0xFF01,226,0xFFFF};
static EIF_TYPE_INDEX Y2787_pgtype1[] = {0xFF01,1338,0xFFFF};
EIF_TYPE_INDEX *Y2787_gen_type [1115];
EIF_TYPE_INDEX Y2787 [1115];
void Y2787_init (void)
{
	egc_routines_types [2787] = Y2787;
	egc_routines_gen_types [2787] = Y2787_gen_type;
	egc_routines_offset [2787] = 229;
	Y2787_gen_type [0] = Y2787_pgtype0;
	Y2787_gen_type [1114] = Y2787_pgtype1;
	Y2787[0] = 226;
	Y2787[1114] = 1338;
}

static EIF_TYPE_INDEX Y2788_pgtype0[] = {0xFF01,494,0xFFFF};
static EIF_TYPE_INDEX Y2788_pgtype1[] = {0xFF01,1340,0xFFFF};
EIF_TYPE_INDEX *Y2788_gen_type [1115];
EIF_TYPE_INDEX Y2788 [1115];
void Y2788_init (void)
{
	egc_routines_types [2788] = Y2788;
	egc_routines_gen_types [2788] = Y2788_gen_type;
	egc_routines_offset [2788] = 229;
	Y2788_gen_type [0] = Y2788_pgtype0;
	Y2788_gen_type [1114] = Y2788_pgtype1;
	Y2788[0] = 494;
	Y2788[1114] = 1340;
}

long O2802[207];
void O2802_init () {
	O2802[0] = + _PTROFF_1_1_0_0_0_0_;
	O2802[1] = + _PTROFF_3_2_0_1_0_0_;
	{long i; for (i = 202; i < 205; i++) O2802[i] = + _PTROFF_3_2_0_2_0_0_;}
	O2802[206] = + _PTROFF_3_3_0_2_0_0_;
}

long O2803[207];
void O2803_init () {
	O2803[0] = + _CHROFF_1_0_;
	O2803[1] = + _CHROFF_3_0_;
	{long i; for (i = 202; i < 205; i++) O2803[i] = + _CHROFF_3_0_;}
	O2803[206] = + _CHROFF_3_1_;
}

long O2818[207];
void O2818_init () {
	{long i; for (i = 0; i < 2; i++) O2818[i] = 0;}
	{long i; for (i = 202; i < 205; i++) O2818[i] = 0;}
	O2818[206] =  + _REFACS_1_;
}

long O2854[60];
void O2854_init () {
	O2854[0] = 0;
	O2854[1] =  + _REFACS_1_;
	O2854[59] = 0;
}

long O2855[60];
void O2855_init () {
	O2855[0] =  + _REFACS_1_;
	O2855[1] =  + _REFACS_2_;
	O2855[59] =  + _REFACS_1_;
}

long O3183[4];
void O3183_init () {
	O3183[0] = + _CHROFF_2_0_;
	O3183[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O3183[i] = + _CHROFF_2_0_;}
}

long O3184[4];
void O3184_init () {
	O3184[0] = + _CHROFF_2_1_;
	O3184[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O3184[i] = + _CHROFF_2_1_;}
}

long O4349[568];
void O4349_init () {
	O4349[0] = + _CHROFF_4_0_;
	O4349[1] = + _CHROFF_7_0_;
	O4349[567] = + _CHROFF_26_0_;
}

long O4350[568];
void O4350_init () {
	O4350[0] = + _CHROFF_4_1_;
	O4350[1] = + _CHROFF_7_1_;
	O4350[567] = + _CHROFF_26_1_;
}

long O4351[568];
void O4351_init () {
	O4351[0] = + _CHROFF_4_2_;
	O4351[1] = + _CHROFF_7_2_;
	O4351[567] = + _CHROFF_26_2_;
}

long O4467[758];
void O4467_init () {
	{long i; for (i = 0; i < 11; i++) O4467[i] = 0;}
	{long i; for (i = 748; i < 758; i++) O4467[i] =  + _REFACS_1_;}
}

static EIF_TYPE_INDEX Y4515_pgtype0[] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype1[] = {0xFF01,1141,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype2[] = {0xFF01,1142,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype3[] = {0xFF01,1143,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype4[] = {0xFF01,1144,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype5[] = {0xFF01,1145,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype6[] = {0xFF01,1146,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype7[] = {0xFF01,1147,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype8[] = {0xFF01,1148,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype9[] = {0xFF01,1149,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype10[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype11[] = {0xFF01,1151,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype12[] = {0xFF01,1148,1237,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype13[] = {0xFF01,1148,1237,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype14[] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype15[] = {0xFF01,1141,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype16[] = {0xFF01,1142,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype17[] = {0xFF01,1143,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype18[] = {0xFF01,1144,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype19[] = {0xFF01,1145,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype20[] = {0xFF01,1146,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype21[] = {0xFF01,1147,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype22[] = {0xFF01,1148,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype23[] = {0xFF01,1149,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype24[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype25[] = {0xFF01,1151,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype26[] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype27[] = {0xFF01,1141,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype28[] = {0xFF01,1142,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype29[] = {0xFF01,1144,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype30[] = {0xFF01,1145,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype31[] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype32[] = {0xFF01,1141,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype33[] = {0xFF01,1142,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype34[] = {0xFF01,1143,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype35[] = {0xFF01,1144,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype36[] = {0xFF01,1145,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype37[] = {0xFF01,1146,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype38[] = {0xFF01,1147,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype39[] = {0xFF01,1148,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype40[] = {0xFF01,1149,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype41[] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype42[] = {0xFF01,1151,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype43[] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype44[] = {0xFF01,1140,0xFF01,1300,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype45[] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype46[] = {0xFF01,1142,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype47[] = {0xFF01,1140,0xFF01,964,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype48[] = {0xFF01,1144,1034,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype49[] = {0xFF01,1144,1034,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype50[] = {0xFF01,1146,1031,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype51[] = {0xFF01,1144,1034,0xFFFF};
static EIF_TYPE_INDEX Y4515_pgtype52[] = {0xFF01,1144,1034,0xFFFF};
EIF_TYPE_INDEX *Y4515_gen_type [937];
EIF_TYPE_INDEX Y4515 [937];
void Y4515_init (void)
{
	egc_routines_types [4515] = Y4515;
	egc_routines_gen_types [4515] = Y4515_gen_type;
	egc_routines_offset [4515] = 415;
	Y4515_gen_type [0] = Y4515_pgtype0;
	Y4515_gen_type [1] = Y4515_pgtype1;
	Y4515_gen_type [2] = Y4515_pgtype2;
	Y4515_gen_type [3] = Y4515_pgtype3;
	Y4515_gen_type [4] = Y4515_pgtype4;
	Y4515_gen_type [5] = Y4515_pgtype5;
	Y4515_gen_type [6] = Y4515_pgtype6;
	Y4515_gen_type [7] = Y4515_pgtype7;
	Y4515_gen_type [8] = Y4515_pgtype8;
	Y4515_gen_type [9] = Y4515_pgtype9;
	Y4515_gen_type [10] = Y4515_pgtype10;
	Y4515_gen_type [11] = Y4515_pgtype11;
	Y4515_gen_type [17] = Y4515_pgtype12;
	Y4515_gen_type [18] = Y4515_pgtype13;
	Y4515_gen_type [463] = Y4515_pgtype14;
	Y4515_gen_type [464] = Y4515_pgtype15;
	Y4515_gen_type [465] = Y4515_pgtype16;
	Y4515_gen_type [466] = Y4515_pgtype17;
	Y4515_gen_type [467] = Y4515_pgtype18;
	Y4515_gen_type [468] = Y4515_pgtype19;
	Y4515_gen_type [469] = Y4515_pgtype20;
	Y4515_gen_type [470] = Y4515_pgtype21;
	Y4515_gen_type [471] = Y4515_pgtype22;
	Y4515_gen_type [472] = Y4515_pgtype23;
	Y4515_gen_type [473] = Y4515_pgtype24;
	Y4515_gen_type [474] = Y4515_pgtype25;
	Y4515_gen_type [475] = Y4515_pgtype26;
	Y4515_gen_type [476] = Y4515_pgtype27;
	Y4515_gen_type [477] = Y4515_pgtype28;
	Y4515_gen_type [478] = Y4515_pgtype29;
	Y4515_gen_type [479] = Y4515_pgtype30;
	Y4515_gen_type [533] = Y4515_pgtype31;
	Y4515_gen_type [534] = Y4515_pgtype32;
	Y4515_gen_type [535] = Y4515_pgtype33;
	Y4515_gen_type [536] = Y4515_pgtype34;
	Y4515_gen_type [537] = Y4515_pgtype35;
	Y4515_gen_type [538] = Y4515_pgtype36;
	Y4515_gen_type [539] = Y4515_pgtype37;
	Y4515_gen_type [540] = Y4515_pgtype38;
	Y4515_gen_type [541] = Y4515_pgtype39;
	Y4515_gen_type [542] = Y4515_pgtype40;
	Y4515_gen_type [543] = Y4515_pgtype41;
	Y4515_gen_type [544] = Y4515_pgtype42;
	Y4515_gen_type [545] = Y4515_pgtype43;
	Y4515_gen_type [546] = Y4515_pgtype44;
	Y4515_gen_type [547] = Y4515_pgtype45;
	Y4515_gen_type [548] = Y4515_pgtype46;
	Y4515_gen_type [549] = Y4515_pgtype47;
	Y4515_gen_type [667] = Y4515_pgtype48;
	Y4515_gen_type [668] = Y4515_pgtype49;
	Y4515_gen_type [671] = Y4515_pgtype50;
	Y4515_gen_type [935] = Y4515_pgtype51;
	Y4515_gen_type [936] = Y4515_pgtype52;
	Y4515[0] = 1140;
	Y4515[1] = 1141;
	Y4515[2] = 1142;
	Y4515[3] = 1143;
	Y4515[4] = 1144;
	Y4515[5] = 1145;
	Y4515[6] = 1146;
	Y4515[7] = 1147;
	Y4515[8] = 1148;
	Y4515[9] = 1149;
	Y4515[10] = 1150;
	Y4515[11] = 1151;
	{long i; for (i = 17; i < 19; i++) Y4515[i] = 1148;};
	Y4515[463] = 1140;
	Y4515[464] = 1141;
	Y4515[465] = 1142;
	Y4515[466] = 1143;
	Y4515[467] = 1144;
	Y4515[468] = 1145;
	Y4515[469] = 1146;
	Y4515[470] = 1147;
	Y4515[471] = 1148;
	Y4515[472] = 1149;
	Y4515[473] = 1150;
	Y4515[474] = 1151;
	Y4515[475] = 1140;
	Y4515[476] = 1141;
	Y4515[477] = 1142;
	Y4515[478] = 1144;
	Y4515[479] = 1145;
	Y4515[533] = 1140;
	Y4515[534] = 1141;
	Y4515[535] = 1142;
	Y4515[536] = 1143;
	Y4515[537] = 1144;
	Y4515[538] = 1145;
	Y4515[539] = 1146;
	Y4515[540] = 1147;
	Y4515[541] = 1148;
	Y4515[542] = 1149;
	Y4515[543] = 1150;
	Y4515[544] = 1151;
	{long i; for (i = 545; i < 548; i++) Y4515[i] = 1140;};
	Y4515[548] = 1142;
	Y4515[549] = 1140;
	{long i; for (i = 667; i < 669; i++) Y4515[i] = 1144;};
	Y4515[671] = 1146;
	{long i; for (i = 935; i < 937; i++) Y4515[i] = 1144;};
}

long O4639[27];
void O4639_init () {
	O4639[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 1; i < 4; i++) O4639[i] = + _LNGOFF_3_2_0_1_;}
	O4639[4] = + _LNGOFF_0_0_0_0_;
	O4639[5] = + _LNGOFF_3_3_0_1_;
	{long i; for (i = 6; i < 8; i++) O4639[i] = + _LNGOFF_0_0_0_0_;}
	O4639[13] = + _LNGOFF_15_11_0_0_;
	O4639[24] = + _LNGOFF_13_16_0_0_;
	O4639[26] = + _LNGOFF_21_18_0_0_;
}

long O5211[854];
void O5211_init () {
	O5211[0] = + _CHROFF_1_0_;
	O5211[1] = + _CHROFF_2_0_;
	O5211[362] = + _CHROFF_3_0_;
	O5211[363] = + _CHROFF_4_0_;
	O5211[364] = + _CHROFF_5_0_;
	O5211[795] = + _CHROFF_5_0_;
	{long i; for (i = 845; i < 848; i++) O5211[i] = + _CHROFF_5_0_;}
	O5211[849] = + _CHROFF_7_1_;
	{long i; for (i = 850; i < 854; i++) O5211[i] = + _CHROFF_6_1_;}
}

long O5213[854];
void O5213_init () {
	O5213[0] = + _LNGOFF_1_3_2_1_;
	O5213[1] = + _LNGOFF_2_7_2_3_;
	O5213[362] = + _LNGOFF_3_6_2_1_;
	O5213[363] = + _LNGOFF_4_6_2_1_;
	O5213[364] = + _LNGOFF_5_7_2_1_;
	O5213[795] = + _LNGOFF_5_7_2_1_;
	{long i; for (i = 845; i < 848; i++) O5213[i] = + _LNGOFF_5_6_2_1_;}
	O5213[849] = + _LNGOFF_7_8_2_1_;
	{long i; for (i = 850; i < 854; i++) O5213[i] = + _LNGOFF_6_7_2_1_;}
}


#ifdef __cplusplus
}
#endif
