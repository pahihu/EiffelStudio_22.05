#include "epoly7.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5799[500])();
void R5799_init () {
	R5799[0] = (char *(*)()) F852_6759;
	R5799[1] = (char *(*)()) F853_6759;
	R5799[2] = (char *(*)()) F854_6759;
	R5799[3] = (char *(*)()) F855_6759;
	R5799[4] = (char *(*)()) F856_6759;
	R5799[5] = (char *(*)()) F857_6759;
	R5799[6] = (char *(*)()) F858_6759;
	R5799[7] = (char *(*)()) F859_6759;
	{long i; for (i = 8; i < 10; i++) R5799[i] = (char *(*)()) F852_6759;}
	R5799[10] = (char *(*)()) F854_6759;
	R5799[11] = (char *(*)()) F855_6759;
	R5799[12] = (char *(*)()) F856_6759;
	R5799[13] = (char *(*)()) F858_6759;
	R5799[26] = (char *(*)()) F878_6861;
	R5799[27] = (char *(*)()) F879_6912;
	R5799[28] = (char *(*)()) F880_6912;
	R5799[29] = (char *(*)()) F881_6912;
	R5799[30] = (char *(*)()) F882_6912;
	R5799[31] = (char *(*)()) F883_6912;
	R5799[32] = (char *(*)()) F884_6912;
	R5799[33] = (char *(*)()) F885_6912;
	R5799[34] = (char *(*)()) F886_6912;
	R5799[35] = (char *(*)()) F887_6912;
	R5799[36] = (char *(*)()) F888_6912;
	R5799[37] = (char *(*)()) F889_6912;
	R5799[38] = (char *(*)()) F890_6912;
	R5799[92] = (char *(*)()) F896_6963;
	R5799[93] = (char *(*)()) F898_6963;
	R5799[94] = (char *(*)()) F896_6963;
	R5799[95] = (char *(*)()) F898_6963;
	R5799[96] = (char *(*)()) F896_6963;
	R5799[97] = (char *(*)()) F949_7098;
	R5799[98] = (char *(*)()) F950_7098;
	R5799[99] = (char *(*)()) F951_7098;
	R5799[100] = (char *(*)()) F952_7098;
	R5799[101] = (char *(*)()) F953_7098;
	R5799[102] = (char *(*)()) F954_7098;
	R5799[103] = (char *(*)()) F955_7098;
	R5799[104] = (char *(*)()) F956_7098;
	R5799[105] = (char *(*)()) F957_7098;
	R5799[106] = (char *(*)()) F958_7098;
	R5799[107] = (char *(*)()) F959_7098;
	R5799[108] = (char *(*)()) F960_7098;
	{long i; for (i = 109; i < 112; i++) R5799[i] = (char *(*)()) F949_7098;}
	R5799[112] = (char *(*)()) F951_7098;
	R5799[113] = (char *(*)()) F949_7098;
	R5799[174] = (char *(*)()) F1026_7835;
	{long i; for (i = 230; i < 232; i++) R5799[i] = (char *(*)()) F1078_8177;}
	{long i; for (i = 234; i < 236; i++) R5799[i] = (char *(*)()) F1078_8177;}
	R5799[289] = (char *(*)()) F1141_9222;
	R5799[290] = (char *(*)()) F1142_9222;
	R5799[291] = (char *(*)()) F1143_9222;
	R5799[292] = (char *(*)()) F1144_9222;
	R5799[293] = (char *(*)()) F1145_9222;
	R5799[294] = (char *(*)()) F1146_9222;
	R5799[295] = (char *(*)()) F1147_9222;
	R5799[296] = (char *(*)()) F1148_9222;
	R5799[297] = (char *(*)()) F1149_9222;
	R5799[298] = (char *(*)()) F1150_9222;
	R5799[299] = (char *(*)()) F1151_9222;
	R5799[300] = (char *(*)()) F1152_9222;
	R5799[499] = (char *(*)()) F1078_8177;
}

char *(*R5800[14])();
void R5800_init () {
	R5800[0] = (char *(*)()) F852_6721;
	R5800[1] = (char *(*)()) F853_6721;
	R5800[2] = (char *(*)()) F854_6721;
	R5800[3] = (char *(*)()) F855_6721;
	R5800[4] = (char *(*)()) F856_6721;
	R5800[5] = (char *(*)()) F857_6721;
	R5800[6] = (char *(*)()) F858_6721;
	R5800[7] = (char *(*)()) F859_6721;
	{long i; for (i = 8; i < 10; i++) R5800[i] = (char *(*)()) F852_6721;}
	R5800[10] = (char *(*)()) F854_6721;
	R5800[11] = (char *(*)()) F855_6721;
	R5800[12] = (char *(*)()) F856_6721;
	R5800[13] = (char *(*)()) F858_6721;
}

char *(*R5801[14])();
void R5801_init () {
	R5801[0] = (char *(*)()) F852_6722;
	R5801[1] = (char *(*)()) F853_6722;
	R5801[2] = (char *(*)()) F854_6722;
	R5801[3] = (char *(*)()) F855_6722;
	R5801[4] = (char *(*)()) F856_6722;
	R5801[5] = (char *(*)()) F857_6722;
	R5801[6] = (char *(*)()) F858_6722;
	R5801[7] = (char *(*)()) F859_6722;
	{long i; for (i = 8; i < 10; i++) R5801[i] = (char *(*)()) F852_6722;}
	R5801[10] = (char *(*)()) F854_6722;
	R5801[11] = (char *(*)()) F855_6722;
	R5801[12] = (char *(*)()) F856_6722;
	R5801[13] = (char *(*)()) F858_6722;
}

char *(*R5803[14])();
void R5803_init () {
	R5803[0] = (char *(*)()) F852_6724;
	R5803[1] = (char *(*)()) F853_6724;
	R5803[2] = (char *(*)()) F854_6724;
	R5803[3] = (char *(*)()) F855_6724;
	R5803[4] = (char *(*)()) F856_6724;
	R5803[5] = (char *(*)()) F857_6724;
	R5803[6] = (char *(*)()) F858_6724;
	R5803[7] = (char *(*)()) F859_6724;
	{long i; for (i = 8; i < 10; i++) R5803[i] = (char *(*)()) F852_6724;}
	R5803[10] = (char *(*)()) F854_6724;
	R5803[11] = (char *(*)()) F855_6724;
	R5803[12] = (char *(*)()) F856_6724;
	R5803[13] = (char *(*)()) F858_6724;
}

char *(*R5804[14])();
void R5804_init () {
	R5804[0] = (char *(*)()) F852_6725;
	R5804[1] = (char *(*)()) F853_6725;
	R5804[2] = (char *(*)()) F854_6725_5804_1;
	R5804[3] = (char *(*)()) F855_6725_5804_1;
	R5804[4] = (char *(*)()) F856_6725_5804_1;
	R5804[5] = (char *(*)()) F857_6725_5804_1;
	R5804[6] = (char *(*)()) F858_6725_5804_1;
	R5804[7] = (char *(*)()) F859_6725_5804_1;
	{long i; for (i = 8; i < 10; i++) R5804[i] = (char *(*)()) F852_6725;}
	R5804[10] = (char *(*)()) F854_6725_5804_1;
	R5804[11] = (char *(*)()) F855_6725_5804_1;
	R5804[12] = (char *(*)()) F856_6725_5804_1;
	R5804[13] = (char *(*)()) F858_6725_5804_1;
}
static EIF_REFERENCE F854_6725_5804_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F854_6725(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_6725_5804_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F855_6725(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_6725_5804_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F856_6725(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6725_5804_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F857_6725(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_6725_5804_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F858_6725(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_6725_5804_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F859_6725(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y5805_pgtype0[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5805_pgtype1[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5805_pgtype2[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5805_pgtype3[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5805_pgtype4[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5805_pgtype5[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5805_pgtype6[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5805_pgtype7[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5805_pgtype8[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5805_pgtype9[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5805_pgtype10[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5805_pgtype11[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5805_pgtype12[] = {0xFF02,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5805_gen_type [14];
EIF_TYPE_INDEX Y5805 [14];
void Y5805_init (void)
{
	egc_routines_types [5805] = Y5805;
	egc_routines_gen_types [5805] = Y5805_gen_type;
	egc_routines_offset [5805] = 851;
	Y5805_gen_type [0] = Y5805_pgtype0;
	Y5805_gen_type [1] = Y5805_pgtype1;
	Y5805_gen_type [2] = Y5805_pgtype2;
	Y5805_gen_type [3] = Y5805_pgtype3;
	Y5805_gen_type [4] = Y5805_pgtype4;
	Y5805_gen_type [5] = Y5805_pgtype5;
	Y5805_gen_type [6] = Y5805_pgtype6;
	Y5805_gen_type [7] = Y5805_pgtype7;
	Y5805_gen_type [9] = Y5805_pgtype8;
	Y5805_gen_type [10] = Y5805_pgtype9;
	Y5805_gen_type [11] = Y5805_pgtype10;
	Y5805_gen_type [12] = Y5805_pgtype11;
	Y5805_gen_type [13] = Y5805_pgtype12;
	Y5805[8] = 0;
}

char *(*R5809[14])();
void R5809_init () {
	R5809[0] = (char *(*)()) F852_6733;
	R5809[1] = (char *(*)()) F853_6733;
	R5809[2] = (char *(*)()) F854_6733_5809_1;
	R5809[3] = (char *(*)()) F855_6733_5809_1;
	R5809[4] = (char *(*)()) F856_6733_5809_1;
	R5809[5] = (char *(*)()) F857_6733_5809_1;
	R5809[6] = (char *(*)()) F858_6733_5809_1;
	R5809[7] = (char *(*)()) F859_6733_5809_1;
	{long i; for (i = 8; i < 10; i++) R5809[i] = (char *(*)()) F852_6733;}
	R5809[10] = (char *(*)()) F854_6733_5809_1;
	R5809[11] = (char *(*)()) F855_6733_5809_1;
	R5809[12] = (char *(*)()) F856_6733_5809_1;
	R5809[13] = (char *(*)()) F858_6733_5809_1;
}
static EIF_REFERENCE F854_6733_5809_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F854_6733(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_6733_5809_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F855_6733(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_6733_5809_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F856_6733(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6733_5809_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F857_6733(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_6733_5809_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F858_6733(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_6733_5809_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F859_6733(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y5809_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5809_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5809_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5809_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5809_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5809_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5809_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5809_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5809_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5809_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5809_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5809_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5809_pgtype12[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5809_gen_type [14];
EIF_TYPE_INDEX Y5809 [14];
void Y5809_init (void)
{
	egc_routines_types [5809] = Y5809;
	egc_routines_gen_types [5809] = Y5809_gen_type;
	egc_routines_offset [5809] = 851;
	Y5809_gen_type [0] = Y5809_pgtype0;
	Y5809_gen_type [1] = Y5809_pgtype1;
	Y5809_gen_type [2] = Y5809_pgtype2;
	Y5809_gen_type [3] = Y5809_pgtype3;
	Y5809_gen_type [4] = Y5809_pgtype4;
	Y5809_gen_type [5] = Y5809_pgtype5;
	Y5809_gen_type [6] = Y5809_pgtype6;
	Y5809_gen_type [7] = Y5809_pgtype7;
	Y5809_gen_type [9] = Y5809_pgtype8;
	Y5809_gen_type [10] = Y5809_pgtype9;
	Y5809_gen_type [11] = Y5809_pgtype10;
	Y5809_gen_type [12] = Y5809_pgtype11;
	Y5809_gen_type [13] = Y5809_pgtype12;
	Y5809[8] = 0;
}

char *(*R5812[14])();
void R5812_init () {
	R5812[0] = (char *(*)()) F852_6738;
	R5812[1] = (char *(*)()) F853_6738_5812_48;
	R5812[2] = (char *(*)()) F854_6738;
	R5812[3] = (char *(*)()) F855_6738;
	R5812[4] = (char *(*)()) F856_6738;
	R5812[5] = (char *(*)()) F857_6738_5812_48;
	R5812[6] = (char *(*)()) F858_6738;
	R5812[7] = (char *(*)()) F859_6738;
	R5812[8] = (char *(*)()) F852_6738;
	R5812[9] = (char *(*)()) F861_6847;
	R5812[10] = (char *(*)()) F862_6847;
	R5812[11] = (char *(*)()) F863_6847;
	R5812[12] = (char *(*)()) F864_6847;
	R5812[13] = (char *(*)()) F865_6847;
}
static EIF_INTEGER_32 F853_6738_5812_48 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F853_6738(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F857_6738_5812_48 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F857_6738(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5814[14])();
void R5814_init () {
	R5814[0] = (char *(*)()) F852_6745;
	R5814[1] = (char *(*)()) F853_6745_5814_3;
	R5814[2] = (char *(*)()) F854_6745;
	R5814[3] = (char *(*)()) F855_6745;
	R5814[4] = (char *(*)()) F856_6745;
	R5814[5] = (char *(*)()) F857_6745_5814_3;
	R5814[6] = (char *(*)()) F858_6745;
	R5814[7] = (char *(*)()) F859_6745;
	R5814[8] = (char *(*)()) F852_6745;
	R5814[9] = (char *(*)()) F861_6849;
	R5814[10] = (char *(*)()) F862_6849;
	R5814[11] = (char *(*)()) F863_6849;
	R5814[12] = (char *(*)()) F864_6849;
	R5814[13] = (char *(*)()) F865_6849;
}
static EIF_BOOLEAN F853_6745_5814_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F853_6745(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F857_6745_5814_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F857_6745(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R5820[14])();
void R5820_init () {
	R5820[0] = (char *(*)()) F852_6753;
	R5820[1] = (char *(*)()) F853_6753;
	R5820[2] = (char *(*)()) F854_6753;
	R5820[3] = (char *(*)()) F855_6753;
	R5820[4] = (char *(*)()) F856_6753;
	R5820[5] = (char *(*)()) F857_6753;
	R5820[6] = (char *(*)()) F858_6753;
	R5820[7] = (char *(*)()) F859_6753;
	{long i; for (i = 8; i < 10; i++) R5820[i] = (char *(*)()) F852_6753;}
	R5820[10] = (char *(*)()) F854_6753;
	R5820[11] = (char *(*)()) F855_6753;
	R5820[12] = (char *(*)()) F856_6753;
	R5820[13] = (char *(*)()) F858_6753;
}

char *(*R5821[14])();
void R5821_init () {
	R5821[0] = (char *(*)()) F852_6754;
	R5821[1] = (char *(*)()) F853_6754;
	R5821[2] = (char *(*)()) F854_6754;
	R5821[3] = (char *(*)()) F855_6754;
	R5821[4] = (char *(*)()) F856_6754;
	R5821[5] = (char *(*)()) F857_6754;
	R5821[6] = (char *(*)()) F858_6754;
	R5821[7] = (char *(*)()) F859_6754;
	{long i; for (i = 8; i < 10; i++) R5821[i] = (char *(*)()) F852_6754;}
	R5821[10] = (char *(*)()) F854_6754;
	R5821[11] = (char *(*)()) F855_6754;
	R5821[12] = (char *(*)()) F856_6754;
	R5821[13] = (char *(*)()) F858_6754;
}

char *(*R5823[14])();
void R5823_init () {
	R5823[0] = (char *(*)()) F852_6756;
	R5823[1] = (char *(*)()) F853_6756;
	R5823[2] = (char *(*)()) F854_6756;
	R5823[3] = (char *(*)()) F855_6756;
	R5823[4] = (char *(*)()) F856_6756;
	R5823[5] = (char *(*)()) F857_6756;
	R5823[6] = (char *(*)()) F858_6756;
	R5823[7] = (char *(*)()) F859_6756;
	{long i; for (i = 8; i < 10; i++) R5823[i] = (char *(*)()) F852_6756;}
	R5823[10] = (char *(*)()) F854_6756;
	R5823[11] = (char *(*)()) F855_6756;
	R5823[12] = (char *(*)()) F856_6756;
	R5823[13] = (char *(*)()) F858_6756;
}

char *(*R5826[14])();
void R5826_init () {
	R5826[0] = (char *(*)()) F852_6760;
	R5826[1] = (char *(*)()) F853_6760;
	R5826[2] = (char *(*)()) F854_6760;
	R5826[3] = (char *(*)()) F855_6760;
	R5826[4] = (char *(*)()) F856_6760;
	R5826[5] = (char *(*)()) F857_6760;
	R5826[6] = (char *(*)()) F858_6760;
	R5826[7] = (char *(*)()) F859_6760;
	{long i; for (i = 8; i < 10; i++) R5826[i] = (char *(*)()) F852_6760;}
	R5826[10] = (char *(*)()) F854_6760;
	R5826[11] = (char *(*)()) F855_6760;
	R5826[12] = (char *(*)()) F856_6760;
	R5826[13] = (char *(*)()) F858_6760;
}

char *(*R5827[14])();
void R5827_init () {
	R5827[0] = (char *(*)()) F852_6761;
	R5827[1] = (char *(*)()) F853_6761;
	R5827[2] = (char *(*)()) F854_6761;
	R5827[3] = (char *(*)()) F855_6761;
	R5827[4] = (char *(*)()) F856_6761;
	R5827[5] = (char *(*)()) F857_6761;
	R5827[6] = (char *(*)()) F858_6761;
	R5827[7] = (char *(*)()) F859_6761;
	{long i; for (i = 8; i < 10; i++) R5827[i] = (char *(*)()) F852_6761;}
	R5827[10] = (char *(*)()) F854_6761;
	R5827[11] = (char *(*)()) F855_6761;
	R5827[12] = (char *(*)()) F856_6761;
	R5827[13] = (char *(*)()) F858_6761;
}

char *(*R5829[14])();
void R5829_init () {
	R5829[0] = (char *(*)()) F852_6763;
	R5829[1] = (char *(*)()) F853_6763_5829_4;
	R5829[2] = (char *(*)()) F854_6763;
	R5829[3] = (char *(*)()) F855_6763;
	R5829[4] = (char *(*)()) F856_6763;
	R5829[5] = (char *(*)()) F857_6763_5829_4;
	R5829[6] = (char *(*)()) F858_6763;
	R5829[7] = (char *(*)()) F859_6763;
	{long i; for (i = 8; i < 10; i++) R5829[i] = (char *(*)()) F852_6763;}
	R5829[10] = (char *(*)()) F854_6763;
	R5829[11] = (char *(*)()) F855_6763;
	R5829[12] = (char *(*)()) F856_6763;
	R5829[13] = (char *(*)()) F858_6763;
}
static void F853_6763_5829_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F853_6763(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F857_6763_5829_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_6763(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5831[14])();
void R5831_init () {
	R5831[0] = (char *(*)()) F852_6765;
	R5831[1] = (char *(*)()) F853_6765;
	R5831[2] = (char *(*)()) F854_6765;
	R5831[3] = (char *(*)()) F855_6765;
	R5831[4] = (char *(*)()) F856_6765;
	R5831[5] = (char *(*)()) F857_6765;
	R5831[6] = (char *(*)()) F858_6765;
	R5831[7] = (char *(*)()) F859_6765;
	{long i; for (i = 8; i < 10; i++) R5831[i] = (char *(*)()) F852_6765;}
	R5831[10] = (char *(*)()) F854_6765;
	R5831[11] = (char *(*)()) F855_6765;
	R5831[12] = (char *(*)()) F856_6765;
	R5831[13] = (char *(*)()) F858_6765;
}

char *(*R5832[14])();
void R5832_init () {
	R5832[0] = (char *(*)()) F852_6766;
	R5832[1] = (char *(*)()) F853_6766;
	R5832[2] = (char *(*)()) F854_6766;
	R5832[3] = (char *(*)()) F855_6766;
	R5832[4] = (char *(*)()) F856_6766;
	R5832[5] = (char *(*)()) F857_6766;
	R5832[6] = (char *(*)()) F858_6766;
	R5832[7] = (char *(*)()) F859_6766;
	{long i; for (i = 8; i < 10; i++) R5832[i] = (char *(*)()) F852_6766;}
	R5832[10] = (char *(*)()) F854_6766;
	R5832[11] = (char *(*)()) F855_6766;
	R5832[12] = (char *(*)()) F856_6766;
	R5832[13] = (char *(*)()) F858_6766;
}

char *(*R5838[14])();
void R5838_init () {
	R5838[0] = (char *(*)()) F852_6779;
	R5838[1] = (char *(*)()) F853_6779;
	R5838[2] = (char *(*)()) F854_6779;
	R5838[3] = (char *(*)()) F855_6779;
	R5838[4] = (char *(*)()) F856_6779;
	R5838[5] = (char *(*)()) F857_6779;
	R5838[6] = (char *(*)()) F858_6779;
	R5838[7] = (char *(*)()) F859_6779;
	R5838[8] = (char *(*)()) F852_6779;
	R5838[9] = (char *(*)()) F861_6851;
	R5838[10] = (char *(*)()) F862_6851;
	R5838[11] = (char *(*)()) F863_6851;
	R5838[12] = (char *(*)()) F864_6851;
	R5838[13] = (char *(*)()) F865_6851;
}

char *(*R5847[14])();
void R5847_init () {
	R5847[0] = (char *(*)()) F852_6789;
	R5847[1] = (char *(*)()) F853_6789;
	R5847[2] = (char *(*)()) F854_6789;
	R5847[3] = (char *(*)()) F855_6789;
	R5847[4] = (char *(*)()) F856_6789;
	R5847[5] = (char *(*)()) F857_6789;
	R5847[6] = (char *(*)()) F858_6789;
	R5847[7] = (char *(*)()) F859_6789;
	{long i; for (i = 8; i < 10; i++) R5847[i] = (char *(*)()) F852_6789;}
	R5847[10] = (char *(*)()) F854_6789;
	R5847[11] = (char *(*)()) F855_6789;
	R5847[12] = (char *(*)()) F856_6789;
	R5847[13] = (char *(*)()) F858_6789;
}

char *(*R5848[14])();
void R5848_init () {
	R5848[0] = (char *(*)()) F852_6790;
	R5848[1] = (char *(*)()) F853_6790;
	R5848[2] = (char *(*)()) F854_6790;
	R5848[3] = (char *(*)()) F855_6790;
	R5848[4] = (char *(*)()) F856_6790;
	R5848[5] = (char *(*)()) F857_6790;
	R5848[6] = (char *(*)()) F858_6790;
	R5848[7] = (char *(*)()) F859_6790;
	{long i; for (i = 8; i < 10; i++) R5848[i] = (char *(*)()) F852_6790;}
	R5848[10] = (char *(*)()) F854_6790;
	R5848[11] = (char *(*)()) F855_6790;
	R5848[12] = (char *(*)()) F856_6790;
	R5848[13] = (char *(*)()) F858_6790;
}

char *(*R5855[14])();
void R5855_init () {
	R5855[0] = (char *(*)()) F852_6797;
	R5855[1] = (char *(*)()) F853_6797;
	R5855[2] = (char *(*)()) F854_6797_5855_1;
	R5855[3] = (char *(*)()) F855_6797_5855_1;
	R5855[4] = (char *(*)()) F856_6797_5855_1;
	R5855[5] = (char *(*)()) F857_6797_5855_1;
	R5855[6] = (char *(*)()) F858_6797_5855_1;
	R5855[7] = (char *(*)()) F859_6797_5855_1;
	{long i; for (i = 8; i < 10; i++) R5855[i] = (char *(*)()) F852_6797;}
	R5855[10] = (char *(*)()) F854_6797_5855_1;
	R5855[11] = (char *(*)()) F855_6797_5855_1;
	R5855[12] = (char *(*)()) F856_6797_5855_1;
	R5855[13] = (char *(*)()) F858_6797_5855_1;
}
static EIF_REFERENCE F854_6797_5855_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F854_6797(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_6797_5855_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F855_6797(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_6797_5855_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F856_6797(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6797_5855_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F857_6797(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_6797_5855_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F858_6797(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_6797_5855_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F859_6797(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5856[14])();
void R5856_init () {
	R5856[0] = (char *(*)()) F852_6798;
	R5856[1] = (char *(*)()) F853_6798_5856_1;
	R5856[2] = (char *(*)()) F854_6798;
	R5856[3] = (char *(*)()) F855_6798;
	R5856[4] = (char *(*)()) F856_6798;
	R5856[5] = (char *(*)()) F857_6798_5856_1;
	R5856[6] = (char *(*)()) F858_6798;
	R5856[7] = (char *(*)()) F859_6798;
	{long i; for (i = 8; i < 10; i++) R5856[i] = (char *(*)()) F852_6798;}
	R5856[10] = (char *(*)()) F854_6798;
	R5856[11] = (char *(*)()) F855_6798;
	R5856[12] = (char *(*)()) F856_6798;
	R5856[13] = (char *(*)()) F858_6798;
}
static EIF_REFERENCE F853_6798_5856_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F853_6798(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6798_5856_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F857_6798(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5857[14])();
void R5857_init () {
	R5857[0] = (char *(*)()) F852_6799;
	R5857[1] = (char *(*)()) F853_6799;
	R5857[2] = (char *(*)()) F854_6799;
	R5857[3] = (char *(*)()) F855_6799;
	R5857[4] = (char *(*)()) F856_6799;
	R5857[5] = (char *(*)()) F857_6799;
	R5857[6] = (char *(*)()) F858_6799;
	R5857[7] = (char *(*)()) F859_6799;
	{long i; for (i = 8; i < 10; i++) R5857[i] = (char *(*)()) F852_6799;}
	R5857[10] = (char *(*)()) F854_6799;
	R5857[11] = (char *(*)()) F855_6799;
	R5857[12] = (char *(*)()) F856_6799;
	R5857[13] = (char *(*)()) F858_6799;
}

char *(*R5858[14])();
void R5858_init () {
	R5858[0] = (char *(*)()) F852_6800;
	R5858[1] = (char *(*)()) F853_6800;
	R5858[2] = (char *(*)()) F854_6800;
	R5858[3] = (char *(*)()) F855_6800;
	R5858[4] = (char *(*)()) F856_6800;
	R5858[5] = (char *(*)()) F857_6800;
	R5858[6] = (char *(*)()) F858_6800;
	R5858[7] = (char *(*)()) F859_6800;
	{long i; for (i = 8; i < 10; i++) R5858[i] = (char *(*)()) F852_6800;}
	R5858[10] = (char *(*)()) F854_6800;
	R5858[11] = (char *(*)()) F855_6800;
	R5858[12] = (char *(*)()) F856_6800;
	R5858[13] = (char *(*)()) F858_6800;
}

char *(*R5859[14])();
void R5859_init () {
	R5859[0] = (char *(*)()) F852_6801;
	R5859[1] = (char *(*)()) F853_6801;
	R5859[2] = (char *(*)()) F854_6801;
	R5859[3] = (char *(*)()) F855_6801;
	R5859[4] = (char *(*)()) F856_6801;
	R5859[5] = (char *(*)()) F857_6801;
	R5859[6] = (char *(*)()) F858_6801;
	R5859[7] = (char *(*)()) F859_6801;
	{long i; for (i = 8; i < 10; i++) R5859[i] = (char *(*)()) F852_6801;}
	R5859[10] = (char *(*)()) F854_6801;
	R5859[11] = (char *(*)()) F855_6801;
	R5859[12] = (char *(*)()) F856_6801;
	R5859[13] = (char *(*)()) F858_6801;
}

char *(*R5860[14])();
void R5860_init () {
	R5860[0] = (char *(*)()) F852_6802;
	R5860[1] = (char *(*)()) F853_6802;
	R5860[2] = (char *(*)()) F854_6802;
	R5860[3] = (char *(*)()) F855_6802;
	R5860[4] = (char *(*)()) F856_6802;
	R5860[5] = (char *(*)()) F857_6802;
	R5860[6] = (char *(*)()) F858_6802;
	R5860[7] = (char *(*)()) F859_6802;
	{long i; for (i = 8; i < 10; i++) R5860[i] = (char *(*)()) F852_6802;}
	R5860[10] = (char *(*)()) F854_6802;
	R5860[11] = (char *(*)()) F855_6802;
	R5860[12] = (char *(*)()) F856_6802;
	R5860[13] = (char *(*)()) F858_6802;
}

char *(*R5861[14])();
void R5861_init () {
	R5861[0] = (char *(*)()) F852_6803;
	R5861[1] = (char *(*)()) F853_6803;
	R5861[2] = (char *(*)()) F854_6803;
	R5861[3] = (char *(*)()) F855_6803;
	R5861[4] = (char *(*)()) F856_6803;
	R5861[5] = (char *(*)()) F857_6803;
	R5861[6] = (char *(*)()) F858_6803;
	R5861[7] = (char *(*)()) F859_6803;
	{long i; for (i = 8; i < 10; i++) R5861[i] = (char *(*)()) F852_6803;}
	R5861[10] = (char *(*)()) F854_6803;
	R5861[11] = (char *(*)()) F855_6803;
	R5861[12] = (char *(*)()) F856_6803;
	R5861[13] = (char *(*)()) F858_6803;
}

char *(*R5863[14])();
void R5863_init () {
	R5863[0] = (char *(*)()) F852_6805;
	R5863[1] = (char *(*)()) F853_6805;
	R5863[2] = (char *(*)()) F854_6805;
	R5863[3] = (char *(*)()) F855_6805;
	R5863[4] = (char *(*)()) F856_6805;
	R5863[5] = (char *(*)()) F857_6805;
	R5863[6] = (char *(*)()) F858_6805;
	R5863[7] = (char *(*)()) F859_6805;
	{long i; for (i = 8; i < 10; i++) R5863[i] = (char *(*)()) F852_6805;}
	R5863[10] = (char *(*)()) F854_6805;
	R5863[11] = (char *(*)()) F855_6805;
	R5863[12] = (char *(*)()) F856_6805;
	R5863[13] = (char *(*)()) F858_6805;
}

char *(*R5864[14])();
void R5864_init () {
	R5864[0] = (char *(*)()) F852_6806;
	R5864[1] = (char *(*)()) F853_6806;
	R5864[2] = (char *(*)()) F854_6806;
	R5864[3] = (char *(*)()) F855_6806;
	R5864[4] = (char *(*)()) F856_6806;
	R5864[5] = (char *(*)()) F857_6806;
	R5864[6] = (char *(*)()) F858_6806;
	R5864[7] = (char *(*)()) F859_6806;
	{long i; for (i = 8; i < 10; i++) R5864[i] = (char *(*)()) F852_6806;}
	R5864[10] = (char *(*)()) F854_6806;
	R5864[11] = (char *(*)()) F855_6806;
	R5864[12] = (char *(*)()) F856_6806;
	R5864[13] = (char *(*)()) F858_6806;
}

char *(*R5865[14])();
void R5865_init () {
	R5865[0] = (char *(*)()) F852_6807;
	R5865[1] = (char *(*)()) F853_6807;
	R5865[2] = (char *(*)()) F854_6807;
	R5865[3] = (char *(*)()) F855_6807;
	R5865[4] = (char *(*)()) F856_6807;
	R5865[5] = (char *(*)()) F857_6807;
	R5865[6] = (char *(*)()) F858_6807;
	R5865[7] = (char *(*)()) F859_6807;
	{long i; for (i = 8; i < 10; i++) R5865[i] = (char *(*)()) F852_6807;}
	R5865[10] = (char *(*)()) F854_6807;
	R5865[11] = (char *(*)()) F855_6807;
	R5865[12] = (char *(*)()) F856_6807;
	R5865[13] = (char *(*)()) F858_6807;
}

char *(*R5869[14])();
void R5869_init () {
	R5869[0] = (char *(*)()) F852_6811;
	R5869[1] = (char *(*)()) F853_6811_5869_4;
	R5869[2] = (char *(*)()) F854_6811;
	R5869[3] = (char *(*)()) F855_6811;
	R5869[4] = (char *(*)()) F856_6811;
	R5869[5] = (char *(*)()) F857_6811_5869_4;
	R5869[6] = (char *(*)()) F858_6811;
	R5869[7] = (char *(*)()) F859_6811;
	{long i; for (i = 8; i < 10; i++) R5869[i] = (char *(*)()) F852_6811;}
	R5869[10] = (char *(*)()) F854_6811;
	R5869[11] = (char *(*)()) F855_6811;
	R5869[12] = (char *(*)()) F856_6811;
	R5869[13] = (char *(*)()) F858_6811;
}
static void F853_6811_5869_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F853_6811(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F857_6811_5869_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_6811(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5870[14])();
void R5870_init () {
	R5870[0] = (char *(*)()) F852_6812;
	R5870[1] = (char *(*)()) F853_6812_5870_4;
	R5870[2] = (char *(*)()) F854_6812;
	R5870[3] = (char *(*)()) F855_6812;
	R5870[4] = (char *(*)()) F856_6812;
	R5870[5] = (char *(*)()) F857_6812_5870_4;
	R5870[6] = (char *(*)()) F858_6812;
	R5870[7] = (char *(*)()) F859_6812;
	{long i; for (i = 8; i < 10; i++) R5870[i] = (char *(*)()) F852_6812;}
	R5870[10] = (char *(*)()) F854_6812;
	R5870[11] = (char *(*)()) F855_6812;
	R5870[12] = (char *(*)()) F856_6812;
	R5870[13] = (char *(*)()) F858_6812;
}
static void F853_6812_5870_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F853_6812(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F857_6812_5870_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_6812(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5875[14])();
void R5875_init () {
	R5875[0] = (char *(*)()) F852_6817;
	R5875[1] = (char *(*)()) F853_6817;
	R5875[2] = (char *(*)()) F854_6817;
	R5875[3] = (char *(*)()) F855_6817;
	R5875[4] = (char *(*)()) F856_6817;
	R5875[5] = (char *(*)()) F857_6817;
	R5875[6] = (char *(*)()) F858_6817;
	R5875[7] = (char *(*)()) F859_6817;
	{long i; for (i = 8; i < 10; i++) R5875[i] = (char *(*)()) F852_6817;}
	R5875[10] = (char *(*)()) F854_6817;
	R5875[11] = (char *(*)()) F855_6817;
	R5875[12] = (char *(*)()) F856_6817;
	R5875[13] = (char *(*)()) F858_6817;
}

char *(*R5888[14])();
void R5888_init () {
	R5888[0] = (char *(*)()) F852_6830;
	R5888[1] = (char *(*)()) F853_6830;
	R5888[2] = (char *(*)()) F854_6830;
	R5888[3] = (char *(*)()) F855_6830;
	R5888[4] = (char *(*)()) F856_6830;
	R5888[5] = (char *(*)()) F857_6830;
	R5888[6] = (char *(*)()) F858_6830;
	R5888[7] = (char *(*)()) F859_6830;
	{long i; for (i = 8; i < 10; i++) R5888[i] = (char *(*)()) F852_6830;}
	R5888[10] = (char *(*)()) F854_6830;
	R5888[11] = (char *(*)()) F855_6830;
	R5888[12] = (char *(*)()) F856_6830;
	R5888[13] = (char *(*)()) F858_6830;
}

char *(*R5901[5])();
void R5901_init () {
	R5901[0] = (char *(*)()) F861_6845;
	R5901[1] = (char *(*)()) F862_6845;
	R5901[2] = (char *(*)()) F863_6845;
	R5901[3] = (char *(*)()) F864_6845;
	R5901[4] = (char *(*)()) F865_6845;
}

char *(*R5927[12])();
void R5927_init () {
	R5927[0] = (char *(*)()) F879_6895;
	R5927[1] = (char *(*)()) F880_6895;
	R5927[2] = (char *(*)()) F881_6895;
	R5927[3] = (char *(*)()) F882_6895;
	R5927[4] = (char *(*)()) F883_6895;
	R5927[5] = (char *(*)()) F884_6895;
	R5927[6] = (char *(*)()) F885_6895;
	R5927[7] = (char *(*)()) F886_6895;
	R5927[8] = (char *(*)()) F887_6895;
	R5927[9] = (char *(*)()) F888_6895;
	R5927[10] = (char *(*)()) F889_6895;
	R5927[11] = (char *(*)()) F890_6895;
}

char *(*R5951[12])();
void R5951_init () {
	R5951[0] = (char *(*)()) F879_6937;
	R5951[1] = (char *(*)()) F880_6937_5951_20;
	R5951[2] = (char *(*)()) F881_6937_5951_20;
	R5951[3] = (char *(*)()) F882_6937_5951_20;
	R5951[4] = (char *(*)()) F883_6937_5951_20;
	R5951[5] = (char *(*)()) F884_6937_5951_20;
	R5951[6] = (char *(*)()) F885_6937_5951_20;
	R5951[7] = (char *(*)()) F886_6937_5951_20;
	R5951[8] = (char *(*)()) F887_6937_5951_20;
	R5951[9] = (char *(*)()) F888_6937_5951_20;
	R5951[10] = (char *(*)()) F889_6937_5951_20;
	R5951[11] = (char *(*)()) F890_6937_5951_20;
}
static void F880_6937_5951_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F880_6937(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F881_6937_5951_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F881_6937(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F882_6937_5951_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F882_6937(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F883_6937_5951_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F883_6937(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F884_6937_5951_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F884_6937(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F885_6937_5951_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F885_6937(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F886_6937_5951_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F886_6937(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F887_6937_5951_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F887_6937(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F888_6937_5951_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F888_6937(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F889_6937_5951_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F889_6937(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F890_6937_5951_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F890_6937(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R5958[12])();
void R5958_init () {
	R5958[0] = (char *(*)()) F879_6949;
	R5958[1] = (char *(*)()) F880_6949;
	R5958[2] = (char *(*)()) F881_6949;
	R5958[3] = (char *(*)()) F882_6949;
	R5958[4] = (char *(*)()) F883_6949;
	R5958[5] = (char *(*)()) F884_6949;
	R5958[6] = (char *(*)()) F885_6949;
	R5958[7] = (char *(*)()) F886_6949;
	R5958[8] = (char *(*)()) F887_6949;
	R5958[9] = (char *(*)()) F888_6949;
	R5958[10] = (char *(*)()) F889_6949;
	R5958[11] = (char *(*)()) F890_6949;
}

char *(*R5962[22])();
void R5962_init () {
	R5962[0] = (char *(*)()) F944_7004;
	R5962[1] = (char *(*)()) F945_7004_5962_1;
	R5962[2] = (char *(*)()) F944_7004;
	R5962[3] = (char *(*)()) F945_7004_5962_1;
	R5962[4] = (char *(*)()) F944_7004;
	R5962[5] = (char *(*)()) F949_7079;
	R5962[6] = (char *(*)()) F950_7079_5962_1;
	R5962[7] = (char *(*)()) F951_7079_5962_1;
	R5962[8] = (char *(*)()) F952_7079_5962_1;
	R5962[9] = (char *(*)()) F953_7079_5962_1;
	R5962[10] = (char *(*)()) F954_7079_5962_1;
	R5962[11] = (char *(*)()) F955_7079_5962_1;
	R5962[12] = (char *(*)()) F956_7079_5962_1;
	R5962[13] = (char *(*)()) F957_7079_5962_1;
	R5962[14] = (char *(*)()) F958_7079_5962_1;
	R5962[15] = (char *(*)()) F959_7079_5962_1;
	R5962[16] = (char *(*)()) F960_7079_5962_1;
	{long i; for (i = 17; i < 20; i++) R5962[i] = (char *(*)()) F949_7079;}
	R5962[20] = (char *(*)()) F951_7079_5962_1;
	R5962[21] = (char *(*)()) F949_7079;
}
static EIF_REFERENCE F945_7004_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F945_7004(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F950_7079_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F950_7079(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_7079_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F951_7079(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_7079_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F952_7079(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7079_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F953_7079(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7079_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F954_7079(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7079_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F955_7079(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7079_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F956_7079(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1234, 0x00).id, 1234, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7079_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F957_7079(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F958_7079_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F958_7079(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7079_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F959_7079(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7079_5962_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F960_7079(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5963[22])();
void R5963_init () {
	R5963[0] = (char *(*)()) F944_7005;
	R5963[1] = (char *(*)()) F945_7005_5963_1;
	R5963[2] = (char *(*)()) F944_7005;
	R5963[3] = (char *(*)()) F945_7005_5963_1;
	R5963[4] = (char *(*)()) F944_7005;
	R5963[5] = (char *(*)()) F949_7080;
	R5963[6] = (char *(*)()) F950_7080_5963_1;
	R5963[7] = (char *(*)()) F951_7080_5963_1;
	R5963[8] = (char *(*)()) F952_7080_5963_1;
	R5963[9] = (char *(*)()) F953_7080_5963_1;
	R5963[10] = (char *(*)()) F954_7080_5963_1;
	R5963[11] = (char *(*)()) F955_7080_5963_1;
	R5963[12] = (char *(*)()) F956_7080_5963_1;
	R5963[13] = (char *(*)()) F957_7080_5963_1;
	R5963[14] = (char *(*)()) F958_7080_5963_1;
	R5963[15] = (char *(*)()) F959_7080_5963_1;
	R5963[16] = (char *(*)()) F960_7080_5963_1;
	{long i; for (i = 17; i < 20; i++) R5963[i] = (char *(*)()) F949_7080;}
	R5963[20] = (char *(*)()) F951_7080_5963_1;
	R5963[21] = (char *(*)()) F949_7080;
}
static EIF_REFERENCE F945_7005_5963_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F945_7005(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F950_7080_5963_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F950_7080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_7080_5963_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F951_7080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_7080_5963_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F952_7080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7080_5963_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F953_7080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7080_5963_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F954_7080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7080_5963_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F955_7080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7080_5963_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F956_7080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1234, 0x00).id, 1234, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7080_5963_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F957_7080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F958_7080_5963_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F958_7080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7080_5963_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F959_7080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7080_5963_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F960_7080(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5964[5])();
void R5964_init () {
	R5964[0] = (char *(*)()) F944_7024;
	R5964[1] = (char *(*)()) F945_7024;
	R5964[2] = (char *(*)()) F944_7024;
	R5964[3] = (char *(*)()) F945_7024;
	R5964[4] = (char *(*)()) F944_7024;
}

char *(*R5965[22])();
void R5965_init () {
	R5965[0] = (char *(*)()) F944_7025;
	R5965[1] = (char *(*)()) F945_7025;
	R5965[2] = (char *(*)()) F944_7025;
	R5965[3] = (char *(*)()) F945_7025;
	R5965[4] = (char *(*)()) F944_7025;
	R5965[5] = (char *(*)()) F949_7106;
	R5965[6] = (char *(*)()) F950_7106;
	R5965[7] = (char *(*)()) F951_7106;
	R5965[8] = (char *(*)()) F952_7106;
	R5965[9] = (char *(*)()) F953_7106;
	R5965[10] = (char *(*)()) F954_7106;
	R5965[11] = (char *(*)()) F955_7106;
	R5965[12] = (char *(*)()) F956_7106;
	R5965[13] = (char *(*)()) F957_7106;
	R5965[14] = (char *(*)()) F958_7106;
	R5965[15] = (char *(*)()) F959_7106;
	R5965[16] = (char *(*)()) F960_7106;
	{long i; for (i = 17; i < 20; i++) R5965[i] = (char *(*)()) F949_7106;}
	R5965[20] = (char *(*)()) F951_7106;
	R5965[21] = (char *(*)()) F949_7106;
}

char *(*R5966[22])();
void R5966_init () {
	R5966[0] = (char *(*)()) F944_7015;
	R5966[1] = (char *(*)()) F945_7015;
	R5966[2] = (char *(*)()) F944_7015;
	R5966[3] = (char *(*)()) F945_7015;
	R5966[4] = (char *(*)()) F944_7015;
	R5966[5] = (char *(*)()) F896_6964;
	R5966[6] = (char *(*)()) F897_6964;
	R5966[7] = (char *(*)()) F898_6964;
	R5966[8] = (char *(*)()) F899_6964;
	R5966[9] = (char *(*)()) F900_6964;
	R5966[10] = (char *(*)()) F901_6964;
	R5966[11] = (char *(*)()) F902_6964;
	R5966[12] = (char *(*)()) F903_6964;
	R5966[13] = (char *(*)()) F904_6964;
	R5966[14] = (char *(*)()) F905_6964;
	R5966[15] = (char *(*)()) F906_6964;
	R5966[16] = (char *(*)()) F907_6964;
	{long i; for (i = 17; i < 20; i++) R5966[i] = (char *(*)()) F896_6964;}
	R5966[20] = (char *(*)()) F898_6964;
	R5966[21] = (char *(*)()) F896_6964;
}

char *(*R5967[22])();
void R5967_init () {
	R5967[0] = (char *(*)()) F944_7016;
	R5967[1] = (char *(*)()) F945_7016;
	R5967[2] = (char *(*)()) F944_7016;
	R5967[3] = (char *(*)()) F945_7016;
	R5967[4] = (char *(*)()) F944_7016;
	R5967[5] = (char *(*)()) F896_6965;
	R5967[6] = (char *(*)()) F897_6965;
	R5967[7] = (char *(*)()) F898_6965;
	R5967[8] = (char *(*)()) F899_6965;
	R5967[9] = (char *(*)()) F900_6965;
	R5967[10] = (char *(*)()) F901_6965;
	R5967[11] = (char *(*)()) F902_6965;
	R5967[12] = (char *(*)()) F903_6965;
	R5967[13] = (char *(*)()) F904_6965;
	R5967[14] = (char *(*)()) F905_6965;
	R5967[15] = (char *(*)()) F906_6965;
	R5967[16] = (char *(*)()) F907_6965;
	{long i; for (i = 17; i < 20; i++) R5967[i] = (char *(*)()) F896_6965;}
	R5967[20] = (char *(*)()) F898_6965;
	R5967[21] = (char *(*)()) F896_6965;
}

char *(*R5972[5])();
void R5972_init () {
	R5972[0] = (char *(*)()) F944_7027;
	R5972[1] = (char *(*)()) F945_7027_5972_4;
	R5972[2] = (char *(*)()) F944_7027;
	R5972[3] = (char *(*)()) F945_7027_5972_4;
	R5972[4] = (char *(*)()) F944_7027;
}
static void F945_7027_5972_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F945_7027(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5983[5])();
void R5983_init () {
	R5983[0] = (char *(*)()) F944_7040;
	R5983[1] = (char *(*)()) F945_7040_5983_5;
	R5983[2] = (char *(*)()) F944_7040;
	R5983[3] = (char *(*)()) F945_7040_5983_5;
	R5983[4] = (char *(*)()) F944_7040;
}
static EIF_REFERENCE F945_7040_5983_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F945_7040(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5984[5])();
void R5984_init () {
	R5984[0] = (char *(*)()) F944_7041;
	R5984[1] = (char *(*)()) F945_7041;
	R5984[2] = (char *(*)()) F944_7041;
	R5984[3] = (char *(*)()) F945_7041;
	R5984[4] = (char *(*)()) F944_7041;
}

char *(*R5987[5])();
void R5987_init () {
	R5987[0] = (char *(*)()) F944_7044;
	R5987[1] = (char *(*)()) F945_7044;
	R5987[2] = (char *(*)()) F944_7044;
	R5987[3] = (char *(*)()) F945_7044;
	R5987[4] = (char *(*)()) F944_7044;
}

char *(*R5988[5])();
void R5988_init () {
	R5988[0] = (char *(*)()) F944_7045;
	R5988[1] = (char *(*)()) F945_7045;
	R5988[2] = (char *(*)()) F944_7045;
	R5988[3] = (char *(*)()) F945_7045;
	R5988[4] = (char *(*)()) F944_7045;
}

char *(*R5989[5])();
void R5989_init () {
	R5989[0] = (char *(*)()) F944_7046;
	R5989[1] = (char *(*)()) F945_7046;
	R5989[2] = (char *(*)()) F944_7046;
	R5989[3] = (char *(*)()) F945_7046;
	R5989[4] = (char *(*)()) F944_7046;
}

char *(*R5994[2])();
void R5994_init () {
	R5994[0] = (char *(*)()) F944_7003;
	R5994[1] = (char *(*)()) F945_7003_5994_1;
}
static EIF_REFERENCE F945_7003_5994_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F945_7003(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5995[2])();
void R5995_init () {
	R5995[0] = (char *(*)()) F944_7034;
	R5995[1] = (char *(*)()) F945_7034;
}

char *(*R5999[17])();
void R5999_init () {
	R5999[0] = (char *(*)()) F949_7071;
	R5999[1] = (char *(*)()) F950_7071;
	R5999[2] = (char *(*)()) F951_7071;
	R5999[3] = (char *(*)()) F952_7071;
	R5999[4] = (char *(*)()) F953_7071;
	R5999[5] = (char *(*)()) F954_7071;
	R5999[6] = (char *(*)()) F955_7071;
	R5999[7] = (char *(*)()) F956_7071;
	R5999[8] = (char *(*)()) F957_7071;
	R5999[9] = (char *(*)()) F958_7071;
	R5999[10] = (char *(*)()) F959_7071;
	R5999[11] = (char *(*)()) F960_7071;
	R5999[12] = (char *(*)()) F949_7071;
	R5999[13] = (char *(*)()) F962_7147;
	R5999[14] = (char *(*)()) F949_7071;
	R5999[15] = (char *(*)()) F951_7071;
	R5999[16] = (char *(*)()) F965_7162;
}

char *(*R6003[17])();
void R6003_init () {
	R6003[0] = (char *(*)()) F949_7075;
	R6003[1] = (char *(*)()) F950_7075;
	R6003[2] = (char *(*)()) F951_7075;
	R6003[3] = (char *(*)()) F952_7075;
	R6003[4] = (char *(*)()) F953_7075;
	R6003[5] = (char *(*)()) F954_7075;
	R6003[6] = (char *(*)()) F955_7075;
	R6003[7] = (char *(*)()) F956_7075;
	R6003[8] = (char *(*)()) F957_7075;
	R6003[9] = (char *(*)()) F958_7075;
	R6003[10] = (char *(*)()) F959_7075;
	R6003[11] = (char *(*)()) F960_7075;
	{long i; for (i = 12; i < 15; i++) R6003[i] = (char *(*)()) F949_7075;}
	R6003[15] = (char *(*)()) F951_7075;
	R6003[16] = (char *(*)()) F949_7075;
}

char *(*R6007[17])();
void R6007_init () {
	R6007[0] = (char *(*)()) F949_7094;
	R6007[1] = (char *(*)()) F950_7094;
	R6007[2] = (char *(*)()) F951_7094;
	R6007[3] = (char *(*)()) F952_7094;
	R6007[4] = (char *(*)()) F953_7094;
	R6007[5] = (char *(*)()) F954_7094;
	R6007[6] = (char *(*)()) F955_7094;
	R6007[7] = (char *(*)()) F956_7094;
	R6007[8] = (char *(*)()) F957_7094;
	R6007[9] = (char *(*)()) F958_7094;
	R6007[10] = (char *(*)()) F959_7094;
	R6007[11] = (char *(*)()) F960_7094;
	{long i; for (i = 12; i < 15; i++) R6007[i] = (char *(*)()) F949_7094;}
	R6007[15] = (char *(*)()) F951_7094;
	R6007[16] = (char *(*)()) F949_7094;
}

char *(*R6019[2])();
void R6019_init () {
	R6019[0] = (char *(*)()) F949_7112;
	R6019[1] = (char *(*)()) F951_7112_6019_4;
}
static void F951_7112_6019_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F951_7112(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6020[2])();
void R6020_init () {
	R6020[0] = (char *(*)()) F949_7125;
	R6020[1] = (char *(*)()) F951_7125;
}

char *(*R6163[2])();
void R6163_init () {
	R6163[0] = (char *(*)()) F970_7310;
	R6163[1] = (char *(*)()) F971_7415;
}

char *(*R6169[2])();
void R6169_init () {
	R6169[0] = (char *(*)()) F970_7316;
	R6169[1] = (char *(*)()) F971_7416;
}

char *(*R6171[2])();
void R6171_init () {
	R6171[0] = (char *(*)()) F970_7318;
	R6171[1] = (char *(*)()) F971_7417;
}

char *(*R6264[2])();
void R6264_init () {
	R6264[0] = (char *(*)()) F970_7413;
	R6264[1] = (char *(*)()) F971_7442;
}

char *(*R6520[15])();
void R6520_init () {
	R6520[0] = (char *(*)()) F1009_7739;
	R6520[1] = (char *(*)()) F1010_7745;
	R6520[2] = (char *(*)()) F1011_7750;
	R6520[3] = (char *(*)()) F1012_7752;
	R6520[4] = (char *(*)()) F1013_7758;
	R6520[5] = (char *(*)()) F1014_7762;
	R6520[6] = (char *(*)()) F1015_7764;
	{long i; for (i = 7; i < 10; i++) R6520[i] = (char *(*)()) F1016_7771;}
	R6520[10] = (char *(*)()) F1019_7783;
	{long i; for (i = 13; i < 15; i++) R6520[i] = (char *(*)()) F1016_7771;}
}

char *(*R6582[326])();
void R6582_init () {
	R6582[0] = (char *(*)()) F1026_7834;
	{long i; for (i = 1; i < 4; i++) R6582[i] = (char *(*)()) F1027_7947;}
	{long i; for (i = 5; i < 7; i++) R6582[i] = (char *(*)()) F1030_7971;}
	{long i; for (i = 8; i < 10; i++) R6582[i] = (char *(*)()) F1033_8012;}
	{long i; for (i = 11; i < 13; i++) R6582[i] = (char *(*)()) F1036_8060;}
	{long i; for (i = 14; i < 44; i++) R6582[i] = (char *(*)()) F1039_8081;}
	R6582[44] = (char *(*)()) F1070_8107;
	R6582[45] = (char *(*)()) F1071_8107;
	{long i; for (i = 47; i < 52; i++) R6582[i] = (char *(*)()) F1072_8115;}
	{long i; for (i = 56; i < 58; i++) R6582[i] = (char *(*)()) F1078_8174;}
	{long i; for (i = 60; i < 62; i++) R6582[i] = (char *(*)()) F1078_8174;}
	R6582[74] = (char *(*)()) F1100_8946;
	R6582[75] = (char *(*)()) F1101_9079;
	R6582[76] = (char *(*)()) F1102_9126;
	R6582[78] = (char *(*)()) F1104_9175;
	R6582[79] = (char *(*)()) F1105_9175;
	R6582[80] = (char *(*)()) F1106_9175;
	R6582[81] = (char *(*)()) F1107_9175;
	R6582[82] = (char *(*)()) F1108_9175;
	R6582[83] = (char *(*)()) F1109_9175;
	R6582[84] = (char *(*)()) F1110_9175;
	R6582[85] = (char *(*)()) F1111_9175;
	R6582[86] = (char *(*)()) F1112_9175;
	R6582[87] = (char *(*)()) F1113_9175;
	R6582[88] = (char *(*)()) F1114_9175;
	R6582[89] = (char *(*)()) F1115_9175;
	R6582[90] = (char *(*)()) F1116_9175;
	R6582[91] = (char *(*)()) F1117_9175;
	R6582[92] = (char *(*)()) F1118_9175;
	R6582[93] = (char *(*)()) F1119_9175;
	R6582[94] = (char *(*)()) F1120_9175;
	R6582[95] = (char *(*)()) F1121_9175;
	R6582[96] = (char *(*)()) F1122_9175;
	R6582[97] = (char *(*)()) F1123_9175;
	R6582[98] = (char *(*)()) F1124_9175;
	R6582[99] = (char *(*)()) F1125_9175;
	R6582[100] = (char *(*)()) F1126_9175;
	R6582[101] = (char *(*)()) F1127_9175;
	R6582[102] = (char *(*)()) F1128_9175;
	R6582[103] = (char *(*)()) F1129_9175;
	R6582[104] = (char *(*)()) F1130_9175;
	R6582[105] = (char *(*)()) F1131_9175;
	R6582[106] = (char *(*)()) F1132_9175;
	R6582[107] = (char *(*)()) F1133_9175;
	R6582[108] = (char *(*)()) F1134_9175;
	R6582[109] = (char *(*)()) F1135_9175;
	R6582[110] = (char *(*)()) F1136_9175;
	R6582[111] = (char *(*)()) F1137_9175;
	R6582[112] = (char *(*)()) F1138_9175;
	R6582[113] = (char *(*)()) F1139_9175;
	{long i; for (i = 130; i < 133; i++) R6582[i] = (char *(*)()) F1153_9276;}
	{long i; for (i = 134; i < 137; i++) R6582[i] = (char *(*)()) F1153_9276;}
	R6582[184] = (char *(*)()) F1210_9520;
	R6582[185] = (char *(*)()) F1211_9525;
	R6582[186] = (char *(*)()) F1212_9554;
	R6582[187] = (char *(*)()) F1213_9569;
	{long i; for (i = 190; i < 192; i++) R6582[i] = (char *(*)()) F1215_9597;}
	{long i; for (i = 193; i < 195; i++) R6582[i] = (char *(*)()) F1218_9695;}
	{long i; for (i = 196; i < 198; i++) R6582[i] = (char *(*)()) F1221_9794;}
	{long i; for (i = 199; i < 201; i++) R6582[i] = (char *(*)()) F1224_9893;}
	{long i; for (i = 202; i < 204; i++) R6582[i] = (char *(*)()) F1227_9992;}
	{long i; for (i = 205; i < 207; i++) R6582[i] = (char *(*)()) F1230_10086;}
	{long i; for (i = 208; i < 210; i++) R6582[i] = (char *(*)()) F1233_10180;}
	{long i; for (i = 211; i < 213; i++) R6582[i] = (char *(*)()) F1236_10275;}
	{long i; for (i = 214; i < 216; i++) R6582[i] = (char *(*)()) F1239_10370;}
	{long i; for (i = 217; i < 219; i++) R6582[i] = (char *(*)()) F1242_10436;}
	R6582[219] = (char *(*)()) F1245_10518;
	R6582[220] = (char *(*)()) F1246_10556;
	R6582[226] = (char *(*)()) F1252_10564;
	R6582[229] = (char *(*)()) F1255_10603;
	R6582[325] = (char *(*)()) F1351_13241;
}

char *(*R6742[2])();
void R6742_init () {
	R6742[0] = (char *(*)()) F1028_7965;
	R6742[1] = (char *(*)()) F1029_7968;
}

char *(*R6747[2])();
void R6747_init () {
	R6747[0] = (char *(*)()) F1031_8007;
	R6747[1] = (char *(*)()) F1032_8007;
}

char *(*R6871[5])();
void R6871_init () {
	R6871[0] = (char *(*)()) F1073_8152;
	R6871[1] = (char *(*)()) F1074_8155;
	R6871[2] = (char *(*)()) F1075_8155;
	R6871[3] = (char *(*)()) F1076_8155;
	R6871[4] = (char *(*)()) F1075_8155;
}

char *(*R6895[4])();
void R6895_init () {
	R6895[0] = (char *(*)()) F1074_8154;
	R6895[1] = (char *(*)()) F1075_8154_6895_1;
	R6895[2] = (char *(*)()) F1076_8154_6895_1;
	R6895[3] = (char *(*)()) F1075_8154_6895_1;
}
static EIF_REFERENCE F1075_8154_6895_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1075_8154(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1076_8154_6895_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1076_8154(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6896[4])();
void R6896_init () {
	R6896[0] = (char *(*)()) F1074_8156;
	R6896[1] = (char *(*)()) F1075_8156_6896_5;
	R6896[2] = (char *(*)()) F1076_8156_6896_5;
	R6896[3] = (char *(*)()) F1075_8156_6896_5;
}
static EIF_REFERENCE F1075_8156_6896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1075_8156(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1076_8156_6896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1076_8156(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6900[4])();
void R6900_init () {
	R6900[0] = (char *(*)()) F1074_8163;
	R6900[1] = (char *(*)()) F1075_8163_6900_380;
	R6900[2] = (char *(*)()) F1076_8163_6900_380;
	R6900[3] = (char *(*)()) F1075_8163_6900_380;
}
static EIF_REFERENCE F1075_8163_6900_380 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1075_8163(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1076_8163_6900_380 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1076_8163(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y6901_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6901_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6901_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6901_pgtype3[] = {1037,0xFFFF};
EIF_TYPE_INDEX *Y6901_gen_type [4];
EIF_TYPE_INDEX Y6901 [4];
void Y6901_init (void)
{
	egc_routines_types [6901] = Y6901;
	egc_routines_gen_types [6901] = Y6901_gen_type;
	egc_routines_offset [6901] = 1073;
	Y6901_gen_type [0] = Y6901_pgtype0;
	Y6901_gen_type [1] = Y6901_pgtype1;
	Y6901_gen_type [2] = Y6901_pgtype2;
	Y6901_gen_type [3] = Y6901_pgtype3;
	Y6901[3] = 1037;
}

char *(*R6902[270])();
void R6902_init () {
	{long i; for (i = 0; i < 2; i++) R6902[i] = (char *(*)()) F1081_8295;}
	{long i; for (i = 4; i < 6; i++) R6902[i] = (char *(*)()) F1085_8461;}
	R6902[269] = (char *(*)()) F1351_13215;
}

char *(*R6904[270])();
void R6904_init () {
	R6904[0] = (char *(*)()) F1082_8355;
	R6904[1] = (char *(*)()) F1083_8377;
	R6904[4] = (char *(*)()) F1086_8522;
	R6904[5] = (char *(*)()) F1087_8545;
	R6904[269] = (char *(*)()) F1351_13343;
}

char *(*R6905[270])();
void R6905_init () {
	R6905[0] = (char *(*)()) F1082_8354;
	R6905[1] = (char *(*)()) F1083_8376;
	R6905[4] = (char *(*)()) F1086_8520;
	R6905[5] = (char *(*)()) F1087_8543;
	R6905[269] = (char *(*)()) F1083_8376;
}

char *(*R6906[270])();
void R6906_init () {
	{long i; for (i = 0; i < 2; i++) R6906[i] = (char *(*)()) F1078_8168;}
	{long i; for (i = 4; i < 6; i++) R6906[i] = (char *(*)()) F1085_8473;}
	R6906[269] = (char *(*)()) F1078_8168;
}

char *(*R6916[270])();
void R6916_init () {
	{long i; for (i = 0; i < 2; i++) R6916[i] = (char *(*)()) F1081_8326;}
	{long i; for (i = 4; i < 6; i++) R6916[i] = (char *(*)()) F1085_8491;}
	R6916[269] = (char *(*)()) F1081_8326;
}

char *(*R6918[270])();
void R6918_init () {
	{long i; for (i = 0; i < 2; i++) R6918[i] = (char *(*)()) F1081_8328;}
	{long i; for (i = 4; i < 6; i++) R6918[i] = (char *(*)()) F1085_8493;}
	R6918[269] = (char *(*)()) F1081_8328;
}

char *(*R6919[270])();
void R6919_init () {
	R6919[0] = (char *(*)()) F1082_8364;
	R6919[1] = (char *(*)()) F766_6292;
	R6919[4] = (char *(*)()) F1086_8532;
	R6919[5] = (char *(*)()) F768_6292;
	R6919[269] = (char *(*)()) F766_6292;
}

char *(*R6921[270])();
void R6921_init () {
	{long i; for (i = 0; i < 2; i++) R6921[i] = (char *(*)()) F1081_8329;}
	{long i; for (i = 4; i < 6; i++) R6921[i] = (char *(*)()) F1085_8494;}
	R6921[269] = (char *(*)()) F1081_8329;
}

char *(*R6922[270])();
void R6922_init () {
	{long i; for (i = 0; i < 2; i++) R6922[i] = (char *(*)()) F1078_8185;}
	{long i; for (i = 4; i < 6; i++) R6922[i] = (char *(*)()) F1085_8495;}
	R6922[269] = (char *(*)()) F1078_8185;
}

char *(*R6941[270])();
void R6941_init () {
	{long i; for (i = 0; i < 2; i++) R6941[i] = (char *(*)()) F1081_8317;}
	{long i; for (i = 4; i < 6; i++) R6941[i] = (char *(*)()) F1085_8482;}
	R6941[269] = (char *(*)()) F1351_13246;
}

char *(*R6942[270])();
void R6942_init () {
	{long i; for (i = 0; i < 2; i++) R6942[i] = (char *(*)()) F1081_8316;}
	{long i; for (i = 4; i < 6; i++) R6942[i] = (char *(*)()) F1085_8481;}
	R6942[269] = (char *(*)()) F1351_13248;
}

char *(*R6946[270])();
void R6946_init () {
	{long i; for (i = 0; i < 2; i++) R6946[i] = (char *(*)()) F1078_8209;}
	{long i; for (i = 4; i < 6; i++) R6946[i] = (char *(*)()) F1078_8209;}
	R6946[269] = (char *(*)()) F1351_13253;
}

char *(*R6947[270])();
void R6947_init () {
	{long i; for (i = 0; i < 2; i++) R6947[i] = (char *(*)()) F1078_8210;}
	{long i; for (i = 4; i < 6; i++) R6947[i] = (char *(*)()) F1078_8210;}
	R6947[269] = (char *(*)()) F1351_13259;
}

char *(*R6952[270])();
void R6952_init () {
	{long i; for (i = 0; i < 2; i++) R6952[i] = (char *(*)()) F1081_8313;}
	{long i; for (i = 4; i < 6; i++) R6952[i] = (char *(*)()) F1085_8478;}
	R6952[269] = (char *(*)()) F1351_13234;
}

char *(*R6963[270])();
void R6963_init () {
	R6963[0] = (char *(*)()) F1082_8360;
	R6963[1] = (char *(*)()) F1083_8443;
	R6963[4] = (char *(*)()) F1086_8527;
	R6963[5] = (char *(*)()) F1087_8611;
	R6963[269] = (char *(*)()) F1351_13303;
}

char *(*R6964[270])();
void R6964_init () {
	R6964[0] = (char *(*)()) F1082_8361;
	R6964[1] = (char *(*)()) F1083_8444;
	R6964[4] = (char *(*)()) F1086_8528;
	R6964[5] = (char *(*)()) F1087_8612;
	R6964[269] = (char *(*)()) F1351_13304;
}

char *(*R6982[270])();
void R6982_init () {
	R6982[0] = (char *(*)()) F1082_8362;
	R6982[1] = (char *(*)()) F1083_8455;
	R6982[4] = (char *(*)()) F1086_8529;
	R6982[5] = (char *(*)()) F1087_8623;
	R6982[269] = (char *(*)()) F1351_13232;
}

char *(*R6986[270])();
void R6986_init () {
	R6986[0] = (char *(*)()) F1082_8366;
	R6986[1] = (char *(*)()) F1083_8459;
	R6986[4] = (char *(*)()) F1086_8533;
	R6986[5] = (char *(*)()) F1087_8626;
	R6986[269] = (char *(*)()) F1083_8459;
}

char *(*R6997[269])();
void R6997_init () {
	R6997[0] = (char *(*)()) F1083_8457;
	R6997[4] = (char *(*)()) F1087_8625;
	R6997[268] = (char *(*)()) F1083_8457;
}

char *(*R7000[269])();
void R7000_init () {
	R7000[0] = (char *(*)()) F1083_8396;
	R7000[4] = (char *(*)()) F1087_8564;
	R7000[268] = (char *(*)()) F1351_13345;
}

char *(*R7001[269])();
void R7001_init () {
	R7001[0] = (char *(*)()) F1080_8265;
	R7001[4] = (char *(*)()) F1080_8265;
	R7001[268] = (char *(*)()) F1351_13346;
}

char *(*R7012[269])();
void R7012_init () {
	R7012[0] = (char *(*)()) F1083_8407;
	R7012[4] = (char *(*)()) F1087_8575;
	R7012[268] = (char *(*)()) F1351_13268;
}

char *(*R7020[269])();
void R7020_init () {
	R7020[0] = (char *(*)()) F1083_8390;
	R7020[4] = (char *(*)()) F1087_8558;
	R7020[268] = (char *(*)()) F1351_13292;
}

char *(*R7021[269])();
void R7021_init () {
	R7021[0] = (char *(*)()) F1083_8391;
	R7021[4] = (char *(*)()) F1087_8559;
	R7021[268] = (char *(*)()) F1351_13293;
}

char *(*R7022[269])();
void R7022_init () {
	R7022[0] = (char *(*)()) F1083_8392;
	R7022[4] = (char *(*)()) F1087_8560;
	R7022[268] = (char *(*)()) F1351_13341;
}

char *(*R7023[269])();
void R7023_init () {
	R7023[0] = (char *(*)()) F1083_8393;
	R7023[4] = (char *(*)()) F1087_8561;
	R7023[268] = (char *(*)()) F1351_13342;
}

char *(*R7025[269])();
void R7025_init () {
	R7025[0] = (char *(*)()) F1083_8429;
	R7025[4] = (char *(*)()) F1087_8597;
	R7025[268] = (char *(*)()) F1351_13296;
}

char *(*R7026[269])();
void R7026_init () {
	R7026[0] = (char *(*)()) F1083_8430;
	R7026[4] = (char *(*)()) F1087_8598;
	R7026[268] = (char *(*)()) F1351_13294;
}

char *(*R7028[269])();
void R7028_init () {
	R7028[0] = (char *(*)()) F1083_8432;
	R7028[4] = (char *(*)()) F1087_8600;
	R7028[268] = (char *(*)()) F1351_13295;
}

char *(*R7029[269])();
void R7029_init () {
	R7029[0] = (char *(*)()) F1083_8437;
	R7029[4] = (char *(*)()) F1087_8605;
	R7029[268] = (char *(*)()) F1351_13339;
}

char *(*R7030[269])();
void R7030_init () {
	R7030[0] = (char *(*)()) F1083_8440;
	R7030[4] = (char *(*)()) F1087_8608;
	R7030[268] = (char *(*)()) F1083_8440;
}

char *(*R7040[269])();
void R7040_init () {
	R7040[0] = (char *(*)()) F1083_8378;
	R7040[268] = (char *(*)()) F1351_13229;
}


#ifdef __cplusplus
}
#endif
