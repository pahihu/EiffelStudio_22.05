#include "epoly4.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5015[2])();
void R5015_init () {
	R5015[0] = (char *(*)()) F456_5485;
	R5015[1] = (char *(*)()) F457_5488;
}

char *(*R5020[2])();
void R5020_init () {
	R5020[0] = (char *(*)()) F456_5487;
	R5020[1] = (char *(*)()) F457_5490;
}

char *(*R5228[433])();
void R5228_init () {
	{long i; for (i = 0; i < 2; i++) R5228[i] = (char *(*)()) F828_6390;}
	R5228[432] = (char *(*)()) F1261_10656;
}

char *(*R5236[795])();
void R5236_init () {
	R5236[0] = (char *(*)()) F467_5829;
	{long i; for (i = 362; i < 364; i++) R5236[i] = (char *(*)()) F828_6414;}
	R5236[794] = (char *(*)()) F828_6414;
}

char *(*R5238[795])();
void R5238_init () {
	R5238[0] = (char *(*)()) F467_5828;
	{long i; for (i = 362; i < 364; i++) R5238[i] = (char *(*)()) F828_6442;}
	R5238[794] = (char *(*)()) F828_6442;
}

char *(*R5239[433])();
void R5239_init () {
	{long i; for (i = 0; i < 2; i++) R5239[i] = (char *(*)()) F828_6469;}
	R5239[432] = (char *(*)()) F1261_10687;
}

char *(*R5240[433])();
void R5240_init () {
	{long i; for (i = 0; i < 2; i++) R5240[i] = (char *(*)()) F828_6470;}
	R5240[432] = (char *(*)()) F1261_10688;
}

char *(*R5241[795])();
void R5241_init () {
	R5241[0] = (char *(*)()) F467_5874;
	{long i; for (i = 362; i < 364; i++) R5241[i] = (char *(*)()) F828_6464;}
	R5241[794] = (char *(*)()) F1261_10679;
}

char *(*R5243[433])();
void R5243_init () {
	{long i; for (i = 0; i < 2; i++) R5243[i] = (char *(*)()) F828_6467;}
	R5243[432] = (char *(*)()) F1261_10677;
}

char *(*R5271[433])();
void R5271_init () {
	{long i; for (i = 0; i < 2; i++) R5271[i] = (char *(*)()) F828_6497;}
	R5271[432] = (char *(*)()) F1261_10674;
}

char *(*R5273[433])();
void R5273_init () {
	R5273[0] = (char *(*)()) F829_6604;
	R5273[1] = (char *(*)()) F830_6662;
	R5273[432] = (char *(*)()) F830_6662;
}

char *(*R5279[433])();
void R5279_init () {
	R5279[0] = (char *(*)()) F829_6610;
	R5279[1] = (char *(*)()) F830_6671;
	R5279[432] = (char *(*)()) F830_6671;
}

char *(*R5284[433])();
void R5284_init () {
	{long i; for (i = 0; i < 2; i++) R5284[i] = (char *(*)()) F828_6504;}
	R5284[432] = (char *(*)()) F1261_10668;
}

char *(*R5287[433])();
void R5287_init () {
	{long i; for (i = 0; i < 2; i++) R5287[i] = (char *(*)()) F828_6501;}
	R5287[432] = (char *(*)()) F1261_10665;
}

char *(*R5314[282])();
void R5314_init () {
	R5314[0] = (char *(*)()) F480_5916;
	R5314[1] = (char *(*)()) F481_5925_5314_1;
	R5314[2] = (char *(*)()) F482_5932;
	R5314[3] = (char *(*)()) F483_5932_5314_1;
	R5314[4] = (char *(*)()) F484_5932_5314_1;
	R5314[55] = (char *(*)()) F523_6032;
	R5314[56] = (char *(*)()) F524_6032_5314_1;
	R5314[57] = (char *(*)()) F525_6032_5314_1;
	R5314[58] = (char *(*)()) F526_6032_5314_1;
	R5314[59] = (char *(*)()) F527_6032_5314_1;
	R5314[60] = (char *(*)()) F528_6032_5314_1;
	R5314[61] = (char *(*)()) F529_6032_5314_1;
	R5314[62] = (char *(*)()) F530_6032_5314_1;
	R5314[63] = (char *(*)()) F531_6032_5314_1;
	R5314[64] = (char *(*)()) F532_6032_5314_1;
	R5314[65] = (char *(*)()) F533_6032_5314_1;
	R5314[66] = (char *(*)()) F534_6032_5314_1;
	R5314[67] = (char *(*)()) F547_6060;
	R5314[68] = (char *(*)()) F548_6060;
	R5314[69] = (char *(*)()) F549_6060_5314_1;
	R5314[70] = (char *(*)()) F550_6060_5314_1;
	R5314[71] = (char *(*)()) F551_6060_5314_1;
	R5314[72] = (char *(*)()) F552_6060_5314_1;
	R5314[73] = (char *(*)()) F553_6060_5314_1;
	R5314[74] = (char *(*)()) F554_6060_5314_1;
	R5314[75] = (char *(*)()) F555_6066;
	R5314[76] = (char *(*)()) F556_6066_5314_1;
	R5314[89] = (char *(*)()) F557_6072;
	R5314[90] = (char *(*)()) F558_6072_5314_1;
	R5314[91] = (char *(*)()) F559_6072_5314_1;
	R5314[92] = (char *(*)()) F560_6072_5314_1;
	R5314[93] = (char *(*)()) F561_6072_5314_1;
	R5314[94] = (char *(*)()) F562_6072_5314_1;
	R5314[95] = (char *(*)()) F563_6072_5314_1;
	R5314[96] = (char *(*)()) F564_6072_5314_1;
	R5314[97] = (char *(*)()) F565_6072_5314_1;
	R5314[98] = (char *(*)()) F566_6072_5314_1;
	R5314[99] = (char *(*)()) F567_6072_5314_1;
	R5314[100] = (char *(*)()) F568_6072_5314_1;
	R5314[101] = (char *(*)()) F561_6072_5314_1;
	R5314[102] = (char *(*)()) F563_6072_5314_1;
	R5314[103] = (char *(*)()) F557_6072;
	R5314[104] = (char *(*)()) F558_6072_5314_1;
	R5314[105] = (char *(*)()) F559_6072_5314_1;
	R5314[106] = (char *(*)()) F560_6072_5314_1;
	R5314[107] = (char *(*)()) F561_6072_5314_1;
	R5314[108] = (char *(*)()) F562_6072_5314_1;
	R5314[109] = (char *(*)()) F563_6072_5314_1;
	R5314[110] = (char *(*)()) F564_6072_5314_1;
	R5314[111] = (char *(*)()) F565_6072_5314_1;
	R5314[112] = (char *(*)()) F566_6072_5314_1;
	R5314[113] = (char *(*)()) F567_6072_5314_1;
	R5314[114] = (char *(*)()) F568_6072_5314_1;
	R5314[115] = (char *(*)()) F557_6072;
	R5314[116] = (char *(*)()) F558_6072_5314_1;
	R5314[117] = (char *(*)()) F559_6072_5314_1;
	R5314[118] = (char *(*)()) F560_6072_5314_1;
	R5314[119] = (char *(*)()) F561_6072_5314_1;
	R5314[120] = (char *(*)()) F562_6072_5314_1;
	R5314[121] = (char *(*)()) F563_6072_5314_1;
	R5314[122] = (char *(*)()) F564_6072_5314_1;
	R5314[123] = (char *(*)()) F565_6072_5314_1;
	R5314[124] = (char *(*)()) F566_6072_5314_1;
	R5314[125] = (char *(*)()) F567_6072_5314_1;
	R5314[126] = (char *(*)()) F568_6072_5314_1;
	{long i; for (i = 280; i < 282; i++) R5314[i] = (char *(*)()) F759_6241_5314_1;}
}
static EIF_REFERENCE F481_5925_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F481_5925(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F483_5932_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F483_5932(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F484_5932_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F484_5932(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F524_6032_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F524_6032(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F525_6032_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F525_6032(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F526_6032_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F526_6032(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F527_6032_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F527_6032(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F528_6032_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F528_6032(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F529_6032_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F529_6032(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F530_6032_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F530_6032(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1234, 0x00).id, 1234, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F531_6032_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F531_6032(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F532_6032_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F532_6032(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F533_6032_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F533_6032(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F534_6032_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F534_6032(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F549_6060_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F549_6060(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F550_6060_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F550_6060(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F551_6060_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F551_6060(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F552_6060_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F552_6060(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F553_6060_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F553_6060(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F554_6060_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F554_6060(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F556_6066_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F556_6066(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F558_6072_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F558_6072(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1037, 0x00).id, 1037, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F559_6072_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F559_6072(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F560_6072_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F560_6072(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F561_6072_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F561_6072(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F562_6072_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F562_6072(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1231, 0x00).id, 1231, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F563_6072_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F563_6072(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F564_6072_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F564_6072(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1234, 0x00).id, 1234, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F565_6072_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F565_6072(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1237, 0x00).id, 1237, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F566_6072_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F566_6072(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1070, 0x00).id, 1070, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F567_6072_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F567_6072(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F568_6072_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F568_6072(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F759_6241_5314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F759_6241(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5315[282])();
void R5315_init () {
	R5315[0] = (char *(*)()) F480_5917;
	R5315[1] = (char *(*)()) F481_5927;
	R5315[2] = (char *(*)()) F482_5933;
	R5315[3] = (char *(*)()) F483_5933;
	R5315[4] = (char *(*)()) F484_5933;
	R5315[55] = (char *(*)()) F535_6050;
	R5315[56] = (char *(*)()) F536_6050;
	R5315[57] = (char *(*)()) F537_6050;
	R5315[58] = (char *(*)()) F538_6050;
	R5315[59] = (char *(*)()) F539_6050;
	R5315[60] = (char *(*)()) F540_6050;
	R5315[61] = (char *(*)()) F541_6050;
	R5315[62] = (char *(*)()) F542_6050;
	R5315[63] = (char *(*)()) F543_6050;
	R5315[64] = (char *(*)()) F544_6050;
	R5315[65] = (char *(*)()) F545_6050;
	R5315[66] = (char *(*)()) F546_6050;
	R5315[67] = (char *(*)()) F547_6063;
	R5315[68] = (char *(*)()) F548_6063;
	R5315[69] = (char *(*)()) F549_6063;
	R5315[70] = (char *(*)()) F550_6063;
	R5315[71] = (char *(*)()) F551_6063;
	R5315[72] = (char *(*)()) F552_6063;
	R5315[73] = (char *(*)()) F553_6063;
	R5315[74] = (char *(*)()) F554_6063;
	R5315[75] = (char *(*)()) F555_6067;
	R5315[76] = (char *(*)()) F556_6067;
	R5315[89] = (char *(*)()) F557_6081;
	R5315[90] = (char *(*)()) F558_6081;
	R5315[91] = (char *(*)()) F559_6081;
	R5315[92] = (char *(*)()) F560_6081;
	R5315[93] = (char *(*)()) F561_6081;
	R5315[94] = (char *(*)()) F562_6081;
	R5315[95] = (char *(*)()) F563_6081;
	R5315[96] = (char *(*)()) F564_6081;
	R5315[97] = (char *(*)()) F565_6081;
	R5315[98] = (char *(*)()) F566_6081;
	R5315[99] = (char *(*)()) F567_6081;
	R5315[100] = (char *(*)()) F568_6081;
	R5315[101] = (char *(*)()) F561_6081;
	R5315[102] = (char *(*)()) F563_6081;
	R5315[103] = (char *(*)()) F557_6081;
	R5315[104] = (char *(*)()) F558_6081;
	R5315[105] = (char *(*)()) F559_6081;
	R5315[106] = (char *(*)()) F560_6081;
	R5315[107] = (char *(*)()) F561_6081;
	R5315[108] = (char *(*)()) F562_6081;
	R5315[109] = (char *(*)()) F563_6081;
	R5315[110] = (char *(*)()) F564_6081;
	R5315[111] = (char *(*)()) F565_6081;
	R5315[112] = (char *(*)()) F566_6081;
	R5315[113] = (char *(*)()) F567_6081;
	R5315[114] = (char *(*)()) F568_6081;
	R5315[115] = (char *(*)()) F557_6081;
	R5315[116] = (char *(*)()) F558_6081;
	R5315[117] = (char *(*)()) F559_6081;
	R5315[118] = (char *(*)()) F560_6081;
	R5315[119] = (char *(*)()) F561_6081;
	R5315[120] = (char *(*)()) F562_6081;
	R5315[121] = (char *(*)()) F563_6081;
	R5315[122] = (char *(*)()) F564_6081;
	R5315[123] = (char *(*)()) F565_6081;
	R5315[124] = (char *(*)()) F566_6081;
	R5315[125] = (char *(*)()) F567_6081;
	R5315[126] = (char *(*)()) F568_6081;
	{long i; for (i = 280; i < 282; i++) R5315[i] = (char *(*)()) F759_6242;}
}

char *(*R5316[282])();
void R5316_init () {
	R5316[0] = (char *(*)()) F480_5918;
	R5316[1] = (char *(*)()) F481_5928;
	R5316[2] = (char *(*)()) F482_5934;
	R5316[3] = (char *(*)()) F483_5934;
	R5316[4] = (char *(*)()) F484_5934;
	R5316[55] = (char *(*)()) F535_6058;
	R5316[56] = (char *(*)()) F536_6058;
	R5316[57] = (char *(*)()) F537_6058;
	R5316[58] = (char *(*)()) F538_6058;
	R5316[59] = (char *(*)()) F539_6058;
	R5316[60] = (char *(*)()) F540_6058;
	R5316[61] = (char *(*)()) F541_6058;
	R5316[62] = (char *(*)()) F542_6058;
	R5316[63] = (char *(*)()) F543_6058;
	R5316[64] = (char *(*)()) F544_6058;
	R5316[65] = (char *(*)()) F545_6058;
	R5316[66] = (char *(*)()) F546_6058;
	R5316[67] = (char *(*)()) F547_6064;
	R5316[68] = (char *(*)()) F548_6064;
	R5316[69] = (char *(*)()) F549_6064;
	R5316[70] = (char *(*)()) F550_6064;
	R5316[71] = (char *(*)()) F551_6064;
	R5316[72] = (char *(*)()) F552_6064;
	R5316[73] = (char *(*)()) F553_6064;
	R5316[74] = (char *(*)()) F554_6064;
	R5316[75] = (char *(*)()) F555_6069;
	R5316[76] = (char *(*)()) F556_6069;
	R5316[89] = (char *(*)()) F557_6087;
	R5316[90] = (char *(*)()) F558_6087;
	R5316[91] = (char *(*)()) F559_6087;
	R5316[92] = (char *(*)()) F560_6087;
	R5316[93] = (char *(*)()) F561_6087;
	R5316[94] = (char *(*)()) F562_6087;
	R5316[95] = (char *(*)()) F563_6087;
	R5316[96] = (char *(*)()) F564_6087;
	R5316[97] = (char *(*)()) F565_6087;
	R5316[98] = (char *(*)()) F566_6087;
	R5316[99] = (char *(*)()) F567_6087;
	R5316[100] = (char *(*)()) F568_6087;
	R5316[101] = (char *(*)()) F561_6087;
	R5316[102] = (char *(*)()) F563_6087;
	R5316[103] = (char *(*)()) F557_6087;
	R5316[104] = (char *(*)()) F558_6087;
	R5316[105] = (char *(*)()) F559_6087;
	R5316[106] = (char *(*)()) F560_6087;
	R5316[107] = (char *(*)()) F561_6087;
	R5316[108] = (char *(*)()) F562_6087;
	R5316[109] = (char *(*)()) F563_6087;
	R5316[110] = (char *(*)()) F564_6087;
	R5316[111] = (char *(*)()) F565_6087;
	R5316[112] = (char *(*)()) F566_6087;
	R5316[113] = (char *(*)()) F567_6087;
	R5316[114] = (char *(*)()) F568_6087;
	R5316[115] = (char *(*)()) F557_6087;
	R5316[116] = (char *(*)()) F558_6087;
	R5316[117] = (char *(*)()) F559_6087;
	R5316[118] = (char *(*)()) F560_6087;
	R5316[119] = (char *(*)()) F561_6087;
	R5316[120] = (char *(*)()) F562_6087;
	R5316[121] = (char *(*)()) F563_6087;
	R5316[122] = (char *(*)()) F564_6087;
	R5316[123] = (char *(*)()) F565_6087;
	R5316[124] = (char *(*)()) F566_6087;
	R5316[125] = (char *(*)()) F567_6087;
	R5316[126] = (char *(*)()) F568_6087;
	{long i; for (i = 280; i < 282; i++) R5316[i] = (char *(*)()) F759_6248;}
}

static EIF_TYPE_INDEX Y5317_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype13[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype25[] = {1031,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype96[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype97[] = {1031,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype122[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5317_pgtype123[] = {1219,0xFFFF};
EIF_TYPE_INDEX *Y5317_gen_type [294];
EIF_TYPE_INDEX Y5317 [294];
void Y5317_init (void)
{
	egc_routines_types [5317] = Y5317;
	egc_routines_gen_types [5317] = Y5317_gen_type;
	egc_routines_offset [5317] = 467;
	Y5317_gen_type [0] = Y5317_pgtype0;
	Y5317_gen_type [1] = Y5317_pgtype1;
	Y5317_gen_type [2] = Y5317_pgtype2;
	Y5317_gen_type [3] = Y5317_pgtype3;
	Y5317_gen_type [4] = Y5317_pgtype4;
	Y5317_gen_type [5] = Y5317_pgtype5;
	Y5317_gen_type [6] = Y5317_pgtype6;
	Y5317_gen_type [7] = Y5317_pgtype7;
	Y5317_gen_type [8] = Y5317_pgtype8;
	Y5317_gen_type [9] = Y5317_pgtype9;
	Y5317_gen_type [10] = Y5317_pgtype10;
	Y5317_gen_type [11] = Y5317_pgtype11;
	Y5317_gen_type [12] = Y5317_pgtype12;
	Y5317_gen_type [13] = Y5317_pgtype13;
	Y5317_gen_type [14] = Y5317_pgtype14;
	Y5317_gen_type [15] = Y5317_pgtype15;
	Y5317_gen_type [16] = Y5317_pgtype16;
	Y5317_gen_type [17] = Y5317_pgtype17;
	Y5317_gen_type [18] = Y5317_pgtype18;
	Y5317_gen_type [19] = Y5317_pgtype19;
	Y5317_gen_type [20] = Y5317_pgtype20;
	Y5317_gen_type [21] = Y5317_pgtype21;
	Y5317_gen_type [22] = Y5317_pgtype22;
	Y5317_gen_type [23] = Y5317_pgtype23;
	Y5317_gen_type [24] = Y5317_pgtype24;
	Y5317_gen_type [40] = Y5317_pgtype25;
	Y5317_gen_type [43] = Y5317_pgtype26;
	Y5317_gen_type [44] = Y5317_pgtype27;
	Y5317_gen_type [45] = Y5317_pgtype28;
	Y5317_gen_type [46] = Y5317_pgtype29;
	Y5317_gen_type [47] = Y5317_pgtype30;
	Y5317_gen_type [48] = Y5317_pgtype31;
	Y5317_gen_type [49] = Y5317_pgtype32;
	Y5317_gen_type [50] = Y5317_pgtype33;
	Y5317_gen_type [51] = Y5317_pgtype34;
	Y5317_gen_type [52] = Y5317_pgtype35;
	Y5317_gen_type [53] = Y5317_pgtype36;
	Y5317_gen_type [54] = Y5317_pgtype37;
	Y5317_gen_type [55] = Y5317_pgtype38;
	Y5317_gen_type [56] = Y5317_pgtype39;
	Y5317_gen_type [57] = Y5317_pgtype40;
	Y5317_gen_type [58] = Y5317_pgtype41;
	Y5317_gen_type [59] = Y5317_pgtype42;
	Y5317_gen_type [60] = Y5317_pgtype43;
	Y5317_gen_type [61] = Y5317_pgtype44;
	Y5317_gen_type [62] = Y5317_pgtype45;
	Y5317_gen_type [63] = Y5317_pgtype46;
	Y5317_gen_type [64] = Y5317_pgtype47;
	Y5317_gen_type [65] = Y5317_pgtype48;
	Y5317_gen_type [66] = Y5317_pgtype49;
	Y5317_gen_type [67] = Y5317_pgtype50;
	Y5317_gen_type [68] = Y5317_pgtype51;
	Y5317_gen_type [69] = Y5317_pgtype52;
	Y5317_gen_type [70] = Y5317_pgtype53;
	Y5317_gen_type [71] = Y5317_pgtype54;
	Y5317_gen_type [72] = Y5317_pgtype55;
	Y5317_gen_type [73] = Y5317_pgtype56;
	Y5317_gen_type [74] = Y5317_pgtype57;
	Y5317_gen_type [75] = Y5317_pgtype58;
	Y5317_gen_type [76] = Y5317_pgtype59;
	Y5317_gen_type [77] = Y5317_pgtype60;
	Y5317_gen_type [78] = Y5317_pgtype61;
	Y5317_gen_type [79] = Y5317_pgtype62;
	Y5317_gen_type [80] = Y5317_pgtype63;
	Y5317_gen_type [81] = Y5317_pgtype64;
	Y5317_gen_type [82] = Y5317_pgtype65;
	Y5317_gen_type [83] = Y5317_pgtype66;
	Y5317_gen_type [84] = Y5317_pgtype67;
	Y5317_gen_type [85] = Y5317_pgtype68;
	Y5317_gen_type [86] = Y5317_pgtype69;
	Y5317_gen_type [87] = Y5317_pgtype70;
	Y5317_gen_type [88] = Y5317_pgtype71;
	Y5317_gen_type [89] = Y5317_pgtype72;
	Y5317_gen_type [90] = Y5317_pgtype73;
	Y5317_gen_type [91] = Y5317_pgtype74;
	Y5317_gen_type [92] = Y5317_pgtype75;
	Y5317_gen_type [93] = Y5317_pgtype76;
	Y5317_gen_type [94] = Y5317_pgtype77;
	Y5317_gen_type [95] = Y5317_pgtype78;
	Y5317_gen_type [96] = Y5317_pgtype79;
	Y5317_gen_type [97] = Y5317_pgtype80;
	Y5317_gen_type [98] = Y5317_pgtype81;
	Y5317_gen_type [99] = Y5317_pgtype82;
	Y5317_gen_type [100] = Y5317_pgtype83;
	Y5317_gen_type [101] = Y5317_pgtype84;
	Y5317_gen_type [102] = Y5317_pgtype85;
	Y5317_gen_type [103] = Y5317_pgtype86;
	Y5317_gen_type [104] = Y5317_pgtype87;
	Y5317_gen_type [105] = Y5317_pgtype88;
	Y5317_gen_type [106] = Y5317_pgtype89;
	Y5317_gen_type [107] = Y5317_pgtype90;
	Y5317_gen_type [108] = Y5317_pgtype91;
	Y5317_gen_type [109] = Y5317_pgtype92;
	Y5317_gen_type [110] = Y5317_pgtype93;
	Y5317_gen_type [111] = Y5317_pgtype94;
	Y5317_gen_type [112] = Y5317_pgtype95;
	Y5317_gen_type [113] = Y5317_pgtype96;
	Y5317_gen_type [114] = Y5317_pgtype97;
	Y5317_gen_type [115] = Y5317_pgtype98;
	Y5317_gen_type [116] = Y5317_pgtype99;
	Y5317_gen_type [117] = Y5317_pgtype100;
	Y5317_gen_type [118] = Y5317_pgtype101;
	Y5317_gen_type [119] = Y5317_pgtype102;
	Y5317_gen_type [120] = Y5317_pgtype103;
	Y5317_gen_type [121] = Y5317_pgtype104;
	Y5317_gen_type [122] = Y5317_pgtype105;
	Y5317_gen_type [123] = Y5317_pgtype106;
	Y5317_gen_type [124] = Y5317_pgtype107;
	Y5317_gen_type [125] = Y5317_pgtype108;
	Y5317_gen_type [126] = Y5317_pgtype109;
	Y5317_gen_type [127] = Y5317_pgtype110;
	Y5317_gen_type [128] = Y5317_pgtype111;
	Y5317_gen_type [129] = Y5317_pgtype112;
	Y5317_gen_type [130] = Y5317_pgtype113;
	Y5317_gen_type [131] = Y5317_pgtype114;
	Y5317_gen_type [132] = Y5317_pgtype115;
	Y5317_gen_type [133] = Y5317_pgtype116;
	Y5317_gen_type [134] = Y5317_pgtype117;
	Y5317_gen_type [135] = Y5317_pgtype118;
	Y5317_gen_type [136] = Y5317_pgtype119;
	Y5317_gen_type [137] = Y5317_pgtype120;
	Y5317_gen_type [138] = Y5317_pgtype121;
	Y5317_gen_type [292] = Y5317_pgtype122;
	Y5317_gen_type [293] = Y5317_pgtype123;
	Y5317[13] = 1034;
	Y5317[40] = 1031;
	Y5317[113] = 1034;
	Y5317[114] = 1031;
	{long i; for (i = 292; i < 294; i++) Y5317[i] = 1219;};
}

char *(*R5327[3])();
void R5327_init () {
	R5327[0] = (char *(*)()) F482_5931;
	R5327[1] = (char *(*)()) F483_5931;
	R5327[2] = (char *(*)()) F484_5931;
}

char *(*R5330[8])();
void R5330_init () {
	R5330[0] = (char *(*)()) F547_6061;
	R5330[1] = (char *(*)()) F548_6061_5330_1;
	R5330[2] = (char *(*)()) F549_6061;
	R5330[3] = (char *(*)()) F550_6061;
	R5330[4] = (char *(*)()) F551_6061;
	R5330[5] = (char *(*)()) F552_6061_5330_1;
	R5330[6] = (char *(*)()) F553_6061;
	R5330[7] = (char *(*)()) F554_6061;
}
static EIF_REFERENCE F548_6061_5330_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F548_6061(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F552_6061_5330_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F552_6061(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5333[551])();
void R5333_init () {
	R5333[0] = (char *(*)()) F801_6334;
	R5333[51] = (char *(*)()) F852_6780;
	R5333[52] = (char *(*)()) F853_6780;
	R5333[53] = (char *(*)()) F854_6780;
	R5333[54] = (char *(*)()) F855_6780;
	R5333[55] = (char *(*)()) F856_6780;
	R5333[56] = (char *(*)()) F857_6780;
	R5333[57] = (char *(*)()) F858_6780;
	R5333[58] = (char *(*)()) F859_6780;
	{long i; for (i = 59; i < 61; i++) R5333[i] = (char *(*)()) F852_6780;}
	R5333[61] = (char *(*)()) F854_6780;
	R5333[62] = (char *(*)()) F855_6780;
	R5333[63] = (char *(*)()) F856_6780;
	R5333[64] = (char *(*)()) F858_6780;
	R5333[148] = (char *(*)()) F949_7132;
	R5333[149] = (char *(*)()) F950_7132;
	R5333[150] = (char *(*)()) F951_7132;
	R5333[151] = (char *(*)()) F952_7132;
	R5333[152] = (char *(*)()) F953_7132;
	R5333[153] = (char *(*)()) F954_7132;
	R5333[154] = (char *(*)()) F955_7132;
	R5333[155] = (char *(*)()) F956_7132;
	R5333[156] = (char *(*)()) F957_7132;
	R5333[157] = (char *(*)()) F958_7132;
	R5333[158] = (char *(*)()) F959_7132;
	R5333[159] = (char *(*)()) F960_7132;
	{long i; for (i = 160; i < 163; i++) R5333[i] = (char *(*)()) F949_7132;}
	R5333[163] = (char *(*)()) F951_7132;
	R5333[164] = (char *(*)()) F949_7132;
	R5333[225] = (char *(*)()) F1026_7916;
	{long i; for (i = 272; i < 277; i++) R5333[i] = (char *(*)()) F1072_8131;}
	R5333[282] = (char *(*)()) F1083_8458;
	R5333[285] = (char *(*)()) F1086_8536;
	R5333[286] = (char *(*)()) F1087_8627;
	R5333[540] = (char *(*)()) F495_5950;
	R5333[543] = (char *(*)()) F495_5950;
	R5333[550] = (char *(*)()) F1083_8458;
}

char *(*R5345[842])();
void R5345_init () {
	R5345[0] = (char *(*)()) F510_5999;
	R5345[25] = (char *(*)()) F535_6044;
	R5345[26] = (char *(*)()) F536_6044;
	R5345[27] = (char *(*)()) F537_6044;
	R5345[28] = (char *(*)()) F538_6044;
	R5345[29] = (char *(*)()) F539_6044;
	R5345[30] = (char *(*)()) F540_6044;
	R5345[31] = (char *(*)()) F541_6044;
	R5345[32] = (char *(*)()) F542_6044;
	R5345[33] = (char *(*)()) F543_6044;
	R5345[34] = (char *(*)()) F544_6044;
	R5345[35] = (char *(*)()) F545_6044;
	R5345[36] = (char *(*)()) F546_6044;
	{long i; for (i = 37; i < 39; i++) R5345[i] = (char *(*)()) F535_6044;}
	R5345[39] = (char *(*)()) F536_6044;
	R5345[40] = (char *(*)()) F537_6044;
	R5345[41] = (char *(*)()) F540_6044;
	R5345[42] = (char *(*)()) F537_6044;
	R5345[43] = (char *(*)()) F543_6044;
	R5345[44] = (char *(*)()) F544_6044;
	R5345[45] = (char *(*)()) F535_6044;
	R5345[46] = (char *(*)()) F537_6044;
	R5345[59] = (char *(*)()) F569_6094;
	R5345[60] = (char *(*)()) F570_6094;
	R5345[61] = (char *(*)()) F571_6094;
	R5345[62] = (char *(*)()) F572_6094;
	R5345[63] = (char *(*)()) F573_6094;
	R5345[64] = (char *(*)()) F574_6094;
	R5345[65] = (char *(*)()) F575_6094;
	R5345[66] = (char *(*)()) F576_6094;
	R5345[67] = (char *(*)()) F577_6094;
	R5345[68] = (char *(*)()) F578_6094;
	R5345[69] = (char *(*)()) F579_6094;
	R5345[70] = (char *(*)()) F580_6094;
	R5345[71] = (char *(*)()) F581_6100;
	R5345[72] = (char *(*)()) F582_6106;
	R5345[73] = (char *(*)()) F583_6112;
	R5345[74] = (char *(*)()) F584_6112;
	R5345[75] = (char *(*)()) F585_6112;
	R5345[76] = (char *(*)()) F586_6112;
	R5345[77] = (char *(*)()) F587_6112;
	R5345[78] = (char *(*)()) F588_6112;
	R5345[79] = (char *(*)()) F589_6112;
	R5345[80] = (char *(*)()) F590_6112;
	R5345[81] = (char *(*)()) F591_6112;
	R5345[82] = (char *(*)()) F592_6112;
	R5345[83] = (char *(*)()) F593_6112;
	R5345[84] = (char *(*)()) F594_6112;
	R5345[85] = (char *(*)()) F595_6118;
	R5345[86] = (char *(*)()) F596_6118;
	R5345[87] = (char *(*)()) F597_6118;
	R5345[88] = (char *(*)()) F598_6118;
	R5345[89] = (char *(*)()) F599_6118;
	R5345[90] = (char *(*)()) F600_6118;
	R5345[91] = (char *(*)()) F601_6118;
	R5345[92] = (char *(*)()) F602_6118;
	R5345[93] = (char *(*)()) F603_6118;
	R5345[94] = (char *(*)()) F604_6118;
	R5345[95] = (char *(*)()) F605_6118;
	R5345[96] = (char *(*)()) F606_6118;
	R5345[250] = (char *(*)()) F760_6272;
	R5345[251] = (char *(*)()) F761_6287;
	R5345[291] = (char *(*)()) F801_6313;
	{long i; for (i = 319; i < 321; i++) R5345[i] = (char *(*)()) F828_6451;}
	R5345[329] = (char *(*)()) F839_6707;
	R5345[342] = (char *(*)()) F852_6736;
	R5345[343] = (char *(*)()) F853_6736;
	R5345[344] = (char *(*)()) F854_6736;
	R5345[345] = (char *(*)()) F855_6736;
	R5345[346] = (char *(*)()) F856_6736;
	R5345[347] = (char *(*)()) F857_6736;
	R5345[348] = (char *(*)()) F858_6736;
	R5345[349] = (char *(*)()) F859_6736;
	{long i; for (i = 350; i < 352; i++) R5345[i] = (char *(*)()) F852_6736;}
	R5345[352] = (char *(*)()) F854_6736;
	R5345[353] = (char *(*)()) F855_6736;
	R5345[354] = (char *(*)()) F856_6736;
	R5345[355] = (char *(*)()) F858_6736;
	R5345[368] = (char *(*)()) F842_6716;
	R5345[369] = (char *(*)()) F879_6901;
	R5345[370] = (char *(*)()) F880_6901;
	R5345[371] = (char *(*)()) F881_6901;
	R5345[372] = (char *(*)()) F882_6901;
	R5345[373] = (char *(*)()) F883_6901;
	R5345[374] = (char *(*)()) F884_6901;
	R5345[375] = (char *(*)()) F885_6901;
	R5345[376] = (char *(*)()) F886_6901;
	R5345[377] = (char *(*)()) F887_6901;
	R5345[378] = (char *(*)()) F888_6901;
	R5345[379] = (char *(*)()) F889_6901;
	R5345[380] = (char *(*)()) F890_6901;
	R5345[434] = (char *(*)()) F944_7008;
	R5345[435] = (char *(*)()) F945_7008;
	R5345[436] = (char *(*)()) F944_7008;
	R5345[437] = (char *(*)()) F945_7008;
	R5345[438] = (char *(*)()) F944_7008;
	R5345[439] = (char *(*)()) F949_7085;
	R5345[440] = (char *(*)()) F950_7085;
	R5345[441] = (char *(*)()) F951_7085;
	R5345[442] = (char *(*)()) F952_7085;
	R5345[443] = (char *(*)()) F953_7085;
	R5345[444] = (char *(*)()) F954_7085;
	R5345[445] = (char *(*)()) F955_7085;
	R5345[446] = (char *(*)()) F956_7085;
	R5345[447] = (char *(*)()) F957_7085;
	R5345[448] = (char *(*)()) F958_7085;
	R5345[449] = (char *(*)()) F959_7085;
	R5345[450] = (char *(*)()) F960_7085;
	{long i; for (i = 451; i < 454; i++) R5345[i] = (char *(*)()) F949_7085;}
	R5345[454] = (char *(*)()) F951_7085;
	R5345[455] = (char *(*)()) F949_7085;
	R5345[516] = (char *(*)()) F840_6716;
	{long i; for (i = 572; i < 574; i++) R5345[i] = (char *(*)()) F1081_8315;}
	{long i; for (i = 576; i < 578; i++) R5345[i] = (char *(*)()) F1085_8480;}
	{long i; for (i = 579; i < 581; i++) R5345[i] = (char *(*)()) F607_6126;}
	R5345[631] = (char *(*)()) F1141_9215;
	R5345[632] = (char *(*)()) F1142_9215;
	R5345[633] = (char *(*)()) F1143_9215;
	R5345[634] = (char *(*)()) F1144_9215;
	R5345[635] = (char *(*)()) F1145_9215;
	R5345[636] = (char *(*)()) F1146_9215;
	R5345[637] = (char *(*)()) F1147_9215;
	R5345[638] = (char *(*)()) F1148_9215;
	R5345[639] = (char *(*)()) F1149_9215;
	R5345[640] = (char *(*)()) F1150_9215;
	R5345[641] = (char *(*)()) F1151_9215;
	R5345[642] = (char *(*)()) F1152_9215;
	R5345[735] = (char *(*)()) F1245_10509;
	R5345[736] = (char *(*)()) F1246_10552;
	R5345[751] = (char *(*)()) F1261_10660;
	R5345[752] = (char *(*)()) F1262_10724;
	R5345[753] = (char *(*)()) F1263_10724;
	R5345[754] = (char *(*)()) F1264_10724;
	R5345[841] = (char *(*)()) F1081_8315;
}

static EIF_TYPE_INDEX Y5346_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype12[] = {1031,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype13[] = {0xFF01,1082,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype14[] = {0xFF01,1085,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype85[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype86[] = {1031,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype111[] = {0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype264[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype265[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype332[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype333[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype334[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype343[] = {1084,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype364[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype365[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype382[] = {1219,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype451[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype452[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype453[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype454[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype455[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype456[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype457[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype466[] = {0xFF01,1300,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype467[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype468[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype469[] = {0xFF01,964,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype470[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype471[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype472[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype473[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype474[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype475[] = {1031,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype476[] = {1031,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype477[] = {1031,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype478[] = {0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype479[] = {0xFF01,1090,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype480[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype481[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype482[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype483[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype484[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype485[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype486[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype487[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype488[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype489[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype490[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype491[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype492[] = {0xFF01,1208,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype493[] = {0xFF01,1208,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype494[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype495[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype496[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype497[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype498[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype499[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype500[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype501[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype502[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype503[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype504[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype505[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype506[] = {1034,0xFFFF};
static EIF_TYPE_INDEX Y5346_pgtype507[] = {1034,0xFFFF};
EIF_TYPE_INDEX *Y5346_gen_type [857];
EIF_TYPE_INDEX Y5346 [857];
void Y5346_init (void)
{
	egc_routines_types [5346] = Y5346;
	egc_routines_gen_types [5346] = Y5346_gen_type;
	egc_routines_offset [5346] = 495;
	Y5346_gen_type [0] = Y5346_pgtype0;
	Y5346_gen_type [1] = Y5346_pgtype1;
	Y5346_gen_type [2] = Y5346_pgtype2;
	Y5346_gen_type [3] = Y5346_pgtype3;
	Y5346_gen_type [4] = Y5346_pgtype4;
	Y5346_gen_type [5] = Y5346_pgtype5;
	Y5346_gen_type [6] = Y5346_pgtype6;
	Y5346_gen_type [7] = Y5346_pgtype7;
	Y5346_gen_type [8] = Y5346_pgtype8;
	Y5346_gen_type [9] = Y5346_pgtype9;
	Y5346_gen_type [10] = Y5346_pgtype10;
	Y5346_gen_type [11] = Y5346_pgtype11;
	Y5346_gen_type [12] = Y5346_pgtype12;
	Y5346_gen_type [13] = Y5346_pgtype13;
	Y5346_gen_type [14] = Y5346_pgtype14;
	Y5346_gen_type [15] = Y5346_pgtype15;
	Y5346_gen_type [16] = Y5346_pgtype16;
	Y5346_gen_type [17] = Y5346_pgtype17;
	Y5346_gen_type [18] = Y5346_pgtype18;
	Y5346_gen_type [19] = Y5346_pgtype19;
	Y5346_gen_type [20] = Y5346_pgtype20;
	Y5346_gen_type [21] = Y5346_pgtype21;
	Y5346_gen_type [22] = Y5346_pgtype22;
	Y5346_gen_type [23] = Y5346_pgtype23;
	Y5346_gen_type [24] = Y5346_pgtype24;
	Y5346_gen_type [25] = Y5346_pgtype25;
	Y5346_gen_type [26] = Y5346_pgtype26;
	Y5346_gen_type [27] = Y5346_pgtype27;
	Y5346_gen_type [28] = Y5346_pgtype28;
	Y5346_gen_type [29] = Y5346_pgtype29;
	Y5346_gen_type [30] = Y5346_pgtype30;
	Y5346_gen_type [31] = Y5346_pgtype31;
	Y5346_gen_type [32] = Y5346_pgtype32;
	Y5346_gen_type [33] = Y5346_pgtype33;
	Y5346_gen_type [34] = Y5346_pgtype34;
	Y5346_gen_type [35] = Y5346_pgtype35;
	Y5346_gen_type [36] = Y5346_pgtype36;
	Y5346_gen_type [37] = Y5346_pgtype37;
	Y5346_gen_type [38] = Y5346_pgtype38;
	Y5346_gen_type [39] = Y5346_pgtype39;
	Y5346_gen_type [40] = Y5346_pgtype40;
	Y5346_gen_type [41] = Y5346_pgtype41;
	Y5346_gen_type [42] = Y5346_pgtype42;
	Y5346_gen_type [43] = Y5346_pgtype43;
	Y5346_gen_type [44] = Y5346_pgtype44;
	Y5346_gen_type [45] = Y5346_pgtype45;
	Y5346_gen_type [46] = Y5346_pgtype46;
	Y5346_gen_type [47] = Y5346_pgtype47;
	Y5346_gen_type [48] = Y5346_pgtype48;
	Y5346_gen_type [49] = Y5346_pgtype49;
	Y5346_gen_type [50] = Y5346_pgtype50;
	Y5346_gen_type [51] = Y5346_pgtype51;
	Y5346_gen_type [52] = Y5346_pgtype52;
	Y5346_gen_type [53] = Y5346_pgtype53;
	Y5346_gen_type [54] = Y5346_pgtype54;
	Y5346_gen_type [55] = Y5346_pgtype55;
	Y5346_gen_type [56] = Y5346_pgtype56;
	Y5346_gen_type [57] = Y5346_pgtype57;
	Y5346_gen_type [58] = Y5346_pgtype58;
	Y5346_gen_type [59] = Y5346_pgtype59;
	Y5346_gen_type [60] = Y5346_pgtype60;
	Y5346_gen_type [61] = Y5346_pgtype61;
	Y5346_gen_type [62] = Y5346_pgtype62;
	Y5346_gen_type [63] = Y5346_pgtype63;
	Y5346_gen_type [64] = Y5346_pgtype64;
	Y5346_gen_type [65] = Y5346_pgtype65;
	Y5346_gen_type [66] = Y5346_pgtype66;
	Y5346_gen_type [67] = Y5346_pgtype67;
	Y5346_gen_type [68] = Y5346_pgtype68;
	Y5346_gen_type [69] = Y5346_pgtype69;
	Y5346_gen_type [70] = Y5346_pgtype70;
	Y5346_gen_type [71] = Y5346_pgtype71;
	Y5346_gen_type [72] = Y5346_pgtype72;
	Y5346_gen_type [73] = Y5346_pgtype73;
	Y5346_gen_type [74] = Y5346_pgtype74;
	Y5346_gen_type [75] = Y5346_pgtype75;
	Y5346_gen_type [76] = Y5346_pgtype76;
	Y5346_gen_type [77] = Y5346_pgtype77;
	Y5346_gen_type [78] = Y5346_pgtype78;
	Y5346_gen_type [79] = Y5346_pgtype79;
	Y5346_gen_type [80] = Y5346_pgtype80;
	Y5346_gen_type [81] = Y5346_pgtype81;
	Y5346_gen_type [82] = Y5346_pgtype82;
	Y5346_gen_type [83] = Y5346_pgtype83;
	Y5346_gen_type [84] = Y5346_pgtype84;
	Y5346_gen_type [85] = Y5346_pgtype85;
	Y5346_gen_type [86] = Y5346_pgtype86;
	Y5346_gen_type [87] = Y5346_pgtype87;
	Y5346_gen_type [88] = Y5346_pgtype88;
	Y5346_gen_type [89] = Y5346_pgtype89;
	Y5346_gen_type [90] = Y5346_pgtype90;
	Y5346_gen_type [91] = Y5346_pgtype91;
	Y5346_gen_type [92] = Y5346_pgtype92;
	Y5346_gen_type [93] = Y5346_pgtype93;
	Y5346_gen_type [94] = Y5346_pgtype94;
	Y5346_gen_type [95] = Y5346_pgtype95;
	Y5346_gen_type [96] = Y5346_pgtype96;
	Y5346_gen_type [97] = Y5346_pgtype97;
	Y5346_gen_type [98] = Y5346_pgtype98;
	Y5346_gen_type [99] = Y5346_pgtype99;
	Y5346_gen_type [100] = Y5346_pgtype100;
	Y5346_gen_type [101] = Y5346_pgtype101;
	Y5346_gen_type [102] = Y5346_pgtype102;
	Y5346_gen_type [103] = Y5346_pgtype103;
	Y5346_gen_type [104] = Y5346_pgtype104;
	Y5346_gen_type [105] = Y5346_pgtype105;
	Y5346_gen_type [106] = Y5346_pgtype106;
	Y5346_gen_type [107] = Y5346_pgtype107;
	Y5346_gen_type [108] = Y5346_pgtype108;
	Y5346_gen_type [109] = Y5346_pgtype109;
	Y5346_gen_type [110] = Y5346_pgtype110;
	Y5346_gen_type [111] = Y5346_pgtype111;
	Y5346_gen_type [112] = Y5346_pgtype112;
	Y5346_gen_type [113] = Y5346_pgtype113;
	Y5346_gen_type [114] = Y5346_pgtype114;
	Y5346_gen_type [115] = Y5346_pgtype115;
	Y5346_gen_type [116] = Y5346_pgtype116;
	Y5346_gen_type [117] = Y5346_pgtype117;
	Y5346_gen_type [118] = Y5346_pgtype118;
	Y5346_gen_type [119] = Y5346_pgtype119;
	Y5346_gen_type [120] = Y5346_pgtype120;
	Y5346_gen_type [121] = Y5346_pgtype121;
	Y5346_gen_type [122] = Y5346_pgtype122;
	Y5346_gen_type [123] = Y5346_pgtype123;
	Y5346_gen_type [124] = Y5346_pgtype124;
	Y5346_gen_type [125] = Y5346_pgtype125;
	Y5346_gen_type [126] = Y5346_pgtype126;
	Y5346_gen_type [127] = Y5346_pgtype127;
	Y5346_gen_type [128] = Y5346_pgtype128;
	Y5346_gen_type [129] = Y5346_pgtype129;
	Y5346_gen_type [130] = Y5346_pgtype130;
	Y5346_gen_type [131] = Y5346_pgtype131;
	Y5346_gen_type [132] = Y5346_pgtype132;
	Y5346_gen_type [133] = Y5346_pgtype133;
	Y5346_gen_type [134] = Y5346_pgtype134;
	Y5346_gen_type [135] = Y5346_pgtype135;
	Y5346_gen_type [136] = Y5346_pgtype136;
	Y5346_gen_type [137] = Y5346_pgtype137;
	Y5346_gen_type [138] = Y5346_pgtype138;
	Y5346_gen_type [139] = Y5346_pgtype139;
	Y5346_gen_type [140] = Y5346_pgtype140;
	Y5346_gen_type [141] = Y5346_pgtype141;
	Y5346_gen_type [142] = Y5346_pgtype142;
	Y5346_gen_type [143] = Y5346_pgtype143;
	Y5346_gen_type [144] = Y5346_pgtype144;
	Y5346_gen_type [145] = Y5346_pgtype145;
	Y5346_gen_type [146] = Y5346_pgtype146;
	Y5346_gen_type [147] = Y5346_pgtype147;
	Y5346_gen_type [148] = Y5346_pgtype148;
	Y5346_gen_type [149] = Y5346_pgtype149;
	Y5346_gen_type [150] = Y5346_pgtype150;
	Y5346_gen_type [151] = Y5346_pgtype151;
	Y5346_gen_type [152] = Y5346_pgtype152;
	Y5346_gen_type [153] = Y5346_pgtype153;
	Y5346_gen_type [154] = Y5346_pgtype154;
	Y5346_gen_type [155] = Y5346_pgtype155;
	Y5346_gen_type [156] = Y5346_pgtype156;
	Y5346_gen_type [157] = Y5346_pgtype157;
	Y5346_gen_type [158] = Y5346_pgtype158;
	Y5346_gen_type [159] = Y5346_pgtype159;
	Y5346_gen_type [160] = Y5346_pgtype160;
	Y5346_gen_type [161] = Y5346_pgtype161;
	Y5346_gen_type [162] = Y5346_pgtype162;
	Y5346_gen_type [163] = Y5346_pgtype163;
	Y5346_gen_type [164] = Y5346_pgtype164;
	Y5346_gen_type [165] = Y5346_pgtype165;
	Y5346_gen_type [166] = Y5346_pgtype166;
	Y5346_gen_type [167] = Y5346_pgtype167;
	Y5346_gen_type [168] = Y5346_pgtype168;
	Y5346_gen_type [169] = Y5346_pgtype169;
	Y5346_gen_type [170] = Y5346_pgtype170;
	Y5346_gen_type [171] = Y5346_pgtype171;
	Y5346_gen_type [172] = Y5346_pgtype172;
	Y5346_gen_type [173] = Y5346_pgtype173;
	Y5346_gen_type [174] = Y5346_pgtype174;
	Y5346_gen_type [175] = Y5346_pgtype175;
	Y5346_gen_type [176] = Y5346_pgtype176;
	Y5346_gen_type [177] = Y5346_pgtype177;
	Y5346_gen_type [178] = Y5346_pgtype178;
	Y5346_gen_type [179] = Y5346_pgtype179;
	Y5346_gen_type [180] = Y5346_pgtype180;
	Y5346_gen_type [181] = Y5346_pgtype181;
	Y5346_gen_type [182] = Y5346_pgtype182;
	Y5346_gen_type [183] = Y5346_pgtype183;
	Y5346_gen_type [184] = Y5346_pgtype184;
	Y5346_gen_type [185] = Y5346_pgtype185;
	Y5346_gen_type [186] = Y5346_pgtype186;
	Y5346_gen_type [187] = Y5346_pgtype187;
	Y5346_gen_type [188] = Y5346_pgtype188;
	Y5346_gen_type [189] = Y5346_pgtype189;
	Y5346_gen_type [190] = Y5346_pgtype190;
	Y5346_gen_type [191] = Y5346_pgtype191;
	Y5346_gen_type [192] = Y5346_pgtype192;
	Y5346_gen_type [193] = Y5346_pgtype193;
	Y5346_gen_type [194] = Y5346_pgtype194;
	Y5346_gen_type [195] = Y5346_pgtype195;
	Y5346_gen_type [196] = Y5346_pgtype196;
	Y5346_gen_type [197] = Y5346_pgtype197;
	Y5346_gen_type [198] = Y5346_pgtype198;
	Y5346_gen_type [199] = Y5346_pgtype199;
	Y5346_gen_type [200] = Y5346_pgtype200;
	Y5346_gen_type [201] = Y5346_pgtype201;
	Y5346_gen_type [202] = Y5346_pgtype202;
	Y5346_gen_type [203] = Y5346_pgtype203;
	Y5346_gen_type [204] = Y5346_pgtype204;
	Y5346_gen_type [205] = Y5346_pgtype205;
	Y5346_gen_type [206] = Y5346_pgtype206;
	Y5346_gen_type [207] = Y5346_pgtype207;
	Y5346_gen_type [208] = Y5346_pgtype208;
	Y5346_gen_type [209] = Y5346_pgtype209;
	Y5346_gen_type [210] = Y5346_pgtype210;
	Y5346_gen_type [211] = Y5346_pgtype211;
	Y5346_gen_type [212] = Y5346_pgtype212;
	Y5346_gen_type [213] = Y5346_pgtype213;
	Y5346_gen_type [214] = Y5346_pgtype214;
	Y5346_gen_type [215] = Y5346_pgtype215;
	Y5346_gen_type [216] = Y5346_pgtype216;
	Y5346_gen_type [217] = Y5346_pgtype217;
	Y5346_gen_type [218] = Y5346_pgtype218;
	Y5346_gen_type [219] = Y5346_pgtype219;
	Y5346_gen_type [220] = Y5346_pgtype220;
	Y5346_gen_type [221] = Y5346_pgtype221;
	Y5346_gen_type [222] = Y5346_pgtype222;
	Y5346_gen_type [223] = Y5346_pgtype223;
	Y5346_gen_type [224] = Y5346_pgtype224;
	Y5346_gen_type [225] = Y5346_pgtype225;
	Y5346_gen_type [226] = Y5346_pgtype226;
	Y5346_gen_type [227] = Y5346_pgtype227;
	Y5346_gen_type [228] = Y5346_pgtype228;
	Y5346_gen_type [229] = Y5346_pgtype229;
	Y5346_gen_type [230] = Y5346_pgtype230;
	Y5346_gen_type [231] = Y5346_pgtype231;
	Y5346_gen_type [232] = Y5346_pgtype232;
	Y5346_gen_type [233] = Y5346_pgtype233;
	Y5346_gen_type [234] = Y5346_pgtype234;
	Y5346_gen_type [235] = Y5346_pgtype235;
	Y5346_gen_type [236] = Y5346_pgtype236;
	Y5346_gen_type [237] = Y5346_pgtype237;
	Y5346_gen_type [238] = Y5346_pgtype238;
	Y5346_gen_type [239] = Y5346_pgtype239;
	Y5346_gen_type [240] = Y5346_pgtype240;
	Y5346_gen_type [241] = Y5346_pgtype241;
	Y5346_gen_type [242] = Y5346_pgtype242;
	Y5346_gen_type [243] = Y5346_pgtype243;
	Y5346_gen_type [244] = Y5346_pgtype244;
	Y5346_gen_type [245] = Y5346_pgtype245;
	Y5346_gen_type [246] = Y5346_pgtype246;
	Y5346_gen_type [247] = Y5346_pgtype247;
	Y5346_gen_type [248] = Y5346_pgtype248;
	Y5346_gen_type [249] = Y5346_pgtype249;
	Y5346_gen_type [250] = Y5346_pgtype250;
	Y5346_gen_type [251] = Y5346_pgtype251;
	Y5346_gen_type [252] = Y5346_pgtype252;
	Y5346_gen_type [253] = Y5346_pgtype253;
	Y5346_gen_type [254] = Y5346_pgtype254;
	Y5346_gen_type [255] = Y5346_pgtype255;
	Y5346_gen_type [256] = Y5346_pgtype256;
	Y5346_gen_type [257] = Y5346_pgtype257;
	Y5346_gen_type [258] = Y5346_pgtype258;
	Y5346_gen_type [259] = Y5346_pgtype259;
	Y5346_gen_type [260] = Y5346_pgtype260;
	Y5346_gen_type [261] = Y5346_pgtype261;
	Y5346_gen_type [262] = Y5346_pgtype262;
	Y5346_gen_type [263] = Y5346_pgtype263;
	Y5346_gen_type [264] = Y5346_pgtype264;
	Y5346_gen_type [265] = Y5346_pgtype265;
	Y5346_gen_type [266] = Y5346_pgtype266;
	Y5346_gen_type [267] = Y5346_pgtype267;
	Y5346_gen_type [268] = Y5346_pgtype268;
	Y5346_gen_type [269] = Y5346_pgtype269;
	Y5346_gen_type [270] = Y5346_pgtype270;
	Y5346_gen_type [271] = Y5346_pgtype271;
	Y5346_gen_type [272] = Y5346_pgtype272;
	Y5346_gen_type [273] = Y5346_pgtype273;
	Y5346_gen_type [274] = Y5346_pgtype274;
	Y5346_gen_type [275] = Y5346_pgtype275;
	Y5346_gen_type [276] = Y5346_pgtype276;
	Y5346_gen_type [277] = Y5346_pgtype277;
	Y5346_gen_type [278] = Y5346_pgtype278;
	Y5346_gen_type [279] = Y5346_pgtype279;
	Y5346_gen_type [280] = Y5346_pgtype280;
	Y5346_gen_type [281] = Y5346_pgtype281;
	Y5346_gen_type [282] = Y5346_pgtype282;
	Y5346_gen_type [283] = Y5346_pgtype283;
	Y5346_gen_type [284] = Y5346_pgtype284;
	Y5346_gen_type [285] = Y5346_pgtype285;
	Y5346_gen_type [286] = Y5346_pgtype286;
	Y5346_gen_type [287] = Y5346_pgtype287;
	Y5346_gen_type [288] = Y5346_pgtype288;
	Y5346_gen_type [289] = Y5346_pgtype289;
	Y5346_gen_type [290] = Y5346_pgtype290;
	Y5346_gen_type [291] = Y5346_pgtype291;
	Y5346_gen_type [292] = Y5346_pgtype292;
	Y5346_gen_type [293] = Y5346_pgtype293;
	Y5346_gen_type [294] = Y5346_pgtype294;
	Y5346_gen_type [295] = Y5346_pgtype295;
	Y5346_gen_type [296] = Y5346_pgtype296;
	Y5346_gen_type [297] = Y5346_pgtype297;
	Y5346_gen_type [298] = Y5346_pgtype298;
	Y5346_gen_type [299] = Y5346_pgtype299;
	Y5346_gen_type [300] = Y5346_pgtype300;
	Y5346_gen_type [301] = Y5346_pgtype301;
	Y5346_gen_type [302] = Y5346_pgtype302;
	Y5346_gen_type [303] = Y5346_pgtype303;
	Y5346_gen_type [304] = Y5346_pgtype304;
	Y5346_gen_type [305] = Y5346_pgtype305;
	Y5346_gen_type [306] = Y5346_pgtype306;
	Y5346_gen_type [307] = Y5346_pgtype307;
	Y5346_gen_type [308] = Y5346_pgtype308;
	Y5346_gen_type [309] = Y5346_pgtype309;
	Y5346_gen_type [310] = Y5346_pgtype310;
	Y5346_gen_type [311] = Y5346_pgtype311;
	Y5346_gen_type [312] = Y5346_pgtype312;
	Y5346_gen_type [313] = Y5346_pgtype313;
	Y5346_gen_type [314] = Y5346_pgtype314;
	Y5346_gen_type [315] = Y5346_pgtype315;
	Y5346_gen_type [316] = Y5346_pgtype316;
	Y5346_gen_type [317] = Y5346_pgtype317;
	Y5346_gen_type [318] = Y5346_pgtype318;
	Y5346_gen_type [319] = Y5346_pgtype319;
	Y5346_gen_type [320] = Y5346_pgtype320;
	Y5346_gen_type [321] = Y5346_pgtype321;
	Y5346_gen_type [322] = Y5346_pgtype322;
	Y5346_gen_type [323] = Y5346_pgtype323;
	Y5346_gen_type [324] = Y5346_pgtype324;
	Y5346_gen_type [325] = Y5346_pgtype325;
	Y5346_gen_type [326] = Y5346_pgtype326;
	Y5346_gen_type [327] = Y5346_pgtype327;
	Y5346_gen_type [328] = Y5346_pgtype328;
	Y5346_gen_type [329] = Y5346_pgtype329;
	Y5346_gen_type [330] = Y5346_pgtype330;
	Y5346_gen_type [331] = Y5346_pgtype331;
	Y5346_gen_type [332] = Y5346_pgtype332;
	Y5346_gen_type [333] = Y5346_pgtype333;
	Y5346_gen_type [334] = Y5346_pgtype334;
	Y5346_gen_type [335] = Y5346_pgtype335;
	Y5346_gen_type [336] = Y5346_pgtype336;
	Y5346_gen_type [337] = Y5346_pgtype337;
	Y5346_gen_type [338] = Y5346_pgtype338;
	Y5346_gen_type [339] = Y5346_pgtype339;
	Y5346_gen_type [340] = Y5346_pgtype340;
	Y5346_gen_type [341] = Y5346_pgtype341;
	Y5346_gen_type [342] = Y5346_pgtype342;
	Y5346_gen_type [343] = Y5346_pgtype343;
	Y5346_gen_type [344] = Y5346_pgtype344;
	Y5346_gen_type [345] = Y5346_pgtype345;
	Y5346_gen_type [346] = Y5346_pgtype346;
	Y5346_gen_type [347] = Y5346_pgtype347;
	Y5346_gen_type [348] = Y5346_pgtype348;
	Y5346_gen_type [349] = Y5346_pgtype349;
	Y5346_gen_type [350] = Y5346_pgtype350;
	Y5346_gen_type [351] = Y5346_pgtype351;
	Y5346_gen_type [352] = Y5346_pgtype352;
	Y5346_gen_type [353] = Y5346_pgtype353;
	Y5346_gen_type [354] = Y5346_pgtype354;
	Y5346_gen_type [355] = Y5346_pgtype355;
	Y5346_gen_type [356] = Y5346_pgtype356;
	Y5346_gen_type [357] = Y5346_pgtype357;
	Y5346_gen_type [358] = Y5346_pgtype358;
	Y5346_gen_type [359] = Y5346_pgtype359;
	Y5346_gen_type [360] = Y5346_pgtype360;
	Y5346_gen_type [361] = Y5346_pgtype361;
	Y5346_gen_type [362] = Y5346_pgtype362;
	Y5346_gen_type [363] = Y5346_pgtype363;
	Y5346_gen_type [364] = Y5346_pgtype364;
	Y5346_gen_type [365] = Y5346_pgtype365;
	Y5346_gen_type [366] = Y5346_pgtype366;
	Y5346_gen_type [367] = Y5346_pgtype367;
	Y5346_gen_type [368] = Y5346_pgtype368;
	Y5346_gen_type [369] = Y5346_pgtype369;
	Y5346_gen_type [370] = Y5346_pgtype370;
	Y5346_gen_type [371] = Y5346_pgtype371;
	Y5346_gen_type [372] = Y5346_pgtype372;
	Y5346_gen_type [373] = Y5346_pgtype373;
	Y5346_gen_type [374] = Y5346_pgtype374;
	Y5346_gen_type [375] = Y5346_pgtype375;
	Y5346_gen_type [376] = Y5346_pgtype376;
	Y5346_gen_type [377] = Y5346_pgtype377;
	Y5346_gen_type [378] = Y5346_pgtype378;
	Y5346_gen_type [379] = Y5346_pgtype379;
	Y5346_gen_type [380] = Y5346_pgtype380;
	Y5346_gen_type [381] = Y5346_pgtype381;
	Y5346_gen_type [382] = Y5346_pgtype382;
	Y5346_gen_type [383] = Y5346_pgtype383;
	Y5346_gen_type [384] = Y5346_pgtype384;
	Y5346_gen_type [385] = Y5346_pgtype385;
	Y5346_gen_type [386] = Y5346_pgtype386;
	Y5346_gen_type [387] = Y5346_pgtype387;
	Y5346_gen_type [388] = Y5346_pgtype388;
	Y5346_gen_type [389] = Y5346_pgtype389;
	Y5346_gen_type [390] = Y5346_pgtype390;
	Y5346_gen_type [391] = Y5346_pgtype391;
	Y5346_gen_type [392] = Y5346_pgtype392;
	Y5346_gen_type [393] = Y5346_pgtype393;
	Y5346_gen_type [394] = Y5346_pgtype394;
	Y5346_gen_type [395] = Y5346_pgtype395;
	Y5346_gen_type [396] = Y5346_pgtype396;
	Y5346_gen_type [397] = Y5346_pgtype397;
	Y5346_gen_type [398] = Y5346_pgtype398;
	Y5346_gen_type [399] = Y5346_pgtype399;
	Y5346_gen_type [400] = Y5346_pgtype400;
	Y5346_gen_type [401] = Y5346_pgtype401;
	Y5346_gen_type [402] = Y5346_pgtype402;
	Y5346_gen_type [403] = Y5346_pgtype403;
	Y5346_gen_type [404] = Y5346_pgtype404;
	Y5346_gen_type [405] = Y5346_pgtype405;
	Y5346_gen_type [406] = Y5346_pgtype406;
	Y5346_gen_type [407] = Y5346_pgtype407;
	Y5346_gen_type [408] = Y5346_pgtype408;
	Y5346_gen_type [409] = Y5346_pgtype409;
	Y5346_gen_type [410] = Y5346_pgtype410;
	Y5346_gen_type [411] = Y5346_pgtype411;
	Y5346_gen_type [412] = Y5346_pgtype412;
	Y5346_gen_type [413] = Y5346_pgtype413;
	Y5346_gen_type [414] = Y5346_pgtype414;
	Y5346_gen_type [415] = Y5346_pgtype415;
	Y5346_gen_type [416] = Y5346_pgtype416;
	Y5346_gen_type [417] = Y5346_pgtype417;
	Y5346_gen_type [418] = Y5346_pgtype418;
	Y5346_gen_type [419] = Y5346_pgtype419;
	Y5346_gen_type [420] = Y5346_pgtype420;
	Y5346_gen_type [421] = Y5346_pgtype421;
	Y5346_gen_type [422] = Y5346_pgtype422;
	Y5346_gen_type [423] = Y5346_pgtype423;
	Y5346_gen_type [424] = Y5346_pgtype424;
	Y5346_gen_type [425] = Y5346_pgtype425;
	Y5346_gen_type [426] = Y5346_pgtype426;
	Y5346_gen_type [427] = Y5346_pgtype427;
	Y5346_gen_type [428] = Y5346_pgtype428;
	Y5346_gen_type [429] = Y5346_pgtype429;
	Y5346_gen_type [430] = Y5346_pgtype430;
	Y5346_gen_type [431] = Y5346_pgtype431;
	Y5346_gen_type [432] = Y5346_pgtype432;
	Y5346_gen_type [433] = Y5346_pgtype433;
	Y5346_gen_type [434] = Y5346_pgtype434;
	Y5346_gen_type [435] = Y5346_pgtype435;
	Y5346_gen_type [436] = Y5346_pgtype436;
	Y5346_gen_type [437] = Y5346_pgtype437;
	Y5346_gen_type [438] = Y5346_pgtype438;
	Y5346_gen_type [439] = Y5346_pgtype439;
	Y5346_gen_type [440] = Y5346_pgtype440;
	Y5346_gen_type [441] = Y5346_pgtype441;
	Y5346_gen_type [442] = Y5346_pgtype442;
	Y5346_gen_type [443] = Y5346_pgtype443;
	Y5346_gen_type [444] = Y5346_pgtype444;
	Y5346_gen_type [445] = Y5346_pgtype445;
	Y5346_gen_type [446] = Y5346_pgtype446;
	Y5346_gen_type [447] = Y5346_pgtype447;
	Y5346_gen_type [448] = Y5346_pgtype448;
	Y5346_gen_type [449] = Y5346_pgtype449;
	Y5346_gen_type [450] = Y5346_pgtype450;
	Y5346_gen_type [451] = Y5346_pgtype451;
	Y5346_gen_type [452] = Y5346_pgtype452;
	Y5346_gen_type [453] = Y5346_pgtype453;
	Y5346_gen_type [454] = Y5346_pgtype454;
	Y5346_gen_type [455] = Y5346_pgtype455;
	Y5346_gen_type [456] = Y5346_pgtype456;
	Y5346_gen_type [457] = Y5346_pgtype457;
	Y5346_gen_type [458] = Y5346_pgtype458;
	Y5346_gen_type [459] = Y5346_pgtype459;
	Y5346_gen_type [460] = Y5346_pgtype460;
	Y5346_gen_type [461] = Y5346_pgtype461;
	Y5346_gen_type [462] = Y5346_pgtype462;
	Y5346_gen_type [463] = Y5346_pgtype463;
	Y5346_gen_type [464] = Y5346_pgtype464;
	Y5346_gen_type [465] = Y5346_pgtype465;
	Y5346_gen_type [466] = Y5346_pgtype466;
	Y5346_gen_type [467] = Y5346_pgtype467;
	Y5346_gen_type [468] = Y5346_pgtype468;
	Y5346_gen_type [469] = Y5346_pgtype469;
	Y5346_gen_type [530] = Y5346_pgtype470;
	Y5346_gen_type [585] = Y5346_pgtype471;
	Y5346_gen_type [586] = Y5346_pgtype472;
	Y5346_gen_type [587] = Y5346_pgtype473;
	Y5346_gen_type [588] = Y5346_pgtype474;
	Y5346_gen_type [589] = Y5346_pgtype475;
	Y5346_gen_type [590] = Y5346_pgtype476;
	Y5346_gen_type [591] = Y5346_pgtype477;
	Y5346_gen_type [593] = Y5346_pgtype478;
	Y5346_gen_type [594] = Y5346_pgtype479;
	Y5346_gen_type [645] = Y5346_pgtype480;
	Y5346_gen_type [646] = Y5346_pgtype481;
	Y5346_gen_type [647] = Y5346_pgtype482;
	Y5346_gen_type [648] = Y5346_pgtype483;
	Y5346_gen_type [649] = Y5346_pgtype484;
	Y5346_gen_type [650] = Y5346_pgtype485;
	Y5346_gen_type [651] = Y5346_pgtype486;
	Y5346_gen_type [652] = Y5346_pgtype487;
	Y5346_gen_type [653] = Y5346_pgtype488;
	Y5346_gen_type [654] = Y5346_pgtype489;
	Y5346_gen_type [655] = Y5346_pgtype490;
	Y5346_gen_type [656] = Y5346_pgtype491;
	Y5346_gen_type [749] = Y5346_pgtype492;
	Y5346_gen_type [750] = Y5346_pgtype493;
	Y5346_gen_type [765] = Y5346_pgtype494;
	Y5346_gen_type [766] = Y5346_pgtype495;
	Y5346_gen_type [767] = Y5346_pgtype496;
	Y5346_gen_type [768] = Y5346_pgtype497;
	Y5346_gen_type [815] = Y5346_pgtype498;
	Y5346_gen_type [816] = Y5346_pgtype499;
	Y5346_gen_type [817] = Y5346_pgtype500;
	Y5346_gen_type [819] = Y5346_pgtype501;
	Y5346_gen_type [820] = Y5346_pgtype502;
	Y5346_gen_type [821] = Y5346_pgtype503;
	Y5346_gen_type [822] = Y5346_pgtype504;
	Y5346_gen_type [823] = Y5346_pgtype505;
	Y5346_gen_type [855] = Y5346_pgtype506;
	Y5346_gen_type [856] = Y5346_pgtype507;
	Y5346[12] = 1031;
	Y5346[13] = 1082;
	Y5346[14] = 1085;
	Y5346[85] = 1034;
	Y5346[86] = 1031;
	Y5346[111] = 1090;
	{long i; for (i = 264; i < 266; i++) Y5346[i] = 1219;};
	{long i; for (i = 332; i < 335; i++) Y5346[i] = 1034;};
	Y5346[343] = 1084;
	Y5346[364] = 0;
	Y5346[382] = 1219;
	Y5346[466] = 1300;
	Y5346[469] = 964;
	Y5346[530] = 0;
	{long i; for (i = 585; i < 589; i++) Y5346[i] = 1034;};
	{long i; for (i = 589; i < 592; i++) Y5346[i] = 1031;};
	{long i; for (i = 593; i < 595; i++) Y5346[i] = 1090;};
	{long i; for (i = 749; i < 751; i++) Y5346[i] = 1208;};
	Y5346[765] = 1034;
	{long i; for (i = 815; i < 818; i++) Y5346[i] = 1034;};
	{long i; for (i = 819; i < 824; i++) Y5346[i] = 1034;};
	{long i; for (i = 855; i < 857; i++) Y5346[i] = 1034;};
}

char *(*R5398[72])();
void R5398_init () {
	R5398[0] = (char *(*)()) F535_6040;
	R5398[1] = (char *(*)()) F536_6040;
	R5398[2] = (char *(*)()) F537_6040;
	R5398[3] = (char *(*)()) F538_6040;
	R5398[4] = (char *(*)()) F539_6040;
	R5398[5] = (char *(*)()) F540_6040;
	R5398[6] = (char *(*)()) F541_6040;
	R5398[7] = (char *(*)()) F542_6040;
	R5398[8] = (char *(*)()) F543_6040;
	R5398[9] = (char *(*)()) F544_6040;
	R5398[10] = (char *(*)()) F545_6040;
	R5398[11] = (char *(*)()) F546_6040;
	{long i; for (i = 12; i < 14; i++) R5398[i] = (char *(*)()) F535_6040;}
	R5398[14] = (char *(*)()) F536_6040;
	R5398[15] = (char *(*)()) F537_6040;
	R5398[16] = (char *(*)()) F540_6040;
	R5398[17] = (char *(*)()) F537_6040;
	R5398[18] = (char *(*)()) F543_6040;
	R5398[19] = (char *(*)()) F544_6040;
	R5398[20] = (char *(*)()) F535_6040;
	R5398[21] = (char *(*)()) F537_6040;
	R5398[34] = (char *(*)()) F557_6074;
	R5398[35] = (char *(*)()) F558_6074;
	R5398[36] = (char *(*)()) F559_6074;
	R5398[37] = (char *(*)()) F560_6074;
	R5398[38] = (char *(*)()) F561_6074;
	R5398[39] = (char *(*)()) F562_6074;
	R5398[40] = (char *(*)()) F563_6074;
	R5398[41] = (char *(*)()) F564_6074;
	R5398[42] = (char *(*)()) F565_6074;
	R5398[43] = (char *(*)()) F566_6074;
	R5398[44] = (char *(*)()) F567_6074;
	R5398[45] = (char *(*)()) F568_6074;
	R5398[46] = (char *(*)()) F561_6074;
	R5398[47] = (char *(*)()) F563_6074;
	R5398[48] = (char *(*)()) F557_6074;
	R5398[49] = (char *(*)()) F558_6074;
	R5398[50] = (char *(*)()) F559_6074;
	R5398[51] = (char *(*)()) F560_6074;
	R5398[52] = (char *(*)()) F561_6074;
	R5398[53] = (char *(*)()) F562_6074;
	R5398[54] = (char *(*)()) F563_6074;
	R5398[55] = (char *(*)()) F564_6074;
	R5398[56] = (char *(*)()) F565_6074;
	R5398[57] = (char *(*)()) F566_6074;
	R5398[58] = (char *(*)()) F567_6074;
	R5398[59] = (char *(*)()) F568_6074;
	R5398[60] = (char *(*)()) F557_6074;
	R5398[61] = (char *(*)()) F558_6074;
	R5398[62] = (char *(*)()) F559_6074;
	R5398[63] = (char *(*)()) F560_6074;
	R5398[64] = (char *(*)()) F561_6074;
	R5398[65] = (char *(*)()) F562_6074;
	R5398[66] = (char *(*)()) F563_6074;
	R5398[67] = (char *(*)()) F564_6074;
	R5398[68] = (char *(*)()) F565_6074;
	R5398[69] = (char *(*)()) F566_6074;
	R5398[70] = (char *(*)()) F567_6074;
	R5398[71] = (char *(*)()) F568_6074;
}

char *(*R5399[72])();
void R5399_init () {
	R5399[0] = (char *(*)()) F535_6041;
	R5399[1] = (char *(*)()) F536_6041;
	R5399[2] = (char *(*)()) F537_6041;
	R5399[3] = (char *(*)()) F538_6041;
	R5399[4] = (char *(*)()) F539_6041;
	R5399[5] = (char *(*)()) F540_6041;
	R5399[6] = (char *(*)()) F541_6041;
	R5399[7] = (char *(*)()) F542_6041;
	R5399[8] = (char *(*)()) F543_6041;
	R5399[9] = (char *(*)()) F544_6041;
	R5399[10] = (char *(*)()) F545_6041;
	R5399[11] = (char *(*)()) F546_6041;
	{long i; for (i = 12; i < 14; i++) R5399[i] = (char *(*)()) F535_6041;}
	R5399[14] = (char *(*)()) F536_6041;
	R5399[15] = (char *(*)()) F537_6041;
	R5399[16] = (char *(*)()) F540_6041;
	R5399[17] = (char *(*)()) F537_6041;
	R5399[18] = (char *(*)()) F543_6041;
	R5399[19] = (char *(*)()) F544_6041;
	R5399[20] = (char *(*)()) F535_6041;
	R5399[21] = (char *(*)()) F537_6041;
	R5399[34] = (char *(*)()) F569_6093;
	R5399[35] = (char *(*)()) F570_6093;
	R5399[36] = (char *(*)()) F571_6093;
	R5399[37] = (char *(*)()) F572_6093;
	R5399[38] = (char *(*)()) F573_6093;
	R5399[39] = (char *(*)()) F574_6093;
	R5399[40] = (char *(*)()) F575_6093;
	R5399[41] = (char *(*)()) F576_6093;
	R5399[42] = (char *(*)()) F577_6093;
	R5399[43] = (char *(*)()) F578_6093;
	R5399[44] = (char *(*)()) F579_6093;
	R5399[45] = (char *(*)()) F580_6093;
	R5399[46] = (char *(*)()) F581_6099;
	R5399[47] = (char *(*)()) F582_6105;
	R5399[48] = (char *(*)()) F583_6111;
	R5399[49] = (char *(*)()) F584_6111;
	R5399[50] = (char *(*)()) F585_6111;
	R5399[51] = (char *(*)()) F586_6111;
	R5399[52] = (char *(*)()) F587_6111;
	R5399[53] = (char *(*)()) F588_6111;
	R5399[54] = (char *(*)()) F589_6111;
	R5399[55] = (char *(*)()) F590_6111;
	R5399[56] = (char *(*)()) F591_6111;
	R5399[57] = (char *(*)()) F592_6111;
	R5399[58] = (char *(*)()) F593_6111;
	R5399[59] = (char *(*)()) F594_6111;
	R5399[60] = (char *(*)()) F595_6117;
	R5399[61] = (char *(*)()) F596_6117;
	R5399[62] = (char *(*)()) F597_6117;
	R5399[63] = (char *(*)()) F598_6117;
	R5399[64] = (char *(*)()) F599_6117;
	R5399[65] = (char *(*)()) F600_6117;
	R5399[66] = (char *(*)()) F601_6117;
	R5399[67] = (char *(*)()) F602_6117;
	R5399[68] = (char *(*)()) F603_6117;
	R5399[69] = (char *(*)()) F604_6117;
	R5399[70] = (char *(*)()) F605_6117;
	R5399[71] = (char *(*)()) F606_6117;
}

char *(*R5407[22])();
void R5407_init () {
	R5407[0] = (char *(*)()) F535_6052;
	R5407[1] = (char *(*)()) F536_6052;
	R5407[2] = (char *(*)()) F537_6052;
	R5407[3] = (char *(*)()) F538_6052;
	R5407[4] = (char *(*)()) F539_6052;
	R5407[5] = (char *(*)()) F540_6052;
	R5407[6] = (char *(*)()) F541_6052;
	R5407[7] = (char *(*)()) F542_6052;
	R5407[8] = (char *(*)()) F543_6052;
	R5407[9] = (char *(*)()) F544_6052;
	R5407[10] = (char *(*)()) F545_6052;
	R5407[11] = (char *(*)()) F546_6052;
	{long i; for (i = 12; i < 14; i++) R5407[i] = (char *(*)()) F535_6052;}
	R5407[14] = (char *(*)()) F536_6052;
	R5407[15] = (char *(*)()) F537_6052;
	R5407[16] = (char *(*)()) F540_6052;
	R5407[17] = (char *(*)()) F537_6052;
	R5407[18] = (char *(*)()) F543_6052;
	R5407[19] = (char *(*)()) F544_6052;
	R5407[20] = (char *(*)()) F535_6052;
	R5407[21] = (char *(*)()) F537_6052;
}

char *(*R5409[72])();
void R5409_init () {
	R5409[0] = (char *(*)()) F535_6054;
	R5409[1] = (char *(*)()) F536_6054;
	R5409[2] = (char *(*)()) F537_6054;
	R5409[3] = (char *(*)()) F538_6054;
	R5409[4] = (char *(*)()) F539_6054;
	R5409[5] = (char *(*)()) F540_6054;
	R5409[6] = (char *(*)()) F541_6054;
	R5409[7] = (char *(*)()) F542_6054;
	R5409[8] = (char *(*)()) F543_6054;
	R5409[9] = (char *(*)()) F544_6054;
	R5409[10] = (char *(*)()) F545_6054;
	R5409[11] = (char *(*)()) F546_6054;
	{long i; for (i = 12; i < 14; i++) R5409[i] = (char *(*)()) F535_6054;}
	R5409[14] = (char *(*)()) F536_6054;
	R5409[15] = (char *(*)()) F537_6054;
	R5409[16] = (char *(*)()) F540_6054;
	R5409[17] = (char *(*)()) F537_6054;
	R5409[18] = (char *(*)()) F543_6054;
	R5409[19] = (char *(*)()) F544_6054;
	R5409[20] = (char *(*)()) F535_6054;
	R5409[21] = (char *(*)()) F537_6054;
	R5409[34] = (char *(*)()) F557_6085;
	R5409[35] = (char *(*)()) F558_6085;
	R5409[36] = (char *(*)()) F559_6085;
	R5409[37] = (char *(*)()) F560_6085;
	R5409[38] = (char *(*)()) F561_6085;
	R5409[39] = (char *(*)()) F562_6085;
	R5409[40] = (char *(*)()) F563_6085;
	R5409[41] = (char *(*)()) F564_6085;
	R5409[42] = (char *(*)()) F565_6085;
	R5409[43] = (char *(*)()) F566_6085;
	R5409[44] = (char *(*)()) F567_6085;
	R5409[45] = (char *(*)()) F568_6085;
	R5409[46] = (char *(*)()) F561_6085;
	R5409[47] = (char *(*)()) F563_6085;
	R5409[48] = (char *(*)()) F557_6085;
	R5409[49] = (char *(*)()) F558_6085;
	R5409[50] = (char *(*)()) F559_6085;
	R5409[51] = (char *(*)()) F560_6085;
	R5409[52] = (char *(*)()) F561_6085;
	R5409[53] = (char *(*)()) F562_6085;
	R5409[54] = (char *(*)()) F563_6085;
	R5409[55] = (char *(*)()) F564_6085;
	R5409[56] = (char *(*)()) F565_6085;
	R5409[57] = (char *(*)()) F566_6085;
	R5409[58] = (char *(*)()) F567_6085;
	R5409[59] = (char *(*)()) F568_6085;
	R5409[60] = (char *(*)()) F557_6085;
	R5409[61] = (char *(*)()) F558_6085;
	R5409[62] = (char *(*)()) F559_6085;
	R5409[63] = (char *(*)()) F560_6085;
	R5409[64] = (char *(*)()) F561_6085;
	R5409[65] = (char *(*)()) F562_6085;
	R5409[66] = (char *(*)()) F563_6085;
	R5409[67] = (char *(*)()) F564_6085;
	R5409[68] = (char *(*)()) F565_6085;
	R5409[69] = (char *(*)()) F566_6085;
	R5409[70] = (char *(*)()) F567_6085;
	R5409[71] = (char *(*)()) F568_6085;
}

char *(*R5410[72])();
void R5410_init () {
	R5410[0] = (char *(*)()) F535_6057;
	R5410[1] = (char *(*)()) F536_6057;
	R5410[2] = (char *(*)()) F537_6057;
	R5410[3] = (char *(*)()) F538_6057;
	R5410[4] = (char *(*)()) F539_6057;
	R5410[5] = (char *(*)()) F540_6057;
	R5410[6] = (char *(*)()) F541_6057;
	R5410[7] = (char *(*)()) F542_6057;
	R5410[8] = (char *(*)()) F543_6057;
	R5410[9] = (char *(*)()) F544_6057;
	R5410[10] = (char *(*)()) F545_6057;
	R5410[11] = (char *(*)()) F546_6057;
	{long i; for (i = 12; i < 14; i++) R5410[i] = (char *(*)()) F535_6057;}
	R5410[14] = (char *(*)()) F536_6057;
	R5410[15] = (char *(*)()) F537_6057;
	R5410[16] = (char *(*)()) F540_6057;
	R5410[17] = (char *(*)()) F537_6057;
	R5410[18] = (char *(*)()) F543_6057;
	R5410[19] = (char *(*)()) F544_6057;
	R5410[20] = (char *(*)()) F555_6068;
	R5410[21] = (char *(*)()) F556_6068;
	R5410[34] = (char *(*)()) F557_6086;
	R5410[35] = (char *(*)()) F558_6086;
	R5410[36] = (char *(*)()) F559_6086;
	R5410[37] = (char *(*)()) F560_6086;
	R5410[38] = (char *(*)()) F561_6086;
	R5410[39] = (char *(*)()) F562_6086;
	R5410[40] = (char *(*)()) F563_6086;
	R5410[41] = (char *(*)()) F564_6086;
	R5410[42] = (char *(*)()) F565_6086;
	R5410[43] = (char *(*)()) F566_6086;
	R5410[44] = (char *(*)()) F567_6086;
	R5410[45] = (char *(*)()) F568_6086;
	R5410[46] = (char *(*)()) F561_6086;
	R5410[47] = (char *(*)()) F563_6086;
	R5410[48] = (char *(*)()) F557_6086;
	R5410[49] = (char *(*)()) F558_6086;
	R5410[50] = (char *(*)()) F559_6086;
	R5410[51] = (char *(*)()) F560_6086;
	R5410[52] = (char *(*)()) F561_6086;
	R5410[53] = (char *(*)()) F562_6086;
	R5410[54] = (char *(*)()) F563_6086;
	R5410[55] = (char *(*)()) F564_6086;
	R5410[56] = (char *(*)()) F565_6086;
	R5410[57] = (char *(*)()) F566_6086;
	R5410[58] = (char *(*)()) F567_6086;
	R5410[59] = (char *(*)()) F568_6086;
	R5410[60] = (char *(*)()) F557_6086;
	R5410[61] = (char *(*)()) F558_6086;
	R5410[62] = (char *(*)()) F559_6086;
	R5410[63] = (char *(*)()) F560_6086;
	R5410[64] = (char *(*)()) F561_6086;
	R5410[65] = (char *(*)()) F562_6086;
	R5410[66] = (char *(*)()) F563_6086;
	R5410[67] = (char *(*)()) F564_6086;
	R5410[68] = (char *(*)()) F565_6086;
	R5410[69] = (char *(*)()) F566_6086;
	R5410[70] = (char *(*)()) F567_6086;
	R5410[71] = (char *(*)()) F568_6086;
}

char *(*R5411[72])();
void R5411_init () {
	R5411[0] = (char *(*)()) F535_6059;
	R5411[1] = (char *(*)()) F536_6059;
	R5411[2] = (char *(*)()) F537_6059;
	R5411[3] = (char *(*)()) F538_6059;
	R5411[4] = (char *(*)()) F539_6059;
	R5411[5] = (char *(*)()) F540_6059;
	R5411[6] = (char *(*)()) F541_6059;
	R5411[7] = (char *(*)()) F542_6059;
	R5411[8] = (char *(*)()) F543_6059;
	R5411[9] = (char *(*)()) F544_6059;
	R5411[10] = (char *(*)()) F545_6059;
	R5411[11] = (char *(*)()) F546_6059;
	R5411[12] = (char *(*)()) F547_6065;
	R5411[13] = (char *(*)()) F548_6065;
	R5411[14] = (char *(*)()) F549_6065;
	R5411[15] = (char *(*)()) F550_6065;
	R5411[16] = (char *(*)()) F551_6065;
	R5411[17] = (char *(*)()) F552_6065;
	R5411[18] = (char *(*)()) F553_6065;
	R5411[19] = (char *(*)()) F554_6065;
	R5411[20] = (char *(*)()) F555_6070;
	R5411[21] = (char *(*)()) F556_6070;
	R5411[34] = (char *(*)()) F569_6096;
	R5411[35] = (char *(*)()) F570_6096;
	R5411[36] = (char *(*)()) F571_6096;
	R5411[37] = (char *(*)()) F572_6096;
	R5411[38] = (char *(*)()) F573_6096;
	R5411[39] = (char *(*)()) F574_6096;
	R5411[40] = (char *(*)()) F575_6096;
	R5411[41] = (char *(*)()) F576_6096;
	R5411[42] = (char *(*)()) F577_6096;
	R5411[43] = (char *(*)()) F578_6096;
	R5411[44] = (char *(*)()) F579_6096;
	R5411[45] = (char *(*)()) F580_6096;
	R5411[46] = (char *(*)()) F581_6102;
	R5411[47] = (char *(*)()) F582_6108;
	R5411[48] = (char *(*)()) F583_6114;
	R5411[49] = (char *(*)()) F584_6114;
	R5411[50] = (char *(*)()) F585_6114;
	R5411[51] = (char *(*)()) F586_6114;
	R5411[52] = (char *(*)()) F587_6114;
	R5411[53] = (char *(*)()) F588_6114;
	R5411[54] = (char *(*)()) F589_6114;
	R5411[55] = (char *(*)()) F590_6114;
	R5411[56] = (char *(*)()) F591_6114;
	R5411[57] = (char *(*)()) F592_6114;
	R5411[58] = (char *(*)()) F593_6114;
	R5411[59] = (char *(*)()) F594_6114;
	R5411[60] = (char *(*)()) F557_6088;
	R5411[61] = (char *(*)()) F558_6088;
	R5411[62] = (char *(*)()) F559_6088;
	R5411[63] = (char *(*)()) F560_6088;
	R5411[64] = (char *(*)()) F561_6088;
	R5411[65] = (char *(*)()) F562_6088;
	R5411[66] = (char *(*)()) F563_6088;
	R5411[67] = (char *(*)()) F564_6088;
	R5411[68] = (char *(*)()) F565_6088;
	R5411[69] = (char *(*)()) F566_6088;
	R5411[70] = (char *(*)()) F567_6088;
	R5411[71] = (char *(*)()) F568_6088;
}


#ifdef __cplusplus
}
#endif
