
#ifndef _C15_to731_
#define _C15_to731_

#ifdef __cplusplus
extern "C" {
#endif

extern void F416_4946(EIF_REFERENCE, EIF_INTEGER_32);
extern void F416_4947(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F416_4953(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit731(void);
extern char *(*R7704[])();
extern EIF_TYPE_INDEX Y4515[];
extern EIF_TYPE_INDEX *Y4515_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
