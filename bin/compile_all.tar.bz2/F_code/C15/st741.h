
#ifndef _C15_st741_
#define _C15_st741_

#ifdef __cplusplus
extern "C" {
#endif

extern void F861_6845(EIF_REFERENCE, EIF_INTEGER_32);
extern void F861_6846(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F861_6847(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F861_6849(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F861_6850(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F861_6851(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit741(void);
extern EIF_BOOLEAN F1078_8207(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1078_8175(EIF_REFERENCE);
extern EIF_BOOLEAN F852_6744(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5800[])();
extern char *(*R5801[])();
extern char *(*R5459[])();
extern char *(*R6582[])();
extern char *(*R6947[])();
extern char *(*R5901[])();
extern long O5903[];
extern long O5457[];

#ifdef __cplusplus
}
#endif

#endif
