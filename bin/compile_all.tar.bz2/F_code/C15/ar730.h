
#ifndef _C15_ar730_
#define _C15_ar730_

#ifdef __cplusplus
extern "C" {
#endif

extern void F569_6092(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F569_6093(EIF_REFERENCE);
extern EIF_REFERENCE F569_6094(EIF_REFERENCE);
extern EIF_REFERENCE F569_6096(EIF_REFERENCE);
extern EIF_INTEGER_32 F569_6097(EIF_REFERENCE);
extern void EIF_Minit730(void);
extern char *(*R5428[])();
extern char *(*R6003[])();
extern char *(*R6007[])();
extern EIF_TYPE_INDEX Y5317[];
extern EIF_TYPE_INDEX *Y5317_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
