
#ifndef _C15_ar732_
#define _C15_ar732_

#ifdef __cplusplus
extern "C" {
#endif

extern void F583_6110(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F583_6111(EIF_REFERENCE);
extern EIF_REFERENCE F583_6112(EIF_REFERENCE);
extern EIF_REFERENCE F583_6114(EIF_REFERENCE);
extern EIF_INTEGER_32 F583_6115(EIF_REFERENCE);
extern void EIF_Minit732(void);
extern char *(*R5436[])();
extern EIF_TYPE_INDEX Y5317[];
extern EIF_TYPE_INDEX *Y5317_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
