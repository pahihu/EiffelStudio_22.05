
#ifndef _C15_sp724_
#define _C15_sp724_

#ifdef __cplusplus
extern "C" {
#endif

extern void F595_6116(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F595_6117(EIF_REFERENCE);
extern EIF_REFERENCE F595_6118(EIF_REFERENCE);
extern EIF_INTEGER_32 F595_6119(EIF_REFERENCE);
extern void EIF_Minit724(void);
extern char *(*R5439[])();
extern char *(*R5797[])();
extern EIF_TYPE_INDEX Y5317[];
extern EIF_TYPE_INDEX *Y5317_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
