/*
 * Code for class STRING_TABLE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st741.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STRING_TABLE}.make_caseless */
void F861_6845 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_caseless", 860, Current, 0, 1, 8949);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O5903[dtype-860]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5800[dtype-851])(Current, arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {STRING_TABLE}.make_equal_caseless */
void F861_6846 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_equal_caseless", 860, Current, 0, 1, 8950);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O5903[dtype-860]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5801[dtype-851])(Current, arg1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {STRING_TABLE}.hash_code_of */
EIF_INTEGER_32 F861_6847 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("hash_code_of", 860, Current, 0, 1, 8951);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O5903[Dtype(Current)-860])) {
		RTHOOK(2);
		ti4_1 = F1078_8175(RTCW(arg1));
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		RTHOOK(4);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6582[Dtype(RTCW(arg1))-1025])(arg1);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ti4_1;
	}/* NOTREACHED */
	
}

/* {STRING_TABLE}.same_keys */
EIF_BOOLEAN F861_6849 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTEAA("same_keys", 860, Current, 0, 2, 8953);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O5903[Dtype(Current)-860])) {
		RTHOOK(2);
		tb1 = F1078_8207(RTCW(arg1), arg2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTHOOK(4);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6947[Dtype(RTCW(arg1))-1081])(arg1, arg2);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) tb1;
	}/* NOTREACHED */
	
}

/* {STRING_TABLE}.is_equal */
EIF_BOOLEAN F861_6850 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("is_equal", 860, Current, 0, 1, 8954);
	RTGC;
	RTHOOK(1);
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O5903[Dtype(arg1)-860]);
	if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O5903[Dtype(Current)-860]) == tb1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) F852_6744(Current, arg1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {STRING_TABLE}.empty_duplicate */
EIF_REFERENCE F861_6851 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("empty_duplicate", 860, Current, 0, 1, 8948);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O5903[dtype-860])) {
		RTHOOK(2);
		Result = RTLNSMART(dftype);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5901[Dtype(RTCW(Result))-860])(Result, arg1);
	} else {
		RTHOOK(3);
		Result = RTLNSMART(dftype);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5800[Dtype(RTCW(Result))-851])(Result, arg1);
	}
	RTHOOK(4);
	if (*(EIF_BOOLEAN *)(Current + O5457[dtype-607])) {
		RTHOOK(5);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5459[Dtype(RTCW(Result))-759])(Result);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit741 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
