
#ifndef _C15_ch702_
#define _C15_ch702_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F896_6953(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F896_6955(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F896_6958(EIF_REFERENCE);
extern EIF_BOOLEAN F896_6963(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F896_6964(EIF_REFERENCE);
extern EIF_BOOLEAN F896_6965(EIF_REFERENCE);
extern EIF_BOOLEAN F896_6966(EIF_REFERENCE);
extern void F896_6969(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F896_6970(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit702(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern EIF_BOOLEAN F632_6151(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5485[])();
extern char *(*R5561[])();
extern char *(*R5498[])();
extern char *(*R5965[])();
extern char *(*R5465[])();
extern char *(*R5455[])();
extern char *(*R5504[])();
extern char *(*R5506[])();
extern char *(*R5502[])();
extern char *(*R5472[])();
extern char *(*R5475[])();
extern char *(*R5477[])();
extern char *(*R5478[])();

#ifdef __cplusplus
}
#endif

#endif
