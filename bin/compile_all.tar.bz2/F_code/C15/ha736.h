
#ifndef _C15_ha736_
#define _C15_ha736_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F547_6060(EIF_REFERENCE);
extern EIF_REFERENCE F547_6061(EIF_REFERENCE);
extern EIF_BOOLEAN F547_6063(EIF_REFERENCE);
extern void F547_6064(EIF_REFERENCE);
extern EIF_REFERENCE F547_6065(EIF_REFERENCE);
extern void EIF_Minit736(void);
extern char *(*R5831[])();
extern char *(*R5832[])();
extern char *(*R5407[])();
extern char *(*R7700[])();
extern char *(*R5795[])();
extern long O5840[];
extern long O5841[];

#ifdef __cplusplus
}
#endif

#endif
