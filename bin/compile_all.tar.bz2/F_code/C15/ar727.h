
#ifndef _C15_ar727_
#define _C15_ar727_

#ifdef __cplusplus
extern "C" {
#endif

extern void F879_6891(EIF_REFERENCE);
extern void F879_6892(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F879_6893(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F879_6895(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F879_6897(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F879_6900(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F879_6901(EIF_REFERENCE);
extern EIF_INTEGER_32 F879_6902(EIF_REFERENCE);
extern EIF_INTEGER_32 F879_6903(EIF_REFERENCE);
extern EIF_INTEGER_32 F879_6904(EIF_REFERENCE);
extern EIF_INTEGER_32 F879_6905(EIF_REFERENCE);
extern EIF_BOOLEAN F879_6907(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F879_6912(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F879_6913(EIF_REFERENCE);
extern void F879_6916(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F879_6918(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F879_6921(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F879_6935(EIF_REFERENCE, EIF_INTEGER_32);
extern void F879_6937(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F879_6944(EIF_REFERENCE);
extern void F879_6945(EIF_REFERENCE, EIF_REFERENCE);
extern void F879_6948(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F879_6949(EIF_REFERENCE);
extern void EIF_Minit727(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R5485[])();
extern char *(*R4513[])();
extern char *(*R4514[])();
extern char *(*R5951[])();
extern char *(*R5566[])();
extern char *(*R7732[])();
extern char *(*R5999[])();
extern char *(*R5958[])();
extern char *(*R5491[])();
extern char *(*R4520[])();
extern char *(*R7700[])();
extern char *(*R7701[])();
extern char *(*R7731[])();
extern char *(*R5562[])();
extern char *(*R7713[])();
extern char *(*R7714[])();
extern char *(*R7716[])();
extern char *(*R7718[])();
extern char *(*R5561[])();
extern char *(*R5436[])();
extern char *(*R7688[])();
extern char *(*R7721[])();
extern char *(*R7722[])();
extern char *(*R5795[])();
extern EIF_TYPE_INDEX Y5346[];
extern EIF_TYPE_INDEX *Y5346_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
