
#ifndef _C15_co700_
#define _C15_co700_

#ifdef __cplusplus
extern "C" {
#endif

extern void F656_6176(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit700(void);
extern char *(*R5485[])();
extern char *(*R5461[])();
extern char *(*R5463[])();
extern char *(*R5464[])();
extern char *(*R5465[])();
extern char *(*R5478[])();
extern char *(*R5481[])();

#ifdef __cplusplus
}
#endif

#endif
