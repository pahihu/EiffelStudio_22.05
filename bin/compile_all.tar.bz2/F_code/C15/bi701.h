
#ifndef _C15_bi701_
#define _C15_bi701_

#ifdef __cplusplus
extern "C" {
#endif

extern void F644_6170(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit701(void);
extern void F632_6153(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5455[])();
extern char *(*R5478[])();
extern char *(*R5479[])();

#ifdef __cplusplus
}
#endif

#endif
