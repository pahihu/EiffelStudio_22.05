
#ifndef _C15_re728_
#define _C15_re728_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F786_6298(EIF_REFERENCE);
extern void F786_6300(EIF_REFERENCE);
extern void EIF_Minit728(void);
extern char *(*R5562[])();
extern char *(*R5566[])();
extern char *(*R5568[])();

#ifdef __cplusplus
}
#endif

#endif
