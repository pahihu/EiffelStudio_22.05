
#ifndef _C15_dy720_
#define _C15_dy720_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F908_6975(EIF_REFERENCE);
extern void EIF_Minit720(void);

#ifdef __cplusplus
}
#endif

#endif
