
#ifndef _C15_ge725_
#define _C15_ge725_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F557_6072(EIF_REFERENCE);
extern EIF_INTEGER_32 F557_6074(EIF_REFERENCE);
extern EIF_BOOLEAN F557_6081(EIF_REFERENCE);
extern EIF_BOOLEAN F557_6085(EIF_REFERENCE);
extern void F557_6086(EIF_REFERENCE);
extern void F557_6087(EIF_REFERENCE);
extern EIF_REFERENCE F557_6088(EIF_REFERENCE);
extern void EIF_Minit725(void);
extern char *(*R5426[])();
extern char *(*R5399[])();
extern char *(*R5795[])();
extern long O5425[];
extern long O5427[];

#ifdef __cplusplus
}
#endif

#endif
