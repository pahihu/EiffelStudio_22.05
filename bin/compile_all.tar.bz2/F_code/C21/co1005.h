
#ifndef _C21_co1005_
#define _C21_co1005_

#ifdef __cplusplus
extern "C" {
#endif

extern void F662_6176(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1005(void);
extern EIF_CHARACTER_32 F955_7076(EIF_REFERENCE);
extern void F955_7104(EIF_REFERENCE);
extern EIF_BOOLEAN F902_6966(EIF_REFERENCE);
extern void F955_7102(EIF_REFERENCE);
extern char *(*R5485[])();
extern char *(*R5461[])();
extern char *(*R5481[])();

#ifdef __cplusplus
}
#endif

#endif
