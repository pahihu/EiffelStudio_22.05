/*
 * Code for class LINEAR [NATURAL_16]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li1040.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.has */
EIF_BOOLEAN F639_6151 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("has", 638, Current, 0, 1, 7135);
	RTGC;
	RTHOOK(1);
	F956_7102(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !F903_6966(Current)) {
		RTHOOK(3);
		F956_7108(Current, arg1);
	}
	RTHOOK(4);
	Result = F639_6157(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {LINEAR}.search */
void F639_6153 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 638, Current, 0, 1, 7137);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O5457[Dtype(Current)-607])) {
		for (;;) {
			RTHOOK(2);
			tb1 = '\01';
			if (!F639_6157(Current)) {
				tb1 = (arg1 == F956_7076(Current));
			}
			if (tb1) break;
			RTHOOK(3);
			F956_7104(Current);
		}
	} else {
		for (;;) {
			RTHOOK(4);
			tb2 = '\01';
			if (!F639_6157(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == F956_7076(Current));
			}
			if (tb2) break;
			RTHOOK(5);
			F956_7104(Current);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F639_6157 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("exhausted", 638, Current, 0, 0, 7140);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F903_6966(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F639_6159 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 638, Current, 0, 0, 7141);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F769_6292(Current)) {
		Result = F927_6990(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {LINEAR}.linear_representation */
EIF_REFERENCE F639_6166 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("linear_representation", 638, Current, 0, 0, 7146);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) Current;
}

void EIF_Minit1040 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
