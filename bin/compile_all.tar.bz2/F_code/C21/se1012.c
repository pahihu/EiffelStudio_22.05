/*
 * Code for class SEQUENCE [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "se1012.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SEQUENCE}.readable */
EIF_BOOLEAN F810_6347 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("readable", 809, Current, 0, 0, 7608);
	RTGC;
	RTHOOK(1);
	Result = F902_6966(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {SEQUENCE}.force */
void F810_6349 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("force", 809, Current, 0, 1, 7610);
	RTHOOK(1);
	F955_7112(Current, arg1);
	RTHOOK(4);
	RTEE;
}

void EIF_Minit1012 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
