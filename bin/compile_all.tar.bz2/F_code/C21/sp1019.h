
#ifndef _C21_sp1019_
#define _C21_sp1019_

#ifdef __cplusplus
extern "C" {
#endif

extern void F601_6116(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F601_6117(EIF_REFERENCE);
extern EIF_REFERENCE F601_6118(EIF_REFERENCE);
extern EIF_INTEGER_32 F601_6119(EIF_REFERENCE);
extern void EIF_Minit1019(void);
extern EIF_INTEGER_32 F1147_9217(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5317[];
extern EIF_TYPE_INDEX *Y5317_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
