
#ifndef _C21_fi1045_
#define _C21_fi1045_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F769_6292(EIF_REFERENCE);
extern void EIF_Minit1045(void);
extern char *(*R5561[])();

#ifdef __cplusplus
}
#endif

#endif
