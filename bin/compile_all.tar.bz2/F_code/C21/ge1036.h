
#ifndef _C21_ge1036_
#define _C21_ge1036_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_16 F564_6072(EIF_REFERENCE);
extern EIF_INTEGER_32 F564_6074(EIF_REFERENCE);
extern EIF_BOOLEAN F564_6081(EIF_REFERENCE);
extern EIF_BOOLEAN F564_6085(EIF_REFERENCE);
extern void F564_6086(EIF_REFERENCE);
extern void F564_6087(EIF_REFERENCE);
extern EIF_REFERENCE F564_6088(EIF_REFERENCE);
extern void EIF_Minit1036(void);
extern char *(*R5426[])();
extern char *(*R5399[])();
extern long O5425[];
extern long O5427[];

#ifdef __cplusplus
}
#endif

#endif
