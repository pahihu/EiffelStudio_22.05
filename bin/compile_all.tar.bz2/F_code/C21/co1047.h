
#ifndef _C21_co1047_
#define _C21_co1047_

#ifdef __cplusplus
extern "C" {
#endif

extern void F663_6176(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1047(void);
extern EIF_NATURAL_16 F956_7076(EIF_REFERENCE);
extern void F956_7104(EIF_REFERENCE);
extern EIF_BOOLEAN F903_6966(EIF_REFERENCE);
extern void F956_7102(EIF_REFERENCE);
extern char *(*R5485[])();
extern char *(*R5461[])();
extern char *(*R5481[])();

#ifdef __cplusplus
}
#endif

#endif
