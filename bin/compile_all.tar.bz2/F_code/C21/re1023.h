
#ifndef _C21_re1023_
#define _C21_re1023_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F792_6298(EIF_REFERENCE);
extern void F792_6300(EIF_REFERENCE);
extern void EIF_Minit1023(void);
extern char *(*R5562[])();
extern char *(*R5568[])();

#ifdef __cplusplus
}
#endif

#endif
