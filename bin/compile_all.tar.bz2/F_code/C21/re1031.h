
#ifndef _C21_re1031_
#define _C21_re1031_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F847_6716(EIF_REFERENCE);
extern void EIF_Minit1031(void);
extern void F542_6038(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5410[])();
extern EIF_TYPE_INDEX Y5346[];
extern EIF_TYPE_INDEX *Y5346_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
