
#ifndef _C21_sp1029_
#define _C21_sp1029_

#ifdef __cplusplus
extern "C" {
#endif

extern void F602_6116(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F602_6117(EIF_REFERENCE);
extern EIF_REFERENCE F602_6118(EIF_REFERENCE);
extern EIF_INTEGER_32 F602_6119(EIF_REFERENCE);
extern void EIF_Minit1029(void);
extern EIF_INTEGER_32 F1148_9217(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5317[];
extern EIF_TYPE_INDEX *Y5317_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
