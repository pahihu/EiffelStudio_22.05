/*
 * Code for class COLLECTION [NATURAL_16]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1047.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COLLECTION}.fill */
void F663_6176 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_16 tu2_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("fill", 662, Current, 1, 1, 7257);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5461[Dtype(RTCW(arg1))-759])(arg1);
	RTHOOK(2);
	F956_7102(RTCW(loc1));
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5481[dtype-759])(Current)) {
			tb2 = F903_6966(RTCW(loc1));
			tb1 = tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		tu2_1 = F956_7076(RTCW(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[dtype-759])(Current, (EIF_REFERENCE) &tu2_1);
		RTHOOK(5);
		F956_7104(RTCW(loc1));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

void EIF_Minit1047 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
