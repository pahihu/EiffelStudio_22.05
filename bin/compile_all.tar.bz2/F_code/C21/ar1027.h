
#ifndef _C21_ar1027_
#define _C21_ar1027_

#ifdef __cplusplus
extern "C" {
#endif

extern void F575_6092(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F575_6093(EIF_REFERENCE);
extern EIF_REFERENCE F575_6094(EIF_REFERENCE);
extern EIF_REFERENCE F575_6096(EIF_REFERENCE);
extern EIF_INTEGER_32 F575_6097(EIF_REFERENCE);
extern void EIF_Minit1027(void);
extern EIF_INTEGER_32 F955_7094(EIF_REFERENCE);
extern EIF_REFERENCE F955_7075(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5317[];
extern EIF_TYPE_INDEX *Y5317_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
