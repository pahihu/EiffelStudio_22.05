
#ifndef _C21_ge1020_
#define _C21_ge1020_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F563_6072(EIF_REFERENCE);
extern EIF_INTEGER_32 F563_6074(EIF_REFERENCE);
extern EIF_BOOLEAN F563_6081(EIF_REFERENCE);
extern EIF_BOOLEAN F563_6085(EIF_REFERENCE);
extern void F563_6086(EIF_REFERENCE);
extern void F563_6087(EIF_REFERENCE);
extern EIF_REFERENCE F563_6088(EIF_REFERENCE);
extern void EIF_Minit1020(void);
extern char *(*R5426[])();
extern char *(*R5399[])();
extern long O5425[];
extern long O5427[];

#ifdef __cplusplus
}
#endif

#endif
