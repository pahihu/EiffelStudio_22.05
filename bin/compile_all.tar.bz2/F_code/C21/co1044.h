
#ifndef _C21_co1044_
#define _C21_co1044_

#ifdef __cplusplus
extern "C" {
#endif

extern void F615_6140(EIF_REFERENCE);
extern void EIF_Minit1044(void);
extern long O5457[];

#ifdef __cplusplus
}
#endif

#endif
