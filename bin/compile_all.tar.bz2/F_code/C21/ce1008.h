
#ifndef _C21_ce1008_
#define _C21_ce1008_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F193_2534(EIF_REFERENCE);
extern void F193_2535(EIF_REFERENCE, EIF_INTEGER_32);
extern void F193_2536(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1008(void);
extern long O2464[];

#ifdef __cplusplus
}
#endif

#endif
