/*
 * Code for class SPECIAL_ITERATION_CURSOR [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sp1019.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SPECIAL_ITERATION_CURSOR}.make */
void F601_6116 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make", 600, Current, 0, 1, 6878);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	ti4_1 = F1147_9217(RTCW(arg1));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {SPECIAL_ITERATION_CURSOR}.first_index */
EIF_INTEGER_32 F601_6117 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

/* {SPECIAL_ITERATION_CURSOR}.new_cursor */
EIF_REFERENCE F601_6118 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("new_cursor", 600, Current, 0, 0, 6880);
	RTGC;
	RTHOOK(1);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFF01,600,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y5317,Y5317_gen_type,Dftype(Current),467);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 600, _OBJSIZ_1_0_0_2_0_0_0_0_);
	}
	F601_6116(RTCW(tr1), *(EIF_REFERENCE *)(Current));
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {SPECIAL_ITERATION_CURSOR}.area_first_index */
EIF_INTEGER_32 F601_6119 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

void EIF_Minit1019 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
