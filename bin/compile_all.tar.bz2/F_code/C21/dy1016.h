
#ifndef _C21_dy1016_
#define _C21_dy1016_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F914_6975(EIF_REFERENCE);
extern void EIF_Minit1016(void);

#ifdef __cplusplus
}
#endif

#endif
