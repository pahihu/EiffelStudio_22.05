/*
 * Code for class CELL [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ce1008.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CELL}.item */
EIF_INTEGER_32 F193_2534 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O2464[Dtype(Current)-189]);
}


/* {CELL}.put */
void F193_2535 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("put", 192, Current, 0, 1, 2724);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O2464[Dtype(Current)-189]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CELL}.replace */
void F193_2536 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("replace", 192, Current, 0, 1, 2725);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O2464[Dtype(Current)-189]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit1008 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
