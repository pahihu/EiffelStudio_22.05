
#ifndef _C21_se1012_
#define _C21_se1012_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F810_6347(EIF_REFERENCE);
extern void F810_6349(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1012(void);
extern EIF_BOOLEAN F902_6966(EIF_REFERENCE);
extern void F955_7112(EIF_REFERENCE, EIF_CHARACTER_32);

#ifdef __cplusplus
}
#endif

#endif
