
#ifndef _C21_ar1025_
#define _C21_ar1025_

#ifdef __cplusplus
extern "C" {
#endif

extern void F589_6110(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F589_6111(EIF_REFERENCE);
extern EIF_REFERENCE F589_6112(EIF_REFERENCE);
extern EIF_REFERENCE F589_6114(EIF_REFERENCE);
extern EIF_INTEGER_32 F589_6115(EIF_REFERENCE);
extern void EIF_Minit1025(void);
extern EIF_TYPE_INDEX Y5317[];
extern EIF_TYPE_INDEX *Y5317_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
