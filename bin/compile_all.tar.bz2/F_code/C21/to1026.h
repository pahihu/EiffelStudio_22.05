
#ifndef _C21_to1026_
#define _C21_to1026_

#ifdef __cplusplus
extern "C" {
#endif

extern void F422_4946(EIF_REFERENCE, EIF_INTEGER_32);
extern void F422_4947(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F422_4953(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1026(void);
extern void F1147_9206(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4515[];
extern EIF_TYPE_INDEX *Y4515_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
