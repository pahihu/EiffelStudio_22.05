/*
 * Code for class BILINEAR [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi1013.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BILINEAR}.search */
void F650_6170 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 649, Current, 0, 1, 7217);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F926_6991(Current)) {
		tb1 = (EIF_BOOLEAN) !F768_6292(Current);
	}
	if (tb1) {
		RTHOOK(2);
		F955_7104(Current);
	}
	RTHOOK(3);
	F638_6153(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit1013 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
