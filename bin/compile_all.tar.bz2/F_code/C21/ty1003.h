
#ifndef _C21_ty1003_
#define _C21_ty1003_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F529_6032(EIF_REFERENCE);
extern void EIF_Minit1003(void);
extern char *(*R5411[])();
extern char *(*R5398[])();
extern char *(*R5795[])();

#ifdef __cplusplus
}
#endif

#endif
