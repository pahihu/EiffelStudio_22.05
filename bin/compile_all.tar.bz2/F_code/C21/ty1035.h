
#ifndef _C21_ty1035_
#define _C21_ty1035_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_16 F530_6032(EIF_REFERENCE);
extern void EIF_Minit1035(void);
extern char *(*R5411[])();
extern char *(*R5398[])();
extern char *(*R5795[])();

#ifdef __cplusplus
}
#endif

#endif
