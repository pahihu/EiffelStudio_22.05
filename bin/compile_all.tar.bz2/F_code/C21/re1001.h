
#ifndef _C21_re1001_
#define _C21_re1001_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F846_6716(EIF_REFERENCE);
extern void EIF_Minit1001(void);
extern void F541_6038(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5410[])();
extern EIF_TYPE_INDEX Y5346[];
extern EIF_TYPE_INDEX *Y5346_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
