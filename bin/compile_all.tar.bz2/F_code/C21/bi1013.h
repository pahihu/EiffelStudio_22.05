
#ifndef _C21_bi1013_
#define _C21_bi1013_

#ifdef __cplusplus
extern "C" {
#endif

extern void F650_6170(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1013(void);
extern void F955_7104(EIF_REFERENCE);
extern EIF_BOOLEAN F926_6991(EIF_REFERENCE);
extern void F638_6153(EIF_REFERENCE, EIF_CHARACTER_32);
extern EIF_BOOLEAN F768_6292(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
