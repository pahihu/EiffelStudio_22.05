
#ifndef _C1_ut3_
#define _C1_ut3_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F3_38(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit3(void);
extern EIF_REFERENCE F88_1263(EIF_REFERENCE, EIF_REFERENCE);
extern void F1078_8165(EIF_REFERENCE);
extern char *(*R5284[])();

#ifdef __cplusplus
}
#endif

#endif
