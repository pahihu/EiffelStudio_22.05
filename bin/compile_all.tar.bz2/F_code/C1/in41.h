
#ifndef _C1_in41_
#define _C1_in41_

#ifdef __cplusplus
extern "C" {
#endif

extern void F46_447(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit41(void);

#ifdef __cplusplus
}
#endif

#endif
