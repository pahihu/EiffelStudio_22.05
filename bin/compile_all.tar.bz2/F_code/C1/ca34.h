
#ifndef _C1_ca34_
#define _C1_ca34_

#ifdef __cplusplus
extern "C" {
#endif

extern void F39_344(EIF_REFERENCE);
extern void F39_345(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F39_346(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F39_348(EIF_REFERENCE, EIF_INTEGER_32);
extern void F39_349(EIF_REFERENCE);
extern void F39_350(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit34(void);
extern void F1143_9206(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R5795[])();

#ifdef __cplusplus
}
#endif

#endif
