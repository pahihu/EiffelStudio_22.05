
#ifndef _C1_ir9_
#define _C1_ir9_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F14_109(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit9(void);
extern void F208_2637(EIF_REFERENCE, EIF_REFERENCE);
extern void F209_2657(EIF_REFERENCE, EIF_REFERENCE);
extern long O2548[];

#ifdef __cplusplus
}
#endif

#endif
