
#ifndef _C1_ir8_
#define _C1_ir8_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F13_108(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit8(void);
extern void F1336_12810(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1078_8212(EIF_REFERENCE, EIF_REFERENCE);
extern void F1090_8641(EIF_REFERENCE, EIF_REFERENCE);
extern void F1089_8630(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1336_12828(EIF_REFERENCE);
extern void F1090_8643(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
