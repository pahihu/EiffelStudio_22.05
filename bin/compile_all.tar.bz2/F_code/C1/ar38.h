
#ifndef _C1_ar38_
#define _C1_ar38_

#ifdef __cplusplus
extern "C" {
#endif

extern void F43_430(EIF_REFERENCE, EIF_REFERENCE);
extern void F43_431(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F43_433(EIF_REFERENCE);
extern void F43_434(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F43_435(EIF_REFERENCE);
extern void EIF_Minit38(void);
extern EIF_BOOLEAN F1086_8532(EIF_REFERENCE);
extern void F1086_8514(EIF_REFERENCE, EIF_REFERENCE);
extern void F1078_8165(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
