
#ifndef _C1_pc33_
#define _C1_pc33_

#ifdef __cplusplus
extern "C" {
#endif

extern void F38_334(EIF_REFERENCE);
extern void F38_335(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F38_337(EIF_REFERENCE, EIF_INTEGER_32);
extern void F38_338(EIF_REFERENCE, EIF_REFERENCE);
extern void F38_339(EIF_REFERENCE, EIF_INTEGER_32);
extern void F38_340(EIF_REFERENCE, EIF_REFERENCE);
extern void F38_341(EIF_REFERENCE, EIF_REFERENCE);
extern void F38_342(EIF_REFERENCE);
extern void EIF_Minit33(void);
extern void F1142_9206(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern char *(*R7040[])();

#ifdef __cplusplus
}
#endif

#endif
