/*
 * Code for class IRON_PACKAGE_INFO_FILE_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir5.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_INFO_FILE_PARSER}.make */
void F10_56 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 9, Current, 0, 0, 118);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1086, 1).id);
	F1078_8165(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.set_callbacks */
void F10_59 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_callbacks", 9, Current, 0, 1, 121);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.package_token */

EIF_REFERENCE F10_60 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (678,RTMS_EX_H("package",7,382506597));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.setup_token */

EIF_REFERENCE F10_61 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (679,RTMS_EX_H("setup",5,1703014256));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.project_token */

EIF_REFERENCE F10_62 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (680,RTMS_EX_H("project",7,399506036));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.note_token */

EIF_REFERENCE F10_63 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (681,RTMS_EX_H("note",4,1852798053));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.end_token */

EIF_REFERENCE F10_64 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (682,RTMS_EX_H("end",3,6647396));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse */
void F10_65 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("parse", 9, Current, 1, 1, 127);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(829, 0x01).id, 829, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F830_6637(RTCW(loc1), arg1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5228[Dtype(RTCW(loc1))-828])(loc1);
	if (tb2) {
		tb2 = F828_6393(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F828_6425(RTCW(loc1));
		RTHOOK(4);
		F10_66(Current, loc1);
		RTHOOK(5);
		F828_6442(RTCW(loc1));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_file */
void F10_66 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("parse_file", 9, Current, 2, 1, 128);
	RTGC;
	RTHOOK(1);
	loc2 = RTLNS(eif_new_type(1082, 0x01).id, 1082, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1081_8295(RTCW(loc2), ((EIF_INTEGER_32) 2046L));
	RTHOOK(2);
	loc1 = F636_6157(RTCW(arg1));
	for (;;) {
		RTHOOK(3);
		if (loc1) break;
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5284[Dtype(RTCW(arg1))-828])(arg1, ((EIF_INTEGER_32) 2046L));
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7090[Dtype(RTCW(loc2))-1082])(loc2, tr1);
		RTHOOK(6);
		loc1 = '\01';
		tb1 = F636_6157(RTCW(arg1));
		if (!tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			loc1 = (EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 2046L));
		}
	}
	RTHOOK(7);
	F10_67(Current, loc2);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_text */
void F10_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	struct eif_ex_69 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(87, 0x00).id);
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("parse_text", 9, Current, 1, 1, 129);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1087_8605(RTCW(tr1));
	RTHOOK(2);
	F88_1266(RTCW(loc1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTHOOK(3);
	F10_68(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_buffer */
void F10_68 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("parse_buffer", 9, Current, 2, 0, 130);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F768_6292(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) tb1;
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
		RTHOOK(5);
		loc1 = F10_81(Current);
		RTHOOK(6);
		switch (loc1) {
			case (EIF_CHARACTER_8) '-':
				RTHOOK(7);
				loc1 = F10_78(Current);
				RTHOOK(8);
				F10_69(Current);
				break;
			case (EIF_CHARACTER_8) 'p':
				RTHOOK(9);
				loc1 = F10_78(Current);
				RTHOOK(10);
				loc2 = F10_84(Current);
				RTHOOK(11);
				tr1 = F1078_8224(RTCV(RTOUCR(678,F10_60, (Current))));
				tb1 = F1085_8486(RTCW(loc2), tr1);
				if (tb1) {
					RTHOOK(12);
					F10_70(Current);
				} else {
					RTHOOK(13);
					tr1 = F1078_8224(RTCV(RTOUCR(680,F10_62, (Current))));
					tb1 = F1085_8486(RTCW(loc2), tr1);
					if (tb1) {
						RTHOOK(14);
						F10_73(Current);
					} else {
						RTHOOK(15);
						tr1 = F1078_8224(RTMS_EX_H("Unexpected character [p].",25,883275054));
						F10_77(Current, tr1);
					}
				}
				break;
			case (EIF_CHARACTER_8) 's':
				RTHOOK(16);
				loc1 = F10_78(Current);
				RTHOOK(17);
				loc2 = F10_84(Current);
				RTHOOK(18);
				tr1 = RTOUCR(679,F10_61, (Current));
				tb1 = F1078_8207(RTCW(loc2), tr1);
				if (tb1) {
					RTHOOK(19);
					F10_71(Current);
				} else {
					RTHOOK(20);
					tr1 = F1078_8224(RTMS_EX_H("Unexpected character [s].",25,883471662));
					F10_77(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) 'n':
				RTHOOK(21);
				loc1 = F10_78(Current);
				RTHOOK(22);
				loc2 = F10_84(Current);
				RTHOOK(23);
				tr1 = RTOUCR(681,F10_63, (Current));
				tb1 = F1078_8207(RTCW(loc2), tr1);
				if (tb1) {
					RTHOOK(24);
					F10_75(Current);
				} else {
					RTHOOK(25);
					tr1 = F1078_8224(RTMS_EX_H("Unexpected character [n].",25,883143982));
					F10_77(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) 'e':
				RTHOOK(26);
				loc1 = F10_78(Current);
				RTHOOK(27);
				loc2 = F10_84(Current);
				RTHOOK(28);
				tr1 = F1078_8224(RTCV(RTOUCR(682,F10_64, (Current))));
				tb1 = F1085_8486(RTCW(loc2), tr1);
				if ((EIF_BOOLEAN) !tb1) {
					RTHOOK(29);
					tr1 = F1078_8224(RTMS_EX_H("Unexpected character [e].",25,882554158));
					F10_77(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) '\000':
				RTHOOK(30);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
					RTHOOK(31);
					tr1 = F1078_8224(RTMS_EX_H("Unexpected null character.",26,830567726));
					F10_77(Current, tr1);
				}
				break;
			default:
				RTHOOK(32);
				tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
				tr2 = F10_90(Current, loc1);
				tr1 = F1087_8595(tr1, tr2);
				tr2 = F1078_8224(RTMS_EX_H("].",2,23854));
				tr1 = F1087_8595(RTCW(tr1), tr2);
				F10_77(Current, tr1);
				break;
		}
	}
	RTHOOK(33);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_comment */
void F10_69 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("parse_comment", 9, Current, 3, 0, 131);
	RTGC;
	RTHOOK(1);
	loc1 = F10_79(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	if ((EIF_BOOLEAN)(loc1 == tw1)) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			RTHOOK(4);
			loc1 = F10_79(Current);
			RTHOOK(5);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				RTHOOK(6);
				loc2 = F10_83(Current);
				RTHOOK(7);
				tr1 = *(EIF_REFERENCE *)(Current);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					RTHOOK(8);
					{
						/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_comment) */
						(void) loc3;
						/* END INLINED CODE */
					}
					;
				}
			} else {
				RTHOOK(9);
				tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
				tr2 = F10_90(Current, loc1);
				tr1 = F1087_8595(tr1, tr2);
				tr2 = F1078_8224(RTMS_EX_H("].",2,23854));
				tr1 = F1087_8595(RTCW(tr1), tr2);
				F10_77(Current, tr1);
			}
		}
	} else {
		RTHOOK(10);
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F10_90(Current, loc1);
		tr1 = F1087_8595(tr1, tr2);
		tr2 = F1078_8224(RTMS_EX_H("].",2,23854));
		tr1 = F1087_8595(RTCW(tr1), tr2);
		F10_77(Current, tr1);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_package_declaration */
void F10_70 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTEAA("parse_package_declaration", 9, Current, 3, 0, 132);
	RTGC;
	RTHOOK(1);
	loc2 = F10_81(Current);
	RTHOOK(2);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc2 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		RTHOOK(3);
		loc2 = F10_78(Current);
		RTHOOK(4);
		loc1 = F10_86(Current);
		RTHOOK(5);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6919[Dtype(RTCW(loc1))-1081])(loc1);
		if (tb1) {
			RTHOOK(6);
			tr1 = F1078_8224(RTMS_EX_H("Invalid package name",20,1534212709));
			F10_77(Current, tr1);
		} else {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(Current);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(8);
				F208_2641(loc3, loc1);
			}
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_setup_declaration */
void F10_71 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc5 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parse_setup_declaration", 9, Current, 5, 0, 93);
	RTGC;
	RTHOOK(1);
	loc5 = F10_81(Current);
	RTHOOK(2);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc5 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		RTHOOK(3);
		loc5 = F10_78(Current);
		RTHOOK(4);
		loc1 = F10_88(Current);
		RTHOOK(5);
		loc5 = F10_78(Current);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			RTHOOK(7);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6919[Dtype(RTCW(loc1))-1081])(loc1);
			if (tb1) {
				RTHOOK(8);
				loc5 = F10_79(Current);
				RTHOOK(9);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc5 == tw1)) {
					RTHOOK(10);
					loc5 = F10_78(Current);
					RTHOOK(11);
					F10_69(Current);
					RTHOOK(12);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						RTHOOK(13);
						loc5 = F10_81(Current);
						RTHOOK(14);
						loc5 = F10_78(Current);
						RTHOOK(15);
						loc1 = F10_88(Current);
						RTHOOK(16);
						loc5 = F10_78(Current);
					}
				} else {
					RTHOOK(17);
					tr1 = F1078_8224(RTMS_EX_H("Invalid setup name",18,1945739621));
					F10_77(Current, tr1);
					RTHOOK(18);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				RTHOOK(19);
				tr1 = F1078_8224(RTCV(RTOUCR(680,F10_62, (Current))));
				tb1 = F1085_8486(RTCW(loc1), tr1);
				if (tb1) {
					RTHOOK(20);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(21);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(22);
					tr1 = F1078_8224(RTCV(RTOUCR(681,F10_63, (Current))));
					tb1 = F1085_8486(RTCW(loc1), tr1);
					if (tb1) {
						RTHOOK(23);
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						RTHOOK(24);
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						RTHOOK(25);
						tr1 = F1078_8224(RTCV(RTOUCR(682,F10_64, (Current))));
						tb1 = F1085_8486(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(26);
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							RTHOOK(27);
							F10_72(Current, loc1);
							RTHOOK(28);
							loc5 = F10_78(Current);
							RTHOOK(29);
							loc5 = F10_81(Current);
							for (;;) {
								RTHOOK(30);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc5 != tw1)) break;
								RTHOOK(31);
								loc5 = F10_78(Current);
								RTHOOK(32);
								F10_69(Current);
								RTHOOK(33);
								loc5 = F10_81(Current);
							}
							RTHOOK(34);
							loc5 = F10_78(Current);
							RTHOOK(35);
							loc1 = F10_88(Current);
							RTHOOK(36);
							loc5 = F10_78(Current);
						}
					}
				}
			}
		}
		RTHOOK(37);
		if (loc2) {
			RTHOOK(38);
			F10_75(Current);
		} else {
			RTHOOK(39);
			if (loc3) {
				RTHOOK(40);
				F10_73(Current);
			}
		}
	}
	RTHOOK(41);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_setup_item_declaration */
void F10_72 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc5);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("parse_setup_item_declaration", 9, Current, 5, 1, 94);
	RTGC;
	RTHOOK(1);
	loc4 = F10_81(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	if ((EIF_BOOLEAN)(loc4 == tw1)) {
		RTHOOK(3);
		loc4 = F10_82(Current);
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc4 == tw1)) {
			RTHOOK(5);
			tr1 = F1078_8224(RTMS_EX_H("Syntax error in setup declaration",33,1339518062));
			F10_77(Current, tr1);
		} else {
			RTHOOK(6);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc4 == tw1)) {
				RTHOOK(7);
				loc4 = F10_79(Current);
				RTHOOK(8);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					RTHOOK(9);
					loc1 = F10_83(Current);
					RTHOOK(10);
					tb1 = F1078_8183(RTCW(loc1));
					if (tb1) {
						RTHOOK(11);
						loc2 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F1078_8165(RTCW(loc2));
						for (;;) {
							RTHOOK(12);
							if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3)) break;
							RTHOOK(13);
							loc1 = F10_83(Current);
							RTHOOK(14);
							F1087_8561(RTCW(loc1));
							RTHOOK(15);
							tr1 = F1078_8224(RTMS_EX_H("]\"",2,23842));
							tb1 = F1085_8497(RTCW(loc1), tr1);
							if (tb1) {
								RTHOOK(16);
								tb1 = '\01';
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
								if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
									tb2 = F1085_8494(RTCW(loc1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)));
									tb1 = tb2;
								}
								if (tb1) {
									RTHOOK(17);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									RTHOOK(18);
									F1087_8576(RTCW(loc2), loc1);
									RTHOOK(19);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
									F1087_8589(RTCW(loc2), tw1);
								}
							} else {
								RTHOOK(20);
								F1087_8576(RTCW(loc2), loc1);
								RTHOOK(21);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F1087_8589(RTCW(loc2), tw1);
							}
						}
						RTHOOK(22);
						if (loc3) {
							RTHOOK(23);
							F10_91(Current, loc2);
						}
					} else {
						RTHOOK(24);
						F1087_8567(RTCW(loc1), loc4);
						RTHOOK(25);
						F1087_8561(RTCW(loc1));
						RTHOOK(26);
						tr1 = F1078_8224(RTMS_EX_H("\"",1,34));
						tb1 = F1085_8497(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(27);
							F1087_8600(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						} else {
							RTHOOK(28);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
							F1087_8567(RTCW(loc1), tw1);
						}
						RTHOOK(29);
						loc2 = (EIF_REFERENCE) loc1;
					}
				} else {
					RTHOOK(30);
					loc1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1078_8165(RTCW(loc1));
					RTHOOK(31);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					F1087_8589(RTCW(loc1), tw1);
					RTHOOK(32);
					F1087_8589(RTCW(loc1), loc4);
					RTHOOK(33);
					tr1 = F10_83(Current);
					F1087_8576(RTCW(loc1), tr1);
					RTHOOK(34);
					F1087_8560(RTCW(loc1));
					RTHOOK(35);
					F1087_8561(RTCW(loc1));
					RTHOOK(36);
					tb1 = '\0';
					tb2 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
						tw1 = F1087_8543(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tw1 = F1087_8543(RTCW(loc1), ti4_1);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb1 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb1) {
						RTHOOK(37);
						F1087_8598(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						RTHOOK(38);
						F1087_8600(RTCW(loc1), ((EIF_INTEGER_32) 1L));
					}
					RTHOOK(39);
					loc2 = (EIF_REFERENCE) loc1;
					RTHOOK(40);
					loc4 = F10_81(Current);
				}
			} else {
				RTHOOK(41);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					RTHOOK(42);
					loc1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1078_8165(RTCW(loc1));
					RTHOOK(43);
					loc2 = (EIF_REFERENCE) loc1;
				} else {
					RTHOOK(44);
					loc4 = F10_78(Current);
					RTHOOK(45);
					loc1 = F10_83(Current);
					RTHOOK(46);
					F1087_8560(RTCW(loc1));
					RTHOOK(47);
					F1087_8561(RTCW(loc1));
					RTHOOK(48);
					loc2 = (EIF_REFERENCE) loc1;
				}
			}
		}
		RTHOOK(49);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTHOOK(50);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				RTHOOK(51);
				loc2 = F1078_8224(RTMS_EX_H("",0,0));
			}
			RTHOOK(52);
			F208_2642(loc5, arg1, loc2);
		}
	} else {
		RTHOOK(53);
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F10_90(Current, loc4);
		tr1 = F1087_8595(tr1, tr2);
		tr2 = F1078_8224(RTMS_EX_H("].",2,23854));
		tr1 = F1087_8595(RTCW(tr1), tr2);
		F10_77(Current, tr1);
	}
	RTHOOK(54);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_projects_declaration */
void F10_73 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc5 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parse_projects_declaration", 9, Current, 5, 0, 95);
	RTGC;
	RTHOOK(1);
	loc5 = F10_81(Current);
	RTHOOK(2);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc5 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		RTHOOK(3);
		loc5 = F10_78(Current);
		RTHOOK(4);
		loc1 = F10_88(Current);
		RTHOOK(5);
		loc5 = F10_78(Current);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			RTHOOK(7);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6919[Dtype(RTCW(loc1))-1081])(loc1);
			if (tb1) {
				RTHOOK(8);
				loc5 = F10_79(Current);
				RTHOOK(9);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc5 == tw1)) {
					RTHOOK(10);
					loc5 = F10_78(Current);
					RTHOOK(11);
					F10_69(Current);
					RTHOOK(12);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						RTHOOK(13);
						loc5 = F10_81(Current);
						RTHOOK(14);
						loc5 = F10_78(Current);
						RTHOOK(15);
						loc1 = F10_88(Current);
						RTHOOK(16);
						loc5 = F10_78(Current);
					}
				} else {
					RTHOOK(17);
					tr1 = F1078_8224(RTMS_EX_H("Invalid project name",20,415510117));
					F10_77(Current, tr1);
					RTHOOK(18);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				RTHOOK(19);
				tr1 = F1078_8224(RTCV(RTOUCR(679,F10_61, (Current))));
				tb1 = F1085_8486(RTCW(loc1), tr1);
				if (tb1) {
					RTHOOK(20);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(21);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(22);
					tr1 = F1078_8224(RTCV(RTOUCR(681,F10_63, (Current))));
					tb1 = F1085_8486(RTCW(loc1), tr1);
					if (tb1) {
						RTHOOK(23);
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						RTHOOK(24);
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						RTHOOK(25);
						tr1 = F1078_8224(RTCV(RTOUCR(682,F10_64, (Current))));
						tb1 = F1085_8486(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(26);
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							RTHOOK(27);
							F10_74(Current, loc1);
							RTHOOK(28);
							loc5 = F10_78(Current);
							RTHOOK(29);
							loc5 = F10_81(Current);
							for (;;) {
								RTHOOK(30);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc5 != tw1)) break;
								RTHOOK(31);
								loc5 = F10_78(Current);
								RTHOOK(32);
								F10_69(Current);
								RTHOOK(33);
								loc5 = F10_81(Current);
							}
							RTHOOK(34);
							loc5 = F10_78(Current);
							RTHOOK(35);
							loc1 = F10_88(Current);
							RTHOOK(36);
							loc5 = F10_78(Current);
						}
					}
				}
			}
		}
		RTHOOK(37);
		if (loc2) {
			RTHOOK(38);
			F10_75(Current);
		} else {
			RTHOOK(39);
			if (loc3) {
				RTHOOK(40);
				F10_71(Current);
			}
		}
	}
	RTHOOK(41);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_project_item_declaration */
void F10_74 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("parse_project_item_declaration", 9, Current, 4, 1, 96);
	RTGC;
	RTHOOK(1);
	loc2 = F10_81(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	if ((EIF_BOOLEAN)(loc2 == tw1)) {
		RTHOOK(3);
		loc2 = F10_81(Current);
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc2 == tw1)) {
			RTHOOK(5);
			tr1 = F1078_8224(RTMS_EX_H("Syntax error in project declaration",35,1660760430));
			F10_77(Current, tr1);
		} else {
			RTHOOK(6);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc2 == tw1)) {
				RTHOOK(7);
				loc1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1078_8165(RTCW(loc1));
				RTHOOK(8);
				loc2 = F10_79(Current);
				for (;;) {
					RTHOOK(9);
					tb1 = '\01';
					if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb1 = (EIF_BOOLEAN)(loc2 == tw1);
					}
					if (tb1) break;
					RTHOOK(10);
					F1087_8589(RTCW(loc1), loc2);
					RTHOOK(11);
					loc2 = F10_79(Current);
				}
				RTHOOK(12);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					RTHOOK(13);
					tr1 = *(EIF_REFERENCE *)(Current);
					loc3 = tr1;
					if (EIF_TEST(loc3)) {
						RTHOOK(14);
						F208_2643(loc3, arg1, loc1);
					}
					RTHOOK(15);
					loc2 = F10_81(Current);
				}
			} else {
				RTHOOK(16);
				loc1 = F10_83(Current);
				RTHOOK(17);
				F1087_8560(RTCW(loc1));
				RTHOOK(18);
				F1087_8561(RTCW(loc1));
				RTHOOK(19);
				tr1 = *(EIF_REFERENCE *)(Current);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					RTHOOK(20);
					F208_2643(loc4, arg1, loc1);
				}
			}
		}
	} else {
		RTHOOK(21);
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F10_90(Current, loc2);
		tr1 = F1087_8595(tr1, tr2);
		tr2 = F1078_8224(RTMS_EX_H("].",2,23854));
		tr1 = F1087_8595(RTCW(tr1), tr2);
		F10_77(Current, tr1);
	}
	RTHOOK(22);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_notes_declaration */
void F10_75 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parse_notes_declaration", 9, Current, 3, 0, 97);
	RTGC;
	RTHOOK(1);
	loc2 = F10_81(Current);
	RTHOOK(2);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc2 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		RTHOOK(3);
		loc2 = F10_78(Current);
		RTHOOK(4);
		loc1 = F10_89(Current);
		RTHOOK(5);
		loc2 = F10_78(Current);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			RTHOOK(7);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6919[Dtype(RTCW(loc1))-1081])(loc1);
			if (tb1) {
				RTHOOK(8);
				loc2 = F10_79(Current);
				RTHOOK(9);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					RTHOOK(10);
					loc2 = F10_78(Current);
					RTHOOK(11);
					F10_69(Current);
					RTHOOK(12);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						RTHOOK(13);
						loc2 = F10_81(Current);
						RTHOOK(14);
						loc2 = F10_78(Current);
						RTHOOK(15);
						loc1 = F10_89(Current);
						RTHOOK(16);
						loc2 = F10_78(Current);
					}
				} else {
					RTHOOK(17);
					tr1 = F1078_8224(RTMS_EX_H("Invalid note name",17,17618021));
					F10_77(Current, tr1);
					RTHOOK(18);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				RTHOOK(19);
				tr1 = F1078_8224(RTCV(RTOUCR(678,F10_60, (Current))));
				tb1 = F1085_8486(RTCW(loc1), tr1);
				if (tb1) {
					RTHOOK(20);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(21);
					tr1 = F1078_8224(RTCV(RTOUCR(679,F10_61, (Current))));
					tb1 = F1085_8486(RTCW(loc1), tr1);
					if (tb1) {
						RTHOOK(22);
						loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						RTHOOK(23);
						tr1 = F1078_8224(RTCV(RTOUCR(682,F10_64, (Current))));
						tb1 = F1085_8486(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(24);
							loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							RTHOOK(25);
							F10_76(Current, loc1);
							RTHOOK(26);
							loc2 = F10_78(Current);
							RTHOOK(27);
							loc2 = F10_81(Current);
							for (;;) {
								RTHOOK(28);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc2 != tw1)) break;
								RTHOOK(29);
								loc2 = F10_78(Current);
								RTHOOK(30);
								F10_69(Current);
								RTHOOK(31);
								loc2 = F10_81(Current);
							}
							RTHOOK(32);
							loc2 = F10_78(Current);
							RTHOOK(33);
							loc1 = F10_89(Current);
							RTHOOK(34);
							loc2 = F10_78(Current);
						}
					}
				}
			}
		}
		RTHOOK(35);
		if (loc3) {
			RTHOOK(36);
			tr1 = F1078_8224(RTCV(RTOUCR(678,F10_60, (Current))));
			tb1 = F1085_8486(RTCW(loc1), tr1);
			if (tb1) {
				RTHOOK(37);
				F10_70(Current);
			} else {
				RTHOOK(38);
				tr1 = F1078_8224(RTCV(RTOUCR(679,F10_61, (Current))));
				tb1 = F1085_8486(RTCW(loc1), tr1);
				if (tb1) {
					RTHOOK(39);
					F10_71(Current);
				}
			}
		}
	}
	RTHOOK(40);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_note_item_declaration */
void F10_76 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc5);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("parse_note_item_declaration", 9, Current, 5, 1, 98);
	RTGC;
	RTHOOK(1);
	loc4 = F10_81(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	if ((EIF_BOOLEAN)(loc4 == tw1)) {
		RTHOOK(3);
		loc4 = F10_82(Current);
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc4 == tw1)) {
			RTHOOK(5);
			tr1 = F1078_8224(RTMS_EX_H("Syntax error in note declaration",32,1224969838));
			F10_77(Current, tr1);
		} else {
			RTHOOK(6);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc4 == tw1)) {
				RTHOOK(7);
				loc4 = F10_79(Current);
				RTHOOK(8);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					RTHOOK(9);
					loc1 = F10_83(Current);
					RTHOOK(10);
					tb1 = F1078_8183(RTCW(loc1));
					if (tb1) {
						RTHOOK(11);
						loc2 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F1078_8165(RTCW(loc2));
						for (;;) {
							RTHOOK(12);
							if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3)) break;
							RTHOOK(13);
							loc1 = F10_83(Current);
							RTHOOK(14);
							F1087_8561(RTCW(loc1));
							RTHOOK(15);
							tr1 = F1078_8224(RTMS_EX_H("]\"",2,23842));
							tb1 = F1085_8497(RTCW(loc1), tr1);
							if (tb1) {
								RTHOOK(16);
								tb1 = '\01';
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
								if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
									tb2 = F1085_8494(RTCW(loc1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)));
									tb1 = tb2;
								}
								if (tb1) {
									RTHOOK(17);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									RTHOOK(18);
									F1087_8576(RTCW(loc2), loc1);
									RTHOOK(19);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
									F1087_8589(RTCW(loc2), tw1);
								}
							} else {
								RTHOOK(20);
								F1087_8576(RTCW(loc2), loc1);
								RTHOOK(21);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F1087_8589(RTCW(loc2), tw1);
							}
						}
						RTHOOK(22);
						if (loc3) {
							RTHOOK(23);
							F10_91(Current, loc2);
						}
					} else {
						RTHOOK(24);
						F1087_8567(RTCW(loc1), loc4);
						RTHOOK(25);
						F1087_8561(RTCW(loc1));
						RTHOOK(26);
						tr1 = F1078_8224(RTMS_EX_H("\"",1,34));
						tb1 = F1085_8497(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(27);
							F1087_8600(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						} else {
							RTHOOK(28);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
							F1087_8567(RTCW(loc1), tw1);
						}
						RTHOOK(29);
						loc2 = (EIF_REFERENCE) loc1;
					}
				} else {
					RTHOOK(30);
					loc1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1078_8165(RTCW(loc1));
					RTHOOK(31);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					F1087_8589(RTCW(loc1), tw1);
					RTHOOK(32);
					F1087_8589(RTCW(loc1), loc4);
					RTHOOK(33);
					tr1 = F10_83(Current);
					F1087_8576(RTCW(loc1), tr1);
					RTHOOK(34);
					F1087_8560(RTCW(loc1));
					RTHOOK(35);
					F1087_8561(RTCW(loc1));
					RTHOOK(36);
					tb1 = '\0';
					tb2 = '\0';
					tb3 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
						tw1 = F1087_8543(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb3 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb3) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tw1 = F1087_8543(RTCW(loc1), ti4_1);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						ti4_1 = F1085_8473(RTCW(loc1), tw1, ((EIF_INTEGER_32) 2L));
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tb1 = (EIF_BOOLEAN)(ti4_1 == ti4_2);
					}
					if (tb1) {
						RTHOOK(37);
						F1087_8598(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						RTHOOK(38);
						F1087_8600(RTCW(loc1), ((EIF_INTEGER_32) 1L));
					}
					RTHOOK(39);
					loc2 = (EIF_REFERENCE) loc1;
					RTHOOK(40);
					loc4 = F10_81(Current);
				}
			} else {
				RTHOOK(41);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					RTHOOK(42);
					loc1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1078_8165(RTCW(loc1));
					RTHOOK(43);
					loc2 = (EIF_REFERENCE) loc1;
				} else {
					RTHOOK(44);
					loc4 = F10_78(Current);
					RTHOOK(45);
					loc1 = F10_83(Current);
					RTHOOK(46);
					F1087_8560(RTCW(loc1));
					RTHOOK(47);
					F1087_8561(RTCW(loc1));
					RTHOOK(48);
					loc2 = (EIF_REFERENCE) loc1;
				}
			}
		}
		RTHOOK(49);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTHOOK(50);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				RTHOOK(51);
				loc2 = F1078_8224(RTMS_EX_H("",0,0));
			}
			RTHOOK(52);
			F208_2644(loc5, arg1, loc2);
		}
	} else {
		RTHOOK(53);
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F10_90(Current, loc4);
		tr1 = F1087_8595(tr1, tr2);
		tr2 = F1078_8224(RTMS_EX_H("].",2,23854));
		tr1 = F1087_8595(RTCW(tr1), tr2);
		F10_77(Current, tr1);
	}
	RTHOOK(54);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.report_error */
void F10_77 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("report_error", 9, Current, 1, 1, 99);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		{
			/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_error) */
			(void) loc1;
			/* END INLINED CODE */
		}
		;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.previous_character */
EIF_CHARACTER_32 F10_78 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("previous_character", 9, Current, 0, 0, 100);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) >= ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))--;
		RTHOOK(3);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = F1087_8543(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
		} else {
			RTHOOK(5);
			Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		}
		RTHOOK(6);
		F10_80(Current);
	} else {
		RTHOOK(7);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		RTHOOK(8);
		tr1 = F1078_8224(RTMS_EX_H("out of input",12,330662516));
		F10_77(Current, tr1);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_character */
EIF_CHARACTER_32 F10_79 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("next_character", 9, Current, 0, 0, 101);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		RTHOOK(2);
		tr1 = F1078_8224(RTMS_EX_H("out of input",12,330662516));
		F10_77(Current, tr1);
		RTHOOK(3);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		RTHOOK(4);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))++;
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1087_8543(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
		RTHOOK(6);
		F10_80(Current);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.update_end_of_input */
void F10_80 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("update_end_of_input", 9, Current, 0, 0, 102);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_non_whitespace_character */
EIF_CHARACTER_32 F10_81 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("next_non_whitespace_character", 9, Current, 0, 0, 103);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		RTHOOK(2);
		tr1 = F1078_8224(RTMS_EX_H("out of input",12,330662516));
		F10_77(Current, tr1);
		RTHOOK(3);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		RTHOOK(4);
		Result = F10_79(Current);
		for (;;) {
			RTHOOK(5);
			tb1 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
				tr1 = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = Result;
				tb2 = F1030_8001(RTCW(tr1));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) break;
			RTHOOK(6);
			Result = F10_79(Current);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_non_whitespace_character_until_eol */
EIF_CHARACTER_32 F10_82 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("next_non_whitespace_character_until_eol", 9, Current, 0, 0, 104);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		RTHOOK(2);
		tr1 = F1078_8224(RTMS_EX_H("out of input",12,330662516));
		F10_77(Current, tr1);
		RTHOOK(3);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		RTHOOK(4);
		Result = F10_79(Current);
		for (;;) {
			RTHOOK(5);
			tb1 = '\01';
			tb2 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
				tr1 = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = Result;
				tb3 = F1030_8001(RTCW(tr1));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				tb1 = (EIF_BOOLEAN)(Result == tw1);
			}
			if (tb1) break;
			RTHOOK(6);
			Result = F10_79(Current);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_text_until_eol */
EIF_REFERENCE F10_83 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("next_text_until_eol", 9, Current, 1, 0, 105);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1078_8165(RTCW(Result));
	RTHOOK(2);
	loc1 = F10_79(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
			tb1 = (EIF_BOOLEAN)(loc1 == tw1);
		}
		if (tb1) break;
		RTHOOK(4);
		F1087_8589(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F10_79(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alphabetic */
EIF_REFERENCE F10_84 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_alphabetic", 9, Current, 1, 0, 106);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1078_8165(RTCW(Result));
	RTHOOK(2);
	loc1 = F10_79(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tr1 = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb2 = F1030_7995(RTCW(tr1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		F1087_8589(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F10_79(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_package_name */
EIF_REFERENCE F10_86 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_package_name", 9, Current, 1, 0, 108);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1078_8165(RTCW(Result));
	RTHOOK(2);
	loc1 = F10_79(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tb4 = '\01';
			tr1 = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb5 = F1030_8003(RTCW(tr1));
			if (!tb5) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb4 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '+';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		F1087_8589(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F10_79(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alpha_numeric_or_dash */
EIF_REFERENCE F10_88 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_alpha_numeric_or_dash", 9, Current, 1, 0, 110);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1078_8165(RTCW(Result));
	RTHOOK(2);
	loc1 = F10_79(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tr1 = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb4 = F1030_8003(RTCW(tr1));
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		F1087_8589(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F10_79(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alpha_numeric_with_bracket */
EIF_REFERENCE F10_89 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("next_alpha_numeric_with_bracket", 9, Current, 2, 0, 111);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1078_8165(RTCW(Result));
	RTHOOK(2);
	loc1 = F10_79(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tb4 = '\01';
			tr1 = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb5 = F1030_8003(RTCW(tr1));
			if (!tb5) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb4 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		F1087_8589(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F10_79(Current);
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
			if ((EIF_BOOLEAN)(loc1 != tw1)) {
				RTHOOK(8);
				loc2--;
			}
		} else {
			RTHOOK(9);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				RTHOOK(10);
				loc2++;
			}
		}
	}
	RTHOOK(11);
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(12);
		tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000e\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000 \000\000\000w\000\000\000i\000\000\000t\000\000\000h\000\000\000 \000\000\000b\000\000\000r\000\000\000a\000\000\000c\000\000\000k\000\000\000e\000\000\000t\000\000\000 \000\000\000\"\000\000\000",32,304418082);
		tr1 = F1087_8595(tr1, Result);
		tr2 = F1078_8224(RTMS_EX_H("\"",1,34));
		tr1 = F1087_8595(RTCW(tr1), tr2);
		F10_77(Current, tr1);
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.character_to_string */
EIF_REFERENCE F10_90 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("character_to_string", 9, Current, 0, 1, 112);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1085_8461(RTCW(Result), ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	F1087_8589(RTCW(Result), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.normalize_multiline */
void F10_91 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc6);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("normalize_multiline", 9, Current, 6, 1, 113);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) loc1;
	RTHOOK(3);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > loc5)) break;
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
		loc3 = F1085_8473(RTCW(arg1), tw1, loc1);
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			loc3 = (EIF_INTEGER_32) loc5;
		}
		RTHOOK(8);
		if ((EIF_BOOLEAN)(loc3 == loc1)) {
		} else {
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc6 == NULL)) {
				RTHOOK(10);
				loc2 = (EIF_INTEGER_32) loc1;
				for (;;) {
					RTHOOK(11);
					tw1 = F1087_8543(RTCW(arg1), loc2);
					tr1 = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tb1 = F1030_8001(RTCW(tr1));
					if ((EIF_BOOLEAN) !tb1) break;
					RTHOOK(12);
					loc2++;
				}
				RTHOOK(13);
				loc6 = F1087_8623(RTCW(arg1), loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			} else {
				RTHOOK(14);
				loc2 = (EIF_INTEGER_32) loc1;
				RTHOOK(15);
				loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					RTHOOK(16);
					tb2 = '\01';
					tb3 = '\01';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
					if (!(EIF_BOOLEAN) (loc4 > ti4_1)) {
						tw1 = F1087_8543(RTCW(loc6), loc4);
						tw2 = F1087_8543(RTCW(arg1), loc2);
						tb3 = (EIF_BOOLEAN)(tw1 != tw2);
					}
					if (!tb3) {
						tb2 = (EIF_BOOLEAN) (loc2 > loc3);
					}
					if (tb2) break;
					RTHOOK(17);
					loc4++;
					RTHOOK(18);
					loc2++;
				}
				RTHOOK(19);
				tb3 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (loc4 <= ti4_1)) {
					tw1 = F1087_8543(RTCW(loc6), loc4);
					tw2 = F1087_8543(RTCW(arg1), loc2);
					tb3 = (EIF_BOOLEAN)(tw1 != tw2);
				}
				if (tb3) {
					RTHOOK(20);
					F1087_8558(RTCW(loc6), (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L)));
				}
			}
		}
		RTHOOK(21);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
	}
	RTHOOK(22);
	tb3 = '\0';
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
		tb3 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb3) {
		RTHOOK(23);
		tb3 = F1085_8496(RTCW(arg1), loc6);
		if (tb3) {
			RTHOOK(24);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
			F1087_8598(RTCW(arg1), ti4_1);
		}
		RTHOOK(25);
		tr1 = RTMS32_EX_H("\012\000\000\000",1,10);
		tr1 = F1087_8595(tr1, loc6);
		tr2 = RTMS32_EX_H("\012\000\000\000",1,10);
		F1087_8553(RTCW(arg1), tr1, tr2);
	}
	RTHOOK(26);
	RTLE;
	RTEE;
}

void EIF_Minit5 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
