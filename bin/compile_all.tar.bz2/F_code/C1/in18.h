
#ifndef _C1_in18_
#define _C1_in18_

#ifdef __cplusplus
extern "C" {
#endif

extern void F23_189(EIF_REFERENCE);
extern EIF_REFERENCE F23_190(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit18(void);
extern EIF_REFERENCE F1_5(EIF_REFERENCE);
extern EIF_REFERENCE F852_6727(EIF_REFERENCE, EIF_REFERENCE);
extern void F852_6769(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1104_9171(EIF_REFERENCE);
extern void F852_6721(EIF_REFERENCE, EIF_INTEGER_32);
extern void F608_6140(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
