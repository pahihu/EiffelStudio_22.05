/*
 * Code for class IRON_REPOSITORY_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir8.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_REPOSITORY_FACTORY}.new_repository */
EIF_REFERENCE F13_108 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_repository", 12, Current, 1, 1, 141);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tr1 = RTMS_EX_H("https://",8,441357103);
	tb2 = F1078_8212(RTCW(arg1), tr1);
	if (!tb2) {
		tr1 = RTMS_EX_H("http://",7,769736239);
		tb2 = F1078_8212(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(1335, 0x01).id, 1335, _OBJSIZ_6_2_0_1_0_0_0_0_);
		F1336_12810(RTCW(loc1), arg1);
		RTHOOK(3);
		Result = RTLNS(eif_new_type(1088, 0x01).id, 1088, _OBJSIZ_4_0_0_0_0_0_0_0_);
		tr1 = F1336_12828(RTCW(loc1));
		F1089_8630(RTCW(Result), tr1);
	} else {
		RTHOOK(4);
		tr1 = RTMS_EX_H("file://",7,1704345391);
		tb1 = F1078_8212(RTCW(arg1), tr1);
		if (tb1) {
			RTHOOK(5);
			loc1 = RTLNS(eif_new_type(1335, 0x01).id, 1335, _OBJSIZ_6_2_0_1_0_0_0_0_);
			F1336_12810(RTCW(loc1), arg1);
			RTHOOK(6);
			Result = RTLNS(eif_new_type(1089, 0x01).id, 1089, _OBJSIZ_3_0_0_0_0_0_0_0_);
			tr1 = F1336_12828(RTCW(loc1));
			F1090_8643(RTCW(Result), tr1);
		} else {
			RTHOOK(7);
			Result = RTLNS(eif_new_type(1089, 0x01).id, 1089, _OBJSIZ_3_0_0_0_0_0_0_0_);
			F1090_8641(RTCW(Result), arg1);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit8 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
