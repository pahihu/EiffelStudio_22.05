
#ifndef _C1_i123_
#define _C1_i123_

#ifdef __cplusplus
extern "C" {
#endif

extern void F28_218(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit23(void);
extern void F140_1937(EIF_REFERENCE, EIF_REFERENCE);
extern long O1843[];
extern long O1844[];

#ifdef __cplusplus
}
#endif

#endif
