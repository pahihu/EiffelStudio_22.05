
#ifndef _C1_in44_
#define _C1_in44_

#ifdef __cplusplus
extern "C" {
#endif

extern void F48_456(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F48_469(EIF_REFERENCE);
extern void EIF_Minit44(void);

#ifdef __cplusplus
}
#endif

#endif
