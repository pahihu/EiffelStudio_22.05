/*
 * Code for class INI_SCANNER_STATE_POOL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in18.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INI_SCANNER_STATE_POOL}.make */
void F23_189 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make", 22, Current, 1, 0, 224);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1301,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNSMART(typres0.id);
	}
	F852_6721(RTCW(loc1), ((EIF_INTEGER_32) 3L));
	RTHOOK(2);
	F608_6140(RTCW(loc1));
	RTHOOK(3);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {INI_SCANNER_STATE_POOL}.state */
EIF_REFERENCE F23_190 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("state", 22, Current, 1, 1, 225);
	RTGC;
	RTHOOK(1);
	tr1 = F1_5(arg1);
	loc1 = F1104_9171(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F852_6727(RTCW(tr1), loc1);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		RTHOOK(4);
		tr1 = RTLNTY2(eif_new_type(1305, 0x01), 0x01);
		if (RTEQ(arg1, tr1)) {
			RTHOOK(5);
			Result = RTLNS(eif_new_type(1305, 0x01).id, 1305, _OBJSIZ_2_0_0_0_0_0_0_0_);
		} else {
			RTHOOK(6);
			tr1 = RTLNTY2(eif_new_type(1303, 0x01), 0x01);
			if (RTEQ(arg1, tr1)) {
				RTHOOK(7);
				Result = RTLNS(eif_new_type(1303, 0x01).id, 1303, _OBJSIZ_2_0_0_0_0_0_0_0_);
			} else {
				RTHOOK(8);
				tr1 = RTLNTY2(eif_new_type(1302, 0x01), 0x01);
				if (RTEQ(arg1, tr1)) {
					RTHOOK(9);
					Result = RTLNS(eif_new_type(1302, 0x01).id, 1302, _OBJSIZ_2_0_0_0_0_0_0_0_);
				} else {
					RTHOOK(10);
					tr1 = RTLNTY2(eif_new_type(1304, 0x01), 0x01);
					if (RTEQ(arg1, tr1)) {
						RTHOOK(11);
						Result = RTLNS(eif_new_type(1304, 0x01).id, 1304, _OBJSIZ_2_0_0_0_0_0_0_0_);
					} else {
						RTHOOK(12);
						RTCT0("valid_type_from_precondition", EX_CHECK);
							RTCF0;
					}
				}
			}
		}
		RTHOOK(13);
		tr1 = *(EIF_REFERENCE *)(Current);
		F852_6769(RTCW(tr1), Result, loc1);
	}
	RTHOOK(16);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit18 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
