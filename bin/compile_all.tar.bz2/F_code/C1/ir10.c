/*
 * Code for class IRON_PACKAGE_INSTALLATION_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir10.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_INSTALLATION_INFO}.make_with_file */
void F15_112 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make_with_file", 14, Current, 0, 1, 145);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F15_118(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.load */
void F15_118 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	struct eif_ex_44 sloc7;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) sloc7.data;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	memset (&sloc7.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc7.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc7.overhead, eif_new_type(50, 0x00).id);
	RTLI(21);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc10);
	RTLR(3,loc1);
	RTLR(4,loc11);
	RTLR(5,loc12);
	RTLR(6,tr2);
	RTLR(7,loc13);
	RTLR(8,loc2);
	RTLR(9,loc3);
	RTLR(10,loc14);
	RTLR(11,loc5);
	RTLR(12,loc15);
	RTLR(13,loc6);
	RTLR(14,loc16);
	RTLR(15,loc17);
	RTLR(16,loc8);
	RTLR(17,loc9);
	RTLR(18,loc7);
	RTLR(19,loc4);
	RTLR(20,loc18);
	RTLIU(21);
	
	RTEAA("load", 14, Current, 18, 0, 151);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1101, 1).id);
	F1102_9102(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = F15_123(Current, *(EIF_REFERENCE *)(Current));
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		RTHOOK(3);
		loc1 = RTLNS(eif_new_type(1322, 0x01).id, 1322, _OBJSIZ_9_2_0_3_0_0_0_0_);
		F1323_12313(RTCW(loc1), loc10);
		RTHOOK(4);
		F1323_12333(RTCW(loc1));
		RTHOOK(5);
		tb1 = '\0';
		tb2 = F1323_12317(RTCW(loc1));
		if (tb2) {
			tr1 = F1323_12329(RTCW(loc1));
			loc11 = tr1;
			tb1 = EIF_TEST(loc11);
		}
		if (tb1) {
			RTHOOK(6);
			tb1 = '\0';
			tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("repository",10,818164089);
			F1212_9530(RTCW(tr1), tr2);
			tr1 = F1246_10542(loc11, tr1);
			loc12 = tr1;
			loc12 = RTRV(eif_new_type(1245, 0x01),loc12);
			if (EIF_TEST(loc12)) {
				tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("uri",3,7697001);
				F1212_9530(RTCW(tr1), tr2);
				tr1 = F1246_10542(loc12, tr1);
				loc13 = tr1;
				loc13 = RTRV(eif_new_type(1211, 0x01),loc13);
				tb1 = EIF_TEST(loc13);
			}
			if (tb1) {
				RTHOOK(7);
				loc2 = RTLNS(eif_new_type(12, 0x01).id, 12, _OBJSIZ_0_0_0_0_0_0_0_0_);
				RTHOOK(8);
				tr1 = *(EIF_REFERENCE *)(loc13);
				tr1 = F1078_8224(RTCW(tr1));
				loc3 = F13_108(RTCW(loc2), tr1);
			}
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTHOOK(10);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5445[Dtype(RTCW(loc3))-1088])(loc3);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
				RTHOOK(11);
				tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("package-id",10,287790948);
				F1212_9530(RTCW(tr1), tr2);
				tr1 = F1246_10542(loc11, tr1);
				loc14 = tr1;
				loc14 = RTRV(eif_new_type(1211, 0x01),loc14);
				if (EIF_TEST(loc14)) {
					RTHOOK(12);
					tr1 = *(EIF_REFERENCE *)(loc14);
					loc5 = F1078_8224(RTCW(tr1));
				}
				RTHOOK(13);
				tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("package-name",12,1583611749);
				F1212_9530(RTCW(tr1), tr2);
				tr1 = F1246_10542(loc11, tr1);
				loc15 = tr1;
				loc15 = RTRV(eif_new_type(1211, 0x01),loc15);
				if (EIF_TEST(loc15)) {
					RTHOOK(14);
					tr1 = *(EIF_REFERENCE *)(loc15);
					loc6 = F1078_8224(RTCW(tr1));
				}
				RTHOOK(15);
				tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("local-path",10,315937896);
				F1212_9530(RTCW(tr1), tr2);
				tr1 = F1246_10542(loc11, tr1);
				loc16 = tr1;
				loc16 = RTRV(eif_new_type(1211, 0x01),loc16);
				if (EIF_TEST(loc16)) {
					RTHOOK(16);
					loc17 = loc3;
					loc17 = RTRV(eif_new_type(1089, 0x01),loc17);
					if (EIF_TEST(loc17)) {
						RTHOOK(17);
						tr1 = RTLNSMART(eif_new_type(1101, 1).id);
						tr2 = F1212_9543(loc16);
						F1102_9104(RTCW(tr1), tr2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
						RTHOOK(18);
						if ((EIF_BOOLEAN)(loc6 != NULL)) {
							RTHOOK(19);
							loc8 = RTLNS(eif_new_type(13, 0x01).id, 13, _OBJSIZ_0_0_0_0_0_0_0_0_);
							RTHOOK(20);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							tr2 = RTMS_EX_H("package",7,382506597);
							tr1 = F1102_9131(RTCW(tr1), tr2);
							tr2 = RTMS_EX_H("iron",4,1769107310);
							loc9 = F1102_9134(RTCW(tr1), tr2);
							RTHOOK(21);
							tb1 = F51_487(RTCW(loc7), loc9);
							if ((EIF_BOOLEAN) !tb1) {
								RTHOOK(22);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								tr1 = F1102_9131(RTCW(tr1), loc6);
								tr2 = RTMS_EX_H("iron",4,1769107310);
								loc9 = F1102_9134(RTCW(tr1), tr2);
							}
							RTHOOK(23);
							tb1 = F51_487(RTCW(loc7), loc9);
							if ((EIF_BOOLEAN) !tb1) {
								RTHOOK(24);
								loc9 = F15_121(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
							}
							RTHOOK(25);
							tb1 = '\0';
							if ((EIF_BOOLEAN)(loc9 != NULL)) {
								tb2 = F51_487(RTCW(loc7), loc9);
								tb1 = tb2;
							}
							if (tb1) {
								RTHOOK(26);
								loc4 = F14_109(RTCW(loc8), loc9);
								RTHOOK(27);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2557[Dtype(RTCW(loc4))-207])(loc4, loc17);
								RTAR(Current, tr1);
								*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
							}
						}
					} else {
						RTHOOK(28);
						tr1 = RTLNSMART(eif_new_type(1101, 1).id);
						tr2 = F1212_9543(loc16);
						F1102_9104(RTCW(tr1), tr2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
						RTHOOK(29);
						tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("package",7,382506597);
						F1212_9530(RTCW(tr1), tr2);
						tr1 = F1246_10542(loc11, tr1);
						loc18 = tr1;
						loc18 = RTRV(eif_new_type(1245, 0x01),loc18);
						if (EIF_TEST(loc18)) {
							RTHOOK(30);
							tr1 = F15_120(Current, loc18, loc3);
							RTAR(Current, tr1);
							*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
						}
					}
				} else {
					RTHOOK(31);
					tr1 = RTLNSMART(eif_new_type(1101, 1).id);
					F1102_9102(RTCW(tr1));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				}
			}
		}
	}
	RTHOOK(32);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.json_object_to_package */
EIF_REFERENCE F15_120 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(28);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,arg2);
	RTLR(6,Result);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc6);
	RTLR(10,loc1);
	RTLR(11,loc7);
	RTLR(12,loc8);
	RTLR(13,loc9);
	RTLR(14,loc10);
	RTLR(15,loc11);
	RTLR(16,loc12);
	RTLR(17,loc13);
	RTLR(18,loc14);
	RTLR(19,loc15);
	RTLR(20,loc16);
	RTLR(21,loc17);
	RTLR(22,loc18);
	RTLR(23,tr3);
	RTLR(24,loc19);
	RTLR(25,loc20);
	RTLR(26,loc21);
	RTLR(27,Current);
	RTLIU(28);
	
	RTEAA("json_object_to_package", 14, Current, 21, 2, 153);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("id",2,26980);
	F1212_9530(RTCW(tr1), tr2);
	tr1 = F1246_10542(RTCW(arg1), tr1);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1211, 0x01),loc2);
	if (EIF_TEST(loc2)) {
		tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("name",4,1851878757);
		F1212_9530(RTCW(tr1), tr2);
		tr1 = F1246_10542(RTCW(arg1), tr1);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1211, 0x01),loc3);
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		RTHOOK(2);
		Result = RTLNS(eif_new_type(1090, 0x01).id, 1090, _OBJSIZ_10_0_0_2_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(loc2);
		F1091_8658(RTCW(Result), tr1, arg2);
		RTHOOK(3);
		tr1 = F1246_10550(RTCW(arg1));
		tr1 = F1078_8224(RTCW(tr1));
		F1091_8689(RTCW(Result), tr1);
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(loc3);
		F1091_8693(RTCW(Result), tr1);
		RTHOOK(5);
		tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("title",5,1770128485);
		F1212_9530(RTCW(tr1), tr2);
		tr1 = F1246_10542(RTCW(arg1), tr1);
		loc4 = tr1;
		loc4 = RTRV(eif_new_type(1211, 0x01),loc4);
		if (EIF_TEST(loc4)) {
			RTHOOK(6);
			tr1 = F1212_9543(loc4);
			F1091_8694(RTCW(Result), tr1);
		}
		RTHOOK(7);
		tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("description",11,801826414);
		F1212_9530(RTCW(tr1), tr2);
		tr1 = F1246_10542(RTCW(arg1), tr1);
		loc5 = tr1;
		loc5 = RTRV(eif_new_type(1211, 0x01),loc5);
		if (EIF_TEST(loc5)) {
			RTHOOK(8);
			tr1 = F1212_9543(loc5);
			F1091_8695(RTCW(Result), tr1);
		}
		RTHOOK(9);
		tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_revision",16,1455418222);
		F1212_9530(RTCW(tr1), tr2);
		tr1 = F1246_10542(RTCW(arg1), tr1);
		loc6 = tr1;
		loc6 = RTRV(eif_new_type(1212, 0x01),loc6);
		if (EIF_TEST(loc6)) {
			RTHOOK(10);
			loc1 = *(EIF_REFERENCE *)(loc6);
			RTHOOK(11);
			tb1 = F1078_8201(RTCW(loc1));
			if (tb1) {
				RTHOOK(12);
				tu4_1 = F1078_8235(RTCW(loc1));
				F1091_8696(RTCW(Result), tu4_1);
			}
		}
		RTHOOK(13);
		tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive",7,1406298469);
		F1212_9530(RTCW(tr1), tr2);
		tr1 = F1246_10542(RTCW(arg1), tr1);
		loc7 = tr1;
		loc7 = RTRV(eif_new_type(1211, 0x01),loc7);
		if (EIF_TEST(loc7)) {
			RTHOOK(14);
			tr1 = *(EIF_REFERENCE *)(loc7);
			F1091_8698(RTCW(Result), tr1);
		}
		RTHOOK(15);
		tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_hash",12,1760719464);
		F1212_9530(RTCW(tr1), tr2);
		tr1 = F1246_10542(RTCW(arg1), tr1);
		loc8 = tr1;
		loc8 = RTRV(eif_new_type(1211, 0x01),loc8);
		if (EIF_TEST(loc8)) {
			RTHOOK(16);
			tr1 = *(EIF_REFERENCE *)(loc8);
			F1091_8700(RTCW(Result), tr1);
		}
		RTHOOK(17);
		tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_size",12,1945794917);
		F1212_9530(RTCW(tr1), tr2);
		tr1 = F1246_10542(RTCW(arg1), tr1);
		loc9 = tr1;
		loc9 = RTRV(eif_new_type(1212, 0x01),loc9);
		if (EIF_TEST(loc9)) {
			RTHOOK(18);
			loc1 = *(EIF_REFERENCE *)(loc9);
			RTHOOK(19);
			tb1 = F1078_8196(RTCW(loc1));
			if (tb1) {
				RTHOOK(20);
				ti4_1 = F1078_8230(RTCW(loc1));
				F1091_8697(RTCW(Result), ti4_1);
			}
		}
		RTHOOK(21);
		tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("paths",5,1635879027);
		F1212_9530(RTCW(tr1), tr2);
		tr1 = F1246_10542(RTCW(arg1), tr1);
		loc10 = tr1;
		loc10 = RTRV(eif_new_type(1244, 0x01),loc10);
		if (EIF_TEST(loc10)) {
			RTHOOK(22);
			tr1 = F1245_10519(loc10);
			loc11 = F949_7085(RTCW(tr1));
			for (;;) {
				tb1 = F557_6081(loc11);
				if (tb1) break;
				RTHOOK(23);
				tr1 = F557_6072(loc11);
				loc12 = tr1;
				loc12 = RTRV(eif_new_type(1211, 0x01),loc12);
				if (EIF_TEST(loc12)) {
					RTHOOK(24);
					tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_5_);
					tr2 = *(EIF_REFERENCE *)(loc12);
					F949_7111(RTCW(tr1), tr2);
				}
				RTHOOK(25);
				F557_6087(loc11);
			}
		}
		RTHOOK(26);
		tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("tags",4,1952540531);
		F1212_9530(RTCW(tr1), tr2);
		tr1 = F1246_10542(RTCW(arg1), tr1);
		loc13 = tr1;
		loc13 = RTRV(eif_new_type(1244, 0x01),loc13);
		if (EIF_TEST(loc13)) {
			RTHOOK(27);
			tr1 = F1245_10519(loc13);
			loc14 = F949_7085(RTCW(tr1));
			for (;;) {
				tb2 = F557_6081(loc14);
				if (tb2) break;
				RTHOOK(28);
				tr1 = F557_6072(loc14);
				loc15 = tr1;
				loc15 = RTRV(eif_new_type(1211, 0x01),loc15);
				if (EIF_TEST(loc15)) {
					RTHOOK(29);
					tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_6_);
					tr2 = F1212_9543(loc15);
					F949_7111(RTCW(tr1), tr2);
				}
				RTHOOK(30);
				F557_6087(loc14);
			}
		}
		RTHOOK(31);
		tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("links",5,1769673587);
		F1212_9530(RTCW(tr1), tr2);
		tr1 = F1246_10542(RTCW(arg1), tr1);
		loc16 = tr1;
		loc16 = RTRV(eif_new_type(1245, 0x01),loc16);
		if (EIF_TEST(loc16)) {
			RTHOOK(32);
			loc17 = F1246_10552(loc16);
			for (;;) {
				tb3 = F547_6063(loc17);
				if (tb3) break;
				RTHOOK(33);
				tr1 = F547_6060(loc17);
				loc18 = tr1;
				loc18 = RTRV(eif_new_type(1211, 0x01),loc18);
				if (EIF_TEST(loc18)) {
					RTHOOK(34);
					tr1 = F1212_9543(loc18);
					tr2 = RTMS32_EX_H("l\000\000\000i\000\000\000n\000\000\000k\000\000\000[\000\000\000",5,1769673563);
					tr3 = F547_6061(loc17);
					tr3 = F1212_9543(RTCW(tr3));
					tr2 = F1087_8595(tr2, tr3);
					tr3 = F1078_8224(RTMS_EX_H("]",1,93));
					tr2 = F1087_8595(RTCW(tr2), tr3);
					F1091_8692(RTCW(Result), tr1, tr2);
				}
				RTHOOK(35);
				F547_6064(loc17);
			}
		}
		RTHOOK(36);
		tr1 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("notes",5,1870743923);
		F1212_9530(RTCW(tr1), tr2);
		tr1 = F1246_10542(RTCW(arg1), tr1);
		loc19 = tr1;
		loc19 = RTRV(eif_new_type(1245, 0x01),loc19);
		if (EIF_TEST(loc19)) {
			RTHOOK(37);
			loc20 = F1246_10552(loc19);
			for (;;) {
				tb4 = F547_6063(loc20);
				if (tb4) break;
				RTHOOK(38);
				tr1 = F547_6060(loc20);
				loc21 = tr1;
				loc21 = RTRV(eif_new_type(1211, 0x01),loc21);
				if (EIF_TEST(loc21)) {
					RTHOOK(39);
					tr1 = F1212_9543(loc21);
					tr2 = F547_6061(loc20);
					tr2 = F1212_9543(RTCW(tr2));
					F1091_8692(RTCW(Result), tr1, tr2);
				}
				RTHOOK(40);
				F547_6064(loc20);
			}
		}
	}
	RTHOOK(41);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.first_iron_file_path_from */
EIF_REFERENCE F15_121 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,Result);
	RTLR(6,Current);
	RTLIU(7);
	
	RTEAA("first_iron_file_path_from", 14, Current, 3, 1, 154);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(448, 0x01).id, 448, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F449_5345(RTCW(loc1), arg1);
	RTHOOK(2);
	tb1 = F449_5368(RTCW(loc1));
	if (tb1) {
		RTHOOK(3);
		tr1 = F449_5359(RTCW(loc1));
		tr1 = F949_7085(RTCW(tr1));
		loc2 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = F557_6081(loc2);
			if (tb1) break;
			RTHOOK(4);
			if ((EIF_BOOLEAN)(Result != NULL)) break;
			RTHOOK(5);
			tb2 = '\01';
			tr1 = F557_6072(loc2);
			tb3 = F1102_9109(RTCW(tr1));
			if (!tb3) {
				tr1 = F557_6072(loc2);
				tb3 = F1102_9110(RTCW(tr1));
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				RTHOOK(6);
				tb2 = '\0';
				tr1 = F557_6072(loc2);
				tr1 = F1102_9121(RTCW(tr1));
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					tr1 = RTMS_EX_H("iron",4,1769107310);
					tb3 = F1078_8207(loc3, tr1);
					tb2 = tb3;
				}
				if (tb2) {
					RTHOOK(7);
					tr1 = F557_6072(loc2);
					Result = F1102_9132(RTCW(arg1), tr1);
				}
			}
			RTHOOK(8);
			F557_6087(loc2);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.file_content */
EIF_REFERENCE F15_123 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("file_content", 14, Current, 1, 1, 156);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(828, 0x01).id, 828, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F828_6356(RTCW(loc1), arg1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = F828_6390(RTCW(loc1));
	if (tb2) {
		tb2 = F828_6409(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F828_6425(RTCW(loc1));
		RTHOOK(4);
		Result = RTLNS(eif_new_type(1082, 0x01).id, 1082, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1081_8295(RTCW(Result), ((EIF_INTEGER_32) 1024L));
		for (;;) {
			RTHOOK(5);
			tb1 = F636_6157(RTCW(loc1));
			if (tb1) break;
			RTHOOK(6);
			F828_6504(RTCW(loc1), ((EIF_INTEGER_32) 1024L));
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7088[Dtype(RTCW(Result))-1082])(Result, tr1);
		}
		RTHOOK(8);
		F828_6442(RTCW(loc1));
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit10 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
