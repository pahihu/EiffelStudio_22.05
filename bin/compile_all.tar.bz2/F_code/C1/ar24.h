
#ifndef _C1_ar24_
#define _C1_ar24_

#ifdef __cplusplus
extern "C" {
#endif

extern void F29_223(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void F29_224(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit24(void);
extern void F961_7139(EIF_REFERENCE, EIF_REFERENCE);
extern void F949_7071(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R5345[])();
extern char *(*R5314[])();
extern char *(*R5315[])();
extern char *(*R5316[])();

#ifdef __cplusplus
}
#endif

#endif
