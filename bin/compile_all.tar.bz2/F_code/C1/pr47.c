/*
 * Code for class PRODUCT_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr47.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PRODUCT_NAMES}.workbench_name */

EIF_REFERENCE F52_488 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (327,RTMS_EX_H("EiffelStudio",12,1072716399));
}

void EIF_Minit47 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
