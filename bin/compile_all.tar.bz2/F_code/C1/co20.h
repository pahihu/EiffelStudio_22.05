
#ifndef _C1_co20_
#define _C1_co20_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F25_202(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit20(void);
extern void F453_5432(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
