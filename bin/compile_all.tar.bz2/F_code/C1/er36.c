/*
 * Code for class ERROR_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "er36.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ERROR_CONSTANTS}.err_msg_0 */

EIF_REFERENCE F41_379 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (481,RTMS_EX_H("compilation successfully",24,297046137));
}

/* {ERROR_CONSTANTS}.err_msg_1 */

EIF_REFERENCE F41_380 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (511,RTMS_EX_H("\\ at end of pattern",19,1082148462));
}

/* {ERROR_CONSTANTS}.err_msg_2 */

EIF_REFERENCE F41_381 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (512,RTMS_EX_H("\\c at end of pattern",20,586514030));
}

/* {ERROR_CONSTANTS}.err_msg_3 */

EIF_REFERENCE F41_382 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (513,RTMS_EX_H("unrecognized character follows \\",32,1794949212));
}

/* {ERROR_CONSTANTS}.err_msg_4 */

EIF_REFERENCE F41_383 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (507,RTMS_EX_H("numbers out of order in {} quantifier",37,1764177010));
}

/* {ERROR_CONSTANTS}.err_msg_5 */

EIF_REFERENCE F41_384 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (506,RTMS_EX_H("number too big in {} quantifier",31,236715890));
}

/* {ERROR_CONSTANTS}.err_msg_6 */

EIF_REFERENCE F41_385 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (498,RTMS_EX_H("missing terminating ] for character class",41,461852531));
}

/* {ERROR_CONSTANTS}.err_msg_7 */

EIF_REFERENCE F41_386 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (502,RTMS_EX_H("invalid escape sequence in character class",42,267449459));
}

/* {ERROR_CONSTANTS}.err_msg_8 */

EIF_REFERENCE F41_387 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (503,RTMS_EX_H("range out of order in character class",37,652901747));
}

/* {ERROR_CONSTANTS}.err_msg_9 */

EIF_REFERENCE F41_388 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (504,RTMS_EX_H("nothing to repeat",17,825052276));
}

/* {ERROR_CONSTANTS}.err_msg_11 */

EIF_REFERENCE F41_390 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (505,RTMS_EX_H("internal error: unexpected repeat",33,1855335540));
}

/* {ERROR_CONSTANTS}.err_msg_12 */

EIF_REFERENCE F41_391 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (491,RTMS_EX_H("unrecognized character after (\?",31,636561471));
}

/* {ERROR_CONSTANTS}.err_msg_13 */

EIF_REFERENCE F41_392 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (492,RTMS_EX_H("too many capturing parenthesized sub-patterns",45,1757158771));
}

/* {ERROR_CONSTANTS}.err_msg_14 */

EIF_REFERENCE F41_393 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (494,RTMS_EX_H("missing )",9,1989432361));
}

/* {ERROR_CONSTANTS}.err_msg_15 */

EIF_REFERENCE F41_394 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (484,RTMS_EX_H("back reference to non-existent subpattern",41,1930188142));
}

/* {ERROR_CONSTANTS}.err_msg_18 */

EIF_REFERENCE F41_397 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (486,RTMS_EX_H("missing ) after comment",23,1848893300));
}

/* {ERROR_CONSTANTS}.err_msg_22 */

EIF_REFERENCE F41_401 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (483,RTMS_EX_H("unmatched parentheses",21,366512243));
}

/* {ERROR_CONSTANTS}.err_msg_24 */

EIF_REFERENCE F41_403 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (490,RTMS_EX_H("unrecognized character after (\?<",32,1898751036));
}

/* {ERROR_CONSTANTS}.err_msg_25 */

EIF_REFERENCE F41_404 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (485,RTMS_EX_H("lookbehind assertion is not fixed length",40,831850344));
}

/* {ERROR_CONSTANTS}.err_msg_26 */

EIF_REFERENCE F41_405 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (487,RTMS_EX_H("malformed number after (\?(",26,217491240));
}

/* {ERROR_CONSTANTS}.err_msg_27 */

EIF_REFERENCE F41_406 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (493,RTMS_EX_H("conditional group contains more than two branches",49,572996467));
}

/* {ERROR_CONSTANTS}.err_msg_28 */

EIF_REFERENCE F41_407 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (489,RTMS_EX_H("assertion expected after (\?(",28,1018686248));
}

/* {ERROR_CONSTANTS}.err_msg_30 */

EIF_REFERENCE F41_409 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (500,RTMS_EX_H("unknown POSIX class name",24,1984937317));
}

/* {ERROR_CONSTANTS}.err_msg_31 */

EIF_REFERENCE F41_410 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (499,RTMS_EX_H("POSIX collating elements are not supported",42,1477603940));
}

/* {ERROR_CONSTANTS}.err_msg_35 */

EIF_REFERENCE F41_414 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (488,RTMS_EX_H("invalid condition (\?(0)",23,1170936617));
}

/* {ERROR_CONSTANTS}.err_msg_99 */

EIF_REFERENCE F41_416 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (482,RTMS_EX_H("no pattern compiled",19,1370646116));
}

void EIF_Minit36 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
