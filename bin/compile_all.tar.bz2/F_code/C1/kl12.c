/*
 * Code for class KL_ANY_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl12.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_ANY_ROUTINES}.same_types */
EIF_BOOLEAN F17_151 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("same_types", 16, Current, 0, 2, 184);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg2);
	Result = (EIF_BOOLEAN) eif_builtin_ANY_same_type__o_b (arg1, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit12 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
