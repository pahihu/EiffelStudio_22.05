
#ifndef _C1_i17_
#define _C1_i17_

#ifdef __cplusplus
extern "C" {
#endif

extern void F12_101(EIF_REFERENCE, EIF_REFERENCE);
extern void F12_102(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit7(void);

#ifdef __cplusplus
}
#endif

#endif
