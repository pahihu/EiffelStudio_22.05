/*
 * Code for class XML_NAMESPACE_RESOLVER_CONTEXT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm49.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.make */
void F54_496 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 53, Current, 0, 0, 588);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,943,0xFF01,851,0xFF01,1084,0xFF01,1086,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F944_7001(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.reset */
void F54_497 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("reset", 53, Current, 0, 0, 589);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F944_7037(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.add_default */
void F54_498 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("add_default", 53, Current, 0, 1, 590);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(540,F54_510, (Current));
	F54_499(Current, arg1, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.add */
void F54_499 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("add", 53, Current, 0, 2, 591);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F944_7004(RTCW(tr1));
	tr2 = F54_507(Current, arg2);
	F852_6768(RTCW(tr1), arg1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.shallow_has */
EIF_BOOLEAN F54_501 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("shallow_has", 53, Current, 0, 1, 593);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_3_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F944_7004(RTCW(tr1));
		tr2 = F54_507(Current, arg1);
		tb1 = F852_6729(RTCW(tr1), tr2);
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.has */
EIF_BOOLEAN F54_502 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("has", 53, Current, 2, 1, 594);
	RTGC;
	RTHOOK(1);
	loc1 = F54_507(Current, arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = F944_7008(RTCW(tr1));
	tb1 = EIF_FALSE;
	for (;;) {
		if (tb1) break;
		tb2 = F555_6067(loc2);
		if (tb2) break;
		RTHOOK(3);
		tr1 = F555_6066(loc2);
		tb3 = F852_6729(RTCW(tr1), loc1);
		tb1 = tb3;
		F555_6069(loc2);
	}
	Result = (EIF_BOOLEAN) tb1;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.resolve_default */
EIF_REFERENCE F54_503 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("resolve_default", 53, Current, 0, 0, 595);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(540,F54_510, (Current));
	Result = F54_504(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.resolve */
EIF_REFERENCE F54_504 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLR(6,loc1);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTEAA("resolve", 53, Current, 5, 1, 596);
	RTGC;
	RTHOOK(1);
	Result = RTOUCR(541,F54_511, (Current));
	RTHOOK(2);
	loc3 = F54_507(Current, arg1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = F944_7008(RTCW(tr1));
	for (;;) {
		tb1 = F555_6067(loc4);
		if (tb1) break;
		RTHOOK(4);
		if (loc2) break;
		RTHOOK(5);
		loc1 = F555_6066(loc4);
		RTHOOK(6);
		tb2 = '\0';
		tb3 = F852_6729(RTCW(loc1), loc3);
		if (tb3) {
			tr1 = F852_6727(RTCW(loc1), loc3);
			loc5 = tr1;
			tb2 = EIF_TEST(loc5);
		}
		if (tb2) {
			RTHOOK(7);
			Result = (EIF_REFERENCE) loc5;
			RTHOOK(8);
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		RTHOOK(9);
		F555_6069(loc4);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.push */
void F54_505 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("push", 53, Current, 0, 0, 597);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = F54_509(Current);
	F944_7027(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.pop */
void F54_506 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("pop", 53, Current, 0, 0, 598);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_3_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current);
		F944_7020(RTCW(tr1));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5503[Dtype(RTCW(tr1))-800])(tr1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.to_context_key */
EIF_REFERENCE F54_507 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	
	
	RTEAA("to_context_key", 53, Current, 0, 1, 599);
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.new_string_string_table */
EIF_REFERENCE F54_509 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("new_string_string_table", 53, Current, 0, 0, 601);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,851,0xFF01,1084,0xFF01,1086,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 851, _OBJSIZ_7_3_0_7_0_0_0_0_);
	}
	F852_6721(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.default_pseudo_prefix */

EIF_REFERENCE F54_510 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (540,RTMS32_EX_H("",0,0));
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.default_namespace */

EIF_REFERENCE F54_511 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (541,RTMS32_EX_H("",0,0));
}

void EIF_Minit49 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
