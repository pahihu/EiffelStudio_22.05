
#ifndef _C1_in43_
#define _C1_in43_

#ifdef __cplusplus
extern "C" {
#endif

extern void F49_456(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F49_469(EIF_REFERENCE);
extern void EIF_Minit43(void);

#ifdef __cplusplus
}
#endif

#endif
