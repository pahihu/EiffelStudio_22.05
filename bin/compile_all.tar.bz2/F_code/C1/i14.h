
#ifndef _C1_i14_
#define _C1_i14_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F9_50(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F9_54(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_CHARACTER_8);
extern void EIF_Minit4(void);
extern void F1085_8462(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F1087_8537(EIF_REFERENCE, EIF_REFERENCE);
extern void F1087_8568(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
