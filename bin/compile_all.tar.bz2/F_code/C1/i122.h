
#ifndef _C1_i122_
#define _C1_i122_

#ifdef __cplusplus
extern "C" {
#endif

extern void F27_211(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit22(void);
extern void F375_4113(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
