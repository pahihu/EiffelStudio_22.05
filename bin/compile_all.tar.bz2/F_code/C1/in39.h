
#ifndef _C1_in39_
#define _C1_in39_

#ifdef __cplusplus
extern "C" {
#endif

extern void F45_437(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F45_445(EIF_REFERENCE);
extern void EIF_Minit39(void);

#ifdef __cplusplus
}
#endif

#endif
