/*
 * Code for class reference FILE_UTILITIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi46.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FILE_UTILITIES}.directory_path_exists */
EIF_BOOLEAN F50_476 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("directory_path_exists", 49, Current, 0, 1, 568);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = F1102_9112(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNS(eif_new_type(448, 0x01).id, 448, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F449_5345(RTCW(tr1), arg1);
		tb1 = F449_5368(RTCW(tr1));
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE_UTILITIES}.directory_exists */
EIF_BOOLEAN F50_477 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("directory_exists", 49, Current, 0, 1, 569);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6919[Dtype(RTCW(arg1))-1081])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNS(eif_new_type(448, 0x01).id, 448, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F449_5343(RTCW(tr1), arg1);
		tb1 = F449_5368(RTCW(tr1));
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE_UTILITIES}.create_directory */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F50_481 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTLD;
	RTXD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Current);
	RTLR(4,saved_except);
	RTLIU(5);
	RTXSLS;
	
	RTEAA("create_directory", 49, Current, 2, 1, 573);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(448, 0x01).id, 448, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F449_5343(RTCW(tr1), arg1);
		loc2 = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		tb1 = F449_5368(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(4);
			F449_5348(RTCW(loc2));
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(5);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(6);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(7);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {FILE_UTILITIES}.file_path_exists */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_BOOLEAN F50_487 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_VOLATILE EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	RTXD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,saved_except);
	RTLIU(5);
	RTXSLS;
	
	RTEAA("file_path_exists", 49, Current, 2, 1, 579);
	RTGC;
	RTE_T
	RTHOOK(1);
	tb1 = '\0';
	tb2 = F1102_9112(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = (EIF_BOOLEAN) !loc2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(828, 0x01).id, 828, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F828_6356(RTCW(tr1), arg1);
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		Result = '\0';
		tb1 = F828_6390(RTCW(loc1));
		if (tb1) {
			tb1 = F828_6397(RTCW(loc1));
			Result = tb1;
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(4);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(6);
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit46 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
