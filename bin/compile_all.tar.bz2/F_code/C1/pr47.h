
#ifndef _C1_pr47_
#define _C1_pr47_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F52_488(EIF_REFERENCE);
extern void EIF_Minit47(void);

#ifdef __cplusplus
}
#endif

#endif
