
#ifndef _C1_pu15_
#define _C1_pu15_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F20_158(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_NATURAL_32 F20_167(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32, EIF_BOOLEAN);
extern EIF_CHARACTER_8 F20_168(EIF_REFERENCE, EIF_NATURAL_32);
extern EIF_NATURAL_32 F20_169(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32, EIF_REFERENCE);
extern EIF_NATURAL_32 F20_170(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_NATURAL_32 F20_173(EIF_REFERENCE);
extern void EIF_Minit15(void);
extern void F1081_8295(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R7001[])();
extern char *(*R7092[])();
extern char *(*R6941[])();
extern char *(*R6904[])();

#ifdef __cplusplus
}
#endif

#endif
