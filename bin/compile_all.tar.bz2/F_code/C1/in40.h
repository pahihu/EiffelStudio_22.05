
#ifndef _C1_in40_
#define _C1_in40_

#ifdef __cplusplus
extern "C" {
#endif

extern void F44_437(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F44_445(EIF_REFERENCE);
extern void EIF_Minit40(void);

#ifdef __cplusplus
}
#endif

#endif
