
#ifndef _C1_i117_
#define _C1_i117_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F22_188(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit17(void);
extern void F144_1953(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
