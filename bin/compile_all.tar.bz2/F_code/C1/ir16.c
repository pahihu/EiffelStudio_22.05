/*
 * Code for class IRON_CLIENT_DB
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir16.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_CLIENT_DB}.make */
void F21_174 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 20, Current, 0, 1, 211);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {IRON_CLIENT_DB}.revision */
EIF_INTEGER_32 F21_176 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("revision", 20, Current, 2, 0, 213);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(828, 0x01).id, 828, _OBJSIZ_4_6_2_4_1_1_2_1_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOUCR(611,F451_5409, (RTCW(tr1)));
	F828_6356(RTCW(loc1), tr1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = F828_6390(RTCW(loc1));
	if (tb2) {
		tb2 = F828_6393(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F828_6425(RTCW(loc1));
		RTHOOK(4);
		F828_6503(RTCW(loc1));
		RTHOOK(5);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTHOOK(6);
		tb1 = F1078_8196(RTCW(loc2));
		if (tb1) {
			RTHOOK(7);
			Result = F1078_8230(RTCW(loc2));
		} else {
			RTHOOK(8);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		}
		RTHOOK(9);
		F828_6442(RTCW(loc1));
	} else {
		RTHOOK(10);
		RTHOOK(11);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_CLIENT_DB}.repositories */
EIF_REFERENCE F21_177 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("repositories", 20, Current, 1, 0, 214);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(204, 0x01).id, 204, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOUCR(610,F451_5408, (RTCW(tr1)));
	F205_2593(RTCW(loc1), tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT_DB}.installed_packages */
EIF_REFERENCE F21_178 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,loc6);
	RTLR(7,loc4);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,loc9);
	RTLR(11,Result);
	RTLR(12,loc10);
	RTLR(13,tr2);
	RTLR(14,loc11);
	RTLIU(15);
	
	RTEAA("installed_packages", 20, Current, 11, 0, 215);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1090,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc5 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(loc5), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	F608_6140(RTCW(loc5));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = RTOUCR(612,F451_5412, (RTCW(tr1)));
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1101,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc3 = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F949_7071(RTCW(loc3), ((EIF_INTEGER_32) 10L));
	RTHOOK(5);
	loc2 = RTLNS(eif_new_type(105, 0x01).id, 105, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F106_1475(RTCW(loc2), loc3);
	RTHOOK(6);
	tr1 = F1102_9123(RTCW(loc1));
	tr1 = F1102_9125(RTCW(tr1));
	F106_1479(RTCW(loc2), tr1);
	RTHOOK(7);
	loc6 = F949_7085(RTCW(loc3));
	for (;;) {
		tb1 = F557_6081(loc6);
		if (tb1) break;
		RTHOOK(8);
		loc4 = RTLNS(eif_new_type(14, 0x01).id, 14, _OBJSIZ_4_0_0_0_0_0_0_0_);
		tr1 = F557_6072(loc6);
		F15_112(RTCW(loc4), tr1);
		RTHOOK(9);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_3_);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			RTHOOK(10);
			F949_7111(RTCW(loc5), loc7);
		} else {
			RTHOOK(11);
			tb2 = '\0';
			tr1 = F557_6072(loc6);
			tr1 = F21_185(Current, tr1);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				tr1 = F21_186(Current, loc8);
				loc9 = tr1;
				tb2 = EIF_TEST(loc9);
			}
			if (tb2) {
				RTHOOK(12);
				F949_7111(RTCW(loc5), loc9);
			}
		}
		RTHOOK(13);
		F557_6087(loc6);
	}
	RTHOOK(14);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1090,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = F949_7092(RTCW(loc5));
	F949_7071(RTCW(Result), ti4_1);
	RTHOOK(15);
	F608_6140(RTCW(Result));
	RTHOOK(16);
	loc10 = F949_7085(RTCV(F21_177(Current)));
	for (;;) {
		tb2 = F557_6081(loc10);
		if (tb2) break;
		RTHOOK(17);
		tb3 = F762_6292(RTCW(loc5));
		if (tb3) break;
		RTHOOK(18);
		F949_7102(RTCW(loc5));
		for (;;) {
			RTHOOK(19);
			tb4 = F920_6990(RTCW(loc5));
			if (tb4) break;
			RTHOOK(20);
			tr1 = F557_6072(loc10);
			tr2 = F949_7076(RTCW(loc5));
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
			tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5450[Dtype(RTCW(tr1))-1088])(tr1, tr2);
			if (tb5) {
				RTHOOK(21);
				tr1 = F949_7076(RTCW(loc5));
				F949_7111(RTCW(Result), tr1);
				RTHOOK(22);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5503[Dtype(RTCW(loc5))-800])(loc5);
			} else {
				RTHOOK(23);
				F949_7104(RTCW(loc5));
			}
		}
		RTHOOK(24);
		F557_6087(loc10);
	}
	RTHOOK(25);
	tb5 = F762_6292(RTCW(loc5));
	if ((EIF_BOOLEAN) !tb5) {
		RTHOOK(26);
		loc11 = F949_7085(RTCW(loc5));
		for (;;) {
			tb5 = F557_6081(loc11);
			if (tb5) break;
			RTHOOK(27);
			tr1 = F557_6072(loc11);
			F949_7111(RTCW(Result), tr1);
			RTHOOK(28);
			F557_6087(loc11);
		}
	}
	RTHOOK(29);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_CLIENT_DB}.quick_installed_package */
EIF_REFERENCE F21_179 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,arg1);
	RTLR(9,loc4);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLR(14,tr2);
	RTLR(15,Result);
	RTLIU(16);
	
	RTEAA("quick_installed_package", 20, Current, 11, 1, 216);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1090,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc5 = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F949_7071(RTCW(loc5), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	F608_6140(RTCW(loc5));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = RTOUCR(612,F451_5412, (RTCW(tr1)));
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1101,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc3 = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F949_7071(RTCW(loc3), ((EIF_INTEGER_32) 10L));
	RTHOOK(5);
	loc2 = RTLNS(eif_new_type(105, 0x01).id, 105, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F106_1475(RTCW(loc2), loc3);
	RTHOOK(6);
	tr1 = F1102_9123(RTCW(loc1));
	tr1 = F1102_9125(RTCW(tr1));
	F106_1479(RTCW(loc2), tr1);
	RTHOOK(7);
	loc6 = F949_7085(RTCW(loc3));
	for (;;) {
		tb1 = F557_6081(loc6);
		if (tb1) break;
		RTHOOK(8);
		tb2 = '\0';
		tr1 = F557_6072(loc6);
		tr1 = F21_185(Current, tr1);
		tr1 = F21_187(Current, tr1);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			tb3 = F1078_8207(loc7, arg1);
			tb2 = tb3;
		}
		if (tb2) {
			RTHOOK(9);
			loc4 = RTLNS(eif_new_type(14, 0x01).id, 14, _OBJSIZ_4_0_0_0_0_0_0_0_);
			tr1 = F557_6072(loc6);
			F15_112(RTCW(loc4), tr1);
			RTHOOK(10);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_3_);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				RTHOOK(11);
				F949_7111(RTCW(loc5), loc8);
			} else {
				RTHOOK(12);
				tb2 = '\0';
				tr1 = F557_6072(loc6);
				tr1 = F21_185(Current, tr1);
				loc9 = tr1;
				if (EIF_TEST(loc9)) {
					tr1 = F21_186(Current, loc9);
					loc10 = tr1;
					tb2 = EIF_TEST(loc10);
				}
				if (tb2) {
					RTHOOK(13);
					F949_7111(RTCW(loc5), loc10);
				}
			}
		}
		RTHOOK(14);
		F557_6087(loc6);
	}
	RTHOOK(15);
	loc11 = F949_7085(RTCV(F21_177(Current)));
	for (;;) {
		tb2 = F557_6081(loc11);
		if (tb2) break;
		RTHOOK(16);
		tb3 = '\01';
		tb4 = F762_6292(RTCW(loc5));
		if (!tb4) {
			tb3 = (EIF_BOOLEAN)(Result != NULL);
		}
		if (tb3) break;
		RTHOOK(17);
		F949_7102(RTCW(loc5));
		for (;;) {
			RTHOOK(18);
			tb4 = '\01';
			tb5 = F920_6990(RTCW(loc5));
			if (!tb5) {
				tb4 = (EIF_BOOLEAN)(Result != NULL);
			}
			if (tb4) break;
			RTHOOK(19);
			tr1 = F557_6072(loc11);
			tr2 = F949_7076(RTCW(loc5));
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
			tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5450[Dtype(RTCW(tr1))-1088])(tr1, tr2);
			if (tb5) {
				RTHOOK(20);
				Result = F949_7076(RTCW(loc5));
				RTHOOK(21);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5503[Dtype(RTCW(loc5))-800])(loc5);
			} else {
				RTHOOK(22);
				F949_7104(RTCW(loc5));
			}
		}
		RTHOOK(23);
		F557_6087(loc11);
	}
	RTHOOK(24);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_CLIENT_DB}.file_content */
EIF_REFERENCE F21_185 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("file_content", 20, Current, 1, 1, 222);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(828, 0x01).id, 828, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F828_6356(RTCW(loc1), arg1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = F828_6390(RTCW(loc1));
	if (tb2) {
		tb2 = F828_6409(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F828_6425(RTCW(loc1));
		RTHOOK(4);
		Result = RTLNS(eif_new_type(1082, 0x01).id, 1082, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1081_8295(RTCW(Result), ((EIF_INTEGER_32) 1024L));
		for (;;) {
			RTHOOK(5);
			tb1 = F636_6157(RTCW(loc1));
			if (tb1) break;
			RTHOOK(6);
			F828_6504(RTCW(loc1), ((EIF_INTEGER_32) 1024L));
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7088[Dtype(RTCW(Result))-1082])(Result, tr1);
		}
		RTHOOK(8);
		F828_6442(RTCW(loc1));
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_CLIENT_DB}.repo_package_from_json_string */
EIF_REFERENCE F21_186 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("repo_package_from_json_string", 20, Current, 1, 1, 209);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(205, 0x01).id, 205, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(2);
	tr1 = F206_2604(RTCW(loc1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT_DB}.repo_package_identifier_from_json_string */
EIF_REFERENCE F21_187 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("repo_package_identifier_from_json_string", 20, Current, 1, 1, 210);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(205, 0x01).id, 205, _OBJSIZ_0_0_0_0_0_0_0_0_);
		RTHOOK(3);
		tr1 = F206_2606(RTCW(loc1), arg1);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit16 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
