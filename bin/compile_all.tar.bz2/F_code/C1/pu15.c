/*
 * Code for class PUNYCODE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pu15.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PUNYCODE}.encoded_string */
EIF_REFERENCE F20_158 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("encoded_string", 19, Current, 1, 1, 193);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1082, 0x01).id, 1082, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[Dtype(RTCW(arg1))-1081])(arg1);
	F1081_8295(RTCW(Result), ti4_1);
	RTHOOK(2);
	loc1 = F20_170(Current, arg1, Result);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {PUNYCODE}.adapt_bias */
EIF_NATURAL_32 F20_167 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_NATURAL_32 arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_REAL_64 loc2 = (EIF_REAL_64) 0;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_64 ti8_1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("adapt_bias", 19, Current, 2, 3, 202);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_REAL_64) (arg1);
	RTHOOK(2);
	if (arg3) {
		RTHOOK(3);
		tr8_1 = (EIF_REAL_64) (((EIF_NATURAL_32) 700U));
		loc2 /= tr8_1;
	} else {
		RTHOOK(4);
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 2L));
		loc2 /= tr8_1;
	}
	RTHOOK(5);
	tr8_1 = (EIF_REAL_64) (arg2);
	loc2 += (EIF_REAL_64) ((EIF_REAL_64) (loc2) /  (EIF_REAL_64) (tr8_1));
	RTHOOK(6);
	ti8_1 = (EIF_INTEGER_64) loc2;
	tr8_1 = (EIF_REAL_64) (ti8_1);
	loc2 = (EIF_REAL_64) tr8_1;
	RTHOOK(7);
	loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		RTHOOK(8);
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 455L));
		if ((EIF_BOOLEAN) eif_is_less_equal_real_64 (loc2, tr8_1)) break;
		RTHOOK(9);
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 35L));
		loc2 /= tr8_2;
		RTHOOK(10);
		ti8_1 = (EIF_INTEGER_64) loc2;
		tr8_2 = (EIF_REAL_64) (ti8_1);
		loc2 = (EIF_REAL_64) tr8_2;
		RTHOOK(11);
		loc1 += ((EIF_NATURAL_32) 36U);
	}
	RTHOOK(12);
	tr8_2 = (EIF_REAL_64) (((EIF_NATURAL_32) ((EIF_NATURAL_32) (((EIF_NATURAL_32) 36U) - ((EIF_NATURAL_32) 1U)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L))));
	tr8_3 = (EIF_REAL_64) (((EIF_NATURAL_32) 38U));
	ti8_1 = (EIF_INTEGER_64) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (tr8_2 * loc2)) /  (EIF_REAL_64) ((EIF_REAL_64) (loc2 + tr8_3)));
	Result = (EIF_NATURAL_32) ti8_1;
	Result = (EIF_NATURAL_32) (EIF_NATURAL_32) (loc1 + Result);
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {PUNYCODE}.encoded_digit */
EIF_CHARACTER_8 F20_168 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("encoded_digit", 19, Current, 1, 1, 203);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 25L))) {
		RTHOOK(2);
		loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) (arg1 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 22L));
	} else {
		RTHOOK(3);
		loc1 = (EIF_NATURAL_32) (EIF_CHARACTER_8) 'a';
		loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) (arg1 + loc1);
	}
	RTHOOK(4);
	tc1 = (EIF_CHARACTER_8) loc1;
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_CHARACTER_8) tc1;
}

/* {PUNYCODE}.encode_var_int */
EIF_NATURAL_32 F20_169 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_NATURAL_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_64 ti8_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg3);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("encode_var_int", 19, Current, 5, 3, 204);
	RTGC;
	RTHOOK(1);
	loc3 = (EIF_NATURAL_32) arg2;
	RTHOOK(2);
	loc2 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 36U);
	RTHOOK(3);
	loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		RTHOOK(4);
		if (loc5) break;
		RTHOOK(5);
		if ((EIF_BOOLEAN) (loc2 <= arg1)) {
			RTHOOK(6);
			loc4 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 1U);
		} else {
			RTHOOK(7);
			if ((EIF_BOOLEAN) (loc2 >= (EIF_NATURAL_32) (arg1 + ((EIF_NATURAL_32) 26U)))) {
				RTHOOK(8);
				loc4 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 26U);
			} else {
				RTHOOK(9);
				loc4 = (EIF_NATURAL_32) (EIF_NATURAL_32) (loc2 - arg1);
			}
		}
		RTHOOK(10);
		if ((EIF_BOOLEAN) (loc3 < loc4)) {
			RTHOOK(11);
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(12);
			tc1 = F20_168(Current, (EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_NATURAL_32) (loc3 - loc4) % (EIF_NATURAL_32) (((EIF_NATURAL_32) 36U) - loc4))));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7092[Dtype(RTCW(arg3))-1082])(arg3, tc1);
			RTHOOK(13);
			loc1 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
			RTHOOK(14);
			ti8_1 = (EIF_INTEGER_64) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_NATURAL_32) (loc3 - loc4)) /  (EIF_REAL_64) ((EIF_NATURAL_32) (((EIF_NATURAL_32) 36U) - loc4)));
			tu4_1 = (EIF_NATURAL_32) ti8_1;
			loc3 = (EIF_NATURAL_32) tu4_1;
			RTHOOK(15);
			loc2 += ((EIF_NATURAL_32) 36U);
		}
	}
	RTHOOK(16);
	tc1 = F20_168(Current, loc3);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7092[Dtype(RTCW(arg3))-1082])(arg3, tc1);
	RTHOOK(17);
	loc1 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(18);
	RTHOOK(19);
	RTLE;
	RTEE;
	return (EIF_NATURAL_32) loc1;
}

/* {PUNYCODE}.punycode_encode */
EIF_NATURAL_32 F20_170 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc6 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc7 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc8 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc9 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc10 = (EIF_NATURAL_32) 0;
	EIF_BOOLEAN loc11 = (EIF_BOOLEAN) 0;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("punycode_encode", 19, Current, 11, 2, 205);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[Dtype(RTCW(arg1))-1081])(arg1);
	loc1 = (EIF_NATURAL_32) ti4_1;
	RTHOOK(2);
	loc8 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	loc9 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_NATURAL_32) (loc8 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)) > loc1)) break;
		RTHOOK(5);
		ti4_1 = (EIF_INTEGER_32) loc8;
		loc10 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc10 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L))) {
			RTHOOK(7);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[Dtype(RTCW(arg2))-1082])(arg2, loc10);
			RTHOOK(8);
			loc9 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
		}
		RTHOOK(9);
		loc8 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	}
	RTHOOK(10);
	loc3 = (EIF_NATURAL_32) loc9;
	RTHOOK(11);
	loc2 = (EIF_NATURAL_32) loc3;
	RTHOOK(12);
	if ((EIF_BOOLEAN) (loc9 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
		RTHOOK(13);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7092[Dtype(RTCW(arg2))-1082])(arg2, (EIF_CHARACTER_8) '-');
		RTHOOK(14);
		loc9 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	}
	RTHOOK(15);
	loc7 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 128U);
	RTHOOK(16);
	loc5 = (EIF_NATURAL_32) ((EIF_NATURAL_32) 72U);
	RTHOOK(17);
	loc4 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		RTHOOK(18);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) (loc3 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)) > loc1) || loc11)) break;
		RTHOOK(19);
		loc6 = F20_173(Current);
		RTHOOK(20);
		loc8 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			RTHOOK(21);
			if ((EIF_BOOLEAN) ((EIF_NATURAL_32) (loc8 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)) > loc1)) break;
			RTHOOK(22);
			ti4_1 = (EIF_INTEGER_32) loc8;
			loc10 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
			RTHOOK(23);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc10 >= loc7) && (EIF_BOOLEAN) (loc10 < loc6))) {
				RTHOOK(24);
				loc6 = (EIF_NATURAL_32) loc10;
			}
			RTHOOK(25);
			loc8 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
		}
		RTHOOK(26);
		tr8_1 = (EIF_REAL_64) ((EIF_NATURAL_32) (loc6 - loc7));
		if ((EIF_BOOLEAN) eif_is_greater_real_64 (tr8_1, (EIF_REAL_64) ((EIF_REAL_64) ((EIF_NATURAL_32) (F20_173(Current) - loc4)) /  (EIF_REAL_64) ((EIF_NATURAL_32) (loc3 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)))))) {
			
			RTHOOK(28);
			loc11 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(29);
			loc4 += (EIF_NATURAL_32) ((EIF_NATURAL_32) (loc6 - loc7) * (EIF_NATURAL_32) (loc3 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)));
			RTHOOK(30);
			loc7 = (EIF_NATURAL_32) loc6;
			RTHOOK(31);
			loc8 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
			for (;;) {
				RTHOOK(32);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) (loc8 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)) > loc1) || loc11)) break;
				RTHOOK(33);
				ti4_1 = (EIF_INTEGER_32) loc8;
				loc10 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
				RTHOOK(34);
				if ((EIF_BOOLEAN) (loc10 < loc7)) {
					RTHOOK(35);
					loc4 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
					RTHOOK(36);
					if ((EIF_BOOLEAN)(loc4 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
						
						RTHOOK(38);
						loc11 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				} else {
					RTHOOK(39);
					if ((EIF_BOOLEAN)(loc10 == loc7)) {
						RTHOOK(40);
						loc9 += F20_169(Current, loc5, loc4, arg2);
						RTHOOK(41);
						loc5 = F20_167(Current, loc4, (EIF_NATURAL_32) (loc3 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)), (EIF_BOOLEAN)(loc3 == loc2));
						RTHOOK(42);
						loc4 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
						RTHOOK(43);
						loc3 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
					}
				}
				RTHOOK(44);
				if ((EIF_BOOLEAN) !loc11) {
					RTHOOK(45);
					loc8 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
				}
			}
		}
		RTHOOK(46);
		if ((EIF_BOOLEAN) !loc11) {
			RTHOOK(47);
			loc7 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
			RTHOOK(48);
			loc4 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
		}
	}
	RTHOOK(49);
	if (loc11) {
	}
	RTHOOK(50);
	RTHOOK(51);
	RTLE;
	RTEE;
	return (EIF_NATURAL_32) loc8;
}

/* {PUNYCODE}.size_max */
EIF_NATURAL_32 F20_173 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("size_max", 19, Current, 0, 0, 208);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_32) ((EIF_NATURAL_32) 4294967295U);
}

void EIF_Minit15 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
