/*
 * Code for class CONF_VIRTUAL_GROUP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co531.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_VIRTUAL_GROUP}.set_name_prefix */
void F1159_9389 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("set_name_prefix", 1158, Current, 1, 1, 14987);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1085_8463(RTCW(loc1), arg1);
		RTHOOK(3);
		F1087_8618(RTCW(loc1));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O7851[dtype-1158]) = (EIF_REFERENCE) loc1;
	} else {
		RTHOOK(5);
		*(EIF_REFERENCE *)(Current + O7851[dtype-1158]) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_VIRTUAL_GROUP}.add_renaming */
void F1159_9391 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("add_renaming", 1158, Current, 2, 2, 14989);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + O7850[dtype-1158]);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {860,0xFF01,1084,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F852_6722(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O7850[dtype-1158]) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	F852_6768(RTCW(loc1), arg2, arg1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

void EIF_Minit531 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
