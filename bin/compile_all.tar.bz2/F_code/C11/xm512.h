
#ifndef _C11_xm512_
#define _C11_xm512_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1092_8703(EIF_REFERENCE, EIF_REFERENCE);
extern void F1092_8704(EIF_REFERENCE);
extern EIF_REFERENCE F1092_8705(EIF_REFERENCE);
extern EIF_BOOLEAN F1092_8707(EIF_REFERENCE);
extern EIF_INTEGER_32 F1092_8709(EIF_REFERENCE);
extern EIF_INTEGER_32 F1092_8710(EIF_REFERENCE);
extern EIF_INTEGER_32 F1092_8711(EIF_REFERENCE);
extern EIF_CHARACTER_8 F1092_8712(EIF_REFERENCE);
extern void F1092_8713(EIF_REFERENCE, EIF_REFERENCE);
extern void F1092_8714(EIF_REFERENCE);
extern void F1092_8715(EIF_REFERENCE);
extern void EIF_Minit512(void);
extern char *(*R5795[])();
extern long O7064[];

#ifdef __cplusplus
}
#endif

#endif
