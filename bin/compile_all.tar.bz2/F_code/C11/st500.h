
#ifndef _C11_st500_
#define _C11_st500_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1080_8263(EIF_REFERENCE);
extern void F1080_8265(EIF_REFERENCE, EIF_NATURAL_32);
extern void F1080_8276(EIF_REFERENCE, EIF_REFERENCE);
extern void F1080_8278(EIF_REFERENCE, EIF_REFERENCE);
extern void F1080_8288(EIF_REFERENCE);
extern void EIF_Minit500(void);
extern char *(*R7030[])();
extern char *(*R7000[])();
extern char *(*R7001[])();
extern char *(*R6941[])();
extern char *(*R6942[])();
extern char *(*R6904[])();
extern char *(*R7022[])();
extern char *(*R7023[])();
extern char *(*R6997[])();
extern long O6994[];
extern long O6995[];

#ifdef __cplusplus
}
#endif

#endif
