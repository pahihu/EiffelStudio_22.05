
#ifndef _C11_js537_
#define _C11_js537_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1210_9515(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1210_9516(EIF_REFERENCE);
extern void F1210_9517(EIF_REFERENCE);
extern EIF_INTEGER_32 F1210_9520(EIF_REFERENCE);
extern EIF_REFERENCE F1210_9521(EIF_REFERENCE);
extern void EIF_Minit537(void);

#ifdef __cplusplus
}
#endif

#endif
