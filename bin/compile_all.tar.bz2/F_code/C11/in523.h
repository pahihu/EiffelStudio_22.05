
#ifndef _C11_in523_
#define _C11_in523_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1103_9164(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit523(void);
extern void F263_3269(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
