/*
 * Code for class INTEGER_64
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in543.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTEGER_64}.is_less */
EIF_BOOLEAN F1217_9666 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_less", 1216, Current, 0, 1, 15935);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)tr1 = arg1;
	Result = F1215_9604(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_64}.plus */
EIF_INTEGER_64 F1217_9667 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("plus", 1216, Current, 0, 1, 15936);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)tr1 = arg1;
	tr1 = F1215_9614(Current, tr1);
	Result = *(EIF_INTEGER_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_64}.product */
EIF_INTEGER_64 F1217_9669 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("product", 1216, Current, 0, 1, 15938);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)tr1 = arg1;
	tr1 = F1215_9616(Current, tr1);
	Result = *(EIF_INTEGER_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_64}.opposite */
EIF_INTEGER_64 F1217_9672 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("opposite", 1216, Current, 0, 0, 15941);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_INTEGER_64 *)F1215_9619(Current);
}

/* {INTEGER_64}.integer_quotient */
EIF_INTEGER_64 F1217_9673 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_quotient", 1216, Current, 0, 1, 15942);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)tr1 = arg1;
	tr1 = F1215_9620(Current, tr1);
	Result = *(EIF_INTEGER_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_64}.integer_remainder */
EIF_INTEGER_64 F1217_9674 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_remainder", 1216, Current, 0, 1, 15943);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)tr1 = arg1;
	tr1 = F1215_9621(Current, tr1);
	Result = *(EIF_INTEGER_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_64}.as_natural_32 */
EIF_NATURAL_32 F1217_9678 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_32", 1216, Current, 0, 0, 15947);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_32) F1215_9628(Current);
}

/* {INTEGER_64}.as_natural_64 */
EIF_NATURAL_64 F1217_9679 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_64", 1216, Current, 0, 0, 15948);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_64) F1215_9629(Current);
}

/* {INTEGER_64}.as_integer_32 */
EIF_INTEGER_32 F1217_9682 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_32", 1216, Current, 0, 0, 15951);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F1215_9632(Current);
}

/* {INTEGER_64}.to_double */
EIF_REAL_64 F1217_9685 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_double", 1216, Current, 0, 0, 15954);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_64) F1215_9644(Current);
}

/* {INTEGER_64}.to_character_8 */
EIF_CHARACTER_8 F1217_9686 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_8", 1216, Current, 0, 0, 15955);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) F1215_9652(Current);
}

/* {INTEGER_64}.to_character_32 */
EIF_CHARACTER_32 F1217_9687 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_32", 1216, Current, 0, 0, 15956);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_32) F1215_9653(Current);
}

/* {INTEGER_64}.bit_and */
EIF_INTEGER_64 F1217_9688 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_and", 1216, Current, 0, 1, 15957);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)tr1 = arg1;
	tr1 = F1215_9654(Current, tr1);
	Result = *(EIF_INTEGER_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit543 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
