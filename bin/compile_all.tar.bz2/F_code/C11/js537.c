/*
 * Code for class JSON_BOOLEAN
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js537.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_BOOLEAN}.make */
void F1210_9515 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 1209, Current, 0, 1, 15798);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_) = (EIF_BOOLEAN) arg1;
	RTHOOK(2);
	RTEE;
}

/* {JSON_BOOLEAN}.make_true */
void F1210_9516 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("make_true", 1209, Current, 0, 0, 15799);
	RTHOOK(1);
	F1210_9515(Current, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	RTEE;
}

/* {JSON_BOOLEAN}.make_false */
void F1210_9517 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("make_false", 1209, Current, 0, 0, 15791);
	RTHOOK(1);
	F1210_9515(Current, (EIF_BOOLEAN) 0);
	RTHOOK(2);
	RTEE;
}

/* {JSON_BOOLEAN}.hash_code */
EIF_INTEGER_32 F1210_9520 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("hash_code", 1209, Current, 0, 0, 15794);
	RTGC;
	RTHOOK(1);
	tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_);
	Result = (tb1 ? 1L : 0L);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_BOOLEAN}.representation */
EIF_REFERENCE F1210_9521 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("representation", 1209, Current, 0, 0, 15795);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_)) {
		RTHOOK(2);
		Result = RTMS_EX_H("true",4,1953658213);
	} else {
		RTHOOK(3);
		Result = RTMS_EX_H("false",5,1635280741);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit537 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
