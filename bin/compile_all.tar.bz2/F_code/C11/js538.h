
#ifndef _C11_js538_
#define _C11_js538_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1211_9525(EIF_REFERENCE);
extern EIF_REFERENCE F1211_9526(EIF_REFERENCE);
extern EIF_REFERENCE F1211_9529(EIF_REFERENCE);
extern void EIF_Minit538(void);
extern char *(*R6582[])();

#ifdef __cplusplus
}
#endif

#endif
