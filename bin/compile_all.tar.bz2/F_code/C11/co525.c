/*
 * Code for class CONF_GROUP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co525.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_GROUP}.make */
void F1153_9254 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTEAA("make", 1152, Current, 0, 3, 14893);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + O7763[dtype-1152]) = (EIF_REFERENCE) arg3;
	RTHOOK(2);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6963[Dtype(RTCW(arg1))-1081])(arg1);
	F1153_9295(Current, tr1);
	RTHOOK(3);
	F1153_9297(Current, arg2);
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current + O7748[dtype-1152]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.classes_set */
EIF_BOOLEAN F1153_9257 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("classes_set", 1152, Current, 0, 0, 14896);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O7765[Dtype(Current)-1152]) != NULL);
}

/* {CONF_GROUP}.is_precompile */
static EIF_BOOLEAN F1153_9260_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTOUDB(EIF_BOOLEAN, 378)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_precompile", 1152, Current, 0, 0, 14899);
	RTGC;
	RTOTP;
	RTOTE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
#undef Result
}

EIF_BOOLEAN F1153_9260 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,378,F1153_9260_body,(Current));
}

/* {CONF_GROUP}.classes */
EIF_REFERENCE F1153_9275 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O7765[Dtype(Current)-1152]);
}


/* {CONF_GROUP}.hash_code */
EIF_INTEGER_32 F1153_9276 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hash_code", 1152, Current, 0, 0, 14915);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7807[dtype-1152]) == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + O7759[dtype-1152]);
		ti4_1 = F1078_8174(RTCW(tr1));
		*(EIF_INTEGER_32 *)(Current + O7807[dtype-1152]) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O7807[dtype-1152]);
}

/* {CONF_GROUP}.class_by_name */
EIF_REFERENCE F1153_9285 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTEAA("class_by_name", 1152, Current, 2, 2, 14919);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,947,0xFF01,1096,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 947, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F944_7001(RTCW(Result));
	RTHOOK(2);
	tb1 = '\0';
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O7765[Dtype(Current)-1152]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F852_6727(loc1, arg1);
		loc2 = tr1;
		tb2 = EIF_TEST(loc2);
	}
	if (tb2) {
		tb2 = (RTNA((loc2)), ((EIF_BOOLEAN) 0));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F948_7063(RTCW(Result), loc2);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_GROUP}.name_by_class */
EIF_REFERENCE F1153_9286 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,loc4);
	RTLR(8,arg1);
	RTLIU(9);
	
	RTEAA("name_by_class", 1152, Current, 4, 2, 14920);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,947,0xFF01,1077,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 947, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F944_7001(RTCW(Result));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + O7765[dtype-1152]);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(3);
		loc1 = *(EIF_REFERENCE *)(Current + O7808[dtype-1152]);
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			RTHOOK(5);
			{
				static EIF_TYPE_INDEX typarr0[] = {851,0xFF01,1077,0xFF01,1096,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc1 = RTLNSMART(typres0.id);
			}
			ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_7_4_0_6_);
			F852_6721(RTCW(loc1), ti4_1);
			RTHOOK(6);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + O7808[dtype-1152]) = (EIF_REFERENCE) loc1;
			RTHOOK(7);
			loc3 = F852_6736(loc2);
			for (;;) {
				tb1 = F547_6063(loc3);
				if (tb1) break;
				RTHOOK(8);
				tr1 = F547_6061(loc3);
				tr2 = F547_6060(loc3);
				F852_6768(RTCW(loc1), tr1, tr2);
				RTHOOK(9);
				F547_6064(loc3);
			}
		}
		RTHOOK(10);
		tr1 = F852_6727(RTCW(loc1), arg1);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTHOOK(11);
			F804_6349(RTCW(Result), loc4);
		}
	} else {
		
	}
	RTHOOK(14);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_GROUP}.is_less */
EIF_BOOLEAN F1153_9292 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("is_less", 1152, Current, 0, 1, 14857);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7759[Dtype(Current)-1152]);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + O7759[Dtype(arg1)-1152]);
	Result = F1085_8490(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_GROUP}.set_name */
void F1153_9295 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_name", 1152, Current, 0, 1, 14860);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O7759[Dtype(Current)-1152]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_GROUP}.set_description */
void F1153_9296 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_description", 1152, Current, 1, 1, 14861);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1087_8537(RTCW(tr1), arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O7760[dtype-1152]) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(3);
		*(EIF_REFERENCE *)(Current + O7760[dtype-1152]) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.set_location */
void F1153_9297 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_location", 1152, Current, 0, 1, 14862);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O7761[Dtype(Current)-1152]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_GROUP}.set_readonly */
void F1153_9298 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_readonly", 1152, Current, 0, 1, 14863);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7796[dtype-1152]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O7810[dtype-1152]) = (EIF_BOOLEAN) arg1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.merge_options */
void F1153_9301 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("merge_options", 1152, Current, 1, 1, 14866);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O7797[dtype-1152]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6264[Dtype(loc1)-969])(loc1, arg1);
	} else {
		RTHOOK(3);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O7797[dtype-1152]) = (EIF_REFERENCE) arg1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.add_class_options */
void F1153_9303 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("add_class_options", 1152, Current, 2, 2, 14868);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + O7799[dtype-1152]);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {860,0xFF01,969,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F861_6845(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O7799[dtype-1152]) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	F852_6768(RTCW(loc1), arg1, arg2);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.add_condition */
void F1153_9304 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("add_condition", 1152, Current, 1, 1, 14869);
	RTGC;
	RTHOOK(1);
	F405_4888(Current, arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + O7763[Dtype(Current)-1152]);
	loc1 = tr1;
	if ((EIF_TRUE)) {
		RTHOOK(3);
		F1301_12131(RTCW(arg1), loc1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.set_conditions */
void F1153_9305 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("set_conditions", 1152, Current, 2, 1, 14870);
	RTGC;
	RTHOOK(1);
	F405_4889(Current, arg1);
	RTHOOK(2);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O7763[Dtype(Current)-1152]);
	loc1 = tr1;
	if ((EIF_BOOLEAN) ((EIF_TRUE) && (EIF_BOOLEAN)(arg1 != NULL))) {
		tb2 = F762_6292(RTCW(arg1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		loc2 = F949_7085(RTCW(arg1));
		for (;;) {
			tb1 = F557_6081(loc2);
			if (tb1) break;
			RTHOOK(4);
			tr1 = F557_6072(loc2);
			F1301_12131(RTCW(tr1), loc1);
			RTHOOK(5);
			F557_6087(loc2);
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.process */
void F1153_9310 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("process", 1152, Current, 0, 1, 14875);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (CONF_VISITOR.process_group) */
		(void) RTCW(arg1);
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {CONF_GROUP}.class_type */
EIF_REFERENCE F1153_9322 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("class_type", 1152, Current, 0, 0, 14887);
	RTGC;
	RTHOOK(1);
	RTCT0("False", EX_CHECK);
		RTCF0;
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit525 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
