/*
 * Code for class IRON_WEB_REPOSITORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir509.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_WEB_REPOSITORY}.make */
void F1089_8629 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,arg2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTEAA("make", 1088, Current, 2, 2, 12620);
	RTGC;
	RTHOOK(1);
	tr1 = F1_14(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	RTHOOK(3);
	tr1 = RTMS_EX_H("/",1,47);
	tb1 = F1081_8332(RTCW(loc1), tr1);
	if (tb1) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O7064[Dtype(loc1)-1080]);
		tr2 = F1078_8246(RTCW(loc1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
		F1335_12785(RTCW(tr1), tr2);
	}
	RTHOOK(5);
	loc2 = arg2;
	loc2 = RTRV(eif_new_type(1081, 1),loc2);
	if (EIF_TEST(loc2)) {
		RTHOOK(6);
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc2;
	} else {
		RTHOOK(7);
		tr1 = RTLNSMART(eif_new_type(1081, 1).id);
		F1081_8297(RTCW(tr1), arg2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(8);
	tr1 = RTLNSMART(eif_new_type(1334, 1).id);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = F1335_12778(RTCW(tr2));
	tr3 = RTMS_EX_H("/",1,47);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7054[Dtype(RTCW(tr2))-1081])(tr2, tr3);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7054[Dtype(RTCW(tr2))-1081])(tr2, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	F1335_12744(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	F607_6120(Current);
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {IRON_WEB_REPOSITORY}.make_from_version_uri */
void F1089_8630 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc5);
	RTLR(6,loc4);
	RTLR(7,Current);
	RTLIU(8);
	
	RTEAA("make_from_version_uri", 1088, Current, 5, 1, 12621);
	RTGC;
	RTHOOK(1);
	tr1 = F1335_12764(RTCW(arg1));
	loc1 = F1_14(tr1);
	RTHOOK(2);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5963[Dtype(RTCW(loc1))-943])(loc1);
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5477[Dtype(RTCW(loc1))-943])(loc1);
	RTHOOK(4);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5503[Dtype(RTCW(loc1))-800])(loc1);
	RTHOOK(5);
	loc3 = RTLNS(eif_new_type(1082, 0x01).id, 1082, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1078_8165(RTCW(loc3));
	RTHOOK(6);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5561[Dtype(RTCW(loc1))-800])(loc1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(7);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5345[Dtype(RTCW(loc1))-509])(loc1);
		loc5 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5315[Dtype(loc5)-479])(loc5);
			if (tb1) break;
			RTHOOK(8);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7092[Dtype(RTCW(loc3))-1082])(loc3, (EIF_CHARACTER_8) '/');
			RTHOOK(9);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5314[Dtype(loc5)-479])(loc5);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7088[Dtype(RTCW(loc3))-1082])(loc3, tr1);
			RTHOOK(10);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5316[Dtype(loc5)-479])(loc5);
		}
	}
	RTHOOK(11);
	loc4 = RTLNS(eif_new_type(1334, 0x01).id, 1334, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = F1335_12778(RTCW(arg1));
	F1335_12744(RTCW(loc4), tr1);
	RTHOOK(12);
	F1335_12785(RTCW(loc4), loc3);
	RTHOOK(13);
	tr1 = RTMS_EX_H("/",1,47);
	tb2 = F1081_8332(RTCW(loc2), tr1);
	if (tb2) {
		RTHOOK(14);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O7064[Dtype(loc2)-1080]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6982[Dtype(RTCW(loc2))-1081])(loc2, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
		loc2 = (EIF_REFERENCE) tr1;
	}
	RTHOOK(15);
	F1089_8629(Current, loc4, loc2);
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {IRON_WEB_REPOSITORY}.create_available_packages */
void F1089_8631 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_available_packages", 1088, Current, 0, 0, 12622);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_final_id(Y5443,Y5443_gen_type,Dftype(Current),606).id);
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {IRON_WEB_REPOSITORY}.location */
EIF_REFERENCE F1089_8632 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {IRON_WEB_REPOSITORY}.is_same_repository */
EIF_BOOLEAN F1089_8637 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("is_same_repository", 1088, Current, 1, 1, 12628);
	RTGC;
	RTHOOK(1);
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1088, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F607_6124(Current);
		tr2 = F607_6124(loc1);
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R7049[Dtype(RTCW(tr1))-1081])(tr1, tr2);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit509 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
