/*
 * Code for class IRON_WORKING_COPY_REPOSITORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir510.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_WORKING_COPY_REPOSITORY}.make */
void F1090_8641 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("make", 1089, Current, 1, 1, 12641);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1087_8537(RTCW(loc1), arg1);
	RTHOOK(2);
	F1090_8654(Current, loc1);
	RTHOOK(3);
	tr1 = RTLNS(eif_new_type(1101, 0x01).id, 1101, _OBJSIZ_2_1_0_0_0_0_0_0_);
	F1102_9104(RTCW(tr1), loc1);
	F1090_8642(Current, tr1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {IRON_WORKING_COPY_REPOSITORY}.make_from_path */
void F1090_8642 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("make_from_path", 1089, Current, 0, 1, 12642);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tr1 = F1090_8655(Current, arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	F607_6120(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {IRON_WORKING_COPY_REPOSITORY}.make_from_uri */
void F1090_8643 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTEAA("make_from_uri", 1089, Current, 2, 1, 12643);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	loc1 = RTLNS(eif_new_type(1336, 0x01).id, 1336, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1337_12835(RTCW(loc1), arg1);
	RTHOOK(3);
	tr1 = RTLNS(eif_new_type(1336, 0x01).id, 1336, _OBJSIZ_7_3_0_1_0_0_0_0_);
	tr2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_6_);
	F1337_12836(RTCW(tr1), tr2);
	loc1 = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_6_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	tb1 = F1081_8330(RTCW(tr1), (EIF_CHARACTER_8) '$');
	if (tb1) {
		RTHOOK(7);
		loc2 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F1102_9143(RTCW(tr1));
		F1085_8463(RTCW(loc2), tr1);
		RTHOOK(8);
		F1090_8654(Current, loc2);
		RTHOOK(9);
		tr1 = RTLNSMART(eif_new_type(1101, 1).id);
		F1102_9104(RTCW(tr1), loc2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(10);
		loc1 = RTLNS(eif_new_type(1336, 0x01).id, 1336, _OBJSIZ_7_3_0_1_0_0_0_0_);
		F1337_12835(RTCW(loc1), arg1);
		RTHOOK(11);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_6_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(12);
	F607_6120(Current);
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {IRON_WORKING_COPY_REPOSITORY}.create_available_packages */
void F1090_8644 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_available_packages", 1089, Current, 0, 0, 12644);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_final_id(Y5443,Y5443_gen_type,Dftype(Current),606).id);
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {IRON_WORKING_COPY_REPOSITORY}.location */
EIF_REFERENCE F1090_8646 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {IRON_WORKING_COPY_REPOSITORY}.is_same_repository */
EIF_BOOLEAN F1090_8649 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("is_same_repository", 1089, Current, 1, 1, 12633);
	RTGC;
	RTHOOK(1);
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1089, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F1102_9125(RTCW(tr1));
		tr1 = F1102_9143(RTCW(tr1));
		tr2 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
		tr2 = F1102_9125(RTCW(tr2));
		tr2 = F1102_9143(RTCW(tr2));
		Result = F1085_8488(RTCW(tr1), tr2);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_WORKING_COPY_REPOSITORY}.expand_variables */
void F1090_8654 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	struct eif_ex_12 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(18, 0x00).id);
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTEAA("expand_variables", 1089, Current, 1, 1, 12638);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1025,0xFF01,434,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	tr2 = RTOUCR(216,F450_5402, (Current));
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
	RTAR(tr1,tr2);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1073,0xFF01,0xFFF9,1,1025,0xFF01,1077,1086,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A374_40_2, (EIF_POINTER) _A374_40_2, (EIF_POINTER)(F435_5068),tr1, 1, 1);
	}
	F19_156(RTCW(loc1), arg1, tr4);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {IRON_WORKING_COPY_REPOSITORY}.uri_location_from_path */
EIF_REFERENCE F1090_8655 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("uri_location_from_path", 1089, Current, 1, 1, 12639);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1336, 0x01).id, 1336, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1337_12836(RTCW(loc1), arg1);
	RTHOOK(2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

void EIF_Minit510 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
