/*
 * Code for class CONF_PRECOMPILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co534.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_PRECOMPILE}.make */
void F1162_9438 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTEAA("make", 1161, Current, 0, 3, 15037);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg3;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_22_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_22_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6963[Dtype(RTCW(arg1))-1081])(arg1);
	F1153_9295(Current, tr1);
	RTHOOK(5);
	F1153_9297(Current, arg2);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_PRECOMPILE}.is_precompile */
static EIF_BOOLEAN F1162_9439_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 217)

	
	RTEAA("is_precompile", 1161, Current, 0, 0, 15038);
	RTOTP;
	RTHOOK(1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTOTE;
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F1162_9439 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,217,F1162_9439_body,(Current));
}

/* {CONF_PRECOMPILE}.set_eifgens_location */
void F1162_9441 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_eifgens_location", 1161, Current, 0, 1, 15040);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_PRECOMPILE}.process */
void F1162_9442 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("process", 1161, Current, 0, 1, 15041);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (CONF_VISITOR.process_group) */
		(void) RTCW(arg1);
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	F1295_11475(RTCW(arg1), Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit534 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
