/*
 * Code for class CONF_ORDERED_CAPABILITY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co516.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_ORDERED_CAPABILITY}.make */
void F1096_8805 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make", 1095, Current, 0, 1, 12800);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F1096_8820(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_ORDERED_CAPABILITY}.is_valid_item */
EIF_BOOLEAN F1096_8806 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("is_valid_item", 1095, Current, 0, 1, 12801);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1095_8787(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_ORDERED_CAPABILITY}.is_capable */
EIF_BOOLEAN F1096_8808 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_capable", 1095, Current, 0, 1, 12803);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	ti4_1 = (EIF_INTEGER_32) arg1;
	if ((EIF_BOOLEAN) (((EIF_INTEGER_32) 0L) < ti4_1)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tu1_1 = *(EIF_NATURAL_8 *)(RTCW(tr1)+ _CHROFF_1_2_);
		Result = (EIF_BOOLEAN) (arg1 <= tu1_1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_ORDERED_CAPABILITY}.is_root_set */
EIF_BOOLEAN F1096_8809 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTEAA("is_root_set", 1095, Current, 0, 0, 12804);
	RTHOOK(1);
	tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu1_1 != (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L));
	RTHOOK(3);
	RTEE;
	return Result;
}

/* {CONF_ORDERED_CAPABILITY}.default_root_index */
EIF_NATURAL_8 F1096_8813 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("default_root_index", 1095, Current, 0, 0, 12808);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_NATURAL_8 *)(RTCW(tr1)+ _CHROFF_1_2_);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_ORDERED_CAPABILITY}.root_index */
EIF_NATURAL_8 F1096_8815 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("root_index", 1095, Current, 0, 0, 12810);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F1096_8809(Current)) {
		tb1 = F1096_8808(Current, *(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_));
	}
	if (tb1) {
		RTHOOK(2);
		tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_);
	} else {
		RTHOOK(3);
		tu1_1 = F1096_8813(Current);
	}
	Result = (EIF_NATURAL_8) tu1_1;
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_ORDERED_CAPABILITY}.put_root */
void F1096_8818 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("put_root", 1095, Current, 0, 1, 12813);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tu1_1 = F1095_8796(RTCW(tr1), arg1);
	F1096_8819(Current, tu1_1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_ORDERED_CAPABILITY}.put_root_index */
void F1096_8819 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("put_root_index", 1095, Current, 0, 1, 12814);
	RTHOOK(1);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_) = (EIF_NATURAL_8) arg1;
	RTHOOK(5);
	RTEE;
}

/* {CONF_ORDERED_CAPABILITY}.unset_root */
void F1096_8820 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("unset_root", 1095, Current, 0, 0, 12815);
	RTHOOK(1);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	RTEE;
}

/* {CONF_ORDERED_CAPABILITY}.set_safely_root */
void F1096_8821 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_safely_root", 1095, Current, 0, 1, 12816);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN) !F1096_8809(Current)) {
		tb3 = F1096_8809(RTCW(arg1));
		tb2 = tb3;
	}
	if (tb2) {
		tu1_1 = F1096_8815(RTCW(arg1));
		tb1 = (EIF_BOOLEAN)(F1096_8815(Current) != tu1_1);
	}
	if (tb1) {
		RTHOOK(2);
		tu1_1 = F1096_8815(RTCW(arg1));
		F1096_8819(Current, tu1_1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_ORDERED_CAPABILITY}.set_safely */
void F1096_8822 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("set_safely", 1095, Current, 0, 1, 12817);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	F1095_8797(RTCW(tr1), tr2);
	RTHOOK(2);
	F1096_8821(Current, arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit516 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
