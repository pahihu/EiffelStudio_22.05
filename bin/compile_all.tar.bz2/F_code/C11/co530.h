
#ifndef _C11_co530_
#define _C11_co530_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1158_9380(EIF_REFERENCE, EIF_REFERENCE);
extern void F1158_9382(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit530(void);
extern void F949_7071(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F762_6292(EIF_REFERENCE);
extern char *(*R5485[])();

#ifdef __cplusplus
}
#endif

#endif
