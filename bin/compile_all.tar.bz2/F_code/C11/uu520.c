/*
 * Code for class UUID
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uu520.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UUID}.make_from_string */
void F1100_8939 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("make_from_string", 1099, Current, 4, 1, 12939);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,886,1237,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 886, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F887_6892(RTCW(loc1), ((EIF_NATURAL_8) 0U), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 16L));
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[Dtype(RTCW(arg1))-1081])(arg1);
	RTHOOK(4);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(5);
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		RTHOOK(6);
		tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6905[Dtype(RTCW(arg1))-1081])(arg1, loc2);
		if ((EIF_BOOLEAN)(tw1 == (EIF_CHARACTER_32) 45U)) {
			RTHOOK(7);
			loc2++;
		} else {
			
			RTHOOK(9);
			tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6905[Dtype(RTCW(arg1))-1081])(arg1, loc2);
			tu1_1 = F1100_8956(Current, tw1);
			tu1_1 = eif_bit_shift_left(tu1_1,((EIF_INTEGER_32) 4L));
			tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6905[Dtype(RTCW(arg1))-1081])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
			tu1_2 = F1100_8956(Current, tw1);
			tu1_1 = eif_bit_or(tu1_1,tu1_2);
			F887_6916(RTCW(loc1), tu1_1, loc4);
			RTHOOK(10);
			loc4++;
			RTHOOK(11);
			loc2 += ((EIF_INTEGER_32) 2L);
		}
	}
	RTHOOK(12);
	F1100_8940(Current, loc1);
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {UUID}.make_from_array */
void F1100_8940 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_16 loc1 = (EIF_NATURAL_16) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_64 loc3 = (EIF_NATURAL_64) 0;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_16 tu2_1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make_from_array", 1099, Current, 3, 1, 12940);
	RTGC;
	RTHOOK(1);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 1L));
	loc2 = (EIF_NATURAL_32) tu1_1;
	RTHOOK(2);
	tu4_1 = eif_bit_shift_left(loc2,((EIF_INTEGER_32) 8L));
	loc2 = (EIF_NATURAL_32) tu4_1;
	RTHOOK(3);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 2L));
	tu4_1 = (EIF_NATURAL_32) tu1_1;
	loc2 += tu4_1;
	RTHOOK(4);
	tu4_1 = eif_bit_shift_left(loc2,((EIF_INTEGER_32) 8L));
	loc2 = (EIF_NATURAL_32) tu4_1;
	RTHOOK(5);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 3L));
	tu4_1 = (EIF_NATURAL_32) tu1_1;
	loc2 += tu4_1;
	RTHOOK(6);
	tu4_1 = eif_bit_shift_left(loc2,((EIF_INTEGER_32) 8L));
	loc2 = (EIF_NATURAL_32) tu4_1;
	RTHOOK(7);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 4L));
	tu4_1 = (EIF_NATURAL_32) tu1_1;
	loc2 += tu4_1;
	RTHOOK(8);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_3_0_) = (EIF_NATURAL_32) loc2;
	RTHOOK(9);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 5L));
	loc1 = (EIF_NATURAL_16) tu1_1;
	RTHOOK(10);
	tu2_1 = eif_bit_shift_left(loc1,((EIF_INTEGER_32) 8L));
	loc1 = (EIF_NATURAL_16) tu2_1;
	RTHOOK(11);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 6L));
	tu2_1 = (EIF_NATURAL_16) tu1_1;
	loc1 += tu2_1;
	RTHOOK(12);
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_0_) = (EIF_NATURAL_16) loc1;
	RTHOOK(13);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 7L));
	loc1 = (EIF_NATURAL_16) tu1_1;
	RTHOOK(14);
	tu2_1 = eif_bit_shift_left(loc1,((EIF_INTEGER_32) 8L));
	loc1 = (EIF_NATURAL_16) tu2_1;
	RTHOOK(15);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 8L));
	tu2_1 = (EIF_NATURAL_16) tu1_1;
	loc1 += tu2_1;
	RTHOOK(16);
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_1_) = (EIF_NATURAL_16) loc1;
	RTHOOK(17);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 9L));
	loc1 = (EIF_NATURAL_16) tu1_1;
	RTHOOK(18);
	tu2_1 = eif_bit_shift_left(loc1,((EIF_INTEGER_32) 8L));
	loc1 = (EIF_NATURAL_16) tu2_1;
	RTHOOK(19);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 10L));
	tu2_1 = (EIF_NATURAL_16) tu1_1;
	loc1 += tu2_1;
	RTHOOK(20);
	*(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_2_) = (EIF_NATURAL_16) loc1;
	RTHOOK(21);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 11L));
	loc3 = (EIF_NATURAL_64) tu1_1;
	RTHOOK(22);
	tu8_1 = eif_bit_shift_left(loc3,((EIF_INTEGER_32) 8L));
	loc3 = (EIF_NATURAL_64) tu8_1;
	RTHOOK(23);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 12L));
	tu8_1 = (EIF_NATURAL_64) tu1_1;
	loc3 += tu8_1;
	RTHOOK(24);
	tu8_1 = eif_bit_shift_left(loc3,((EIF_INTEGER_32) 8L));
	loc3 = (EIF_NATURAL_64) tu8_1;
	RTHOOK(25);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 13L));
	tu8_1 = (EIF_NATURAL_64) tu1_1;
	loc3 += tu8_1;
	RTHOOK(26);
	tu8_1 = eif_bit_shift_left(loc3,((EIF_INTEGER_32) 8L));
	loc3 = (EIF_NATURAL_64) tu8_1;
	RTHOOK(27);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 14L));
	tu8_1 = (EIF_NATURAL_64) tu1_1;
	loc3 += tu8_1;
	RTHOOK(28);
	tu8_1 = eif_bit_shift_left(loc3,((EIF_INTEGER_32) 8L));
	loc3 = (EIF_NATURAL_64) tu8_1;
	RTHOOK(29);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 15L));
	tu8_1 = (EIF_NATURAL_64) tu1_1;
	loc3 += tu8_1;
	RTHOOK(30);
	tu8_1 = eif_bit_shift_left(loc3,((EIF_INTEGER_32) 8L));
	loc3 = (EIF_NATURAL_64) tu8_1;
	RTHOOK(31);
	tu1_1 = F887_6897(RTCW(arg1), ((EIF_INTEGER_32) 16L));
	tu8_1 = (EIF_NATURAL_64) tu1_1;
	loc3 += tu8_1;
	RTHOOK(32);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_0_0_3_1_0_0_0_) = (EIF_NATURAL_64) loc3;
	RTHOOK(33);
	RTLE;
	RTEE;
}

/* {UUID}.hash_code */
EIF_INTEGER_32 F1100_8946 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("hash_code", 1099, Current, 0, 0, 12946);
	RTGC;
	RTHOOK(1);
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_0_0_3_1_0_0_0_);
	Result = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tu8_1)));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {UUID}.is_valid_uuid */
EIF_BOOLEAN F1100_8948 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("is_valid_uuid", 1099, Current, 1, 1, 12948);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[Dtype(RTCW(arg1))-1081])(arg1);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 36L))) {
		RTHOOK(2);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(4);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 36L)))) break;
			RTHOOK(5);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 9L)) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 14L))) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 19L))) || (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 24L)))) {
				RTHOOK(6);
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6905[Dtype(RTCW(arg1))-1081])(arg1, loc1);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tw1 == (EIF_CHARACTER_32) 45U);
			} else {
				RTHOOK(7);
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6905[Dtype(RTCW(arg1))-1081])(arg1, loc1);
				tr1 = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				Result = F1030_8000(RTCW(tr1));
			}
			RTHOOK(8);
			loc1++;
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {UUID}.is_less */
EIF_BOOLEAN F1100_8949 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_16 tu2_1;
	EIF_NATURAL_16 tu2_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("is_less", 1099, Current, 0, 1, 12949);
	RTGC;
	RTHOOK(1);
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_3_0_);
	tu4_2 = *(EIF_NATURAL_32 *)(RTCW(arg1)+ _LNGOFF_0_0_3_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu4_1 < tu4_2);
	RTHOOK(2);
	tu4_1 = *(EIF_NATURAL_32 *)(RTCW(arg1)+ _LNGOFF_0_0_3_0_);
	if ((EIF_BOOLEAN)(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_3_0_) == tu4_1)) {
		RTHOOK(3);
		tu2_1 = *(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_0_);
		tu2_2 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_0_0_0_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu2_1 < tu2_2);
		RTHOOK(4);
		tu2_1 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_0_0_0_);
		if ((EIF_BOOLEAN)(*(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_0_) == tu2_1)) {
			RTHOOK(5);
			tu2_1 = *(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_1_);
			tu2_2 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_0_0_1_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu2_1 < tu2_2);
			RTHOOK(6);
			tu2_1 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_0_0_1_);
			if ((EIF_BOOLEAN)(*(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_1_) == tu2_1)) {
				RTHOOK(7);
				tu2_1 = *(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_2_);
				tu2_2 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_0_0_2_);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu2_1 < tu2_2);
				RTHOOK(8);
				tu2_1 = *(EIF_NATURAL_16 *)(RTCW(arg1)+ _I16OFF_0_0_2_);
				if ((EIF_BOOLEAN)(*(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_2_) == tu2_1)) {
					RTHOOK(9);
					tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_0_0_3_1_0_0_0_);
					tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_0_0_3_1_0_0_0_);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 < tu8_2);
				}
			}
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {UUID}.string */
EIF_REFERENCE F1100_8950 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("string", 1099, Current, 0, 0, 12950);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1085_8461(RTCW(Result), ((EIF_INTEGER_32) 36L));
	RTHOOK(2);
	F1100_8953(Current, (EIF_CHARACTER_32) 45U, Result);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {UUID}.out */
EIF_REFERENCE F1100_8951 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("out", 1099, Current, 0, 0, 12951);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1082, 0x01).id, 1082, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1081_8295(RTCW(Result), ((EIF_INTEGER_32) 36L));
	RTHOOK(2);
	F1100_8952(Current, (EIF_CHARACTER_8) '-', Result);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {UUID}.append_to_string */
void F1100_8952 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 loc6 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_16 tu2_1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("append_to_string", 1099, Current, 6, 2, 12952);
	RTGC;
	RTHOOK(1);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	F1083_8441(RTCW(arg2), (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 36L)));
	RTHOOK(3);
	F1083_8457(RTCW(arg2), (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 36L)));
	RTHOOK(4);
	ti4_1 = (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 9L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5494[Dtype(RTCW(arg2))-851])(arg2, (EIF_REFERENCE) &arg1, (EIF_REFERENCE) &ti4_1);
	RTHOOK(5);
	ti4_1 = (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 14L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5494[Dtype(RTCW(arg2))-851])(arg2, (EIF_REFERENCE) &arg1, (EIF_REFERENCE) &ti4_1);
	RTHOOK(6);
	ti4_1 = (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 19L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5494[Dtype(RTCW(arg2))-851])(arg2, (EIF_REFERENCE) &arg1, (EIF_REFERENCE) &ti4_1);
	RTHOOK(7);
	ti4_1 = (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 24L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5494[Dtype(RTCW(arg2))-851])(arg2, (EIF_REFERENCE) &arg1, (EIF_REFERENCE) &ti4_1);
	RTHOOK(8);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(9);
		if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 5L))) break;
		RTHOOK(10);
		switch (loc4) {
			case 1L:
				RTHOOK(11);
				tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_3_0_);
				loc6 = (EIF_NATURAL_64) tu4_1;
				RTHOOK(12);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				RTHOOK(13);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
				break;
			case 2L:
				RTHOOK(14);
				tu2_1 = *(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_0_);
				loc6 = (EIF_NATURAL_64) tu2_1;
				RTHOOK(15);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
				RTHOOK(16);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
				break;
			case 3L:
				RTHOOK(17);
				tu2_1 = *(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_1_);
				loc6 = (EIF_NATURAL_64) tu2_1;
				RTHOOK(18);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
				RTHOOK(19);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 18L);
				break;
			case 4L:
				RTHOOK(20);
				tu2_1 = *(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_2_);
				loc6 = (EIF_NATURAL_64) tu2_1;
				RTHOOK(21);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
				RTHOOK(22);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
				break;
			default:
				RTHOOK(23);
				loc6 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_0_0_3_1_0_0_0_);
				RTHOOK(24);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 25L);
				RTHOOK(25);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 36L);
				break;
		}
		RTHOOK(26);
		loc3 = (EIF_INTEGER_32) loc2;
		for (;;) {
			RTHOOK(27);
			if ((EIF_BOOLEAN) (loc3 < loc1)) break;
			RTHOOK(28);
			tu8_1 = eif_bit_and(loc6,((EIF_NATURAL_64) RTU64C(15)));
			tr1 = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
			*(EIF_NATURAL_64 *)tr1 = tu8_1;
			tc1 = F1227_10043(RTCW(tr1));
			ti4_1 = (EIF_INTEGER_32) (loc5 + loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5494[Dtype(RTCW(arg2))-851])(arg2, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &ti4_1);
			RTHOOK(29);
			tu8_1 = eif_bit_shift_right(loc6,((EIF_INTEGER_32) 4L));
			loc6 = (EIF_NATURAL_64) tu8_1;
			RTHOOK(30);
			loc3--;
		}
		RTHOOK(31);
		loc4++;
	}
	RTHOOK(32);
	RTLE;
	RTEE;
}

/* {UUID}.append_to_string_32 */
void F1100_8953 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 loc6 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_NATURAL_16 tu2_1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("append_to_string_32", 1099, Current, 6, 2, 12953);
	RTGC;
	RTHOOK(1);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	F1087_8609(RTCW(arg2), (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 36L)));
	RTHOOK(3);
	F1087_8625(RTCW(arg2), (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 36L)));
	RTHOOK(4);
	F1087_8563(RTCW(arg2), arg1, (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 9L)));
	RTHOOK(5);
	F1087_8563(RTCW(arg2), arg1, (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 14L)));
	RTHOOK(6);
	F1087_8563(RTCW(arg2), arg1, (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 19L)));
	RTHOOK(7);
	F1087_8563(RTCW(arg2), arg1, (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 24L)));
	RTHOOK(8);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(9);
		if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 5L))) break;
		RTHOOK(10);
		switch (loc4) {
			case 1L:
				RTHOOK(11);
				tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_3_0_);
				loc6 = (EIF_NATURAL_64) tu4_1;
				RTHOOK(12);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				RTHOOK(13);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
				break;
			case 2L:
				RTHOOK(14);
				tu2_1 = *(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_0_);
				loc6 = (EIF_NATURAL_64) tu2_1;
				RTHOOK(15);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
				RTHOOK(16);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
				break;
			case 3L:
				RTHOOK(17);
				tu2_1 = *(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_1_);
				loc6 = (EIF_NATURAL_64) tu2_1;
				RTHOOK(18);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
				RTHOOK(19);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 18L);
				break;
			case 4L:
				RTHOOK(20);
				tu2_1 = *(EIF_NATURAL_16 *)(Current+ _I16OFF_0_0_2_);
				loc6 = (EIF_NATURAL_64) tu2_1;
				RTHOOK(21);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
				RTHOOK(22);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
				break;
			default:
				RTHOOK(23);
				loc6 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_0_0_3_1_0_0_0_);
				RTHOOK(24);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 25L);
				RTHOOK(25);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 36L);
				break;
		}
		RTHOOK(26);
		loc3 = (EIF_INTEGER_32) loc2;
		for (;;) {
			RTHOOK(27);
			if ((EIF_BOOLEAN) (loc3 < loc1)) break;
			RTHOOK(28);
			tu8_1 = eif_bit_and(loc6,((EIF_NATURAL_64) RTU64C(15)));
			tr1 = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_0_1_0_);
			*(EIF_NATURAL_64 *)tr1 = tu8_1;
			tc1 = F1227_10043(RTCW(tr1));
			tw1 = (EIF_CHARACTER_32) tc1;
			F1087_8563(RTCW(arg2), tw1, (EIF_INTEGER_32) (loc5 + loc3));
			RTHOOK(29);
			tu8_1 = eif_bit_shift_right(loc6,((EIF_INTEGER_32) 4L));
			loc6 = (EIF_NATURAL_64) tu8_1;
			RTHOOK(30);
			loc3--;
		}
		RTHOOK(31);
		loc4++;
	}
	RTHOOK(32);
	RTLE;
	RTEE;
}

/* {UUID}.hex_to_natural_8 */
EIF_NATURAL_8 F1100_8956 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("hex_to_natural_8", 1099, Current, 1, 1, 12956);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '0';
	if ((EIF_BOOLEAN) (tw1 <= arg1)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '9';
		tb1 = (EIF_BOOLEAN) (arg1 <= tw1);
	}
	if (tb1) {
		RTHOOK(2);
		loc1 = (EIF_INTEGER_32) (arg1);
		ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '0');
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
	} else {
		RTHOOK(3);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'a';
		if ((EIF_BOOLEAN) (arg1 >= tw1)) {
			RTHOOK(4);
			loc1 = (EIF_INTEGER_32) (arg1);
			ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) 'a');
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 10L)));
		} else {
			RTHOOK(5);
			loc1 = (EIF_INTEGER_32) (arg1);
			ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) 'A');
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 10L)));
		}
	}
	RTHOOK(6);
	tu1_1 = (EIF_NATURAL_8) loc1;
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_NATURAL_8) tu1_1;
}

void EIF_Minit520 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
