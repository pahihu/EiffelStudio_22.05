
#ifndef _C11_ir509_
#define _C11_ir509_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1089_8629(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1089_8630(EIF_REFERENCE, EIF_REFERENCE);
extern void F1089_8631(EIF_REFERENCE);
extern EIF_REFERENCE F1089_8632(EIF_REFERENCE);
extern EIF_BOOLEAN F1089_8637(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit509(void);
extern void F607_6120(EIF_REFERENCE);
extern EIF_REFERENCE F1335_12764(EIF_REFERENCE);
extern EIF_REFERENCE F607_6124(EIF_REFERENCE);
extern void F1335_12785(EIF_REFERENCE, EIF_REFERENCE);
extern void F949_7071(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F1081_8332(EIF_REFERENCE, EIF_REFERENCE);
extern void F1078_8165(EIF_REFERENCE);
extern void F1335_12744(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1335_12778(EIF_REFERENCE);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern void F1081_8297(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1078_8246(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R5561[])();
extern char *(*R6982[])();
extern char *(*R5963[])();
extern char *(*R7088[])();
extern char *(*R7049[])();
extern char *(*R5345[])();
extern char *(*R7092[])();
extern char *(*R5503[])();
extern char *(*R7054[])();
extern char *(*R5314[])();
extern char *(*R5315[])();
extern char *(*R5316[])();
extern char *(*R5477[])();
extern long O7064[];
extern EIF_TYPE_INDEX Y5443[];
extern EIF_TYPE_INDEX *Y5443_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
