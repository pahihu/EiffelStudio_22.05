/*
 * Code for class XML_FILE_INPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm513.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_FILE_INPUT_STREAM}.make */
void F1093_8720 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("make", 1092, Current, 0, 1, 12730);
	RTGC;
	RTHOOK(1);
	tr1 = F828_6365(RTCW(arg1));
	tr1 = F1102_9143(RTCW(tr1));
	F1093_8724(Current, tr1);
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(1082, 1).id);
	F1078_8165(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4096L);
	RTHOOK(4);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5561[Dtype(RTCW(arg1))-800])(arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_0_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(5);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {XML_FILE_INPUT_STREAM}.name */
EIF_REFERENCE F1093_8723 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {XML_FILE_INPUT_STREAM}.set_name */
void F1093_8724 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_name", 1092, Current, 0, 1, 12734);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {XML_FILE_INPUT_STREAM}.end_of_input */
EIF_BOOLEAN F1093_8727 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("end_of_input", 1092, Current, 0, 0, 12737);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) && (EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_6_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_3_)) && (EIF_BOOLEAN) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_3_) - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_2_)) + ((EIF_INTEGER_32) 1L)) < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_1_))));
}

/* {XML_FILE_INPUT_STREAM}.index */
EIF_INTEGER_32 F1093_8729 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_6_);
}


/* {XML_FILE_INPUT_STREAM}.line */
EIF_INTEGER_32 F1093_8730 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_5_);
}


/* {XML_FILE_INPUT_STREAM}.column */
EIF_INTEGER_32 F1093_8731 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_4_);
}


/* {XML_FILE_INPUT_STREAM}.last_character */
EIF_CHARACTER_8 F1093_8732 (EIF_REFERENCE Current)
{
	return *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_);
}


/* {XML_FILE_INPUT_STREAM}.compute_smart_chunk_size */
void F1093_8735 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("compute_smart_chunk_size", 1092, Current, 1, 2, 12715);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 100L));
	} else {
		RTHOOK(3);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 / ((EIF_INTEGER_32) 100L));
	}
	RTHOOK(4);
	if ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_1_))) {
		RTHOOK(5);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_1_);
		ti4_1 = eif_max_int32 (ti4_1,(EIF_INTEGER_32) (loc1 - (EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 4096L))));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_1_) = (EIF_INTEGER_32) ti4_1;
		RTHOOK(6);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg2 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_1_) > arg2))) {
			RTHOOK(7);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_1_) = (EIF_INTEGER_32) arg2;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {XML_FILE_INPUT_STREAM}.start */
void F1093_8736 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("start", 1092, Current, 0, 0, 12716);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb2 = F828_6415(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F828_6425(RTCW(tr1));
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F828_6443(RTCW(tr1));
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(5);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(6);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(7);
	F1093_8740(Current);
	RTHOOK(8);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {XML_FILE_INPUT_STREAM}.close */
void F1093_8737 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("close", 1092, Current, 0, 0, 12717);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(3);
	tr1 = RTLNSMART(eif_new_type(1082, 1).id);
	F1078_8165(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_)) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F828_6442(RTCW(tr1));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {XML_FILE_INPUT_STREAM}.read_character */
void F1093_8738 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("read_character", 1092, Current, 2, 0, 12718);
	RTGC;
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_6_))++;
	RTHOOK(2);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_)) {
		RTHOOK(3);
		F1093_8736(Current);
	}
	RTHOOK(4);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_6_) <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_3_))) {
		RTHOOK(5);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_6_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_2_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + loc2) - ti4_1);
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current);
		tb1 = F1078_8177(RTCW(tr1), loc2);
		if (tb1) {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(Current);
			loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5795[Dtype(RTCW(tr1))-851])(tr1, loc2));
		} else {
			
			RTHOOK(9);
			loc1 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
		}
		RTHOOK(10);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_6_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_3_))) {
			RTHOOK(11);
			F1093_8740(Current);
		}
		RTHOOK(12);
		if ((EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) == (EIF_CHARACTER_8) '\012')) {
			RTHOOK(13);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_5_))++;
			RTHOOK(14);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		} else {
			RTHOOK(15);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_4_))++;
		}
	} else {
		
		RTHOOK(17);
		loc1 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	}
	RTHOOK(18);
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) loc1;
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {XML_FILE_INPUT_STREAM}.get_next_chunk */
void F1093_8740 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("get_next_chunk", 1092, Current, 0, 0, 12720);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F828_6413(RTCW(tr1));
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5284[Dtype(RTCW(tr1))-828])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_1_));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		tr1 = RTLNSMART(eif_new_type(1082, 1).id);
		F1078_8165(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_6_) + ((EIF_INTEGER_32) 1L));
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_3_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_2_) + ti4_1) - ((EIF_INTEGER_32) 1L));
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit513 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
