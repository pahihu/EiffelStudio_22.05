
#ifndef _C11_xm519_
#define _C11_xm519_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1099_8930(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1099_8935(EIF_REFERENCE);
extern EIF_REFERENCE F1099_8936(EIF_REFERENCE);
extern void EIF_Minit519(void);
extern void F1087_8578(EIF_REFERENCE, EIF_REFERENCE);
extern void F1078_8165(EIF_REFERENCE);
extern void F1087_8579(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
