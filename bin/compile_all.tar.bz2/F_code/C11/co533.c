/*
 * Code for class CONF_LIBRARY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co533.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LIBRARY}.make */
void F1161_9420 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("make", 1160, Current, 0, 3, 15033);
	RTGC;
	RTHOOK(1);
	F1153_9254(Current, arg1, arg2, arg3);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O7810[Dtype(Current)-1152]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_LIBRARY}.mapping */
EIF_REFERENCE F1161_9425 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("mapping", 1160, Current, 1, 0, 15019);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1101_9020(loc1);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1084,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNS(typres0.id, 860, _OBJSIZ_7_4_0_7_0_0_0_0_);
		}
		F852_6722(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {CONF_LIBRARY}.class_by_name */
EIF_REFERENCE F1161_9427 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLR(6,Result);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLIU(9);
	
	RTEAA("class_by_name", 1160, Current, 5, 2, 15021);
	RTGC;
	RTHOOK(1);
	loc2 = F1161_9425(Current);
	RTHOOK(2);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = F852_6727(RTCW(loc2), arg1);
		loc3 = tr1;
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		RTHOOK(3);
		loc1 = (EIF_REFERENCE) loc3;
	} else {
		RTHOOK(4);
		loc1 = (EIF_REFERENCE) arg1;
	}
	RTHOOK(5);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,947,0xFF01,1096,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 947, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F944_7001(RTCW(Result));
	RTHOOK(6);
	tb1 = '\0';
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = F852_6727(loc4, loc1);
		loc5 = tr1;
		tb2 = EIF_TEST(loc5);
	}
	if (tb2) {
		tb2 = (RTNA((loc5)), ((EIF_BOOLEAN) 0));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(7);
		F948_7063(RTCW(Result), loc5);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_LIBRARY}.path */
EIF_REFERENCE F1161_9432 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("path", 1160, Current, 0, 0, 15026);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(218,F1161_9437, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = F1320_12293(RTCW(tr2));
	tr2 = F1102_9143(RTCW(tr2));
	Result = F186_2458(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_LIBRARY}.set_use_application_options */
void F1161_9433 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_use_application_options", 1160, Current, 0, 1, 15027);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7867[Dtype(Current)-1160]) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_LIBRARY}.set_library_target */
void F1161_9434 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_library_target", 1160, Current, 0, 1, 15028);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	F1289_11327(RTCW(tr1), Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_LIBRARY}.process */
void F1161_9435 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("process", 1160, Current, 0, 1, 15029);
	RTGC;
	RTHOOK(1);
	F1153_9310(Current, arg1);
	RTHOOK(2);
	F1295_11474(RTCW(arg1), Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_LIBRARY}.resolver */
static EIF_REFERENCE F1161_9437_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(218)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("resolver", 1160, Current, 0, 0, 15031);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(185, 0x01).id, 185, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1161_9437 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(218,F1161_9437_body,(Current));
}

void EIF_Minit533 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
