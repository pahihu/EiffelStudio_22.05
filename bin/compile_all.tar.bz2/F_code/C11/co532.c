/*
 * Code for class CONF_ASSEMBLY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co532.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_ASSEMBLY}.make_from_gac */
void F1160_9392 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg6);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLR(6,arg4);
	RTLR(7,arg5);
	RTLR(8,tr2);
	RTLIU(9);
	
	RTEAA("make_from_gac", 1159, Current, 0, 6, 14990);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg6);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg6;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_23_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6963[Dtype(RTCW(arg1))-1081])(arg1);
	F1153_9295(Current, tr1);
	RTHOOK(4);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) arg2;
	RTHOOK(5);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) arg3;
	RTHOOK(6);
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) arg4;
	RTHOOK(7);
	RTAR(Current, arg5);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg5;
	RTHOOK(8);
	tr1 = RTLNSMART(eif_final_id(Y7761,Y7761_gen_type,Dftype(Current),1152).id);
	tr2 = RTMS32_EX_H("",0,0);
	F1322_12309(RTCW(tr1), tr2, arg6);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_23_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {CONF_ASSEMBLY}.classes_set */
EIF_BOOLEAN F1160_9393 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("classes_set", 1159, Current, 0, 0, 14991);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_8_) != NULL);
}

/* {CONF_ASSEMBLY}.accessible_groups */
EIF_REFERENCE F1160_9404 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("accessible_groups", 1159, Current, 1, 0, 15002);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = (RTNA((loc1)), ((EIF_REFERENCE) 0));
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1261,0xFF01,1152,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNS(typres0.id, 1261, _OBJSIZ_4_1_0_5_0_0_0_0_);
		}
		F1262_10713(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {CONF_ASSEMBLY}.class_by_name */
EIF_REFERENCE F1160_9406 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTEAA("class_by_name", 1159, Current, 2, 2, 15004);
	RTGC;
	RTHOOK(1);
	Result = F1153_9285(Current, arg1, arg2);
	RTHOOK(2);
	if (arg2) {
		RTHOOK(3);
		loc2 = F1262_10724(RTCV(F1160_9404(Current)));
		for (;;) {
			tb1 = F482_5933(loc2);
			if (tb1) break;
			RTHOOK(4);
			loc1 = F482_5932(loc2);
			RTHOOK(5);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7747[Dtype(RTCW(loc1))-1155])(loc1);
			if (tb2) {
				RTHOOK(6);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R7774[Dtype(RTCW(loc1))-1155])(loc1, arg1, (EIF_BOOLEAN) 0);
				F896_6970(RTCW(Result), tr1);
			}
			RTHOOK(7);
			F482_5934(loc2);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_ASSEMBLY}.name_by_class */
EIF_REFERENCE F1160_9407 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTEAA("name_by_class", 1159, Current, 2, 2, 15005);
	RTGC;
	RTHOOK(1);
	Result = F1153_9286(Current, arg1, arg2);
	RTHOOK(2);
	if (arg2) {
		RTHOOK(3);
		loc2 = F1160_9404(Current);
		RTHOOK(4);
		F1262_10759(RTCW(loc2));
		for (;;) {
			RTHOOK(5);
			tb1 = F1262_10762(RTCW(loc2));
			if (tb1) break;
			RTHOOK(6);
			loc1 = F1262_10764(RTCW(loc2));
			RTHOOK(7);
			F1262_10760(RTCW(loc2));
			RTHOOK(8);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7747[Dtype(RTCW(loc1))-1155])(loc1);
			if (tb2) {
				RTHOOK(9);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R7775[Dtype(RTCW(loc1))-1155])(loc1, arg1, (EIF_BOOLEAN) 0);
				F896_6970(RTCW(Result), tr1);
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit532 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
