/*
 * Code for class reference INTEGER_64
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in544.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTEGER_64}.is_less */
EIF_BOOLEAN F1216_9666 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_less", 1215, Current, 0, 1, 15963);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)tr1 = arg1;
	Result = F1215_9604(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_64}.plus */
EIF_INTEGER_64 F1216_9667 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("plus", 1215, Current, 0, 1, 15964);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)tr1 = arg1;
	tr1 = F1215_9614(Current, tr1);
	Result = *(EIF_INTEGER_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_64}.product */
EIF_INTEGER_64 F1216_9669 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("product", 1215, Current, 0, 1, 15966);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)tr1 = arg1;
	tr1 = F1215_9616(Current, tr1);
	Result = *(EIF_INTEGER_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_64}.opposite */
EIF_INTEGER_64 F1216_9672 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("opposite", 1215, Current, 0, 0, 15969);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_INTEGER_64 *)F1215_9619(Current);
}

/* {INTEGER_64}.integer_quotient */
EIF_INTEGER_64 F1216_9673 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_quotient", 1215, Current, 0, 1, 15970);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)tr1 = arg1;
	tr1 = F1215_9620(Current, tr1);
	Result = *(EIF_INTEGER_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_64}.integer_remainder */
EIF_INTEGER_64 F1216_9674 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_remainder", 1215, Current, 0, 1, 15971);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)tr1 = arg1;
	tr1 = F1215_9621(Current, tr1);
	Result = *(EIF_INTEGER_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_64}.as_natural_32 */
EIF_NATURAL_32 F1216_9678 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_32", 1215, Current, 0, 0, 15975);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_32) F1215_9628(Current);
}

/* {INTEGER_64}.as_natural_64 */
EIF_NATURAL_64 F1216_9679 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_64", 1215, Current, 0, 0, 15976);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_64) F1215_9629(Current);
}

/* {INTEGER_64}.as_integer_32 */
EIF_INTEGER_32 F1216_9682 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_32", 1215, Current, 0, 0, 15979);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F1215_9632(Current);
}

/* {INTEGER_64}.to_double */
EIF_REAL_64 F1216_9685 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_double", 1215, Current, 0, 0, 15982);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_64) F1215_9644(Current);
}

/* {INTEGER_64}.to_character_8 */
EIF_CHARACTER_8 F1216_9686 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_8", 1215, Current, 0, 0, 15983);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) F1215_9652(Current);
}

/* {INTEGER_64}.to_character_32 */
EIF_CHARACTER_32 F1216_9687 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_32", 1215, Current, 0, 0, 15984);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_32) F1215_9653(Current);
}

/* {INTEGER_64}.bit_and */
EIF_INTEGER_64 F1216_9688 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_and", 1215, Current, 0, 1, 15985);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1216, 0x00).id, 1216, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)tr1 = arg1;
	tr1 = F1215_9654(Current, tr1);
	Result = *(EIF_INTEGER_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit544 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
