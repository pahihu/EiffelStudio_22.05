/*
 * Code for class INTEGER_32_REF
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in545.h"
#include <math.h>
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTEGER_32_REF}.hash_code */
EIF_INTEGER_32 F1218_9695 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("hash_code", 1217, Current, 0, 0, 15993);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	Result = eif_bit_and(ti4_1,((EIF_INTEGER_32) 2147483647L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.is_less */
EIF_BOOLEAN F1218_9702 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("is_less", 1217, Current, 0, 1, 16000);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 < ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.is_equal */
EIF_BOOLEAN F1218_9703 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_equal", 1217, Current, 0, 1, 16001);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.set_item */
void F1218_9704 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_item", 1217, Current, 0, 1, 16002);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {INTEGER_32_REF}.abs */
EIF_INTEGER_32 F1218_9711 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("abs", 1217, Current, 0, 0, 16009);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_INTEGER_32 *)(RTCV(F1218_9764(Current))+ _LNGOFF_0_0_0_0_);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.plus */
EIF_REFERENCE F1218_9712 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("plus", 1217, Current, 0, 1, 16010);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	F1218_9704(RTCW(Result), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) + ti4_1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.minus */
EIF_REFERENCE F1218_9713 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("minus", 1217, Current, 0, 1, 16011);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	F1218_9704(RTCW(Result), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) - ti4_1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.product */
EIF_REFERENCE F1218_9714 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("product", 1217, Current, 0, 1, 16012);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	F1218_9704(RTCW(Result), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) * ti4_1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.quotient */
EIF_REAL_64 F1218_9715 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("quotient", 1217, Current, 0, 1, 16013);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	Result = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) (ti4_1) /  (EIF_REAL_64) (ti4_2));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.opposite */
EIF_REFERENCE F1218_9717 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("opposite", 1217, Current, 0, 0, 16015);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	F1218_9704(RTCW(Result), (EIF_INTEGER_32) -*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.integer_quotient */
EIF_REFERENCE F1218_9718 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("integer_quotient", 1217, Current, 0, 1, 16016);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	F1218_9704(RTCW(Result), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) / ti4_1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.integer_remainder */
EIF_REFERENCE F1218_9719 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("integer_remainder", 1217, Current, 0, 1, 16017);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	F1218_9704(RTCW(Result), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) % ti4_1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.power */
EIF_REAL_64 F1218_9720 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("power", 1217, Current, 0, 1, 16018);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_64) (EIF_REAL_64) pow ((EIF_REAL_64) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_)), (EIF_REAL_64) (arg1));
}

/* {INTEGER_32_REF}.interval */
EIF_REFERENCE F1218_9721 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("interval", 1217, Current, 0, 1, 16019);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(877, 0x01).id, 877, _OBJSIZ_0_1_0_2_0_0_0_0_);
	F878_6852(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {INTEGER_32_REF}.as_natural_8 */
EIF_NATURAL_8 F1218_9725 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("as_natural_8", 1217, Current, 0, 0, 16023);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	Result = (EIF_NATURAL_8) ti4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.as_natural_32 */
EIF_NATURAL_32 F1218_9727 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("as_natural_32", 1217, Current, 0, 0, 16025);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	Result = (EIF_NATURAL_32) ti4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.as_natural_64 */
EIF_NATURAL_64 F1218_9728 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("as_natural_64", 1217, Current, 0, 0, 16026);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	Result = (EIF_NATURAL_64) ti4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.as_integer_32 */
EIF_INTEGER_32 F1218_9731 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("as_integer_32", 1217, Current, 0, 0, 16029);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	Result = (EIF_INTEGER_32) ti4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.as_integer_64 */
EIF_INTEGER_64 F1218_9732 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("as_integer_64", 1217, Current, 0, 0, 16030);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	Result = (EIF_INTEGER_64) ti4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.to_natural_8 */
EIF_NATURAL_8 F1218_9733 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_natural_8", 1217, Current, 0, 0, 16031);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_8) (FUNCTION_CAST(EIF_NATURAL_8, (EIF_REFERENCE)) R8053[Dtype(Current)-1218])(Current);
}

/* {INTEGER_32_REF}.to_natural_32 */
EIF_NATURAL_32 F1218_9735 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_natural_32", 1217, Current, 0, 0, 16033);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_32) (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE)) R8055[Dtype(Current)-1218])(Current);
}

/* {INTEGER_32_REF}.to_natural_64 */
EIF_NATURAL_64 F1218_9736 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_natural_64", 1217, Current, 0, 0, 16034);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_64) (FUNCTION_CAST(EIF_NATURAL_64, (EIF_REFERENCE)) R8056[Dtype(Current)-1218])(Current);
}

/* {INTEGER_32_REF}.to_integer_64 */
EIF_INTEGER_64 F1218_9741 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_integer_64", 1217, Current, 0, 0, 16039);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_64) (FUNCTION_CAST(EIF_INTEGER_64, (EIF_REFERENCE)) R8060[Dtype(Current)-1218])(Current);
}

/* {INTEGER_32_REF}.to_double */
EIF_REAL_64 F1218_9743 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("to_double", 1217, Current, 0, 0, 16041);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	Result = (EIF_REAL_64) (ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.to_hex_string */
EIF_REFERENCE F1218_9748 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("to_hex_string", 1217, Current, 3, 0, 16046);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 32L) / ((EIF_INTEGER_32) 4L));
	RTHOOK(2);
	Result = RTLNS(eif_new_type(1082, 0x01).id, 1082, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1081_8296(RTCW(Result), (EIF_CHARACTER_8) '0', loc1);
	RTHOOK(3);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) break;
		RTHOOK(5);
		ti4_1 = eif_bit_and(loc2,((EIF_INTEGER_32) 15L));
		tr1 = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)tr1 = ti4_1;
		tc1 = F1218_9749(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5494[Dtype(RTCW(Result))-851])(Result, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc1);
		RTHOOK(6);
		ti4_1 = eif_bit_shift_right(loc2,((EIF_INTEGER_32) 4L));
		loc2 = (EIF_INTEGER_32) ti4_1;
		RTHOOK(7);
		loc1--;
	}
	RTHOOK(14);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.to_hex_character */
EIF_CHARACTER_8 F1218_9749 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("to_hex_character", 1217, Current, 1, 0, 16047);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (loc1 <= ((EIF_INTEGER_32) 9L))) {
		RTHOOK(3);
		tc1 = (EIF_CHARACTER_8) '0';
	} else {
		RTHOOK(4);
		tc2 = (EIF_CHARACTER_8) (((EIF_INTEGER_32) (EIF_CHARACTER_8) 'A') - ((EIF_INTEGER_32) 10L));
		tc1 = tc2;
	}
	Result = (EIF_CHARACTER_8) (((EIF_INTEGER_32) tc1) + loc1);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.to_character_8 */
EIF_CHARACTER_8 F1218_9751 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("to_character_8", 1217, Current, 0, 0, 16049);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	Result = (EIF_CHARACTER_8) ti4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.to_character_32 */
EIF_CHARACTER_32 F1218_9752 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("to_character_32", 1217, Current, 0, 0, 16050);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	Result = (EIF_CHARACTER_32) ti4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.bit_and */
EIF_REFERENCE F1218_9753 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("bit_and", 1217, Current, 0, 1, 16051);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	ti4_1 = eif_bit_and(ti4_1,ti4_2);
	F1218_9704(RTCW(Result), ti4_1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.bit_or */
EIF_REFERENCE F1218_9754 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("bit_or", 1217, Current, 0, 1, 16052);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	F1218_9704(RTCW(Result), ti4_1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.bit_xor */
EIF_REFERENCE F1218_9755 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("bit_xor", 1217, Current, 0, 1, 16053);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	ti4_1 = eif_bit_xor(ti4_1,ti4_2);
	F1218_9704(RTCW(Result), ti4_1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.bit_not */
EIF_REFERENCE F1218_9756 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("bit_not", 1217, Current, 0, 0, 16054);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	ti4_1 = eif_bit_not(ti4_1);
	F1218_9704(RTCW(Result), ti4_1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.bit_shift_left */
EIF_REFERENCE F1218_9758 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("bit_shift_left", 1217, Current, 0, 1, 16056);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	ti4_1 = eif_bit_shift_left(ti4_1,arg1);
	F1218_9704(RTCW(Result), ti4_1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.bit_shift_right */
EIF_REFERENCE F1218_9759 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("bit_shift_right", 1217, Current, 0, 1, 16057);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	F1_29(RTCW(Result));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	ti4_1 = eif_bit_shift_right(ti4_1,arg1);
	F1218_9704(RTCW(Result), ti4_1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.out */
EIF_REFERENCE F1218_9763 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("out", 1217, Current, 0, 0, 16061);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1082, 0x01).id, 1082, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1081_8295(RTCW(Result), ((EIF_INTEGER_32) 11L));
	RTHOOK(2);
	F1083_8411(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32_REF}.abs_ref */
EIF_REFERENCE F1218_9764 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("abs_ref", 1217, Current, 0, 0, 16062);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) >= ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Current;
	} else {
		RTHOOK(4);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7980[Dtype(Current)-1215])(Current);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

void EIF_Minit545 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
