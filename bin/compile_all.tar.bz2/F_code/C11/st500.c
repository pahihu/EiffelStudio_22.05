/*
 * Code for class STRING_GENERAL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st500.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STRING_GENERAL}.reset_hash_codes */
void F1080_8263 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reset_hash_codes", 1079, Current, 0, 0, 12293);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O6994[dtype-1077]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O6995[dtype-1077]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {STRING_GENERAL}.append_code */
void F1080_8265 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("append_code", 1079, Current, 1, 1, 12294);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[dtype-1081])(Current);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	if ((EIF_BOOLEAN) (loc1 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6942[dtype-1081])(Current))) {
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R7030[dtype-1082])(Current, loc1);
	}
	RTHOOK(4);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6997[dtype-1082])(Current, loc1);
	RTHOOK(5);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32)) R7000[dtype-1082])(Current, arg1, loc1);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {STRING_GENERAL}.append */
void F1080_8276 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("append", 1079, Current, 3, 1, 12296);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[Dtype(RTCW(arg1))-1081])(arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[dtype-1081])(Current);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + loc2);
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc2 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6942[dtype-1081])(Current))) {
			RTHOOK(5);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R7030[dtype-1082])(Current, loc2);
		}
		RTHOOK(6);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(7);
			if ((EIF_BOOLEAN) (loc3 > loc1)) break;
			RTHOOK(8);
			tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[dtype-1082])(Current, tu4_1);
			RTHOOK(9);
			loc3++;
		}
		RTHOOK(10);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6997[dtype-1082])(Current, loc2);
		RTHOOK(11);
		F1080_8263(Current);
	}
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {STRING_GENERAL}.prepend */
void F1080_8278 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("prepend", 1079, Current, 4, 1, 12289);
	RTGC;
	RTHOOK(1);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[Dtype(RTCW(arg1))-1081])(arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[dtype-1081])(Current);
		RTHOOK(4);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + loc1);
		RTHOOK(5);
		if ((EIF_BOOLEAN) (loc3 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6942[dtype-1081])(Current))) {
			RTHOOK(6);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R7030[dtype-1082])(Current, loc3);
		}
		RTHOOK(7);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6997[dtype-1082])(Current, loc3);
		RTHOOK(8);
		loc4 = (EIF_INTEGER_32) loc1;
		for (;;) {
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) break;
			RTHOOK(10);
			tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[dtype-1081])(Current, loc4);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32)) R7000[dtype-1082])(Current, tu4_1, (EIF_INTEGER_32) (loc4 + loc2));
			RTHOOK(11);
			loc4--;
		}
		RTHOOK(12);
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(13);
			if ((EIF_BOOLEAN) (loc4 > loc2)) break;
			RTHOOK(14);
			tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, loc4);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32)) R7000[dtype-1082])(Current, tu4_1, loc4);
			RTHOOK(15);
			loc4++;
		}
		RTHOOK(16);
		F1080_8263(Current);
	}
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {STRING_GENERAL}.adjust */
void F1080_8288 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("adjust", 1079, Current, 0, 0, 12291);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7022[dtype-1082])(Current);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7023[dtype-1082])(Current);
	RTHOOK(9);
	RTLE;
	RTEE;
}

void EIF_Minit500 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
