/*
 * Code for class CONF_CLUSTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co528.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_CLUSTER}.make */
void F1156_9332 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("make", 1155, Current, 0, 3, 14932);
	RTGC;
	RTHOOK(1);
	F1153_9254(Current, arg1, arg2, arg3);
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,405,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	F608_6140(RTCW(tr1));
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,947,0xFF01,1096,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F852_6721(RTCW(tr1), ((EIF_INTEGER_32) 50L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,851,0xFF01,947,0xFF01,1077,0xFF01,1096,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F852_6721(RTCW(tr1), ((EIF_INTEGER_32) 50L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_CLUSTER}.dependencies */
EIF_REFERENCE F1156_9339 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,Result);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTEAA("dependencies", 1155, Current, 3, 0, 14939);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1156_9339(loc1);
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(2);
		Result = F1_14(loc2);
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(Result != NULL)) {
			RTHOOK(5);
			F1262_10735(RTCW(Result), loc3);
		} else {
			RTHOOK(6);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) loc3;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_CLUSTER}.file_rule */
EIF_REFERENCE F1156_9341 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("file_rule", 1155, Current, 1, 0, 14941);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1156_9341(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5583[Dtype(RTCW(Result))-943])(Result, tr1);
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = F1101_9007(RTCW(tr1));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5583[Dtype(RTCW(Result))-943])(Result, tr1);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_CLUSTER}.mapping */
EIF_REFERENCE F1156_9346 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("mapping", 1155, Current, 3, 0, 14946);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_23_) == NULL) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_18_) == NULL))) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			loc1 = F1101_9020(RTCW(tr1));
		} else {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			tr1 = F1101_9020(RTCW(tr1));
			loc1 = F1_14(tr1);
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				RTHOOK(7);
				tr1 = F1156_9346(loc2);
				F852_6772(RTCW(loc1), tr1);
			}
			RTHOOK(8);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(9);
				F852_6772(RTCW(loc1), loc3);
			}
		}
		RTHOOK(10);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(11);
	RTHOOK(12);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {CONF_CLUSTER}.class_by_name */
EIF_REFERENCE F1156_9347 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLR(5,loc4);
	RTLR(6,Result);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc1);
	RTLIU(11);
	
	RTEAA("class_by_name", 1155, Current, 7, 2, 14947);
	RTGC;
	RTHOOK(1);
	tr1 = F1156_9346(Current);
	tr1 = F852_6727(RTCW(tr1), arg1);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(2);
		loc2 = (EIF_REFERENCE) loc3;
	} else {
		RTHOOK(3);
		loc2 = (EIF_REFERENCE) arg1;
	}
	RTHOOK(4);
	tb1 = '\0';
	if (arg2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
		tr1 = F852_6727(RTCW(tr1), loc2);
		loc4 = tr1;
		tb1 = EIF_TEST(loc4);
	}
	if (tb1) {
		RTHOOK(5);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc4;
	} else {
		RTHOOK(7);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,947,0xFF01,1096,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			Result = RTLNS(typres0.id, 947, _OBJSIZ_2_3_0_1_0_0_0_0_);
		}
		F944_7001(RTCW(Result));
		RTHOOK(8);
		tb1 = '\0';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			tr1 = F852_6727(loc5, loc2);
			loc6 = tr1;
			tb2 = EIF_TEST(loc6);
		}
		if (tb2) {
			tb2 = (RTNA((loc6)), ((EIF_BOOLEAN) 0));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			RTHOOK(9);
			F948_7063(RTCW(Result), loc6);
		}
		RTHOOK(10);
		if (arg2) {
			RTHOOK(11);
			loc7 = F1262_10724(RTCV(F1156_9349(Current)));
			for (;;) {
				tb1 = F482_5933(loc7);
				if (tb1) break;
				RTHOOK(12);
				loc1 = F482_5932(loc7);
				RTHOOK(13);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7747[Dtype(RTCW(loc1))-1155])(loc1);
				if (tb2) {
					RTHOOK(14);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R7774[Dtype(RTCW(loc1))-1155])(loc1, loc2, (EIF_BOOLEAN) 0);
					F896_6970(RTCW(Result), tr1);
				}
				RTHOOK(15);
				F482_5934(loc7);
			}
			RTHOOK(16);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
			F852_6768(RTCW(tr1), Result, loc2);
		}
	}
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_CLUSTER}.name_by_class */
EIF_REFERENCE F1156_9348 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLR(5,loc3);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTEAA("name_by_class", 1155, Current, 3, 2, 14948);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (arg2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
		tr1 = F852_6727(RTCW(tr1), arg1);
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc2;
	} else {
		RTHOOK(4);
		Result = F1153_9286(Current, arg1, arg2);
		RTHOOK(5);
		if (arg2) {
			RTHOOK(6);
			loc3 = F1262_10724(RTCV(F1156_9349(Current)));
			for (;;) {
				tb1 = F482_5933(loc3);
				if (tb1) break;
				RTHOOK(7);
				loc1 = F482_5932(loc3);
				RTHOOK(8);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7747[Dtype(RTCW(loc1))-1155])(loc1);
				if (tb2) {
					RTHOOK(9);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R7775[Dtype(RTCW(loc1))-1155])(loc1, arg1, (EIF_BOOLEAN) 0);
					F896_6970(RTCW(Result), tr1);
				}
				RTHOOK(10);
				F482_5934(loc3);
			}
			RTHOOK(11);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			F852_6768(RTCW(tr1), Result, arg1);
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_CLUSTER}.accessible_groups */
EIF_REFERENCE F1156_9349 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLIU(10);
	
	RTEAA("accessible_groups", 1155, Current, 8, 0, 14949);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		RTHOOK(3);
		tr1 = F1156_9339(Current);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(4);
			loc2 = (EIF_REFERENCE) loc3;
			RTHOOK(5);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc2;
		} else {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			loc1 = F1101_9003(RTCW(tr1));
			RTHOOK(7);
			{
				static EIF_TYPE_INDEX typarr0[] = {1261,0xFF01,1152,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc2 = RTLNSMART(typres0.id);
			}
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_7_4_0_6_);
			F1262_10713(RTCW(loc2), ti4_1);
			RTHOOK(8);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc2;
			RTHOOK(9);
			loc4 = F852_6736(RTCW(loc1));
			for (;;) {
				tb1 = F547_6063(loc4);
				if (tb1) break;
				RTHOOK(10);
				tr1 = F547_6060(loc4);
				F1262_10729(RTCW(loc2), tr1);
				RTHOOK(11);
				F547_6064(loc4);
			}
			RTHOOK(12);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			loc1 = F1101_9001(RTCW(tr1));
			RTHOOK(13);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F1156_9349(Current))+ _LNGOFF_4_1_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_7_4_0_6_);
			F1262_10736(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 + ti4_2));
			RTHOOK(14);
			loc5 = F852_6736(RTCW(loc1));
			for (;;) {
				tb2 = F547_6063(loc5);
				if (tb2) break;
				RTHOOK(15);
				tr1 = F547_6060(loc5);
				F1262_10729(RTCW(loc2), tr1);
				RTHOOK(16);
				F547_6064(loc5);
			}
			RTHOOK(17);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			loc1 = F1101_9002(RTCW(tr1));
			RTHOOK(18);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F1156_9349(Current))+ _LNGOFF_4_1_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_7_4_0_6_);
			F1262_10736(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 + ti4_2));
			RTHOOK(19);
			loc6 = F852_6736(RTCW(loc1));
			for (;;) {
				tb3 = F547_6063(loc6);
				if (tb3) break;
				RTHOOK(20);
				tr1 = F547_6060(loc6);
				F1262_10729(RTCW(loc2), tr1);
				RTHOOK(21);
				F547_6064(loc6);
			}
			RTHOOK(22);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			loc1 = F1101_9004(RTCW(tr1));
			RTHOOK(23);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F1156_9349(Current))+ _LNGOFF_4_1_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_7_4_0_6_);
			F1262_10736(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 + ti4_2));
			RTHOOK(24);
			loc7 = F852_6736(RTCW(loc1));
			for (;;) {
				tb4 = F547_6063(loc7);
				if (tb4) break;
				RTHOOK(25);
				tr1 = F547_6060(loc7);
				F1262_10729(RTCW(loc2), tr1);
				RTHOOK(26);
				F547_6064(loc7);
			}
			RTHOOK(27);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			tr1 = F1101_9000(RTCW(tr1));
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				RTHOOK(28);
				F1262_10729(RTCW(loc2), loc8);
			}
			RTHOOK(29);
			F1262_10731(RTCW(loc2), Current);
		}
	}
	RTHOOK(30);
	RTHOOK(31);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc2;
}

/* {CONF_CLUSTER}.set_parent */
void F1156_9352 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_parent", 1155, Current, 0, 1, 14952);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_CLUSTER}.add_child */
void F1156_9353 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_child", 1155, Current, 2, 1, 14953);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		loc1 = RTLNSMART(eif_final_id(Y7818,Y7818_gen_type,Dftype(Current),1155).id);
		F949_7071(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	F949_7111(RTCW(loc1), arg1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {CONF_CLUSTER}.set_recursive */
void F1156_9355 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_recursive", 1155, Current, 0, 1, 14955);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7815[Dtype(Current)-1155]) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_CLUSTER}.set_hidden */
void F1156_9356 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_hidden", 1155, Current, 0, 1, 14956);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7816[Dtype(Current)-1155]) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_CLUSTER}.set_dependencies */
void F1156_9357 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_dependencies", 1155, Current, 0, 1, 14957);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_CLUSTER}.add_dependency_name */
void F1156_9359 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_dependency_name", 1155, Current, 2, 1, 14959);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {948,0xFF01,1084,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F949_7071(RTCW(loc1), ((EIF_INTEGER_32) 0L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	F949_7111(RTCW(loc1), arg1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {CONF_CLUSTER}.add_file_rule */
void F1156_9361 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_file_rule", 1155, Current, 0, 1, 14961);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	F949_7111(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_CLUSTER}.add_mapping */
void F1156_9363 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("add_mapping", 1155, Current, 1, 2, 14963);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {860,0xFF01,1084,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F852_6722(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	tr1 = F1087_8612(RTCW(arg2));
	tr2 = F1087_8612(RTCW(arg1));
	F852_6768(RTCW(loc1), tr1, tr2);
	RTHOOK(6);
	*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) NULL;
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit528 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
