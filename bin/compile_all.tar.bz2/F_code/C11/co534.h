
#ifndef _C11_co534_
#define _C11_co534_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1162_9438(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
static EIF_BOOLEAN F1162_9439_body(EIF_REFERENCE);
extern EIF_BOOLEAN F1162_9439(EIF_REFERENCE);
extern void F1162_9441(EIF_REFERENCE, EIF_REFERENCE);
extern void F1162_9442(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit534(void);
extern void F1153_9295(EIF_REFERENCE, EIF_REFERENCE);
extern void F1295_11475(EIF_REFERENCE, EIF_REFERENCE);
extern void F1153_9297(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R6963[])();

#ifdef __cplusplus
}
#endif

#endif
