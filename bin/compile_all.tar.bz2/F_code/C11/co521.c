/*
 * Code for class CONF_TARGET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co521.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_TARGET}.make */
void F1101_8959 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("make", 1100, Current, 0, 2, 12959);
	RTGC;
	RTHOOK(1);
	F404_4857(Current);
	RTHOOK(2);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6963[Dtype(RTCW(arg1))-1081])(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1160,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F852_6721(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1157,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F852_6721(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1155,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F852_6721(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1159,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F852_6721(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,405,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F608_6140(RTCW(tr1));
	RTHOOK(9);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,410,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	RTHOOK(10);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,408,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	RTHOOK(11);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,414,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
	RTHOOK(12);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,411,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	RTHOOK(13);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,409,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
	RTHOOK(14);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,412,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
	RTHOOK(15);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,413,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
	RTHOOK(16);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,406,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) tr1;
	RTHOOK(17);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,406,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_27_) = (EIF_REFERENCE) tr1;
	RTHOOK(18);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1084,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F861_6846(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_28_) = (EIF_REFERENCE) tr1;
	RTHOOK(19);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1084,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F852_6721(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(20);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg2;
	RTHOOK(23);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.namespace */
EIF_REFERENCE F1101_8968 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("namespace", 1100, Current, 0, 0, 12968);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_6_);
	Result = F1078_8224(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.setting_boolean */
EIF_BOOLEAN F1101_8969 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("setting_boolean", 1100, Current, 0, 1, 12969);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_6_);
	Result = F404_4862(Current, arg1, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.setting_dynamic_runtime */
EIF_BOOLEAN F1101_8982 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("setting_dynamic_runtime", 1100, Current, 0, 0, 12982);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(78,F378_4187, (Current));
	Result = F1101_8969(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.setting_msil_generation */
EIF_BOOLEAN F1101_8990 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("setting_msil_generation", 1100, Current, 0, 0, 12990);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(79,F378_4205, (Current));
	Result = F1101_8969(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.record_environ_variable */
void F1101_8996 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("record_environ_variable", 1100, Current, 0, 2, 12996);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F852_6767(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.library_root */
EIF_REFERENCE F1101_8997 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,Result);
	RTLIU(7);
	
	RTEAA("library_root", 1100, Current, 1, 0, 12997);
	RTGC;
	RTHOOK(1);
	tr1 = F1101_9009(Current);
	tr2 = RTOUCR(80,F378_4197, (Current));
	tr1 = F852_6727(RTCW(tr1), tr2);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1320, 0x01).id, 1320, _OBJSIZ_3_0_0_0_0_0_0_0_);
		tr2 = RTLNS(eif_new_type(397, 0x01).id, 397, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr3 = RTMS32_EX_H("d\000\000\000u\000\000\000m\000\000\000m\000\000\000y\000\000\000",5,1970873721);
		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = F398_4736(RTCW(tr2), tr3, tr4);
		F1321_12306(RTCW(tr1), loc1, tr2);
		Result = F1320_12293(RTCW(tr1));
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.precompile */
EIF_REFERENCE F1101_9000 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("precompile", 1100, Current, 2, 0, 13000);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc2 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) && EIF_TEST(loc2))) {
		RTHOOK(3);
		tr1 = F1101_9000(loc2);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(5);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	}/* NOTREACHED */
	
}

/* {CONF_TARGET}.libraries */
EIF_REFERENCE F1101_9001 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("libraries", 1100, Current, 1, 0, 13001);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1101_9001(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		F852_6772(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_13_));
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		Result = F1_14(tr1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.assemblies */
EIF_REFERENCE F1101_9002 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("assemblies", 1100, Current, 1, 0, 13002);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1101_9002(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		F852_6772(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_16_));
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
		Result = F1_14(tr1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.clusters */
EIF_REFERENCE F1101_9003 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("clusters", 1100, Current, 1, 0, 13003);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1101_9003(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		F852_6772(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_15_));
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		Result = F1_14(tr1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.overrides */
EIF_REFERENCE F1101_9004 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("overrides", 1100, Current, 1, 0, 13004);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1101_9004(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		F852_6772(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_14_));
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		Result = F1_14(tr1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.root */
EIF_REFERENCE F1101_9006 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("root", 1100, Current, 1, 0, 13006);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_10_) != NULL)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_10_);
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTHOOK(5);
			tr1 = F1101_9006(loc1);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) tr1;
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {CONF_TARGET}.file_rule */
EIF_REFERENCE F1101_9007 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("file_rule", 1100, Current, 1, 0, 13007);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1101_9007(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5583[Dtype(RTCW(Result))-943])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.options */
EIF_REFERENCE F1101_9008 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("options", 1100, Current, 2, 0, 13008);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
		RTHOOK(2);
		Result = F1_14(F404_4858(Current));
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(4);
			Result = F1_14(F404_4858(Current));
			RTHOOK(5);
			tr1 = F1101_9008(loc1);
			F971_7442(RTCW(Result), tr1);
		} else {
			RTHOOK(6);
			Result = F1101_9008(loc1);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.settings */
EIF_REFERENCE F1101_9009 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("settings", 1100, Current, 1, 0, 13009);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc1) && (EIF_BOOLEAN)(loc1 != Current))) {
		RTHOOK(2);
		tr1 = F1101_9009(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		tr1 = F404_4860(Current);
		F852_6772(RTCW(Result), tr1);
	} else {
		RTHOOK(4);
		Result = F404_4860(Current);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_include */
EIF_REFERENCE F1101_9010 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_include", 1100, Current, 1, 0, 13010);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1101_9010(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5583[Dtype(RTCW(Result))-943])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_cflag */
EIF_REFERENCE F1101_9011 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_cflag", 1100, Current, 1, 0, 13011);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1101_9011(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5583[Dtype(RTCW(Result))-943])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_object */
EIF_REFERENCE F1101_9012 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_object", 1100, Current, 1, 0, 13012);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1101_9012(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5583[Dtype(RTCW(Result))-943])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_library */
EIF_REFERENCE F1101_9013 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_library", 1100, Current, 1, 0, 13013);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1101_9013(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5583[Dtype(RTCW(Result))-943])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_linker_flag */
EIF_REFERENCE F1101_9014 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_linker_flag", 1100, Current, 1, 0, 13014);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1101_9014(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5583[Dtype(RTCW(Result))-943])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_make */
EIF_REFERENCE F1101_9015 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_make", 1100, Current, 1, 0, 13015);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1101_9015(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5583[Dtype(RTCW(Result))-943])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.external_resource */
EIF_REFERENCE F1101_9016 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("external_resource", 1100, Current, 1, 0, 13016);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
	Result = F1_14(tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = F1101_9016(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5583[Dtype(RTCW(Result))-943])(Result, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.pre_compile_action */
EIF_REFERENCE F1101_9017 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("pre_compile_action", 1100, Current, 2, 0, 13017);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
	loc1 = tr1;
	if ((EIF_TRUE)) {
		RTHOOK(2);
		Result = F1_14(loc1);
	} else {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,406,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			Result = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F949_7071(RTCW(Result), ((EIF_INTEGER_32) 0L));
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(5);
		tr1 = F1101_9017(loc2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5583[Dtype(RTCW(Result))-943])(Result, tr1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.post_compile_action */
EIF_REFERENCE F1101_9018 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("post_compile_action", 1100, Current, 2, 0, 13018);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	loc1 = tr1;
	if ((EIF_TRUE)) {
		RTHOOK(2);
		Result = F1_14(loc1);
	} else {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,406,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			Result = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F949_7071(RTCW(Result), ((EIF_INTEGER_32) 0L));
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(5);
		tr1 = F1101_9018(loc2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5583[Dtype(RTCW(Result))-943])(Result, tr1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.variables */
EIF_REFERENCE F1101_9019 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("variables", 1100, Current, 1, 0, 13019);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1101_9019(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		F852_6772(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_28_));
	} else {
		RTHOOK(4);
		Result = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.mapping */
EIF_REFERENCE F1101_9020 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTEAA("mapping", 1100, Current, 3, 0, 13020);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1101_9020(loc1);
		Result = F1_14(tr1);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(4);
			F852_6772(RTCW(Result), loc2);
		}
	} else {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(6);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) loc3;
		} else {
			RTHOOK(8);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1084,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				Result = RTLNS(typres0.id, 860, _OBJSIZ_7_4_0_7_0_0_0_0_);
			}
			F852_6722(RTCW(Result), ((EIF_INTEGER_32) 5L));
			RTHOOK(9);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.concurrency_mode */
EIF_INTEGER_32 F1101_9021 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("concurrency_mode", 1100, Current, 0, 0, 13021);
	RTGC;
	RTHOOK(1);
	Result = F971_7429(RTCV(F1101_9008(Current)));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.void_safety_mode */
EIF_INTEGER_32 F1101_9022 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("void_safety_mode", 1100, Current, 0, 0, 13022);
	RTGC;
	RTHOOK(1);
	Result = F971_7432(RTCV(F1101_9008(Current)));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.set_description */
void F1101_9024 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_description", 1100, Current, 0, 1, 13024);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_TARGET}.set_parent */
void F1101_9025 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_parent", 1100, Current, 0, 1, 13025);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.reference_parent */
void F1101_9027 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("reference_parent", 1100, Current, 0, 1, 13027);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {CONF_TARGET}.set_version */
void F1101_9030 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_version", 1100, Current, 0, 1, 13030);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_TARGET}.set_precompile */
void F1101_9031 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_precompile", 1100, Current, 0, 1, 13031);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_TARGET}.add_library */
void F1101_9032 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("add_library", 1100, Current, 0, 1, 13032);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	F852_6768(RTCW(tr1), arg1, tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_assembly */
void F1101_9033 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("add_assembly", 1100, Current, 0, 1, 13033);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	F852_6768(RTCW(tr1), arg1, tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_cluster */
void F1101_9034 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("add_cluster", 1100, Current, 0, 1, 13034);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	F852_6768(RTCW(tr1), arg1, tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_override */
void F1101_9035 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("add_override", 1100, Current, 0, 1, 13035);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	F852_6768(RTCW(tr1), arg1, tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.set_root */
void F1101_9040 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_root", 1100, Current, 0, 1, 13040);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_TARGET}.add_file_rule */
void F1101_9043 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_file_rule", 1100, Current, 0, 1, 13043);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F949_7111(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_include */
void F1101_9051 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_include", 1100, Current, 0, 1, 13051);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_cflag */
void F1101_9052 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_cflag", 1100, Current, 0, 1, 13052);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_object */
void F1101_9053 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_object", 1100, Current, 0, 1, 13053);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_library */
void F1101_9054 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_library", 1100, Current, 0, 1, 13054);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_resource */
void F1101_9055 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_resource", 1100, Current, 0, 1, 13055);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_23_) == NULL)) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,409,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, arg1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_linker_flag */
void F1101_9056 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_linker_flag", 1100, Current, 0, 1, 13056);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_external_make */
void F1101_9057 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_external_make", 1100, Current, 0, 1, 13057);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.remove_external_object */
void F1101_9060 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("remove_external_object", 1100, Current, 0, 1, 13060);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	F949_7102(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	F949_7108(RTCW(tr1), arg1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5503[Dtype(RTCW(tr1))-800])(tr1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.remove_external_library */
void F1101_9061 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("remove_external_library", 1100, Current, 0, 1, 13061);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	F949_7102(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	F949_7108(RTCW(tr1), arg1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5503[Dtype(RTCW(tr1))-800])(tr1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_pre_compile */
void F1101_9067 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_pre_compile", 1100, Current, 0, 1, 13067);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_26_) == NULL)) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,406,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_post_compile */
void F1101_9068 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_post_compile", 1100, Current, 0, 1, 13068);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_27_) == NULL)) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,406,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_27_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_variable */
void F1101_9070 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("add_variable", 1100, Current, 0, 2, 13070);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	F852_6768(RTCW(tr1), arg2, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.add_mapping */
void F1101_9072 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("add_mapping", 1100, Current, 1, 2, 13072);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {860,0xFF01,1084,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F861_6846(RTCW(loc1), ((EIF_INTEGER_32) 15L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	tr1 = F1087_8612(RTCW(arg2));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6964[Dtype(RTCW(arg1))-1081])(arg1);
	F852_6768(RTCW(loc1), tr1, tr2);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_TARGET}.set_abstract */
void F1101_9074 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_abstract", 1100, Current, 0, 1, 13074);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_29_0_) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_TARGET}.set_environ_variables */
void F1101_9075 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_environ_variables", 1100, Current, 0, 1, 13075);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_TARGET}.same_as */
EIF_BOOLEAN F1101_9076 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("same_as", 1100, Current, 2, 1, 13076);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(arg1 == Current)) {
			RTHOOK(3);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
			tb1 = F1078_8207(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
			if (tb1) {
				RTHOOK(6);
				tb1 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
				loc1 = tr1;
				if ((EIF_TRUE)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
					loc2 = tr1;
					tb1 = (EIF_TRUE);
				}
				if (tb1) {
					RTHOOK(7);
					if ((EIF_BOOLEAN)(loc1 == loc2)) {
						RTHOOK(8);
						RTHOOK(9);
						RTLE;
						RTEE;
						return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						RTHOOK(10);
						tb1 = '\0';
						tb2 = *(EIF_BOOLEAN *)(loc1+ _CHROFF_16_2_);
						if (tb2) {
							tb2 = *(EIF_BOOLEAN *)(loc2+ _CHROFF_16_2_);
							tb1 = tb2;
						}
						if (tb1) {
							RTHOOK(11);
							tr1 = F1287_11287(loc1);
							tr2 = F1287_11287(loc2);
							Result = F1102_9135(RTCW(tr1), tr2);
						} else {
							RTHOOK(12);
							tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_5_);
							tr2 = *(EIF_REFERENCE *)(loc2 + _REFACS_5_);
							Result = (EIF_BOOLEAN) RTEQ(tr1, tr2);
						}
					}
				} else {
					RTHOOK(13);
					RTHOOK(14);
					RTLE;
					RTEE;
					return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			}
		}
	}
	RTHOOK(15);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.hash_code */
EIF_INTEGER_32 F1101_9079 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hash_code", 1100, Current, 0, 0, 13079);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	Result = F1078_8174(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_TARGET}.process */
void F1101_9080 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("process", 1100, Current, 0, 1, 13080);
	RTHOOK(1);
	F1295_11473(RTCW(arg1), Current);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit521 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
