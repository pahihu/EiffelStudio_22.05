/*
 * Code for class INTEGER_32
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in546.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTEGER_32}.is_less */
EIF_BOOLEAN F1220_9765 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_less", 1219, Current, 0, 1, 16063);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	Result = F1218_9702(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.plus */
EIF_INTEGER_32 F1220_9766 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("plus", 1219, Current, 0, 1, 16064);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1218_9712(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.minus */
EIF_INTEGER_32 F1220_9767 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("minus", 1219, Current, 0, 1, 16065);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1218_9713(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.product */
EIF_INTEGER_32 F1220_9768 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("product", 1219, Current, 0, 1, 16066);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1218_9714(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.quotient */
EIF_REAL_64 F1220_9769 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("quotient", 1219, Current, 0, 1, 16067);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	Result = F1218_9715(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.opposite */
EIF_INTEGER_32 F1220_9771 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("opposite", 1219, Current, 0, 0, 16069);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_INTEGER_32 *)F1218_9717(Current);
}

/* {INTEGER_32}.integer_quotient */
EIF_INTEGER_32 F1220_9772 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_quotient", 1219, Current, 0, 1, 16070);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1218_9718(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.integer_remainder */
EIF_INTEGER_32 F1220_9773 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_remainder", 1219, Current, 0, 1, 16071);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1218_9719(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.power */
EIF_REAL_64 F1220_9774 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("power", 1219, Current, 0, 1, 16072);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_64) F1218_9720(Current, arg1);
}

/* {INTEGER_32}.as_natural_8 */
EIF_NATURAL_8 F1220_9775 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_8", 1219, Current, 0, 0, 16073);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_8) F1218_9725(Current);
}

/* {INTEGER_32}.as_natural_32 */
EIF_NATURAL_32 F1220_9777 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_32", 1219, Current, 0, 0, 16075);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_32) F1218_9727(Current);
}

/* {INTEGER_32}.as_natural_64 */
EIF_NATURAL_64 F1220_9778 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_64", 1219, Current, 0, 0, 16076);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_64) F1218_9728(Current);
}

/* {INTEGER_32}.as_integer_32 */
EIF_INTEGER_32 F1220_9781 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_32", 1219, Current, 0, 0, 16079);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F1218_9731(Current);
}

/* {INTEGER_32}.as_integer_64 */
EIF_INTEGER_64 F1220_9782 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_64", 1219, Current, 0, 0, 16080);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_64) F1218_9732(Current);
}

/* {INTEGER_32}.to_double */
EIF_REAL_64 F1220_9784 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_double", 1219, Current, 0, 0, 16082);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_64) F1218_9743(Current);
}

/* {INTEGER_32}.to_character_8 */
EIF_CHARACTER_8 F1220_9785 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_8", 1219, Current, 0, 0, 16083);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) F1218_9751(Current);
}

/* {INTEGER_32}.to_character_32 */
EIF_CHARACTER_32 F1220_9786 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_32", 1219, Current, 0, 0, 16084);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_32) F1218_9752(Current);
}

/* {INTEGER_32}.bit_and */
EIF_INTEGER_32 F1220_9787 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_and", 1219, Current, 0, 1, 16085);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1218_9753(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.bit_or */
EIF_INTEGER_32 F1220_9788 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_or", 1219, Current, 0, 1, 16086);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1218_9754(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.bit_xor */
EIF_INTEGER_32 F1220_9789 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_xor", 1219, Current, 0, 1, 16087);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1219, 0x00).id, 1219, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = arg1;
	tr1 = F1218_9755(Current, tr1);
	Result = *(EIF_INTEGER_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_32}.bit_not */
EIF_INTEGER_32 F1220_9790 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("bit_not", 1219, Current, 0, 0, 16088);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_INTEGER_32 *)F1218_9756(Current);
}

/* {INTEGER_32}.bit_shift_left */
EIF_INTEGER_32 F1220_9791 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("bit_shift_left", 1219, Current, 0, 1, 16089);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_INTEGER_32 *)F1218_9758(Current, arg1);
}

/* {INTEGER_32}.bit_shift_right */
EIF_INTEGER_32 F1220_9792 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("bit_shift_right", 1219, Current, 0, 1, 16090);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_INTEGER_32 *)F1218_9759(Current, arg1);
}

void EIF_Minit546 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
