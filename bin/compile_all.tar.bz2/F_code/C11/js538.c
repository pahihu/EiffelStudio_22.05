/*
 * Code for class JSON_NULL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js538.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_NULL}.hash_code */
EIF_INTEGER_32 F1211_9525 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hash_code", 1210, Current, 0, 0, 15801);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(674,F1211_9529, (Current));
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6582[Dtype(RTCW(tr1))-1025])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_NULL}.representation */
EIF_REFERENCE F1211_9526 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("representation", 1210, Current, 0, 0, 15802);
	RTGC;
	RTHOOK(1);
	Result = RTMS_EX_H("null",4,1853189228);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_NULL}.null_value */

EIF_REFERENCE F1211_9529 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (674,RTMS_EX_H("null",4,1853189228));
}

void EIF_Minit538 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
