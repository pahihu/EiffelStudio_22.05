
#ifndef _C11_co531_
#define _C11_co531_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1159_9389(EIF_REFERENCE, EIF_REFERENCE);
extern void F1159_9391(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit531(void);
extern void F852_6768(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1087_8618(EIF_REFERENCE);
extern void F852_6722(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1085_8463(EIF_REFERENCE, EIF_REFERENCE);
extern long O7850[];
extern long O7851[];

#ifdef __cplusplus
}
#endif

#endif
