/*
 * Code for class JSON_NUMBER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js540.h"
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_NUMBER}.make_integer */
void F1213_9560 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_integer", 1212, Current, 0, 1, 15839);
	RTGC;
	RTHOOK(1);
	tr1 = eif_out__i8_s1(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {JSON_NUMBER}.make_real */
void F1213_9562 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_real", 1212, Current, 0, 1, 15841);
	RTGC;
	RTHOOK(1);
	tb1 = eif_is_nan_real_64 (arg1);
	if (tb1) {
		RTHOOK(2);
		tr1 = RTOUCR(666,F1213_9564, (Current));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(3);
		tb1 = eif_is_negative_infinity_real_64 (arg1);
		if (tb1) {
			RTHOOK(4);
			tr1 = RTOUCR(667,F1213_9565, (Current));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(5);
			tb1 = eif_is_positive_infinity_real_64 (arg1);
			if (tb1) {
				RTHOOK(6);
				tr1 = RTOUCR(668,F1213_9566, (Current));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
			} else {
				RTHOOK(7);
				tr1 = eif_out__r8_s1(arg1);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
			}
		}
	}
	RTHOOK(8);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {JSON_NUMBER}.nan_real_value */
static EIF_REFERENCE F1213_9564_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(666)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("nan_real_value", 1212, Current, 0, 0, 15843);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1081, 0x01).id, 1081, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("NaN",3,5136718);
	F1081_8297(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1213_9564 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(666,F1213_9564_body,(Current));
}

/* {JSON_NUMBER}.negative_infinity_real_value */
static EIF_REFERENCE F1213_9565_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(667)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("negative_infinity_real_value", 1212, Current, 0, 0, 15844);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1081, 0x01).id, 1081, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("-Infinity",9,2107636601);
	F1081_8297(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1213_9565 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(667,F1213_9565_body,(Current));
}

/* {JSON_NUMBER}.positive_infinity_real_value */
static EIF_REFERENCE F1213_9566_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(668)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("positive_infinity_real_value", 1212, Current, 0, 0, 15845);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1081, 0x01).id, 1081, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Infinity",8,1600908409);
	F1081_8297(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1213_9566 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(668,F1213_9566_body,(Current));
}

/* {JSON_NUMBER}.hash_code */
EIF_INTEGER_32 F1213_9569 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hash_code", 1212, Current, 0, 0, 15848);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6582[Dtype(RTCW(tr1))-1025])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_NUMBER}.representation */
EIF_REFERENCE F1213_9570 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("representation", 1212, Current, 1, 0, 15849);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	tb1 = '\0';
	if (F1213_9578(Current)) {
		tb2 = '\01';
		tb3 = '\01';
		if (!(EIF_BOOLEAN)(loc1 == RTOUCR(666,F1213_9564, (Current)))) {
			tb3 = (EIF_BOOLEAN)(loc1 == RTOUCR(667,F1213_9565, (Current)));
		}
		if (!tb3) {
			tb2 = (EIF_BOOLEAN)(loc1 == RTOUCR(668,F1213_9566, (Current)));
		}
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tr1 = RTLNS(eif_new_type(1210, 0x01).id, 1210, _OBJSIZ_0_0_0_0_0_0_0_0_);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1211_9526(RTCW(tr1));
	} else {
		RTHOOK(5);
		tr1 = F1078_8218(RTCW(loc1));
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {JSON_NUMBER}.is_real */
EIF_BOOLEAN F1213_9578 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_real", 1212, Current, 0, 0, 15857);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) == ((EIF_INTEGER_32) 2L));
}

/* {JSON_NUMBER}.is_equal */
EIF_BOOLEAN F1213_9580 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("is_equal", 1212, Current, 0, 1, 15859);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-2])(tr1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit540 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
