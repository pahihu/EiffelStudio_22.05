/*
 * Code for class I18N_POSIX_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1108.h"
#include "eif_langinfo.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F132_1751
static EIF_INTEGER_32 inline_F132_1751 (void)
{
	return ABDAY_1;
	;
}
#define INLINE_F132_1751
#endif
#ifndef INLINE_F132_1758
static EIF_INTEGER_32 inline_F132_1758 (void)
{
	return DAY_1;
	;
}
#define INLINE_F132_1758
#endif
#ifndef INLINE_F132_1765
static EIF_INTEGER_32 inline_F132_1765 (void)
{
	return ABMON_1;
	;
}
#define INLINE_F132_1765
#endif
#ifndef INLINE_F132_1777
static EIF_INTEGER_32 inline_F132_1777 (void)
{
	return MON_1;
	;
}
#define INLINE_F132_1777
#endif
#ifndef INLINE_F132_1789
static EIF_INTEGER_32 inline_F132_1789 (void)
{
	return AM_STR;
	;
}
#define INLINE_F132_1789
#endif
#ifndef INLINE_F132_1790
static EIF_INTEGER_32 inline_F132_1790 (void)
{
	return PM_STR;
	;
}
#define INLINE_F132_1790
#endif
#ifndef INLINE_F132_1791
static EIF_INTEGER_32 inline_F132_1791 (void)
{
	return D_T_FMT;
	;
}
#define INLINE_F132_1791
#endif
#ifndef INLINE_F132_1792
static EIF_INTEGER_32 inline_F132_1792 (void)
{
	return D_FMT;
	;
}
#define INLINE_F132_1792
#endif
#ifndef INLINE_F132_1793
static EIF_INTEGER_32 inline_F132_1793 (void)
{
	return T_FMT;
	;
}
#define INLINE_F132_1793
#endif
#ifndef INLINE_F132_1795
static EIF_INTEGER_32 inline_F132_1795 (void)
{
	return CRNCYSTR;
	;
}
#define INLINE_F132_1795
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_POSIX_CONSTANTS}.abday_1 */
EIF_INTEGER_32 F132_1751 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("abday_1", 131, Current, 0, 0, 1991);
	Result = inline_F132_1751 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.day_1 */
EIF_INTEGER_32 F132_1758 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("day_1", 131, Current, 0, 0, 1998);
	Result = inline_F132_1758 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.abmon_1 */
EIF_INTEGER_32 F132_1765 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("abmon_1", 131, Current, 0, 0, 2005);
	Result = inline_F132_1765 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.mon_1 */
EIF_INTEGER_32 F132_1777 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("mon_1", 131, Current, 0, 0, 1972);
	Result = inline_F132_1777 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.am_str */
EIF_INTEGER_32 F132_1789 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("am_str", 131, Current, 0, 0, 1984);
	Result = inline_F132_1789 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.pm_str */
EIF_INTEGER_32 F132_1790 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pm_str", 131, Current, 0, 0, 1985);
	Result = inline_F132_1790 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.d_t_fmt */
EIF_INTEGER_32 F132_1791 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("d_t_fmt", 131, Current, 0, 0, 1986);
	Result = inline_F132_1791 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.d_fmt */
EIF_INTEGER_32 F132_1792 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("d_fmt", 131, Current, 0, 0, 1987);
	Result = inline_F132_1792 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.t_fmt */
EIF_INTEGER_32 F132_1793 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("t_fmt", 131, Current, 0, 0, 1988);
	Result = inline_F132_1793 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_POSIX_CONSTANTS}.crncystr */
EIF_INTEGER_32 F132_1795 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("crncystr", 131, Current, 0, 0, 1990);
	Result = inline_F132_1795 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit108 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
