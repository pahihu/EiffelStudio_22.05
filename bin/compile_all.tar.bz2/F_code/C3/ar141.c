/*
 * Code for class ARGUMENT_OPTION_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar141.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_OPTION_PARSER}.make */
void F165_2238 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 164, Current, 0, 1, 2441);
	RTHOOK(1);
	F164_2138(Current, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
	RTHOOK(3);
	RTEE;
}

/* {ARGUMENT_OPTION_PARSER}.execute_noop */
void F165_2239 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("execute_noop", 164, Current, 0, 1, 2442);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
		*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
		*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_));
	RTHOOK(2);
	RTEE;
}

void EIF_Minit141 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
