
#ifndef _C3_in146_
#define _C3_in146_

#ifdef __cplusplus
extern "C" {
#endif

extern void F170_2316(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit146(void);
extern char *(*R5498[])();
extern char *(*R5465[])();
extern char *(*R5504[])();
extern char *(*R5506[])();
extern char *(*R5476[])();
extern char *(*R5478[])();
extern char *(*R3421[])();

#ifdef __cplusplus
}
#endif

#endif
