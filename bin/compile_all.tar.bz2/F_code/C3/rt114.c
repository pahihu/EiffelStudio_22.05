/*
 * Code for class RT_DEBUGGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rt114.h"
#include "eif_main.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F138_1919
static void inline_F138_1919 (EIF_BOOLEAN arg1)
{
	#ifdef WORKBENCH
	set_debug_mode (arg1 ? 1 : 0);
#endif
	;
}
#define INLINE_F138_1919
#endif
#ifndef INLINE_F138_1920
static int inline_F138_1920 (void)
{
	#ifdef WORKBENCH
	return EIF_TEST(is_debug_mode());
#else
	return EIF_FALSE;
#endif
	;
}
#define INLINE_F138_1920
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RT_DEBUGGER}.disable_debug */
void F138_1918 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("disable_debug", 137, Current, 0, 0, 2138);
	RTHOOK(1);
	inline_F138_1919((EIF_BOOLEAN) 0);
	RTHOOK(2);
	RTEE;
}

/* {RT_DEBUGGER}.set_debug_state */
void F138_1919 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_debug_state", 137, Current, 0, 1, 2139);
	inline_F138_1919 ((EIF_BOOLEAN) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {RT_DEBUGGER}.debug_state */
EIF_BOOLEAN F138_1920 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("debug_state", 137, Current, 0, 0, 2140);
	Result = EIF_TEST(inline_F138_1920 ());
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit114 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
