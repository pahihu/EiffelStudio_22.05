/*
 * Code for class INI_DEFAULT_NODE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in149.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INI_DEFAULT_NODE_FACTORY}.new_id_node */
EIF_REFERENCE F173_2333 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_id_node", 172, Current, 0, 2, 2522);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(302, 0x01).id, 302, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F300_3660(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {INI_DEFAULT_NODE_FACTORY}.new_value_node */
EIF_REFERENCE F173_2334 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_value_node", 172, Current, 0, 2, 2523);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(301, 0x01).id, 301, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F300_3660(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {INI_DEFAULT_NODE_FACTORY}.new_symbol_node */
EIF_REFERENCE F173_2335 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_symbol_node", 172, Current, 0, 2, 2524);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(300, 0x01).id, 300, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F300_3660(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {INI_DEFAULT_NODE_FACTORY}.new_section_node */
EIF_REFERENCE F173_2336 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_section_node", 172, Current, 0, 3, 2525);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(297, 0x01).id, 297, _OBJSIZ_6_0_0_0_0_0_0_0_);
	F298_3645(RTCW(tr1), arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {INI_DEFAULT_NODE_FACTORY}.new_property_node */
EIF_REFERENCE F173_2337 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_property_node", 172, Current, 0, 3, 2526);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(298, 0x01).id, 298, _OBJSIZ_4_0_0_0_0_0_0_0_);
	F299_3653(RTCW(tr1), arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {INI_DEFAULT_NODE_FACTORY}.new_literal_node */
EIF_REFERENCE F173_2338 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_literal_node", 172, Current, 0, 2, 2527);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(303, 0x01).id, 303, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F300_3660(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit149 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
