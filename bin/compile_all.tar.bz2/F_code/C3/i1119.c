/*
 * Code for class I18N_DATASOURCE_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1119.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_DATASOURCE_MANAGER}.make */
void F143_1946 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("make", 142, Current, 0, 1, 2161);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1086, 1).id);
	F1087_8537(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATASOURCE_MANAGER}.has_locale */
EIF_BOOLEAN F143_1950 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("has_locale", 142, Current, 0, 1, 2162);
	RTGC;
	RTHOOK(1);
	tr1 = F144_1955(Current);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5454[Dtype(RTCW(tr1))-759])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_DATASOURCE_MANAGER}.has_language */
EIF_BOOLEAN F143_1951 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("has_language", 142, Current, 0, 1, 2163);
	RTGC;
	RTHOOK(1);
	tr1 = F144_1956(Current);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5454[Dtype(RTCW(tr1))-759])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit119 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
