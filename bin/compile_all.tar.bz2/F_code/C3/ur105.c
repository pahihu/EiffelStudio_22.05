/*
 * Code for class URI_PERCENT_ENCODER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ur105.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {URI_PERCENT_ENCODER}.append_percent_encoded_string_to */
void F129_1695 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("append_percent_encoded_string_to", 128, Current, 2, 2, 1932);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[Dtype(RTCW(arg1))-1081])(arg1);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(4);
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, loc1);
		F129_1700(Current, tu4_1, arg2);
		RTHOOK(5);
		loc1++;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {URI_PERCENT_ENCODER}.append_path_segment_encoded_string_to */
void F129_1698 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("append_path_segment_encoded_string_to", 128, Current, 2, 2, 1935);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[Dtype(RTCW(arg1))-1081])(arg1);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(4);
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, loc1);
		F129_1703(Current, tu4_1, arg2);
		RTHOOK(5);
		loc1++;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {URI_PERCENT_ENCODER}.append_www_form_url_encoded_string_to */
void F129_1699 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("append_www_form_url_encoded_string_to", 128, Current, 2, 2, 1936);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[Dtype(RTCW(arg1))-1081])(arg1);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(4);
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, loc1);
		switch (tu4_1) {
			case 32U:
				RTHOOK(5);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[Dtype(RTCW(arg2))-1082])(arg2, (EIF_NATURAL_32) ((EIF_INTEGER_32) 43L));
				break;
			default:
				RTHOOK(6);
				tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, loc1);
				F129_1700(Current, tu4_1, arg2);
				break;
		}
		RTHOOK(7);
		loc1++;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {URI_PERCENT_ENCODER}.append_encoded_character_code_to */
void F129_1700 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("append_encoded_character_code_to", 128, Current, 0, 2, 1937);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 48L) <= arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 57L))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 65L) <= arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 90L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 97L) <= arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 122L))))) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[Dtype(RTCW(arg2))-1082])(arg2, arg1);
	} else {
		RTHOOK(3);
		switch (arg1) {
			case 45U:
			case 46U:
			case 95U:
			case 126U:
				RTHOOK(4);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[Dtype(RTCW(arg2))-1082])(arg2, arg1);
				break;
			case 33U:
			case 36U:
			case 37U:
			case 38U:
			case 39U:
			case 40U:
			case 41U:
			case 42U:
			case 43U:
			case 44U:
			case 58U:
			case 59U:
			case 61U:
			case 64U:
				RTHOOK(5);
				F129_1704(Current, arg1, arg2);
				break;
			default:
				RTHOOK(6);
				F129_1704(Current, arg1, arg2);
				break;
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {URI_PERCENT_ENCODER}.append_path_segment_encoded_character_code_to */
void F129_1703 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	
	
	RTEAA("append_path_segment_encoded_character_code_to", 128, Current, 0, 2, 1940);
	RTHOOK(1);
	F129_1700(Current, arg1, arg2);
	RTHOOK(2);
	RTEE;
}

/* {URI_PERCENT_ENCODER}.append_percent_encoded_character_code_to */
void F129_1704 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("append_percent_encoded_character_code_to", 128, Current, 0, 2, 1914);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L))) {
		RTHOOK(2);
		F129_1706(Current, arg1, arg2);
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (arg1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
			RTHOOK(4);
			F129_1706(Current, arg1, arg2);
		} else {
			RTHOOK(5);
			F129_1705(Current, arg1, arg2);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {URI_PERCENT_ENCODER}.append_percent_encoded_ascii_character_code_to */
void F129_1705 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("append_percent_encoded_ascii_character_code_to", 128, Current, 1, 2, 1915);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L))) {
		RTHOOK(2);
		F129_1706(Current, arg1, arg2);
	} else {
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) arg1;
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[Dtype(RTCW(arg2))-1082])(arg2, (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L));
		RTHOOK(5);
		tr1 = RTOUCR(657,F129_1718, (Current));
		ti4_1 = eif_bit_shift_right(loc1,((EIF_INTEGER_32) 4L));
		/* INLINED CODE (SPECIAL.item) */
		tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1));
		/* END INLINED CODE */
		tu4_1 = tu4_2;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[Dtype(RTCW(arg2))-1082])(arg2, tu4_1);
		RTHOOK(6);
		tr1 = RTOUCR(657,F129_1718, (Current));
		ti4_1 = eif_bit_and(loc1,((EIF_INTEGER_32) 15L));
		/* INLINED CODE (SPECIAL.item) */
		tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1));
		/* END INLINED CODE */
		tu4_1 = tu4_2;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[Dtype(RTCW(arg2))-1082])(arg2, tu4_1);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {URI_PERCENT_ENCODER}.append_percent_encoded_unicode_character_code_to */
void F129_1706 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("append_percent_encoded_unicode_character_code_to", 128, Current, 0, 2, 1916);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
		RTHOOK(2);
		F129_1705(Current, arg1, arg2);
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 2047L))) {
			RTHOOK(4);
			tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 6L));
			tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 192L));
			F129_1705(Current, tu4_1, arg2);
			RTHOOK(5);
			tu4_1 = eif_bit_and(arg1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
			tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
			F129_1705(Current, tu4_1, arg2);
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 65535L))) {
				RTHOOK(7);
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 12L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 224L));
				F129_1705(Current, tu4_1, arg2);
				RTHOOK(8);
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 6L));
				tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F129_1705(Current, tu4_1, arg2);
				RTHOOK(9);
				tu4_1 = eif_bit_and(arg1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F129_1705(Current, tu4_1, arg2);
			} else {
				RTHOOK(10);
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 18L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 240L));
				F129_1705(Current, tu4_1, arg2);
				RTHOOK(11);
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 12L));
				tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F129_1705(Current, tu4_1, arg2);
				RTHOOK(12);
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 6L));
				tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F129_1705(Current, tu4_1, arg2);
				RTHOOK(13);
				tu4_1 = eif_bit_and(arg1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F129_1705(Current, tu4_1, arg2);
			}
		}
	}
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {URI_PERCENT_ENCODER}.append_percent_decoded_string_to */
void F129_1707 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc6);
	RTLR(1,arg2);
	RTLR(2,loc4);
	RTLR(3,Current);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTEAA("append_percent_decoded_string_to", 128, Current, 6, 2, 1917);
	RTGC;
	RTHOOK(1);
	loc6 = arg2;
	loc6 = RTRV(eif_new_type(1086, 0x01),loc6);
	loc5 = (EIF_BOOLEAN) EIF_TEST(loc6);
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,192,1219,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc4 = RTLNS(typres0.id, 192, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	F193_2535(RTCW(loc4), loc1);
	RTHOOK(4);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[Dtype(RTCW(arg1))-1081])(arg1);
	for (;;) {
		RTHOOK(5);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(6);
		loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, loc1);
		RTHOOK(7);
		switch (loc3) {
			case 43U:
				RTHOOK(8);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[Dtype(RTCW(arg2))-1082])(arg2, (EIF_NATURAL_32) ((EIF_INTEGER_32) 32L));
				break;
			case 37U:
				RTHOOK(9);
				if ((EIF_BOOLEAN)(loc1 == loc2)) {
					RTHOOK(10);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[Dtype(RTCW(arg2))-1082])(arg2, loc3);
				} else {
					RTHOOK(11);
					if (loc5) {
						RTHOOK(12);
						F193_2536(RTCW(loc4), loc1);
						RTHOOK(13);
						loc3 = F129_1709(Current, arg1, loc4);
						RTHOOK(14);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[Dtype(RTCW(arg2))-1082])(arg2, loc3);
						RTHOOK(15);
						loc1 = *(EIF_INTEGER_32 *)(RTCW(loc4) + O2464[Dtype(loc4)-189]);
					} else {
						RTHOOK(16);
						F193_2536(RTCW(loc4), loc1);
						RTHOOK(17);
						loc3 = F129_1708(Current, arg1, loc4);
						RTHOOK(18);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[Dtype(RTCW(arg2))-1082])(arg2, loc3);
						RTHOOK(19);
						loc1 = *(EIF_INTEGER_32 *)(RTCW(loc4) + O2464[Dtype(loc4)-189]);
					}
				}
				break;
			default:
				RTHOOK(20);
				if ((EIF_BOOLEAN) (loc3 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
					RTHOOK(21);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[Dtype(RTCW(arg2))-1082])(arg2, loc3);
				} else {
					RTHOOK(22);
					if (loc5) {
						RTHOOK(23);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R7001[Dtype(RTCW(arg2))-1082])(arg2, loc3);
					} else {
						RTHOOK(24);
						F129_1704(Current, loc3, arg2);
					}
				}
				break;
		}
		RTHOOK(25);
		loc1++;
	}
	RTHOOK(26);
	RTLE;
	RTEE;
}

/* {URI_PERCENT_ENCODER}.next_percent_decoded_character_code */
EIF_NATURAL_32 F129_1708 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc6 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("next_percent_decoded_character_code", 128, Current, 8, 2, 1918);
	RTGC;
	RTHOOK(1);
	loc7 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O2464[Dtype(arg2)-189]);
	RTHOOK(2);
	loc1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(3);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 85L)) || (EIF_BOOLEAN)(loc1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 117L)))) {
		RTHOOK(4);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 2L));
		RTHOOK(5);
		loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[Dtype(RTCW(arg1))-1081])(arg1);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 > loc3) || loc4)) break;
			RTHOOK(7);
			loc1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, loc2);
			RTHOOK(8);
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 48L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 57L)));
			RTHOOK(9);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc8 || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 97L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 102L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 65L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 70L))))) {
				RTHOOK(10);
				loc6 *= (EIF_NATURAL_32) ((EIF_INTEGER_32) 16L);
				RTHOOK(11);
				if (loc8) {
					RTHOOK(12);
					loc6 += (EIF_NATURAL_32) (loc1 - (EIF_NATURAL_32) ((EIF_INTEGER_32) 48L));
				} else {
					RTHOOK(13);
					if ((EIF_BOOLEAN) (loc1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 70L))) {
						RTHOOK(14);
						loc6 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) (loc6 + (EIF_NATURAL_32) (loc1 - (EIF_NATURAL_32) ((EIF_INTEGER_32) 97L))) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 10L));
					} else {
						RTHOOK(15);
						loc6 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) (loc6 + (EIF_NATURAL_32) (loc1 - (EIF_NATURAL_32) ((EIF_INTEGER_32) 65L))) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 10L));
					}
				}
				RTHOOK(16);
				loc2++;
			} else {
				RTHOOK(17);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(18);
				loc2--;
			}
		}
		RTHOOK(19);
		F193_2536(RTCW(arg2), loc2);
		RTHOOK(20);
		RTHOOK(21);
		RTLE;
		RTEE;
		return (EIF_NATURAL_32) loc6;
	} else {
		RTHOOK(22);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6982[Dtype(RTCW(arg1))-1081])(arg1, (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 2L)));
		loc5 = F129_1720(Current, tr1);
		RTHOOK(23);
		Result = (EIF_NATURAL_32) loc5;
		RTHOOK(24);
		F193_2536(RTCW(arg2), (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 2L)));
	}
	RTHOOK(25);
	RTLE;
	RTEE;
	return Result;
}

/* {URI_PERCENT_ENCODER}.next_percent_decoded_unicode_character_code */
EIF_NATURAL_32 F129_1709 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc6 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc7 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc8);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("next_percent_decoded_unicode_character_code", 128, Current, 8, 2, 1919);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,192,1219,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc8 = RTLNS(typres0.id, 192, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O2464[Dtype(arg2)-189]);
	F193_2535(RTCW(loc8), ti4_1);
	RTHOOK(2);
	loc4 = F129_1708(Current, arg1, loc8);
	RTHOOK(3);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2464[Dtype(loc8)-189]);
	RTHOOK(4);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[Dtype(RTCW(arg1))-1081])(arg1);
	RTHOOK(5);
	Result = (EIF_NATURAL_32) loc4;
	RTHOOK(6);
	F193_2536(RTCW(arg2), loc2);
	RTHOOK(7);
	if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
		RTHOOK(8);
		RTHOOK(9);
		RTLE;
		RTEE;
		return (EIF_NATURAL_32) loc4;
	} else {
		RTHOOK(10);
		if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 223L))) {
			RTHOOK(11);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) <= loc1)) {
				RTHOOK(12);
				loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
				RTHOOK(13);
				if ((EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L))) {
					RTHOOK(14);
					F193_2536(RTCW(loc8), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					RTHOOK(15);
					loc5 = F129_1708(Current, arg1, loc8);
					RTHOOK(16);
					loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2464[Dtype(loc8)-189]);
					RTHOOK(17);
					tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 31L));
					tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 6L));
					tu4_2 = eif_bit_and(loc5,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
					Result = eif_bit_or(tu4_1,tu4_2);
					RTHOOK(18);
					F193_2536(RTCW(arg2), loc2);
				}
			}
		} else {
			RTHOOK(19);
			if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 239L))) {
				RTHOOK(20);
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) <= loc1)) {
					RTHOOK(21);
					loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					RTHOOK(22);
					if ((EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L))) {
						RTHOOK(23);
						F193_2536(RTCW(loc8), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
						RTHOOK(24);
						loc5 = F129_1708(Current, arg1, loc8);
						RTHOOK(25);
						loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2464[Dtype(loc8)-189]);
						RTHOOK(26);
						if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) <= loc1)) {
							RTHOOK(27);
							loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
							RTHOOK(28);
							if ((EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L))) {
								RTHOOK(29);
								F193_2536(RTCW(loc8), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
								RTHOOK(30);
								loc6 = F129_1708(Current, arg1, loc8);
								RTHOOK(31);
								loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2464[Dtype(loc8)-189]);
								RTHOOK(32);
								tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 15L));
								tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 12L));
								tu4_2 = eif_bit_and(loc5,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
								tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 6L));
								tu4_1 = eif_bit_or(tu4_1,tu4_2);
								tu4_2 = eif_bit_and(loc6,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
								Result = eif_bit_or(tu4_1,tu4_2);
								RTHOOK(33);
								F193_2536(RTCW(arg2), loc2);
							}
						}
					}
				}
			} else {
				RTHOOK(34);
				if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 247L))) {
					RTHOOK(35);
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) <= loc1)) {
						RTHOOK(36);
						loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
						RTHOOK(37);
						if ((EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L))) {
							RTHOOK(38);
							F193_2536(RTCW(loc8), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
							RTHOOK(39);
							loc5 = F129_1708(Current, arg1, loc8);
							RTHOOK(40);
							loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2464[Dtype(loc8)-189]);
							RTHOOK(41);
							if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) <= loc1)) {
								RTHOOK(42);
								loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
								RTHOOK(43);
								if ((EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L))) {
									RTHOOK(44);
									F193_2536(RTCW(loc8), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
									RTHOOK(45);
									loc6 = F129_1708(Current, arg1, loc8);
									RTHOOK(46);
									loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2464[Dtype(loc8)-189]);
									RTHOOK(47);
									if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) <= loc1)) {
										RTHOOK(48);
										loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6904[Dtype(RTCW(arg1))-1081])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
										RTHOOK(49);
										if ((EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L))) {
											RTHOOK(50);
											F193_2536(RTCW(loc8), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
											RTHOOK(51);
											loc7 = F129_1708(Current, arg1, loc8);
											RTHOOK(52);
											loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2464[Dtype(loc8)-189]);
											RTHOOK(53);
											F193_2536(RTCW(arg2), loc2);
											RTHOOK(54);
											tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 7L));
											tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 18L));
											tu4_2 = eif_bit_and(loc5,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
											tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 12L));
											tu4_1 = eif_bit_or(tu4_1,tu4_2);
											tu4_2 = eif_bit_and(loc6,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
											tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 6L));
											tu4_1 = eif_bit_or(tu4_1,tu4_2);
											tu4_2 = eif_bit_and(loc7,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
											Result = eif_bit_or(tu4_1,tu4_2);
										}
									}
								}
							}
						}
					}
				} else {
					RTHOOK(55);
					RTHOOK(56);
					RTLE;
					RTEE;
					return (EIF_NATURAL_32) loc4;
				}
			}
		}
	}
	RTHOOK(57);
	RTLE;
	RTEE;
	return Result;
}

/* {URI_PERCENT_ENCODER}.is_hexa_decimal_character */
EIF_BOOLEAN F129_1710 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_hexa_decimal_character", 128, Current, 0, 1, 1920);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	tb1 = '\01';
	tb2 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'a';
	if ((EIF_BOOLEAN) (tw1 <= arg1)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'f';
		tb2 = (EIF_BOOLEAN) (arg1 <= tw1);
	}
	if (!tb2) {
		tb2 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'A';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'F';
			tb2 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		tb1 = tb2;
	}
	if (!tb1) {
		tb1 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '0';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '9';
			tb1 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {URI_PERCENT_ENCODER}.is_alpha_or_digit_character */
EIF_BOOLEAN F129_1711 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_alpha_or_digit_character", 128, Current, 0, 1, 1921);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	tb1 = '\01';
	tb2 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'a';
	if ((EIF_BOOLEAN) (tw1 <= arg1)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'z';
		tb2 = (EIF_BOOLEAN) (arg1 <= tw1);
	}
	if (!tb2) {
		tb2 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'A';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Z';
			tb2 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		tb1 = tb2;
	}
	if (!tb1) {
		tb1 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '0';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '9';
			tb1 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {URI_PERCENT_ENCODER}.is_alpha_character */
EIF_BOOLEAN F129_1712 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_alpha_character", 128, Current, 0, 1, 1922);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'a';
	if ((EIF_BOOLEAN) (tw1 <= arg1)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'z';
		tb1 = (EIF_BOOLEAN) (arg1 <= tw1);
	}
	if (!tb1) {
		tb1 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'A';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Z';
			tb1 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {URI_PERCENT_ENCODER}.is_unreserved_character */
EIF_BOOLEAN F129_1714 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_unreserved_character", 128, Current, 0, 1, 1924);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'a';
	if ((EIF_BOOLEAN) (tw1 <= arg1)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'z';
		tb3 = (EIF_BOOLEAN) (arg1 <= tw1);
	}
	if (!tb3) {
		tb3 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'A';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Z';
			tb3 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		tb2 = tb3;
	}
	if (!tb2) {
		tb2 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '0';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '9';
			tb2 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		switch (arg1) {
			case (EIF_CHARACTER_8) '-':
			case (EIF_CHARACTER_8) '.':
			case (EIF_CHARACTER_8) '_':
			case (EIF_CHARACTER_8) '~':
				RTHOOK(5);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {URI_PERCENT_ENCODER}.is_sub_delims_character */
EIF_BOOLEAN F129_1717 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_sub_delims_character", 128, Current, 0, 1, 1927);
	RTGC;
	RTHOOK(1);
	switch (arg1) {
		case (EIF_CHARACTER_8) '!':
		case (EIF_CHARACTER_8) '$':
		case (EIF_CHARACTER_8) '&':
		case (EIF_CHARACTER_8) '\'':
		case (EIF_CHARACTER_8) '(':
		case (EIF_CHARACTER_8) ')':
		case (EIF_CHARACTER_8) '*':
		case (EIF_CHARACTER_8) '+':
		case (EIF_CHARACTER_8) ',':
		case (EIF_CHARACTER_8) ';':
		case (EIF_CHARACTER_8) '=':
			RTHOOK(2);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			break;
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {URI_PERCENT_ENCODER}.hex_digit */
static EIF_REFERENCE F129_1718_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(657)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hex_digit", 128, Current, 0, 0, 1928);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1145,1231,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 16L),sizeof(EIF_NATURAL_32), EIF_TRUE);
	}
	F1146_9206(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 16L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 0L))) = ((EIF_NATURAL_32) 48U);
	/* END INLINED CODE */
	;
	RTHOOK(3);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 1L))) = ((EIF_NATURAL_32) 49U);
	/* END INLINED CODE */
	;
	RTHOOK(4);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 2L))) = ((EIF_NATURAL_32) 50U);
	/* END INLINED CODE */
	;
	RTHOOK(5);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 3L))) = ((EIF_NATURAL_32) 51U);
	/* END INLINED CODE */
	;
	RTHOOK(6);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 4L))) = ((EIF_NATURAL_32) 52U);
	/* END INLINED CODE */
	;
	RTHOOK(7);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 5L))) = ((EIF_NATURAL_32) 53U);
	/* END INLINED CODE */
	;
	RTHOOK(8);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 6L))) = ((EIF_NATURAL_32) 54U);
	/* END INLINED CODE */
	;
	RTHOOK(9);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 7L))) = ((EIF_NATURAL_32) 55U);
	/* END INLINED CODE */
	;
	RTHOOK(10);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 8L))) = ((EIF_NATURAL_32) 56U);
	/* END INLINED CODE */
	;
	RTHOOK(11);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 9L))) = ((EIF_NATURAL_32) 57U);
	/* END INLINED CODE */
	;
	RTHOOK(12);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 10L))) = ((EIF_NATURAL_32) 65U);
	/* END INLINED CODE */
	;
	RTHOOK(13);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 11L))) = ((EIF_NATURAL_32) 66U);
	/* END INLINED CODE */
	;
	RTHOOK(14);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 12L))) = ((EIF_NATURAL_32) 67U);
	/* END INLINED CODE */
	;
	RTHOOK(15);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 13L))) = ((EIF_NATURAL_32) 68U);
	/* END INLINED CODE */
	;
	RTHOOK(16);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 14L))) = ((EIF_NATURAL_32) 69U);
	/* END INLINED CODE */
	;
	RTHOOK(17);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 15L))) = ((EIF_NATURAL_32) 70U);
	/* END INLINED CODE */
	;
	RTOTE;
	RTHOOK(18);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F129_1718 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(657,F129_1718_body,(Current));
}

/* {URI_PERCENT_ENCODER}.hexadecimal_string_to_natural_32 */
EIF_NATURAL_32 F129_1720 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("hexadecimal_string_to_natural_32", 128, Current, 1, 1, 1930);
	RTGC;
	RTHOOK(1);
	loc1 = RTOUCR(658,F129_1721, (Current));
	RTHOOK(2);
	F271_3363(RTCW(loc1), arg1, ((EIF_INTEGER_32) 0L));
	RTHOOK(3);
	tu4_1 = F271_3375(RTCW(loc1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_NATURAL_32) tu4_1;
}

/* {URI_PERCENT_ENCODER}.ctoi_convertor */
static EIF_REFERENCE F129_1721_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(658)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("ctoi_convertor", 128, Current, 0, 0, 1931);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(270, 0x01).id, 270, _OBJSIZ_2_4_0_3_0_0_2_0_);
	F271_3357(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F270_3350(RTCW(Result), (EIF_BOOLEAN) 0);
	RTHOOK(3);
	F270_3349(RTCW(Result), (EIF_BOOLEAN) 0);
	RTOTE;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F129_1721 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(658,F129_1721_body,(Current));
}

void EIF_Minit105 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
