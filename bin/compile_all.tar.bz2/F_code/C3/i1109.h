
#ifndef _C3_i1109_
#define _C3_i1109_

#ifdef __cplusplus
extern "C" {
#endif

extern void F133_1796(EIF_REFERENCE);
extern void F133_1801(EIF_REFERENCE, EIF_REFERENCE);
extern void F133_1802(EIF_REFERENCE, EIF_REFERENCE);
extern void F133_1803(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit109(void);
extern EIF_REFERENCE F1078_8218(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
