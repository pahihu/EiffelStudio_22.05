/*
 * Code for class ARGUMENT_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar142.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_PARSER}.make */
void F166_2240 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 165, Current, 0, 0, 2462);
	RTGC;
	RTHOOK(1);
	F165_2238(Current, (EIF_BOOLEAN) 0);
	RTHOOK(2);
	F164_2172(Current, (EIF_BOOLEAN) 1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {ARGUMENT_PARSER}.new_argument_source */
EIF_REFERENCE F166_2241 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("new_argument_source", 165, Current, 0, 0, 2463);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(261, 0x01).id, 261, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = RTLNS(eif_new_type(456, 0x01).id, 456, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F262_3265(RTCW(Result), tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_PARSER}.name */

EIF_REFERENCE F166_2242 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (81,RTMS32_EX_H("C\000\000\000o\000\000\000m\000\000\000p\000\000\000i\000\000\000l\000\000\000e\000\000\000-\000\000\000A\000\000\000l\000\000\000l\000\000\000 \000\000\000T\000\000\000o\000\000\000o\000\000\000l\000\000\000",16,1884417900));
}

/* {ARGUMENT_PARSER}.version */
static EIF_REFERENCE F166_2243_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(82)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("version", 165, Current, 0, 0, 2465);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1085_8461(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 22U);
	F1087_8579(RTCW(Result), ti4_1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
	F1087_8589(RTCW(Result), tw1);
	RTHOOK(4);
	tr1 = RTLNS(eif_new_type(196, 0x01).id, 196, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOUCR(63,F197_2559, (RTCW(tr1)));
	tr1 = F1078_8224(RTCW(tr1));
	F1087_8576(RTCW(Result), tr1);
	RTOTE;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2243 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(82,F166_2243_body,(Current));
}

/* {ARGUMENT_PARSER}.copyright */
static EIF_REFERENCE F166_2244_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(83)

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("copyright", 165, Current, 0, 0, 2466);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS32_EX_H("C\000\000\000o\000\000\000p\000\000\000y\000\000\000r\000\000\000i\000\000\000g\000\000\000h\000\000\000t\000\000\000 \000\000\000E\000\000\000i\000\000\000f\000\000\000f\000\000\000e\000\000\000l\000\000\000 \000\000\000S\000\000\000o\000\000\000f\000\000\000t\000\000\000w\000\000\000a\000\000\000r\000\000\000e\000\000\000 \000\000\0002\000\000\0000\000\000\0000\000\000\0006\000\000\000-\000\000\000",31,250375213);
	tr3 = F1078_8224(RTCV(RTOUCR(84,F1346_13004, (Current))));
	tr2 = F1087_8595(tr2, tr3);
	tr3 = F1078_8224(RTMS_EX_H(". All Rights Reserved.",22,1613843246));
	tr2 = F1087_8595(RTCW(tr2), tr3);
	F1086_8516(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2244 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(83,F166_2244_body,(Current));
}

/* {ARGUMENT_PARSER}.switches */
static EIF_REFERENCE F166_2245_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(85)

	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLR(6,tr6);
	RTLIU(7);
	
	RTEAA("switches", 165, Current, 0, 0, 2467);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1026,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 9L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(1028, 0x01).id, 1028, _OBJSIZ_5_5_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(86,F166_2282, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Directory where to look for configuration files.",48,2044649774);
	F1086_8515(RTCW(tr3), tr4);
	tr4 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr5 = RTMS_EX_H("directory",9,1028911737);
	F1086_8515(RTCW(tr4), tr5);
	tr5 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr6 = RTMS_EX_H("A directory to look for ecf files",33,1968262771);
	F1086_8515(RTCW(tr5), tr6);
	F1028_7961(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0, tr4, tr5, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(3);
	tr1 = RTLNS(eif_new_type(1028, 0x01).id, 1028, _OBJSIZ_5_5_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(87,F166_2284, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Directory where projects will be compiled.",42,1112658990);
	F1086_8515(RTCW(tr3), tr4);
	tr4 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr5 = RTMS_EX_H("directory",9,1028911737);
	F1086_8515(RTCW(tr4), tr5);
	tr5 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr6 = RTMS_EX_H("A directory where the projects will be compiled",47,1493049700);
	F1086_8515(RTCW(tr5), tr6);
	F1028_7961(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0, tr4, tr5, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(4);
	tr1 = RTLNS(eif_new_type(1028, 0x01).id, 1028, _OBJSIZ_5_5_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(88,F166_2283, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Obsolete: see \"",15,1548402466);
	tr5 = RTOUCR(87,F166_2284, (Current));
	tr4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7054[Dtype(tr4)-1081])(tr4, tr5);
	tr5 = RTMS_EX_H("\" option.",9,1888951086);
	tr4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7054[Dtype(RTCW(tr4))-1081])(tr4, tr5);
	F1086_8515(RTCW(tr3), tr4);
	tr4 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr5 = RTMS_EX_H("directory",9,1028911737);
	F1086_8515(RTCW(tr4), tr5);
	tr5 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr6 = RTMS_EX_H("...",3,3026478);
	F1086_8515(RTCW(tr5), tr6);
	F1028_7961(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0, tr4, tr5, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(5);
	tr1 = RTLNS(eif_new_type(1028, 0x01).id, 1028, _OBJSIZ_5_5_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(89,F166_2285, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Directory where logs will be stored (if verbose logging is enabled).",68,1691832622);
	F1086_8515(RTCW(tr3), tr4);
	tr4 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr5 = RTMS_EX_H("directory",9,1028911737);
	F1086_8515(RTCW(tr4), tr5);
	tr5 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr6 = RTMS_EX_H("A directory where the logs will be stored",41,2118779236);
	F1086_8515(RTCW(tr5), tr6);
	F1028_7961(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0, tr4, tr5, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(6);
	tr1 = RTLNS(eif_new_type(1027, 0x01).id, 1027, _OBJSIZ_5_5_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(90,F166_2288, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Ignore file with files/targets to ignore.",41,659888174);
	F1086_8515(RTCW(tr3), tr4);
	tr4 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr5 = RTMS_EX_H("ignore.ini",10,1302130025);
	F1086_8515(RTCW(tr4), tr5);
	tr5 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr6 = RTMS_EX_H("INI file with the ignores.",26,1322767150);
	F1086_8515(RTCW(tr5), tr6);
	F1028_7961(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0, tr4, tr5, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(7);
	tr1 = RTLNS(eif_new_type(1026, 0x01).id, 1026, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(91,F166_2289, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Verbose logging of actions\?",27,425663807);
	F1086_8515(RTCW(tr3), tr4);
	F1027_7940(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(8);
	tr1 = RTLNS(eif_new_type(1026, 0x01).id, 1026, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(92,F166_2299, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Display a list of failed compilation(s) with associated log filename if available.",82,725858862);
	F1086_8515(RTCW(tr3), tr4);
	F1027_7940(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(9);
	tr1 = RTLNS(eif_new_type(1026, 0x01).id, 1026, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(93,F166_2290, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Use ecb instead of ec\?",22,1560366655);
	F1086_8515(RTCW(tr3), tr4);
	F1027_7940(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(10);
	tr1 = RTLNS(eif_new_type(1026, 0x01).id, 1026, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(94,F166_2286, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Use experimental library during compilation\?",44,2118779967);
	F1086_8515(RTCW(tr3), tr4);
	F1027_7940(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(11);
	tr1 = RTLNS(eif_new_type(1026, 0x01).id, 1026, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(95,F166_2287, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Use compatible library during compilation\?",42,1778998335);
	F1086_8515(RTCW(tr3), tr4);
	F1027_7940(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(12);
	tr1 = RTLNS(eif_new_type(1026, 0x01).id, 1026, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(96,F166_2293, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Compile generated C code\?",25,828430399);
	F1086_8515(RTCW(tr3), tr4);
	F1027_7940(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(13);
	tr1 = RTLNS(eif_new_type(1026, 0x01).id, 1026, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(97,F166_2294, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Melt the project\?",17,630473279);
	F1086_8515(RTCW(tr3), tr4);
	F1027_7940(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(14);
	tr1 = RTLNS(eif_new_type(1026, 0x01).id, 1026, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(98,F166_2295, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Freeze the project\?",19,1389328959);
	F1086_8515(RTCW(tr3), tr4);
	F1027_7940(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(15);
	tr1 = RTLNS(eif_new_type(1026, 0x01).id, 1026, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(99,F166_2296, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Finalize the project\?",21,1937451327);
	F1086_8515(RTCW(tr3), tr4);
	F1027_7940(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(16);
	tr1 = RTLNS(eif_new_type(1026, 0x01).id, 1026, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(100,F166_2291, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Clean before compilation\?",25,779970879);
	F1086_8515(RTCW(tr3), tr4);
	F1027_7940(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(17);
	tr1 = RTLNS(eif_new_type(1027, 0x01).id, 1027, _OBJSIZ_5_5_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(101,F166_2292, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Keep EIFGENs related data after compilation\? (by default they are removed)",74,1499581993);
	F1086_8515(RTCW(tr3), tr4);
	tr4 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr5 = RTMS_EX_H("status",6,1862012275);
	F1086_8515(RTCW(tr4), tr5);
	tr5 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr6 = RTMS_EX_H("{all | passed | failed}",23,106787197);
	F1086_8515(RTCW(tr5), tr6);
	F1028_7961(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0, tr4, tr5, (EIF_BOOLEAN) 1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(18);
	tr1 = RTLNS(eif_new_type(1027, 0x01).id, 1027, _OBJSIZ_5_5_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(102,F166_2297, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Comma separated option(s)",25,1752186921);
	F1086_8515(RTCW(tr3), tr4);
	tr4 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr5 = RTMS_EX_H("key=value",9,271662437);
	F1086_8515(RTCW(tr4), tr5);
	tr5 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr6 = RTMS_EX_H("dotnet=(true|false),platform=(unix|windows|macintosh|vxworks)\012...",65,1139399470);
	F1086_8515(RTCW(tr5), tr6);
	F1028_7961(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1, tr4, tr5, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTHOOK(19);
	tr1 = RTLNS(eif_new_type(1027, 0x01).id, 1027, _OBJSIZ_5_5_0_1_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTOUCR(103,F166_2298, (Current));
	F1086_8515(RTCW(tr2), tr3);
	tr3 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr4 = RTMS_EX_H("Comma separated option(s) to customize the output",49,793554292);
	F1086_8515(RTCW(tr3), tr4);
	tr4 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr5 = RTMS_EX_H("key=value",9,271662437);
	F1086_8515(RTCW(tr4), tr5);
	tr5 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr6 = RTMS_EX_H("for instance key \"template\": using any of #action, #target, #uuid, #system, #ecf , #absolute_ecf variables \012...",111,2009670190);
	F1086_8515(RTCW(tr5), tr6);
	F1028_7961(RTCW(tr1), tr2, tr3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1, tr4, tr5, (EIF_BOOLEAN) 0);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
	RTOTE;
	RTHOOK(20);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2245 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(85,F166_2245_body,(Current));
}

/* {ARGUMENT_PARSER}.location */
static EIF_REFERENCE F166_2247_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1)

	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("location", 165, Current, 1, 0, 2469);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(86,F166_2282, (Current));
	tr1 = F164_2176(Current, tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1101, 0x01).id, 1101, _OBJSIZ_2_1_0_0_0_0_0_0_);
		tr2 = F43_433(loc1);
		F1102_9104(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(3);
		tr1 = RTLNS(eif_new_type(434, 0x01).id, 434, _OBJSIZ_0_0_0_1_0_0_0_0_);
		Result = F435_5064(RTCW(tr1));
	}
	RTOTE;
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2247 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1,F166_2247_body,(Current));
}

/* {ARGUMENT_PARSER}.compilation_dir */
static EIF_REFERENCE F166_2248_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(17)

	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("compilation_dir", 165, Current, 2, 0, 2470);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(88,F166_2283, (Current));
	tr1 = F164_2176(Current, tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1101, 0x01).id, 1101, _OBJSIZ_2_1_0_0_0_0_0_0_);
		tr2 = F43_433(loc1);
		F1102_9104(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(3);
		tr1 = RTOUCR(87,F166_2284, (Current));
		tr1 = F164_2176(Current, tr1);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(4);
			tr1 = RTLNS(eif_new_type(1101, 0x01).id, 1101, _OBJSIZ_2_1_0_0_0_0_0_0_);
			tr2 = F43_433(loc2);
			F1102_9104(RTCW(tr1), tr2);
			Result = (EIF_REFERENCE) tr1;
		}
	}
	RTOTE;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2248 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(17,F166_2248_body,(Current));
}

/* {ARGUMENT_PARSER}.logs_dir */
static EIF_REFERENCE F166_2249_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(28)

	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("logs_dir", 165, Current, 1, 0, 2471);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(89,F166_2285, (Current));
	tr1 = F164_2176(Current, tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1101, 0x01).id, 1101, _OBJSIZ_2_1_0_0_0_0_0_0_);
		tr2 = F43_433(loc1);
		F1102_9104(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	}
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2249 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(28,F166_2249_body,(Current));
}

/* {ARGUMENT_PARSER}.ignore */
static EIF_REFERENCE F166_2250_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2)

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("ignore", 165, Current, 1, 0, 2472);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(90,F166_2288, (Current));
	tr1 = F164_2176(Current, tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		Result = F43_433(loc1);
	}
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2250 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2,F166_2250_body,(Current));
}

/* {ARGUMENT_PARSER}.is_ecb */
static EIF_BOOLEAN F166_2251_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 3)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_ecb", 165, Current, 0, 0, 2473);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(93,F166_2290, (Current));
	Result = F164_2159(Current, tr1);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2251 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,3,F166_2251_body,(Current));
}

/* {ARGUMENT_PARSER}.is_experiment */
static EIF_BOOLEAN F166_2252_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 20)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_experiment", 165, Current, 0, 0, 2474);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(94,F166_2286, (Current));
	Result = F164_2159(Current, tr1);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2252 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,20,F166_2252_body,(Current));
}

/* {ARGUMENT_PARSER}.is_compatible */
static EIF_BOOLEAN F166_2253_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 21)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_compatible", 165, Current, 0, 0, 2475);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(95,F166_2287, (Current));
	Result = F164_2159(Current, tr1);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2253 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,21,F166_2253_body,(Current));
}

/* {ARGUMENT_PARSER}.is_parse_only */
static EIF_BOOLEAN F166_2254_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 9)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_parse_only", 165, Current, 0, 0, 2476);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = '\0';
	tb1 = '\0';
	if ((EIF_BOOLEAN) !RTOUCB(EIF_BOOLEAN,11,F166_2262, (Current))) {
		tb1 = (EIF_BOOLEAN) !RTOUCB(EIF_BOOLEAN,12,F166_2263, (Current));
	}
	if (tb1) {
		Result = (EIF_BOOLEAN) !RTOUCB(EIF_BOOLEAN,13,F166_2264, (Current));
	}
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2254 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,9,F166_2254_body,(Current));
}

/* {ARGUMENT_PARSER}.is_log_verbose */
static EIF_BOOLEAN F166_2255_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 0)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_log_verbose", 165, Current, 0, 0, 2477);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(91,F166_2289, (Current));
	Result = F164_2159(Current, tr1);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2255 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,0,F166_2255_body,(Current));
}

/* {ARGUMENT_PARSER}.is_clean */
static EIF_BOOLEAN F166_2256_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 10)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_clean", 165, Current, 0, 0, 2478);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(100,F166_2291, (Current));
	Result = F164_2159(Current, tr1);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2256 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,10,F166_2256_body,(Current));
}

/* {ARGUMENT_PARSER}.has_keep_all */
static EIF_BOOLEAN F166_2258_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 16)

	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("has_keep_all", 165, Current, 2, 0, 2480);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = '\0';
	tr1 = RTOUCR(101,F166_2292, (Current));
	tr1 = F164_2176(Current, tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = '\01';
		tb2 = '\0';
		tr1 = F43_433(loc1);
		loc2 = tr1;
		if ((EIF_TRUE)) {
			tb3 = F1086_8532(loc2);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tr1 = F1078_8224(RTMS_EX_H("all",3,6384748));
			tb2 = F1085_8486(loc2, tr1);
			tb1 = tb2;
		}
		Result = tb1;
	}
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2258 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,16,F166_2258_body,(Current));
}

/* {ARGUMENT_PARSER}.has_keep_failed */
static EIF_BOOLEAN F166_2259_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 14)

	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("has_keep_failed", 165, Current, 2, 0, 2481);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = '\0';
	tb1 = '\0';
	tr1 = RTOUCR(101,F166_2292, (Current));
	tr1 = F164_2176(Current, tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F43_433(loc1);
		loc2 = tr1;
		tb1 = (EIF_TRUE);
	}
	if (tb1) {
		tr1 = F1078_8224(RTMS_EX_H("failed",6,1969996644));
		tb1 = F1085_8486(loc2, tr1);
		Result = tb1;
	}
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2259 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,14,F166_2259_body,(Current));
}

/* {ARGUMENT_PARSER}.has_keep_passed */
static EIF_BOOLEAN F166_2260_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 15)

	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("has_keep_passed", 165, Current, 2, 0, 2482);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = '\0';
	tb1 = '\0';
	tr1 = RTOUCR(101,F166_2292, (Current));
	tr1 = F164_2176(Current, tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F43_433(loc1);
		loc2 = tr1;
		tb1 = (EIF_TRUE);
	}
	if (tb1) {
		tr1 = F1078_8224(RTMS_EX_H("passed",6,10408548));
		tb1 = F1085_8486(loc2, tr1);
		Result = tb1;
	}
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2260 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,15,F166_2260_body,(Current));
}

/* {ARGUMENT_PARSER}.is_c_compile */
static EIF_BOOLEAN F166_2261_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 19)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_c_compile", 165, Current, 0, 0, 2483);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(96,F166_2293, (Current));
	Result = F164_2159(Current, tr1);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2261 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,19,F166_2261_body,(Current));
}

/* {ARGUMENT_PARSER}.is_melt */
static EIF_BOOLEAN F166_2262_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 11)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_melt", 165, Current, 0, 0, 2484);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(97,F166_2294, (Current));
	Result = F164_2159(Current, tr1);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2262 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,11,F166_2262_body,(Current));
}

/* {ARGUMENT_PARSER}.is_freeze */
static EIF_BOOLEAN F166_2263_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 12)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_freeze", 165, Current, 0, 0, 2485);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(98,F166_2295, (Current));
	Result = F164_2159(Current, tr1);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2263 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,12,F166_2263_body,(Current));
}

/* {ARGUMENT_PARSER}.is_finalize */
static EIF_BOOLEAN F166_2264_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 13)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_finalize", 165, Current, 0, 0, 2486);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(99,F166_2296, (Current));
	Result = F164_2159(Current, tr1);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2264 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,13,F166_2264_body,(Current));
}

/* {ARGUMENT_PARSER}.list_failures */
static EIF_BOOLEAN F166_2265_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 5)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("list_failures", 165, Current, 0, 0, 2487);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(92,F166_2299, (Current));
	Result = F164_2159(Current, tr1);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2265 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,5,F166_2265_body,(Current));
}

/* {ARGUMENT_PARSER}.interface_output_action_template */
static EIF_REFERENCE F166_2266_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(31)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("interface_output_action_template", 165, Current, 0, 0, 2488);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTMS_EX_H("template",8,1355664485);
	Result = F166_2275(Current, tr1);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2266 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(31,F166_2266_body,(Current));
}

/* {ARGUMENT_PARSER}.interface_text */
EIF_REFERENCE F166_2267 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("interface_text", 165, Current, 0, 1, 2489);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("t\000\000\000e\000\000\000x\000\000\000t\000\000\000.\000\000\000",5,1703283758);
	tr1 = F1087_8595(tr1, arg1);
	Result = F166_2275(Current, tr1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(3);
		Result = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1085_8463(RTCW(Result), arg1);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_PARSER}.skip_dotnet */
static EIF_BOOLEAN F166_2268_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 6)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("skip_dotnet", 165, Current, 0, 0, 2490);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTMS_EX_H("dotnet",6,3372660);
	Result = F166_2278(Current, tr1);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2268 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,6,F166_2268_body,(Current));
}

/* {ARGUMENT_PARSER}.platform_option */
static EIF_REFERENCE F166_2269_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(7)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("platform_option", 165, Current, 0, 0, 2491);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTMS_EX_H("platform",8,459690093);
	Result = F166_2279(Current, tr1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(3);
		tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1078_8165(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		tb1 = '\0';
		tb2 = F1086_8532(RTCW(Result));
		if ((EIF_BOOLEAN) !tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_0_0_2_);
			tw1 = F1086_8520(RTCW(Result), ti4_1);
			tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '!';
			tb1 = (EIF_BOOLEAN)(tw1 == tw2);
		}
		if (tb1) {
			RTHOOK(5);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_0_0_2_);
			tr1 = F1078_8246(RTCW(Result), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
			Result = (EIF_REFERENCE) tr1;
		}
	}
	RTOTE;
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2269 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(7,F166_2269_body,(Current));
}

/* {ARGUMENT_PARSER}.is_platform_exclusive */
static EIF_BOOLEAN F166_2270_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 8)

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("is_platform_exclusive", 165, Current, 1, 0, 2492);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = '\0';
	tb1 = '\0';
	tr1 = RTMS_EX_H("platform",8,459690093);
	tr1 = F166_2279(Current, tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = F1086_8532(loc1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_0_0_2_);
		tw1 = F1086_8520(loc1, ti4_1);
		tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '!';
		Result = (EIF_BOOLEAN)(tw1 == tw2);
	}
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F166_2270 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,8,F166_2270_body,(Current));
}

/* {ARGUMENT_PARSER}.ec_options */
static EIF_REFERENCE F166_2271_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(26)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("ec_options", 165, Current, 0, 0, 2493);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTMS_EX_H("ec",2,25955);
	Result = F166_2279(Current, tr1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(3);
		tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1078_8165(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
	}
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2271 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(26,F166_2271_body,(Current));
}

/* {ARGUMENT_PARSER}.melt_ec_options */
static EIF_REFERENCE F166_2272_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(23)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("melt_ec_options", 165, Current, 0, 0, 2494);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTMS_EX_H("ec.melt",7,1325807732);
	Result = F166_2279(Current, tr1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(3);
		tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1078_8165(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
	}
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2272 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(23,F166_2272_body,(Current));
}

/* {ARGUMENT_PARSER}.freeze_ec_options */
static EIF_REFERENCE F166_2273_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(24)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("freeze_ec_options", 165, Current, 0, 0, 2495);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTMS_EX_H("ec.freeze",9,970437733);
	Result = F166_2279(Current, tr1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(3);
		tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1078_8165(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
	}
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2273 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(24,F166_2273_body,(Current));
}

/* {ARGUMENT_PARSER}.finalize_ec_options */
static EIF_REFERENCE F166_2274_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(25)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("finalize_ec_options", 165, Current, 0, 0, 2496);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTMS_EX_H("ec.finalize",11,540943717);
	Result = F166_2279(Current, tr1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(3);
		tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1078_8165(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
	}
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2274 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(25,F166_2274_body,(Current));
}

/* {ARGUMENT_PARSER}.interface_item */
EIF_REFERENCE F166_2275 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("interface_item", 165, Current, 0, 1, 2497);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(104,F166_2276, (Current));
	Result = F852_6727(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_PARSER}.interface_options */
static EIF_REFERENCE F166_2276_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(104)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("interface_options", 165, Current, 0, 0, 2498);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(103,F166_2298, (Current));
	Result = F166_2281(Current, tr1, (EIF_CHARACTER_8) ',');
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2276 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(104,F166_2276_body,(Current));
}

/* {ARGUMENT_PARSER}.options_has_false */
EIF_BOOLEAN F166_2278 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("options_has_false", 165, Current, 1, 1, 2500);
	RTGC;
	RTHOOK(1);
	tr1 = F166_2279(Current, arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1078_8224(RTMS_EX_H("false",5,1635280741));
		Result = F1085_8486(loc1, tr1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_PARSER}.options_item */
EIF_REFERENCE F166_2279 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("options_item", 165, Current, 0, 1, 2501);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(105,F166_2280, (Current));
	Result = F852_6727(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_PARSER}.options */
static EIF_REFERENCE F166_2280_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(105)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("options", 165, Current, 0, 0, 2502);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(102,F166_2297, (Current));
	Result = F166_2281(Current, tr1, (EIF_CHARACTER_8) ',');
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F166_2280 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(105,F166_2280_body,(Current));
}

/* {ARGUMENT_PARSER}.concatenated_multiple_options */
EIF_REFERENCE F166_2281 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc6);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLR(5,loc7);
	RTLR(6,loc2);
	RTLR(7,loc8);
	RTLR(8,loc3);
	RTLR(9,loc4);
	RTLR(10,tr2);
	RTLIU(11);
	
	RTEAA("concatenated_multiple_options", 165, Current, 8, 2, 2503);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = '\0';
	if (F164_2159(Current, arg1)) {
		tr1 = F164_2177(Current, arg1);
		loc6 = tr1;
		tb2 = (EIF_TRUE);
	}
	if (tb2) {
		tb2 = F762_6292(loc6);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1085,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			Result = RTLNS(typres0.id, 860, _OBJSIZ_7_4_0_7_0_0_0_0_);
		}
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5561[Dtype(loc6)-800])(loc6);
		F861_6845(RTCW(Result), ti4_1);
		RTHOOK(3);
		F608_6140(RTCW(Result));
		RTHOOK(4);
		loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5345[Dtype(loc6)-509])(loc6);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5315[Dtype(loc7)-479])(loc7);
			if (tb1) break;
			RTHOOK(5);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5314[Dtype(loc7)-479])(loc7);
			tb2 = F43_435(RTCW(tr1));
			if (tb2) {
				RTHOOK(6);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5314[Dtype(loc7)-479])(loc7);
				tr1 = F43_433(RTCW(tr1));
				loc2 = F1078_8224(RTCW(tr1));
				RTHOOK(7);
				tb2 = F768_6292(RTCW(loc2));
				if ((EIF_BOOLEAN) !tb2) {
					RTHOOK(8);
					loc1 = F1087_8543(RTCW(loc2), ((EIF_INTEGER_32) 1L));
					RTHOOK(9);
					tr1 = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = loc1;
					tb2 = F1030_7995(RTCW(tr1));
					if (tb2) {
						RTHOOK(10);
						loc1 = (EIF_CHARACTER_32) arg2;
					} else {
						RTHOOK(11);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
						tr1 = F1087_8623(RTCW(loc2), ((EIF_INTEGER_32) 2L), ti4_1);
						loc2 = (EIF_REFERENCE) tr1;
					}
					RTHOOK(12);
					tr1 = F1078_8243(RTCW(loc2), loc1);
					loc8 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5345[Dtype(RTCW(tr1))-509])(tr1);
					for (;;) {
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5315[Dtype(loc8)-479])(loc8);
						if (tb2) break;
						RTHOOK(13);
						loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5314[Dtype(loc8)-479])(loc8);
						RTHOOK(14);
						F1087_8560(RTCW(loc2));
						RTHOOK(15);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
						loc5 = F1085_8473(RTCW(loc2), tw1, ((EIF_INTEGER_32) 1L));
						RTHOOK(16);
						if ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L))) {
							RTHOOK(17);
							loc3 = F1087_8623(RTCW(loc2), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L)));
							RTHOOK(18);
							F1087_8561(RTCW(loc3));
							RTHOOK(19);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
							loc4 = F1087_8623(RTCW(loc2), (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L)), ti4_1);
							RTHOOK(20);
							tb3 = '\0';
							tb4 = '\0';
							tb5 = F768_6292(RTCW(loc4));
							if ((EIF_BOOLEAN) !tb5) {
								tw1 = F1087_8543(RTCW(loc4), ((EIF_INTEGER_32) 1L));
								tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
								tb4 = (EIF_BOOLEAN)(tw1 == tw2);
							}
							if (tb4) {
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
								tw1 = F1087_8543(RTCW(loc4), ti4_1);
								tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
								tb3 = (EIF_BOOLEAN)(tw1 == tw2);
							}
							if (tb3) {
								RTHOOK(21);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
								tr1 = F1087_8623(RTCW(loc4), ((EIF_INTEGER_32) 2L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
								loc4 = (EIF_REFERENCE) tr1;
							}
							RTHOOK(22);
							tr1 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
							F1086_8516(RTCW(tr1), loc4);
							F852_6768(RTCW(Result), tr1, loc3);
						} else {
							RTHOOK(23);
							tr1 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
							tr2 = RTMS_EX_H("true",4,1953658213);
							F1086_8515(RTCW(tr1), tr2);
							F852_6768(RTCW(Result), tr1, loc2);
						}
						RTHOOK(24);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R5316[Dtype(loc8)-479])(loc8);
					}
				}
			}
			RTHOOK(25);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5316[Dtype(loc7)-479])(loc7);
		}
	} else {
		RTHOOK(26);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1085,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			Result = RTLNS(typres0.id, 860, _OBJSIZ_7_4_0_7_0_0_0_0_);
		}
		F852_6721(RTCW(Result), ((EIF_INTEGER_32) 0L));
		RTHOOK(27);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(28);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_PARSER}.location_switch */

EIF_REFERENCE F166_2282 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (86,RTMS_EX_H("l",1,108));
}

/* {ARGUMENT_PARSER}.eifgen_switch */

EIF_REFERENCE F166_2283 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (88,RTMS_EX_H("eifgen",6,1917432686));
}

/* {ARGUMENT_PARSER}.compdir_switch */

EIF_REFERENCE F166_2284 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (87,RTMS_EX_H("compdir",7,393516914));
}

/* {ARGUMENT_PARSER}.logdir_switch */

EIF_REFERENCE F166_2285 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (89,RTMS_EX_H("logdir",6,1947822962));
}

/* {ARGUMENT_PARSER}.experiment_switch */

EIF_REFERENCE F166_2286 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (94,RTMS_EX_H("experiment",10,207796852));
}

/* {ARGUMENT_PARSER}.compatible_switch */

EIF_REFERENCE F166_2287 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (95,RTMS_EX_H("compat",6,2031575924));
}

/* {ARGUMENT_PARSER}.ignore_switch */

EIF_REFERENCE F166_2288 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (90,RTMS_EX_H("ignore",6,2060026981));
}

/* {ARGUMENT_PARSER}.log_verbose_switch */

EIF_REFERENCE F166_2289 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (91,RTMS_EX_H("log_verbose",11,376110949));
}

/* {ARGUMENT_PARSER}.ecb_switch */

EIF_REFERENCE F166_2290 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (93,RTMS_EX_H("ecb",3,6644578));
}

/* {ARGUMENT_PARSER}.clean_switch */

EIF_REFERENCE F166_2291 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (100,RTMS_EX_H("clean",5,1819343726));
}

/* {ARGUMENT_PARSER}.keep_switch */

EIF_REFERENCE F166_2292 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (101,RTMS_EX_H("keep",4,1801807216));
}

/* {ARGUMENT_PARSER}.c_compile_switch */

EIF_REFERENCE F166_2293 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (96,RTMS_EX_H("c_compile",9,1960031333));
}

/* {ARGUMENT_PARSER}.melt_switch */

EIF_REFERENCE F166_2294 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (97,RTMS_EX_H("melt",4,1835363444));
}

/* {ARGUMENT_PARSER}.freeze_switch */

EIF_REFERENCE F166_2295 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (98,RTMS_EX_H("freeze",6,1902564965));
}

/* {ARGUMENT_PARSER}.finalize_switch */

EIF_REFERENCE F166_2296 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (99,RTMS_EX_H("finalize",8,1220601701));
}

/* {ARGUMENT_PARSER}.options_switch */

EIF_REFERENCE F166_2297 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (102,RTMS_EX_H("options",7,2023656563));
}

/* {ARGUMENT_PARSER}.interface_switch */

EIF_REFERENCE F166_2298 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (103,RTMS_EX_H("interface",9,2095921509));
}

/* {ARGUMENT_PARSER}.list_failures_switch */

EIF_REFERENCE F166_2299 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (92,RTMS_EX_H("list_failures",13,372625267));
}

void EIF_Minit142 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
