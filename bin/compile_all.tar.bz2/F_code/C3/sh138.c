/*
 * Code for class SHARED_CHARACTER_SETS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sh138.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SHARED_CHARACTER_SETS}.default_character_case_mapping */
static EIF_REFERENCE F162_2094_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(479)

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("default_character_case_mapping", 161, Current, 0, 0, 2302);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(38, 0x01).id, 38, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,680947802);
	tr3 = RTMS_EX_H("abcdefghijklmnopqrstuvwxyz",26,1741663354);
	F39_345(RTCW(tr1), tr2, tr3);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2094 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(479,F162_2094_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.default_word_set */
static EIF_REFERENCE F162_2095_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(480)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("default_word_set", 161, Current, 0, 0, 2303);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_",63,1064094303);
	F38_335(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2095 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(480,F162_2095_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.upper_set */
static EIF_REFERENCE F162_2096_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(595)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("upper_set", 161, Current, 0, 0, 2304);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,680947802);
	F38_335(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2096 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(595,F162_2096_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.lower_set */
static EIF_REFERENCE F162_2097_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(596)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("lower_set", 161, Current, 0, 0, 2305);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("abcdefghijklmnopqrstuvwxyz",26,1741663354);
	F38_335(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2097 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(596,F162_2097_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.alpha_set */
static EIF_REFERENCE F162_2098_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(508)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("alpha_set", 161, Current, 0, 0, 2306);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F38_334(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOUCR(596,F162_2097, (Current));
	F38_340(RTCW(Result), tr1);
	RTHOOK(3);
	tr1 = RTOUCR(595,F162_2096, (Current));
	F38_340(RTCW(Result), tr1);
	RTOTE;
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2098 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(508,F162_2098_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.digit_set */
static EIF_REFERENCE F162_2099_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(109)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("digit_set", 161, Current, 0, 0, 2307);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("0123456789",10,593348409);
	F38_335(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2099 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(109,F162_2099_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.alnum_set */
static EIF_REFERENCE F162_2100_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(597)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("alnum_set", 161, Current, 0, 0, 2308);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F38_334(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOUCR(508,F162_2098, (Current));
	F38_340(RTCW(Result), tr1);
	RTHOOK(3);
	tr1 = RTOUCR(109,F162_2099, (Current));
	F38_340(RTCW(Result), tr1);
	RTOTE;
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2100 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(597,F162_2100_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.xdigit_set */
static EIF_REFERENCE F162_2101_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(510)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("xdigit_set", 161, Current, 0, 0, 2309);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("0123456789abcdefABCDEF",22,1983803462);
	F38_335(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2101 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(510,F162_2101_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.cntrl_set */
static EIF_REFERENCE F162_2102_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(598)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cntrl_set", 161, Current, 1, 0, 2310);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F38_334(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 31L))) break;
		RTHOOK(4);
		F38_339(RTCW(Result), loc1);
		RTHOOK(5);
		loc1++;
	}
	RTHOOK(6);
	F38_339(RTCW(Result), ((EIF_INTEGER_32) 127L));
	RTOTE;
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2102 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(598,F162_2102_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.graph_set */
static EIF_REFERENCE F162_2103_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(599)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("graph_set", 161, Current, 0, 0, 2311);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("!\"#$%&\'()*+,-./0123456789:;<=>\?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",94,554150526);
	F38_335(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2103 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(599,F162_2103_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.print_set */
static EIF_REFERENCE F162_2104_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(600)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("print_set", 161, Current, 0, 0, 2312);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H(" !\"#$%&\'()*+,-./0123456789:;<=>\?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",95,1652388478);
	F38_335(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2104 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(600,F162_2104_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.punct_set */
static EIF_REFERENCE F162_2105_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(601)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("punct_set", 161, Current, 0, 0, 2313);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("!\"#$%&\'()*+,-./:;<=>\?@[\\]^_`{|}~",32,391924606);
	F38_335(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2105 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(601,F162_2105_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.ascii_set */
static EIF_REFERENCE F162_2106_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(602)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("ascii_set", 161, Current, 1, 0, 2314);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F38_334(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 127L))) break;
		RTHOOK(4);
		F38_339(RTCW(Result), loc1);
		RTHOOK(5);
		loc1++;
	}
	RTOTE;
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2106 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(602,F162_2106_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.space_set */
static EIF_REFERENCE F162_2107_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(110)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("space_set", 161, Current, 0, 0, 2315);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("\011\012\014\015\013 ",6,219952928);
	F38_335(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2107 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(110,F162_2107_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.meta_set */
static EIF_REFERENCE F162_2108_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(496)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("meta_set", 161, Current, 0, 0, 2299);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("*+\?{^.$|()[",11,572368475);
	F38_335(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2108 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(496,F162_2108_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.class_names */
static EIF_REFERENCE F162_2109_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(509)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("class_names", 161, Current, 0, 0, 2300);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1140,0xFF01,1082,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 13L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 13L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS_EX_H("alpha",5,1820051041);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("lower",5,1870925170);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("upper",5,1887312754);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("alnum",5,1819923309);
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("ascii",5,1936639849);
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("cntrl",5,1853885548);
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("digit",5,1769152884);
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("graph",5,1919779432);
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("print",5,1920372340);
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("punct",5,1971028852);
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("space",5,1886313829);
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("word",4,2003792484);
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("xdigit",6,2005082484);
	*((EIF_REFERENCE *)tr2+12) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1141_9214)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2109 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(509,F162_2109_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.class_sets */
static EIF_REFERENCE F162_2110_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(501)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("class_sets", 161, Current, 0, 0, 2301);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1140,0xFF01,37,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 13L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 13L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTOUCR(508,F162_2098, (Current));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(596,F162_2097, (Current));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(595,F162_2096, (Current));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(597,F162_2100, (Current));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(602,F162_2106, (Current));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(598,F162_2102, (Current));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(109,F162_2099, (Current));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(599,F162_2103, (Current));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(600,F162_2104, (Current));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(601,F162_2105, (Current));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(110,F162_2107, (Current));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(480,F162_2095, (Current));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(510,F162_2101, (Current));
	*((EIF_REFERENCE *)tr2+12) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1141_9214)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_2110 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(501,F162_2110_body,(Current));
}

void EIF_Minit138 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
