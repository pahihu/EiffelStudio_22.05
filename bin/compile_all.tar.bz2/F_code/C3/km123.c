/*
 * Code for class KMP_MATCHER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "km123.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KMP_MATCHER}.make_empty */
void F147_1976 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_empty", 146, Current, 0, 0, 2192);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1142,1219,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 0L),sizeof(EIF_INTEGER_32), EIF_TRUE);
	}
	F1143_9206(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F146_1966(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {KMP_MATCHER}.set_pattern */
void F147_1981 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_pattern", 146, Current, 0, 1, 2197);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8224(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {KMP_MATCHER}.search_for_pattern */
EIF_BOOLEAN F147_1984 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_CHARACTER_32 tw3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc7);
	RTLR(5,loc8);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTEAA("search_for_pattern", 146, Current, 9, 0, 2188);
	RTGC;
	RTHOOK(1);
	loc5 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	loc4 = *(EIF_REFERENCE *)(Current);
	RTHOOK(3);
	if (*(EIF_BOOLEAN *)(Current + O1950[dtype-146])) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F1087_8611(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F1087_8611(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(6);
	F147_1986(Current);
	RTHOOK(7);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc7 = *(EIF_REFERENCE *)(RTCW(tr1));
	RTHOOK(8);
	loc8 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	RTHOOK(9);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc6 = *(EIF_REFERENCE *)(RTCW(tr1));
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	RTHOOK(11);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	RTHOOK(12);
	loc3 = *(EIF_INTEGER_32 *)(Current + O1946[dtype-145]);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
	RTHOOK(13);
	loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		RTHOOK(14);
		if ((EIF_BOOLEAN) (Result || (EIF_BOOLEAN) (loc3 >= loc1))) break;
		RTHOOK(15);
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc9 == ((EIF_INTEGER_32) -1L))) {
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)RTCW(loc7) + (loc9));
			/* END INLINED CODE */
			tw1 = tw2;
			/* INLINED CODE (SPECIAL.item) */
			tw3 = *((EIF_CHARACTER_32 *)RTCW(loc6) + (loc3));
			/* END INLINED CODE */
			tw2 = tw3;
			tb1 = (EIF_BOOLEAN)(tw1 == tw2);
		}
		if (tb1) {
			RTHOOK(16);
			loc3++;
			RTHOOK(17);
			loc9++;
			RTHOOK(18);
			if ((EIF_BOOLEAN) (loc9 >= loc2)) {
				RTHOOK(19);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(20);
				*(EIF_INTEGER_32 *)(Current + O1946[dtype-145]) = (EIF_INTEGER_32) loc3;
			}
		} else {
			RTHOOK(21);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(loc8) + (loc9));
			/* END INLINED CODE */
			ti4_1 = ti4_2;
			loc9 = (EIF_INTEGER_32) ti4_1;
		}
	}
	RTHOOK(22);
	*(EIF_BOOLEAN *)(Current + O1941[dtype-145]) = (EIF_BOOLEAN) Result;
	RTHOOK(23);
	if (*(EIF_BOOLEAN *)(Current + O1950[dtype-146])) {
		RTHOOK(24);
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc5;
		RTHOOK(25);
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc4;
	}
	RTHOOK(26);
	RTLE;
	RTEE;
	return Result;
}

/* {KMP_MATCHER}.init_arrays */
void F147_1986 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_CHARACTER_32 tw3;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("init_arrays", 146, Current, 5, 0, 2190);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_REFERENCE *)(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1143_9241(RTCW(tr1), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	RTHOOK(5);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(6);
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(7);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_INTEGER_32 *)RTCW(loc1) + (((EIF_INTEGER_32) 0L))) = ((EIF_INTEGER_32) -1L);
	/* END INLINED CODE */
	;
	for (;;) {
		RTHOOK(8);
		if ((EIF_BOOLEAN) (loc4 >= loc3)) break;
		RTHOOK(9);
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) -1L))) {
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)RTCW(loc2) + (loc4));
			/* END INLINED CODE */
			tw1 = tw2;
			/* INLINED CODE (SPECIAL.item) */
			tw3 = *((EIF_CHARACTER_32 *)RTCW(loc2) + (loc5));
			/* END INLINED CODE */
			tw2 = tw3;
			tb1 = (EIF_BOOLEAN)(tw1 == tw2);
		}
		if (tb1) {
			RTHOOK(10);
			loc4++;
			RTHOOK(11);
			loc5++;
			RTHOOK(12);
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)RTCW(loc2) + (loc5));
			/* END INLINED CODE */
			tw1 = tw2;
			/* INLINED CODE (SPECIAL.item) */
			tw3 = *((EIF_CHARACTER_32 *)RTCW(loc2) + (loc4));
			/* END INLINED CODE */
			tw2 = tw3;
			if ((EIF_BOOLEAN)(tw1 == tw2)) {
				RTHOOK(13);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(loc1) + (loc5));
				/* END INLINED CODE */
				ti4_1 = ti4_2;
				/* INLINED CODE (SPECIAL.put) */
				*((EIF_INTEGER_32 *)RTCW(loc1) + (loc4)) = ti4_1;
				/* END INLINED CODE */
				;
			} else {
				RTHOOK(14);
				/* INLINED CODE (SPECIAL.put) */
				*((EIF_INTEGER_32 *)RTCW(loc1) + (loc4)) = loc5;
				/* END INLINED CODE */
				;
			}
		} else {
			RTHOOK(15);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(loc1) + (loc5));
			/* END INLINED CODE */
			ti4_1 = ti4_2;
			loc5 = (EIF_INTEGER_32) ti4_1;
		}
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

void EIF_Minit123 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
