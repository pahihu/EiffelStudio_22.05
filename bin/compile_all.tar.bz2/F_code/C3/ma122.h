
#ifndef _C3_ma122_
#define _C3_ma122_

#ifdef __cplusplus
extern "C" {
#endif

extern void F146_1965(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F146_1966(EIF_REFERENCE);
extern void F146_1967(EIF_REFERENCE, EIF_INTEGER_32);
extern void F146_1969(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F146_1971(EIF_REFERENCE);
extern void EIF_Minit122(void);
extern EIF_REFERENCE F1078_8224(EIF_REFERENCE);
extern void F1078_8165(EIF_REFERENCE);
extern char *(*R1937[])();
extern char *(*R1939[])();
extern long O1946[];

#ifdef __cplusplus
}
#endif

#endif
