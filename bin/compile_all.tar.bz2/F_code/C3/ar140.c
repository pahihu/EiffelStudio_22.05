/*
 * Code for class ARGUMENT_BASE_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar140.h"
#include "eif_built_in.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <termios.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F30_228
static EIF_INTEGER_32 inline_F30_228 (void)
{
	#ifdef TIOCGSIZE
	struct ttysize win;
    if (ioctl (STDIN_FILENO, TIOCGSIZE, &win))
        return 0;
    else
        return win.ts_cols;
#elif defined TIOCGWINSZ
	struct winsize win;
    if (ioctl (STDIN_FILENO, TIOCGWINSZ, &win))
        return 0;
    else
        return win.ws_col;
#else
    {
		// Not likely to work because COLUMNS generally is a shell variable.
        const char *s;
        s = getenv ("COLUMNS");
        if (s)
            return strtol (s, 0, 10);
        else
            return 0;
    }
#endif
	;
}
#define INLINE_F30_228
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENT_BASE_PARSER}.make */
void F164_2138 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 163, Current, 0, 3, 2343);
	RTGC;
	RTHOOK(1);
	F164_2139(Current);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_) = (EIF_BOOLEAN) arg2;
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_8_) = (EIF_BOOLEAN) arg3;
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.initialize_defaults */
void F164_2139 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("initialize_defaults", 163, Current, 0, 0, 2344);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(5);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(6);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(7);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(8);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,42,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1085,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(10);
	tr1 = RTLNS(eif_new_type(244, 0x01).id, 244, _OBJSIZ_1_2_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.values */
EIF_REFERENCE F164_2141 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	
	
	RTEAA("values", 163, Current, 1, 0, 2346);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_2_);
}

/* {ARGUMENT_BASE_PARSER}.option_values */
EIF_REFERENCE F164_2142 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("option_values", 163, Current, 0, 0, 2347);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
}

/* {ARGUMENT_BASE_PARSER}.error_messages */
static EIF_REFERENCE F164_2143_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(567)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("error_messages", 163, Current, 1, 0, 2348);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1077,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2143 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(567,F164_2143_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.system_name */
EIF_REFERENCE F164_2144 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("system_name", 163, Current, 1, 0, 2349);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(380,F260_3258, (RTCV(F164_2147(Current))));
	tr1 = F1102_9120(RTCW(tr1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1102_9143(loc1);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) RTOUCR(568,F164_2219, (Current));
	}/* NOTREACHED */
	
}

/* {ARGUMENT_BASE_PARSER}.sub_system_name */
EIF_REFERENCE F164_2145 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("sub_system_name", 163, Current, 0, 0, 2350);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {ARGUMENT_BASE_PARSER}.arguments */
EIF_REFERENCE F164_2146 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,Result);
	RTLR(3,loc4);
	RTLR(4,loc8);
	RTLR(5,tr1);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTEAA("arguments", 163, Current, 8, 0, 2351);
	RTGC;
	RTHOOK(1);
	if (RTOUCB(EIF_BOOLEAN,569,F164_2167, (Current))) {
		RTHOOK(2);
		loc1 = RTOUCR(381,F262_3267, (RTCV(F164_2147(Current))));
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1085,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		ti4_1 = F949_7092(RTCW(loc1));
		F949_7071(RTCW(Result), ti4_1);
		RTHOOK(4);
		loc4 = RTOUCR(570,F164_2217, (Current));
		RTHOOK(5);
		loc5 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_);
		RTHOOK(6);
		tr1 = F949_7085(RTCW(loc1));
		loc8 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = F557_6081(loc8);
			if (tb1) break;
			RTHOOK(7);
			loc2 = F557_6072(loc8);
			RTHOOK(8);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
				RTHOOK(9);
				tb2 = '\0';
				tw1 = F1086_8520(RTCW(loc2), ((EIF_INTEGER_32) 1L));
				tb3 = F885_6900(RTCW(loc4), tw1);
				if (tb3) {
					tw1 = F1086_8520(RTCW(loc2), ((EIF_INTEGER_32) 2L));
					tb3 = F885_6900(RTCW(loc4), tw1);
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (tb2) {
					RTHOOK(10);
					if (loc5) {
						RTHOOK(11);
						loc7 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_2_);
					} else {
						RTHOOK(12);
						tw1 = RTOUCB(EIF_CHARACTER_32,571,F164_2218, (Current));
						loc7 = F1085_8473(RTCW(loc2), tw1, ((EIF_INTEGER_32) 2L));
						RTHOOK(13);
						if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 0L))) {
							RTHOOK(14);
							loc7 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_2_);
						} else {
							RTHOOK(15);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_2_);
							ti4_1 = eif_min_int32 (loc7,ti4_1);
							loc7 = (EIF_INTEGER_32) ti4_1;
						}
					}
					RTHOOK(16);
					loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
					for (;;) {
						RTHOOK(17);
						if ((EIF_BOOLEAN) (loc6 > loc7)) break;
						RTHOOK(18);
						loc3 = (EIF_REFERENCE) NULL;
						RTHOOK(19);
						tb2 = '\0';
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc5 && (EIF_BOOLEAN) (loc6 < loc7))) {
							tw1 = F1086_8520(RTCW(loc2), (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)));
							tb2 = (EIF_BOOLEAN)(tw1 == RTOUCB(EIF_CHARACTER_32,571,F164_2218, (Current)));
						}
						if (tb2) {
							RTHOOK(20);
							loc3 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
							F1085_8461(RTCW(loc3), (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) (loc7 - loc6)));
							RTHOOK(21);
							tw1 = F885_6897(RTCW(loc4), ((EIF_INTEGER_32) 1L));
							F1087_8589(RTCW(loc3), tw1);
							RTHOOK(22);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_2_);
							tr1 = F1086_8529(RTCW(loc2), loc6, ti4_1);
							F1087_8576(RTCW(loc3), tr1);
							RTHOOK(23);
							loc6 = (EIF_INTEGER_32) loc7;
						}
						RTHOOK(24);
						tb2 = '\0';
						if ((EIF_BOOLEAN)(loc3 == NULL)) {
							tb3 = '\01';
							if (!loc5) {
								tw1 = F1086_8520(RTCW(loc2), loc6);
								tb3 = (EIF_BOOLEAN)(tw1 != RTOUCB(EIF_CHARACTER_32,571,F164_2218, (Current)));
							}
							tb2 = tb3;
						}
						if (tb2) {
							RTHOOK(25);
							loc3 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
							F1085_8461(RTCW(loc3), ((EIF_INTEGER_32) 2L));
							RTHOOK(26);
							tw1 = F885_6897(RTCW(loc4), ((EIF_INTEGER_32) 1L));
							F1087_8589(RTCW(loc3), tw1);
							RTHOOK(27);
							tw1 = F1086_8520(RTCW(loc2), loc6);
							F1087_8589(RTCW(loc3), tw1);
						}
						RTHOOK(28);
						if ((EIF_BOOLEAN)(loc3 != NULL)) {
							RTHOOK(29);
							tr1 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
							F1086_8516(RTCW(tr1), loc3);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
						}
						RTHOOK(30);
						loc6++;
					}
				} else {
					RTHOOK(31);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, loc2);
				}
			} else {
				RTHOOK(32);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, loc2);
			}
			RTHOOK(33);
			F557_6087(loc8);
		}
	} else {
		RTHOOK(34);
		Result = RTOUCR(381,F262_3267, (RTCV(F164_2147(Current))));
	}
	RTHOOK(36);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.argument_source */
EIF_REFERENCE F164_2147 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("argument_source", 163, Current, 0, 0, 2352);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(3);
		Result = F166_2241(Current);
		RTHOOK(4);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) Result;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.max_columns */
static EIF_NATURAL_32 F164_2151_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
#define Result RTOTRB(EIF_NATURAL_32)
	RTOUDB(EIF_NATURAL_32, 572)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("max_columns", 163, Current, 0, 0, 2356);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = (EIF_NATURAL_32) inline_F30_228();
	RTHOOK(2);
	if ((EIF_BOOLEAN)(Result == (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		Result = (EIF_NATURAL_32) ((EIF_INTEGER_32) 2147483647L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			RTHOOK(5);
			Result -= (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
		}
		RTHOOK(6);
		tu4_1 = eif_max_uint32 (Result,(EIF_NATURAL_32) ((EIF_INTEGER_32) 25L));
		Result = (EIF_NATURAL_32) tu4_1;
	}
	RTOTE;
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_NATURAL_32 F164_2151 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_NATURAL_32,572,F164_2151_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.is_successful */
EIF_BOOLEAN F164_2152 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_successful", 163, Current, 0, 0, 2357);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_11_)) {
		tb1 = F762_6292(RTCV(RTOUCR(567,F164_2143, (Current))));
		Result = tb1;
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.has_option */
EIF_BOOLEAN F164_2159 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("has_option", 163, Current, 0, 1, 2364);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_11_)) {
		Result = (EIF_BOOLEAN)(F164_2234(Current, arg1) != NULL);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.is_using_unix_switch_style */
static EIF_BOOLEAN F164_2167_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 569)

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_using_unix_switch_style", 163, Current, 1, 0, 2372);
	RTGC;
	RTOTP;
	RTHOOK(1);
	loc1 = F949_7085(RTCV(RTOUCR(85,F166_2245, (Current))));
	tb1 = EIF_FALSE;
	for (;;) {
		if (tb1) break;
		tb2 = F557_6081(loc1);
		if (tb2) break;
		RTHOOK(2);
		tr1 = F557_6072(loc1);
		tb3 = F1027_7952(RTCW(tr1));
		tb1 = tb3;
		F557_6087(loc1);
	}
	Result = (EIF_BOOLEAN) tb1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F164_2167 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,569,F164_2167_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.has_visible_available_options */
EIF_BOOLEAN F164_2169 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("has_visible_available_options", 163, Current, 0, 0, 2374);
	RTGC;
	RTHOOK(1);
	Result = F762_6292(RTCV(RTOUCR(573,F164_2210, (Current))));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.has_switch */
EIF_BOOLEAN F164_2171 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("has_switch", 163, Current, 2, 1, 2376);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_);
	RTHOOK(2);
	loc2 = F949_7085(RTCV(RTOUCR(574,F164_2209, (Current))));
	tb1 = EIF_FALSE;
	for (;;) {
		if (tb1) break;
		tb2 = F557_6081(loc2);
		if (tb2) break;
		RTHOOK(3);
		if (loc1) {
			tr1 = F557_6072(loc2);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb3 = F1078_8210(RTCW(tr1), arg1);
		} else {
			tr1 = F557_6072(loc2);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb4 = F1078_8207(RTCW(tr1), arg1);
			tb3 = tb4;
		}
		tb1 = tb3;
		F557_6087(loc2);
	}
	Result = (EIF_BOOLEAN) tb1;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.set_is_using_separated_switch_values */
void F164_2172 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_is_using_separated_switch_values", 163, Current, 0, 1, 2377);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.option_of_name */
EIF_REFERENCE F164_2176 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("option_of_name", 163, Current, 0, 1, 2381);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F164_2234(Current, arg1);
}

/* {ARGUMENT_BASE_PARSER}.options_of_name */
EIF_REFERENCE F164_2177 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTEAA("options_of_name", 163, Current, 3, 1, 2382);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,42,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F949_7071(RTCW(Result), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	loc1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_);
	RTHOOK(3);
	tr1 = F164_2142(Current);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5345[Dtype(RTCW(tr1))-509])(tr1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5315[Dtype(loc3)-479])(loc3);
		if (tb1) break;
		RTHOOK(4);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5314[Dtype(loc3)-479])(loc3);
		RTHOOK(5);
		if (loc1) {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb2 = F1078_8210(RTCW(tr1), arg1);
		} else {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb3 = F1078_8207(RTCW(tr1), arg1);
			tb2 = tb3;
		}
		if (tb2) {
			RTHOOK(8);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, loc2);
		}
		RTHOOK(9);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5316[Dtype(loc3)-479])(loc3);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.switch_of_name */
EIF_REFERENCE F164_2180 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("switch_of_name", 163, Current, 2, 1, 2385);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_);
	RTHOOK(2);
	loc2 = F949_7085(RTCV(RTOUCR(574,F164_2209, (Current))));
	for (;;) {
		tb1 = F557_6081(loc2);
		if (tb1) break;
		RTHOOK(3);
		if ((EIF_BOOLEAN)(Result != NULL)) break;
		RTHOOK(4);
		if (loc1) {
			RTHOOK(5);
			tr1 = F557_6072(loc2);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb2 = F1078_8210(RTCW(tr1), arg1);
		} else {
			RTHOOK(6);
			tr1 = F557_6072(loc2);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb3 = F1078_8207(RTCW(tr1), arg1);
			tb2 = tb3;
		}
		if (tb2) {
			RTHOOK(7);
			Result = F557_6072(loc2);
		}
		RTHOOK(8);
		F557_6087(loc2);
	}
	RTHOOK(9);
	RTCT0("from_precondition_has_switch", EX_CHECK);
	if ((EIF_BOOLEAN)(Result != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.string_formatter */
static EIF_REFERENCE F164_2181_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(575)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("string_formatter", 163, Current, 0, 0, 2386);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1252, 0x01).id, 1252, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2181 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(575,F164_2181_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.execute */
void F164_2182 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("execute", 163, Current, 0, 1, 2387);
	RTGC;
	RTHOOK(1);
	F164_2184(Current);
	RTHOOK(2);
	if (F164_2152(Current)) {
		RTHOOK(3);
		tb1 = '\0';
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_9_);
		}
		if (tb1) {
			RTHOOK(4);
			F164_2195(Current);
		}
		RTHOOK(5);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_10_)) {
			RTHOOK(6);
			F164_2194(Current);
		} else {
			RTHOOK(7);
			tb1 = '\0';
			tr1 = RTOUCR(576,F164_2208, (Current));
			if (F164_2171(Current, tr1)) {
				tr1 = RTOUCR(576,F164_2208, (Current));
				tb1 = F164_2159(Current, tr1);
			}
			if (tb1) {
				RTHOOK(8);
				F164_2196(Current);
			} else {
				RTHOOK(9);
				tb1 = '\0';
				tb2 = F762_6292(RTCV(F164_2142(Current)));
				if (tb2) {
					tb2 = F762_6292(RTCV(F164_2141(Current)));
					tb1 = tb2;
				}
				if (tb1) {
					RTHOOK(10);
					F165_2239(Current, arg1);
				} else {
					RTHOOK(11);
					(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
						*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
						*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_));
				}
			}
		}
	} else {
		RTHOOK(12);
		tb1 = '\0';
		tr1 = RTOUCR(577,F164_2206, (Current));
		if (F164_2171(Current, tr1)) {
			tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_9_);
		}
		if (tb1) {
			RTHOOK(13);
			F164_2195(Current);
		}
		RTHOOK(14);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_)) {
			RTHOOK(15);
			F164_2194(Current);
		}
		RTHOOK(16);
		F164_2197(Current);
	}
	RTHOOK(17);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.parse_arguments */
void F164_2184 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc11 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc14 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc15 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc16 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc17 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	RTCFDT;
	RTLD;
	
	RTLI(17);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc8);
	RTLR(4,loc18);
	RTLR(5,loc12);
	RTLR(6,loc4);
	RTLR(7,loc3);
	RTLR(8,loc5);
	RTLR(9,tr2);
	RTLR(10,tr3);
	RTLR(11,loc7);
	RTLR(12,loc19);
	RTLR(13,loc6);
	RTLR(14,loc20);
	RTLR(15,loc21);
	RTLR(16,loc22);
	RTLIU(17);
	
	RTEAA("parse_arguments", 163, Current, 22, 0, 2389);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F949_7130(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F949_7130(RTCW(tr1));
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	loc1 = RTOUCR(574,F164_2209, (Current));
	RTHOOK(5);
	loc8 = RTOUCR(570,F164_2217, (Current));
	RTHOOK(6);
	loc9 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_);
	RTHOOK(7);
	loc2 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_);
	RTHOOK(8);
	loc18 = F949_7085(RTCV(F164_2146(Current)));
	for (;;) {
		tb1 = F557_6081(loc18);
		if (tb1) break;
		
		RTHOOK(10);
		loc12 = F557_6072(loc18);
		RTHOOK(11);
		tb2 = '\0';
		tb3 = '\0';
		tb4 = '\0';
		if ((EIF_BOOLEAN) !loc14) {
			tb5 = F1086_8532(RTCW(loc12));
			tb4 = (EIF_BOOLEAN) !tb5;
		}
		if (tb4) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_0_0_2_);
			tb3 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
		}
		if (tb3) {
			tw1 = F1086_8520(RTCW(loc12), ((EIF_INTEGER_32) 1L));
			tb3 = F885_6900(RTCW(loc8), tw1);
			tb2 = tb3;
		}
		if (tb2) {
			RTHOOK(12);
			tb2 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_0_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 2L))) {
				tw1 = F1086_8520(RTCW(loc12), ((EIF_INTEGER_32) 2L));
				tb3 = F885_6900(RTCW(loc8), tw1);
				tb2 = tb3;
			}
			if (tb2) {
				RTHOOK(13);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_0_0_2_);
				loc4 = F1086_8530(RTCW(loc12), ((EIF_INTEGER_32) 3L), ti4_1);
				RTHOOK(14);
				loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				RTHOOK(15);
				tb2 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_0_0_2_);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
					tr1 = RTMS_EX_H("--",2,11565);
					tb3 = F1078_8210(RTCW(loc12), tr1);
					tb2 = tb3;
				}
				if (tb2) {
					RTHOOK(16);
					loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(17);
					loc4 = (EIF_REFERENCE) loc12;
				} else {
					RTHOOK(18);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_0_0_2_);
					loc4 = F1086_8530(RTCW(loc12), ((EIF_INTEGER_32) 2L), ti4_1);
				}
				RTHOOK(19);
				loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			RTHOOK(20);
			if ((EIF_BOOLEAN) !loc14) {
				RTHOOK(21);
				loc3 = (EIF_REFERENCE) NULL;
				RTHOOK(22);
				tb2 = F1086_8532(RTCW(loc4));
				if ((EIF_BOOLEAN) !tb2) {
					RTHOOK(23);
					loc11 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(24);
					loc5 = (EIF_REFERENCE) NULL;
					RTHOOK(25);
					if ((EIF_BOOLEAN) !loc2) {
						RTHOOK(26);
						tw1 = RTOUCB(EIF_CHARACTER_32,571,F164_2218, (Current));
						loc16 = F1085_8473(RTCW(loc4), tw1, ((EIF_INTEGER_32) 1L));
						RTHOOK(27);
						if ((EIF_BOOLEAN) (loc16 > ((EIF_INTEGER_32) 0L))) {
							RTHOOK(28);
							if ((EIF_BOOLEAN)(loc16 == ((EIF_INTEGER_32) 1L))) {
								RTHOOK(29);
								tr1 = RTOUCR(578,F164_2221, (Current));
								{
									static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1025,0xFF01,1086,0xFFFF};
									EIF_TYPE typres0;
									static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
									
									typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
									tr2 = RTLNTS(typres0.id, 2, 0);
								}
								tr3 = F164_2214(Current, loc12);
								((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
								RTAR(tr2,tr3);
								F164_2193(Current, tr1, tr2);
								RTHOOK(30);
								loc11 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								RTHOOK(31);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_0_0_2_);
								loc5 = F1086_8530(RTCW(loc4), (EIF_INTEGER_32) (loc16 + ((EIF_INTEGER_32) 1L)), ti4_1);
								RTHOOK(32);
								tr1 = F1086_8530(RTCW(loc4), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc16 - ((EIF_INTEGER_32) 1L)));
								loc4 = (EIF_REFERENCE) tr1;
							}
						}
					}
					RTHOOK(33);
					if ((EIF_BOOLEAN) !loc11) {
						RTHOOK(34);
						if ((EIF_BOOLEAN) !loc9) {
							RTHOOK(35);
							tr1 = F1086_8527(RTCW(loc4));
							loc4 = (EIF_REFERENCE) tr1;
						}
						RTHOOK(36);
						loc7 = (EIF_REFERENCE) NULL;
						RTHOOK(37);
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						RTHOOK(38);
						loc19 = F949_7085(RTCW(loc1));
						for (;;) {
							tb2 = F557_6081(loc19);
							if (tb2) break;
							RTHOOK(39);
							if (loc10) break;
							RTHOOK(40);
							loc6 = F557_6072(loc19);
							RTHOOK(41);
							if (loc13) {
								RTHOOK(42);
								if (loc9) {
									RTHOOK(43);
									tr1 = *(EIF_REFERENCE *)(RTCW(loc6) + _REFACS_1_);
									loc10 = F1085_8488(RTCW(tr1), loc4);
								} else {
									RTHOOK(44);
									tr1 = *(EIF_REFERENCE *)(RTCW(loc6) + _REFACS_1_);
									loc10 = F1085_8486(RTCW(tr1), loc4);
								}
							} else {
								RTHOOK(45);
								if (loc9) {
									RTHOOK(46);
									tr1 = F1027_7943(RTCW(loc6));
									loc10 = F1085_8488(RTCW(tr1), loc4);
								} else {
									RTHOOK(47);
									tr1 = F1027_7943(RTCW(loc6));
									loc10 = F1085_8486(RTCW(tr1), loc4);
								}
							}
							RTHOOK(48);
							if (loc10) {
								RTHOOK(49);
								loc7 = (EIF_REFERENCE) loc6;
							}
							RTHOOK(50);
							F557_6087(loc19);
						}
						RTHOOK(51);
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc10 && (EIF_BOOLEAN) !loc13)) {
							RTHOOK(52);
							loc17 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							RTHOOK(53);
							loc15 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_0_0_2_);
							for (;;) {
								RTHOOK(54);
								if ((EIF_BOOLEAN) (loc17 > loc15)) break;
								RTHOOK(55);
								loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								RTHOOK(56);
								loc20 = F949_7085(RTCW(loc1));
								for (;;) {
									tb3 = F557_6081(loc20);
									if (tb3) break;
									RTHOOK(57);
									if (loc10) break;
									RTHOOK(58);
									loc6 = F557_6072(loc20);
									RTHOOK(59);
									tb4 = F1027_7952(RTCW(loc6));
									if (tb4) {
										RTHOOK(60);
										if (loc9) {
											RTHOOK(61);
											tw1 = *(EIF_CHARACTER_32 *)(RTCW(loc6) + O6723[Dtype(loc6)-1026]);
											tw2 = F1086_8520(RTCW(loc4), loc17);
											loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tw1 == tw2);
										} else {
											RTHOOK(62);
											tw1 = *(EIF_CHARACTER_32 *)(RTCW(loc6) + O6723[Dtype(loc6)-1026]);
											tr1 = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
											*(EIF_CHARACTER_32 *)tr1 = tw1;
											tw1 = F1030_7991(RTCW(tr1));
											tw2 = F1086_8520(RTCW(loc4), loc17);
											loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tw1 == tw2);
										}
										RTHOOK(63);
										if ((EIF_BOOLEAN) (loc10 && (EIF_BOOLEAN) (loc17 < loc15))) {
											RTHOOK(64);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
											tr2 = F1027_7955(RTCW(loc6));
											(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, tr2);
										}
									}
									RTHOOK(65);
									F557_6087(loc20);
								}
								RTHOOK(66);
								loc17++;
							}
							RTHOOK(67);
							if (loc10) {
								RTHOOK(68);
								loc7 = (EIF_REFERENCE) loc6;
							}
						}
						RTHOOK(69);
						if (loc10) {
							RTHOOK(70);
							if ((EIF_BOOLEAN)(loc6 != NULL)) {
								RTHOOK(71);
								tb4 = '\0';
								tb5 = '\0';
								if ((EIF_BOOLEAN)(loc5 != NULL)) {
									tb6 = F1086_8532(RTCW(loc5));
									tb5 = (EIF_BOOLEAN) !tb6;
								}
								if (tb5) {
									loc21 = loc7;
									loc21 = RTRV(eif_new_type(1027, 0x01),loc21);
									tb4 = EIF_TEST(loc21);
								}
								if (tb4) {
									RTHOOK(72);
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									tr2 = F1028_7967(loc21, loc5);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, tr2);
								} else {
									RTHOOK(73);
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									tr2 = F1027_7955(RTCW(loc6));
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, tr2);
								}
							} else {
								
							}
							RTHOOK(75);
							if (loc2) {
								RTHOOK(76);
								loc3 = (EIF_REFERENCE) loc6;
							}
						} else {
							RTHOOK(77);
							tr1 = RTOUCR(579,F164_2222, (Current));
							{
								static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1025,0xFF01,1086,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr2 = RTLNTS(typres0.id, 2, 0);
							}
							tr3 = F164_2214(Current, loc12);
							((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
							RTAR(tr2,tr3);
							F164_2193(Current, tr1, tr2);
						}
					}
				} else {
					RTHOOK(78);
					tr1 = RTOUCR(578,F164_2221, (Current));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1025,0xFF01,1086,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 2, 0);
					}
					tr3 = F164_2214(Current, loc12);
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					F164_2193(Current, tr1, tr2);
				}
			}
		} else {
			RTHOOK(79);
			loc22 = loc3;
			loc22 = RTRV(eif_new_type(1027, 0x01),loc22);
			if (EIF_TEST(loc22)) {
				
				RTHOOK(82);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F949_7103(RTCW(tr1));
				RTHOOK(83);
				tb4 = '\0';
				if ((EIF_BOOLEAN)(loc12 != NULL)) {
					tb5 = F1086_8532(RTCW(loc12));
					tb4 = (EIF_BOOLEAN) !tb5;
				}
				if (tb4) {
					RTHOOK(84);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tr2 = F1028_7967(loc22, loc12);
					F949_7115(RTCW(tr1), tr2);
				}
			} else {
				RTHOOK(85);
				tb4 = F1086_8532(RTCW(loc12));
				if ((EIF_BOOLEAN) !tb4) {
					RTHOOK(86);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, loc12);
				} else {
					RTHOOK(87);
					tr1 = RTOUCR(578,F164_2221, (Current));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1025,0xFF01,1086,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 2, 0);
					}
					tr3 = F164_2214(Current, loc12);
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					F164_2193(Current, tr1, tr2);
				}
			}
			RTHOOK(88);
			loc3 = (EIF_REFERENCE) NULL;
		}
		RTHOOK(89);
		F557_6087(loc18);
	}
	RTHOOK(90);
	if (F164_2152(Current)) {
		RTHOOK(91);
		tr1 = RTOUCR(580,F164_2207, (Current));
		if ((EIF_BOOLEAN) !F164_2159(Current, tr1)) {
			RTHOOK(92);
			F164_2186(Current);
			RTHOOK(93);
			if (F164_2152(Current)) {
				RTHOOK(94);
				F164_2185(Current);
			}
		} else {
			RTHOOK(95);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTHOOK(96);
	tb4 = F164_2152(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_11_) = (EIF_BOOLEAN) tb4;
	RTHOOK(98);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.post_process_arguments */
void F164_2185 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("post_process_arguments", 163, Current, 0, 0, 2390);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tb2 = '\01';
	tr1 = RTOUCR(577,F164_2206, (Current));
	if (!(EIF_BOOLEAN) !F164_2171(Current, tr1)) {
		tr1 = RTOUCR(577,F164_2206, (Current));
		tb2 = F164_2159(Current, tr1);
	}
	if (!tb2) {
		tr1 = RTOUCR(576,F164_2208, (Current));
		tb1 = F164_2159(Current, tr1);
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_9_) = (EIF_BOOLEAN) tb1;
	RTHOOK(2);
	tr1 = RTOUCR(580,F164_2207, (Current));
	tb1 = F164_2159(Current, tr1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_10_) = (EIF_BOOLEAN) tb1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.validate_arguments */
void F164_2186 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTCFDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc8);
	RTLR(5,loc4);
	RTLR(6,loc1);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,loc9);
	RTLR(10,loc10);
	RTLR(11,loc11);
	RTLR(12,loc6);
	RTLR(13,loc12);
	RTLR(14,loc5);
	RTLIU(15);
	
	RTEAA("validate_arguments", 163, Current, 12, 0, 2391);
	RTGC;
	RTHOOK(1);
	loc2 = RTOUCR(581,F164_2212, (Current));
	RTHOOK(2);
	tb1 = F762_6292(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		loc2 = F164_2189(Current);
		RTHOOK(4);
		tb1 = F762_6292(RTCW(loc2));
		if (tb1) {
			RTHOOK(5);
			tr1 = RTOUCR(582,F164_2230, (Current));
			F164_2192(Current, tr1);
		}
	}
	RTHOOK(6);
	loc3 = RTOUCR(583,F164_2213, (Current));
	RTHOOK(7);
	tb1 = '\0';
	tb2 = F762_6292(RTCW(loc3));
	if ((EIF_BOOLEAN) !tb2) {
		tb2 = F762_6292(RTCV(F164_2142(Current)));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(8);
		F164_2188(Current);
	}
	RTHOOK(9);
	tb1 = F762_6292(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(10);
		F164_2187(Current, loc2);
	}
	RTHOOK(11);
	loc8 = F949_7085(RTCV(RTOUCR(574,F164_2209, (Current))));
	for (;;) {
		tb1 = F557_6081(loc8);
		if (tb1) break;
		RTHOOK(12);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(13);
		loc4 = F557_6072(loc8);
		RTHOOK(14);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc4));
		if (F164_2159(Current, tr1)) {
			RTHOOK(15);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4));
			loc1 = F164_2177(Current, tr1);
		} else {
			RTHOOK(16);
			loc1 = (EIF_REFERENCE) NULL;
		}
		RTHOOK(17);
		tb2 = '\0';
		tb3 = '\0';
		tb4 = '\0';
		tb5 = *(EIF_BOOLEAN *)(RTCW(loc4) + O6725[Dtype(loc4)-1026]);
		if ((EIF_BOOLEAN) !tb5) {
			tb4 = (EIF_BOOLEAN)(loc1 == NULL);
		}
		if (tb4) {
			tb4 = F762_6292(RTCW(loc2));
			tb3 = tb4;
		}
		if (tb3) {
			tb3 = F762_6292(RTCW(loc3));
			tb2 = tb3;
		}
		if (tb2) {
			RTHOOK(18);
			tr1 = RTOUCR(584,F164_2227, (Current));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1025,0xFF01,1085,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1027_7943(RTCW(loc4));
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			F164_2193(Current, tr1, tr2);
		} else {
			RTHOOK(19);
			tb2 = '\0';
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				tb3 = F762_6292(RTCW(loc1));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				RTHOOK(20);
				tb2 = '\0';
				tb3 = *(EIF_BOOLEAN *)(RTCW(loc4) + O6726[Dtype(loc4)-1026]);
				if ((EIF_BOOLEAN) !tb3) {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5561[Dtype(RTCW(loc1))-800])(loc1);
					tb2 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
				}
				if (tb2) {
					RTHOOK(21);
					tr1 = RTOUCR(585,F164_2225, (Current));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1025,0xFF01,1085,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 2, 0);
					}
					tr3 = F1027_7943(RTCW(loc4));
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					F164_2193(Current, tr1, tr2);
				}
				RTHOOK(22);
				loc9 = loc4;
				loc9 = RTRV(eif_new_type(1027, 0x01),loc9);
				if ((EIF_BOOLEAN) !EIF_TEST(loc9)) {
					RTHOOK(23);
					loc10 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5345[Dtype(RTCW(loc1))-509])(loc1);
					for (;;) {
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5315[Dtype(loc10)-479])(loc10);
						if (tb2) break;
						RTHOOK(24);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5314[Dtype(loc10)-479])(loc10);
						tb3 = F43_435(RTCW(tr1));
						if (tb3) {
							RTHOOK(25);
							tr1 = RTOUCR(586,F164_2226, (Current));
							{
								static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1025,0xFF01,1085,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr2 = RTLNTS(typres0.id, 2, 0);
							}
							tr3 = F1027_7943(RTCW(loc4));
							((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
							RTAR(tr2,tr3);
							F164_2193(Current, tr1, tr2);
						}
						RTHOOK(26);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R5316[Dtype(loc10)-479])(loc10);
					}
				} else {
					RTHOOK(27);
					tb3 = *(EIF_BOOLEAN *)(loc9+ _CHROFF_5_4_);
					if ((EIF_BOOLEAN) !tb3) {
						RTHOOK(28);
						loc11 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5345[Dtype(RTCW(loc1))-509])(loc1);
						for (;;) {
							tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5315[Dtype(loc11)-479])(loc11);
							if (tb3) break;
							RTHOOK(29);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5314[Dtype(loc11)-479])(loc11);
							tb4 = F43_435(RTCW(tr1));
							if ((EIF_BOOLEAN) !tb4) {
								RTHOOK(30);
								tr1 = RTOUCR(587,F164_2224, (Current));
								{
									static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1025,0xFF01,1085,0xFF01,1085,0xFFFF};
									EIF_TYPE typres0;
									static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
									
									typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
									tr2 = RTLNTS(typres0.id, 3, 0);
								}
								tr3 = F1027_7943(loc9);
								((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
								RTAR(tr2,tr3);
								tr3 = *(EIF_REFERENCE *)(loc9 + _REFACS_3_);
								((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
								RTAR(tr2,tr3);
								F164_2193(Current, tr1, tr2);
								RTHOOK(31);
								loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							}
							RTHOOK(32);
							(FUNCTION_CAST(void, (EIF_REFERENCE)) R5316[Dtype(loc11)-479])(loc11);
						}
						RTHOOK(33);
						if (loc7) {
							RTHOOK(34);
							loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6742[Dtype(loc9)-1027])(loc9);
							RTHOOK(35);
							loc12 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5345[Dtype(RTCW(loc1))-509])(loc1);
							for (;;) {
								tb4 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5315[Dtype(loc12)-479])(loc12);
								if (tb4) break;
								RTHOOK(36);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5314[Dtype(loc12)-479])(loc12);
								loc5 = F43_433(RTCW(tr1));
								RTHOOK(37);
								F244_3053(RTCW(loc6), loc5);
								RTHOOK(38);
								tb5 = *(EIF_BOOLEAN *)(RTCW(loc6)+ _CHROFF_1_0_);
								if ((EIF_BOOLEAN) !tb5) {
									RTHOOK(39);
									tr1 = RTOUCR(588,F164_2232, (Current));
									{
										static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,3,1025,0xFF01,1086,0xFF01,1085,0xFF01,1085,0xFFFF};
										EIF_TYPE typres0;
										static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
										
										typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
										tr2 = RTLNTS(typres0.id, 4, 0);
									}
									tr3 = F164_2214(Current, loc5);
									((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
									RTAR(tr2,tr3);
									tr3 = F1027_7943(RTCW(loc4));
									((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
									RTAR(tr2,tr3);
									tr3 = F244_3049(RTCW(loc6));
									((EIF_TYPED_VALUE *)tr2+3)->it_r = tr3;
									RTAR(tr2,tr3);
									F164_2193(Current, tr1, tr2);
								}
								RTHOOK(40);
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R5316[Dtype(loc12)-479])(loc12);
							}
						}
					}
				}
			}
		}
		RTHOOK(41);
		F557_6087(loc8);
	}
	RTHOOK(45);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.validate_non_switched_arguments */
void F164_2187 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTEAA("validate_non_switched_arguments", 163, Current, 3, 1, 2392);
	RTGC;
	RTHOOK(1);
	loc2 = F164_2141(Current);
	RTHOOK(2);
	tb1 = F762_6292(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_)) {
			RTHOOK(4);
			loc1 = *(EIF_REFERENCE *)(Current);
			RTHOOK(5);
			loc3 = F949_7085(RTCW(loc2));
			for (;;) {
				tb1 = F557_6081(loc3);
				if (tb1) break;
				RTHOOK(6);
				tr1 = F557_6072(loc3);
				F244_3053(RTCW(loc1), tr1);
				RTHOOK(7);
				tb2 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_1_0_);
				if ((EIF_BOOLEAN) !tb2) {
					RTHOOK(8);
					tr1 = RTOUCR(589,F164_2233, (Current));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1025,0xFF01,1085,0xFF01,1085,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
						tr2 = RTLNTS(typres0.id, 3, 0);
					}
					tr3 = F557_6072(loc3);
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					tr3 = F244_3049(RTCW(loc1));
					((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
					RTAR(tr2,tr3);
					F164_2193(Current, tr1, tr2);
				}
				RTHOOK(9);
				F557_6087(loc3);
			}
		} else {
			RTHOOK(10);
			tr1 = RTOUCR(590,F164_2228, (Current));
			F164_2192(Current, tr1);
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.validate_switch_appurtenances */
void F164_2188 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc6);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc7);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLIU(9);
	
	RTEAA("validate_switch_appurtenances", 163, Current, 7, 0, 2393);
	RTGC;
	RTHOOK(1);
	loc1 = RTOUCR(583,F164_2213, (Current));
	RTHOOK(2);
	tr1 = F164_2142(Current);
	loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5345[Dtype(RTCW(tr1))-509])(tr1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5315[Dtype(loc6)-479])(loc6);
		if (tb1) break;
		RTHOOK(3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5314[Dtype(loc6)-479])(loc6);
		loc3 = *(EIF_REFERENCE *)(RTCW(tr1));
		RTHOOK(4);
		tb2 = F852_6729(RTCW(loc1), loc3);
		if (tb2) {
			RTHOOK(5);
			tr1 = F852_6727(RTCW(loc1), loc3);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				RTHOOK(6);
				loc5 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_1_1_0_1_);
				RTHOOK(7);
				loc4 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_1_1_0_0_);
				for (;;) {
					RTHOOK(8);
					if ((EIF_BOOLEAN) (loc5 > loc4)) break;
					RTHOOK(9);
					loc2 = F879_6897(loc7, loc5);
					RTHOOK(10);
					tb2 = '\0';
					tb3 = '\0';
					tb4 = *(EIF_BOOLEAN *)(RTCW(loc2) + O6725[Dtype(loc2)-1026]);
					if ((EIF_BOOLEAN) !tb4) {
						tb4 = *(EIF_BOOLEAN *)(RTCW(loc2) + O6728[Dtype(loc2)-1026]);
						tb3 = (EIF_BOOLEAN) !tb4;
					}
					if (tb3) {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
						tb2 = (EIF_BOOLEAN) !F164_2159(Current, tr1);
					}
					if (tb2) {
						RTHOOK(11);
						tr1 = RTOUCR(591,F164_2231, (Current));
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1025,0xFF01,1085,0xFF01,1085,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2 = RTLNTS(typres0.id, 3, 0);
						}
						tr3 = F1027_7943(RTCW(loc3));
						((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
						RTAR(tr2,tr3);
						tr3 = F1027_7943(RTCW(loc2));
						((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
						RTAR(tr2,tr3);
						F164_2193(Current, tr1, tr2);
					}
					RTHOOK(12);
					loc5++;
				}
			} else {
				
			}
		}
		RTHOOK(14);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5316[Dtype(loc6)-479])(loc6);
	}
	RTHOOK(17);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.valid_switch_groups */
EIF_REFERENCE F164_2189 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_BOOLEAN tb7;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTEAA("valid_switch_groups", 163, Current, 3, 0, 2394);
	RTGC;
	RTHOOK(1);
	Result = F1_14(F164_2190(Current));
	RTHOOK(2);
	tr1 = F164_2142(Current);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5345[Dtype(RTCW(tr1))-509])(tr1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5315[Dtype(loc2)-479])(loc2);
		if (tb1) break;
		RTHOOK(3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5314[Dtype(loc2)-479])(loc2);
		loc1 = *(EIF_REFERENCE *)(RTCW(tr1));
		RTHOOK(4);
		F949_7102(RTCW(Result));
		for (;;) {
			RTHOOK(5);
			tb2 = '\01';
			tb3 = F762_6292(RTCW(Result));
			if (!tb3) {
				tb3 = F920_6990(RTCW(Result));
				tb2 = tb3;
			}
			if (tb2) break;
			RTHOOK(6);
			tb3 = '\0';
			tb4 = *(EIF_BOOLEAN *)(RTCW(loc1) + O6728[Dtype(loc1)-1026]);
			if ((EIF_BOOLEAN) !tb4) {
				tr1 = F949_7076(RTCW(Result));
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
				tb4 = F949_7083(RTCW(tr1), loc1);
				tb3 = (EIF_BOOLEAN) !tb4;
			}
			if (tb3) {
				RTHOOK(7);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5503[Dtype(RTCW(Result))-800])(Result);
			} else {
				RTHOOK(8);
				F949_7104(RTCW(Result));
			}
		}
		RTHOOK(9);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5316[Dtype(loc2)-479])(loc2);
	}
	RTHOOK(10);
	F949_7102(RTCW(Result));
	for (;;) {
		RTHOOK(11);
		tb3 = F920_6990(RTCW(Result));
		if (tb3) break;
		RTHOOK(12);
		tr1 = F949_7076(RTCW(Result));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		loc3 = F949_7085(RTCW(tr1));
		tb4 = EIF_TRUE;
		for (;;) {
			if (!tb4) break;
			tb5 = F557_6081(loc3);
			if (tb5) break;
			RTHOOK(13);
			tb6 = '\01';
			tr1 = F557_6072(loc3);
			tb7 = *(EIF_BOOLEAN *)(RTCW(tr1) + O6725[Dtype(tr1)-1026]);
			if (!tb7) {
				tr1 = F557_6072(loc3);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
				tb6 = F164_2159(Current, tr1);
			}
			tb4 = tb6;
			F557_6087(loc3);
		}
		if (tb4) {
			RTHOOK(14);
			F949_7104(RTCW(Result));
		} else {
			RTHOOK(15);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5503[Dtype(RTCW(Result))-800])(Result);
		}
	}
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.expanded_switch_groups */
EIF_REFERENCE F164_2190 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("expanded_switch_groups", 163, Current, 2, 0, 2395);
	RTGC;
	RTHOOK(1);
	loc1 = RTOUCR(581,F164_2212, (Current));
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,28,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = F949_7092(RTCW(loc1));
	F949_7071(RTCW(Result), ti4_1);
	RTHOOK(3);
	tr1 = F949_7085(RTCW(loc1));
	loc2 = (EIF_REFERENCE) tr1;
	for (;;) {
		tb1 = F557_6081(loc2);
		if (tb1) break;
		RTHOOK(4);
		tr1 = F557_6072(loc2);
		tr1 = F164_2191(Current, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
		RTHOOK(5);
		F557_6087(loc2);
	}
	
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.expand_switch_group */
EIF_REFERENCE F164_2191 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,Result);
	RTLIU(9);
	
	RTEAA("expand_switch_group", 163, Current, 5, 1, 2396);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc1 = F1_14(tr1);
	RTHOOK(2);
	loc2 = RTOUCR(583,F164_2213, (Current));
	RTHOOK(3);
	tb1 = F762_6292(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(4);
		F949_7102(RTCW(loc1));
		for (;;) {
			RTHOOK(5);
			tb1 = F920_6990(RTCW(loc1));
			if (tb1) break;
			RTHOOK(6);
			loc3 = F949_7076(RTCW(loc1));
			RTHOOK(7);
			tr1 = F852_6727(RTCW(loc2), loc3);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				RTHOOK(8);
				loc5 = F879_6901(loc4);
				for (;;) {
					tb2 = F557_6081(loc5);
					if (tb2) break;
					RTHOOK(9);
					loc3 = F557_6072(loc5);
					RTHOOK(10);
					tb3 = F949_7083(RTCW(loc1), loc3);
					if ((EIF_BOOLEAN) !tb3) {
						RTHOOK(11);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(loc1))-759])(loc1, loc3);
						
					}
					RTHOOK(13);
					F557_6087(loc5);
				}
			}
			RTHOOK(14);
			F949_7104(RTCW(loc1));
		}
	}
	RTHOOK(15);
	tb3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
	if (tb3) {
		RTHOOK(16);
		Result = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_2_0_0_0_0_0_0_);
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_1_);
		F29_223(RTCW(Result), loc1, tb3);
	} else {
		RTHOOK(17);
		Result = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_2_0_0_0_0_0_0_);
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_1_);
		F29_224(RTCW(Result), loc1, tb3);
	}
	RTHOOK(20);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.add_error */
void F164_2192 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_error", 163, Current, 0, 1, 2397);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(567,F164_2143, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.add_template_error */
void F164_2193 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("add_template_error", 163, Current, 0, 2, 2398);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1252, 0x01).id, 1252, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = F1253_10566(RTCW(tr1), arg1, arg2);
	F164_2192(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.display_usage */
void F164_2194 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,loc1);
	RTLR(6,loc6);
	RTLR(7,loc4);
	RTLR(8,tr3);
	RTLR(9,loc2);
	RTLIU(10);
	
	RTEAA("display_usage", 163, Current, 6, 0, 2399);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	{
		/* INLINED CODE (ARGUMENT_BASE_PARSER.sub_system_name) */
		tr1 = (EIF_REFERENCE)  0;
		/* END INLINED CODE */
	}
	tr2 = tr1;
	loc5 = tr2;
	if (EIF_TEST(loc5)) {
		tb2 = F1086_8532(loc5);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		loc3 = RTLNSMART(eif_new_type(1085, 1).id);
		tr1 = F164_2144(Current);
		tr2 = F1078_8224(RTMS_EX_H(" ",1,32));
		tr1 = F1086_8524(RTCW(tr1), tr2);
		tr1 = F1086_8524(RTCW(tr1), loc5);
		F1085_8463(RTCW(loc3), tr1);
	} else {
		RTHOOK(3);
		loc3 = F164_2144(Current);
	}
	RTHOOK(4);
	tr1 = RTOUCR(4,F1_24, (Current));
	tr2 = F1078_8224(RTMS_EX_H("USAGE: \012",8,135033354));
	F86_1191(RTCW(tr1), tr2);
	RTHOOK(5);
	loc1 = RTOUCR(592,F164_2202, (Current));
	RTHOOK(6);
	tb1 = F762_6292(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(7);
		loc6 = F949_7085(RTCW(loc1));
		for (;;) {
			tb1 = F557_6081(loc6);
			if (tb1) break;
			RTHOOK(8);
			tr1 = RTOUCR(4,F1_24, (Current));
			tr2 = RTOUCR(593,F164_2220, (Current));
			F86_1191(RTCW(tr1), tr2);
			RTHOOK(9);
			tr1 = RTOUCR(4,F1_24, (Current));
			F86_1191(RTCW(tr1), loc3);
			RTHOOK(10);
			tr1 = RTOUCR(4,F1_24, (Current));
			tr2 = F1078_8224(RTMS_EX_H(" ",1,32));
			F86_1191(RTCW(tr1), tr2);
			RTHOOK(11);
			loc4 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
			tr1 = F557_6072(loc6);
			F1085_8463(RTCW(loc4), tr1);
			RTHOOK(12);
			tr1 = RTMS32_EX_H("\012\000\000\000",1,10);
			tr2 = RTMS32_EX_H("\012\000\000\000",1,10);
			tr3 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_0_0_2_);
			F1085_8462(RTCW(tr3), tw1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
			tr2 = F1087_8595(tr2, tr3);
			F1087_8553(RTCW(loc4), tr1, tr2);
			RTHOOK(13);
			tr1 = RTOUCR(4,F1_24, (Current));
			F86_1191(RTCW(tr1), loc4);
			RTHOOK(14);
			tb2 = F557_6085(loc6);
			if ((EIF_BOOLEAN) !tb2) {
				RTHOOK(15);
				F86_1212(RTCV(RTOUCR(4,F1_24, (Current))));
			}
			RTHOOK(16);
			F557_6087(loc6);
		}
	} else {
		RTHOOK(17);
		tr1 = RTOUCR(4,F1_24, (Current));
		tr2 = RTOUCR(593,F164_2220, (Current));
		F86_1191(RTCW(tr1), tr2);
		RTHOOK(18);
		tr1 = RTOUCR(4,F1_24, (Current));
		F86_1191(RTCW(tr1), loc3);
	}
	RTHOOK(19);
	if (F164_2169(Current)) {
		RTHOOK(20);
		F86_1212(RTCV(RTOUCR(4,F1_24, (Current))));
		RTHOOK(21);
		F164_2198(Current);
	}
	RTHOOK(22);
	loc2 = RTOUCR(594,F164_2205, (Current));
	RTHOOK(23);
	tb2 = F1086_8532(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb2) {
		RTHOOK(24);
		F86_1212(RTCV(RTOUCR(4,F1_24, (Current))));
		RTHOOK(25);
		tr1 = RTOUCR(4,F1_24, (Current));
		F86_1191(RTCW(tr1), loc2);
	}
	RTHOOK(26);
	F86_1212(RTCV(RTOUCR(4,F1_24, (Current))));
	RTHOOK(27);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.display_logo */
void F164_2195 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("display_logo", 163, Current, 0, 0, 2400);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(4,F1_24, (Current));
	tr2 = F1078_8224(RTCV(RTOUCR(81,F166_2242, (Current))));
	F86_1191(RTCW(tr1), tr2);
	RTHOOK(2);
	tr1 = RTOUCR(4,F1_24, (Current));
	tr2 = F1078_8224(RTMS_EX_H(" - Version: ",12,1246374688));
	F86_1191(RTCW(tr1), tr2);
	RTHOOK(3);
	tr1 = RTOUCR(4,F1_24, (Current));
	tr2 = F1078_8224(RTCV(RTOUCR(82,F166_2243, (Current))));
	F86_1191(RTCW(tr1), tr2);
	RTHOOK(4);
	tr1 = RTOUCR(83,F166_2244, (Current));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6919[Dtype(RTCW(tr1))-1081])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(5);
		F86_1212(RTCV(RTOUCR(4,F1_24, (Current))));
		RTHOOK(6);
		tr1 = RTOUCR(4,F1_24, (Current));
		tr2 = F1078_8224(RTCV(RTOUCR(83,F166_2244, (Current))));
		F86_1191(RTCW(tr1), tr2);
	}
	RTHOOK(7);
	F86_1212(RTCV(RTOUCR(4,F1_24, (Current))));
	RTHOOK(8);
	F86_1212(RTCV(RTOUCR(4,F1_24, (Current))));
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.display_version */
void F164_2196 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("display_version", 163, Current, 0, 0, 2401);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(4,F1_24, (Current));
	tr2 = F1078_8224(RTCV(RTOUCR(81,F166_2242, (Current))));
	F86_1191(RTCW(tr1), tr2);
	RTHOOK(2);
	tr1 = RTOUCR(4,F1_24, (Current));
	tr2 = F1078_8224(RTMS_EX_H(" version ",9,1056519968));
	F86_1191(RTCW(tr1), tr2);
	RTHOOK(3);
	tr1 = RTOUCR(4,F1_24, (Current));
	tr2 = F1078_8224(RTCV(RTOUCR(82,F166_2243, (Current))));
	F86_1191(RTCW(tr1), tr2);
	RTHOOK(4);
	tr1 = RTOUCR(83,F166_2244, (Current));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6919[Dtype(RTCW(tr1))-1081])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(5);
		F86_1212(RTCV(RTOUCR(4,F1_24, (Current))));
		RTHOOK(6);
		tr1 = RTOUCR(4,F1_24, (Current));
		tr2 = F1078_8224(RTCV(RTOUCR(83,F166_2244, (Current))));
		F86_1191(RTCW(tr1), tr2);
	}
	RTHOOK(7);
	F86_1212(RTCV(RTOUCR(4,F1_24, (Current))));
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.display_errors */
void F164_2197 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTEAA("display_errors", 163, Current, 2, 0, 2402);
	RTGC;
	RTHOOK(1);
	loc1 = RTOUCR(567,F164_2143, (Current));
	RTHOOK(2);
	tr1 = RTOUCR(30,F86_1160, (RTCV(RTOUCR(4,F1_24, (Current)))));
	tr2 = RTOUCR(575,F164_2181, (Current));
	tr3 = RTMS_EX_H("{1} error(s) occurred.\012",23,2016916746);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1025,1219,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr4 = RTLNTS(typres0.id, 2, 1);
	}
	ti4_1 = F949_7092(RTCW(loc1));
	((EIF_TYPED_VALUE *)tr4+1)->it_i4 = ti4_1;
	tr2 = F1253_10566(RTCW(tr2), tr3, tr4);
	F830_6659(RTCW(tr1), tr2);
	RTHOOK(3);
	tr1 = F949_7085(RTCW(loc1));
	loc2 = (EIF_REFERENCE) tr1;
	for (;;) {
		tb1 = F557_6081(loc2);
		if (tb1) break;
		RTHOOK(4);
		tr1 = RTOUCR(30,F86_1160, (RTCV(RTOUCR(4,F1_24, (Current)))));
		tr2 = RTOUCR(593,F164_2220, (Current));
		F830_6659(RTCW(tr1), tr2);
		RTHOOK(5);
		tr1 = RTOUCR(30,F86_1160, (RTCV(RTOUCR(4,F1_24, (Current)))));
		tr2 = F1078_8224(RTMS_EX_H("> ",2,15904));
		F830_6659(RTCW(tr1), tr2);
		RTHOOK(6);
		tr1 = RTOUCR(30,F86_1160, (RTCV(RTOUCR(4,F1_24, (Current)))));
		tr2 = F557_6072(loc2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(593,F164_2220, (Current)))+ _LNGOFF_1_0_0_2_);
		tu1_1 = (EIF_NATURAL_8) ti4_1;
		tr2 = F164_2204(Current, tr2, (EIF_NATURAL_8) (tu1_1 + (EIF_NATURAL_8) ((EIF_INTEGER_32) 2L)));
		F830_6659(RTCW(tr1), tr2);
		RTHOOK(7);
		tr1 = RTOUCR(30,F86_1160, (RTCV(RTOUCR(4,F1_24, (Current)))));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5240[Dtype(RTCW(tr1))-828])(tr1);
		RTHOOK(8);
		F557_6087(loc2);
	}
	RTHOOK(9);
	tr1 = RTOUCR(30,F86_1160, (RTCV(RTOUCR(4,F1_24, (Current)))));
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5240[Dtype(RTCW(tr1))-828])(tr1);
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.display_options */
void F164_2198 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc16 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc17 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc18 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTCFDT;
	RTLD;
	
	RTLI(22);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc7);
	RTLR(4,loc1);
	RTLR(5,loc3);
	RTLR(6,loc2);
	RTLR(7,loc4);
	RTLR(8,loc19);
	RTLR(9,loc5);
	RTLR(10,loc20);
	RTLR(11,loc21);
	RTLR(12,loc11);
	RTLR(13,loc10);
	RTLR(14,loc12);
	RTLR(15,loc22);
	RTLR(16,loc13);
	RTLR(17,loc15);
	RTLR(18,loc23);
	RTLR(19,loc24);
	RTLR(20,loc6);
	RTLR(21,loc14);
	RTLIU(22);
	
	RTEAA("display_options", 163, Current, 24, 0, 2403);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(4,F1_24, (Current));
	tr2 = F1078_8224(RTMS_EX_H("\012OPTIONS:\012",10,1841635338));
	F86_1191(RTCW(tr1), tr2);
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1027,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc7 = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F949_7071(RTCW(loc7), ((EIF_INTEGER_32) 0L));
	RTHOOK(3);
	loc1 = RTOUCR(570,F164_2217, (Current));
	RTHOOK(4);
	loc3 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1085_8461(RTCW(loc3), ((EIF_INTEGER_32) 1L));
	RTHOOK(5);
	tw1 = F885_6897(RTCW(loc1), ((EIF_INTEGER_32) 1L));
	F1087_8589(RTCW(loc3), tw1);
	RTHOOK(6);
	ti4_1 = F885_6904(RTCW(loc1));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
		RTHOOK(7);
		loc2 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = F885_6904(RTCW(loc1));
		F1085_8461(RTCW(loc2), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 5L)) + ((EIF_INTEGER_32) 2L)));
		RTHOOK(8);
		loc18 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_1_);
		RTHOOK(9);
		loc17 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_0_);
		for (;;) {
			RTHOOK(10);
			if ((EIF_BOOLEAN) (loc18 > loc17)) break;
			RTHOOK(11);
			if ((EIF_BOOLEAN) (loc18 > ((EIF_INTEGER_32) 1L))) {
				RTHOOK(12);
				if ((EIF_BOOLEAN) (loc18 < loc17)) {
					RTHOOK(13);
					tr1 = RTMS_EX_H(", ",2,11296);
					F1087_8575(RTCW(loc2), tr1);
				} else {
					RTHOOK(14);
					tr1 = RTMS_EX_H(" or ",4,544174624);
					F1087_8575(RTCW(loc2), tr1);
				}
			}
			RTHOOK(15);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\'';
			F1087_8589(RTCW(loc2), tw1);
			RTHOOK(16);
			tw1 = F885_6897(RTCW(loc1), loc18);
			F1087_8589(RTCW(loc2), tw1);
			RTHOOK(17);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\'';
			F1087_8589(RTCW(loc2), tw1);
			RTHOOK(18);
			loc18++;
		}
		RTHOOK(19);
		tr1 = RTOUCR(4,F1_24, (Current));
		tr2 = RTOUCR(593,F164_2220, (Current));
		F86_1191(RTCW(tr1), tr2);
		RTHOOK(20);
		tr1 = RTOUCR(4,F1_24, (Current));
		tr2 = F1078_8224(RTMS_EX_H("Options ",8,506073632));
		F86_1191(RTCW(tr1), tr2);
		RTHOOK(21);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_)) {
			RTHOOK(22);
			tr1 = RTOUCR(4,F1_24, (Current));
			tr2 = F1078_8224(RTMS_EX_H("are case-sensitive and ",23,1259914016));
			F86_1191(RTCW(tr1), tr2);
		}
		RTHOOK(23);
		tr1 = RTOUCR(4,F1_24, (Current));
		tr2 = F1078_8224(RTMS_EX_H("should be prefixed with: ",25,889669920));
		F86_1191(RTCW(tr1), tr2);
		RTHOOK(24);
		tr1 = RTOUCR(4,F1_24, (Current));
		F86_1191(RTCW(tr1), loc2);
		RTHOOK(25);
		F86_1212(RTCV(RTOUCR(4,F1_24, (Current))));
		RTHOOK(26);
		F86_1212(RTCV(RTOUCR(4,F1_24, (Current))));
	}
	RTHOOK(27);
	loc4 = RTOUCR(573,F164_2210, (Current));
	RTHOOK(28);
	loc19 = F949_7085(RTCW(loc4));
	for (;;) {
		tb1 = F557_6081(loc19);
		if (tb1) break;
		RTHOOK(29);
		loc5 = F557_6072(loc19);
		RTHOOK(30);
		tb2 = *(EIF_BOOLEAN *)(RTCW(loc5) + O6727[Dtype(loc5)-1026]);
		if ((EIF_BOOLEAN) !tb2) {
			RTHOOK(31);
			tb2 = '\01';
			if (!RTOUCB(EIF_BOOLEAN,569,F164_2167, (Current))) {
				tb3 = F1027_7952(RTCW(loc5));
				tb2 = tb3;
			}
			if (tb2) {
				RTHOOK(32);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_2_);
				ti4_1 = eif_max_int32 (loc9,(EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 5L)));
				loc9 = (EIF_INTEGER_32) ti4_1;
			} else {
				RTHOOK(33);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_2_);
				ti4_1 = eif_max_int32 (loc9,(EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
				loc9 = (EIF_INTEGER_32) ti4_1;
			}
		}
		RTHOOK(34);
		F557_6087(loc19);
	}
	RTHOOK(35);
	loc16 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_);
	RTHOOK(36);
	loc20 = F949_7085(RTCW(loc4));
	for (;;) {
		tb2 = F557_6081(loc20);
		if (tb2) break;
		RTHOOK(37);
		loc5 = F557_6072(loc20);
		RTHOOK(38);
		loc21 = loc5;
		loc21 = RTRV(eif_new_type(1027, 0x01),loc21);
		if (EIF_TEST(loc21)) {
			RTHOOK(39);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(loc7))-759])(loc7, loc21);
		}
		RTHOOK(40);
		tb3 = F1027_7952(RTCW(loc5));
		if (tb3) {
			RTHOOK(41);
			loc11 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1085_8461(RTCW(loc11), ((EIF_INTEGER_32) 20L));
			RTHOOK(42);
			F1087_8576(RTCW(loc11), loc3);
			RTHOOK(43);
			tw1 = *(EIF_CHARACTER_32 *)(RTCW(loc5) + O6723[Dtype(loc5)-1026]);
			F1087_8589(RTCW(loc11), tw1);
			RTHOOK(44);
			tr1 = RTMS_EX_H(" ",1,32);
			F1087_8575(RTCW(loc11), tr1);
			RTHOOK(45);
			if (RTOUCB(EIF_BOOLEAN,569,F164_2167, (Current))) {
				RTHOOK(46);
				F1087_8576(RTCW(loc11), loc3);
			}
			RTHOOK(47);
			F1087_8576(RTCW(loc11), loc3);
			RTHOOK(48);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
			F1087_8576(RTCW(loc11), tr1);
		} else {
			RTHOOK(49);
			if (RTOUCB(EIF_BOOLEAN,569,F164_2167, (Current))) {
				RTHOOK(50);
				tr1 = RTMS32_EX_H(" \000\000\000 \000\000\000 \000\000\000",3,2105376);
				tr1 = F1087_8595(tr1, loc3);
				tr1 = F1087_8595(RTCW(tr1), loc3);
				tr2 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
				loc11 = F1087_8595(RTCW(tr1), tr2);
			} else {
				RTHOOK(51);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
				loc11 = F1087_8595(RTCW(loc3), tr1);
			}
		}
		RTHOOK(52);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc9 > ti4_1)) {
			RTHOOK(53);
			loc10 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_1_1_0_2_);
			F1085_8462(RTCW(loc10), tw1, (EIF_INTEGER_32) (loc9 - ti4_1));
		} else {
			RTHOOK(54);
			loc10 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1078_8165(RTCW(loc10));
		}
		RTHOOK(55);
		F1087_8593(RTCW(loc10), loc11, ((EIF_INTEGER_32) 1L));
		RTHOOK(56);
		loc12 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1085_8461(RTCW(loc12), ((EIF_INTEGER_32) 256L));
		RTHOOK(57);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_2_);
		F1087_8576(RTCW(loc12), tr1);
		RTHOOK(58);
		tb3 = *(EIF_BOOLEAN *)(RTCW(loc5) + O6725[Dtype(loc5)-1026]);
		if (tb3) {
			RTHOOK(59);
			tr1 = RTMS_EX_H(" (Optional)",11,1464035113);
			F1087_8575(RTCW(loc12), tr1);
		}
		RTHOOK(60);
		loc8 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_1_1_0_2_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(593,F164_2220, (Current)))+ _LNGOFF_1_0_0_2_);
		loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 + ti4_1) + ((EIF_INTEGER_32) 2L));
		RTHOOK(61);
		tu1_1 = (EIF_NATURAL_8) loc8;
		tr1 = F164_2204(Current, loc12, tu1_1);
		loc12 = (EIF_REFERENCE) tr1;
		RTHOOK(62);
		loc22 = loc5;
		loc22 = RTRV(eif_new_type(1027, 0x01),loc22);
		if ((EIF_BOOLEAN) (loc16 && EIF_TEST(loc22))) {
			RTHOOK(63);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
			F1087_8589(RTCW(loc12), tw1);
			RTHOOK(64);
			tr1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
			F1085_8462(RTCW(tr1), tw1, loc8);
			F1087_8576(RTCW(loc12), tr1);
			RTHOOK(65);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '<';
			F1087_8589(RTCW(loc12), tw1);
			RTHOOK(66);
			tr1 = *(EIF_REFERENCE *)(loc22 + _REFACS_3_);
			F1087_8576(RTCW(loc12), tr1);
			RTHOOK(67);
			tr1 = RTMS_EX_H(">: ",3,4078112);
			F1087_8575(RTCW(loc12), tr1);
			RTHOOK(68);
			loc13 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1085_8461(RTCW(loc13), ((EIF_INTEGER_32) 32L));
			RTHOOK(69);
			tb3 = *(EIF_BOOLEAN *)(loc22+ _CHROFF_5_4_);
			if (tb3) {
				RTHOOK(70);
				tr1 = RTMS_EX_H("(Optional) ",11,342873376);
				F1087_8575(RTCW(loc13), tr1);
			}
			RTHOOK(71);
			tr1 = *(EIF_REFERENCE *)(loc22 + _REFACS_4_);
			F1087_8576(RTCW(loc13), tr1);
			RTHOOK(72);
			tr1 = *(EIF_REFERENCE *)(loc22 + _REFACS_3_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_2_);
			tu1_1 = (EIF_NATURAL_8) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 + ti4_1) + ((EIF_INTEGER_32) 4L));
			tr1 = F164_2204(Current, loc13, tu1_1);
			loc13 = (EIF_REFERENCE) tr1;
			RTHOOK(73);
			F1087_8576(RTCW(loc12), loc13);
		}
		RTHOOK(74);
		tr1 = RTOUCR(4,F1_24, (Current));
		tr2 = RTOUCR(593,F164_2220, (Current));
		F86_1191(RTCW(tr1), tr2);
		RTHOOK(75);
		tr1 = RTOUCR(4,F1_24, (Current));
		F86_1191(RTCW(tr1), loc10);
		RTHOOK(76);
		tr1 = RTOUCR(4,F1_24, (Current));
		tr2 = F1078_8224(RTMS_EX_H(": ",2,14880));
		F86_1191(RTCW(tr1), tr2);
		RTHOOK(77);
		tr1 = RTOUCR(4,F1_24, (Current));
		F86_1191(RTCW(tr1), loc12);
		RTHOOK(78);
		F86_1212(RTCV(RTOUCR(4,F1_24, (Current))));
		RTHOOK(79);
		F557_6087(loc20);
	}
	RTHOOK(80);
	tb3 = '\0';
	if ((EIF_BOOLEAN) !loc16) {
		tb4 = F762_6292(RTCW(loc7));
		tb3 = (EIF_BOOLEAN) !tb4;
	}
	if (tb3) {
		RTHOOK(81);
		tr1 = RTOUCR(4,F1_24, (Current));
		tr2 = F1078_8224(RTMS_EX_H("\012ARGUMENTS:\012",12,1590959370));
		F86_1191(RTCW(tr1), tr2);
		RTHOOK(82);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,861,1037,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc15 = RTLNS(typres0.id, 861, _OBJSIZ_5_6_0_7_0_0_0_0_);
		}
		ti4_1 = F949_7092(RTCW(loc7));
		F854_6721(RTCW(loc15), ti4_1);
		RTHOOK(83);
		loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		RTHOOK(84);
		loc23 = F949_7085(RTCW(loc7));
		for (;;) {
			tb3 = F557_6081(loc23);
			if (tb3) break;
			RTHOOK(85);
			tr1 = F557_6072(loc23);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_2_);
			ti4_1 = eif_max_int32 (loc9,ti4_1);
			loc9 = (EIF_INTEGER_32) ti4_1;
			RTHOOK(86);
			F557_6087(loc23);
		}
		RTHOOK(87);
		loc24 = F949_7085(RTCW(loc7));
		for (;;) {
			tb4 = F557_6081(loc24);
			if (tb4) break;
			RTHOOK(88);
			loc6 = F557_6072(loc24);
			RTHOOK(89);
			loc14 = *(EIF_REFERENCE *)(RTCW(loc6) + _REFACS_3_);
			RTHOOK(90);
			tb5 = F854_6729(RTCW(loc15), loc14);
			if ((EIF_BOOLEAN) !tb5) {
				RTHOOK(91);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc14)+ _LNGOFF_1_0_0_2_);
				if ((EIF_BOOLEAN) (loc9 > ti4_1)) {
					RTHOOK(92);
					loc10 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc14)+ _LNGOFF_1_0_0_2_);
					F1085_8462(RTCW(loc10), tw1, (EIF_INTEGER_32) (loc9 - ti4_1));
				} else {
					RTHOOK(93);
					loc10 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1078_8165(RTCW(loc10));
				}
				RTHOOK(94);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '<';
				F1087_8594(RTCW(loc10), tw1, ((EIF_INTEGER_32) 1L));
				RTHOOK(95);
				F1087_8593(RTCW(loc10), loc14, ((EIF_INTEGER_32) 2L));
				RTHOOK(96);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc14)+ _LNGOFF_1_0_0_2_);
				F1087_8594(RTCW(loc10), tw1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
				RTHOOK(97);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc6) + _REFACS_4_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc14)+ _LNGOFF_1_0_0_2_);
				ti4_2 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(593,F164_2220, (Current)))+ _LNGOFF_1_0_0_2_);
				tu1_1 = (EIF_NATURAL_8) (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 4L));
				loc12 = F164_2204(Current, tr1, tu1_1);
				RTHOOK(98);
				tr1 = RTOUCR(4,F1_24, (Current));
				tr2 = RTOUCR(593,F164_2220, (Current));
				F86_1191(RTCW(tr1), tr2);
				RTHOOK(99);
				tr1 = RTOUCR(4,F1_24, (Current));
				F86_1191(RTCW(tr1), loc10);
				RTHOOK(100);
				tr1 = RTOUCR(4,F1_24, (Current));
				tr2 = F1078_8224(RTMS_EX_H(": ",2,14880));
				F86_1191(RTCW(tr1), tr2);
				RTHOOK(101);
				tr1 = RTOUCR(4,F1_24, (Current));
				F86_1191(RTCW(tr1), loc12);
				RTHOOK(102);
				F86_1212(RTCV(RTOUCR(4,F1_24, (Current))));
				RTHOOK(103);
				F854_6767(RTCW(loc15), (EIF_BOOLEAN) 1, loc14);
			}
			RTHOOK(104);
			F557_6087(loc24);
		}
	}
	RTHOOK(105);
	RTLE;
	RTEE;
}

/* {ARGUMENT_BASE_PARSER}.command_option_configurations */
static EIF_REFERENCE F164_2202_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(592)
	dftype = Dftype(Current);

	RTLI(11);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,loc4);
	RTLR(7,loc3);
	RTLR(8,loc7);
	RTLR(9,loc2);
	RTLR(10,loc5);
	RTLIU(11);
	
	RTEAA("command_option_configurations", 163, Current, 8, 0, 2404);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1085,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F608_6140(RTCW(Result));
	RTHOOK(3);
	loc1 = RTOUCR(581,F164_2212, (Current));
	RTHOOK(4);
	loc6 = F762_6292(RTCW(loc1));
	RTHOOK(5);
	if ((EIF_BOOLEAN) !loc6) {
		RTHOOK(6);
		{
			EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1025,0xFF01,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[4] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
		RTAR(tr1,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1076,0xFF01,0xFFF9,1,1025,0xFF01,28,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A140_132_2, (EIF_POINTER) _A140_132_2, 0, tr1, 0, 1);
		}
		loc6 = F949_7089(RTCW(loc1), tr4);
	}
	RTHOOK(7);
	if (loc6) {
		RTHOOK(8);
		loc4 = RTOUCR(573,F164_2210, (Current));
		RTHOOK(9);
		loc3 = F164_2203(Current, loc4, *(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_), *(EIF_BOOLEAN *)(Current+ _CHROFF_4_8_), (EIF_BOOLEAN) 1, loc4);
		RTHOOK(10);
		tb1 = F768_6292(RTCW(loc3));
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(11);
			tr1 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
			F1086_8516(RTCW(tr1), loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
		}
	} else {
		RTHOOK(12);
		F949_7120(RTCW(Result), ((EIF_INTEGER_32) 1024L));
		RTHOOK(13);
		tr1 = F949_7085(RTCW(loc1));
		loc7 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = F557_6081(loc7);
			if (tb1) break;
			RTHOOK(14);
			loc2 = F557_6072(loc7);
			RTHOOK(15);
			tb2 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_1_0_);
			if ((EIF_BOOLEAN) !tb2) {
				RTHOOK(16);
				loc4 = *(EIF_REFERENCE *)(RTCW(loc2));
				RTHOOK(17);
				tr1 = RTOUCR(577,F164_2206, (Current));
				if (F164_2171(Current, tr1)) {
					RTHOOK(18);
					tr1 = RTOUCR(577,F164_2206, (Current));
					loc5 = F164_2180(Current, tr1);
					RTHOOK(19);
					tb2 = F949_7083(RTCW(loc4), loc5);
					if ((EIF_BOOLEAN) !tb2) {
						RTHOOK(20);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(loc4))-759])(loc4, loc5);
					}
				}
				RTHOOK(21);
				tb2 = '\0';
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_7_)) {
					tb3 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_1_1_);
					tb2 = tb3;
				}
				loc3 = F164_2203(Current, loc4, tb2, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1, loc4);
				RTHOOK(22);
				tb2 = '\0';
				tb3 = F768_6292(RTCW(loc3));
				if ((EIF_BOOLEAN) !tb3) {
					tr1 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
					F1086_8516(RTCW(tr1), loc3);
					tb3 = F949_7083(RTCW(Result), tr1);
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (tb2) {
					RTHOOK(23);
					tr1 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
					F1086_8516(RTCW(tr1), loc3);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, tr1);
				}
			}
			RTHOOK(24);
			F557_6087(loc7);
		}
	}
	RTOTE;
	RTHOOK(32);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2202 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(592,F164_2202_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.command_option_group_configuration */
EIF_REFERENCE F164_2203 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4, EIF_REFERENCE arg5)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc8 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc11 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLR(5,loc14);
	RTLR(6,loc6);
	RTLR(7,tr2);
	RTLR(8,arg5);
	RTLR(9,loc15);
	RTLR(10,loc16);
	RTLR(11,loc2);
	RTLR(12,loc17);
	RTLR(13,loc7);
	RTLIU(14);
	
	RTEAA("command_option_group_configuration", 163, Current, 17, 5, 2405);
	RTGC;
	RTHOOK(1);
	tb1 = F762_6292(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		loc1 = RTOUCR(583,F164_2213, (Current));
		RTHOOK(3);
		tr1 = RTOUCR(570,F164_2217, (Current));
		loc8 = F885_6897(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		loc3 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_);
		RTHOOK(5);
		loc4 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_);
		RTHOOK(6);
		loc5 = RTOUCB(EIF_BOOLEAN,569,F164_2167, (Current));
		RTHOOK(7);
		Result = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5561[Dtype(RTCW(arg1))-800])(arg1);
		F1085_8461(RTCW(Result), (EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 12L)));
		RTHOOK(8);
		loc14 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5345[Dtype(RTCW(arg1))-509])(arg1);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5315[Dtype(loc14)-479])(loc14);
			if (tb1) break;
			RTHOOK(9);
			loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5314[Dtype(loc14)-479])(loc14);
			RTHOOK(10);
			loc9 = *(EIF_BOOLEAN *)(RTCW(loc6) + O6725[Dtype(loc6)-1026]);
			RTHOOK(11);
			tb2 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
			tr2 = RTOUCR(580,F164_2207, (Current));
			tb3 = F1085_8488(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN) !tb3) {
				tb3 = *(EIF_BOOLEAN *)(RTCW(loc6) + O6727[Dtype(loc6)-1026]);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				RTHOOK(12);
				loc11 = '\01';
				if ((EIF_BOOLEAN) !arg4) {
					tb2 = '\01';
					tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5454[Dtype(RTCW(arg5))-759])(arg5, loc6);
					if (!(EIF_BOOLEAN) !tb3) {
						tb3 = *(EIF_BOOLEAN *)(RTCW(loc6) + O6725[Dtype(loc6)-1026]);
						tb2 = tb3;
					}
					loc11 = tb2;
				}
				RTHOOK(13);
				if (loc11) {
					RTHOOK(14);
					if (loc9) {
						RTHOOK(15);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
						F1087_8589(RTCW(Result), tw1);
					}
					RTHOOK(16);
					F1087_8589(RTCW(Result), loc8);
					RTHOOK(17);
					if (loc4) {
						RTHOOK(18);
						if (loc5) {
							RTHOOK(19);
							F1087_8589(RTCW(Result), loc8);
						}
						RTHOOK(20);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc6) + _REFACS_1_);
						F1087_8576(RTCW(Result), tr1);
					} else {
						RTHOOK(21);
						tb2 = '\0';
						if (loc5) {
							tb3 = F1027_7952(RTCW(loc6));
							tb2 = (EIF_BOOLEAN) !tb3;
						}
						if (tb2) {
							RTHOOK(22);
							F1087_8589(RTCW(Result), loc8);
						}
						RTHOOK(23);
						tr1 = F1027_7943(RTCW(loc6));
						F1087_8576(RTCW(Result), tr1);
					}
					RTHOOK(24);
					loc15 = loc6;
					loc15 = RTRV(eif_new_type(1027, 0x01),loc15);
					if (EIF_TEST(loc15)) {
						RTHOOK(25);
						loc10 = *(EIF_BOOLEAN *)(loc15+ _CHROFF_5_4_);
						RTHOOK(26);
						if (loc10) {
							RTHOOK(27);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
							F1087_8589(RTCW(Result), tw1);
						}
						RTHOOK(28);
						if (loc3) {
							RTHOOK(29);
							tr1 = RTMS_EX_H(" <",2,8252);
							F1087_8575(RTCW(Result), tr1);
						} else {
							RTHOOK(30);
							tw1 = RTOUCB(EIF_CHARACTER_32,571,F164_2218, (Current));
							F1087_8589(RTCW(Result), tw1);
							RTHOOK(31);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '<';
							F1087_8589(RTCW(Result), tw1);
						}
						RTHOOK(32);
						tr1 = *(EIF_REFERENCE *)(loc15 + _REFACS_3_);
						F1087_8576(RTCW(Result), tr1);
						RTHOOK(33);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
						F1087_8589(RTCW(Result), tw1);
						RTHOOK(34);
						if (loc10) {
							RTHOOK(35);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
							F1087_8589(RTCW(Result), tw1);
						}
					}
					RTHOOK(36);
					tb2 = '\0';
					if ((EIF_BOOLEAN)(loc1 != NULL)) {
						tb3 = F852_6729(RTCW(loc1), loc6);
						tb2 = tb3;
					}
					if (tb2) {
						RTHOOK(37);
						tr1 = F852_6727(RTCW(loc1), loc6);
						loc16 = tr1;
						if (EIF_TEST(loc16)) {
							RTHOOK(38);
							tb2 = F762_6292(loc16);
							if ((EIF_BOOLEAN) !tb2) {
								RTHOOK(39);
								{
									static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1026,0xFFFF};
									EIF_TYPE typres0;
									static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
									
									typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
									loc2 = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
								}
								ti4_1 = F879_6904(loc16);
								F949_7071(RTCW(loc2), ti4_1);
								RTHOOK(40);
								loc12 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								RTHOOK(41);
								loc13 = *(EIF_INTEGER_32 *)(loc16+ _LNGOFF_1_1_0_0_);
								for (;;) {
									RTHOOK(42);
									if ((EIF_BOOLEAN) (loc12 > loc13)) break;
									RTHOOK(43);
									tr1 = F879_6897(loc16, loc12);
									loc17 = tr1;
									if ((EIF_TRUE)) {
										RTHOOK(44);
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(loc2))-759])(loc2, loc17);
									}
									RTHOOK(45);
									loc12++;
								}
								RTHOOK(46);
								loc7 = F164_2203(Current, loc2, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, arg5);
								RTHOOK(47);
								tb2 = F768_6292(RTCW(loc7));
								if ((EIF_BOOLEAN) !tb2) {
									RTHOOK(48);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
									F1087_8589(RTCW(Result), tw1);
									RTHOOK(49);
									F1087_8576(RTCW(Result), loc7);
								}
							}
						} else {
							
						}
					}
					RTHOOK(51);
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc6) + O6726[Dtype(loc6)-1026]);
					if (tb2) {
						RTHOOK(52);
						tr1 = RTMS_EX_H(" [",2,8283);
						F1087_8575(RTCW(Result), tr1);
						RTHOOK(53);
						F1087_8589(RTCW(Result), loc8);
						RTHOOK(54);
						tr1 = F1027_7943(RTCW(loc6));
						F1087_8576(RTCW(Result), tr1);
						RTHOOK(55);
						tr1 = RTMS_EX_H("...]",4,774778461);
						F1087_8575(RTCW(Result), tr1);
					}
					RTHOOK(56);
					if (loc9) {
						RTHOOK(57);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
						F1087_8589(RTCW(Result), tw1);
					}
					RTHOOK(58);
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5409[Dtype(loc14)-534])(loc14);
					if ((EIF_BOOLEAN) !tb2) {
						RTHOOK(59);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
						F1087_8589(RTCW(Result), tw1);
					}
				}
			}
			RTHOOK(60);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5316[Dtype(loc14)-479])(loc14);
		}
	} else {
		RTHOOK(61);
		Result = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1078_8165(RTCW(Result));
		RTHOOK(62);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(65);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.format_terminal_text */
EIF_REFERENCE F164_2204 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_8 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc3);
	RTLR(5,Result);
	RTLR(6,loc5);
	RTLIU(7);
	
	RTEAA("format_terminal_text", 163, Current, 5, 2, 2406);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8224(RTCW(arg1));
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
	loc2 = F1078_8243(RTCW(tr1), tw1);
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) RTOUCB(EIF_NATURAL_32,572,F164_2151, (Current));
	ti4_1 = (EIF_INTEGER_32) arg2;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
	RTHOOK(3);
	loc3 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
	ti4_1 = (EIF_INTEGER_32) arg2;
	F1085_8462(RTCW(loc3), tw1, ti4_1);
	RTHOOK(4);
	Result = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6941[Dtype(RTCW(arg1))-1081])(arg1);
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5561[Dtype(RTCW(loc2))-800])(loc2);
	ti4_3 = (EIF_INTEGER_32) ((EIF_NATURAL_8) (arg2 + (EIF_NATURAL_8) ((EIF_INTEGER_32) 1L)));
	F1085_8461(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (ti4_2 * ti4_3)));
	RTHOOK(5);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5465[Dtype(RTCW(loc2))-759])(loc2);
	for (;;) {
		RTHOOK(6);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5476[Dtype(RTCW(loc2))-759])(loc2);
		if (tb1) break;
		RTHOOK(7);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5498[Dtype(RTCW(loc2))-759])(loc2);
		loc5 = tr1;
		if ((EIF_TRUE)) {
			RTHOOK(8);
			tb2 = F768_6292(RTCW(Result));
			if ((EIF_BOOLEAN) !tb2) {
				RTHOOK(9);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				F1087_8589(RTCW(Result), tw1);
				RTHOOK(10);
				F1087_8576(RTCW(Result), loc3);
			}
			RTHOOK(11);
			ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > loc1)) {
				RTHOOK(12);
				ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
				loc4 = eif_min_int32 (ti4_1,loc1);
				for (;;) {
					RTHOOK(13);
					tb2 = '\01';
					tb3 = '\01';
					if (!(EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
						tw1 = F1087_8543(loc5, loc4);
						tr1 = RTLNS(eif_new_type(1031, 0x00).id, 1031, _OBJSIZ_0_0_0_1_0_0_0_0_);
						*(EIF_CHARACTER_32 *)tr1 = tw1;
						tb4 = F1030_8001(RTCW(tr1));
						tb3 = tb4;
					}
					if (!tb3) {
						tw1 = F1087_8543(loc5, loc4);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) break;
					RTHOOK(14);
					loc4--;
				}
				RTHOOK(15);
				if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
					RTHOOK(16);
					loc4 = (EIF_INTEGER_32) loc1;
				}
				RTHOOK(17);
				tr1 = F1087_8623(loc5, ((EIF_INTEGER_32) 1L), loc4);
				F1087_8576(RTCW(Result), tr1);
				RTHOOK(18);
				ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
				F1087_8559(loc5, (EIF_INTEGER_32) (ti4_1 - loc4));
				RTHOOK(19);
				F1087_8560(loc5);
			} else {
				RTHOOK(20);
				F1087_8576(RTCW(Result), loc5);
				RTHOOK(21);
				F1087_8605(loc5);
			}
			RTHOOK(22);
			tb3 = F768_6292(loc5);
			if (tb3) {
				RTHOOK(23);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5478[Dtype(RTCW(loc2))-759])(loc2);
			}
		} else {
			RTHOOK(24);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5478[Dtype(RTCW(loc2))-759])(loc2);
		}
	}
	RTHOOK(27);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.extended_usage */
static EIF_REFERENCE F164_2205_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(594)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("extended_usage", 163, Current, 0, 0, 2407);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	F1078_8165(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2205 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(594,F164_2205_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.nologo_switch */
static EIF_REFERENCE F164_2206_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(577)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("nologo_switch", 163, Current, 0, 0, 2408);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("nologo",6,2036361583);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2206 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(577,F164_2206_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.help_switch */
static EIF_REFERENCE F164_2207_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(580)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("help_switch", 163, Current, 0, 0, 2409);
	RTGC;
	RTOTP;
	RTHOOK(1);
	if (RTOUCB(EIF_BOOLEAN,569,F164_2167, (Current))) {
		RTHOOK(2);
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			RTHOOK(3);
			tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
			tr2 = RTMS_EX_H("\?|help",6,1876292720);
			F1086_8514(RTCW(tr1), tr2);
			Result = (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(4);
			tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
			tr2 = RTMS_EX_H("h|help",6,1956902000);
			F1086_8514(RTCW(tr1), tr2);
			Result = (EIF_REFERENCE) tr1;
		}
	} else {
		RTHOOK(5);
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			RTHOOK(6);
			tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
			tr2 = RTMS_EX_H("\?",1,63);
			F1086_8515(RTCW(tr1), tr2);
			Result = (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(7);
			tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
			tr2 = RTMS_EX_H("help",4,1751477360);
			F1086_8515(RTCW(tr1), tr2);
			Result = (EIF_REFERENCE) tr1;
		}
	}
	RTOTE;
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2207 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(580,F164_2207_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.version_switch */
static EIF_REFERENCE F164_2208_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(576)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("version_switch", 163, Current, 0, 0, 2410);
	RTGC;
	RTOTP;
	RTHOOK(1);
	if (RTOUCB(EIF_BOOLEAN,569,F164_2167, (Current))) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr2 = RTMS_EX_H("v|version",9,1943702638);
		F1086_8514(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(3);
		tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr2 = RTMS_EX_H("version",7,1397649262);
		F1086_8514(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	}
	RTOTE;
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2208 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(576,F164_2208_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.available_switches */
static EIF_REFERENCE F164_2209_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(574)
	dftype = Dftype(Current);

	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTEAA("available_switches", 163, Current, 2, 0, 2411);
	RTGC;
	RTOTP;
	RTHOOK(1);
	loc1 = RTOUCR(85,F166_2245, (Current));
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1026,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		ti4_1 = F949_7092(RTCW(loc1));
		F949_7071(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) + ti4_1));
		Result = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5583[Dtype(RTCW(Result))-943])(Result, loc1);
	} else {
		RTHOOK(5);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1026,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 3L));
		Result = (EIF_REFERENCE) tr1;
	}
	RTHOOK(6);
	loc2 = RTLNS(eif_new_type(1026, 0x01).id, 1026, _OBJSIZ_3_4_0_1_0_0_0_0_);
	tr1 = RTOUCR(580,F164_2207, (Current));
	tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr3 = RTMS_EX_H("Display usage information.",26,790767406);
	F1086_8515(RTCW(tr2), tr3);
	F1027_7940(RTCW(loc2), tr1, tr2, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	RTHOOK(7);
	F1027_7954(RTCW(loc2));
	RTHOOK(8);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, loc2);
	RTHOOK(9);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_6_)) {
		RTHOOK(10);
		loc2 = RTLNS(eif_new_type(1026, 0x01).id, 1026, _OBJSIZ_3_4_0_1_0_0_0_0_);
		tr1 = RTOUCR(576,F164_2208, (Current));
		tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr3 = RTMS_EX_H("Displays version information.",29,582720558);
		F1086_8515(RTCW(tr2), tr3);
		F1027_7940(RTCW(loc2), tr1, tr2, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
		RTHOOK(11);
		F1027_7954(RTCW(loc2));
		RTHOOK(12);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, loc2);
		RTHOOK(13);
		loc2 = RTLNS(eif_new_type(1026, 0x01).id, 1026, _OBJSIZ_3_4_0_1_0_0_0_0_);
		tr1 = RTOUCR(577,F164_2206, (Current));
		tr2 = RTLNS(eif_new_type(1085, 0x00).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr3 = RTMS_EX_H("Supresses copyright information.",32,1705082414);
		F1086_8515(RTCW(tr2), tr3);
		F1027_7940(RTCW(loc2), tr1, tr2, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
		RTHOOK(14);
		F1027_7954(RTCW(loc2));
		RTHOOK(15);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, loc2);
	}
	RTOTE;
	RTHOOK(18);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2209 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(574,F164_2209_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.available_visible_switches */
static EIF_REFERENCE F164_2210_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(573)

	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("available_visible_switches", 163, Current, 3, 0, 2412);
	RTGC;
	RTOTP;
	RTHOOK(1);
	loc1 = RTOUCR(574,F164_2209, (Current));
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,1026,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = F949_7092(RTCW(loc1));
	F949_7071(RTCW(tr1), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = F949_7085(RTCW(loc1));
	loc3 = (EIF_REFERENCE) tr1;
	for (;;) {
		tb1 = F557_6081(loc3);
		if (tb1) break;
		RTHOOK(4);
		loc2 = F557_6072(loc3);
		RTHOOK(5);
		tb2 = *(EIF_BOOLEAN *)(RTCW(loc2) + O6727[Dtype(loc2)-1026]);
		if ((EIF_BOOLEAN) !tb2) {
			RTHOOK(6);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(Result))-759])(Result, loc2);
		}
		RTHOOK(7);
		F557_6087(loc3);
	}
	RTOTE;
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2210 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(573,F164_2210_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.switch_groups */
static EIF_REFERENCE F164_2212_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(581)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("switch_groups", 163, Current, 0, 0, 2413);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,948,0xFF01,28,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 948, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F949_7071(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2212 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(581,F164_2212_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.switch_dependencies */
static EIF_REFERENCE F164_2213_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(583)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("switch_dependencies", 163, Current, 0, 0, 2414);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,851,0xFF01,878,0xFF01,1026,0xFF01,1026,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 851, _OBJSIZ_7_3_0_7_0_0_0_0_);
	}
	F852_6721(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2213 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(583,F164_2213_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.ellipse_text */
EIF_REFERENCE F164_2214 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("ellipse_text", 163, Current, 0, 1, 2415);
	RTGC;
	RTHOOK(1);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6919[Dtype(RTCW(arg1))-1081])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		tr1 = RTOUCR(575,F164_2181, (Current));
		ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_8) 255U);
		Result = F1253_10567(RTCW(tr1), arg1, ti4_1);
	} else {
		RTHOOK(3);
		Result = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1078_8165(RTCW(Result));
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.switch_prefixes */
static EIF_REFERENCE F164_2217_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_CHARACTER_32 tw1;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(570)
	dftype = Dftype(Current);

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("switch_prefixes", 163, Current, 1, 0, 2418);
	RTGC;
	RTOTP;
	RTHOOK(1);
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {1146,1031,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 2L),sizeof(EIF_CHARACTER_32), EIF_TRUE);
			RT_SPECIAL_COUNT(tr2) = 2L;
		}
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
		*((EIF_CHARACTER_32 *)tr2+0) = (EIF_CHARACTER_32) tw1;
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
		*((EIF_CHARACTER_32 *)tr2+1) = (EIF_CHARACTER_32) tw1;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1147_9214)(tr2);
	} else {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {1146,1031,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 1L),sizeof(EIF_CHARACTER_32), EIF_TRUE);
			RT_SPECIAL_COUNT(tr3) = 1L;
		}
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
		*((EIF_CHARACTER_32 *)tr3+0) = (EIF_CHARACTER_32) tw1;
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1147_9214)(tr3);
		tr1 = tr2;
	}
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2217 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(570,F164_2217_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.switch_value_qualifer */
static EIF_CHARACTER_32 F164_2218_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRB(EIF_CHARACTER_32)
	RTOUDB(EIF_CHARACTER_32, 571)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("switch_value_qualifer", 163, Current, 0, 0, 2419);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_32 F164_2218 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_CHARACTER_32,571,F164_2218_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.default_system_name */
static EIF_REFERENCE F164_2219_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(568)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("default_system_name", 163, Current, 0, 0, 2420);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("app",3,6385776);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2219 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(568,F164_2219_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.tab_string */
static EIF_REFERENCE F164_2220_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(593)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("tab_string", 163, Current, 0, 0, 2421);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("   ",3,2105376);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2220 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(593,F164_2220_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_invalid_switch_error */
static EIF_REFERENCE F164_2221_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(578)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("e_invalid_switch_error", 163, Current, 0, 0, 2422);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("The switch \'{1}\' is invalid.",28,1573419310);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2221 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(578,F164_2221_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_unrecognized_switch_error */
static EIF_REFERENCE F164_2222_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(579)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("e_unrecognized_switch_error", 163, Current, 0, 0, 2423);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Unrecognized switch \'{1}\'.",26,1405505070);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2222 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(579,F164_2222_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_require_switch_value */
static EIF_REFERENCE F164_2224_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(587)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("e_require_switch_value", 163, Current, 0, 0, 2425);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Switch \'{1}\' requires a paired value \'{2}\'.",43,736796462);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2224 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(587,F164_2224_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_multiple_switch_error */
static EIF_REFERENCE F164_2225_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(585)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("e_multiple_switch_error", 163, Current, 0, 0, 2426);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Switch \'{1}\' can only be used once.",35,2066790446);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2225 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(585,F164_2225_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_non_value_switch */
static EIF_REFERENCE F164_2226_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(586)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("e_non_value_switch", 163, Current, 0, 0, 2427);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Switch \'{1}\' should not have any value paired with it.",54,510438446);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2226 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(586,F164_2226_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_missing_switch_error */
static EIF_REFERENCE F164_2227_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(584)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("e_missing_switch_error", 163, Current, 0, 0, 2428);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Switch \'{1}\' was not specified.",31,1763454766);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2227 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(584,F164_2227_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_non_switched_argument_specified_error */
static EIF_REFERENCE F164_2228_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(590)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("e_non_switched_argument_specified_error", 163, Current, 0, 0, 2429);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Arguments without a switch prefix are not valid arguments.",58,156258862);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2228 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(590,F164_2228_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_switch_group_unrecognized_error */
static EIF_REFERENCE F164_2230_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(582)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("e_switch_group_unrecognized_error", 163, Current, 0, 0, 2431);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("The specified switches are not in a valid configuration.",56,723639342);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2230 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(582,F164_2230_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_missing_switch_dependency_error */
static EIF_REFERENCE F164_2231_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(591)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("e_missing_switch_dependency_error", 163, Current, 0, 0, 2432);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Switch \'{1}\' require the switch \'{2}\' be specified also.",56,1344471598);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2231 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(591,F164_2231_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_invalid_switch_value_with_reason */
static EIF_REFERENCE F164_2232_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(588)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("e_invalid_switch_value_with_reason", 163, Current, 0, 0, 2433);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("\'{1}\' is an invalid option for switch \'{2}\'.\012{3}",48,341313917);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2232 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(588,F164_2232_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.e_invalid_non_switched_value_with_reason */
static EIF_REFERENCE F164_2233_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(589)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("e_invalid_non_switched_value_with_reason", 163, Current, 0, 0, 2434);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("\'{1}\' is an invalid option.\012{2}",31,1578061949);
	F1086_8514(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F164_2233 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(589,F164_2233_body,(Current));
}

/* {ARGUMENT_BASE_PARSER}.internal_option_of_name */
EIF_REFERENCE F164_2234 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("internal_option_of_name", 163, Current, 3, 1, 2435);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_5_);
	RTHOOK(2);
	tr1 = F164_2142(Current);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5345[Dtype(RTCW(tr1))-509])(tr1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5315[Dtype(loc3)-479])(loc3);
		if (tb1) break;
		RTHOOK(3);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5314[Dtype(loc3)-479])(loc3);
		RTHOOK(4);
		if (loc1) {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6947[Dtype(RTCW(arg1))-1081])(arg1, tr1);
		} else {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb3 = F1078_8207(RTCW(arg1), tr1);
			tb2 = tb3;
		}
		if (tb2) {
			RTHOOK(7);
			Result = (EIF_REFERENCE) loc2;
		}
		RTHOOK(8);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5316[Dtype(loc3)-479])(loc3);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENT_BASE_PARSER}.fake inline-agent#13397#523#35# of command_option_configurations */
EIF_BOOLEAN F164_13397 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	
	
	RTEAA("fake inline-agent#13397#523#35# of command_option_configurations", 163, Current, 0, 1, 2355);
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
	RTEE;
	return (EIF_BOOLEAN) tb1;
}

void EIF_Minit140 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
