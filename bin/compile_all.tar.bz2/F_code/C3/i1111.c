/*
 * Code for class I18N_NUMERIC_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1111.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_NUMERIC_INFO}.make */
void F135_1844 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 134, Current, 0, 0, 2069);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(637,F135_1852, (Current));
	F135_1859(Current, tr1);
	RTHOOK(2);
	F135_1860(Current, ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	tr1 = RTOUCR(638,F135_1854, (Current));
	F135_1861(Current, tr1);
	RTHOOK(4);
	tr1 = RTOUCR(639,F135_1855, (Current));
	F135_1862(Current, tr1);
	RTHOOK(5);
	tr1 = RTOUCR(640,F135_1858, (Current));
	F135_1865(Current, tr1);
	RTHOOK(6);
	tr1 = RTOUCR(641,F135_1856, (Current));
	F135_1863(Current, tr1);
	RTHOOK(7);
	tr1 = RTOUCR(642,F135_1857, (Current));
	F135_1864(Current, tr1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.default_value_decimal_separator */
static EIF_REFERENCE F135_1852_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(637)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_value_decimal_separator", 134, Current, 0, 0, 2077);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H(".\000\000\000",1,46);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F135_1852 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(637,F135_1852_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_group_separator */
static EIF_REFERENCE F135_1854_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(638)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_value_group_separator", 134, Current, 0, 0, 2079);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H(",\000\000\000",1,44);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F135_1854 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(638,F135_1854_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_number_list_separator */
static EIF_REFERENCE F135_1855_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(639)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_value_number_list_separator", 134, Current, 0, 0, 2080);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H(";\000\000\000",1,59);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F135_1855 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(639,F135_1855_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_positive_sign */
static EIF_REFERENCE F135_1856_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(641)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_positive_sign", 134, Current, 0, 0, 2081);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H("",0,0);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F135_1856 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(641,F135_1856_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_negative_sign */
static EIF_REFERENCE F135_1857_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(642)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_negative_sign", 134, Current, 0, 0, 2082);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H("-\000\000\000",1,45);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F135_1857 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(642,F135_1857_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_grouping */
static EIF_REFERENCE F135_1858_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(640)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("default_value_grouping", 134, Current, 0, 0, 2083);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1142,1219,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 3L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 3L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1143_9214)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F135_1858 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(640,F135_1858_body,(Current));
}

/* {I18N_NUMERIC_INFO}.set_value_decimal_separator */
void F135_1859 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_decimal_separator", 134, Current, 0, 1, 2084);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8224(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_numbers_after_decimal_separator */
void F135_1860 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_value_numbers_after_decimal_separator", 134, Current, 0, 1, 2063);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_35_0_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_group_separator */
void F135_1861 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_group_separator", 134, Current, 0, 1, 2064);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8224(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_number_list_separator */
void F135_1862 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_number_list_separator", 134, Current, 0, 1, 2065);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8224(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_positive_sign */
void F135_1863 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_positive_sign", 134, Current, 0, 1, 2066);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8224(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_negative_sign */
void F135_1864 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_value_negative_sign", 134, Current, 0, 1, 2067);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8224(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_NUMERIC_INFO}.set_value_grouping */
void F135_1865 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_value_grouping", 134, Current, 0, 1, 2068);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit111 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
