
#ifndef _C3_i1113_
#define _C3_i1113_

#ifdef __cplusplus
extern "C" {
#endif

extern void F137_1914(EIF_REFERENCE);
extern void F137_1916(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit113(void);
extern void F135_1844(EIF_REFERENCE);
extern void F1255_10596(EIF_REFERENCE, EIF_REFERENCE);
extern void F134_1804(EIF_REFERENCE);
extern void F136_1866(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
