/*
 * Code for class INI_DOCUMENT_BUILDER_NODE_VISITOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in147.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INI_DOCUMENT_BUILDER_NODE_VISITOR}.make */
void F171_2317 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 170, Current, 0, 0, 2514);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(263, 1).id);
	F264_3280(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {INI_DOCUMENT_BUILDER_NODE_VISITOR}.process_document */
void F171_2319 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("process_document", 170, Current, 0, 1, 2516);
	RTGC;
	RTHOOK(1);
	tr1 = F239_2980(RTCW(arg1));
	F170_2316(Current, tr1);
	RTHOOK(2);
	tr1 = F239_2981(RTCW(arg1));
	F170_2316(Current, tr1);
	RTHOOK(3);
	tr1 = F153_2045(RTCW(arg1));
	F170_2316(Current, tr1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {INI_DOCUMENT_BUILDER_NODE_VISITOR}.process_section */
void F171_2320 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("process_section", 170, Current, 2, 1, 2517);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	loc1 = RTLNS(eif_new_type(1102, 0x01).id, 1102, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	tr1 = F300_3661(RTCW(tr1));
	F1103_9164(RTCW(loc1), tr1, loc2);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_2_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, loc1);
	RTHOOK(4);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	RTHOOK(5);
	tr1 = F239_2980(RTCW(arg1));
	F170_2316(Current, tr1);
	RTHOOK(6);
	tr1 = F239_2981(RTCW(arg1));
	F170_2316(Current, tr1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {INI_DOCUMENT_BUILDER_NODE_VISITOR}.process_property */
void F171_2321 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,arg1);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc1);
	RTLR(7,tr1);
	RTLIU(8);
	
	RTEAA("process_property", 170, Current, 5, 1, 2518);
	RTGC;
	RTHOOK(1);
	loc5 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1));
	RTHOOK(3);
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		RTHOOK(5);
		loc4 = RTLNS(eif_new_type(1082, 0x01).id, 1082, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1078_8165(RTCW(loc4));
	} else {
		RTHOOK(6);
		loc4 = F300_3661(RTCW(loc3));
	}
	RTHOOK(7);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		RTHOOK(8);
		loc1 = RTLNS(eif_new_type(1256, 0x01).id, 1256, _OBJSIZ_3_0_0_0_0_0_0_0_);
		F1257_10618(RTCW(loc1), loc4, loc5);
	} else {
		RTHOOK(9);
		loc1 = RTLNS(eif_new_type(1256, 0x01).id, 1256, _OBJSIZ_3_0_0_0_0_0_0_0_);
		tr1 = F300_3661(RTCW(loc2));
		F1257_10617(RTCW(loc1), tr1, loc4, loc5);
	}
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, loc1);
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {INI_DOCUMENT_BUILDER_NODE_VISITOR}.process_literal */
void F171_2322 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTEAA("process_literal", 170, Current, 1, 1, 2519);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
	tr2 = RTLNS(eif_new_type(1264, 0x01).id, 1264, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr3 = F300_3661(RTCW(arg1));
	F1265_10768(RTCW(tr2), tr3, loc1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(tr1))-759])(tr1, tr2);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {INI_DOCUMENT_BUILDER_NODE_VISITOR}.process_id */
void F171_2323 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("process_id", 170, Current, 0, 1, 2520);
	RTGC;
	
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {INI_DOCUMENT_BUILDER_NODE_VISITOR}.process_symbol */
void F171_2324 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("process_symbol", 170, Current, 0, 1, 2521);
	RTGC;
	
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {INI_DOCUMENT_BUILDER_NODE_VISITOR}.process_value */
void F171_2325 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("process_value", 170, Current, 0, 1, 2511);
	RTGC;
	
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit147 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
