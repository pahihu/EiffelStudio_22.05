/*
 * Code for class KMP_WILD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "km124.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KMP_WILD}.make_empty */
void F148_1988 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_empty", 147, Current, 0, 0, 2202);
	RTGC;
	RTHOOK(1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_0_) = (EIF_CHARACTER_32) tw1;
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '*';
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_) = (EIF_CHARACTER_32) tw1;
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,943,0xFF01,1086,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F944_7001(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	F147_1976(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {KMP_WILD}.found_pattern_length */
EIF_INTEGER_32 F148_1989 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_4_);
}


/* {KMP_WILD}.set_pattern */
void F148_1991 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_pattern", 147, Current, 0, 1, 2205);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8224(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {KMP_WILD}.found_at */
EIF_INTEGER_32 F148_1994 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_3_);
}


/* {KMP_WILD}.pattern_matches */
EIF_BOOLEAN F148_1998 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc6 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc5);
	RTLR(3,loc4);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTEAA("pattern_matches", 147, Current, 6, 0, 2212);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F148_1999(Current)) {
		tb2 = '\01';
		if (!(EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_3_) == ((EIF_INTEGER_32) 1L))) {
			tr1 = *(EIF_REFERENCE *)(Current);
			tw1 = F1087_8543(RTCW(tr1), ((EIF_INTEGER_32) 1L));
			tb2 = (EIF_BOOLEAN)(tw1 == *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_));
		}
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		loc5 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTHOOK(3);
		loc4 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		RTHOOK(4);
		F944_7021(RTCW(loc4));
		RTHOOK(5);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
		RTHOOK(6);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		for (;;) {
			RTHOOK(7);
			tb1 = '\01';
			tb2 = '\01';
			tb3 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_2_1_);
			if (!tb3) {
				tb2 = loc2;
			}
			if (!tb2) {
				tb1 = (EIF_BOOLEAN) !Result;
			}
			if (tb1) break;
			RTHOOK(8);
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5498[Dtype(RTCW(loc4))-759])(loc4);
			
			RTHOOK(10);
			loc6 = F1087_8543(RTCW(loc1), ((EIF_INTEGER_32) 1L));
			RTHOOK(11);
			if ((EIF_BOOLEAN)(loc6 == *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_))) {
				RTHOOK(12);
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				RTHOOK(13);
				if ((EIF_BOOLEAN)(loc6 == *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_0_))) {
					RTHOOK(14);
					loc3--;
				} else {
					RTHOOK(15);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					Result = F148_2004(Current, loc5, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - ti4_1) + ((EIF_INTEGER_32) 1L)), loc3, loc1);
					RTHOOK(16);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					loc3 -= ti4_1;
				}
			}
			RTHOOK(17);
			F944_7023(RTCW(loc4));
		}
		RTHOOK(18);
		if ((EIF_BOOLEAN) !loc2) {
			RTHOOK(19);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_4_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
		}
	}
	RTHOOK(20);
	RTLE;
	RTEE;
	return Result;
}

/* {KMP_WILD}.search_for_pattern */
EIF_BOOLEAN F148_1999 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(10);
	RTLR(0,loc15);
	RTLR(1,Current);
	RTLR(2,loc14);
	RTLR(3,tr1);
	RTLR(4,loc9);
	RTLR(5,loc10);
	RTLR(6,loc11);
	RTLR(7,loc12);
	RTLR(8,loc1);
	RTLR(9,loc2);
	RTLIU(10);
	
	RTEAA("search_for_pattern", 147, Current, 15, 0, 2213);
	RTGC;
	RTHOOK(1);
	loc15 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	loc14 = *(EIF_REFERENCE *)(Current);
	RTHOOK(3);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F1087_8611(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F1087_8611(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(6);
	F148_2002(Current);
	RTHOOK(7);
	loc9 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1085_8461(RTCW(loc9), ((EIF_INTEGER_32) 1L));
	RTHOOK(8);
	F1087_8590(RTCW(loc9), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_));
	RTHOOK(9);
	loc10 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1085_8461(RTCW(loc10), ((EIF_INTEGER_32) 1L));
	RTHOOK(10);
	F1087_8590(RTCW(loc10), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_0_));
	RTHOOK(11);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	RTHOOK(12);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	RTHOOK(13);
	loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - loc6);
	RTHOOK(14);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) -1L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tw1 = F1087_8543(RTCW(tr1), loc6);
		tb1 = (EIF_BOOLEAN)(tw1 == *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_));
	}
	if (tb1) {
		RTHOOK(15);
		Result = F148_2004(Current, *(EIF_REFERENCE *)(Current), ((EIF_INTEGER_32) 1L), loc5, *(EIF_REFERENCE *)(Current + _REFACS_1_));
		RTHOOK(16);
		if (Result) {
			RTHOOK(17);
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	}
	RTHOOK(18);
	loc11 = RTLNS(eif_new_type(146, 0x01).id, 146, _OBJSIZ_4_2_0_1_0_0_0_0_);
	F146_1965(RTCW(loc11), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTHOOK(19);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc12 = F1_14(tr1);
	RTHOOK(20);
	F1087_8602(RTCW(loc12), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_));
	RTHOOK(21);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_1_0_2_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 > ti4_2)) {
		RTHOOK(22);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(23);
		loc8 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_2_);
		loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			RTHOOK(24);
			if ((EIF_BOOLEAN) (Result || (EIF_BOOLEAN) (loc8 >= loc5))) break;
			RTHOOK(25);
			loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
			RTHOOK(26);
			loc8 = (EIF_INTEGER_32) loc4;
			RTHOOK(27);
			loc1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			RTHOOK(28);
			F944_7020(RTCW(loc1));
			RTHOOK(29);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(30);
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			for (;;) {
				RTHOOK(31);
				tb1 = '\01';
				if (!(EIF_BOOLEAN) !Result) {
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_2_2_);
					tb1 = tb2;
				}
				if (tb1) break;
				RTHOOK(32);
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5498[Dtype(RTCW(loc1))-759])(loc1);
				RTHOOK(33);
				tb2 = F1085_8485(RTCW(loc2), loc9);
				if (tb2) {
					RTHOOK(34);
					F944_7022(RTCW(loc1));
					RTHOOK(35);
					loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(36);
					tb2 = F1085_8485(RTCW(loc2), loc10);
					if (tb2) {
						RTHOOK(37);
						if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
							RTHOOK(38);
							loc3 = (EIF_INTEGER_32) loc4;
						}
						RTHOOK(39);
						loc4++;
						RTHOOK(40);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_2_) = (EIF_INTEGER_32) loc4;
						RTHOOK(41);
						F944_7022(RTCW(loc1));
					} else {
						RTHOOK(42);
						if ((EIF_BOOLEAN) (loc4 > loc5)) {
							RTHOOK(43);
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						} else {
							RTHOOK(44);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1939[Dtype(RTCW(loc11))-146])(loc11, loc2);
							RTHOOK(45);
							F146_1967(RTCW(loc11), loc4);
							RTHOOK(46);
							Result = '\0';
							tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1945[Dtype(RTCW(loc11))-146])(loc11);
							if (tb2) {
								tb2 = '\01';
								if ((EIF_BOOLEAN) !loc13) {
									ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1942[Dtype(RTCW(loc11))-146])(loc11);
									tb2 = (EIF_BOOLEAN)(ti4_1 == loc4);
								}
								Result = tb2;
							}
							RTHOOK(47);
							if (Result) {
								RTHOOK(48);
								loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1942[Dtype(RTCW(loc11))-146])(loc11);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
								loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ti4_1);
								RTHOOK(49);
								if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
									RTHOOK(50);
									loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1942[Dtype(RTCW(loc11))-146])(loc11);
								}
							}
						}
						RTHOOK(51);
						loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						RTHOOK(52);
						F944_7022(RTCW(loc1));
					}
				}
				RTHOOK(53);
				tb2 = '\0';
				if (Result) {
					tb3 = '\01';
					if (!(EIF_BOOLEAN) (loc4 <= (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L)))) {
						tb4 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_2_2_);
						tb3 = tb4;
					}
					tb2 = tb3;
				}
				Result = (EIF_BOOLEAN) tb2;
			}
		}
	}
	RTHOOK(54);
	if (Result) {
		RTHOOK(55);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_4_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - loc3);
		RTHOOK(56);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_3_) = (EIF_INTEGER_32) loc3;
		RTHOOK(57);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_2_) = (EIF_INTEGER_32) loc4;
	}
	RTHOOK(58);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) Result;
	RTHOOK(59);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
		RTHOOK(60);
		RTAR(Current, loc15);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc15;
		RTHOOK(61);
		RTAR(Current, loc14);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc14;
	}
	RTHOOK(62);
	RTLE;
	RTEE;
	return Result;
}

/* {KMP_WILD}.init_list */
void F148_2002 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc8 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc6);
	RTLR(4,loc7);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLIU(7);
	
	RTEAA("init_list", 147, Current, 8, 0, 2216);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,943,0xFF01,1086,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNSMART(typres0.id);
	}
	F944_7001(RTCW(loc1));
	RTHOOK(2);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) loc1;
	RTHOOK(3);
	loc2 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1085_8461(RTCW(loc2), ((EIF_INTEGER_32) 0L));
	RTHOOK(4);
	loc6 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1085_8461(RTCW(loc6), ((EIF_INTEGER_32) 1L));
	RTHOOK(5);
	F1087_8590(RTCW(loc6), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_));
	RTHOOK(6);
	loc7 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1085_8461(RTCW(loc7), ((EIF_INTEGER_32) 1L));
	RTHOOK(7);
	F1087_8590(RTCW(loc7), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_0_));
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc5 = *(EIF_REFERENCE *)(RTCW(tr1));
	RTHOOK(9);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	RTHOOK(10);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		RTHOOK(11);
		if ((EIF_BOOLEAN)(loc3 == loc4)) break;
		RTHOOK(12);
		/* INLINED CODE (SPECIAL.item) */
		tw2 = *((EIF_CHARACTER_32 *)RTCW(loc5) + (loc3));
		/* END INLINED CODE */
		loc8 = tw2;
		RTHOOK(13);
		if ((EIF_BOOLEAN)(loc8 == *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_))) {
			RTHOOK(14);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
				RTHOOK(15);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(loc1))-759])(loc1, loc2);
			}
			RTHOOK(16);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(loc1))-759])(loc1, loc6);
			RTHOOK(17);
			loc2 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1085_8461(RTCW(loc2), ((EIF_INTEGER_32) 0L));
		} else {
			RTHOOK(18);
			if ((EIF_BOOLEAN)(loc8 == *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_0_))) {
				RTHOOK(19);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
					RTHOOK(20);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(loc1))-759])(loc1, loc2);
				}
				RTHOOK(21);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(loc1))-759])(loc1, loc7);
				RTHOOK(22);
				loc2 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1085_8461(RTCW(loc2), ((EIF_INTEGER_32) 0L));
			} else {
				RTHOOK(23);
				/* INLINED CODE (SPECIAL.item) */
				tw2 = *((EIF_CHARACTER_32 *)RTCW(loc5) + (loc3));
				/* END INLINED CODE */
				tw1 = tw2;
				F1087_8590(RTCW(loc2), tw1);
			}
		}
		RTHOOK(24);
		loc3++;
	}
	RTHOOK(25);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(26);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5485[Dtype(RTCW(loc1))-759])(loc1, loc2);
	}
	RTHOOK(27);
	RTLE;
	RTEE;
}

/* {KMP_WILD}.imp_same_substring */
EIF_BOOLEAN F148_2004 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg4);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("imp_same_substring", 147, Current, 4, 4, 2218);
	RTGC;
	RTHOOK(1);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg4)+ _LNGOFF_1_1_0_2_);
	RTHOOK(3);
	if ((EIF_BOOLEAN) (loc3 >= loc4)) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) <= arg2) && (EIF_BOOLEAN) (arg2 <= arg3)) && (EIF_BOOLEAN) (arg3 <= loc3))) {
			RTHOOK(5);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			RTHOOK(6);
			loc2 = (EIF_INTEGER_32) arg2;
			RTHOOK(7);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)) == loc4);
			for (;;) {
				RTHOOK(8);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc4)) || (EIF_BOOLEAN) (loc2 > arg3))) break;
				RTHOOK(9);
				tw1 = F1087_8543(RTCW(arg1), loc2);
				tw2 = F1087_8543(RTCW(arg4), loc1);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tw1 == tw2);
				RTHOOK(10);
				loc1++;
				RTHOOK(11);
				loc2++;
			}
		} else {
			RTHOOK(12);
			Result = F768_6292(RTCW(arg4));
			RTHOOK(13);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) Result;
		}
	}
	RTHOOK(15);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit124 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
