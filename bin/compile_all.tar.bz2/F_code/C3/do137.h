
#ifndef _C3_do137_
#define _C3_do137_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F161_2089(EIF_REFERENCE, EIF_REAL_64);
extern EIF_REAL_64 F161_2091(EIF_REFERENCE, EIF_REAL_64);
extern void EIF_Minit137(void);

#ifdef __cplusplus
}
#endif

#endif
