/*
 * Code for class INI_NODE_VISITOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in146.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INI_NODE_VISITOR}.process_list */
void F170_2316 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("process_list", 169, Current, 1, 1, 2510);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5504[Dtype(RTCW(arg1))-943])(arg1);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5465[Dtype(RTCW(arg1))-759])(arg1);
	for (;;) {
		RTHOOK(3);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5476[Dtype(RTCW(arg1))-759])(arg1);
		if (tb1) break;
		RTHOOK(4);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5498[Dtype(RTCW(arg1))-759])(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3421[Dtype(RTCW(tr1))-297])(tr1, Current);
		RTHOOK(5);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5478[Dtype(RTCW(arg1))-759])(arg1);
	}
	RTHOOK(6);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5506[Dtype(RTCW(arg1))-943])(arg1, loc1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

void EIF_Minit146 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
