/*
 * Code for class I18N_LOCALE_CONV
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1106.h"
#include <locale.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_LOCALE_CONV}.localeconv */
EIF_POINTER F130_1722 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("localeconv", 129, Current, 0, 0, 1947);Result = (EIF_POINTER) localeconv();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.decimal_point */
EIF_POINTER F130_1724 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("decimal_point", 129, Current, 0, 1, 1949);Result = (EIF_POINTER) (((struct lconv *)arg1)->decimal_point);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.thousands_sep */
EIF_POINTER F130_1725 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("thousands_sep", 129, Current, 0, 1, 1950);Result = (EIF_POINTER) (((struct lconv *)arg1)->thousands_sep);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.grouping */
EIF_POINTER F130_1726 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("grouping", 129, Current, 0, 1, 1951);Result = (EIF_POINTER) (((struct lconv *)arg1)->grouping);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.int_curr_symbol */
EIF_POINTER F130_1727 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("int_curr_symbol", 129, Current, 0, 1, 1952);Result = (EIF_POINTER) (((struct lconv *)arg1)->int_curr_symbol);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.mon_decimal_point */
EIF_POINTER F130_1729 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("mon_decimal_point", 129, Current, 0, 1, 1954);Result = (EIF_POINTER) (((struct lconv *)arg1)->mon_decimal_point);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.mon_thousands_sep */
EIF_POINTER F130_1730 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("mon_thousands_sep", 129, Current, 0, 1, 1955);Result = (EIF_POINTER) (((struct lconv *)arg1)->mon_thousands_sep);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.mon_grouping */
EIF_POINTER F130_1731 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("mon_grouping", 129, Current, 0, 1, 1956);Result = (EIF_POINTER) (((struct lconv *)arg1)->mon_grouping);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.positive_sign */
EIF_POINTER F130_1732 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("positive_sign", 129, Current, 0, 1, 1957);Result = (EIF_POINTER) (((struct lconv *)arg1)->positive_sign);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.negative_sign */
EIF_POINTER F130_1733 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("negative_sign", 129, Current, 0, 1, 1958);Result = (EIF_POINTER) (((struct lconv *)arg1)->negative_sign);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.int_frac_digits */
EIF_CHARACTER_8 F130_1734 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("int_frac_digits", 129, Current, 0, 1, 1959);Result = (EIF_CHARACTER_8) (((struct lconv *)arg1)->int_frac_digits);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_LOCALE_CONV}.frac_digits */
EIF_CHARACTER_8 F130_1735 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("frac_digits", 129, Current, 0, 1, 1960);Result = (EIF_CHARACTER_8) (((struct lconv *)arg1)->frac_digits);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit106 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
