
#ifndef _C3_i1116_
#define _C3_i1116_

#ifdef __cplusplus
extern "C" {
#endif

extern void F140_1937(EIF_REFERENCE, EIF_REFERENCE);
extern void F140_1938(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit116(void);
extern long O1848[];
extern long O1849[];
extern long O1850[];
extern long O1852[];
extern long O1853[];
extern long O1854[];

#ifdef __cplusplus
}
#endif

#endif
