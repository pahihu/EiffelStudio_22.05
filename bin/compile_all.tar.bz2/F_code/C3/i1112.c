/*
 * Code for class I18N_CURRENCY_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1112.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_CURRENCY_INFO}.make */
void F136_1866 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 135, Current, 0, 0, 2085);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(630,F136_1889, (Current));
	F136_1898(Current, tr1);
	RTHOOK(2);
	F136_1899(Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(3);
	tr1 = RTOUCR(631,F136_1890, (Current));
	F136_1900(Current, tr1);
	RTHOOK(4);
	F136_1901(Current, ((EIF_INTEGER_32) 2L));
	RTHOOK(5);
	tr1 = RTOUCR(632,F136_1893, (Current));
	F136_1902(Current, tr1);
	RTHOOK(6);
	tr1 = RTOUCR(633,F136_1894, (Current));
	F136_1903(Current, tr1);
	RTHOOK(7);
	tr1 = RTOUCR(634,F136_1895, (Current));
	F136_1904(Current, tr1);
	RTHOOK(8);
	tr1 = RTOUCR(635,F136_1896, (Current));
	F136_1905(Current, tr1);
	RTHOOK(9);
	tr1 = RTOUCR(636,F136_1897, (Current));
	F136_1906(Current, tr1);
	RTHOOK(10);
	tr1 = RTOUCR(630,F136_1889, (Current));
	F136_1907(Current, tr1);
	RTHOOK(11);
	F136_1908(Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(12);
	tr1 = RTOUCR(631,F136_1890, (Current));
	F136_1909(Current, tr1);
	RTHOOK(13);
	F136_1910(Current, ((EIF_INTEGER_32) 2L));
	RTHOOK(14);
	tr1 = RTOUCR(632,F136_1893, (Current));
	F136_1911(Current, tr1);
	RTHOOK(15);
	tr1 = RTOUCR(633,F136_1894, (Current));
	F136_1912(Current, tr1);
	RTHOOK(16);
	tr1 = RTOUCR(636,F136_1897, (Current));
	F136_1913(Current, tr1);
	RTHOOK(17);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.default_currency_symbol */
static EIF_REFERENCE F136_1889_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(630)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_symbol", 135, Current, 0, 0, 2108);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H("",0,0);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_1889 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(630,F136_1889_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_decimal_separator */
static EIF_REFERENCE F136_1890_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(631)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_decimal_separator", 135, Current, 0, 0, 2109);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H(".\000\000\000",1,46);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_1890 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(631,F136_1890_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_group_separator */
static EIF_REFERENCE F136_1893_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(632)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_group_separator", 135, Current, 0, 0, 2112);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H(",\000\000\000",1,44);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_1893 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(632,F136_1893_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_number_list_separator */
static EIF_REFERENCE F136_1894_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(633)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_number_list_separator", 135, Current, 0, 0, 2113);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H(";\000\000\000",1,59);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_1894 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(633,F136_1894_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_positive_sign */
static EIF_REFERENCE F136_1895_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(634)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_positive_sign", 135, Current, 0, 0, 2114);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H("",0,0);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_1895 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(634,F136_1895_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_negative_sign */
static EIF_REFERENCE F136_1896_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(635)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_currency_negative_sign", 135, Current, 0, 0, 2115);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H("-\000\000\000",1,45);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_1896 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(635,F136_1896_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_grouping */
static EIF_REFERENCE F136_1897_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(636)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("default_currency_grouping", 135, Current, 0, 0, 2116);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1142,1219,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 3L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 3L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1143_9214)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F136_1897 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(636,F136_1897_body,(Current));
}

/* {I18N_CURRENCY_INFO}.set_currency_symbol */
void F136_1898 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_symbol", 135, Current, 0, 1, 2117);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8224(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1843[Dtype(Current)-135]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_symbol_location */
void F136_1899 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_currency_symbol_location", 135, Current, 0, 1, 2118);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O1844[Dtype(Current)-135]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_decimal_separator */
void F136_1900 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_decimal_separator", 135, Current, 0, 1, 2119);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1848[Dtype(Current)-135]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_numbers_after_decimal_separator */
void F136_1901 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_currency_numbers_after_decimal_separator", 135, Current, 0, 1, 2120);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O1849[Dtype(Current)-135]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_group_separator */
void F136_1902 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_group_separator", 135, Current, 0, 1, 2121);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1850[Dtype(Current)-135]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_number_list_separator */
void F136_1903 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_number_list_separator", 135, Current, 0, 1, 2122);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1851[Dtype(Current)-135]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_positive_sign */
void F136_1904 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_positive_sign", 135, Current, 0, 1, 2123);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1852[Dtype(Current)-135]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_negative_sign */
void F136_1905 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_currency_negative_sign", 135, Current, 0, 1, 2124);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1853[Dtype(Current)-135]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_currency_grouping */
void F136_1906 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_currency_grouping", 135, Current, 0, 1, 2125);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O1854[Dtype(Current)-135]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_symbol */
void F136_1907 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_international_currency_symbol", 135, Current, 0, 1, 2126);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8224(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1855[Dtype(Current)-135]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_symbol_location */
void F136_1908 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_international_currency_symbol_location", 135, Current, 0, 1, 2127);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O1856[Dtype(Current)-135]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_decimal_separator */
void F136_1909 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_international_currency_decimal_separator", 135, Current, 0, 1, 2128);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1860[Dtype(Current)-135]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_numbers_after_decimal_separator */
void F136_1910 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_international_currency_numbers_after_decimal_separator", 135, Current, 0, 1, 2129);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O1861[Dtype(Current)-135]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_group_separator */
void F136_1911 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_international_currency_group_separator", 135, Current, 0, 1, 2130);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1862[Dtype(Current)-135]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_number_list_separator */
void F136_1912 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_international_currency_number_list_separator", 135, Current, 0, 1, 2131);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1863[Dtype(Current)-135]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_grouping */
void F136_1913 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_international_currency_grouping", 135, Current, 0, 1, 2132);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O1864[Dtype(Current)-135]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit112 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
