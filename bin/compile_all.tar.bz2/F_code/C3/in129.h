
#ifndef _C3_in129_
#define _C3_in129_

#ifdef __cplusplus
extern "C" {
#endif

extern void F153_2044(EIF_REFERENCE);
extern EIF_REFERENCE F153_2045(EIF_REFERENCE);
extern void F153_2046(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit129(void);
extern void F949_7071(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R5485[])();

#ifdef __cplusplus
}
#endif

#endif
