/*
 * Code for class I18N_LOCALE_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1113.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_LOCALE_INFO}.make */
void F137_1914 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("make", 136, Current, 0, 0, 2133);
	RTGC;
	RTHOOK(1);
	F134_1804(Current);
	RTHOOK(2);
	F135_1844(Current);
	RTHOOK(3);
	F136_1866(Current);
	RTHOOK(4);
	{
		/* INLINED CODE (I18N_CODE_PAGE_INFO.initialize_code_page_info) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(5);
	tr1 = RTLNSMART(eif_new_type(1254, 1).id);
	tr2 = RTMS32_EX_H("",0,0);
	F1255_10596(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_34_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {I18N_LOCALE_INFO}.set_id */
void F137_1916 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_id", 136, Current, 0, 1, 2135);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_34_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit113 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
