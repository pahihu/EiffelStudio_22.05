
#ifndef _C3_km123_
#define _C3_km123_

#ifdef __cplusplus
extern "C" {
#endif

extern void F147_1976(EIF_REFERENCE);
extern void F147_1981(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F147_1984(EIF_REFERENCE);
extern void F147_1986(EIF_REFERENCE);
extern void EIF_Minit123(void);
extern EIF_REFERENCE F1078_8224(EIF_REFERENCE);
extern void F146_1966(EIF_REFERENCE);
extern void F1143_9206(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F1087_8611(EIF_REFERENCE);
extern EIF_REFERENCE F1143_9241(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern long O1950[];
extern long O1941[];
extern long O1946[];

#ifdef __cplusplus
}
#endif

#endif
