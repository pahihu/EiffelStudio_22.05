
#ifndef _C3_ar141_
#define _C3_ar141_

#ifdef __cplusplus
extern "C" {
#endif

extern void F165_2238(EIF_REFERENCE, EIF_BOOLEAN);
extern void F165_2239(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit141(void);
extern void F164_2138(EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN, EIF_BOOLEAN);

#ifdef __cplusplus
}
#endif

#endif
