
#ifndef _C3_co130_
#define _C3_co130_

#ifdef __cplusplus
extern "C" {
#endif

extern void F154_2050(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit130(void);

#ifdef __cplusplus
}
#endif

#endif
