
#ifndef _C3_rt114_
#define _C3_rt114_

#ifdef __cplusplus
extern "C" {
#endif

extern void F138_1918(EIF_REFERENCE);
extern void F138_1919(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F138_1920(EIF_REFERENCE);
extern void EIF_Minit114(void);

#ifdef __cplusplus
}
#endif

#endif
