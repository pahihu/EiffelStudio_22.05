/*
 * Code for class I18N_DATE_TIME_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1110.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_DATE_TIME_INFO}.make */
void F134_1804 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 133, Current, 0, 0, 2023);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(643,F134_1831, (Current));
	F134_1822(Current, tr1);
	RTHOOK(2);
	tr1 = RTOUCR(644,F134_1834, (Current));
	F134_1823(Current, tr1);
	RTHOOK(3);
	tr1 = RTOUCR(645,F134_1833, (Current));
	F134_1824(Current, tr1);
	RTHOOK(4);
	tr1 = RTOUCR(644,F134_1834, (Current));
	F134_1825(Current, tr1);
	RTHOOK(5);
	tr1 = RTOUCR(646,F134_1835, (Current));
	F134_1826(Current, tr1);
	RTHOOK(6);
	tr1 = RTOUCR(647,F134_1836, (Current));
	F134_1827(Current, tr1);
	RTHOOK(7);
	tr1 = RTOUCR(648,F134_1837, (Current));
	F134_1828(Current, tr1);
	RTHOOK(8);
	tr1 = RTOUCR(649,F134_1843, (Current));
	F134_1829(Current, tr1);
	RTHOOK(9);
	tr1 = RTOUCR(650,F134_1842, (Current));
	F134_1830(Current, tr1);
	RTHOOK(10);
	tr1 = RTOUCR(651,F134_1838, (Current));
	F134_1818(Current, tr1);
	RTHOOK(11);
	tr1 = RTOUCR(652,F134_1839, (Current));
	F134_1820(Current, tr1);
	RTHOOK(12);
	tr1 = RTOUCR(653,F134_1840, (Current));
	F134_1819(Current, tr1);
	RTHOOK(13);
	tr1 = RTOUCR(654,F134_1841, (Current));
	F134_1821(Current, tr1);
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_day_names */
void F134_1818 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_day_names", 133, Current, 0, 1, 2037);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_abbreviated_day_names */
void F134_1819 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_abbreviated_day_names", 133, Current, 0, 1, 2038);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_month_names */
void F134_1820 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_month_names", 133, Current, 0, 1, 2039);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_abbreviated_month_names */
void F134_1821 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_abbreviated_month_names", 133, Current, 0, 1, 2040);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_date_time_format */
void F134_1822 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_date_time_format", 133, Current, 0, 1, 2041);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_long_date_format */
void F134_1823 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_long_date_format", 133, Current, 0, 1, 2042);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_short_date_format */
void F134_1824 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_short_date_format", 133, Current, 0, 1, 2043);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_long_time_format */
void F134_1825 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_long_time_format", 133, Current, 0, 1, 2044);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_short_time_format */
void F134_1826 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_short_time_format", 133, Current, 0, 1, 2045);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_am_suffix */
void F134_1827 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_am_suffix", 133, Current, 0, 1, 2046);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_pm_suffix */
void F134_1828 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_pm_suffix", 133, Current, 0, 1, 2047);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_time_separator */
void F134_1829 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_time_separator", 133, Current, 0, 1, 2048);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.set_date_separator */
void F134_1830 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_date_separator", 133, Current, 0, 1, 2049);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8225(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {I18N_DATE_TIME_INFO}.default_date_time_format */
static EIF_REFERENCE F134_1831_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(643)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_date_time_format", 133, Current, 0, 0, 2050);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1078_8165(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOUCR(655,F134_1832, (Current));
	F1087_8576(RTCW(Result), tr1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'T';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(4);
	tr1 = RTOUCR(644,F134_1834, (Current));
	F1087_8576(RTCW(Result), tr1);
	RTOTE;
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1831 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(643,F134_1831_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_long_date_format */
static EIF_REFERENCE F134_1832_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(655)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_long_date_format", 133, Current, 0, 0, 2051);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1078_8165(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Y';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(4);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(5);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(6);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'm';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(7);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(8);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(9);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'e';
	F1087_8590(RTCW(Result), tw1);
	RTOTE;
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1832 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(655,F134_1832_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_short_date_format */
static EIF_REFERENCE F134_1833_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(645)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_short_date_format", 133, Current, 0, 0, 2052);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1078_8165(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Y';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(4);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(5);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(6);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'm';
	F1087_8590(RTCW(Result), tw1);
	RTOTE;
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1833 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(645,F134_1833_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_long_time_format */
static EIF_REFERENCE F134_1834_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(644)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_long_time_format", 133, Current, 0, 0, 2053);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1078_8165(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOUCR(646,F134_1835, (Current));
	F1087_8576(RTCW(Result), tr1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(4);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(5);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '5';
	F1087_8590(RTCW(Result), tw1);
	RTOTE;
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1834 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(644,F134_1834_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_short_time_format */
static EIF_REFERENCE F134_1835_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(646)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_short_time_format", 133, Current, 0, 0, 2054);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1078_8165(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'k';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(4);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(5);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
	F1087_8590(RTCW(Result), tw1);
	RTHOOK(6);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'M';
	F1087_8590(RTCW(Result), tw1);
	RTOTE;
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1835 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(646,F134_1835_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_am_suffix */
static EIF_REFERENCE F134_1836_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(647)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_am_suffix", 133, Current, 0, 0, 2055);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H("a\000\000\000m\000\000\000",2,24941);
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1836 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(647,F134_1836_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_pm_suffix */
static EIF_REFERENCE F134_1837_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(648)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_pm_suffix", 133, Current, 0, 0, 2056);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H("p\000\000\000m\000\000\000",2,28781);
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1837 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(648,F134_1837_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_day_names */
static EIF_REFERENCE F134_1838_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(651)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("default_day_names", 133, Current, 0, 0, 2057);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1140,0xFF01,1086,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 7L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1078_8225(RTMS_EX_H("Monday",6,2004312953));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Tuesday",7,1495753593));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Wednesday",9,1804915065));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Thursday",8,844137593));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Friday",6,1906687353));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Saturday",8,1596931193));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Sunday",6,2016155513));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1141_9214)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1838 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(651,F134_1838_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_month_names */
static EIF_REFERENCE F134_1839_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(652)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("default_month_names", 133, Current, 0, 0, 2058);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1140,0xFF01,1086,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 12L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1078_8225(RTMS_EX_H("January",7,751658105));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("February",8,1474449017));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("March",5,1635477864));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("April",5,1887045484));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("May",3,5071225));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("June",4,1249209957));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("July",4,1249209465));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("August",6,1864444276));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("September",9,1077346930));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("October",7,1024137842));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("November",8,2119563634));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("December",8,1341698930));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1141_9214)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1839 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(652,F134_1839_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_abbreviated_day_names */
static EIF_REFERENCE F134_1840_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(653)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("default_abbreviated_day_names", 133, Current, 0, 0, 2059);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1140,0xFF01,1086,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 7L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1078_8225(RTMS_EX_H("Mon",3,5074798));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Tue",3,5535077));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Wed",3,5727588));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Thu",3,5531765));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Fri",3,4616809));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Sat",3,5464436));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Sun",3,5469550));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1141_9214)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1840 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(653,F134_1840_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_abbreviated_month_names */
static EIF_REFERENCE F134_1841_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(654)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("default_abbreviated_month_names", 133, Current, 0, 0, 2060);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1140,0xFF01,1086,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 12L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1078_8225(RTMS_EX_H("Jan",3,4874606));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Feb",3,4613474));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Mar",3,5071218));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Apr",3,4288626));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("May",3,5071225));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Jun",3,4879726));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Jul",3,4879724));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Aug",3,4289895));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Sep",3,5465456));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Oct",3,5202804));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Nov",3,5140342));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1078_8225(RTMS_EX_H("Dec",3,4482403));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1141_9214)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1841 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(654,F134_1841_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_date_separator */
static EIF_REFERENCE F134_1842_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(650)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_date_separator", 133, Current, 0, 0, 2061);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H("/\000\000\000",1,47);
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1842 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(650,F134_1842_body,(Current));
}

/* {I18N_DATE_TIME_INFO}.default_time_separator */
static EIF_REFERENCE F134_1843_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(649)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_time_separator", 133, Current, 0, 0, 2062);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = RTMS32_EX_H(":\000\000\000",1,58);
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1843 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(649,F134_1843_body,(Current));
}

void EIF_Minit110 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
