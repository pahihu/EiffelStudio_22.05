
#ifndef _C3_sh117_
#define _C3_sh117_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F141_1939_body(EIF_REFERENCE);
extern EIF_REFERENCE F141_1939(EIF_REFERENCE);
extern void EIF_Minit117(void);

#ifdef __cplusplus
}
#endif

#endif
