/*
 * Code for class CODE_SETS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co128.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_SETS}.two_byte_code_pages */
static EIF_REFERENCE F152_2040_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(559)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("two_byte_code_pages", 151, Current, 0, 0, 2249);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1080,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 860, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F861_6845(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTMS_EX_H("UCS-2",5,1130177330);
	tr2 = RTMS_EX_H("ucs-2",5,1669391154);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(3);
	tr1 = RTMS_EX_H("ISO-10646-UCS-2",15,137660722);
	tr2 = RTMS_EX_H("iso-10646-ucs-2",15,932466994);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	tr1 = RTMS_EX_H("csUnicode",9,1140938597);
	tr2 = RTMS_EX_H("csunicode",9,67227493);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(5);
	tr1 = RTMS_EX_H("UCS-2BE",7,722937925);
	tr2 = RTMS_EX_H("ucs-2be",7,1859875173);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(6);
	tr1 = RTMS_EX_H("UNICODEBIG",10,266927431);
	tr2 = RTMS_EX_H("unicodebig",10,1691026535);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(7);
	tr1 = RTMS_EX_H("UNICODE-1-1",11,1407647281);
	tr2 = RTMS_EX_H("unicode-1-1",11,366474289);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(8);
	tr1 = RTMS_EX_H("csUnicode11",11,1599950641);
	tr2 = RTMS_EX_H("csunicode11",11,1339907633);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(9);
	tr1 = RTMS_EX_H("UCS-2LE",7,722940485);
	tr2 = RTMS_EX_H("ucs-2le",7,1859877733);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(10);
	tr1 = RTMS_EX_H("UNICODELITTLE",13,852373061);
	tr2 = RTMS_EX_H("unicodelittle",13,1164725349);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(11);
	tr1 = RTOUCR(364,F64_953, (Current));
	tr2 = RTMS_EX_H("utf-16",6,1945159990);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(12);
	tr1 = RTOUCR(368,F64_957, (Current));
	tr2 = RTMS_EX_H("utf-16be",8,1456247141);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(13);
	tr1 = RTOUCR(366,F64_955, (Current));
	tr2 = RTMS_EX_H("utf-16le",8,1456249701);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(14);
	tr1 = RTMS_EX_H("UCS-2-INTERNAL",14,834453068);
	tr2 = RTMS_EX_H("ucs-2-internal",14,1377880940);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(15);
	tr1 = RTMS_EX_H("UCS-2-SWAPPED",13,297507908);
	tr2 = RTMS_EX_H("ucs-2-swapped",13,861666404);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(16);
	tr1 = RTMS_EX_H("JAVA",4,1245795905);
	tr2 = RTMS_EX_H("java",4,1784772193);
	F852_6767(RTCW(Result), tr1, tr2);
	RTOTE;
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2040 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(559,F152_2040_body,(Current));
}

/* {CODE_SETS}.four_byte_code_pages */
static EIF_REFERENCE F152_2041_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(560)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("four_byte_code_pages", 151, Current, 0, 0, 2250);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1080,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 860, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F861_6845(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTMS_EX_H("UCS-4",5,1130177332);
	tr2 = RTMS_EX_H("ucs-4",5,1669391156);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(3);
	tr1 = RTMS_EX_H("ISO-10646-UCS-4",15,137660724);
	tr2 = RTMS_EX_H("iso-10646-ucs-4",15,932466996);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	tr1 = RTMS_EX_H("csUCS4",6,1626000692);
	tr2 = RTMS_EX_H("csucs4",6,17497140);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(5);
	tr1 = RTMS_EX_H("UCS-4BE",7,723068997);
	tr2 = RTMS_EX_H("ucs-4be",7,1860006245);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(6);
	tr1 = RTMS_EX_H("UCS-4LE",7,723071557);
	tr2 = RTMS_EX_H("ucs-4le",7,1860008805);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(7);
	tr1 = RTOUCR(365,F64_954, (Current));
	tr2 = RTMS_EX_H("utf-32",6,1945160498);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(8);
	tr1 = RTOUCR(369,F64_958, (Current));
	tr2 = RTMS_EX_H("utf-32be",8,1489539429);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(9);
	tr1 = RTOUCR(367,F64_956, (Current));
	tr2 = RTMS_EX_H("utf-32le",8,1489541989);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(10);
	tr1 = RTMS_EX_H("UCS-4-INTERNAL",14,968724556);
	tr2 = RTMS_EX_H("ucs-4-internal",14,1512152428);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(11);
	tr1 = RTMS_EX_H("UCS-4-SWAPPED",13,415472708);
	tr2 = RTMS_EX_H("ucs-4-swapped",13,979631204);
	F852_6767(RTCW(Result), tr1, tr2);
	RTOTE;
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2041 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(560,F152_2041_body,(Current));
}

/* {CODE_SETS}.little_endian_code_pages */
static EIF_REFERENCE F152_2042_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(562)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("little_endian_code_pages", 151, Current, 0, 0, 2251);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1080,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 860, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F861_6845(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTMS_EX_H("UCS-2LE",7,722940485);
	tr2 = RTMS_EX_H("ucs-2le",7,1859877733);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(3);
	tr1 = RTMS_EX_H("UNICODELITTLE",13,852373061);
	tr2 = RTMS_EX_H("unicodelittle",13,1164725349);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	tr1 = RTOUCR(366,F64_955, (Current));
	tr2 = RTMS_EX_H("utf-16le",8,1456249701);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(5);
	tr1 = RTMS_EX_H("UCS-4LE",7,723071557);
	tr2 = RTMS_EX_H("ucs-4le",7,1860008805);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(6);
	tr1 = RTOUCR(367,F64_956, (Current));
	tr2 = RTMS_EX_H("utf-32le",8,1489541989);
	F852_6767(RTCW(Result), tr1, tr2);
	RTOTE;
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2042 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(562,F152_2042_body,(Current));
}

/* {CODE_SETS}.big_endian_code_pages */
static EIF_REFERENCE F152_2043_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(561)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("big_endian_code_pages", 151, Current, 0, 0, 2252);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,860,0xFF01,1080,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 860, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F861_6845(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTMS_EX_H("UCS-2BE",7,722937925);
	tr2 = RTMS_EX_H("ucs-2be",7,1859875173);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(3);
	tr1 = RTMS_EX_H("UNICODEBIG",10,266927431);
	tr2 = RTMS_EX_H("unicodebig",10,1691026535);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	tr1 = RTOUCR(368,F64_957, (Current));
	tr2 = RTMS_EX_H("utf-16be",8,1456247141);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(5);
	tr1 = RTMS_EX_H("UCS-4BE",7,723068997);
	tr2 = RTMS_EX_H("ucs-4be",7,1860006245);
	F852_6767(RTCW(Result), tr1, tr2);
	RTHOOK(6);
	tr1 = RTOUCR(369,F64_958, (Current));
	tr2 = RTMS_EX_H("utf-32be",8,1489539429);
	F852_6767(RTCW(Result), tr1, tr2);
	RTOTE;
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_2043 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(561,F152_2043_body,(Current));
}

void EIF_Minit128 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
