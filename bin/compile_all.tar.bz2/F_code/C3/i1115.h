
#ifndef _C3_i1115_
#define _C3_i1115_

#ifdef __cplusplus
extern "C" {
#endif

extern void F139_1922(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit115(void);

#ifdef __cplusplus
}
#endif

#endif
