
#ifndef _C3_i1119_
#define _C3_i1119_

#ifdef __cplusplus
extern "C" {
#endif

extern void F143_1946(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F143_1950(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F143_1951(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit119(void);
extern EIF_REFERENCE F144_1955(EIF_REFERENCE);
extern void F1087_8537(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F144_1956(EIF_REFERENCE);
extern char *(*R5454[])();

#ifdef __cplusplus
}
#endif

#endif
