#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* I18N_PLURAL_TOOLS reduce_one_plural_form */
EIF_INTEGER_32 _A11_50_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_one_plural_form */
EIF_INTEGER_32 __A11_50_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 _A11_51_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 __A11_51_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 _A11_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 __A11_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 _A11_53_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 __A11_53_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 _A11_54_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 __A11_54_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 _A11_55_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 __A11_55_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 _A11_56_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 __A11_56_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 _A11_57_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 __A11_57_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 _A11_58_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 __A11_58_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DESCRIPTOR_CACHE c_iconv_close */
void _A26_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_p);
}

	/* DESCRIPTOR_CACHE c_iconv_close */
void __A26_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ARGUMENT_BASE_PARSER fake inline-agent#13397#523#35# of command_option_configurations */
EIF_BOOLEAN _A140_132_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F164_13397)(closed [1].it_r, open [1].it_r);
}

	/* ARGUMENT_BASE_PARSER fake inline-agent#13397#523#35# of command_option_configurations */
EIF_BOOLEAN __A140_132_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F164_13397)(closed [1].it_r, op_2);
}

	/* THREAD thr_get_terminated */
EIF_BOOLEAN A196_51 (EIF_REFERENCE Current)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F234_2943)(Current);
}

	/* THREAD thr_main */
void A196_50 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) F234_2942)(Current, arg1);
}

	/* THREAD thr_set_terminated */
void A196_52 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) F234_2944)(Current, arg1);
}

	/* MISMATCH_INFORMATION wipe_out */
void A423_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F852_6775)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A423_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F860_6841)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A423_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F860_6842)(Current, arg1, arg2);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_cflag */
void _A428_562_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_cflag */
void __A428_562_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_linker_flag */
void _A428_563_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_linker_flag */
void __A428_563_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#13486#204#406# of on_start_tag_finish */
EIF_REFERENCE _A428_639_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F967_13486)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#13486#204#406# of on_start_tag_finish */
EIF_REFERENCE __A428_639_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F967_13486)(closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#13487#204#407# of on_start_tag_finish */
EIF_REFERENCE _A428_640_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F967_13487)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#13487#204#407# of on_start_tag_finish */
EIF_REFERENCE __A428_640_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F967_13487)(closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#13488#204#405# of on_start_tag_finish */
EIF_REFERENCE _A428_641_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F967_13488)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#13488#204#405# of on_start_tag_finish */
EIF_REFERENCE __A428_641_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F967_13488)(closed [1].it_r, op_2);
}

	/* EXECUTION_ENVIRONMENT item */
EIF_REFERENCE _A374_40_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EXECUTION_ENVIRONMENT item */
EIF_REFERENCE __A374_40_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LIBRARY process */
void _A533_400_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3758[Dtype(open [1].it_r) - 1100])(open [1].it_r, closed [1].it_r);
}

	/* CONF_LIBRARY process */
void __A533_400_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3758[Dtype(op_1) - 1100])(op_1, closed [1].it_r);
}

	/* CONF_LIBRARY is_enabled */
EIF_BOOLEAN _A533_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F405_4887)(open [1].it_r, closed [1].it_r);
}

	/* CONF_LIBRARY is_enabled */
EIF_BOOLEAN __A533_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F405_4887)(op_1, closed [1].it_r);
}

	/* CONF_ASSEMBLY process */
void _A532_408_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* CONF_ASSEMBLY process */
void __A532_408_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* CONF_ASSEMBLY is_enabled */
EIF_BOOLEAN _A532_385_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* CONF_ASSEMBLY is_enabled */
EIF_BOOLEAN __A532_385_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* CONF_CLUSTER process */
void _A528_416_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* CONF_CLUSTER process */
void __A528_416_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* CONF_CLUSTER is_enabled */
EIF_BOOLEAN _A528_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F405_4887)(open [1].it_r, closed [1].it_r);
}

	/* CONF_CLUSTER is_enabled */
EIF_BOOLEAN __A528_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F405_4887)(op_1, closed [1].it_r);
}

	/* CONF_OVERRIDE process */
void _A530_425_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* CONF_OVERRIDE process */
void __A530_425_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* CONF_OVERRIDE is_enabled */
EIF_BOOLEAN _A530_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F405_4887)(open [1].it_r, closed [1].it_r);
}

	/* CONF_OVERRIDE is_enabled */
EIF_BOOLEAN __A530_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F405_4887)(op_1, closed [1].it_r);
}

	/* ROOT_CLASS inline-agent#1 of compilation */
void _A616_369_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1297_13556)(closed [1].it_r, open [1].it_r);
}

	/* ROOT_CLASS inline-agent#1 of compilation */
void __A616_369_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1297_13556)(closed [1].it_r, op_2);
}

	/* ROOT_CLASS inline-agent#1 of parse */
void _A616_370_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1297_13557)(closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ROOT_CLASS inline-agent#1 of parse */
void __A616_370_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1297_13557)(closed [1].it_r, op_2, closed [2].it_r);
}

	/* ROOT_CLASS start */
void _A616_332 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* ROOT_CLASS start */
void __A616_332 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_action */
EIF_REFERENCE _A643_113_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_action */
EIF_REFERENCE __A643_113_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_padded_action */
EIF_REFERENCE _A643_114_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_padded_action */
EIF_REFERENCE __A643_114_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER month_action */
EIF_REFERENCE _A643_120_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_action */
EIF_REFERENCE __A643_120_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_name_action */
EIF_REFERENCE _A643_116_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_name_action */
EIF_REFERENCE __A643_116_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_sunday_as_first_action */
EIF_REFERENCE _A643_126_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_sunday_as_first_action */
EIF_REFERENCE __A643_126_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_4_action */
EIF_REFERENCE _A643_132_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_4_action */
EIF_REFERENCE __A643_132_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_day_name_action */
EIF_REFERENCE _A643_115_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_day_name_action */
EIF_REFERENCE __A643_115_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_year_action */
EIF_REFERENCE _A643_117_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_year_action */
EIF_REFERENCE __A643_117_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_action */
EIF_REFERENCE _A643_118_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_action */
EIF_REFERENCE __A643_118_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_0_action */
EIF_REFERENCE _A643_119_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_0_action */
EIF_REFERENCE __A643_119_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER month_padded_action */
EIF_REFERENCE _A643_121_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_padded_action */
EIF_REFERENCE __A643_121_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_month_name_action */
EIF_REFERENCE _A643_122_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_month_name_action */
EIF_REFERENCE __A643_122_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_name_action */
EIF_REFERENCE _A643_123_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_name_action */
EIF_REFERENCE __A643_123_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER century_number_action */
EIF_REFERENCE _A643_124_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER century_number_action */
EIF_REFERENCE __A643_124_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_with_century_action */
EIF_REFERENCE _A643_128_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_with_century_action */
EIF_REFERENCE __A643_128_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_without_century_action */
EIF_REFERENCE _A643_129_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_without_century_action */
EIF_REFERENCE __A643_129_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER week_number_iso_action */
EIF_REFERENCE _A643_125_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_iso_action */
EIF_REFERENCE __A643_125_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER week_number_monday_as_first_action */
EIF_REFERENCE _A643_127_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_monday_as_first_action */
EIF_REFERENCE __A643_127_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_1_action */
EIF_REFERENCE _A643_130_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_1_action */
EIF_REFERENCE __A643_130_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_2_action */
EIF_REFERENCE _A643_131_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_2_action */
EIF_REFERENCE __A643_131_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_padded_action */
EIF_REFERENCE _A643_102_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_padded_action */
EIF_REFERENCE __A643_102_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_action */
EIF_REFERENCE _A643_103_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_action */
EIF_REFERENCE __A643_103_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_24_action */
EIF_REFERENCE _A643_104_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_24_action */
EIF_REFERENCE __A643_104_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER minutes_action */
EIF_REFERENCE _A643_106_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER minutes_action */
EIF_REFERENCE __A643_106_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER minutes_padded_action */
EIF_REFERENCE _A643_107_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER minutes_padded_action */
EIF_REFERENCE __A643_107_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER seconds_action */
EIF_REFERENCE _A643_108_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER seconds_action */
EIF_REFERENCE __A643_108_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER seconds_padded_action */
EIF_REFERENCE _A643_109_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER seconds_padded_action */
EIF_REFERENCE __A643_109_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_1_action */
EIF_REFERENCE _A643_110_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_1_action */
EIF_REFERENCE __A643_110_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_lowercase_action */
EIF_REFERENCE _A643_111_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_lowercase_action */
EIF_REFERENCE __A643_111_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_uppercase_action */
EIF_REFERENCE _A643_112_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_uppercase_action */
EIF_REFERENCE __A643_112_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EIFFEL_ENV safe_create_dir */
void _A665_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EIFFEL_ENV safe_create_dir */
void __A665_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN _A503_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F766_6292)(open [1].it_r);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN __A503_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F766_6292)(op_1);
}


#ifdef __cplusplus
}
#endif
