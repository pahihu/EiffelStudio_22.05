#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif
extern const char *names10[];
static const uint32 types10 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags10 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype10_0 [] = {94,0xFFFF};
static const EIF_TYPE_INDEX g_atype10_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype10_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype10_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype10_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes10 [] = {
g_atype10_0,
g_atype10_1,
g_atype10_2,
g_atype10_3,
g_atype10_4,
};

static const long offsets10 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names12[];
static const uint32 types12 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags12 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype12_0 [] = {1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype12_1 [] = {1251,0xFFFF};

static const EIF_TYPE_INDEX *gtypes12 [] = {
g_atype12_0,
g_atype12_1,
};

static const long offsets12 [] =
{
0,
 + @REFACS(1),
};

extern const char *names15[];
static const uint32 types15 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags15 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype15_0 [] = {0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype15_1 [] = {0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype15_2 [] = {1334,0xFFFF};
static const EIF_TYPE_INDEX g_atype15_3 [] = {1090,0xFFFF};

static const EIF_TYPE_INDEX *gtypes15 [] = {
g_atype15_0,
g_atype15_1,
g_atype15_2,
g_atype15_3,
};

static const long offsets15 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names21[];
static const uint32 types21 [] =
{
SK_REF,
};

static const uint16 attr_flags21 [] =
{0,};

static const EIF_TYPE_INDEX g_atype21_0 [] = {0xFF01,450,0xFFFF};

static const EIF_TYPE_INDEX *gtypes21 [] = {
g_atype21_0,
};

static const long offsets21 [] =
{
0,
};

extern const char *names23[];
static const uint32 types23 [] =
{
SK_REF,
};

static const uint16 attr_flags23 [] =
{0,};

static const EIF_TYPE_INDEX g_atype23_0 [] = {0xFF01,860,0xFF01,1301,0xFFFF};

static const EIF_TYPE_INDEX *gtypes23 [] = {
g_atype23_0,
};

static const long offsets23 [] =
{
0,
};

extern const char *names26[];
static const uint32 types26 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags26 [] =
{0,};

static const EIF_TYPE_INDEX g_atype26_0 [] = {1034,0xFFFF};

static const EIF_TYPE_INDEX *gtypes26 [] = {
g_atype26_0,
};

static const long offsets26 [] =
{
+ @CHROFF(0,0),
};

extern const char *names27[];
static const uint32 types27 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags27 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype27_0 [] = {0xFF01,374,0xFFFF};
static const EIF_TYPE_INDEX g_atype27_1 [] = {0xFF01,374,0xFFFF};
static const EIF_TYPE_INDEX g_atype27_2 [] = {0xFF01,374,0xFFFF};

static const EIF_TYPE_INDEX *gtypes27 [] = {
g_atype27_0,
g_atype27_1,
g_atype27_2,
};

static const long offsets27 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names28[];
static const uint32 types28 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags28 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype28_0 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_1 [] = {0xFF01,139,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes28 [] = {
g_atype28_0,
g_atype28_1,
g_atype28_2,
};

static const long offsets28 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names29[];
static const uint32 types29 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags29 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype29_0 [] = {0xFF01,960,0xFF01,1026,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes29 [] = {
g_atype29_0,
g_atype29_1,
g_atype29_2,
};

static const long offsets29 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names31[];
static const uint32 types31 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags31 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype31_0 [] = {0xFF01,858,1070,0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype31_1 [] = {0xFF01,851,0xFF01,1080,0xFF01,1080,0xFFFF};

static const EIF_TYPE_INDEX *gtypes31 [] = {
g_atype31_0,
g_atype31_1,
};

static const long offsets31 [] =
{
0,
 + @REFACS(1),
};

extern const char *names32[];
static const uint32 types32 [] =
{
SK_UINT32,
};

static const uint16 attr_flags32 [] =
{0,};

static const EIF_TYPE_INDEX g_atype32_0 [] = {1231,0xFFFF};

static const EIF_TYPE_INDEX *gtypes32 [] = {
g_atype32_0,
};

static const long offsets32 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names34[];
static const uint32 types34 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags34 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype34_0 [] = {0xFF01,154,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_1 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_2 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_3 [] = {0xFF01,860,0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes34 [] = {
g_atype34_0,
g_atype34_1,
g_atype34_2,
g_atype34_3,
};

static const long offsets34 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names36[];
static const uint32 types36 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags36 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype36_0 [] = {0xFF01,136,0xFFFF};
static const EIF_TYPE_INDEX g_atype36_1 [] = {0xFF01,26,0xFFFF};
static const EIF_TYPE_INDEX g_atype36_2 [] = {0xFF01,138,0xFFFF};
static const EIF_TYPE_INDEX g_atype36_3 [] = {0xFF01,27,0xFFFF};
static const EIF_TYPE_INDEX g_atype36_4 [] = {0xFF01,25,0xFFFF};
static const EIF_TYPE_INDEX g_atype36_5 [] = {0xFF01,213,0xFFFF};

static const EIF_TYPE_INDEX *gtypes36 [] = {
g_atype36_0,
g_atype36_1,
g_atype36_2,
g_atype36_3,
g_atype36_4,
g_atype36_5,
};

static const long offsets36 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names37[];
static const uint32 types37 [] =
{
SK_UINT32,
};

static const uint16 attr_flags37 [] =
{1,};

static const EIF_TYPE_INDEX g_atype37_0 [] = {1231,0xFFFF};

static const EIF_TYPE_INDEX *gtypes37 [] = {
g_atype37_0,
};

static const long offsets37 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names38[];
static const uint32 types38 [] =
{
SK_REF,
};

static const uint16 attr_flags38 [] =
{0,};

static const EIF_TYPE_INDEX g_atype38_0 [] = {0xFF01,1141,1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes38 [] = {
g_atype38_0,
};

static const long offsets38 [] =
{
0,
};

extern const char *names39[];
static const uint32 types39 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags39 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype39_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype39_1 [] = {0xFF01,1142,1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes39 [] = {
g_atype39_0,
g_atype39_1,
};

static const long offsets39 [] =
{
0,
 + @REFACS(1),
};

extern const char *names40[];
static const uint32 types40 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags40 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype40_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype40_1 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype40_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype40_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype40_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype40_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes40 [] = {
g_atype40_0,
g_atype40_1,
g_atype40_2,
g_atype40_3,
g_atype40_4,
g_atype40_5,
};

static const long offsets40 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names43[];
static const uint32 types43 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags43 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype43_0 [] = {0xFF01,1026,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_1 [] = {1085,0xFFFF};

static const EIF_TYPE_INDEX *gtypes43 [] = {
g_atype43_0,
g_atype43_1,
};

static const long offsets43 [] =
{
0,
 + @REFACS(1),
};

extern const char *names44[];
static const uint32 types44 [] =
{
SK_INT32,
};

static const uint16 attr_flags44 [] =
{0,};

static const EIF_TYPE_INDEX g_atype44_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes44 [] = {
g_atype44_0,
};

static const long offsets44 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names45[];
static const uint32 types45 [] =
{
SK_INT32,
};

static const uint16 attr_flags45 [] =
{0,};

static const EIF_TYPE_INDEX g_atype45_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes45 [] = {
g_atype45_0,
};

static const long offsets45 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names46[];
static const uint32 types46 [] =
{
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags46 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype46_0 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes46 [] = {
g_atype46_0,
g_atype46_1,
g_atype46_2,
g_atype46_3,
};

static const long offsets46 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @LNGOFF(0,0,0,2),
+ @LNGOFF(0,0,0,3),
};

extern const char *names48[];
static const uint32 types48 [] =
{
SK_INT32,
};

static const uint16 attr_flags48 [] =
{0,};

static const EIF_TYPE_INDEX g_atype48_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes48 [] = {
g_atype48_0,
};

static const long offsets48 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names49[];
static const uint32 types49 [] =
{
SK_INT32,
};

static const uint16 attr_flags49 [] =
{0,};

static const EIF_TYPE_INDEX g_atype49_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes49 [] = {
g_atype49_0,
};

static const long offsets49 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names53[];
static const uint32 types53 [] =
{
SK_REF,
};

static const uint16 attr_flags53 [] =
{0,};

static const EIF_TYPE_INDEX g_atype53_0 [] = {0xFF01,948,0xFF01,154,0xFFFF};

static const EIF_TYPE_INDEX *gtypes53 [] = {
g_atype53_0,
};

static const long offsets53 [] =
{
0,
};

extern const char *names54[];
static const uint32 types54 [] =
{
SK_REF,
};

static const uint16 attr_flags54 [] =
{0,};

static const EIF_TYPE_INDEX g_atype54_0 [] = {0xFF01,943,0xFF01,851,0xFF01,1084,0xFF01,1086,0xFFFF};

static const EIF_TYPE_INDEX *gtypes54 [] = {
g_atype54_0,
};

static const long offsets54 [] =
{
0,
};

extern const char *names57[];
static const uint32 types57 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags57 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype57_0 [] = {0xFF01,444,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes57 [] = {
g_atype57_0,
g_atype57_1,
g_atype57_2,
};

static const long offsets57 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names63[];
static const uint32 types63 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags63 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype63_0 [] = {0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype63_1 [] = {0xFF01,1282,0xFFFF};

static const EIF_TYPE_INDEX *gtypes63 [] = {
g_atype63_0,
g_atype63_1,
};

static const long offsets63 [] =
{
0,
 + @REFACS(1),
};

extern const char *names65[];
static const uint32 types65 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags65 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype65_0 [] = {0xFF01,239,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_1 [] = {0xFF01,171,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_2 [] = {0xFF01,948,0xFF01,273,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes65 [] = {
g_atype65_0,
g_atype65_1,
g_atype65_2,
g_atype65_3,
g_atype65_4,
};

static const long offsets65 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names67[];
static const uint32 types67 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags67 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype67_0 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype67_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype67_2 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype67_3 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes67 [] = {
g_atype67_0,
g_atype67_1,
g_atype67_2,
g_atype67_3,
};

static const long offsets67 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
};

extern const char *names68[];
static const uint32 types68 [] =
{
SK_INT32,
};

static const uint16 attr_flags68 [] =
{0,};

static const EIF_TYPE_INDEX g_atype68_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes68 [] = {
g_atype68_0,
};

static const long offsets68 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names69[];
static const uint32 types69 [] =
{
SK_REF,
};

static const uint16 attr_flags69 [] =
{0,};

static const EIF_TYPE_INDEX g_atype69_0 [] = {0xFF01,948,0xFF01,1101,0xFFFF};

static const EIF_TYPE_INDEX *gtypes69 [] = {
g_atype69_0,
};

static const long offsets69 [] =
{
0,
};

extern const char *names70[];
static const uint32 types70 [] =
{
SK_BOOL,
SK_UINT8,
};

static const uint16 attr_flags70 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype70_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_1 [] = {1237,0xFFFF};

static const EIF_TYPE_INDEX *gtypes70 [] = {
g_atype70_0,
g_atype70_1,
};

static const long offsets70 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
};

extern const char *names72[];
static const uint32 types72 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags72 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype72_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype72_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype72_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype72_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes72 [] = {
g_atype72_0,
g_atype72_1,
g_atype72_2,
g_atype72_3,
};

static const long offsets72 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @LNGOFF(0,3,0,0),
};

extern const char *names86[];
static const uint32 types86 [] =
{
SK_REF,
};

static const uint16 attr_flags86 [] =
{0,};

static const EIF_TYPE_INDEX g_atype86_0 [] = {829,0xFFFF};

static const EIF_TYPE_INDEX *gtypes86 [] = {
g_atype86_0,
};

static const long offsets86 [] =
{
0,
};

extern const char *names90[];
static const uint32 types90 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags90 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype90_0 [] = {263,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_1 [] = {0xFF01,919,0xFF01,273,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes90 [] = {
g_atype90_0,
g_atype90_1,
g_atype90_2,
};

static const long offsets90 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names103[];
static const uint32 types103 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags103 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype103_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes103 [] = {
g_atype103_0,
g_atype103_1,
};

static const long offsets103 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names106[];
static const uint32 types106 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags106 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype106_0 [] = {0xFF01,919,0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes106 [] = {
g_atype106_0,
g_atype106_1,
};

static const long offsets106 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names107[];
static const uint32 types107 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags107 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype107_0 [] = {0xFF01,948,0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes107 [] = {
g_atype107_0,
g_atype107_1,
g_atype107_2,
};

static const long offsets107 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names109[];
static const uint32 types109 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags109 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype109_0 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_1 [] = {211,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes109 [] = {
g_atype109_0,
g_atype109_1,
g_atype109_2,
};

static const long offsets109 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names110[];
static const uint32 types110 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags110 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype110_0 [] = {108,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_1 [] = {212,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes110 [] = {
g_atype110_0,
g_atype110_1,
g_atype110_2,
};

static const long offsets110 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names112[];
static const uint32 types112 [] =
{
SK_REF,
};

static const uint16 attr_flags112 [] =
{0,};

static const EIF_TYPE_INDEX g_atype112_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes112 [] = {
g_atype112_0,
};

static const long offsets112 [] =
{
0,
};

extern const char *names113[];
static const uint32 types113 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags113 [] =
{0,};

static const EIF_TYPE_INDEX g_atype113_0 [] = {1034,0xFFFF};

static const EIF_TYPE_INDEX *gtypes113 [] = {
g_atype113_0,
};

static const long offsets113 [] =
{
+ @CHROFF(0,0),
};

extern const char *names114[];
static const uint32 types114 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags114 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype114_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_1 [] = {113,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes114 [] = {
g_atype114_0,
g_atype114_1,
};

static const long offsets114 [] =
{
0,
 + @REFACS(1),
};

extern const char *names115[];
static const uint32 types115 [] =
{
SK_REF,
SK_CHAR8,
};

static const uint16 attr_flags115 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype115_0 [] = {114,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_1 [] = {1034,0xFFFF};

static const EIF_TYPE_INDEX *gtypes115 [] = {
g_atype115_0,
g_atype115_1,
};

static const long offsets115 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names119[];
static const uint32 types119 [] =
{
SK_UINT64,
};

static const uint16 attr_flags119 [] =
{0,};

static const EIF_TYPE_INDEX g_atype119_0 [] = {1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes119 [] = {
g_atype119_0,
};

static const long offsets119 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names120[];
static const uint32 types120 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags120 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype120_0 [] = {0xFF01,1148,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_1 [] = {0xFF01,1145,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_3 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_4 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_5 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_6 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_7 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_8 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_9 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_10 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_11 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_13 [] = {1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes120 [] = {
g_atype120_0,
g_atype120_1,
g_atype120_2,
g_atype120_3,
g_atype120_4,
g_atype120_5,
g_atype120_6,
g_atype120_7,
g_atype120_8,
g_atype120_9,
g_atype120_10,
g_atype120_11,
g_atype120_12,
g_atype120_13,
};

static const long offsets120 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
+ @LNGOFF(2,0,0,9),
+ @LNGOFF(2,0,0,10),
+ @I64OFF(2,0,0,11,0,0,0),
};

extern const char *names133[];
static const uint32 types133 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags133 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype133_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_2 [] = {1082,0xFFFF};

static const EIF_TYPE_INDEX *gtypes133 [] = {
g_atype133_0,
g_atype133_1,
g_atype133_2,
};

static const long offsets133 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names134[];
static const uint32 types134 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags134 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype134_0 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_2 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_3 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_4 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_5 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_6 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_7 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_8 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_9 [] = {0xFF01,878,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_10 [] = {0xFF01,878,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_11 [] = {0xFF01,878,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_12 [] = {0xFF01,878,0xFF01,1086,0xFFFF};

static const EIF_TYPE_INDEX *gtypes134 [] = {
g_atype134_0,
g_atype134_1,
g_atype134_2,
g_atype134_3,
g_atype134_4,
g_atype134_5,
g_atype134_6,
g_atype134_7,
g_atype134_8,
g_atype134_9,
g_atype134_10,
g_atype134_11,
g_atype134_12,
};

static const long offsets134 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
};

extern const char *names135[];
static const uint32 types135 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags135 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype135_0 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_2 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_3 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_4 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_5 [] = {0xFF01,880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes135 [] = {
g_atype135_0,
g_atype135_1,
g_atype135_2,
g_atype135_3,
g_atype135_4,
g_atype135_5,
g_atype135_6,
};

static const long offsets135 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names136[];
static const uint32 types136 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags136 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype136_0 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_2 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_3 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_4 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_5 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_6 [] = {0xFF01,880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_7 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_8 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_9 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_10 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_11 [] = {0xFF01,880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_15 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes136 [] = {
g_atype136_0,
g_atype136_1,
g_atype136_2,
g_atype136_3,
g_atype136_4,
g_atype136_5,
g_atype136_6,
g_atype136_7,
g_atype136_8,
g_atype136_9,
g_atype136_10,
g_atype136_11,
g_atype136_12,
g_atype136_13,
g_atype136_14,
g_atype136_15,
};

static const long offsets136 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @LNGOFF(12,0,0,0),
+ @LNGOFF(12,0,0,1),
+ @LNGOFF(12,0,0,2),
+ @LNGOFF(12,0,0,3),
};

extern const char *names137[];
static const uint32 types137 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags137 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype137_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_2 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_3 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_4 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_5 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_6 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_7 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_8 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_9 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_10 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_11 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_12 [] = {0xFF01,878,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_13 [] = {0xFF01,878,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_14 [] = {0xFF01,878,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_15 [] = {0xFF01,878,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_16 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_17 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_18 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_19 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_20 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_21 [] = {0xFF01,880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_22 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_23 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_24 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_25 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_26 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_27 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_28 [] = {0xFF01,880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_29 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_30 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_31 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_32 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_33 [] = {0xFF01,880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_34 [] = {0xFF01,1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_35 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_36 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_37 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_38 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_39 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes137 [] = {
g_atype137_0,
g_atype137_1,
g_atype137_2,
g_atype137_3,
g_atype137_4,
g_atype137_5,
g_atype137_6,
g_atype137_7,
g_atype137_8,
g_atype137_9,
g_atype137_10,
g_atype137_11,
g_atype137_12,
g_atype137_13,
g_atype137_14,
g_atype137_15,
g_atype137_16,
g_atype137_17,
g_atype137_18,
g_atype137_19,
g_atype137_20,
g_atype137_21,
g_atype137_22,
g_atype137_23,
g_atype137_24,
g_atype137_25,
g_atype137_26,
g_atype137_27,
g_atype137_28,
g_atype137_29,
g_atype137_30,
g_atype137_31,
g_atype137_32,
g_atype137_33,
g_atype137_34,
g_atype137_35,
g_atype137_36,
g_atype137_37,
g_atype137_38,
g_atype137_39,
};

static const long offsets137 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
+ @LNGOFF(35,0,0,0),
+ @LNGOFF(35,0,0,1),
+ @LNGOFF(35,0,0,2),
+ @LNGOFF(35,0,0,3),
+ @LNGOFF(35,0,0,4),
};

extern const char *names139[];
static const uint32 types139 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags139 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype139_0 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_2 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_3 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_4 [] = {0xFF01,880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes139 [] = {
g_atype139_0,
g_atype139_1,
g_atype139_2,
g_atype139_3,
g_atype139_4,
g_atype139_5,
};

static const long offsets139 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names140[];
static const uint32 types140 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags140 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype140_0 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_2 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_3 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_4 [] = {0xFF01,880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes140 [] = {
g_atype140_0,
g_atype140_1,
g_atype140_2,
g_atype140_3,
g_atype140_4,
g_atype140_5,
};

static const long offsets140 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names143[];
static const uint32 types143 [] =
{
SK_REF,
};

static const uint16 attr_flags143 [] =
{0,};

static const EIF_TYPE_INDEX g_atype143_0 [] = {0xFF01,1086,0xFFFF};

static const EIF_TYPE_INDEX *gtypes143 [] = {
g_atype143_0,
};

static const long offsets143 [] =
{
0,
};

extern const char *names144[];
static const uint32 types144 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags144 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype144_0 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_1 [] = {0xFF01,851,0xFF01,1077,0xFF01,1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_2 [] = {0xFF01,948,0xFF01,1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_3 [] = {0xFF01,851,0xFF01,1077,0xFF01,1251,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_4 [] = {0xFF01,948,0xFF01,1251,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_5 [] = {0xFF01,448,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_6 [] = {0xFF01,108,0xFFFF};

static const EIF_TYPE_INDEX *gtypes144 [] = {
g_atype144_0,
g_atype144_1,
g_atype144_2,
g_atype144_3,
g_atype144_4,
g_atype144_5,
g_atype144_6,
};

static const long offsets144 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
};

extern const char *names146[];
static const uint32 types146 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags146 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype146_0 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes146 [] = {
g_atype146_0,
g_atype146_1,
g_atype146_2,
g_atype146_3,
};

static const long offsets146 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names147[];
static const uint32 types147 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags147 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype147_0 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_2 [] = {950,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_3 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes147 [] = {
g_atype147_0,
g_atype147_1,
g_atype147_2,
g_atype147_3,
g_atype147_4,
g_atype147_5,
g_atype147_6,
};

static const long offsets147 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
};

extern const char *names148[];
static const uint32 types148 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags148 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype148_0 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_2 [] = {950,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_3 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_4 [] = {0xFF01,943,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_5 [] = {950,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_8 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_9 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_12 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes148 [] = {
g_atype148_0,
g_atype148_1,
g_atype148_2,
g_atype148_3,
g_atype148_4,
g_atype148_5,
g_atype148_6,
g_atype148_7,
g_atype148_8,
g_atype148_9,
g_atype148_10,
g_atype148_11,
g_atype148_12,
};

static const long offsets148 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @LNGOFF(6,2,0,1),
+ @LNGOFF(6,2,0,2),
+ @LNGOFF(6,2,0,3),
+ @LNGOFF(6,2,0,4),
};

extern const char *names149[];
static const uint32 types149 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags149 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype149_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_1 [] = {1072,0xFF01,0xFFF9,1,1025,0xFF01,390,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_2 [] = {1072,0xFF01,0xFFF9,2,1025,0xFF01,390,0xFF01,390,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_3 [] = {1072,0xFF01,0xFFF9,1,1025,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_4 [] = {948,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_5 [] = {856,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_11 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes149 [] = {
g_atype149_0,
g_atype149_1,
g_atype149_2,
g_atype149_3,
g_atype149_4,
g_atype149_5,
g_atype149_6,
g_atype149_7,
g_atype149_8,
g_atype149_9,
g_atype149_10,
g_atype149_11,
};

static const long offsets149 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names150[];
static const uint32 types150 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags150 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype150_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_1 [] = {1072,0xFF01,0xFFF9,1,1025,0xFF01,390,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_2 [] = {1072,0xFF01,0xFFF9,2,1025,0xFF01,390,0xFF01,390,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_3 [] = {1072,0xFF01,0xFFF9,1,1025,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_4 [] = {948,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_5 [] = {856,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_11 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes150 [] = {
g_atype150_0,
g_atype150_1,
g_atype150_2,
g_atype150_3,
g_atype150_4,
g_atype150_5,
g_atype150_6,
g_atype150_7,
g_atype150_8,
g_atype150_9,
g_atype150_10,
g_atype150_11,
};

static const long offsets150 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names153[];
static const uint32 types153 [] =
{
SK_REF,
};

static const uint16 attr_flags153 [] =
{0,};

static const EIF_TYPE_INDEX g_atype153_0 [] = {0xFF01,948,0xFF01,297,0xFFFF};

static const EIF_TYPE_INDEX *gtypes153 [] = {
g_atype153_0,
};

static const long offsets153 [] =
{
0,
};

extern const char *names154[];
static const uint32 types154 [] =
{
SK_BOOL,
};

static const uint16 attr_flags154 [] =
{0,};

static const EIF_TYPE_INDEX g_atype154_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes154 [] = {
g_atype154_0,
};

static const long offsets154 [] =
{
+ @CHROFF(0,0),
};

extern const char *names156[];
static const uint32 types156 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags156 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype156_0 [] = {0xFF01,450,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_1 [] = {0xFF01,34,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_2 [] = {453,0xFFFF};

static const EIF_TYPE_INDEX *gtypes156 [] = {
g_atype156_0,
g_atype156_1,
g_atype156_2,
};

static const long offsets156 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names164[];
static const uint32 types164 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags164 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype164_0 [] = {0xFF01,243,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_1 [] = {0xFF01,948,0xFF01,42,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_2 [] = {0xFF01,948,0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_3 [] = {259,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_11 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_12 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_13 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_14 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_15 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes164 [] = {
g_atype164_0,
g_atype164_1,
g_atype164_2,
g_atype164_3,
g_atype164_4,
g_atype164_5,
g_atype164_6,
g_atype164_7,
g_atype164_8,
g_atype164_9,
g_atype164_10,
g_atype164_11,
g_atype164_12,
g_atype164_13,
g_atype164_14,
g_atype164_15,
};

static const long offsets164 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @CHROFF(4,7),
+ @CHROFF(4,8),
+ @CHROFF(4,9),
+ @CHROFF(4,10),
+ @CHROFF(4,11),
};

extern const char *names165[];
static const uint32 types165 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags165 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype165_0 [] = {0xFF01,243,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_1 [] = {0xFF01,948,0xFF01,42,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_2 [] = {0xFF01,948,0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_3 [] = {259,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_11 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_12 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_13 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_14 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_15 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes165 [] = {
g_atype165_0,
g_atype165_1,
g_atype165_2,
g_atype165_3,
g_atype165_4,
g_atype165_5,
g_atype165_6,
g_atype165_7,
g_atype165_8,
g_atype165_9,
g_atype165_10,
g_atype165_11,
g_atype165_12,
g_atype165_13,
g_atype165_14,
g_atype165_15,
};

static const long offsets165 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @CHROFF(4,7),
+ @CHROFF(4,8),
+ @CHROFF(4,9),
+ @CHROFF(4,10),
+ @CHROFF(4,11),
};

extern const char *names166[];
static const uint32 types166 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags166 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype166_0 [] = {0xFF01,243,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_1 [] = {0xFF01,948,0xFF01,42,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_2 [] = {0xFF01,948,0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_3 [] = {259,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_11 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_12 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_13 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_14 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_15 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes166 [] = {
g_atype166_0,
g_atype166_1,
g_atype166_2,
g_atype166_3,
g_atype166_4,
g_atype166_5,
g_atype166_6,
g_atype166_7,
g_atype166_8,
g_atype166_9,
g_atype166_10,
g_atype166_11,
g_atype166_12,
g_atype166_13,
g_atype166_14,
g_atype166_15,
};

static const long offsets166 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @CHROFF(4,7),
+ @CHROFF(4,8),
+ @CHROFF(4,9),
+ @CHROFF(4,10),
+ @CHROFF(4,11),
};

extern const char *names171[];
static const uint32 types171 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags171 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype171_0 [] = {0xFF01,263,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_1 [] = {0xFF01,262,0xFFFF};

static const EIF_TYPE_INDEX *gtypes171 [] = {
g_atype171_0,
g_atype171_1,
};

static const long offsets171 [] =
{
0,
 + @REFACS(1),
};

extern const char *names180[];
static const uint32 types180 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_UINT32,
};

static const uint16 attr_flags180 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype180_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_1 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_3 [] = {1231,0xFFFF};

static const EIF_TYPE_INDEX *gtypes180 [] = {
g_atype180_0,
g_atype180_1,
g_atype180_2,
g_atype180_3,
};

static const long offsets180 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names181[];
static const uint32 types181 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags181 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype181_0 [] = {459,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes181 [] = {
g_atype181_0,
g_atype181_1,
g_atype181_2,
};

static const long offsets181 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names184[];
static const uint32 types184 [] =
{
SK_REF,
};

static const uint16 attr_flags184 [] =
{0,};

static const EIF_TYPE_INDEX g_atype184_0 [] = {0xFF01,277,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes184 [] = {
g_atype184_0,
};

static const long offsets184 [] =
{
0,
};

extern const char *names185[];
static const uint32 types185 [] =
{
SK_REF,
};

static const uint16 attr_flags185 [] =
{0,};

static const EIF_TYPE_INDEX g_atype185_0 [] = {0xFF01,277,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes185 [] = {
g_atype185_0,
};

static const long offsets185 [] =
{
0,
};

extern const char *names190[];
static const uint32 types190 [] =
{
SK_REF,
};

static const uint16 attr_flags190 [] =
{0,};

static const EIF_TYPE_INDEX g_atype190_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes190 [] = {
g_atype190_0,
};

static const long offsets190 [] =
{
0,
};

extern const char *names191[];
static const uint32 types191 [] =
{
SK_UINT64,
};

static const uint16 attr_flags191 [] =
{0,};

static const EIF_TYPE_INDEX g_atype191_0 [] = {1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes191 [] = {
g_atype191_0,
};

static const long offsets191 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names192[];
static const uint32 types192 [] =
{
SK_BOOL,
};

static const uint16 attr_flags192 [] =
{0,};

static const EIF_TYPE_INDEX g_atype192_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes192 [] = {
g_atype192_0,
};

static const long offsets192 [] =
{
+ @CHROFF(0,0),
};

extern const char *names193[];
static const uint32 types193 [] =
{
SK_INT32,
};

static const uint16 attr_flags193 [] =
{0,};

static const EIF_TYPE_INDEX g_atype193_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes193 [] = {
g_atype193_0,
};

static const long offsets193 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names194[];
static const uint32 types194 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags194 [] =
{0,};

static const EIF_TYPE_INDEX g_atype194_0 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes194 [] = {
g_atype194_0,
};

static const long offsets194 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names195[];
static const uint32 types195 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags195 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype195_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_1 [] = {194,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes195 [] = {
g_atype195_0,
g_atype195_1,
};

static const long offsets195 [] =
{
0,
 + @REFACS(1),
};

extern const char *names196[];
static const uint32 types196 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags196 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype196_0 [] = {195,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes196 [] = {
g_atype196_0,
g_atype196_1,
};

static const long offsets196 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names205[];
static const uint32 types205 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags205 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype205_0 [] = {0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_1 [] = {0xFF01,948,0xFF01,606,0xFFFF};

static const EIF_TYPE_INDEX *gtypes205 [] = {
g_atype205_0,
g_atype205_1,
};

static const long offsets205 [] =
{
0,
 + @REFACS(1),
};

extern const char *names207[];
static const uint32 types207 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags207 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype207_0 [] = {0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_1 [] = {948,0xFF01,0xFFF9,2,1025,0xFF01,1077,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_2 [] = {948,0xFF01,0xFFF9,2,1025,0xFF01,1077,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_4 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes207 [] = {
g_atype207_0,
g_atype207_1,
g_atype207_2,
g_atype207_3,
g_atype207_4,
};

static const long offsets207 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names208[];
static const uint32 types208 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags208 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype208_0 [] = {0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_1 [] = {948,0xFF01,0xFFF9,2,1025,0xFF01,1077,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_2 [] = {948,0xFF01,0xFFF9,2,1025,0xFF01,1077,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_3 [] = {0xFF01,860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_4 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_6 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes208 [] = {
g_atype208_0,
g_atype208_1,
g_atype208_2,
g_atype208_3,
g_atype208_4,
g_atype208_5,
g_atype208_6,
};

static const long offsets208 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
};

extern const char *names209[];
static const uint32 types209 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags209 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype209_0 [] = {0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_1 [] = {948,0xFF01,0xFFF9,2,1025,0xFF01,1077,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_2 [] = {948,0xFF01,0xFFF9,2,1025,0xFF01,1077,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_3 [] = {0xFF01,838,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_5 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes209 [] = {
g_atype209_0,
g_atype209_1,
g_atype209_2,
g_atype209_3,
g_atype209_4,
g_atype209_5,
};

static const long offsets209 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
};

extern const char *names212[];
static const uint32 types212 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags212 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype212_0 [] = {0xFF01,827,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes212 [] = {
g_atype212_0,
g_atype212_1,
g_atype212_2,
g_atype212_3,
};

static const long offsets212 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names213[];
static const uint32 types213 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags213 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype213_0 [] = {0xFF01,827,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_1 [] = {0xFF01,0xFFF9,2,1025,1219,0xFF01,919,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_2 [] = {0xFF01,0xFFF9,2,1025,1219,0xFF01,919,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_14 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes213 [] = {
g_atype213_0,
g_atype213_1,
g_atype213_2,
g_atype213_3,
g_atype213_4,
g_atype213_5,
g_atype213_6,
g_atype213_7,
g_atype213_8,
g_atype213_9,
g_atype213_10,
g_atype213_11,
g_atype213_12,
g_atype213_13,
g_atype213_14,
};

static const long offsets213 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @LNGOFF(3,5,0,0),
+ @LNGOFF(3,5,0,1),
+ @LNGOFF(3,5,0,2),
+ @LNGOFF(3,5,0,3),
+ @LNGOFF(3,5,0,4),
+ @LNGOFF(3,5,0,5),
+ @LNGOFF(3,5,0,6),
};

extern const char *names214[];
static const uint32 types214 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags214 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype214_0 [] = {0xFF01,1075,0xFF01,0xFFF9,1,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes214 [] = {
g_atype214_0,
g_atype214_1,
g_atype214_2,
};

static const long offsets214 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names215[];
static const uint32 types215 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags215 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype215_0 [] = {0xFF01,1075,0xFF01,0xFFF9,1,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_1 [] = {0xFF01,878,0xFF01,385,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes215 [] = {
g_atype215_0,
g_atype215_1,
g_atype215_2,
g_atype215_3,
g_atype215_4,
};

static const long offsets215 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names216[];
static const uint32 types216 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags216 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype216_0 [] = {0xFF01,1075,0xFF01,0xFFF9,1,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes216 [] = {
g_atype216_0,
g_atype216_1,
g_atype216_2,
};

static const long offsets216 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names227[];
static const uint32 types227 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags227 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype227_0 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_1 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes227 [] = {
g_atype227_0,
g_atype227_1,
};

static const long offsets227 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names230[];
static const uint32 types230 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags230 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype230_0 [] = {0xFF01,226,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_1 [] = {0xFF01,494,0xFFFF};

static const EIF_TYPE_INDEX *gtypes230 [] = {
g_atype230_0,
g_atype230_1,
};

static const long offsets230 [] =
{
0,
 + @REFACS(1),
};

extern const char *names234[];
static const uint32 types234 [] =
{
SK_REF,
SK_BOOL,
SK_POINTER,
};

static const uint16 attr_flags234 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype234_0 [] = {0xFF01,443,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_2 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes234 [] = {
g_atype234_0,
g_atype234_1,
g_atype234_2,
};

static const long offsets234 [] =
{
0,
+ @CHROFF(1,0),
+ @PTROFF(1,1,0,0,0,0),
};

extern const char *names235[];
static const uint32 types235 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags235 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype235_0 [] = {0xFF01,443,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_1 [] = {0xFF01,460,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_2 [] = {0xFF01,443,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_6 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes235 [] = {
g_atype235_0,
g_atype235_1,
g_atype235_2,
g_atype235_3,
g_atype235_4,
g_atype235_5,
g_atype235_6,
};

static const long offsets235 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @LNGOFF(3,2,0,0),
+ @PTROFF(3,2,0,1,0,0),
};

extern const char *names239[];
static const uint32 types239 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags239 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype239_0 [] = {0xFF01,948,0xFF01,298,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_1 [] = {0xFF01,948,0xFF01,303,0xFFFF};

static const EIF_TYPE_INDEX *gtypes239 [] = {
g_atype239_0,
g_atype239_1,
};

static const long offsets239 [] =
{
0,
 + @REFACS(1),
};

extern const char *names240[];
static const uint32 types240 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags240 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype240_0 [] = {0xFF01,948,0xFF01,297,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_1 [] = {0xFF01,948,0xFF01,298,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_2 [] = {0xFF01,948,0xFF01,303,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_3 [] = {45,0xFFFF};

static const EIF_TYPE_INDEX *gtypes240 [] = {
g_atype240_0,
g_atype240_1,
g_atype240_2,
g_atype240_3,
};

static const long offsets240 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names242[];
static const uint32 types242 [] =
{
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags242 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype242_0 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes242 [] = {
g_atype242_0,
g_atype242_1,
g_atype242_2,
g_atype242_3,
};

static const long offsets242 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names244[];
static const uint32 types244 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags244 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype244_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes244 [] = {
g_atype244_0,
g_atype244_1,
g_atype244_2,
};

static const long offsets244 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names245[];
static const uint32 types245 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags245 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype245_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes245 [] = {
g_atype245_0,
g_atype245_1,
g_atype245_2,
};

static const long offsets245 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names246[];
static const uint32 types246 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags246 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype246_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes246 [] = {
g_atype246_0,
g_atype246_1,
g_atype246_2,
};

static const long offsets246 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names252[];
static const uint32 types252 [] =
{
SK_BOOL,
};

static const uint16 attr_flags252 [] =
{0,};

static const EIF_TYPE_INDEX g_atype252_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes252 [] = {
g_atype252_0,
};

static const long offsets252 [] =
{
+ @CHROFF(0,0),
};

extern const char *names257[];
static const uint32 types257 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags257 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype257_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_1 [] = {1140,0xFF01,1142,1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes257 [] = {
g_atype257_0,
g_atype257_1,
};

static const long offsets257 [] =
{
0,
 + @REFACS(1),
};

extern const char *names258[];
static const uint32 types258 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags258 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype258_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_1 [] = {1140,0xFF01,1142,1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes258 [] = {
g_atype258_0,
g_atype258_1,
};

static const long offsets258 [] =
{
0,
 + @REFACS(1),
};

extern const char *names259[];
static const uint32 types259 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags259 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype259_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_1 [] = {1140,0xFF01,1142,1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes259 [] = {
g_atype259_0,
g_atype259_1,
};

static const long offsets259 [] =
{
0,
 + @REFACS(1),
};

extern const char *names262[];
static const uint32 types262 [] =
{
SK_REF,
};

static const uint16 attr_flags262 [] =
{0,};

static const EIF_TYPE_INDEX g_atype262_0 [] = {0xFF01,454,0xFFFF};

static const EIF_TYPE_INDEX *gtypes262 [] = {
g_atype262_0,
};

static const long offsets262 [] =
{
0,
};

extern const char *names263[];
static const uint32 types263 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags263 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype263_0 [] = {0xFF01,948,0xFF01,1264,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_1 [] = {0xFF01,948,0xFF01,1256,0xFFFF};

static const EIF_TYPE_INDEX *gtypes263 [] = {
g_atype263_0,
g_atype263_1,
};

static const long offsets263 [] =
{
0,
 + @REFACS(1),
};

extern const char *names264[];
static const uint32 types264 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags264 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype264_0 [] = {0xFF01,948,0xFF01,1264,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_1 [] = {0xFF01,948,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_2 [] = {0xFF01,948,0xFF01,1102,0xFFFF};

static const EIF_TYPE_INDEX *gtypes264 [] = {
g_atype264_0,
g_atype264_1,
g_atype264_2,
};

static const long offsets264 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names266[];
static const uint32 types266 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags266 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype266_0 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_1 [] = {1001,0xFFFF};

static const EIF_TYPE_INDEX *gtypes266 [] = {
g_atype266_0,
g_atype266_1,
};

static const long offsets266 [] =
{
0,
 + @REFACS(1),
};

extern const char *names267[];
static const uint32 types267 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags267 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype267_0 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_1 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_2 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_3 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes267 [] = {
g_atype267_0,
g_atype267_1,
g_atype267_2,
g_atype267_3,
};

static const long offsets267 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
};

extern const char *names269[];
static const uint32 types269 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags269 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype269_0 [] = {0xFF01,1143,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_1 [] = {0xFF01,1143,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_2 [] = {0xFF01,1143,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_3 [] = {0xFF01,1143,1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes269 [] = {
g_atype269_0,
g_atype269_1,
g_atype269_2,
g_atype269_3,
};

static const long offsets269 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names270[];
static const uint32 types270 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags270 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype270_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_1 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes270 [] = {
g_atype270_0,
g_atype270_1,
g_atype270_2,
g_atype270_3,
g_atype270_4,
g_atype270_5,
g_atype270_6,
};

static const long offsets270 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
};

extern const char *names271[];
static const uint32 types271 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags271 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype271_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_1 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_2 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_9 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_10 [] = {1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes271 [] = {
g_atype271_0,
g_atype271_1,
g_atype271_2,
g_atype271_3,
g_atype271_4,
g_atype271_5,
g_atype271_6,
g_atype271_7,
g_atype271_8,
g_atype271_9,
g_atype271_10,
};

static const long offsets271 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @I64OFF(2,4,0,3,0,0,0),
+ @I64OFF(2,4,0,3,0,0,1),
};

extern const char *names272[];
static const uint32 types272 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags272 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype272_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_1 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_12 [] = {1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_13 [] = {1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_14 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes272 [] = {
g_atype272_0,
g_atype272_1,
g_atype272_2,
g_atype272_3,
g_atype272_4,
g_atype272_5,
g_atype272_6,
g_atype272_7,
g_atype272_8,
g_atype272_9,
g_atype272_10,
g_atype272_11,
g_atype272_12,
g_atype272_13,
g_atype272_14,
};

static const long offsets272 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @R64OFF(2,6,0,4,0,0,0,0),
+ @R64OFF(2,6,0,4,0,0,0,1),
+ @R64OFF(2,6,0,4,0,0,0,2),
};

extern const char *names273[];
static const uint32 types273 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags273 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype273_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_1 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_8 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_9 [] = {1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes273 [] = {
g_atype273_0,
g_atype273_1,
g_atype273_2,
g_atype273_3,
g_atype273_4,
g_atype273_5,
g_atype273_6,
g_atype273_7,
g_atype273_8,
g_atype273_9,
};

static const long offsets273 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
+ @LNGOFF(2,3,0,1),
+ @LNGOFF(2,3,0,2),
+ @I64OFF(2,3,0,3,0,0,0),
+ @I64OFF(2,3,0,3,0,0,1),
};

extern const char *names274[];
static const uint32 types274 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags274 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype274_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes274 [] = {
g_atype274_0,
g_atype274_1,
g_atype274_2,
};

static const long offsets274 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names275[];
static const uint32 types275 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags275 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype275_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes275 [] = {
g_atype275_0,
g_atype275_1,
g_atype275_2,
};

static const long offsets275 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names276[];
static const uint32 types276 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags276 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype276_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes276 [] = {
g_atype276_0,
g_atype276_1,
g_atype276_2,
};

static const long offsets276 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names279[];
static const uint32 types279 [] =
{
SK_REF,
};

static const uint16 attr_flags279 [] =
{0,};

static const EIF_TYPE_INDEX g_atype279_0 [] = {0xFF01,277,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes279 [] = {
g_atype279_0,
};

static const long offsets279 [] =
{
0,
};

extern const char *names281[];
static const uint32 types281 [] =
{
SK_BOOL,
};

static const uint16 attr_flags281 [] =
{0,};

static const EIF_TYPE_INDEX g_atype281_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes281 [] = {
g_atype281_0,
};

static const long offsets281 [] =
{
+ @CHROFF(0,0),
};

extern const char *names286[];
static const uint32 types286 [] =
{
SK_REF,
};

static const uint16 attr_flags286 [] =
{0,};

static const EIF_TYPE_INDEX g_atype286_0 [] = {0xFF01,1085,0xFFFF};

static const EIF_TYPE_INDEX *gtypes286 [] = {
g_atype286_0,
};

static const long offsets286 [] =
{
0,
};

extern const char *names287[];
static const uint32 types287 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags287 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype287_0 [] = {0xFF01,122,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_9 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes287 [] = {
g_atype287_0,
g_atype287_1,
g_atype287_2,
g_atype287_3,
g_atype287_4,
g_atype287_5,
g_atype287_6,
g_atype287_7,
g_atype287_8,
g_atype287_9,
};

static const long offsets287 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names288[];
static const uint32 types288 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags288 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype288_0 [] = {0xFF01,122,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_9 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes288 [] = {
g_atype288_0,
g_atype288_1,
g_atype288_2,
g_atype288_3,
g_atype288_4,
g_atype288_5,
g_atype288_6,
g_atype288_7,
g_atype288_8,
g_atype288_9,
};

static const long offsets288 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names289[];
static const uint32 types289 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags289 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype289_0 [] = {0xFF01,462,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_9 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes289 [] = {
g_atype289_0,
g_atype289_1,
g_atype289_2,
g_atype289_3,
g_atype289_4,
g_atype289_5,
g_atype289_6,
g_atype289_7,
g_atype289_8,
g_atype289_9,
};

static const long offsets289 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names290[];
static const uint32 types290 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags290 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype290_0 [] = {0xFF01,122,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_1 [] = {0xFF01,994,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_11 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes290 [] = {
g_atype290_0,
g_atype290_1,
g_atype290_2,
g_atype290_3,
g_atype290_4,
g_atype290_5,
g_atype290_6,
g_atype290_7,
g_atype290_8,
g_atype290_9,
g_atype290_10,
g_atype290_11,
};

static const long offsets290 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
};

extern const char *names291[];
static const uint32 types291 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags291 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype291_0 [] = {0xFF01,462,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_1 [] = {0xFF01,994,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_14 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes291 [] = {
g_atype291_0,
g_atype291_1,
g_atype291_2,
g_atype291_3,
g_atype291_4,
g_atype291_5,
g_atype291_6,
g_atype291_7,
g_atype291_8,
g_atype291_9,
g_atype291_10,
g_atype291_11,
g_atype291_12,
g_atype291_13,
g_atype291_14,
};

static const long offsets291 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @LNGOFF(2,5,0,0),
+ @LNGOFF(2,5,0,1),
+ @LNGOFF(2,5,0,2),
+ @LNGOFF(2,5,0,3),
+ @LNGOFF(2,5,0,4),
+ @LNGOFF(2,5,0,5),
+ @LNGOFF(2,5,0,6),
+ @LNGOFF(2,5,0,7),
};

extern const char *names292[];
static const uint32 types292 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags292 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype292_0 [] = {0xFF01,122,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_1 [] = {0xFF01,994,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_13 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes292 [] = {
g_atype292_0,
g_atype292_1,
g_atype292_2,
g_atype292_3,
g_atype292_4,
g_atype292_5,
g_atype292_6,
g_atype292_7,
g_atype292_8,
g_atype292_9,
g_atype292_10,
g_atype292_11,
g_atype292_12,
g_atype292_13,
};

static const long offsets292 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
+ @LNGOFF(2,4,0,6),
+ @LNGOFF(2,4,0,7),
};

extern const char *names296[];
static const uint32 types296 [] =
{
SK_REF,
SK_BOOL,
SK_POINTER,
};

static const uint16 attr_flags296 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype296_0 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_2 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes296 [] = {
g_atype296_0,
g_atype296_1,
g_atype296_2,
};

static const long offsets296 [] =
{
0,
+ @CHROFF(1,0),
+ @PTROFF(1,1,0,0,0,0),
};

extern const char *names298[];
static const uint32 types298 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags298 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype298_0 [] = {0xFF01,948,0xFF01,298,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_1 [] = {0xFF01,948,0xFF01,303,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_2 [] = {0xFF01,300,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_3 [] = {0xFF01,302,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_4 [] = {0xFF01,300,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_5 [] = {45,0xFFFF};

static const EIF_TYPE_INDEX *gtypes298 [] = {
g_atype298_0,
g_atype298_1,
g_atype298_2,
g_atype298_3,
g_atype298_4,
g_atype298_5,
};

static const long offsets298 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names299[];
static const uint32 types299 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags299 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype299_0 [] = {302,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_1 [] = {0xFF01,300,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_2 [] = {301,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_3 [] = {45,0xFFFF};

static const EIF_TYPE_INDEX *gtypes299 [] = {
g_atype299_0,
g_atype299_1,
g_atype299_2,
g_atype299_3,
};

static const long offsets299 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names300[];
static const uint32 types300 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags300 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype300_0 [] = {0xFF01,45,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_1 [] = {0xFF01,1082,0xFFFF};

static const EIF_TYPE_INDEX *gtypes300 [] = {
g_atype300_0,
g_atype300_1,
};

static const long offsets300 [] =
{
0,
 + @REFACS(1),
};

extern const char *names301[];
static const uint32 types301 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags301 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype301_0 [] = {0xFF01,45,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_1 [] = {0xFF01,1082,0xFFFF};

static const EIF_TYPE_INDEX *gtypes301 [] = {
g_atype301_0,
g_atype301_1,
};

static const long offsets301 [] =
{
0,
 + @REFACS(1),
};

extern const char *names302[];
static const uint32 types302 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags302 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype302_0 [] = {0xFF01,45,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_1 [] = {0xFF01,1082,0xFFFF};

static const EIF_TYPE_INDEX *gtypes302 [] = {
g_atype302_0,
g_atype302_1,
};

static const long offsets302 [] =
{
0,
 + @REFACS(1),
};

extern const char *names303[];
static const uint32 types303 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags303 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype303_0 [] = {0xFF01,45,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_1 [] = {0xFF01,1082,0xFFFF};

static const EIF_TYPE_INDEX *gtypes303 [] = {
g_atype303_0,
g_atype303_1,
};

static const long offsets303 [] =
{
0,
 + @REFACS(1),
};

extern const char *names304[];
static const uint32 types304 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags304 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype304_0 [] = {0xFF01,45,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_1 [] = {0xFF01,1082,0xFFFF};

static const EIF_TYPE_INDEX *gtypes304 [] = {
g_atype304_0,
g_atype304_1,
};

static const long offsets304 [] =
{
0,
 + @REFACS(1),
};

extern const char *names305[];
static const uint32 types305 [] =
{
SK_REF,
};

static const uint16 attr_flags305 [] =
{0,};

static const EIF_TYPE_INDEX g_atype305_0 [] = {309,0xFFFF};

static const EIF_TYPE_INDEX *gtypes305 [] = {
g_atype305_0,
};

static const long offsets305 [] =
{
0,
};

extern const char *names306[];
static const uint32 types306 [] =
{
SK_REF,
};

static const uint16 attr_flags306 [] =
{0,};

static const EIF_TYPE_INDEX g_atype306_0 [] = {309,0xFFFF};

static const EIF_TYPE_INDEX *gtypes306 [] = {
g_atype306_0,
};

static const long offsets306 [] =
{
0,
};

extern const char *names309[];
static const uint32 types309 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags309 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype309_0 [] = {309,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_1 [] = {0xFF01,304,0xFFFF};

static const EIF_TYPE_INDEX *gtypes309 [] = {
g_atype309_0,
g_atype309_1,
};

static const long offsets309 [] =
{
0,
 + @REFACS(1),
};

extern const char *names311[];
static const uint32 types311 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
};

static const uint16 attr_flags311 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype311_0 [] = {0xFF01,304,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_1 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_2 [] = {0xFF01,315,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_3 [] = {1098,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_4 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_8 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_9 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes311 [] = {
g_atype311_0,
g_atype311_1,
g_atype311_2,
g_atype311_3,
g_atype311_4,
g_atype311_5,
g_atype311_6,
g_atype311_7,
g_atype311_8,
g_atype311_9,
};

static const long offsets311 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
};

extern const char *names312[];
static const uint32 types312 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags312 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype312_0 [] = {0xFF01,304,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_1 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_2 [] = {0xFF01,315,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_3 [] = {1098,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_4 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_10 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_11 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_14 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes312 [] = {
g_atype312_0,
g_atype312_1,
g_atype312_2,
g_atype312_3,
g_atype312_4,
g_atype312_5,
g_atype312_6,
g_atype312_7,
g_atype312_8,
g_atype312_9,
g_atype312_10,
g_atype312_11,
g_atype312_12,
g_atype312_13,
g_atype312_14,
};

static const long offsets312 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
+ @LNGOFF(5,5,0,1),
+ @LNGOFF(5,5,0,2),
+ @LNGOFF(5,5,0,3),
+ @LNGOFF(5,5,0,4),
};

extern const char *names313[];
static const uint32 types313 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags313 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype313_0 [] = {309,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_1 [] = {0xFF01,304,0xFFFF};

static const EIF_TYPE_INDEX *gtypes313 [] = {
g_atype313_0,
g_atype313_1,
};

static const long offsets313 [] =
{
0,
 + @REFACS(1),
};

extern const char *names314[];
static const uint32 types314 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags314 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype314_0 [] = {309,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_1 [] = {0xFF01,304,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_2 [] = {0xFF01,53,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_3 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_4 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_5 [] = {0xFF01,800,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_6 [] = {0xFF01,800,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_7 [] = {0xFF01,800,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_8 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes314 [] = {
g_atype314_0,
g_atype314_1,
g_atype314_2,
g_atype314_3,
g_atype314_4,
g_atype314_5,
g_atype314_6,
g_atype314_7,
g_atype314_8,
};

static const long offsets314 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
};

extern const char *names315[];
static const uint32 types315 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags315 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype315_0 [] = {309,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_1 [] = {0xFF01,304,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_2 [] = {0xFF01,962,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_3 [] = {0xFF01,962,0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes315 [] = {
g_atype315_0,
g_atype315_1,
g_atype315_2,
g_atype315_3,
};

static const long offsets315 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names317[];
static const uint32 types317 [] =
{
SK_REF,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags317 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype317_0 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_2 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes317 [] = {
g_atype317_0,
g_atype317_1,
g_atype317_2,
g_atype317_3,
g_atype317_4,
g_atype317_5,
g_atype317_6,
};

static const long offsets317 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names318[];
static const uint32 types318 [] =
{
SK_REF,
};

static const uint16 attr_flags318 [] =
{0,};

static const EIF_TYPE_INDEX g_atype318_0 [] = {0xFF01,319,0xFFFF};

static const EIF_TYPE_INDEX *gtypes318 [] = {
g_atype318_0,
};

static const long offsets318 [] =
{
0,
};

extern const char *names319[];
static const uint32 types319 [] =
{
SK_REF,
SK_UINT32,
};

static const uint16 attr_flags319 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype319_0 [] = {0xFF01,319,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_1 [] = {1231,0xFFFF};

static const EIF_TYPE_INDEX *gtypes319 [] = {
g_atype319_0,
g_atype319_1,
};

static const long offsets319 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names322[];
static const uint32 types322 [] =
{
SK_INT32,
};

static const uint16 attr_flags322 [] =
{0,};

static const EIF_TYPE_INDEX g_atype322_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes322 [] = {
g_atype322_0,
};

static const long offsets322 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names323[];
static const uint32 types323 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags323 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype323_0 [] = {194,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes323 [] = {
g_atype323_0,
g_atype323_1,
g_atype323_2,
};

static const long offsets323 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names324[];
static const uint32 types324 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags324 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype324_0 [] = {195,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes324 [] = {
g_atype324_0,
g_atype324_1,
g_atype324_2,
};

static const long offsets324 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names325[];
static const uint32 types325 [] =
{
SK_INT32,
};

static const uint16 attr_flags325 [] =
{0,};

static const EIF_TYPE_INDEX g_atype325_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes325 [] = {
g_atype325_0,
};

static const long offsets325 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names327[];
static const uint32 types327 [] =
{
SK_REF,
};

static const uint16 attr_flags327 [] =
{0,};

static const EIF_TYPE_INDEX g_atype327_0 [] = {964,0xFFFF};

static const EIF_TYPE_INDEX *gtypes327 [] = {
g_atype327_0,
};

static const long offsets327 [] =
{
0,
};

extern const char *names330[];
static const uint32 types330 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags330 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype330_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes330 [] = {
g_atype330_0,
g_atype330_1,
g_atype330_2,
g_atype330_3,
g_atype330_4,
g_atype330_5,
g_atype330_6,
};

static const long offsets330 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names331[];
static const uint32 types331 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags331 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype331_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes331 [] = {
g_atype331_0,
g_atype331_1,
g_atype331_2,
g_atype331_3,
g_atype331_4,
g_atype331_5,
g_atype331_6,
};

static const long offsets331 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names332[];
static const uint32 types332 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags332 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype332_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes332 [] = {
g_atype332_0,
g_atype332_1,
g_atype332_2,
g_atype332_3,
g_atype332_4,
g_atype332_5,
g_atype332_6,
};

static const long offsets332 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names333[];
static const uint32 types333 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags333 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype333_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes333 [] = {
g_atype333_0,
g_atype333_1,
g_atype333_2,
g_atype333_3,
g_atype333_4,
g_atype333_5,
g_atype333_6,
};

static const long offsets333 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names334[];
static const uint32 types334 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags334 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype334_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes334 [] = {
g_atype334_0,
g_atype334_1,
g_atype334_2,
g_atype334_3,
g_atype334_4,
g_atype334_5,
g_atype334_6,
};

static const long offsets334 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names335[];
static const uint32 types335 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags335 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype335_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_7 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes335 [] = {
g_atype335_0,
g_atype335_1,
g_atype335_2,
g_atype335_3,
g_atype335_4,
g_atype335_5,
g_atype335_6,
g_atype335_7,
};

static const long offsets335 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names336[];
static const uint32 types336 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags336 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype336_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_5 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_9 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes336 [] = {
g_atype336_0,
g_atype336_1,
g_atype336_2,
g_atype336_3,
g_atype336_4,
g_atype336_5,
g_atype336_6,
g_atype336_7,
g_atype336_8,
g_atype336_9,
};

static const long offsets336 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
+ @LNGOFF(6,1,0,2),
};

extern const char *names337[];
static const uint32 types337 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags337 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype337_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_7 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes337 [] = {
g_atype337_0,
g_atype337_1,
g_atype337_2,
g_atype337_3,
g_atype337_4,
g_atype337_5,
g_atype337_6,
g_atype337_7,
};

static const long offsets337 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names338[];
static const uint32 types338 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags338 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype338_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes338 [] = {
g_atype338_0,
g_atype338_1,
g_atype338_2,
g_atype338_3,
g_atype338_4,
g_atype338_5,
g_atype338_6,
};

static const long offsets338 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names339[];
static const uint32 types339 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags339 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype339_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes339 [] = {
g_atype339_0,
g_atype339_1,
g_atype339_2,
g_atype339_3,
g_atype339_4,
g_atype339_5,
g_atype339_6,
};

static const long offsets339 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names340[];
static const uint32 types340 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags340 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype340_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes340 [] = {
g_atype340_0,
g_atype340_1,
g_atype340_2,
g_atype340_3,
g_atype340_4,
g_atype340_5,
g_atype340_6,
};

static const long offsets340 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names341[];
static const uint32 types341 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags341 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype341_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes341 [] = {
g_atype341_0,
g_atype341_1,
g_atype341_2,
g_atype341_3,
g_atype341_4,
g_atype341_5,
g_atype341_6,
};

static const long offsets341 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names342[];
static const uint32 types342 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags342 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype342_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes342 [] = {
g_atype342_0,
g_atype342_1,
g_atype342_2,
g_atype342_3,
g_atype342_4,
g_atype342_5,
g_atype342_6,
};

static const long offsets342 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names343[];
static const uint32 types343 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags343 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype343_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes343 [] = {
g_atype343_0,
g_atype343_1,
g_atype343_2,
g_atype343_3,
g_atype343_4,
g_atype343_5,
g_atype343_6,
};

static const long offsets343 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names344[];
static const uint32 types344 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags344 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype344_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes344 [] = {
g_atype344_0,
g_atype344_1,
g_atype344_2,
g_atype344_3,
g_atype344_4,
g_atype344_5,
g_atype344_6,
};

static const long offsets344 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names345[];
static const uint32 types345 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags345 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype345_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes345 [] = {
g_atype345_0,
g_atype345_1,
g_atype345_2,
g_atype345_3,
g_atype345_4,
g_atype345_5,
g_atype345_6,
};

static const long offsets345 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names346[];
static const uint32 types346 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags346 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype346_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes346 [] = {
g_atype346_0,
g_atype346_1,
g_atype346_2,
g_atype346_3,
g_atype346_4,
g_atype346_5,
g_atype346_6,
};

static const long offsets346 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names347[];
static const uint32 types347 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags347 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype347_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_7 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes347 [] = {
g_atype347_0,
g_atype347_1,
g_atype347_2,
g_atype347_3,
g_atype347_4,
g_atype347_5,
g_atype347_6,
g_atype347_7,
};

static const long offsets347 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names348[];
static const uint32 types348 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags348 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype348_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes348 [] = {
g_atype348_0,
g_atype348_1,
g_atype348_2,
g_atype348_3,
g_atype348_4,
g_atype348_5,
g_atype348_6,
};

static const long offsets348 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names349[];
static const uint32 types349 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags349 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype349_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes349 [] = {
g_atype349_0,
g_atype349_1,
g_atype349_2,
g_atype349_3,
g_atype349_4,
g_atype349_5,
g_atype349_6,
};

static const long offsets349 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names350[];
static const uint32 types350 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags350 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype350_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_7 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes350 [] = {
g_atype350_0,
g_atype350_1,
g_atype350_2,
g_atype350_3,
g_atype350_4,
g_atype350_5,
g_atype350_6,
g_atype350_7,
};

static const long offsets350 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names351[];
static const uint32 types351 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags351 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype351_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes351 [] = {
g_atype351_0,
g_atype351_1,
g_atype351_2,
g_atype351_3,
g_atype351_4,
g_atype351_5,
g_atype351_6,
};

static const long offsets351 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names352[];
static const uint32 types352 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags352 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype352_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes352 [] = {
g_atype352_0,
g_atype352_1,
g_atype352_2,
g_atype352_3,
g_atype352_4,
g_atype352_5,
g_atype352_6,
};

static const long offsets352 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names353[];
static const uint32 types353 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags353 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype353_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes353 [] = {
g_atype353_0,
g_atype353_1,
g_atype353_2,
g_atype353_3,
g_atype353_4,
g_atype353_5,
g_atype353_6,
};

static const long offsets353 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names354[];
static const uint32 types354 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags354 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype354_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes354 [] = {
g_atype354_0,
g_atype354_1,
g_atype354_2,
g_atype354_3,
g_atype354_4,
g_atype354_5,
g_atype354_6,
};

static const long offsets354 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names355[];
static const uint32 types355 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags355 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype355_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_8 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes355 [] = {
g_atype355_0,
g_atype355_1,
g_atype355_2,
g_atype355_3,
g_atype355_4,
g_atype355_5,
g_atype355_6,
g_atype355_7,
g_atype355_8,
};

static const long offsets355 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
};

extern const char *names356[];
static const uint32 types356 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags356 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype356_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes356 [] = {
g_atype356_0,
g_atype356_1,
g_atype356_2,
g_atype356_3,
g_atype356_4,
g_atype356_5,
g_atype356_6,
};

static const long offsets356 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names357[];
static const uint32 types357 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags357 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype357_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes357 [] = {
g_atype357_0,
g_atype357_1,
g_atype357_2,
g_atype357_3,
g_atype357_4,
g_atype357_5,
g_atype357_6,
};

static const long offsets357 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names358[];
static const uint32 types358 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags358 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype358_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_5 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_6 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_8 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes358 [] = {
g_atype358_0,
g_atype358_1,
g_atype358_2,
g_atype358_3,
g_atype358_4,
g_atype358_5,
g_atype358_6,
g_atype358_7,
g_atype358_8,
};

static const long offsets358 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names359[];
static const uint32 types359 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags359 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype359_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes359 [] = {
g_atype359_0,
g_atype359_1,
g_atype359_2,
g_atype359_3,
g_atype359_4,
g_atype359_5,
g_atype359_6,
};

static const long offsets359 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names360[];
static const uint32 types360 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags360 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype360_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes360 [] = {
g_atype360_0,
g_atype360_1,
g_atype360_2,
g_atype360_3,
g_atype360_4,
g_atype360_5,
g_atype360_6,
};

static const long offsets360 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names361[];
static const uint32 types361 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags361 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype361_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes361 [] = {
g_atype361_0,
g_atype361_1,
g_atype361_2,
g_atype361_3,
g_atype361_4,
g_atype361_5,
g_atype361_6,
};

static const long offsets361 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names362[];
static const uint32 types362 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags362 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype362_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes362 [] = {
g_atype362_0,
g_atype362_1,
g_atype362_2,
g_atype362_3,
g_atype362_4,
g_atype362_5,
g_atype362_6,
};

static const long offsets362 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names363[];
static const uint32 types363 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags363 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype363_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes363 [] = {
g_atype363_0,
g_atype363_1,
g_atype363_2,
g_atype363_3,
g_atype363_4,
g_atype363_5,
g_atype363_6,
};

static const long offsets363 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names364[];
static const uint32 types364 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags364 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype364_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes364 [] = {
g_atype364_0,
g_atype364_1,
g_atype364_2,
g_atype364_3,
g_atype364_4,
g_atype364_5,
g_atype364_6,
};

static const long offsets364 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names365[];
static const uint32 types365 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags365 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype365_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes365 [] = {
g_atype365_0,
g_atype365_1,
g_atype365_2,
g_atype365_3,
g_atype365_4,
g_atype365_5,
g_atype365_6,
};

static const long offsets365 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names366[];
static const uint32 types366 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags366 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype366_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes366 [] = {
g_atype366_0,
g_atype366_1,
g_atype366_2,
g_atype366_3,
g_atype366_4,
g_atype366_5,
g_atype366_6,
};

static const long offsets366 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names367[];
static const uint32 types367 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags367 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype367_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes367 [] = {
g_atype367_0,
g_atype367_1,
g_atype367_2,
g_atype367_3,
g_atype367_4,
g_atype367_5,
g_atype367_6,
};

static const long offsets367 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names368[];
static const uint32 types368 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags368 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype368_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_7 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes368 [] = {
g_atype368_0,
g_atype368_1,
g_atype368_2,
g_atype368_3,
g_atype368_4,
g_atype368_5,
g_atype368_6,
g_atype368_7,
};

static const long offsets368 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names369[];
static const uint32 types369 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags369 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype369_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes369 [] = {
g_atype369_0,
g_atype369_1,
g_atype369_2,
g_atype369_3,
g_atype369_4,
g_atype369_5,
g_atype369_6,
};

static const long offsets369 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names370[];
static const uint32 types370 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags370 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype370_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_2 [] = {329,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_3 [] = {464,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_4 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes370 [] = {
g_atype370_0,
g_atype370_1,
g_atype370_2,
g_atype370_3,
g_atype370_4,
g_atype370_5,
g_atype370_6,
};

static const long offsets370 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names372[];
static const uint32 types372 [] =
{
SK_REF,
};

static const uint16 attr_flags372 [] =
{0,};

static const EIF_TYPE_INDEX g_atype372_0 [] = {0xFF01,1086,0xFFFF};

static const EIF_TYPE_INDEX *gtypes372 [] = {
g_atype372_0,
};

static const long offsets372 [] =
{
0,
};

extern const char *names373[];
static const uint32 types373 [] =
{
SK_REF,
};

static const uint16 attr_flags373 [] =
{0,};

static const EIF_TYPE_INDEX g_atype373_0 [] = {0xFF01,1073,0xFF01,0xFFF9,1,1025,0xFF01,1340,0xFF01,1086,0xFFFF};

static const EIF_TYPE_INDEX *gtypes373 [] = {
g_atype373_0,
};

static const long offsets373 [] =
{
0,
};

extern const char *names374[];
static const uint32 types374 [] =
{
SK_REF,
};

static const uint16 attr_flags374 [] =
{0,};

static const EIF_TYPE_INDEX g_atype374_0 [] = {0xFF01,1073,0xFF01,0xFFF9,1,1025,0xFF01,1338,0xFF01,1086,0xFFFF};

static const EIF_TYPE_INDEX *gtypes374 [] = {
g_atype374_0,
};

static const long offsets374 [] =
{
0,
};

extern const char *names375[];
static const uint32 types375 [] =
{
SK_REF,
};

static const uint16 attr_flags375 [] =
{0,};

static const EIF_TYPE_INDEX g_atype375_0 [] = {0xFF01,943,0xFF01,370,0xFFFF};

static const EIF_TYPE_INDEX *gtypes375 [] = {
g_atype375_0,
};

static const long offsets375 [] =
{
0,
};

extern const char *names380[];
static const uint32 types380 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags380 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype380_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_1 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes380 [] = {
g_atype380_0,
g_atype380_1,
};

static const long offsets380 [] =
{
0,
 + @REFACS(1),
};

extern const char *names382[];
static const uint32 types382 [] =
{
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags382 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype382_0 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_2 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes382 [] = {
g_atype382_0,
g_atype382_1,
g_atype382_2,
};

static const long offsets382 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @R64OFF(0,0,0,2,0,0,0,0),
};

extern const char *names383[];
static const uint32 types383 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags383 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype383_0 [] = {1343,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_1 [] = {0xFF01,381,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_2 [] = {0xFF01,383,0xFFFF};

static const EIF_TYPE_INDEX *gtypes383 [] = {
g_atype383_0,
g_atype383_1,
g_atype383_2,
};

static const long offsets383 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names384[];
static const uint32 types384 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags384 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype384_0 [] = {1340,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes384 [] = {
g_atype384_0,
g_atype384_1,
g_atype384_2,
g_atype384_3,
};

static const long offsets384 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names386[];
static const uint32 types386 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags386 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype386_0 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_1 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_2 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_3 [] = {0xFF01,878,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_4 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_5 [] = {1086,0xFFFF};

static const EIF_TYPE_INDEX *gtypes386 [] = {
g_atype386_0,
g_atype386_1,
g_atype386_2,
g_atype386_3,
g_atype386_4,
g_atype386_5,
};

static const long offsets386 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names391[];
static const uint32 types391 [] =
{
SK_INT32,
};

static const uint16 attr_flags391 [] =
{0,};

static const EIF_TYPE_INDEX g_atype391_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes391 [] = {
g_atype391_0,
};

static const long offsets391 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names395[];
static const uint32 types395 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags395 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype395_0 [] = {0xFF01,390,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes395 [] = {
g_atype395_0,
g_atype395_1,
g_atype395_2,
g_atype395_3,
};

static const long offsets395 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names396[];
static const uint32 types396 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags396 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype396_0 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes396 [] = {
g_atype396_0,
g_atype396_1,
g_atype396_2,
};

static const long offsets396 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names399[];
static const uint32 types399 [] =
{
SK_REF,
};

static const uint16 attr_flags399 [] =
{0,};

static const EIF_TYPE_INDEX g_atype399_0 [] = {1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes399 [] = {
g_atype399_0,
};

static const long offsets399 [] =
{
0,
};

extern const char *names400[];
static const uint32 types400 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags400 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype400_0 [] = {309,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_2 [] = {1015,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_3 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_6 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes400 [] = {
g_atype400_0,
g_atype400_1,
g_atype400_2,
g_atype400_3,
g_atype400_4,
g_atype400_5,
g_atype400_6,
};

static const long offsets400 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
};

extern const char *names401[];
static const uint32 types401 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags401 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype401_0 [] = {309,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_2 [] = {1015,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_3 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_4 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_5 [] = {1099,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_6 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_11 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes401 [] = {
g_atype401_0,
g_atype401_1,
g_atype401_2,
g_atype401_3,
g_atype401_4,
g_atype401_5,
g_atype401_6,
g_atype401_7,
g_atype401_8,
g_atype401_9,
g_atype401_10,
g_atype401_11,
};

static const long offsets401 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
};

extern const char *names403[];
static const uint32 types403 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags403 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype403_0 [] = {0xFF01,860,0xFF01,1265,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_1 [] = {0xFF01,860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_7 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes403 [] = {
g_atype403_0,
g_atype403_1,
g_atype403_2,
g_atype403_3,
g_atype403_4,
g_atype403_5,
g_atype403_6,
g_atype403_7,
};

static const long offsets403 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
+ @LNGOFF(2,2,0,3),
};

extern const char *names404[];
static const uint32 types404 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags404 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype404_0 [] = {970,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_1 [] = {970,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_2 [] = {0xFF01,860,0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes404 [] = {
g_atype404_0,
g_atype404_1,
g_atype404_2,
};

static const long offsets404 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names405[];
static const uint32 types405 [] =
{
SK_REF,
};

static const uint16 attr_flags405 [] =
{0,};

static const EIF_TYPE_INDEX g_atype405_0 [] = {961,0xFFFF};

static const EIF_TYPE_INDEX *gtypes405 [] = {
g_atype405_0,
};

static const long offsets405 [] =
{
0,
};

extern const char *names406[];
static const uint32 types406 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags406 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype406_0 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_1 [] = {1261,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_2 [] = {1261,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_3 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_4 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_5 [] = {1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_6 [] = {1333,0xFFFF};

static const EIF_TYPE_INDEX *gtypes406 [] = {
g_atype406_0,
g_atype406_1,
g_atype406_2,
g_atype406_3,
g_atype406_4,
g_atype406_5,
g_atype406_6,
};

static const long offsets406 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
};

extern const char *names407[];
static const uint32 types407 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags407 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype407_0 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_1 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_2 [] = {1320,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_3 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_4 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes407 [] = {
g_atype407_0,
g_atype407_1,
g_atype407_2,
g_atype407_3,
g_atype407_4,
};

static const long offsets407 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
};

extern const char *names408[];
static const uint32 types408 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags408 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype408_0 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_2 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_3 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes408 [] = {
g_atype408_0,
g_atype408_1,
g_atype408_2,
g_atype408_3,
};

static const long offsets408 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names409[];
static const uint32 types409 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags409 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype409_0 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_2 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_3 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes409 [] = {
g_atype409_0,
g_atype409_1,
g_atype409_2,
g_atype409_3,
};

static const long offsets409 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names410[];
static const uint32 types410 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags410 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype410_0 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_2 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_3 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes410 [] = {
g_atype410_0,
g_atype410_1,
g_atype410_2,
g_atype410_3,
};

static const long offsets410 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names411[];
static const uint32 types411 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags411 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype411_0 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_2 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_3 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes411 [] = {
g_atype411_0,
g_atype411_1,
g_atype411_2,
g_atype411_3,
};

static const long offsets411 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names412[];
static const uint32 types412 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags412 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype412_0 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_2 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_3 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes412 [] = {
g_atype412_0,
g_atype412_1,
g_atype412_2,
g_atype412_3,
};

static const long offsets412 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names413[];
static const uint32 types413 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags413 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype413_0 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_2 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_3 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes413 [] = {
g_atype413_0,
g_atype413_1,
g_atype413_2,
g_atype413_3,
};

static const long offsets413 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names414[];
static const uint32 types414 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags414 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype414_0 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_2 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_3 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes414 [] = {
g_atype414_0,
g_atype414_1,
g_atype414_2,
g_atype414_3,
};

static const long offsets414 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names415[];
static const uint32 types415 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags415 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype415_0 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_2 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_3 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes415 [] = {
g_atype415_0,
g_atype415_1,
g_atype415_2,
g_atype415_3,
};

static const long offsets415 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names416[];
static const uint32 types416 [] =
{
SK_REF,
};

static const uint16 attr_flags416 [] =
{0,};

static const EIF_TYPE_INDEX g_atype416_0 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes416 [] = {
g_atype416_0,
};

static const long offsets416 [] =
{
0,
};

extern const char *names417[];
static const uint32 types417 [] =
{
SK_REF,
};

static const uint16 attr_flags417 [] =
{0,};

static const EIF_TYPE_INDEX g_atype417_0 [] = {0xFF01,1141,1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes417 [] = {
g_atype417_0,
};

static const long offsets417 [] =
{
0,
};

extern const char *names418[];
static const uint32 types418 [] =
{
SK_REF,
};

static const uint16 attr_flags418 [] =
{0,};

static const EIF_TYPE_INDEX g_atype418_0 [] = {0xFF01,1142,1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes418 [] = {
g_atype418_0,
};

static const long offsets418 [] =
{
0,
};

extern const char *names419[];
static const uint32 types419 [] =
{
SK_REF,
};

static const uint16 attr_flags419 [] =
{0,};

static const EIF_TYPE_INDEX g_atype419_0 [] = {0xFF01,1143,1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes419 [] = {
g_atype419_0,
};

static const long offsets419 [] =
{
0,
};

extern const char *names420[];
static const uint32 types420 [] =
{
SK_REF,
};

static const uint16 attr_flags420 [] =
{0,};

static const EIF_TYPE_INDEX g_atype420_0 [] = {0xFF01,1144,1034,0xFFFF};

static const EIF_TYPE_INDEX *gtypes420 [] = {
g_atype420_0,
};

static const long offsets420 [] =
{
0,
};

extern const char *names421[];
static const uint32 types421 [] =
{
SK_REF,
};

static const uint16 attr_flags421 [] =
{0,};

static const EIF_TYPE_INDEX g_atype421_0 [] = {0xFF01,1145,1231,0xFFFF};

static const EIF_TYPE_INDEX *gtypes421 [] = {
g_atype421_0,
};

static const long offsets421 [] =
{
0,
};

extern const char *names422[];
static const uint32 types422 [] =
{
SK_REF,
};

static const uint16 attr_flags422 [] =
{0,};

static const EIF_TYPE_INDEX g_atype422_0 [] = {0xFF01,1146,1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes422 [] = {
g_atype422_0,
};

static const long offsets422 [] =
{
0,
};

extern const char *names423[];
static const uint32 types423 [] =
{
SK_REF,
};

static const uint16 attr_flags423 [] =
{0,};

static const EIF_TYPE_INDEX g_atype423_0 [] = {0xFF01,1147,1234,0xFFFF};

static const EIF_TYPE_INDEX *gtypes423 [] = {
g_atype423_0,
};

static const long offsets423 [] =
{
0,
};

extern const char *names424[];
static const uint32 types424 [] =
{
SK_REF,
};

static const uint16 attr_flags424 [] =
{0,};

static const EIF_TYPE_INDEX g_atype424_0 [] = {0xFF01,1148,1237,0xFFFF};

static const EIF_TYPE_INDEX *gtypes424 [] = {
g_atype424_0,
};

static const long offsets424 [] =
{
0,
};

extern const char *names425[];
static const uint32 types425 [] =
{
SK_REF,
};

static const uint16 attr_flags425 [] =
{0,};

static const EIF_TYPE_INDEX g_atype425_0 [] = {0xFF01,1149,1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes425 [] = {
g_atype425_0,
};

static const long offsets425 [] =
{
0,
};

extern const char *names426[];
static const uint32 types426 [] =
{
SK_REF,
};

static const uint16 attr_flags426 [] =
{0,};

static const EIF_TYPE_INDEX g_atype426_0 [] = {0xFF01,1150,1240,0xFFFF};

static const EIF_TYPE_INDEX *gtypes426 [] = {
g_atype426_0,
};

static const long offsets426 [] =
{
0,
};

extern const char *names427[];
static const uint32 types427 [] =
{
SK_REF,
};

static const uint16 attr_flags427 [] =
{0,};

static const EIF_TYPE_INDEX g_atype427_0 [] = {0xFF01,1151,1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes427 [] = {
g_atype427_0,
};

static const long offsets427 [] =
{
0,
};

extern const char *names432[];
static const uint32 types432 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags432 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype432_0 [] = {0xFF01,444,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes432 [] = {
g_atype432_0,
g_atype432_1,
};

static const long offsets432 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names433[];
static const uint32 types433 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags433 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype433_0 [] = {0xFF01,1148,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_1 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_4 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes433 [] = {
g_atype433_0,
g_atype433_1,
g_atype433_2,
g_atype433_3,
g_atype433_4,
};

static const long offsets433 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names434[];
static const uint32 types434 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags434 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype434_0 [] = {0xFF01,1148,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_1 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_4 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes434 [] = {
g_atype434_0,
g_atype434_1,
g_atype434_2,
g_atype434_3,
g_atype434_4,
};

static const long offsets434 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names435[];
static const uint32 types435 [] =
{
SK_INT32,
};

static const uint16 attr_flags435 [] =
{0,};

static const EIF_TYPE_INDEX g_atype435_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes435 [] = {
g_atype435_0,
};

static const long offsets435 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names436[];
static const uint32 types436 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags436 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype436_0 [] = {0xFF01,443,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_1 [] = {0xFF01,460,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_2 [] = {0xFF01,443,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_7 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes436 [] = {
g_atype436_0,
g_atype436_1,
g_atype436_2,
g_atype436_3,
g_atype436_4,
g_atype436_5,
g_atype436_6,
g_atype436_7,
};

static const long offsets436 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @LNGOFF(3,2,0,0),
+ @LNGOFF(3,2,0,1),
+ @PTROFF(3,2,0,2,0,0),
};

extern const char *names437[];
static const uint32 types437 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags437 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype437_0 [] = {0xFF01,443,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_1 [] = {0xFF01,460,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_2 [] = {0xFF01,443,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_7 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes437 [] = {
g_atype437_0,
g_atype437_1,
g_atype437_2,
g_atype437_3,
g_atype437_4,
g_atype437_5,
g_atype437_6,
g_atype437_7,
};

static const long offsets437 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @LNGOFF(3,2,0,0),
+ @LNGOFF(3,2,0,1),
+ @PTROFF(3,2,0,2,0,0),
};

extern const char *names438[];
static const uint32 types438 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags438 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype438_0 [] = {0xFF01,443,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_1 [] = {0xFF01,460,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_2 [] = {0xFF01,443,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_7 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes438 [] = {
g_atype438_0,
g_atype438_1,
g_atype438_2,
g_atype438_3,
g_atype438_4,
g_atype438_5,
g_atype438_6,
g_atype438_7,
};

static const long offsets438 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @LNGOFF(3,2,0,0),
+ @LNGOFF(3,2,0,1),
+ @PTROFF(3,2,0,2,0,0),
};

extern const char *names439[];
static const uint32 types439 [] =
{
SK_INT32,
};

static const uint16 attr_flags439 [] =
{0,};

static const EIF_TYPE_INDEX g_atype439_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes439 [] = {
g_atype439_0,
};

static const long offsets439 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names440[];
static const uint32 types440 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags440 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype440_0 [] = {459,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_1 [] = {0xFF01,443,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_2 [] = {0xFF01,443,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_8 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes440 [] = {
g_atype440_0,
g_atype440_1,
g_atype440_2,
g_atype440_3,
g_atype440_4,
g_atype440_5,
g_atype440_6,
g_atype440_7,
g_atype440_8,
};

static const long offsets440 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @LNGOFF(3,3,0,0),
+ @LNGOFF(3,3,0,1),
+ @PTROFF(3,3,0,2,0,0),
};

extern const char *names441[];
static const uint32 types441 [] =
{
SK_INT32,
};

static const uint16 attr_flags441 [] =
{0,};

static const EIF_TYPE_INDEX g_atype441_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes441 [] = {
g_atype441_0,
};

static const long offsets441 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names442[];
static const uint32 types442 [] =
{
SK_INT32,
};

static const uint16 attr_flags442 [] =
{0,};

static const EIF_TYPE_INDEX g_atype442_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes442 [] = {
g_atype442_0,
};

static const long offsets442 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names444[];
static const uint32 types444 [] =
{
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags444 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype444_0 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype444_1 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes444 [] = {
g_atype444_0,
g_atype444_1,
};

static const long offsets444 [] =
{
+ @PTROFF(0,0,0,0,0,0),
+ @PTROFF(0,0,0,0,0,1),
};

extern const char *names445[];
static const uint32 types445 [] =
{
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_UINT64,
};

static const uint16 attr_flags445 [] =
{0,0,1,1,};

static const EIF_TYPE_INDEX g_atype445_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_2 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_3 [] = {1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes445 [] = {
g_atype445_0,
g_atype445_1,
g_atype445_2,
g_atype445_3,
};

static const long offsets445 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @PTROFF(0,1,0,1,0,0),
+ @I64OFF(0,1,0,1,0,1,0),
};

extern const char *names446[];
static const uint32 types446 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags446 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype446_0 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype446_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes446 [] = {
g_atype446_0,
g_atype446_1,
};

static const long offsets446 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names448[];
static const uint32 types448 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags448 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype448_0 [] = {1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_1 [] = {878,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_2 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_3 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_4 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_5 [] = {948,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_6 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_7 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_8 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_9 [] = {828,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_10 [] = {828,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_11 [] = {828,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_12 [] = {466,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_13 [] = {466,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_14 [] = {466,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_15 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_16 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_17 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_19 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_20 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_21 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_22 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_23 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_24 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_25 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_26 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_27 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_28 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes448 [] = {
g_atype448_0,
g_atype448_1,
g_atype448_2,
g_atype448_3,
g_atype448_4,
g_atype448_5,
g_atype448_6,
g_atype448_7,
g_atype448_8,
g_atype448_9,
g_atype448_10,
g_atype448_11,
g_atype448_12,
g_atype448_13,
g_atype448_14,
g_atype448_15,
g_atype448_16,
g_atype448_17,
g_atype448_18,
g_atype448_19,
g_atype448_20,
g_atype448_21,
g_atype448_22,
g_atype448_23,
g_atype448_24,
g_atype448_25,
g_atype448_26,
g_atype448_27,
g_atype448_28,
};

static const long offsets448 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
+ @CHROFF(15,0),
+ @CHROFF(15,1),
+ @CHROFF(15,2),
+ @CHROFF(15,3),
+ @CHROFF(15,4),
+ @CHROFF(15,5),
+ @CHROFF(15,6),
+ @CHROFF(15,7),
+ @CHROFF(15,8),
+ @CHROFF(15,9),
+ @CHROFF(15,10),
+ @LNGOFF(15,11,0,0),
+ @LNGOFF(15,11,0,1),
+ @LNGOFF(15,11,0,2),
};

extern const char *names449[];
static const uint32 types449 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags449 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype449_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_1 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_4 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_5 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes449 [] = {
g_atype449_0,
g_atype449_1,
g_atype449_2,
g_atype449_3,
g_atype449_4,
g_atype449_5,
};

static const long offsets449 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @PTROFF(3,0,0,1,0,0),
+ @PTROFF(3,0,0,1,0,1),
};

extern const char *names451[];
static const uint32 types451 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags451 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype451_0 [] = {0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype451_1 [] = {0xFF01,1101,0xFFFF};

static const EIF_TYPE_INDEX *gtypes451 [] = {
g_atype451_0,
g_atype451_1,
};

static const long offsets451 [] =
{
0,
 + @REFACS(1),
};

extern const char *names453[];
static const uint32 types453 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags453 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype453_0 [] = {0xFF01,450,0xFFFF};
static const EIF_TYPE_INDEX g_atype453_1 [] = {0xFF01,34,0xFFFF};

static const EIF_TYPE_INDEX *gtypes453 [] = {
g_atype453_0,
g_atype453_1,
};

static const long offsets453 [] =
{
0,
 + @REFACS(1),
};

extern const char *names454[];
static const uint32 types454 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags454 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype454_0 [] = {0xFF01,450,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_1 [] = {0xFF01,34,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_2 [] = {0xFF01,20,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_3 [] = {919,0xFF01,1090,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_4 [] = {919,0xFF01,1090,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes454 [] = {
g_atype454_0,
g_atype454_1,
g_atype454_2,
g_atype454_3,
g_atype454_4,
g_atype454_5,
};

static const long offsets454 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names455[];
static const uint32 types455 [] =
{
SK_REF,
};

static const uint16 attr_flags455 [] =
{0,};

static const EIF_TYPE_INDEX g_atype455_0 [] = {948,0xFF01,1085,0xFFFF};

static const EIF_TYPE_INDEX *gtypes455 [] = {
g_atype455_0,
};

static const long offsets455 [] =
{
0,
};

extern const char *names456[];
static const uint32 types456 [] =
{
SK_REF,
};

static const uint16 attr_flags456 [] =
{0,};

static const EIF_TYPE_INDEX g_atype456_0 [] = {948,0xFF01,1085,0xFFFF};

static const EIF_TYPE_INDEX *gtypes456 [] = {
g_atype456_0,
};

static const long offsets456 [] =
{
0,
};

extern const char *names457[];
static const uint32 types457 [] =
{
SK_REF,
};

static const uint16 attr_flags457 [] =
{0,};

static const EIF_TYPE_INDEX g_atype457_0 [] = {948,0xFF01,1085,0xFFFF};

static const EIF_TYPE_INDEX *gtypes457 [] = {
g_atype457_0,
};

static const long offsets457 [] =
{
0,
};

extern const char *names458[];
static const uint32 types458 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags458 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype458_0 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_1 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_2 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_3 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_4 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_5 [] = {851,0xFF01,1077,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_6 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_7 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_8 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_9 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_10 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_11 [] = {919,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_12 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_13 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_14 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_15 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_16 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_17 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_19 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_20 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_21 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_22 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_23 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_24 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_25 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_26 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_27 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_28 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_29 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_30 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_31 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes458 [] = {
g_atype458_0,
g_atype458_1,
g_atype458_2,
g_atype458_3,
g_atype458_4,
g_atype458_5,
g_atype458_6,
g_atype458_7,
g_atype458_8,
g_atype458_9,
g_atype458_10,
g_atype458_11,
g_atype458_12,
g_atype458_13,
g_atype458_14,
g_atype458_15,
g_atype458_16,
g_atype458_17,
g_atype458_18,
g_atype458_19,
g_atype458_20,
g_atype458_21,
g_atype458_22,
g_atype458_23,
g_atype458_24,
g_atype458_25,
g_atype458_26,
g_atype458_27,
g_atype458_28,
g_atype458_29,
g_atype458_30,
g_atype458_31,
};

static const long offsets458 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @LNGOFF(12,16,0,0),
+ @LNGOFF(12,16,0,1),
+ @LNGOFF(12,16,0,2),
+ @LNGOFF(12,16,0,3),
};

extern const char *names459[];
static const uint32 types459 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags459 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype459_0 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_1 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_2 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_3 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_4 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_5 [] = {851,0xFF01,1077,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_6 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_7 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_8 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_9 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_10 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_11 [] = {919,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_12 [] = {0xFF01,447,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_13 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_14 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_15 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_16 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_17 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_19 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_20 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_21 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_22 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_23 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_24 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_25 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_26 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_27 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_28 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_29 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_30 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_31 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_32 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_33 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes459 [] = {
g_atype459_0,
g_atype459_1,
g_atype459_2,
g_atype459_3,
g_atype459_4,
g_atype459_5,
g_atype459_6,
g_atype459_7,
g_atype459_8,
g_atype459_9,
g_atype459_10,
g_atype459_11,
g_atype459_12,
g_atype459_13,
g_atype459_14,
g_atype459_15,
g_atype459_16,
g_atype459_17,
g_atype459_18,
g_atype459_19,
g_atype459_20,
g_atype459_21,
g_atype459_22,
g_atype459_23,
g_atype459_24,
g_atype459_25,
g_atype459_26,
g_atype459_27,
g_atype459_28,
g_atype459_29,
g_atype459_30,
g_atype459_31,
g_atype459_32,
g_atype459_33,
};

static const long offsets459 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
+ @CHROFF(13,0),
+ @CHROFF(13,1),
+ @CHROFF(13,2),
+ @CHROFF(13,3),
+ @CHROFF(13,4),
+ @CHROFF(13,5),
+ @CHROFF(13,6),
+ @CHROFF(13,7),
+ @CHROFF(13,8),
+ @CHROFF(13,9),
+ @CHROFF(13,10),
+ @CHROFF(13,11),
+ @CHROFF(13,12),
+ @CHROFF(13,13),
+ @CHROFF(13,14),
+ @CHROFF(13,15),
+ @LNGOFF(13,16,0,0),
+ @LNGOFF(13,16,0,1),
+ @LNGOFF(13,16,0,2),
+ @LNGOFF(13,16,0,3),
+ @LNGOFF(13,16,0,4),
};

extern const char *names460[];
static const uint32 types460 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags460 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype460_0 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_1 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_2 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_3 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_4 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_5 [] = {851,0xFF01,1077,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_6 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_7 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_8 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_9 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_10 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_11 [] = {919,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_12 [] = {1072,0xFF01,0xFFF9,1,1025,0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_13 [] = {1072,0xFF01,0xFFF9,1,1025,0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_14 [] = {0xFF01,180,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_15 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_16 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_17 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_19 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_20 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_21 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_22 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_23 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_24 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_25 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_26 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_27 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_28 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_29 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_30 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_31 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_32 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_33 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_34 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_35 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes460 [] = {
g_atype460_0,
g_atype460_1,
g_atype460_2,
g_atype460_3,
g_atype460_4,
g_atype460_5,
g_atype460_6,
g_atype460_7,
g_atype460_8,
g_atype460_9,
g_atype460_10,
g_atype460_11,
g_atype460_12,
g_atype460_13,
g_atype460_14,
g_atype460_15,
g_atype460_16,
g_atype460_17,
g_atype460_18,
g_atype460_19,
g_atype460_20,
g_atype460_21,
g_atype460_22,
g_atype460_23,
g_atype460_24,
g_atype460_25,
g_atype460_26,
g_atype460_27,
g_atype460_28,
g_atype460_29,
g_atype460_30,
g_atype460_31,
g_atype460_32,
g_atype460_33,
g_atype460_34,
g_atype460_35,
};

static const long offsets460 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
+ @CHROFF(15,0),
+ @CHROFF(15,1),
+ @CHROFF(15,2),
+ @CHROFF(15,3),
+ @CHROFF(15,4),
+ @CHROFF(15,5),
+ @CHROFF(15,6),
+ @CHROFF(15,7),
+ @CHROFF(15,8),
+ @CHROFF(15,9),
+ @CHROFF(15,10),
+ @CHROFF(15,11),
+ @CHROFF(15,12),
+ @CHROFF(15,13),
+ @CHROFF(15,14),
+ @CHROFF(15,15),
+ @LNGOFF(15,16,0,0),
+ @LNGOFF(15,16,0,1),
+ @LNGOFF(15,16,0,2),
+ @LNGOFF(15,16,0,3),
+ @LNGOFF(15,16,0,4),
};

extern const char *names461[];
static const uint32 types461 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags461 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype461_0 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_1 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_2 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_3 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_4 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_5 [] = {851,0xFF01,1077,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_6 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_7 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_8 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_9 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_10 [] = {1071,0xFF01,0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_11 [] = {919,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_12 [] = {0xFF01,447,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_13 [] = {1072,0xFF01,0xFFF9,1,1025,0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_14 [] = {1072,0xFF01,0xFFF9,1,1025,0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_15 [] = {0xFF01,180,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_16 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_17 [] = {436,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_18 [] = {435,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_19 [] = {437,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_20 [] = {0xFF01,443,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_21 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_22 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_23 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_24 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_25 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_26 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_27 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_28 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_29 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_30 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_31 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_32 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_33 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_34 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_35 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_36 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_37 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_38 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_39 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_40 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_41 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_42 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_43 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_44 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_45 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_46 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_47 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes461 [] = {
g_atype461_0,
g_atype461_1,
g_atype461_2,
g_atype461_3,
g_atype461_4,
g_atype461_5,
g_atype461_6,
g_atype461_7,
g_atype461_8,
g_atype461_9,
g_atype461_10,
g_atype461_11,
g_atype461_12,
g_atype461_13,
g_atype461_14,
g_atype461_15,
g_atype461_16,
g_atype461_17,
g_atype461_18,
g_atype461_19,
g_atype461_20,
g_atype461_21,
g_atype461_22,
g_atype461_23,
g_atype461_24,
g_atype461_25,
g_atype461_26,
g_atype461_27,
g_atype461_28,
g_atype461_29,
g_atype461_30,
g_atype461_31,
g_atype461_32,
g_atype461_33,
g_atype461_34,
g_atype461_35,
g_atype461_36,
g_atype461_37,
g_atype461_38,
g_atype461_39,
g_atype461_40,
g_atype461_41,
g_atype461_42,
g_atype461_43,
g_atype461_44,
g_atype461_45,
g_atype461_46,
g_atype461_47,
};

static const long offsets461 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
+ @CHROFF(21,0),
+ @CHROFF(21,1),
+ @CHROFF(21,2),
+ @CHROFF(21,3),
+ @CHROFF(21,4),
+ @CHROFF(21,5),
+ @CHROFF(21,6),
+ @CHROFF(21,7),
+ @CHROFF(21,8),
+ @CHROFF(21,9),
+ @CHROFF(21,10),
+ @CHROFF(21,11),
+ @CHROFF(21,12),
+ @CHROFF(21,13),
+ @CHROFF(21,14),
+ @CHROFF(21,15),
+ @CHROFF(21,16),
+ @CHROFF(21,17),
+ @LNGOFF(21,18,0,0),
+ @LNGOFF(21,18,0,1),
+ @LNGOFF(21,18,0,2),
+ @LNGOFF(21,18,0,3),
+ @LNGOFF(21,18,0,4),
+ @LNGOFF(21,18,0,5),
+ @LNGOFF(21,18,0,6),
+ @LNGOFF(21,18,0,7),
+ @LNGOFF(21,18,0,8),
};

extern const char *names463[];
static const uint32 types463 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR32,
};

static const uint16 attr_flags463 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype463_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_2 [] = {0xFF01,1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_3 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_4 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes463 [] = {
g_atype463_0,
g_atype463_1,
g_atype463_2,
g_atype463_3,
g_atype463_4,
};

static const long offsets463 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names464[];
static const uint32 types464 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags464 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype464_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype464_1 [] = {0xFF01,1144,1034,0xFFFF};

static const EIF_TYPE_INDEX *gtypes464 [] = {
g_atype464_0,
g_atype464_1,
};

static const long offsets464 [] =
{
0,
 + @REFACS(1),
};

extern const char *names465[];
static const uint32 types465 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags465 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype465_0 [] = {0xFF01,444,0xFFFF};
static const EIF_TYPE_INDEX g_atype465_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes465 [] = {
g_atype465_0,
g_atype465_1,
};

static const long offsets465 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names466[];
static const uint32 types466 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags466 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype466_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_1 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_2 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_3 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_4 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_5 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_6 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_9 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_10 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_11 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_12 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes466 [] = {
g_atype466_0,
g_atype466_1,
g_atype466_2,
g_atype466_3,
g_atype466_4,
g_atype466_5,
g_atype466_6,
g_atype466_7,
g_atype466_8,
g_atype466_9,
g_atype466_10,
g_atype466_11,
g_atype466_12,
};

static const long offsets466 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I16OFF(1,3,0),
+ @I16OFF(1,3,1),
+ @LNGOFF(1,3,2,0),
+ @LNGOFF(1,3,2,1),
+ @LNGOFF(1,3,2,2),
+ @R32OFF(1,3,2,3,0),
+ @I64OFF(1,3,2,3,1,0,0),
+ @I64OFF(1,3,2,3,1,0,1),
+ @R64OFF(1,3,2,3,1,0,2,0),
};

extern const char *names467[];
static const uint32 types467 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags467 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype467_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_1 [] = {0xFF01,444,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_2 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_7 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_8 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_9 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_10 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_11 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_16 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_17 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_18 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_19 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes467 [] = {
g_atype467_0,
g_atype467_1,
g_atype467_2,
g_atype467_3,
g_atype467_4,
g_atype467_5,
g_atype467_6,
g_atype467_7,
g_atype467_8,
g_atype467_9,
g_atype467_10,
g_atype467_11,
g_atype467_12,
g_atype467_13,
g_atype467_14,
g_atype467_15,
g_atype467_16,
g_atype467_17,
g_atype467_18,
g_atype467_19,
};

static const long offsets467 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @CHROFF(2,6),
+ @I16OFF(2,7,0),
+ @I16OFF(2,7,1),
+ @LNGOFF(2,7,2,0),
+ @LNGOFF(2,7,2,1),
+ @LNGOFF(2,7,2,2),
+ @LNGOFF(2,7,2,3),
+ @LNGOFF(2,7,2,4),
+ @R32OFF(2,7,2,5,0),
+ @I64OFF(2,7,2,5,1,0,0),
+ @I64OFF(2,7,2,5,1,0,1),
+ @R64OFF(2,7,2,5,1,0,2,0),
};

extern const char *names480[];
static const uint32 types480 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags480 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype480_0 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_1 [] = {0xFFF5,1,0xFF01,1140,0xFFF8,1,5796,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_2 [] = {0xFFF5,1,0xFF01,800,0xFFF8,1,5581,0xFFFF};

static const EIF_TYPE_INDEX *gtypes480 [] = {
g_atype480_0,
g_atype480_1,
g_atype480_2,
};

static const long offsets480 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names481[];
static const uint32 types481 [] =
{
SK_UINT8,
SK_POINTER,
};

static const uint16 attr_flags481 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype481_0 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype481_1 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes481 [] = {
g_atype481_0,
g_atype481_1,
};

static const long offsets481 [] =
{
+ @CHROFF(0,0),
+ @PTROFF(0,1,0,0,0,0),
};

extern const char *names482[];
static const uint32 types482 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags482 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype482_0 [] = {0xFF01,1261,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype482_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes482 [] = {
g_atype482_0,
g_atype482_1,
};

static const long offsets482 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names483[];
static const uint32 types483 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags483 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype483_0 [] = {0xFF01,1262,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes483 [] = {
g_atype483_0,
g_atype483_1,
};

static const long offsets483 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names484[];
static const uint32 types484 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags484 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype484_0 [] = {0xFF01,1263,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype484_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes484 [] = {
g_atype484_0,
g_atype484_1,
};

static const long offsets484 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names495[];
static const uint32 types495 [] =
{
SK_INT32,
};

static const uint16 attr_flags495 [] =
{0,};

static const EIF_TYPE_INDEX g_atype495_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes495 [] = {
g_atype495_0,
};

static const long offsets495 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names508[];
static const uint32 types508 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags508 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype508_0 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype508_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype508_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype508_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes508 [] = {
g_atype508_0,
g_atype508_1,
g_atype508_2,
g_atype508_3,
};

static const long offsets508 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names535[];
static const uint32 types535 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags535 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype535_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype535_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype535_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype535_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype535_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype535_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype535_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes535 [] = {
g_atype535_0,
g_atype535_1,
g_atype535_2,
g_atype535_3,
g_atype535_4,
g_atype535_5,
g_atype535_6,
};

static const long offsets535 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names536[];
static const uint32 types536 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags536 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype536_0 [] = {0xFF01,840,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype536_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype536_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype536_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype536_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype536_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype536_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes536 [] = {
g_atype536_0,
g_atype536_1,
g_atype536_2,
g_atype536_3,
g_atype536_4,
g_atype536_5,
g_atype536_6,
};

static const long offsets536 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names537[];
static const uint32 types537 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags537 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype537_0 [] = {0xFF01,841,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype537_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype537_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype537_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype537_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype537_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype537_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes537 [] = {
g_atype537_0,
g_atype537_1,
g_atype537_2,
g_atype537_3,
g_atype537_4,
g_atype537_5,
g_atype537_6,
};

static const long offsets537 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names538[];
static const uint32 types538 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags538 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype538_0 [] = {0xFF01,842,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype538_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype538_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype538_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype538_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype538_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype538_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes538 [] = {
g_atype538_0,
g_atype538_1,
g_atype538_2,
g_atype538_3,
g_atype538_4,
g_atype538_5,
g_atype538_6,
};

static const long offsets538 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names539[];
static const uint32 types539 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags539 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype539_0 [] = {0xFF01,843,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype539_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype539_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype539_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype539_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype539_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype539_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes539 [] = {
g_atype539_0,
g_atype539_1,
g_atype539_2,
g_atype539_3,
g_atype539_4,
g_atype539_5,
g_atype539_6,
};

static const long offsets539 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names540[];
static const uint32 types540 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags540 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype540_0 [] = {0xFF01,844,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype540_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype540_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype540_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype540_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype540_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype540_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes540 [] = {
g_atype540_0,
g_atype540_1,
g_atype540_2,
g_atype540_3,
g_atype540_4,
g_atype540_5,
g_atype540_6,
};

static const long offsets540 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names541[];
static const uint32 types541 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags541 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype541_0 [] = {0xFF01,845,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype541_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype541_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype541_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype541_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype541_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype541_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes541 [] = {
g_atype541_0,
g_atype541_1,
g_atype541_2,
g_atype541_3,
g_atype541_4,
g_atype541_5,
g_atype541_6,
};

static const long offsets541 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names542[];
static const uint32 types542 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags542 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype542_0 [] = {0xFF01,846,1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype542_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype542_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype542_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype542_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype542_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype542_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes542 [] = {
g_atype542_0,
g_atype542_1,
g_atype542_2,
g_atype542_3,
g_atype542_4,
g_atype542_5,
g_atype542_6,
};

static const long offsets542 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names543[];
static const uint32 types543 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags543 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype543_0 [] = {0xFF01,847,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype543_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype543_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype543_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype543_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype543_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype543_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes543 [] = {
g_atype543_0,
g_atype543_1,
g_atype543_2,
g_atype543_3,
g_atype543_4,
g_atype543_5,
g_atype543_6,
};

static const long offsets543 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names544[];
static const uint32 types544 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags544 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype544_0 [] = {0xFF01,848,1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype544_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype544_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype544_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype544_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype544_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype544_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes544 [] = {
g_atype544_0,
g_atype544_1,
g_atype544_2,
g_atype544_3,
g_atype544_4,
g_atype544_5,
g_atype544_6,
};

static const long offsets544 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names545[];
static const uint32 types545 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags545 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype545_0 [] = {0xFF01,849,1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype545_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype545_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype545_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype545_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype545_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype545_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes545 [] = {
g_atype545_0,
g_atype545_1,
g_atype545_2,
g_atype545_3,
g_atype545_4,
g_atype545_5,
g_atype545_6,
};

static const long offsets545 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names546[];
static const uint32 types546 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags546 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype546_0 [] = {0xFF01,850,1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype546_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype546_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype546_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype546_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype546_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype546_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes546 [] = {
g_atype546_0,
g_atype546_1,
g_atype546_2,
g_atype546_3,
g_atype546_4,
g_atype546_5,
g_atype546_6,
};

static const long offsets546 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names547[];
static const uint32 types547 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags547 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype547_0 [] = {0xFF01,851,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype547_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype547_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype547_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype547_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype547_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype547_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes547 [] = {
g_atype547_0,
g_atype547_1,
g_atype547_2,
g_atype547_3,
g_atype547_4,
g_atype547_5,
g_atype547_6,
};

static const long offsets547 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names548[];
static const uint32 types548 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags548 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype548_0 [] = {0xFF01,852,0xFFF8,1,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype548_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype548_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype548_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype548_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype548_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype548_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes548 [] = {
g_atype548_0,
g_atype548_1,
g_atype548_2,
g_atype548_3,
g_atype548_4,
g_atype548_5,
g_atype548_6,
};

static const long offsets548 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names549[];
static const uint32 types549 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags549 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype549_0 [] = {0xFF01,853,1037,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype549_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype549_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype549_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype549_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype549_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype549_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes549 [] = {
g_atype549_0,
g_atype549_1,
g_atype549_2,
g_atype549_3,
g_atype549_4,
g_atype549_5,
g_atype549_6,
};

static const long offsets549 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names550[];
static const uint32 types550 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags550 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype550_0 [] = {0xFF01,854,1219,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype550_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype550_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype550_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype550_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype550_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype550_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes550 [] = {
g_atype550_0,
g_atype550_1,
g_atype550_2,
g_atype550_3,
g_atype550_4,
g_atype550_5,
g_atype550_6,
};

static const long offsets550 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names551[];
static const uint32 types551 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags551 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype551_0 [] = {0xFF01,855,1231,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype551_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype551_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype551_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype551_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype551_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype551_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes551 [] = {
g_atype551_0,
g_atype551_1,
g_atype551_2,
g_atype551_3,
g_atype551_4,
g_atype551_5,
g_atype551_6,
};

static const long offsets551 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names552[];
static const uint32 types552 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags552 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype552_0 [] = {0xFF01,856,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype552_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype552_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype552_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype552_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype552_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype552_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes552 [] = {
g_atype552_0,
g_atype552_1,
g_atype552_2,
g_atype552_3,
g_atype552_4,
g_atype552_5,
g_atype552_6,
};

static const long offsets552 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names553[];
static const uint32 types553 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags553 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype553_0 [] = {0xFF01,857,1237,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype553_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes553 [] = {
g_atype553_0,
g_atype553_1,
g_atype553_2,
g_atype553_3,
g_atype553_4,
g_atype553_5,
g_atype553_6,
};

static const long offsets553 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names554[];
static const uint32 types554 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags554 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype554_0 [] = {0xFF01,858,1070,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype554_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype554_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype554_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype554_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype554_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype554_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes554 [] = {
g_atype554_0,
g_atype554_1,
g_atype554_2,
g_atype554_3,
g_atype554_4,
g_atype554_5,
g_atype554_6,
};

static const long offsets554 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names555[];
static const uint32 types555 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags555 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype555_0 [] = {0xFF01,943,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_1 [] = {194,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_3 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype555_7 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes555 [] = {
g_atype555_0,
g_atype555_1,
g_atype555_2,
g_atype555_3,
g_atype555_4,
g_atype555_5,
g_atype555_6,
g_atype555_7,
};

static const long offsets555 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names556[];
static const uint32 types556 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags556 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype556_0 [] = {0xFF01,944,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_1 [] = {195,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_3 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype556_7 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes556 [] = {
g_atype556_0,
g_atype556_1,
g_atype556_2,
g_atype556_3,
g_atype556_4,
g_atype556_5,
g_atype556_6,
g_atype556_7,
};

static const long offsets556 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names557[];
static const uint32 types557 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags557 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype557_0 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype557_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes557 [] = {
g_atype557_0,
g_atype557_1,
g_atype557_2,
};

static const long offsets557 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names558[];
static const uint32 types558 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags558 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype558_0 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype558_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes558 [] = {
g_atype558_0,
g_atype558_1,
g_atype558_2,
};

static const long offsets558 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names559[];
static const uint32 types559 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags559 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype559_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype559_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes559 [] = {
g_atype559_0,
g_atype559_1,
g_atype559_2,
};

static const long offsets559 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names560[];
static const uint32 types560 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags560 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype560_0 [] = {0xFF01,1143,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype560_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype560_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes560 [] = {
g_atype560_0,
g_atype560_1,
g_atype560_2,
};

static const long offsets560 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names561[];
static const uint32 types561 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags561 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype561_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype561_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype561_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes561 [] = {
g_atype561_0,
g_atype561_1,
g_atype561_2,
};

static const long offsets561 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names562[];
static const uint32 types562 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags562 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype562_0 [] = {0xFF01,1145,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype562_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype562_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes562 [] = {
g_atype562_0,
g_atype562_1,
g_atype562_2,
};

static const long offsets562 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names563[];
static const uint32 types563 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags563 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype563_0 [] = {0xFF01,1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype563_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes563 [] = {
g_atype563_0,
g_atype563_1,
g_atype563_2,
};

static const long offsets563 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names564[];
static const uint32 types564 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags564 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype564_0 [] = {0xFF01,1147,1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype564_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes564 [] = {
g_atype564_0,
g_atype564_1,
g_atype564_2,
};

static const long offsets564 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names565[];
static const uint32 types565 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags565 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype565_0 [] = {0xFF01,1148,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype565_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes565 [] = {
g_atype565_0,
g_atype565_1,
g_atype565_2,
};

static const long offsets565 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names566[];
static const uint32 types566 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags566 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype566_0 [] = {0xFF01,1149,1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype566_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes566 [] = {
g_atype566_0,
g_atype566_1,
g_atype566_2,
};

static const long offsets566 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names567[];
static const uint32 types567 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags567 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype567_0 [] = {0xFF01,1150,1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype567_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes567 [] = {
g_atype567_0,
g_atype567_1,
g_atype567_2,
};

static const long offsets567 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names568[];
static const uint32 types568 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags568 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype568_0 [] = {0xFF01,1151,1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype568_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes568 [] = {
g_atype568_0,
g_atype568_1,
g_atype568_2,
};

static const long offsets568 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names569[];
static const uint32 types569 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags569 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype569_0 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_1 [] = {0xFF01,948,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype569_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes569 [] = {
g_atype569_0,
g_atype569_1,
g_atype569_2,
g_atype569_3,
};

static const long offsets569 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names570[];
static const uint32 types570 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags570 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype570_0 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_1 [] = {0xFF01,949,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes570 [] = {
g_atype570_0,
g_atype570_1,
g_atype570_2,
g_atype570_3,
};

static const long offsets570 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names571[];
static const uint32 types571 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags571 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype571_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype571_1 [] = {0xFF01,950,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype571_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype571_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes571 [] = {
g_atype571_0,
g_atype571_1,
g_atype571_2,
g_atype571_3,
};

static const long offsets571 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names572[];
static const uint32 types572 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags572 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype572_0 [] = {0xFF01,1143,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype572_1 [] = {0xFF01,951,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype572_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype572_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes572 [] = {
g_atype572_0,
g_atype572_1,
g_atype572_2,
g_atype572_3,
};

static const long offsets572 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names573[];
static const uint32 types573 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags573 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype573_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype573_1 [] = {0xFF01,952,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype573_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype573_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes573 [] = {
g_atype573_0,
g_atype573_1,
g_atype573_2,
g_atype573_3,
};

static const long offsets573 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names574[];
static const uint32 types574 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags574 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype574_0 [] = {0xFF01,1145,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype574_1 [] = {0xFF01,953,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype574_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype574_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes574 [] = {
g_atype574_0,
g_atype574_1,
g_atype574_2,
g_atype574_3,
};

static const long offsets574 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names575[];
static const uint32 types575 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags575 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype575_0 [] = {0xFF01,1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype575_1 [] = {0xFF01,954,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype575_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype575_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes575 [] = {
g_atype575_0,
g_atype575_1,
g_atype575_2,
g_atype575_3,
};

static const long offsets575 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names576[];
static const uint32 types576 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags576 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype576_0 [] = {0xFF01,1147,1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype576_1 [] = {0xFF01,955,1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype576_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype576_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes576 [] = {
g_atype576_0,
g_atype576_1,
g_atype576_2,
g_atype576_3,
};

static const long offsets576 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names577[];
static const uint32 types577 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags577 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype577_0 [] = {0xFF01,1148,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype577_1 [] = {0xFF01,956,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype577_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype577_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes577 [] = {
g_atype577_0,
g_atype577_1,
g_atype577_2,
g_atype577_3,
};

static const long offsets577 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names578[];
static const uint32 types578 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags578 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype578_0 [] = {0xFF01,1149,1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype578_1 [] = {0xFF01,957,1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype578_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype578_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes578 [] = {
g_atype578_0,
g_atype578_1,
g_atype578_2,
g_atype578_3,
};

static const long offsets578 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names579[];
static const uint32 types579 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags579 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype579_0 [] = {0xFF01,1150,1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype579_1 [] = {0xFF01,958,1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype579_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype579_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes579 [] = {
g_atype579_0,
g_atype579_1,
g_atype579_2,
g_atype579_3,
};

static const long offsets579 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names580[];
static const uint32 types580 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags580 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype580_0 [] = {0xFF01,1151,1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype580_1 [] = {0xFF01,959,1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype580_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype580_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes580 [] = {
g_atype580_0,
g_atype580_1,
g_atype580_2,
g_atype580_3,
};

static const long offsets580 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names581[];
static const uint32 types581 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags581 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype581_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype581_1 [] = {0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype581_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype581_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype581_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes581 [] = {
g_atype581_0,
g_atype581_1,
g_atype581_2,
g_atype581_3,
g_atype581_4,
};

static const long offsets581 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names582[];
static const uint32 types582 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags582 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype582_0 [] = {0xFF01,1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype582_1 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype582_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype582_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype582_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes582 [] = {
g_atype582_0,
g_atype582_1,
g_atype582_2,
g_atype582_3,
g_atype582_4,
};

static const long offsets582 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names583[];
static const uint32 types583 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags583 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype583_0 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype583_1 [] = {0xFF01,878,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype583_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype583_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype583_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes583 [] = {
g_atype583_0,
g_atype583_1,
g_atype583_2,
g_atype583_3,
g_atype583_4,
};

static const long offsets583 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names584[];
static const uint32 types584 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags584 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype584_0 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype584_1 [] = {0xFF01,879,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype584_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype584_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype584_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes584 [] = {
g_atype584_0,
g_atype584_1,
g_atype584_2,
g_atype584_3,
g_atype584_4,
};

static const long offsets584 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names585[];
static const uint32 types585 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags585 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype585_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype585_1 [] = {0xFF01,880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype585_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype585_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype585_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes585 [] = {
g_atype585_0,
g_atype585_1,
g_atype585_2,
g_atype585_3,
g_atype585_4,
};

static const long offsets585 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names586[];
static const uint32 types586 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags586 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype586_0 [] = {0xFF01,1143,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype586_1 [] = {0xFF01,881,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype586_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype586_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype586_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes586 [] = {
g_atype586_0,
g_atype586_1,
g_atype586_2,
g_atype586_3,
g_atype586_4,
};

static const long offsets586 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names587[];
static const uint32 types587 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags587 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype587_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype587_1 [] = {0xFF01,882,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype587_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype587_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype587_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes587 [] = {
g_atype587_0,
g_atype587_1,
g_atype587_2,
g_atype587_3,
g_atype587_4,
};

static const long offsets587 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names588[];
static const uint32 types588 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags588 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype588_0 [] = {0xFF01,1145,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype588_1 [] = {0xFF01,883,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype588_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype588_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype588_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes588 [] = {
g_atype588_0,
g_atype588_1,
g_atype588_2,
g_atype588_3,
g_atype588_4,
};

static const long offsets588 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names589[];
static const uint32 types589 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags589 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype589_0 [] = {0xFF01,1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype589_1 [] = {0xFF01,884,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype589_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype589_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype589_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes589 [] = {
g_atype589_0,
g_atype589_1,
g_atype589_2,
g_atype589_3,
g_atype589_4,
};

static const long offsets589 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names590[];
static const uint32 types590 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags590 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype590_0 [] = {0xFF01,1147,1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype590_1 [] = {0xFF01,885,1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype590_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype590_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype590_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes590 [] = {
g_atype590_0,
g_atype590_1,
g_atype590_2,
g_atype590_3,
g_atype590_4,
};

static const long offsets590 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names591[];
static const uint32 types591 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags591 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype591_0 [] = {0xFF01,1148,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype591_1 [] = {0xFF01,886,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype591_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype591_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype591_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes591 [] = {
g_atype591_0,
g_atype591_1,
g_atype591_2,
g_atype591_3,
g_atype591_4,
};

static const long offsets591 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names592[];
static const uint32 types592 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags592 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype592_0 [] = {0xFF01,1149,1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_1 [] = {0xFF01,887,1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes592 [] = {
g_atype592_0,
g_atype592_1,
g_atype592_2,
g_atype592_3,
g_atype592_4,
};

static const long offsets592 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names593[];
static const uint32 types593 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags593 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype593_0 [] = {0xFF01,1150,1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_1 [] = {0xFF01,888,1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes593 [] = {
g_atype593_0,
g_atype593_1,
g_atype593_2,
g_atype593_3,
g_atype593_4,
};

static const long offsets593 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names594[];
static const uint32 types594 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags594 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype594_0 [] = {0xFF01,1151,1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_1 [] = {0xFF01,889,1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes594 [] = {
g_atype594_0,
g_atype594_1,
g_atype594_2,
g_atype594_3,
g_atype594_4,
};

static const long offsets594 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names595[];
static const uint32 types595 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags595 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype595_0 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype595_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes595 [] = {
g_atype595_0,
g_atype595_1,
g_atype595_2,
};

static const long offsets595 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names596[];
static const uint32 types596 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags596 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype596_0 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype596_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype596_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes596 [] = {
g_atype596_0,
g_atype596_1,
g_atype596_2,
};

static const long offsets596 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names597[];
static const uint32 types597 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags597 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype597_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype597_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype597_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes597 [] = {
g_atype597_0,
g_atype597_1,
g_atype597_2,
};

static const long offsets597 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names598[];
static const uint32 types598 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags598 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype598_0 [] = {0xFF01,1143,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype598_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype598_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes598 [] = {
g_atype598_0,
g_atype598_1,
g_atype598_2,
};

static const long offsets598 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names599[];
static const uint32 types599 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags599 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype599_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype599_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype599_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes599 [] = {
g_atype599_0,
g_atype599_1,
g_atype599_2,
};

static const long offsets599 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names600[];
static const uint32 types600 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags600 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype600_0 [] = {0xFF01,1145,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype600_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype600_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes600 [] = {
g_atype600_0,
g_atype600_1,
g_atype600_2,
};

static const long offsets600 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names601[];
static const uint32 types601 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags601 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype601_0 [] = {0xFF01,1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype601_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype601_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes601 [] = {
g_atype601_0,
g_atype601_1,
g_atype601_2,
};

static const long offsets601 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names602[];
static const uint32 types602 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags602 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype602_0 [] = {0xFF01,1147,1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype602_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype602_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes602 [] = {
g_atype602_0,
g_atype602_1,
g_atype602_2,
};

static const long offsets602 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names603[];
static const uint32 types603 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags603 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype603_0 [] = {0xFF01,1148,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype603_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype603_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes603 [] = {
g_atype603_0,
g_atype603_1,
g_atype603_2,
};

static const long offsets603 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names604[];
static const uint32 types604 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags604 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype604_0 [] = {0xFF01,1149,1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype604_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype604_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes604 [] = {
g_atype604_0,
g_atype604_1,
g_atype604_2,
};

static const long offsets604 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names605[];
static const uint32 types605 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags605 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype605_0 [] = {0xFF01,1150,1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype605_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype605_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes605 [] = {
g_atype605_0,
g_atype605_1,
g_atype605_2,
};

static const long offsets605 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names606[];
static const uint32 types606 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags606 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype606_0 [] = {0xFF01,1151,1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype606_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype606_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes606 [] = {
g_atype606_0,
g_atype606_1,
g_atype606_2,
};

static const long offsets606 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names607[];
static const uint32 types607 [] =
{
SK_REF,
};

static const uint16 attr_flags607 [] =
{0,};

static const EIF_TYPE_INDEX g_atype607_0 [] = {0xFF01,495,0xFF01,1090,0xFFFF};

static const EIF_TYPE_INDEX *gtypes607 [] = {
g_atype607_0,
};

static const long offsets607 [] =
{
0,
};

extern const char *names608[];
static const uint32 types608 [] =
{
SK_BOOL,
};

static const uint16 attr_flags608 [] =
{0,};

static const EIF_TYPE_INDEX g_atype608_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes608 [] = {
g_atype608_0,
};

static const long offsets608 [] =
{
+ @CHROFF(0,0),
};

extern const char *names609[];
static const uint32 types609 [] =
{
SK_BOOL,
};

static const uint16 attr_flags609 [] =
{0,};

static const EIF_TYPE_INDEX g_atype609_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes609 [] = {
g_atype609_0,
};

static const long offsets609 [] =
{
+ @CHROFF(0,0),
};

extern const char *names610[];
static const uint32 types610 [] =
{
SK_BOOL,
};

static const uint16 attr_flags610 [] =
{0,};

static const EIF_TYPE_INDEX g_atype610_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes610 [] = {
g_atype610_0,
};

static const long offsets610 [] =
{
+ @CHROFF(0,0),
};

extern const char *names611[];
static const uint32 types611 [] =
{
SK_BOOL,
};

static const uint16 attr_flags611 [] =
{0,};

static const EIF_TYPE_INDEX g_atype611_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes611 [] = {
g_atype611_0,
};

static const long offsets611 [] =
{
+ @CHROFF(0,0),
};

extern const char *names612[];
static const uint32 types612 [] =
{
SK_BOOL,
};

static const uint16 attr_flags612 [] =
{0,};

static const EIF_TYPE_INDEX g_atype612_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes612 [] = {
g_atype612_0,
};

static const long offsets612 [] =
{
+ @CHROFF(0,0),
};

extern const char *names613[];
static const uint32 types613 [] =
{
SK_BOOL,
};

static const uint16 attr_flags613 [] =
{0,};

static const EIF_TYPE_INDEX g_atype613_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes613 [] = {
g_atype613_0,
};

static const long offsets613 [] =
{
+ @CHROFF(0,0),
};

extern const char *names614[];
static const uint32 types614 [] =
{
SK_BOOL,
};

static const uint16 attr_flags614 [] =
{0,};

static const EIF_TYPE_INDEX g_atype614_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes614 [] = {
g_atype614_0,
};

static const long offsets614 [] =
{
+ @CHROFF(0,0),
};

extern const char *names615[];
static const uint32 types615 [] =
{
SK_BOOL,
};

static const uint16 attr_flags615 [] =
{0,};

static const EIF_TYPE_INDEX g_atype615_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes615 [] = {
g_atype615_0,
};

static const long offsets615 [] =
{
+ @CHROFF(0,0),
};

extern const char *names616[];
static const uint32 types616 [] =
{
SK_BOOL,
};

static const uint16 attr_flags616 [] =
{0,};

static const EIF_TYPE_INDEX g_atype616_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes616 [] = {
g_atype616_0,
};

static const long offsets616 [] =
{
+ @CHROFF(0,0),
};

extern const char *names617[];
static const uint32 types617 [] =
{
SK_BOOL,
};

static const uint16 attr_flags617 [] =
{0,};

static const EIF_TYPE_INDEX g_atype617_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes617 [] = {
g_atype617_0,
};

static const long offsets617 [] =
{
+ @CHROFF(0,0),
};

extern const char *names618[];
static const uint32 types618 [] =
{
SK_BOOL,
};

static const uint16 attr_flags618 [] =
{0,};

static const EIF_TYPE_INDEX g_atype618_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes618 [] = {
g_atype618_0,
};

static const long offsets618 [] =
{
+ @CHROFF(0,0),
};

extern const char *names619[];
static const uint32 types619 [] =
{
SK_BOOL,
};

static const uint16 attr_flags619 [] =
{0,};

static const EIF_TYPE_INDEX g_atype619_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes619 [] = {
g_atype619_0,
};

static const long offsets619 [] =
{
+ @CHROFF(0,0),
};

extern const char *names620[];
static const uint32 types620 [] =
{
SK_BOOL,
};

static const uint16 attr_flags620 [] =
{0,};

static const EIF_TYPE_INDEX g_atype620_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes620 [] = {
g_atype620_0,
};

static const long offsets620 [] =
{
+ @CHROFF(0,0),
};

extern const char *names621[];
static const uint32 types621 [] =
{
SK_BOOL,
};

static const uint16 attr_flags621 [] =
{0,};

static const EIF_TYPE_INDEX g_atype621_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes621 [] = {
g_atype621_0,
};

static const long offsets621 [] =
{
+ @CHROFF(0,0),
};

extern const char *names622[];
static const uint32 types622 [] =
{
SK_BOOL,
};

static const uint16 attr_flags622 [] =
{0,};

static const EIF_TYPE_INDEX g_atype622_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes622 [] = {
g_atype622_0,
};

static const long offsets622 [] =
{
+ @CHROFF(0,0),
};

extern const char *names623[];
static const uint32 types623 [] =
{
SK_BOOL,
};

static const uint16 attr_flags623 [] =
{0,};

static const EIF_TYPE_INDEX g_atype623_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes623 [] = {
g_atype623_0,
};

static const long offsets623 [] =
{
+ @CHROFF(0,0),
};

extern const char *names624[];
static const uint32 types624 [] =
{
SK_BOOL,
};

static const uint16 attr_flags624 [] =
{0,};

static const EIF_TYPE_INDEX g_atype624_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes624 [] = {
g_atype624_0,
};

static const long offsets624 [] =
{
+ @CHROFF(0,0),
};

extern const char *names625[];
static const uint32 types625 [] =
{
SK_BOOL,
};

static const uint16 attr_flags625 [] =
{0,};

static const EIF_TYPE_INDEX g_atype625_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes625 [] = {
g_atype625_0,
};

static const long offsets625 [] =
{
+ @CHROFF(0,0),
};

extern const char *names626[];
static const uint32 types626 [] =
{
SK_BOOL,
};

static const uint16 attr_flags626 [] =
{0,};

static const EIF_TYPE_INDEX g_atype626_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes626 [] = {
g_atype626_0,
};

static const long offsets626 [] =
{
+ @CHROFF(0,0),
};

extern const char *names627[];
static const uint32 types627 [] =
{
SK_BOOL,
};

static const uint16 attr_flags627 [] =
{0,};

static const EIF_TYPE_INDEX g_atype627_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes627 [] = {
g_atype627_0,
};

static const long offsets627 [] =
{
+ @CHROFF(0,0),
};

extern const char *names628[];
static const uint32 types628 [] =
{
SK_BOOL,
};

static const uint16 attr_flags628 [] =
{0,};

static const EIF_TYPE_INDEX g_atype628_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes628 [] = {
g_atype628_0,
};

static const long offsets628 [] =
{
+ @CHROFF(0,0),
};

extern const char *names629[];
static const uint32 types629 [] =
{
SK_BOOL,
};

static const uint16 attr_flags629 [] =
{0,};

static const EIF_TYPE_INDEX g_atype629_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes629 [] = {
g_atype629_0,
};

static const long offsets629 [] =
{
+ @CHROFF(0,0),
};

extern const char *names630[];
static const uint32 types630 [] =
{
SK_BOOL,
};

static const uint16 attr_flags630 [] =
{0,};

static const EIF_TYPE_INDEX g_atype630_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes630 [] = {
g_atype630_0,
};

static const long offsets630 [] =
{
+ @CHROFF(0,0),
};

extern const char *names631[];
static const uint32 types631 [] =
{
SK_BOOL,
};

static const uint16 attr_flags631 [] =
{0,};

static const EIF_TYPE_INDEX g_atype631_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes631 [] = {
g_atype631_0,
};

static const long offsets631 [] =
{
+ @CHROFF(0,0),
};

extern const char *names632[];
static const uint32 types632 [] =
{
SK_BOOL,
};

static const uint16 attr_flags632 [] =
{0,};

static const EIF_TYPE_INDEX g_atype632_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes632 [] = {
g_atype632_0,
};

static const long offsets632 [] =
{
+ @CHROFF(0,0),
};

extern const char *names633[];
static const uint32 types633 [] =
{
SK_BOOL,
};

static const uint16 attr_flags633 [] =
{0,};

static const EIF_TYPE_INDEX g_atype633_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes633 [] = {
g_atype633_0,
};

static const long offsets633 [] =
{
+ @CHROFF(0,0),
};

extern const char *names634[];
static const uint32 types634 [] =
{
SK_BOOL,
};

static const uint16 attr_flags634 [] =
{0,};

static const EIF_TYPE_INDEX g_atype634_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes634 [] = {
g_atype634_0,
};

static const long offsets634 [] =
{
+ @CHROFF(0,0),
};

extern const char *names635[];
static const uint32 types635 [] =
{
SK_BOOL,
};

static const uint16 attr_flags635 [] =
{0,};

static const EIF_TYPE_INDEX g_atype635_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes635 [] = {
g_atype635_0,
};

static const long offsets635 [] =
{
+ @CHROFF(0,0),
};

extern const char *names636[];
static const uint32 types636 [] =
{
SK_BOOL,
};

static const uint16 attr_flags636 [] =
{0,};

static const EIF_TYPE_INDEX g_atype636_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes636 [] = {
g_atype636_0,
};

static const long offsets636 [] =
{
+ @CHROFF(0,0),
};

extern const char *names637[];
static const uint32 types637 [] =
{
SK_BOOL,
};

static const uint16 attr_flags637 [] =
{0,};

static const EIF_TYPE_INDEX g_atype637_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes637 [] = {
g_atype637_0,
};

static const long offsets637 [] =
{
+ @CHROFF(0,0),
};

extern const char *names638[];
static const uint32 types638 [] =
{
SK_BOOL,
};

static const uint16 attr_flags638 [] =
{0,};

static const EIF_TYPE_INDEX g_atype638_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes638 [] = {
g_atype638_0,
};

static const long offsets638 [] =
{
+ @CHROFF(0,0),
};

extern const char *names639[];
static const uint32 types639 [] =
{
SK_BOOL,
};

static const uint16 attr_flags639 [] =
{0,};

static const EIF_TYPE_INDEX g_atype639_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes639 [] = {
g_atype639_0,
};

static const long offsets639 [] =
{
+ @CHROFF(0,0),
};

extern const char *names640[];
static const uint32 types640 [] =
{
SK_BOOL,
};

static const uint16 attr_flags640 [] =
{0,};

static const EIF_TYPE_INDEX g_atype640_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes640 [] = {
g_atype640_0,
};

static const long offsets640 [] =
{
+ @CHROFF(0,0),
};

extern const char *names641[];
static const uint32 types641 [] =
{
SK_BOOL,
};

static const uint16 attr_flags641 [] =
{0,};

static const EIF_TYPE_INDEX g_atype641_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes641 [] = {
g_atype641_0,
};

static const long offsets641 [] =
{
+ @CHROFF(0,0),
};

extern const char *names642[];
static const uint32 types642 [] =
{
SK_BOOL,
};

static const uint16 attr_flags642 [] =
{0,};

static const EIF_TYPE_INDEX g_atype642_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes642 [] = {
g_atype642_0,
};

static const long offsets642 [] =
{
+ @CHROFF(0,0),
};

extern const char *names643[];
static const uint32 types643 [] =
{
SK_BOOL,
};

static const uint16 attr_flags643 [] =
{0,};

static const EIF_TYPE_INDEX g_atype643_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes643 [] = {
g_atype643_0,
};

static const long offsets643 [] =
{
+ @CHROFF(0,0),
};

extern const char *names644[];
static const uint32 types644 [] =
{
SK_BOOL,
};

static const uint16 attr_flags644 [] =
{0,};

static const EIF_TYPE_INDEX g_atype644_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes644 [] = {
g_atype644_0,
};

static const long offsets644 [] =
{
+ @CHROFF(0,0),
};

extern const char *names645[];
static const uint32 types645 [] =
{
SK_BOOL,
};

static const uint16 attr_flags645 [] =
{0,};

static const EIF_TYPE_INDEX g_atype645_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes645 [] = {
g_atype645_0,
};

static const long offsets645 [] =
{
+ @CHROFF(0,0),
};

extern const char *names646[];
static const uint32 types646 [] =
{
SK_BOOL,
};

static const uint16 attr_flags646 [] =
{0,};

static const EIF_TYPE_INDEX g_atype646_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes646 [] = {
g_atype646_0,
};

static const long offsets646 [] =
{
+ @CHROFF(0,0),
};

extern const char *names647[];
static const uint32 types647 [] =
{
SK_BOOL,
};

static const uint16 attr_flags647 [] =
{0,};

static const EIF_TYPE_INDEX g_atype647_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes647 [] = {
g_atype647_0,
};

static const long offsets647 [] =
{
+ @CHROFF(0,0),
};

extern const char *names648[];
static const uint32 types648 [] =
{
SK_BOOL,
};

static const uint16 attr_flags648 [] =
{0,};

static const EIF_TYPE_INDEX g_atype648_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes648 [] = {
g_atype648_0,
};

static const long offsets648 [] =
{
+ @CHROFF(0,0),
};

extern const char *names649[];
static const uint32 types649 [] =
{
SK_BOOL,
};

static const uint16 attr_flags649 [] =
{0,};

static const EIF_TYPE_INDEX g_atype649_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes649 [] = {
g_atype649_0,
};

static const long offsets649 [] =
{
+ @CHROFF(0,0),
};

extern const char *names650[];
static const uint32 types650 [] =
{
SK_BOOL,
};

static const uint16 attr_flags650 [] =
{0,};

static const EIF_TYPE_INDEX g_atype650_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes650 [] = {
g_atype650_0,
};

static const long offsets650 [] =
{
+ @CHROFF(0,0),
};

extern const char *names651[];
static const uint32 types651 [] =
{
SK_BOOL,
};

static const uint16 attr_flags651 [] =
{0,};

static const EIF_TYPE_INDEX g_atype651_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes651 [] = {
g_atype651_0,
};

static const long offsets651 [] =
{
+ @CHROFF(0,0),
};

extern const char *names652[];
static const uint32 types652 [] =
{
SK_BOOL,
};

static const uint16 attr_flags652 [] =
{0,};

static const EIF_TYPE_INDEX g_atype652_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes652 [] = {
g_atype652_0,
};

static const long offsets652 [] =
{
+ @CHROFF(0,0),
};

extern const char *names653[];
static const uint32 types653 [] =
{
SK_BOOL,
};

static const uint16 attr_flags653 [] =
{0,};

static const EIF_TYPE_INDEX g_atype653_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes653 [] = {
g_atype653_0,
};

static const long offsets653 [] =
{
+ @CHROFF(0,0),
};

extern const char *names654[];
static const uint32 types654 [] =
{
SK_BOOL,
};

static const uint16 attr_flags654 [] =
{0,};

static const EIF_TYPE_INDEX g_atype654_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes654 [] = {
g_atype654_0,
};

static const long offsets654 [] =
{
+ @CHROFF(0,0),
};

extern const char *names655[];
static const uint32 types655 [] =
{
SK_BOOL,
};

static const uint16 attr_flags655 [] =
{0,};

static const EIF_TYPE_INDEX g_atype655_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes655 [] = {
g_atype655_0,
};

static const long offsets655 [] =
{
+ @CHROFF(0,0),
};

extern const char *names656[];
static const uint32 types656 [] =
{
SK_BOOL,
};

static const uint16 attr_flags656 [] =
{0,};

static const EIF_TYPE_INDEX g_atype656_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes656 [] = {
g_atype656_0,
};

static const long offsets656 [] =
{
+ @CHROFF(0,0),
};

extern const char *names657[];
static const uint32 types657 [] =
{
SK_BOOL,
};

static const uint16 attr_flags657 [] =
{0,};

static const EIF_TYPE_INDEX g_atype657_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes657 [] = {
g_atype657_0,
};

static const long offsets657 [] =
{
+ @CHROFF(0,0),
};

extern const char *names658[];
static const uint32 types658 [] =
{
SK_BOOL,
};

static const uint16 attr_flags658 [] =
{0,};

static const EIF_TYPE_INDEX g_atype658_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes658 [] = {
g_atype658_0,
};

static const long offsets658 [] =
{
+ @CHROFF(0,0),
};

extern const char *names659[];
static const uint32 types659 [] =
{
SK_BOOL,
};

static const uint16 attr_flags659 [] =
{0,};

static const EIF_TYPE_INDEX g_atype659_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes659 [] = {
g_atype659_0,
};

static const long offsets659 [] =
{
+ @CHROFF(0,0),
};

extern const char *names660[];
static const uint32 types660 [] =
{
SK_BOOL,
};

static const uint16 attr_flags660 [] =
{0,};

static const EIF_TYPE_INDEX g_atype660_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes660 [] = {
g_atype660_0,
};

static const long offsets660 [] =
{
+ @CHROFF(0,0),
};

extern const char *names661[];
static const uint32 types661 [] =
{
SK_BOOL,
};

static const uint16 attr_flags661 [] =
{0,};

static const EIF_TYPE_INDEX g_atype661_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes661 [] = {
g_atype661_0,
};

static const long offsets661 [] =
{
+ @CHROFF(0,0),
};

extern const char *names662[];
static const uint32 types662 [] =
{
SK_BOOL,
};

static const uint16 attr_flags662 [] =
{0,};

static const EIF_TYPE_INDEX g_atype662_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes662 [] = {
g_atype662_0,
};

static const long offsets662 [] =
{
+ @CHROFF(0,0),
};

extern const char *names663[];
static const uint32 types663 [] =
{
SK_BOOL,
};

static const uint16 attr_flags663 [] =
{0,};

static const EIF_TYPE_INDEX g_atype663_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes663 [] = {
g_atype663_0,
};

static const long offsets663 [] =
{
+ @CHROFF(0,0),
};

extern const char *names664[];
static const uint32 types664 [] =
{
SK_BOOL,
};

static const uint16 attr_flags664 [] =
{0,};

static const EIF_TYPE_INDEX g_atype664_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes664 [] = {
g_atype664_0,
};

static const long offsets664 [] =
{
+ @CHROFF(0,0),
};

extern const char *names665[];
static const uint32 types665 [] =
{
SK_BOOL,
};

static const uint16 attr_flags665 [] =
{0,};

static const EIF_TYPE_INDEX g_atype665_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes665 [] = {
g_atype665_0,
};

static const long offsets665 [] =
{
+ @CHROFF(0,0),
};

extern const char *names666[];
static const uint32 types666 [] =
{
SK_BOOL,
};

static const uint16 attr_flags666 [] =
{0,};

static const EIF_TYPE_INDEX g_atype666_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes666 [] = {
g_atype666_0,
};

static const long offsets666 [] =
{
+ @CHROFF(0,0),
};

extern const char *names667[];
static const uint32 types667 [] =
{
SK_BOOL,
};

static const uint16 attr_flags667 [] =
{0,};

static const EIF_TYPE_INDEX g_atype667_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes667 [] = {
g_atype667_0,
};

static const long offsets667 [] =
{
+ @CHROFF(0,0),
};

extern const char *names668[];
static const uint32 types668 [] =
{
SK_BOOL,
};

static const uint16 attr_flags668 [] =
{0,};

static const EIF_TYPE_INDEX g_atype668_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes668 [] = {
g_atype668_0,
};

static const long offsets668 [] =
{
+ @CHROFF(0,0),
};

extern const char *names669[];
static const uint32 types669 [] =
{
SK_BOOL,
};

static const uint16 attr_flags669 [] =
{0,};

static const EIF_TYPE_INDEX g_atype669_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes669 [] = {
g_atype669_0,
};

static const long offsets669 [] =
{
+ @CHROFF(0,0),
};

extern const char *names670[];
static const uint32 types670 [] =
{
SK_BOOL,
};

static const uint16 attr_flags670 [] =
{0,};

static const EIF_TYPE_INDEX g_atype670_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes670 [] = {
g_atype670_0,
};

static const long offsets670 [] =
{
+ @CHROFF(0,0),
};

extern const char *names671[];
static const uint32 types671 [] =
{
SK_BOOL,
};

static const uint16 attr_flags671 [] =
{0,};

static const EIF_TYPE_INDEX g_atype671_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes671 [] = {
g_atype671_0,
};

static const long offsets671 [] =
{
+ @CHROFF(0,0),
};

extern const char *names672[];
static const uint32 types672 [] =
{
SK_BOOL,
};

static const uint16 attr_flags672 [] =
{0,};

static const EIF_TYPE_INDEX g_atype672_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes672 [] = {
g_atype672_0,
};

static const long offsets672 [] =
{
+ @CHROFF(0,0),
};

extern const char *names673[];
static const uint32 types673 [] =
{
SK_BOOL,
};

static const uint16 attr_flags673 [] =
{0,};

static const EIF_TYPE_INDEX g_atype673_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes673 [] = {
g_atype673_0,
};

static const long offsets673 [] =
{
+ @CHROFF(0,0),
};

extern const char *names674[];
static const uint32 types674 [] =
{
SK_BOOL,
};

static const uint16 attr_flags674 [] =
{0,};

static const EIF_TYPE_INDEX g_atype674_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes674 [] = {
g_atype674_0,
};

static const long offsets674 [] =
{
+ @CHROFF(0,0),
};

extern const char *names675[];
static const uint32 types675 [] =
{
SK_BOOL,
};

static const uint16 attr_flags675 [] =
{0,};

static const EIF_TYPE_INDEX g_atype675_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes675 [] = {
g_atype675_0,
};

static const long offsets675 [] =
{
+ @CHROFF(0,0),
};

extern const char *names676[];
static const uint32 types676 [] =
{
SK_BOOL,
};

static const uint16 attr_flags676 [] =
{0,};

static const EIF_TYPE_INDEX g_atype676_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes676 [] = {
g_atype676_0,
};

static const long offsets676 [] =
{
+ @CHROFF(0,0),
};

extern const char *names677[];
static const uint32 types677 [] =
{
SK_BOOL,
};

static const uint16 attr_flags677 [] =
{0,};

static const EIF_TYPE_INDEX g_atype677_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes677 [] = {
g_atype677_0,
};

static const long offsets677 [] =
{
+ @CHROFF(0,0),
};

extern const char *names678[];
static const uint32 types678 [] =
{
SK_BOOL,
};

static const uint16 attr_flags678 [] =
{0,};

static const EIF_TYPE_INDEX g_atype678_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes678 [] = {
g_atype678_0,
};

static const long offsets678 [] =
{
+ @CHROFF(0,0),
};

extern const char *names679[];
static const uint32 types679 [] =
{
SK_BOOL,
};

static const uint16 attr_flags679 [] =
{0,};

static const EIF_TYPE_INDEX g_atype679_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes679 [] = {
g_atype679_0,
};

static const long offsets679 [] =
{
+ @CHROFF(0,0),
};

extern const char *names680[];
static const uint32 types680 [] =
{
SK_BOOL,
};

static const uint16 attr_flags680 [] =
{0,};

static const EIF_TYPE_INDEX g_atype680_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes680 [] = {
g_atype680_0,
};

static const long offsets680 [] =
{
+ @CHROFF(0,0),
};

extern const char *names681[];
static const uint32 types681 [] =
{
SK_BOOL,
};

static const uint16 attr_flags681 [] =
{0,};

static const EIF_TYPE_INDEX g_atype681_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes681 [] = {
g_atype681_0,
};

static const long offsets681 [] =
{
+ @CHROFF(0,0),
};

extern const char *names682[];
static const uint32 types682 [] =
{
SK_BOOL,
};

static const uint16 attr_flags682 [] =
{0,};

static const EIF_TYPE_INDEX g_atype682_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes682 [] = {
g_atype682_0,
};

static const long offsets682 [] =
{
+ @CHROFF(0,0),
};

extern const char *names683[];
static const uint32 types683 [] =
{
SK_BOOL,
};

static const uint16 attr_flags683 [] =
{0,};

static const EIF_TYPE_INDEX g_atype683_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes683 [] = {
g_atype683_0,
};

static const long offsets683 [] =
{
+ @CHROFF(0,0),
};

extern const char *names684[];
static const uint32 types684 [] =
{
SK_BOOL,
};

static const uint16 attr_flags684 [] =
{0,};

static const EIF_TYPE_INDEX g_atype684_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes684 [] = {
g_atype684_0,
};

static const long offsets684 [] =
{
+ @CHROFF(0,0),
};

extern const char *names685[];
static const uint32 types685 [] =
{
SK_BOOL,
};

static const uint16 attr_flags685 [] =
{0,};

static const EIF_TYPE_INDEX g_atype685_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes685 [] = {
g_atype685_0,
};

static const long offsets685 [] =
{
+ @CHROFF(0,0),
};

extern const char *names686[];
static const uint32 types686 [] =
{
SK_BOOL,
};

static const uint16 attr_flags686 [] =
{0,};

static const EIF_TYPE_INDEX g_atype686_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes686 [] = {
g_atype686_0,
};

static const long offsets686 [] =
{
+ @CHROFF(0,0),
};

extern const char *names687[];
static const uint32 types687 [] =
{
SK_BOOL,
};

static const uint16 attr_flags687 [] =
{0,};

static const EIF_TYPE_INDEX g_atype687_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes687 [] = {
g_atype687_0,
};

static const long offsets687 [] =
{
+ @CHROFF(0,0),
};

extern const char *names688[];
static const uint32 types688 [] =
{
SK_BOOL,
};

static const uint16 attr_flags688 [] =
{0,};

static const EIF_TYPE_INDEX g_atype688_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes688 [] = {
g_atype688_0,
};

static const long offsets688 [] =
{
+ @CHROFF(0,0),
};

extern const char *names689[];
static const uint32 types689 [] =
{
SK_BOOL,
};

static const uint16 attr_flags689 [] =
{0,};

static const EIF_TYPE_INDEX g_atype689_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes689 [] = {
g_atype689_0,
};

static const long offsets689 [] =
{
+ @CHROFF(0,0),
};

extern const char *names690[];
static const uint32 types690 [] =
{
SK_BOOL,
};

static const uint16 attr_flags690 [] =
{0,};

static const EIF_TYPE_INDEX g_atype690_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes690 [] = {
g_atype690_0,
};

static const long offsets690 [] =
{
+ @CHROFF(0,0),
};

extern const char *names691[];
static const uint32 types691 [] =
{
SK_BOOL,
};

static const uint16 attr_flags691 [] =
{0,};

static const EIF_TYPE_INDEX g_atype691_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes691 [] = {
g_atype691_0,
};

static const long offsets691 [] =
{
+ @CHROFF(0,0),
};

extern const char *names692[];
static const uint32 types692 [] =
{
SK_BOOL,
};

static const uint16 attr_flags692 [] =
{0,};

static const EIF_TYPE_INDEX g_atype692_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes692 [] = {
g_atype692_0,
};

static const long offsets692 [] =
{
+ @CHROFF(0,0),
};

extern const char *names693[];
static const uint32 types693 [] =
{
SK_BOOL,
};

static const uint16 attr_flags693 [] =
{0,};

static const EIF_TYPE_INDEX g_atype693_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes693 [] = {
g_atype693_0,
};

static const long offsets693 [] =
{
+ @CHROFF(0,0),
};

extern const char *names694[];
static const uint32 types694 [] =
{
SK_BOOL,
};

static const uint16 attr_flags694 [] =
{0,};

static const EIF_TYPE_INDEX g_atype694_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes694 [] = {
g_atype694_0,
};

static const long offsets694 [] =
{
+ @CHROFF(0,0),
};

extern const char *names695[];
static const uint32 types695 [] =
{
SK_BOOL,
};

static const uint16 attr_flags695 [] =
{0,};

static const EIF_TYPE_INDEX g_atype695_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes695 [] = {
g_atype695_0,
};

static const long offsets695 [] =
{
+ @CHROFF(0,0),
};

extern const char *names696[];
static const uint32 types696 [] =
{
SK_BOOL,
};

static const uint16 attr_flags696 [] =
{0,};

static const EIF_TYPE_INDEX g_atype696_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes696 [] = {
g_atype696_0,
};

static const long offsets696 [] =
{
+ @CHROFF(0,0),
};

extern const char *names697[];
static const uint32 types697 [] =
{
SK_BOOL,
};

static const uint16 attr_flags697 [] =
{0,};

static const EIF_TYPE_INDEX g_atype697_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes697 [] = {
g_atype697_0,
};

static const long offsets697 [] =
{
+ @CHROFF(0,0),
};

extern const char *names698[];
static const uint32 types698 [] =
{
SK_BOOL,
};

static const uint16 attr_flags698 [] =
{0,};

static const EIF_TYPE_INDEX g_atype698_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes698 [] = {
g_atype698_0,
};

static const long offsets698 [] =
{
+ @CHROFF(0,0),
};

extern const char *names699[];
static const uint32 types699 [] =
{
SK_BOOL,
};

static const uint16 attr_flags699 [] =
{0,};

static const EIF_TYPE_INDEX g_atype699_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes699 [] = {
g_atype699_0,
};

static const long offsets699 [] =
{
+ @CHROFF(0,0),
};

extern const char *names700[];
static const uint32 types700 [] =
{
SK_BOOL,
};

static const uint16 attr_flags700 [] =
{0,};

static const EIF_TYPE_INDEX g_atype700_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes700 [] = {
g_atype700_0,
};

static const long offsets700 [] =
{
+ @CHROFF(0,0),
};

extern const char *names701[];
static const uint32 types701 [] =
{
SK_BOOL,
};

static const uint16 attr_flags701 [] =
{0,};

static const EIF_TYPE_INDEX g_atype701_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes701 [] = {
g_atype701_0,
};

static const long offsets701 [] =
{
+ @CHROFF(0,0),
};

extern const char *names702[];
static const uint32 types702 [] =
{
SK_BOOL,
};

static const uint16 attr_flags702 [] =
{0,};

static const EIF_TYPE_INDEX g_atype702_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes702 [] = {
g_atype702_0,
};

static const long offsets702 [] =
{
+ @CHROFF(0,0),
};

extern const char *names703[];
static const uint32 types703 [] =
{
SK_BOOL,
};

static const uint16 attr_flags703 [] =
{0,};

static const EIF_TYPE_INDEX g_atype703_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes703 [] = {
g_atype703_0,
};

static const long offsets703 [] =
{
+ @CHROFF(0,0),
};

extern const char *names704[];
static const uint32 types704 [] =
{
SK_BOOL,
};

static const uint16 attr_flags704 [] =
{0,};

static const EIF_TYPE_INDEX g_atype704_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes704 [] = {
g_atype704_0,
};

static const long offsets704 [] =
{
+ @CHROFF(0,0),
};

extern const char *names705[];
static const uint32 types705 [] =
{
SK_BOOL,
};

static const uint16 attr_flags705 [] =
{0,};

static const EIF_TYPE_INDEX g_atype705_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes705 [] = {
g_atype705_0,
};

static const long offsets705 [] =
{
+ @CHROFF(0,0),
};

extern const char *names706[];
static const uint32 types706 [] =
{
SK_BOOL,
};

static const uint16 attr_flags706 [] =
{0,};

static const EIF_TYPE_INDEX g_atype706_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes706 [] = {
g_atype706_0,
};

static const long offsets706 [] =
{
+ @CHROFF(0,0),
};

extern const char *names707[];
static const uint32 types707 [] =
{
SK_BOOL,
};

static const uint16 attr_flags707 [] =
{0,};

static const EIF_TYPE_INDEX g_atype707_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes707 [] = {
g_atype707_0,
};

static const long offsets707 [] =
{
+ @CHROFF(0,0),
};

extern const char *names708[];
static const uint32 types708 [] =
{
SK_BOOL,
};

static const uint16 attr_flags708 [] =
{0,};

static const EIF_TYPE_INDEX g_atype708_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes708 [] = {
g_atype708_0,
};

static const long offsets708 [] =
{
+ @CHROFF(0,0),
};

extern const char *names709[];
static const uint32 types709 [] =
{
SK_BOOL,
};

static const uint16 attr_flags709 [] =
{0,};

static const EIF_TYPE_INDEX g_atype709_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes709 [] = {
g_atype709_0,
};

static const long offsets709 [] =
{
+ @CHROFF(0,0),
};

extern const char *names710[];
static const uint32 types710 [] =
{
SK_BOOL,
};

static const uint16 attr_flags710 [] =
{0,};

static const EIF_TYPE_INDEX g_atype710_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes710 [] = {
g_atype710_0,
};

static const long offsets710 [] =
{
+ @CHROFF(0,0),
};

extern const char *names711[];
static const uint32 types711 [] =
{
SK_BOOL,
};

static const uint16 attr_flags711 [] =
{0,};

static const EIF_TYPE_INDEX g_atype711_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes711 [] = {
g_atype711_0,
};

static const long offsets711 [] =
{
+ @CHROFF(0,0),
};

extern const char *names712[];
static const uint32 types712 [] =
{
SK_BOOL,
};

static const uint16 attr_flags712 [] =
{0,};

static const EIF_TYPE_INDEX g_atype712_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes712 [] = {
g_atype712_0,
};

static const long offsets712 [] =
{
+ @CHROFF(0,0),
};

extern const char *names713[];
static const uint32 types713 [] =
{
SK_BOOL,
};

static const uint16 attr_flags713 [] =
{0,};

static const EIF_TYPE_INDEX g_atype713_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes713 [] = {
g_atype713_0,
};

static const long offsets713 [] =
{
+ @CHROFF(0,0),
};

extern const char *names714[];
static const uint32 types714 [] =
{
SK_BOOL,
};

static const uint16 attr_flags714 [] =
{0,};

static const EIF_TYPE_INDEX g_atype714_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes714 [] = {
g_atype714_0,
};

static const long offsets714 [] =
{
+ @CHROFF(0,0),
};

extern const char *names715[];
static const uint32 types715 [] =
{
SK_BOOL,
};

static const uint16 attr_flags715 [] =
{0,};

static const EIF_TYPE_INDEX g_atype715_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes715 [] = {
g_atype715_0,
};

static const long offsets715 [] =
{
+ @CHROFF(0,0),
};

extern const char *names716[];
static const uint32 types716 [] =
{
SK_BOOL,
};

static const uint16 attr_flags716 [] =
{0,};

static const EIF_TYPE_INDEX g_atype716_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes716 [] = {
g_atype716_0,
};

static const long offsets716 [] =
{
+ @CHROFF(0,0),
};

extern const char *names717[];
static const uint32 types717 [] =
{
SK_BOOL,
};

static const uint16 attr_flags717 [] =
{0,};

static const EIF_TYPE_INDEX g_atype717_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes717 [] = {
g_atype717_0,
};

static const long offsets717 [] =
{
+ @CHROFF(0,0),
};

extern const char *names718[];
static const uint32 types718 [] =
{
SK_BOOL,
};

static const uint16 attr_flags718 [] =
{0,};

static const EIF_TYPE_INDEX g_atype718_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes718 [] = {
g_atype718_0,
};

static const long offsets718 [] =
{
+ @CHROFF(0,0),
};

extern const char *names719[];
static const uint32 types719 [] =
{
SK_BOOL,
};

static const uint16 attr_flags719 [] =
{0,};

static const EIF_TYPE_INDEX g_atype719_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes719 [] = {
g_atype719_0,
};

static const long offsets719 [] =
{
+ @CHROFF(0,0),
};

extern const char *names720[];
static const uint32 types720 [] =
{
SK_BOOL,
};

static const uint16 attr_flags720 [] =
{0,};

static const EIF_TYPE_INDEX g_atype720_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes720 [] = {
g_atype720_0,
};

static const long offsets720 [] =
{
+ @CHROFF(0,0),
};

extern const char *names721[];
static const uint32 types721 [] =
{
SK_BOOL,
};

static const uint16 attr_flags721 [] =
{0,};

static const EIF_TYPE_INDEX g_atype721_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes721 [] = {
g_atype721_0,
};

static const long offsets721 [] =
{
+ @CHROFF(0,0),
};

extern const char *names722[];
static const uint32 types722 [] =
{
SK_BOOL,
};

static const uint16 attr_flags722 [] =
{0,};

static const EIF_TYPE_INDEX g_atype722_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes722 [] = {
g_atype722_0,
};

static const long offsets722 [] =
{
+ @CHROFF(0,0),
};

extern const char *names723[];
static const uint32 types723 [] =
{
SK_BOOL,
};

static const uint16 attr_flags723 [] =
{0,};

static const EIF_TYPE_INDEX g_atype723_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes723 [] = {
g_atype723_0,
};

static const long offsets723 [] =
{
+ @CHROFF(0,0),
};

extern const char *names724[];
static const uint32 types724 [] =
{
SK_BOOL,
};

static const uint16 attr_flags724 [] =
{0,};

static const EIF_TYPE_INDEX g_atype724_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes724 [] = {
g_atype724_0,
};

static const long offsets724 [] =
{
+ @CHROFF(0,0),
};

extern const char *names725[];
static const uint32 types725 [] =
{
SK_BOOL,
};

static const uint16 attr_flags725 [] =
{0,};

static const EIF_TYPE_INDEX g_atype725_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes725 [] = {
g_atype725_0,
};

static const long offsets725 [] =
{
+ @CHROFF(0,0),
};

extern const char *names726[];
static const uint32 types726 [] =
{
SK_BOOL,
};

static const uint16 attr_flags726 [] =
{0,};

static const EIF_TYPE_INDEX g_atype726_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes726 [] = {
g_atype726_0,
};

static const long offsets726 [] =
{
+ @CHROFF(0,0),
};

extern const char *names727[];
static const uint32 types727 [] =
{
SK_BOOL,
};

static const uint16 attr_flags727 [] =
{0,};

static const EIF_TYPE_INDEX g_atype727_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes727 [] = {
g_atype727_0,
};

static const long offsets727 [] =
{
+ @CHROFF(0,0),
};

extern const char *names728[];
static const uint32 types728 [] =
{
SK_BOOL,
};

static const uint16 attr_flags728 [] =
{0,};

static const EIF_TYPE_INDEX g_atype728_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes728 [] = {
g_atype728_0,
};

static const long offsets728 [] =
{
+ @CHROFF(0,0),
};

extern const char *names729[];
static const uint32 types729 [] =
{
SK_BOOL,
};

static const uint16 attr_flags729 [] =
{0,};

static const EIF_TYPE_INDEX g_atype729_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes729 [] = {
g_atype729_0,
};

static const long offsets729 [] =
{
+ @CHROFF(0,0),
};

extern const char *names730[];
static const uint32 types730 [] =
{
SK_BOOL,
};

static const uint16 attr_flags730 [] =
{0,};

static const EIF_TYPE_INDEX g_atype730_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes730 [] = {
g_atype730_0,
};

static const long offsets730 [] =
{
+ @CHROFF(0,0),
};

extern const char *names731[];
static const uint32 types731 [] =
{
SK_BOOL,
};

static const uint16 attr_flags731 [] =
{0,};

static const EIF_TYPE_INDEX g_atype731_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes731 [] = {
g_atype731_0,
};

static const long offsets731 [] =
{
+ @CHROFF(0,0),
};

extern const char *names732[];
static const uint32 types732 [] =
{
SK_BOOL,
};

static const uint16 attr_flags732 [] =
{0,};

static const EIF_TYPE_INDEX g_atype732_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes732 [] = {
g_atype732_0,
};

static const long offsets732 [] =
{
+ @CHROFF(0,0),
};

extern const char *names733[];
static const uint32 types733 [] =
{
SK_BOOL,
};

static const uint16 attr_flags733 [] =
{0,};

static const EIF_TYPE_INDEX g_atype733_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes733 [] = {
g_atype733_0,
};

static const long offsets733 [] =
{
+ @CHROFF(0,0),
};

extern const char *names734[];
static const uint32 types734 [] =
{
SK_BOOL,
};

static const uint16 attr_flags734 [] =
{0,};

static const EIF_TYPE_INDEX g_atype734_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes734 [] = {
g_atype734_0,
};

static const long offsets734 [] =
{
+ @CHROFF(0,0),
};

extern const char *names735[];
static const uint32 types735 [] =
{
SK_BOOL,
};

static const uint16 attr_flags735 [] =
{0,};

static const EIF_TYPE_INDEX g_atype735_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes735 [] = {
g_atype735_0,
};

static const long offsets735 [] =
{
+ @CHROFF(0,0),
};

extern const char *names736[];
static const uint32 types736 [] =
{
SK_BOOL,
};

static const uint16 attr_flags736 [] =
{0,};

static const EIF_TYPE_INDEX g_atype736_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes736 [] = {
g_atype736_0,
};

static const long offsets736 [] =
{
+ @CHROFF(0,0),
};

extern const char *names737[];
static const uint32 types737 [] =
{
SK_BOOL,
};

static const uint16 attr_flags737 [] =
{0,};

static const EIF_TYPE_INDEX g_atype737_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes737 [] = {
g_atype737_0,
};

static const long offsets737 [] =
{
+ @CHROFF(0,0),
};

extern const char *names738[];
static const uint32 types738 [] =
{
SK_BOOL,
};

static const uint16 attr_flags738 [] =
{0,};

static const EIF_TYPE_INDEX g_atype738_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes738 [] = {
g_atype738_0,
};

static const long offsets738 [] =
{
+ @CHROFF(0,0),
};

extern const char *names739[];
static const uint32 types739 [] =
{
SK_BOOL,
};

static const uint16 attr_flags739 [] =
{0,};

static const EIF_TYPE_INDEX g_atype739_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes739 [] = {
g_atype739_0,
};

static const long offsets739 [] =
{
+ @CHROFF(0,0),
};

extern const char *names740[];
static const uint32 types740 [] =
{
SK_BOOL,
};

static const uint16 attr_flags740 [] =
{0,};

static const EIF_TYPE_INDEX g_atype740_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes740 [] = {
g_atype740_0,
};

static const long offsets740 [] =
{
+ @CHROFF(0,0),
};

extern const char *names741[];
static const uint32 types741 [] =
{
SK_BOOL,
};

static const uint16 attr_flags741 [] =
{0,};

static const EIF_TYPE_INDEX g_atype741_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes741 [] = {
g_atype741_0,
};

static const long offsets741 [] =
{
+ @CHROFF(0,0),
};

extern const char *names742[];
static const uint32 types742 [] =
{
SK_BOOL,
};

static const uint16 attr_flags742 [] =
{0,};

static const EIF_TYPE_INDEX g_atype742_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes742 [] = {
g_atype742_0,
};

static const long offsets742 [] =
{
+ @CHROFF(0,0),
};

extern const char *names743[];
static const uint32 types743 [] =
{
SK_BOOL,
};

static const uint16 attr_flags743 [] =
{0,};

static const EIF_TYPE_INDEX g_atype743_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes743 [] = {
g_atype743_0,
};

static const long offsets743 [] =
{
+ @CHROFF(0,0),
};

extern const char *names744[];
static const uint32 types744 [] =
{
SK_BOOL,
};

static const uint16 attr_flags744 [] =
{0,};

static const EIF_TYPE_INDEX g_atype744_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes744 [] = {
g_atype744_0,
};

static const long offsets744 [] =
{
+ @CHROFF(0,0),
};

extern const char *names745[];
static const uint32 types745 [] =
{
SK_BOOL,
};

static const uint16 attr_flags745 [] =
{0,};

static const EIF_TYPE_INDEX g_atype745_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes745 [] = {
g_atype745_0,
};

static const long offsets745 [] =
{
+ @CHROFF(0,0),
};

extern const char *names746[];
static const uint32 types746 [] =
{
SK_BOOL,
};

static const uint16 attr_flags746 [] =
{0,};

static const EIF_TYPE_INDEX g_atype746_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes746 [] = {
g_atype746_0,
};

static const long offsets746 [] =
{
+ @CHROFF(0,0),
};

extern const char *names747[];
static const uint32 types747 [] =
{
SK_BOOL,
};

static const uint16 attr_flags747 [] =
{0,};

static const EIF_TYPE_INDEX g_atype747_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes747 [] = {
g_atype747_0,
};

static const long offsets747 [] =
{
+ @CHROFF(0,0),
};

extern const char *names748[];
static const uint32 types748 [] =
{
SK_BOOL,
};

static const uint16 attr_flags748 [] =
{0,};

static const EIF_TYPE_INDEX g_atype748_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes748 [] = {
g_atype748_0,
};

static const long offsets748 [] =
{
+ @CHROFF(0,0),
};

extern const char *names749[];
static const uint32 types749 [] =
{
SK_BOOL,
};

static const uint16 attr_flags749 [] =
{0,};

static const EIF_TYPE_INDEX g_atype749_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes749 [] = {
g_atype749_0,
};

static const long offsets749 [] =
{
+ @CHROFF(0,0),
};

extern const char *names750[];
static const uint32 types750 [] =
{
SK_BOOL,
};

static const uint16 attr_flags750 [] =
{0,};

static const EIF_TYPE_INDEX g_atype750_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes750 [] = {
g_atype750_0,
};

static const long offsets750 [] =
{
+ @CHROFF(0,0),
};

extern const char *names751[];
static const uint32 types751 [] =
{
SK_BOOL,
};

static const uint16 attr_flags751 [] =
{0,};

static const EIF_TYPE_INDEX g_atype751_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes751 [] = {
g_atype751_0,
};

static const long offsets751 [] =
{
+ @CHROFF(0,0),
};

extern const char *names752[];
static const uint32 types752 [] =
{
SK_BOOL,
};

static const uint16 attr_flags752 [] =
{0,};

static const EIF_TYPE_INDEX g_atype752_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes752 [] = {
g_atype752_0,
};

static const long offsets752 [] =
{
+ @CHROFF(0,0),
};

extern const char *names753[];
static const uint32 types753 [] =
{
SK_BOOL,
};

static const uint16 attr_flags753 [] =
{0,};

static const EIF_TYPE_INDEX g_atype753_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes753 [] = {
g_atype753_0,
};

static const long offsets753 [] =
{
+ @CHROFF(0,0),
};

extern const char *names754[];
static const uint32 types754 [] =
{
SK_BOOL,
};

static const uint16 attr_flags754 [] =
{0,};

static const EIF_TYPE_INDEX g_atype754_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes754 [] = {
g_atype754_0,
};

static const long offsets754 [] =
{
+ @CHROFF(0,0),
};

extern const char *names755[];
static const uint32 types755 [] =
{
SK_BOOL,
};

static const uint16 attr_flags755 [] =
{0,};

static const EIF_TYPE_INDEX g_atype755_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes755 [] = {
g_atype755_0,
};

static const long offsets755 [] =
{
+ @CHROFF(0,0),
};

extern const char *names756[];
static const uint32 types756 [] =
{
SK_BOOL,
};

static const uint16 attr_flags756 [] =
{0,};

static const EIF_TYPE_INDEX g_atype756_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes756 [] = {
g_atype756_0,
};

static const long offsets756 [] =
{
+ @CHROFF(0,0),
};

extern const char *names757[];
static const uint32 types757 [] =
{
SK_BOOL,
};

static const uint16 attr_flags757 [] =
{0,};

static const EIF_TYPE_INDEX g_atype757_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes757 [] = {
g_atype757_0,
};

static const long offsets757 [] =
{
+ @CHROFF(0,0),
};

extern const char *names758[];
static const uint32 types758 [] =
{
SK_BOOL,
};

static const uint16 attr_flags758 [] =
{0,};

static const EIF_TYPE_INDEX g_atype758_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes758 [] = {
g_atype758_0,
};

static const long offsets758 [] =
{
+ @CHROFF(0,0),
};

extern const char *names759[];
static const uint32 types759 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags759 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype759_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes759 [] = {
g_atype759_0,
g_atype759_1,
};

static const long offsets759 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names760[];
static const uint32 types760 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags760 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype760_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes760 [] = {
g_atype760_0,
g_atype760_1,
g_atype760_2,
g_atype760_3,
g_atype760_4,
};

static const long offsets760 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
+ @LNGOFF(0,1,0,2),
+ @LNGOFF(0,1,0,3),
};

extern const char *names761[];
static const uint32 types761 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags761 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype761_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes761 [] = {
g_atype761_0,
g_atype761_1,
};

static const long offsets761 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names762[];
static const uint32 types762 [] =
{
SK_BOOL,
};

static const uint16 attr_flags762 [] =
{0,};

static const EIF_TYPE_INDEX g_atype762_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes762 [] = {
g_atype762_0,
};

static const long offsets762 [] =
{
+ @CHROFF(0,0),
};

extern const char *names763[];
static const uint32 types763 [] =
{
SK_BOOL,
};

static const uint16 attr_flags763 [] =
{0,};

static const EIF_TYPE_INDEX g_atype763_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes763 [] = {
g_atype763_0,
};

static const long offsets763 [] =
{
+ @CHROFF(0,0),
};

extern const char *names764[];
static const uint32 types764 [] =
{
SK_BOOL,
};

static const uint16 attr_flags764 [] =
{0,};

static const EIF_TYPE_INDEX g_atype764_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes764 [] = {
g_atype764_0,
};

static const long offsets764 [] =
{
+ @CHROFF(0,0),
};

extern const char *names765[];
static const uint32 types765 [] =
{
SK_BOOL,
};

static const uint16 attr_flags765 [] =
{0,};

static const EIF_TYPE_INDEX g_atype765_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes765 [] = {
g_atype765_0,
};

static const long offsets765 [] =
{
+ @CHROFF(0,0),
};

extern const char *names766[];
static const uint32 types766 [] =
{
SK_BOOL,
};

static const uint16 attr_flags766 [] =
{0,};

static const EIF_TYPE_INDEX g_atype766_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes766 [] = {
g_atype766_0,
};

static const long offsets766 [] =
{
+ @CHROFF(0,0),
};

extern const char *names767[];
static const uint32 types767 [] =
{
SK_BOOL,
};

static const uint16 attr_flags767 [] =
{0,};

static const EIF_TYPE_INDEX g_atype767_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes767 [] = {
g_atype767_0,
};

static const long offsets767 [] =
{
+ @CHROFF(0,0),
};

extern const char *names768[];
static const uint32 types768 [] =
{
SK_BOOL,
};

static const uint16 attr_flags768 [] =
{0,};

static const EIF_TYPE_INDEX g_atype768_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes768 [] = {
g_atype768_0,
};

static const long offsets768 [] =
{
+ @CHROFF(0,0),
};

extern const char *names769[];
static const uint32 types769 [] =
{
SK_BOOL,
};

static const uint16 attr_flags769 [] =
{0,};

static const EIF_TYPE_INDEX g_atype769_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes769 [] = {
g_atype769_0,
};

static const long offsets769 [] =
{
+ @CHROFF(0,0),
};

extern const char *names770[];
static const uint32 types770 [] =
{
SK_BOOL,
};

static const uint16 attr_flags770 [] =
{0,};

static const EIF_TYPE_INDEX g_atype770_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes770 [] = {
g_atype770_0,
};

static const long offsets770 [] =
{
+ @CHROFF(0,0),
};

extern const char *names771[];
static const uint32 types771 [] =
{
SK_BOOL,
};

static const uint16 attr_flags771 [] =
{0,};

static const EIF_TYPE_INDEX g_atype771_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes771 [] = {
g_atype771_0,
};

static const long offsets771 [] =
{
+ @CHROFF(0,0),
};

extern const char *names772[];
static const uint32 types772 [] =
{
SK_BOOL,
};

static const uint16 attr_flags772 [] =
{0,};

static const EIF_TYPE_INDEX g_atype772_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes772 [] = {
g_atype772_0,
};

static const long offsets772 [] =
{
+ @CHROFF(0,0),
};

extern const char *names773[];
static const uint32 types773 [] =
{
SK_BOOL,
};

static const uint16 attr_flags773 [] =
{0,};

static const EIF_TYPE_INDEX g_atype773_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes773 [] = {
g_atype773_0,
};

static const long offsets773 [] =
{
+ @CHROFF(0,0),
};

extern const char *names774[];
static const uint32 types774 [] =
{
SK_BOOL,
};

static const uint16 attr_flags774 [] =
{0,};

static const EIF_TYPE_INDEX g_atype774_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes774 [] = {
g_atype774_0,
};

static const long offsets774 [] =
{
+ @CHROFF(0,0),
};

extern const char *names775[];
static const uint32 types775 [] =
{
SK_BOOL,
};

static const uint16 attr_flags775 [] =
{0,};

static const EIF_TYPE_INDEX g_atype775_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes775 [] = {
g_atype775_0,
};

static const long offsets775 [] =
{
+ @CHROFF(0,0),
};

extern const char *names776[];
static const uint32 types776 [] =
{
SK_BOOL,
};

static const uint16 attr_flags776 [] =
{0,};

static const EIF_TYPE_INDEX g_atype776_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes776 [] = {
g_atype776_0,
};

static const long offsets776 [] =
{
+ @CHROFF(0,0),
};

extern const char *names777[];
static const uint32 types777 [] =
{
SK_BOOL,
};

static const uint16 attr_flags777 [] =
{0,};

static const EIF_TYPE_INDEX g_atype777_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes777 [] = {
g_atype777_0,
};

static const long offsets777 [] =
{
+ @CHROFF(0,0),
};

extern const char *names778[];
static const uint32 types778 [] =
{
SK_BOOL,
};

static const uint16 attr_flags778 [] =
{0,};

static const EIF_TYPE_INDEX g_atype778_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes778 [] = {
g_atype778_0,
};

static const long offsets778 [] =
{
+ @CHROFF(0,0),
};

extern const char *names779[];
static const uint32 types779 [] =
{
SK_BOOL,
};

static const uint16 attr_flags779 [] =
{0,};

static const EIF_TYPE_INDEX g_atype779_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes779 [] = {
g_atype779_0,
};

static const long offsets779 [] =
{
+ @CHROFF(0,0),
};

extern const char *names780[];
static const uint32 types780 [] =
{
SK_BOOL,
};

static const uint16 attr_flags780 [] =
{0,};

static const EIF_TYPE_INDEX g_atype780_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes780 [] = {
g_atype780_0,
};

static const long offsets780 [] =
{
+ @CHROFF(0,0),
};

extern const char *names781[];
static const uint32 types781 [] =
{
SK_BOOL,
};

static const uint16 attr_flags781 [] =
{0,};

static const EIF_TYPE_INDEX g_atype781_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes781 [] = {
g_atype781_0,
};

static const long offsets781 [] =
{
+ @CHROFF(0,0),
};

extern const char *names782[];
static const uint32 types782 [] =
{
SK_BOOL,
};

static const uint16 attr_flags782 [] =
{0,};

static const EIF_TYPE_INDEX g_atype782_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes782 [] = {
g_atype782_0,
};

static const long offsets782 [] =
{
+ @CHROFF(0,0),
};

extern const char *names783[];
static const uint32 types783 [] =
{
SK_BOOL,
};

static const uint16 attr_flags783 [] =
{0,};

static const EIF_TYPE_INDEX g_atype783_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes783 [] = {
g_atype783_0,
};

static const long offsets783 [] =
{
+ @CHROFF(0,0),
};

extern const char *names784[];
static const uint32 types784 [] =
{
SK_BOOL,
};

static const uint16 attr_flags784 [] =
{0,};

static const EIF_TYPE_INDEX g_atype784_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes784 [] = {
g_atype784_0,
};

static const long offsets784 [] =
{
+ @CHROFF(0,0),
};

extern const char *names785[];
static const uint32 types785 [] =
{
SK_BOOL,
};

static const uint16 attr_flags785 [] =
{0,};

static const EIF_TYPE_INDEX g_atype785_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes785 [] = {
g_atype785_0,
};

static const long offsets785 [] =
{
+ @CHROFF(0,0),
};

extern const char *names786[];
static const uint32 types786 [] =
{
SK_BOOL,
};

static const uint16 attr_flags786 [] =
{0,};

static const EIF_TYPE_INDEX g_atype786_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes786 [] = {
g_atype786_0,
};

static const long offsets786 [] =
{
+ @CHROFF(0,0),
};

extern const char *names787[];
static const uint32 types787 [] =
{
SK_BOOL,
};

static const uint16 attr_flags787 [] =
{0,};

static const EIF_TYPE_INDEX g_atype787_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes787 [] = {
g_atype787_0,
};

static const long offsets787 [] =
{
+ @CHROFF(0,0),
};

extern const char *names788[];
static const uint32 types788 [] =
{
SK_BOOL,
};

static const uint16 attr_flags788 [] =
{0,};

static const EIF_TYPE_INDEX g_atype788_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes788 [] = {
g_atype788_0,
};

static const long offsets788 [] =
{
+ @CHROFF(0,0),
};

extern const char *names789[];
static const uint32 types789 [] =
{
SK_BOOL,
};

static const uint16 attr_flags789 [] =
{0,};

static const EIF_TYPE_INDEX g_atype789_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes789 [] = {
g_atype789_0,
};

static const long offsets789 [] =
{
+ @CHROFF(0,0),
};

extern const char *names790[];
static const uint32 types790 [] =
{
SK_BOOL,
};

static const uint16 attr_flags790 [] =
{0,};

static const EIF_TYPE_INDEX g_atype790_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes790 [] = {
g_atype790_0,
};

static const long offsets790 [] =
{
+ @CHROFF(0,0),
};

extern const char *names791[];
static const uint32 types791 [] =
{
SK_BOOL,
};

static const uint16 attr_flags791 [] =
{0,};

static const EIF_TYPE_INDEX g_atype791_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes791 [] = {
g_atype791_0,
};

static const long offsets791 [] =
{
+ @CHROFF(0,0),
};

extern const char *names792[];
static const uint32 types792 [] =
{
SK_BOOL,
};

static const uint16 attr_flags792 [] =
{0,};

static const EIF_TYPE_INDEX g_atype792_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes792 [] = {
g_atype792_0,
};

static const long offsets792 [] =
{
+ @CHROFF(0,0),
};

extern const char *names793[];
static const uint32 types793 [] =
{
SK_BOOL,
};

static const uint16 attr_flags793 [] =
{0,};

static const EIF_TYPE_INDEX g_atype793_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes793 [] = {
g_atype793_0,
};

static const long offsets793 [] =
{
+ @CHROFF(0,0),
};

extern const char *names794[];
static const uint32 types794 [] =
{
SK_BOOL,
};

static const uint16 attr_flags794 [] =
{0,};

static const EIF_TYPE_INDEX g_atype794_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes794 [] = {
g_atype794_0,
};

static const long offsets794 [] =
{
+ @CHROFF(0,0),
};

extern const char *names795[];
static const uint32 types795 [] =
{
SK_BOOL,
};

static const uint16 attr_flags795 [] =
{0,};

static const EIF_TYPE_INDEX g_atype795_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes795 [] = {
g_atype795_0,
};

static const long offsets795 [] =
{
+ @CHROFF(0,0),
};

extern const char *names796[];
static const uint32 types796 [] =
{
SK_BOOL,
};

static const uint16 attr_flags796 [] =
{0,};

static const EIF_TYPE_INDEX g_atype796_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes796 [] = {
g_atype796_0,
};

static const long offsets796 [] =
{
+ @CHROFF(0,0),
};

extern const char *names797[];
static const uint32 types797 [] =
{
SK_BOOL,
};

static const uint16 attr_flags797 [] =
{0,};

static const EIF_TYPE_INDEX g_atype797_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes797 [] = {
g_atype797_0,
};

static const long offsets797 [] =
{
+ @CHROFF(0,0),
};

extern const char *names798[];
static const uint32 types798 [] =
{
SK_BOOL,
};

static const uint16 attr_flags798 [] =
{0,};

static const EIF_TYPE_INDEX g_atype798_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes798 [] = {
g_atype798_0,
};

static const long offsets798 [] =
{
+ @CHROFF(0,0),
};

extern const char *names799[];
static const uint32 types799 [] =
{
SK_BOOL,
};

static const uint16 attr_flags799 [] =
{0,};

static const EIF_TYPE_INDEX g_atype799_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes799 [] = {
g_atype799_0,
};

static const long offsets799 [] =
{
+ @CHROFF(0,0),
};

extern const char *names800[];
static const uint32 types800 [] =
{
SK_BOOL,
};

static const uint16 attr_flags800 [] =
{0,};

static const EIF_TYPE_INDEX g_atype800_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes800 [] = {
g_atype800_0,
};

static const long offsets800 [] =
{
+ @CHROFF(0,0),
};

extern const char *names801[];
static const uint32 types801 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags801 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype801_0 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes801 [] = {
g_atype801_0,
g_atype801_1,
g_atype801_2,
g_atype801_3,
};

static const long offsets801 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names802[];
static const uint32 types802 [] =
{
SK_BOOL,
};

static const uint16 attr_flags802 [] =
{0,};

static const EIF_TYPE_INDEX g_atype802_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes802 [] = {
g_atype802_0,
};

static const long offsets802 [] =
{
+ @CHROFF(0,0),
};

extern const char *names803[];
static const uint32 types803 [] =
{
SK_BOOL,
};

static const uint16 attr_flags803 [] =
{0,};

static const EIF_TYPE_INDEX g_atype803_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes803 [] = {
g_atype803_0,
};

static const long offsets803 [] =
{
+ @CHROFF(0,0),
};

extern const char *names804[];
static const uint32 types804 [] =
{
SK_BOOL,
};

static const uint16 attr_flags804 [] =
{0,};

static const EIF_TYPE_INDEX g_atype804_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes804 [] = {
g_atype804_0,
};

static const long offsets804 [] =
{
+ @CHROFF(0,0),
};

extern const char *names805[];
static const uint32 types805 [] =
{
SK_BOOL,
};

static const uint16 attr_flags805 [] =
{0,};

static const EIF_TYPE_INDEX g_atype805_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes805 [] = {
g_atype805_0,
};

static const long offsets805 [] =
{
+ @CHROFF(0,0),
};

extern const char *names806[];
static const uint32 types806 [] =
{
SK_BOOL,
};

static const uint16 attr_flags806 [] =
{0,};

static const EIF_TYPE_INDEX g_atype806_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes806 [] = {
g_atype806_0,
};

static const long offsets806 [] =
{
+ @CHROFF(0,0),
};

extern const char *names807[];
static const uint32 types807 [] =
{
SK_BOOL,
};

static const uint16 attr_flags807 [] =
{0,};

static const EIF_TYPE_INDEX g_atype807_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes807 [] = {
g_atype807_0,
};

static const long offsets807 [] =
{
+ @CHROFF(0,0),
};

extern const char *names808[];
static const uint32 types808 [] =
{
SK_BOOL,
};

static const uint16 attr_flags808 [] =
{0,};

static const EIF_TYPE_INDEX g_atype808_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes808 [] = {
g_atype808_0,
};

static const long offsets808 [] =
{
+ @CHROFF(0,0),
};

extern const char *names809[];
static const uint32 types809 [] =
{
SK_BOOL,
};

static const uint16 attr_flags809 [] =
{0,};

static const EIF_TYPE_INDEX g_atype809_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes809 [] = {
g_atype809_0,
};

static const long offsets809 [] =
{
+ @CHROFF(0,0),
};

extern const char *names810[];
static const uint32 types810 [] =
{
SK_BOOL,
};

static const uint16 attr_flags810 [] =
{0,};

static const EIF_TYPE_INDEX g_atype810_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes810 [] = {
g_atype810_0,
};

static const long offsets810 [] =
{
+ @CHROFF(0,0),
};

extern const char *names811[];
static const uint32 types811 [] =
{
SK_BOOL,
};

static const uint16 attr_flags811 [] =
{0,};

static const EIF_TYPE_INDEX g_atype811_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes811 [] = {
g_atype811_0,
};

static const long offsets811 [] =
{
+ @CHROFF(0,0),
};

extern const char *names812[];
static const uint32 types812 [] =
{
SK_BOOL,
};

static const uint16 attr_flags812 [] =
{0,};

static const EIF_TYPE_INDEX g_atype812_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes812 [] = {
g_atype812_0,
};

static const long offsets812 [] =
{
+ @CHROFF(0,0),
};

extern const char *names813[];
static const uint32 types813 [] =
{
SK_BOOL,
};

static const uint16 attr_flags813 [] =
{0,};

static const EIF_TYPE_INDEX g_atype813_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes813 [] = {
g_atype813_0,
};

static const long offsets813 [] =
{
+ @CHROFF(0,0),
};

extern const char *names814[];
static const uint32 types814 [] =
{
SK_BOOL,
};

static const uint16 attr_flags814 [] =
{0,};

static const EIF_TYPE_INDEX g_atype814_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes814 [] = {
g_atype814_0,
};

static const long offsets814 [] =
{
+ @CHROFF(0,0),
};

extern const char *names815[];
static const uint32 types815 [] =
{
SK_BOOL,
};

static const uint16 attr_flags815 [] =
{0,};

static const EIF_TYPE_INDEX g_atype815_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes815 [] = {
g_atype815_0,
};

static const long offsets815 [] =
{
+ @CHROFF(0,0),
};

extern const char *names816[];
static const uint32 types816 [] =
{
SK_BOOL,
};

static const uint16 attr_flags816 [] =
{0,};

static const EIF_TYPE_INDEX g_atype816_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes816 [] = {
g_atype816_0,
};

static const long offsets816 [] =
{
+ @CHROFF(0,0),
};

extern const char *names817[];
static const uint32 types817 [] =
{
SK_BOOL,
};

static const uint16 attr_flags817 [] =
{0,};

static const EIF_TYPE_INDEX g_atype817_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes817 [] = {
g_atype817_0,
};

static const long offsets817 [] =
{
+ @CHROFF(0,0),
};

extern const char *names818[];
static const uint32 types818 [] =
{
SK_BOOL,
};

static const uint16 attr_flags818 [] =
{0,};

static const EIF_TYPE_INDEX g_atype818_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes818 [] = {
g_atype818_0,
};

static const long offsets818 [] =
{
+ @CHROFF(0,0),
};

extern const char *names819[];
static const uint32 types819 [] =
{
SK_BOOL,
};

static const uint16 attr_flags819 [] =
{0,};

static const EIF_TYPE_INDEX g_atype819_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes819 [] = {
g_atype819_0,
};

static const long offsets819 [] =
{
+ @CHROFF(0,0),
};

extern const char *names820[];
static const uint32 types820 [] =
{
SK_BOOL,
};

static const uint16 attr_flags820 [] =
{0,};

static const EIF_TYPE_INDEX g_atype820_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes820 [] = {
g_atype820_0,
};

static const long offsets820 [] =
{
+ @CHROFF(0,0),
};

extern const char *names821[];
static const uint32 types821 [] =
{
SK_BOOL,
};

static const uint16 attr_flags821 [] =
{0,};

static const EIF_TYPE_INDEX g_atype821_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes821 [] = {
g_atype821_0,
};

static const long offsets821 [] =
{
+ @CHROFF(0,0),
};

extern const char *names822[];
static const uint32 types822 [] =
{
SK_BOOL,
};

static const uint16 attr_flags822 [] =
{0,};

static const EIF_TYPE_INDEX g_atype822_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes822 [] = {
g_atype822_0,
};

static const long offsets822 [] =
{
+ @CHROFF(0,0),
};

extern const char *names823[];
static const uint32 types823 [] =
{
SK_BOOL,
};

static const uint16 attr_flags823 [] =
{0,};

static const EIF_TYPE_INDEX g_atype823_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes823 [] = {
g_atype823_0,
};

static const long offsets823 [] =
{
+ @CHROFF(0,0),
};

extern const char *names824[];
static const uint32 types824 [] =
{
SK_BOOL,
};

static const uint16 attr_flags824 [] =
{0,};

static const EIF_TYPE_INDEX g_atype824_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes824 [] = {
g_atype824_0,
};

static const long offsets824 [] =
{
+ @CHROFF(0,0),
};

extern const char *names825[];
static const uint32 types825 [] =
{
SK_BOOL,
};

static const uint16 attr_flags825 [] =
{0,};

static const EIF_TYPE_INDEX g_atype825_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes825 [] = {
g_atype825_0,
};

static const long offsets825 [] =
{
+ @CHROFF(0,0),
};

extern const char *names826[];
static const uint32 types826 [] =
{
SK_BOOL,
};

static const uint16 attr_flags826 [] =
{0,};

static const EIF_TYPE_INDEX g_atype826_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes826 [] = {
g_atype826_0,
};

static const long offsets826 [] =
{
+ @CHROFF(0,0),
};

extern const char *names827[];
static const uint32 types827 [] =
{
SK_BOOL,
};

static const uint16 attr_flags827 [] =
{0,};

static const EIF_TYPE_INDEX g_atype827_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes827 [] = {
g_atype827_0,
};

static const long offsets827 [] =
{
+ @CHROFF(0,0),
};

extern const char *names828[];
static const uint32 types828 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags828 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype828_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_1 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_3 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_4 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_7 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_8 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_9 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_10 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_11 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_15 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_16 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_17 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_18 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_19 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes828 [] = {
g_atype828_0,
g_atype828_1,
g_atype828_2,
g_atype828_3,
g_atype828_4,
g_atype828_5,
g_atype828_6,
g_atype828_7,
g_atype828_8,
g_atype828_9,
g_atype828_10,
g_atype828_11,
g_atype828_12,
g_atype828_13,
g_atype828_14,
g_atype828_15,
g_atype828_16,
g_atype828_17,
g_atype828_18,
g_atype828_19,
};

static const long offsets828 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @I16OFF(3,6,0),
+ @I16OFF(3,6,1),
+ @LNGOFF(3,6,2,0),
+ @LNGOFF(3,6,2,1),
+ @LNGOFF(3,6,2,2),
+ @LNGOFF(3,6,2,3),
+ @R32OFF(3,6,2,4,0),
+ @PTROFF(3,6,2,4,1,0),
+ @I64OFF(3,6,2,4,1,1,0),
+ @I64OFF(3,6,2,4,1,1,1),
+ @R64OFF(3,6,2,4,1,1,2,0),
};

extern const char *names829[];
static const uint32 types829 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags829 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype829_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_1 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_3 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_4 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_5 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_8 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_9 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_10 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_11 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_12 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_16 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_17 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_18 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_19 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_20 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes829 [] = {
g_atype829_0,
g_atype829_1,
g_atype829_2,
g_atype829_3,
g_atype829_4,
g_atype829_5,
g_atype829_6,
g_atype829_7,
g_atype829_8,
g_atype829_9,
g_atype829_10,
g_atype829_11,
g_atype829_12,
g_atype829_13,
g_atype829_14,
g_atype829_15,
g_atype829_16,
g_atype829_17,
g_atype829_18,
g_atype829_19,
g_atype829_20,
};

static const long offsets829 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @I16OFF(4,6,0),
+ @I16OFF(4,6,1),
+ @LNGOFF(4,6,2,0),
+ @LNGOFF(4,6,2,1),
+ @LNGOFF(4,6,2,2),
+ @LNGOFF(4,6,2,3),
+ @R32OFF(4,6,2,4,0),
+ @PTROFF(4,6,2,4,1,0),
+ @I64OFF(4,6,2,4,1,1,0),
+ @I64OFF(4,6,2,4,1,1,1),
+ @R64OFF(4,6,2,4,1,1,2,0),
};

extern const char *names830[];
static const uint32 types830 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags830 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype830_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_1 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_3 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_4 [] = {62,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_5 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_6 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_10 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_11 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_12 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_13 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_14 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_17 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_18 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_19 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_20 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_21 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype830_22 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes830 [] = {
g_atype830_0,
g_atype830_1,
g_atype830_2,
g_atype830_3,
g_atype830_4,
g_atype830_5,
g_atype830_6,
g_atype830_7,
g_atype830_8,
g_atype830_9,
g_atype830_10,
g_atype830_11,
g_atype830_12,
g_atype830_13,
g_atype830_14,
g_atype830_15,
g_atype830_16,
g_atype830_17,
g_atype830_18,
g_atype830_19,
g_atype830_20,
g_atype830_21,
g_atype830_22,
};

static const long offsets830 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names839[];
static const uint32 types839 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags839 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype839_0 [] = {0xFF01,860,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype839_1 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes839 [] = {
g_atype839_0,
g_atype839_1,
};

static const long offsets839 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names852[];
static const uint32 types852 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags852 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype852_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_1 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_2 [] = {0xFF01,1140,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_3 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_4 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_6 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_16 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes852 [] = {
g_atype852_0,
g_atype852_1,
g_atype852_2,
g_atype852_3,
g_atype852_4,
g_atype852_5,
g_atype852_6,
g_atype852_7,
g_atype852_8,
g_atype852_9,
g_atype852_10,
g_atype852_11,
g_atype852_12,
g_atype852_13,
g_atype852_14,
g_atype852_15,
g_atype852_16,
};

static const long offsets852 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
+ @LNGOFF(7,3,0,1),
+ @LNGOFF(7,3,0,2),
+ @LNGOFF(7,3,0,3),
+ @LNGOFF(7,3,0,4),
+ @LNGOFF(7,3,0,5),
+ @LNGOFF(7,3,0,6),
};

extern const char *names853[];
static const uint32 types853 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags853 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype853_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_1 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_2 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_3 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_4 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_16 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes853 [] = {
g_atype853_0,
g_atype853_1,
g_atype853_2,
g_atype853_3,
g_atype853_4,
g_atype853_5,
g_atype853_6,
g_atype853_7,
g_atype853_8,
g_atype853_9,
g_atype853_10,
g_atype853_11,
g_atype853_12,
g_atype853_13,
g_atype853_14,
g_atype853_15,
g_atype853_16,
};

static const long offsets853 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
+ @LNGOFF(6,3,0,5),
+ @LNGOFF(6,3,0,6),
+ @LNGOFF(6,3,0,7),
};

extern const char *names854[];
static const uint32 types854 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags854 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype854_0 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_1 [] = {0xFF01,1140,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_2 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_3 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_16 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes854 [] = {
g_atype854_0,
g_atype854_1,
g_atype854_2,
g_atype854_3,
g_atype854_4,
g_atype854_5,
g_atype854_6,
g_atype854_7,
g_atype854_8,
g_atype854_9,
g_atype854_10,
g_atype854_11,
g_atype854_12,
g_atype854_13,
g_atype854_14,
g_atype854_15,
g_atype854_16,
};

static const long offsets854 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
+ @LNGOFF(5,5,0,1),
+ @LNGOFF(5,5,0,2),
+ @LNGOFF(5,5,0,3),
+ @LNGOFF(5,5,0,4),
+ @LNGOFF(5,5,0,5),
+ @LNGOFF(5,5,0,6),
};

extern const char *names855[];
static const uint32 types855 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags855 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype855_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_1 [] = {0xFF01,1140,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_2 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_3 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_16 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes855 [] = {
g_atype855_0,
g_atype855_1,
g_atype855_2,
g_atype855_3,
g_atype855_4,
g_atype855_5,
g_atype855_6,
g_atype855_7,
g_atype855_8,
g_atype855_9,
g_atype855_10,
g_atype855_11,
g_atype855_12,
g_atype855_13,
g_atype855_14,
g_atype855_15,
g_atype855_16,
};

static const long offsets855 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names856[];
static const uint32 types856 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags856 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype856_0 [] = {0xFF01,1145,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_1 [] = {0xFF01,1140,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_2 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_3 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_8 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_9 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_16 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes856 [] = {
g_atype856_0,
g_atype856_1,
g_atype856_2,
g_atype856_3,
g_atype856_4,
g_atype856_5,
g_atype856_6,
g_atype856_7,
g_atype856_8,
g_atype856_9,
g_atype856_10,
g_atype856_11,
g_atype856_12,
g_atype856_13,
g_atype856_14,
g_atype856_15,
g_atype856_16,
};

static const long offsets856 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names857[];
static const uint32 types857 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags857 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype857_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_1 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_2 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_3 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_16 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes857 [] = {
g_atype857_0,
g_atype857_1,
g_atype857_2,
g_atype857_3,
g_atype857_4,
g_atype857_5,
g_atype857_6,
g_atype857_7,
g_atype857_8,
g_atype857_9,
g_atype857_10,
g_atype857_11,
g_atype857_12,
g_atype857_13,
g_atype857_14,
g_atype857_15,
g_atype857_16,
};

static const long offsets857 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @LNGOFF(4,3,0,3),
+ @LNGOFF(4,3,0,4),
+ @LNGOFF(4,3,0,5),
+ @LNGOFF(4,3,0,6),
+ @LNGOFF(4,3,0,7),
+ @LNGOFF(4,3,0,8),
+ @LNGOFF(4,3,0,9),
};

extern const char *names858[];
static const uint32 types858 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_UINT8,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags858 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype858_0 [] = {0xFF01,1148,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_1 [] = {0xFF01,1140,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_2 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_3 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_8 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_9 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_16 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes858 [] = {
g_atype858_0,
g_atype858_1,
g_atype858_2,
g_atype858_3,
g_atype858_4,
g_atype858_5,
g_atype858_6,
g_atype858_7,
g_atype858_8,
g_atype858_9,
g_atype858_10,
g_atype858_11,
g_atype858_12,
g_atype858_13,
g_atype858_14,
g_atype858_15,
g_atype858_16,
};

static const long offsets858 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
+ @LNGOFF(5,5,0,1),
+ @LNGOFF(5,5,0,2),
+ @LNGOFF(5,5,0,3),
+ @LNGOFF(5,5,0,4),
+ @LNGOFF(5,5,0,5),
+ @LNGOFF(5,5,0,6),
};

extern const char *names859[];
static const uint32 types859 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags859 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype859_0 [] = {0xFF01,1149,1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_1 [] = {0xFF01,1140,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_2 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_3 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_15 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_16 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes859 [] = {
g_atype859_0,
g_atype859_1,
g_atype859_2,
g_atype859_3,
g_atype859_4,
g_atype859_5,
g_atype859_6,
g_atype859_7,
g_atype859_8,
g_atype859_9,
g_atype859_10,
g_atype859_11,
g_atype859_12,
g_atype859_13,
g_atype859_14,
g_atype859_15,
g_atype859_16,
};

static const long offsets859 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @PTROFF(5,3,0,7,0,0),
+ @PTROFF(5,3,0,7,0,1),
};

extern const char *names860[];
static const uint32 types860 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags860 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype860_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_1 [] = {0xFF01,1140,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_2 [] = {0xFF01,1140,0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_3 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_4 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_5 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_6 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_7 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_8 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_11 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_17 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_18 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes860 [] = {
g_atype860_0,
g_atype860_1,
g_atype860_2,
g_atype860_3,
g_atype860_4,
g_atype860_5,
g_atype860_6,
g_atype860_7,
g_atype860_8,
g_atype860_9,
g_atype860_10,
g_atype860_11,
g_atype860_12,
g_atype860_13,
g_atype860_14,
g_atype860_15,
g_atype860_16,
g_atype860_17,
g_atype860_18,
};

static const long offsets860 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @LNGOFF(9,3,0,0),
+ @LNGOFF(9,3,0,1),
+ @LNGOFF(9,3,0,2),
+ @LNGOFF(9,3,0,3),
+ @LNGOFF(9,3,0,4),
+ @LNGOFF(9,3,0,5),
+ @LNGOFF(9,3,0,6),
};

extern const char *names861[];
static const uint32 types861 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags861 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype861_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_1 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_2 [] = {0xFF01,1140,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_3 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_4 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_6 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_17 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes861 [] = {
g_atype861_0,
g_atype861_1,
g_atype861_2,
g_atype861_3,
g_atype861_4,
g_atype861_5,
g_atype861_6,
g_atype861_7,
g_atype861_8,
g_atype861_9,
g_atype861_10,
g_atype861_11,
g_atype861_12,
g_atype861_13,
g_atype861_14,
g_atype861_15,
g_atype861_16,
g_atype861_17,
};

static const long offsets861 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @LNGOFF(7,4,0,0),
+ @LNGOFF(7,4,0,1),
+ @LNGOFF(7,4,0,2),
+ @LNGOFF(7,4,0,3),
+ @LNGOFF(7,4,0,4),
+ @LNGOFF(7,4,0,5),
+ @LNGOFF(7,4,0,6),
};

extern const char *names862[];
static const uint32 types862 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags862 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype862_0 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_1 [] = {0xFF01,1140,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_2 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_3 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_4 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_17 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes862 [] = {
g_atype862_0,
g_atype862_1,
g_atype862_2,
g_atype862_3,
g_atype862_4,
g_atype862_5,
g_atype862_6,
g_atype862_7,
g_atype862_8,
g_atype862_9,
g_atype862_10,
g_atype862_11,
g_atype862_12,
g_atype862_13,
g_atype862_14,
g_atype862_15,
g_atype862_16,
g_atype862_17,
};

static const long offsets862 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @LNGOFF(5,6,0,0),
+ @LNGOFF(5,6,0,1),
+ @LNGOFF(5,6,0,2),
+ @LNGOFF(5,6,0,3),
+ @LNGOFF(5,6,0,4),
+ @LNGOFF(5,6,0,5),
+ @LNGOFF(5,6,0,6),
};

extern const char *names863[];
static const uint32 types863 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags863 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype863_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_1 [] = {0xFF01,1140,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_2 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_3 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_4 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_17 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes863 [] = {
g_atype863_0,
g_atype863_1,
g_atype863_2,
g_atype863_3,
g_atype863_4,
g_atype863_5,
g_atype863_6,
g_atype863_7,
g_atype863_8,
g_atype863_9,
g_atype863_10,
g_atype863_11,
g_atype863_12,
g_atype863_13,
g_atype863_14,
g_atype863_15,
g_atype863_16,
g_atype863_17,
};

static const long offsets863 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names864[];
static const uint32 types864 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags864 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype864_0 [] = {0xFF01,1145,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_1 [] = {0xFF01,1140,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_2 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_3 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_4 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_9 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_10 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_17 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes864 [] = {
g_atype864_0,
g_atype864_1,
g_atype864_2,
g_atype864_3,
g_atype864_4,
g_atype864_5,
g_atype864_6,
g_atype864_7,
g_atype864_8,
g_atype864_9,
g_atype864_10,
g_atype864_11,
g_atype864_12,
g_atype864_13,
g_atype864_14,
g_atype864_15,
g_atype864_16,
g_atype864_17,
};

static const long offsets864 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names865[];
static const uint32 types865 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_UINT8,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags865 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype865_0 [] = {0xFF01,1148,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_1 [] = {0xFF01,1140,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_2 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_3 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_4 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_9 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_10 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_17 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes865 [] = {
g_atype865_0,
g_atype865_1,
g_atype865_2,
g_atype865_3,
g_atype865_4,
g_atype865_5,
g_atype865_6,
g_atype865_7,
g_atype865_8,
g_atype865_9,
g_atype865_10,
g_atype865_11,
g_atype865_12,
g_atype865_13,
g_atype865_14,
g_atype865_15,
g_atype865_16,
g_atype865_17,
};

static const long offsets865 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @LNGOFF(5,6,0,0),
+ @LNGOFF(5,6,0,1),
+ @LNGOFF(5,6,0,2),
+ @LNGOFF(5,6,0,3),
+ @LNGOFF(5,6,0,4),
+ @LNGOFF(5,6,0,5),
+ @LNGOFF(5,6,0,6),
};

extern const char *names866[];
static const uint32 types866 [] =
{
SK_BOOL,
};

static const uint16 attr_flags866 [] =
{0,};

static const EIF_TYPE_INDEX g_atype866_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes866 [] = {
g_atype866_0,
};

static const long offsets866 [] =
{
+ @CHROFF(0,0),
};

extern const char *names867[];
static const uint32 types867 [] =
{
SK_BOOL,
};

static const uint16 attr_flags867 [] =
{0,};

static const EIF_TYPE_INDEX g_atype867_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes867 [] = {
g_atype867_0,
};

static const long offsets867 [] =
{
+ @CHROFF(0,0),
};

extern const char *names868[];
static const uint32 types868 [] =
{
SK_BOOL,
};

static const uint16 attr_flags868 [] =
{0,};

static const EIF_TYPE_INDEX g_atype868_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes868 [] = {
g_atype868_0,
};

static const long offsets868 [] =
{
+ @CHROFF(0,0),
};

extern const char *names869[];
static const uint32 types869 [] =
{
SK_BOOL,
};

static const uint16 attr_flags869 [] =
{0,};

static const EIF_TYPE_INDEX g_atype869_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes869 [] = {
g_atype869_0,
};

static const long offsets869 [] =
{
+ @CHROFF(0,0),
};

extern const char *names870[];
static const uint32 types870 [] =
{
SK_BOOL,
};

static const uint16 attr_flags870 [] =
{0,};

static const EIF_TYPE_INDEX g_atype870_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes870 [] = {
g_atype870_0,
};

static const long offsets870 [] =
{
+ @CHROFF(0,0),
};

extern const char *names871[];
static const uint32 types871 [] =
{
SK_BOOL,
};

static const uint16 attr_flags871 [] =
{0,};

static const EIF_TYPE_INDEX g_atype871_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes871 [] = {
g_atype871_0,
};

static const long offsets871 [] =
{
+ @CHROFF(0,0),
};

extern const char *names872[];
static const uint32 types872 [] =
{
SK_BOOL,
};

static const uint16 attr_flags872 [] =
{0,};

static const EIF_TYPE_INDEX g_atype872_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes872 [] = {
g_atype872_0,
};

static const long offsets872 [] =
{
+ @CHROFF(0,0),
};

extern const char *names873[];
static const uint32 types873 [] =
{
SK_BOOL,
};

static const uint16 attr_flags873 [] =
{0,};

static const EIF_TYPE_INDEX g_atype873_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes873 [] = {
g_atype873_0,
};

static const long offsets873 [] =
{
+ @CHROFF(0,0),
};

extern const char *names874[];
static const uint32 types874 [] =
{
SK_BOOL,
};

static const uint16 attr_flags874 [] =
{0,};

static const EIF_TYPE_INDEX g_atype874_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes874 [] = {
g_atype874_0,
};

static const long offsets874 [] =
{
+ @CHROFF(0,0),
};

extern const char *names875[];
static const uint32 types875 [] =
{
SK_BOOL,
};

static const uint16 attr_flags875 [] =
{0,};

static const EIF_TYPE_INDEX g_atype875_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes875 [] = {
g_atype875_0,
};

static const long offsets875 [] =
{
+ @CHROFF(0,0),
};

extern const char *names876[];
static const uint32 types876 [] =
{
SK_BOOL,
};

static const uint16 attr_flags876 [] =
{0,};

static const EIF_TYPE_INDEX g_atype876_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes876 [] = {
g_atype876_0,
};

static const long offsets876 [] =
{
+ @CHROFF(0,0),
};

extern const char *names877[];
static const uint32 types877 [] =
{
SK_BOOL,
};

static const uint16 attr_flags877 [] =
{0,};

static const EIF_TYPE_INDEX g_atype877_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes877 [] = {
g_atype877_0,
};

static const long offsets877 [] =
{
+ @CHROFF(0,0),
};

extern const char *names878[];
static const uint32 types878 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags878 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype878_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype878_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype878_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes878 [] = {
g_atype878_0,
g_atype878_1,
g_atype878_2,
};

static const long offsets878 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
};

extern const char *names879[];
static const uint32 types879 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags879 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype879_0 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype879_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype879_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype879_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes879 [] = {
g_atype879_0,
g_atype879_1,
g_atype879_2,
g_atype879_3,
};

static const long offsets879 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names880[];
static const uint32 types880 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags880 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype880_0 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes880 [] = {
g_atype880_0,
g_atype880_1,
g_atype880_2,
g_atype880_3,
};

static const long offsets880 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names881[];
static const uint32 types881 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags881 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype881_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype881_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype881_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype881_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes881 [] = {
g_atype881_0,
g_atype881_1,
g_atype881_2,
g_atype881_3,
};

static const long offsets881 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names882[];
static const uint32 types882 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags882 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype882_0 [] = {0xFF01,1143,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes882 [] = {
g_atype882_0,
g_atype882_1,
g_atype882_2,
g_atype882_3,
};

static const long offsets882 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names883[];
static const uint32 types883 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags883 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype883_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes883 [] = {
g_atype883_0,
g_atype883_1,
g_atype883_2,
g_atype883_3,
};

static const long offsets883 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names884[];
static const uint32 types884 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags884 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype884_0 [] = {0xFF01,1145,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes884 [] = {
g_atype884_0,
g_atype884_1,
g_atype884_2,
g_atype884_3,
};

static const long offsets884 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names885[];
static const uint32 types885 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags885 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype885_0 [] = {0xFF01,1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes885 [] = {
g_atype885_0,
g_atype885_1,
g_atype885_2,
g_atype885_3,
};

static const long offsets885 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names886[];
static const uint32 types886 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags886 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype886_0 [] = {0xFF01,1147,1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes886 [] = {
g_atype886_0,
g_atype886_1,
g_atype886_2,
g_atype886_3,
};

static const long offsets886 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names887[];
static const uint32 types887 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags887 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype887_0 [] = {0xFF01,1148,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes887 [] = {
g_atype887_0,
g_atype887_1,
g_atype887_2,
g_atype887_3,
};

static const long offsets887 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names888[];
static const uint32 types888 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags888 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype888_0 [] = {0xFF01,1149,1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes888 [] = {
g_atype888_0,
g_atype888_1,
g_atype888_2,
g_atype888_3,
};

static const long offsets888 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names889[];
static const uint32 types889 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags889 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype889_0 [] = {0xFF01,1150,1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes889 [] = {
g_atype889_0,
g_atype889_1,
g_atype889_2,
g_atype889_3,
};

static const long offsets889 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names890[];
static const uint32 types890 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags890 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype890_0 [] = {0xFF01,1151,1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes890 [] = {
g_atype890_0,
g_atype890_1,
g_atype890_2,
g_atype890_3,
};

static const long offsets890 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names891[];
static const uint32 types891 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags891 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype891_0 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes891 [] = {
g_atype891_0,
g_atype891_1,
g_atype891_2,
g_atype891_3,
};

static const long offsets891 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names892[];
static const uint32 types892 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags892 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype892_0 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes892 [] = {
g_atype892_0,
g_atype892_1,
g_atype892_2,
g_atype892_3,
};

static const long offsets892 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names893[];
static const uint32 types893 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags893 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype893_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes893 [] = {
g_atype893_0,
g_atype893_1,
g_atype893_2,
g_atype893_3,
};

static const long offsets893 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names894[];
static const uint32 types894 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags894 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype894_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes894 [] = {
g_atype894_0,
g_atype894_1,
g_atype894_2,
g_atype894_3,
};

static const long offsets894 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names895[];
static const uint32 types895 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags895 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype895_0 [] = {0xFF01,1145,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes895 [] = {
g_atype895_0,
g_atype895_1,
g_atype895_2,
g_atype895_3,
};

static const long offsets895 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names896[];
static const uint32 types896 [] =
{
SK_BOOL,
};

static const uint16 attr_flags896 [] =
{0,};

static const EIF_TYPE_INDEX g_atype896_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes896 [] = {
g_atype896_0,
};

static const long offsets896 [] =
{
+ @CHROFF(0,0),
};

extern const char *names897[];
static const uint32 types897 [] =
{
SK_BOOL,
};

static const uint16 attr_flags897 [] =
{0,};

static const EIF_TYPE_INDEX g_atype897_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes897 [] = {
g_atype897_0,
};

static const long offsets897 [] =
{
+ @CHROFF(0,0),
};

extern const char *names898[];
static const uint32 types898 [] =
{
SK_BOOL,
};

static const uint16 attr_flags898 [] =
{0,};

static const EIF_TYPE_INDEX g_atype898_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes898 [] = {
g_atype898_0,
};

static const long offsets898 [] =
{
+ @CHROFF(0,0),
};

extern const char *names899[];
static const uint32 types899 [] =
{
SK_BOOL,
};

static const uint16 attr_flags899 [] =
{0,};

static const EIF_TYPE_INDEX g_atype899_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes899 [] = {
g_atype899_0,
};

static const long offsets899 [] =
{
+ @CHROFF(0,0),
};

extern const char *names900[];
static const uint32 types900 [] =
{
SK_BOOL,
};

static const uint16 attr_flags900 [] =
{0,};

static const EIF_TYPE_INDEX g_atype900_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes900 [] = {
g_atype900_0,
};

static const long offsets900 [] =
{
+ @CHROFF(0,0),
};

extern const char *names901[];
static const uint32 types901 [] =
{
SK_BOOL,
};

static const uint16 attr_flags901 [] =
{0,};

static const EIF_TYPE_INDEX g_atype901_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes901 [] = {
g_atype901_0,
};

static const long offsets901 [] =
{
+ @CHROFF(0,0),
};

extern const char *names902[];
static const uint32 types902 [] =
{
SK_BOOL,
};

static const uint16 attr_flags902 [] =
{0,};

static const EIF_TYPE_INDEX g_atype902_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes902 [] = {
g_atype902_0,
};

static const long offsets902 [] =
{
+ @CHROFF(0,0),
};

extern const char *names903[];
static const uint32 types903 [] =
{
SK_BOOL,
};

static const uint16 attr_flags903 [] =
{0,};

static const EIF_TYPE_INDEX g_atype903_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes903 [] = {
g_atype903_0,
};

static const long offsets903 [] =
{
+ @CHROFF(0,0),
};

extern const char *names904[];
static const uint32 types904 [] =
{
SK_BOOL,
};

static const uint16 attr_flags904 [] =
{0,};

static const EIF_TYPE_INDEX g_atype904_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes904 [] = {
g_atype904_0,
};

static const long offsets904 [] =
{
+ @CHROFF(0,0),
};

extern const char *names905[];
static const uint32 types905 [] =
{
SK_BOOL,
};

static const uint16 attr_flags905 [] =
{0,};

static const EIF_TYPE_INDEX g_atype905_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes905 [] = {
g_atype905_0,
};

static const long offsets905 [] =
{
+ @CHROFF(0,0),
};

extern const char *names906[];
static const uint32 types906 [] =
{
SK_BOOL,
};

static const uint16 attr_flags906 [] =
{0,};

static const EIF_TYPE_INDEX g_atype906_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes906 [] = {
g_atype906_0,
};

static const long offsets906 [] =
{
+ @CHROFF(0,0),
};

extern const char *names907[];
static const uint32 types907 [] =
{
SK_BOOL,
};

static const uint16 attr_flags907 [] =
{0,};

static const EIF_TYPE_INDEX g_atype907_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes907 [] = {
g_atype907_0,
};

static const long offsets907 [] =
{
+ @CHROFF(0,0),
};

extern const char *names908[];
static const uint32 types908 [] =
{
SK_BOOL,
};

static const uint16 attr_flags908 [] =
{0,};

static const EIF_TYPE_INDEX g_atype908_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes908 [] = {
g_atype908_0,
};

static const long offsets908 [] =
{
+ @CHROFF(0,0),
};

extern const char *names909[];
static const uint32 types909 [] =
{
SK_BOOL,
};

static const uint16 attr_flags909 [] =
{0,};

static const EIF_TYPE_INDEX g_atype909_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes909 [] = {
g_atype909_0,
};

static const long offsets909 [] =
{
+ @CHROFF(0,0),
};

extern const char *names910[];
static const uint32 types910 [] =
{
SK_BOOL,
};

static const uint16 attr_flags910 [] =
{0,};

static const EIF_TYPE_INDEX g_atype910_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes910 [] = {
g_atype910_0,
};

static const long offsets910 [] =
{
+ @CHROFF(0,0),
};

extern const char *names911[];
static const uint32 types911 [] =
{
SK_BOOL,
};

static const uint16 attr_flags911 [] =
{0,};

static const EIF_TYPE_INDEX g_atype911_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes911 [] = {
g_atype911_0,
};

static const long offsets911 [] =
{
+ @CHROFF(0,0),
};

extern const char *names912[];
static const uint32 types912 [] =
{
SK_BOOL,
};

static const uint16 attr_flags912 [] =
{0,};

static const EIF_TYPE_INDEX g_atype912_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes912 [] = {
g_atype912_0,
};

static const long offsets912 [] =
{
+ @CHROFF(0,0),
};

extern const char *names913[];
static const uint32 types913 [] =
{
SK_BOOL,
};

static const uint16 attr_flags913 [] =
{0,};

static const EIF_TYPE_INDEX g_atype913_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes913 [] = {
g_atype913_0,
};

static const long offsets913 [] =
{
+ @CHROFF(0,0),
};

extern const char *names914[];
static const uint32 types914 [] =
{
SK_BOOL,
};

static const uint16 attr_flags914 [] =
{0,};

static const EIF_TYPE_INDEX g_atype914_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes914 [] = {
g_atype914_0,
};

static const long offsets914 [] =
{
+ @CHROFF(0,0),
};

extern const char *names915[];
static const uint32 types915 [] =
{
SK_BOOL,
};

static const uint16 attr_flags915 [] =
{0,};

static const EIF_TYPE_INDEX g_atype915_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes915 [] = {
g_atype915_0,
};

static const long offsets915 [] =
{
+ @CHROFF(0,0),
};

extern const char *names916[];
static const uint32 types916 [] =
{
SK_BOOL,
};

static const uint16 attr_flags916 [] =
{0,};

static const EIF_TYPE_INDEX g_atype916_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes916 [] = {
g_atype916_0,
};

static const long offsets916 [] =
{
+ @CHROFF(0,0),
};

extern const char *names917[];
static const uint32 types917 [] =
{
SK_BOOL,
};

static const uint16 attr_flags917 [] =
{0,};

static const EIF_TYPE_INDEX g_atype917_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes917 [] = {
g_atype917_0,
};

static const long offsets917 [] =
{
+ @CHROFF(0,0),
};

extern const char *names918[];
static const uint32 types918 [] =
{
SK_BOOL,
};

static const uint16 attr_flags918 [] =
{0,};

static const EIF_TYPE_INDEX g_atype918_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes918 [] = {
g_atype918_0,
};

static const long offsets918 [] =
{
+ @CHROFF(0,0),
};

extern const char *names919[];
static const uint32 types919 [] =
{
SK_BOOL,
};

static const uint16 attr_flags919 [] =
{0,};

static const EIF_TYPE_INDEX g_atype919_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes919 [] = {
g_atype919_0,
};

static const long offsets919 [] =
{
+ @CHROFF(0,0),
};

extern const char *names920[];
static const uint32 types920 [] =
{
SK_BOOL,
};

static const uint16 attr_flags920 [] =
{0,};

static const EIF_TYPE_INDEX g_atype920_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes920 [] = {
g_atype920_0,
};

static const long offsets920 [] =
{
+ @CHROFF(0,0),
};

extern const char *names921[];
static const uint32 types921 [] =
{
SK_BOOL,
};

static const uint16 attr_flags921 [] =
{0,};

static const EIF_TYPE_INDEX g_atype921_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes921 [] = {
g_atype921_0,
};

static const long offsets921 [] =
{
+ @CHROFF(0,0),
};

extern const char *names922[];
static const uint32 types922 [] =
{
SK_BOOL,
};

static const uint16 attr_flags922 [] =
{0,};

static const EIF_TYPE_INDEX g_atype922_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes922 [] = {
g_atype922_0,
};

static const long offsets922 [] =
{
+ @CHROFF(0,0),
};

extern const char *names923[];
static const uint32 types923 [] =
{
SK_BOOL,
};

static const uint16 attr_flags923 [] =
{0,};

static const EIF_TYPE_INDEX g_atype923_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes923 [] = {
g_atype923_0,
};

static const long offsets923 [] =
{
+ @CHROFF(0,0),
};

extern const char *names924[];
static const uint32 types924 [] =
{
SK_BOOL,
};

static const uint16 attr_flags924 [] =
{0,};

static const EIF_TYPE_INDEX g_atype924_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes924 [] = {
g_atype924_0,
};

static const long offsets924 [] =
{
+ @CHROFF(0,0),
};

extern const char *names925[];
static const uint32 types925 [] =
{
SK_BOOL,
};

static const uint16 attr_flags925 [] =
{0,};

static const EIF_TYPE_INDEX g_atype925_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes925 [] = {
g_atype925_0,
};

static const long offsets925 [] =
{
+ @CHROFF(0,0),
};

extern const char *names926[];
static const uint32 types926 [] =
{
SK_BOOL,
};

static const uint16 attr_flags926 [] =
{0,};

static const EIF_TYPE_INDEX g_atype926_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes926 [] = {
g_atype926_0,
};

static const long offsets926 [] =
{
+ @CHROFF(0,0),
};

extern const char *names927[];
static const uint32 types927 [] =
{
SK_BOOL,
};

static const uint16 attr_flags927 [] =
{0,};

static const EIF_TYPE_INDEX g_atype927_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes927 [] = {
g_atype927_0,
};

static const long offsets927 [] =
{
+ @CHROFF(0,0),
};

extern const char *names928[];
static const uint32 types928 [] =
{
SK_BOOL,
};

static const uint16 attr_flags928 [] =
{0,};

static const EIF_TYPE_INDEX g_atype928_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes928 [] = {
g_atype928_0,
};

static const long offsets928 [] =
{
+ @CHROFF(0,0),
};

extern const char *names929[];
static const uint32 types929 [] =
{
SK_BOOL,
};

static const uint16 attr_flags929 [] =
{0,};

static const EIF_TYPE_INDEX g_atype929_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes929 [] = {
g_atype929_0,
};

static const long offsets929 [] =
{
+ @CHROFF(0,0),
};

extern const char *names930[];
static const uint32 types930 [] =
{
SK_BOOL,
};

static const uint16 attr_flags930 [] =
{0,};

static const EIF_TYPE_INDEX g_atype930_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes930 [] = {
g_atype930_0,
};

static const long offsets930 [] =
{
+ @CHROFF(0,0),
};

extern const char *names931[];
static const uint32 types931 [] =
{
SK_BOOL,
};

static const uint16 attr_flags931 [] =
{0,};

static const EIF_TYPE_INDEX g_atype931_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes931 [] = {
g_atype931_0,
};

static const long offsets931 [] =
{
+ @CHROFF(0,0),
};

extern const char *names932[];
static const uint32 types932 [] =
{
SK_BOOL,
};

static const uint16 attr_flags932 [] =
{0,};

static const EIF_TYPE_INDEX g_atype932_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes932 [] = {
g_atype932_0,
};

static const long offsets932 [] =
{
+ @CHROFF(0,0),
};

extern const char *names933[];
static const uint32 types933 [] =
{
SK_BOOL,
};

static const uint16 attr_flags933 [] =
{0,};

static const EIF_TYPE_INDEX g_atype933_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes933 [] = {
g_atype933_0,
};

static const long offsets933 [] =
{
+ @CHROFF(0,0),
};

extern const char *names934[];
static const uint32 types934 [] =
{
SK_BOOL,
};

static const uint16 attr_flags934 [] =
{0,};

static const EIF_TYPE_INDEX g_atype934_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes934 [] = {
g_atype934_0,
};

static const long offsets934 [] =
{
+ @CHROFF(0,0),
};

extern const char *names935[];
static const uint32 types935 [] =
{
SK_BOOL,
};

static const uint16 attr_flags935 [] =
{0,};

static const EIF_TYPE_INDEX g_atype935_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes935 [] = {
g_atype935_0,
};

static const long offsets935 [] =
{
+ @CHROFF(0,0),
};

extern const char *names936[];
static const uint32 types936 [] =
{
SK_BOOL,
};

static const uint16 attr_flags936 [] =
{0,};

static const EIF_TYPE_INDEX g_atype936_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes936 [] = {
g_atype936_0,
};

static const long offsets936 [] =
{
+ @CHROFF(0,0),
};

extern const char *names937[];
static const uint32 types937 [] =
{
SK_BOOL,
};

static const uint16 attr_flags937 [] =
{0,};

static const EIF_TYPE_INDEX g_atype937_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes937 [] = {
g_atype937_0,
};

static const long offsets937 [] =
{
+ @CHROFF(0,0),
};

extern const char *names938[];
static const uint32 types938 [] =
{
SK_BOOL,
};

static const uint16 attr_flags938 [] =
{0,};

static const EIF_TYPE_INDEX g_atype938_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes938 [] = {
g_atype938_0,
};

static const long offsets938 [] =
{
+ @CHROFF(0,0),
};

extern const char *names939[];
static const uint32 types939 [] =
{
SK_BOOL,
};

static const uint16 attr_flags939 [] =
{0,};

static const EIF_TYPE_INDEX g_atype939_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes939 [] = {
g_atype939_0,
};

static const long offsets939 [] =
{
+ @CHROFF(0,0),
};

extern const char *names940[];
static const uint32 types940 [] =
{
SK_BOOL,
};

static const uint16 attr_flags940 [] =
{0,};

static const EIF_TYPE_INDEX g_atype940_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes940 [] = {
g_atype940_0,
};

static const long offsets940 [] =
{
+ @CHROFF(0,0),
};

extern const char *names941[];
static const uint32 types941 [] =
{
SK_BOOL,
};

static const uint16 attr_flags941 [] =
{0,};

static const EIF_TYPE_INDEX g_atype941_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes941 [] = {
g_atype941_0,
};

static const long offsets941 [] =
{
+ @CHROFF(0,0),
};

extern const char *names942[];
static const uint32 types942 [] =
{
SK_BOOL,
};

static const uint16 attr_flags942 [] =
{0,};

static const EIF_TYPE_INDEX g_atype942_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes942 [] = {
g_atype942_0,
};

static const long offsets942 [] =
{
+ @CHROFF(0,0),
};

extern const char *names943[];
static const uint32 types943 [] =
{
SK_BOOL,
};

static const uint16 attr_flags943 [] =
{0,};

static const EIF_TYPE_INDEX g_atype943_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes943 [] = {
g_atype943_0,
};

static const long offsets943 [] =
{
+ @CHROFF(0,0),
};

extern const char *names944[];
static const uint32 types944 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags944 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype944_0 [] = {194,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_1 [] = {194,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes944 [] = {
g_atype944_0,
g_atype944_1,
g_atype944_2,
g_atype944_3,
g_atype944_4,
g_atype944_5,
};

static const long offsets944 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names945[];
static const uint32 types945 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags945 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype945_0 [] = {195,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype945_1 [] = {195,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype945_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype945_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype945_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype945_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes945 [] = {
g_atype945_0,
g_atype945_1,
g_atype945_2,
g_atype945_3,
g_atype945_4,
g_atype945_5,
};

static const long offsets945 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names946[];
static const uint32 types946 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags946 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype946_0 [] = {194,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_1 [] = {194,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes946 [] = {
g_atype946_0,
g_atype946_1,
g_atype946_2,
g_atype946_3,
g_atype946_4,
g_atype946_5,
};

static const long offsets946 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names947[];
static const uint32 types947 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags947 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype947_0 [] = {195,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_1 [] = {195,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes947 [] = {
g_atype947_0,
g_atype947_1,
g_atype947_2,
g_atype947_3,
g_atype947_4,
g_atype947_5,
};

static const long offsets947 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names948[];
static const uint32 types948 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags948 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype948_0 [] = {194,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_1 [] = {194,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes948 [] = {
g_atype948_0,
g_atype948_1,
g_atype948_2,
g_atype948_3,
g_atype948_4,
g_atype948_5,
};

static const long offsets948 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names949[];
static const uint32 types949 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags949 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype949_0 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype949_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype949_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes949 [] = {
g_atype949_0,
g_atype949_1,
g_atype949_2,
};

static const long offsets949 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names950[];
static const uint32 types950 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags950 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype950_0 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype950_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype950_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes950 [] = {
g_atype950_0,
g_atype950_1,
g_atype950_2,
};

static const long offsets950 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names951[];
static const uint32 types951 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags951 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype951_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype951_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype951_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes951 [] = {
g_atype951_0,
g_atype951_1,
g_atype951_2,
};

static const long offsets951 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names952[];
static const uint32 types952 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags952 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype952_0 [] = {0xFF01,1143,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype952_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype952_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes952 [] = {
g_atype952_0,
g_atype952_1,
g_atype952_2,
};

static const long offsets952 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names953[];
static const uint32 types953 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags953 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype953_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype953_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype953_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes953 [] = {
g_atype953_0,
g_atype953_1,
g_atype953_2,
};

static const long offsets953 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names954[];
static const uint32 types954 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags954 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype954_0 [] = {0xFF01,1145,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes954 [] = {
g_atype954_0,
g_atype954_1,
g_atype954_2,
};

static const long offsets954 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names955[];
static const uint32 types955 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags955 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype955_0 [] = {0xFF01,1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes955 [] = {
g_atype955_0,
g_atype955_1,
g_atype955_2,
};

static const long offsets955 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names956[];
static const uint32 types956 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags956 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype956_0 [] = {0xFF01,1147,1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes956 [] = {
g_atype956_0,
g_atype956_1,
g_atype956_2,
};

static const long offsets956 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names957[];
static const uint32 types957 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags957 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype957_0 [] = {0xFF01,1148,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype957_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype957_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes957 [] = {
g_atype957_0,
g_atype957_1,
g_atype957_2,
};

static const long offsets957 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names958[];
static const uint32 types958 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags958 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype958_0 [] = {0xFF01,1149,1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype958_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype958_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes958 [] = {
g_atype958_0,
g_atype958_1,
g_atype958_2,
};

static const long offsets958 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names959[];
static const uint32 types959 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags959 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype959_0 [] = {0xFF01,1150,1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype959_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype959_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes959 [] = {
g_atype959_0,
g_atype959_1,
g_atype959_2,
};

static const long offsets959 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names960[];
static const uint32 types960 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags960 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype960_0 [] = {0xFF01,1151,1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype960_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype960_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes960 [] = {
g_atype960_0,
g_atype960_1,
g_atype960_2,
};

static const long offsets960 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names961[];
static const uint32 types961 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags961 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype961_0 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype961_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes961 [] = {
g_atype961_0,
g_atype961_1,
g_atype961_2,
};

static const long offsets961 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names962[];
static const uint32 types962 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags962 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype962_0 [] = {0xFF01,1140,0xFF01,1300,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype962_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes962 [] = {
g_atype962_0,
g_atype962_1,
g_atype962_2,
};

static const long offsets962 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names963[];
static const uint32 types963 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags963 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype963_0 [] = {0xFF01,1140,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype963_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes963 [] = {
g_atype963_0,
g_atype963_1,
g_atype963_2,
};

static const long offsets963 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names964[];
static const uint32 types964 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags964 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype964_0 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype964_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes964 [] = {
g_atype964_0,
g_atype964_1,
g_atype964_2,
};

static const long offsets964 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names965[];
static const uint32 types965 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags965 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype965_0 [] = {0xFF01,1140,0xFF01,964,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_2 [] = {0xFF01,860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_3 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_4 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype965_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes965 [] = {
g_atype965_0,
g_atype965_1,
g_atype965_2,
g_atype965_3,
g_atype965_4,
g_atype965_5,
g_atype965_6,
};

static const long offsets965 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names967[];
static const uint32 types967 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags967 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype967_0 [] = {309,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_2 [] = {1015,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_3 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_4 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_5 [] = {1288,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_6 [] = {1287,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_7 [] = {0xFF01,397,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_8 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_9 [] = {1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_10 [] = {1155,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_11 [] = {1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_12 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_13 [] = {1159,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_14 [] = {1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_15 [] = {405,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_16 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_17 [] = {407,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_18 [] = {406,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_19 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_20 [] = {1300,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_21 [] = {0xFF01,946,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_22 [] = {0xFF01,852,0xFF01,1086,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_23 [] = {0xFF01,860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_24 [] = {0xFF01,945,0xFF01,964,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_25 [] = {854,1219,0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_26 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_27 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_28 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_29 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes967 [] = {
g_atype967_0,
g_atype967_1,
g_atype967_2,
g_atype967_3,
g_atype967_4,
g_atype967_5,
g_atype967_6,
g_atype967_7,
g_atype967_8,
g_atype967_9,
g_atype967_10,
g_atype967_11,
g_atype967_12,
g_atype967_13,
g_atype967_14,
g_atype967_15,
g_atype967_16,
g_atype967_17,
g_atype967_18,
g_atype967_19,
g_atype967_20,
g_atype967_21,
g_atype967_22,
g_atype967_23,
g_atype967_24,
g_atype967_25,
g_atype967_26,
g_atype967_27,
g_atype967_28,
g_atype967_29,
};

static const long offsets967 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
+ @CHROFF(26,0),
+ @CHROFF(26,1),
+ @CHROFF(26,2),
+ @LNGOFF(26,3,0,0),
};

extern const char *names968[];
static const uint32 types968 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags968 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype968_0 [] = {0xFF01,397,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_1 [] = {54,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_2 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_3 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_4 [] = {0xFF01,948,0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_5 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes968 [] = {
g_atype968_0,
g_atype968_1,
g_atype968_2,
g_atype968_3,
g_atype968_4,
g_atype968_5,
};

static const long offsets968 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
};

extern const char *names969[];
static const uint32 types969 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags969 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype969_0 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_1 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_2 [] = {1288,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_3 [] = {1287,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_4 [] = {1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_5 [] = {1099,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_6 [] = {1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_7 [] = {0xFF01,397,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_11 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes969 [] = {
g_atype969_0,
g_atype969_1,
g_atype969_2,
g_atype969_3,
g_atype969_4,
g_atype969_5,
g_atype969_6,
g_atype969_7,
g_atype969_8,
g_atype969_9,
g_atype969_10,
g_atype969_11,
};

static const long offsets969 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
};

extern const char *names970[];
static const uint32 types970 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags970 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype970_0 [] = {67,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_2 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_3 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_4 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_5 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_6 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_7 [] = {861,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_8 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_9 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_10 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_11 [] = {861,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_12 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_13 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_14 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_15 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_16 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_17 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_19 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_20 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_21 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_22 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_23 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_24 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_25 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_26 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_27 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_28 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_29 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes970 [] = {
g_atype970_0,
g_atype970_1,
g_atype970_2,
g_atype970_3,
g_atype970_4,
g_atype970_5,
g_atype970_6,
g_atype970_7,
g_atype970_8,
g_atype970_9,
g_atype970_10,
g_atype970_11,
g_atype970_12,
g_atype970_13,
g_atype970_14,
g_atype970_15,
g_atype970_16,
g_atype970_17,
g_atype970_18,
g_atype970_19,
g_atype970_20,
g_atype970_21,
g_atype970_22,
g_atype970_23,
g_atype970_24,
g_atype970_25,
g_atype970_26,
g_atype970_27,
g_atype970_28,
g_atype970_29,
};

static const long offsets970 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @CHROFF(12,16),
+ @CHROFF(12,17),
};

extern const char *names971[];
static const uint32 types971 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags971 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype971_0 [] = {67,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_2 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_3 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_4 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_5 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_6 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_7 [] = {861,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_8 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_9 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_10 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_11 [] = {861,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_12 [] = {0xFF01,1095,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_13 [] = {0xFF01,1095,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_14 [] = {0xFF01,1095,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_15 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_16 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_17 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_19 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_20 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_21 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_22 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_23 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_24 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_25 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_26 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_27 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_28 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_29 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_30 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_31 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_32 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_33 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_34 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_35 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes971 [] = {
g_atype971_0,
g_atype971_1,
g_atype971_2,
g_atype971_3,
g_atype971_4,
g_atype971_5,
g_atype971_6,
g_atype971_7,
g_atype971_8,
g_atype971_9,
g_atype971_10,
g_atype971_11,
g_atype971_12,
g_atype971_13,
g_atype971_14,
g_atype971_15,
g_atype971_16,
g_atype971_17,
g_atype971_18,
g_atype971_19,
g_atype971_20,
g_atype971_21,
g_atype971_22,
g_atype971_23,
g_atype971_24,
g_atype971_25,
g_atype971_26,
g_atype971_27,
g_atype971_28,
g_atype971_29,
g_atype971_30,
g_atype971_31,
g_atype971_32,
g_atype971_33,
g_atype971_34,
g_atype971_35,
};

static const long offsets971 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
+ @CHROFF(18,0),
+ @CHROFF(18,1),
+ @CHROFF(18,2),
+ @CHROFF(18,3),
+ @CHROFF(18,4),
+ @CHROFF(18,5),
+ @CHROFF(18,6),
+ @CHROFF(18,7),
+ @CHROFF(18,8),
+ @CHROFF(18,9),
+ @CHROFF(18,10),
+ @CHROFF(18,11),
+ @CHROFF(18,12),
+ @CHROFF(18,13),
+ @CHROFF(18,14),
+ @CHROFF(18,15),
+ @CHROFF(18,16),
+ @CHROFF(18,17),
};

extern const char *names972[];
static const uint32 types972 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags972 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype972_0 [] = {943,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_1 [] = {860,0xFF01,0xFFF9,2,1025,0xFF01,1084,860,0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes972 [] = {
g_atype972_0,
g_atype972_1,
};

static const long offsets972 [] =
{
0,
 + @REFACS(1),
};

extern const char *names982[];
static const uint32 types982 [] =
{
SK_REF,
};

static const uint16 attr_flags982 [] =
{0,};

static const EIF_TYPE_INDEX g_atype982_0 [] = {0xFF01,1082,0xFFFF};

static const EIF_TYPE_INDEX *gtypes982 [] = {
g_atype982_0,
};

static const long offsets982 [] =
{
0,
};

extern const char *names997[];
static const uint32 types997 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags997 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype997_0 [] = {114,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype997_1 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype997_2 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype997_3 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes997 [] = {
g_atype997_0,
g_atype997_1,
g_atype997_2,
g_atype997_3,
};

static const long offsets997 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
};

extern const char *names998[];
static const uint32 types998 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags998 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype998_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_1 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_2 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype998_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes998 [] = {
g_atype998_0,
g_atype998_1,
g_atype998_2,
g_atype998_3,
g_atype998_4,
};

static const long offsets998 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names1003[];
static const uint32 types1003 [] =
{
SK_REF,
};

static const uint16 attr_flags1003 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1003_0 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1003 [] = {
g_atype1003_0,
};

static const long offsets1003 [] =
{
0,
};

extern const char *names1004[];
static const uint32 types1004 [] =
{
SK_REF,
};

static const uint16 attr_flags1004 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1004_0 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1004 [] = {
g_atype1004_0,
};

static const long offsets1004 [] =
{
0,
};

extern const char *names1005[];
static const uint32 types1005 [] =
{
SK_REF,
};

static const uint16 attr_flags1005 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1005_0 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1005 [] = {
g_atype1005_0,
};

static const long offsets1005 [] =
{
0,
};

extern const char *names1006[];
static const uint32 types1006 [] =
{
SK_REF,
};

static const uint16 attr_flags1006 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1006_0 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1006 [] = {
g_atype1006_0,
};

static const long offsets1006 [] =
{
0,
};

extern const char *names1007[];
static const uint32 types1007 [] =
{
SK_REF,
};

static const uint16 attr_flags1007 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1007_0 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1007 [] = {
g_atype1007_0,
};

static const long offsets1007 [] =
{
0,
};

extern const char *names1008[];
static const uint32 types1008 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1008 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1008_0 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1008_1 [] = {0xFF01,919,0xFF01,1100,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1008 [] = {
g_atype1008_0,
g_atype1008_1,
};

static const long offsets1008 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1009[];
static const uint32 types1009 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1009 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1009_0 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1009_1 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1009_2 [] = {1099,0xFFFF};
static const EIF_TYPE_INDEX g_atype1009_3 [] = {1099,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1009 [] = {
g_atype1009_0,
g_atype1009_1,
g_atype1009_2,
g_atype1009_3,
};

static const long offsets1009 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1010[];
static const uint32 types1010 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1010 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1010_0 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1010_1 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1010_2 [] = {0xFF01,1077,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1010 [] = {
g_atype1010_0,
g_atype1010_1,
g_atype1010_2,
};

static const long offsets1010 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1011[];
static const uint32 types1011 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1011 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1011_0 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1011_1 [] = {0xFF01,948,0xFF01,1101,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1011 [] = {
g_atype1011_0,
g_atype1011_1,
};

static const long offsets1011 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1012[];
static const uint32 types1012 [] =
{
SK_REF,
};

static const uint16 attr_flags1012 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1012_0 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1012 [] = {
g_atype1012_0,
};

static const long offsets1012 [] =
{
0,
};

extern const char *names1013[];
static const uint32 types1013 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1013 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1013_0 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1013_1 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1013_2 [] = {1086,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1013 [] = {
g_atype1013_0,
g_atype1013_1,
g_atype1013_2,
};

static const long offsets1013 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1014[];
static const uint32 types1014 [] =
{
SK_REF,
};

static const uint16 attr_flags1014 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1014_0 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1014 [] = {
g_atype1014_0,
};

static const long offsets1014 [] =
{
0,
};

extern const char *names1015[];
static const uint32 types1015 [] =
{
SK_REF,
};

static const uint16 attr_flags1015 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1015_0 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1015 [] = {
g_atype1015_0,
};

static const long offsets1015 [] =
{
0,
};

extern const char *names1016[];
static const uint32 types1016 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1016 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1016_0 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_1 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1016 [] = {
g_atype1016_0,
g_atype1016_1,
g_atype1016_2,
g_atype1016_3,
g_atype1016_4,
};

static const long offsets1016 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1017[];
static const uint32 types1017 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1017 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1017_0 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_1 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1017 [] = {
g_atype1017_0,
g_atype1017_1,
g_atype1017_2,
g_atype1017_3,
g_atype1017_4,
};

static const long offsets1017 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1018[];
static const uint32 types1018 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1018 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1018_0 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_1 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1018 [] = {
g_atype1018_0,
g_atype1018_1,
g_atype1018_2,
g_atype1018_3,
g_atype1018_4,
};

static const long offsets1018 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1019[];
static const uint32 types1019 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1019 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1019_0 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_1 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_2 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1019 [] = {
g_atype1019_0,
g_atype1019_1,
g_atype1019_2,
g_atype1019_3,
g_atype1019_4,
g_atype1019_5,
g_atype1019_6,
};

static const long offsets1019 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
+ @LNGOFF(3,0,0,3),
};

extern const char *names1020[];
static const uint32 types1020 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1020 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1020_0 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1020_1 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1020_2 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1020_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1020_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1020_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1020 [] = {
g_atype1020_0,
g_atype1020_1,
g_atype1020_2,
g_atype1020_3,
g_atype1020_4,
g_atype1020_5,
};

static const long offsets1020 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1021[];
static const uint32 types1021 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1021 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1021_0 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1021_1 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1021_2 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1021_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1021_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1021_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1021 [] = {
g_atype1021_0,
g_atype1021_1,
g_atype1021_2,
g_atype1021_3,
g_atype1021_4,
g_atype1021_5,
};

static const long offsets1021 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1022[];
static const uint32 types1022 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1022 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1022_0 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_1 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1022 [] = {
g_atype1022_0,
g_atype1022_1,
g_atype1022_2,
g_atype1022_3,
g_atype1022_4,
};

static const long offsets1022 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1023[];
static const uint32 types1023 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1023 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1023_0 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1023_1 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1023_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1023_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1023_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1023 [] = {
g_atype1023_0,
g_atype1023_1,
g_atype1023_2,
g_atype1023_3,
g_atype1023_4,
};

static const long offsets1023 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1025[];
static const uint32 types1025 [] =
{
SK_INT32,
};

static const uint16 attr_flags1025 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1025_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1025 [] = {
g_atype1025_0,
};

static const long offsets1025 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1027[];
static const uint32 types1027 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
};

static const uint16 attr_flags1027 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1027_0 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_1 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_2 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_7 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1027 [] = {
g_atype1027_0,
g_atype1027_1,
g_atype1027_2,
g_atype1027_3,
g_atype1027_4,
g_atype1027_5,
g_atype1027_6,
g_atype1027_7,
};

static const long offsets1027 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @LNGOFF(3,4,0,0),
};

extern const char *names1028[];
static const uint32 types1028 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
};

static const uint16 attr_flags1028 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1028_0 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_1 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_2 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_3 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_4 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_10 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1028 [] = {
g_atype1028_0,
g_atype1028_1,
g_atype1028_2,
g_atype1028_3,
g_atype1028_4,
g_atype1028_5,
g_atype1028_6,
g_atype1028_7,
g_atype1028_8,
g_atype1028_9,
g_atype1028_10,
};

static const long offsets1028 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
};

extern const char *names1029[];
static const uint32 types1029 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
};

static const uint16 attr_flags1029 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1029_0 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_1 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_2 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_3 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_4 [] = {0xFF01,1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_10 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1029 [] = {
g_atype1029_0,
g_atype1029_1,
g_atype1029_2,
g_atype1029_3,
g_atype1029_4,
g_atype1029_5,
g_atype1029_6,
g_atype1029_7,
g_atype1029_8,
g_atype1029_9,
g_atype1029_10,
};

static const long offsets1029 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
};

extern const char *names1030[];
static const uint32 types1030 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags1030 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1030_0 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1030 [] = {
g_atype1030_0,
};

static const long offsets1030 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1031[];
static const uint32 types1031 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags1031 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1031_0 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1031 [] = {
g_atype1031_0,
};

static const long offsets1031 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1032[];
static const uint32 types1032 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags1032 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1032_0 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1032 [] = {
g_atype1032_0,
};

static const long offsets1032 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1033[];
static const uint32 types1033 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags1033 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1033_0 [] = {1034,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1033 [] = {
g_atype1033_0,
};

static const long offsets1033 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1034[];
static const uint32 types1034 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags1034 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1034_0 [] = {1034,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1034 [] = {
g_atype1034_0,
};

static const long offsets1034 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1035[];
static const uint32 types1035 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags1035 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1035_0 [] = {1034,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1035 [] = {
g_atype1035_0,
};

static const long offsets1035 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1036[];
static const uint32 types1036 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1036 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1036_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1036 [] = {
g_atype1036_0,
};

static const long offsets1036 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1037[];
static const uint32 types1037 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1037 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1037_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1037 [] = {
g_atype1037_0,
};

static const long offsets1037 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1038[];
static const uint32 types1038 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1038 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1038_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1038 [] = {
g_atype1038_0,
};

static const long offsets1038 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1039[];
static const uint32 types1039 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1039 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1039_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1039 [] = {
g_atype1039_0,
};

static const long offsets1039 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1040[];
static const uint32 types1040 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1040 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1040_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1040 [] = {
g_atype1040_0,
};

static const long offsets1040 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1041[];
static const uint32 types1041 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1041 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1041_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1041 [] = {
g_atype1041_0,
};

static const long offsets1041 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1042[];
static const uint32 types1042 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1042 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1042_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1042 [] = {
g_atype1042_0,
};

static const long offsets1042 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1043[];
static const uint32 types1043 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1043 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1043_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1043 [] = {
g_atype1043_0,
};

static const long offsets1043 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1044[];
static const uint32 types1044 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1044 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1044_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1044 [] = {
g_atype1044_0,
};

static const long offsets1044 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1045[];
static const uint32 types1045 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1045 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1045_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1045 [] = {
g_atype1045_0,
};

static const long offsets1045 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1046[];
static const uint32 types1046 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1046 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1046_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1046 [] = {
g_atype1046_0,
};

static const long offsets1046 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1047[];
static const uint32 types1047 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1047 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1047_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1047 [] = {
g_atype1047_0,
};

static const long offsets1047 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1048[];
static const uint32 types1048 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1048 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1048_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1048 [] = {
g_atype1048_0,
};

static const long offsets1048 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1049[];
static const uint32 types1049 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1049 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1049_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1049 [] = {
g_atype1049_0,
};

static const long offsets1049 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1050[];
static const uint32 types1050 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1050 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1050_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1050 [] = {
g_atype1050_0,
};

static const long offsets1050 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1051[];
static const uint32 types1051 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1051 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1051_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1051 [] = {
g_atype1051_0,
};

static const long offsets1051 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1052[];
static const uint32 types1052 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1052 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1052_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1052 [] = {
g_atype1052_0,
};

static const long offsets1052 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1053[];
static const uint32 types1053 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1053 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1053_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1053 [] = {
g_atype1053_0,
};

static const long offsets1053 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1054[];
static const uint32 types1054 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1054 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1054_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1054 [] = {
g_atype1054_0,
};

static const long offsets1054 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1055[];
static const uint32 types1055 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1055 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1055_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1055 [] = {
g_atype1055_0,
};

static const long offsets1055 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1056[];
static const uint32 types1056 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1056 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1056_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1056 [] = {
g_atype1056_0,
};

static const long offsets1056 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1057[];
static const uint32 types1057 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1057 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1057_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1057 [] = {
g_atype1057_0,
};

static const long offsets1057 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1058[];
static const uint32 types1058 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1058 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1058_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1058 [] = {
g_atype1058_0,
};

static const long offsets1058 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1059[];
static const uint32 types1059 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1059 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1059_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1059 [] = {
g_atype1059_0,
};

static const long offsets1059 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1060[];
static const uint32 types1060 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1060 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1060_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1060 [] = {
g_atype1060_0,
};

static const long offsets1060 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1061[];
static const uint32 types1061 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1061 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1061_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1061 [] = {
g_atype1061_0,
};

static const long offsets1061 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1062[];
static const uint32 types1062 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1062 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1062_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1062 [] = {
g_atype1062_0,
};

static const long offsets1062 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1063[];
static const uint32 types1063 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1063 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1063_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1063 [] = {
g_atype1063_0,
};

static const long offsets1063 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1064[];
static const uint32 types1064 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1064 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1064_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1064 [] = {
g_atype1064_0,
};

static const long offsets1064 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1065[];
static const uint32 types1065 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1065 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1065_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1065 [] = {
g_atype1065_0,
};

static const long offsets1065 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1066[];
static const uint32 types1066 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1066 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1066_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1066 [] = {
g_atype1066_0,
};

static const long offsets1066 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1067[];
static const uint32 types1067 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1067 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1067_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1067 [] = {
g_atype1067_0,
};

static const long offsets1067 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1068[];
static const uint32 types1068 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1068 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1068_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1068 [] = {
g_atype1068_0,
};

static const long offsets1068 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1069[];
static const uint32 types1069 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1069 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1069_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1069 [] = {
g_atype1069_0,
};

static const long offsets1069 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1070[];
static const uint32 types1070 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1070 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1070_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1070 [] = {
g_atype1070_0,
};

static const long offsets1070 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1071[];
static const uint32 types1071 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1071 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1071_0 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1071 [] = {
g_atype1071_0,
};

static const long offsets1071 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1072[];
static const uint32 types1072 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1072 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1072_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_1 [] = {0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_2 [] = {880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_3 [] = {880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_9 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_10 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_11 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1072 [] = {
g_atype1072_0,
g_atype1072_1,
g_atype1072_2,
g_atype1072_3,
g_atype1072_4,
g_atype1072_5,
g_atype1072_6,
g_atype1072_7,
g_atype1072_8,
g_atype1072_9,
g_atype1072_10,
g_atype1072_11,
};

static const long offsets1072 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names1073[];
static const uint32 types1073 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1073 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1073_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_1 [] = {0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_2 [] = {880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_3 [] = {880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_9 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_10 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_11 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1073 [] = {
g_atype1073_0,
g_atype1073_1,
g_atype1073_2,
g_atype1073_3,
g_atype1073_4,
g_atype1073_5,
g_atype1073_6,
g_atype1073_7,
g_atype1073_8,
g_atype1073_9,
g_atype1073_10,
g_atype1073_11,
};

static const long offsets1073 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names1074[];
static const uint32 types1074 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1074 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1074_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_1 [] = {0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_2 [] = {880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_3 [] = {880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_10 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_11 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_12 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1074 [] = {
g_atype1074_0,
g_atype1074_1,
g_atype1074_2,
g_atype1074_3,
g_atype1074_4,
g_atype1074_5,
g_atype1074_6,
g_atype1074_7,
g_atype1074_8,
g_atype1074_9,
g_atype1074_10,
g_atype1074_11,
g_atype1074_12,
};

static const long offsets1074 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @PTROFF(5,2,0,3,0,0),
+ @PTROFF(5,2,0,3,0,1),
+ @PTROFF(5,2,0,3,0,2),
};

extern const char *names1075[];
static const uint32 types1075 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1075 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1075_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_1 [] = {0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_2 [] = {880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_3 [] = {880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_10 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_11 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_12 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1075 [] = {
g_atype1075_0,
g_atype1075_1,
g_atype1075_2,
g_atype1075_3,
g_atype1075_4,
g_atype1075_5,
g_atype1075_6,
g_atype1075_7,
g_atype1075_8,
g_atype1075_9,
g_atype1075_10,
g_atype1075_11,
g_atype1075_12,
};

static const long offsets1075 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names1076[];
static const uint32 types1076 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1076 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1076_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_1 [] = {0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_2 [] = {880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_3 [] = {880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_10 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_11 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_12 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1076 [] = {
g_atype1076_0,
g_atype1076_1,
g_atype1076_2,
g_atype1076_3,
g_atype1076_4,
g_atype1076_5,
g_atype1076_6,
g_atype1076_7,
g_atype1076_8,
g_atype1076_9,
g_atype1076_10,
g_atype1076_11,
g_atype1076_12,
};

static const long offsets1076 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @LNGOFF(4,2,0,3),
+ @PTROFF(4,2,0,4,0,0),
+ @PTROFF(4,2,0,4,0,1),
+ @PTROFF(4,2,0,4,0,2),
};

extern const char *names1077[];
static const uint32 types1077 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1077 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1077_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_1 [] = {0xFFF9,0,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_2 [] = {880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_3 [] = {880,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_10 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_11 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_12 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1077 [] = {
g_atype1077_0,
g_atype1077_1,
g_atype1077_2,
g_atype1077_3,
g_atype1077_4,
g_atype1077_5,
g_atype1077_6,
g_atype1077_7,
g_atype1077_8,
g_atype1077_9,
g_atype1077_10,
g_atype1077_11,
g_atype1077_12,
};

static const long offsets1077 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names1078[];
static const uint32 types1078 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1078 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1078_0 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1078 [] = {
g_atype1078_0,
g_atype1078_1,
};

static const long offsets1078 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names1079[];
static const uint32 types1079 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1079 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1079_0 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1079 [] = {
g_atype1079_0,
g_atype1079_1,
};

static const long offsets1079 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names1080[];
static const uint32 types1080 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1080 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1080_0 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1080 [] = {
g_atype1080_0,
g_atype1080_1,
};

static const long offsets1080 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names1081[];
static const uint32 types1081 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1081 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1081_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1081 [] = {
g_atype1081_0,
g_atype1081_1,
g_atype1081_2,
g_atype1081_3,
};

static const long offsets1081 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1082[];
static const uint32 types1082 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1082 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1082_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1082 [] = {
g_atype1082_0,
g_atype1082_1,
g_atype1082_2,
g_atype1082_3,
g_atype1082_4,
};

static const long offsets1082 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names1083[];
static const uint32 types1083 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1083 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1083_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1083 [] = {
g_atype1083_0,
g_atype1083_1,
g_atype1083_2,
g_atype1083_3,
g_atype1083_4,
};

static const long offsets1083 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names1084[];
static const uint32 types1084 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1084 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1084_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1084 [] = {
g_atype1084_0,
g_atype1084_1,
g_atype1084_2,
g_atype1084_3,
g_atype1084_4,
};

static const long offsets1084 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names1085[];
static const uint32 types1085 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1085 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1085_0 [] = {0xFF01,1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1085 [] = {
g_atype1085_0,
g_atype1085_1,
g_atype1085_2,
g_atype1085_3,
};

static const long offsets1085 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1086[];
static const uint32 types1086 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1086 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1086_0 [] = {0xFF01,1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1086 [] = {
g_atype1086_0,
g_atype1086_1,
g_atype1086_2,
g_atype1086_3,
g_atype1086_4,
};

static const long offsets1086 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names1087[];
static const uint32 types1087 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1087 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1087_0 [] = {0xFF01,1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1087 [] = {
g_atype1087_0,
g_atype1087_1,
g_atype1087_2,
g_atype1087_3,
g_atype1087_4,
};

static const long offsets1087 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names1089[];
static const uint32 types1089 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1089 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1089_0 [] = {0xFF01,948,0xFF01,1090,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_1 [] = {0xFF01,1334,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_2 [] = {0xFF01,1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_3 [] = {0xFF01,1334,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1089 [] = {
g_atype1089_0,
g_atype1089_1,
g_atype1089_2,
g_atype1089_3,
};

static const long offsets1089 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1090[];
static const uint32 types1090 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1090 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1090_0 [] = {0xFF01,948,0xFF01,1090,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_1 [] = {0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_2 [] = {0xFF01,1334,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1090 [] = {
g_atype1090_0,
g_atype1090_1,
g_atype1090_2,
};

static const long offsets1090 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1091[];
static const uint32 types1091 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
};

static const uint16 attr_flags1091 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1091_0 [] = {0xFF01,606,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_1 [] = {0xFF01,1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_2 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_3 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_4 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_5 [] = {0xFF01,948,0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_6 [] = {0xFF01,948,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_7 [] = {1334,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_8 [] = {1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_9 [] = {860,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_10 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_11 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1091 [] = {
g_atype1091_0,
g_atype1091_1,
g_atype1091_2,
g_atype1091_3,
g_atype1091_4,
g_atype1091_5,
g_atype1091_6,
g_atype1091_7,
g_atype1091_8,
g_atype1091_9,
g_atype1091_10,
g_atype1091_11,
};

static const long offsets1091 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
};

extern const char *names1092[];
static const uint32 types1092 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1092 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1092_0 [] = {0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_2 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_7 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1092 [] = {
g_atype1092_0,
g_atype1092_1,
g_atype1092_2,
g_atype1092_3,
g_atype1092_4,
g_atype1092_5,
g_atype1092_6,
g_atype1092_7,
};

static const long offsets1092 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
+ @LNGOFF(2,2,0,3),
};

extern const char *names1093[];
static const uint32 types1093 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1093 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1093_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_1 [] = {0xFF01,827,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_2 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_3 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_12 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1093 [] = {
g_atype1093_0,
g_atype1093_1,
g_atype1093_2,
g_atype1093_3,
g_atype1093_4,
g_atype1093_5,
g_atype1093_6,
g_atype1093_7,
g_atype1093_8,
g_atype1093_9,
g_atype1093_10,
g_atype1093_11,
g_atype1093_12,
};

static const long offsets1093 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @LNGOFF(3,3,0,0),
+ @LNGOFF(3,3,0,1),
+ @LNGOFF(3,3,0,2),
+ @LNGOFF(3,3,0,3),
+ @LNGOFF(3,3,0,4),
+ @LNGOFF(3,3,0,5),
+ @LNGOFF(3,3,0,6),
};

extern const char *names1094[];
static const uint32 types1094 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1094 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1094_0 [] = {0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_1 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_8 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1094 [] = {
g_atype1094_0,
g_atype1094_1,
g_atype1094_2,
g_atype1094_3,
g_atype1094_4,
g_atype1094_5,
g_atype1094_6,
g_atype1094_7,
g_atype1094_8,
};

static const long offsets1094 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
+ @LNGOFF(2,2,0,3),
+ @LNGOFF(2,2,0,4),
};

extern const char *names1095[];
static const uint32 types1095 [] =
{
SK_REF,
SK_BOOL,
SK_UINT8,
SK_UINT8,
};

static const uint16 attr_flags1095 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1095_0 [] = {0xFF01,878,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_2 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_3 [] = {1237,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1095 [] = {
g_atype1095_0,
g_atype1095_1,
g_atype1095_2,
g_atype1095_3,
};

static const long offsets1095 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
};

extern const char *names1096[];
static const uint32 types1096 [] =
{
SK_REF,
SK_UINT8,
};

static const uint16 attr_flags1096 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1096_0 [] = {0xFF01,1094,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_1 [] = {1237,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1096 [] = {
g_atype1096_0,
g_atype1096_1,
};

static const long offsets1096 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names1097[];
static const uint32 types1097 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1097 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1097_0 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_1 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_2 [] = {0xFFF9,2,1025,0xFF01,1084,860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_3 [] = {0xFF01,1153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_4 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_5 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_6 [] = {1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_7 [] = {948,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_8 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_9 [] = {0xFF01,397,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_10 [] = {1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_11 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_12 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_13 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_14 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_15 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_16 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_17 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_18 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1097 [] = {
g_atype1097_0,
g_atype1097_1,
g_atype1097_2,
g_atype1097_3,
g_atype1097_4,
g_atype1097_5,
g_atype1097_6,
g_atype1097_7,
g_atype1097_8,
g_atype1097_9,
g_atype1097_10,
g_atype1097_11,
g_atype1097_12,
g_atype1097_13,
g_atype1097_14,
g_atype1097_15,
g_atype1097_16,
g_atype1097_17,
g_atype1097_18,
};

static const long offsets1097 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @CHROFF(11,1),
+ @CHROFF(11,2),
+ @CHROFF(11,3),
+ @CHROFF(11,4),
+ @CHROFF(11,5),
+ @LNGOFF(11,6,0,0),
+ @LNGOFF(11,6,0,1),
};

extern const char *names1098[];
static const uint32 types1098 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1098 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1098_0 [] = {0xFF01,1326,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_2 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_3 [] = {1097,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_4 [] = {0xFF01,949,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_5 [] = {948,1097,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_6 [] = {948,0xFF01,1162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_7 [] = {0xFF01,0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_11 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_14 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1098 [] = {
g_atype1098_0,
g_atype1098_1,
g_atype1098_2,
g_atype1098_3,
g_atype1098_4,
g_atype1098_5,
g_atype1098_6,
g_atype1098_7,
g_atype1098_8,
g_atype1098_9,
g_atype1098_10,
g_atype1098_11,
g_atype1098_12,
g_atype1098_13,
g_atype1098_14,
};

static const long offsets1098 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @LNGOFF(8,4,0,0),
+ @LNGOFF(8,4,0,1),
+ @LNGOFF(8,4,0,2),
};

extern const char *names1099[];
static const uint32 types1099 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1099 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1099_0 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1099 [] = {
g_atype1099_0,
g_atype1099_1,
g_atype1099_2,
g_atype1099_3,
};

static const long offsets1099 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1100[];
static const uint32 types1100 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_UINT64,
};

static const uint16 attr_flags1100 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1100_0 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_1 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_2 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_3 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_4 [] = {1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1100 [] = {
g_atype1100_0,
g_atype1100_1,
g_atype1100_2,
g_atype1100_3,
g_atype1100_4,
};

static const long offsets1100 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @I64OFF(0,0,3,1,0,0,0),
};

extern const char *names1101[];
static const uint32 types1101 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1101 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1101_0 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_1 [] = {970,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_2 [] = {970,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_3 [] = {0xFF01,860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_4 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_5 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_6 [] = {1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_7 [] = {264,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_8 [] = {0xFF01,1288,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_9 [] = {0xFF01,860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_10 [] = {66,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_11 [] = {1265,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_12 [] = {1161,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_13 [] = {0xFF01,860,0xFF01,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_14 [] = {0xFF01,860,0xFF01,1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_15 [] = {0xFF01,860,0xFF01,1155,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_16 [] = {0xFF01,860,0xFF01,1159,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_17 [] = {0xFF01,948,0xFF01,405,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_18 [] = {860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_19 [] = {0xFF01,948,0xFF01,410,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_20 [] = {0xFF01,948,0xFF01,408,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_21 [] = {0xFF01,948,0xFF01,414,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_22 [] = {0xFF01,948,0xFF01,411,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_23 [] = {0xFF01,948,0xFF01,409,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_24 [] = {0xFF01,948,0xFF01,412,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_25 [] = {0xFF01,948,0xFF01,413,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_26 [] = {0xFF01,948,0xFF01,406,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_27 [] = {0xFF01,948,0xFF01,406,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_28 [] = {0xFF01,860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_29 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1101 [] = {
g_atype1101_0,
g_atype1101_1,
g_atype1101_2,
g_atype1101_3,
g_atype1101_4,
g_atype1101_5,
g_atype1101_6,
g_atype1101_7,
g_atype1101_8,
g_atype1101_9,
g_atype1101_10,
g_atype1101_11,
g_atype1101_12,
g_atype1101_13,
g_atype1101_14,
g_atype1101_15,
g_atype1101_16,
g_atype1101_17,
g_atype1101_18,
g_atype1101_19,
g_atype1101_20,
g_atype1101_21,
g_atype1101_22,
g_atype1101_23,
g_atype1101_24,
g_atype1101_25,
g_atype1101_26,
g_atype1101_27,
g_atype1101_28,
g_atype1101_29,
};

static const long offsets1101 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
+ @CHROFF(29,0),
};

extern const char *names1102[];
static const uint32 types1102 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1102 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1102_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_1 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1102 [] = {
g_atype1102_0,
g_atype1102_1,
g_atype1102_2,
};

static const long offsets1102 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names1103[];
static const uint32 types1103 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1103 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1103_0 [] = {0xFF01,948,0xFF01,1264,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_1 [] = {0xFF01,948,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_2 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_3 [] = {0xFF01,263,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1103 [] = {
g_atype1103_0,
g_atype1103_1,
g_atype1103_2,
g_atype1103_3,
};

static const long offsets1103 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1104[];
static const uint32 types1104 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1104 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1104_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1104 [] = {
g_atype1104_0,
g_atype1104_1,
};

static const long offsets1104 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1105[];
static const uint32 types1105 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1105 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1105_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1105 [] = {
g_atype1105_0,
g_atype1105_1,
};

static const long offsets1105 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1106[];
static const uint32 types1106 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1106 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1106_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1106 [] = {
g_atype1106_0,
g_atype1106_1,
};

static const long offsets1106 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1107[];
static const uint32 types1107 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1107 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1107_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1107 [] = {
g_atype1107_0,
g_atype1107_1,
};

static const long offsets1107 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1108[];
static const uint32 types1108 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1108 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1108_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1108 [] = {
g_atype1108_0,
g_atype1108_1,
};

static const long offsets1108 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1109[];
static const uint32 types1109 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1109 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1109_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1109 [] = {
g_atype1109_0,
g_atype1109_1,
};

static const long offsets1109 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1110[];
static const uint32 types1110 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1110 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1110_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1110 [] = {
g_atype1110_0,
g_atype1110_1,
};

static const long offsets1110 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1111[];
static const uint32 types1111 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1111 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1111_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1111_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1111 [] = {
g_atype1111_0,
g_atype1111_1,
};

static const long offsets1111 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1112[];
static const uint32 types1112 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1112 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1112_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1112 [] = {
g_atype1112_0,
g_atype1112_1,
};

static const long offsets1112 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1113[];
static const uint32 types1113 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1113 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1113_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1113_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1113 [] = {
g_atype1113_0,
g_atype1113_1,
};

static const long offsets1113 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1114[];
static const uint32 types1114 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1114 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1114_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1114 [] = {
g_atype1114_0,
g_atype1114_1,
};

static const long offsets1114 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1115[];
static const uint32 types1115 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1115 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1115_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1115 [] = {
g_atype1115_0,
g_atype1115_1,
};

static const long offsets1115 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1116[];
static const uint32 types1116 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1116 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1116_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1116 [] = {
g_atype1116_0,
g_atype1116_1,
};

static const long offsets1116 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1117[];
static const uint32 types1117 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1117 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1117_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1117_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1117 [] = {
g_atype1117_0,
g_atype1117_1,
};

static const long offsets1117 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1118[];
static const uint32 types1118 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1118 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1118_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1118_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1118 [] = {
g_atype1118_0,
g_atype1118_1,
};

static const long offsets1118 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1119[];
static const uint32 types1119 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1119 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1119_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1119 [] = {
g_atype1119_0,
g_atype1119_1,
};

static const long offsets1119 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1120[];
static const uint32 types1120 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1120 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1120_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1120 [] = {
g_atype1120_0,
g_atype1120_1,
};

static const long offsets1120 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1121[];
static const uint32 types1121 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1121 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1121_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1121 [] = {
g_atype1121_0,
g_atype1121_1,
};

static const long offsets1121 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1122[];
static const uint32 types1122 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1122 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1122_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1122 [] = {
g_atype1122_0,
g_atype1122_1,
};

static const long offsets1122 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1123[];
static const uint32 types1123 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1123 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1123_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1123 [] = {
g_atype1123_0,
g_atype1123_1,
};

static const long offsets1123 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1124[];
static const uint32 types1124 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1124 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1124_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1124 [] = {
g_atype1124_0,
g_atype1124_1,
};

static const long offsets1124 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1125[];
static const uint32 types1125 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1125 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1125_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1125 [] = {
g_atype1125_0,
g_atype1125_1,
};

static const long offsets1125 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1126[];
static const uint32 types1126 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1126 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1126_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1126 [] = {
g_atype1126_0,
g_atype1126_1,
};

static const long offsets1126 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1127[];
static const uint32 types1127 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1127 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1127_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1127 [] = {
g_atype1127_0,
g_atype1127_1,
};

static const long offsets1127 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1128[];
static const uint32 types1128 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1128 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1128_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1128_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1128 [] = {
g_atype1128_0,
g_atype1128_1,
};

static const long offsets1128 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1129[];
static const uint32 types1129 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1129 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1129_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1129 [] = {
g_atype1129_0,
g_atype1129_1,
};

static const long offsets1129 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1130[];
static const uint32 types1130 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1130 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1130_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1130_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1130 [] = {
g_atype1130_0,
g_atype1130_1,
};

static const long offsets1130 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1131[];
static const uint32 types1131 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1131 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1131_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1131_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1131 [] = {
g_atype1131_0,
g_atype1131_1,
};

static const long offsets1131 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1132[];
static const uint32 types1132 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1132 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1132_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1132_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1132 [] = {
g_atype1132_0,
g_atype1132_1,
};

static const long offsets1132 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1133[];
static const uint32 types1133 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1133 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1133_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1133_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1133 [] = {
g_atype1133_0,
g_atype1133_1,
};

static const long offsets1133 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1134[];
static const uint32 types1134 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1134 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1134_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1134_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1134 [] = {
g_atype1134_0,
g_atype1134_1,
};

static const long offsets1134 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1135[];
static const uint32 types1135 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1135 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1135_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1135_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1135 [] = {
g_atype1135_0,
g_atype1135_1,
};

static const long offsets1135 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1136[];
static const uint32 types1136 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1136 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1136_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1136_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1136 [] = {
g_atype1136_0,
g_atype1136_1,
};

static const long offsets1136 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1137[];
static const uint32 types1137 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1137 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1137_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1137_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1137 [] = {
g_atype1137_0,
g_atype1137_1,
};

static const long offsets1137 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1138[];
static const uint32 types1138 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1138 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1138_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1138_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1138 [] = {
g_atype1138_0,
g_atype1138_1,
};

static const long offsets1138 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1139[];
static const uint32 types1139 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1139 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype1139_0 [] = {1085,0xFFFF};
static const EIF_TYPE_INDEX g_atype1139_1 [] = {1081,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1139 [] = {
g_atype1139_0,
g_atype1139_1,
};

static const long offsets1139 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1153[];
static const uint32 types1153 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1153 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1153_0 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_1 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_2 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_3 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_4 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_5 [] = {0xFF01,1319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_6 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_7 [] = {948,0xFF01,1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_8 [] = {860,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_9 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_10 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_11 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_12 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_13 [] = {851,0xFF01,1096,0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_14 [] = {851,0xFF01,1077,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_15 [] = {1261,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_16 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_17 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_19 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1153 [] = {
g_atype1153_0,
g_atype1153_1,
g_atype1153_2,
g_atype1153_3,
g_atype1153_4,
g_atype1153_5,
g_atype1153_6,
g_atype1153_7,
g_atype1153_8,
g_atype1153_9,
g_atype1153_10,
g_atype1153_11,
g_atype1153_12,
g_atype1153_13,
g_atype1153_14,
g_atype1153_15,
g_atype1153_16,
g_atype1153_17,
g_atype1153_18,
g_atype1153_19,
};

static const long offsets1153 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @LNGOFF(16,3,0,0),
};

extern const char *names1154[];
static const uint32 types1154 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1154 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1154_0 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_1 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_2 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_3 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_4 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_5 [] = {0xFF01,1319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_6 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_7 [] = {948,0xFF01,1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_8 [] = {860,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_9 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_10 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_11 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_12 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_13 [] = {851,0xFF01,1096,0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_14 [] = {851,0xFF01,1077,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_15 [] = {1261,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_16 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_17 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_19 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1154 [] = {
g_atype1154_0,
g_atype1154_1,
g_atype1154_2,
g_atype1154_3,
g_atype1154_4,
g_atype1154_5,
g_atype1154_6,
g_atype1154_7,
g_atype1154_8,
g_atype1154_9,
g_atype1154_10,
g_atype1154_11,
g_atype1154_12,
g_atype1154_13,
g_atype1154_14,
g_atype1154_15,
g_atype1154_16,
g_atype1154_17,
g_atype1154_18,
g_atype1154_19,
};

static const long offsets1154 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @LNGOFF(16,3,0,0),
};

extern const char *names1155[];
static const uint32 types1155 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1155 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1155_0 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_1 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_2 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_3 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_4 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_5 [] = {0xFF01,1319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_6 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_7 [] = {948,0xFF01,1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_8 [] = {860,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_9 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_10 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_11 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_12 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_13 [] = {851,0xFF01,1096,0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_14 [] = {851,0xFF01,1077,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_15 [] = {1261,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_16 [] = {0xFF01,948,0xFF01,1159,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_17 [] = {852,0xFF01,1154,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_19 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_20 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_21 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1155 [] = {
g_atype1155_0,
g_atype1155_1,
g_atype1155_2,
g_atype1155_3,
g_atype1155_4,
g_atype1155_5,
g_atype1155_6,
g_atype1155_7,
g_atype1155_8,
g_atype1155_9,
g_atype1155_10,
g_atype1155_11,
g_atype1155_12,
g_atype1155_13,
g_atype1155_14,
g_atype1155_15,
g_atype1155_16,
g_atype1155_17,
g_atype1155_18,
g_atype1155_19,
g_atype1155_20,
g_atype1155_21,
};

static const long offsets1155 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
+ @CHROFF(18,0),
+ @CHROFF(18,1),
+ @CHROFF(18,2),
+ @LNGOFF(18,3,0,0),
};

extern const char *names1156[];
static const uint32 types1156 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1156 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1156_0 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_1 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_2 [] = {943,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_3 [] = {860,0xFF01,0xFFF9,2,1025,0xFF01,1084,860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_4 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_5 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_6 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_7 [] = {0xFF01,1320,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_8 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_9 [] = {948,0xFF01,1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_10 [] = {860,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_11 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_12 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_13 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_14 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_15 [] = {851,0xFF01,1096,0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_16 [] = {851,0xFF01,1077,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_17 [] = {1261,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_18 [] = {1155,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_19 [] = {948,1155,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_20 [] = {1261,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_21 [] = {948,0xFFF5,1,0xFF01,1152,7759,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_22 [] = {0xFF01,948,0xFF01,405,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_23 [] = {860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_24 [] = {0xFF01,860,0xFF01,947,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_25 [] = {0xFF01,851,0xFF01,947,0xFF01,1077,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_26 [] = {860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_27 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_28 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_29 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_30 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_31 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_32 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1156 [] = {
g_atype1156_0,
g_atype1156_1,
g_atype1156_2,
g_atype1156_3,
g_atype1156_4,
g_atype1156_5,
g_atype1156_6,
g_atype1156_7,
g_atype1156_8,
g_atype1156_9,
g_atype1156_10,
g_atype1156_11,
g_atype1156_12,
g_atype1156_13,
g_atype1156_14,
g_atype1156_15,
g_atype1156_16,
g_atype1156_17,
g_atype1156_18,
g_atype1156_19,
g_atype1156_20,
g_atype1156_21,
g_atype1156_22,
g_atype1156_23,
g_atype1156_24,
g_atype1156_25,
g_atype1156_26,
g_atype1156_27,
g_atype1156_28,
g_atype1156_29,
g_atype1156_30,
g_atype1156_31,
g_atype1156_32,
};

static const long offsets1156 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
+ @CHROFF(27,0),
+ @CHROFF(27,1),
+ @CHROFF(27,2),
+ @CHROFF(27,3),
+ @CHROFF(27,4),
+ @LNGOFF(27,5,0,0),
};

extern const char *names1157[];
static const uint32 types1157 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1157 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1157_0 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_1 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_2 [] = {943,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_3 [] = {860,0xFF01,0xFFF9,2,1025,0xFF01,1084,860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_4 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_5 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_6 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_7 [] = {0xFF01,1320,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_8 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_9 [] = {948,0xFF01,1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_10 [] = {860,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_11 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_12 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_13 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_14 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_15 [] = {851,0xFF01,1096,0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_16 [] = {851,0xFF01,1077,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_17 [] = {1261,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_18 [] = {1155,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_19 [] = {948,1156,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_20 [] = {1261,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_21 [] = {948,0xFFF5,1,0xFF01,1152,7759,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_22 [] = {0xFF01,948,0xFF01,405,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_23 [] = {860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_24 [] = {0xFF01,860,0xFF01,947,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_25 [] = {0xFF01,851,0xFF01,947,0xFF01,1077,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_26 [] = {860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_27 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_28 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_29 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_30 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_31 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_32 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1157 [] = {
g_atype1157_0,
g_atype1157_1,
g_atype1157_2,
g_atype1157_3,
g_atype1157_4,
g_atype1157_5,
g_atype1157_6,
g_atype1157_7,
g_atype1157_8,
g_atype1157_9,
g_atype1157_10,
g_atype1157_11,
g_atype1157_12,
g_atype1157_13,
g_atype1157_14,
g_atype1157_15,
g_atype1157_16,
g_atype1157_17,
g_atype1157_18,
g_atype1157_19,
g_atype1157_20,
g_atype1157_21,
g_atype1157_22,
g_atype1157_23,
g_atype1157_24,
g_atype1157_25,
g_atype1157_26,
g_atype1157_27,
g_atype1157_28,
g_atype1157_29,
g_atype1157_30,
g_atype1157_31,
g_atype1157_32,
};

static const long offsets1157 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
+ @CHROFF(27,0),
+ @CHROFF(27,1),
+ @CHROFF(27,2),
+ @CHROFF(27,3),
+ @CHROFF(27,4),
+ @LNGOFF(27,5,0,0),
};

extern const char *names1158[];
static const uint32 types1158 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1158 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1158_0 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_1 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_2 [] = {943,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_3 [] = {860,0xFF01,0xFFF9,2,1025,0xFF01,1084,860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_4 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_5 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_6 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_7 [] = {0xFF01,1320,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_8 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_9 [] = {948,0xFF01,1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_10 [] = {860,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_11 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_12 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_13 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_14 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_15 [] = {851,0xFF01,1096,0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_16 [] = {851,0xFF01,1077,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_17 [] = {1261,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_18 [] = {1155,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_19 [] = {948,1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_20 [] = {1261,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_21 [] = {948,0xFFF5,1,0xFF01,1152,7759,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_22 [] = {0xFF01,948,0xFF01,405,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_23 [] = {860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_24 [] = {0xFF01,860,0xFF01,947,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_25 [] = {0xFF01,851,0xFF01,947,0xFF01,1077,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_26 [] = {860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_27 [] = {948,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_28 [] = {948,0xFFF5,1,0xFF01,1152,7759,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_29 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_30 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_31 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_32 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_33 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_34 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1158 [] = {
g_atype1158_0,
g_atype1158_1,
g_atype1158_2,
g_atype1158_3,
g_atype1158_4,
g_atype1158_5,
g_atype1158_6,
g_atype1158_7,
g_atype1158_8,
g_atype1158_9,
g_atype1158_10,
g_atype1158_11,
g_atype1158_12,
g_atype1158_13,
g_atype1158_14,
g_atype1158_15,
g_atype1158_16,
g_atype1158_17,
g_atype1158_18,
g_atype1158_19,
g_atype1158_20,
g_atype1158_21,
g_atype1158_22,
g_atype1158_23,
g_atype1158_24,
g_atype1158_25,
g_atype1158_26,
g_atype1158_27,
g_atype1158_28,
g_atype1158_29,
g_atype1158_30,
g_atype1158_31,
g_atype1158_32,
g_atype1158_33,
g_atype1158_34,
};

static const long offsets1158 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
+ @CHROFF(29,0),
+ @CHROFF(29,1),
+ @CHROFF(29,2),
+ @CHROFF(29,3),
+ @CHROFF(29,4),
+ @LNGOFF(29,5,0,0),
};

extern const char *names1159[];
static const uint32 types1159 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1159 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1159_0 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_1 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_2 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_3 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_4 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_5 [] = {0xFF01,1319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_6 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_7 [] = {948,0xFF01,1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_8 [] = {860,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_9 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_10 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_11 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_12 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_13 [] = {851,0xFF01,1096,0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_14 [] = {851,0xFF01,1077,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_15 [] = {1261,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_16 [] = {860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_17 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_19 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_20 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_21 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1159 [] = {
g_atype1159_0,
g_atype1159_1,
g_atype1159_2,
g_atype1159_3,
g_atype1159_4,
g_atype1159_5,
g_atype1159_6,
g_atype1159_7,
g_atype1159_8,
g_atype1159_9,
g_atype1159_10,
g_atype1159_11,
g_atype1159_12,
g_atype1159_13,
g_atype1159_14,
g_atype1159_15,
g_atype1159_16,
g_atype1159_17,
g_atype1159_18,
g_atype1159_19,
g_atype1159_20,
g_atype1159_21,
};

static const long offsets1159 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
+ @CHROFF(18,0),
+ @CHROFF(18,1),
+ @CHROFF(18,2),
+ @LNGOFF(18,3,0,0),
};

extern const char *names1160[];
static const uint32 types1160 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1160 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1160_0 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_1 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_2 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_3 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_4 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_5 [] = {0xFF01,1321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_6 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_7 [] = {948,0xFF01,1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_8 [] = {860,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_9 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_10 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_11 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_12 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_13 [] = {851,0xFF01,1096,0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_14 [] = {851,0xFF01,1077,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_15 [] = {1261,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_16 [] = {860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_17 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_18 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_19 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_20 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_21 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_22 [] = {1154,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_23 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_24 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_25 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_26 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_27 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1160 [] = {
g_atype1160_0,
g_atype1160_1,
g_atype1160_2,
g_atype1160_3,
g_atype1160_4,
g_atype1160_5,
g_atype1160_6,
g_atype1160_7,
g_atype1160_8,
g_atype1160_9,
g_atype1160_10,
g_atype1160_11,
g_atype1160_12,
g_atype1160_13,
g_atype1160_14,
g_atype1160_15,
g_atype1160_16,
g_atype1160_17,
g_atype1160_18,
g_atype1160_19,
g_atype1160_20,
g_atype1160_21,
g_atype1160_22,
g_atype1160_23,
g_atype1160_24,
g_atype1160_25,
g_atype1160_26,
g_atype1160_27,
};

static const long offsets1160 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
+ @CHROFF(23,0),
+ @CHROFF(23,1),
+ @CHROFF(23,2),
+ @CHROFF(23,3),
+ @LNGOFF(23,4,0,0),
};

extern const char *names1161[];
static const uint32 types1161 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1161 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1161_0 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_1 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_2 [] = {943,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_3 [] = {860,0xFF01,0xFFF9,2,1025,0xFF01,1084,860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_4 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_5 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_6 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_7 [] = {0xFF01,1319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_8 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_9 [] = {948,0xFF01,1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_10 [] = {860,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_11 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_12 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_13 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_14 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_15 [] = {851,0xFF01,1096,0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_16 [] = {851,0xFF01,1077,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_17 [] = {1261,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_18 [] = {860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_19 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_20 [] = {1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_21 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_22 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_23 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_24 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_25 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1161 [] = {
g_atype1161_0,
g_atype1161_1,
g_atype1161_2,
g_atype1161_3,
g_atype1161_4,
g_atype1161_5,
g_atype1161_6,
g_atype1161_7,
g_atype1161_8,
g_atype1161_9,
g_atype1161_10,
g_atype1161_11,
g_atype1161_12,
g_atype1161_13,
g_atype1161_14,
g_atype1161_15,
g_atype1161_16,
g_atype1161_17,
g_atype1161_18,
g_atype1161_19,
g_atype1161_20,
g_atype1161_21,
g_atype1161_22,
g_atype1161_23,
g_atype1161_24,
g_atype1161_25,
};

static const long offsets1161 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
+ @CHROFF(21,0),
+ @CHROFF(21,1),
+ @CHROFF(21,2),
+ @CHROFF(21,3),
+ @LNGOFF(21,4,0,0),
};

extern const char *names1162[];
static const uint32 types1162 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1162 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1162_0 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_1 [] = {961,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_2 [] = {943,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_3 [] = {860,0xFF01,0xFFF9,2,1025,0xFF01,1084,860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_4 [] = {1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_5 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_6 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_7 [] = {0xFF01,1319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_8 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_9 [] = {948,0xFF01,1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_10 [] = {860,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_11 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_12 [] = {969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_13 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_14 [] = {860,0xFF01,969,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_15 [] = {851,0xFF01,1096,0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_16 [] = {851,0xFF01,1077,0xFF01,1096,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_17 [] = {1261,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_18 [] = {860,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_19 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_20 [] = {1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_21 [] = {1320,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_22 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_23 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_24 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_25 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_26 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1162 [] = {
g_atype1162_0,
g_atype1162_1,
g_atype1162_2,
g_atype1162_3,
g_atype1162_4,
g_atype1162_5,
g_atype1162_6,
g_atype1162_7,
g_atype1162_8,
g_atype1162_9,
g_atype1162_10,
g_atype1162_11,
g_atype1162_12,
g_atype1162_13,
g_atype1162_14,
g_atype1162_15,
g_atype1162_16,
g_atype1162_17,
g_atype1162_18,
g_atype1162_19,
g_atype1162_20,
g_atype1162_21,
g_atype1162_22,
g_atype1162_23,
g_atype1162_24,
g_atype1162_25,
g_atype1162_26,
};

static const long offsets1162 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
+ @CHROFF(22,0),
+ @CHROFF(22,1),
+ @CHROFF(22,2),
+ @CHROFF(22,3),
+ @LNGOFF(22,4,0,0),
};

extern const char *names1163[];
static const uint32 types1163 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1163 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1163_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_2 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1163 [] = {
g_atype1163_0,
g_atype1163_1,
g_atype1163_2,
};

static const long offsets1163 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names1164[];
static const uint32 types1164 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1164 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1164_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_1 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1164 [] = {
g_atype1164_0,
g_atype1164_1,
g_atype1164_2,
g_atype1164_3,
g_atype1164_4,
g_atype1164_5,
};

static const long offsets1164 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1165[];
static const uint32 types1165 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1165 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1165_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_1 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_5 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1165 [] = {
g_atype1165_0,
g_atype1165_1,
g_atype1165_2,
g_atype1165_3,
g_atype1165_4,
g_atype1165_5,
};

static const long offsets1165 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @PTROFF(1,0,0,4,0,0),
};

extern const char *names1166[];
static const uint32 types1166 [] =
{
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1166 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1166_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_1 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1166 [] = {
g_atype1166_0,
g_atype1166_1,
g_atype1166_2,
g_atype1166_3,
g_atype1166_4,
g_atype1166_5,
};

static const long offsets1166 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names1167[];
static const uint32 types1167 [] =
{
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1167 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1167_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_1 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1167 [] = {
g_atype1167_0,
g_atype1167_1,
g_atype1167_2,
g_atype1167_3,
g_atype1167_4,
g_atype1167_5,
};

static const long offsets1167 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names1168[];
static const uint32 types1168 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags1168 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1168_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_1 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_5 [] = {1240,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1168 [] = {
g_atype1168_0,
g_atype1168_1,
g_atype1168_2,
g_atype1168_3,
g_atype1168_4,
g_atype1168_5,
};

static const long offsets1168 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R32OFF(1,0,0,4,0),
};

extern const char *names1169[];
static const uint32 types1169 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1169 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1169_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_1 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_5 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1169 [] = {
g_atype1169_0,
g_atype1169_1,
g_atype1169_2,
g_atype1169_3,
g_atype1169_4,
g_atype1169_5,
};

static const long offsets1169 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R64OFF(1,0,0,4,0,0,0,0),
};

extern const char *names1170[];
static const uint32 types1170 [] =
{
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1170 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1170_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1170 [] = {
g_atype1170_0,
g_atype1170_1,
g_atype1170_2,
g_atype1170_3,
g_atype1170_4,
g_atype1170_5,
};

static const long offsets1170 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names1171[];
static const uint32 types1171 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1171 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1171_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_1 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1171 [] = {
g_atype1171_0,
g_atype1171_1,
g_atype1171_2,
g_atype1171_3,
g_atype1171_4,
g_atype1171_5,
};

static const long offsets1171 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names1172[];
static const uint32 types1172 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags1172 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1172_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_1 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_5 [] = {1216,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1172 [] = {
g_atype1172_0,
g_atype1172_1,
g_atype1172_2,
g_atype1172_3,
g_atype1172_4,
g_atype1172_5,
};

static const long offsets1172 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names1173[];
static const uint32 types1173 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1173 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1173_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_1 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1173 [] = {
g_atype1173_0,
g_atype1173_1,
g_atype1173_2,
g_atype1173_3,
g_atype1173_4,
g_atype1173_5,
};

static const long offsets1173 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names1174[];
static const uint32 types1174 [] =
{
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1174 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1174_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_1 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1174 [] = {
g_atype1174_0,
g_atype1174_1,
g_atype1174_2,
g_atype1174_3,
g_atype1174_4,
g_atype1174_5,
};

static const long offsets1174 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names1175[];
static const uint32 types1175 [] =
{
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1175 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1175_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_1 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1175 [] = {
g_atype1175_0,
g_atype1175_1,
g_atype1175_2,
g_atype1175_3,
g_atype1175_4,
g_atype1175_5,
};

static const long offsets1175 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names1176[];
static const uint32 types1176 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags1176 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1176_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_1 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_5 [] = {1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1176 [] = {
g_atype1176_0,
g_atype1176_1,
g_atype1176_2,
g_atype1176_3,
g_atype1176_4,
g_atype1176_5,
};

static const long offsets1176 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names1177[];
static const uint32 types1177 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1177 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1177_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_1 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1177 [] = {
g_atype1177_0,
g_atype1177_1,
g_atype1177_2,
g_atype1177_3,
g_atype1177_4,
g_atype1177_5,
};

static const long offsets1177 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names1178[];
static const uint32 types1178 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1178 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1178_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1178 [] = {
g_atype1178_0,
g_atype1178_1,
g_atype1178_2,
g_atype1178_3,
g_atype1178_4,
g_atype1178_5,
};

static const long offsets1178 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names1179[];
static const uint32 types1179 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1179 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1179_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_3 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1179 [] = {
g_atype1179_0,
g_atype1179_1,
g_atype1179_2,
g_atype1179_3,
g_atype1179_4,
g_atype1179_5,
};

static const long offsets1179 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1180[];
static const uint32 types1180 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1180 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1180_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_2 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_3 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1180 [] = {
g_atype1180_0,
g_atype1180_1,
g_atype1180_2,
g_atype1180_3,
g_atype1180_4,
g_atype1180_5,
};

static const long offsets1180 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1181[];
static const uint32 types1181 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1181 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1181_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1181 [] = {
g_atype1181_0,
g_atype1181_1,
g_atype1181_2,
g_atype1181_3,
g_atype1181_4,
g_atype1181_5,
};

static const long offsets1181 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1182[];
static const uint32 types1182 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags1182 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1182_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_5 [] = {1216,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1182 [] = {
g_atype1182_0,
g_atype1182_1,
g_atype1182_2,
g_atype1182_3,
g_atype1182_4,
g_atype1182_5,
};

static const long offsets1182 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names1183[];
static const uint32 types1183 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1183 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1183_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_2 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_3 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1183 [] = {
g_atype1183_0,
g_atype1183_1,
g_atype1183_2,
g_atype1183_3,
g_atype1183_4,
g_atype1183_5,
};

static const long offsets1183 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names1184[];
static const uint32 types1184 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1184 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1184_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_3 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1184 [] = {
g_atype1184_0,
g_atype1184_1,
g_atype1184_2,
g_atype1184_3,
g_atype1184_4,
g_atype1184_5,
};

static const long offsets1184 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1185[];
static const uint32 types1185 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags1185 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1185_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_5 [] = {1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1185 [] = {
g_atype1185_0,
g_atype1185_1,
g_atype1185_2,
g_atype1185_3,
g_atype1185_4,
g_atype1185_5,
};

static const long offsets1185 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names1186[];
static const uint32 types1186 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1186 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1186_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_3 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1186 [] = {
g_atype1186_0,
g_atype1186_1,
g_atype1186_2,
g_atype1186_3,
g_atype1186_4,
g_atype1186_5,
};

static const long offsets1186 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1187[];
static const uint32 types1187 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1187 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1187_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_5 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1187 [] = {
g_atype1187_0,
g_atype1187_1,
g_atype1187_2,
g_atype1187_3,
g_atype1187_4,
g_atype1187_5,
};

static const long offsets1187 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @PTROFF(2,0,0,3,0,0),
};

extern const char *names1188[];
static const uint32 types1188 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1188 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1188_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_2 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_3 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1188 [] = {
g_atype1188_0,
g_atype1188_1,
g_atype1188_2,
g_atype1188_3,
g_atype1188_4,
g_atype1188_5,
};

static const long offsets1188 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1189[];
static const uint32 types1189 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1189 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1189_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_2 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_3 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1189 [] = {
g_atype1189_0,
g_atype1189_1,
g_atype1189_2,
g_atype1189_3,
g_atype1189_4,
g_atype1189_5,
};

static const long offsets1189 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names1190[];
static const uint32 types1190 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1190 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1190_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1190_5 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1190 [] = {
g_atype1190_0,
g_atype1190_1,
g_atype1190_2,
g_atype1190_3,
g_atype1190_4,
g_atype1190_5,
};

static const long offsets1190 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R64OFF(2,0,0,3,0,0,0,0),
};

extern const char *names1191[];
static const uint32 types1191 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1191 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1191_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1191_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1191_2 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1191_3 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1191_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1191_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1191 [] = {
g_atype1191_0,
g_atype1191_1,
g_atype1191_2,
g_atype1191_3,
g_atype1191_4,
g_atype1191_5,
};

static const long offsets1191 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1192[];
static const uint32 types1192 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1192 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1192_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_2 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_3 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1192 [] = {
g_atype1192_0,
g_atype1192_1,
g_atype1192_2,
g_atype1192_3,
g_atype1192_4,
g_atype1192_5,
};

static const long offsets1192 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1193[];
static const uint32 types1193 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags1193 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1193_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_5 [] = {1240,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1193 [] = {
g_atype1193_0,
g_atype1193_1,
g_atype1193_2,
g_atype1193_3,
g_atype1193_4,
g_atype1193_5,
};

static const long offsets1193 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R32OFF(2,0,0,3,0),
};

extern const char *names1194[];
static const uint32 types1194 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1194 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1194_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1194 [] = {
g_atype1194_0,
g_atype1194_1,
g_atype1194_2,
g_atype1194_3,
g_atype1194_4,
};

static const long offsets1194 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names1195[];
static const uint32 types1195 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags1195 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1195_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_4 [] = {1216,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1195 [] = {
g_atype1195_0,
g_atype1195_1,
g_atype1195_2,
g_atype1195_3,
g_atype1195_4,
};

static const long offsets1195 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names1196[];
static const uint32 types1196 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1196 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1196_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1196 [] = {
g_atype1196_0,
g_atype1196_1,
g_atype1196_2,
g_atype1196_3,
g_atype1196_4,
};

static const long offsets1196 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1197[];
static const uint32 types1197 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags1197 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1197_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_4 [] = {1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1197 [] = {
g_atype1197_0,
g_atype1197_1,
g_atype1197_2,
g_atype1197_3,
g_atype1197_4,
};

static const long offsets1197 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names1198[];
static const uint32 types1198 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1198 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1198_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_2 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1198 [] = {
g_atype1198_0,
g_atype1198_1,
g_atype1198_2,
g_atype1198_3,
g_atype1198_4,
};

static const long offsets1198 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1199[];
static const uint32 types1199 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1199 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1199_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_2 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1199 [] = {
g_atype1199_0,
g_atype1199_1,
g_atype1199_2,
g_atype1199_3,
g_atype1199_4,
};

static const long offsets1199 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names1200[];
static const uint32 types1200 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1200 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1200_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_2 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1200 [] = {
g_atype1200_0,
g_atype1200_1,
g_atype1200_2,
g_atype1200_3,
g_atype1200_4,
};

static const long offsets1200 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1201[];
static const uint32 types1201 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1201 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1201_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1201 [] = {
g_atype1201_0,
g_atype1201_1,
g_atype1201_2,
g_atype1201_3,
g_atype1201_4,
};

static const long offsets1201 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1202[];
static const uint32 types1202 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags1202 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1202_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_4 [] = {1240,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1202 [] = {
g_atype1202_0,
g_atype1202_1,
g_atype1202_2,
g_atype1202_3,
g_atype1202_4,
};

static const long offsets1202 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R32OFF(2,0,0,2,0),
};

extern const char *names1203[];
static const uint32 types1203 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1203 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1203_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1203_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1203_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1203_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1203_4 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1203 [] = {
g_atype1203_0,
g_atype1203_1,
g_atype1203_2,
g_atype1203_3,
g_atype1203_4,
};

static const long offsets1203 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names1204[];
static const uint32 types1204 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1204 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1204_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1204_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1204_2 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1204_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1204_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1204 [] = {
g_atype1204_0,
g_atype1204_1,
g_atype1204_2,
g_atype1204_3,
g_atype1204_4,
};

static const long offsets1204 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names1205[];
static const uint32 types1205 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1205 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1205_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1205_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1205_2 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1205_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1205_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1205 [] = {
g_atype1205_0,
g_atype1205_1,
g_atype1205_2,
g_atype1205_3,
g_atype1205_4,
};

static const long offsets1205 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1206[];
static const uint32 types1206 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1206 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1206_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_2 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1206 [] = {
g_atype1206_0,
g_atype1206_1,
g_atype1206_2,
g_atype1206_3,
g_atype1206_4,
};

static const long offsets1206 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1207[];
static const uint32 types1207 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1207 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1207_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1207_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1207_2 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1207_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1207_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1207 [] = {
g_atype1207_0,
g_atype1207_1,
g_atype1207_2,
g_atype1207_3,
g_atype1207_4,
};

static const long offsets1207 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1208[];
static const uint32 types1208 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1208 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1208_0 [] = {0xFFF9,2,1025,1219,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_4 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1208 [] = {
g_atype1208_0,
g_atype1208_1,
g_atype1208_2,
g_atype1208_3,
g_atype1208_4,
};

static const long offsets1208 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @PTROFF(2,0,0,2,0,0),
};

extern const char *names1210[];
static const uint32 types1210 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1210 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1210_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1210 [] = {
g_atype1210_0,
};

static const long offsets1210 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1212[];
static const uint32 types1212 [] =
{
SK_REF,
};

static const uint16 attr_flags1212 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1212_0 [] = {0xFF01,1082,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1212 [] = {
g_atype1212_0,
};

static const long offsets1212 [] =
{
0,
};

extern const char *names1213[];
static const uint32 types1213 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1213 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1213_0 [] = {0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_1 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1213 [] = {
g_atype1213_0,
g_atype1213_1,
};

static const long offsets1213 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1215[];
static const uint32 types1215 [] =
{
SK_INT64,
};

static const uint16 attr_flags1215 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1215_0 [] = {1216,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1215 [] = {
g_atype1215_0,
};

static const long offsets1215 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1216[];
static const uint32 types1216 [] =
{
SK_INT64,
};

static const uint16 attr_flags1216 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1216_0 [] = {1216,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1216 [] = {
g_atype1216_0,
};

static const long offsets1216 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1217[];
static const uint32 types1217 [] =
{
SK_INT64,
};

static const uint16 attr_flags1217 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1217_0 [] = {1216,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1217 [] = {
g_atype1217_0,
};

static const long offsets1217 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1218[];
static const uint32 types1218 [] =
{
SK_INT32,
};

static const uint16 attr_flags1218 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1218_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1218 [] = {
g_atype1218_0,
};

static const long offsets1218 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1219[];
static const uint32 types1219 [] =
{
SK_INT32,
};

static const uint16 attr_flags1219 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1219_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1219 [] = {
g_atype1219_0,
};

static const long offsets1219 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1220[];
static const uint32 types1220 [] =
{
SK_INT32,
};

static const uint16 attr_flags1220 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1220_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1220 [] = {
g_atype1220_0,
};

static const long offsets1220 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1221[];
static const uint32 types1221 [] =
{
SK_INT16,
};

static const uint16 attr_flags1221 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1221_0 [] = {1222,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1221 [] = {
g_atype1221_0,
};

static const long offsets1221 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1222[];
static const uint32 types1222 [] =
{
SK_INT16,
};

static const uint16 attr_flags1222 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1222_0 [] = {1222,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1222 [] = {
g_atype1222_0,
};

static const long offsets1222 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1223[];
static const uint32 types1223 [] =
{
SK_INT16,
};

static const uint16 attr_flags1223 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1223_0 [] = {1222,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1223 [] = {
g_atype1223_0,
};

static const long offsets1223 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1224[];
static const uint32 types1224 [] =
{
SK_INT8,
};

static const uint16 attr_flags1224 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1224_0 [] = {1225,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1224 [] = {
g_atype1224_0,
};

static const long offsets1224 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1225[];
static const uint32 types1225 [] =
{
SK_INT8,
};

static const uint16 attr_flags1225 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1225_0 [] = {1225,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1225 [] = {
g_atype1225_0,
};

static const long offsets1225 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1226[];
static const uint32 types1226 [] =
{
SK_INT8,
};

static const uint16 attr_flags1226 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1226_0 [] = {1225,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1226 [] = {
g_atype1226_0,
};

static const long offsets1226 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1227[];
static const uint32 types1227 [] =
{
SK_UINT64,
};

static const uint16 attr_flags1227 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1227_0 [] = {1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1227 [] = {
g_atype1227_0,
};

static const long offsets1227 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1228[];
static const uint32 types1228 [] =
{
SK_UINT64,
};

static const uint16 attr_flags1228 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1228_0 [] = {1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1228 [] = {
g_atype1228_0,
};

static const long offsets1228 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1229[];
static const uint32 types1229 [] =
{
SK_UINT64,
};

static const uint16 attr_flags1229 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1229_0 [] = {1228,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1229 [] = {
g_atype1229_0,
};

static const long offsets1229 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names1230[];
static const uint32 types1230 [] =
{
SK_UINT32,
};

static const uint16 attr_flags1230 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1230_0 [] = {1231,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1230 [] = {
g_atype1230_0,
};

static const long offsets1230 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1231[];
static const uint32 types1231 [] =
{
SK_UINT32,
};

static const uint16 attr_flags1231 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1231_0 [] = {1231,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1231 [] = {
g_atype1231_0,
};

static const long offsets1231 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1232[];
static const uint32 types1232 [] =
{
SK_UINT32,
};

static const uint16 attr_flags1232 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1232_0 [] = {1231,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1232 [] = {
g_atype1232_0,
};

static const long offsets1232 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1233[];
static const uint32 types1233 [] =
{
SK_UINT16,
};

static const uint16 attr_flags1233 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1233_0 [] = {1234,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1233 [] = {
g_atype1233_0,
};

static const long offsets1233 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1234[];
static const uint32 types1234 [] =
{
SK_UINT16,
};

static const uint16 attr_flags1234 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1234_0 [] = {1234,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1234 [] = {
g_atype1234_0,
};

static const long offsets1234 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1235[];
static const uint32 types1235 [] =
{
SK_UINT16,
};

static const uint16 attr_flags1235 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1235_0 [] = {1234,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1235 [] = {
g_atype1235_0,
};

static const long offsets1235 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names1236[];
static const uint32 types1236 [] =
{
SK_UINT8,
};

static const uint16 attr_flags1236 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1236_0 [] = {1237,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1236 [] = {
g_atype1236_0,
};

static const long offsets1236 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1237[];
static const uint32 types1237 [] =
{
SK_UINT8,
};

static const uint16 attr_flags1237 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1237_0 [] = {1237,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1237 [] = {
g_atype1237_0,
};

static const long offsets1237 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1238[];
static const uint32 types1238 [] =
{
SK_UINT8,
};

static const uint16 attr_flags1238 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1238_0 [] = {1237,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1238 [] = {
g_atype1238_0,
};

static const long offsets1238 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1239[];
static const uint32 types1239 [] =
{
SK_REAL32,
};

static const uint16 attr_flags1239 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1239_0 [] = {1240,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1239 [] = {
g_atype1239_0,
};

static const long offsets1239 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names1240[];
static const uint32 types1240 [] =
{
SK_REAL32,
};

static const uint16 attr_flags1240 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1240_0 [] = {1240,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1240 [] = {
g_atype1240_0,
};

static const long offsets1240 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names1241[];
static const uint32 types1241 [] =
{
SK_REAL32,
};

static const uint16 attr_flags1241 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1241_0 [] = {1240,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1241 [] = {
g_atype1241_0,
};

static const long offsets1241 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names1242[];
static const uint32 types1242 [] =
{
SK_REAL64,
};

static const uint16 attr_flags1242 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1242_0 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1242 [] = {
g_atype1242_0,
};

static const long offsets1242 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names1243[];
static const uint32 types1243 [] =
{
SK_REAL64,
};

static const uint16 attr_flags1243 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1243_0 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1243 [] = {
g_atype1243_0,
};

static const long offsets1243 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names1244[];
static const uint32 types1244 [] =
{
SK_REAL64,
};

static const uint16 attr_flags1244 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1244_0 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1244 [] = {
g_atype1244_0,
};

static const long offsets1244 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names1245[];
static const uint32 types1245 [] =
{
SK_REF,
};

static const uint16 attr_flags1245 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1245_0 [] = {0xFF01,948,0xFF01,1208,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1245 [] = {
g_atype1245_0,
};

static const long offsets1245 [] =
{
0,
};

extern const char *names1246[];
static const uint32 types1246 [] =
{
SK_REF,
};

static const uint16 attr_flags1246 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1246_0 [] = {0xFF01,851,0xFF01,1208,0xFF01,1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1246 [] = {
g_atype1246_0,
};

static const long offsets1246 [] =
{
0,
};

extern const char *names1252[];
static const uint32 types1252 [] =
{
SK_REF,
};

static const uint16 attr_flags1252 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1252_0 [] = {0xFF01,1086,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1252 [] = {
g_atype1252_0,
};

static const long offsets1252 [] =
{
0,
};

extern const char *names1254[];
static const uint32 types1254 [] =
{
SK_REF,
SK_BOOL,
SK_POINTER,
};

static const uint16 attr_flags1254 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1254_0 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_2 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1254 [] = {
g_atype1254_0,
g_atype1254_1,
g_atype1254_2,
};

static const long offsets1254 [] =
{
0,
+ @CHROFF(1,0),
+ @PTROFF(1,1,0,0,0,0),
};

extern const char *names1255[];
static const uint32 types1255 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1255 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1255_0 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_2 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_3 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_4 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_5 [] = {1086,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1255 [] = {
g_atype1255_0,
g_atype1255_1,
g_atype1255_2,
g_atype1255_3,
g_atype1255_4,
g_atype1255_5,
};

static const long offsets1255 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names1256[];
static const uint32 types1256 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1256 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1256_0 [] = {0xFF01,142,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_1 [] = {0xFF01,141,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1256 [] = {
g_atype1256_0,
g_atype1256_1,
};

static const long offsets1256 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1257[];
static const uint32 types1257 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1257 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1257_0 [] = {0xFF01,262,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_2 [] = {0xFF01,1082,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1257 [] = {
g_atype1257_0,
g_atype1257_1,
g_atype1257_2,
};

static const long offsets1257 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1258[];
static const uint32 types1258 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1258 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1258_0 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_1 [] = {0xFF01,1305,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_2 [] = {1301,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1258 [] = {
g_atype1258_0,
g_atype1258_1,
g_atype1258_2,
};

static const long offsets1258 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1259[];
static const uint32 types1259 [] =
{
SK_REF,
SK_INT32,
SK_EXP + 48,
};

static const uint16 attr_flags1259 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1259_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_2 [] = {48,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1259 [] = {
g_atype1259_0,
g_atype1259_1,
g_atype1259_2,
};

static const long offsets1259 [] =
{
0,
+ @LNGOFF(2,0,0,0),
+ @OBJSIZ(2,0,0,1,0,0,0,0) + OVERHEAD,
};

extern const char *names1260[];
static const uint32 types1260 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1260 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1260_0 [] = {0xFF01,52,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_3 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1260 [] = {
g_atype1260_0,
g_atype1260_1,
g_atype1260_2,
g_atype1260_3,
};

static const long offsets1260 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
};

extern const char *names1261[];
static const uint32 types1261 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1261 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1261_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_1 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_3 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_4 [] = {62,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_5 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_6 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_10 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_11 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_12 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_13 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_14 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_17 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_18 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_19 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_20 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_21 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_22 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1261 [] = {
g_atype1261_0,
g_atype1261_1,
g_atype1261_2,
g_atype1261_3,
g_atype1261_4,
g_atype1261_5,
g_atype1261_6,
g_atype1261_7,
g_atype1261_8,
g_atype1261_9,
g_atype1261_10,
g_atype1261_11,
g_atype1261_12,
g_atype1261_13,
g_atype1261_14,
g_atype1261_15,
g_atype1261_16,
g_atype1261_17,
g_atype1261_18,
g_atype1261_19,
g_atype1261_20,
g_atype1261_21,
g_atype1261_22,
};

static const long offsets1261 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names1262[];
static const uint32 types1262 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1262 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1262_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_1 [] = {248,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_2 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_3 [] = {0xFF01,1140,0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_9 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1262 [] = {
g_atype1262_0,
g_atype1262_1,
g_atype1262_2,
g_atype1262_3,
g_atype1262_4,
g_atype1262_5,
g_atype1262_6,
g_atype1262_7,
g_atype1262_8,
g_atype1262_9,
};

static const long offsets1262 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
+ @LNGOFF(4,1,0,2),
+ @LNGOFF(4,1,0,3),
+ @LNGOFF(4,1,0,4),
};

extern const char *names1263[];
static const uint32 types1263 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1263 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1263_0 [] = {249,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_1 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_2 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_9 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1263 [] = {
g_atype1263_0,
g_atype1263_1,
g_atype1263_2,
g_atype1263_3,
g_atype1263_4,
g_atype1263_5,
g_atype1263_6,
g_atype1263_7,
g_atype1263_8,
g_atype1263_9,
};

static const long offsets1263 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
+ @LNGOFF(3,1,0,3),
+ @LNGOFF(3,1,0,4),
+ @LNGOFF(3,1,0,5),
};

extern const char *names1264[];
static const uint32 types1264 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1264 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1264_0 [] = {250,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_1 [] = {0xFF01,1141,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_2 [] = {0xFF01,1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_4 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_9 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1264 [] = {
g_atype1264_0,
g_atype1264_1,
g_atype1264_2,
g_atype1264_3,
g_atype1264_4,
g_atype1264_5,
g_atype1264_6,
g_atype1264_7,
g_atype1264_8,
g_atype1264_9,
};

static const long offsets1264 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
+ @LNGOFF(3,1,0,3),
+ @LNGOFF(3,1,0,4),
+ @LNGOFF(3,1,0,5),
};

extern const char *names1265[];
static const uint32 types1265 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1265 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1265_0 [] = {0xFF01,262,0xFFFF};
static const EIF_TYPE_INDEX g_atype1265_1 [] = {0xFF01,1082,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1265 [] = {
g_atype1265_0,
g_atype1265_1,
};

static const long offsets1265 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1266[];
static const uint32 types1266 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT8,
SK_UINT8,
SK_UINT8,
SK_UINT8,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT16,
};

static const uint16 attr_flags1266 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1266_0 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_1 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_2 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_3 [] = {1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_5 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_6 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_7 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_8 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_9 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_10 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_11 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_12 [] = {1234,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1266 [] = {
g_atype1266_0,
g_atype1266_1,
g_atype1266_2,
g_atype1266_3,
g_atype1266_4,
g_atype1266_5,
g_atype1266_6,
g_atype1266_7,
g_atype1266_8,
g_atype1266_9,
g_atype1266_10,
g_atype1266_11,
g_atype1266_12,
};

static const long offsets1266 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @I16OFF(4,5,0),
+ @I16OFF(4,5,1),
+ @I16OFF(4,5,2),
+ @I16OFF(4,5,3),
};

extern const char *names1272[];
static const uint32 types1272 [] =
{
SK_REF,
SK_CHAR8,
SK_CHAR32,
SK_INT32,
};

static const uint16 attr_flags1272 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1272_0 [] = {0xFF01,286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_1 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_2 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1272 [] = {
g_atype1272_0,
g_atype1272_1,
g_atype1272_2,
g_atype1272_3,
};

static const long offsets1272 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names1273[];
static const uint32 types1273 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1273 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1273_0 [] = {0xFF01,286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_1 [] = {0xFF01,122,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_2 [] = {1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_3 [] = {1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_4 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_5 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_7 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_17 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_18 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_19 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_20 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_21 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1273 [] = {
g_atype1273_0,
g_atype1273_1,
g_atype1273_2,
g_atype1273_3,
g_atype1273_4,
g_atype1273_5,
g_atype1273_6,
g_atype1273_7,
g_atype1273_8,
g_atype1273_9,
g_atype1273_10,
g_atype1273_11,
g_atype1273_12,
g_atype1273_13,
g_atype1273_14,
g_atype1273_15,
g_atype1273_16,
g_atype1273_17,
g_atype1273_18,
g_atype1273_19,
g_atype1273_20,
g_atype1273_21,
};

static const long offsets1273 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @LNGOFF(5,2,0,3),
+ @LNGOFF(5,2,0,4),
+ @LNGOFF(5,2,0,5),
+ @LNGOFF(5,2,0,6),
+ @LNGOFF(5,2,0,7),
+ @LNGOFF(5,2,0,8),
+ @LNGOFF(5,2,0,9),
+ @LNGOFF(5,2,0,10),
+ @LNGOFF(5,2,0,11),
+ @LNGOFF(5,2,0,12),
+ @LNGOFF(5,2,0,13),
+ @LNGOFF(5,2,0,14),
};

extern const char *names1274[];
static const uint32 types1274 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1274 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1274_0 [] = {0xFF01,286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_1 [] = {0xFF01,122,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_2 [] = {1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_3 [] = {1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_4 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_5 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_6 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_7 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_8 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_9 [] = {1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_10 [] = {1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_11 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_12 [] = {1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_13 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_14 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_15 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_16 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_17 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_18 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_19 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_20 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_21 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_22 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_23 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_24 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_25 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_26 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_27 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_28 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_29 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_30 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_31 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_32 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_33 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_34 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_35 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_36 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_37 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1274 [] = {
g_atype1274_0,
g_atype1274_1,
g_atype1274_2,
g_atype1274_3,
g_atype1274_4,
g_atype1274_5,
g_atype1274_6,
g_atype1274_7,
g_atype1274_8,
g_atype1274_9,
g_atype1274_10,
g_atype1274_11,
g_atype1274_12,
g_atype1274_13,
g_atype1274_14,
g_atype1274_15,
g_atype1274_16,
g_atype1274_17,
g_atype1274_18,
g_atype1274_19,
g_atype1274_20,
g_atype1274_21,
g_atype1274_22,
g_atype1274_23,
g_atype1274_24,
g_atype1274_25,
g_atype1274_26,
g_atype1274_27,
g_atype1274_28,
g_atype1274_29,
g_atype1274_30,
g_atype1274_31,
g_atype1274_32,
g_atype1274_33,
g_atype1274_34,
g_atype1274_35,
g_atype1274_36,
g_atype1274_37,
};

static const long offsets1274 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @CHROFF(14,1),
+ @CHROFF(14,2),
+ @LNGOFF(14,3,0,0),
+ @LNGOFF(14,3,0,1),
+ @LNGOFF(14,3,0,2),
+ @LNGOFF(14,3,0,3),
+ @LNGOFF(14,3,0,4),
+ @LNGOFF(14,3,0,5),
+ @LNGOFF(14,3,0,6),
+ @LNGOFF(14,3,0,7),
+ @LNGOFF(14,3,0,8),
+ @LNGOFF(14,3,0,9),
+ @LNGOFF(14,3,0,10),
+ @LNGOFF(14,3,0,11),
+ @LNGOFF(14,3,0,12),
+ @LNGOFF(14,3,0,13),
+ @LNGOFF(14,3,0,14),
+ @LNGOFF(14,3,0,15),
+ @LNGOFF(14,3,0,16),
+ @LNGOFF(14,3,0,17),
+ @LNGOFF(14,3,0,18),
+ @LNGOFF(14,3,0,19),
+ @LNGOFF(14,3,0,20),
};

extern const char *names1275[];
static const uint32 types1275 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1275 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1275_0 [] = {0xFF01,286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_1 [] = {0xFF01,122,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_2 [] = {1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_3 [] = {1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_4 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_5 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_6 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_7 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_8 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_9 [] = {1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_10 [] = {1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_11 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_12 [] = {1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_13 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_14 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_15 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_16 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_17 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_19 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_20 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_21 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_22 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_23 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_24 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_25 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_26 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_27 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_28 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_29 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_30 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_31 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_32 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_33 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_34 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_35 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_36 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_37 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_38 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_39 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_40 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_41 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1275 [] = {
g_atype1275_0,
g_atype1275_1,
g_atype1275_2,
g_atype1275_3,
g_atype1275_4,
g_atype1275_5,
g_atype1275_6,
g_atype1275_7,
g_atype1275_8,
g_atype1275_9,
g_atype1275_10,
g_atype1275_11,
g_atype1275_12,
g_atype1275_13,
g_atype1275_14,
g_atype1275_15,
g_atype1275_16,
g_atype1275_17,
g_atype1275_18,
g_atype1275_19,
g_atype1275_20,
g_atype1275_21,
g_atype1275_22,
g_atype1275_23,
g_atype1275_24,
g_atype1275_25,
g_atype1275_26,
g_atype1275_27,
g_atype1275_28,
g_atype1275_29,
g_atype1275_30,
g_atype1275_31,
g_atype1275_32,
g_atype1275_33,
g_atype1275_34,
g_atype1275_35,
g_atype1275_36,
g_atype1275_37,
g_atype1275_38,
g_atype1275_39,
g_atype1275_40,
g_atype1275_41,
};

static const long offsets1275 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @CHROFF(16,3),
+ @LNGOFF(16,4,0,0),
+ @LNGOFF(16,4,0,1),
+ @LNGOFF(16,4,0,2),
+ @LNGOFF(16,4,0,3),
+ @LNGOFF(16,4,0,4),
+ @LNGOFF(16,4,0,5),
+ @LNGOFF(16,4,0,6),
+ @LNGOFF(16,4,0,7),
+ @LNGOFF(16,4,0,8),
+ @LNGOFF(16,4,0,9),
+ @LNGOFF(16,4,0,10),
+ @LNGOFF(16,4,0,11),
+ @LNGOFF(16,4,0,12),
+ @LNGOFF(16,4,0,13),
+ @LNGOFF(16,4,0,14),
+ @LNGOFF(16,4,0,15),
+ @LNGOFF(16,4,0,16),
+ @LNGOFF(16,4,0,17),
+ @LNGOFF(16,4,0,18),
+ @LNGOFF(16,4,0,19),
+ @LNGOFF(16,4,0,20),
+ @LNGOFF(16,4,0,21),
};

extern const char *names1276[];
static const uint32 types1276 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1276 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1276_0 [] = {0xFF01,286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_1 [] = {0xFF01,122,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_2 [] = {1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_3 [] = {1146,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_4 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_5 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_6 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_7 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_8 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_9 [] = {1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_10 [] = {1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_11 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_12 [] = {1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_13 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_14 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_15 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_16 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_17 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_19 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_20 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_21 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_22 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_23 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_24 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_25 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_26 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_27 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_28 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_29 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_30 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_31 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_32 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_33 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_34 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_35 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_36 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_37 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_38 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_39 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_40 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_41 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1276 [] = {
g_atype1276_0,
g_atype1276_1,
g_atype1276_2,
g_atype1276_3,
g_atype1276_4,
g_atype1276_5,
g_atype1276_6,
g_atype1276_7,
g_atype1276_8,
g_atype1276_9,
g_atype1276_10,
g_atype1276_11,
g_atype1276_12,
g_atype1276_13,
g_atype1276_14,
g_atype1276_15,
g_atype1276_16,
g_atype1276_17,
g_atype1276_18,
g_atype1276_19,
g_atype1276_20,
g_atype1276_21,
g_atype1276_22,
g_atype1276_23,
g_atype1276_24,
g_atype1276_25,
g_atype1276_26,
g_atype1276_27,
g_atype1276_28,
g_atype1276_29,
g_atype1276_30,
g_atype1276_31,
g_atype1276_32,
g_atype1276_33,
g_atype1276_34,
g_atype1276_35,
g_atype1276_36,
g_atype1276_37,
g_atype1276_38,
g_atype1276_39,
g_atype1276_40,
g_atype1276_41,
};

static const long offsets1276 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @CHROFF(16,3),
+ @LNGOFF(16,4,0,0),
+ @LNGOFF(16,4,0,1),
+ @LNGOFF(16,4,0,2),
+ @LNGOFF(16,4,0,3),
+ @LNGOFF(16,4,0,4),
+ @LNGOFF(16,4,0,5),
+ @LNGOFF(16,4,0,6),
+ @LNGOFF(16,4,0,7),
+ @LNGOFF(16,4,0,8),
+ @LNGOFF(16,4,0,9),
+ @LNGOFF(16,4,0,10),
+ @LNGOFF(16,4,0,11),
+ @LNGOFF(16,4,0,12),
+ @LNGOFF(16,4,0,13),
+ @LNGOFF(16,4,0,14),
+ @LNGOFF(16,4,0,15),
+ @LNGOFF(16,4,0,16),
+ @LNGOFF(16,4,0,17),
+ @LNGOFF(16,4,0,18),
+ @LNGOFF(16,4,0,19),
+ @LNGOFF(16,4,0,20),
+ @LNGOFF(16,4,0,21),
};

extern const char *names1279[];
static const uint32 types1279 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1279 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1279_0 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1279 [] = {
g_atype1279_0,
};

static const long offsets1279 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1280[];
static const uint32 types1280 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1280 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1280_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_1 [] = {62,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_3 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1280 [] = {
g_atype1280_0,
g_atype1280_1,
g_atype1280_2,
g_atype1280_3,
};

static const long offsets1280 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names1282[];
static const uint32 types1282 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1282 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1282_0 [] = {0xFF01,852,0xFF01,1093,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_1 [] = {0xFF01,878,0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_2 [] = {0xFF01,878,0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_3 [] = {1342,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_6 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1282 [] = {
g_atype1282_0,
g_atype1282_1,
g_atype1282_2,
g_atype1282_3,
g_atype1282_4,
g_atype1282_5,
g_atype1282_6,
};

static const long offsets1282 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
};

extern const char *names1283[];
static const uint32 types1283 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1283 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1283_0 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1283 [] = {
g_atype1283_0,
g_atype1283_1,
g_atype1283_2,
};

static const long offsets1283 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1284[];
static const uint32 types1284 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1284 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1284_0 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1284 [] = {
g_atype1284_0,
g_atype1284_1,
g_atype1284_2,
};

static const long offsets1284 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1285[];
static const uint32 types1285 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1285 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1285_0 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1285 [] = {
g_atype1285_0,
g_atype1285_1,
g_atype1285_2,
};

static const long offsets1285 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1286[];
static const uint32 types1286 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1286 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1286_0 [] = {1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1286 [] = {
g_atype1286_0,
g_atype1286_1,
g_atype1286_2,
};

static const long offsets1286 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1287[];
static const uint32 types1287 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1287 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1287_0 [] = {0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_4 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1287 [] = {
g_atype1287_0,
g_atype1287_1,
g_atype1287_2,
g_atype1287_3,
g_atype1287_4,
};

static const long offsets1287 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names1288[];
static const uint32 types1288 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1288 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1288_0 [] = {0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_1 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_2 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_3 [] = {1099,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_4 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_7 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1288 [] = {
g_atype1288_0,
g_atype1288_1,
g_atype1288_2,
g_atype1288_3,
g_atype1288_4,
g_atype1288_5,
g_atype1288_6,
g_atype1288_7,
};

static const long offsets1288 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names1289[];
static const uint32 types1289 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
};

static const uint16 attr_flags1289 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1289_0 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_1 [] = {0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_2 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_3 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_4 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_5 [] = {0xFF01,1099,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_6 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_7 [] = {0xFF01,860,0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_8 [] = {1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_9 [] = {1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_10 [] = {0xFF01,851,0xFF01,1100,0xFF01,1099,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_11 [] = {860,0xFF01,1154,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_12 [] = {948,0xFF01,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_13 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_14 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_15 [] = {0xFF01,948,0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_16 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_17 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_19 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_20 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_21 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1289 [] = {
g_atype1289_0,
g_atype1289_1,
g_atype1289_2,
g_atype1289_3,
g_atype1289_4,
g_atype1289_5,
g_atype1289_6,
g_atype1289_7,
g_atype1289_8,
g_atype1289_9,
g_atype1289_10,
g_atype1289_11,
g_atype1289_12,
g_atype1289_13,
g_atype1289_14,
g_atype1289_15,
g_atype1289_16,
g_atype1289_17,
g_atype1289_18,
g_atype1289_19,
g_atype1289_20,
g_atype1289_21,
};

static const long offsets1289 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @CHROFF(16,0),
+ @CHROFF(16,1),
+ @CHROFF(16,2),
+ @CHROFF(16,3),
+ @LNGOFF(16,4,0,0),
+ @LNGOFF(16,4,0,1),
};

extern const char *names1290[];
static const uint32 types1290 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1290 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1290_0 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_1 [] = {948,0xFF01,1001,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1290 [] = {
g_atype1290_0,
g_atype1290_1,
};

static const long offsets1290 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1291[];
static const uint32 types1291 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1291 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1291_0 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_1 [] = {948,0xFF01,1001,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1291 [] = {
g_atype1291_0,
g_atype1291_1,
};

static const long offsets1291 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1292[];
static const uint32 types1292 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1292 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1292_0 [] = {1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_1 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_2 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_3 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_4 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_5 [] = {1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_8 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1292 [] = {
g_atype1292_0,
g_atype1292_1,
g_atype1292_2,
g_atype1292_3,
g_atype1292_4,
g_atype1292_5,
g_atype1292_6,
g_atype1292_7,
g_atype1292_8,
};

static const long offsets1292 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
};

extern const char *names1293[];
static const uint32 types1293 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1293 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1293_0 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_1 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_2 [] = {1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_3 [] = {1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_4 [] = {1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_5 [] = {0xFF01,948,0xFF01,1155,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_6 [] = {0xFF01,948,0xFF01,1157,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_7 [] = {0xFF01,860,0xFF01,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_8 [] = {54,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_9 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1293 [] = {
g_atype1293_0,
g_atype1293_1,
g_atype1293_2,
g_atype1293_3,
g_atype1293_4,
g_atype1293_5,
g_atype1293_6,
g_atype1293_7,
g_atype1293_8,
g_atype1293_9,
};

static const long offsets1293 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
};

extern const char *names1294[];
static const uint32 types1294 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1294 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1294_0 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_1 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_2 [] = {0xFF01,402,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1294 [] = {
g_atype1294_0,
g_atype1294_1,
g_atype1294_2,
};

static const long offsets1294 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1295[];
static const uint32 types1295 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
};

static const uint16 attr_flags1295 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1295_0 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_1 [] = {948,0xFF01,1001,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_2 [] = {0xFF01,402,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_3 [] = {0xFF01,1261,0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_4 [] = {0xFF01,397,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_5 [] = {0xFF01,1100,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_6 [] = {0xFF01,851,0xFF01,0xFFF9,2,1025,0xFF01,1100,0xFF01,1100,0xFF01,1099,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_7 [] = {1231,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1295 [] = {
g_atype1295_0,
g_atype1295_1,
g_atype1295_2,
g_atype1295_3,
g_atype1295_4,
g_atype1295_5,
g_atype1295_6,
g_atype1295_7,
};

static const long offsets1295 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @LNGOFF(7,0,0,0),
};

extern const char *names1297[];
static const uint32 types1297 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1297 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1297_0 [] = {0xFF01,943,0xFF01,0xFFF9,5,1025,1101,0xFF01,1101,0xFF01,1084,0xFF01,1084,0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_1 [] = {0xFF01,165,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_2 [] = {0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_3 [] = {860,0xFF01,861,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_4 [] = {860,0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_5 [] = {948,0xFF01,1333,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_6 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_7 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_8 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_9 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_10 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_11 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_12 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_13 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_14 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_15 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_17 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_18 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1297 [] = {
g_atype1297_0,
g_atype1297_1,
g_atype1297_2,
g_atype1297_3,
g_atype1297_4,
g_atype1297_5,
g_atype1297_6,
g_atype1297_7,
g_atype1297_8,
g_atype1297_9,
g_atype1297_10,
g_atype1297_11,
g_atype1297_12,
g_atype1297_13,
g_atype1297_14,
g_atype1297_15,
g_atype1297_16,
g_atype1297_17,
g_atype1297_18,
};

static const long offsets1297 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
+ @LNGOFF(16,0,0,0),
+ @LNGOFF(16,0,0,1),
+ @LNGOFF(16,0,0,2),
};

extern const char *names1300[];
static const uint32 types1300 [] =
{
SK_REF,
};

static const uint16 attr_flags1300 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1300_0 [] = {0xFF01,1084,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1300 [] = {
g_atype1300_0,
};

static const long offsets1300 [] =
{
0,
};

extern const char *names1301[];
static const uint32 types1301 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1301 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1301_0 [] = {0xFFF9,2,1025,0xFF01,950,1219,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_1 [] = {0xFFF9,2,1025,0xFF01,950,1219,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_2 [] = {0xFFF9,2,1025,0xFF01,950,1219,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_3 [] = {0xFFF9,2,1025,0xFF01,950,1219,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_4 [] = {191,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_5 [] = {191,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_6 [] = {0xFF01,860,0xFF01,0xFFF9,2,1025,1265,1265,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_7 [] = {0xFF01,860,0xFF01,860,0xFF01,69,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_8 [] = {1100,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1301 [] = {
g_atype1301_0,
g_atype1301_1,
g_atype1301_2,
g_atype1301_3,
g_atype1301_4,
g_atype1301_5,
g_atype1301_6,
g_atype1301_7,
g_atype1301_8,
};

static const long offsets1301 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
};

extern const char *names1302[];
static const uint32 types1302 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1302 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1302_0 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_1 [] = {1301,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1302 [] = {
g_atype1302_0,
g_atype1302_1,
};

static const long offsets1302 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1303[];
static const uint32 types1303 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1303 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1303_0 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_1 [] = {1301,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1303 [] = {
g_atype1303_0,
g_atype1303_1,
};

static const long offsets1303 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1304[];
static const uint32 types1304 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1304 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1304_0 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_1 [] = {1301,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1304 [] = {
g_atype1304_0,
g_atype1304_1,
};

static const long offsets1304 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1305[];
static const uint32 types1305 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1305 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1305_0 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_1 [] = {1301,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1305 [] = {
g_atype1305_0,
g_atype1305_1,
};

static const long offsets1305 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1306[];
static const uint32 types1306 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1306 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1306_0 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_1 [] = {1301,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1306 [] = {
g_atype1306_0,
g_atype1306_1,
};

static const long offsets1306 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1308[];
static const uint32 types1308 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1308 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1308_0 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_1 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_3 [] = {113,0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_4 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_5 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_9 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_10 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1308 [] = {
g_atype1308_0,
g_atype1308_1,
g_atype1308_2,
g_atype1308_3,
g_atype1308_4,
g_atype1308_5,
g_atype1308_6,
g_atype1308_7,
g_atype1308_8,
g_atype1308_9,
g_atype1308_10,
};

static const long offsets1308 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @PTROFF(6,2,0,1,0,0),
+ @PTROFF(6,2,0,1,0,1),
};

extern const char *names1309[];
static const uint32 types1309 [] =
{
SK_REF,
};

static const uint16 attr_flags1309 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1309_0 [] = {0xFF01,1082,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1309 [] = {
g_atype1309_0,
};

static const long offsets1309 [] =
{
0,
};

extern const char *names1310[];
static const uint32 types1310 [] =
{
SK_REF,
};

static const uint16 attr_flags1310 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1310_0 [] = {0xFF01,1082,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1310 [] = {
g_atype1310_0,
};

static const long offsets1310 [] =
{
0,
};

extern const char *names1311[];
static const uint32 types1311 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1311 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1311_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_1 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_3 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_4 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_5 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_6 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_9 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_10 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_11 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_12 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_13 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_17 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_18 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_19 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_20 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_21 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1311 [] = {
g_atype1311_0,
g_atype1311_1,
g_atype1311_2,
g_atype1311_3,
g_atype1311_4,
g_atype1311_5,
g_atype1311_6,
g_atype1311_7,
g_atype1311_8,
g_atype1311_9,
g_atype1311_10,
g_atype1311_11,
g_atype1311_12,
g_atype1311_13,
g_atype1311_14,
g_atype1311_15,
g_atype1311_16,
g_atype1311_17,
g_atype1311_18,
g_atype1311_19,
g_atype1311_20,
g_atype1311_21,
};

static const long offsets1311 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1312[];
static const uint32 types1312 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1312 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1312_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_1 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_3 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_4 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_5 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_6 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_9 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_10 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_11 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_12 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_13 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_17 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_18 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_19 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_20 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_21 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1312 [] = {
g_atype1312_0,
g_atype1312_1,
g_atype1312_2,
g_atype1312_3,
g_atype1312_4,
g_atype1312_5,
g_atype1312_6,
g_atype1312_7,
g_atype1312_8,
g_atype1312_9,
g_atype1312_10,
g_atype1312_11,
g_atype1312_12,
g_atype1312_13,
g_atype1312_14,
g_atype1312_15,
g_atype1312_16,
g_atype1312_17,
g_atype1312_18,
g_atype1312_19,
g_atype1312_20,
g_atype1312_21,
};

static const long offsets1312 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1313[];
static const uint32 types1313 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1313 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1313_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_1 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_3 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_4 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_5 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_6 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_9 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_10 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_11 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_12 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_13 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_14 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_15 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_17 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_18 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_19 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_20 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_21 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1313 [] = {
g_atype1313_0,
g_atype1313_1,
g_atype1313_2,
g_atype1313_3,
g_atype1313_4,
g_atype1313_5,
g_atype1313_6,
g_atype1313_7,
g_atype1313_8,
g_atype1313_9,
g_atype1313_10,
g_atype1313_11,
g_atype1313_12,
g_atype1313_13,
g_atype1313_14,
g_atype1313_15,
g_atype1313_16,
g_atype1313_17,
g_atype1313_18,
g_atype1313_19,
g_atype1313_20,
g_atype1313_21,
};

static const long offsets1313 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1314[];
static const uint32 types1314 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1314 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1314_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_1 [] = {114,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_2 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_3 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_4 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1314 [] = {
g_atype1314_0,
g_atype1314_1,
g_atype1314_2,
g_atype1314_3,
g_atype1314_4,
};

static const long offsets1314 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1315[];
static const uint32 types1315 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1315 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1315_0 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_1 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_2 [] = {0xFF01,1086,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_3 [] = {62,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_4 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_5 [] = {114,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_6 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_7 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_8 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_11 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_12 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_13 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_14 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_15 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_16 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_17 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_18 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_19 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_20 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_21 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_22 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_23 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_24 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1315_25 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1315 [] = {
g_atype1315_0,
g_atype1315_1,
g_atype1315_2,
g_atype1315_3,
g_atype1315_4,
g_atype1315_5,
g_atype1315_6,
g_atype1315_7,
g_atype1315_8,
g_atype1315_9,
g_atype1315_10,
g_atype1315_11,
g_atype1315_12,
g_atype1315_13,
g_atype1315_14,
g_atype1315_15,
g_atype1315_16,
g_atype1315_17,
g_atype1315_18,
g_atype1315_19,
g_atype1315_20,
g_atype1315_21,
g_atype1315_22,
g_atype1315_23,
g_atype1315_24,
g_atype1315_25,
};

static const long offsets1315 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @I16OFF(7,8,0),
+ @I16OFF(7,8,1),
+ @LNGOFF(7,8,2,0),
+ @LNGOFF(7,8,2,1),
+ @LNGOFF(7,8,2,2),
+ @LNGOFF(7,8,2,3),
+ @R32OFF(7,8,2,4,0),
+ @PTROFF(7,8,2,4,1,0),
+ @I64OFF(7,8,2,4,1,1,0),
+ @I64OFF(7,8,2,4,1,1,1),
+ @R64OFF(7,8,2,4,1,1,2,0),
};

extern const char *names1316[];
static const uint32 types1316 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1316 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1316_0 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_1 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_3 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_4 [] = {114,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_5 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_6 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_7 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_11 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_12 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_13 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_14 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_15 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_17 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_18 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_19 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_20 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_21 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_22 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1316_23 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1316 [] = {
g_atype1316_0,
g_atype1316_1,
g_atype1316_2,
g_atype1316_3,
g_atype1316_4,
g_atype1316_5,
g_atype1316_6,
g_atype1316_7,
g_atype1316_8,
g_atype1316_9,
g_atype1316_10,
g_atype1316_11,
g_atype1316_12,
g_atype1316_13,
g_atype1316_14,
g_atype1316_15,
g_atype1316_16,
g_atype1316_17,
g_atype1316_18,
g_atype1316_19,
g_atype1316_20,
g_atype1316_21,
g_atype1316_22,
g_atype1316_23,
};

static const long offsets1316 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1317[];
static const uint32 types1317 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1317 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1317_0 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_1 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_3 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_4 [] = {114,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_5 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_6 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_7 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_11 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_12 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_13 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_14 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_15 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_17 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_18 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_19 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_20 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_21 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_22 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_23 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1317 [] = {
g_atype1317_0,
g_atype1317_1,
g_atype1317_2,
g_atype1317_3,
g_atype1317_4,
g_atype1317_5,
g_atype1317_6,
g_atype1317_7,
g_atype1317_8,
g_atype1317_9,
g_atype1317_10,
g_atype1317_11,
g_atype1317_12,
g_atype1317_13,
g_atype1317_14,
g_atype1317_15,
g_atype1317_16,
g_atype1317_17,
g_atype1317_18,
g_atype1317_19,
g_atype1317_20,
g_atype1317_21,
g_atype1317_22,
g_atype1317_23,
};

static const long offsets1317 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1318[];
static const uint32 types1318 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1318 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1318_0 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_1 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_3 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_4 [] = {114,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_5 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_6 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_7 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_11 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_12 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_13 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_14 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_15 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_17 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_18 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_19 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_20 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_21 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_22 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_23 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1318 [] = {
g_atype1318_0,
g_atype1318_1,
g_atype1318_2,
g_atype1318_3,
g_atype1318_4,
g_atype1318_5,
g_atype1318_6,
g_atype1318_7,
g_atype1318_8,
g_atype1318_9,
g_atype1318_10,
g_atype1318_11,
g_atype1318_12,
g_atype1318_13,
g_atype1318_14,
g_atype1318_15,
g_atype1318_16,
g_atype1318_17,
g_atype1318_18,
g_atype1318_19,
g_atype1318_20,
g_atype1318_21,
g_atype1318_22,
g_atype1318_23,
};

static const long offsets1318 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1319[];
static const uint32 types1319 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1319 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1319_0 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_1 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_2 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_3 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_4 [] = {114,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_5 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_6 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_7 [] = {1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_11 [] = {1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_12 [] = {1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_13 [] = {1234,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_14 [] = {1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_15 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_16 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_17 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_18 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_19 [] = {1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_20 [] = {1070,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_21 [] = {1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_22 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_23 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1319 [] = {
g_atype1319_0,
g_atype1319_1,
g_atype1319_2,
g_atype1319_3,
g_atype1319_4,
g_atype1319_5,
g_atype1319_6,
g_atype1319_7,
g_atype1319_8,
g_atype1319_9,
g_atype1319_10,
g_atype1319_11,
g_atype1319_12,
g_atype1319_13,
g_atype1319_14,
g_atype1319_15,
g_atype1319_16,
g_atype1319_17,
g_atype1319_18,
g_atype1319_19,
g_atype1319_20,
g_atype1319_21,
g_atype1319_22,
g_atype1319_23,
};

static const long offsets1319 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1320[];
static const uint32 types1320 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1320 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1320_0 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1320_1 [] = {1319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1320_2 [] = {0xFF01,1100,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1320 [] = {
g_atype1320_0,
g_atype1320_1,
g_atype1320_2,
};

static const long offsets1320 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1321[];
static const uint32 types1321 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1321 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1321_0 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1321_1 [] = {1319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1321_2 [] = {0xFF01,1100,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1321 [] = {
g_atype1321_0,
g_atype1321_1,
g_atype1321_2,
};

static const long offsets1321 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1322[];
static const uint32 types1322 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1322 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1322_0 [] = {0xFF01,1084,0xFFFF};
static const EIF_TYPE_INDEX g_atype1322_1 [] = {1319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1322_2 [] = {0xFF01,1100,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1322 [] = {
g_atype1322_0,
g_atype1322_1,
g_atype1322_2,
};

static const long offsets1322 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1323[];
static const uint32 types1323 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1323 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1323_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1323_1 [] = {0xFF01,943,0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1323_2 [] = {1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype1323_3 [] = {0xFF01,1209,0xFFFF};
static const EIF_TYPE_INDEX g_atype1323_4 [] = {0xFF01,1209,0xFFFF};
static const EIF_TYPE_INDEX g_atype1323_5 [] = {0xFF01,1210,0xFFFF};
static const EIF_TYPE_INDEX g_atype1323_6 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1323_7 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1323_8 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1323_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1323_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1323_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1323_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1323_13 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1323 [] = {
g_atype1323_0,
g_atype1323_1,
g_atype1323_2,
g_atype1323_3,
g_atype1323_4,
g_atype1323_5,
g_atype1323_6,
g_atype1323_7,
g_atype1323_8,
g_atype1323_9,
g_atype1323_10,
g_atype1323_11,
g_atype1323_12,
g_atype1323_13,
};

static const long offsets1323 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
+ @LNGOFF(9,2,0,1),
+ @LNGOFF(9,2,0,2),
};

extern const char *names1324[];
static const uint32 types1324 [] =
{
SK_REF,
};

static const uint16 attr_flags1324 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1324_0 [] = {0xFF01,136,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1324 [] = {
g_atype1324_0,
};

static const long offsets1324 [] =
{
0,
};

extern const char *names1325[];
static const uint32 types1325 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1325 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1325_0 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1325_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1325_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1325_3 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1325 [] = {
g_atype1325_0,
g_atype1325_1,
g_atype1325_2,
g_atype1325_3,
};

static const long offsets1325 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @PTROFF(1,1,0,1,0,0),
};

extern const char *names1326[];
static const uint32 types1326 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1326 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1326_0 [] = {444,0xFFFF};
static const EIF_TYPE_INDEX g_atype1326_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1326_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1326_3 [] = {1070,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1326 [] = {
g_atype1326_0,
g_atype1326_1,
g_atype1326_2,
g_atype1326_3,
};

static const long offsets1326 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @PTROFF(1,1,0,1,0,0),
};

extern const char *names1327[];
static const uint32 types1327 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1327 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1327_0 [] = {1097,0xFFFF};
static const EIF_TYPE_INDEX g_atype1327_1 [] = {1097,0xFFFF};
static const EIF_TYPE_INDEX g_atype1327_2 [] = {1097,0xFFFF};
static const EIF_TYPE_INDEX g_atype1327_3 [] = {943,0xFF01,0xFFF9,2,1025,0xFF01,1097,948,0xFF01,0xFFF9,2,1025,0xFF01,1162,0xFF01,1162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1327_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1327_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1327_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1327_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1327_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1327_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1327_10 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1327 [] = {
g_atype1327_0,
g_atype1327_1,
g_atype1327_2,
g_atype1327_3,
g_atype1327_4,
g_atype1327_5,
g_atype1327_6,
g_atype1327_7,
g_atype1327_8,
g_atype1327_9,
g_atype1327_10,
};

static const long offsets1327 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @LNGOFF(4,5,0,0),
+ @LNGOFF(4,5,0,1),
};

extern const char *names1333[];
static const uint32 types1333 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1333 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1333_0 [] = {0xFF01,39,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_1 [] = {0xFF01,38,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_2 [] = {0xFF01,37,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_3 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_4 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_5 [] = {0xFF01,37,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_6 [] = {37,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_10 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_11 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_12 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_13 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_14 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_15 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_16 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_17 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_19 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_20 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_21 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_22 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_23 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_24 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_25 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_26 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_27 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_28 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_29 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_30 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1333 [] = {
g_atype1333_0,
g_atype1333_1,
g_atype1333_2,
g_atype1333_3,
g_atype1333_4,
g_atype1333_5,
g_atype1333_6,
g_atype1333_7,
g_atype1333_8,
g_atype1333_9,
g_atype1333_10,
g_atype1333_11,
g_atype1333_12,
g_atype1333_13,
g_atype1333_14,
g_atype1333_15,
g_atype1333_16,
g_atype1333_17,
g_atype1333_18,
g_atype1333_19,
g_atype1333_20,
g_atype1333_21,
g_atype1333_22,
g_atype1333_23,
g_atype1333_24,
g_atype1333_25,
g_atype1333_26,
g_atype1333_27,
g_atype1333_28,
g_atype1333_29,
g_atype1333_30,
};

static const long offsets1333 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @CHROFF(7,8),
+ @CHROFF(7,9),
+ @CHROFF(7,10),
+ @CHROFF(7,11),
+ @CHROFF(7,12),
+ @LNGOFF(7,13,0,0),
+ @LNGOFF(7,13,0,1),
+ @LNGOFF(7,13,0,2),
+ @LNGOFF(7,13,0,3),
+ @LNGOFF(7,13,0,4),
+ @LNGOFF(7,13,0,5),
+ @LNGOFF(7,13,0,6),
+ @LNGOFF(7,13,0,7),
+ @LNGOFF(7,13,0,8),
+ @LNGOFF(7,13,0,9),
+ @LNGOFF(7,13,0,10),
};

extern const char *names1334[];
static const uint32 types1334 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1334 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1334_0 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_1 [] = {0xFF01,39,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_2 [] = {0xFF01,38,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_3 [] = {0xFF01,37,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_4 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_5 [] = {0xFF01,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_6 [] = {0xFF01,37,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_7 [] = {37,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_8 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_9 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_10 [] = {0xFF01,1142,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_11 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_12 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_13 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_14 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_15 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_16 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_17 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_18 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_19 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_20 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_21 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_22 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_23 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_24 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_25 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_26 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_27 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_28 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_29 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_30 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_31 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_32 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_33 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_34 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_35 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_36 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_37 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_38 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_39 [] = {1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_40 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_41 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_42 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_43 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_44 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_45 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_46 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_47 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_48 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_49 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_50 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_51 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1334 [] = {
g_atype1334_0,
g_atype1334_1,
g_atype1334_2,
g_atype1334_3,
g_atype1334_4,
g_atype1334_5,
g_atype1334_6,
g_atype1334_7,
g_atype1334_8,
g_atype1334_9,
g_atype1334_10,
g_atype1334_11,
g_atype1334_12,
g_atype1334_13,
g_atype1334_14,
g_atype1334_15,
g_atype1334_16,
g_atype1334_17,
g_atype1334_18,
g_atype1334_19,
g_atype1334_20,
g_atype1334_21,
g_atype1334_22,
g_atype1334_23,
g_atype1334_24,
g_atype1334_25,
g_atype1334_26,
g_atype1334_27,
g_atype1334_28,
g_atype1334_29,
g_atype1334_30,
g_atype1334_31,
g_atype1334_32,
g_atype1334_33,
g_atype1334_34,
g_atype1334_35,
g_atype1334_36,
g_atype1334_37,
g_atype1334_38,
g_atype1334_39,
g_atype1334_40,
g_atype1334_41,
g_atype1334_42,
g_atype1334_43,
g_atype1334_44,
g_atype1334_45,
g_atype1334_46,
g_atype1334_47,
g_atype1334_48,
g_atype1334_49,
g_atype1334_50,
g_atype1334_51,
};

static const long offsets1334 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @CHROFF(11,1),
+ @CHROFF(11,2),
+ @CHROFF(11,3),
+ @CHROFF(11,4),
+ @CHROFF(11,5),
+ @CHROFF(11,6),
+ @CHROFF(11,7),
+ @CHROFF(11,8),
+ @CHROFF(11,9),
+ @CHROFF(11,10),
+ @CHROFF(11,11),
+ @CHROFF(11,12),
+ @CHROFF(11,13),
+ @CHROFF(11,14),
+ @CHROFF(11,15),
+ @LNGOFF(11,16,0,0),
+ @LNGOFF(11,16,0,1),
+ @LNGOFF(11,16,0,2),
+ @LNGOFF(11,16,0,3),
+ @LNGOFF(11,16,0,4),
+ @LNGOFF(11,16,0,5),
+ @LNGOFF(11,16,0,6),
+ @LNGOFF(11,16,0,7),
+ @LNGOFF(11,16,0,8),
+ @LNGOFF(11,16,0,9),
+ @LNGOFF(11,16,0,10),
+ @LNGOFF(11,16,0,11),
+ @LNGOFF(11,16,0,12),
+ @LNGOFF(11,16,0,13),
+ @LNGOFF(11,16,0,14),
+ @LNGOFF(11,16,0,15),
+ @LNGOFF(11,16,0,16),
+ @LNGOFF(11,16,0,17),
+ @LNGOFF(11,16,0,18),
+ @LNGOFF(11,16,0,19),
+ @LNGOFF(11,16,0,20),
+ @LNGOFF(11,16,0,21),
+ @LNGOFF(11,16,0,22),
+ @LNGOFF(11,16,0,23),
+ @LNGOFF(11,16,0,24),
};

extern const char *names1335[];
static const uint32 types1335 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1335 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1335_0 [] = {0xFF01,1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1335_1 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1335_2 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1335_3 [] = {0xFF01,1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1335_4 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1335_5 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1335_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1335_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1335_8 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1335 [] = {
g_atype1335_0,
g_atype1335_1,
g_atype1335_2,
g_atype1335_3,
g_atype1335_4,
g_atype1335_5,
g_atype1335_6,
g_atype1335_7,
g_atype1335_8,
};

static const long offsets1335 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
};

extern const char *names1336[];
static const uint32 types1336 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1336 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1336_0 [] = {0xFF01,1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1336_1 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1336_2 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1336_3 [] = {0xFF01,1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1336_4 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1336_5 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1336_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1336_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1336_8 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1336 [] = {
g_atype1336_0,
g_atype1336_1,
g_atype1336_2,
g_atype1336_3,
g_atype1336_4,
g_atype1336_5,
g_atype1336_6,
g_atype1336_7,
g_atype1336_8,
};

static const long offsets1336 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
};

extern const char *names1337[];
static const uint32 types1337 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1337 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1337_0 [] = {0xFF01,1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1337_1 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1337_2 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1337_3 [] = {0xFF01,1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1337_4 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1337_5 [] = {1081,0xFFFF};
static const EIF_TYPE_INDEX g_atype1337_6 [] = {0xFF01,1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1337_7 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1337_8 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1337_9 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1337_10 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1337 [] = {
g_atype1337_0,
g_atype1337_1,
g_atype1337_2,
g_atype1337_3,
g_atype1337_4,
g_atype1337_5,
g_atype1337_6,
g_atype1337_7,
g_atype1337_8,
g_atype1337_9,
g_atype1337_10,
};

static const long offsets1337 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
};

extern const char *names1338[];
static const uint32 types1338 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1338 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1338_0 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1338_1 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1338 [] = {
g_atype1338_0,
g_atype1338_1,
};

static const long offsets1338 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names1339[];
static const uint32 types1339 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1339 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1339_0 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1339_1 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1339 [] = {
g_atype1339_0,
g_atype1339_1,
};

static const long offsets1339 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names1340[];
static const uint32 types1340 [] =
{
SK_INT32,
};

static const uint16 attr_flags1340 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1340_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1340 [] = {
g_atype1340_0,
};

static const long offsets1340 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1341[];
static const uint32 types1341 [] =
{
SK_INT32,
};

static const uint16 attr_flags1341 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1341_0 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1341 [] = {
g_atype1341_0,
};

static const long offsets1341 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1342[];
static const uint32 types1342 [] =
{
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1342 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1342_0 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1342_1 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1342_2 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1342 [] = {
g_atype1342_0,
g_atype1342_1,
g_atype1342_2,
};

static const long offsets1342 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @R64OFF(0,0,0,2,0,0,0,0),
};

extern const char *names1343[];
static const uint32 types1343 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags1343 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1343_0 [] = {1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_1 [] = {1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_2 [] = {0xFF01,852,0xFF01,1093,1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_3 [] = {878,0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_4 [] = {878,0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_7 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_8 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_9 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_10 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_11 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_12 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_13 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_14 [] = {1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_15 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1343 [] = {
g_atype1343_0,
g_atype1343_1,
g_atype1343_2,
g_atype1343_3,
g_atype1343_4,
g_atype1343_5,
g_atype1343_6,
g_atype1343_7,
g_atype1343_8,
g_atype1343_9,
g_atype1343_10,
g_atype1343_11,
g_atype1343_12,
g_atype1343_13,
g_atype1343_14,
g_atype1343_15,
};

static const long offsets1343 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
+ @LNGOFF(5,1,0,3),
+ @LNGOFF(5,1,0,4),
+ @LNGOFF(5,1,0,5),
+ @LNGOFF(5,1,0,6),
+ @LNGOFF(5,1,0,7),
+ @R64OFF(5,1,0,8,0,0,0,0),
+ @R64OFF(5,1,0,8,0,0,0,1),
};

extern const char *names1344[];
static const uint32 types1344 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1344 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1344_0 [] = {0xFF01,1338,0xFFFF};
static const EIF_TYPE_INDEX g_atype1344_1 [] = {0xFF01,1340,0xFFFF};
static const EIF_TYPE_INDEX g_atype1344_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1344_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1344_4 [] = {1243,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1344 [] = {
g_atype1344_0,
g_atype1344_1,
g_atype1344_2,
g_atype1344_3,
g_atype1344_4,
};

static const long offsets1344 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names1346[];
static const uint32 types1346 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1346 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1346_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1346_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1346_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1346 [] = {
g_atype1346_0,
g_atype1346_1,
g_atype1346_2,
};

static const long offsets1346 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
};

extern const char *names1347[];
static const uint32 types1347 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1347 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1347_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1347_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1347_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1347 [] = {
g_atype1347_0,
g_atype1347_1,
g_atype1347_2,
};

static const long offsets1347 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
};

extern const char *names1348[];
static const uint32 types1348 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1348 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1348_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1348_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1348_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1348 [] = {
g_atype1348_0,
g_atype1348_1,
g_atype1348_2,
};

static const long offsets1348 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
};

extern const char *names1350[];
static const uint32 types1350 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1350 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1350_0 [] = {0xFF01,878,1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_1 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_2 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_3 [] = {1082,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_5 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1350 [] = {
g_atype1350_0,
g_atype1350_1,
g_atype1350_2,
g_atype1350_3,
g_atype1350_4,
g_atype1350_5,
};

static const long offsets1350 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
};

extern const char *names1351[];
static const uint32 types1351 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1351 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1351_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1351_7 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1351 [] = {
g_atype1351_0,
g_atype1351_1,
g_atype1351_2,
g_atype1351_3,
g_atype1351_4,
g_atype1351_5,
g_atype1351_6,
g_atype1351_7,
};

static const long offsets1351 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

extern const char *names1352[];
static const uint32 types1352 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1352 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1352_0 [] = {0xFF01,1144,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_2 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_3 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_4 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_5 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_6 [] = {1219,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_7 [] = {1219,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1352 [] = {
g_atype1352_0,
g_atype1352_1,
g_atype1352_2,
g_atype1352_3,
g_atype1352_4,
g_atype1352_5,
g_atype1352_6,
g_atype1352_7,
};

static const long offsets1352 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

const struct cnode egc_fsystem_init[] = {
{
	(long) 0,
	(long) 0,
	"ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF8_READER_WRITER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IRON_PACKAGE_INFO_FILE_PARSER",
	names10,
	types10,
	attr_flags10,
	gtypes10,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets10,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_VISITOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"I18N_FILE_SCOPE_INFORMATION",
	names12,
	types12,
	attr_flags12,
	gtypes12,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets12,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_REPOSITORY_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_PACKAGE_FILE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"IRON_PACKAGE_INSTALLATION_INFO",
	names15,
	types15,
	attr_flags15,
	gtypes15,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets15,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_PLURAL_TOOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_STRING_VARIABLE_EXPANSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_STRING_VARIABLE_EXPANSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PUNYCODE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_CLIENT_DB",
	names21,
	types21,
	attr_flags21,
	gtypes21,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets21,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_URI_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INI_SCANNER_STATE_POOL",
	names23,
	types23,
	attr_flags23,
	gtypes23,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets23,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_API_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_IRON_INSTALLATION_API_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_STRING_FORMATTER",
	names26,
	types26,
	attr_flags26,
	gtypes26,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets26,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_DATE_FORMATTER",
	names27,
	types27,
	attr_flags27,
	gtypes27,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets27,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_CURRENCY_FORMATTER",
	names28,
	types28,
	attr_flags28,
	gtypes28,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets28,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARGUMENT_GROUP",
	names29,
	types29,
	attr_flags29,
	gtypes29,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets29,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENT_EXTERNALS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DESCRIPTOR_CACHE",
	names31,
	types31,
	attr_flags31,
	gtypes31,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets31,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COMPILER_PROFILE",
	names32,
	types32,
	attr_flags32,
	gtypes32,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets32,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_LOCATION_MAPPER_ACTION",
	names34,
	types34,
	attr_flags34,
	gtypes34,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets34,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_URL_BUILDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_LOCALE",
	names36,
	types36,
	attr_flags36,
	gtypes36,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets36,
	NULL
},
{
	(long) 1,
	(long) 0,
	"VERSIONABLE",
	names37,
	types37,
	attr_flags37,
	gtypes37,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets37,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PCRE_CHARACTER_SET",
	names38,
	types38,
	attr_flags38,
	gtypes38,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets38,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CASE_MAPPING",
	names39,
	types39,
	attr_flags39,
	gtypes39,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets39,
	NULL
},
{
	(long) 6,
	(long) 6,
	"PCRE_BYTE_CODE",
	names40,
	types40,
	attr_flags40,
	gtypes40,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets40,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ERROR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ESCAPE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ARGUMENT_OPTION",
	names43,
	types43,
	attr_flags43,
	gtypes43,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets43,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INI_PARSER_TOKEN_LINE_TYPE",
	names44,
	types44,
	attr_flags44,
	gtypes44,
	(uint16) 0x0100,
	(void (*)()) 0,
	offsets44,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INI_PARSER_TOKEN_LINE_TYPE",
	names45,
	types45,
	attr_flags45,
	gtypes45,
	(uint16) 0x0300,
	(void (*)()) 0,
	offsets45,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INI_TEXT_SPAN",
	names46,
	types46,
	attr_flags46,
	gtypes46,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets46,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INI_SCANNER_SYMBOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INI_SCANNER_TOKEN_TYPE",
	names48,
	types48,
	attr_flags48,
	gtypes48,
	(uint16) 0x0100,
	(void (*)()) 0,
	offsets48,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INI_SCANNER_TOKEN_TYPE",
	names49,
	types49,
	attr_flags49,
	gtypes49,
	(uint16) 0x0300,
	(void (*)()) 0,
	offsets49,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FILE_UTILITIES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FILE_UTILITIES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PRODUCT_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_LOCATION_MAPPER",
	names53,
	types53,
	attr_flags53,
	gtypes53,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets53,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XML_NAMESPACE_RESOLVER_CONTEXT",
	names54,
	types54,
	attr_flags54,
	gtypes54,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets54,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_ERROR_OBSERVER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_ERROR_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"C_DATE",
	names57,
	types57,
	attr_flags57,
	gtypes57,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets57,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ASCII",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BYTE_CODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BYTE_CODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CHARACTER_PROPERTY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ENCODING",
	names63,
	types63,
	attr_flags63,
	gtypes63,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets63,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_PAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"INI_PARSER",
	names65,
	types65,
	attr_flags65,
	gtypes65,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets65,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UUID_GENERATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_ROOT",
	names67,
	types67,
	attr_flags67,
	gtypes67,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets67,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ASSERTIONS",
	names68,
	types68,
	attr_flags68,
	gtypes68,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets68,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_LOAD_CONTEXT",
	names69,
	types69,
	attr_flags69,
	gtypes69,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets69,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_CONDITION_CUSTOM_ATTRIBUTES",
	names70,
	types70,
	attr_flags70,
	gtypes70,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets70,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RT_DBG_EXECUTION_PARAMETERS",
	names72,
	types72,
	attr_flags72,
	gtypes72,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets72,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_RUNTIME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STD_FILES",
	names86,
	types86,
	attr_flags86,
	gtypes86,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets86,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENV_INTERP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INI_DOCUMENT_READER",
	names90,
	types90,
	attr_flags90,
	gtypes90,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets90,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IMPORTED_UTF8_READER_WRITER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_I18N_FORMATTING_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_TOKENS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"JSON_READER",
	names103,
	types103,
	attr_flags103,
	gtypes103,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets103,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DIRECTORY_VISITOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DIRECTORY_ITERATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IRON_FS_PACKAGE_INFO_DIRECTORY_ITERATOR",
	names106,
	types106,
	attr_flags106,
	gtypes106,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets106,
	NULL
},
{
	(long) 3,
	(long) 3,
	"IRON_ECF_SCANNER",
	names107,
	types107,
	attr_flags107,
	gtypes107,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets107,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STREAMS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_FILE_HANDLER",
	names109,
	types109,
	attr_flags109,
	gtypes109,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets109,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_MO_HANDLER",
	names110,
	types110,
	attr_flags110,
	gtypes110,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets110,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names112,
	types112,
	attr_flags112,
	gtypes112,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets112,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names113,
	types113,
	attr_flags113,
	gtypes113,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets113,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names114,
	types114,
	attr_flags114,
	gtypes114,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets114,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names115,
	types115,
	attr_flags115,
	gtypes115,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets115,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"MESSAGE_DIGEST",
	names119,
	types119,
	attr_flags119,
	gtypes119,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets119,
	NULL
},
{
	(long) 14,
	(long) 14,
	"SHA1",
	names120,
	types120,
	attr_flags120,
	gtypes120,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets120,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_CHARACTERS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_LANGUAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_TOOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"URI_PERCENT_ENCODER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_LOCALE_CONV",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_UNIX_C_FUNCTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_POSIX_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_CODE_PAGE_INFO",
	names133,
	types133,
	attr_flags133,
	gtypes133,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets133,
	NULL
},
{
	(long) 13,
	(long) 13,
	"I18N_DATE_TIME_INFO",
	names134,
	types134,
	attr_flags134,
	gtypes134,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets134,
	NULL
},
{
	(long) 7,
	(long) 7,
	"I18N_NUMERIC_INFO",
	names135,
	types135,
	attr_flags135,
	gtypes135,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets135,
	NULL
},
{
	(long) 16,
	(long) 16,
	"I18N_CURRENCY_INFO",
	names136,
	types136,
	attr_flags136,
	gtypes136,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets136,
	NULL
},
{
	(long) 40,
	(long) 40,
	"I18N_LOCALE_INFO",
	names137,
	types137,
	attr_flags137,
	gtypes137,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets137,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DEBUGGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_VALUE_FORMATTER",
	names139,
	types139,
	attr_flags139,
	gtypes139,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets139,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_CURRENCY_VALUE_FORMATTER",
	names140,
	types140,
	attr_flags140,
	gtypes140,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets140,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_I18N_URI_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_HOST_LOCALE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_DATASOURCE_MANAGER",
	names143,
	types143,
	attr_flags143,
	gtypes143,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets143,
	NULL
},
{
	(long) 7,
	(long) 7,
	"I18N_FILE_MANAGER",
	names144,
	types144,
	attr_flags144,
	gtypes144,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets144,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BOM_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"MATCHER",
	names146,
	types146,
	attr_flags146,
	gtypes146,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets146,
	NULL
},
{
	(long) 7,
	(long) 7,
	"KMP_MATCHER",
	names147,
	types147,
	attr_flags147,
	gtypes147,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets147,
	NULL
},
{
	(long) 13,
	(long) 13,
	"KMP_WILD",
	names148,
	types148,
	attr_flags148,
	gtypes148,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets148,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_TRAVERSABLE",
	names149,
	types149,
	attr_flags149,
	gtypes149,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets149,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE",
	names150,
	types150,
	attr_flags150,
	gtypes150,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets150,
	NULL
},
{
	(long) 0,
	(long) 0,
	"GROUP_ELEMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INI_SECTION_CONTAINER_NODE",
	names153,
	types153,
	attr_flags153,
	gtypes153,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets153,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_VALUE",
	names154,
	types154,
	attr_flags154,
	gtypes154,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets154,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_LOCATION_MAPPING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_LOCATION_IRON_MAPPING",
	names156,
	types156,
	attr_flags156,
	gtypes156,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets156,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_EXPANDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_CLASSNAME_FINDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OBJECT_GRAPH_MARKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MATH_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DOUBLE_MATH",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_CHARACTER_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPTION_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ARGUMENT_BASE_PARSER",
	names164,
	types164,
	attr_flags164,
	gtypes164,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets164,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ARGUMENT_OPTION_PARSER",
	names165,
	types165,
	attr_flags165,
	gtypes165,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets165,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ARGUMENT_PARSER",
	names166,
	types166,
	attr_flags166,
	gtypes166,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets166,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BASE_REDIRECTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PROCESS_REDIRECTION_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INI_NODE_VISITOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_DOCUMENT_BUILDER_NODE_VISITOR",
	names171,
	types171,
	attr_flags171,
	gtypes171,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets171,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INI_NODE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INI_DEFAULT_NODE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_COMPILER_PROFILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_XMLNS_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_MARKUP_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFACTORING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"PATTERN_MATCHER",
	names180,
	types180,
	attr_flags180,
	gtypes180,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets180,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PROCESS_TIMER",
	names181,
	types181,
	attr_flags181,
	gtypes181,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets181,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BASE_PROCESS_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PROCESS_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SORTER",
	names184,
	types184,
	attr_flags184,
	gtypes184,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets184,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUICK_SORTER",
	names185,
	types185,
	attr_flags185,
	gtypes185,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets185,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_PARSER_CONTROLLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEP_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names190,
	types190,
	attr_flags190,
	gtypes190,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets190,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names191,
	types191,
	attr_flags191,
	gtypes191,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets191,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names192,
	types192,
	attr_flags192,
	gtypes192,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets192,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names193,
	types193,
	attr_flags193,
	gtypes193,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets193,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names194,
	types194,
	attr_flags194,
	gtypes194,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets194,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names195,
	types195,
	attr_flags195,
	gtypes195,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets195,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names196,
	types196,
	attr_flags196,
	gtypes196,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets196,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EIFFEL_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM_ENTRY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IRON_EXPORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IRON_REPOSITORY_CONFIGURATION_FILE",
	names205,
	types205,
	attr_flags205,
	gtypes205,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets205,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_TO_IRON_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IRON_PACKAGE_FILE",
	names207,
	types207,
	attr_flags207,
	gtypes207,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets207,
	NULL
},
{
	(long) 7,
	(long) 7,
	"IRON_PACKAGE_INFO_FILE",
	names208,
	types208,
	attr_flags208,
	gtypes208,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets208,
	NULL
},
{
	(long) 6,
	(long) 6,
	"IRON_PACKAGE_INI_FILE",
	names209,
	types209,
	attr_flags209,
	gtypes209,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets209,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_DICTIONARY_ID_BUILDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_I18N_PLURAL_TOOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"I18N_FILE",
	names212,
	types212,
	attr_flags212,
	gtypes212,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets212,
	NULL
},
{
	(long) 15,
	(long) 15,
	"I18N_MO_FILE",
	names213,
	types213,
	attr_flags213,
	gtypes213,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets213,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_DICTIONARY",
	names214,
	types214,
	attr_flags214,
	gtypes214,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets214,
	NULL
},
{
	(long) 5,
	(long) 5,
	"I18N_BINARY_SEARCH_ARRAY_DICTIONARY",
	names215,
	types215,
	attr_flags215,
	gtypes215,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets215,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_DUMMY_DICTIONARY",
	names216,
	types216,
	attr_flags216,
	gtypes216,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets216,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UNIX_SIGNALS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PROCESS_UNIX_OS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UNIX_PIPE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SUBSET_STRATEGY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SUBSET_STRATEGY_HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SUBSET_STRATEGY_GENERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_VALIDITY_CHECKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME_VALUE",
	names227,
	types227,
	attr_flags227,
	gtypes227,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets227,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DATE_TIME_VALUE",
	names230,
	types230,
	attr_flags230,
	gtypes230,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets230,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"THREAD_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"THREAD_CONTROL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"THREAD",
	names234,
	types234,
	attr_flags234,
	gtypes234,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets234,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PROCESS_IO_LISTENER_THREAD",
	names235,
	types235,
	attr_flags235,
	gtypes235,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets235,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENCODING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_IMP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INI_SHARED_SCANNER_STATE_POOL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_PROPERTY_CONTAINER_NODE",
	names239,
	types239,
	attr_flags239,
	gtypes239,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets239,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INI_DOCUMENT_NODE",
	names240,
	types240,
	attr_flags240,
	gtypes240,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets240,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYNTAX_STRINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CLASS_TYPE_NAME_SYNTAX_CHECKER",
	names242,
	types242,
	attr_flags242,
	gtypes242,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets242,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EIFFEL_SYNTAX_CHECKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARGUMENT_VALUE_VALIDATOR",
	names244,
	types244,
	attr_flags244,
	gtypes244,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets244,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARGUMENT_DEFAULT_VALIDATOR",
	names245,
	types245,
	attr_flags245,
	gtypes245,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets245,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARGUMENT_DIRECTORY_VALIDATOR",
	names246,
	types246,
	attr_flags246,
	gtypes246,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets246,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_LOAD_PARSE_CALLBACKS_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_FILE_DATE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STRING_EQUALITY_TESTER",
	names252,
	types252,
	attr_flags252,
	gtypes252,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets252,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_GENERAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_SEARCHER",
	names257,
	types257,
	attr_flags257,
	gtypes257,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets257,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_8_SEARCHER",
	names258,
	types258,
	attr_flags258,
	gtypes258,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets258,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_32_SEARCHER",
	names259,
	types259,
	attr_flags259,
	gtypes259,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets259,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENT_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENT_TERMINAL_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ENVIRONMENT_ARGUMENTS_SOURCE",
	names262,
	types262,
	attr_flags262,
	gtypes262,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets262,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_PROPERTY_CONTAINER",
	names263,
	types263,
	attr_flags263,
	gtypes263,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets263,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INI_DOCUMENT",
	names264,
	types264,
	attr_flags264,
	gtypes264,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets264,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_TARGET_REFERENCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_LOCAL_TARGET_REFERENCE",
	names266,
	types266,
	attr_flags266,
	gtypes266,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets266,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_REMOTE_TARGET_REFERENCE",
	names267,
	types267,
	attr_flags267,
	gtypes267,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets267,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC_INFORMATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INTEGER_OVERFLOW_CHECKER",
	names269,
	types269,
	attr_flags269,
	gtypes269,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets269,
	NULL
},
{
	(long) 7,
	(long) 7,
	"STRING_TO_NUMERIC_CONVERTOR",
	names270,
	types270,
	attr_flags270,
	gtypes270,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets270,
	NULL
},
{
	(long) 11,
	(long) 11,
	"HEXADECIMAL_STRING_TO_INTEGER_CONVERTER",
	names271,
	types271,
	attr_flags271,
	gtypes271,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets271,
	NULL
},
{
	(long) 15,
	(long) 15,
	"STRING_TO_REAL_CONVERTOR",
	names272,
	types272,
	attr_flags272,
	gtypes272,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets272,
	NULL
},
{
	(long) 10,
	(long) 10,
	"STRING_TO_INTEGER_CONVERTOR",
	names273,
	types273,
	attr_flags273,
	gtypes273,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets273,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INI_SYNTAX_ERROR",
	names274,
	types274,
	attr_flags274,
	gtypes274,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets274,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INI_UNEXPECTED_SYNTAX_ERROR",
	names275,
	types275,
	attr_flags275,
	gtypes275,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets275,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INI_EXPECTED_SYNTAX_ERROR",
	names276,
	types276,
	attr_flags276,
	gtypes276,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets276,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_CONF_SETTING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REVERSE_PART_COMPARATOR",
	names279,
	types279,
	attr_flags279,
	gtypes279,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets279,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STRING_COMPARATOR",
	names281,
	types281,
	attr_flags281,
	gtypes281,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets281,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPERATING_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IL_ENVIRONMENT",
	names286,
	types286,
	attr_flags286,
	gtypes286,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets286,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_BUFFER",
	names287,
	types287,
	attr_flags287,
	gtypes287,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets287,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UTF8_BUFFER",
	names288,
	types288,
	attr_flags288,
	gtypes288,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets288,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UNICODE_BUFFER",
	names289,
	types289,
	attr_flags289,
	gtypes289,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets289,
	NULL
},
{
	(long) 12,
	(long) 12,
	"YY_FILE_BUFFER",
	names290,
	types290,
	attr_flags290,
	gtypes290,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets290,
	NULL
},
{
	(long) 15,
	(long) 15,
	"YY_UNICODE_FILE_BUFFER",
	names291,
	types291,
	attr_flags291,
	gtypes291,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets291,
	NULL
},
{
	(long) 14,
	(long) 14,
	"YY_UTF8_FILE_BUFFER",
	names292,
	types292,
	attr_flags292,
	gtypes292,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets292,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MEM_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"MEMORY_STRUCTURE",
	names296,
	types296,
	attr_flags296,
	gtypes296,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets296,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INI_NODE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"INI_SECTION_NODE",
	names298,
	types298,
	attr_flags298,
	gtypes298,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets298,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INI_PROPERTY_NODE",
	names299,
	types299,
	attr_flags299,
	gtypes299,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets299,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_ATOMIC_NODE",
	names300,
	types300,
	attr_flags300,
	gtypes300,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets300,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_SYMBOL_NODE",
	names301,
	types301,
	attr_flags301,
	gtypes301,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets301,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_VALUE_NODE",
	names302,
	types302,
	attr_flags302,
	gtypes302,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets302,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_ID_NODE",
	names303,
	types303,
	attr_flags303,
	gtypes303,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets303,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_LITERAL_NODE",
	names304,
	types304,
	attr_flags304,
	gtypes304,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets304,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XML_CALLBACKS",
	names305,
	types305,
	attr_flags305,
	gtypes305,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets305,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XML_CALLBACKS_NULL",
	names306,
	types306,
	attr_flags306,
	gtypes306,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets306,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_CALLBACKS_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XML_FORWARD_CALLBACKS",
	names309,
	types309,
	attr_flags309,
	gtypes309,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets309,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 10,
	(long) 10,
	"XML_STANDARD_PARSER",
	names311,
	types311,
	attr_flags311,
	gtypes311,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets311,
	NULL
},
{
	(long) 15,
	(long) 15,
	"XML_STOPPABLE_PARSER",
	names312,
	types312,
	attr_flags312,
	gtypes312,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets312,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XML_CALLBACKS_FILTER",
	names313,
	types313,
	attr_flags313,
	gtypes313,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets313,
	NULL
},
{
	(long) 9,
	(long) 9,
	"XML_NAMESPACE_RESOLVER",
	names314,
	types314,
	attr_flags314,
	gtypes314,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets314,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XML_END_TAG_CHECKER",
	names315,
	types315,
	attr_flags315,
	gtypes315,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets315,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"XML_STRING_32_INPUT_STREAM",
	names317,
	types317,
	attr_flags317,
	gtypes317,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets317,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XML_CHARACTER_8_INPUT_STREAM_FILTER",
	names318,
	types318,
	attr_flags318,
	gtypes318,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets318,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XML_CHARACTER_8_INPUT_STREAM_UTF8_FILTER",
	names319,
	types319,
	attr_flags319,
	gtypes319,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets319,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XML_CHARACTER_8_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HASH_TABLE_CURSOR",
	names322,
	types322,
	attr_flags322,
	gtypes322,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets322,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names323,
	types323,
	attr_flags323,
	gtypes323,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets323,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names324,
	types324,
	attr_flags324,
	gtypes324,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets324,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ARRAYED_LIST_CURSOR",
	names325,
	types325,
	attr_flags325,
	gtypes325,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets325,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_NOTABLE",
	names327,
	types327,
	attr_flags327,
	gtypes327,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets327,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION",
	names330,
	types330,
	attr_flags330,
	gtypes330,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets330,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MACHINE_EXCEPTION",
	names331,
	types331,
	attr_flags331,
	gtypes331,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets331,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HARDWARE_EXCEPTION",
	names332,
	types332,
	attr_flags332,
	gtypes332,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets332,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FLOATING_POINT_FAILURE",
	names333,
	types333,
	attr_flags333,
	gtypes333,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets333,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OPERATING_SYSTEM_EXCEPTION",
	names334,
	types334,
	attr_flags334,
	gtypes334,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets334,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_SIGNAL_FAILURE",
	names335,
	types335,
	attr_flags335,
	gtypes335,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets335,
	NULL
},
{
	(long) 10,
	(long) 10,
	"COM_FAILURE",
	names336,
	types336,
	attr_flags336,
	gtypes336,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets336,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_FAILURE",
	names337,
	types337,
	attr_flags337,
	gtypes337,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets337,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DEVELOPER_EXCEPTION",
	names338,
	types338,
	attr_flags338,
	gtypes338,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets338,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONVERSION_FAILURE",
	names339,
	types339,
	attr_flags339,
	gtypes339,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets339,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_EXCEPTION",
	names340,
	types340,
	attr_flags340,
	gtypes340,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets340,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OBSOLETE_EXCEPTION",
	names341,
	types341,
	attr_flags341,
	gtypes341,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets341,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION_IN_SIGNAL_HANDLER_FAILURE",
	names342,
	types342,
	attr_flags342,
	gtypes342,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets342,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESUMPTION_FAILURE",
	names343,
	types343,
	attr_flags343,
	gtypes343,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets343,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESCUE_FAILURE",
	names344,
	types344,
	attr_flags344,
	gtypes344,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets344,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SYS_EXCEPTION",
	names345,
	types345,
	attr_flags345,
	gtypes345,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets345,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OLD_VIOLATION",
	names346,
	types346,
	attr_flags346,
	gtypes346,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets346,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EIFFEL_RUNTIME_PANIC",
	names347,
	types347,
	attr_flags347,
	gtypes347,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets347,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIF_EXCEPTION",
	names348,
	types348,
	attr_flags348,
	gtypes348,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets348,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFEL_RUNTIME_EXCEPTION",
	names349,
	types349,
	attr_flags349,
	gtypes349,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets349,
	NULL
},
{
	(long) 8,
	(long) 8,
	"NO_MORE_MEMORY",
	names350,
	types350,
	attr_flags350,
	gtypes350,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets350,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXTERNAL_FAILURE",
	names351,
	types351,
	attr_flags351,
	gtypes351,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets351,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATA_EXCEPTION",
	names352,
	types352,
	attr_flags352,
	gtypes352,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets352,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SERIALIZATION_FAILURE",
	names353,
	types353,
	attr_flags353,
	gtypes353,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets353,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MISMATCH_FAILURE",
	names354,
	types354,
	attr_flags354,
	gtypes354,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets354,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IO_FAILURE",
	names355,
	types355,
	attr_flags355,
	gtypes355,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets355,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LANGUAGE_EXCEPTION",
	names356,
	types356,
	attr_flags356,
	gtypes356,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets356,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BAD_INSPECT_VALUE",
	names357,
	types357,
	attr_flags357,
	gtypes357,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets357,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ROUTINE_FAILURE",
	names358,
	types358,
	attr_flags358,
	gtypes358,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets358,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_TARGET",
	names359,
	types359,
	attr_flags359,
	gtypes359,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets359,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_ASSIGNED_TO_EXPANDED",
	names360,
	types360,
	attr_flags360,
	gtypes360,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets360,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION",
	names361,
	types361,
	attr_flags361,
	gtypes361,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets361,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ADDRESS_APPLIED_TO_MELTED_FEATURE",
	names362,
	types362,
	attr_flags362,
	gtypes362,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets362,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CREATE_ON_DEFERRED",
	names363,
	types363,
	attr_flags363,
	gtypes363,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets363,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ASSERTION_VIOLATION",
	names364,
	types364,
	attr_flags364,
	gtypes364,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets364,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LOOP_INVARIANT_VIOLATION",
	names365,
	types365,
	attr_flags365,
	gtypes365,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets365,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VARIANT_VIOLATION",
	names366,
	types366,
	attr_flags366,
	gtypes366,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets366,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CHECK_VIOLATION",
	names367,
	types367,
	attr_flags367,
	gtypes367,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets367,
	NULL
},
{
	(long) 8,
	(long) 8,
	"INVARIANT_VIOLATION",
	names368,
	types368,
	attr_flags368,
	gtypes368,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets368,
	NULL
},
{
	(long) 7,
	(long) 7,
	"POSTCONDITION_VIOLATION",
	names369,
	types369,
	attr_flags369,
	gtypes369,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets369,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PRECONDITION_VIOLATION",
	names370,
	types370,
	attr_flags370,
	gtypes370,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets370,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_ELEMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_USERSTRING_ELEMENT",
	names372,
	types372,
	attr_flags372,
	gtypes372,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets372,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_DATE_ELEMENT",
	names373,
	types373,
	attr_flags373,
	gtypes373,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets373,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_TIME_ELEMENT",
	names374,
	types374,
	attr_flags374,
	gtypes374,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets374,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_FORMAT_STRING",
	names375,
	types375,
	attr_flags375,
	gtypes375,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets375,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_INTERFACE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_VISITABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INTERVAL",
	names380,
	types380,
	attr_flags380,
	gtypes380,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets380,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DURATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"TIME_DURATION",
	names382,
	types382,
	attr_flags382,
	gtypes382,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets382,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DATE_TIME_DURATION",
	names383,
	types383,
	attr_flags383,
	gtypes383,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets383,
	NULL
},
{
	(long) 4,
	(long) 4,
	"DATE_DURATION",
	names384,
	types384,
	attr_flags384,
	gtypes384,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets384,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_DICTIONARY_ENTRY",
	names386,
	types386,
	attr_flags386,
	gtypes386,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets386,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSOLUTE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REFLECTED_OBJECT",
	names391,
	types391,
	attr_flags391,
	gtypes391,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets391,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REFLECTED_COPY_SEMANTICS_OBJECT",
	names395,
	types395,
	attr_flags395,
	gtypes395,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets395,
	NULL
},
{
	(long) 3,
	(long) 3,
	"REFLECTED_REFERENCE_OBJECT",
	names396,
	types396,
	attr_flags396,
	gtypes396,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets396,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_FILE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_PARSE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_NAMESPACE_TESTER",
	names399,
	types399,
	attr_flags399,
	gtypes399,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets399,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_LOAD_CALLBACKS",
	names400,
	types400,
	attr_flags400,
	gtypes400,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets400,
	NULL
},
{
	(long) 12,
	(long) 12,
	"CONF_LOAD_UUID_CALLBACKS",
	names401,
	types401,
	attr_flags401,
	gtypes401,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets401,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_VALIDITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"CONF_STATE",
	names403,
	types403,
	attr_flags403,
	gtypes403,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets403,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_TARGET_SETTINGS",
	names404,
	types404,
	attr_flags404,
	gtypes404,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets404,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_CONDITIONED",
	names405,
	types405,
	attr_flags405,
	gtypes405,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets405,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_FILE_RULE",
	names406,
	types406,
	attr_flags406,
	gtypes406,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets406,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ACTION",
	names407,
	types407,
	attr_flags407,
	gtypes407,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets407,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL",
	names408,
	types408,
	attr_flags408,
	gtypes408,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets408,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_CFLAG",
	names409,
	types409,
	attr_flags409,
	gtypes409,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets409,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_RESOURCE",
	names410,
	types410,
	attr_flags410,
	gtypes410,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets410,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_INCLUDE",
	names411,
	types411,
	attr_flags411,
	gtypes411,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets411,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_LIBRARY",
	names412,
	types412,
	attr_flags412,
	gtypes412,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets412,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_LINKER_FLAG",
	names413,
	types413,
	attr_flags413,
	gtypes413,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets413,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_MAKE",
	names414,
	types414,
	attr_flags414,
	gtypes414,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets414,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_EXTERNAL_OBJECT",
	names415,
	types415,
	attr_flags415,
	gtypes415,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets415,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names416,
	types416,
	attr_flags416,
	gtypes416,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets416,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names417,
	types417,
	attr_flags417,
	gtypes417,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets417,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names418,
	types418,
	attr_flags418,
	gtypes418,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets418,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names419,
	types419,
	attr_flags419,
	gtypes419,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets419,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names420,
	types420,
	attr_flags420,
	gtypes420,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets420,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names421,
	types421,
	attr_flags421,
	gtypes421,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets421,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names422,
	types422,
	attr_flags422,
	gtypes422,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets422,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names423,
	types423,
	attr_flags423,
	gtypes423,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets423,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names424,
	types424,
	attr_flags424,
	gtypes424,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets424,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names425,
	types425,
	attr_flags425,
	gtypes425,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets425,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names426,
	types426,
	attr_flags426,
	gtypes426,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets426,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names427,
	types427,
	attr_flags427,
	gtypes427,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets427,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EIFFEL_LAYOUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_DIRECTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"NATIVE_STRING",
	names432,
	types432,
	attr_flags432,
	gtypes432,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets432,
	NULL
},
{
	(long) 5,
	(long) 5,
	"FILE_INFO",
	names433,
	types433,
	attr_flags433,
	gtypes433,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets433,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UNIX_FILE_INFO",
	names434,
	types434,
	attr_flags434,
	gtypes434,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets434,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXECUTION_ENVIRONMENT",
	names435,
	types435,
	attr_flags435,
	gtypes435,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets435,
	NULL
},
{
	(long) 8,
	(long) 8,
	"PROCESS_OUTPUT_LISTENER_THREAD",
	names436,
	types436,
	attr_flags436,
	gtypes436,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets436,
	NULL
},
{
	(long) 8,
	(long) 8,
	"PROCESS_INPUT_LISTENER_THREAD",
	names437,
	types437,
	attr_flags437,
	gtypes437,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets437,
	NULL
},
{
	(long) 8,
	(long) 8,
	"PROCESS_ERROR_LISTENER_THREAD",
	names438,
	types438,
	attr_flags438,
	gtypes438,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets438,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ENVIRONMENT_ACCESS",
	names439,
	types439,
	attr_flags439,
	gtypes439,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets439,
	NULL
},
{
	(long) 9,
	(long) 9,
	"PROCESS_THREAD_TIMER",
	names440,
	types440,
	attr_flags440,
	gtypes440,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets440,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PROCESS_INFO",
	names441,
	types441,
	attr_flags441,
	gtypes441,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets441,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PROCESS_INFO_IMP",
	names442,
	types442,
	attr_flags442,
	gtypes442,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets442,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DISPOSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"MUTEX",
	names444,
	types444,
	attr_flags444,
	gtypes444,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets444,
	NULL
},
{
	(long) 4,
	(long) 2,
	"MANAGED_POINTER",
	names445,
	types445,
	attr_flags445,
	gtypes445,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets445,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PROCESS_UNIX_PIPE",
	names446,
	types446,
	attr_flags446,
	gtypes446,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets446,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MEMORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4400,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 29,
	(long) 29,
	"PROCESS_UNIX_PROCESS_MANAGER",
	names448,
	types448,
	attr_flags448,
	gtypes448,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets448,
	NULL
},
{
	(long) 6,
	(long) 6,
	"DIRECTORY",
	names449,
	types449,
	attr_flags449,
	gtypes449,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets449,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_EXECUTION_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IRON_LAYOUT",
	names451,
	types451,
	attr_flags451,
	gtypes451,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets451,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_ENVIRONMENT_EXPANDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IRON_API",
	names453,
	types453,
	attr_flags453,
	gtypes453,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets453,
	NULL
},
{
	(long) 6,
	(long) 6,
	"IRON_INSTALLATION_API",
	names454,
	types454,
	attr_flags454,
	gtypes454,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets454,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ENVIRONMENT_ARGUMENTS",
	names455,
	types455,
	attr_flags455,
	gtypes455,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets455,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ES_ARGUMENTS",
	names456,
	types456,
	attr_flags456,
	gtypes456,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets456,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COMPILE_ALL_ARGUMENTS",
	names457,
	types457,
	attr_flags457,
	gtypes457,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets457,
	NULL
},
{
	(long) 32,
	(long) 32,
	"BASE_PROCESS",
	names458,
	types458,
	attr_flags458,
	gtypes458,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets458,
	NULL
},
{
	(long) 34,
	(long) 34,
	"BASE_PROCESS_IMP",
	names459,
	types459,
	attr_flags459,
	gtypes459,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets459,
	NULL
},
{
	(long) 36,
	(long) 36,
	"PROCESS",
	names460,
	types460,
	attr_flags460,
	gtypes460,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets460,
	NULL
},
{
	(long) 48,
	(long) 48,
	"PROCESS_IMP",
	names461,
	types461,
	attr_flags461,
	gtypes461,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets461,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_UNICODE_CHARACTER_BUFFER",
	names463,
	types463,
	attr_flags463,
	gtypes463,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets463,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_CHARACTER_BUFFER",
	names464,
	types464,
	attr_flags464,
	gtypes464,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets464,
	NULL
},
{
	(long) 2,
	(long) 2,
	"C_STRING",
	names465,
	types465,
	attr_flags465,
	gtypes465,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets465,
	NULL
},
{
	(long) 13,
	(long) 13,
	"IO_MEDIUM",
	names466,
	types466,
	attr_flags466,
	gtypes466,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets466,
	NULL
},
{
	(long) 20,
	(long) 20,
	"UNIX_UNNAMED_PIPE",
	names467,
	types467,
	attr_flags467,
	gtypes467,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets467,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_QUEUE_ITERATION_CURSOR",
	names480,
	types480,
	attr_flags480,
	gtypes480,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets480,
	NULL
},
{
	(long) 2,
	(long) 2,
	"FILE_ITERATION_CURSOR",
	names481,
	types481,
	attr_flags481,
	gtypes481,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets481,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SEARCH_TABLE_ITERATION_CURSOR",
	names482,
	types482,
	attr_flags482,
	gtypes482,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets482,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SEARCH_TABLE_ITERATION_CURSOR",
	names483,
	types483,
	attr_flags483,
	gtypes483,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets483,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SEARCH_TABLE_ITERATION_CURSOR",
	names484,
	types484,
	attr_flags484,
	gtypes484,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets484,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MISMATCH_CORRECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE_VALUE",
	names495,
	types495,
	attr_flags495,
	gtypes495,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets495,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"STRING_ITERATION_CURSOR",
	names508,
	types508,
	attr_flags508,
	gtypes508,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets508,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS_32",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names535,
	types535,
	attr_flags535,
	gtypes535,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets535,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names536,
	types536,
	attr_flags536,
	gtypes536,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets536,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names537,
	types537,
	attr_flags537,
	gtypes537,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets537,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names538,
	types538,
	attr_flags538,
	gtypes538,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets538,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names539,
	types539,
	attr_flags539,
	gtypes539,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets539,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names540,
	types540,
	attr_flags540,
	gtypes540,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets540,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names541,
	types541,
	attr_flags541,
	gtypes541,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets541,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names542,
	types542,
	attr_flags542,
	gtypes542,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets542,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names543,
	types543,
	attr_flags543,
	gtypes543,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets543,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names544,
	types544,
	attr_flags544,
	gtypes544,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets544,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names545,
	types545,
	attr_flags545,
	gtypes545,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets545,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names546,
	types546,
	attr_flags546,
	gtypes546,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets546,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names547,
	types547,
	attr_flags547,
	gtypes547,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets547,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names548,
	types548,
	attr_flags548,
	gtypes548,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets548,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names549,
	types549,
	attr_flags549,
	gtypes549,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets549,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names550,
	types550,
	attr_flags550,
	gtypes550,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets550,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names551,
	types551,
	attr_flags551,
	gtypes551,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets551,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names552,
	types552,
	attr_flags552,
	gtypes552,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets552,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names553,
	types553,
	attr_flags553,
	gtypes553,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets553,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names554,
	types554,
	attr_flags554,
	gtypes554,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets554,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names555,
	types555,
	attr_flags555,
	gtypes555,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets555,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names556,
	types556,
	attr_flags556,
	gtypes556,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets556,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names557,
	types557,
	attr_flags557,
	gtypes557,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets557,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names558,
	types558,
	attr_flags558,
	gtypes558,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets558,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names559,
	types559,
	attr_flags559,
	gtypes559,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets559,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names560,
	types560,
	attr_flags560,
	gtypes560,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets560,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names561,
	types561,
	attr_flags561,
	gtypes561,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets561,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names562,
	types562,
	attr_flags562,
	gtypes562,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets562,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names563,
	types563,
	attr_flags563,
	gtypes563,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets563,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names564,
	types564,
	attr_flags564,
	gtypes564,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets564,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names565,
	types565,
	attr_flags565,
	gtypes565,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets565,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names566,
	types566,
	attr_flags566,
	gtypes566,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets566,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names567,
	types567,
	attr_flags567,
	gtypes567,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets567,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names568,
	types568,
	attr_flags568,
	gtypes568,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets568,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names569,
	types569,
	attr_flags569,
	gtypes569,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets569,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names570,
	types570,
	attr_flags570,
	gtypes570,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets570,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names571,
	types571,
	attr_flags571,
	gtypes571,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets571,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names572,
	types572,
	attr_flags572,
	gtypes572,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets572,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names573,
	types573,
	attr_flags573,
	gtypes573,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets573,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names574,
	types574,
	attr_flags574,
	gtypes574,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets574,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names575,
	types575,
	attr_flags575,
	gtypes575,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets575,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names576,
	types576,
	attr_flags576,
	gtypes576,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets576,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names577,
	types577,
	attr_flags577,
	gtypes577,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets577,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names578,
	types578,
	attr_flags578,
	gtypes578,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets578,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names579,
	types579,
	attr_flags579,
	gtypes579,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets579,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names580,
	types580,
	attr_flags580,
	gtypes580,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets580,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8_ITERATION_CURSOR",
	names581,
	types581,
	attr_flags581,
	gtypes581,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets581,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32_ITERATION_CURSOR",
	names582,
	types582,
	attr_flags582,
	gtypes582,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets582,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names583,
	types583,
	attr_flags583,
	gtypes583,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets583,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names584,
	types584,
	attr_flags584,
	gtypes584,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets584,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names585,
	types585,
	attr_flags585,
	gtypes585,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets585,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names586,
	types586,
	attr_flags586,
	gtypes586,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets586,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names587,
	types587,
	attr_flags587,
	gtypes587,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets587,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names588,
	types588,
	attr_flags588,
	gtypes588,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets588,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names589,
	types589,
	attr_flags589,
	gtypes589,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets589,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names590,
	types590,
	attr_flags590,
	gtypes590,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets590,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names591,
	types591,
	attr_flags591,
	gtypes591,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets591,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names592,
	types592,
	attr_flags592,
	gtypes592,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets592,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names593,
	types593,
	attr_flags593,
	gtypes593,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets593,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names594,
	types594,
	attr_flags594,
	gtypes594,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets594,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names595,
	types595,
	attr_flags595,
	gtypes595,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets595,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names596,
	types596,
	attr_flags596,
	gtypes596,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets596,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names597,
	types597,
	attr_flags597,
	gtypes597,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets597,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names598,
	types598,
	attr_flags598,
	gtypes598,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets598,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names599,
	types599,
	attr_flags599,
	gtypes599,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets599,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names600,
	types600,
	attr_flags600,
	gtypes600,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets600,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names601,
	types601,
	attr_flags601,
	gtypes601,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets601,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names602,
	types602,
	attr_flags602,
	gtypes602,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets602,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names603,
	types603,
	attr_flags603,
	gtypes603,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets603,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names604,
	types604,
	attr_flags604,
	gtypes604,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets604,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names605,
	types605,
	attr_flags605,
	gtypes605,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets605,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names606,
	types606,
	attr_flags606,
	gtypes606,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets606,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IRON_REPOSITORY",
	names607,
	types607,
	attr_flags607,
	gtypes607,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets607,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names608,
	types608,
	attr_flags608,
	gtypes608,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets608,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names609,
	types609,
	attr_flags609,
	gtypes609,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets609,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names610,
	types610,
	attr_flags610,
	gtypes610,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets610,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names611,
	types611,
	attr_flags611,
	gtypes611,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets611,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names612,
	types612,
	attr_flags612,
	gtypes612,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets612,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names613,
	types613,
	attr_flags613,
	gtypes613,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets613,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names614,
	types614,
	attr_flags614,
	gtypes614,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets614,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names615,
	types615,
	attr_flags615,
	gtypes615,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets615,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names616,
	types616,
	attr_flags616,
	gtypes616,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets616,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names617,
	types617,
	attr_flags617,
	gtypes617,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets617,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names618,
	types618,
	attr_flags618,
	gtypes618,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets618,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names619,
	types619,
	attr_flags619,
	gtypes619,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets619,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names620,
	types620,
	attr_flags620,
	gtypes620,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets620,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names621,
	types621,
	attr_flags621,
	gtypes621,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets621,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names622,
	types622,
	attr_flags622,
	gtypes622,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets622,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names623,
	types623,
	attr_flags623,
	gtypes623,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets623,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names624,
	types624,
	attr_flags624,
	gtypes624,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets624,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names625,
	types625,
	attr_flags625,
	gtypes625,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets625,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names626,
	types626,
	attr_flags626,
	gtypes626,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets626,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names627,
	types627,
	attr_flags627,
	gtypes627,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets627,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names628,
	types628,
	attr_flags628,
	gtypes628,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets628,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names629,
	types629,
	attr_flags629,
	gtypes629,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets629,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names630,
	types630,
	attr_flags630,
	gtypes630,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets630,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names631,
	types631,
	attr_flags631,
	gtypes631,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets631,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names632,
	types632,
	attr_flags632,
	gtypes632,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets632,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names633,
	types633,
	attr_flags633,
	gtypes633,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets633,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names634,
	types634,
	attr_flags634,
	gtypes634,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets634,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names635,
	types635,
	attr_flags635,
	gtypes635,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets635,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names636,
	types636,
	attr_flags636,
	gtypes636,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets636,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names637,
	types637,
	attr_flags637,
	gtypes637,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets637,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names638,
	types638,
	attr_flags638,
	gtypes638,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets638,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names639,
	types639,
	attr_flags639,
	gtypes639,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets639,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names640,
	types640,
	attr_flags640,
	gtypes640,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets640,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names641,
	types641,
	attr_flags641,
	gtypes641,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets641,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names642,
	types642,
	attr_flags642,
	gtypes642,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets642,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names643,
	types643,
	attr_flags643,
	gtypes643,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets643,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names644,
	types644,
	attr_flags644,
	gtypes644,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets644,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names645,
	types645,
	attr_flags645,
	gtypes645,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets645,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names646,
	types646,
	attr_flags646,
	gtypes646,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets646,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names647,
	types647,
	attr_flags647,
	gtypes647,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets647,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names648,
	types648,
	attr_flags648,
	gtypes648,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets648,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names649,
	types649,
	attr_flags649,
	gtypes649,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets649,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names650,
	types650,
	attr_flags650,
	gtypes650,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets650,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names651,
	types651,
	attr_flags651,
	gtypes651,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets651,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names652,
	types652,
	attr_flags652,
	gtypes652,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets652,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names653,
	types653,
	attr_flags653,
	gtypes653,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets653,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names654,
	types654,
	attr_flags654,
	gtypes654,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets654,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names655,
	types655,
	attr_flags655,
	gtypes655,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets655,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names656,
	types656,
	attr_flags656,
	gtypes656,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets656,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names657,
	types657,
	attr_flags657,
	gtypes657,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets657,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names658,
	types658,
	attr_flags658,
	gtypes658,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets658,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names659,
	types659,
	attr_flags659,
	gtypes659,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets659,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names660,
	types660,
	attr_flags660,
	gtypes660,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets660,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names661,
	types661,
	attr_flags661,
	gtypes661,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets661,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names662,
	types662,
	attr_flags662,
	gtypes662,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets662,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names663,
	types663,
	attr_flags663,
	gtypes663,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets663,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names664,
	types664,
	attr_flags664,
	gtypes664,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets664,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names665,
	types665,
	attr_flags665,
	gtypes665,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets665,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names666,
	types666,
	attr_flags666,
	gtypes666,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets666,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names667,
	types667,
	attr_flags667,
	gtypes667,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets667,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names668,
	types668,
	attr_flags668,
	gtypes668,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets668,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names669,
	types669,
	attr_flags669,
	gtypes669,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets669,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names670,
	types670,
	attr_flags670,
	gtypes670,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets670,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names671,
	types671,
	attr_flags671,
	gtypes671,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets671,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names672,
	types672,
	attr_flags672,
	gtypes672,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets672,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names673,
	types673,
	attr_flags673,
	gtypes673,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets673,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names674,
	types674,
	attr_flags674,
	gtypes674,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets674,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names675,
	types675,
	attr_flags675,
	gtypes675,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets675,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names676,
	types676,
	attr_flags676,
	gtypes676,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets676,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names677,
	types677,
	attr_flags677,
	gtypes677,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets677,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names678,
	types678,
	attr_flags678,
	gtypes678,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets678,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names679,
	types679,
	attr_flags679,
	gtypes679,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets679,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names680,
	types680,
	attr_flags680,
	gtypes680,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets680,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names681,
	types681,
	attr_flags681,
	gtypes681,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets681,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names682,
	types682,
	attr_flags682,
	gtypes682,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets682,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names683,
	types683,
	attr_flags683,
	gtypes683,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets683,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names684,
	types684,
	attr_flags684,
	gtypes684,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets684,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names685,
	types685,
	attr_flags685,
	gtypes685,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets685,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names686,
	types686,
	attr_flags686,
	gtypes686,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets686,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names687,
	types687,
	attr_flags687,
	gtypes687,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets687,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names688,
	types688,
	attr_flags688,
	gtypes688,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets688,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names689,
	types689,
	attr_flags689,
	gtypes689,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets689,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names690,
	types690,
	attr_flags690,
	gtypes690,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets690,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names691,
	types691,
	attr_flags691,
	gtypes691,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets691,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names692,
	types692,
	attr_flags692,
	gtypes692,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets692,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names693,
	types693,
	attr_flags693,
	gtypes693,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets693,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names694,
	types694,
	attr_flags694,
	gtypes694,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets694,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names695,
	types695,
	attr_flags695,
	gtypes695,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets695,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names696,
	types696,
	attr_flags696,
	gtypes696,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets696,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names697,
	types697,
	attr_flags697,
	gtypes697,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets697,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names698,
	types698,
	attr_flags698,
	gtypes698,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets698,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names699,
	types699,
	attr_flags699,
	gtypes699,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets699,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names700,
	types700,
	attr_flags700,
	gtypes700,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets700,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names701,
	types701,
	attr_flags701,
	gtypes701,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets701,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names702,
	types702,
	attr_flags702,
	gtypes702,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets702,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names703,
	types703,
	attr_flags703,
	gtypes703,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets703,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names704,
	types704,
	attr_flags704,
	gtypes704,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets704,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names705,
	types705,
	attr_flags705,
	gtypes705,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets705,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names706,
	types706,
	attr_flags706,
	gtypes706,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets706,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names707,
	types707,
	attr_flags707,
	gtypes707,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets707,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names708,
	types708,
	attr_flags708,
	gtypes708,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets708,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names709,
	types709,
	attr_flags709,
	gtypes709,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets709,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names710,
	types710,
	attr_flags710,
	gtypes710,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets710,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names711,
	types711,
	attr_flags711,
	gtypes711,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets711,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names712,
	types712,
	attr_flags712,
	gtypes712,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets712,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names713,
	types713,
	attr_flags713,
	gtypes713,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets713,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names714,
	types714,
	attr_flags714,
	gtypes714,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets714,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names715,
	types715,
	attr_flags715,
	gtypes715,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets715,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names716,
	types716,
	attr_flags716,
	gtypes716,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets716,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names717,
	types717,
	attr_flags717,
	gtypes717,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets717,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names718,
	types718,
	attr_flags718,
	gtypes718,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets718,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names719,
	types719,
	attr_flags719,
	gtypes719,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets719,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names720,
	types720,
	attr_flags720,
	gtypes720,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets720,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names721,
	types721,
	attr_flags721,
	gtypes721,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets721,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names722,
	types722,
	attr_flags722,
	gtypes722,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets722,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names723,
	types723,
	attr_flags723,
	gtypes723,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets723,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names724,
	types724,
	attr_flags724,
	gtypes724,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets724,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names725,
	types725,
	attr_flags725,
	gtypes725,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets725,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names726,
	types726,
	attr_flags726,
	gtypes726,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets726,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names727,
	types727,
	attr_flags727,
	gtypes727,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets727,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names728,
	types728,
	attr_flags728,
	gtypes728,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets728,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names729,
	types729,
	attr_flags729,
	gtypes729,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets729,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names730,
	types730,
	attr_flags730,
	gtypes730,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets730,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names731,
	types731,
	attr_flags731,
	gtypes731,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets731,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names732,
	types732,
	attr_flags732,
	gtypes732,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets732,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names733,
	types733,
	attr_flags733,
	gtypes733,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets733,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names734,
	types734,
	attr_flags734,
	gtypes734,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets734,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names735,
	types735,
	attr_flags735,
	gtypes735,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets735,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names736,
	types736,
	attr_flags736,
	gtypes736,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets736,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names737,
	types737,
	attr_flags737,
	gtypes737,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets737,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names738,
	types738,
	attr_flags738,
	gtypes738,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets738,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names739,
	types739,
	attr_flags739,
	gtypes739,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets739,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names740,
	types740,
	attr_flags740,
	gtypes740,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets740,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names741,
	types741,
	attr_flags741,
	gtypes741,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets741,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SUBSET",
	names742,
	types742,
	attr_flags742,
	gtypes742,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets742,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE_SUBSET",
	names743,
	types743,
	attr_flags743,
	gtypes743,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets743,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR_SUBSET",
	names744,
	types744,
	attr_flags744,
	gtypes744,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets744,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names745,
	types745,
	attr_flags745,
	gtypes745,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets745,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names746,
	types746,
	attr_flags746,
	gtypes746,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets746,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names747,
	types747,
	attr_flags747,
	gtypes747,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets747,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names748,
	types748,
	attr_flags748,
	gtypes748,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets748,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names749,
	types749,
	attr_flags749,
	gtypes749,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets749,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names750,
	types750,
	attr_flags750,
	gtypes750,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets750,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names751,
	types751,
	attr_flags751,
	gtypes751,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets751,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names752,
	types752,
	attr_flags752,
	gtypes752,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets752,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names753,
	types753,
	attr_flags753,
	gtypes753,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets753,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names754,
	types754,
	attr_flags754,
	gtypes754,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets754,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names755,
	types755,
	attr_flags755,
	gtypes755,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets755,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names756,
	types756,
	attr_flags756,
	gtypes756,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets756,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INFINITE",
	names757,
	types757,
	attr_flags757,
	gtypes757,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets757,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COUNTABLE",
	names758,
	types758,
	attr_flags758,
	gtypes758,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets758,
	NULL
},
{
	(long) 2,
	(long) 2,
	"COUNTABLE_SEQUENCE",
	names759,
	types759,
	attr_flags759,
	gtypes759,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets759,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RANDOM",
	names760,
	types760,
	attr_flags760,
	gtypes760,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets760,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PRIMES",
	names761,
	types761,
	attr_flags761,
	gtypes761,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets761,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names762,
	types762,
	attr_flags762,
	gtypes762,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets762,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names763,
	types763,
	attr_flags763,
	gtypes763,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets763,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names764,
	types764,
	attr_flags764,
	gtypes764,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets764,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names765,
	types765,
	attr_flags765,
	gtypes765,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets765,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names766,
	types766,
	attr_flags766,
	gtypes766,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets766,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names767,
	types767,
	attr_flags767,
	gtypes767,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets767,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names768,
	types768,
	attr_flags768,
	gtypes768,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets768,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names769,
	types769,
	attr_flags769,
	gtypes769,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets769,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names770,
	types770,
	attr_flags770,
	gtypes770,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets770,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names771,
	types771,
	attr_flags771,
	gtypes771,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets771,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names772,
	types772,
	attr_flags772,
	gtypes772,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets772,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names773,
	types773,
	attr_flags773,
	gtypes773,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets773,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names774,
	types774,
	attr_flags774,
	gtypes774,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets774,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names775,
	types775,
	attr_flags775,
	gtypes775,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets775,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names776,
	types776,
	attr_flags776,
	gtypes776,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets776,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names777,
	types777,
	attr_flags777,
	gtypes777,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets777,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names778,
	types778,
	attr_flags778,
	gtypes778,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets778,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names779,
	types779,
	attr_flags779,
	gtypes779,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets779,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names780,
	types780,
	attr_flags780,
	gtypes780,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets780,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names781,
	types781,
	attr_flags781,
	gtypes781,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets781,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names782,
	types782,
	attr_flags782,
	gtypes782,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets782,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names783,
	types783,
	attr_flags783,
	gtypes783,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets783,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names784,
	types784,
	attr_flags784,
	gtypes784,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets784,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names785,
	types785,
	attr_flags785,
	gtypes785,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets785,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names786,
	types786,
	attr_flags786,
	gtypes786,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets786,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names787,
	types787,
	attr_flags787,
	gtypes787,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets787,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names788,
	types788,
	attr_flags788,
	gtypes788,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets788,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names789,
	types789,
	attr_flags789,
	gtypes789,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets789,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names790,
	types790,
	attr_flags790,
	gtypes790,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets790,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names791,
	types791,
	attr_flags791,
	gtypes791,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets791,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names792,
	types792,
	attr_flags792,
	gtypes792,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets792,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names793,
	types793,
	attr_flags793,
	gtypes793,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets793,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names794,
	types794,
	attr_flags794,
	gtypes794,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets794,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names795,
	types795,
	attr_flags795,
	gtypes795,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets795,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names796,
	types796,
	attr_flags796,
	gtypes796,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets796,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names797,
	types797,
	attr_flags797,
	gtypes797,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets797,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names798,
	types798,
	attr_flags798,
	gtypes798,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets798,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names799,
	types799,
	attr_flags799,
	gtypes799,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets799,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUEUE",
	names800,
	types800,
	attr_flags800,
	gtypes800,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets800,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_QUEUE",
	names801,
	types801,
	attr_flags801,
	gtypes801,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets801,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STACK",
	names802,
	types802,
	attr_flags802,
	gtypes802,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets802,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STACK",
	names803,
	types803,
	attr_flags803,
	gtypes803,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets803,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names804,
	types804,
	attr_flags804,
	gtypes804,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets804,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names805,
	types805,
	attr_flags805,
	gtypes805,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets805,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names806,
	types806,
	attr_flags806,
	gtypes806,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets806,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names807,
	types807,
	attr_flags807,
	gtypes807,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets807,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names808,
	types808,
	attr_flags808,
	gtypes808,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets808,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names809,
	types809,
	attr_flags809,
	gtypes809,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets809,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names810,
	types810,
	attr_flags810,
	gtypes810,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets810,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names811,
	types811,
	attr_flags811,
	gtypes811,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets811,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names812,
	types812,
	attr_flags812,
	gtypes812,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets812,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names813,
	types813,
	attr_flags813,
	gtypes813,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets813,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names814,
	types814,
	attr_flags814,
	gtypes814,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets814,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names815,
	types815,
	attr_flags815,
	gtypes815,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets815,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names816,
	types816,
	attr_flags816,
	gtypes816,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets816,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names817,
	types817,
	attr_flags817,
	gtypes817,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets817,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names818,
	types818,
	attr_flags818,
	gtypes818,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets818,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names819,
	types819,
	attr_flags819,
	gtypes819,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets819,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names820,
	types820,
	attr_flags820,
	gtypes820,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets820,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names821,
	types821,
	attr_flags821,
	gtypes821,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets821,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names822,
	types822,
	attr_flags822,
	gtypes822,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets822,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names823,
	types823,
	attr_flags823,
	gtypes823,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets823,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names824,
	types824,
	attr_flags824,
	gtypes824,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets824,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names825,
	types825,
	attr_flags825,
	gtypes825,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets825,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names826,
	types826,
	attr_flags826,
	gtypes826,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets826,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names827,
	types827,
	attr_flags827,
	gtypes827,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets827,
	NULL
},
{
	(long) 20,
	(long) 19,
	"FILE",
	names828,
	types828,
	attr_flags828,
	gtypes828,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets828,
	NULL
},
{
	(long) 21,
	(long) 20,
	"RAW_FILE",
	names829,
	types829,
	attr_flags829,
	gtypes829,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets829,
	NULL
},
{
	(long) 23,
	(long) 22,
	"PLAIN_TEXT_FILE",
	names830,
	types830,
	attr_flags830,
	gtypes830,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets830,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_FILE",
	names839,
	types839,
	attr_flags839,
	gtypes839,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets839,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names852,
	types852,
	attr_flags852,
	gtypes852,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets852,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names853,
	types853,
	attr_flags853,
	gtypes853,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets853,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names854,
	types854,
	attr_flags854,
	gtypes854,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets854,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names855,
	types855,
	attr_flags855,
	gtypes855,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets855,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names856,
	types856,
	attr_flags856,
	gtypes856,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets856,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names857,
	types857,
	attr_flags857,
	gtypes857,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets857,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names858,
	types858,
	attr_flags858,
	gtypes858,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets858,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names859,
	types859,
	attr_flags859,
	gtypes859,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets859,
	NULL
},
{
	(long) 19,
	(long) 19,
	"MISMATCH_INFORMATION",
	names860,
	types860,
	attr_flags860,
	gtypes860,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets860,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names861,
	types861,
	attr_flags861,
	gtypes861,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets861,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names862,
	types862,
	attr_flags862,
	gtypes862,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets862,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names863,
	types863,
	attr_flags863,
	gtypes863,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets863,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names864,
	types864,
	attr_flags864,
	gtypes864,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets864,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names865,
	types865,
	attr_flags865,
	gtypes865,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets865,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names866,
	types866,
	attr_flags866,
	gtypes866,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets866,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names867,
	types867,
	attr_flags867,
	gtypes867,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets867,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names868,
	types868,
	attr_flags868,
	gtypes868,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets868,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names869,
	types869,
	attr_flags869,
	gtypes869,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets869,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names870,
	types870,
	attr_flags870,
	gtypes870,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets870,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names871,
	types871,
	attr_flags871,
	gtypes871,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets871,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names872,
	types872,
	attr_flags872,
	gtypes872,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets872,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names873,
	types873,
	attr_flags873,
	gtypes873,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets873,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names874,
	types874,
	attr_flags874,
	gtypes874,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets874,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names875,
	types875,
	attr_flags875,
	gtypes875,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets875,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names876,
	types876,
	attr_flags876,
	gtypes876,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets876,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names877,
	types877,
	attr_flags877,
	gtypes877,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets877,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INTEGER_INTERVAL",
	names878,
	types878,
	attr_flags878,
	gtypes878,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets878,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names879,
	types879,
	attr_flags879,
	gtypes879,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets879,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names880,
	types880,
	attr_flags880,
	gtypes880,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets880,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names881,
	types881,
	attr_flags881,
	gtypes881,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets881,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names882,
	types882,
	attr_flags882,
	gtypes882,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets882,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names883,
	types883,
	attr_flags883,
	gtypes883,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets883,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names884,
	types884,
	attr_flags884,
	gtypes884,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets884,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names885,
	types885,
	attr_flags885,
	gtypes885,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets885,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names886,
	types886,
	attr_flags886,
	gtypes886,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets886,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names887,
	types887,
	attr_flags887,
	gtypes887,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets887,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names888,
	types888,
	attr_flags888,
	gtypes888,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets888,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names889,
	types889,
	attr_flags889,
	gtypes889,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets889,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names890,
	types890,
	attr_flags890,
	gtypes890,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets890,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names891,
	types891,
	attr_flags891,
	gtypes891,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets891,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names892,
	types892,
	attr_flags892,
	gtypes892,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets892,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names893,
	types893,
	attr_flags893,
	gtypes893,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets893,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names894,
	types894,
	attr_flags894,
	gtypes894,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets894,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names895,
	types895,
	attr_flags895,
	gtypes895,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets895,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names896,
	types896,
	attr_flags896,
	gtypes896,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets896,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names897,
	types897,
	attr_flags897,
	gtypes897,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets897,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names898,
	types898,
	attr_flags898,
	gtypes898,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets898,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names899,
	types899,
	attr_flags899,
	gtypes899,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets899,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names900,
	types900,
	attr_flags900,
	gtypes900,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets900,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names901,
	types901,
	attr_flags901,
	gtypes901,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets901,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names902,
	types902,
	attr_flags902,
	gtypes902,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets902,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names903,
	types903,
	attr_flags903,
	gtypes903,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets903,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names904,
	types904,
	attr_flags904,
	gtypes904,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets904,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names905,
	types905,
	attr_flags905,
	gtypes905,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets905,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names906,
	types906,
	attr_flags906,
	gtypes906,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets906,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names907,
	types907,
	attr_flags907,
	gtypes907,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets907,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names908,
	types908,
	attr_flags908,
	gtypes908,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets908,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names909,
	types909,
	attr_flags909,
	gtypes909,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets909,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names910,
	types910,
	attr_flags910,
	gtypes910,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets910,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names911,
	types911,
	attr_flags911,
	gtypes911,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets911,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names912,
	types912,
	attr_flags912,
	gtypes912,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets912,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names913,
	types913,
	attr_flags913,
	gtypes913,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets913,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names914,
	types914,
	attr_flags914,
	gtypes914,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets914,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names915,
	types915,
	attr_flags915,
	gtypes915,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets915,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names916,
	types916,
	attr_flags916,
	gtypes916,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets916,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names917,
	types917,
	attr_flags917,
	gtypes917,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets917,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names918,
	types918,
	attr_flags918,
	gtypes918,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets918,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names919,
	types919,
	attr_flags919,
	gtypes919,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets919,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names920,
	types920,
	attr_flags920,
	gtypes920,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets920,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names921,
	types921,
	attr_flags921,
	gtypes921,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets921,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names922,
	types922,
	attr_flags922,
	gtypes922,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets922,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names923,
	types923,
	attr_flags923,
	gtypes923,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets923,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names924,
	types924,
	attr_flags924,
	gtypes924,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets924,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names925,
	types925,
	attr_flags925,
	gtypes925,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets925,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names926,
	types926,
	attr_flags926,
	gtypes926,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets926,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names927,
	types927,
	attr_flags927,
	gtypes927,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets927,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names928,
	types928,
	attr_flags928,
	gtypes928,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets928,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names929,
	types929,
	attr_flags929,
	gtypes929,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets929,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names930,
	types930,
	attr_flags930,
	gtypes930,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets930,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names931,
	types931,
	attr_flags931,
	gtypes931,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets931,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names932,
	types932,
	attr_flags932,
	gtypes932,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets932,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names933,
	types933,
	attr_flags933,
	gtypes933,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets933,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names934,
	types934,
	attr_flags934,
	gtypes934,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets934,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names935,
	types935,
	attr_flags935,
	gtypes935,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets935,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names936,
	types936,
	attr_flags936,
	gtypes936,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets936,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names937,
	types937,
	attr_flags937,
	gtypes937,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets937,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names938,
	types938,
	attr_flags938,
	gtypes938,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets938,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names939,
	types939,
	attr_flags939,
	gtypes939,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets939,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names940,
	types940,
	attr_flags940,
	gtypes940,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets940,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names941,
	types941,
	attr_flags941,
	gtypes941,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets941,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names942,
	types942,
	attr_flags942,
	gtypes942,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets942,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names943,
	types943,
	attr_flags943,
	gtypes943,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets943,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names944,
	types944,
	attr_flags944,
	gtypes944,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets944,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names945,
	types945,
	attr_flags945,
	gtypes945,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets945,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_STACK",
	names946,
	types946,
	attr_flags946,
	gtypes946,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets946,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_STACK",
	names947,
	types947,
	attr_flags947,
	gtypes947,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets947,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_SET",
	names948,
	types948,
	attr_flags948,
	gtypes948,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets948,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names949,
	types949,
	attr_flags949,
	gtypes949,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets949,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names950,
	types950,
	attr_flags950,
	gtypes950,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets950,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names951,
	types951,
	attr_flags951,
	gtypes951,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets951,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names952,
	types952,
	attr_flags952,
	gtypes952,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets952,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names953,
	types953,
	attr_flags953,
	gtypes953,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets953,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names954,
	types954,
	attr_flags954,
	gtypes954,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets954,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names955,
	types955,
	attr_flags955,
	gtypes955,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets955,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names956,
	types956,
	attr_flags956,
	gtypes956,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets956,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names957,
	types957,
	attr_flags957,
	gtypes957,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets957,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names958,
	types958,
	attr_flags958,
	gtypes958,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets958,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names959,
	types959,
	attr_flags959,
	gtypes959,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets959,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names960,
	types960,
	attr_flags960,
	gtypes960,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets960,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_SET",
	names961,
	types961,
	attr_flags961,
	gtypes961,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets961,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_CONDITION_LIST",
	names962,
	types962,
	attr_flags962,
	gtypes962,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets962,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_STACK",
	names963,
	types963,
	attr_flags963,
	gtypes963,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets963,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_STACK",
	names964,
	types964,
	attr_flags964,
	gtypes964,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets964,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_NOTE_ELEMENT",
	names965,
	types965,
	attr_flags965,
	gtypes965,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets965,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_ACCESS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 30,
	(long) 30,
	"CONF_LOAD_PARSE_CALLBACKS",
	names967,
	types967,
	attr_flags967,
	gtypes967,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets967,
	NULL
},
{
	(long) 6,
	(long) 6,
	"CONF_PARENT_TARGET_CHECKER",
	names968,
	types968,
	attr_flags968,
	gtypes968,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets968,
	NULL
},
{
	(long) 12,
	(long) 12,
	"CONF_LOAD",
	names969,
	types969,
	attr_flags969,
	gtypes969,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets969,
	NULL
},
{
	(long) 30,
	(long) 30,
	"CONF_OPTION",
	names970,
	types970,
	attr_flags970,
	gtypes970,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets970,
	NULL
},
{
	(long) 36,
	(long) 36,
	"CONF_TARGET_OPTION",
	names971,
	types971,
	attr_flags971,
	gtypes971,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets971,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_VISIBLE",
	names972,
	types972,
	attr_flags972,
	gtypes972,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets972,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CASE_INSENSITIVE_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDERR_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDOUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_NULL_TEXT_OUTPUT_STREAM",
	names982,
	types982,
	attr_flags982,
	gtypes982,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets982,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_STDIN_FILE",
	names997,
	types997,
	attr_flags997,
	gtypes997,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets997,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING_INPUT_STREAM",
	names998,
	types998,
	attr_flags998,
	gtypes998,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets998,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_ERROR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_VISI",
	names1003,
	types1003,
	attr_flags1003,
	gtypes1003,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1003,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_VISI_CONFL03",
	names1004,
	types1004,
	attr_flags1004,
	gtypes1004,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1004,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_VISI_CONFL02",
	names1005,
	types1005,
	attr_flags1005,
	gtypes1005,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1005,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_VISI_CONFL01",
	names1006,
	types1006,
	attr_flags1006,
	gtypes1006,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1006,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_MULOVER",
	names1007,
	types1007,
	attr_flags1007,
	gtypes1007,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1007,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_ERROR_CYCLE_IN_PARENTS",
	names1008,
	types1008,
	attr_flags1008,
	gtypes1008,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1008,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_ERROR_UUID_MISMATCH_IN_REDIRECTION",
	names1009,
	types1009,
	attr_flags1009,
	gtypes1009,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1009,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_ERROR_MESSAGE_IN_REDIRECTION",
	names1010,
	types1010,
	attr_flags1010,
	gtypes1010,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1010,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_ERROR_CYCLE_IN_REDIRECTION",
	names1011,
	types1011,
	attr_flags1011,
	gtypes1011,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1011,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_PREINLIB",
	names1012,
	types1012,
	attr_flags1012,
	gtypes1012,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1012,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_ERROR_FILE",
	names1013,
	types1013,
	attr_flags1013,
	gtypes1013,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1013,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_NOLIB",
	names1014,
	types1014,
	attr_flags1014,
	gtypes1014,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1014,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_UUIDFILE",
	names1015,
	types1015,
	attr_flags1015,
	gtypes1015,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1015,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_PARSE",
	names1016,
	types1016,
	attr_flags1016,
	gtypes1016,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1016,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_LIBOVER",
	names1017,
	types1017,
	attr_flags1017,
	gtypes1017,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1017,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_LIBTAR",
	names1018,
	types1018,
	attr_flags1018,
	gtypes1018,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1018,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONF_ERROR_REGEXP",
	names1019,
	types1019,
	attr_flags1019,
	gtypes1019,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1019,
	NULL
},
{
	(long) 6,
	(long) 6,
	"CONF_ERROR_GRUNDEF",
	names1020,
	types1020,
	attr_flags1020,
	gtypes1020,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1020,
	NULL
},
{
	(long) 6,
	(long) 6,
	"CONF_ERROR_OVERRIDE",
	names1021,
	types1021,
	attr_flags1021,
	gtypes1021,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1021,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_VERSION",
	names1022,
	types1022,
	attr_flags1022,
	gtypes1022,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1022,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_ERROR_UUID",
	names1023,
	types1023,
	attr_flags1023,
	gtypes1023,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1023,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UC_CHARACTER",
	names1025,
	types1025,
	attr_flags1025,
	gtypes1025,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1025,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TUPLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"ARGUMENT_SWITCH",
	names1027,
	types1027,
	attr_flags1027,
	gtypes1027,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1027,
	NULL
},
{
	(long) 11,
	(long) 11,
	"ARGUMENT_VALUE_SWITCH",
	names1028,
	types1028,
	attr_flags1028,
	gtypes1028,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1028,
	NULL
},
{
	(long) 11,
	(long) 11,
	"ARGUMENT_DIRECTORY_SWITCH",
	names1029,
	types1029,
	attr_flags1029,
	gtypes1029,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1029,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32_REF",
	names1030,
	types1030,
	attr_flags1030,
	gtypes1030,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1030,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names1031,
	types1031,
	attr_flags1031,
	gtypes1031,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1031,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names1032,
	types1032,
	attr_flags1032,
	gtypes1032,
	(uint16) 0x230E,
	(void (*)()) 0,
	offsets1032,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8_REF",
	names1033,
	types1033,
	attr_flags1033,
	gtypes1033,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1033,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names1034,
	types1034,
	attr_flags1034,
	gtypes1034,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1034,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names1035,
	types1035,
	attr_flags1035,
	gtypes1035,
	(uint16) 0x2302,
	(void (*)()) 0,
	offsets1035,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN_REF",
	names1036,
	types1036,
	attr_flags1036,
	gtypes1036,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1036,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names1037,
	types1037,
	attr_flags1037,
	gtypes1037,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1037,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names1038,
	types1038,
	attr_flags1038,
	gtypes1038,
	(uint16) 0x2301,
	(void (*)()) 0,
	offsets1038,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER_REF",
	names1039,
	types1039,
	attr_flags1039,
	gtypes1039,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1039,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1040,
	types1040,
	attr_flags1040,
	gtypes1040,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1040,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1041,
	types1041,
	attr_flags1041,
	gtypes1041,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1041,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1042,
	types1042,
	attr_flags1042,
	gtypes1042,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1042,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1043,
	types1043,
	attr_flags1043,
	gtypes1043,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1043,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1044,
	types1044,
	attr_flags1044,
	gtypes1044,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1044,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1045,
	types1045,
	attr_flags1045,
	gtypes1045,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1045,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1046,
	types1046,
	attr_flags1046,
	gtypes1046,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1046,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1047,
	types1047,
	attr_flags1047,
	gtypes1047,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1047,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1048,
	types1048,
	attr_flags1048,
	gtypes1048,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1048,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1049,
	types1049,
	attr_flags1049,
	gtypes1049,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1049,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1050,
	types1050,
	attr_flags1050,
	gtypes1050,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1050,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1051,
	types1051,
	attr_flags1051,
	gtypes1051,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1051,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1052,
	types1052,
	attr_flags1052,
	gtypes1052,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1052,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1053,
	types1053,
	attr_flags1053,
	gtypes1053,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1053,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1054,
	types1054,
	attr_flags1054,
	gtypes1054,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1054,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1055,
	types1055,
	attr_flags1055,
	gtypes1055,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1055,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1056,
	types1056,
	attr_flags1056,
	gtypes1056,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1056,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1057,
	types1057,
	attr_flags1057,
	gtypes1057,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1057,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1058,
	types1058,
	attr_flags1058,
	gtypes1058,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1058,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1059,
	types1059,
	attr_flags1059,
	gtypes1059,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1059,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1060,
	types1060,
	attr_flags1060,
	gtypes1060,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1060,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1061,
	types1061,
	attr_flags1061,
	gtypes1061,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1061,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1062,
	types1062,
	attr_flags1062,
	gtypes1062,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1062,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1063,
	types1063,
	attr_flags1063,
	gtypes1063,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1063,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1064,
	types1064,
	attr_flags1064,
	gtypes1064,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1064,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1065,
	types1065,
	attr_flags1065,
	gtypes1065,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1065,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1066,
	types1066,
	attr_flags1066,
	gtypes1066,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1066,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1067,
	types1067,
	attr_flags1067,
	gtypes1067,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1067,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1068,
	types1068,
	attr_flags1068,
	gtypes1068,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1068,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1069,
	types1069,
	attr_flags1069,
	gtypes1069,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1069,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names1070,
	types1070,
	attr_flags1070,
	gtypes1070,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1070,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names1071,
	types1071,
	attr_flags1071,
	gtypes1071,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1071,
	NULL
},
{
	(long) 12,
	(long) 12,
	"ROUTINE",
	names1072,
	types1072,
	attr_flags1072,
	gtypes1072,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1072,
	NULL
},
{
	(long) 12,
	(long) 12,
	"PROCEDURE",
	names1073,
	types1073,
	attr_flags1073,
	gtypes1073,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1073,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names1074,
	types1074,
	attr_flags1074,
	gtypes1074,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1074,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names1075,
	types1075,
	attr_flags1075,
	gtypes1075,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1075,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names1076,
	types1076,
	attr_flags1076,
	gtypes1076,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1076,
	NULL
},
{
	(long) 13,
	(long) 13,
	"PREDICATE",
	names1077,
	types1077,
	attr_flags1077,
	gtypes1077,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1077,
	NULL
},
{
	(long) 2,
	(long) 2,
	"READABLE_STRING_GENERAL",
	names1078,
	types1078,
	attr_flags1078,
	gtypes1078,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1078,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IMMUTABLE_STRING_GENERAL",
	names1079,
	types1079,
	attr_flags1079,
	gtypes1079,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1079,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_GENERAL",
	names1080,
	types1080,
	attr_flags1080,
	gtypes1080,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1080,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_8",
	names1081,
	types1081,
	attr_flags1081,
	gtypes1081,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1081,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_8",
	names1082,
	types1082,
	attr_flags1082,
	gtypes1082,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1082,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8",
	names1083,
	types1083,
	attr_flags1083,
	gtypes1083,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1083,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING",
	names1084,
	types1084,
	attr_flags1084,
	gtypes1084,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1084,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_32",
	names1085,
	types1085,
	attr_flags1085,
	gtypes1085,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1085,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_32",
	names1086,
	types1086,
	attr_flags1086,
	gtypes1086,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1086,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32",
	names1087,
	types1087,
	attr_flags1087,
	gtypes1087,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1087,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DEBUG_OUTPUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"IRON_WEB_REPOSITORY",
	names1089,
	types1089,
	attr_flags1089,
	gtypes1089,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1089,
	NULL
},
{
	(long) 3,
	(long) 3,
	"IRON_WORKING_COPY_REPOSITORY",
	names1090,
	types1090,
	attr_flags1090,
	gtypes1090,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1090,
	NULL
},
{
	(long) 12,
	(long) 12,
	"IRON_PACKAGE",
	names1091,
	types1091,
	attr_flags1091,
	gtypes1091,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1091,
	NULL
},
{
	(long) 8,
	(long) 8,
	"XML_STRING_INPUT_STREAM",
	names1092,
	types1092,
	attr_flags1092,
	gtypes1092,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1092,
	NULL
},
{
	(long) 13,
	(long) 13,
	"XML_FILE_INPUT_STREAM",
	names1093,
	types1093,
	attr_flags1093,
	gtypes1093,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1093,
	NULL
},
{
	(long) 9,
	(long) 9,
	"DATE_TIME_CODE",
	names1094,
	types1094,
	attr_flags1094,
	gtypes1094,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1094,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_VALUE_CHOICE",
	names1095,
	types1095,
	attr_flags1095,
	gtypes1095,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1095,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_ORDERED_CAPABILITY",
	names1096,
	types1096,
	attr_flags1096,
	gtypes1096,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1096,
	NULL
},
{
	(long) 19,
	(long) 19,
	"CONF_CLASS",
	names1097,
	types1097,
	attr_flags1097,
	gtypes1097,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1097,
	NULL
},
{
	(long) 15,
	(long) 15,
	"RT_DBG_CALL_RECORD",
	names1098,
	types1098,
	attr_flags1098,
	gtypes1098,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1098,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XML_POSITION",
	names1099,
	types1099,
	attr_flags1099,
	gtypes1099,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1099,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UUID",
	names1100,
	types1100,
	attr_flags1100,
	gtypes1100,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1100,
	NULL
},
{
	(long) 30,
	(long) 30,
	"CONF_TARGET",
	names1101,
	types1101,
	attr_flags1101,
	gtypes1101,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1101,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PATH",
	names1102,
	types1102,
	attr_flags1102,
	gtypes1102,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1102,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INI_SECTION",
	names1103,
	types1103,
	attr_flags1103,
	gtypes1103,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1103,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1104,
	types1104,
	attr_flags1104,
	gtypes1104,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1104,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1105,
	types1105,
	attr_flags1105,
	gtypes1105,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1105,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1106,
	types1106,
	attr_flags1106,
	gtypes1106,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1106,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1107,
	types1107,
	attr_flags1107,
	gtypes1107,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1107,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1108,
	types1108,
	attr_flags1108,
	gtypes1108,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1108,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1109,
	types1109,
	attr_flags1109,
	gtypes1109,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1109,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1110,
	types1110,
	attr_flags1110,
	gtypes1110,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1110,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1111,
	types1111,
	attr_flags1111,
	gtypes1111,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1111,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1112,
	types1112,
	attr_flags1112,
	gtypes1112,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1112,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1113,
	types1113,
	attr_flags1113,
	gtypes1113,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1113,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1114,
	types1114,
	attr_flags1114,
	gtypes1114,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1114,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1115,
	types1115,
	attr_flags1115,
	gtypes1115,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1115,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1116,
	types1116,
	attr_flags1116,
	gtypes1116,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1116,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1117,
	types1117,
	attr_flags1117,
	gtypes1117,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1117,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1118,
	types1118,
	attr_flags1118,
	gtypes1118,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1118,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1119,
	types1119,
	attr_flags1119,
	gtypes1119,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1119,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1120,
	types1120,
	attr_flags1120,
	gtypes1120,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1120,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1121,
	types1121,
	attr_flags1121,
	gtypes1121,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1121,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1122,
	types1122,
	attr_flags1122,
	gtypes1122,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1122,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1123,
	types1123,
	attr_flags1123,
	gtypes1123,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1123,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1124,
	types1124,
	attr_flags1124,
	gtypes1124,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1124,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1125,
	types1125,
	attr_flags1125,
	gtypes1125,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1125,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1126,
	types1126,
	attr_flags1126,
	gtypes1126,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1126,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1127,
	types1127,
	attr_flags1127,
	gtypes1127,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1127,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1128,
	types1128,
	attr_flags1128,
	gtypes1128,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1128,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1129,
	types1129,
	attr_flags1129,
	gtypes1129,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1129,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1130,
	types1130,
	attr_flags1130,
	gtypes1130,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1130,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1131,
	types1131,
	attr_flags1131,
	gtypes1131,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1131,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1132,
	types1132,
	attr_flags1132,
	gtypes1132,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1132,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1133,
	types1133,
	attr_flags1133,
	gtypes1133,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1133,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1134,
	types1134,
	attr_flags1134,
	gtypes1134,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1134,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1135,
	types1135,
	attr_flags1135,
	gtypes1135,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1135,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1136,
	types1136,
	attr_flags1136,
	gtypes1136,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1136,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1137,
	types1137,
	attr_flags1137,
	gtypes1137,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1137,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1138,
	types1138,
	attr_flags1138,
	gtypes1138,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1138,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names1139,
	types1139,
	attr_flags1139,
	gtypes1139,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1139,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSTRACT_SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 20,
	(long) 20,
	"CONF_GROUP",
	names1153,
	types1153,
	attr_flags1153,
	gtypes1153,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1153,
	NULL
},
{
	(long) 20,
	(long) 20,
	"CONF_PHYSICAL_GROUP",
	names1154,
	types1154,
	attr_flags1154,
	gtypes1154,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1154,
	NULL
},
{
	(long) 22,
	(long) 22,
	"CONF_PHYSICAL_ASSEMBLY_INTERFACE",
	names1155,
	types1155,
	attr_flags1155,
	gtypes1155,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1155,
	NULL
},
{
	(long) 33,
	(long) 33,
	"CONF_CLUSTER",
	names1156,
	types1156,
	attr_flags1156,
	gtypes1156,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1156,
	NULL
},
{
	(long) 33,
	(long) 33,
	"CONF_TEST_CLUSTER",
	names1157,
	types1157,
	attr_flags1157,
	gtypes1157,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1157,
	NULL
},
{
	(long) 35,
	(long) 35,
	"CONF_OVERRIDE",
	names1158,
	types1158,
	attr_flags1158,
	gtypes1158,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1158,
	NULL
},
{
	(long) 22,
	(long) 22,
	"CONF_VIRTUAL_GROUP",
	names1159,
	types1159,
	attr_flags1159,
	gtypes1159,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1159,
	NULL
},
{
	(long) 28,
	(long) 28,
	"CONF_ASSEMBLY",
	names1160,
	types1160,
	attr_flags1160,
	gtypes1160,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1160,
	NULL
},
{
	(long) 26,
	(long) 26,
	"CONF_LIBRARY",
	names1161,
	types1161,
	attr_flags1161,
	gtypes1161,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1161,
	NULL
},
{
	(long) 27,
	(long) 27,
	"CONF_PRECOMPILE",
	names1162,
	types1162,
	attr_flags1162,
	gtypes1162,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1162,
	NULL
},
{
	(long) 3,
	(long) 3,
	"RT_DBG_VALUE_RECORD",
	names1163,
	types1163,
	attr_flags1163,
	gtypes1163,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1163,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1164,
	types1164,
	attr_flags1164,
	gtypes1164,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1164,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1165,
	types1165,
	attr_flags1165,
	gtypes1165,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1165,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1166,
	types1166,
	attr_flags1166,
	gtypes1166,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1166,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1167,
	types1167,
	attr_flags1167,
	gtypes1167,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1167,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1168,
	types1168,
	attr_flags1168,
	gtypes1168,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1168,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1169,
	types1169,
	attr_flags1169,
	gtypes1169,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1169,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1170,
	types1170,
	attr_flags1170,
	gtypes1170,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1170,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1171,
	types1171,
	attr_flags1171,
	gtypes1171,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1171,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1172,
	types1172,
	attr_flags1172,
	gtypes1172,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1172,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1173,
	types1173,
	attr_flags1173,
	gtypes1173,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1173,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1174,
	types1174,
	attr_flags1174,
	gtypes1174,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1174,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1175,
	types1175,
	attr_flags1175,
	gtypes1175,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1175,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1176,
	types1176,
	attr_flags1176,
	gtypes1176,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1176,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1177,
	types1177,
	attr_flags1177,
	gtypes1177,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1177,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names1178,
	types1178,
	attr_flags1178,
	gtypes1178,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1178,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1179,
	types1179,
	attr_flags1179,
	gtypes1179,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1179,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1180,
	types1180,
	attr_flags1180,
	gtypes1180,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1180,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1181,
	types1181,
	attr_flags1181,
	gtypes1181,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1181,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1182,
	types1182,
	attr_flags1182,
	gtypes1182,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1182,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1183,
	types1183,
	attr_flags1183,
	gtypes1183,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1183,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1184,
	types1184,
	attr_flags1184,
	gtypes1184,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1184,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1185,
	types1185,
	attr_flags1185,
	gtypes1185,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1185,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1186,
	types1186,
	attr_flags1186,
	gtypes1186,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1186,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1187,
	types1187,
	attr_flags1187,
	gtypes1187,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1187,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1188,
	types1188,
	attr_flags1188,
	gtypes1188,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1188,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1189,
	types1189,
	attr_flags1189,
	gtypes1189,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1189,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1190,
	types1190,
	attr_flags1190,
	gtypes1190,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1190,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1191,
	types1191,
	attr_flags1191,
	gtypes1191,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1191,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1192,
	types1192,
	attr_flags1192,
	gtypes1192,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1192,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names1193,
	types1193,
	attr_flags1193,
	gtypes1193,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1193,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1194,
	types1194,
	attr_flags1194,
	gtypes1194,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1194,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1195,
	types1195,
	attr_flags1195,
	gtypes1195,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1195,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1196,
	types1196,
	attr_flags1196,
	gtypes1196,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1196,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1197,
	types1197,
	attr_flags1197,
	gtypes1197,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1197,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1198,
	types1198,
	attr_flags1198,
	gtypes1198,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1198,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1199,
	types1199,
	attr_flags1199,
	gtypes1199,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1199,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1200,
	types1200,
	attr_flags1200,
	gtypes1200,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1200,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1201,
	types1201,
	attr_flags1201,
	gtypes1201,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1201,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1202,
	types1202,
	attr_flags1202,
	gtypes1202,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1202,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1203,
	types1203,
	attr_flags1203,
	gtypes1203,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1203,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1204,
	types1204,
	attr_flags1204,
	gtypes1204,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1204,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1205,
	types1205,
	attr_flags1205,
	gtypes1205,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1205,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1206,
	types1206,
	attr_flags1206,
	gtypes1206,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1206,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1207,
	types1207,
	attr_flags1207,
	gtypes1207,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1207,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names1208,
	types1208,
	attr_flags1208,
	gtypes1208,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1208,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_VALUE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"JSON_BOOLEAN",
	names1210,
	types1210,
	attr_flags1210,
	gtypes1210,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1210,
	NULL
},
{
	(long) 0,
	(long) 0,
	"JSON_NULL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"JSON_STRING",
	names1212,
	types1212,
	attr_flags1212,
	gtypes1212,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1212,
	NULL
},
{
	(long) 2,
	(long) 2,
	"JSON_NUMBER",
	names1213,
	types1213,
	attr_flags1213,
	gtypes1213,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1213,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64_REF",
	names1215,
	types1215,
	attr_flags1215,
	gtypes1215,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1215,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names1216,
	types1216,
	attr_flags1216,
	gtypes1216,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1216,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names1217,
	types1217,
	attr_flags1217,
	gtypes1217,
	(uint16) 0x2309,
	(void (*)()) 0,
	offsets1217,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32_REF",
	names1218,
	types1218,
	attr_flags1218,
	gtypes1218,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1218,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names1219,
	types1219,
	attr_flags1219,
	gtypes1219,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1219,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names1220,
	types1220,
	attr_flags1220,
	gtypes1220,
	(uint16) 0x2308,
	(void (*)()) 0,
	offsets1220,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16_REF",
	names1221,
	types1221,
	attr_flags1221,
	gtypes1221,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1221,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names1222,
	types1222,
	attr_flags1222,
	gtypes1222,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1222,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names1223,
	types1223,
	attr_flags1223,
	gtypes1223,
	(uint16) 0x2307,
	(void (*)()) 0,
	offsets1223,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8_REF",
	names1224,
	types1224,
	attr_flags1224,
	gtypes1224,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1224,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names1225,
	types1225,
	attr_flags1225,
	gtypes1225,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1225,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names1226,
	types1226,
	attr_flags1226,
	gtypes1226,
	(uint16) 0x2306,
	(void (*)()) 0,
	offsets1226,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64_REF",
	names1227,
	types1227,
	attr_flags1227,
	gtypes1227,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1227,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names1228,
	types1228,
	attr_flags1228,
	gtypes1228,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1228,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names1229,
	types1229,
	attr_flags1229,
	gtypes1229,
	(uint16) 0x230D,
	(void (*)()) 0,
	offsets1229,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32_REF",
	names1230,
	types1230,
	attr_flags1230,
	gtypes1230,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1230,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names1231,
	types1231,
	attr_flags1231,
	gtypes1231,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1231,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names1232,
	types1232,
	attr_flags1232,
	gtypes1232,
	(uint16) 0x230C,
	(void (*)()) 0,
	offsets1232,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16_REF",
	names1233,
	types1233,
	attr_flags1233,
	gtypes1233,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1233,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names1234,
	types1234,
	attr_flags1234,
	gtypes1234,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1234,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names1235,
	types1235,
	attr_flags1235,
	gtypes1235,
	(uint16) 0x230B,
	(void (*)()) 0,
	offsets1235,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8_REF",
	names1236,
	types1236,
	attr_flags1236,
	gtypes1236,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1236,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names1237,
	types1237,
	attr_flags1237,
	gtypes1237,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1237,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names1238,
	types1238,
	attr_flags1238,
	gtypes1238,
	(uint16) 0x230A,
	(void (*)()) 0,
	offsets1238,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32_REF",
	names1239,
	types1239,
	attr_flags1239,
	gtypes1239,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1239,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names1240,
	types1240,
	attr_flags1240,
	gtypes1240,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1240,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names1241,
	types1241,
	attr_flags1241,
	gtypes1241,
	(uint16) 0x2304,
	(void (*)()) 0,
	offsets1241,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64_REF",
	names1242,
	types1242,
	attr_flags1242,
	gtypes1242,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1242,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names1243,
	types1243,
	attr_flags1243,
	gtypes1243,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1243,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names1244,
	types1244,
	attr_flags1244,
	gtypes1244,
	(uint16) 0x2303,
	(void (*)()) 0,
	offsets1244,
	NULL
},
{
	(long) 1,
	(long) 1,
	"JSON_ARRAY",
	names1245,
	types1245,
	attr_flags1245,
	gtypes1245,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1245,
	NULL
},
{
	(long) 1,
	(long) 1,
	"JSON_OBJECT",
	names1246,
	types1246,
	attr_flags1246,
	gtypes1246,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1246,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_LANGUAGE_ID",
	names1252,
	types1252,
	attr_flags1252,
	gtypes1252,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1252,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"THREAD_ATTRIBUTES",
	names1254,
	types1254,
	attr_flags1254,
	gtypes1254,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1254,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_LOCALE_ID",
	names1255,
	types1255,
	attr_flags1255,
	gtypes1255,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1255,
	NULL
},
{
	(long) 2,
	(long) 2,
	"I18N_LOCALE_MANAGER",
	names1256,
	types1256,
	attr_flags1256,
	gtypes1256,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1256,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INI_PROPERTY",
	names1257,
	types1257,
	attr_flags1257,
	gtypes1257,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1257,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INI_SCANNER",
	names1258,
	types1258,
	attr_flags1258,
	gtypes1258,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1258,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INI_SCANNER_TOKEN_INFO",
	names1259,
	types1259,
	attr_flags1259,
	gtypes1259,
	(uint16) 0x0800,
	(void (*)()) 0,
	offsets1259,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONF_SETTING",
	names1260,
	types1260,
	attr_flags1260,
	gtypes1260,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1260,
	NULL
},
{
	(long) 23,
	(long) 22,
	"CONSOLE",
	names1261,
	types1261,
	attr_flags1261,
	gtypes1261,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1261,
	NULL
},
{
	(long) 10,
	(long) 10,
	"SEARCH_TABLE",
	names1262,
	types1262,
	attr_flags1262,
	gtypes1262,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1262,
	NULL
},
{
	(long) 10,
	(long) 10,
	"SEARCH_TABLE",
	names1263,
	types1263,
	attr_flags1263,
	gtypes1263,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1263,
	NULL
},
{
	(long) 10,
	(long) 10,
	"SEARCH_TABLE",
	names1264,
	types1264,
	attr_flags1264,
	gtypes1264,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1264,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_LITERAL",
	names1265,
	types1265,
	attr_flags1265,
	gtypes1265,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1265,
	NULL
},
{
	(long) 13,
	(long) 13,
	"CONF_VERSION",
	names1266,
	types1266,
	attr_flags1266,
	gtypes1266,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1266,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_TITLECASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_UPPERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_LOWERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"YY_SCANNER",
	names1272,
	types1272,
	attr_flags1272,
	gtypes1272,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1272,
	NULL
},
{
	(long) 22,
	(long) 22,
	"YY_SCANNER_SKELETON",
	names1273,
	types1273,
	attr_flags1273,
	gtypes1273,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1273,
	NULL
},
{
	(long) 38,
	(long) 38,
	"YY_COMPRESSED_SCANNER_SKELETON",
	names1274,
	types1274,
	attr_flags1274,
	gtypes1274,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1274,
	NULL
},
{
	(long) 42,
	(long) 42,
	"CLASSNAME_FINDER_SKELETON",
	names1275,
	types1275,
	attr_flags1275,
	gtypes1275,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1275,
	NULL
},
{
	(long) 42,
	(long) 42,
	"CLASSNAME_FINDER",
	names1276,
	types1276,
	attr_flags1276,
	gtypes1276,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1276,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_ACTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CLONABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ENCODING_DETECTOR",
	names1279,
	types1279,
	attr_flags1279,
	gtypes1279,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1279,
	NULL
},
{
	(long) 4,
	(long) 4,
	"BOM_ENCODING_DETECTOR",
	names1280,
	types1280,
	attr_flags1280,
	gtypes1280,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1280,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FIND_SEPARATOR_FACILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATE_TIME_CODE_STRING",
	names1282,
	types1282,
	attr_flags1282,
	gtypes1282,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1282,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_I",
	names1283,
	types1283,
	attr_flags1283,
	gtypes1283,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1283,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_IMP",
	names1284,
	types1284,
	attr_flags1284,
	gtypes1284,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1284,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UNICODE_CONVERSION",
	names1285,
	types1285,
	attr_flags1285,
	gtypes1285,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1285,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_HOST_LOCALE_IMP",
	names1286,
	types1286,
	attr_flags1286,
	gtypes1286,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1286,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONF_FILE",
	names1287,
	types1287,
	attr_flags1287,
	gtypes1287,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1287,
	NULL
},
{
	(long) 8,
	(long) 8,
	"CONF_REDIRECTION",
	names1288,
	types1288,
	attr_flags1288,
	gtypes1288,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1288,
	NULL
},
{
	(long) 22,
	(long) 22,
	"CONF_SYSTEM",
	names1289,
	types1289,
	attr_flags1289,
	gtypes1289,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1289,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_VISITOR",
	names1290,
	types1290,
	attr_flags1290,
	gtypes1290,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1290,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONF_ITERATOR",
	names1291,
	types1291,
	attr_flags1291,
	gtypes1291,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1291,
	NULL
},
{
	(long) 9,
	(long) 9,
	"CONF_PRINT_VISITOR",
	names1292,
	types1292,
	attr_flags1292,
	gtypes1292,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1292,
	NULL
},
{
	(long) 10,
	(long) 10,
	"CONF_GROUPS_TARGET_CHECKER",
	names1293,
	types1293,
	attr_flags1293,
	gtypes1293,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1293,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_CONDITIONED_ITERATOR",
	names1294,
	types1294,
	attr_flags1294,
	gtypes1294,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1294,
	NULL
},
{
	(long) 8,
	(long) 8,
	"CONF_PARSE_VISITOR",
	names1295,
	types1295,
	attr_flags1295,
	gtypes1295,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1295,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LOCALIZED_PRINTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 19,
	(long) 19,
	"ROOT_CLASS",
	names1297,
	types1297,
	attr_flags1297,
	gtypes1297,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1297,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_LOCALE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONF_INTERFACE_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONF_ERROR_CLASSN",
	names1300,
	types1300,
	attr_flags1300,
	gtypes1300,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1300,
	NULL
},
{
	(long) 9,
	(long) 9,
	"CONF_CONDITION",
	names1301,
	types1301,
	attr_flags1301,
	gtypes1301,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1301,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_SCANNER_STATE",
	names1302,
	types1302,
	attr_flags1302,
	gtypes1302,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1302,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_SCANNER_POST_PROPERTY_STATE",
	names1303,
	types1303,
	attr_flags1303,
	gtypes1303,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1303,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_SCANNER_OPEN_SECTION_STATE",
	names1304,
	types1304,
	attr_flags1304,
	gtypes1304,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1304,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_SCANNER_POST_ASSIGNER_STATE",
	names1305,
	types1305,
	attr_flags1305,
	gtypes1305,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1305,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INI_SCANNER_INITIAL_STATE",
	names1306,
	types1306,
	attr_flags1306,
	gtypes1306,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1306,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 11,
	(long) 11,
	"KL_DIRECTORY",
	names1308,
	types1308,
	attr_flags1308,
	gtypes1308,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1308,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_FILE",
	names1309,
	types1309,
	attr_flags1309,
	gtypes1309,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1309,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_OUTPUT_FILE",
	names1310,
	types1310,
	attr_flags1310,
	gtypes1310,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1310,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_BINARY_OUTPUT_FILE",
	names1311,
	types1311,
	attr_flags1311,
	gtypes1311,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1311,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_UNIX_OUTPUT_FILE",
	names1312,
	types1312,
	attr_flags1312,
	gtypes1312,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1312,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_WINDOWS_OUTPUT_FILE",
	names1313,
	types1313,
	attr_flags1313,
	gtypes1313,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1313,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_INPUT_FILE",
	names1314,
	types1314,
	attr_flags1314,
	gtypes1314,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1314,
	NULL
},
{
	(long) 26,
	(long) 25,
	"KL_TEXT_INPUT_FILE",
	names1315,
	types1315,
	attr_flags1315,
	gtypes1315,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1315,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_BINARY_INPUT_FILE",
	names1316,
	types1316,
	attr_flags1316,
	gtypes1316,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1316,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_UNIX_INPUT_FILE",
	names1317,
	types1317,
	attr_flags1317,
	gtypes1317,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1317,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_WINDOWS_INPUT_FILE",
	names1318,
	types1318,
	attr_flags1318,
	gtypes1318,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1318,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_BINARY_INPUT_FILE_32",
	names1319,
	types1319,
	attr_flags1319,
	gtypes1319,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1319,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_LOCATION",
	names1320,
	types1320,
	attr_flags1320,
	gtypes1320,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1320,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_DIRECTORY_LOCATION",
	names1321,
	types1321,
	attr_flags1321,
	gtypes1321,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1321,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONF_FILE_LOCATION",
	names1322,
	types1322,
	attr_flags1322,
	gtypes1322,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1322,
	NULL
},
{
	(long) 14,
	(long) 14,
	"JSON_PARSER",
	names1323,
	types1323,
	attr_flags1323,
	gtypes1323,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1323,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_FORMAT_STRING_PARSER",
	names1324,
	types1324,
	attr_flags1324,
	gtypes1324,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1324,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GC_INFO",
	names1325,
	types1325,
	attr_flags1325,
	gtypes1325,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1325,
	NULL
},
{
	(long) 4,
	(long) 4,
	"MEM_INFO",
	names1326,
	types1326,
	attr_flags1326,
	gtypes1326,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1326,
	NULL
},
{
	(long) 11,
	(long) 11,
	"RT_DBG_EXECUTION_RECORDER",
	names1327,
	types1327,
	attr_flags1327,
	gtypes1327,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1327,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_UNIX_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 31,
	(long) 31,
	"COMPILER",
	names1333,
	types1333,
	attr_flags1333,
	gtypes1333,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1333,
	NULL
},
{
	(long) 52,
	(long) 52,
	"REGULAR_EXPRESSION",
	names1334,
	types1334,
	attr_flags1334,
	gtypes1334,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1334,
	NULL
},
{
	(long) 9,
	(long) 9,
	"URI",
	names1335,
	types1335,
	attr_flags1335,
	gtypes1335,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1335,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IRI",
	names1336,
	types1336,
	attr_flags1336,
	gtypes1336,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1336,
	NULL
},
{
	(long) 11,
	(long) 11,
	"PATH_URI",
	names1337,
	types1337,
	attr_flags1337,
	gtypes1337,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1337,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME_VALIDITY_CHECKER",
	names1338,
	types1338,
	attr_flags1338,
	gtypes1338,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1338,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME",
	names1339,
	types1339,
	attr_flags1339,
	gtypes1339,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1339,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE_VALIDITY_CHECKER",
	names1340,
	types1340,
	attr_flags1340,
	gtypes1340,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1340,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE",
	names1341,
	types1341,
	attr_flags1341,
	gtypes1341,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1341,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DATE_TIME_VALIDITY_CHECKER",
	names1342,
	types1342,
	attr_flags1342,
	gtypes1342,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1342,
	NULL
},
{
	(long) 16,
	(long) 16,
	"DATE_TIME_PARSER",
	names1343,
	types1343,
	attr_flags1343,
	gtypes1343,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1343,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DATE_TIME",
	names1344,
	types1344,
	attr_flags1344,
	gtypes1344,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1344,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EIFFEL_ENV",
	names1346,
	types1346,
	attr_flags1346,
	gtypes1346,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1346,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EC_EIFFEL_LAYOUT",
	names1347,
	types1347,
	attr_flags1347,
	gtypes1347,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1347,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CAT_EIFFEL_ENV",
	names1348,
	types1348,
	attr_flags1348,
	gtypes1348,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1348,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PATHNAME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"KL_PATHNAME",
	names1350,
	types1350,
	attr_flags1350,
	gtypes1350,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1350,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_STRING",
	names1351,
	types1351,
	attr_flags1351,
	gtypes1351,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1351,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_UTF8_STRING",
	names1352,
	types1352,
	attr_flags1352,
	gtypes1352,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1352,
	NULL
},};


#ifdef __cplusplus
}
#endif
