
#ifndef _C7_i1324_
#define _C7_i1324_

#ifdef __cplusplus
extern "C" {
#endif

extern void F372_4104(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit324(void);
extern EIF_REFERENCE F1078_8224(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
