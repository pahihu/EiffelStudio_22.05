
#ifndef _C7_co328_
#define _C7_co328_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F376_4116_body(EIF_REFERENCE);
extern EIF_REFERENCE F376_4116(EIF_REFERENCE);
extern void EIF_Minit328(void);

#ifdef __cplusplus
}
#endif

#endif
