
#ifndef _C7_i1327_
#define _C7_i1327_

#ifdef __cplusplus
extern "C" {
#endif

extern void F375_4113(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit327(void);
extern EIF_REFERENCE F1324_12365(EIF_REFERENCE, EIF_REFERENCE);
extern void F1324_12364(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
