
#ifndef _C7_vo311_
#define _C7_vo311_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F359_4081(EIF_REFERENCE);
extern void EIF_Minit311(void);

#ifdef __cplusplus
}
#endif

#endif
