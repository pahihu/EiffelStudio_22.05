
#ifndef _C7_po321_
#define _C7_po321_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F369_4099(EIF_REFERENCE);
extern void EIF_Minit321(void);

#ifdef __cplusplus
}
#endif

#endif
