
#ifndef _C7_vo312_
#define _C7_vo312_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F360_4083(EIF_REFERENCE);
extern void EIF_Minit312(void);

#ifdef __cplusplus
}
#endif

#endif
