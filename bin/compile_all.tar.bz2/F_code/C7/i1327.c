/*
 * Code for class I18N_FORMAT_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1327.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_FORMAT_STRING}.make */
void F375_4113 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("make", 374, Current, 1, 2, 4217);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1323, 0x01).id, 1323, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1324_12364(RTCW(loc1), arg2);
	RTHOOK(2);
	tr1 = F1324_12365(RTCW(loc1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit327 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
