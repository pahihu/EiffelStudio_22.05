
#ifndef _C7_lo317_
#define _C7_lo317_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F365_4089(EIF_REFERENCE);
extern void EIF_Minit317(void);

#ifdef __cplusplus
}
#endif

#endif
