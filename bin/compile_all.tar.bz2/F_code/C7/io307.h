
#ifndef _C7_io307_
#define _C7_io307_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F355_4067(EIF_REFERENCE);
extern void F355_4070(EIF_REFERENCE, EIF_INTEGER_32);
extern void F355_4071(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit307(void);

#ifdef __cplusplus
}
#endif

#endif
