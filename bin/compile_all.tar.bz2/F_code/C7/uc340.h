
#ifndef _C7_uc340_
#define _C7_uc340_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F389_4430_body(EIF_REFERENCE);
extern EIF_REFERENCE F389_4430(EIF_REFERENCE);
extern void EIF_Minit340(void);

#ifdef __cplusplus
}
#endif

#endif
