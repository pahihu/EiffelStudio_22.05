
#ifndef _C7_ex303_
#define _C7_ex303_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F351_4061(EIF_REFERENCE);
extern void EIF_Minit303(void);

#ifdef __cplusplus
}
#endif

#endif
