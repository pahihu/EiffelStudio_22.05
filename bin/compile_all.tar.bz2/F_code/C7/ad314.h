
#ifndef _C7_ad314_
#define _C7_ad314_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F362_4085(EIF_REFERENCE);
extern void EIF_Minit314(void);

#ifdef __cplusplus
}
#endif

#endif
