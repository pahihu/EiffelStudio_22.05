
#ifndef _C7_re343_
#define _C7_re343_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F392_4524(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit343(void);

#ifdef __cplusplus
}
#endif

#endif
