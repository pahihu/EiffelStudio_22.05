
#ifndef _C7_ro310_
#define _C7_ro310_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F358_4077(EIF_REFERENCE);
extern void F358_4079(EIF_REFERENCE, EIF_REFERENCE);
extern void F358_4080(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit310(void);

#ifdef __cplusplus
}
#endif

#endif
