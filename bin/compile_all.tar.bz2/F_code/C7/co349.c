/*
 * Code for class CONF_PARSE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co349.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_PARSE_FACTORY}.new_redirection_with_file_name */
EIF_REFERENCE F398_4733 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_redirection_with_file_name", 397, Current, 0, 3, 4830);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1287, 0x01).id, 1287, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1288_11294(RTCW(tr1), arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_system_generate_uuid_with_file_name */
EIF_REFERENCE F398_4734 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("new_system_generate_uuid_with_file_name", 397, Current, 0, 3, 4831);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1288, 0x01).id, 1288, _OBJSIZ_16_4_0_2_0_0_0_0_);
	tr1 = F66_977(RTCV(RTOUCR(67,F398_4761, (Current))));
	F1289_11303(RTCW(Result), arg1, arg2, tr1, arg3);
	RTHOOK(2);
	F1289_11338(RTCW(Result), (EIF_BOOLEAN) 1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_system_with_file_name */
EIF_REFERENCE F398_4735 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,Current);
	RTLIU(6);
	
	RTEAA("new_system_with_file_name", 397, Current, 0, 4, 4832);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1288, 0x01).id, 1288, _OBJSIZ_16_4_0_2_0_0_0_0_);
	F1289_11303(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_target */
EIF_REFERENCE F398_4736 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_target", 397, Current, 0, 2, 4833);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1100, 0x01).id, 1100, _OBJSIZ_29_1_0_0_0_0_0_0_);
	F1101_8959(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_location_from_path */
EIF_REFERENCE F398_4737 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_location_from_path", 397, Current, 0, 2, 4834);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1320, 0x01).id, 1320, _OBJSIZ_3_0_0_0_0_0_0_0_);
	F1321_12306(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_location_from_full_path */
EIF_REFERENCE F398_4739 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_location_from_full_path", 397, Current, 0, 2, 4836);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1321, 0x01).id, 1321, _OBJSIZ_3_0_0_0_0_0_0_0_);
	F1322_12309(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_root */
EIF_REFERENCE F398_4740 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_BOOLEAN arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_root", 397, Current, 0, 4, 4837);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(66, 0x01).id, 66, _OBJSIZ_3_1_0_0_0_0_0_0_);
	F67_982(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_version */
EIF_REFERENCE F398_4741 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1, EIF_NATURAL_16 arg2, EIF_NATURAL_16 arg3, EIF_NATURAL_16 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("new_version", 397, Current, 0, 4, 4838);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1265, 0x01).id, 1265, _OBJSIZ_4_5_4_0_0_0_0_0_);
	F1266_10775(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_option */
EIF_REFERENCE F398_4742 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_option", 397, Current, 0, 1, 4839);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(969, 0x01).id, 969, _OBJSIZ_12_18_0_0_0_0_0_0_);
	Result = F970_7308(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_target_option */
EIF_REFERENCE F398_4743 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_target_option", 397, Current, 0, 1, 4840);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(970, 0x01).id, 970, _OBJSIZ_18_18_0_0_0_0_0_0_);
	Result = F970_7308(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_file_rule */
EIF_REFERENCE F398_4744 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("new_file_rule", 397, Current, 0, 0, 4841);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(405, 0x01).id, 405, _OBJSIZ_7_0_0_0_0_0_0_0_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_external_include */
EIF_REFERENCE F398_4745 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_include", 397, Current, 0, 2, 4842);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(410, 0x01).id, 410, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1078_8224(RTCW(arg1));
	F408_4923(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_cflag */
EIF_REFERENCE F398_4746 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_cflag", 397, Current, 0, 2, 4843);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(408, 0x01).id, 408, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1078_8224(RTCW(arg1));
	F408_4923(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_object */
EIF_REFERENCE F398_4747 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_object", 397, Current, 0, 2, 4844);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(414, 0x01).id, 414, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1078_8224(RTCW(arg1));
	F408_4923(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_library */
EIF_REFERENCE F398_4748 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_library", 397, Current, 0, 2, 4845);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(411, 0x01).id, 411, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1078_8224(RTCW(arg1));
	F408_4923(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_resource */
EIF_REFERENCE F398_4749 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_resource", 397, Current, 0, 2, 4846);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(409, 0x01).id, 409, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1078_8224(RTCW(arg1));
	F408_4923(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_linker_flag */
EIF_REFERENCE F398_4750 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_linker_flag", 397, Current, 0, 2, 4847);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(412, 0x01).id, 412, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1078_8224(RTCW(arg1));
	F408_4923(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_make */
EIF_REFERENCE F398_4751 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_external_make", 397, Current, 0, 2, 4848);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(413, 0x01).id, 413, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1078_8224(RTCW(arg1));
	F408_4923(RTCW(Result), tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_action */
EIF_REFERENCE F398_4752 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_action", 397, Current, 0, 3, 4849);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(406, 0x01).id, 406, _OBJSIZ_4_1_0_0_0_0_0_0_);
	tr1 = F1078_8224(RTCW(arg1));
	F407_4914(RTCW(Result), tr1, arg2, arg3);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_assertions */
EIF_REFERENCE F398_4753 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("new_assertions", 397, Current, 0, 0, 4850);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(67, 0x01).id, 67, _OBJSIZ_0_0_0_1_0_0_0_0_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_assembly */
EIF_REFERENCE F398_4754 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTEAA("new_assembly", 397, Current, 1, 3, 4851);
	RTGC;
	RTHOOK(1);
	tr1 = F1078_8224(RTCW(arg2));
	loc1 = F398_4739(Current, tr1, arg3);
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(1159, 0x01).id, 1159, _OBJSIZ_23_4_0_1_0_0_0_0_);
	F1153_9254(RTCW(tr1), arg1, loc1, arg3);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_assembly_from_gac */
EIF_REFERENCE F398_4755 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,arg5);
	RTLR(6,arg6);
	RTLR(7,Current);
	RTLIU(8);
	
	RTEAA("new_assembly_from_gac", 397, Current, 0, 6, 4852);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1159, 0x01).id, 1159, _OBJSIZ_23_4_0_1_0_0_0_0_);
	F1160_9392(RTCW(tr1), arg1, arg2, arg3, arg4, arg5, arg6);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_library */
EIF_REFERENCE F398_4756 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("new_library", 397, Current, 0, 3, 4853);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1160, 0x01).id, 1160, _OBJSIZ_21_4_0_1_0_0_0_0_);
	tr1 = F1078_8224(RTCW(arg2));
	tr1 = F398_4739(Current, tr1, arg3);
	F1161_9420(RTCW(Result), arg1, tr1, arg3);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_precompile */
EIF_REFERENCE F398_4757 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("new_precompile", 397, Current, 0, 3, 4825);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1161, 0x01).id, 1161, _OBJSIZ_22_4_0_1_0_0_0_0_);
	tr1 = F1078_8224(RTCW(arg2));
	tr1 = F398_4739(Current, tr1, arg3);
	F1162_9438(RTCW(Result), arg1, tr1, arg3);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_cluster */
EIF_REFERENCE F398_4758 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_cluster", 397, Current, 0, 3, 4826);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1155, 0x01).id, 1155, _OBJSIZ_27_5_0_1_0_0_0_0_);
	F1156_9332(RTCW(tr1), arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_test_cluster */
EIF_REFERENCE F398_4759 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_test_cluster", 397, Current, 0, 3, 4827);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1156, 0x01).id, 1156, _OBJSIZ_27_5_0_1_0_0_0_0_);
	F1156_9332(RTCW(tr1), arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_override */
EIF_REFERENCE F398_4760 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_override", 397, Current, 0, 3, 4828);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1157, 0x01).id, 1157, _OBJSIZ_29_5_0_1_0_0_0_0_);
	F1156_9332(RTCW(tr1), arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.uuid_generator */
static EIF_REFERENCE F398_4761_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(67)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("uuid_generator", 397, Current, 0, 0, 4829);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(65, 0x01).id, 65, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F398_4761 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(67,F398_4761_body,(Current));
}

void EIF_Minit349 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
