
#ifndef _C7_in320_
#define _C7_in320_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F368_4095(EIF_REFERENCE);
extern void F368_4096(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit320(void);

#ifdef __cplusplus
}
#endif

#endif
