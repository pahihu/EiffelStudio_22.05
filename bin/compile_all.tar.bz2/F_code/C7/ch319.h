
#ifndef _C7_ch319_
#define _C7_ch319_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F367_4093(EIF_REFERENCE);
extern void EIF_Minit319(void);

#ifdef __cplusplus
}
#endif

#endif
