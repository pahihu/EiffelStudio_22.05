
#ifndef _C7_i1325_
#define _C7_i1325_

#ifdef __cplusplus
extern "C" {
#endif

extern void F373_4107(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit325(void);

#ifdef __cplusplus
}
#endif

#endif
