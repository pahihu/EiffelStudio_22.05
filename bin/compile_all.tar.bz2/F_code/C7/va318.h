
#ifndef _C7_va318_
#define _C7_va318_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F366_4091(EIF_REFERENCE);
extern void EIF_Minit318(void);

#ifdef __cplusplus
}
#endif

#endif
