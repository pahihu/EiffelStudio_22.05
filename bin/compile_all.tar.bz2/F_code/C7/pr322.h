
#ifndef _C7_pr322_
#define _C7_pr322_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F370_4101(EIF_REFERENCE);
extern void EIF_Minit322(void);

#ifdef __cplusplus
}
#endif

#endif
