
#ifndef _C7_se305_
#define _C7_se305_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F353_4063(EIF_REFERENCE);
extern void EIF_Minit305(void);

#ifdef __cplusplus
}
#endif

#endif
