
#ifndef _C7_no302_
#define _C7_no302_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F350_4057(EIF_REFERENCE);
extern void F350_4059(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit302(void);

#ifdef __cplusplus
}
#endif

#endif
