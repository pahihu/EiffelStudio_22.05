
#ifndef _C7_i1326_
#define _C7_i1326_

#ifdef __cplusplus
extern "C" {
#endif

extern void F374_4110(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit326(void);

#ifdef __cplusplus
}
#endif

#endif
