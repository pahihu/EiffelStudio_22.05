
#ifndef _C7_cr315_
#define _C7_cr315_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F363_4087(EIF_REFERENCE);
extern void EIF_Minit315(void);

#ifdef __cplusplus
}
#endif

#endif
