
#ifndef _C2_op96_
#define _C2_op96_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F132_1325(EIF_REFERENCE);
extern void F132_1328(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit96(void);

#ifdef __cplusplus
}
#endif

#endif
