
#ifndef _C2_in60_
#define _C2_in60_

#ifdef __cplusplus
extern "C" {
#endif

extern void F94_950(EIF_REFERENCE);
extern EIF_BOOLEAN F94_951(EIF_REFERENCE, EIF_NATURAL_64, EIF_NATURAL_64, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit60(void);
extern void F609_2956(EIF_REFERENCE, EIF_NATURAL_64);

#ifdef __cplusplus
}
#endif

#endif
