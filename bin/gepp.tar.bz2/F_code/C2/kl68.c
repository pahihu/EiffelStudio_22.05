/*
 * Code for class KL_SHARED_STREAMS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl68.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_STREAMS}.null_input_stream */
static EIF_REFERENCE F102_1069_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1069);
#define Result RTOSR(1069)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(748, 0x01).id, 748, _OBJSIZ_2_2_0_1_0_0_0_0_);
	tr2 = RTMS_EX_H("",0,0);
	F749_3661(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1069);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F102_1069 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1069,F102_1069_body,(Current));
}

void EIF_Minit68 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
