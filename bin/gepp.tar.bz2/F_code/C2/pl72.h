
#ifndef _C2_pl72_
#define _C2_pl72_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F106_1086(EIF_REFERENCE);
extern void EIF_Minit72(void);

#ifdef __cplusplus
}
#endif

#endif
