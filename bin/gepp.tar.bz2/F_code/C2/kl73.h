
#ifndef _C2_kl73_
#define _C2_kl73_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_INTEGER_32,1147)
static EIF_INTEGER_32 F107_1147_body(EIF_REFERENCE);
extern EIF_INTEGER_32 F107_1147(EIF_REFERENCE);
extern void EIF_Minit73(void);

#ifdef __cplusplus
}
#endif

#endif
