/*
 * Code for class YY_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy79.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_BUFFER}.make */
void F115_1167 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = F115_1190(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
	F64_737(RTCW(loc1), arg1, ((EIF_INTEGER_32) 1L));
	F199_1979(RTCW(loc1), (EIF_CHARACTER_8) '\000', (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
	F199_1979(RTCW(loc1), (EIF_CHARACTER_8) '\000', (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
	F115_1168(Current, loc1);
	RTLE;
}

/* {YY_BUFFER}.make_from_buffer */
void F115_1168 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = F199_1977(RTCW(arg1));
	*(EIF_INTEGER_32 *)(Current + O1115[dtype-114]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L));
	*(EIF_INTEGER_32 *)(Current + O1114[dtype-114]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O1115[dtype-114]);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	*(EIF_INTEGER_32 *)(Current + O1119[dtype-114]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O1117[dtype-114]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O1118[dtype-114]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O1116[dtype-114]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_BOOLEAN *)(Current + O1120[dtype-114]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {YY_BUFFER}.set_position */
void F115_1179 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O1116[dtype-114]) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current + O1117[dtype-114]) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current + O1118[dtype-114]) = (EIF_INTEGER_32) arg3;
	RTLE;
}

/* {YY_BUFFER}.set_index */
void F115_1180 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O1119[Dtype(Current)-114]) = (EIF_INTEGER_32) arg1;
}

/* {YY_BUFFER}.set_beginning_of_line */
void F115_1181 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O1120[Dtype(Current)-114]) = (EIF_BOOLEAN) arg1;
}

/* {YY_BUFFER}.fill */
void F115_1185 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O1125[Dtype(Current)-114]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {YY_BUFFER}.flush */
void F115_1186 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F199_1979(RTCW(tr1), (EIF_CHARACTER_8) '\000', ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current);
	F199_1979(RTCW(tr1), (EIF_CHARACTER_8) '\000', ((EIF_INTEGER_32) 2L));
	*(EIF_INTEGER_32 *)(Current + O1114[dtype-114]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current + O1119[dtype-114]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O1117[dtype-114]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O1118[dtype-114]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O1116[dtype-114]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_BOOLEAN *)(Current + O1120[dtype-114]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O1125[dtype-114]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {YY_BUFFER}.compact_left */
void F115_1188 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O1114[dtype-114]);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O1119[dtype-114]);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) + ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current + O1115[dtype-114]))) {
		F115_1191(Current);
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O1119[dtype-114]) != ((EIF_INTEGER_32) 1L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		F199_1985(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O1119[dtype-114]), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
		*(EIF_INTEGER_32 *)(Current + O1119[dtype-114]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		*(EIF_INTEGER_32 *)(Current + O1114[dtype-114]) = (EIF_INTEGER_32) loc1;
	}
	RTLE;
}

/* {YY_BUFFER}.new_default_buffer */
EIF_REFERENCE F115_1190 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(198, 0x01).id, 198, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F199_1972(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {YY_BUFFER}.resize */
void F115_1191 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O1115[dtype-114]) == ((EIF_INTEGER_32) 0L))) {
		ti4_1 = RTOSCF(1192,F115_1192, (Current));
		*(EIF_INTEGER_32 *)(Current + O1115[dtype-114]) = (EIF_INTEGER_32) ti4_1;
	} else {
		(*(EIF_INTEGER_32 *)(Current + O1115[dtype-114])) *= ((EIF_INTEGER_32) 2L);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = F199_1977(RTCW(tr1));
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O1115[dtype-114]) + ((EIF_INTEGER_32) 2L)) > ti4_1)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		F199_1987(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O1115[dtype-114]) + ((EIF_INTEGER_32) 2L)));
	}
	RTLE;
}

/* {YY_BUFFER}.default_capacity */
static EIF_INTEGER_32 F115_1192_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (1192);
#define Result RTOSR(1192)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16384L);
	RTOSE (1192);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F115_1192 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1192,F115_1192_body,(Current));
}

void EIF_Minit79 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
