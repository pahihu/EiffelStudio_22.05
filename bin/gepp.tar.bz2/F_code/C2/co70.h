
#ifndef _C2_co70_
#define _C2_co70_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F104_1076(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F104_1077(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F104_1078(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F104_1081(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F104_1082(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit70(void);
extern char *(*R1036[])();

#ifdef __cplusplus
}
#endif

#endif
