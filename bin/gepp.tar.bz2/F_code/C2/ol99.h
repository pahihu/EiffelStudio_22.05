
#ifndef _C2_ol99_
#define _C2_ol99_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F135_1333(EIF_REFERENCE);
extern void EIF_Minit99(void);

#ifdef __cplusplus
}
#endif

#endif
