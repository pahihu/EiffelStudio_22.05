
#ifndef _C2_op97_
#define _C2_op97_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F133_1329(EIF_REFERENCE);
extern void F133_1332(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit97(void);

#ifdef __cplusplus
}
#endif

#endif
