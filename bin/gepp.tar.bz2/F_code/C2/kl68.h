
#ifndef _C2_kl68_
#define _C2_kl68_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1069)
static EIF_REFERENCE F102_1069_body(EIF_REFERENCE);
extern EIF_REFERENCE F102_1069(EIF_REFERENCE);
extern void EIF_Minit68(void);
extern void F749_3661(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
