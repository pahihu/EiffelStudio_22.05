
#ifndef _C2_de89_
#define _C2_de89_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F125_1301(EIF_REFERENCE);
extern void EIF_Minit89(void);

#ifdef __cplusplus
}
#endif

#endif
