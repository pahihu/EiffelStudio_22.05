
#ifndef _C2_nu59_
#define _C2_nu59_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F93_928(EIF_REFERENCE);
extern void EIF_Minit59(void);

#ifdef __cplusplus
}
#endif

#endif
