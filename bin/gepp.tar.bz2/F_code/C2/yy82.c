/*
 * Code for class YY_FILE_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy82.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_FILE_BUFFER}.make */
void F118_1203 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = RTOSCF(1192,F115_1192, (Current));
	F118_1204(Current, arg1, ti4_1);
	RTLE;
}

/* {YY_FILE_BUFFER}.make_with_size */
void F118_1204 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) = (EIF_INTEGER_32) arg2;
	tr1 = F115_1190(Current, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 2L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	F118_1209(Current, arg1);
	RTLE;
}

/* {YY_FILE_BUFFER}.make_from_string */
void F118_1205 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = RTOSCF(1069,F102_1069, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F115_1167(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {YY_FILE_BUFFER}.set_file */
void F118_1209 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F118_1210(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_));
}

/* {YY_FILE_BUFFER}.set_file_with_size */
void F118_1210 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R877[Dtype(RTCW(arg1))-747])(arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) tb1;
	F115_1186(Current);
	if ((EIF_BOOLEAN) (arg2 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) = (EIF_INTEGER_32) arg2;
		tr1 = *(EIF_REFERENCE *)(Current);
		F199_1987(RTCW(tr1), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 2L)));
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {YY_FILE_BUFFER}.fill */
void F118_1213 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_))) {
		F115_1188(Current);
		loc3 = *(EIF_REFERENCE *)(Current);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R871[Dtype(RTCW(tr1))-747])(tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R877[Dtype(RTCW(tr1))-747])(tr1);
			if ((EIF_BOOLEAN) !tb1) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_))++;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R880[Dtype(RTCW(tr1))-747])(tr1));
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
				F199_1979(RTCW(loc3), tc1, ti4_1);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		} else {
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
			loc2 = F199_1984(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
			if ((EIF_BOOLEAN) (loc2 < loc1)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R877[Dtype(RTCW(tr1))-747])(tr1);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) tb1;
			}
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_)) += loc2;
		}
		F199_1979(RTCW(loc3), (EIF_CHARACTER_8) '\000', (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) + ((EIF_INTEGER_32) 1L)));
		F199_1979(RTCW(loc3), (EIF_CHARACTER_8) '\000', (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) + ((EIF_INTEGER_32) 2L)));
	} else {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

void EIF_Minit82 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
