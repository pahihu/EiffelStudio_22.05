
#ifndef _C2_kl87_
#define _C2_kl87_

#ifdef __cplusplus
extern "C" {
#endif

extern void F123_1268(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit87(void);

#ifdef __cplusplus
}
#endif

#endif
