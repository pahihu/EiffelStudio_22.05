
#ifndef _C2_st61_
#define _C2_st61_

#ifdef __cplusplus
extern "C" {
#endif

extern void F95_967(EIF_REFERENCE, EIF_BOOLEAN);
extern void F95_968(EIF_REFERENCE, EIF_BOOLEAN);
extern void F95_969(EIF_REFERENCE, EIF_REFERENCE);
extern void F95_970(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit61(void);
extern void F871_5319(EIF_REFERENCE, EIF_REFERENCE);
extern long O953[];
extern long O954[];

#ifdef __cplusplus
}
#endif

#endif
