
#ifndef _C2_kl75_
#define _C2_kl75_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1156)
static EIF_REFERENCE F109_1156_body(EIF_REFERENCE);
extern EIF_REFERENCE F109_1156(EIF_REFERENCE);
extern void EIF_Minit75(void);

#ifdef __cplusplus
}
#endif

#endif
