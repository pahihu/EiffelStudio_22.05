
#ifndef _C2_ex85_
#define _C2_ex85_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1242)
static EIF_REFERENCE F121_1242_body(EIF_REFERENCE);
extern EIF_REFERENCE F121_1242(EIF_REFERENCE);
extern void EIF_Minit85(void);

#ifdef __cplusplus
}
#endif

#endif
