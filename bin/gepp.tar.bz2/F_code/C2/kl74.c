/*
 * Code for class KL_SHARED_ARGUMENTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl74.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_ARGUMENTS}.arguments */
static EIF_REFERENCE F108_1152_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1152);
#define Result RTOSR(1152)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(287, 0x01).id, 287, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F288_2348(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1152);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F108_1152 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1152,F108_1152_body,(Current));
}

void EIF_Minit74 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
