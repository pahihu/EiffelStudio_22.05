
#ifndef _C2_fl93_
#define _C2_fl93_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F129_1304(EIF_REFERENCE);
extern void EIF_Minit93(void);

#ifdef __cplusplus
}
#endif

#endif
