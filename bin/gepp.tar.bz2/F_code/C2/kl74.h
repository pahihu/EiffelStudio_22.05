
#ifndef _C2_kl74_
#define _C2_kl74_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1152)
static EIF_REFERENCE F108_1152_body(EIF_REFERENCE);
extern EIF_REFERENCE F108_1152(EIF_REFERENCE);
extern void EIF_Minit74(void);
extern void F288_2348(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
