/*
 * Code for class KL_PLATFORM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl73.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_PLATFORM}.maximum_character_code */
static EIF_INTEGER_32 F107_1147_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (1147);
#define Result RTOSR(1147)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
	RTOSE (1147);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F107_1147 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1147,F107_1147_body,(Current));
}

void EIF_Minit73 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
