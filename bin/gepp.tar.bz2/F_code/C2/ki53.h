
#ifndef _C2_ki53_
#define _C2_ki53_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F85_864(EIF_REFERENCE);
extern void EIF_Minit53(void);
extern char *(*R856[])();

#ifdef __cplusplus
}
#endif

#endif
