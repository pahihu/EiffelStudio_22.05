
#ifndef _C2_ex86_
#define _C2_ex86_

#ifdef __cplusplus
extern "C" {
#endif

extern void F122_1261(EIF_REFERENCE, EIF_REFERENCE);
extern void F122_1262(EIF_REFERENCE, EIF_REFERENCE);
extern void F122_1263(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit86(void);
extern void F124_1285(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F121_1242(EIF_REFERENCE);
extern void F124_1270(EIF_REFERENCE);
extern EIF_REFERENCE F71_779(EIF_REFERENCE, EIF_INTEGER_32);
RTOSHF(EIF_REFERENCE,1242)

#ifdef __cplusplus
}
#endif

#endif
