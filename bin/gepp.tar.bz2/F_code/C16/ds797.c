/*
 * Code for class DS_SPARSE_TABLE [G#1, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds797.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_TABLE}.make */
void F941_6329 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y4676,Y4676_gen_type,Dftype(Current),940).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	F941_6335(Current, arg1, NULL, *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTLE;
}

/* {DS_SPARSE_TABLE}.make_with_equality_testers */
void F941_6335 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg3;
	F940_6238(Current, arg1);
	RTLE;
}

/* {DS_SPARSE_TABLE}.item */
EIF_REFERENCE F941_6337 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	F940_6271(Current, tr1);
	RTLE;
	return (EIF_REFERENCE) F942_6375(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
}

/* {DS_SPARSE_TABLE}.key_equality_tester */
EIF_REFERENCE F941_6343 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {DS_SPARSE_TABLE}.has */
EIF_BOOLEAN F941_6345 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	F940_6271(Current, tr1);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_TABLE}.is_equal */
EIF_BOOLEAN F941_6349 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(3460,F733_3460, (Current));
		tb2 = F4_52(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_11_0_0_8_);
			tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) == ti4_1);
		}
		if (tb1) {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L)))) break;
				if ((EIF_BOOLEAN) (F942_6378(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
					loc1 = F942_6377(Current, loc2);
					Result = '\0';
					tr1 = RTCCL(loc1);
					tb1 = F941_6345(RTCW(arg1), tr1);
					if (tb1) {
						tr1 = RTCCL(loc1);
						tr1 = F941_6337(RTCW(arg1), tr1);
						Result = RTCEQ(tr1, F942_6375(Current, loc2));
					}
				}
				loc2--;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_TABLE}.force */
void F941_6357 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	F940_6257(Current);
	tr1 = RTCCL(arg2);
	F940_6271(Current, tr1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		tr1 = RTCCL(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_);
		F942_6376(Current, tr1, ti4_1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
			ti4_1 = F940_6327(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) + ((EIF_INTEGER_32) 1L)));
			F940_6262(Current, ti4_1);
			tr1 = RTCCL(arg2);
			loc2 = F943_6412(Current, tr1);
		} else {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_);
		}
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_))++;
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
		} else {
			ti4_1 = F942_6378(Current, loc1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
		}
		ti4_1 = F942_6400(Current, loc2);
		F942_6394(Current, ti4_1, loc1);
		F942_6401(Current, loc1, loc2);
		tr1 = RTCCL(arg1);
		F942_6376(Current, tr1, loc1);
		tr1 = RTCCL(arg2);
		F942_6387(Current, tr1, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.copy */
void F941_6361 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		F940_6258(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.internal_set_key_equality_tester */
void F941_6370 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		(RTNA((loc1, arg1)));
	}
	RTLE;
}

void EIF_Minit797 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
