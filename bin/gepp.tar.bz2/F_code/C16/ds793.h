
#ifndef _C16_ds793_
#define _C16_ds793_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F943_6409(EIF_REFERENCE);
extern EIF_INTEGER_32 F943_6412(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit793(void);
extern void F898_5854(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2942[])();
extern EIF_TYPE_INDEX Y835[];
extern EIF_TYPE_INDEX *Y835_gen_type [];
extern EIF_TYPE_INDEX Y4493[];
extern EIF_TYPE_INDEX *Y4493_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
