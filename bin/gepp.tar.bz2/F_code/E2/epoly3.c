#include "epoly3.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2240[336])();
void R2240_init () {
	R2240[0] = (char *(*)()) F632_3037;
	R2240[1] = (char *(*)()) F633_3037;
	R2240[2] = (char *(*)()) F634_3037;
	R2240[3] = (char *(*)()) F635_3037;
	R2240[4] = (char *(*)()) F636_3037;
	R2240[5] = (char *(*)()) F637_3037;
	R2240[6] = (char *(*)()) F638_3037;
	R2240[7] = (char *(*)()) F639_3037;
	R2240[8] = (char *(*)()) F640_3037;
	R2240[9] = (char *(*)()) F641_3037;
	R2240[10] = (char *(*)()) F642_3037;
	R2240[11] = (char *(*)()) F643_3037;
	R2240[82] = (char *(*)()) F714_3299;
	R2240[83] = (char *(*)()) F715_3299;
	R2240[84] = (char *(*)()) F716_3299;
	R2240[85] = (char *(*)()) F717_3299;
	R2240[86] = (char *(*)()) F718_3299;
	R2240[89] = (char *(*)()) F714_3299;
	R2240[238] = (char *(*)()) F868_5171;
	R2240[241] = (char *(*)()) F871_5339;
	R2240[248] = (char *(*)()) F880_5492;
	R2240[277] = (char *(*)()) F592_2615;
	R2240[282] = (char *(*)()) F592_2615;
	R2240[335] = (char *(*)()) F967_6922;
}

char *(*R2243[336])();
void R2243_init () {
	R2243[0] = (char *(*)()) F632_3038;
	R2243[1] = (char *(*)()) F633_3038;
	R2243[2] = (char *(*)()) F634_3038;
	R2243[3] = (char *(*)()) F635_3038;
	R2243[4] = (char *(*)()) F636_3038;
	R2243[5] = (char *(*)()) F637_3038;
	R2243[6] = (char *(*)()) F638_3038;
	R2243[7] = (char *(*)()) F639_3038;
	R2243[8] = (char *(*)()) F640_3038;
	R2243[9] = (char *(*)()) F641_3038;
	R2243[10] = (char *(*)()) F642_3038;
	R2243[11] = (char *(*)()) F643_3038;
	R2243[238] = (char *(*)()) F868_5170;
	R2243[241] = (char *(*)()) F871_5338;
	R2243[335] = (char *(*)()) F967_6924;
}

char *(*R2247[336])();
void R2247_init () {
	R2247[0] = (char *(*)()) F556_2572;
	R2247[1] = (char *(*)()) F557_2572;
	R2247[2] = (char *(*)()) F558_2572;
	R2247[3] = (char *(*)()) F559_2572;
	R2247[4] = (char *(*)()) F560_2572;
	R2247[5] = (char *(*)()) F561_2572;
	R2247[6] = (char *(*)()) F562_2572;
	R2247[7] = (char *(*)()) F563_2572;
	R2247[8] = (char *(*)()) F564_2572;
	R2247[9] = (char *(*)()) F565_2572;
	R2247[10] = (char *(*)()) F566_2572;
	R2247[11] = (char *(*)()) F567_2572;
	R2247[238] = (char *(*)()) F564_2572;
	R2247[241] = (char *(*)()) F563_2572;
	R2247[335] = (char *(*)()) F563_2572;
}

char *(*R2279[35])();
void R2279_init () {
	R2279[0] = (char *(*)()) F880_5490;
	R2279[29] = (char *(*)()) F592_2619;
	R2279[34] = (char *(*)()) F592_2619;
}

char *(*R2349[35])();
void R2349_init () {
	R2349[0] = (char *(*)()) F880_5546;
	R2349[29] = (char *(*)()) F592_2744;
	R2349[34] = (char *(*)()) F592_2744;
}

char *(*R2450[361])();
void R2450_init () {
	R2450[0] = (char *(*)()) F607_2939;
	R2450[1] = (char *(*)()) F608_2939_2450_19;
	R2450[2] = (char *(*)()) F609_2939_2450_19;
	R2450[3] = (char *(*)()) F610_2939_2450_19;
	R2450[4] = (char *(*)()) F611_2939_2450_19;
	R2450[5] = (char *(*)()) F612_2939_2450_19;
	R2450[6] = (char *(*)()) F613_2939_2450_19;
	R2450[7] = (char *(*)()) F614_2939_2450_19;
	R2450[8] = (char *(*)()) F615_2939_2450_19;
	R2450[9] = (char *(*)()) F616_2939_2450_19;
	R2450[10] = (char *(*)()) F617_2939_2450_19;
	R2450[11] = (char *(*)()) F618_2939_2450_19;
	R2450[25] = (char *(*)()) F632_3030;
	R2450[26] = (char *(*)()) F633_3030_2450_19;
	R2450[27] = (char *(*)()) F634_3030_2450_19;
	R2450[28] = (char *(*)()) F635_3030_2450_19;
	R2450[29] = (char *(*)()) F636_3030_2450_19;
	R2450[30] = (char *(*)()) F637_3030_2450_19;
	R2450[31] = (char *(*)()) F638_3030_2450_19;
	R2450[32] = (char *(*)()) F639_3030_2450_19;
	R2450[33] = (char *(*)()) F640_3030_2450_19;
	R2450[34] = (char *(*)()) F641_3030_2450_19;
	R2450[35] = (char *(*)()) F642_3030_2450_19;
	R2450[36] = (char *(*)()) F643_3030_2450_19;
	R2450[180] = (char *(*)()) F787_3787;
	R2450[262] = (char *(*)()) F869_5209_2450_19;
	R2450[263] = (char *(*)()) F870_5232_2450_19;
	R2450[265] = (char *(*)()) F872_5374_2450_19;
	R2450[266] = (char *(*)()) F873_5396_2450_19;
	R2450[360] = (char *(*)()) F967_6906_2450_19;
}
static EIF_REFERENCE F608_2939_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F608_2939(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F609_2939_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F609_2939(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(798, 0x00).id, 798, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F610_2939_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F610_2939(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(804, 0x00).id, 804, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F611_2939_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F611_2939(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(807, 0x00).id, 807, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F612_2939_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F612_2939(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(822, 0x00).id, 822, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F613_2939_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F613_2939(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(801, 0x00).id, 801, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F614_2939_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F614_2939(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(819, 0x00).id, 819, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F615_2939_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F615_2939(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(816, 0x00).id, 816, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F616_2939_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F616_2939(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(858, 0x00).id, 858, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F617_2939_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F617_2939(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(810, 0x00).id, 810, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F618_2939_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F618_2939(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(813, 0x00).id, 813, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F633_3030_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F633_3030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F634_3030_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F634_3030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(798, 0x00).id, 798, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F635_3030_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F635_3030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(804, 0x00).id, 804, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F636_3030_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F636_3030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(807, 0x00).id, 807, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F637_3030_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F637_3030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(822, 0x00).id, 822, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F638_3030_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F638_3030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(801, 0x00).id, 801, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F639_3030_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F639_3030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(819, 0x00).id, 819, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F640_3030_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F640_3030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(816, 0x00).id, 816, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_3030_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F641_3030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(858, 0x00).id, 858, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F642_3030_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F642_3030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(810, 0x00).id, 810, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F643_3030_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F643_3030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(813, 0x00).id, 813, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F869_5209_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F869_5209(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(816, 0x00).id, 816, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F870_5232_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F870_5232(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(816, 0x00).id, 816, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F872_5374_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F872_5374(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(819, 0x00).id, 819, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F873_5396_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F873_5396(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(819, 0x00).id, 819, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F967_6906_2450_19 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F967_6906(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(819, 0x00).id, 819, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2451[361])();
void R2451_init () {
	R2451[0] = (char *(*)()) F607_2947;
	R2451[1] = (char *(*)()) F608_2947;
	R2451[2] = (char *(*)()) F609_2947;
	R2451[3] = (char *(*)()) F610_2947;
	R2451[4] = (char *(*)()) F611_2947;
	R2451[5] = (char *(*)()) F612_2947;
	R2451[6] = (char *(*)()) F613_2947;
	R2451[7] = (char *(*)()) F614_2947;
	R2451[8] = (char *(*)()) F615_2947;
	R2451[9] = (char *(*)()) F616_2947;
	R2451[10] = (char *(*)()) F617_2947;
	R2451[11] = (char *(*)()) F618_2947;
	R2451[25] = (char *(*)()) F632_3035;
	R2451[26] = (char *(*)()) F633_3035;
	R2451[27] = (char *(*)()) F634_3035;
	R2451[28] = (char *(*)()) F635_3035;
	R2451[29] = (char *(*)()) F636_3035;
	R2451[30] = (char *(*)()) F637_3035;
	R2451[31] = (char *(*)()) F638_3035;
	R2451[32] = (char *(*)()) F639_3035;
	R2451[33] = (char *(*)()) F640_3035;
	R2451[34] = (char *(*)()) F641_3035;
	R2451[35] = (char *(*)()) F642_3035;
	R2451[36] = (char *(*)()) F643_3035;
	R2451[107] = (char *(*)()) F714_3302;
	R2451[108] = (char *(*)()) F715_3302;
	R2451[109] = (char *(*)()) F716_3302;
	R2451[110] = (char *(*)()) F717_3302;
	R2451[111] = (char *(*)()) F718_3302;
	R2451[114] = (char *(*)()) F714_3302;
	R2451[180] = (char *(*)()) F787_3817;
	{long i; for (i = 262; i < 264; i++) R2451[i] = (char *(*)()) F868_5173;}
	{long i; for (i = 265; i < 267; i++) R2451[i] = (char *(*)()) F871_5341;}
	R2451[360] = (char *(*)()) F871_5341;
}

EIF_TYPE_INDEX *Y2451_gen_type [374];
EIF_TYPE_INDEX Y2451 [374];
void Y2451_init (void)
{
	egc_routines_types [2451] = Y2451;
	egc_routines_gen_types [2451] = Y2451_gen_type;
	egc_routines_offset [2451] = 594;
	{long i; for (i = 0; i < 104; i++) Y2451[i] = 789;};
	{long i; for (i = 107; i < 127; i++) Y2451[i] = 789;};
	Y2451[192] = 789;
	{long i; for (i = 273; i < 280; i++) Y2451[i] = 789;};
	{long i; for (i = 372; i < 374; i++) Y2451[i] = 789;};
}

char *(*R2452[361])();
void R2452_init () {
	R2452[0] = (char *(*)()) F607_2948;
	R2452[1] = (char *(*)()) F608_2948;
	R2452[2] = (char *(*)()) F609_2948;
	R2452[3] = (char *(*)()) F610_2948;
	R2452[4] = (char *(*)()) F611_2948;
	R2452[5] = (char *(*)()) F612_2948;
	R2452[6] = (char *(*)()) F613_2948;
	R2452[7] = (char *(*)()) F614_2948;
	R2452[8] = (char *(*)()) F615_2948;
	R2452[9] = (char *(*)()) F616_2948;
	R2452[10] = (char *(*)()) F617_2948;
	R2452[11] = (char *(*)()) F618_2948;
	R2452[25] = (char *(*)()) F632_3036;
	R2452[26] = (char *(*)()) F633_3036;
	R2452[27] = (char *(*)()) F634_3036;
	R2452[28] = (char *(*)()) F635_3036;
	R2452[29] = (char *(*)()) F636_3036;
	R2452[30] = (char *(*)()) F637_3036;
	R2452[31] = (char *(*)()) F638_3036;
	R2452[32] = (char *(*)()) F639_3036;
	R2452[33] = (char *(*)()) F640_3036;
	R2452[34] = (char *(*)()) F641_3036;
	R2452[35] = (char *(*)()) F642_3036;
	R2452[36] = (char *(*)()) F643_3036;
	R2452[107] = (char *(*)()) F714_3303;
	R2452[108] = (char *(*)()) F715_3303;
	R2452[109] = (char *(*)()) F716_3303;
	R2452[110] = (char *(*)()) F717_3303;
	R2452[111] = (char *(*)()) F718_3303;
	R2452[114] = (char *(*)()) F714_3303;
	R2452[180] = (char *(*)()) F787_3816;
	{long i; for (i = 262; i < 264; i++) R2452[i] = (char *(*)()) F868_5171;}
	{long i; for (i = 265; i < 267; i++) R2452[i] = (char *(*)()) F871_5339;}
	R2452[360] = (char *(*)()) F967_6922;
}

char *(*R2455[12])();
void R2455_init () {
	R2455[0] = (char *(*)()) F607_2936;
	R2455[1] = (char *(*)()) F608_2936;
	R2455[2] = (char *(*)()) F609_2936;
	R2455[3] = (char *(*)()) F610_2936;
	R2455[4] = (char *(*)()) F611_2936;
	R2455[5] = (char *(*)()) F612_2936;
	R2455[6] = (char *(*)()) F613_2936;
	R2455[7] = (char *(*)()) F614_2936;
	R2455[8] = (char *(*)()) F615_2936;
	R2455[9] = (char *(*)()) F616_2936;
	R2455[10] = (char *(*)()) F617_2936;
	R2455[11] = (char *(*)()) F618_2936;
}

char *(*R2456[12])();
void R2456_init () {
	R2456[0] = (char *(*)()) F607_2937;
	R2456[1] = (char *(*)()) F608_2937_2456_117;
	R2456[2] = (char *(*)()) F609_2937_2456_117;
	R2456[3] = (char *(*)()) F610_2937_2456_117;
	R2456[4] = (char *(*)()) F611_2937_2456_117;
	R2456[5] = (char *(*)()) F612_2937_2456_117;
	R2456[6] = (char *(*)()) F613_2937_2456_117;
	R2456[7] = (char *(*)()) F614_2937_2456_117;
	R2456[8] = (char *(*)()) F615_2937_2456_117;
	R2456[9] = (char *(*)()) F616_2937_2456_117;
	R2456[10] = (char *(*)()) F617_2937_2456_117;
	R2456[11] = (char *(*)()) F618_2937_2456_117;
}
static void F608_2937_2456_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F608_2937(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F609_2937_2456_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F609_2937(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F610_2937_2456_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F610_2937(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F611_2937_2456_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F611_2937(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F612_2937_2456_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F612_2937(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F613_2937_2456_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F613_2937(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F614_2937_2456_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F614_2937(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F615_2937_2456_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F615_2937(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F616_2937_2456_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F616_2937(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F617_2937_2456_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F617_2937(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F618_2937_2456_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F618_2937(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R2465[12])();
void R2465_init () {
	R2465[0] = (char *(*)()) F607_2952;
	R2465[1] = (char *(*)()) F608_2952;
	R2465[2] = (char *(*)()) F609_2952;
	R2465[3] = (char *(*)()) F610_2952;
	R2465[4] = (char *(*)()) F611_2952;
	R2465[5] = (char *(*)()) F612_2952;
	R2465[6] = (char *(*)()) F613_2952;
	R2465[7] = (char *(*)()) F614_2952;
	R2465[8] = (char *(*)()) F615_2952;
	R2465[9] = (char *(*)()) F616_2952;
	R2465[10] = (char *(*)()) F617_2952;
	R2465[11] = (char *(*)()) F618_2952;
}

char *(*R2466[12])();
void R2466_init () {
	R2466[0] = (char *(*)()) F607_2954;
	R2466[1] = (char *(*)()) F608_2954_2466_117;
	R2466[2] = (char *(*)()) F609_2954_2466_117;
	R2466[3] = (char *(*)()) F610_2954_2466_117;
	R2466[4] = (char *(*)()) F611_2954_2466_117;
	R2466[5] = (char *(*)()) F612_2954_2466_117;
	R2466[6] = (char *(*)()) F613_2954_2466_117;
	R2466[7] = (char *(*)()) F614_2954_2466_117;
	R2466[8] = (char *(*)()) F615_2954_2466_117;
	R2466[9] = (char *(*)()) F616_2954_2466_117;
	R2466[10] = (char *(*)()) F617_2954_2466_117;
	R2466[11] = (char *(*)()) F618_2954_2466_117;
}
static void F608_2954_2466_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F608_2954(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F609_2954_2466_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F609_2954(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F610_2954_2466_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F610_2954(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F611_2954_2466_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F611_2954(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F612_2954_2466_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F612_2954(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F613_2954_2466_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F613_2954(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F614_2954_2466_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F614_2954(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F615_2954_2466_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F615_2954(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F616_2954_2466_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F616_2954(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F617_2954_2466_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F617_2954(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F618_2954_2466_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F618_2954(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R2467[12])();
void R2467_init () {
	R2467[0] = (char *(*)()) F607_2955;
	R2467[1] = (char *(*)()) F608_2955_2467_117;
	R2467[2] = (char *(*)()) F609_2955_2467_117;
	R2467[3] = (char *(*)()) F610_2955_2467_117;
	R2467[4] = (char *(*)()) F611_2955_2467_117;
	R2467[5] = (char *(*)()) F612_2955_2467_117;
	R2467[6] = (char *(*)()) F613_2955_2467_117;
	R2467[7] = (char *(*)()) F614_2955_2467_117;
	R2467[8] = (char *(*)()) F615_2955_2467_117;
	R2467[9] = (char *(*)()) F616_2955_2467_117;
	R2467[10] = (char *(*)()) F617_2955_2467_117;
	R2467[11] = (char *(*)()) F618_2955_2467_117;
}
static void F608_2955_2467_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F608_2955(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F609_2955_2467_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F609_2955(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F610_2955_2467_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F610_2955(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F611_2955_2467_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F611_2955(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F612_2955_2467_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F612_2955(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F613_2955_2467_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F613_2955(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F614_2955_2467_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F614_2955(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F615_2955_2467_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F615_2955(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F616_2955_2467_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F616_2955(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F617_2955_2467_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F617_2955(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F618_2955_2467_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F618_2955(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R2468[12])();
void R2468_init () {
	R2468[0] = (char *(*)()) F607_2956;
	R2468[1] = (char *(*)()) F608_2956_2468_4;
	R2468[2] = (char *(*)()) F609_2956_2468_4;
	R2468[3] = (char *(*)()) F610_2956_2468_4;
	R2468[4] = (char *(*)()) F611_2956_2468_4;
	R2468[5] = (char *(*)()) F612_2956_2468_4;
	R2468[6] = (char *(*)()) F613_2956_2468_4;
	R2468[7] = (char *(*)()) F614_2956_2468_4;
	R2468[8] = (char *(*)()) F615_2956_2468_4;
	R2468[9] = (char *(*)()) F616_2956_2468_4;
	R2468[10] = (char *(*)()) F617_2956_2468_4;
	R2468[11] = (char *(*)()) F618_2956_2468_4;
}
static void F608_2956_2468_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F608_2956(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F609_2956_2468_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F609_2956(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F610_2956_2468_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F610_2956(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F611_2956_2468_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F611_2956(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F612_2956_2468_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F612_2956(Current, *(EIF_BOOLEAN *)arg1);
}
static void F613_2956_2468_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F613_2956(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F614_2956_2468_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F614_2956(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F615_2956_2468_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F615_2956(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F616_2956_2468_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F616_2956(Current, *(EIF_POINTER *)arg1);
}
static void F617_2956_2468_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F617_2956(Current, *(EIF_REAL_32 *)arg1);
}
static void F618_2956_2468_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F618_2956(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R2470[12])();
void R2470_init () {
	R2470[0] = (char *(*)()) F607_2958;
	R2470[1] = (char *(*)()) F608_2958_2470_29;
	R2470[2] = (char *(*)()) F609_2958_2470_29;
	R2470[3] = (char *(*)()) F610_2958_2470_29;
	R2470[4] = (char *(*)()) F611_2958_2470_29;
	R2470[5] = (char *(*)()) F612_2958_2470_29;
	R2470[6] = (char *(*)()) F613_2958_2470_29;
	R2470[7] = (char *(*)()) F614_2958_2470_29;
	R2470[8] = (char *(*)()) F615_2958_2470_29;
	R2470[9] = (char *(*)()) F616_2958_2470_29;
	R2470[10] = (char *(*)()) F617_2958_2470_29;
	R2470[11] = (char *(*)()) F618_2958_2470_29;
}
static void F608_2958_2470_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F608_2958(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F609_2958_2470_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F609_2958(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F610_2958_2470_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F610_2958(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F611_2958_2470_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F611_2958(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F612_2958_2470_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F612_2958(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F613_2958_2470_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F613_2958(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F614_2958_2470_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F614_2958(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F615_2958_2470_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F615_2958(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F616_2958_2470_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F616_2958(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F617_2958_2470_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F617_2958(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F618_2958_2470_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F618_2958(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R2473[12])();
void R2473_init () {
	R2473[0] = (char *(*)()) F607_2961;
	R2473[1] = (char *(*)()) F608_2961;
	R2473[2] = (char *(*)()) F609_2961;
	R2473[3] = (char *(*)()) F610_2961;
	R2473[4] = (char *(*)()) F611_2961;
	R2473[5] = (char *(*)()) F612_2961;
	R2473[6] = (char *(*)()) F613_2961;
	R2473[7] = (char *(*)()) F614_2961;
	R2473[8] = (char *(*)()) F615_2961;
	R2473[9] = (char *(*)()) F616_2961;
	R2473[10] = (char *(*)()) F617_2961;
	R2473[11] = (char *(*)()) F618_2961;
}

char *(*R2474[12])();
void R2474_init () {
	R2474[0] = (char *(*)()) F607_2962;
	R2474[1] = (char *(*)()) F608_2962;
	R2474[2] = (char *(*)()) F609_2962;
	R2474[3] = (char *(*)()) F610_2962;
	R2474[4] = (char *(*)()) F611_2962;
	R2474[5] = (char *(*)()) F612_2962;
	R2474[6] = (char *(*)()) F613_2962;
	R2474[7] = (char *(*)()) F614_2962;
	R2474[8] = (char *(*)()) F615_2962;
	R2474[9] = (char *(*)()) F616_2962;
	R2474[10] = (char *(*)()) F617_2962;
	R2474[11] = (char *(*)()) F618_2962;
}

char *(*R2475[12])();
void R2475_init () {
	R2475[0] = (char *(*)()) F607_2963;
	R2475[1] = (char *(*)()) F608_2963;
	R2475[2] = (char *(*)()) F609_2963;
	R2475[3] = (char *(*)()) F610_2963;
	R2475[4] = (char *(*)()) F611_2963;
	R2475[5] = (char *(*)()) F612_2963;
	R2475[6] = (char *(*)()) F613_2963;
	R2475[7] = (char *(*)()) F614_2963;
	R2475[8] = (char *(*)()) F615_2963;
	R2475[9] = (char *(*)()) F616_2963;
	R2475[10] = (char *(*)()) F617_2963;
	R2475[11] = (char *(*)()) F618_2963;
}

char *(*R2476[12])();
void R2476_init () {
	R2476[0] = (char *(*)()) F607_2964;
	R2476[1] = (char *(*)()) F608_2964;
	R2476[2] = (char *(*)()) F609_2964;
	R2476[3] = (char *(*)()) F610_2964;
	R2476[4] = (char *(*)()) F611_2964;
	R2476[5] = (char *(*)()) F612_2964;
	R2476[6] = (char *(*)()) F613_2964;
	R2476[7] = (char *(*)()) F614_2964;
	R2476[8] = (char *(*)()) F615_2964;
	R2476[9] = (char *(*)()) F616_2964;
	R2476[10] = (char *(*)()) F617_2964;
	R2476[11] = (char *(*)()) F618_2964;
}

char *(*R2477[12])();
void R2477_init () {
	R2477[0] = (char *(*)()) F607_2965;
	R2477[1] = (char *(*)()) F608_2965;
	R2477[2] = (char *(*)()) F609_2965;
	R2477[3] = (char *(*)()) F610_2965;
	R2477[4] = (char *(*)()) F611_2965;
	R2477[5] = (char *(*)()) F612_2965;
	R2477[6] = (char *(*)()) F613_2965;
	R2477[7] = (char *(*)()) F614_2965;
	R2477[8] = (char *(*)()) F615_2965;
	R2477[9] = (char *(*)()) F616_2965;
	R2477[10] = (char *(*)()) F617_2965;
	R2477[11] = (char *(*)()) F618_2965;
}

char *(*R2481[12])();
void R2481_init () {
	R2481[0] = (char *(*)()) F607_2969;
	R2481[1] = (char *(*)()) F608_2969;
	R2481[2] = (char *(*)()) F609_2969;
	R2481[3] = (char *(*)()) F610_2969;
	R2481[4] = (char *(*)()) F611_2969;
	R2481[5] = (char *(*)()) F612_2969;
	R2481[6] = (char *(*)()) F613_2969;
	R2481[7] = (char *(*)()) F614_2969;
	R2481[8] = (char *(*)()) F615_2969;
	R2481[9] = (char *(*)()) F616_2969;
	R2481[10] = (char *(*)()) F617_2969;
	R2481[11] = (char *(*)()) F618_2969;
}

char *(*R2483[12])();
void R2483_init () {
	R2483[0] = (char *(*)()) F607_2971;
	R2483[1] = (char *(*)()) F608_2971;
	R2483[2] = (char *(*)()) F609_2971;
	R2483[3] = (char *(*)()) F610_2971;
	R2483[4] = (char *(*)()) F611_2971;
	R2483[5] = (char *(*)()) F612_2971;
	R2483[6] = (char *(*)()) F613_2971;
	R2483[7] = (char *(*)()) F614_2971;
	R2483[8] = (char *(*)()) F615_2971;
	R2483[9] = (char *(*)()) F616_2971;
	R2483[10] = (char *(*)()) F617_2971;
	R2483[11] = (char *(*)()) F618_2971;
}

char *(*R2484[12])();
void R2484_init () {
	R2484[0] = (char *(*)()) F607_2972;
	R2484[1] = (char *(*)()) F608_2972_2484_21;
	R2484[2] = (char *(*)()) F609_2972_2484_21;
	R2484[3] = (char *(*)()) F610_2972_2484_21;
	R2484[4] = (char *(*)()) F611_2972_2484_21;
	R2484[5] = (char *(*)()) F612_2972_2484_21;
	R2484[6] = (char *(*)()) F613_2972_2484_21;
	R2484[7] = (char *(*)()) F614_2972_2484_21;
	R2484[8] = (char *(*)()) F615_2972_2484_21;
	R2484[9] = (char *(*)()) F616_2972_2484_21;
	R2484[10] = (char *(*)()) F617_2972_2484_21;
	R2484[11] = (char *(*)()) F618_2972_2484_21;
}
static EIF_REFERENCE F608_2972_2484_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F608_2972(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F609_2972_2484_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F609_2972(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F610_2972_2484_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F610_2972(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F611_2972_2484_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F611_2972(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F612_2972_2484_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F612_2972(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F613_2972_2484_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F613_2972(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F614_2972_2484_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F614_2972(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F615_2972_2484_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F615_2972(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F616_2972_2484_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F616_2972(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F617_2972_2484_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F617_2972(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F618_2972_2484_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F618_2972(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R2486[12])();
void R2486_init () {
	R2486[0] = (char *(*)()) F607_2974;
	R2486[1] = (char *(*)()) F608_2974;
	R2486[2] = (char *(*)()) F609_2974;
	R2486[3] = (char *(*)()) F610_2974;
	R2486[4] = (char *(*)()) F611_2974;
	R2486[5] = (char *(*)()) F612_2974;
	R2486[6] = (char *(*)()) F613_2974;
	R2486[7] = (char *(*)()) F614_2974;
	R2486[8] = (char *(*)()) F615_2974;
	R2486[9] = (char *(*)()) F616_2974;
	R2486[10] = (char *(*)()) F617_2974;
	R2486[11] = (char *(*)()) F618_2974;
}

char *(*R2495[12])();
void R2495_init () {
	R2495[0] = (char *(*)()) F607_2984;
	R2495[1] = (char *(*)()) F608_2984;
	R2495[2] = (char *(*)()) F609_2984;
	R2495[3] = (char *(*)()) F610_2984;
	R2495[4] = (char *(*)()) F611_2984;
	R2495[5] = (char *(*)()) F612_2984;
	R2495[6] = (char *(*)()) F613_2984;
	R2495[7] = (char *(*)()) F614_2984;
	R2495[8] = (char *(*)()) F615_2984;
	R2495[9] = (char *(*)()) F616_2984;
	R2495[10] = (char *(*)()) F617_2984;
	R2495[11] = (char *(*)()) F618_2984;
}

char *(*R2519[12])();
void R2519_init () {
	R2519[0] = (char *(*)()) F632_3028;
	R2519[1] = (char *(*)()) F633_3028;
	R2519[2] = (char *(*)()) F634_3028;
	R2519[3] = (char *(*)()) F635_3028;
	R2519[4] = (char *(*)()) F636_3028;
	R2519[5] = (char *(*)()) F637_3028;
	R2519[6] = (char *(*)()) F638_3028;
	R2519[7] = (char *(*)()) F639_3028;
	R2519[8] = (char *(*)()) F640_3028;
	R2519[9] = (char *(*)()) F641_3028;
	R2519[10] = (char *(*)()) F642_3028;
	R2519[11] = (char *(*)()) F643_3028;
}

char *(*R2529[12])();
void R2529_init () {
	R2529[0] = (char *(*)()) F632_3054;
	R2529[1] = (char *(*)()) F633_3054;
	R2529[2] = (char *(*)()) F634_3054;
	R2529[3] = (char *(*)()) F635_3054;
	R2529[4] = (char *(*)()) F636_3054;
	R2529[5] = (char *(*)()) F637_3054;
	R2529[6] = (char *(*)()) F638_3054;
	R2529[7] = (char *(*)()) F639_3054;
	R2529[8] = (char *(*)()) F640_3054;
	R2529[9] = (char *(*)()) F641_3054;
	R2529[10] = (char *(*)()) F642_3054;
	R2529[11] = (char *(*)()) F643_3054;
}

char *(*R2550[12])();
void R2550_init () {
	R2550[0] = (char *(*)()) F632_3082;
	R2550[1] = (char *(*)()) F633_3082;
	R2550[2] = (char *(*)()) F634_3082;
	R2550[3] = (char *(*)()) F635_3082;
	R2550[4] = (char *(*)()) F636_3082;
	R2550[5] = (char *(*)()) F637_3082;
	R2550[6] = (char *(*)()) F638_3082;
	R2550[7] = (char *(*)()) F639_3082;
	R2550[8] = (char *(*)()) F640_3082;
	R2550[9] = (char *(*)()) F641_3082;
	R2550[10] = (char *(*)()) F642_3082;
	R2550[11] = (char *(*)()) F643_3082;
}

char *(*R2586[254])();
void R2586_init () {
	R2586[0] = (char *(*)()) F714_3340;
	R2586[1] = (char *(*)()) F715_3340;
	R2586[2] = (char *(*)()) F716_3340;
	R2586[3] = (char *(*)()) F717_3340;
	R2586[4] = (char *(*)()) F718_3340;
	R2586[7] = (char *(*)()) F714_3340;
	R2586[73] = (char *(*)()) F787_3895;
	R2586[155] = (char *(*)()) F869_5225;
	R2586[156] = (char *(*)()) F870_5316;
	R2586[159] = (char *(*)()) F873_5480;
	R2586[187] = (char *(*)()) F898_5867;
	R2586[224] = (char *(*)()) F938_6236;
	R2586[225] = (char *(*)()) F939_6236;
	R2586[229] = (char *(*)()) F942_6407;
	R2586[253] = (char *(*)()) F873_5480;
}

char *(*R2613[8])();
void R2613_init () {
	R2613[0] = (char *(*)()) F714_3281;
	R2613[1] = (char *(*)()) F715_3281;
	R2613[2] = (char *(*)()) F716_3281;
	R2613[3] = (char *(*)()) F717_3281;
	R2613[4] = (char *(*)()) F718_3281;
	R2613[7] = (char *(*)()) F714_3281;
}

char *(*R2616[8])();
void R2616_init () {
	R2616[0] = (char *(*)()) F714_3284;
	R2616[1] = (char *(*)()) F715_3284;
	R2616[2] = (char *(*)()) F716_3284;
	R2616[3] = (char *(*)()) F717_3284;
	R2616[4] = (char *(*)()) F718_3284;
	R2616[7] = (char *(*)()) F714_3284;
}

char *(*R2617[8])();
void R2617_init () {
	R2617[0] = (char *(*)()) F714_3285;
	R2617[1] = (char *(*)()) F715_3285_2617_1;
	R2617[2] = (char *(*)()) F716_3285;
	R2617[3] = (char *(*)()) F717_3285_2617_1;
	R2617[4] = (char *(*)()) F718_3285_2617_1;
	R2617[7] = (char *(*)()) F714_3285;
}
static EIF_REFERENCE F715_3285_2617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F715_3285(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F717_3285_2617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F717_3285(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F718_3285_2617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F718_3285(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(858, 0x00).id, 858, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R2625[8])();
void R2625_init () {
	R2625[0] = (char *(*)()) F714_3298;
	R2625[1] = (char *(*)()) F715_3298;
	R2625[2] = (char *(*)()) F716_3298_2625_14;
	R2625[3] = (char *(*)()) F717_3298_2625_14;
	R2625[4] = (char *(*)()) F718_3298;
	R2625[7] = (char *(*)()) F714_3298;
}
static EIF_INTEGER_32 F716_3298_2625_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F716_3298(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F717_3298_2625_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F717_3298(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R2627[8])();
void R2627_init () {
	R2627[0] = (char *(*)()) F714_3305;
	R2627[1] = (char *(*)()) F715_3305;
	R2627[2] = (char *(*)()) F716_3305_2627_3;
	R2627[3] = (char *(*)()) F717_3305_2627_3;
	R2627[4] = (char *(*)()) F718_3305;
	R2627[7] = (char *(*)()) F714_3305;
}
static EIF_BOOLEAN F716_3305_2627_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F716_3305(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F717_3305_2627_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F717_3305(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R2633[8])();
void R2633_init () {
	R2633[0] = (char *(*)()) F714_3313;
	R2633[1] = (char *(*)()) F715_3313;
	R2633[2] = (char *(*)()) F716_3313;
	R2633[3] = (char *(*)()) F717_3313;
	R2633[4] = (char *(*)()) F718_3313;
	R2633[7] = (char *(*)()) F714_3313;
}

char *(*R2634[8])();
void R2634_init () {
	R2634[0] = (char *(*)()) F714_3314;
	R2634[1] = (char *(*)()) F715_3314;
	R2634[2] = (char *(*)()) F716_3314;
	R2634[3] = (char *(*)()) F717_3314;
	R2634[4] = (char *(*)()) F718_3314;
	R2634[7] = (char *(*)()) F714_3314;
}

char *(*R2642[8])();
void R2642_init () {
	R2642[0] = (char *(*)()) F714_3323;
	R2642[1] = (char *(*)()) F715_3323;
	R2642[2] = (char *(*)()) F716_3323_2642_4;
	R2642[3] = (char *(*)()) F717_3323_2642_4;
	R2642[4] = (char *(*)()) F718_3323;
	R2642[7] = (char *(*)()) F714_3323;
}
static void F716_3323_2642_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F716_3323(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F717_3323_2642_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F717_3323(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R2644[8])();
void R2644_init () {
	R2644[0] = (char *(*)()) F714_3325;
	R2644[1] = (char *(*)()) F715_3325;
	R2644[2] = (char *(*)()) F716_3325;
	R2644[3] = (char *(*)()) F717_3325;
	R2644[4] = (char *(*)()) F718_3325;
	R2644[7] = (char *(*)()) F714_3325;
}

char *(*R2645[8])();
void R2645_init () {
	R2645[0] = (char *(*)()) F714_3326;
	R2645[1] = (char *(*)()) F715_3326;
	R2645[2] = (char *(*)()) F716_3326;
	R2645[3] = (char *(*)()) F717_3326;
	R2645[4] = (char *(*)()) F718_3326;
	R2645[7] = (char *(*)()) F714_3326;
}

char *(*R2651[8])();
void R2651_init () {
	R2651[0] = (char *(*)()) F714_3339;
	R2651[1] = (char *(*)()) F715_3339;
	R2651[2] = (char *(*)()) F716_3339;
	R2651[3] = (char *(*)()) F717_3339;
	R2651[4] = (char *(*)()) F718_3339;
	R2651[7] = (char *(*)()) F714_3339;
}

char *(*R2660[8])();
void R2660_init () {
	R2660[0] = (char *(*)()) F714_3349;
	R2660[1] = (char *(*)()) F715_3349;
	R2660[2] = (char *(*)()) F716_3349;
	R2660[3] = (char *(*)()) F717_3349;
	R2660[4] = (char *(*)()) F718_3349;
	R2660[7] = (char *(*)()) F714_3349;
}

char *(*R2661[8])();
void R2661_init () {
	R2661[0] = (char *(*)()) F714_3350;
	R2661[1] = (char *(*)()) F715_3350;
	R2661[2] = (char *(*)()) F716_3350;
	R2661[3] = (char *(*)()) F717_3350;
	R2661[4] = (char *(*)()) F718_3350;
	R2661[7] = (char *(*)()) F714_3350;
}

char *(*R2668[8])();
void R2668_init () {
	R2668[0] = (char *(*)()) F714_3357;
	R2668[1] = (char *(*)()) F715_3357_2668_1;
	R2668[2] = (char *(*)()) F716_3357;
	R2668[3] = (char *(*)()) F717_3357_2668_1;
	R2668[4] = (char *(*)()) F718_3357_2668_1;
	R2668[7] = (char *(*)()) F714_3357;
}
static EIF_REFERENCE F715_3357_2668_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F715_3357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F717_3357_2668_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F717_3357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F718_3357_2668_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F718_3357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(858, 0x00).id, 858, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R2669[8])();
void R2669_init () {
	R2669[0] = (char *(*)()) F714_3358;
	R2669[1] = (char *(*)()) F715_3358;
	R2669[2] = (char *(*)()) F716_3358_2669_1;
	R2669[3] = (char *(*)()) F717_3358_2669_1;
	R2669[4] = (char *(*)()) F718_3358;
	R2669[7] = (char *(*)()) F714_3358;
}
static EIF_REFERENCE F716_3358_2669_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F716_3358(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F717_3358_2669_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F717_3358(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2670[8])();
void R2670_init () {
	R2670[0] = (char *(*)()) F714_3359;
	R2670[1] = (char *(*)()) F715_3359;
	R2670[2] = (char *(*)()) F716_3359;
	R2670[3] = (char *(*)()) F717_3359;
	R2670[4] = (char *(*)()) F718_3359;
	R2670[7] = (char *(*)()) F714_3359;
}

char *(*R2671[8])();
void R2671_init () {
	R2671[0] = (char *(*)()) F714_3360;
	R2671[1] = (char *(*)()) F715_3360;
	R2671[2] = (char *(*)()) F716_3360;
	R2671[3] = (char *(*)()) F717_3360;
	R2671[4] = (char *(*)()) F718_3360;
	R2671[7] = (char *(*)()) F714_3360;
}

char *(*R2674[8])();
void R2674_init () {
	R2674[0] = (char *(*)()) F714_3363;
	R2674[1] = (char *(*)()) F715_3363;
	R2674[2] = (char *(*)()) F716_3363;
	R2674[3] = (char *(*)()) F717_3363;
	R2674[4] = (char *(*)()) F718_3363;
	R2674[7] = (char *(*)()) F714_3363;
}

char *(*R2676[8])();
void R2676_init () {
	R2676[0] = (char *(*)()) F714_3365;
	R2676[1] = (char *(*)()) F715_3365;
	R2676[2] = (char *(*)()) F716_3365;
	R2676[3] = (char *(*)()) F717_3365;
	R2676[4] = (char *(*)()) F718_3365;
	R2676[7] = (char *(*)()) F714_3365;
}

char *(*R2677[8])();
void R2677_init () {
	R2677[0] = (char *(*)()) F714_3366;
	R2677[1] = (char *(*)()) F715_3366;
	R2677[2] = (char *(*)()) F716_3366;
	R2677[3] = (char *(*)()) F717_3366;
	R2677[4] = (char *(*)()) F718_3366;
	R2677[7] = (char *(*)()) F714_3366;
}

char *(*R2678[8])();
void R2678_init () {
	R2678[0] = (char *(*)()) F714_3367;
	R2678[1] = (char *(*)()) F715_3367;
	R2678[2] = (char *(*)()) F716_3367;
	R2678[3] = (char *(*)()) F717_3367;
	R2678[4] = (char *(*)()) F718_3367;
	R2678[7] = (char *(*)()) F714_3367;
}

char *(*R2682[8])();
void R2682_init () {
	R2682[0] = (char *(*)()) F714_3371;
	R2682[1] = (char *(*)()) F715_3371;
	R2682[2] = (char *(*)()) F716_3371_2682_4;
	R2682[3] = (char *(*)()) F717_3371_2682_4;
	R2682[4] = (char *(*)()) F718_3371;
	R2682[7] = (char *(*)()) F714_3371;
}
static void F716_3371_2682_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F716_3371(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F717_3371_2682_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F717_3371(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R2688[8])();
void R2688_init () {
	R2688[0] = (char *(*)()) F714_3377;
	R2688[1] = (char *(*)()) F715_3377;
	R2688[2] = (char *(*)()) F716_3377;
	R2688[3] = (char *(*)()) F717_3377;
	R2688[4] = (char *(*)()) F718_3377;
	R2688[7] = (char *(*)()) F714_3377;
}

char *(*R2701[8])();
void R2701_init () {
	R2701[0] = (char *(*)()) F714_3390;
	R2701[1] = (char *(*)()) F715_3390;
	R2701[2] = (char *(*)()) F716_3390;
	R2701[3] = (char *(*)()) F717_3390;
	R2701[4] = (char *(*)()) F718_3390;
	R2701[7] = (char *(*)()) F714_3390;
}

char *(*R2718[239])();
void R2718_init () {
	R2718[0] = (char *(*)()) F729_3442;
	R2718[1] = (char *(*)()) F730_3450;
	R2718[180] = (char *(*)()) F908_5992;
	R2718[238] = (char *(*)()) F967_6949;
}

char *(*R2738[239])();
void R2738_init () {
	R2738[0] = (char *(*)()) F729_3439;
	R2738[1] = (char *(*)()) F730_3447;
	R2738[180] = (char *(*)()) F909_6006;
	R2738[238] = (char *(*)()) F967_6990;
}

char *(*R2923[167])();
void R2923_init () {
	R2923[0] = (char *(*)()) F748_3656;
	R2923[1] = (char *(*)()) F746_3638;
	R2923[166] = (char *(*)()) F913_6021;
}

char *(*R2942[213])();
void R2942_init () {
	R2942[0] = (char *(*)()) F755_3719;
	R2942[1] = (char *(*)()) F756_3761;
	R2942[2] = (char *(*)()) F757_3761;
	R2942[3] = (char *(*)()) F758_3761;
	R2942[4] = (char *(*)()) F759_3761;
	R2942[5] = (char *(*)()) F760_3761;
	R2942[6] = (char *(*)()) F761_3761;
	R2942[7] = (char *(*)()) F762_3761;
	R2942[8] = (char *(*)()) F763_3761;
	R2942[9] = (char *(*)()) F764_3761;
	R2942[10] = (char *(*)()) F765_3761;
	R2942[11] = (char *(*)()) F766_3761;
	R2942[12] = (char *(*)()) F767_3761;
	R2942[13] = (char *(*)()) F768_3761;
	R2942[14] = (char *(*)()) F769_3761;
	R2942[15] = (char *(*)()) F770_3761;
	R2942[16] = (char *(*)()) F771_3761;
	R2942[17] = (char *(*)()) F772_3761;
	R2942[18] = (char *(*)()) F773_3761;
	R2942[19] = (char *(*)()) F774_3761;
	R2942[20] = (char *(*)()) F775_3761;
	R2942[21] = (char *(*)()) F776_3761;
	R2942[22] = (char *(*)()) F777_3761;
	R2942[23] = (char *(*)()) F778_3761;
	R2942[24] = (char *(*)()) F779_3761;
	R2942[25] = (char *(*)()) F780_3761;
	R2942[26] = (char *(*)()) F781_3761;
	R2942[27] = (char *(*)()) F782_3761;
	R2942[28] = (char *(*)()) F783_3761;
	R2942[29] = (char *(*)()) F784_3761;
	R2942[30] = (char *(*)()) F785_3761;
	R2942[31] = (char *(*)()) F786_3761;
	R2942[32] = (char *(*)()) F787_3813;
	{long i; for (i = 34; i < 36; i++) R2942[i] = (char *(*)()) F788_3920;}
	{long i; for (i = 37; i < 39; i++) R2942[i] = (char *(*)()) F791_4019;}
	{long i; for (i = 40; i < 42; i++) R2942[i] = (char *(*)()) F794_4118;}
	{long i; for (i = 43; i < 45; i++) R2942[i] = (char *(*)()) F797_4217;}
	{long i; for (i = 46; i < 48; i++) R2942[i] = (char *(*)()) F800_4311;}
	{long i; for (i = 49; i < 51; i++) R2942[i] = (char *(*)()) F803_4405;}
	{long i; for (i = 52; i < 54; i++) R2942[i] = (char *(*)()) F806_4500;}
	{long i; for (i = 55; i < 57; i++) R2942[i] = (char *(*)()) F809_4595;}
	{long i; for (i = 58; i < 60; i++) R2942[i] = (char *(*)()) F812_4661;}
	{long i; for (i = 61; i < 63; i++) R2942[i] = (char *(*)()) F815_4728;}
	{long i; for (i = 64; i < 66; i++) R2942[i] = (char *(*)()) F818_4769;}
	{long i; for (i = 67; i < 69; i++) R2942[i] = (char *(*)()) F821_4817;}
	{long i; for (i = 70; i < 72; i++) R2942[i] = (char *(*)()) F824_4838;}
	{long i; for (i = 73; i < 103; i++) R2942[i] = (char *(*)()) F827_4936;}
	R2942[103] = (char *(*)()) F858_4962;
	R2942[104] = (char *(*)()) F859_4962;
	{long i; for (i = 114; i < 116; i++) R2942[i] = (char *(*)()) F865_5029;}
	{long i; for (i = 117; i < 119; i++) R2942[i] = (char *(*)()) F865_5029;}
	R2942[212] = (char *(*)()) F967_6917;
}

char *(*R3009[31])();
void R3009_init () {
	R3009[0] = (char *(*)()) F756_3757;
	R3009[1] = (char *(*)()) F757_3757;
	R3009[2] = (char *(*)()) F758_3757;
	R3009[3] = (char *(*)()) F759_3757;
	R3009[4] = (char *(*)()) F760_3757;
	R3009[5] = (char *(*)()) F761_3757;
	R3009[6] = (char *(*)()) F762_3757;
	R3009[7] = (char *(*)()) F763_3757;
	R3009[8] = (char *(*)()) F764_3757;
	R3009[9] = (char *(*)()) F765_3757;
	R3009[10] = (char *(*)()) F766_3757;
	R3009[11] = (char *(*)()) F767_3757;
	R3009[12] = (char *(*)()) F768_3757;
	R3009[13] = (char *(*)()) F769_3757;
	R3009[14] = (char *(*)()) F770_3757;
	R3009[15] = (char *(*)()) F771_3757;
	R3009[16] = (char *(*)()) F772_3757;
	R3009[17] = (char *(*)()) F773_3757;
	R3009[18] = (char *(*)()) F774_3757;
	R3009[19] = (char *(*)()) F775_3757;
	R3009[20] = (char *(*)()) F776_3757;
	R3009[21] = (char *(*)()) F777_3757;
	R3009[22] = (char *(*)()) F778_3757;
	R3009[23] = (char *(*)()) F779_3757;
	R3009[24] = (char *(*)()) F780_3757;
	R3009[25] = (char *(*)()) F781_3757;
	R3009[26] = (char *(*)()) F782_3757;
	R3009[27] = (char *(*)()) F783_3757;
	R3009[28] = (char *(*)()) F784_3757;
	R3009[29] = (char *(*)()) F785_3757;
	R3009[30] = (char *(*)()) F786_3757;
}

char *(*R3012[31])();
void R3012_init () {
	R3012[0] = (char *(*)()) F756_3760;
	R3012[1] = (char *(*)()) F757_3760;
	R3012[2] = (char *(*)()) F758_3760;
	R3012[3] = (char *(*)()) F759_3760;
	R3012[4] = (char *(*)()) F760_3760;
	R3012[5] = (char *(*)()) F761_3760;
	R3012[6] = (char *(*)()) F762_3760;
	R3012[7] = (char *(*)()) F763_3760;
	R3012[8] = (char *(*)()) F764_3760;
	R3012[9] = (char *(*)()) F765_3760;
	R3012[10] = (char *(*)()) F766_3760;
	R3012[11] = (char *(*)()) F767_3760;
	R3012[12] = (char *(*)()) F768_3760;
	R3012[13] = (char *(*)()) F769_3760;
	R3012[14] = (char *(*)()) F770_3760;
	R3012[15] = (char *(*)()) F771_3760;
	R3012[16] = (char *(*)()) F772_3760;
	R3012[17] = (char *(*)()) F773_3760;
	R3012[18] = (char *(*)()) F774_3760;
	R3012[19] = (char *(*)()) F775_3760;
	R3012[20] = (char *(*)()) F776_3760;
	R3012[21] = (char *(*)()) F777_3760;
	R3012[22] = (char *(*)()) F778_3760;
	R3012[23] = (char *(*)()) F779_3760;
	R3012[24] = (char *(*)()) F780_3760;
	R3012[25] = (char *(*)()) F781_3760;
	R3012[26] = (char *(*)()) F782_3760;
	R3012[27] = (char *(*)()) F783_3760;
	R3012[28] = (char *(*)()) F784_3760;
	R3012[29] = (char *(*)()) F785_3760;
	R3012[30] = (char *(*)()) F786_3760;
}

char *(*R3014[31])();
void R3014_init () {
	R3014[0] = (char *(*)()) F756_3763;
	R3014[1] = (char *(*)()) F757_3763;
	R3014[2] = (char *(*)()) F758_3763;
	R3014[3] = (char *(*)()) F759_3763;
	R3014[4] = (char *(*)()) F760_3763;
	R3014[5] = (char *(*)()) F761_3763;
	R3014[6] = (char *(*)()) F762_3763;
	R3014[7] = (char *(*)()) F763_3763;
	R3014[8] = (char *(*)()) F764_3763;
	R3014[9] = (char *(*)()) F765_3763;
	R3014[10] = (char *(*)()) F766_3763;
	R3014[11] = (char *(*)()) F767_3763;
	R3014[12] = (char *(*)()) F768_3763;
	R3014[13] = (char *(*)()) F769_3763;
	R3014[14] = (char *(*)()) F770_3763;
	R3014[15] = (char *(*)()) F771_3763;
	R3014[16] = (char *(*)()) F772_3763;
	R3014[17] = (char *(*)()) F773_3763;
	R3014[18] = (char *(*)()) F774_3763;
	R3014[19] = (char *(*)()) F775_3763;
	R3014[20] = (char *(*)()) F776_3763;
	R3014[21] = (char *(*)()) F777_3763;
	R3014[22] = (char *(*)()) F778_3763;
	R3014[23] = (char *(*)()) F779_3763;
	R3014[24] = (char *(*)()) F780_3763;
	R3014[25] = (char *(*)()) F781_3763;
	R3014[26] = (char *(*)()) F782_3763;
	R3014[27] = (char *(*)()) F783_3763;
	R3014[28] = (char *(*)()) F784_3763;
	R3014[29] = (char *(*)()) F785_3763;
	R3014[30] = (char *(*)()) F786_3763;
}

char *(*R3017[31])();
void R3017_init () {
	R3017[0] = (char *(*)()) F756_3766;
	R3017[1] = (char *(*)()) F757_3766;
	R3017[2] = (char *(*)()) F758_3766;
	R3017[3] = (char *(*)()) F759_3766;
	R3017[4] = (char *(*)()) F760_3766;
	R3017[5] = (char *(*)()) F761_3766;
	R3017[6] = (char *(*)()) F762_3766;
	R3017[7] = (char *(*)()) F763_3766;
	R3017[8] = (char *(*)()) F764_3766;
	R3017[9] = (char *(*)()) F765_3766;
	R3017[10] = (char *(*)()) F766_3766;
	R3017[11] = (char *(*)()) F767_3766;
	R3017[12] = (char *(*)()) F768_3766;
	R3017[13] = (char *(*)()) F769_3766;
	R3017[14] = (char *(*)()) F770_3766;
	R3017[15] = (char *(*)()) F771_3766;
	R3017[16] = (char *(*)()) F772_3766;
	R3017[17] = (char *(*)()) F773_3766;
	R3017[18] = (char *(*)()) F774_3766;
	R3017[19] = (char *(*)()) F775_3766;
	R3017[20] = (char *(*)()) F776_3766;
	R3017[21] = (char *(*)()) F777_3766;
	R3017[22] = (char *(*)()) F778_3766;
	R3017[23] = (char *(*)()) F779_3766;
	R3017[24] = (char *(*)()) F780_3766;
	R3017[25] = (char *(*)()) F781_3766;
	R3017[26] = (char *(*)()) F782_3766;
	R3017[27] = (char *(*)()) F783_3766;
	R3017[28] = (char *(*)()) F784_3766;
	R3017[29] = (char *(*)()) F785_3766;
	R3017[30] = (char *(*)()) F786_3766;
}

char *(*R3022[31])();
void R3022_init () {
	R3022[0] = (char *(*)()) F756_3774;
	R3022[1] = (char *(*)()) F757_3774_3022_1;
	R3022[2] = (char *(*)()) F758_3774_3022_1;
	R3022[3] = (char *(*)()) F759_3774_3022_1;
	R3022[4] = (char *(*)()) F760_3774_3022_1;
	R3022[5] = (char *(*)()) F761_3774_3022_1;
	R3022[6] = (char *(*)()) F762_3774_3022_1;
	R3022[7] = (char *(*)()) F763_3774_3022_1;
	R3022[8] = (char *(*)()) F764_3774_3022_1;
	R3022[9] = (char *(*)()) F765_3774_3022_1;
	R3022[10] = (char *(*)()) F766_3774_3022_1;
	R3022[11] = (char *(*)()) F767_3774_3022_1;
	R3022[12] = (char *(*)()) F768_3774_3022_1;
	R3022[13] = (char *(*)()) F769_3774_3022_1;
	R3022[14] = (char *(*)()) F770_3774_3022_1;
	R3022[15] = (char *(*)()) F771_3774_3022_1;
	R3022[16] = (char *(*)()) F772_3774;
	R3022[17] = (char *(*)()) F773_3774_3022_1;
	R3022[18] = (char *(*)()) F774_3774_3022_1;
	R3022[19] = (char *(*)()) F775_3774_3022_1;
	R3022[20] = (char *(*)()) F776_3774_3022_1;
	R3022[21] = (char *(*)()) F777_3774_3022_1;
	R3022[22] = (char *(*)()) F778_3774_3022_1;
	R3022[23] = (char *(*)()) F779_3774_3022_1;
	R3022[24] = (char *(*)()) F780_3774_3022_1;
	R3022[25] = (char *(*)()) F781_3774_3022_1;
	R3022[26] = (char *(*)()) F782_3774_3022_1;
	R3022[27] = (char *(*)()) F783_3774_3022_1;
	R3022[28] = (char *(*)()) F784_3774_3022_1;
	R3022[29] = (char *(*)()) F785_3774_3022_1;
	R3022[30] = (char *(*)()) F786_3774_3022_1;
}
static EIF_REFERENCE F757_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F757_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(858, 0x00).id, 858, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F758_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F758_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {828,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 828, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F759_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F759_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(813, 0x00).id, 813, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F760_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F760_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(810, 0x00).id, 810, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F761_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F761_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(807, 0x00).id, 807, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F762_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F762_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(804, 0x00).id, 804, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F763_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F763_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(801, 0x00).id, 801, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F764_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F764_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(798, 0x00).id, 798, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F765_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F765_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(795, 0x00).id, 795, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F766_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F766_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(792, 0x00).id, 792, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F767_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F767_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F768_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F768_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(825, 0x00).id, 825, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F769_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F769_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(819, 0x00).id, 819, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F770_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F770_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(822, 0x00).id, 822, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F771_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F771_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(816, 0x00).id, 816, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F773_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F773_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {830,792,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 830, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F774_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F774_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {832,813,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 832, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F775_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F775_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {834,858,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 834, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F776_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F776_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {836,798,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 836, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F777_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F777_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {838,795,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 838, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F778_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F778_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {840,810,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 840, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F779_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F779_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {842,789,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 842, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F780_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F780_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {844,819,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 844, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F781_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F781_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {846,816,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 846, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F782_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F782_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {848,804,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 848, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F783_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F783_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {850,801,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 850, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F784_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F784_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {852,807,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 852, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F785_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F785_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {854,822,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 854, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F786_3774_3022_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F786_3774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {856,825,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 856, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}

char *(*R3032[31])();
void R3032_init () {
	R3032[0] = (char *(*)()) F756_3786;
	R3032[1] = (char *(*)()) F757_3786;
	R3032[2] = (char *(*)()) F758_3786;
	R3032[3] = (char *(*)()) F759_3786;
	R3032[4] = (char *(*)()) F760_3786;
	R3032[5] = (char *(*)()) F761_3786;
	R3032[6] = (char *(*)()) F762_3786;
	R3032[7] = (char *(*)()) F763_3786;
	R3032[8] = (char *(*)()) F764_3786;
	R3032[9] = (char *(*)()) F765_3786;
	R3032[10] = (char *(*)()) F766_3786;
	R3032[11] = (char *(*)()) F767_3786;
	R3032[12] = (char *(*)()) F768_3786;
	R3032[13] = (char *(*)()) F769_3786;
	R3032[14] = (char *(*)()) F770_3786;
	R3032[15] = (char *(*)()) F771_3786;
	R3032[16] = (char *(*)()) F772_3786;
	R3032[17] = (char *(*)()) F773_3786;
	R3032[18] = (char *(*)()) F774_3786;
	R3032[19] = (char *(*)()) F775_3786;
	R3032[20] = (char *(*)()) F776_3786;
	R3032[21] = (char *(*)()) F777_3786;
	R3032[22] = (char *(*)()) F778_3786;
	R3032[23] = (char *(*)()) F779_3786;
	R3032[24] = (char *(*)()) F780_3786;
	R3032[25] = (char *(*)()) F781_3786;
	R3032[26] = (char *(*)()) F782_3786;
	R3032[27] = (char *(*)()) F783_3786;
	R3032[28] = (char *(*)()) F784_3786;
	R3032[29] = (char *(*)()) F785_3786;
	R3032[30] = (char *(*)()) F786_3786;
}

char *(*R3178[2])();
void R3178_init () {
	R3178[0] = (char *(*)()) F789_4002;
	R3178[1] = (char *(*)()) F790_4002;
}

char *(*R3179[2])();
void R3179_init () {
	R3179[0] = (char *(*)()) F789_4003;
	R3179[1] = (char *(*)()) F790_4003;
}

char *(*R3183[2])();
void R3183_init () {
	R3183[0] = (char *(*)()) F789_4007;
	R3183[1] = (char *(*)()) F790_4007;
}

char *(*R3235[2])();
void R3235_init () {
	R3235[0] = (char *(*)()) F792_4102;
	R3235[1] = (char *(*)()) F793_4102;
}

char *(*R3238[2])();
void R3238_init () {
	R3238[0] = (char *(*)()) F792_4105;
	R3238[1] = (char *(*)()) F793_4105;
}

char *(*R3288[2])();
void R3288_init () {
	R3288[0] = (char *(*)()) F795_4198;
	R3288[1] = (char *(*)()) F796_4198;
}

char *(*R3291[2])();
void R3291_init () {
	R3291[0] = (char *(*)()) F795_4201;
	R3291[1] = (char *(*)()) F796_4201;
}

char *(*R3294[2])();
void R3294_init () {
	R3294[0] = (char *(*)()) F795_4204;
	R3294[1] = (char *(*)()) F796_4204;
}

char *(*R3348[2])();
void R3348_init () {
	R3348[0] = (char *(*)()) F798_4298;
	R3348[1] = (char *(*)()) F799_4298;
}

char *(*R3394[2])();
void R3394_init () {
	R3394[0] = (char *(*)()) F801_4386;
	R3394[1] = (char *(*)()) F802_4386;
}

char *(*R3395[2])();
void R3395_init () {
	R3395[0] = (char *(*)()) F801_4387;
	R3395[1] = (char *(*)()) F802_4387;
}

char *(*R3397[2])();
void R3397_init () {
	R3397[0] = (char *(*)()) F801_4389;
	R3397[1] = (char *(*)()) F802_4389;
}

char *(*R3400[2])();
void R3400_init () {
	R3400[0] = (char *(*)()) F801_4392;
	R3400[1] = (char *(*)()) F802_4392;
}

char *(*R3401[2])();
void R3401_init () {
	R3401[0] = (char *(*)()) F801_4393;
	R3401[1] = (char *(*)()) F802_4393;
}

char *(*R3449[2])();
void R3449_init () {
	R3449[0] = (char *(*)()) F804_4483;
	R3449[1] = (char *(*)()) F805_4483;
}

char *(*R3450[2])();
void R3450_init () {
	R3450[0] = (char *(*)()) F804_4484;
	R3450[1] = (char *(*)()) F805_4484;
}

char *(*R3453[2])();
void R3453_init () {
	R3453[0] = (char *(*)()) F804_4487;
	R3453[1] = (char *(*)()) F805_4487;
}

char *(*R3501[2])();
void R3501_init () {
	R3501[0] = (char *(*)()) F807_4577;
	R3501[1] = (char *(*)()) F808_4577;
}

char *(*R3502[2])();
void R3502_init () {
	R3502[0] = (char *(*)()) F807_4578;
	R3502[1] = (char *(*)()) F808_4578;
}

char *(*R3503[2])();
void R3503_init () {
	R3503[0] = (char *(*)()) F807_4579;
	R3503[1] = (char *(*)()) F808_4579;
}

char *(*R3504[2])();
void R3504_init () {
	R3504[0] = (char *(*)()) F807_4580;
	R3504[1] = (char *(*)()) F808_4580;
}

char *(*R3506[2])();
void R3506_init () {
	R3506[0] = (char *(*)()) F807_4582;
	R3506[1] = (char *(*)()) F808_4582;
}

char *(*R3552[2])();
void R3552_init () {
	R3552[0] = (char *(*)()) F810_4640;
	R3552[1] = (char *(*)()) F811_4640;
}

char *(*R3586[2])();
void R3586_init () {
	R3586[0] = (char *(*)()) F813_4706;
	R3586[1] = (char *(*)()) F814_4706;
}

char *(*R3607[2])();
void R3607_init () {
	R3607[0] = (char *(*)()) F816_4764;
	R3607[1] = (char *(*)()) F817_4764;
}

char *(*R3713[2])();
void R3713_init () {
	R3713[0] = (char *(*)()) F825_4920;
	R3713[1] = (char *(*)()) F826_4920;
}

char *(*R3716[2])();
void R3716_init () {
	R3716[0] = (char *(*)()) F825_4923;
	R3716[1] = (char *(*)()) F826_4923;
}

char *(*R3817[99])();
void R3817_init () {
	{long i; for (i = 0; i < 2; i++) R3817[i] = (char *(*)()) F868_5150;}
	{long i; for (i = 3; i < 5; i++) R3817[i] = (char *(*)()) F871_5317;}
	R3817[98] = (char *(*)()) F967_6891;
}

char *(*R3819[99])();
void R3819_init () {
	R3819[0] = (char *(*)()) F869_5211;
	R3819[1] = (char *(*)()) F870_5234;
	R3819[3] = (char *(*)()) F872_5377;
	R3819[4] = (char *(*)()) F873_5399;
	R3819[98] = (char *(*)()) F967_7019;
}

char *(*R3820[99])();
void R3820_init () {
	R3820[0] = (char *(*)()) F869_5209;
	R3820[1] = (char *(*)()) F870_5232;
	R3820[3] = (char *(*)()) F872_5376;
	R3820[4] = (char *(*)()) F873_5398;
	R3820[98] = (char *(*)()) F873_5398;
}

char *(*R3833[99])();
void R3833_init () {
	{long i; for (i = 0; i < 2; i++) R3833[i] = (char *(*)()) F868_5182;}
	{long i; for (i = 3; i < 5; i++) R3833[i] = (char *(*)()) F871_5350;}
	R3833[98] = (char *(*)()) F871_5350;
}

char *(*R3834[99])();
void R3834_init () {
	R3834[0] = (char *(*)()) F869_5221;
	R3834[1] = (char *(*)()) F533_2559;
	R3834[3] = (char *(*)()) F872_5386;
	R3834[4] = (char *(*)()) F534_2559;
	R3834[98] = (char *(*)()) F534_2559;
}

char *(*R3856[99])();
void R3856_init () {
	{long i; for (i = 0; i < 2; i++) R3856[i] = (char *(*)()) F868_5171;}
	{long i; for (i = 3; i < 5; i++) R3856[i] = (char *(*)()) F871_5339;}
	R3856[98] = (char *(*)()) F967_6922;
}

char *(*R3857[99])();
void R3857_init () {
	{long i; for (i = 0; i < 2; i++) R3857[i] = (char *(*)()) F868_5170;}
	{long i; for (i = 3; i < 5; i++) R3857[i] = (char *(*)()) F871_5338;}
	R3857[98] = (char *(*)()) F967_6924;
}

char *(*R3862[99])();
void R3862_init () {
	{long i; for (i = 0; i < 2; i++) R3862[i] = (char *(*)()) F865_5065;}
	{long i; for (i = 3; i < 5; i++) R3862[i] = (char *(*)()) F865_5065;}
	R3862[98] = (char *(*)()) F967_6935;
}

char *(*R3897[99])();
void R3897_init () {
	R3897[0] = (char *(*)()) F869_5218;
	R3897[1] = (char *(*)()) F870_5312;
	R3897[3] = (char *(*)()) F872_5384;
	R3897[4] = (char *(*)()) F873_5477;
	R3897[98] = (char *(*)()) F967_6908;
}

char *(*R3912[98])();
void R3912_init () {
	R3912[0] = (char *(*)()) F870_5314;
	R3912[3] = (char *(*)()) F873_5479;
	R3912[97] = (char *(*)()) F873_5479;
}

char *(*R3915[98])();
void R3915_init () {
	R3915[0] = (char *(*)()) F870_5253;
	R3915[3] = (char *(*)()) F873_5418;
	R3915[97] = (char *(*)()) F967_7021;
}

char *(*R3916[98])();
void R3916_init () {
	R3916[0] = (char *(*)()) F867_5120;
	R3916[3] = (char *(*)()) F867_5120;
	R3916[97] = (char *(*)()) F967_7022;
}

char *(*R3935[95])();
void R3935_init () {
	R3935[0] = (char *(*)()) F873_5412;
	R3935[94] = (char *(*)()) F967_6968;
}

char *(*R3936[95])();
void R3936_init () {
	R3936[0] = (char *(*)()) F873_5413;
	R3936[94] = (char *(*)()) F967_6969;
}

char *(*R3941[95])();
void R3941_init () {
	R3941[0] = (char *(*)()) F873_5452;
	R3941[94] = (char *(*)()) F967_6970;
}

char *(*R3943[95])();
void R3943_init () {
	R3943[0] = (char *(*)()) F873_5454;
	R3943[94] = (char *(*)()) F967_6971;
}

char *(*R3944[95])();
void R3944_init () {
	R3944[0] = (char *(*)()) F873_5459;
	R3944[94] = (char *(*)()) F967_7015;
}

char *(*R3945[98])();
void R3945_init () {
	R3945[0] = (char *(*)()) F870_5297;
	R3945[3] = (char *(*)()) F873_5462;
	R3945[97] = (char *(*)()) F873_5462;
}

char *(*R3973[2])();
void R3973_init () {
	R3973[0] = (char *(*)()) F869_5224;
	R3973[1] = (char *(*)()) F868_5201;
}

char *(*R4031[95])();
void R4031_init () {
	R4031[0] = (char *(*)()) F873_5400;
	R4031[94] = (char *(*)()) F967_6905;
}

char *(*R4035[96])();
void R4035_init () {
	{long i; for (i = 0; i < 2; i++) R4035[i] = (char *(*)()) F871_5333;}
	R4035[95] = (char *(*)()) F967_6911;
}

char *(*R4040[96])();
void R4040_init () {
	{long i; for (i = 0; i < 2; i++) R4040[i] = (char *(*)()) F871_5345;}
	R4040[95] = (char *(*)()) F967_6934;
}

char *(*R4045[95])();
void R4045_init () {
	R4045[0] = (char *(*)()) F873_5449;
	R4045[94] = (char *(*)()) F967_6912;
}

char *(*R4053[96])();
void R4053_init () {
	R4053[0] = (char *(*)()) F872_5390;
	R4053[1] = (char *(*)()) F871_5369;
	R4053[95] = (char *(*)()) F871_5369;
}

char *(*R4079[95])();
void R4079_init () {
	R4079[0] = (char *(*)()) F873_5430;
	R4079[94] = (char *(*)()) F967_6950;
}

char *(*R4081[95])();
void R4081_init () {
	R4081[0] = (char *(*)()) F873_5432;
	R4081[94] = (char *(*)()) F967_6948;
}

char *(*R4083[95])();
void R4083_init () {
	R4083[0] = (char *(*)()) F873_5443;
	R4083[94] = (char *(*)()) F967_6947;
}

char *(*R4484[6])();
void R4484_init () {
	R4484[0] = (char *(*)()) F938_6213;
	R4484[1] = (char *(*)()) F939_6213;
	R4484[5] = (char *(*)()) F940_6243;
}

static EIF_TYPE_INDEX Y4493_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4493_pgtype25[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y4493_gen_type [26];
EIF_TYPE_INDEX Y4493 [26];
void Y4493_init (void)
{
	egc_routines_types [4493] = Y4493;
	egc_routines_gen_types [4493] = Y4493_gen_type;
	egc_routines_offset [4493] = 917;
	Y4493_gen_type [0] = Y4493_pgtype0;
	Y4493_gen_type [1] = Y4493_pgtype1;
	Y4493_gen_type [2] = Y4493_pgtype2;
	Y4493_gen_type [3] = Y4493_pgtype3;
	Y4493_gen_type [4] = Y4493_pgtype4;
	Y4493_gen_type [5] = Y4493_pgtype5;
	Y4493_gen_type [6] = Y4493_pgtype6;
	Y4493_gen_type [7] = Y4493_pgtype7;
	Y4493_gen_type [8] = Y4493_pgtype8;
	Y4493_gen_type [9] = Y4493_pgtype9;
	Y4493_gen_type [10] = Y4493_pgtype10;
	Y4493_gen_type [11] = Y4493_pgtype11;
	Y4493_gen_type [12] = Y4493_pgtype12;
	Y4493_gen_type [13] = Y4493_pgtype13;
	Y4493_gen_type [14] = Y4493_pgtype14;
	Y4493_gen_type [15] = Y4493_pgtype15;
	Y4493_gen_type [16] = Y4493_pgtype16;
	Y4493_gen_type [17] = Y4493_pgtype17;
	Y4493_gen_type [18] = Y4493_pgtype18;
	Y4493_gen_type [19] = Y4493_pgtype19;
	Y4493_gen_type [20] = Y4493_pgtype20;
	Y4493_gen_type [21] = Y4493_pgtype21;
	Y4493_gen_type [22] = Y4493_pgtype22;
	Y4493_gen_type [23] = Y4493_pgtype23;
	Y4493_gen_type [24] = Y4493_pgtype24;
	Y4493_gen_type [25] = Y4493_pgtype25;
}

static EIF_TYPE_INDEX Y4514_pgtype0[] = {0xFF01,889,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4514_pgtype1[] = {0xFF01,890,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4514_pgtype2[] = {0xFF01,892,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4514_pgtype3[] = {0xFF01,893,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4514_pgtype4[] = {0xFF01,894,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4514_pgtype5[] = {0xFF01,895,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4514_pgtype6[] = {0xFF01,896,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4514_pgtype7[] = {0xFF01,897,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4514_pgtype8[] = {0xFF01,898,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4514_pgtype9[] = {0xFF01,899,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4514_pgtype10[] = {0xFF01,900,0xFFF8,1,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y4514_gen_type [23];
EIF_TYPE_INDEX Y4514 [23];
void Y4514_init (void)
{
	egc_routines_types [4514] = Y4514;
	egc_routines_gen_types [4514] = Y4514_gen_type;
	egc_routines_offset [4514] = 920;
	Y4514_gen_type [0] = Y4514_pgtype0;
	Y4514_gen_type [1] = Y4514_pgtype1;
	Y4514_gen_type [10] = Y4514_pgtype2;
	Y4514_gen_type [11] = Y4514_pgtype3;
	Y4514_gen_type [12] = Y4514_pgtype4;
	Y4514_gen_type [13] = Y4514_pgtype5;
	Y4514_gen_type [14] = Y4514_pgtype6;
	Y4514_gen_type [19] = Y4514_pgtype7;
	Y4514_gen_type [20] = Y4514_pgtype8;
	Y4514_gen_type [21] = Y4514_pgtype9;
	Y4514_gen_type [22] = Y4514_pgtype10;
	Y4514[0] = 889;
	Y4514[1] = 890;
	Y4514[10] = 892;
	Y4514[11] = 893;
	Y4514[12] = 894;
	Y4514[13] = 895;
	Y4514[14] = 896;
	Y4514[19] = 897;
	Y4514[20] = 898;
	Y4514[21] = 899;
	Y4514[22] = 900;
}

char *(*R4582[6])();
void R4582_init () {
	R4582[0] = (char *(*)()) F938_6214;
	R4582[1] = (char *(*)()) F939_6214;
	R4582[5] = (char *(*)()) F940_6244;
}

char *(*R4592[2])();
void R4592_init () {
	R4592[0] = (char *(*)()) F938_6237;
	R4592[1] = (char *(*)()) F939_6237;
}

static EIF_TYPE_INDEX Y4655_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4655_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4655_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4655_pgtype3[] = {0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y4655_gen_type [4];
EIF_TYPE_INDEX Y4655 [4];
void Y4655_init (void)
{
	egc_routines_types [4655] = Y4655;
	egc_routines_gen_types [4655] = Y4655_gen_type;
	egc_routines_offset [4655] = 939;
	Y4655_gen_type [0] = Y4655_pgtype0;
	Y4655_gen_type [1] = Y4655_pgtype1;
	Y4655_gen_type [2] = Y4655_pgtype2;
	Y4655_gen_type [3] = Y4655_pgtype3;
}

char *(*R4794[2])();
void R4794_init () {
	R4794[0] = (char *(*)()) F948_6577;
	R4794[1] = (char *(*)()) F949_6605;
}

char *(*R4805[2])();
void R4805_init () {
	R4805[0] = (char *(*)()) F948_6587;
	R4805[1] = (char *(*)()) F949_6615;
}

char *(*R4806[2])();
void R4806_init () {
	R4806[0] = (char *(*)()) F948_6588;
	R4806[1] = (char *(*)()) F949_6616;
}

char *(*R4970[7])();
void R4970_init () {
	R4970[0] = (char *(*)()) F958_6832;
	R4970[1] = (char *(*)()) F959_6835;
	R4970[2] = (char *(*)()) F960_6838;
	R4970[3] = (char *(*)()) F961_6841;
	R4970[4] = (char *(*)()) F962_6844;
	R4970[5] = (char *(*)()) F963_6847;
	R4970[6] = (char *(*)()) F964_6850;
}
char *(*R2[968])();
void R2_init () {}
char *(*R6[968])();
void R6_init () {}

char *(*R3[968])();
void R3_init () {
	R3[167] = (char *(*)()) F168_1486;
	R3[879] = (char *(*)()) F880_5493;
	R3[905] = (char *(*)()) F194_1857;
	R3[908] = (char *(*)()) F201_2059;
	R3[913] = (char *(*)()) F201_2059;
}

char *(*R4[968])();
void R4_init () {
	R4[1] = (char *(*)()) F1_15;
	R4[3] = (char *(*)()) F1_15;
	{long i; for (i = 10; i < 17; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 19; i < 22; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 34; i < 36; i++) R4[i] = (char *(*)()) F1_15;}
	R4[47] = (char *(*)()) F1_15;
	R4[58] = (char *(*)()) F1_15;
	{long i; for (i = 70; i < 76; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 92; i < 94; i++) R4[i] = (char *(*)()) F1_15;}
	R4[95] = (char *(*)()) F1_15;
	R4[97] = (char *(*)()) F1_15;
	{long i; for (i = 105; i < 107; i++) R4[i] = (char *(*)()) F1_15;}
	R4[114] = (char *(*)()) F1_15;
	R4[117] = (char *(*)()) F1_15;
	{long i; for (i = 121; i < 125; i++) R4[i] = (char *(*)()) F1_15;}
	R4[128] = (char *(*)()) F1_15;
	{long i; for (i = 130; i < 133; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 134; i < 136; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 138; i < 140; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 141; i < 144; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 145; i < 149; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 150; i < 152; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 153; i < 156; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 157; i < 165; i++) R4[i] = (char *(*)()) F1_15;}
	R4[167] = (char *(*)()) F168_1405;
	R4[169] = (char *(*)()) F1_15;
	R4[173] = (char *(*)()) F1_15;
	{long i; for (i = 191; i < 193; i++) R4[i] = (char *(*)()) F1_15;}
	R4[194] = (char *(*)()) F195_1925;
	{long i; for (i = 198; i < 200; i++) R4[i] = (char *(*)()) F1_15;}
	R4[284] = (char *(*)()) F1_15;
	R4[287] = (char *(*)()) F1_15;
	{long i; for (i = 331; i < 336; i++) R4[i] = (char *(*)()) F1_15;}
	R4[528] = (char *(*)()) F1_15;
	{long i; for (i = 606; i < 618; i++) R4[i] = (char *(*)()) F1_15;}
	R4[631] = (char *(*)()) F632_3078;
	R4[632] = (char *(*)()) F633_3078;
	R4[633] = (char *(*)()) F634_3078;
	R4[634] = (char *(*)()) F635_3078;
	R4[635] = (char *(*)()) F636_3078;
	R4[636] = (char *(*)()) F637_3078;
	R4[637] = (char *(*)()) F638_3078;
	R4[638] = (char *(*)()) F639_3078;
	R4[639] = (char *(*)()) F640_3078;
	R4[640] = (char *(*)()) F641_3078;
	R4[641] = (char *(*)()) F642_3078;
	R4[642] = (char *(*)()) F643_3078;
	R4[713] = (char *(*)()) F714_3338;
	R4[714] = (char *(*)()) F715_3338;
	R4[715] = (char *(*)()) F716_3338;
	R4[716] = (char *(*)()) F717_3338;
	R4[717] = (char *(*)()) F718_3338;
	R4[720] = (char *(*)()) F714_3338;
	R4[722] = (char *(*)()) F1_15;
	{long i; for (i = 728; i < 730; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 735; i < 743; i++) R4[i] = (char *(*)()) F1_15;}
	R4[744] = (char *(*)()) F1_15;
	{long i; for (i = 747; i < 749; i++) R4[i] = (char *(*)()) F1_15;}
	R4[754] = (char *(*)()) F755_3733;
	{long i; for (i = 755; i < 787; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 788; i < 790; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 791; i < 793; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 794; i < 796; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 797; i < 799; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 800; i < 802; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 803; i < 805; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 806; i < 808; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 809; i < 811; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 812; i < 814; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 815; i < 817; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 818; i < 820; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 821; i < 823; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 824; i < 826; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 827; i < 859; i++) R4[i] = (char *(*)()) F1_15;}
	R4[868] = (char *(*)()) F869_5208;
	R4[869] = (char *(*)()) F868_5189;
	R4[871] = (char *(*)()) F872_5373;
	R4[872] = (char *(*)()) F871_5357;
	{long i; for (i = 874; i < 880; i++) R4[i] = (char *(*)()) F1_15;}
	R4[900] = (char *(*)()) F890_5819;
	R4[905] = (char *(*)()) F1_15;
	R4[908] = (char *(*)()) F1_15;
	R4[913] = (char *(*)()) F1_15;
	R4[937] = (char *(*)()) F938_6216;
	R4[938] = (char *(*)()) F939_6216;
	R4[942] = (char *(*)()) F941_6361;
	R4[944] = (char *(*)()) F1_15;
	{long i; for (i = 947; i < 949; i++) R4[i] = (char *(*)()) F1_15;}
	R4[950] = (char *(*)()) F1_15;
	R4[955] = (char *(*)()) F1_15;
	{long i; for (i = 957; i < 964; i++) R4[i] = (char *(*)()) F1_15;}
	R4[965] = (char *(*)()) F966_6886;
	R4[966] = (char *(*)()) F967_6975;
}

char *(*R5[968])();
void R5_init () {
	R5[1] = (char *(*)()) F1_8;
	R5[3] = (char *(*)()) F1_8;
	{long i; for (i = 10; i < 17; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 19; i < 22; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 34; i < 36; i++) R5[i] = (char *(*)()) F1_8;}
	R5[47] = (char *(*)()) F1_8;
	R5[58] = (char *(*)()) F1_8;
	{long i; for (i = 70; i < 76; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 92; i < 94; i++) R5[i] = (char *(*)()) F1_8;}
	R5[95] = (char *(*)()) F1_8;
	R5[97] = (char *(*)()) F1_8;
	{long i; for (i = 105; i < 107; i++) R5[i] = (char *(*)()) F1_8;}
	R5[114] = (char *(*)()) F1_8;
	R5[117] = (char *(*)()) F1_8;
	{long i; for (i = 121; i < 125; i++) R5[i] = (char *(*)()) F1_8;}
	R5[128] = (char *(*)()) F1_8;
	{long i; for (i = 130; i < 133; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 134; i < 136; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 138; i < 140; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 141; i < 144; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 145; i < 149; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 150; i < 152; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 153; i < 156; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 157; i < 165; i++) R5[i] = (char *(*)()) F1_8;}
	R5[167] = (char *(*)()) F168_1404;
	R5[169] = (char *(*)()) F1_8;
	R5[173] = (char *(*)()) F1_8;
	R5[191] = (char *(*)()) F192_1779;
	R5[192] = (char *(*)()) F1_8;
	R5[194] = (char *(*)()) F195_1924;
	{long i; for (i = 198; i < 200; i++) R5[i] = (char *(*)()) F1_8;}
	R5[284] = (char *(*)()) F1_8;
	R5[287] = (char *(*)()) F1_8;
	{long i; for (i = 331; i < 336; i++) R5[i] = (char *(*)()) F1_8;}
	R5[528] = (char *(*)()) F1_8;
	{long i; for (i = 606; i < 618; i++) R5[i] = (char *(*)()) F1_8;}
	R5[631] = (char *(*)()) F632_3040;
	R5[632] = (char *(*)()) F633_3040;
	R5[633] = (char *(*)()) F634_3040;
	R5[634] = (char *(*)()) F635_3040;
	R5[635] = (char *(*)()) F636_3040;
	R5[636] = (char *(*)()) F637_3040;
	R5[637] = (char *(*)()) F638_3040;
	R5[638] = (char *(*)()) F639_3040;
	R5[639] = (char *(*)()) F640_3040;
	R5[640] = (char *(*)()) F641_3040;
	R5[641] = (char *(*)()) F642_3040;
	R5[642] = (char *(*)()) F643_3040;
	R5[713] = (char *(*)()) F714_3304;
	R5[714] = (char *(*)()) F715_3304;
	R5[715] = (char *(*)()) F716_3304;
	R5[716] = (char *(*)()) F717_3304;
	R5[717] = (char *(*)()) F718_3304;
	R5[720] = (char *(*)()) F714_3304;
	R5[722] = (char *(*)()) F1_8;
	{long i; for (i = 728; i < 730; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 735; i < 743; i++) R5[i] = (char *(*)()) F1_8;}
	R5[744] = (char *(*)()) F1_8;
	{long i; for (i = 747; i < 749; i++) R5[i] = (char *(*)()) F1_8;}
	R5[754] = (char *(*)()) F755_3730;
	R5[755] = (char *(*)()) F756_3767;
	R5[756] = (char *(*)()) F757_3767;
	R5[757] = (char *(*)()) F758_3767;
	R5[758] = (char *(*)()) F759_3767;
	R5[759] = (char *(*)()) F760_3767;
	R5[760] = (char *(*)()) F761_3767;
	R5[761] = (char *(*)()) F762_3767;
	R5[762] = (char *(*)()) F763_3767;
	R5[763] = (char *(*)()) F764_3767;
	R5[764] = (char *(*)()) F765_3767;
	R5[765] = (char *(*)()) F766_3767;
	R5[766] = (char *(*)()) F767_3767;
	R5[767] = (char *(*)()) F768_3767;
	R5[768] = (char *(*)()) F769_3767;
	R5[769] = (char *(*)()) F770_3767;
	R5[770] = (char *(*)()) F771_3767;
	R5[771] = (char *(*)()) F772_3767;
	R5[772] = (char *(*)()) F773_3767;
	R5[773] = (char *(*)()) F774_3767;
	R5[774] = (char *(*)()) F775_3767;
	R5[775] = (char *(*)()) F776_3767;
	R5[776] = (char *(*)()) F777_3767;
	R5[777] = (char *(*)()) F778_3767;
	R5[778] = (char *(*)()) F779_3767;
	R5[779] = (char *(*)()) F780_3767;
	R5[780] = (char *(*)()) F781_3767;
	R5[781] = (char *(*)()) F782_3767;
	R5[782] = (char *(*)()) F783_3767;
	R5[783] = (char *(*)()) F784_3767;
	R5[784] = (char *(*)()) F785_3767;
	R5[785] = (char *(*)()) F786_3767;
	R5[786] = (char *(*)()) F787_3810;
	{long i; for (i = 788; i < 790; i++) R5[i] = (char *(*)()) F788_3928;}
	{long i; for (i = 791; i < 793; i++) R5[i] = (char *(*)()) F791_4027;}
	{long i; for (i = 794; i < 796; i++) R5[i] = (char *(*)()) F794_4126;}
	{long i; for (i = 797; i < 799; i++) R5[i] = (char *(*)()) F797_4225;}
	{long i; for (i = 800; i < 802; i++) R5[i] = (char *(*)()) F800_4319;}
	{long i; for (i = 803; i < 805; i++) R5[i] = (char *(*)()) F803_4413;}
	{long i; for (i = 806; i < 808; i++) R5[i] = (char *(*)()) F806_4508;}
	{long i; for (i = 809; i < 811; i++) R5[i] = (char *(*)()) F809_4607;}
	{long i; for (i = 812; i < 814; i++) R5[i] = (char *(*)()) F812_4673;}
	{long i; for (i = 815; i < 817; i++) R5[i] = (char *(*)()) F815_4734;}
	{long i; for (i = 818; i < 820; i++) R5[i] = (char *(*)()) F818_4774;}
	{long i; for (i = 821; i < 823; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 824; i < 826; i++) R5[i] = (char *(*)()) F824_4846;}
	{long i; for (i = 827; i < 859; i++) R5[i] = (char *(*)()) F827_4938;}
	{long i; for (i = 868; i < 870; i++) R5[i] = (char *(*)()) F868_5174;}
	{long i; for (i = 871; i < 873; i++) R5[i] = (char *(*)()) F871_5342;}
	{long i; for (i = 874; i < 880; i++) R5[i] = (char *(*)()) F1_8;}
	R5[900] = (char *(*)()) F890_5820;
	R5[905] = (char *(*)()) F1_8;
	R5[908] = (char *(*)()) F1_8;
	R5[913] = (char *(*)()) F1_8;
	R5[937] = (char *(*)()) F938_6217;
	R5[938] = (char *(*)()) F939_6217;
	R5[942] = (char *(*)()) F941_6349;
	R5[944] = (char *(*)()) F1_8;
	{long i; for (i = 947; i < 949; i++) R5[i] = (char *(*)()) F1_8;}
	R5[950] = (char *(*)()) F1_8;
	R5[955] = (char *(*)()) F1_8;
	{long i; for (i = 957; i < 964; i++) R5[i] = (char *(*)()) F1_8;}
	R5[965] = (char *(*)()) F965_6867;
	R5[966] = (char *(*)()) F967_6932;
}


#ifdef __cplusplus
}
#endif
