#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O825[6];
void O825_init () {
	O825[0] = 0;
	{long i; for (i = 1; i < 3; i++) O825[i] = + _LNGOFF_0_0_0_0_;}
	O825[3] = + _I64OFF_0_0_0_0_0_0_0_;
	O825[4] = 0;
	O825[5] = + _LNGOFF_1_0_0_0_;
}

long O953[4];
void O953_init () {
	O953[0] = + _CHROFF_2_0_;
	O953[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O953[i] = + _CHROFF_2_0_;}
}

long O954[4];
void O954_init () {
	O954[0] = + _CHROFF_2_1_;
	O954[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O954[i] = + _CHROFF_2_1_;}
}

long O1114[6];
void O1114_init () {
	{long i; for (i = 0; i < 3; i++) O1114[i] = + _LNGOFF_1_3_0_0_;}
	{long i; for (i = 3; i < 5; i++) O1114[i] = + _LNGOFF_2_4_0_0_;}
	O1114[5] = + _LNGOFF_2_5_0_0_;
}

long O1115[6];
void O1115_init () {
	{long i; for (i = 0; i < 3; i++) O1115[i] = + _LNGOFF_1_3_0_1_;}
	{long i; for (i = 3; i < 5; i++) O1115[i] = + _LNGOFF_2_4_0_1_;}
	O1115[5] = + _LNGOFF_2_5_0_1_;
}

long O1116[6];
void O1116_init () {
	{long i; for (i = 0; i < 3; i++) O1116[i] = + _LNGOFF_1_3_0_2_;}
	{long i; for (i = 3; i < 5; i++) O1116[i] = + _LNGOFF_2_4_0_2_;}
	O1116[5] = + _LNGOFF_2_5_0_2_;
}

long O1117[6];
void O1117_init () {
	{long i; for (i = 0; i < 3; i++) O1117[i] = + _LNGOFF_1_3_0_3_;}
	{long i; for (i = 3; i < 5; i++) O1117[i] = + _LNGOFF_2_4_0_3_;}
	O1117[5] = + _LNGOFF_2_5_0_3_;
}

long O1118[6];
void O1118_init () {
	{long i; for (i = 0; i < 3; i++) O1118[i] = + _LNGOFF_1_3_0_4_;}
	{long i; for (i = 3; i < 5; i++) O1118[i] = + _LNGOFF_2_4_0_4_;}
	O1118[5] = + _LNGOFF_2_5_0_4_;
}

long O1119[6];
void O1119_init () {
	{long i; for (i = 0; i < 3; i++) O1119[i] = + _LNGOFF_1_3_0_5_;}
	{long i; for (i = 3; i < 5; i++) O1119[i] = + _LNGOFF_2_4_0_5_;}
	O1119[5] = + _LNGOFF_2_5_0_5_;
}

long O1120[6];
void O1120_init () {
	{long i; for (i = 0; i < 3; i++) O1120[i] = + _CHROFF_1_0_;}
	{long i; for (i = 3; i < 6; i++) O1120[i] = + _CHROFF_2_0_;}
}

long O1125[6];
void O1125_init () {
	{long i; for (i = 0; i < 3; i++) O1125[i] = + _CHROFF_1_1_;}
	{long i; for (i = 3; i < 6; i++) O1125[i] = + _CHROFF_2_1_;}
}

static EIF_TYPE_INDEX Y1613_pgtype0[] = {0xFF01,606,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype1[] = {0xFF01,607,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype2[] = {0xFF01,608,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype3[] = {0xFF01,609,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype4[] = {0xFF01,610,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype5[] = {0xFF01,611,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype6[] = {0xFF01,612,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype7[] = {0xFF01,613,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype8[] = {0xFF01,614,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype9[] = {0xFF01,615,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype10[] = {0xFF01,616,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype11[] = {0xFF01,617,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype12[] = {0xFF01,610,807,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype13[] = {0xFF01,610,807,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype14[] = {0xFF01,606,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype15[] = {0xFF01,607,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype16[] = {0xFF01,608,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype17[] = {0xFF01,609,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype18[] = {0xFF01,610,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype19[] = {0xFF01,611,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype20[] = {0xFF01,612,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype21[] = {0xFF01,613,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype22[] = {0xFF01,614,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype23[] = {0xFF01,615,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype24[] = {0xFF01,616,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype25[] = {0xFF01,617,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype26[] = {0xFF01,606,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype27[] = {0xFF01,607,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype28[] = {0xFF01,611,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype29[] = {0xFF01,612,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype30[] = {0xFF01,613,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype31[] = {0xFF01,606,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype32[] = {0xFF01,607,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype33[] = {0xFF01,608,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype34[] = {0xFF01,609,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype35[] = {0xFF01,610,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype36[] = {0xFF01,611,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype37[] = {0xFF01,612,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype38[] = {0xFF01,613,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype39[] = {0xFF01,614,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype40[] = {0xFF01,615,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype41[] = {0xFF01,616,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype42[] = {0xFF01,617,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype43[] = {0xFF01,614,816,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype44[] = {0xFF01,613,819,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype45[] = {0xFF01,613,819,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype46[] = {0xFF01,613,819,0xFFFF};
static EIF_TYPE_INDEX Y1613_pgtype47[] = {0xFF01,613,819,0xFFFF};
EIF_TYPE_INDEX *Y1613_gen_type [790];
EIF_TYPE_INDEX Y1613 [790];
void Y1613_init (void)
{
	egc_routines_types [1613] = Y1613;
	egc_routines_gen_types [1613] = Y1613_gen_type;
	egc_routines_offset [1613] = 178;
	Y1613_gen_type [0] = Y1613_pgtype0;
	Y1613_gen_type [1] = Y1613_pgtype1;
	Y1613_gen_type [2] = Y1613_pgtype2;
	Y1613_gen_type [3] = Y1613_pgtype3;
	Y1613_gen_type [4] = Y1613_pgtype4;
	Y1613_gen_type [5] = Y1613_pgtype5;
	Y1613_gen_type [6] = Y1613_pgtype6;
	Y1613_gen_type [7] = Y1613_pgtype7;
	Y1613_gen_type [8] = Y1613_pgtype8;
	Y1613_gen_type [9] = Y1613_pgtype9;
	Y1613_gen_type [10] = Y1613_pgtype10;
	Y1613_gen_type [11] = Y1613_pgtype11;
	Y1613_gen_type [16] = Y1613_pgtype12;
	Y1613_gen_type [17] = Y1613_pgtype13;
	Y1613_gen_type [453] = Y1613_pgtype14;
	Y1613_gen_type [454] = Y1613_pgtype15;
	Y1613_gen_type [455] = Y1613_pgtype16;
	Y1613_gen_type [456] = Y1613_pgtype17;
	Y1613_gen_type [457] = Y1613_pgtype18;
	Y1613_gen_type [458] = Y1613_pgtype19;
	Y1613_gen_type [459] = Y1613_pgtype20;
	Y1613_gen_type [460] = Y1613_pgtype21;
	Y1613_gen_type [461] = Y1613_pgtype22;
	Y1613_gen_type [462] = Y1613_pgtype23;
	Y1613_gen_type [463] = Y1613_pgtype24;
	Y1613_gen_type [464] = Y1613_pgtype25;
	Y1613_gen_type [465] = Y1613_pgtype26;
	Y1613_gen_type [466] = Y1613_pgtype27;
	Y1613_gen_type [467] = Y1613_pgtype28;
	Y1613_gen_type [468] = Y1613_pgtype29;
	Y1613_gen_type [469] = Y1613_pgtype30;
	Y1613_gen_type [523] = Y1613_pgtype31;
	Y1613_gen_type [524] = Y1613_pgtype32;
	Y1613_gen_type [525] = Y1613_pgtype33;
	Y1613_gen_type [526] = Y1613_pgtype34;
	Y1613_gen_type [527] = Y1613_pgtype35;
	Y1613_gen_type [528] = Y1613_pgtype36;
	Y1613_gen_type [529] = Y1613_pgtype37;
	Y1613_gen_type [530] = Y1613_pgtype38;
	Y1613_gen_type [531] = Y1613_pgtype39;
	Y1613_gen_type [532] = Y1613_pgtype40;
	Y1613_gen_type [533] = Y1613_pgtype41;
	Y1613_gen_type [534] = Y1613_pgtype42;
	Y1613_gen_type [691] = Y1613_pgtype43;
	Y1613_gen_type [694] = Y1613_pgtype44;
	Y1613_gen_type [695] = Y1613_pgtype45;
	Y1613_gen_type [788] = Y1613_pgtype46;
	Y1613_gen_type [789] = Y1613_pgtype47;
	Y1613[0] = 606;
	Y1613[1] = 607;
	Y1613[2] = 608;
	Y1613[3] = 609;
	Y1613[4] = 610;
	Y1613[5] = 611;
	Y1613[6] = 612;
	Y1613[7] = 613;
	Y1613[8] = 614;
	Y1613[9] = 615;
	Y1613[10] = 616;
	Y1613[11] = 617;
	{long i; for (i = 16; i < 18; i++) Y1613[i] = 610;};
	Y1613[453] = 606;
	Y1613[454] = 607;
	Y1613[455] = 608;
	Y1613[456] = 609;
	Y1613[457] = 610;
	Y1613[458] = 611;
	Y1613[459] = 612;
	Y1613[460] = 613;
	Y1613[461] = 614;
	Y1613[462] = 615;
	Y1613[463] = 616;
	Y1613[464] = 617;
	Y1613[465] = 606;
	Y1613[466] = 607;
	Y1613[467] = 611;
	Y1613[468] = 612;
	Y1613[469] = 613;
	Y1613[523] = 606;
	Y1613[524] = 607;
	Y1613[525] = 608;
	Y1613[526] = 609;
	Y1613[527] = 610;
	Y1613[528] = 611;
	Y1613[529] = 612;
	Y1613[530] = 613;
	Y1613[531] = 614;
	Y1613[532] = 615;
	Y1613[533] = 616;
	Y1613[534] = 617;
	Y1613[691] = 614;
	{long i; for (i = 694; i < 696; i++) Y1613[i] = 613;};
	{long i; for (i = 788; i < 790; i++) Y1613[i] = 613;};
}

long O1852[717];
void O1852_init () {
	O1852[0] = + _CHROFF_1_0_;
	O1852[391] = + _CHROFF_3_0_;
	O1852[392] = + _CHROFF_4_0_;
	O1852[393] = + _CHROFF_5_0_;
	O1852[679] = + _CHROFF_5_0_;
	O1852[708] = + _CHROFF_6_0_;
	{long i; for (i = 709; i < 712; i++) O1852[i] = + _CHROFF_5_0_;}
	O1852[713] = + _CHROFF_7_1_;
	{long i; for (i = 714; i < 717; i++) O1852[i] = + _CHROFF_6_1_;}
}

long O1853[717];
void O1853_init () {
	O1853[0] = 0;
	{long i; for (i = 391; i < 394; i++) O1853[i] = 0;}
	O1853[679] = 0;
	{long i; for (i = 708; i < 712; i++) O1853[i] = 0;}
	O1853[713] =  + _REFACS_6_;
	{long i; for (i = 714; i < 717; i++) O1853[i] =  + _REFACS_5_;}
}

long O2178[582];
void O2178_init () {
	{long i; for (i = 0; i < 205; i++) O2178[i] = + _CHROFF_0_0_;}
	O2178[205] = + _CHROFF_3_2_;
	O2178[206] = + _CHROFF_4_2_;
	O2178[207] = + _CHROFF_5_2_;
	{long i; for (i = 232; i < 245; i++) O2178[i] = + _CHROFF_0_0_;}
	{long i; for (i = 245; i < 262; i++) O2178[i] = + _CHROFF_1_0_;}
	{long i; for (i = 262; i < 310; i++) O2178[i] = + _CHROFF_0_0_;}
	{long i; for (i = 310; i < 312; i++) O2178[i] = + _CHROFF_2_0_;}
	{long i; for (i = 314; i < 327; i++) O2178[i] = + _CHROFF_1_0_;}
	O2178[327] = + _CHROFF_7_0_;
	O2178[328] = + _CHROFF_5_0_;
	O2178[329] = + _CHROFF_6_0_;
	O2178[330] = + _CHROFF_4_0_;
	O2178[331] = + _CHROFF_5_0_;
	O2178[332] = + _CHROFF_7_0_;
	O2178[333] = + _CHROFF_5_0_;
	O2178[334] = + _CHROFF_9_0_;
	O2178[483] = + _CHROFF_1_0_;
	{long i; for (i = 486; i < 488; i++) O2178[i] = + _CHROFF_1_0_;}
	O2178[493] = + _CHROFF_5_2_;
	O2178[522] = + _CHROFF_6_2_;
	{long i; for (i = 523; i < 526; i++) O2178[i] = + _CHROFF_5_2_;}
	O2178[527] = + _CHROFF_7_2_;
	{long i; for (i = 528; i < 531; i++) O2178[i] = + _CHROFF_6_2_;}
	{long i; for (i = 580; i < 582; i++) O2178[i] = + _CHROFF_1_0_;}
}

long O2267[326];
void O2267_init () {
	O2267[0] = + _PTROFF_3_6_2_4_1_0_;
	O2267[1] = + _PTROFF_4_6_2_4_1_0_;
	O2267[2] = + _PTROFF_5_7_2_4_1_0_;
	O2267[288] = + _PTROFF_5_7_2_4_1_0_;
	O2267[317] = + _PTROFF_6_7_2_4_1_0_;
	{long i; for (i = 318; i < 321; i++) O2267[i] = + _PTROFF_5_6_2_4_1_0_;}
	O2267[322] = + _PTROFF_7_8_2_4_1_0_;
	{long i; for (i = 323; i < 326; i++) O2267[i] = + _PTROFF_6_7_2_4_1_0_;}
}

long O2350[326];
void O2350_init () {
	{long i; for (i = 0; i < 3; i++) O2350[i] =  + _REFACS_1_;}
	O2350[288] =  + _REFACS_1_;
	{long i; for (i = 317; i < 321; i++) O2350[i] =  + _REFACS_1_;}
	{long i; for (i = 322; i < 326; i++) O2350[i] = 0;}
}

long O2352[326];
void O2352_init () {
	{long i; for (i = 0; i < 3; i++) O2352[i] =  + _REFACS_2_;}
	O2352[288] =  + _REFACS_2_;
	{long i; for (i = 317; i < 321; i++) O2352[i] =  + _REFACS_2_;}
	{long i; for (i = 322; i < 326; i++) O2352[i] =  + _REFACS_1_;}
}

long O2406[326];
void O2406_init () {
	O2406[0] = + _LNGOFF_3_6_2_3_;
	O2406[1] = + _LNGOFF_4_6_2_3_;
	O2406[2] = + _LNGOFF_5_7_2_3_;
	O2406[288] = + _LNGOFF_5_7_2_3_;
	O2406[317] = + _LNGOFF_6_7_2_3_;
	{long i; for (i = 318; i < 321; i++) O2406[i] = + _LNGOFF_5_6_2_3_;}
	O2406[322] = + _LNGOFF_7_8_2_3_;
	{long i; for (i = 323; i < 326; i++) O2406[i] = + _LNGOFF_6_7_2_3_;}
}

long O2415[326];
void O2415_init () {
	O2415[0] = + _CHROFF_3_3_;
	O2415[1] = + _CHROFF_4_3_;
	O2415[2] = + _CHROFF_5_3_;
	O2415[288] = + _CHROFF_5_3_;
	O2415[317] = + _CHROFF_6_3_;
	{long i; for (i = 318; i < 321; i++) O2415[i] = + _CHROFF_5_3_;}
	O2415[322] = + _CHROFF_7_3_;
	{long i; for (i = 323; i < 326; i++) O2415[i] = + _CHROFF_6_3_;}
}

long O2429[321];
void O2429_init () {
	O2429[0] =  + _REFACS_3_;
	O2429[286] =  + _REFACS_3_;
	O2429[315] =  + _REFACS_3_;
	O2429[320] =  + _REFACS_2_;
}

EIF_TYPE_INDEX *Y2597_gen_type [1];
EIF_TYPE_INDEX Y2597 [1];
void Y2597_init (void)
{
	egc_routines_types [2597] = Y2597;
	egc_routines_gen_types [2597] = Y2597_gen_type;
	egc_routines_offset [2597] = 700;
	Y2597[0] = 789;
}

long O2617[8];
void O2617_init () {
	O2617[0] = 0;
	O2617[1] = + _LNGOFF_5_3_0_0_;
	O2617[2] = 0;
	O2617[3] = + _LNGOFF_4_3_0_0_;
	O2617[4] = + _PTROFF_5_3_0_7_0_0_;
	O2617[5] = 0;
	O2617[6] = + _LNGOFF_5_4_0_0_;
	O2617[7] = 0;
}

long O2626[8];
void O2626_init () {
	O2626[0] = + _LNGOFF_7_3_0_0_;
	O2626[1] = + _LNGOFF_5_3_0_1_;
	O2626[2] = + _LNGOFF_6_3_0_0_;
	O2626[3] = + _LNGOFF_4_3_0_1_;
	O2626[4] = + _LNGOFF_5_3_0_0_;
	O2626[5] = + _LNGOFF_7_4_0_0_;
	O2626[6] = + _LNGOFF_5_4_0_1_;
	O2626[7] = + _LNGOFF_9_3_0_0_;
}

long O2653[8];
void O2653_init () {
	O2653[0] =  + _REFACS_1_;
	O2653[1] = 0;
	O2653[2] =  + _REFACS_1_;
	{long i; for (i = 3; i < 5; i++) O2653[i] = 0;}
	O2653[5] =  + _REFACS_1_;
	O2653[6] = 0;
	O2653[7] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y2653_pgtype0[] = {0xFF01,606,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2653_pgtype1[] = {0xFF01,607,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2653_pgtype2[] = {0xFF01,606,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2653_pgtype3[] = {0xFF01,607,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2653_pgtype4[] = {0xFF01,615,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2653_pgtype5[] = {0xFF01,606,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2653_pgtype6[] = {0xFF01,607,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2653_pgtype7[] = {0xFF01,606,0,0xFFFF};
EIF_TYPE_INDEX *Y2653_gen_type [8];
EIF_TYPE_INDEX Y2653 [8];
void Y2653_init (void)
{
	egc_routines_types [2653] = Y2653;
	egc_routines_gen_types [2653] = Y2653_gen_type;
	egc_routines_offset [2653] = 713;
	Y2653_gen_type [0] = Y2653_pgtype0;
	Y2653_gen_type [1] = Y2653_pgtype1;
	Y2653_gen_type [2] = Y2653_pgtype2;
	Y2653_gen_type [3] = Y2653_pgtype3;
	Y2653_gen_type [4] = Y2653_pgtype4;
	Y2653_gen_type [5] = Y2653_pgtype5;
	Y2653_gen_type [6] = Y2653_pgtype6;
	Y2653_gen_type [7] = Y2653_pgtype7;
	Y2653[0] = 606;
	Y2653[1] = 607;
	Y2653[2] = 606;
	Y2653[3] = 607;
	Y2653[4] = 615;
	Y2653[5] = 606;
	Y2653[6] = 607;
	Y2653[7] = 606;
}

long O2654[8];
void O2654_init () {
	O2654[0] =  + _REFACS_2_;
	O2654[1] =  + _REFACS_1_;
	O2654[2] =  + _REFACS_2_;
	{long i; for (i = 3; i < 5; i++) O2654[i] =  + _REFACS_1_;}
	O2654[5] =  + _REFACS_2_;
	O2654[6] =  + _REFACS_1_;
	O2654[7] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y2654_pgtype0[] = {0xFF01,606,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2654_pgtype1[] = {0xFF01,606,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2654_pgtype2[] = {0xFF01,607,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2654_pgtype3[] = {0xFF01,607,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2654_pgtype4[] = {0xFF01,606,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2654_pgtype5[] = {0xFF01,606,0xFF01,864,0xFFFF};
static EIF_TYPE_INDEX Y2654_pgtype6[] = {0xFF01,606,0xFF01,864,0xFFFF};
static EIF_TYPE_INDEX Y2654_pgtype7[] = {0xFF01,606,0xFF01,872,0xFFFF};
EIF_TYPE_INDEX *Y2654_gen_type [8];
EIF_TYPE_INDEX Y2654 [8];
void Y2654_init (void)
{
	egc_routines_types [2654] = Y2654;
	egc_routines_gen_types [2654] = Y2654_gen_type;
	egc_routines_offset [2654] = 713;
	Y2654_gen_type [0] = Y2654_pgtype0;
	Y2654_gen_type [1] = Y2654_pgtype1;
	Y2654_gen_type [2] = Y2654_pgtype2;
	Y2654_gen_type [3] = Y2654_pgtype3;
	Y2654_gen_type [4] = Y2654_pgtype4;
	Y2654_gen_type [5] = Y2654_pgtype5;
	Y2654_gen_type [6] = Y2654_pgtype6;
	Y2654_gen_type [7] = Y2654_pgtype7;
	{long i; for (i = 0; i < 2; i++) Y2654[i] = 606;};
	{long i; for (i = 2; i < 4; i++) Y2654[i] = 607;};
	{long i; for (i = 4; i < 8; i++) Y2654[i] = 606;};
}

long O2655[8];
void O2655_init () {
	O2655[0] =  + _REFACS_3_;
	O2655[1] =  + _REFACS_2_;
	O2655[2] =  + _REFACS_3_;
	{long i; for (i = 3; i < 5; i++) O2655[i] =  + _REFACS_2_;}
	O2655[5] =  + _REFACS_3_;
	O2655[6] =  + _REFACS_2_;
	O2655[7] =  + _REFACS_3_;
}

long O2656[8];
void O2656_init () {
	O2656[0] =  + _REFACS_4_;
	O2656[1] =  + _REFACS_3_;
	O2656[2] =  + _REFACS_4_;
	{long i; for (i = 3; i < 5; i++) O2656[i] =  + _REFACS_3_;}
	O2656[5] =  + _REFACS_4_;
	O2656[6] =  + _REFACS_3_;
	O2656[7] =  + _REFACS_4_;
}

long O2657[8];
void O2657_init () {
	O2657[0] = + _LNGOFF_7_3_0_1_;
	O2657[1] = + _LNGOFF_5_3_0_2_;
	O2657[2] = + _LNGOFF_6_3_0_1_;
	O2657[3] = + _LNGOFF_4_3_0_2_;
	O2657[4] = + _LNGOFF_5_3_0_1_;
	O2657[5] = + _LNGOFF_7_4_0_1_;
	O2657[6] = + _LNGOFF_5_4_0_2_;
	O2657[7] = + _LNGOFF_9_3_0_1_;
}

long O2658[8];
void O2658_init () {
	O2658[0] = + _CHROFF_7_2_;
	O2658[1] = + _CHROFF_5_2_;
	O2658[2] = + _CHROFF_6_2_;
	O2658[3] = + _CHROFF_4_2_;
	O2658[4] = + _CHROFF_5_2_;
	O2658[5] = + _CHROFF_7_2_;
	O2658[6] = + _CHROFF_5_2_;
	O2658[7] = + _CHROFF_9_2_;
}

long O2659[8];
void O2659_init () {
	O2659[0] = + _LNGOFF_7_3_0_2_;
	O2659[1] = + _LNGOFF_5_3_0_3_;
	O2659[2] = + _LNGOFF_6_3_0_2_;
	O2659[3] = + _LNGOFF_4_3_0_3_;
	O2659[4] = + _LNGOFF_5_3_0_2_;
	O2659[5] = + _LNGOFF_7_4_0_2_;
	O2659[6] = + _LNGOFF_5_4_0_3_;
	O2659[7] = + _LNGOFF_9_3_0_2_;
}

long O2662[8];
void O2662_init () {
	O2662[0] = + _LNGOFF_7_3_0_3_;
	O2662[1] = + _LNGOFF_5_3_0_4_;
	O2662[2] = + _LNGOFF_6_3_0_3_;
	O2662[3] = + _LNGOFF_4_3_0_4_;
	O2662[4] = + _LNGOFF_5_3_0_3_;
	O2662[5] = + _LNGOFF_7_4_0_3_;
	O2662[6] = + _LNGOFF_5_4_0_4_;
	O2662[7] = + _LNGOFF_9_3_0_3_;
}

long O2663[8];
void O2663_init () {
	O2663[0] = + _LNGOFF_7_3_0_4_;
	O2663[1] = + _LNGOFF_5_3_0_5_;
	O2663[2] = + _LNGOFF_6_3_0_4_;
	O2663[3] = + _LNGOFF_4_3_0_5_;
	O2663[4] = + _LNGOFF_5_3_0_4_;
	O2663[5] = + _LNGOFF_7_4_0_4_;
	O2663[6] = + _LNGOFF_5_4_0_5_;
	O2663[7] = + _LNGOFF_9_3_0_4_;
}

long O2667[8];
void O2667_init () {
	O2667[0] = + _LNGOFF_7_3_0_5_;
	O2667[1] = + _LNGOFF_5_3_0_6_;
	O2667[2] = + _LNGOFF_6_3_0_5_;
	O2667[3] = + _LNGOFF_4_3_0_6_;
	O2667[4] = + _LNGOFF_5_3_0_5_;
	O2667[5] = + _LNGOFF_7_4_0_5_;
	O2667[6] = + _LNGOFF_5_4_0_6_;
	O2667[7] = + _LNGOFF_9_3_0_5_;
}

long O2668[8];
void O2668_init () {
	O2668[0] =  + _REFACS_5_;
	O2668[1] = + _LNGOFF_5_3_0_7_;
	O2668[2] =  + _REFACS_5_;
	O2668[3] = + _LNGOFF_4_3_0_7_;
	O2668[4] = + _PTROFF_5_3_0_7_0_1_;
	O2668[5] =  + _REFACS_5_;
	O2668[6] = + _LNGOFF_5_4_0_7_;
	O2668[7] =  + _REFACS_5_;
}

long O2669[8];
void O2669_init () {
	O2669[0] =  + _REFACS_6_;
	O2669[1] =  + _REFACS_4_;
	O2669[2] = + _LNGOFF_6_3_0_6_;
	O2669[3] = + _LNGOFF_4_3_0_8_;
	O2669[4] =  + _REFACS_4_;
	O2669[5] =  + _REFACS_6_;
	O2669[6] =  + _REFACS_4_;
	O2669[7] =  + _REFACS_6_;
}

long O2703[8];
void O2703_init () {
	O2703[0] = + _LNGOFF_7_3_0_6_;
	O2703[1] = + _LNGOFF_5_3_0_8_;
	O2703[2] = + _LNGOFF_6_3_0_7_;
	O2703[3] = + _LNGOFF_4_3_0_9_;
	O2703[4] = + _LNGOFF_5_3_0_6_;
	O2703[5] = + _LNGOFF_7_4_0_6_;
	O2703[6] = + _LNGOFF_5_4_0_8_;
	O2703[7] = + _LNGOFF_9_3_0_6_;
}

long O3909[104];
void O3909_init () {
	{long i; for (i = 0; i < 3; i++) O3909[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O3909[i] = + _LNGOFF_1_0_0_0_;}
	O3909[5] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 6; i < 8; i++) O3909[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 8; i < 10; i++) O3909[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 102; i < 104; i++) O3909[i] = + _LNGOFF_1_1_0_0_;}
}

long O3910[104];
void O3910_init () {
	{long i; for (i = 0; i < 3; i++) O3910[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O3910[i] = + _LNGOFF_1_0_0_1_;}
	O3910[5] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 6; i < 8; i++) O3910[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 8; i < 10; i++) O3910[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 102; i < 104; i++) O3910[i] = + _LNGOFF_1_1_0_1_;}
}

long O3975[3];
void O3975_init () {
	{long i; for (i = 0; i < 2; i++) O3975[i] = + _LNGOFF_1_0_0_2_;}
	O3975[2] = + _LNGOFF_1_1_0_2_;
}

long O4055[98];
void O4055_init () {
	{long i; for (i = 0; i < 2; i++) O4055[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O4055[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 96; i < 98; i++) O4055[i] = + _LNGOFF_1_1_0_2_;}
}

long O4461[11];
void O4461_init () {
	{long i; for (i = 0; i < 2; i++) O4461[i] = 0;}
	O4461[2] =  + _REFACS_5_;
	{long i; for (i = 3; i < 6; i++) O4461[i] =  + _REFACS_4_;}
	O4461[6] = 0;
	O4461[7] =  + _REFACS_4_;
	{long i; for (i = 8; i < 11; i++) O4461[i] =  + _REFACS_3_;}
}

static EIF_TYPE_INDEX Y4576_pgtype0[] = {0xFF01,940,0xFFF8,1,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y4576_gen_type [1];
EIF_TYPE_INDEX Y4576 [1];
void Y4576_init (void)
{
	egc_routines_types [4576] = Y4576;
	egc_routines_gen_types [4576] = Y4576_gen_type;
	egc_routines_offset [4576] = 933;
	Y4576_gen_type [0] = Y4576_pgtype0;
	Y4576[0] = 940;
}

static EIF_TYPE_INDEX Y4676_pgtype0[] = {163,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4676_pgtype1[] = {163,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4676_pgtype2[] = {163,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y4676_gen_type [3];
EIF_TYPE_INDEX Y4676 [3];
void Y4676_init (void)
{
	egc_routines_types [4676] = Y4676;
	egc_routines_gen_types [4676] = Y4676_gen_type;
	egc_routines_offset [4676] = 940;
	Y4676_gen_type [0] = Y4676_pgtype0;
	Y4676_gen_type [1] = Y4676_pgtype1;
	Y4676_gen_type [2] = Y4676_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y4676[i] = 163;};
}

static EIF_TYPE_INDEX Y4682_pgtype0[] = {0xFF01,12,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4682_pgtype1[] = {0xFF01,12,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y4682_gen_type [2];
EIF_TYPE_INDEX Y4682 [2];
void Y4682_init (void)
{
	egc_routines_types [4682] = Y4682;
	egc_routines_gen_types [4682] = Y4682_gen_type;
	egc_routines_offset [4682] = 941;
	Y4682_gen_type [0] = Y4682_pgtype0;
	Y4682_gen_type [1] = Y4682_pgtype1;
	{long i; for (i = 0; i < 2; i++) Y4682[i] = 12;};
}


#ifdef __cplusplus
}
#endif
