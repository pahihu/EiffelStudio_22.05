#include "epoly1.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R11[966])();
void R11_init () {
	R11[0] = (char *(*)()) F1_8;
	R11[2] = (char *(*)()) F1_8;
	{long i; for (i = 9; i < 16; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 18; i < 21; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 33; i < 35; i++) R11[i] = (char *(*)()) F1_8;}
	R11[46] = (char *(*)()) F1_8;
	R11[57] = (char *(*)()) F1_8;
	{long i; for (i = 69; i < 75; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 91; i < 93; i++) R11[i] = (char *(*)()) F1_8;}
	R11[94] = (char *(*)()) F1_8;
	R11[96] = (char *(*)()) F1_8;
	{long i; for (i = 104; i < 106; i++) R11[i] = (char *(*)()) F1_8;}
	R11[113] = (char *(*)()) F1_8;
	R11[116] = (char *(*)()) F1_8;
	{long i; for (i = 120; i < 124; i++) R11[i] = (char *(*)()) F1_8;}
	R11[127] = (char *(*)()) F1_8;
	{long i; for (i = 129; i < 132; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 133; i < 135; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 137; i < 139; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 140; i < 143; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 144; i < 148; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 149; i < 151; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 152; i < 155; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 156; i < 164; i++) R11[i] = (char *(*)()) F1_8;}
	R11[166] = (char *(*)()) F168_1404;
	R11[168] = (char *(*)()) F1_8;
	R11[172] = (char *(*)()) F1_8;
	R11[190] = (char *(*)()) F192_1779;
	R11[191] = (char *(*)()) F1_8;
	R11[193] = (char *(*)()) F195_1924;
	{long i; for (i = 197; i < 199; i++) R11[i] = (char *(*)()) F1_8;}
	R11[283] = (char *(*)()) F1_8;
	R11[286] = (char *(*)()) F1_8;
	{long i; for (i = 330; i < 335; i++) R11[i] = (char *(*)()) F1_8;}
	R11[527] = (char *(*)()) F1_8;
	{long i; for (i = 605; i < 617; i++) R11[i] = (char *(*)()) F1_8;}
	R11[630] = (char *(*)()) F632_3040;
	R11[631] = (char *(*)()) F633_3040;
	R11[632] = (char *(*)()) F634_3040;
	R11[633] = (char *(*)()) F635_3040;
	R11[634] = (char *(*)()) F636_3040;
	R11[635] = (char *(*)()) F637_3040;
	R11[636] = (char *(*)()) F638_3040;
	R11[637] = (char *(*)()) F639_3040;
	R11[638] = (char *(*)()) F640_3040;
	R11[639] = (char *(*)()) F641_3040;
	R11[640] = (char *(*)()) F642_3040;
	R11[641] = (char *(*)()) F643_3040;
	R11[712] = (char *(*)()) F714_3304;
	R11[713] = (char *(*)()) F715_3304;
	R11[714] = (char *(*)()) F716_3304;
	R11[715] = (char *(*)()) F717_3304;
	R11[716] = (char *(*)()) F718_3304;
	R11[719] = (char *(*)()) F714_3304;
	R11[721] = (char *(*)()) F1_8;
	{long i; for (i = 727; i < 729; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 734; i < 742; i++) R11[i] = (char *(*)()) F1_8;}
	R11[743] = (char *(*)()) F1_8;
	{long i; for (i = 746; i < 748; i++) R11[i] = (char *(*)()) F1_8;}
	R11[753] = (char *(*)()) F755_3730;
	R11[754] = (char *(*)()) F756_3767;
	R11[755] = (char *(*)()) F757_3767;
	R11[756] = (char *(*)()) F758_3767;
	R11[757] = (char *(*)()) F759_3767;
	R11[758] = (char *(*)()) F760_3767;
	R11[759] = (char *(*)()) F761_3767;
	R11[760] = (char *(*)()) F762_3767;
	R11[761] = (char *(*)()) F763_3767;
	R11[762] = (char *(*)()) F764_3767;
	R11[763] = (char *(*)()) F765_3767;
	R11[764] = (char *(*)()) F766_3767;
	R11[765] = (char *(*)()) F767_3767;
	R11[766] = (char *(*)()) F768_3767;
	R11[767] = (char *(*)()) F769_3767;
	R11[768] = (char *(*)()) F770_3767;
	R11[769] = (char *(*)()) F771_3767;
	R11[770] = (char *(*)()) F772_3767;
	R11[771] = (char *(*)()) F773_3767;
	R11[772] = (char *(*)()) F774_3767;
	R11[773] = (char *(*)()) F775_3767;
	R11[774] = (char *(*)()) F776_3767;
	R11[775] = (char *(*)()) F777_3767;
	R11[776] = (char *(*)()) F778_3767;
	R11[777] = (char *(*)()) F779_3767;
	R11[778] = (char *(*)()) F780_3767;
	R11[779] = (char *(*)()) F781_3767;
	R11[780] = (char *(*)()) F782_3767;
	R11[781] = (char *(*)()) F783_3767;
	R11[782] = (char *(*)()) F784_3767;
	R11[783] = (char *(*)()) F785_3767;
	R11[784] = (char *(*)()) F786_3767;
	R11[785] = (char *(*)()) F787_3810;
	{long i; for (i = 787; i < 789; i++) R11[i] = (char *(*)()) F788_3928;}
	{long i; for (i = 790; i < 792; i++) R11[i] = (char *(*)()) F791_4027;}
	{long i; for (i = 793; i < 795; i++) R11[i] = (char *(*)()) F794_4126;}
	{long i; for (i = 796; i < 798; i++) R11[i] = (char *(*)()) F797_4225;}
	{long i; for (i = 799; i < 801; i++) R11[i] = (char *(*)()) F800_4319;}
	{long i; for (i = 802; i < 804; i++) R11[i] = (char *(*)()) F803_4413;}
	{long i; for (i = 805; i < 807; i++) R11[i] = (char *(*)()) F806_4508;}
	{long i; for (i = 808; i < 810; i++) R11[i] = (char *(*)()) F809_4607;}
	{long i; for (i = 811; i < 813; i++) R11[i] = (char *(*)()) F812_4673;}
	{long i; for (i = 814; i < 816; i++) R11[i] = (char *(*)()) F815_4734;}
	{long i; for (i = 817; i < 819; i++) R11[i] = (char *(*)()) F818_4774;}
	{long i; for (i = 820; i < 822; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 823; i < 825; i++) R11[i] = (char *(*)()) F824_4846;}
	{long i; for (i = 826; i < 858; i++) R11[i] = (char *(*)()) F827_4938;}
	{long i; for (i = 867; i < 869; i++) R11[i] = (char *(*)()) F868_5174;}
	{long i; for (i = 870; i < 872; i++) R11[i] = (char *(*)()) F871_5342;}
	{long i; for (i = 873; i < 879; i++) R11[i] = (char *(*)()) F1_8;}
	R11[899] = (char *(*)()) F890_5820;
	R11[904] = (char *(*)()) F1_8;
	R11[907] = (char *(*)()) F1_8;
	R11[912] = (char *(*)()) F1_8;
	R11[936] = (char *(*)()) F938_6217;
	R11[937] = (char *(*)()) F939_6217;
	R11[941] = (char *(*)()) F941_6349;
	R11[943] = (char *(*)()) F1_8;
	{long i; for (i = 946; i < 948; i++) R11[i] = (char *(*)()) F1_8;}
	R11[949] = (char *(*)()) F1_8;
	R11[954] = (char *(*)()) F1_8;
	{long i; for (i = 956; i < 963; i++) R11[i] = (char *(*)()) F1_8;}
	R11[964] = (char *(*)()) F965_6867;
	R11[965] = (char *(*)()) F967_6932;
}

char *(*R237[5])();
void R237_init () {
	R237[0] = (char *(*)()) F13_233;
	R237[1] = (char *(*)()) F14_233;
	R237[2] = (char *(*)()) F15_233;
	R237[3] = (char *(*)()) F16_233;
	R237[4] = (char *(*)()) F17_233;
}

char *(*R242[5])();
void R242_init () {
	R242[0] = (char *(*)()) F13_238;
	R242[1] = (char *(*)()) F14_238_242_30;
	R242[2] = (char *(*)()) F15_238_242_30;
	R242[3] = (char *(*)()) F16_238_242_30;
	R242[4] = (char *(*)()) F17_238_242_30;
}
static void F14_238_242_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F14_238(Current, arg1, *(EIF_INTEGER_32 *)arg2, arg3);
}
static void F15_238_242_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F15_238(Current, arg1, *(EIF_BOOLEAN *)arg2, arg3);
}
static void F16_238_242_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F16_238(Current, arg1, *(EIF_NATURAL_32 *)arg2, arg3);
}
static void F17_238_242_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F17_238(Current, arg1, *(EIF_CHARACTER_8 *)arg2, arg3);
}

char *(*R245[5])();
void R245_init () {
	R245[0] = (char *(*)()) F13_241;
	R245[1] = (char *(*)()) F14_241;
	R245[2] = (char *(*)()) F15_241;
	R245[3] = (char *(*)()) F16_241;
	R245[4] = (char *(*)()) F17_241;
}

char *(*R659[239])();
void R659_init () {
	R659[0] = (char *(*)()) F729_3441;
	R659[1] = (char *(*)()) F730_3449;
	R659[180] = (char *(*)()) F908_5991;
	R659[238] = (char *(*)()) F967_6947;
}

char *(*R825[4])();
void R825_init () {
	R825[0] = (char *(*)()) F73_829;
	R825[1] = (char *(*)()) F74_829_825_1;
	R825[2] = (char *(*)()) F75_829_825_1;
	R825[3] = (char *(*)()) F76_829_825_1;
}
static EIF_REFERENCE F74_829_825_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F74_829(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F75_829_825_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F75_829(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(816, 0x00).id, 816, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F76_829_825_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F76_829(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(798, 0x00).id, 798, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y835_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y835_pgtype1[] = {0xFF01,872,0xFFFF};
static EIF_TYPE_INDEX Y835_pgtype2[] = {0xFF01,872,0xFFFF};
static EIF_TYPE_INDEX Y835_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y835_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y835_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y835_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y835_pgtype7[] = {0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y835_gen_type [864];
EIF_TYPE_INDEX Y835 [864];
void Y835_init (void)
{
	egc_routines_types [835] = Y835;
	egc_routines_gen_types [835] = Y835_gen_type;
	egc_routines_offset [835] = 79;
	Y835_gen_type [0] = Y835_pgtype0;
	Y835_gen_type [664] = Y835_pgtype1;
	Y835_gen_type [665] = Y835_pgtype2;
	Y835_gen_type [840] = Y835_pgtype3;
	Y835_gen_type [855] = Y835_pgtype4;
	Y835_gen_type [861] = Y835_pgtype5;
	Y835_gen_type [862] = Y835_pgtype6;
	Y835_gen_type [863] = Y835_pgtype7;
	{long i; for (i = 664; i < 666; i++) Y835[i] = 872;};
}

char *(*R856[9])();
void R856_init () {
	R856[0] = (char *(*)()) F906_5933;
	R856[3] = (char *(*)()) F908_5990;
	R856[8] = (char *(*)()) F913_6016;
}

char *(*R871[167])();
void R871_init () {
	R871[0] = (char *(*)()) F748_3651;
	R871[1] = (char *(*)()) F749_3669;
	R871[166] = (char *(*)()) F913_6018;
}

char *(*R874[167])();
void R874_init () {
	{long i; for (i = 0; i < 2; i++) R874[i] = (char *(*)()) F88_878;}
	R874[158] = (char *(*)()) F85_864;
	R874[166] = (char *(*)()) F85_864;
}

char *(*R877[167])();
void R877_init () {
	R877[0] = (char *(*)()) F748_3650;
	R877[1] = (char *(*)()) F749_3663;
	R877[166] = (char *(*)()) F750_3677;
}

char *(*R879[167])();
void R879_init () {
	R879[0] = (char *(*)()) F748_3645;
	R879[1] = (char *(*)()) F749_3665;
	R879[158] = (char *(*)()) F906_5929;
	R879[166] = (char *(*)()) F907_5961;
}

char *(*R880[167])();
void R880_init () {
	R880[0] = (char *(*)()) F748_3646_880_1;
	R880[1] = (char *(*)()) F749_3666_880_1;
	R880[158] = (char *(*)()) F906_5930;
	R880[166] = (char *(*)()) F914_6035_880_1;
}
static EIF_REFERENCE F748_3646_880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F748_3646(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(819, 0x00).id, 819, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F749_3666_880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F749_3666(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(819, 0x00).id, 819, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F914_6035_880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F914_6035(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(819, 0x00).id, 819, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R881[167])();
void R881_init () {
	{long i; for (i = 0; i < 2; i++) R881[i] = (char *(*)()) F88_885;}
	R881[166] = (char *(*)()) F913_6024;
}

char *(*R1036[213])();
void R1036_init () {
	R1036[0] = (char *(*)()) F755_3729;
	R1036[34] = (char *(*)()) F789_3990_1036_2;
	R1036[35] = (char *(*)()) F790_3990_1036_2;
	R1036[37] = (char *(*)()) F792_4089_1036_2;
	R1036[38] = (char *(*)()) F793_4089_1036_2;
	R1036[40] = (char *(*)()) F795_4188_1036_2;
	R1036[41] = (char *(*)()) F796_4188_1036_2;
	R1036[43] = (char *(*)()) F798_4283_1036_2;
	R1036[44] = (char *(*)()) F799_4283_1036_2;
	R1036[46] = (char *(*)()) F801_4377_1036_2;
	R1036[47] = (char *(*)()) F802_4377_1036_2;
	R1036[49] = (char *(*)()) F804_4472_1036_2;
	R1036[50] = (char *(*)()) F805_4472_1036_2;
	R1036[52] = (char *(*)()) F807_4567_1036_2;
	R1036[53] = (char *(*)()) F808_4567_1036_2;
	R1036[55] = (char *(*)()) F810_4636_1036_2;
	R1036[56] = (char *(*)()) F811_4636_1036_2;
	R1036[58] = (char *(*)()) F813_4702_1036_2;
	R1036[59] = (char *(*)()) F814_4702_1036_2;
	{long i; for (i = 61; i < 63; i++) R1036[i] = (char *(*)()) F815_4733;}
	{long i; for (i = 64; i < 66; i++) R1036[i] = (char *(*)()) F818_4773;}
	R1036[70] = (char *(*)()) F825_4907_1036_2;
	R1036[71] = (char *(*)()) F826_4907_1036_2;
	{long i; for (i = 114; i < 116; i++) R1036[i] = (char *(*)()) F868_5179;}
	{long i; for (i = 117; i < 119; i++) R1036[i] = (char *(*)()) F871_5347;}
	R1036[212] = (char *(*)()) F967_6933;
}
static EIF_BOOLEAN F789_3990_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F789_3990(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F790_3990_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F790_3990(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F792_4089_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F792_4089(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F793_4089_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F793_4089(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F795_4188_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F795_4188(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F796_4188_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F796_4188(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F798_4283_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F798_4283(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F799_4283_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F799_4283(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F801_4377_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F801_4377(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F802_4377_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F802_4377(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F804_4472_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F804_4472(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F805_4472_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F805_4472(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F807_4567_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F807_4567(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F808_4567_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F808_4567(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F810_4636_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F810_4636(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F811_4636_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F811_4636(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F813_4702_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F813_4702(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F814_4702_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F814_4702(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F825_4907_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F825_4907(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F826_4907_1036_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F826_4907(Current, *(EIF_INTEGER_64 *)arg1);
}

char *(*R1128[4])();
void R1128_init () {
	R1128[0] = (char *(*)()) F115_1185;
	R1128[3] = (char *(*)()) F118_1213;
}

char *(*R1199[40])();
void R1199_init () {
	R1199[0] = (char *(*)()) F124_1277;
	R1199[1] = (char *(*)()) F125_1301;
	R1199[5] = (char *(*)()) F129_1304;
	R1199[7] = (char *(*)()) F131_1308;
	R1199[8] = (char *(*)()) F132_1325;
	R1199[9] = (char *(*)()) F133_1329;
	R1199[11] = (char *(*)()) F135_1333;
	R1199[12] = (char *(*)()) F136_1335;
	R1199[15] = (char *(*)()) F139_1339;
	R1199[16] = (char *(*)()) F140_1343;
	R1199[18] = (char *(*)()) F142_1345;
	R1199[19] = (char *(*)()) F143_1347;
	R1199[20] = (char *(*)()) F144_1349;
	R1199[22] = (char *(*)()) F146_1355;
	R1199[23] = (char *(*)()) F147_1357;
	R1199[24] = (char *(*)()) F148_1359;
	R1199[25] = (char *(*)()) F149_1363;
	R1199[27] = (char *(*)()) F151_1367;
	R1199[28] = (char *(*)()) F152_1369;
	R1199[30] = (char *(*)()) F154_1371;
	R1199[31] = (char *(*)()) F155_1373;
	R1199[32] = (char *(*)()) F156_1375;
	R1199[34] = (char *(*)()) F158_1377;
	R1199[35] = (char *(*)()) F159_1379;
	R1199[36] = (char *(*)()) F160_1381;
	R1199[37] = (char *(*)()) F161_1383;
	R1199[38] = (char *(*)()) F162_1385;
	R1199[39] = (char *(*)()) F163_1387;
}

char *(*R1258[560])();
void R1258_init () {
	R1258[0] = (char *(*)()) F164_1391;
	R1258[1] = (char *(*)()) F165_1391_1258_3;
	R1258[559] = (char *(*)()) F723_3413;
}
static EIF_BOOLEAN F165_1391_1258_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F165_1391(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R1611[773])();
void R1611_init () {
	R1611[0] = (char *(*)()) F183_1755;
	R1611[437] = (char *(*)()) F179_1755;
	R1611[438] = (char *(*)()) F180_1755;
	R1611[439] = (char *(*)()) F181_1755;
	R1611[440] = (char *(*)()) F182_1755;
	R1611[441] = (char *(*)()) F183_1755;
	R1611[442] = (char *(*)()) F184_1755;
	R1611[443] = (char *(*)()) F185_1755;
	R1611[444] = (char *(*)()) F186_1755;
	R1611[445] = (char *(*)()) F187_1755;
	R1611[446] = (char *(*)()) F188_1755;
	R1611[447] = (char *(*)()) F189_1755;
	R1611[448] = (char *(*)()) F190_1755;
	R1611[675] = (char *(*)()) F187_1755;
	R1611[678] = (char *(*)()) F186_1755;
	R1611[772] = (char *(*)()) F186_1755;
}

char *(*R1612[773])();
void R1612_init () {
	R1612[0] = (char *(*)()) F183_1756_1612_117;
	R1612[437] = (char *(*)()) F179_1756;
	R1612[438] = (char *(*)()) F180_1756_1612_117;
	R1612[439] = (char *(*)()) F181_1756_1612_117;
	R1612[440] = (char *(*)()) F182_1756_1612_117;
	R1612[441] = (char *(*)()) F183_1756_1612_117;
	R1612[442] = (char *(*)()) F184_1756_1612_117;
	R1612[443] = (char *(*)()) F185_1756_1612_117;
	R1612[444] = (char *(*)()) F186_1756_1612_117;
	R1612[445] = (char *(*)()) F187_1756_1612_117;
	R1612[446] = (char *(*)()) F188_1756_1612_117;
	R1612[447] = (char *(*)()) F189_1756_1612_117;
	R1612[448] = (char *(*)()) F190_1756_1612_117;
	R1612[675] = (char *(*)()) F187_1756_1612_117;
	R1612[678] = (char *(*)()) F186_1756_1612_117;
	R1612[772] = (char *(*)()) F186_1756_1612_117;
}
static void F183_1756_1612_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F183_1756(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F180_1756_1612_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F180_1756(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F181_1756_1612_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F181_1756(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F182_1756_1612_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F182_1756(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F184_1756_1612_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F184_1756(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F185_1756_1612_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F185_1756(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F186_1756_1612_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F186_1756(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F187_1756_1612_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F187_1756(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F188_1756_1612_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F188_1756(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F189_1756_1612_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F189_1756(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F190_1756_1612_117 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F190_1756(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R1618[773])();
void R1618_init () {
	R1618[0] = (char *(*)()) F183_1762;
	R1618[437] = (char *(*)()) F179_1762;
	R1618[438] = (char *(*)()) F180_1762;
	R1618[439] = (char *(*)()) F181_1762;
	R1618[440] = (char *(*)()) F182_1762;
	R1618[441] = (char *(*)()) F183_1762;
	R1618[442] = (char *(*)()) F184_1762;
	R1618[443] = (char *(*)()) F185_1762;
	R1618[444] = (char *(*)()) F186_1762;
	R1618[445] = (char *(*)()) F187_1762;
	R1618[446] = (char *(*)()) F188_1762;
	R1618[447] = (char *(*)()) F189_1762;
	R1618[448] = (char *(*)()) F190_1762;
	R1618[675] = (char *(*)()) F187_1762;
	R1618[678] = (char *(*)()) F186_1762;
	R1618[772] = (char *(*)()) F186_1762;
}

char *(*R1869[35])();
void R1869_init () {
	R1869[0] = (char *(*)()) F880_5491;
	R1869[29] = (char *(*)()) F592_2620;
	R1869[34] = (char *(*)()) F592_2620;
}

char *(*R1882[35])();
void R1882_init () {
	R1882[0] = (char *(*)()) F880_5514;
	R1882[29] = (char *(*)()) F592_2694;
	R1882[34] = (char *(*)()) F592_2694;
}

char *(*R1884[35])();
void R1884_init () {
	R1884[0] = (char *(*)()) F880_5512;
	R1884[29] = (char *(*)()) F592_2697;
	R1884[34] = (char *(*)()) F592_2697;
}

char *(*R1912[35])();
void R1912_init () {
	R1912[0] = (char *(*)()) F880_5509;
	R1912[29] = (char *(*)()) F592_2727;
	R1912[34] = (char *(*)()) F592_2727;
}

char *(*R1925[35])();
void R1925_init () {
	R1925[0] = (char *(*)()) F880_5503;
	R1925[29] = (char *(*)()) F592_2734;
	R1925[34] = (char *(*)()) F592_2734;
}

char *(*R1993[12])();
void R1993_init () {
	R1993[0] = (char *(*)()) F607_2949;
	R1993[1] = (char *(*)()) F608_2949;
	R1993[2] = (char *(*)()) F609_2949;
	R1993[3] = (char *(*)()) F610_2949;
	R1993[4] = (char *(*)()) F611_2949;
	R1993[5] = (char *(*)()) F612_2949;
	R1993[6] = (char *(*)()) F613_2949;
	R1993[7] = (char *(*)()) F614_2949;
	R1993[8] = (char *(*)()) F615_2949;
	R1993[9] = (char *(*)()) F616_2949;
	R1993[10] = (char *(*)()) F617_2949;
	R1993[11] = (char *(*)()) F618_2949;
}

char *(*R1994[12])();
void R1994_init () {
	R1994[0] = (char *(*)()) F607_2950;
	R1994[1] = (char *(*)()) F608_2950;
	R1994[2] = (char *(*)()) F609_2950;
	R1994[3] = (char *(*)()) F610_2950;
	R1994[4] = (char *(*)()) F611_2950;
	R1994[5] = (char *(*)()) F612_2950;
	R1994[6] = (char *(*)()) F613_2950;
	R1994[7] = (char *(*)()) F614_2950;
	R1994[8] = (char *(*)()) F615_2950;
	R1994[9] = (char *(*)()) F616_2950;
	R1994[10] = (char *(*)()) F617_2950;
	R1994[11] = (char *(*)()) F618_2950;
}

char *(*R2043[5])();
void R2043_init () {
	R2043[0] = (char *(*)()) F332_2402;
	R2043[1] = (char *(*)()) F333_2402_2043_1;
	R2043[2] = (char *(*)()) F334_2402;
	R2043[3] = (char *(*)()) F335_2402_2043_1;
	R2043[4] = (char *(*)()) F336_2402_2043_1;
}
static EIF_REFERENCE F333_2402_2043_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F333_2402(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F335_2402_2043_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F335_2402(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F336_2402_2043_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F336_2402(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(858, 0x00).id, 858, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R2044[570])();
void R2044_init () {
	R2044[0] = (char *(*)()) F332_2405;
	R2044[1] = (char *(*)()) F333_2405;
	R2044[2] = (char *(*)()) F334_2405;
	R2044[3] = (char *(*)()) F335_2405;
	R2044[4] = (char *(*)()) F336_2405;
	R2044[197] = (char *(*)()) F528_2531;
	R2044[569] = (char *(*)()) F898_5856;
}

char *(*R2045[570])();
void R2045_init () {
	R2045[0] = (char *(*)()) F332_2406;
	R2045[1] = (char *(*)()) F333_2406;
	R2045[2] = (char *(*)()) F334_2406;
	R2045[3] = (char *(*)()) F335_2406;
	R2045[4] = (char *(*)()) F336_2406;
	R2045[197] = (char *(*)()) F528_2537;
	R2045[569] = (char *(*)()) F893_5831;
}

char *(*R2056[5])();
void R2056_init () {
	R2056[0] = (char *(*)()) F332_2403;
	R2056[1] = (char *(*)()) F333_2403;
	R2056[2] = (char *(*)()) F334_2403_2056_1;
	R2056[3] = (char *(*)()) F335_2403_2056_1;
	R2056[4] = (char *(*)()) F336_2403;
}
static EIF_REFERENCE F334_2403_2056_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F334_2403(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F335_2403_2056_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F335_2403(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2076[8])();
void R2076_init () {
	R2076[0] = (char *(*)()) F714_3296;
	R2076[1] = (char *(*)()) F715_3296;
	R2076[2] = (char *(*)()) F716_3296;
	R2076[3] = (char *(*)()) F717_3296;
	R2076[4] = (char *(*)()) F718_3296;
	R2076[7] = (char *(*)()) F714_3296;
}

static EIF_TYPE_INDEX Y2077_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype12[] = {0xFF01,868,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype13[] = {816,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype14[] = {0xFF01,872,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype15[] = {0xFF01,872,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype88[] = {816,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype89[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype256[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype319[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype320[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype321[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype358[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype364[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype365[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype382[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype446[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype447[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype448[] = {816,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype449[] = {816,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype450[] = {816,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype451[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype452[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype453[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype454[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype455[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype456[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype457[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype459[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype465[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype466[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype467[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype468[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype469[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype470[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype471[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype472[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype473[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype474[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype475[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype476[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype477[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype478[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype479[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype480[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype481[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype482[] = {819,0xFFFF};
static EIF_TYPE_INDEX Y2077_pgtype483[] = {819,0xFFFF};
EIF_TYPE_INDEX *Y2077_gen_type [696];
EIF_TYPE_INDEX Y2077 [696];
void Y2077_init (void)
{
	egc_routines_types [2077] = Y2077;
	egc_routines_gen_types [2077] = Y2077_gen_type;
	egc_routines_offset [2077] = 272;
	Y2077_gen_type [0] = Y2077_pgtype0;
	Y2077_gen_type [1] = Y2077_pgtype1;
	Y2077_gen_type [2] = Y2077_pgtype2;
	Y2077_gen_type [3] = Y2077_pgtype3;
	Y2077_gen_type [4] = Y2077_pgtype4;
	Y2077_gen_type [5] = Y2077_pgtype5;
	Y2077_gen_type [6] = Y2077_pgtype6;
	Y2077_gen_type [7] = Y2077_pgtype7;
	Y2077_gen_type [8] = Y2077_pgtype8;
	Y2077_gen_type [9] = Y2077_pgtype9;
	Y2077_gen_type [10] = Y2077_pgtype10;
	Y2077_gen_type [11] = Y2077_pgtype11;
	Y2077_gen_type [12] = Y2077_pgtype12;
	Y2077_gen_type [13] = Y2077_pgtype13;
	Y2077_gen_type [14] = Y2077_pgtype14;
	Y2077_gen_type [15] = Y2077_pgtype15;
	Y2077_gen_type [16] = Y2077_pgtype16;
	Y2077_gen_type [17] = Y2077_pgtype17;
	Y2077_gen_type [18] = Y2077_pgtype18;
	Y2077_gen_type [19] = Y2077_pgtype19;
	Y2077_gen_type [20] = Y2077_pgtype20;
	Y2077_gen_type [21] = Y2077_pgtype21;
	Y2077_gen_type [22] = Y2077_pgtype22;
	Y2077_gen_type [23] = Y2077_pgtype23;
	Y2077_gen_type [24] = Y2077_pgtype24;
	Y2077_gen_type [25] = Y2077_pgtype25;
	Y2077_gen_type [26] = Y2077_pgtype26;
	Y2077_gen_type [27] = Y2077_pgtype27;
	Y2077_gen_type [28] = Y2077_pgtype28;
	Y2077_gen_type [29] = Y2077_pgtype29;
	Y2077_gen_type [30] = Y2077_pgtype30;
	Y2077_gen_type [31] = Y2077_pgtype31;
	Y2077_gen_type [32] = Y2077_pgtype32;
	Y2077_gen_type [33] = Y2077_pgtype33;
	Y2077_gen_type [34] = Y2077_pgtype34;
	Y2077_gen_type [35] = Y2077_pgtype35;
	Y2077_gen_type [36] = Y2077_pgtype36;
	Y2077_gen_type [37] = Y2077_pgtype37;
	Y2077_gen_type [38] = Y2077_pgtype38;
	Y2077_gen_type [39] = Y2077_pgtype39;
	Y2077_gen_type [40] = Y2077_pgtype40;
	Y2077_gen_type [41] = Y2077_pgtype41;
	Y2077_gen_type [42] = Y2077_pgtype42;
	Y2077_gen_type [43] = Y2077_pgtype43;
	Y2077_gen_type [44] = Y2077_pgtype44;
	Y2077_gen_type [45] = Y2077_pgtype45;
	Y2077_gen_type [46] = Y2077_pgtype46;
	Y2077_gen_type [47] = Y2077_pgtype47;
	Y2077_gen_type [48] = Y2077_pgtype48;
	Y2077_gen_type [49] = Y2077_pgtype49;
	Y2077_gen_type [50] = Y2077_pgtype50;
	Y2077_gen_type [51] = Y2077_pgtype51;
	Y2077_gen_type [52] = Y2077_pgtype52;
	Y2077_gen_type [53] = Y2077_pgtype53;
	Y2077_gen_type [54] = Y2077_pgtype54;
	Y2077_gen_type [55] = Y2077_pgtype55;
	Y2077_gen_type [56] = Y2077_pgtype56;
	Y2077_gen_type [57] = Y2077_pgtype57;
	Y2077_gen_type [58] = Y2077_pgtype58;
	Y2077_gen_type [59] = Y2077_pgtype59;
	Y2077_gen_type [60] = Y2077_pgtype60;
	Y2077_gen_type [61] = Y2077_pgtype61;
	Y2077_gen_type [62] = Y2077_pgtype62;
	Y2077_gen_type [63] = Y2077_pgtype63;
	Y2077_gen_type [64] = Y2077_pgtype64;
	Y2077_gen_type [65] = Y2077_pgtype65;
	Y2077_gen_type [66] = Y2077_pgtype66;
	Y2077_gen_type [67] = Y2077_pgtype67;
	Y2077_gen_type [68] = Y2077_pgtype68;
	Y2077_gen_type [69] = Y2077_pgtype69;
	Y2077_gen_type [70] = Y2077_pgtype70;
	Y2077_gen_type [71] = Y2077_pgtype71;
	Y2077_gen_type [72] = Y2077_pgtype72;
	Y2077_gen_type [73] = Y2077_pgtype73;
	Y2077_gen_type [74] = Y2077_pgtype74;
	Y2077_gen_type [75] = Y2077_pgtype75;
	Y2077_gen_type [76] = Y2077_pgtype76;
	Y2077_gen_type [77] = Y2077_pgtype77;
	Y2077_gen_type [78] = Y2077_pgtype78;
	Y2077_gen_type [79] = Y2077_pgtype79;
	Y2077_gen_type [80] = Y2077_pgtype80;
	Y2077_gen_type [81] = Y2077_pgtype81;
	Y2077_gen_type [82] = Y2077_pgtype82;
	Y2077_gen_type [83] = Y2077_pgtype83;
	Y2077_gen_type [84] = Y2077_pgtype84;
	Y2077_gen_type [85] = Y2077_pgtype85;
	Y2077_gen_type [86] = Y2077_pgtype86;
	Y2077_gen_type [87] = Y2077_pgtype87;
	Y2077_gen_type [88] = Y2077_pgtype88;
	Y2077_gen_type [89] = Y2077_pgtype89;
	Y2077_gen_type [90] = Y2077_pgtype90;
	Y2077_gen_type [91] = Y2077_pgtype91;
	Y2077_gen_type [92] = Y2077_pgtype92;
	Y2077_gen_type [93] = Y2077_pgtype93;
	Y2077_gen_type [94] = Y2077_pgtype94;
	Y2077_gen_type [95] = Y2077_pgtype95;
	Y2077_gen_type [96] = Y2077_pgtype96;
	Y2077_gen_type [97] = Y2077_pgtype97;
	Y2077_gen_type [98] = Y2077_pgtype98;
	Y2077_gen_type [99] = Y2077_pgtype99;
	Y2077_gen_type [100] = Y2077_pgtype100;
	Y2077_gen_type [101] = Y2077_pgtype101;
	Y2077_gen_type [102] = Y2077_pgtype102;
	Y2077_gen_type [103] = Y2077_pgtype103;
	Y2077_gen_type [104] = Y2077_pgtype104;
	Y2077_gen_type [105] = Y2077_pgtype105;
	Y2077_gen_type [106] = Y2077_pgtype106;
	Y2077_gen_type [107] = Y2077_pgtype107;
	Y2077_gen_type [108] = Y2077_pgtype108;
	Y2077_gen_type [109] = Y2077_pgtype109;
	Y2077_gen_type [110] = Y2077_pgtype110;
	Y2077_gen_type [111] = Y2077_pgtype111;
	Y2077_gen_type [112] = Y2077_pgtype112;
	Y2077_gen_type [113] = Y2077_pgtype113;
	Y2077_gen_type [114] = Y2077_pgtype114;
	Y2077_gen_type [115] = Y2077_pgtype115;
	Y2077_gen_type [116] = Y2077_pgtype116;
	Y2077_gen_type [117] = Y2077_pgtype117;
	Y2077_gen_type [118] = Y2077_pgtype118;
	Y2077_gen_type [119] = Y2077_pgtype119;
	Y2077_gen_type [120] = Y2077_pgtype120;
	Y2077_gen_type [121] = Y2077_pgtype121;
	Y2077_gen_type [122] = Y2077_pgtype122;
	Y2077_gen_type [123] = Y2077_pgtype123;
	Y2077_gen_type [124] = Y2077_pgtype124;
	Y2077_gen_type [125] = Y2077_pgtype125;
	Y2077_gen_type [126] = Y2077_pgtype126;
	Y2077_gen_type [127] = Y2077_pgtype127;
	Y2077_gen_type [128] = Y2077_pgtype128;
	Y2077_gen_type [129] = Y2077_pgtype129;
	Y2077_gen_type [130] = Y2077_pgtype130;
	Y2077_gen_type [131] = Y2077_pgtype131;
	Y2077_gen_type [132] = Y2077_pgtype132;
	Y2077_gen_type [133] = Y2077_pgtype133;
	Y2077_gen_type [134] = Y2077_pgtype134;
	Y2077_gen_type [135] = Y2077_pgtype135;
	Y2077_gen_type [136] = Y2077_pgtype136;
	Y2077_gen_type [137] = Y2077_pgtype137;
	Y2077_gen_type [138] = Y2077_pgtype138;
	Y2077_gen_type [139] = Y2077_pgtype139;
	Y2077_gen_type [140] = Y2077_pgtype140;
	Y2077_gen_type [141] = Y2077_pgtype141;
	Y2077_gen_type [142] = Y2077_pgtype142;
	Y2077_gen_type [143] = Y2077_pgtype143;
	Y2077_gen_type [144] = Y2077_pgtype144;
	Y2077_gen_type [145] = Y2077_pgtype145;
	Y2077_gen_type [146] = Y2077_pgtype146;
	Y2077_gen_type [147] = Y2077_pgtype147;
	Y2077_gen_type [148] = Y2077_pgtype148;
	Y2077_gen_type [149] = Y2077_pgtype149;
	Y2077_gen_type [150] = Y2077_pgtype150;
	Y2077_gen_type [151] = Y2077_pgtype151;
	Y2077_gen_type [152] = Y2077_pgtype152;
	Y2077_gen_type [153] = Y2077_pgtype153;
	Y2077_gen_type [154] = Y2077_pgtype154;
	Y2077_gen_type [155] = Y2077_pgtype155;
	Y2077_gen_type [156] = Y2077_pgtype156;
	Y2077_gen_type [157] = Y2077_pgtype157;
	Y2077_gen_type [158] = Y2077_pgtype158;
	Y2077_gen_type [159] = Y2077_pgtype159;
	Y2077_gen_type [160] = Y2077_pgtype160;
	Y2077_gen_type [161] = Y2077_pgtype161;
	Y2077_gen_type [162] = Y2077_pgtype162;
	Y2077_gen_type [163] = Y2077_pgtype163;
	Y2077_gen_type [164] = Y2077_pgtype164;
	Y2077_gen_type [165] = Y2077_pgtype165;
	Y2077_gen_type [166] = Y2077_pgtype166;
	Y2077_gen_type [167] = Y2077_pgtype167;
	Y2077_gen_type [168] = Y2077_pgtype168;
	Y2077_gen_type [169] = Y2077_pgtype169;
	Y2077_gen_type [170] = Y2077_pgtype170;
	Y2077_gen_type [171] = Y2077_pgtype171;
	Y2077_gen_type [172] = Y2077_pgtype172;
	Y2077_gen_type [173] = Y2077_pgtype173;
	Y2077_gen_type [174] = Y2077_pgtype174;
	Y2077_gen_type [175] = Y2077_pgtype175;
	Y2077_gen_type [176] = Y2077_pgtype176;
	Y2077_gen_type [177] = Y2077_pgtype177;
	Y2077_gen_type [178] = Y2077_pgtype178;
	Y2077_gen_type [179] = Y2077_pgtype179;
	Y2077_gen_type [180] = Y2077_pgtype180;
	Y2077_gen_type [181] = Y2077_pgtype181;
	Y2077_gen_type [182] = Y2077_pgtype182;
	Y2077_gen_type [183] = Y2077_pgtype183;
	Y2077_gen_type [184] = Y2077_pgtype184;
	Y2077_gen_type [185] = Y2077_pgtype185;
	Y2077_gen_type [186] = Y2077_pgtype186;
	Y2077_gen_type [187] = Y2077_pgtype187;
	Y2077_gen_type [188] = Y2077_pgtype188;
	Y2077_gen_type [189] = Y2077_pgtype189;
	Y2077_gen_type [190] = Y2077_pgtype190;
	Y2077_gen_type [191] = Y2077_pgtype191;
	Y2077_gen_type [192] = Y2077_pgtype192;
	Y2077_gen_type [193] = Y2077_pgtype193;
	Y2077_gen_type [194] = Y2077_pgtype194;
	Y2077_gen_type [195] = Y2077_pgtype195;
	Y2077_gen_type [196] = Y2077_pgtype196;
	Y2077_gen_type [197] = Y2077_pgtype197;
	Y2077_gen_type [198] = Y2077_pgtype198;
	Y2077_gen_type [199] = Y2077_pgtype199;
	Y2077_gen_type [200] = Y2077_pgtype200;
	Y2077_gen_type [201] = Y2077_pgtype201;
	Y2077_gen_type [202] = Y2077_pgtype202;
	Y2077_gen_type [203] = Y2077_pgtype203;
	Y2077_gen_type [204] = Y2077_pgtype204;
	Y2077_gen_type [205] = Y2077_pgtype205;
	Y2077_gen_type [206] = Y2077_pgtype206;
	Y2077_gen_type [207] = Y2077_pgtype207;
	Y2077_gen_type [208] = Y2077_pgtype208;
	Y2077_gen_type [209] = Y2077_pgtype209;
	Y2077_gen_type [210] = Y2077_pgtype210;
	Y2077_gen_type [211] = Y2077_pgtype211;
	Y2077_gen_type [212] = Y2077_pgtype212;
	Y2077_gen_type [213] = Y2077_pgtype213;
	Y2077_gen_type [214] = Y2077_pgtype214;
	Y2077_gen_type [215] = Y2077_pgtype215;
	Y2077_gen_type [216] = Y2077_pgtype216;
	Y2077_gen_type [217] = Y2077_pgtype217;
	Y2077_gen_type [218] = Y2077_pgtype218;
	Y2077_gen_type [219] = Y2077_pgtype219;
	Y2077_gen_type [220] = Y2077_pgtype220;
	Y2077_gen_type [221] = Y2077_pgtype221;
	Y2077_gen_type [222] = Y2077_pgtype222;
	Y2077_gen_type [223] = Y2077_pgtype223;
	Y2077_gen_type [224] = Y2077_pgtype224;
	Y2077_gen_type [225] = Y2077_pgtype225;
	Y2077_gen_type [226] = Y2077_pgtype226;
	Y2077_gen_type [227] = Y2077_pgtype227;
	Y2077_gen_type [228] = Y2077_pgtype228;
	Y2077_gen_type [229] = Y2077_pgtype229;
	Y2077_gen_type [230] = Y2077_pgtype230;
	Y2077_gen_type [231] = Y2077_pgtype231;
	Y2077_gen_type [232] = Y2077_pgtype232;
	Y2077_gen_type [233] = Y2077_pgtype233;
	Y2077_gen_type [234] = Y2077_pgtype234;
	Y2077_gen_type [235] = Y2077_pgtype235;
	Y2077_gen_type [236] = Y2077_pgtype236;
	Y2077_gen_type [237] = Y2077_pgtype237;
	Y2077_gen_type [238] = Y2077_pgtype238;
	Y2077_gen_type [239] = Y2077_pgtype239;
	Y2077_gen_type [240] = Y2077_pgtype240;
	Y2077_gen_type [241] = Y2077_pgtype241;
	Y2077_gen_type [242] = Y2077_pgtype242;
	Y2077_gen_type [243] = Y2077_pgtype243;
	Y2077_gen_type [244] = Y2077_pgtype244;
	Y2077_gen_type [245] = Y2077_pgtype245;
	Y2077_gen_type [246] = Y2077_pgtype246;
	Y2077_gen_type [247] = Y2077_pgtype247;
	Y2077_gen_type [248] = Y2077_pgtype248;
	Y2077_gen_type [249] = Y2077_pgtype249;
	Y2077_gen_type [250] = Y2077_pgtype250;
	Y2077_gen_type [251] = Y2077_pgtype251;
	Y2077_gen_type [252] = Y2077_pgtype252;
	Y2077_gen_type [253] = Y2077_pgtype253;
	Y2077_gen_type [254] = Y2077_pgtype254;
	Y2077_gen_type [255] = Y2077_pgtype255;
	Y2077_gen_type [256] = Y2077_pgtype256;
	Y2077_gen_type [257] = Y2077_pgtype257;
	Y2077_gen_type [258] = Y2077_pgtype258;
	Y2077_gen_type [259] = Y2077_pgtype259;
	Y2077_gen_type [260] = Y2077_pgtype260;
	Y2077_gen_type [261] = Y2077_pgtype261;
	Y2077_gen_type [262] = Y2077_pgtype262;
	Y2077_gen_type [263] = Y2077_pgtype263;
	Y2077_gen_type [264] = Y2077_pgtype264;
	Y2077_gen_type [265] = Y2077_pgtype265;
	Y2077_gen_type [266] = Y2077_pgtype266;
	Y2077_gen_type [267] = Y2077_pgtype267;
	Y2077_gen_type [268] = Y2077_pgtype268;
	Y2077_gen_type [269] = Y2077_pgtype269;
	Y2077_gen_type [270] = Y2077_pgtype270;
	Y2077_gen_type [271] = Y2077_pgtype271;
	Y2077_gen_type [272] = Y2077_pgtype272;
	Y2077_gen_type [273] = Y2077_pgtype273;
	Y2077_gen_type [274] = Y2077_pgtype274;
	Y2077_gen_type [275] = Y2077_pgtype275;
	Y2077_gen_type [276] = Y2077_pgtype276;
	Y2077_gen_type [277] = Y2077_pgtype277;
	Y2077_gen_type [278] = Y2077_pgtype278;
	Y2077_gen_type [279] = Y2077_pgtype279;
	Y2077_gen_type [280] = Y2077_pgtype280;
	Y2077_gen_type [281] = Y2077_pgtype281;
	Y2077_gen_type [282] = Y2077_pgtype282;
	Y2077_gen_type [283] = Y2077_pgtype283;
	Y2077_gen_type [284] = Y2077_pgtype284;
	Y2077_gen_type [285] = Y2077_pgtype285;
	Y2077_gen_type [286] = Y2077_pgtype286;
	Y2077_gen_type [287] = Y2077_pgtype287;
	Y2077_gen_type [288] = Y2077_pgtype288;
	Y2077_gen_type [289] = Y2077_pgtype289;
	Y2077_gen_type [290] = Y2077_pgtype290;
	Y2077_gen_type [291] = Y2077_pgtype291;
	Y2077_gen_type [292] = Y2077_pgtype292;
	Y2077_gen_type [293] = Y2077_pgtype293;
	Y2077_gen_type [294] = Y2077_pgtype294;
	Y2077_gen_type [295] = Y2077_pgtype295;
	Y2077_gen_type [296] = Y2077_pgtype296;
	Y2077_gen_type [297] = Y2077_pgtype297;
	Y2077_gen_type [298] = Y2077_pgtype298;
	Y2077_gen_type [299] = Y2077_pgtype299;
	Y2077_gen_type [300] = Y2077_pgtype300;
	Y2077_gen_type [301] = Y2077_pgtype301;
	Y2077_gen_type [302] = Y2077_pgtype302;
	Y2077_gen_type [303] = Y2077_pgtype303;
	Y2077_gen_type [304] = Y2077_pgtype304;
	Y2077_gen_type [305] = Y2077_pgtype305;
	Y2077_gen_type [306] = Y2077_pgtype306;
	Y2077_gen_type [307] = Y2077_pgtype307;
	Y2077_gen_type [308] = Y2077_pgtype308;
	Y2077_gen_type [309] = Y2077_pgtype309;
	Y2077_gen_type [310] = Y2077_pgtype310;
	Y2077_gen_type [311] = Y2077_pgtype311;
	Y2077_gen_type [312] = Y2077_pgtype312;
	Y2077_gen_type [313] = Y2077_pgtype313;
	Y2077_gen_type [314] = Y2077_pgtype314;
	Y2077_gen_type [315] = Y2077_pgtype315;
	Y2077_gen_type [316] = Y2077_pgtype316;
	Y2077_gen_type [317] = Y2077_pgtype317;
	Y2077_gen_type [318] = Y2077_pgtype318;
	Y2077_gen_type [319] = Y2077_pgtype319;
	Y2077_gen_type [320] = Y2077_pgtype320;
	Y2077_gen_type [321] = Y2077_pgtype321;
	Y2077_gen_type [322] = Y2077_pgtype322;
	Y2077_gen_type [323] = Y2077_pgtype323;
	Y2077_gen_type [324] = Y2077_pgtype324;
	Y2077_gen_type [325] = Y2077_pgtype325;
	Y2077_gen_type [326] = Y2077_pgtype326;
	Y2077_gen_type [327] = Y2077_pgtype327;
	Y2077_gen_type [328] = Y2077_pgtype328;
	Y2077_gen_type [329] = Y2077_pgtype329;
	Y2077_gen_type [330] = Y2077_pgtype330;
	Y2077_gen_type [331] = Y2077_pgtype331;
	Y2077_gen_type [332] = Y2077_pgtype332;
	Y2077_gen_type [333] = Y2077_pgtype333;
	Y2077_gen_type [334] = Y2077_pgtype334;
	Y2077_gen_type [335] = Y2077_pgtype335;
	Y2077_gen_type [336] = Y2077_pgtype336;
	Y2077_gen_type [337] = Y2077_pgtype337;
	Y2077_gen_type [338] = Y2077_pgtype338;
	Y2077_gen_type [339] = Y2077_pgtype339;
	Y2077_gen_type [340] = Y2077_pgtype340;
	Y2077_gen_type [341] = Y2077_pgtype341;
	Y2077_gen_type [342] = Y2077_pgtype342;
	Y2077_gen_type [343] = Y2077_pgtype343;
	Y2077_gen_type [344] = Y2077_pgtype344;
	Y2077_gen_type [345] = Y2077_pgtype345;
	Y2077_gen_type [346] = Y2077_pgtype346;
	Y2077_gen_type [347] = Y2077_pgtype347;
	Y2077_gen_type [348] = Y2077_pgtype348;
	Y2077_gen_type [349] = Y2077_pgtype349;
	Y2077_gen_type [350] = Y2077_pgtype350;
	Y2077_gen_type [351] = Y2077_pgtype351;
	Y2077_gen_type [352] = Y2077_pgtype352;
	Y2077_gen_type [353] = Y2077_pgtype353;
	Y2077_gen_type [354] = Y2077_pgtype354;
	Y2077_gen_type [355] = Y2077_pgtype355;
	Y2077_gen_type [356] = Y2077_pgtype356;
	Y2077_gen_type [357] = Y2077_pgtype357;
	Y2077_gen_type [358] = Y2077_pgtype358;
	Y2077_gen_type [359] = Y2077_pgtype359;
	Y2077_gen_type [360] = Y2077_pgtype360;
	Y2077_gen_type [361] = Y2077_pgtype361;
	Y2077_gen_type [362] = Y2077_pgtype362;
	Y2077_gen_type [363] = Y2077_pgtype363;
	Y2077_gen_type [364] = Y2077_pgtype364;
	Y2077_gen_type [365] = Y2077_pgtype365;
	Y2077_gen_type [366] = Y2077_pgtype366;
	Y2077_gen_type [367] = Y2077_pgtype367;
	Y2077_gen_type [368] = Y2077_pgtype368;
	Y2077_gen_type [369] = Y2077_pgtype369;
	Y2077_gen_type [370] = Y2077_pgtype370;
	Y2077_gen_type [371] = Y2077_pgtype371;
	Y2077_gen_type [372] = Y2077_pgtype372;
	Y2077_gen_type [373] = Y2077_pgtype373;
	Y2077_gen_type [374] = Y2077_pgtype374;
	Y2077_gen_type [375] = Y2077_pgtype375;
	Y2077_gen_type [376] = Y2077_pgtype376;
	Y2077_gen_type [377] = Y2077_pgtype377;
	Y2077_gen_type [378] = Y2077_pgtype378;
	Y2077_gen_type [379] = Y2077_pgtype379;
	Y2077_gen_type [380] = Y2077_pgtype380;
	Y2077_gen_type [381] = Y2077_pgtype381;
	Y2077_gen_type [382] = Y2077_pgtype382;
	Y2077_gen_type [383] = Y2077_pgtype383;
	Y2077_gen_type [384] = Y2077_pgtype384;
	Y2077_gen_type [385] = Y2077_pgtype385;
	Y2077_gen_type [386] = Y2077_pgtype386;
	Y2077_gen_type [387] = Y2077_pgtype387;
	Y2077_gen_type [388] = Y2077_pgtype388;
	Y2077_gen_type [389] = Y2077_pgtype389;
	Y2077_gen_type [390] = Y2077_pgtype390;
	Y2077_gen_type [391] = Y2077_pgtype391;
	Y2077_gen_type [392] = Y2077_pgtype392;
	Y2077_gen_type [393] = Y2077_pgtype393;
	Y2077_gen_type [394] = Y2077_pgtype394;
	Y2077_gen_type [395] = Y2077_pgtype395;
	Y2077_gen_type [396] = Y2077_pgtype396;
	Y2077_gen_type [397] = Y2077_pgtype397;
	Y2077_gen_type [398] = Y2077_pgtype398;
	Y2077_gen_type [399] = Y2077_pgtype399;
	Y2077_gen_type [400] = Y2077_pgtype400;
	Y2077_gen_type [401] = Y2077_pgtype401;
	Y2077_gen_type [402] = Y2077_pgtype402;
	Y2077_gen_type [403] = Y2077_pgtype403;
	Y2077_gen_type [404] = Y2077_pgtype404;
	Y2077_gen_type [405] = Y2077_pgtype405;
	Y2077_gen_type [406] = Y2077_pgtype406;
	Y2077_gen_type [407] = Y2077_pgtype407;
	Y2077_gen_type [408] = Y2077_pgtype408;
	Y2077_gen_type [409] = Y2077_pgtype409;
	Y2077_gen_type [410] = Y2077_pgtype410;
	Y2077_gen_type [411] = Y2077_pgtype411;
	Y2077_gen_type [412] = Y2077_pgtype412;
	Y2077_gen_type [413] = Y2077_pgtype413;
	Y2077_gen_type [414] = Y2077_pgtype414;
	Y2077_gen_type [415] = Y2077_pgtype415;
	Y2077_gen_type [416] = Y2077_pgtype416;
	Y2077_gen_type [417] = Y2077_pgtype417;
	Y2077_gen_type [418] = Y2077_pgtype418;
	Y2077_gen_type [419] = Y2077_pgtype419;
	Y2077_gen_type [420] = Y2077_pgtype420;
	Y2077_gen_type [421] = Y2077_pgtype421;
	Y2077_gen_type [422] = Y2077_pgtype422;
	Y2077_gen_type [423] = Y2077_pgtype423;
	Y2077_gen_type [424] = Y2077_pgtype424;
	Y2077_gen_type [425] = Y2077_pgtype425;
	Y2077_gen_type [428] = Y2077_pgtype426;
	Y2077_gen_type [429] = Y2077_pgtype427;
	Y2077_gen_type [430] = Y2077_pgtype428;
	Y2077_gen_type [431] = Y2077_pgtype429;
	Y2077_gen_type [432] = Y2077_pgtype430;
	Y2077_gen_type [433] = Y2077_pgtype431;
	Y2077_gen_type [434] = Y2077_pgtype432;
	Y2077_gen_type [435] = Y2077_pgtype433;
	Y2077_gen_type [436] = Y2077_pgtype434;
	Y2077_gen_type [437] = Y2077_pgtype435;
	Y2077_gen_type [438] = Y2077_pgtype436;
	Y2077_gen_type [439] = Y2077_pgtype437;
	Y2077_gen_type [440] = Y2077_pgtype438;
	Y2077_gen_type [441] = Y2077_pgtype439;
	Y2077_gen_type [442] = Y2077_pgtype440;
	Y2077_gen_type [443] = Y2077_pgtype441;
	Y2077_gen_type [444] = Y2077_pgtype442;
	Y2077_gen_type [445] = Y2077_pgtype443;
	Y2077_gen_type [446] = Y2077_pgtype444;
	Y2077_gen_type [447] = Y2077_pgtype445;
	Y2077_gen_type [448] = Y2077_pgtype446;
	Y2077_gen_type [514] = Y2077_pgtype447;
	Y2077_gen_type [595] = Y2077_pgtype448;
	Y2077_gen_type [596] = Y2077_pgtype449;
	Y2077_gen_type [597] = Y2077_pgtype450;
	Y2077_gen_type [598] = Y2077_pgtype451;
	Y2077_gen_type [599] = Y2077_pgtype452;
	Y2077_gen_type [600] = Y2077_pgtype453;
	Y2077_gen_type [601] = Y2077_pgtype454;
	Y2077_gen_type [607] = Y2077_pgtype455;
	Y2077_gen_type [620] = Y2077_pgtype456;
	Y2077_gen_type [621] = Y2077_pgtype457;
	Y2077_gen_type [622] = Y2077_pgtype458;
	Y2077_gen_type [623] = Y2077_pgtype459;
	Y2077_gen_type [624] = Y2077_pgtype460;
	Y2077_gen_type [625] = Y2077_pgtype461;
	Y2077_gen_type [626] = Y2077_pgtype462;
	Y2077_gen_type [627] = Y2077_pgtype463;
	Y2077_gen_type [628] = Y2077_pgtype464;
	Y2077_gen_type [636] = Y2077_pgtype465;
	Y2077_gen_type [637] = Y2077_pgtype466;
	Y2077_gen_type [638] = Y2077_pgtype467;
	Y2077_gen_type [639] = Y2077_pgtype468;
	Y2077_gen_type [641] = Y2077_pgtype469;
	Y2077_gen_type [642] = Y2077_pgtype470;
	Y2077_gen_type [643] = Y2077_pgtype471;
	Y2077_gen_type [644] = Y2077_pgtype472;
	Y2077_gen_type [658] = Y2077_pgtype473;
	Y2077_gen_type [659] = Y2077_pgtype474;
	Y2077_gen_type [660] = Y2077_pgtype475;
	Y2077_gen_type [661] = Y2077_pgtype476;
	Y2077_gen_type [662] = Y2077_pgtype477;
	Y2077_gen_type [667] = Y2077_pgtype478;
	Y2077_gen_type [668] = Y2077_pgtype479;
	Y2077_gen_type [669] = Y2077_pgtype480;
	Y2077_gen_type [670] = Y2077_pgtype481;
	Y2077_gen_type [694] = Y2077_pgtype482;
	Y2077_gen_type [695] = Y2077_pgtype483;
	Y2077[12] = 868;
	Y2077[13] = 816;
	{long i; for (i = 14; i < 16; i++) Y2077[i] = 872;};
	Y2077[88] = 816;
	Y2077[89] = 819;
	Y2077[256] = 789;
	{long i; for (i = 319; i < 322; i++) Y2077[i] = 819;};
	Y2077[358] = 789;
	Y2077[448] = 0;
	Y2077[514] = 0;
	{long i; for (i = 595; i < 598; i++) Y2077[i] = 816;};
	{long i; for (i = 598; i < 602; i++) Y2077[i] = 819;};
	Y2077[607] = 819;
	{long i; for (i = 636; i < 640; i++) Y2077[i] = 819;};
	{long i; for (i = 641; i < 645; i++) Y2077[i] = 819;};
	{long i; for (i = 694; i < 696; i++) Y2077[i] = 819;};
}

char *(*R2142[5])();
void R2142_init () {
	R2142[0] = (char *(*)()) F318_2388;
	R2142[1] = (char *(*)()) F319_2388;
	R2142[2] = (char *(*)()) F318_2388;
	R2142[3] = (char *(*)()) F319_2388;
	R2142[4] = (char *(*)()) F327_2388;
}

char *(*R2145[5])();
void R2145_init () {
	R2145[0] = (char *(*)()) F318_2393;
	R2145[1] = (char *(*)()) F319_2393;
	R2145[2] = (char *(*)()) F318_2393;
	R2145[3] = (char *(*)()) F319_2393;
	R2145[4] = (char *(*)()) F327_2393;
}

char *(*R2148[5])();
void R2148_init () {
	R2148[0] = (char *(*)()) F318_2374;
	R2148[1] = (char *(*)()) F319_2374;
	R2148[2] = (char *(*)()) F318_2374;
	R2148[3] = (char *(*)()) F319_2374;
	R2148[4] = (char *(*)()) F327_2374;
}

char *(*R2175[439])();
void R2175_init () {
	R2175[0] = (char *(*)()) F529_2552_2175_2;
	R2175[344] = (char *(*)()) F871_5352_2175_2;
	R2175[438] = (char *(*)()) F967_6927_2175_2;
}
static EIF_BOOLEAN F529_2552_2175_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F529_2552(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F871_5352_2175_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F871_5352(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F967_6927_2175_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F967_6927(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R2180[439])();
void R2180_init () {
	R2180[0] = (char *(*)()) F388_2461;
	R2180[103] = (char *(*)()) F387_2461;
	R2180[104] = (char *(*)()) F388_2461;
	R2180[105] = (char *(*)()) F389_2461;
	R2180[106] = (char *(*)()) F392_2461;
	R2180[107] = (char *(*)()) F393_2461;
	R2180[108] = (char *(*)()) F394_2461;
	R2180[109] = (char *(*)()) F395_2461;
	R2180[110] = (char *(*)()) F391_2461;
	R2180[111] = (char *(*)()) F390_2461;
	R2180[112] = (char *(*)()) F396_2461;
	R2180[113] = (char *(*)()) F397_2461;
	R2180[114] = (char *(*)()) F398_2461;
	R2180[185] = (char *(*)()) F387_2461;
	R2180[186] = (char *(*)()) F388_2461;
	R2180[187] = (char *(*)()) F387_2461;
	R2180[188] = (char *(*)()) F388_2461;
	R2180[189] = (char *(*)()) F396_2461;
	R2180[192] = (char *(*)()) F387_2461;
	R2180[341] = (char *(*)()) F390_2461;
	R2180[344] = (char *(*)()) F391_2461;
	R2180[351] = (char *(*)()) F391_2461;
	R2180[380] = (char *(*)()) F391_2461;
	R2180[385] = (char *(*)()) F391_2461;
	R2180[438] = (char *(*)()) F391_2461;
}

char *(*R2213[336])();
void R2213_init () {
	R2213[0] = (char *(*)()) F632_3030_2213_5;
	R2213[1] = (char *(*)()) F633_3030_2213_5;
	R2213[2] = (char *(*)()) F634_3030_2213_5;
	R2213[3] = (char *(*)()) F635_3030_2213_5;
	R2213[4] = (char *(*)()) F636_3030_2213_5;
	R2213[5] = (char *(*)()) F637_3030_2213_5;
	R2213[6] = (char *(*)()) F638_3030_2213_5;
	R2213[7] = (char *(*)()) F639_3030_2213_5;
	R2213[8] = (char *(*)()) F640_3030_2213_5;
	R2213[9] = (char *(*)()) F641_3030_2213_5;
	R2213[10] = (char *(*)()) F642_3030_2213_5;
	R2213[11] = (char *(*)()) F643_3030_2213_5;
	R2213[238] = (char *(*)()) F870_5232_2213_5;
	R2213[241] = (char *(*)()) F873_5396_2213_5;
	R2213[335] = (char *(*)()) F967_6906_2213_5;
}
static EIF_REFERENCE F632_3030_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F632_3030(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F633_3030_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F633_3030(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(789, 0x00).id, 789, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F634_3030_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F634_3030(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(798, 0x00).id, 798, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F635_3030_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F635_3030(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(804, 0x00).id, 804, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F636_3030_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F636_3030(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(807, 0x00).id, 807, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F637_3030_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F637_3030(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(822, 0x00).id, 822, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F638_3030_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F638_3030(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(801, 0x00).id, 801, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F639_3030_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F639_3030(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(819, 0x00).id, 819, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F640_3030_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F640_3030(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(816, 0x00).id, 816, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_3030_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F641_3030(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(858, 0x00).id, 858, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F642_3030_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F642_3030(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(810, 0x00).id, 810, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F643_3030_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F643_3030(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(813, 0x00).id, 813, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F870_5232_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F870_5232(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(816, 0x00).id, 816, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F873_5396_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F873_5396(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(819, 0x00).id, 819, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F967_6906_2213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F967_6906(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(819, 0x00).id, 819, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2216[336])();
void R2216_init () {
	R2216[0] = (char *(*)()) F632_3049_2216_10;
	R2216[1] = (char *(*)()) F633_3049_2216_10;
	R2216[2] = (char *(*)()) F634_3049_2216_10;
	R2216[3] = (char *(*)()) F635_3049_2216_10;
	R2216[4] = (char *(*)()) F636_3049_2216_10;
	R2216[5] = (char *(*)()) F637_3049_2216_10;
	R2216[6] = (char *(*)()) F638_3049_2216_10;
	R2216[7] = (char *(*)()) F639_3049_2216_10;
	R2216[8] = (char *(*)()) F640_3049_2216_10;
	R2216[9] = (char *(*)()) F641_3049_2216_10;
	R2216[10] = (char *(*)()) F642_3049_2216_10;
	R2216[11] = (char *(*)()) F643_3049_2216_10;
	R2216[82] = (char *(*)()) F714_3327;
	R2216[83] = (char *(*)()) F715_3327_2216_10;
	R2216[84] = (char *(*)()) F716_3327_2216_10;
	R2216[85] = (char *(*)()) F717_3327_2216_10;
	R2216[86] = (char *(*)()) F718_3327_2216_10;
	R2216[89] = (char *(*)()) F714_3327;
	R2216[241] = (char *(*)()) F873_5417_2216_10;
	R2216[335] = (char *(*)()) F967_6941_2216_10;
}
static void F632_3049_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F632_3049(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F633_3049_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F633_3049(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F634_3049_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F634_3049(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F635_3049_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F635_3049(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F636_3049_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F636_3049(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F637_3049_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F637_3049(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F638_3049_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F638_3049(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F639_3049_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F639_3049(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F640_3049_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F640_3049(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F641_3049_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F641_3049(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F642_3049_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F642_3049(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F643_3049_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F643_3049(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F715_3327_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F715_3327(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F716_3327_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F716_3327(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F717_3327_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F717_3327(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F718_3327_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F718_3327(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F873_5417_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F873_5417(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F967_6941_2216_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F967_6941(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y2218_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype30[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype31[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype32[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype33[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype34[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype35[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype36[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype37[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype38[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype39[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype40[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype41[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype42[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype43[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype44[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype45[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype46[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype47[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype48[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype49[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype50[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype51[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype52[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype53[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype54[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype55[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype56[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype57[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype58[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype59[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype60[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype61[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype62[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype63[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype64[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype65[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype66[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype67[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype68[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype69[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype70[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype71[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype72[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype73[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype74[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype75[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype76[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype77[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype78[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype79[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype80[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype81[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype82[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype83[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype84[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype85[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype86[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype87[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype88[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype89[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype90[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype91[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype92[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype93[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype94[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype95[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype96[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype97[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype98[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype99[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype100[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype101[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype102[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype103[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype104[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype105[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype106[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype107[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype108[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype109[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype110[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype111[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype112[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype113[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype114[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype115[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype116[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype117[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype118[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype119[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype120[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype121[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype122[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype123[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype124[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype125[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype126[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype127[] = {0xFF01,864,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype128[] = {0xFF01,864,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype129[] = {0xFF01,872,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype130[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype131[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype132[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype133[] = {789,0xFFFF};
static EIF_TYPE_INDEX Y2218_pgtype134[] = {789,0xFFFF};
EIF_TYPE_INDEX *Y2218_gen_type [509];
EIF_TYPE_INDEX Y2218 [509];
void Y2218_init (void)
{
	egc_routines_types [2218] = Y2218;
	egc_routines_gen_types [2218] = Y2218_gen_type;
	egc_routines_offset [2218] = 459;
	Y2218_gen_type [0] = Y2218_pgtype0;
	Y2218_gen_type [1] = Y2218_pgtype1;
	Y2218_gen_type [2] = Y2218_pgtype2;
	Y2218_gen_type [3] = Y2218_pgtype3;
	Y2218_gen_type [4] = Y2218_pgtype4;
	Y2218_gen_type [5] = Y2218_pgtype5;
	Y2218_gen_type [6] = Y2218_pgtype6;
	Y2218_gen_type [7] = Y2218_pgtype7;
	Y2218_gen_type [8] = Y2218_pgtype8;
	Y2218_gen_type [9] = Y2218_pgtype9;
	Y2218_gen_type [10] = Y2218_pgtype10;
	Y2218_gen_type [11] = Y2218_pgtype11;
	Y2218_gen_type [12] = Y2218_pgtype12;
	Y2218_gen_type [13] = Y2218_pgtype13;
	Y2218_gen_type [14] = Y2218_pgtype14;
	Y2218_gen_type [15] = Y2218_pgtype15;
	Y2218_gen_type [16] = Y2218_pgtype16;
	Y2218_gen_type [17] = Y2218_pgtype17;
	Y2218_gen_type [18] = Y2218_pgtype18;
	Y2218_gen_type [19] = Y2218_pgtype19;
	Y2218_gen_type [20] = Y2218_pgtype20;
	Y2218_gen_type [21] = Y2218_pgtype21;
	Y2218_gen_type [22] = Y2218_pgtype22;
	Y2218_gen_type [23] = Y2218_pgtype23;
	Y2218_gen_type [24] = Y2218_pgtype24;
	Y2218_gen_type [25] = Y2218_pgtype25;
	Y2218_gen_type [26] = Y2218_pgtype26;
	Y2218_gen_type [27] = Y2218_pgtype27;
	Y2218_gen_type [28] = Y2218_pgtype28;
	Y2218_gen_type [29] = Y2218_pgtype29;
	Y2218_gen_type [159] = Y2218_pgtype30;
	Y2218_gen_type [160] = Y2218_pgtype31;
	Y2218_gen_type [161] = Y2218_pgtype32;
	Y2218_gen_type [162] = Y2218_pgtype33;
	Y2218_gen_type [163] = Y2218_pgtype34;
	Y2218_gen_type [164] = Y2218_pgtype35;
	Y2218_gen_type [165] = Y2218_pgtype36;
	Y2218_gen_type [166] = Y2218_pgtype37;
	Y2218_gen_type [167] = Y2218_pgtype38;
	Y2218_gen_type [168] = Y2218_pgtype39;
	Y2218_gen_type [169] = Y2218_pgtype40;
	Y2218_gen_type [170] = Y2218_pgtype41;
	Y2218_gen_type [171] = Y2218_pgtype42;
	Y2218_gen_type [172] = Y2218_pgtype43;
	Y2218_gen_type [173] = Y2218_pgtype44;
	Y2218_gen_type [174] = Y2218_pgtype45;
	Y2218_gen_type [175] = Y2218_pgtype46;
	Y2218_gen_type [176] = Y2218_pgtype47;
	Y2218_gen_type [177] = Y2218_pgtype48;
	Y2218_gen_type [178] = Y2218_pgtype49;
	Y2218_gen_type [179] = Y2218_pgtype50;
	Y2218_gen_type [180] = Y2218_pgtype51;
	Y2218_gen_type [181] = Y2218_pgtype52;
	Y2218_gen_type [182] = Y2218_pgtype53;
	Y2218_gen_type [183] = Y2218_pgtype54;
	Y2218_gen_type [184] = Y2218_pgtype55;
	Y2218_gen_type [185] = Y2218_pgtype56;
	Y2218_gen_type [186] = Y2218_pgtype57;
	Y2218_gen_type [187] = Y2218_pgtype58;
	Y2218_gen_type [188] = Y2218_pgtype59;
	Y2218_gen_type [189] = Y2218_pgtype60;
	Y2218_gen_type [190] = Y2218_pgtype61;
	Y2218_gen_type [191] = Y2218_pgtype62;
	Y2218_gen_type [192] = Y2218_pgtype63;
	Y2218_gen_type [193] = Y2218_pgtype64;
	Y2218_gen_type [194] = Y2218_pgtype65;
	Y2218_gen_type [195] = Y2218_pgtype66;
	Y2218_gen_type [196] = Y2218_pgtype67;
	Y2218_gen_type [197] = Y2218_pgtype68;
	Y2218_gen_type [198] = Y2218_pgtype69;
	Y2218_gen_type [199] = Y2218_pgtype70;
	Y2218_gen_type [200] = Y2218_pgtype71;
	Y2218_gen_type [201] = Y2218_pgtype72;
	Y2218_gen_type [202] = Y2218_pgtype73;
	Y2218_gen_type [203] = Y2218_pgtype74;
	Y2218_gen_type [204] = Y2218_pgtype75;
	Y2218_gen_type [205] = Y2218_pgtype76;
	Y2218_gen_type [206] = Y2218_pgtype77;
	Y2218_gen_type [207] = Y2218_pgtype78;
	Y2218_gen_type [208] = Y2218_pgtype79;
	Y2218_gen_type [209] = Y2218_pgtype80;
	Y2218_gen_type [210] = Y2218_pgtype81;
	Y2218_gen_type [211] = Y2218_pgtype82;
	Y2218_gen_type [212] = Y2218_pgtype83;
	Y2218_gen_type [213] = Y2218_pgtype84;
	Y2218_gen_type [214] = Y2218_pgtype85;
	Y2218_gen_type [215] = Y2218_pgtype86;
	Y2218_gen_type [216] = Y2218_pgtype87;
	Y2218_gen_type [217] = Y2218_pgtype88;
	Y2218_gen_type [218] = Y2218_pgtype89;
	Y2218_gen_type [219] = Y2218_pgtype90;
	Y2218_gen_type [220] = Y2218_pgtype91;
	Y2218_gen_type [221] = Y2218_pgtype92;
	Y2218_gen_type [222] = Y2218_pgtype93;
	Y2218_gen_type [223] = Y2218_pgtype94;
	Y2218_gen_type [224] = Y2218_pgtype95;
	Y2218_gen_type [225] = Y2218_pgtype96;
	Y2218_gen_type [226] = Y2218_pgtype97;
	Y2218_gen_type [227] = Y2218_pgtype98;
	Y2218_gen_type [228] = Y2218_pgtype99;
	Y2218_gen_type [229] = Y2218_pgtype100;
	Y2218_gen_type [230] = Y2218_pgtype101;
	Y2218_gen_type [231] = Y2218_pgtype102;
	Y2218_gen_type [232] = Y2218_pgtype103;
	Y2218_gen_type [233] = Y2218_pgtype104;
	Y2218_gen_type [234] = Y2218_pgtype105;
	Y2218_gen_type [235] = Y2218_pgtype106;
	Y2218_gen_type [236] = Y2218_pgtype107;
	Y2218_gen_type [237] = Y2218_pgtype108;
	Y2218_gen_type [238] = Y2218_pgtype109;
	Y2218_gen_type [242] = Y2218_pgtype110;
	Y2218_gen_type [243] = Y2218_pgtype111;
	Y2218_gen_type [244] = Y2218_pgtype112;
	Y2218_gen_type [245] = Y2218_pgtype113;
	Y2218_gen_type [246] = Y2218_pgtype114;
	Y2218_gen_type [247] = Y2218_pgtype115;
	Y2218_gen_type [248] = Y2218_pgtype116;
	Y2218_gen_type [249] = Y2218_pgtype117;
	Y2218_gen_type [250] = Y2218_pgtype118;
	Y2218_gen_type [251] = Y2218_pgtype119;
	Y2218_gen_type [252] = Y2218_pgtype120;
	Y2218_gen_type [253] = Y2218_pgtype121;
	Y2218_gen_type [254] = Y2218_pgtype122;
	Y2218_gen_type [255] = Y2218_pgtype123;
	Y2218_gen_type [256] = Y2218_pgtype124;
	Y2218_gen_type [257] = Y2218_pgtype125;
	Y2218_gen_type [258] = Y2218_pgtype126;
	Y2218_gen_type [259] = Y2218_pgtype127;
	Y2218_gen_type [260] = Y2218_pgtype128;
	Y2218_gen_type [261] = Y2218_pgtype129;
	Y2218_gen_type [410] = Y2218_pgtype130;
	Y2218_gen_type [413] = Y2218_pgtype131;
	Y2218_gen_type [414] = Y2218_pgtype132;
	Y2218_gen_type [507] = Y2218_pgtype133;
	Y2218_gen_type [508] = Y2218_pgtype134;
	{long i; for (i = 159; i < 239; i++) Y2218[i] = 789;};
	{long i; for (i = 242; i < 254; i++) Y2218[i] = 789;};
	{long i; for (i = 259; i < 261; i++) Y2218[i] = 864;};
	Y2218[261] = 872;
	Y2218[410] = 789;
	{long i; for (i = 413; i < 415; i++) Y2218[i] = 789;};
	{long i; for (i = 507; i < 509; i++) Y2218[i] = 789;};
}


#ifdef __cplusplus
}
#endif
