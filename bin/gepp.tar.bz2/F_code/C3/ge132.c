/*
 * Code for class GEPP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge132.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEPP}.execute */
void F170_1491 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(1152,F108_1152, (Current));
	tr2 = RTMS_EX_H("gepp",4,1734701168);
	F288_2350(RTCW(tr1), tr2);
	tr1 = RTLNSMART(eif_new_type(944, 1).id);
	F945_6461(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(955, 1).id);
	F956_6803(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("-",1,45);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("-",1,45);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F170_1493(Current);
	F170_1492(Current);
	RTLE;
}

/* {GEPP}.preprocess */
void F170_1492 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTMS_EX_H("-",1,45);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-1])(tr1, tr2);
	if ((EIF_BOOLEAN) !tb1) {
		loc2 = RTLNS(eif_new_type(908, 0x01).id, 908, _OBJSIZ_6_7_2_4_1_1_2_1_);
		F907_5960(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_1_));
		F908_5995(RTCW(loc2));
		tb1 = F908_5990(RTCW(loc2));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F954_6686(RTCW(tr1), loc2);
		} else {
			F170_1499(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
			tr1 = RTOSCF(835,F79_835, (Current));
			F123_1268(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = RTOSCF(231,F12_231, (RTCV(RTOSCF(1490,F169_1490, (Current)))));
		F954_6686(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTMS_EX_H("-",1,45);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-1])(tr1, tr2);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = RTOSCF(230,F12_230, (RTCV(RTOSCF(1490,F169_1490, (Current)))));
		F956_6805(RTCW(tr1), tr2);
	} else {
		loc1 = RTLNS(eif_new_type(913, 0x01).id, 913, _OBJSIZ_7_8_2_4_1_1_2_1_);
		F913_6013(RTCW(loc1), *(EIF_REFERENCE *)(Current));
		F913_6023(RTCW(loc1));
		tb1 = F913_6016(RTCW(loc1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F956_6805(RTCW(tr1), loc1);
			F913_6024(RTCW(loc1));
		} else {
			F170_1498(Current, *(EIF_REFERENCE *)(Current));
			tr1 = RTOSCF(835,F79_835, (Current));
			F123_1268(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F955_6690(RTCW(tr1));
	if (tb1) {
		tr1 = RTOSCF(835,F79_835, (Current));
		F123_1268(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tb2 = F907_5966(RTCW(loc2));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F907_5968(RTCW(loc2));
	}
	RTLE;
}

/* {GEPP}.read_arguments */
void F170_1493 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	loc5 = F287_2342(RTCV(RTOSCF(1152,F108_1152, (Current))));
	if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 1L))) {
		tr1 = RTOSCF(1152,F108_1152, (Current));
		loc1 = F287_2324(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		tb1 = '\01';
		tr1 = RTMS_EX_H("-V",2,11606);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc1))-1])(loc1, tr1);
		if (!tb2) {
			tr1 = RTMS_EX_H("--version",9,1914745454);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc1))-1])(loc1, tr1);
			tb1 = tb2;
		}
		if (tb1) {
			F170_1502(Current);
			tr1 = RTOSCF(835,F79_835, (Current));
			F123_1268(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		} else {
			tb1 = '\01';
			tb2 = '\01';
			tr1 = RTMS_EX_H("-h",2,11624);
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc1))-1])(loc1, tr1);
			if (!tb3) {
				tr1 = RTMS_EX_H("-\?",2,11583);
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc1))-1])(loc1, tr1);
				tb2 = tb3;
			}
			if (!tb2) {
				tr1 = RTMS_EX_H("--help",6,1840296560);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc1))-1])(loc1, tr1);
				tb1 = tb2;
			}
			if (tb1) {
				F170_1501(Current);
				tr1 = RTOSCF(835,F79_835, (Current));
				F123_1268(RTCW(tr1), ((EIF_INTEGER_32) 0L));
			}
		}
	}
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 > loc5) || loc2)) break;
		tr1 = RTOSCF(1152,F108_1152, (Current));
		loc1 = F287_2324(RTCW(tr1), loc3);
		loc4 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		tb1 = '\0';
		if ((EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 2L))) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2450[Dtype(RTCW(loc1))-606])(loc1, ((EIF_INTEGER_32) 1L)));
			tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '-');
		}
		if (tb1) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2450[Dtype(RTCW(loc1))-606])(loc1, ((EIF_INTEGER_32) 2L)));
			if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) 'D')) {
				if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 2L))) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tr2 = RTMS_EX_H("",0,0);
					tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R3897[Dtype(RTCW(loc1))-868])(loc1, ((EIF_INTEGER_32) 3L), loc4);
					F956_6815(RTCW(tr1), tr2, tr3);
				}
				loc3++;
			} else {
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 2L))) {
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2450[Dtype(RTCW(loc1))-606])(loc1, ((EIF_INTEGER_32) 2L)));
					tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) 'M');
				}
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F956_6817(RTCW(tr1), (EIF_BOOLEAN) 1);
					loc3++;
				} else {
					tb1 = '\0';
					if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 2L))) {
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2450[Dtype(RTCW(loc1))-606])(loc1, ((EIF_INTEGER_32) 2L)));
						tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) 'l');
					}
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						F954_6683(RTCW(tr1), (EIF_BOOLEAN) 1);
						loc3++;
					} else {
						tr1 = RTMS_EX_H("--lines",7,885109363);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc1))-1])(loc1, tr1);
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							F954_6683(RTCW(tr1), (EIF_BOOLEAN) 1);
							loc3++;
						} else {
							loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						}
					}
				}
			}
		} else {
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	switch ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 - loc3) + ((EIF_INTEGER_32) 1L))) {
		case 0L:
			break;
		case 1L:
			tr1 = RTOSCF(1152,F108_1152, (Current));
			tr1 = F287_2324(RTCW(tr1), loc3);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
			break;
		case 2L:
			tr1 = RTOSCF(1152,F108_1152, (Current));
			tr1 = F287_2324(RTCW(tr1), loc3);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(1152,F108_1152, (Current));
			tr1 = F287_2324(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			break;
		default:
			F170_1500(Current);
			tr1 = RTOSCF(835,F79_835, (Current));
			F123_1268(RTCW(tr1), ((EIF_INTEGER_32) 1L));
			break;
	}
	RTLE;
}

/* {GEPP}.report_cannot_read_error */
void F170_1498 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(962, 0x01).id, 962, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F963_6846(RTCW(loc1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F945_6463(RTCW(tr1), loc1);
	RTLE;
}

/* {GEPP}.report_cannot_write_error */
void F170_1499 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(960, 0x01).id, 960, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F961_6840(RTCW(loc1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F945_6463(RTCW(tr1), loc1);
	RTLE;
}

/* {GEPP}.report_usage_error */
void F170_1500 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOSCF(1503,F170_1503, (Current));
	F945_6463(RTCW(tr1), tr2);
	RTLE;
}

/* {GEPP}.report_usage_message */
void F170_1501 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOSCF(1503,F170_1503, (Current));
	F945_6465(RTCW(tr1), tr2);
	RTLE;
}

/* {GEPP}.report_version_number */
void F170_1502 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(961, 0x01).id, 961, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(756,F67_756, (Current));
	F962_6843(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F945_6465(RTCW(tr1), loc1);
	RTLE;
}

/* {GEPP}.usage_message */
static EIF_REFERENCE F170_1503_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1503);
#define Result RTOSR(1503)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(963, 0x01).id, 963, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("[--version][--help][-hV\?lM]\012\011[--lines][-Dname ...][filename | -][filename | -]",78,1338205277);
	F964_6849(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1503);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F170_1503 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1503,F170_1503_body,(Current));
}

/* {GEPP}.resurrect_code */
void F170_1504 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,163,0xFF01,872,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 163, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	RTLE;
}

void EIF_Minit132 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
