
#ifndef _C3_na141_
#define _C3_na141_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F191_1763(EIF_REFERENCE, EIF_POINTER);
extern EIF_NATURAL_64 F191_1764(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit141(void);

#ifdef __cplusplus
}
#endif

#endif
