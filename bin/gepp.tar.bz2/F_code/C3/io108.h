
#ifndef _C3_io108_
#define _C3_io108_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F144_1349(EIF_REFERENCE);
extern void F144_1352(EIF_REFERENCE, EIF_INTEGER_32);
extern void F144_1353(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit108(void);

#ifdef __cplusplus
}
#endif

#endif
