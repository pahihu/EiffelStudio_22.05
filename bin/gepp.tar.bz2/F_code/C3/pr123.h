
#ifndef _C3_pr123_
#define _C3_pr123_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F159_1379(EIF_REFERENCE);
extern void EIF_Minit123(void);

#ifdef __cplusplus
}
#endif

#endif
