
#ifndef _C3_no103_
#define _C3_no103_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F139_1339(EIF_REFERENCE);
extern void F139_1341(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit103(void);

#ifdef __cplusplus
}
#endif

#endif
