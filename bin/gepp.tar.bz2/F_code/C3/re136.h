
#ifndef _C3_re136_
#define _C3_re136_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F174_1599(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit136(void);

#ifdef __cplusplus
}
#endif

#endif
