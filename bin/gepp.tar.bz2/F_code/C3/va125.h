
#ifndef _C3_va125_
#define _C3_va125_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F161_1383(EIF_REFERENCE);
extern void EIF_Minit125(void);

#ifdef __cplusplus
}
#endif

#endif
