
#ifndef _C3_ro113_
#define _C3_ro113_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F149_1363(EIF_REFERENCE);
extern void F149_1365(EIF_REFERENCE, EIF_REFERENCE);
extern void F149_1366(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit113(void);

#ifdef __cplusplus
}
#endif

#endif
