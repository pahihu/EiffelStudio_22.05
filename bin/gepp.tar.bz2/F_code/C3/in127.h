
#ifndef _C3_in127_
#define _C3_in127_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F163_1387(EIF_REFERENCE);
extern void F163_1388(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit127(void);

#ifdef __cplusplus
}
#endif

#endif
