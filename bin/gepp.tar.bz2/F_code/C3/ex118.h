
#ifndef _C3_ex118_
#define _C3_ex118_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F154_1371(EIF_REFERENCE);
extern void EIF_Minit118(void);

#ifdef __cplusplus
}
#endif

#endif
