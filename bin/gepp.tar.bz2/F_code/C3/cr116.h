
#ifndef _C3_cr116_
#define _C3_cr116_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F152_1369(EIF_REFERENCE);
extern void EIF_Minit116(void);

#ifdef __cplusplus
}
#endif

#endif
