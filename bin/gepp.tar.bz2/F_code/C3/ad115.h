
#ifndef _C3_ad115_
#define _C3_ad115_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F151_1367(EIF_REFERENCE);
extern void EIF_Minit115(void);

#ifdef __cplusplus
}
#endif

#endif
