
#ifndef _C3_re119_
#define _C3_re119_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F155_1373(EIF_REFERENCE);
extern void EIF_Minit119(void);

#ifdef __cplusplus
}
#endif

#endif
