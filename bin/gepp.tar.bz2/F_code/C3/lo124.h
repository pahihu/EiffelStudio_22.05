
#ifndef _C3_lo124_
#define _C3_lo124_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F160_1381(EIF_REFERENCE);
extern void EIF_Minit124(void);

#ifdef __cplusplus
}
#endif

#endif
