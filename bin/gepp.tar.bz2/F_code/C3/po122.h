
#ifndef _C3_po122_
#define _C3_po122_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F158_1377(EIF_REFERENCE);
extern void EIF_Minit122(void);

#ifdef __cplusplus
}
#endif

#endif
