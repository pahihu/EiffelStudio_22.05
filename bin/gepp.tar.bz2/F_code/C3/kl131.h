
#ifndef _C3_kl131_
#define _C3_kl131_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1490)
static EIF_REFERENCE F169_1490_body(EIF_REFERENCE);
extern EIF_REFERENCE F169_1490(EIF_REFERENCE);
extern void EIF_Minit131(void);

#ifdef __cplusplus
}
#endif

#endif
