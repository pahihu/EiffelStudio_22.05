
#ifndef _C3_ei100_
#define _C3_ei100_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F136_1335(EIF_REFERENCE);
extern void F136_1337(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit100(void);

#ifdef __cplusplus
}
#endif

#endif
