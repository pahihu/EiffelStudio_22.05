
#ifndef _C3_re120_
#define _C3_re120_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F156_1375(EIF_REFERENCE);
extern void EIF_Minit120(void);

#ifdef __cplusplus
}
#endif

#endif
