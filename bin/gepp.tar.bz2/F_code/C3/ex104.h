
#ifndef _C3_ex104_
#define _C3_ex104_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F140_1343(EIF_REFERENCE);
extern void EIF_Minit104(void);

#ifdef __cplusplus
}
#endif

#endif
