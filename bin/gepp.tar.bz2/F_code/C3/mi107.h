
#ifndef _C3_mi107_
#define _C3_mi107_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F143_1347(EIF_REFERENCE);
extern void EIF_Minit107(void);

#ifdef __cplusplus
}
#endif

#endif
