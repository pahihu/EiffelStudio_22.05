
#ifndef _C3_ch126_
#define _C3_ch126_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F162_1385(EIF_REFERENCE);
extern void EIF_Minit126(void);

#ifdef __cplusplus
}
#endif

#endif
