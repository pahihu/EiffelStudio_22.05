
#ifndef _C3_se106_
#define _C3_se106_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F142_1345(EIF_REFERENCE);
extern void EIF_Minit106(void);

#ifdef __cplusplus
}
#endif

#endif
