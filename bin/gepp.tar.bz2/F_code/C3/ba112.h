
#ifndef _C3_ba112_
#define _C3_ba112_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F148_1359(EIF_REFERENCE);
extern void EIF_Minit112(void);

#ifdef __cplusplus
}
#endif

#endif
