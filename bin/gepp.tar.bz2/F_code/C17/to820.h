
#ifndef _C17_to820_
#define _C17_to820_

#ifdef __cplusplus
extern "C" {
#endif

extern void F187_1755(EIF_REFERENCE, EIF_INTEGER_32);
extern void F187_1756(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F187_1762(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit820(void);
extern void F615_2937(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1613[];
extern EIF_TYPE_INDEX *Y1613_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
