
#ifndef _C17_co835_
#define _C17_co835_

#ifdef __cplusplus
extern "C" {
#endif

extern void F396_2461(EIF_REFERENCE);
extern void EIF_Minit835(void);
extern long O2178[];

#ifdef __cplusplus
}
#endif

#endif
