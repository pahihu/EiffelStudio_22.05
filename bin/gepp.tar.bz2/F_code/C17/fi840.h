
#ifndef _C17_fi840_
#define _C17_fi840_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F539_2559(EIF_REFERENCE);
extern void EIF_Minit840(void);
extern char *(*R2240[])();

#ifdef __cplusplus
}
#endif

#endif
