
#ifndef _C17_re838_
#define _C17_re838_

#ifdef __cplusplus
extern "C" {
#endif

extern void F327_2374(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F327_2376(EIF_REFERENCE);
extern EIF_INTEGER_32 F327_2377(EIF_REFERENCE);
extern EIF_INTEGER_32 F327_2378(EIF_REFERENCE);
extern EIF_INTEGER_32 F327_2379(EIF_REFERENCE);
extern EIF_BOOLEAN F327_2387(EIF_REFERENCE);
extern EIF_BOOLEAN F327_2388(EIF_REFERENCE);
extern void F327_2393(EIF_REFERENCE);
extern void EIF_Minit838(void);
extern char *(*R2451[])();
extern char *(*R2452[])();

#ifdef __cplusplus
}
#endif

#endif
