
#ifndef _C17_re827_
#define _C17_re827_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F564_2572(EIF_REFERENCE);
extern void EIF_Minit827(void);
extern char *(*R2243[])();

#ifdef __cplusplus
}
#endif

#endif
