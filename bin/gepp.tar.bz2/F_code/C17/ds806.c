/*
 * Code for class DS_SPARSE_CONTAINER [G#1, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds806.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_CONTAINER}.make */
void F940_6238 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_) = (EIF_INTEGER_32) arg1;
	F942_6380(Current, arg1);
	F942_6386(Current, arg1);
	F942_6393(Current, arg1);
	ti4_1 = F940_6328(Current, arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_1_) = (EIF_INTEGER_32) ti4_1;
	F942_6399(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_1_) + ((EIF_INTEGER_32) 1L)));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	F940_6257(Current);
	tr1 = F943_6409(Current);
	F940_6308(Current, tr1);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.count */
EIF_INTEGER_32 F940_6243 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_);
}


/* {DS_SPARSE_CONTAINER}.capacity */
EIF_INTEGER_32 F940_6244 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_);
}


/* {DS_SPARSE_CONTAINER}.unset_found_item */
void F940_6257 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
}

/* {DS_SPARSE_CONTAINER}.copy */
void F940_6258 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F940_6310(Current);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = F921_6085(Current, loc1);
		}
		if (tb1) {
			F940_6308(Current, loc1);
		} else {
			tr1 = F943_6409(Current);
			F940_6308(Current, tr1);
		}
		F940_6257(Current);
		F942_6381(Current);
		F942_6388(Current);
		F942_6402(Current);
		F942_6395(Current);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.remove */
void F940_6259 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F940_6257(Current);
	tr1 = RTCCL(arg1);
	F940_6271(Current, tr1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		F940_6276(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.resize */
void F940_6262 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	F940_6257(Current);
	loc1 = F940_6328(Current, arg1);
	F942_6403(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		F942_6401(Current, ((EIF_INTEGER_32) -1L), loc2);
		loc2--;
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_1_) = (EIF_INTEGER_32) loc1;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		if ((EIF_BOOLEAN) (F942_6378(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
			tr1 = F942_6377(Current, loc2);
			tr2 = RTCCL(tr1);
			loc3 = F943_6412(Current, tr2);
			ti4_1 = F942_6400(Current, loc3);
			F942_6394(Current, ti4_1, loc2);
			F942_6401(Current, loc2, loc3);
		}
		loc2--;
	}
	F942_6382(Current, arg1);
	F942_6389(Current, arg1);
	F942_6396(Current, arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.search_position */
void F940_6271 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		ti4_1 = F942_6400(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_1_));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) = (EIF_INTEGER_32) ti4_1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_1_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_);
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_5_);
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) (F942_6378(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				tr1 = RTCCL(arg1);
				tr2 = F942_6377(Current, loc3);
				tr3 = RTCCL(tr2);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1258[Dtype(loc5)-163])(loc5, tr1, tr3);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				tr1 = RTCCL(arg1);
				loc4 = F943_6412(Current, tr1);
				loc1 = F942_6400(Current, loc4);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					tr1 = RTCCL(arg1);
					tr2 = F942_6377(Current, loc1);
					tr3 = RTCCL(tr2);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1258[Dtype(loc5)-163])(loc5, tr1, tr3);
					if (tb1) {
						loc3 = (EIF_INTEGER_32) loc1;
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 = (EIF_INTEGER_32) loc1;
						ti4_1 = F942_6378(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
			}
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) = (EIF_INTEGER_32) loc3;
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_) = (EIF_INTEGER_32) loc4;
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_5_) = (EIF_INTEGER_32) loc2;
		} else {
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) (F942_6378(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				tb1 = !RTCEQ(arg1, F942_6377(Current, loc3));
			}
			if (tb1) {
				tr1 = RTCCL(arg1);
				loc4 = F943_6412(Current, tr1);
				loc1 = F942_6400(Current, loc4);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					if (RTCEQ(arg1, F942_6377(Current, loc1))) {
						loc3 = (EIF_INTEGER_32) loc1;
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 = (EIF_INTEGER_32) loc1;
						ti4_1 = F942_6378(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) = (EIF_INTEGER_32) loc3;
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_) = (EIF_INTEGER_32) loc4;
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_5_) = (EIF_INTEGER_32) loc2;
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.remove_position */
void F940_6276 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_))) {
		loc1 = F942_6377(Current, arg1);
		tr1 = RTCCL(loc1);
		loc2 = F943_6412(Current, tr1);
		if ((EIF_BOOLEAN)(F942_6400(Current, loc2) == arg1)) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) = (EIF_INTEGER_32) arg1;
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_) = (EIF_INTEGER_32) loc2;
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		} else {
			loc3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F941_6370(Current, NULL);
			tr1 = RTCCL(loc1);
			F940_6271(Current, tr1);
			F941_6370(Current, loc3);
		}
	}
	F940_6313(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_5_) == ((EIF_INTEGER_32) -1L))) {
		ti4_1 = F942_6378(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_);
		F942_6401(Current, ti4_1, ti4_2);
	} else {
		ti4_1 = F942_6378(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_5_);
		F942_6394(Current, ti4_1, ti4_2);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_) == ((EIF_INTEGER_32) -1L)) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_)))) {
		F942_6384(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
		F942_6391(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
		F942_6394(Current, ((EIF_INTEGER_32) -1L), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_))--;
	} else {
		tr1 = RTLNTY2(eif_final_id(Y4493,Y4493_gen_type,dftype,917), 0x00);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3014[Dtype(tr1)-755])(tr1);
		if (tb1) {
			tr1 = RTLNTY2(eif_final_id(Y4493,Y4493_gen_type,dftype,917), 0x00);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3022[Dtype(tr1)-755])(tr1);
			tr2 = RTCCL(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_);
			F942_6376(Current, tr2, ti4_1);
		}
		tr1 = RTLNTY2(eif_final_id(Y4655,Y4655_gen_type,dftype,939), 0x00);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3014[Dtype(tr1)-755])(tr1);
		if (tb1) {
			tr1 = RTLNTY2(eif_final_id(Y4655,Y4655_gen_type,dftype,939), 0x00);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3022[Dtype(tr1)-755])(tr1);
			tr2 = RTCCL(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_);
			F942_6387(Current, tr2, ti4_1);
		}
		F942_6394(Current, (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_)), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_);
	}
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))--;
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.set_internal_cursor */
void F940_6308 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {DS_SPARSE_CONTAINER}.internal_cursor */
EIF_REFERENCE F940_6309 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {DS_SPARSE_CONTAINER}.move_all_cursors_after */
void F940_6310 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		F898_5861(RTCW(loc1));
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		F890_5822(RTCW(loc1), NULL);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.move_cursors_forth */
void F940_6313 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == arg1)) {
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
				loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
				loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (loc4 > loc5)) {
						tb1 = (EIF_BOOLEAN) (F942_6378(Current, loc4) > ((EIF_INTEGER_32) -2L));
					}
					if (tb1) break;
					loc4++;
				}
			}
			if ((EIF_BOOLEAN) (loc4 > loc5)) {
				F898_5861(RTCW(loc1));
				if ((EIF_BOOLEAN)(loc3 == NULL)) {
					loc3 = (EIF_REFERENCE) loc1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
					F890_5822(RTCW(loc3), loc2);
					F890_5822(RTCW(loc1), NULL);
					loc1 = (EIF_REFERENCE) loc2;
				}
			} else {
				F898_5860(RTCW(loc1), loc4);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				loc1 = (EIF_REFERENCE) tr1;
			}
		} else {
			loc3 = (EIF_REFERENCE) loc1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_same_position */
EIF_BOOLEAN F940_6317 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_forth */
void F940_6320 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_1 = ((EIF_INTEGER_32) -2L);
	if ((EIF_BOOLEAN)(loc4 == ti4_1)) {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
	}
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > loc2)) {
			tb1 = (EIF_BOOLEAN) (F942_6378(Current, loc1) > ((EIF_INTEGER_32) -2L));
		}
		if (tb1) break;
		loc1++;
	}
	if ((EIF_BOOLEAN) (loc1 > loc2)) {
		F898_5861(RTCW(arg1));
		if ((EIF_BOOLEAN) !loc3) {
			F921_6094(Current, arg1);
		}
	} else {
		F898_5860(RTCW(arg1), loc1);
		if (loc3) {
			F921_6093(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.new_capacity */
EIF_INTEGER_32 F940_6327 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * arg1);
}

/* {DS_SPARSE_CONTAINER}.new_modulus */
EIF_INTEGER_32 F940_6328 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 3L)) / ((EIF_INTEGER_32) 2L));
}

void EIF_Minit806 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
