
#ifndef _C17_ds809_
#define _C17_ds809_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F901_5875(EIF_REFERENCE);
extern void EIF_Minit809(void);

#ifdef __cplusplus
}
#endif

#endif
