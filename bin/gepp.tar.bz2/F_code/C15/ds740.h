
#ifndef _C15_ds740_
#define _C15_ds740_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F936_6203(EIF_REFERENCE);
extern void EIF_Minit740(void);
extern char *(*R4484[])();
extern char *(*R4582[])();

#ifdef __cplusplus
}
#endif

#endif
