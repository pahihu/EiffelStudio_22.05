
#ifndef _C15_to716_
#define _C15_to716_

#ifdef __cplusplus
extern "C" {
#endif

extern void F186_1755(EIF_REFERENCE, EIF_INTEGER_32);
extern void F186_1756(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F186_1762(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit716(void);
extern void F614_2937(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1613[];
extern EIF_TYPE_INDEX *Y1613_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
