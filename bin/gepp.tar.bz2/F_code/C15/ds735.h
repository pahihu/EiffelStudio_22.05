
#ifndef _C15_ds735_
#define _C15_ds735_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F921_6085(EIF_REFERENCE, EIF_REFERENCE);
extern void F921_6093(EIF_REFERENCE, EIF_REFERENCE);
extern void F921_6094(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit735(void);
extern void F890_5822(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
