
#ifndef _C15_ds732_
#define _C15_ds732_

#ifdef __cplusplus
extern "C" {
#endif

extern void F938_6206(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F938_6211(EIF_REFERENCE);
extern EIF_INTEGER_32 F938_6213(EIF_REFERENCE);
extern EIF_INTEGER_32 F938_6214(EIF_REFERENCE);
extern void F938_6216(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F938_6217(EIF_REFERENCE, EIF_REFERENCE);
extern void F938_6218(EIF_REFERENCE, EIF_REFERENCE);
extern void F938_6223(EIF_REFERENCE);
extern void F938_6236(EIF_REFERENCE);
extern void F938_6237(EIF_REFERENCE);
extern void EIF_Minit732(void);
extern EIF_BOOLEAN F872_5386(EIF_REFERENCE);
extern EIF_REFERENCE F733_3460(EIF_REFERENCE);
extern EIF_BOOLEAN F4_52(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1_29(EIF_REFERENCE);
extern EIF_INTEGER_32 F865_5085(EIF_REFERENCE);
extern void F700_3181(EIF_REFERENCE);
extern EIF_REFERENCE F700_3182(EIF_REFERENCE);
extern EIF_BOOLEAN F865_5051(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,3460)
RTOSHF(EIF_REFERENCE,3182)
extern char *(*R242[])();
extern char *(*R2474[])();
extern char *(*R2477[])();
extern char *(*R2481[])();
extern char *(*R2450[])();
extern char *(*R1994[])();
extern char *(*R237[])();
extern char *(*R4592[])();
extern EIF_TYPE_INDEX Y4493[];
extern EIF_TYPE_INDEX *Y4493_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
