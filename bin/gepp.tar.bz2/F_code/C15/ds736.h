
#ifndef _C15_ds736_
#define _C15_ds736_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F918_6052(EIF_REFERENCE);
extern void EIF_Minit736(void);
extern char *(*R4484[])();

#ifdef __cplusplus
}
#endif

#endif
