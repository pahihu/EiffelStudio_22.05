
#ifndef _C15_re703_
#define _C15_re703_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F562_2572(EIF_REFERENCE);
extern void EIF_Minit703(void);
extern EIF_INTEGER_32 F638_3038(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
