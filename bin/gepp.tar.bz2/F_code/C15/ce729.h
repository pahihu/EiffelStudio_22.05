
#ifndef _C15_ce729_
#define _C15_ce729_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F74_829(EIF_REFERENCE);
extern void F74_830(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit729(void);

#ifdef __cplusplus
}
#endif

#endif
