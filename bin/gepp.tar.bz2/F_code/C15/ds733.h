
#ifndef _C15_ds733_
#define _C15_ds733_

#ifdef __cplusplus
extern "C" {
#endif

extern void F893_5831(EIF_REFERENCE);
extern void EIF_Minit733(void);
extern void F940_6320(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
