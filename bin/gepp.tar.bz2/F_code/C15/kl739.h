
#ifndef _C15_kl739_
#define _C15_kl739_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F164_1391(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit739(void);

#ifdef __cplusplus
}
#endif

#endif
