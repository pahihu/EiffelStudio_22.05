
#ifndef _C15_re723_
#define _C15_re723_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F563_2572(EIF_REFERENCE);
extern void EIF_Minit723(void);
extern char *(*R2243[])();

#ifdef __cplusplus
}
#endif

#endif
