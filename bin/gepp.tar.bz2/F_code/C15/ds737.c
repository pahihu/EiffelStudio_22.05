/*
 * Code for class DS_CURSOR [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds737.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_CURSOR}.same_position */
EIF_BOOLEAN F890_5816 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F940_6317(RTCW(tr1), Current, arg1);
	RTLE;
	return Result;
}

/* {DS_CURSOR}.copy */
void F890_5819 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
		tb1 = (EIF_BOOLEAN) !F898_5858(Current);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F921_6094(RTCW(tr1), Current);
	}
	eif_builtin_ANY_standard_copy__o_ (Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	if ((EIF_BOOLEAN) !F898_5858(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F921_6093(RTCW(tr1), Current);
	}
	RTLE;
}

/* {DS_CURSOR}.is_equal */
EIF_BOOLEAN F890_5820 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(3460,F733_3460, (Current));
	tb1 = F4_52(RTCW(tr1), Current, arg1);
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) F890_5816(Current, arg1);
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {DS_CURSOR}.set_next_cursor */
void F890_5822 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

void EIF_Minit737 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
