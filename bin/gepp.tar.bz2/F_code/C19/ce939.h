
#ifndef _C19_ce939_
#define _C19_ce939_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F76_829(EIF_REFERENCE);
extern void F76_830(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit939(void);

#ifdef __cplusplus
}
#endif

#endif
