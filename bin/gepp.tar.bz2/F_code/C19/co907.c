/*
 * Code for class CONTAINER [REAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co907.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F398_2461 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O2178[Dtype(Current)-386]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit907 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
