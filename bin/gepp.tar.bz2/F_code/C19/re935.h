
#ifndef _C19_re935_
#define _C19_re935_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F567_2572(EIF_REFERENCE);
extern void EIF_Minit935(void);
extern EIF_INTEGER_32 F643_3038(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
