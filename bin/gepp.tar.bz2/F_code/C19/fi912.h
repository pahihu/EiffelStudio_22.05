
#ifndef _C19_fi912_
#define _C19_fi912_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F541_2559(EIF_REFERENCE);
extern void EIF_Minit912(void);
extern EIF_INTEGER_32 F643_3037(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
