
#ifndef _C19_co907_
#define _C19_co907_

#ifdef __cplusplus
extern "C" {
#endif

extern void F398_2461(EIF_REFERENCE);
extern void EIF_Minit907(void);
extern long O2178[];

#ifdef __cplusplus
}
#endif

#endif
