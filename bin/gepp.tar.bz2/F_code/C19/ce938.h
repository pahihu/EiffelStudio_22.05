
#ifndef _C19_ce938_
#define _C19_ce938_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F75_829(EIF_REFERENCE);
extern void F75_830(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit938(void);

#ifdef __cplusplus
}
#endif

#endif
