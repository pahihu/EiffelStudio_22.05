
#ifndef _C19_re910_
#define _C19_re910_

#ifdef __cplusplus
extern "C" {
#endif

extern void F329_2374(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F329_2376(EIF_REFERENCE);
extern EIF_INTEGER_32 F329_2377(EIF_REFERENCE);
extern EIF_INTEGER_32 F329_2378(EIF_REFERENCE);
extern EIF_INTEGER_32 F329_2379(EIF_REFERENCE);
extern EIF_BOOLEAN F329_2387(EIF_REFERENCE);
extern EIF_BOOLEAN F329_2388(EIF_REFERENCE);
extern void F329_2393(EIF_REFERENCE);
extern void EIF_Minit910(void);
extern char *(*R2451[])();
extern char *(*R2452[])();

#ifdef __cplusplus
}
#endif

#endif
