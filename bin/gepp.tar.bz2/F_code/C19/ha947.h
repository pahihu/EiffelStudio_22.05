
#ifndef _C19_ha947_
#define _C19_ha947_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F336_2402(EIF_REFERENCE);
extern EIF_REFERENCE F336_2403(EIF_REFERENCE);
extern EIF_BOOLEAN F336_2405(EIF_REFERENCE);
extern void F336_2406(EIF_REFERENCE);
extern EIF_REFERENCE F336_2407(EIF_REFERENCE);
extern void EIF_Minit947(void);
extern EIF_INTEGER_32 F718_3326(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F327_2388(EIF_REFERENCE);
extern EIF_INTEGER_32 F718_3325(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R2450[])();
extern char *(*R1993[])();

#ifdef __cplusplus
}
#endif

#endif
