
#ifndef _C19_to926_
#define _C19_to926_

#ifdef __cplusplus
extern "C" {
#endif

extern void F190_1755(EIF_REFERENCE, EIF_INTEGER_32);
extern void F190_1756(EIF_REFERENCE, EIF_REAL_64, EIF_INTEGER_32);
extern void F190_1762(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit926(void);
extern void F618_2937(EIF_REFERENCE, EIF_REAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1613[];
extern EIF_TYPE_INDEX *Y1613_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
