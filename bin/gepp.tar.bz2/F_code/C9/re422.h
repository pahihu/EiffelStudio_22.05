
#ifndef _C9_re422_
#define _C9_re422_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F557_2572(EIF_REFERENCE);
extern void EIF_Minit422(void);
extern EIF_INTEGER_32 F633_3038(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
