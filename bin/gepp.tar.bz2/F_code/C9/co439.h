
#ifndef _C9_co439_
#define _C9_co439_

#ifdef __cplusplus
extern "C" {
#endif

extern void F389_2461(EIF_REFERENCE);
extern void EIF_Minit439(void);
extern long O2178[];

#ifdef __cplusplus
}
#endif

#endif
