
#ifndef _C9_re433_
#define _C9_re433_

#ifdef __cplusplus
extern "C" {
#endif

extern void F320_2374(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F320_2376(EIF_REFERENCE);
extern EIF_INTEGER_32 F320_2377(EIF_REFERENCE);
extern EIF_INTEGER_32 F320_2378(EIF_REFERENCE);
extern EIF_INTEGER_32 F320_2379(EIF_REFERENCE);
extern EIF_BOOLEAN F320_2387(EIF_REFERENCE);
extern EIF_BOOLEAN F320_2388(EIF_REFERENCE);
extern void F320_2393(EIF_REFERENCE);
extern void EIF_Minit433(void);
extern char *(*R2451[])();
extern char *(*R2452[])();

#ifdef __cplusplus
}
#endif

#endif
