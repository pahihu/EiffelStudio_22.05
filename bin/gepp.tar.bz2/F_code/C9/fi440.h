
#ifndef _C9_fi440_
#define _C9_fi440_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F532_2559(EIF_REFERENCE);
extern void EIF_Minit440(void);
extern EIF_INTEGER_32 F634_3037(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
