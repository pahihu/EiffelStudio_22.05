
#ifndef _C9_to413_
#define _C9_to413_

#ifdef __cplusplus
extern "C" {
#endif

extern void F180_1755(EIF_REFERENCE, EIF_INTEGER_32);
extern void F180_1756(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F180_1762(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit413(void);
extern void F608_2937(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1613[];
extern EIF_TYPE_INDEX *Y1613_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
