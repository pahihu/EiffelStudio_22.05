
#ifndef _C11_fi547_
#define _C11_fi547_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F534_2559(EIF_REFERENCE);
extern void EIF_Minit547(void);
extern char *(*R2240[])();

#ifdef __cplusplus
}
#endif

#endif
