
#ifndef _C11_co534_
#define _C11_co534_

#ifdef __cplusplus
extern "C" {
#endif

extern void F391_2461(EIF_REFERENCE);
extern void EIF_Minit534(void);
extern long O2178[];

#ifdef __cplusplus
}
#endif

#endif
