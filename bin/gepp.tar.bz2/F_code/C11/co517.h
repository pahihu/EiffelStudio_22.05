
#ifndef _C11_co517_
#define _C11_co517_

#ifdef __cplusplus
extern "C" {
#endif

extern void F390_2461(EIF_REFERENCE);
extern void EIF_Minit517(void);
extern long O2178[];

#ifdef __cplusplus
}
#endif

#endif
