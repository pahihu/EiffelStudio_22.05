
#ifndef _C11_re539_
#define _C11_re539_

#ifdef __cplusplus
extern "C" {
#endif

extern void F322_2374(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F322_2376(EIF_REFERENCE);
extern EIF_INTEGER_32 F322_2377(EIF_REFERENCE);
extern EIF_INTEGER_32 F322_2378(EIF_REFERENCE);
extern EIF_INTEGER_32 F322_2379(EIF_REFERENCE);
extern EIF_BOOLEAN F322_2387(EIF_REFERENCE);
extern EIF_BOOLEAN F322_2388(EIF_REFERENCE);
extern void F322_2393(EIF_REFERENCE);
extern void EIF_Minit539(void);
extern char *(*R2451[])();
extern char *(*R2452[])();

#ifdef __cplusplus
}
#endif

#endif
