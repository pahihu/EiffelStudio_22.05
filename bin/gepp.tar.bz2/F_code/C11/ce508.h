
#ifndef _C11_ce508_
#define _C11_ce508_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F73_829(EIF_REFERENCE);
extern void F73_830(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit508(void);
extern long O825[];

#ifdef __cplusplus
}
#endif

#endif
