
#ifndef _C11_kl513_
#define _C11_kl513_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F13_233(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F13_236(EIF_REFERENCE, EIF_REFERENCE);
extern void F13_238(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F13_241(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F13_242(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit513(void);
extern char *(*R2466[])();
extern char *(*R2470[])();
extern char *(*R2483[])();
extern char *(*R2484[])();
extern char *(*R1993[])();
extern char *(*R1994[])();

#ifdef __cplusplus
}
#endif

#endif
