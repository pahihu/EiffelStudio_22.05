
#ifndef _C11_fi530_
#define _C11_fi530_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F533_2559(EIF_REFERENCE);
extern void EIF_Minit530(void);
extern char *(*R2240[])();

#ifdef __cplusplus
}
#endif

#endif
