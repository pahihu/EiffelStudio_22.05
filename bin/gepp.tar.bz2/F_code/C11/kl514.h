
#ifndef _C11_kl514_
#define _C11_kl514_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F739_3627(EIF_REFERENCE, EIF_REFERENCE);
extern void F739_3628(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit514(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R2529[])();

#ifdef __cplusplus
}
#endif

#endif
