
#ifndef _C11_re522_
#define _C11_re522_

#ifdef __cplusplus
extern "C" {
#endif

extern void F321_2374(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F321_2376(EIF_REFERENCE);
extern EIF_INTEGER_32 F321_2377(EIF_REFERENCE);
extern EIF_INTEGER_32 F321_2378(EIF_REFERENCE);
extern EIF_INTEGER_32 F321_2379(EIF_REFERENCE);
extern EIF_BOOLEAN F321_2387(EIF_REFERENCE);
extern EIF_BOOLEAN F321_2388(EIF_REFERENCE);
extern void F321_2393(EIF_REFERENCE);
extern void EIF_Minit522(void);
extern char *(*R2451[])();
extern char *(*R2452[])();

#ifdef __cplusplus
}
#endif

#endif
