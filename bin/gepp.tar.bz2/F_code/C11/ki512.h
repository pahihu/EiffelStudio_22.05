
#ifndef _C11_ki512_
#define _C11_ki512_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F88_878(EIF_REFERENCE);
extern void F88_885(EIF_REFERENCE);
extern void EIF_Minit512(void);

#ifdef __cplusplus
}
#endif

#endif
