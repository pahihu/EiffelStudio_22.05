
#ifndef _C10_kl469_
#define _C10_kl469_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F165_1391(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit469(void);

#ifdef __cplusplus
}
#endif

#endif
