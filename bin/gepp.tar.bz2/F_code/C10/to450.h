
#ifndef _C10_to450_
#define _C10_to450_

#ifdef __cplusplus
extern "C" {
#endif

extern void F181_1755(EIF_REFERENCE, EIF_INTEGER_32);
extern void F181_1756(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern void F181_1762(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit450(void);
extern void F609_2937(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1613[];
extern EIF_TYPE_INDEX *Y1613_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
