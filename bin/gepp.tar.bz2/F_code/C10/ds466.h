
#ifndef _C10_ds466_
#define _C10_ds466_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F919_6052(EIF_REFERENCE);
extern void EIF_Minit466(void);

#ifdef __cplusplus
}
#endif

#endif
