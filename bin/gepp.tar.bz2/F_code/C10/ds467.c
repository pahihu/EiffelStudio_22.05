/*
 * Code for class DS_CURSOR [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds467.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_CURSOR}.same_position */
EIF_BOOLEAN F891_5816 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	Result = (RTNA((RTCW(tr1), Current, arg1)), ((EIF_BOOLEAN) 0));
	RTLE;
	return Result;
}

/* {DS_CURSOR}.copy */
void F891_5819 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)((RTNA((Current)), ((EIF_REFERENCE) 0)) != NULL)) {
		tb1 = (EIF_BOOLEAN) !(RTNA((Current)), ((EIF_BOOLEAN) 0));
	}
	if (tb1) {
		tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
		(RTNA((RTCW(tr1), Current)));
	}
	(RTNA((Current, arg1)));
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	if ((EIF_BOOLEAN) !(RTNA((Current)), ((EIF_BOOLEAN) 0))) {
		tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
		(RTNA((RTCW(tr1), Current)));
	}
	RTLE;
}

/* {DS_CURSOR}.is_equal */
EIF_BOOLEAN F891_5820 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	tb1 = F4_52(RTCW(tr1), Current, arg1);
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) (RTNA((Current, arg1)), ((EIF_BOOLEAN) 0));
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {DS_CURSOR}.set_next_cursor */
void F891_5822 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

void EIF_Minit467 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
