
#ifndef _C10_ds463_
#define _C10_ds463_

#ifdef __cplusplus
extern "C" {
#endif

extern void F894_5831(EIF_REFERENCE);
extern void EIF_Minit463(void);

#ifdef __cplusplus
}
#endif

#endif
