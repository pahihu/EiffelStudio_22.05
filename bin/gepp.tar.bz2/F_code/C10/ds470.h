
#ifndef _C10_ds470_
#define _C10_ds470_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F937_6203(EIF_REFERENCE);
extern void EIF_Minit470(void);

#ifdef __cplusplus
}
#endif

#endif
