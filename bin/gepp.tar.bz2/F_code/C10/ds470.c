/*
 * Code for class DS_RESIZABLE [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds470.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_RESIZABLE}.is_full */
EIF_BOOLEAN F937_6203 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_1_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_));
}

void EIF_Minit470 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
