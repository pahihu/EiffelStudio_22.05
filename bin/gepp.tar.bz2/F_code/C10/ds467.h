
#ifndef _C10_ds467_
#define _C10_ds467_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F891_5816(EIF_REFERENCE, EIF_REFERENCE);
extern void F891_5819(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F891_5820(EIF_REFERENCE, EIF_REFERENCE);
extern void F891_5822(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit467(void);
extern EIF_BOOLEAN F4_52(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
