
#ifndef _C10_ds465_
#define _C10_ds465_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F922_6085(EIF_REFERENCE, EIF_REFERENCE);
extern void F922_6093(EIF_REFERENCE, EIF_REFERENCE);
extern void F922_6094(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit465(void);

#ifdef __cplusplus
}
#endif

#endif
