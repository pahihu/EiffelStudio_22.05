
#ifndef _C10_re459_
#define _C10_re459_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F558_2572(EIF_REFERENCE);
extern void EIF_Minit459(void);
extern EIF_INTEGER_32 F634_3038(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
