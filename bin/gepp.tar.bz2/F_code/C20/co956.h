
#ifndef _C20_co956_
#define _C20_co956_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F528_2529(EIF_REFERENCE);
extern EIF_BOOLEAN F528_2531(EIF_REFERENCE);
extern void F528_2537(EIF_REFERENCE);
extern void EIF_Minit956(void);

#ifdef __cplusplus
}
#endif

#endif
