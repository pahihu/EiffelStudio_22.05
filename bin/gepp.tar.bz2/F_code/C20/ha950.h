
#ifndef _C20_ha950_
#define _C20_ha950_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F333_2402(EIF_REFERENCE);
extern EIF_REFERENCE F333_2403(EIF_REFERENCE);
extern EIF_BOOLEAN F333_2405(EIF_REFERENCE);
extern void F333_2406(EIF_REFERENCE);
extern EIF_REFERENCE F333_2407(EIF_REFERENCE);
extern void EIF_Minit950(void);
extern EIF_BOOLEAN F319_2388(EIF_REFERENCE);
extern char *(*R2644[])();
extern char *(*R2645[])();
extern char *(*R2450[])();
extern char *(*R1993[])();

#ifdef __cplusplus
}
#endif

#endif
