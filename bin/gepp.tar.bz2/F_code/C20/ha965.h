
#ifndef _C20_ha965_
#define _C20_ha965_

#ifdef __cplusplus
extern "C" {
#endif

extern void F716_3281(EIF_REFERENCE, EIF_INTEGER_32);
extern void F716_3284(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F716_3285(EIF_REFERENCE);
extern EIF_REFERENCE F716_3287(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F716_3289(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F716_3296(EIF_REFERENCE);
extern EIF_INTEGER_32 F716_3298(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F716_3299(EIF_REFERENCE);
extern EIF_INTEGER_32 F716_3302(EIF_REFERENCE);
extern EIF_INTEGER_32 F716_3303(EIF_REFERENCE);
extern EIF_BOOLEAN F716_3304(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F716_3305(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_BOOLEAN F716_3313(EIF_REFERENCE);
extern EIF_BOOLEAN F716_3314(EIF_REFERENCE);
extern void F716_3323(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F716_3325(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F716_3326(EIF_REFERENCE, EIF_INTEGER_32);
extern void F716_3327(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F716_3328(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F716_3335(EIF_REFERENCE);
extern void F716_3338(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F716_3339(EIF_REFERENCE, EIF_INTEGER_32);
extern void F716_3340(EIF_REFERENCE);
extern EIF_INTEGER_32 F716_3349(EIF_REFERENCE);
extern EIF_BOOLEAN F716_3350(EIF_REFERENCE);
extern EIF_REFERENCE F716_3357(EIF_REFERENCE);
extern EIF_INTEGER_32 F716_3358(EIF_REFERENCE);
extern EIF_INTEGER_32 F716_3359(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F716_3360(EIF_REFERENCE, EIF_INTEGER_32);
extern void F716_3363(EIF_REFERENCE, EIF_REFERENCE);
extern void F716_3365(EIF_REFERENCE, EIF_REFERENCE);
extern void F716_3366(EIF_REFERENCE, EIF_REFERENCE);
extern void F716_3367(EIF_REFERENCE, EIF_REFERENCE);
extern void F716_3371(EIF_REFERENCE, EIF_INTEGER_32);
extern void F716_3377(EIF_REFERENCE);
extern void F716_3390(EIF_REFERENCE);
extern void EIF_Minit965(void);
extern EIF_INTEGER_32 F612_2948(EIF_REFERENCE);
extern void F612_2958(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F700_3181(EIF_REFERENCE);
extern EIF_REFERENCE F714_3287(EIF_REFERENCE, EIF_REFERENCE);
extern void F608_2955(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F612_2955(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F608_2937(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F529_2549(EIF_REFERENCE, EIF_INTEGER_32);
extern void F608_2974(EIF_REFERENCE);
extern void F612_2937(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern void F608_2958(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_BOOLEAN F714_3289(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F700_3182(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,3182)
extern char *(*R2616[])();
extern char *(*R2617[])();
extern char *(*R2076[])();
extern char *(*R2633[])();
extern char *(*R2467[])();
extern char *(*R2660[])();
extern char *(*R2661[])();
extern char *(*R2486[])();
extern char *(*R2701[])();
extern char *(*R2625[])();
extern char *(*R2627[])();
extern char *(*R2043[])();
extern char *(*R2044[])();
extern char *(*R2045[])();
extern char *(*R2634[])();
extern char *(*R2670[])();
extern char *(*R2671[])();
extern char *(*R2674[])();
extern char *(*R2676[])();
extern char *(*R2677[])();
extern char *(*R2678[])();
extern char *(*R2056[])();
extern char *(*R2682[])();
extern char *(*R2642[])();
extern char *(*R2644[])();
extern char *(*R2645[])();
extern char *(*R2216[])();
extern char *(*R2450[])();
extern char *(*R2180[])();
extern char *(*R1993[])();
extern char *(*R1994[])();
extern char *(*R2688[])();
extern char *(*R2148[])();
extern char *(*R2145[])();
extern char *(*R2651[])();
extern char *(*R2613[])();
extern long O2653[];
extern long O2654[];
extern long O2655[];
extern long O2656[];
extern long O2657[];
extern long O2658[];
extern long O2659[];
extern long O2617[];
extern long O2662[];
extern long O2663[];
extern long O2667[];
extern long O2668[];
extern long O2626[];
extern long O2703[];
extern long O2669[];
extern long O2178[];
extern EIF_TYPE_INDEX Y2218[];
extern EIF_TYPE_INDEX *Y2218_gen_type [];
extern EIF_TYPE_INDEX Y2653[];
extern EIF_TYPE_INDEX *Y2653_gen_type [];
extern EIF_TYPE_INDEX Y2654[];
extern EIF_TYPE_INDEX *Y2654_gen_type [];
extern EIF_TYPE_INDEX Y2077[];
extern EIF_TYPE_INDEX *Y2077_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
