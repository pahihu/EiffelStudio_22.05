
#ifndef _C20_ha968_
#define _C20_ha968_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F334_2402(EIF_REFERENCE);
extern EIF_INTEGER_32 F334_2403(EIF_REFERENCE);
extern EIF_BOOLEAN F334_2405(EIF_REFERENCE);
extern void F334_2406(EIF_REFERENCE);
extern EIF_REFERENCE F334_2407(EIF_REFERENCE);
extern void EIF_Minit968(void);
extern char *(*R2644[])();
extern char *(*R2645[])();
extern char *(*R2450[])();
extern char *(*R2142[])();
extern long O2653[];
extern long O2654[];

#ifdef __cplusplus
}
#endif

#endif
