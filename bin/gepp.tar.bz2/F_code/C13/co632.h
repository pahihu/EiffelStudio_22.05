
#ifndef _C13_co632_
#define _C13_co632_

#ifdef __cplusplus
extern "C" {
#endif

extern void F394_2461(EIF_REFERENCE);
extern void EIF_Minit632(void);
extern long O2178[];

#ifdef __cplusplus
}
#endif

#endif
