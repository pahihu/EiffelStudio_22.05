
#ifndef _C13_fi637_
#define _C13_fi637_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F537_2559(EIF_REFERENCE);
extern void EIF_Minit637(void);
extern EIF_INTEGER_32 F637_3037(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
