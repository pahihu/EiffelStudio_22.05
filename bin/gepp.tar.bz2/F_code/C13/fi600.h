
#ifndef _C13_fi600_
#define _C13_fi600_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F536_2559(EIF_REFERENCE);
extern void EIF_Minit600(void);
extern EIF_INTEGER_32 F636_3037(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
