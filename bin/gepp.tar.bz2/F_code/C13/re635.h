
#ifndef _C13_re635_
#define _C13_re635_

#ifdef __cplusplus
extern "C" {
#endif

extern void F325_2374(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F325_2376(EIF_REFERENCE);
extern EIF_INTEGER_32 F325_2377(EIF_REFERENCE);
extern EIF_INTEGER_32 F325_2378(EIF_REFERENCE);
extern EIF_INTEGER_32 F325_2379(EIF_REFERENCE);
extern EIF_BOOLEAN F325_2387(EIF_REFERENCE);
extern EIF_BOOLEAN F325_2388(EIF_REFERENCE);
extern void F325_2393(EIF_REFERENCE);
extern void EIF_Minit635(void);
extern char *(*R2451[])();
extern char *(*R2452[])();

#ifdef __cplusplus
}
#endif

#endif
