
#ifndef _C13_re619_
#define _C13_re619_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F560_2572(EIF_REFERENCE);
extern void EIF_Minit619(void);
extern EIF_INTEGER_32 F636_3038(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
