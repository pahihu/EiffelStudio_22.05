
#ifndef _C13_to610_
#define _C13_to610_

#ifdef __cplusplus
extern "C" {
#endif

extern void F183_1755(EIF_REFERENCE, EIF_INTEGER_32);
extern void F183_1756(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern void F183_1762(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit610(void);
extern void F611_2937(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1613[];
extern EIF_TYPE_INDEX *Y1613_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
