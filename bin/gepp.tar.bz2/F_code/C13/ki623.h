
#ifndef _C13_ki623_
#define _C13_ki623_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F87_878(EIF_REFERENCE);
extern void F87_885(EIF_REFERENCE);
extern void EIF_Minit623(void);

#ifdef __cplusplus
}
#endif

#endif
