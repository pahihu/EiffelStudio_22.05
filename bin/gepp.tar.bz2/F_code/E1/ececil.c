#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* MISMATCH_INFORMATION wipe_out */
void A173_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F714_3335)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A173_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F721_3408)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A173_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F721_3409)(Current, arg1, arg2);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN _A254_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F534_2559)(open [1].it_r);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN __A254_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F534_2559)(op_1);
}


#ifdef __cplusplus
}
#endif
