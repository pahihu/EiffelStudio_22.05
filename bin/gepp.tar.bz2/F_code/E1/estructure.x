#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_13 {union overhead overhead; char data [1];};
struct eif_ex_204 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_207 {union overhead overhead; char data [@OBJSIZ(0,0,1,0,0,0,0,0)];};
struct eif_ex_210 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_213 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,1,0)];};
struct eif_ex_216 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_219 {union overhead overhead; char data [@OBJSIZ(0,0,1,0,0,0,0,0)];};
struct eif_ex_222 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_225 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,1,0,0,0)];};
struct eif_ex_228 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,0,1)];};
struct eif_ex_231 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_234 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_237 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_240 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,1,0)];};
struct eif_ex_315 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_365 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_369 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_373 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_478 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_482 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_486 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_490 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_494 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_498 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_745 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_749 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_754 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_763 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_767 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_243 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};

#ifdef __cplusplus
}
#endif
#endif
