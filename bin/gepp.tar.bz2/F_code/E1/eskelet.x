#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif
extern const char *names3[];
static const uint32 types3 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags3 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype3_0 [] = {0xFF01,717,858,0xFF01,870,0xFFFF};
static const EIF_TYPE_INDEX g_atype3_1 [] = {0xFF01,713,0xFF01,870,0xFF01,870,0xFFFF};

static const EIF_TYPE_INDEX *gtypes3 [] = {
g_atype3_0,
g_atype3_1,
};

static const long offsets3 [] =
{
0,
 + @REFACS(1),
};

extern const char *names5[];
static const uint32 types5 [] =
{
SK_UINT32,
};

static const uint16 attr_flags5 [] =
{1,};

static const EIF_TYPE_INDEX g_atype5_0 [] = {801,0xFFFF};

static const EIF_TYPE_INDEX *gtypes5 [] = {
g_atype5_0,
};

static const long offsets5 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names8[];
static const uint32 types8 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags8 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype8_0 [] = {0xFF01,870,0xFFFF};
static const EIF_TYPE_INDEX g_atype8_1 [] = {0xFF01,901,0xFFFF};

static const EIF_TYPE_INDEX *gtypes8 [] = {
g_atype8_0,
g_atype8_1,
};

static const long offsets8 [] =
{
0,
 + @REFACS(1),
};

extern const char *names19[];
static const uint32 types19 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags19 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype19_0 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype19_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype19_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype19_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes19 [] = {
g_atype19_0,
g_atype19_1,
g_atype19_2,
g_atype19_3,
};

static const long offsets19 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @LNGOFF(0,3,0,0),
};

extern const char *names36[];
static const uint32 types36 [] =
{
SK_REF,
};

static const uint16 attr_flags36 [] =
{0,};

static const EIF_TYPE_INDEX g_atype36_0 [] = {593,0xFFFF};

static const EIF_TYPE_INDEX *gtypes36 [] = {
g_atype36_0,
};

static const long offsets36 [] =
{
0,
};

extern const char *names49[];
static const uint32 types49 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags49 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype49_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype49_1 [] = {860,0xFF01,0xFFF9,1,786,0xFF01,172,0xFFFF};
static const EIF_TYPE_INDEX g_atype49_2 [] = {860,0xFF01,0xFFF9,2,786,0xFF01,172,0xFF01,172,0xFFFF};
static const EIF_TYPE_INDEX g_atype49_3 [] = {860,0xFF01,0xFFF9,1,786,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype49_4 [] = {701,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype49_5 [] = {716,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype49_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype49_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype49_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype49_9 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype49_10 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype49_11 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes49 [] = {
g_atype49_0,
g_atype49_1,
g_atype49_2,
g_atype49_3,
g_atype49_4,
g_atype49_5,
g_atype49_6,
g_atype49_7,
g_atype49_8,
g_atype49_9,
g_atype49_10,
g_atype49_11,
};

static const long offsets49 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names50[];
static const uint32 types50 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags50 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype50_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype50_1 [] = {860,0xFF01,0xFFF9,1,786,0xFF01,172,0xFFFF};
static const EIF_TYPE_INDEX g_atype50_2 [] = {860,0xFF01,0xFFF9,2,786,0xFF01,172,0xFF01,172,0xFFFF};
static const EIF_TYPE_INDEX g_atype50_3 [] = {860,0xFF01,0xFFF9,1,786,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype50_4 [] = {701,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype50_5 [] = {716,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype50_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype50_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype50_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype50_9 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype50_10 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype50_11 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes50 [] = {
g_atype50_0,
g_atype50_1,
g_atype50_2,
g_atype50_3,
g_atype50_4,
g_atype50_5,
g_atype50_6,
g_atype50_7,
g_atype50_8,
g_atype50_9,
g_atype50_10,
g_atype50_11,
};

static const long offsets50 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names53[];
static const uint32 types53 [] =
{
SK_REF,
};

static const uint16 attr_flags53 [] =
{0,};

static const EIF_TYPE_INDEX g_atype53_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes53 [] = {
g_atype53_0,
};

static const long offsets53 [] =
{
0,
};

extern const char *names54[];
static const uint32 types54 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags54 [] =
{0,};

static const EIF_TYPE_INDEX g_atype54_0 [] = {819,0xFFFF};

static const EIF_TYPE_INDEX *gtypes54 [] = {
g_atype54_0,
};

static const long offsets54 [] =
{
+ @CHROFF(0,0),
};

extern const char *names55[];
static const uint32 types55 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags55 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype55_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_1 [] = {54,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes55 [] = {
g_atype55_0,
g_atype55_1,
};

static const long offsets55 [] =
{
0,
 + @REFACS(1),
};

extern const char *names56[];
static const uint32 types56 [] =
{
SK_REF,
SK_CHAR8,
};

static const uint16 attr_flags56 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype56_0 [] = {55,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_1 [] = {819,0xFFFF};

static const EIF_TYPE_INDEX *gtypes56 [] = {
g_atype56_0,
g_atype56_1,
};

static const long offsets56 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names73[];
static const uint32 types73 [] =
{
SK_REF,
};

static const uint16 attr_flags73 [] =
{0,};

static const EIF_TYPE_INDEX g_atype73_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes73 [] = {
g_atype73_0,
};

static const long offsets73 [] =
{
0,
};

extern const char *names74[];
static const uint32 types74 [] =
{
SK_INT32,
};

static const uint16 attr_flags74 [] =
{0,};

static const EIF_TYPE_INDEX g_atype74_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes74 [] = {
g_atype74_0,
};

static const long offsets74 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names75[];
static const uint32 types75 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags75 [] =
{0,};

static const EIF_TYPE_INDEX g_atype75_0 [] = {816,0xFFFF};

static const EIF_TYPE_INDEX *gtypes75 [] = {
g_atype75_0,
};

static const long offsets75 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names76[];
static const uint32 types76 [] =
{
SK_UINT64,
};

static const uint16 attr_flags76 [] =
{0,};

static const EIF_TYPE_INDEX g_atype76_0 [] = {798,0xFFFF};

static const EIF_TYPE_INDEX *gtypes76 [] = {
g_atype76_0,
};

static const long offsets76 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names77[];
static const uint32 types77 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags77 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype77_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_1 [] = {76,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes77 [] = {
g_atype77_0,
g_atype77_1,
};

static const long offsets77 [] =
{
0,
 + @REFACS(1),
};

extern const char *names78[];
static const uint32 types78 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags78 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype78_0 [] = {77,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype78_1 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes78 [] = {
g_atype78_0,
g_atype78_1,
};

static const long offsets78 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names94[];
static const uint32 types94 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags94 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype94_0 [] = {0xFF01,608,798,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_1 [] = {0xFF01,608,798,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_2 [] = {0xFF01,608,798,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_3 [] = {0xFF01,608,798,0xFFFF};

static const EIF_TYPE_INDEX *gtypes94 [] = {
g_atype94_0,
g_atype94_1,
g_atype94_2,
g_atype94_3,
};

static const long offsets94 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names95[];
static const uint32 types95 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags95 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype95_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_1 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes95 [] = {
g_atype95_0,
g_atype95_1,
g_atype95_2,
g_atype95_3,
g_atype95_4,
g_atype95_5,
g_atype95_6,
};

static const long offsets95 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
};

extern const char *names96[];
static const uint32 types96 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags96 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype96_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_1 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_2 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_9 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_10 [] = {798,0xFFFF};

static const EIF_TYPE_INDEX *gtypes96 [] = {
g_atype96_0,
g_atype96_1,
g_atype96_2,
g_atype96_3,
g_atype96_4,
g_atype96_5,
g_atype96_6,
g_atype96_7,
g_atype96_8,
g_atype96_9,
g_atype96_10,
};

static const long offsets96 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @I64OFF(2,4,0,3,0,0,0),
+ @I64OFF(2,4,0,3,0,0,1),
};

extern const char *names97[];
static const uint32 types97 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags97 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype97_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_1 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_12 [] = {813,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_13 [] = {813,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_14 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes97 [] = {
g_atype97_0,
g_atype97_1,
g_atype97_2,
g_atype97_3,
g_atype97_4,
g_atype97_5,
g_atype97_6,
g_atype97_7,
g_atype97_8,
g_atype97_9,
g_atype97_10,
g_atype97_11,
g_atype97_12,
g_atype97_13,
g_atype97_14,
};

static const long offsets97 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @R64OFF(2,6,0,4,0,0,0,0),
+ @R64OFF(2,6,0,4,0,0,0,1),
+ @R64OFF(2,6,0,4,0,0,0,2),
};

extern const char *names98[];
static const uint32 types98 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags98 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype98_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_1 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_8 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_9 [] = {798,0xFFFF};

static const EIF_TYPE_INDEX *gtypes98 [] = {
g_atype98_0,
g_atype98_1,
g_atype98_2,
g_atype98_3,
g_atype98_4,
g_atype98_5,
g_atype98_6,
g_atype98_7,
g_atype98_8,
g_atype98_9,
};

static const long offsets98 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
+ @LNGOFF(2,3,0,1),
+ @LNGOFF(2,3,0,2),
+ @I64OFF(2,3,0,3,0,0,0),
+ @I64OFF(2,3,0,3,0,0,1),
};

extern const char *names99[];
static const uint32 types99 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags99 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype99_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_1 [] = {606,0xFF01,607,789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes99 [] = {
g_atype99_0,
g_atype99_1,
};

static const long offsets99 [] =
{
0,
 + @REFACS(1),
};

extern const char *names100[];
static const uint32 types100 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags100 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype100_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_1 [] = {606,0xFF01,607,789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes100 [] = {
g_atype100_0,
g_atype100_1,
};

static const long offsets100 [] =
{
0,
 + @REFACS(1),
};

extern const char *names101[];
static const uint32 types101 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags101 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype101_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_1 [] = {606,0xFF01,607,789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes101 [] = {
g_atype101_0,
g_atype101_1,
};

static const long offsets101 [] =
{
0,
 + @REFACS(1),
};

extern const char *names111[];
static const uint32 types111 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags111 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype111_0 [] = {76,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_2 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes111 [] = {
g_atype111_0,
g_atype111_1,
g_atype111_2,
};

static const long offsets111 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names112[];
static const uint32 types112 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags112 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype112_0 [] = {77,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_2 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes112 [] = {
g_atype112_0,
g_atype112_1,
g_atype112_2,
};

static const long offsets112 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names113[];
static const uint32 types113 [] =
{
SK_INT32,
};

static const uint16 attr_flags113 [] =
{0,};

static const EIF_TYPE_INDEX g_atype113_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes113 [] = {
g_atype113_0,
};

static const long offsets113 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names114[];
static const uint32 types114 [] =
{
SK_INT32,
};

static const uint16 attr_flags114 [] =
{0,};

static const EIF_TYPE_INDEX g_atype114_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes114 [] = {
g_atype114_0,
};

static const long offsets114 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names115[];
static const uint32 types115 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags115 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype115_0 [] = {0xFF01,63,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_9 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes115 [] = {
g_atype115_0,
g_atype115_1,
g_atype115_2,
g_atype115_3,
g_atype115_4,
g_atype115_5,
g_atype115_6,
g_atype115_7,
g_atype115_8,
g_atype115_9,
};

static const long offsets115 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names116[];
static const uint32 types116 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags116 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype116_0 [] = {0xFF01,63,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_9 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes116 [] = {
g_atype116_0,
g_atype116_1,
g_atype116_2,
g_atype116_3,
g_atype116_4,
g_atype116_5,
g_atype116_6,
g_atype116_7,
g_atype116_8,
g_atype116_9,
};

static const long offsets116 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names117[];
static const uint32 types117 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags117 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype117_0 [] = {0xFF01,197,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_9 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes117 [] = {
g_atype117_0,
g_atype117_1,
g_atype117_2,
g_atype117_3,
g_atype117_4,
g_atype117_5,
g_atype117_6,
g_atype117_7,
g_atype117_8,
g_atype117_9,
};

static const long offsets117 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names118[];
static const uint32 types118 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags118 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype118_0 [] = {0xFF01,63,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_1 [] = {0xFF01,745,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_11 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes118 [] = {
g_atype118_0,
g_atype118_1,
g_atype118_2,
g_atype118_3,
g_atype118_4,
g_atype118_5,
g_atype118_6,
g_atype118_7,
g_atype118_8,
g_atype118_9,
g_atype118_10,
g_atype118_11,
};

static const long offsets118 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
};

extern const char *names119[];
static const uint32 types119 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags119 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype119_0 [] = {0xFF01,63,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_1 [] = {0xFF01,745,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_13 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes119 [] = {
g_atype119_0,
g_atype119_1,
g_atype119_2,
g_atype119_3,
g_atype119_4,
g_atype119_5,
g_atype119_6,
g_atype119_7,
g_atype119_8,
g_atype119_9,
g_atype119_10,
g_atype119_11,
g_atype119_12,
g_atype119_13,
};

static const long offsets119 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
+ @LNGOFF(2,4,0,6),
+ @LNGOFF(2,4,0,7),
};

extern const char *names120[];
static const uint32 types120 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags120 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype120_0 [] = {0xFF01,197,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_1 [] = {0xFF01,745,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_14 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes120 [] = {
g_atype120_0,
g_atype120_1,
g_atype120_2,
g_atype120_3,
g_atype120_4,
g_atype120_5,
g_atype120_6,
g_atype120_7,
g_atype120_8,
g_atype120_9,
g_atype120_10,
g_atype120_11,
g_atype120_12,
g_atype120_13,
g_atype120_14,
};

static const long offsets120 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @LNGOFF(2,5,0,0),
+ @LNGOFF(2,5,0,1),
+ @LNGOFF(2,5,0,2),
+ @LNGOFF(2,5,0,3),
+ @LNGOFF(2,5,0,4),
+ @LNGOFF(2,5,0,5),
+ @LNGOFF(2,5,0,6),
+ @LNGOFF(2,5,0,7),
};

extern const char *names124[];
static const uint32 types124 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags124 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype124_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype124_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes124 [] = {
g_atype124_0,
g_atype124_1,
g_atype124_2,
g_atype124_3,
g_atype124_4,
g_atype124_5,
g_atype124_6,
};

static const long offsets124 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names125[];
static const uint32 types125 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags125 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype125_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype125_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes125 [] = {
g_atype125_0,
g_atype125_1,
g_atype125_2,
g_atype125_3,
g_atype125_4,
g_atype125_5,
g_atype125_6,
};

static const long offsets125 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names126[];
static const uint32 types126 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags126 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype126_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype126_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes126 [] = {
g_atype126_0,
g_atype126_1,
g_atype126_2,
g_atype126_3,
g_atype126_4,
g_atype126_5,
g_atype126_6,
};

static const long offsets126 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names127[];
static const uint32 types127 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags127 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype127_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes127 [] = {
g_atype127_0,
g_atype127_1,
g_atype127_2,
g_atype127_3,
g_atype127_4,
g_atype127_5,
g_atype127_6,
};

static const long offsets127 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names128[];
static const uint32 types128 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags128 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype128_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes128 [] = {
g_atype128_0,
g_atype128_1,
g_atype128_2,
g_atype128_3,
g_atype128_4,
g_atype128_5,
g_atype128_6,
};

static const long offsets128 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names129[];
static const uint32 types129 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags129 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype129_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype129_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes129 [] = {
g_atype129_0,
g_atype129_1,
g_atype129_2,
g_atype129_3,
g_atype129_4,
g_atype129_5,
g_atype129_6,
};

static const long offsets129 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names130[];
static const uint32 types130 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags130 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype130_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes130 [] = {
g_atype130_0,
g_atype130_1,
g_atype130_2,
g_atype130_3,
g_atype130_4,
g_atype130_5,
g_atype130_6,
};

static const long offsets130 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names131[];
static const uint32 types131 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags131 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype131_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_5 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype131_9 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes131 [] = {
g_atype131_0,
g_atype131_1,
g_atype131_2,
g_atype131_3,
g_atype131_4,
g_atype131_5,
g_atype131_6,
g_atype131_7,
g_atype131_8,
g_atype131_9,
};

static const long offsets131 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
+ @LNGOFF(6,1,0,2),
};

extern const char *names132[];
static const uint32 types132 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags132 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype132_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_7 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes132 [] = {
g_atype132_0,
g_atype132_1,
g_atype132_2,
g_atype132_3,
g_atype132_4,
g_atype132_5,
g_atype132_6,
g_atype132_7,
};

static const long offsets132 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names133[];
static const uint32 types133 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags133 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype133_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype133_7 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes133 [] = {
g_atype133_0,
g_atype133_1,
g_atype133_2,
g_atype133_3,
g_atype133_4,
g_atype133_5,
g_atype133_6,
g_atype133_7,
};

static const long offsets133 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names134[];
static const uint32 types134 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags134 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype134_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes134 [] = {
g_atype134_0,
g_atype134_1,
g_atype134_2,
g_atype134_3,
g_atype134_4,
g_atype134_5,
g_atype134_6,
};

static const long offsets134 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names135[];
static const uint32 types135 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags135 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype135_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes135 [] = {
g_atype135_0,
g_atype135_1,
g_atype135_2,
g_atype135_3,
g_atype135_4,
g_atype135_5,
g_atype135_6,
};

static const long offsets135 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names136[];
static const uint32 types136 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags136 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype136_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_7 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes136 [] = {
g_atype136_0,
g_atype136_1,
g_atype136_2,
g_atype136_3,
g_atype136_4,
g_atype136_5,
g_atype136_6,
g_atype136_7,
};

static const long offsets136 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names137[];
static const uint32 types137 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags137 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype137_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes137 [] = {
g_atype137_0,
g_atype137_1,
g_atype137_2,
g_atype137_3,
g_atype137_4,
g_atype137_5,
g_atype137_6,
};

static const long offsets137 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names138[];
static const uint32 types138 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags138 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype138_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes138 [] = {
g_atype138_0,
g_atype138_1,
g_atype138_2,
g_atype138_3,
g_atype138_4,
g_atype138_5,
g_atype138_6,
};

static const long offsets138 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names139[];
static const uint32 types139 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags139 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype139_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_7 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes139 [] = {
g_atype139_0,
g_atype139_1,
g_atype139_2,
g_atype139_3,
g_atype139_4,
g_atype139_5,
g_atype139_6,
g_atype139_7,
};

static const long offsets139 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names140[];
static const uint32 types140 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags140 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype140_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes140 [] = {
g_atype140_0,
g_atype140_1,
g_atype140_2,
g_atype140_3,
g_atype140_4,
g_atype140_5,
g_atype140_6,
};

static const long offsets140 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names141[];
static const uint32 types141 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags141 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype141_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes141 [] = {
g_atype141_0,
g_atype141_1,
g_atype141_2,
g_atype141_3,
g_atype141_4,
g_atype141_5,
g_atype141_6,
};

static const long offsets141 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names142[];
static const uint32 types142 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags142 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype142_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes142 [] = {
g_atype142_0,
g_atype142_1,
g_atype142_2,
g_atype142_3,
g_atype142_4,
g_atype142_5,
g_atype142_6,
};

static const long offsets142 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names143[];
static const uint32 types143 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags143 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype143_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes143 [] = {
g_atype143_0,
g_atype143_1,
g_atype143_2,
g_atype143_3,
g_atype143_4,
g_atype143_5,
g_atype143_6,
};

static const long offsets143 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names144[];
static const uint32 types144 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags144 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype144_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_8 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes144 [] = {
g_atype144_0,
g_atype144_1,
g_atype144_2,
g_atype144_3,
g_atype144_4,
g_atype144_5,
g_atype144_6,
g_atype144_7,
g_atype144_8,
};

static const long offsets144 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
};

extern const char *names145[];
static const uint32 types145 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags145 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype145_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes145 [] = {
g_atype145_0,
g_atype145_1,
g_atype145_2,
g_atype145_3,
g_atype145_4,
g_atype145_5,
g_atype145_6,
};

static const long offsets145 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names146[];
static const uint32 types146 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags146 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype146_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes146 [] = {
g_atype146_0,
g_atype146_1,
g_atype146_2,
g_atype146_3,
g_atype146_4,
g_atype146_5,
g_atype146_6,
};

static const long offsets146 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names147[];
static const uint32 types147 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags147 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype147_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes147 [] = {
g_atype147_0,
g_atype147_1,
g_atype147_2,
g_atype147_3,
g_atype147_4,
g_atype147_5,
g_atype147_6,
};

static const long offsets147 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names148[];
static const uint32 types148 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags148 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype148_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes148 [] = {
g_atype148_0,
g_atype148_1,
g_atype148_2,
g_atype148_3,
g_atype148_4,
g_atype148_5,
g_atype148_6,
};

static const long offsets148 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names149[];
static const uint32 types149 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags149 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype149_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_5 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_6 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_8 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes149 [] = {
g_atype149_0,
g_atype149_1,
g_atype149_2,
g_atype149_3,
g_atype149_4,
g_atype149_5,
g_atype149_6,
g_atype149_7,
g_atype149_8,
};

static const long offsets149 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names150[];
static const uint32 types150 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags150 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype150_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes150 [] = {
g_atype150_0,
g_atype150_1,
g_atype150_2,
g_atype150_3,
g_atype150_4,
g_atype150_5,
g_atype150_6,
};

static const long offsets150 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names151[];
static const uint32 types151 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags151 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype151_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes151 [] = {
g_atype151_0,
g_atype151_1,
g_atype151_2,
g_atype151_3,
g_atype151_4,
g_atype151_5,
g_atype151_6,
};

static const long offsets151 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names152[];
static const uint32 types152 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags152 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype152_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes152 [] = {
g_atype152_0,
g_atype152_1,
g_atype152_2,
g_atype152_3,
g_atype152_4,
g_atype152_5,
g_atype152_6,
};

static const long offsets152 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names153[];
static const uint32 types153 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags153 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype153_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes153 [] = {
g_atype153_0,
g_atype153_1,
g_atype153_2,
g_atype153_3,
g_atype153_4,
g_atype153_5,
g_atype153_6,
};

static const long offsets153 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names154[];
static const uint32 types154 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags154 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype154_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes154 [] = {
g_atype154_0,
g_atype154_1,
g_atype154_2,
g_atype154_3,
g_atype154_4,
g_atype154_5,
g_atype154_6,
};

static const long offsets154 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names155[];
static const uint32 types155 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags155 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype155_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes155 [] = {
g_atype155_0,
g_atype155_1,
g_atype155_2,
g_atype155_3,
g_atype155_4,
g_atype155_5,
g_atype155_6,
};

static const long offsets155 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names156[];
static const uint32 types156 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags156 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype156_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes156 [] = {
g_atype156_0,
g_atype156_1,
g_atype156_2,
g_atype156_3,
g_atype156_4,
g_atype156_5,
g_atype156_6,
};

static const long offsets156 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names157[];
static const uint32 types157 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags157 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype157_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes157 [] = {
g_atype157_0,
g_atype157_1,
g_atype157_2,
g_atype157_3,
g_atype157_4,
g_atype157_5,
g_atype157_6,
};

static const long offsets157 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names158[];
static const uint32 types158 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags158 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype158_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes158 [] = {
g_atype158_0,
g_atype158_1,
g_atype158_2,
g_atype158_3,
g_atype158_4,
g_atype158_5,
g_atype158_6,
};

static const long offsets158 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names159[];
static const uint32 types159 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags159 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype159_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes159 [] = {
g_atype159_0,
g_atype159_1,
g_atype159_2,
g_atype159_3,
g_atype159_4,
g_atype159_5,
g_atype159_6,
};

static const long offsets159 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names160[];
static const uint32 types160 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags160 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype160_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes160 [] = {
g_atype160_0,
g_atype160_1,
g_atype160_2,
g_atype160_3,
g_atype160_4,
g_atype160_5,
g_atype160_6,
};

static const long offsets160 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names161[];
static const uint32 types161 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags161 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype161_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes161 [] = {
g_atype161_0,
g_atype161_1,
g_atype161_2,
g_atype161_3,
g_atype161_4,
g_atype161_5,
g_atype161_6,
};

static const long offsets161 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names162[];
static const uint32 types162 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags162 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype162_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes162 [] = {
g_atype162_0,
g_atype162_1,
g_atype162_2,
g_atype162_3,
g_atype162_4,
g_atype162_5,
g_atype162_6,
};

static const long offsets162 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names163[];
static const uint32 types163 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags163 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype163_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_2 [] = {123,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_3 [] = {199,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_4 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_7 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes163 [] = {
g_atype163_0,
g_atype163_1,
g_atype163_2,
g_atype163_3,
g_atype163_4,
g_atype163_5,
g_atype163_6,
g_atype163_7,
};

static const long offsets163 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names168[];
static const uint32 types168 [] =
{
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_UINT64,
};

static const uint16 attr_flags168 [] =
{0,0,1,1,};

static const EIF_TYPE_INDEX g_atype168_0 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_2 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_3 [] = {798,0xFFFF};

static const EIF_TYPE_INDEX *gtypes168 [] = {
g_atype168_0,
g_atype168_1,
g_atype168_2,
g_atype168_3,
};

static const long offsets168 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @PTROFF(0,1,0,1,0,0),
+ @I64OFF(0,1,0,1,0,1,0),
};

extern const char *names170[];
static const uint32 types170 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags170 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype170_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_1 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_2 [] = {0xFF01,955,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_3 [] = {0xFF01,944,0xFFFF};

static const EIF_TYPE_INDEX *gtypes170 [] = {
g_atype170_0,
g_atype170_1,
g_atype170_2,
g_atype170_3,
};

static const long offsets170 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names173[];
static const uint32 types173 [] =
{
SK_INT32,
};

static const uint16 attr_flags173 [] =
{0,};

static const EIF_TYPE_INDEX g_atype173_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes173 [] = {
g_atype173_0,
};

static const long offsets173 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names177[];
static const uint32 types177 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags177 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype177_0 [] = {0xFF01,172,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes177 [] = {
g_atype177_0,
g_atype177_1,
g_atype177_2,
g_atype177_3,
};

static const long offsets177 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names178[];
static const uint32 types178 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags178 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype178_0 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes178 [] = {
g_atype178_0,
g_atype178_1,
g_atype178_2,
};

static const long offsets178 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names179[];
static const uint32 types179 [] =
{
SK_REF,
};

static const uint16 attr_flags179 [] =
{0,};

static const EIF_TYPE_INDEX g_atype179_0 [] = {0xFF01,606,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes179 [] = {
g_atype179_0,
};

static const long offsets179 [] =
{
0,
};

extern const char *names180[];
static const uint32 types180 [] =
{
SK_REF,
};

static const uint16 attr_flags180 [] =
{0,};

static const EIF_TYPE_INDEX g_atype180_0 [] = {0xFF01,607,789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes180 [] = {
g_atype180_0,
};

static const long offsets180 [] =
{
0,
};

extern const char *names181[];
static const uint32 types181 [] =
{
SK_REF,
};

static const uint16 attr_flags181 [] =
{0,};

static const EIF_TYPE_INDEX g_atype181_0 [] = {0xFF01,608,798,0xFFFF};

static const EIF_TYPE_INDEX *gtypes181 [] = {
g_atype181_0,
};

static const long offsets181 [] =
{
0,
};

extern const char *names182[];
static const uint32 types182 [] =
{
SK_REF,
};

static const uint16 attr_flags182 [] =
{0,};

static const EIF_TYPE_INDEX g_atype182_0 [] = {0xFF01,609,804,0xFFFF};

static const EIF_TYPE_INDEX *gtypes182 [] = {
g_atype182_0,
};

static const long offsets182 [] =
{
0,
};

extern const char *names183[];
static const uint32 types183 [] =
{
SK_REF,
};

static const uint16 attr_flags183 [] =
{0,};

static const EIF_TYPE_INDEX g_atype183_0 [] = {0xFF01,610,807,0xFFFF};

static const EIF_TYPE_INDEX *gtypes183 [] = {
g_atype183_0,
};

static const long offsets183 [] =
{
0,
};

extern const char *names184[];
static const uint32 types184 [] =
{
SK_REF,
};

static const uint16 attr_flags184 [] =
{0,};

static const EIF_TYPE_INDEX g_atype184_0 [] = {0xFF01,611,822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes184 [] = {
g_atype184_0,
};

static const long offsets184 [] =
{
0,
};

extern const char *names185[];
static const uint32 types185 [] =
{
SK_REF,
};

static const uint16 attr_flags185 [] =
{0,};

static const EIF_TYPE_INDEX g_atype185_0 [] = {0xFF01,612,801,0xFFFF};

static const EIF_TYPE_INDEX *gtypes185 [] = {
g_atype185_0,
};

static const long offsets185 [] =
{
0,
};

extern const char *names186[];
static const uint32 types186 [] =
{
SK_REF,
};

static const uint16 attr_flags186 [] =
{0,};

static const EIF_TYPE_INDEX g_atype186_0 [] = {0xFF01,613,819,0xFFFF};

static const EIF_TYPE_INDEX *gtypes186 [] = {
g_atype186_0,
};

static const long offsets186 [] =
{
0,
};

extern const char *names187[];
static const uint32 types187 [] =
{
SK_REF,
};

static const uint16 attr_flags187 [] =
{0,};

static const EIF_TYPE_INDEX g_atype187_0 [] = {0xFF01,614,816,0xFFFF};

static const EIF_TYPE_INDEX *gtypes187 [] = {
g_atype187_0,
};

static const long offsets187 [] =
{
0,
};

extern const char *names188[];
static const uint32 types188 [] =
{
SK_REF,
};

static const uint16 attr_flags188 [] =
{0,};

static const EIF_TYPE_INDEX g_atype188_0 [] = {0xFF01,615,858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes188 [] = {
g_atype188_0,
};

static const long offsets188 [] =
{
0,
};

extern const char *names189[];
static const uint32 types189 [] =
{
SK_REF,
};

static const uint16 attr_flags189 [] =
{0,};

static const EIF_TYPE_INDEX g_atype189_0 [] = {0xFF01,616,810,0xFFFF};

static const EIF_TYPE_INDEX *gtypes189 [] = {
g_atype189_0,
};

static const long offsets189 [] =
{
0,
};

extern const char *names190[];
static const uint32 types190 [] =
{
SK_REF,
};

static const uint16 attr_flags190 [] =
{0,};

static const EIF_TYPE_INDEX g_atype190_0 [] = {0xFF01,617,813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes190 [] = {
g_atype190_0,
};

static const long offsets190 [] =
{
0,
};

extern const char *names192[];
static const uint32 types192 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags192 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype192_0 [] = {0xFF01,167,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_1 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes192 [] = {
g_atype192_0,
g_atype192_1,
};

static const long offsets192 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names193[];
static const uint32 types193 [] =
{
SK_INT32,
};

static const uint16 attr_flags193 [] =
{0,};

static const EIF_TYPE_INDEX g_atype193_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes193 [] = {
g_atype193_0,
};

static const long offsets193 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names194[];
static const uint32 types194 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags194 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype194_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_1 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_4 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_5 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes194 [] = {
g_atype194_0,
g_atype194_1,
g_atype194_2,
g_atype194_3,
g_atype194_4,
g_atype194_5,
};

static const long offsets194 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @PTROFF(3,0,0,1,0,0),
+ @PTROFF(3,0,0,1,0,1),
};

extern const char *names195[];
static const uint32 types195 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags195 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype195_0 [] = {0xFF01,610,807,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_1 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_4 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes195 [] = {
g_atype195_0,
g_atype195_1,
g_atype195_2,
g_atype195_3,
g_atype195_4,
};

static const long offsets195 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names196[];
static const uint32 types196 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags196 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype196_0 [] = {0xFF01,610,807,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_1 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_4 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes196 [] = {
g_atype196_0,
g_atype196_1,
g_atype196_2,
g_atype196_3,
g_atype196_4,
};

static const long offsets196 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names198[];
static const uint32 types198 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR32,
};

static const uint16 attr_flags198 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype198_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_1 [] = {0xFF01,869,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_2 [] = {0xFF01,614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_4 [] = {816,0xFFFF};

static const EIF_TYPE_INDEX *gtypes198 [] = {
g_atype198_0,
g_atype198_1,
g_atype198_2,
g_atype198_3,
g_atype198_4,
};

static const long offsets198 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names199[];
static const uint32 types199 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags199 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype199_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_1 [] = {0xFF01,613,819,0xFFFF};

static const EIF_TYPE_INDEX *gtypes199 [] = {
g_atype199_0,
g_atype199_1,
};

static const long offsets199 [] =
{
0,
 + @REFACS(1),
};

extern const char *names200[];
static const uint32 types200 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags200 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype200_0 [] = {0xFF01,167,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_1 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes200 [] = {
g_atype200_0,
g_atype200_1,
};

static const long offsets200 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names201[];
static const uint32 types201 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags201 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype201_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_1 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_2 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_3 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_4 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_5 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_6 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_9 [] = {810,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_10 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_11 [] = {825,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_12 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes201 [] = {
g_atype201_0,
g_atype201_1,
g_atype201_2,
g_atype201_3,
g_atype201_4,
g_atype201_5,
g_atype201_6,
g_atype201_7,
g_atype201_8,
g_atype201_9,
g_atype201_10,
g_atype201_11,
g_atype201_12,
};

static const long offsets201 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I16OFF(1,3,0),
+ @I16OFF(1,3,1),
+ @LNGOFF(1,3,2,0),
+ @LNGOFF(1,3,2,1),
+ @LNGOFF(1,3,2,2),
+ @R32OFF(1,3,2,3,0),
+ @I64OFF(1,3,2,3,1,0,0),
+ @I64OFF(1,3,2,3,1,0,1),
+ @R64OFF(1,3,2,3,1,0,2,0),
};

extern const char *names203[];
static const uint32 types203 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags203 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype203_0 [] = {0xFF01,943,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_2 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_3 [] = {202,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_4 [] = {0xFF01,706,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_5 [] = {701,202,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_6 [] = {701,0xFF01,204,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_7 [] = {0xFF01,0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_9 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_10 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_11 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_14 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes203 [] = {
g_atype203_0,
g_atype203_1,
g_atype203_2,
g_atype203_3,
g_atype203_4,
g_atype203_5,
g_atype203_6,
g_atype203_7,
g_atype203_8,
g_atype203_9,
g_atype203_10,
g_atype203_11,
g_atype203_12,
g_atype203_13,
g_atype203_14,
};

static const long offsets203 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @LNGOFF(8,4,0,0),
+ @LNGOFF(8,4,0,1),
+ @LNGOFF(8,4,0,2),
};

extern const char *names205[];
static const uint32 types205 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags205 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype205_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes205 [] = {
g_atype205_0,
g_atype205_1,
g_atype205_2,
};

static const long offsets205 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names206[];
static const uint32 types206 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags206 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype206_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes206 [] = {
g_atype206_0,
g_atype206_1,
g_atype206_2,
g_atype206_3,
g_atype206_4,
};

static const long offsets206 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names207[];
static const uint32 types207 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags207 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype207_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_2 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes207 [] = {
g_atype207_0,
g_atype207_1,
g_atype207_2,
g_atype207_3,
g_atype207_4,
};

static const long offsets207 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names208[];
static const uint32 types208 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags208 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype208_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_4 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes208 [] = {
g_atype208_0,
g_atype208_1,
g_atype208_2,
g_atype208_3,
g_atype208_4,
};

static const long offsets208 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names209[];
static const uint32 types209 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags209 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype209_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_4 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes209 [] = {
g_atype209_0,
g_atype209_1,
g_atype209_2,
g_atype209_3,
g_atype209_4,
};

static const long offsets209 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @PTROFF(2,0,0,2,0,0),
};

extern const char *names210[];
static const uint32 types210 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags210 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype210_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype210_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype210_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype210_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype210_4 [] = {798,0xFFFF};

static const EIF_TYPE_INDEX *gtypes210 [] = {
g_atype210_0,
g_atype210_1,
g_atype210_2,
g_atype210_3,
g_atype210_4,
};

static const long offsets210 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names211[];
static const uint32 types211 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags211 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype211_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_2 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes211 [] = {
g_atype211_0,
g_atype211_1,
g_atype211_2,
g_atype211_3,
g_atype211_4,
};

static const long offsets211 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names212[];
static const uint32 types212 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags212 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype212_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_4 [] = {810,0xFFFF};

static const EIF_TYPE_INDEX *gtypes212 [] = {
g_atype212_0,
g_atype212_1,
g_atype212_2,
g_atype212_3,
g_atype212_4,
};

static const long offsets212 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R32OFF(2,0,0,2,0),
};

extern const char *names213[];
static const uint32 types213 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags213 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype213_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes213 [] = {
g_atype213_0,
g_atype213_1,
g_atype213_2,
g_atype213_3,
g_atype213_4,
};

static const long offsets213 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names214[];
static const uint32 types214 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags214 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype214_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_2 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes214 [] = {
g_atype214_0,
g_atype214_1,
g_atype214_2,
g_atype214_3,
g_atype214_4,
};

static const long offsets214 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names215[];
static const uint32 types215 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags215 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype215_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_2 [] = {816,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes215 [] = {
g_atype215_0,
g_atype215_1,
g_atype215_2,
g_atype215_3,
g_atype215_4,
};

static const long offsets215 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names216[];
static const uint32 types216 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags216 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype216_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes216 [] = {
g_atype216_0,
g_atype216_1,
g_atype216_2,
g_atype216_3,
g_atype216_4,
};

static const long offsets216 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names217[];
static const uint32 types217 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags217 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype217_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_2 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes217 [] = {
g_atype217_0,
g_atype217_1,
g_atype217_2,
g_atype217_3,
g_atype217_4,
};

static const long offsets217 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names218[];
static const uint32 types218 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags218 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype218_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_2 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes218 [] = {
g_atype218_0,
g_atype218_1,
g_atype218_2,
g_atype218_3,
g_atype218_4,
};

static const long offsets218 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names219[];
static const uint32 types219 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags219 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype219_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes219 [] = {
g_atype219_0,
g_atype219_1,
g_atype219_2,
g_atype219_3,
g_atype219_4,
};

static const long offsets219 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names220[];
static const uint32 types220 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags220 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype220_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_4 [] = {825,0xFFFF};

static const EIF_TYPE_INDEX *gtypes220 [] = {
g_atype220_0,
g_atype220_1,
g_atype220_2,
g_atype220_3,
g_atype220_4,
};

static const long offsets220 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names221[];
static const uint32 types221 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags221 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype221_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_1 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes221 [] = {
g_atype221_0,
g_atype221_1,
g_atype221_2,
g_atype221_3,
g_atype221_4,
g_atype221_5,
};

static const long offsets221 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names222[];
static const uint32 types222 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags222 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype222_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_1 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes222 [] = {
g_atype222_0,
g_atype222_1,
g_atype222_2,
g_atype222_3,
g_atype222_4,
g_atype222_5,
};

static const long offsets222 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names223[];
static const uint32 types223 [] =
{
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags223 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype223_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_1 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes223 [] = {
g_atype223_0,
g_atype223_1,
g_atype223_2,
g_atype223_3,
g_atype223_4,
g_atype223_5,
};

static const long offsets223 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names224[];
static const uint32 types224 [] =
{
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags224 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype224_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_1 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes224 [] = {
g_atype224_0,
g_atype224_1,
g_atype224_2,
g_atype224_3,
g_atype224_4,
g_atype224_5,
};

static const long offsets224 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names225[];
static const uint32 types225 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags225 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype225_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_1 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_5 [] = {810,0xFFFF};

static const EIF_TYPE_INDEX *gtypes225 [] = {
g_atype225_0,
g_atype225_1,
g_atype225_2,
g_atype225_3,
g_atype225_4,
g_atype225_5,
};

static const long offsets225 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R32OFF(1,0,0,4,0),
};

extern const char *names226[];
static const uint32 types226 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags226 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype226_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_1 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes226 [] = {
g_atype226_0,
g_atype226_1,
g_atype226_2,
g_atype226_3,
g_atype226_4,
g_atype226_5,
};

static const long offsets226 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names227[];
static const uint32 types227 [] =
{
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags227 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype227_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_1 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes227 [] = {
g_atype227_0,
g_atype227_1,
g_atype227_2,
g_atype227_3,
g_atype227_4,
g_atype227_5,
};

static const long offsets227 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names228[];
static const uint32 types228 [] =
{
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags228 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype228_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_1 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes228 [] = {
g_atype228_0,
g_atype228_1,
g_atype228_2,
g_atype228_3,
g_atype228_4,
g_atype228_5,
};

static const long offsets228 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names229[];
static const uint32 types229 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags229 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype229_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_1 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_5 [] = {798,0xFFFF};

static const EIF_TYPE_INDEX *gtypes229 [] = {
g_atype229_0,
g_atype229_1,
g_atype229_2,
g_atype229_3,
g_atype229_4,
g_atype229_5,
};

static const long offsets229 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names230[];
static const uint32 types230 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags230 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype230_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes230 [] = {
g_atype230_0,
g_atype230_1,
g_atype230_2,
g_atype230_3,
g_atype230_4,
g_atype230_5,
};

static const long offsets230 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names231[];
static const uint32 types231 [] =
{
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags231 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype231_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_1 [] = {816,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes231 [] = {
g_atype231_0,
g_atype231_1,
g_atype231_2,
g_atype231_3,
g_atype231_4,
g_atype231_5,
};

static const long offsets231 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names232[];
static const uint32 types232 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags232 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype232_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_1 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes232 [] = {
g_atype232_0,
g_atype232_1,
g_atype232_2,
g_atype232_3,
g_atype232_4,
g_atype232_5,
};

static const long offsets232 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names233[];
static const uint32 types233 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags233 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype233_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_1 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_5 [] = {825,0xFFFF};

static const EIF_TYPE_INDEX *gtypes233 [] = {
g_atype233_0,
g_atype233_1,
g_atype233_2,
g_atype233_3,
g_atype233_4,
g_atype233_5,
};

static const long offsets233 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names234[];
static const uint32 types234 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags234 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype234_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_1 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_5 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes234 [] = {
g_atype234_0,
g_atype234_1,
g_atype234_2,
g_atype234_3,
g_atype234_4,
g_atype234_5,
};

static const long offsets234 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @PTROFF(1,0,0,4,0,0),
};

extern const char *names235[];
static const uint32 types235 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags235 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype235_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_1 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_5 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes235 [] = {
g_atype235_0,
g_atype235_1,
g_atype235_2,
g_atype235_3,
g_atype235_4,
g_atype235_5,
};

static const long offsets235 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R64OFF(1,0,0,4,0,0,0,0),
};

extern const char *names236[];
static const uint32 types236 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags236 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype236_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_3 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes236 [] = {
g_atype236_0,
g_atype236_1,
g_atype236_2,
g_atype236_3,
g_atype236_4,
g_atype236_5,
};

static const long offsets236 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names237[];
static const uint32 types237 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags237 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype237_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_2 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_3 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes237 [] = {
g_atype237_0,
g_atype237_1,
g_atype237_2,
g_atype237_3,
g_atype237_4,
g_atype237_5,
};

static const long offsets237 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names238[];
static const uint32 types238 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags238 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype238_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_3 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes238 [] = {
g_atype238_0,
g_atype238_1,
g_atype238_2,
g_atype238_3,
g_atype238_4,
g_atype238_5,
};

static const long offsets238 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names239[];
static const uint32 types239 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags239 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype239_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_5 [] = {810,0xFFFF};

static const EIF_TYPE_INDEX *gtypes239 [] = {
g_atype239_0,
g_atype239_1,
g_atype239_2,
g_atype239_3,
g_atype239_4,
g_atype239_5,
};

static const long offsets239 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R32OFF(2,0,0,3,0),
};

extern const char *names240[];
static const uint32 types240 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags240 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype240_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_2 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_3 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes240 [] = {
g_atype240_0,
g_atype240_1,
g_atype240_2,
g_atype240_3,
g_atype240_4,
g_atype240_5,
};

static const long offsets240 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names241[];
static const uint32 types241 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags241 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype241_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_2 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_3 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes241 [] = {
g_atype241_0,
g_atype241_1,
g_atype241_2,
g_atype241_3,
g_atype241_4,
g_atype241_5,
};

static const long offsets241 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names242[];
static const uint32 types242 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags242 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype242_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes242 [] = {
g_atype242_0,
g_atype242_1,
g_atype242_2,
g_atype242_3,
g_atype242_4,
g_atype242_5,
};

static const long offsets242 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names243[];
static const uint32 types243 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags243 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype243_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_5 [] = {798,0xFFFF};

static const EIF_TYPE_INDEX *gtypes243 [] = {
g_atype243_0,
g_atype243_1,
g_atype243_2,
g_atype243_3,
g_atype243_4,
g_atype243_5,
};

static const long offsets243 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names244[];
static const uint32 types244 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags244 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype244_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_2 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_3 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes244 [] = {
g_atype244_0,
g_atype244_1,
g_atype244_2,
g_atype244_3,
g_atype244_4,
g_atype244_5,
};

static const long offsets244 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names245[];
static const uint32 types245 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags245 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype245_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_2 [] = {816,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_3 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes245 [] = {
g_atype245_0,
g_atype245_1,
g_atype245_2,
g_atype245_3,
g_atype245_4,
g_atype245_5,
};

static const long offsets245 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names246[];
static const uint32 types246 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags246 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype246_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_3 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes246 [] = {
g_atype246_0,
g_atype246_1,
g_atype246_2,
g_atype246_3,
g_atype246_4,
g_atype246_5,
};

static const long offsets246 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names247[];
static const uint32 types247 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags247 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype247_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_5 [] = {825,0xFFFF};

static const EIF_TYPE_INDEX *gtypes247 [] = {
g_atype247_0,
g_atype247_1,
g_atype247_2,
g_atype247_3,
g_atype247_4,
g_atype247_5,
};

static const long offsets247 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names248[];
static const uint32 types248 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags248 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype248_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_2 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_3 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes248 [] = {
g_atype248_0,
g_atype248_1,
g_atype248_2,
g_atype248_3,
g_atype248_4,
g_atype248_5,
};

static const long offsets248 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names249[];
static const uint32 types249 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags249 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype249_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_5 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes249 [] = {
g_atype249_0,
g_atype249_1,
g_atype249_2,
g_atype249_3,
g_atype249_4,
g_atype249_5,
};

static const long offsets249 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @PTROFF(2,0,0,3,0,0),
};

extern const char *names250[];
static const uint32 types250 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags250 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype250_0 [] = {0xFFF9,2,786,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_5 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes250 [] = {
g_atype250_0,
g_atype250_1,
g_atype250_2,
g_atype250_3,
g_atype250_4,
g_atype250_5,
};

static const long offsets250 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R64OFF(2,0,0,3,0,0,0,0),
};

extern const char *names264[];
static const uint32 types264 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags264 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype264_0 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_1 [] = {0xFFF5,1,0xFF01,606,0xFFF8,1,2451,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_2 [] = {0xFFF5,1,0xFF01,700,0xFFF8,1,2597,0xFFFF};

static const EIF_TYPE_INDEX *gtypes264 [] = {
g_atype264_0,
g_atype264_1,
g_atype264_2,
};

static const long offsets264 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names265[];
static const uint32 types265 [] =
{
SK_UINT8,
SK_POINTER,
};

static const uint16 attr_flags265 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype265_0 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_1 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes265 [] = {
g_atype265_0,
g_atype265_1,
};

static const long offsets265 [] =
{
+ @CHROFF(0,0),
+ @PTROFF(0,1,0,0,0,0),
};

extern const char *names286[];
static const uint32 types286 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags286 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype286_0 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes286 [] = {
g_atype286_0,
g_atype286_1,
g_atype286_2,
g_atype286_3,
};

static const long offsets286 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names288[];
static const uint32 types288 [] =
{
SK_REF,
};

static const uint16 attr_flags288 [] =
{0,};

static const EIF_TYPE_INDEX g_atype288_0 [] = {0xFF01,872,0xFFFF};

static const EIF_TYPE_INDEX *gtypes288 [] = {
g_atype288_0,
};

static const long offsets288 [] =
{
0,
};

extern const char *names318[];
static const uint32 types318 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags318 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype318_0 [] = {0xFF01,594,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes318 [] = {
g_atype318_0,
g_atype318_1,
g_atype318_2,
g_atype318_3,
g_atype318_4,
g_atype318_5,
g_atype318_6,
};

static const long offsets318 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names319[];
static const uint32 types319 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags319 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype319_0 [] = {0xFF01,595,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes319 [] = {
g_atype319_0,
g_atype319_1,
g_atype319_2,
g_atype319_3,
g_atype319_4,
g_atype319_5,
g_atype319_6,
};

static const long offsets319 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names320[];
static const uint32 types320 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags320 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype320_0 [] = {0xFF01,596,798,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes320 [] = {
g_atype320_0,
g_atype320_1,
g_atype320_2,
g_atype320_3,
g_atype320_4,
g_atype320_5,
g_atype320_6,
};

static const long offsets320 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names321[];
static const uint32 types321 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags321 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype321_0 [] = {0xFF01,597,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes321 [] = {
g_atype321_0,
g_atype321_1,
g_atype321_2,
g_atype321_3,
g_atype321_4,
g_atype321_5,
g_atype321_6,
};

static const long offsets321 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names322[];
static const uint32 types322 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags322 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype322_0 [] = {0xFF01,598,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes322 [] = {
g_atype322_0,
g_atype322_1,
g_atype322_2,
g_atype322_3,
g_atype322_4,
g_atype322_5,
g_atype322_6,
};

static const long offsets322 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names323[];
static const uint32 types323 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags323 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype323_0 [] = {0xFF01,599,804,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes323 [] = {
g_atype323_0,
g_atype323_1,
g_atype323_2,
g_atype323_3,
g_atype323_4,
g_atype323_5,
g_atype323_6,
};

static const long offsets323 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names324[];
static const uint32 types324 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags324 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype324_0 [] = {0xFF01,600,807,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes324 [] = {
g_atype324_0,
g_atype324_1,
g_atype324_2,
g_atype324_3,
g_atype324_4,
g_atype324_5,
g_atype324_6,
};

static const long offsets324 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names325[];
static const uint32 types325 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags325 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype325_0 [] = {0xFF01,601,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes325 [] = {
g_atype325_0,
g_atype325_1,
g_atype325_2,
g_atype325_3,
g_atype325_4,
g_atype325_5,
g_atype325_6,
};

static const long offsets325 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names326[];
static const uint32 types326 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags326 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype326_0 [] = {0xFF01,602,801,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes326 [] = {
g_atype326_0,
g_atype326_1,
g_atype326_2,
g_atype326_3,
g_atype326_4,
g_atype326_5,
g_atype326_6,
};

static const long offsets326 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names327[];
static const uint32 types327 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags327 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype327_0 [] = {0xFF01,603,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes327 [] = {
g_atype327_0,
g_atype327_1,
g_atype327_2,
g_atype327_3,
g_atype327_4,
g_atype327_5,
g_atype327_6,
};

static const long offsets327 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names328[];
static const uint32 types328 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags328 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype328_0 [] = {0xFF01,604,810,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes328 [] = {
g_atype328_0,
g_atype328_1,
g_atype328_2,
g_atype328_3,
g_atype328_4,
g_atype328_5,
g_atype328_6,
};

static const long offsets328 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names329[];
static const uint32 types329 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags329 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype329_0 [] = {0xFF01,605,813,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes329 [] = {
g_atype329_0,
g_atype329_1,
g_atype329_2,
g_atype329_3,
g_atype329_4,
g_atype329_5,
g_atype329_6,
};

static const long offsets329 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names330[];
static const uint32 types330 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags330 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype330_0 [] = {0xFF01,696,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_1 [] = {76,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_3 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_7 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes330 [] = {
g_atype330_0,
g_atype330_1,
g_atype330_2,
g_atype330_3,
g_atype330_4,
g_atype330_5,
g_atype330_6,
g_atype330_7,
};

static const long offsets330 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names331[];
static const uint32 types331 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags331 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype331_0 [] = {0xFF01,697,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_1 [] = {77,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_3 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_7 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes331 [] = {
g_atype331_0,
g_atype331_1,
g_atype331_2,
g_atype331_3,
g_atype331_4,
g_atype331_5,
g_atype331_6,
g_atype331_7,
};

static const long offsets331 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names332[];
static const uint32 types332 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags332 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype332_0 [] = {0xFF01,713,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes332 [] = {
g_atype332_0,
g_atype332_1,
g_atype332_2,
g_atype332_3,
g_atype332_4,
g_atype332_5,
g_atype332_6,
};

static const long offsets332 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names333[];
static const uint32 types333 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags333 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype333_0 [] = {0xFF01,714,789,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes333 [] = {
g_atype333_0,
g_atype333_1,
g_atype333_2,
g_atype333_3,
g_atype333_4,
g_atype333_5,
g_atype333_6,
};

static const long offsets333 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names334[];
static const uint32 types334 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags334 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype334_0 [] = {0xFF01,715,0xFFF8,1,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes334 [] = {
g_atype334_0,
g_atype334_1,
g_atype334_2,
g_atype334_3,
g_atype334_4,
g_atype334_5,
g_atype334_6,
};

static const long offsets334 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names335[];
static const uint32 types335 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags335 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype335_0 [] = {0xFF01,716,789,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes335 [] = {
g_atype335_0,
g_atype335_1,
g_atype335_2,
g_atype335_3,
g_atype335_4,
g_atype335_5,
g_atype335_6,
};

static const long offsets335 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names336[];
static const uint32 types336 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags336 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype336_0 [] = {0xFF01,717,858,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_2 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_6 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes336 [] = {
g_atype336_0,
g_atype336_1,
g_atype336_2,
g_atype336_3,
g_atype336_4,
g_atype336_5,
g_atype336_6,
};

static const long offsets336 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names337[];
static const uint32 types337 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags337 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype337_0 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes337 [] = {
g_atype337_0,
g_atype337_1,
g_atype337_2,
};

static const long offsets337 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names338[];
static const uint32 types338 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags338 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype338_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes338 [] = {
g_atype338_0,
g_atype338_1,
g_atype338_2,
};

static const long offsets338 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names339[];
static const uint32 types339 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags339 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype339_0 [] = {0xFF01,608,798,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes339 [] = {
g_atype339_0,
g_atype339_1,
g_atype339_2,
};

static const long offsets339 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names340[];
static const uint32 types340 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags340 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype340_0 [] = {0xFF01,609,804,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes340 [] = {
g_atype340_0,
g_atype340_1,
g_atype340_2,
};

static const long offsets340 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names341[];
static const uint32 types341 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags341 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype341_0 [] = {0xFF01,610,807,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes341 [] = {
g_atype341_0,
g_atype341_1,
g_atype341_2,
};

static const long offsets341 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names342[];
static const uint32 types342 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags342 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype342_0 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes342 [] = {
g_atype342_0,
g_atype342_1,
g_atype342_2,
};

static const long offsets342 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names343[];
static const uint32 types343 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags343 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype343_0 [] = {0xFF01,612,801,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes343 [] = {
g_atype343_0,
g_atype343_1,
g_atype343_2,
};

static const long offsets343 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names344[];
static const uint32 types344 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags344 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype344_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes344 [] = {
g_atype344_0,
g_atype344_1,
g_atype344_2,
};

static const long offsets344 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names345[];
static const uint32 types345 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags345 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype345_0 [] = {0xFF01,614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes345 [] = {
g_atype345_0,
g_atype345_1,
g_atype345_2,
};

static const long offsets345 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names346[];
static const uint32 types346 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags346 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype346_0 [] = {0xFF01,615,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes346 [] = {
g_atype346_0,
g_atype346_1,
g_atype346_2,
};

static const long offsets346 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names347[];
static const uint32 types347 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags347 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype347_0 [] = {0xFF01,616,810,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes347 [] = {
g_atype347_0,
g_atype347_1,
g_atype347_2,
};

static const long offsets347 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names348[];
static const uint32 types348 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags348 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype348_0 [] = {0xFF01,617,813,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes348 [] = {
g_atype348_0,
g_atype348_1,
g_atype348_2,
};

static const long offsets348 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names349[];
static const uint32 types349 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags349 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype349_0 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_1 [] = {0xFF01,701,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes349 [] = {
g_atype349_0,
g_atype349_1,
g_atype349_2,
g_atype349_3,
};

static const long offsets349 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names350[];
static const uint32 types350 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags350 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype350_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_1 [] = {0xFF01,702,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes350 [] = {
g_atype350_0,
g_atype350_1,
g_atype350_2,
g_atype350_3,
};

static const long offsets350 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names351[];
static const uint32 types351 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags351 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype351_0 [] = {0xFF01,608,798,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_1 [] = {0xFF01,703,798,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes351 [] = {
g_atype351_0,
g_atype351_1,
g_atype351_2,
g_atype351_3,
};

static const long offsets351 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names352[];
static const uint32 types352 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags352 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype352_0 [] = {0xFF01,609,804,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_1 [] = {0xFF01,704,804,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes352 [] = {
g_atype352_0,
g_atype352_1,
g_atype352_2,
g_atype352_3,
};

static const long offsets352 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names353[];
static const uint32 types353 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags353 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype353_0 [] = {0xFF01,610,807,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_1 [] = {0xFF01,705,807,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes353 [] = {
g_atype353_0,
g_atype353_1,
g_atype353_2,
g_atype353_3,
};

static const long offsets353 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names354[];
static const uint32 types354 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags354 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype354_0 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_1 [] = {0xFF01,706,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes354 [] = {
g_atype354_0,
g_atype354_1,
g_atype354_2,
g_atype354_3,
};

static const long offsets354 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names355[];
static const uint32 types355 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags355 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype355_0 [] = {0xFF01,612,801,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_1 [] = {0xFF01,707,801,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes355 [] = {
g_atype355_0,
g_atype355_1,
g_atype355_2,
g_atype355_3,
};

static const long offsets355 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names356[];
static const uint32 types356 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags356 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype356_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_1 [] = {0xFF01,708,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes356 [] = {
g_atype356_0,
g_atype356_1,
g_atype356_2,
g_atype356_3,
};

static const long offsets356 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names357[];
static const uint32 types357 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags357 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype357_0 [] = {0xFF01,614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_1 [] = {0xFF01,709,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes357 [] = {
g_atype357_0,
g_atype357_1,
g_atype357_2,
g_atype357_3,
};

static const long offsets357 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names358[];
static const uint32 types358 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags358 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype358_0 [] = {0xFF01,615,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_1 [] = {0xFF01,710,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes358 [] = {
g_atype358_0,
g_atype358_1,
g_atype358_2,
g_atype358_3,
};

static const long offsets358 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names359[];
static const uint32 types359 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags359 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype359_0 [] = {0xFF01,616,810,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_1 [] = {0xFF01,711,810,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes359 [] = {
g_atype359_0,
g_atype359_1,
g_atype359_2,
g_atype359_3,
};

static const long offsets359 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names360[];
static const uint32 types360 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags360 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype360_0 [] = {0xFF01,617,813,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_1 [] = {0xFF01,712,813,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes360 [] = {
g_atype360_0,
g_atype360_1,
g_atype360_2,
g_atype360_3,
};

static const long offsets360 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names361[];
static const uint32 types361 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags361 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype361_0 [] = {0xFF01,614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_1 [] = {0xFF01,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes361 [] = {
g_atype361_0,
g_atype361_1,
g_atype361_2,
g_atype361_3,
g_atype361_4,
};

static const long offsets361 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names362[];
static const uint32 types362 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags362 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype362_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_1 [] = {0xFF01,870,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes362 [] = {
g_atype362_0,
g_atype362_1,
g_atype362_2,
g_atype362_3,
g_atype362_4,
};

static const long offsets362 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names363[];
static const uint32 types363 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags363 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype363_0 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_1 [] = {0xFF01,631,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes363 [] = {
g_atype363_0,
g_atype363_1,
g_atype363_2,
g_atype363_3,
g_atype363_4,
};

static const long offsets363 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names364[];
static const uint32 types364 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags364 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype364_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_1 [] = {0xFF01,632,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes364 [] = {
g_atype364_0,
g_atype364_1,
g_atype364_2,
g_atype364_3,
g_atype364_4,
};

static const long offsets364 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names365[];
static const uint32 types365 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags365 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype365_0 [] = {0xFF01,608,798,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_1 [] = {0xFF01,633,798,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes365 [] = {
g_atype365_0,
g_atype365_1,
g_atype365_2,
g_atype365_3,
g_atype365_4,
};

static const long offsets365 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names366[];
static const uint32 types366 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags366 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype366_0 [] = {0xFF01,609,804,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_1 [] = {0xFF01,634,804,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes366 [] = {
g_atype366_0,
g_atype366_1,
g_atype366_2,
g_atype366_3,
g_atype366_4,
};

static const long offsets366 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names367[];
static const uint32 types367 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags367 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype367_0 [] = {0xFF01,610,807,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_1 [] = {0xFF01,635,807,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes367 [] = {
g_atype367_0,
g_atype367_1,
g_atype367_2,
g_atype367_3,
g_atype367_4,
};

static const long offsets367 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names368[];
static const uint32 types368 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags368 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype368_0 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_1 [] = {0xFF01,636,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes368 [] = {
g_atype368_0,
g_atype368_1,
g_atype368_2,
g_atype368_3,
g_atype368_4,
};

static const long offsets368 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names369[];
static const uint32 types369 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags369 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype369_0 [] = {0xFF01,612,801,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_1 [] = {0xFF01,637,801,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes369 [] = {
g_atype369_0,
g_atype369_1,
g_atype369_2,
g_atype369_3,
g_atype369_4,
};

static const long offsets369 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names370[];
static const uint32 types370 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags370 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype370_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_1 [] = {0xFF01,638,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes370 [] = {
g_atype370_0,
g_atype370_1,
g_atype370_2,
g_atype370_3,
g_atype370_4,
};

static const long offsets370 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names371[];
static const uint32 types371 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags371 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype371_0 [] = {0xFF01,614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_1 [] = {0xFF01,639,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes371 [] = {
g_atype371_0,
g_atype371_1,
g_atype371_2,
g_atype371_3,
g_atype371_4,
};

static const long offsets371 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names372[];
static const uint32 types372 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags372 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype372_0 [] = {0xFF01,615,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_1 [] = {0xFF01,640,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes372 [] = {
g_atype372_0,
g_atype372_1,
g_atype372_2,
g_atype372_3,
g_atype372_4,
};

static const long offsets372 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names373[];
static const uint32 types373 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags373 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype373_0 [] = {0xFF01,616,810,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_1 [] = {0xFF01,641,810,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes373 [] = {
g_atype373_0,
g_atype373_1,
g_atype373_2,
g_atype373_3,
g_atype373_4,
};

static const long offsets373 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names374[];
static const uint32 types374 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags374 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype374_0 [] = {0xFF01,617,813,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_1 [] = {0xFF01,642,813,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes374 [] = {
g_atype374_0,
g_atype374_1,
g_atype374_2,
g_atype374_3,
g_atype374_4,
};

static const long offsets374 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names375[];
static const uint32 types375 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags375 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype375_0 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes375 [] = {
g_atype375_0,
g_atype375_1,
g_atype375_2,
};

static const long offsets375 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names376[];
static const uint32 types376 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags376 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype376_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes376 [] = {
g_atype376_0,
g_atype376_1,
g_atype376_2,
};

static const long offsets376 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names377[];
static const uint32 types377 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags377 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype377_0 [] = {0xFF01,608,798,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes377 [] = {
g_atype377_0,
g_atype377_1,
g_atype377_2,
};

static const long offsets377 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names378[];
static const uint32 types378 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags378 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype378_0 [] = {0xFF01,609,804,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes378 [] = {
g_atype378_0,
g_atype378_1,
g_atype378_2,
};

static const long offsets378 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names379[];
static const uint32 types379 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags379 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype379_0 [] = {0xFF01,610,807,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes379 [] = {
g_atype379_0,
g_atype379_1,
g_atype379_2,
};

static const long offsets379 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names380[];
static const uint32 types380 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags380 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype380_0 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes380 [] = {
g_atype380_0,
g_atype380_1,
g_atype380_2,
};

static const long offsets380 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names381[];
static const uint32 types381 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags381 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype381_0 [] = {0xFF01,612,801,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes381 [] = {
g_atype381_0,
g_atype381_1,
g_atype381_2,
};

static const long offsets381 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names382[];
static const uint32 types382 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags382 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype382_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes382 [] = {
g_atype382_0,
g_atype382_1,
g_atype382_2,
};

static const long offsets382 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names383[];
static const uint32 types383 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags383 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype383_0 [] = {0xFF01,614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes383 [] = {
g_atype383_0,
g_atype383_1,
g_atype383_2,
};

static const long offsets383 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names384[];
static const uint32 types384 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags384 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype384_0 [] = {0xFF01,615,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes384 [] = {
g_atype384_0,
g_atype384_1,
g_atype384_2,
};

static const long offsets384 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names385[];
static const uint32 types385 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags385 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype385_0 [] = {0xFF01,616,810,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes385 [] = {
g_atype385_0,
g_atype385_1,
g_atype385_2,
};

static const long offsets385 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names386[];
static const uint32 types386 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags386 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype386_0 [] = {0xFF01,617,813,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes386 [] = {
g_atype386_0,
g_atype386_1,
g_atype386_2,
};

static const long offsets386 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names387[];
static const uint32 types387 [] =
{
SK_BOOL,
};

static const uint16 attr_flags387 [] =
{0,};

static const EIF_TYPE_INDEX g_atype387_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes387 [] = {
g_atype387_0,
};

static const long offsets387 [] =
{
+ @CHROFF(0,0),
};

extern const char *names388[];
static const uint32 types388 [] =
{
SK_BOOL,
};

static const uint16 attr_flags388 [] =
{0,};

static const EIF_TYPE_INDEX g_atype388_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes388 [] = {
g_atype388_0,
};

static const long offsets388 [] =
{
+ @CHROFF(0,0),
};

extern const char *names389[];
static const uint32 types389 [] =
{
SK_BOOL,
};

static const uint16 attr_flags389 [] =
{0,};

static const EIF_TYPE_INDEX g_atype389_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes389 [] = {
g_atype389_0,
};

static const long offsets389 [] =
{
+ @CHROFF(0,0),
};

extern const char *names390[];
static const uint32 types390 [] =
{
SK_BOOL,
};

static const uint16 attr_flags390 [] =
{0,};

static const EIF_TYPE_INDEX g_atype390_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes390 [] = {
g_atype390_0,
};

static const long offsets390 [] =
{
+ @CHROFF(0,0),
};

extern const char *names391[];
static const uint32 types391 [] =
{
SK_BOOL,
};

static const uint16 attr_flags391 [] =
{0,};

static const EIF_TYPE_INDEX g_atype391_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes391 [] = {
g_atype391_0,
};

static const long offsets391 [] =
{
+ @CHROFF(0,0),
};

extern const char *names392[];
static const uint32 types392 [] =
{
SK_BOOL,
};

static const uint16 attr_flags392 [] =
{0,};

static const EIF_TYPE_INDEX g_atype392_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes392 [] = {
g_atype392_0,
};

static const long offsets392 [] =
{
+ @CHROFF(0,0),
};

extern const char *names393[];
static const uint32 types393 [] =
{
SK_BOOL,
};

static const uint16 attr_flags393 [] =
{0,};

static const EIF_TYPE_INDEX g_atype393_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes393 [] = {
g_atype393_0,
};

static const long offsets393 [] =
{
+ @CHROFF(0,0),
};

extern const char *names394[];
static const uint32 types394 [] =
{
SK_BOOL,
};

static const uint16 attr_flags394 [] =
{0,};

static const EIF_TYPE_INDEX g_atype394_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes394 [] = {
g_atype394_0,
};

static const long offsets394 [] =
{
+ @CHROFF(0,0),
};

extern const char *names395[];
static const uint32 types395 [] =
{
SK_BOOL,
};

static const uint16 attr_flags395 [] =
{0,};

static const EIF_TYPE_INDEX g_atype395_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes395 [] = {
g_atype395_0,
};

static const long offsets395 [] =
{
+ @CHROFF(0,0),
};

extern const char *names396[];
static const uint32 types396 [] =
{
SK_BOOL,
};

static const uint16 attr_flags396 [] =
{0,};

static const EIF_TYPE_INDEX g_atype396_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes396 [] = {
g_atype396_0,
};

static const long offsets396 [] =
{
+ @CHROFF(0,0),
};

extern const char *names397[];
static const uint32 types397 [] =
{
SK_BOOL,
};

static const uint16 attr_flags397 [] =
{0,};

static const EIF_TYPE_INDEX g_atype397_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes397 [] = {
g_atype397_0,
};

static const long offsets397 [] =
{
+ @CHROFF(0,0),
};

extern const char *names398[];
static const uint32 types398 [] =
{
SK_BOOL,
};

static const uint16 attr_flags398 [] =
{0,};

static const EIF_TYPE_INDEX g_atype398_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes398 [] = {
g_atype398_0,
};

static const long offsets398 [] =
{
+ @CHROFF(0,0),
};

extern const char *names399[];
static const uint32 types399 [] =
{
SK_BOOL,
};

static const uint16 attr_flags399 [] =
{0,};

static const EIF_TYPE_INDEX g_atype399_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes399 [] = {
g_atype399_0,
};

static const long offsets399 [] =
{
+ @CHROFF(0,0),
};

extern const char *names400[];
static const uint32 types400 [] =
{
SK_BOOL,
};

static const uint16 attr_flags400 [] =
{0,};

static const EIF_TYPE_INDEX g_atype400_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes400 [] = {
g_atype400_0,
};

static const long offsets400 [] =
{
+ @CHROFF(0,0),
};

extern const char *names401[];
static const uint32 types401 [] =
{
SK_BOOL,
};

static const uint16 attr_flags401 [] =
{0,};

static const EIF_TYPE_INDEX g_atype401_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes401 [] = {
g_atype401_0,
};

static const long offsets401 [] =
{
+ @CHROFF(0,0),
};

extern const char *names402[];
static const uint32 types402 [] =
{
SK_BOOL,
};

static const uint16 attr_flags402 [] =
{0,};

static const EIF_TYPE_INDEX g_atype402_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes402 [] = {
g_atype402_0,
};

static const long offsets402 [] =
{
+ @CHROFF(0,0),
};

extern const char *names403[];
static const uint32 types403 [] =
{
SK_BOOL,
};

static const uint16 attr_flags403 [] =
{0,};

static const EIF_TYPE_INDEX g_atype403_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes403 [] = {
g_atype403_0,
};

static const long offsets403 [] =
{
+ @CHROFF(0,0),
};

extern const char *names404[];
static const uint32 types404 [] =
{
SK_BOOL,
};

static const uint16 attr_flags404 [] =
{0,};

static const EIF_TYPE_INDEX g_atype404_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes404 [] = {
g_atype404_0,
};

static const long offsets404 [] =
{
+ @CHROFF(0,0),
};

extern const char *names405[];
static const uint32 types405 [] =
{
SK_BOOL,
};

static const uint16 attr_flags405 [] =
{0,};

static const EIF_TYPE_INDEX g_atype405_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes405 [] = {
g_atype405_0,
};

static const long offsets405 [] =
{
+ @CHROFF(0,0),
};

extern const char *names406[];
static const uint32 types406 [] =
{
SK_BOOL,
};

static const uint16 attr_flags406 [] =
{0,};

static const EIF_TYPE_INDEX g_atype406_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes406 [] = {
g_atype406_0,
};

static const long offsets406 [] =
{
+ @CHROFF(0,0),
};

extern const char *names407[];
static const uint32 types407 [] =
{
SK_BOOL,
};

static const uint16 attr_flags407 [] =
{0,};

static const EIF_TYPE_INDEX g_atype407_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes407 [] = {
g_atype407_0,
};

static const long offsets407 [] =
{
+ @CHROFF(0,0),
};

extern const char *names408[];
static const uint32 types408 [] =
{
SK_BOOL,
};

static const uint16 attr_flags408 [] =
{0,};

static const EIF_TYPE_INDEX g_atype408_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes408 [] = {
g_atype408_0,
};

static const long offsets408 [] =
{
+ @CHROFF(0,0),
};

extern const char *names409[];
static const uint32 types409 [] =
{
SK_BOOL,
};

static const uint16 attr_flags409 [] =
{0,};

static const EIF_TYPE_INDEX g_atype409_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes409 [] = {
g_atype409_0,
};

static const long offsets409 [] =
{
+ @CHROFF(0,0),
};

extern const char *names410[];
static const uint32 types410 [] =
{
SK_BOOL,
};

static const uint16 attr_flags410 [] =
{0,};

static const EIF_TYPE_INDEX g_atype410_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes410 [] = {
g_atype410_0,
};

static const long offsets410 [] =
{
+ @CHROFF(0,0),
};

extern const char *names411[];
static const uint32 types411 [] =
{
SK_BOOL,
};

static const uint16 attr_flags411 [] =
{0,};

static const EIF_TYPE_INDEX g_atype411_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes411 [] = {
g_atype411_0,
};

static const long offsets411 [] =
{
+ @CHROFF(0,0),
};

extern const char *names412[];
static const uint32 types412 [] =
{
SK_BOOL,
};

static const uint16 attr_flags412 [] =
{0,};

static const EIF_TYPE_INDEX g_atype412_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes412 [] = {
g_atype412_0,
};

static const long offsets412 [] =
{
+ @CHROFF(0,0),
};

extern const char *names413[];
static const uint32 types413 [] =
{
SK_BOOL,
};

static const uint16 attr_flags413 [] =
{0,};

static const EIF_TYPE_INDEX g_atype413_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes413 [] = {
g_atype413_0,
};

static const long offsets413 [] =
{
+ @CHROFF(0,0),
};

extern const char *names414[];
static const uint32 types414 [] =
{
SK_BOOL,
};

static const uint16 attr_flags414 [] =
{0,};

static const EIF_TYPE_INDEX g_atype414_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes414 [] = {
g_atype414_0,
};

static const long offsets414 [] =
{
+ @CHROFF(0,0),
};

extern const char *names415[];
static const uint32 types415 [] =
{
SK_BOOL,
};

static const uint16 attr_flags415 [] =
{0,};

static const EIF_TYPE_INDEX g_atype415_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes415 [] = {
g_atype415_0,
};

static const long offsets415 [] =
{
+ @CHROFF(0,0),
};

extern const char *names416[];
static const uint32 types416 [] =
{
SK_BOOL,
};

static const uint16 attr_flags416 [] =
{0,};

static const EIF_TYPE_INDEX g_atype416_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes416 [] = {
g_atype416_0,
};

static const long offsets416 [] =
{
+ @CHROFF(0,0),
};

extern const char *names417[];
static const uint32 types417 [] =
{
SK_BOOL,
};

static const uint16 attr_flags417 [] =
{0,};

static const EIF_TYPE_INDEX g_atype417_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes417 [] = {
g_atype417_0,
};

static const long offsets417 [] =
{
+ @CHROFF(0,0),
};

extern const char *names418[];
static const uint32 types418 [] =
{
SK_BOOL,
};

static const uint16 attr_flags418 [] =
{0,};

static const EIF_TYPE_INDEX g_atype418_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes418 [] = {
g_atype418_0,
};

static const long offsets418 [] =
{
+ @CHROFF(0,0),
};

extern const char *names419[];
static const uint32 types419 [] =
{
SK_BOOL,
};

static const uint16 attr_flags419 [] =
{0,};

static const EIF_TYPE_INDEX g_atype419_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes419 [] = {
g_atype419_0,
};

static const long offsets419 [] =
{
+ @CHROFF(0,0),
};

extern const char *names420[];
static const uint32 types420 [] =
{
SK_BOOL,
};

static const uint16 attr_flags420 [] =
{0,};

static const EIF_TYPE_INDEX g_atype420_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes420 [] = {
g_atype420_0,
};

static const long offsets420 [] =
{
+ @CHROFF(0,0),
};

extern const char *names421[];
static const uint32 types421 [] =
{
SK_BOOL,
};

static const uint16 attr_flags421 [] =
{0,};

static const EIF_TYPE_INDEX g_atype421_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes421 [] = {
g_atype421_0,
};

static const long offsets421 [] =
{
+ @CHROFF(0,0),
};

extern const char *names422[];
static const uint32 types422 [] =
{
SK_BOOL,
};

static const uint16 attr_flags422 [] =
{0,};

static const EIF_TYPE_INDEX g_atype422_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes422 [] = {
g_atype422_0,
};

static const long offsets422 [] =
{
+ @CHROFF(0,0),
};

extern const char *names423[];
static const uint32 types423 [] =
{
SK_BOOL,
};

static const uint16 attr_flags423 [] =
{0,};

static const EIF_TYPE_INDEX g_atype423_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes423 [] = {
g_atype423_0,
};

static const long offsets423 [] =
{
+ @CHROFF(0,0),
};

extern const char *names424[];
static const uint32 types424 [] =
{
SK_BOOL,
};

static const uint16 attr_flags424 [] =
{0,};

static const EIF_TYPE_INDEX g_atype424_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes424 [] = {
g_atype424_0,
};

static const long offsets424 [] =
{
+ @CHROFF(0,0),
};

extern const char *names425[];
static const uint32 types425 [] =
{
SK_BOOL,
};

static const uint16 attr_flags425 [] =
{0,};

static const EIF_TYPE_INDEX g_atype425_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes425 [] = {
g_atype425_0,
};

static const long offsets425 [] =
{
+ @CHROFF(0,0),
};

extern const char *names426[];
static const uint32 types426 [] =
{
SK_BOOL,
};

static const uint16 attr_flags426 [] =
{0,};

static const EIF_TYPE_INDEX g_atype426_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes426 [] = {
g_atype426_0,
};

static const long offsets426 [] =
{
+ @CHROFF(0,0),
};

extern const char *names427[];
static const uint32 types427 [] =
{
SK_BOOL,
};

static const uint16 attr_flags427 [] =
{0,};

static const EIF_TYPE_INDEX g_atype427_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes427 [] = {
g_atype427_0,
};

static const long offsets427 [] =
{
+ @CHROFF(0,0),
};

extern const char *names428[];
static const uint32 types428 [] =
{
SK_BOOL,
};

static const uint16 attr_flags428 [] =
{0,};

static const EIF_TYPE_INDEX g_atype428_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes428 [] = {
g_atype428_0,
};

static const long offsets428 [] =
{
+ @CHROFF(0,0),
};

extern const char *names429[];
static const uint32 types429 [] =
{
SK_BOOL,
};

static const uint16 attr_flags429 [] =
{0,};

static const EIF_TYPE_INDEX g_atype429_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes429 [] = {
g_atype429_0,
};

static const long offsets429 [] =
{
+ @CHROFF(0,0),
};

extern const char *names430[];
static const uint32 types430 [] =
{
SK_BOOL,
};

static const uint16 attr_flags430 [] =
{0,};

static const EIF_TYPE_INDEX g_atype430_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes430 [] = {
g_atype430_0,
};

static const long offsets430 [] =
{
+ @CHROFF(0,0),
};

extern const char *names431[];
static const uint32 types431 [] =
{
SK_BOOL,
};

static const uint16 attr_flags431 [] =
{0,};

static const EIF_TYPE_INDEX g_atype431_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes431 [] = {
g_atype431_0,
};

static const long offsets431 [] =
{
+ @CHROFF(0,0),
};

extern const char *names432[];
static const uint32 types432 [] =
{
SK_BOOL,
};

static const uint16 attr_flags432 [] =
{0,};

static const EIF_TYPE_INDEX g_atype432_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes432 [] = {
g_atype432_0,
};

static const long offsets432 [] =
{
+ @CHROFF(0,0),
};

extern const char *names433[];
static const uint32 types433 [] =
{
SK_BOOL,
};

static const uint16 attr_flags433 [] =
{0,};

static const EIF_TYPE_INDEX g_atype433_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes433 [] = {
g_atype433_0,
};

static const long offsets433 [] =
{
+ @CHROFF(0,0),
};

extern const char *names434[];
static const uint32 types434 [] =
{
SK_BOOL,
};

static const uint16 attr_flags434 [] =
{0,};

static const EIF_TYPE_INDEX g_atype434_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes434 [] = {
g_atype434_0,
};

static const long offsets434 [] =
{
+ @CHROFF(0,0),
};

extern const char *names435[];
static const uint32 types435 [] =
{
SK_BOOL,
};

static const uint16 attr_flags435 [] =
{0,};

static const EIF_TYPE_INDEX g_atype435_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes435 [] = {
g_atype435_0,
};

static const long offsets435 [] =
{
+ @CHROFF(0,0),
};

extern const char *names436[];
static const uint32 types436 [] =
{
SK_BOOL,
};

static const uint16 attr_flags436 [] =
{0,};

static const EIF_TYPE_INDEX g_atype436_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes436 [] = {
g_atype436_0,
};

static const long offsets436 [] =
{
+ @CHROFF(0,0),
};

extern const char *names437[];
static const uint32 types437 [] =
{
SK_BOOL,
};

static const uint16 attr_flags437 [] =
{0,};

static const EIF_TYPE_INDEX g_atype437_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes437 [] = {
g_atype437_0,
};

static const long offsets437 [] =
{
+ @CHROFF(0,0),
};

extern const char *names438[];
static const uint32 types438 [] =
{
SK_BOOL,
};

static const uint16 attr_flags438 [] =
{0,};

static const EIF_TYPE_INDEX g_atype438_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes438 [] = {
g_atype438_0,
};

static const long offsets438 [] =
{
+ @CHROFF(0,0),
};

extern const char *names439[];
static const uint32 types439 [] =
{
SK_BOOL,
};

static const uint16 attr_flags439 [] =
{0,};

static const EIF_TYPE_INDEX g_atype439_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes439 [] = {
g_atype439_0,
};

static const long offsets439 [] =
{
+ @CHROFF(0,0),
};

extern const char *names440[];
static const uint32 types440 [] =
{
SK_BOOL,
};

static const uint16 attr_flags440 [] =
{0,};

static const EIF_TYPE_INDEX g_atype440_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes440 [] = {
g_atype440_0,
};

static const long offsets440 [] =
{
+ @CHROFF(0,0),
};

extern const char *names441[];
static const uint32 types441 [] =
{
SK_BOOL,
};

static const uint16 attr_flags441 [] =
{0,};

static const EIF_TYPE_INDEX g_atype441_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes441 [] = {
g_atype441_0,
};

static const long offsets441 [] =
{
+ @CHROFF(0,0),
};

extern const char *names442[];
static const uint32 types442 [] =
{
SK_BOOL,
};

static const uint16 attr_flags442 [] =
{0,};

static const EIF_TYPE_INDEX g_atype442_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes442 [] = {
g_atype442_0,
};

static const long offsets442 [] =
{
+ @CHROFF(0,0),
};

extern const char *names443[];
static const uint32 types443 [] =
{
SK_BOOL,
};

static const uint16 attr_flags443 [] =
{0,};

static const EIF_TYPE_INDEX g_atype443_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes443 [] = {
g_atype443_0,
};

static const long offsets443 [] =
{
+ @CHROFF(0,0),
};

extern const char *names444[];
static const uint32 types444 [] =
{
SK_BOOL,
};

static const uint16 attr_flags444 [] =
{0,};

static const EIF_TYPE_INDEX g_atype444_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes444 [] = {
g_atype444_0,
};

static const long offsets444 [] =
{
+ @CHROFF(0,0),
};

extern const char *names445[];
static const uint32 types445 [] =
{
SK_BOOL,
};

static const uint16 attr_flags445 [] =
{0,};

static const EIF_TYPE_INDEX g_atype445_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes445 [] = {
g_atype445_0,
};

static const long offsets445 [] =
{
+ @CHROFF(0,0),
};

extern const char *names446[];
static const uint32 types446 [] =
{
SK_BOOL,
};

static const uint16 attr_flags446 [] =
{0,};

static const EIF_TYPE_INDEX g_atype446_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes446 [] = {
g_atype446_0,
};

static const long offsets446 [] =
{
+ @CHROFF(0,0),
};

extern const char *names447[];
static const uint32 types447 [] =
{
SK_BOOL,
};

static const uint16 attr_flags447 [] =
{0,};

static const EIF_TYPE_INDEX g_atype447_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes447 [] = {
g_atype447_0,
};

static const long offsets447 [] =
{
+ @CHROFF(0,0),
};

extern const char *names448[];
static const uint32 types448 [] =
{
SK_BOOL,
};

static const uint16 attr_flags448 [] =
{0,};

static const EIF_TYPE_INDEX g_atype448_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes448 [] = {
g_atype448_0,
};

static const long offsets448 [] =
{
+ @CHROFF(0,0),
};

extern const char *names449[];
static const uint32 types449 [] =
{
SK_BOOL,
};

static const uint16 attr_flags449 [] =
{0,};

static const EIF_TYPE_INDEX g_atype449_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes449 [] = {
g_atype449_0,
};

static const long offsets449 [] =
{
+ @CHROFF(0,0),
};

extern const char *names450[];
static const uint32 types450 [] =
{
SK_BOOL,
};

static const uint16 attr_flags450 [] =
{0,};

static const EIF_TYPE_INDEX g_atype450_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes450 [] = {
g_atype450_0,
};

static const long offsets450 [] =
{
+ @CHROFF(0,0),
};

extern const char *names451[];
static const uint32 types451 [] =
{
SK_BOOL,
};

static const uint16 attr_flags451 [] =
{0,};

static const EIF_TYPE_INDEX g_atype451_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes451 [] = {
g_atype451_0,
};

static const long offsets451 [] =
{
+ @CHROFF(0,0),
};

extern const char *names452[];
static const uint32 types452 [] =
{
SK_BOOL,
};

static const uint16 attr_flags452 [] =
{0,};

static const EIF_TYPE_INDEX g_atype452_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes452 [] = {
g_atype452_0,
};

static const long offsets452 [] =
{
+ @CHROFF(0,0),
};

extern const char *names453[];
static const uint32 types453 [] =
{
SK_BOOL,
};

static const uint16 attr_flags453 [] =
{0,};

static const EIF_TYPE_INDEX g_atype453_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes453 [] = {
g_atype453_0,
};

static const long offsets453 [] =
{
+ @CHROFF(0,0),
};

extern const char *names454[];
static const uint32 types454 [] =
{
SK_BOOL,
};

static const uint16 attr_flags454 [] =
{0,};

static const EIF_TYPE_INDEX g_atype454_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes454 [] = {
g_atype454_0,
};

static const long offsets454 [] =
{
+ @CHROFF(0,0),
};

extern const char *names455[];
static const uint32 types455 [] =
{
SK_BOOL,
};

static const uint16 attr_flags455 [] =
{0,};

static const EIF_TYPE_INDEX g_atype455_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes455 [] = {
g_atype455_0,
};

static const long offsets455 [] =
{
+ @CHROFF(0,0),
};

extern const char *names456[];
static const uint32 types456 [] =
{
SK_BOOL,
};

static const uint16 attr_flags456 [] =
{0,};

static const EIF_TYPE_INDEX g_atype456_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes456 [] = {
g_atype456_0,
};

static const long offsets456 [] =
{
+ @CHROFF(0,0),
};

extern const char *names457[];
static const uint32 types457 [] =
{
SK_BOOL,
};

static const uint16 attr_flags457 [] =
{0,};

static const EIF_TYPE_INDEX g_atype457_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes457 [] = {
g_atype457_0,
};

static const long offsets457 [] =
{
+ @CHROFF(0,0),
};

extern const char *names458[];
static const uint32 types458 [] =
{
SK_BOOL,
};

static const uint16 attr_flags458 [] =
{0,};

static const EIF_TYPE_INDEX g_atype458_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes458 [] = {
g_atype458_0,
};

static const long offsets458 [] =
{
+ @CHROFF(0,0),
};

extern const char *names459[];
static const uint32 types459 [] =
{
SK_BOOL,
};

static const uint16 attr_flags459 [] =
{0,};

static const EIF_TYPE_INDEX g_atype459_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes459 [] = {
g_atype459_0,
};

static const long offsets459 [] =
{
+ @CHROFF(0,0),
};

extern const char *names460[];
static const uint32 types460 [] =
{
SK_BOOL,
};

static const uint16 attr_flags460 [] =
{0,};

static const EIF_TYPE_INDEX g_atype460_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes460 [] = {
g_atype460_0,
};

static const long offsets460 [] =
{
+ @CHROFF(0,0),
};

extern const char *names461[];
static const uint32 types461 [] =
{
SK_BOOL,
};

static const uint16 attr_flags461 [] =
{0,};

static const EIF_TYPE_INDEX g_atype461_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes461 [] = {
g_atype461_0,
};

static const long offsets461 [] =
{
+ @CHROFF(0,0),
};

extern const char *names462[];
static const uint32 types462 [] =
{
SK_BOOL,
};

static const uint16 attr_flags462 [] =
{0,};

static const EIF_TYPE_INDEX g_atype462_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes462 [] = {
g_atype462_0,
};

static const long offsets462 [] =
{
+ @CHROFF(0,0),
};

extern const char *names463[];
static const uint32 types463 [] =
{
SK_BOOL,
};

static const uint16 attr_flags463 [] =
{0,};

static const EIF_TYPE_INDEX g_atype463_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes463 [] = {
g_atype463_0,
};

static const long offsets463 [] =
{
+ @CHROFF(0,0),
};

extern const char *names464[];
static const uint32 types464 [] =
{
SK_BOOL,
};

static const uint16 attr_flags464 [] =
{0,};

static const EIF_TYPE_INDEX g_atype464_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes464 [] = {
g_atype464_0,
};

static const long offsets464 [] =
{
+ @CHROFF(0,0),
};

extern const char *names465[];
static const uint32 types465 [] =
{
SK_BOOL,
};

static const uint16 attr_flags465 [] =
{0,};

static const EIF_TYPE_INDEX g_atype465_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes465 [] = {
g_atype465_0,
};

static const long offsets465 [] =
{
+ @CHROFF(0,0),
};

extern const char *names466[];
static const uint32 types466 [] =
{
SK_BOOL,
};

static const uint16 attr_flags466 [] =
{0,};

static const EIF_TYPE_INDEX g_atype466_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes466 [] = {
g_atype466_0,
};

static const long offsets466 [] =
{
+ @CHROFF(0,0),
};

extern const char *names467[];
static const uint32 types467 [] =
{
SK_BOOL,
};

static const uint16 attr_flags467 [] =
{0,};

static const EIF_TYPE_INDEX g_atype467_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes467 [] = {
g_atype467_0,
};

static const long offsets467 [] =
{
+ @CHROFF(0,0),
};

extern const char *names468[];
static const uint32 types468 [] =
{
SK_BOOL,
};

static const uint16 attr_flags468 [] =
{0,};

static const EIF_TYPE_INDEX g_atype468_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes468 [] = {
g_atype468_0,
};

static const long offsets468 [] =
{
+ @CHROFF(0,0),
};

extern const char *names469[];
static const uint32 types469 [] =
{
SK_BOOL,
};

static const uint16 attr_flags469 [] =
{0,};

static const EIF_TYPE_INDEX g_atype469_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes469 [] = {
g_atype469_0,
};

static const long offsets469 [] =
{
+ @CHROFF(0,0),
};

extern const char *names470[];
static const uint32 types470 [] =
{
SK_BOOL,
};

static const uint16 attr_flags470 [] =
{0,};

static const EIF_TYPE_INDEX g_atype470_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes470 [] = {
g_atype470_0,
};

static const long offsets470 [] =
{
+ @CHROFF(0,0),
};

extern const char *names471[];
static const uint32 types471 [] =
{
SK_BOOL,
};

static const uint16 attr_flags471 [] =
{0,};

static const EIF_TYPE_INDEX g_atype471_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes471 [] = {
g_atype471_0,
};

static const long offsets471 [] =
{
+ @CHROFF(0,0),
};

extern const char *names472[];
static const uint32 types472 [] =
{
SK_BOOL,
};

static const uint16 attr_flags472 [] =
{0,};

static const EIF_TYPE_INDEX g_atype472_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes472 [] = {
g_atype472_0,
};

static const long offsets472 [] =
{
+ @CHROFF(0,0),
};

extern const char *names473[];
static const uint32 types473 [] =
{
SK_BOOL,
};

static const uint16 attr_flags473 [] =
{0,};

static const EIF_TYPE_INDEX g_atype473_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes473 [] = {
g_atype473_0,
};

static const long offsets473 [] =
{
+ @CHROFF(0,0),
};

extern const char *names474[];
static const uint32 types474 [] =
{
SK_BOOL,
};

static const uint16 attr_flags474 [] =
{0,};

static const EIF_TYPE_INDEX g_atype474_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes474 [] = {
g_atype474_0,
};

static const long offsets474 [] =
{
+ @CHROFF(0,0),
};

extern const char *names475[];
static const uint32 types475 [] =
{
SK_BOOL,
};

static const uint16 attr_flags475 [] =
{0,};

static const EIF_TYPE_INDEX g_atype475_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes475 [] = {
g_atype475_0,
};

static const long offsets475 [] =
{
+ @CHROFF(0,0),
};

extern const char *names476[];
static const uint32 types476 [] =
{
SK_BOOL,
};

static const uint16 attr_flags476 [] =
{0,};

static const EIF_TYPE_INDEX g_atype476_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes476 [] = {
g_atype476_0,
};

static const long offsets476 [] =
{
+ @CHROFF(0,0),
};

extern const char *names477[];
static const uint32 types477 [] =
{
SK_BOOL,
};

static const uint16 attr_flags477 [] =
{0,};

static const EIF_TYPE_INDEX g_atype477_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes477 [] = {
g_atype477_0,
};

static const long offsets477 [] =
{
+ @CHROFF(0,0),
};

extern const char *names478[];
static const uint32 types478 [] =
{
SK_BOOL,
};

static const uint16 attr_flags478 [] =
{0,};

static const EIF_TYPE_INDEX g_atype478_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes478 [] = {
g_atype478_0,
};

static const long offsets478 [] =
{
+ @CHROFF(0,0),
};

extern const char *names479[];
static const uint32 types479 [] =
{
SK_BOOL,
};

static const uint16 attr_flags479 [] =
{0,};

static const EIF_TYPE_INDEX g_atype479_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes479 [] = {
g_atype479_0,
};

static const long offsets479 [] =
{
+ @CHROFF(0,0),
};

extern const char *names480[];
static const uint32 types480 [] =
{
SK_BOOL,
};

static const uint16 attr_flags480 [] =
{0,};

static const EIF_TYPE_INDEX g_atype480_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes480 [] = {
g_atype480_0,
};

static const long offsets480 [] =
{
+ @CHROFF(0,0),
};

extern const char *names481[];
static const uint32 types481 [] =
{
SK_BOOL,
};

static const uint16 attr_flags481 [] =
{0,};

static const EIF_TYPE_INDEX g_atype481_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes481 [] = {
g_atype481_0,
};

static const long offsets481 [] =
{
+ @CHROFF(0,0),
};

extern const char *names482[];
static const uint32 types482 [] =
{
SK_BOOL,
};

static const uint16 attr_flags482 [] =
{0,};

static const EIF_TYPE_INDEX g_atype482_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes482 [] = {
g_atype482_0,
};

static const long offsets482 [] =
{
+ @CHROFF(0,0),
};

extern const char *names483[];
static const uint32 types483 [] =
{
SK_BOOL,
};

static const uint16 attr_flags483 [] =
{0,};

static const EIF_TYPE_INDEX g_atype483_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes483 [] = {
g_atype483_0,
};

static const long offsets483 [] =
{
+ @CHROFF(0,0),
};

extern const char *names484[];
static const uint32 types484 [] =
{
SK_BOOL,
};

static const uint16 attr_flags484 [] =
{0,};

static const EIF_TYPE_INDEX g_atype484_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes484 [] = {
g_atype484_0,
};

static const long offsets484 [] =
{
+ @CHROFF(0,0),
};

extern const char *names485[];
static const uint32 types485 [] =
{
SK_BOOL,
};

static const uint16 attr_flags485 [] =
{0,};

static const EIF_TYPE_INDEX g_atype485_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes485 [] = {
g_atype485_0,
};

static const long offsets485 [] =
{
+ @CHROFF(0,0),
};

extern const char *names486[];
static const uint32 types486 [] =
{
SK_BOOL,
};

static const uint16 attr_flags486 [] =
{0,};

static const EIF_TYPE_INDEX g_atype486_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes486 [] = {
g_atype486_0,
};

static const long offsets486 [] =
{
+ @CHROFF(0,0),
};

extern const char *names487[];
static const uint32 types487 [] =
{
SK_BOOL,
};

static const uint16 attr_flags487 [] =
{0,};

static const EIF_TYPE_INDEX g_atype487_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes487 [] = {
g_atype487_0,
};

static const long offsets487 [] =
{
+ @CHROFF(0,0),
};

extern const char *names488[];
static const uint32 types488 [] =
{
SK_BOOL,
};

static const uint16 attr_flags488 [] =
{0,};

static const EIF_TYPE_INDEX g_atype488_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes488 [] = {
g_atype488_0,
};

static const long offsets488 [] =
{
+ @CHROFF(0,0),
};

extern const char *names489[];
static const uint32 types489 [] =
{
SK_BOOL,
};

static const uint16 attr_flags489 [] =
{0,};

static const EIF_TYPE_INDEX g_atype489_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes489 [] = {
g_atype489_0,
};

static const long offsets489 [] =
{
+ @CHROFF(0,0),
};

extern const char *names490[];
static const uint32 types490 [] =
{
SK_BOOL,
};

static const uint16 attr_flags490 [] =
{0,};

static const EIF_TYPE_INDEX g_atype490_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes490 [] = {
g_atype490_0,
};

static const long offsets490 [] =
{
+ @CHROFF(0,0),
};

extern const char *names491[];
static const uint32 types491 [] =
{
SK_BOOL,
};

static const uint16 attr_flags491 [] =
{0,};

static const EIF_TYPE_INDEX g_atype491_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes491 [] = {
g_atype491_0,
};

static const long offsets491 [] =
{
+ @CHROFF(0,0),
};

extern const char *names492[];
static const uint32 types492 [] =
{
SK_BOOL,
};

static const uint16 attr_flags492 [] =
{0,};

static const EIF_TYPE_INDEX g_atype492_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes492 [] = {
g_atype492_0,
};

static const long offsets492 [] =
{
+ @CHROFF(0,0),
};

extern const char *names493[];
static const uint32 types493 [] =
{
SK_BOOL,
};

static const uint16 attr_flags493 [] =
{0,};

static const EIF_TYPE_INDEX g_atype493_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes493 [] = {
g_atype493_0,
};

static const long offsets493 [] =
{
+ @CHROFF(0,0),
};

extern const char *names494[];
static const uint32 types494 [] =
{
SK_BOOL,
};

static const uint16 attr_flags494 [] =
{0,};

static const EIF_TYPE_INDEX g_atype494_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes494 [] = {
g_atype494_0,
};

static const long offsets494 [] =
{
+ @CHROFF(0,0),
};

extern const char *names495[];
static const uint32 types495 [] =
{
SK_BOOL,
};

static const uint16 attr_flags495 [] =
{0,};

static const EIF_TYPE_INDEX g_atype495_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes495 [] = {
g_atype495_0,
};

static const long offsets495 [] =
{
+ @CHROFF(0,0),
};

extern const char *names496[];
static const uint32 types496 [] =
{
SK_BOOL,
};

static const uint16 attr_flags496 [] =
{0,};

static const EIF_TYPE_INDEX g_atype496_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes496 [] = {
g_atype496_0,
};

static const long offsets496 [] =
{
+ @CHROFF(0,0),
};

extern const char *names497[];
static const uint32 types497 [] =
{
SK_BOOL,
};

static const uint16 attr_flags497 [] =
{0,};

static const EIF_TYPE_INDEX g_atype497_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes497 [] = {
g_atype497_0,
};

static const long offsets497 [] =
{
+ @CHROFF(0,0),
};

extern const char *names498[];
static const uint32 types498 [] =
{
SK_BOOL,
};

static const uint16 attr_flags498 [] =
{0,};

static const EIF_TYPE_INDEX g_atype498_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes498 [] = {
g_atype498_0,
};

static const long offsets498 [] =
{
+ @CHROFF(0,0),
};

extern const char *names499[];
static const uint32 types499 [] =
{
SK_BOOL,
};

static const uint16 attr_flags499 [] =
{0,};

static const EIF_TYPE_INDEX g_atype499_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes499 [] = {
g_atype499_0,
};

static const long offsets499 [] =
{
+ @CHROFF(0,0),
};

extern const char *names500[];
static const uint32 types500 [] =
{
SK_BOOL,
};

static const uint16 attr_flags500 [] =
{0,};

static const EIF_TYPE_INDEX g_atype500_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes500 [] = {
g_atype500_0,
};

static const long offsets500 [] =
{
+ @CHROFF(0,0),
};

extern const char *names501[];
static const uint32 types501 [] =
{
SK_BOOL,
};

static const uint16 attr_flags501 [] =
{0,};

static const EIF_TYPE_INDEX g_atype501_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes501 [] = {
g_atype501_0,
};

static const long offsets501 [] =
{
+ @CHROFF(0,0),
};

extern const char *names502[];
static const uint32 types502 [] =
{
SK_BOOL,
};

static const uint16 attr_flags502 [] =
{0,};

static const EIF_TYPE_INDEX g_atype502_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes502 [] = {
g_atype502_0,
};

static const long offsets502 [] =
{
+ @CHROFF(0,0),
};

extern const char *names503[];
static const uint32 types503 [] =
{
SK_BOOL,
};

static const uint16 attr_flags503 [] =
{0,};

static const EIF_TYPE_INDEX g_atype503_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes503 [] = {
g_atype503_0,
};

static const long offsets503 [] =
{
+ @CHROFF(0,0),
};

extern const char *names504[];
static const uint32 types504 [] =
{
SK_BOOL,
};

static const uint16 attr_flags504 [] =
{0,};

static const EIF_TYPE_INDEX g_atype504_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes504 [] = {
g_atype504_0,
};

static const long offsets504 [] =
{
+ @CHROFF(0,0),
};

extern const char *names505[];
static const uint32 types505 [] =
{
SK_BOOL,
};

static const uint16 attr_flags505 [] =
{0,};

static const EIF_TYPE_INDEX g_atype505_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes505 [] = {
g_atype505_0,
};

static const long offsets505 [] =
{
+ @CHROFF(0,0),
};

extern const char *names506[];
static const uint32 types506 [] =
{
SK_BOOL,
};

static const uint16 attr_flags506 [] =
{0,};

static const EIF_TYPE_INDEX g_atype506_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes506 [] = {
g_atype506_0,
};

static const long offsets506 [] =
{
+ @CHROFF(0,0),
};

extern const char *names507[];
static const uint32 types507 [] =
{
SK_BOOL,
};

static const uint16 attr_flags507 [] =
{0,};

static const EIF_TYPE_INDEX g_atype507_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes507 [] = {
g_atype507_0,
};

static const long offsets507 [] =
{
+ @CHROFF(0,0),
};

extern const char *names508[];
static const uint32 types508 [] =
{
SK_BOOL,
};

static const uint16 attr_flags508 [] =
{0,};

static const EIF_TYPE_INDEX g_atype508_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes508 [] = {
g_atype508_0,
};

static const long offsets508 [] =
{
+ @CHROFF(0,0),
};

extern const char *names509[];
static const uint32 types509 [] =
{
SK_BOOL,
};

static const uint16 attr_flags509 [] =
{0,};

static const EIF_TYPE_INDEX g_atype509_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes509 [] = {
g_atype509_0,
};

static const long offsets509 [] =
{
+ @CHROFF(0,0),
};

extern const char *names510[];
static const uint32 types510 [] =
{
SK_BOOL,
};

static const uint16 attr_flags510 [] =
{0,};

static const EIF_TYPE_INDEX g_atype510_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes510 [] = {
g_atype510_0,
};

static const long offsets510 [] =
{
+ @CHROFF(0,0),
};

extern const char *names511[];
static const uint32 types511 [] =
{
SK_BOOL,
};

static const uint16 attr_flags511 [] =
{0,};

static const EIF_TYPE_INDEX g_atype511_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes511 [] = {
g_atype511_0,
};

static const long offsets511 [] =
{
+ @CHROFF(0,0),
};

extern const char *names512[];
static const uint32 types512 [] =
{
SK_BOOL,
};

static const uint16 attr_flags512 [] =
{0,};

static const EIF_TYPE_INDEX g_atype512_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes512 [] = {
g_atype512_0,
};

static const long offsets512 [] =
{
+ @CHROFF(0,0),
};

extern const char *names513[];
static const uint32 types513 [] =
{
SK_BOOL,
};

static const uint16 attr_flags513 [] =
{0,};

static const EIF_TYPE_INDEX g_atype513_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes513 [] = {
g_atype513_0,
};

static const long offsets513 [] =
{
+ @CHROFF(0,0),
};

extern const char *names514[];
static const uint32 types514 [] =
{
SK_BOOL,
};

static const uint16 attr_flags514 [] =
{0,};

static const EIF_TYPE_INDEX g_atype514_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes514 [] = {
g_atype514_0,
};

static const long offsets514 [] =
{
+ @CHROFF(0,0),
};

extern const char *names515[];
static const uint32 types515 [] =
{
SK_BOOL,
};

static const uint16 attr_flags515 [] =
{0,};

static const EIF_TYPE_INDEX g_atype515_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes515 [] = {
g_atype515_0,
};

static const long offsets515 [] =
{
+ @CHROFF(0,0),
};

extern const char *names516[];
static const uint32 types516 [] =
{
SK_BOOL,
};

static const uint16 attr_flags516 [] =
{0,};

static const EIF_TYPE_INDEX g_atype516_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes516 [] = {
g_atype516_0,
};

static const long offsets516 [] =
{
+ @CHROFF(0,0),
};

extern const char *names517[];
static const uint32 types517 [] =
{
SK_BOOL,
};

static const uint16 attr_flags517 [] =
{0,};

static const EIF_TYPE_INDEX g_atype517_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes517 [] = {
g_atype517_0,
};

static const long offsets517 [] =
{
+ @CHROFF(0,0),
};

extern const char *names518[];
static const uint32 types518 [] =
{
SK_BOOL,
};

static const uint16 attr_flags518 [] =
{0,};

static const EIF_TYPE_INDEX g_atype518_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes518 [] = {
g_atype518_0,
};

static const long offsets518 [] =
{
+ @CHROFF(0,0),
};

extern const char *names519[];
static const uint32 types519 [] =
{
SK_BOOL,
};

static const uint16 attr_flags519 [] =
{0,};

static const EIF_TYPE_INDEX g_atype519_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes519 [] = {
g_atype519_0,
};

static const long offsets519 [] =
{
+ @CHROFF(0,0),
};

extern const char *names520[];
static const uint32 types520 [] =
{
SK_BOOL,
};

static const uint16 attr_flags520 [] =
{0,};

static const EIF_TYPE_INDEX g_atype520_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes520 [] = {
g_atype520_0,
};

static const long offsets520 [] =
{
+ @CHROFF(0,0),
};

extern const char *names521[];
static const uint32 types521 [] =
{
SK_BOOL,
};

static const uint16 attr_flags521 [] =
{0,};

static const EIF_TYPE_INDEX g_atype521_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes521 [] = {
g_atype521_0,
};

static const long offsets521 [] =
{
+ @CHROFF(0,0),
};

extern const char *names522[];
static const uint32 types522 [] =
{
SK_BOOL,
};

static const uint16 attr_flags522 [] =
{0,};

static const EIF_TYPE_INDEX g_atype522_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes522 [] = {
g_atype522_0,
};

static const long offsets522 [] =
{
+ @CHROFF(0,0),
};

extern const char *names523[];
static const uint32 types523 [] =
{
SK_BOOL,
};

static const uint16 attr_flags523 [] =
{0,};

static const EIF_TYPE_INDEX g_atype523_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes523 [] = {
g_atype523_0,
};

static const long offsets523 [] =
{
+ @CHROFF(0,0),
};

extern const char *names524[];
static const uint32 types524 [] =
{
SK_BOOL,
};

static const uint16 attr_flags524 [] =
{0,};

static const EIF_TYPE_INDEX g_atype524_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes524 [] = {
g_atype524_0,
};

static const long offsets524 [] =
{
+ @CHROFF(0,0),
};

extern const char *names525[];
static const uint32 types525 [] =
{
SK_BOOL,
};

static const uint16 attr_flags525 [] =
{0,};

static const EIF_TYPE_INDEX g_atype525_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes525 [] = {
g_atype525_0,
};

static const long offsets525 [] =
{
+ @CHROFF(0,0),
};

extern const char *names526[];
static const uint32 types526 [] =
{
SK_BOOL,
};

static const uint16 attr_flags526 [] =
{0,};

static const EIF_TYPE_INDEX g_atype526_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes526 [] = {
g_atype526_0,
};

static const long offsets526 [] =
{
+ @CHROFF(0,0),
};

extern const char *names527[];
static const uint32 types527 [] =
{
SK_BOOL,
};

static const uint16 attr_flags527 [] =
{0,};

static const EIF_TYPE_INDEX g_atype527_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes527 [] = {
g_atype527_0,
};

static const long offsets527 [] =
{
+ @CHROFF(0,0),
};

extern const char *names528[];
static const uint32 types528 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags528 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype528_0 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype528_1 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes528 [] = {
g_atype528_0,
g_atype528_1,
};

static const long offsets528 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names529[];
static const uint32 types529 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags529 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype529_0 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype529_1 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes529 [] = {
g_atype529_0,
g_atype529_1,
};

static const long offsets529 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names530[];
static const uint32 types530 [] =
{
SK_BOOL,
};

static const uint16 attr_flags530 [] =
{0,};

static const EIF_TYPE_INDEX g_atype530_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes530 [] = {
g_atype530_0,
};

static const long offsets530 [] =
{
+ @CHROFF(0,0),
};

extern const char *names531[];
static const uint32 types531 [] =
{
SK_BOOL,
};

static const uint16 attr_flags531 [] =
{0,};

static const EIF_TYPE_INDEX g_atype531_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes531 [] = {
g_atype531_0,
};

static const long offsets531 [] =
{
+ @CHROFF(0,0),
};

extern const char *names532[];
static const uint32 types532 [] =
{
SK_BOOL,
};

static const uint16 attr_flags532 [] =
{0,};

static const EIF_TYPE_INDEX g_atype532_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes532 [] = {
g_atype532_0,
};

static const long offsets532 [] =
{
+ @CHROFF(0,0),
};

extern const char *names533[];
static const uint32 types533 [] =
{
SK_BOOL,
};

static const uint16 attr_flags533 [] =
{0,};

static const EIF_TYPE_INDEX g_atype533_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes533 [] = {
g_atype533_0,
};

static const long offsets533 [] =
{
+ @CHROFF(0,0),
};

extern const char *names534[];
static const uint32 types534 [] =
{
SK_BOOL,
};

static const uint16 attr_flags534 [] =
{0,};

static const EIF_TYPE_INDEX g_atype534_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes534 [] = {
g_atype534_0,
};

static const long offsets534 [] =
{
+ @CHROFF(0,0),
};

extern const char *names535[];
static const uint32 types535 [] =
{
SK_BOOL,
};

static const uint16 attr_flags535 [] =
{0,};

static const EIF_TYPE_INDEX g_atype535_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes535 [] = {
g_atype535_0,
};

static const long offsets535 [] =
{
+ @CHROFF(0,0),
};

extern const char *names536[];
static const uint32 types536 [] =
{
SK_BOOL,
};

static const uint16 attr_flags536 [] =
{0,};

static const EIF_TYPE_INDEX g_atype536_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes536 [] = {
g_atype536_0,
};

static const long offsets536 [] =
{
+ @CHROFF(0,0),
};

extern const char *names537[];
static const uint32 types537 [] =
{
SK_BOOL,
};

static const uint16 attr_flags537 [] =
{0,};

static const EIF_TYPE_INDEX g_atype537_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes537 [] = {
g_atype537_0,
};

static const long offsets537 [] =
{
+ @CHROFF(0,0),
};

extern const char *names538[];
static const uint32 types538 [] =
{
SK_BOOL,
};

static const uint16 attr_flags538 [] =
{0,};

static const EIF_TYPE_INDEX g_atype538_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes538 [] = {
g_atype538_0,
};

static const long offsets538 [] =
{
+ @CHROFF(0,0),
};

extern const char *names539[];
static const uint32 types539 [] =
{
SK_BOOL,
};

static const uint16 attr_flags539 [] =
{0,};

static const EIF_TYPE_INDEX g_atype539_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes539 [] = {
g_atype539_0,
};

static const long offsets539 [] =
{
+ @CHROFF(0,0),
};

extern const char *names540[];
static const uint32 types540 [] =
{
SK_BOOL,
};

static const uint16 attr_flags540 [] =
{0,};

static const EIF_TYPE_INDEX g_atype540_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes540 [] = {
g_atype540_0,
};

static const long offsets540 [] =
{
+ @CHROFF(0,0),
};

extern const char *names541[];
static const uint32 types541 [] =
{
SK_BOOL,
};

static const uint16 attr_flags541 [] =
{0,};

static const EIF_TYPE_INDEX g_atype541_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes541 [] = {
g_atype541_0,
};

static const long offsets541 [] =
{
+ @CHROFF(0,0),
};

extern const char *names542[];
static const uint32 types542 [] =
{
SK_BOOL,
};

static const uint16 attr_flags542 [] =
{0,};

static const EIF_TYPE_INDEX g_atype542_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes542 [] = {
g_atype542_0,
};

static const long offsets542 [] =
{
+ @CHROFF(0,0),
};

extern const char *names543[];
static const uint32 types543 [] =
{
SK_BOOL,
};

static const uint16 attr_flags543 [] =
{0,};

static const EIF_TYPE_INDEX g_atype543_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes543 [] = {
g_atype543_0,
};

static const long offsets543 [] =
{
+ @CHROFF(0,0),
};

extern const char *names544[];
static const uint32 types544 [] =
{
SK_BOOL,
};

static const uint16 attr_flags544 [] =
{0,};

static const EIF_TYPE_INDEX g_atype544_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes544 [] = {
g_atype544_0,
};

static const long offsets544 [] =
{
+ @CHROFF(0,0),
};

extern const char *names545[];
static const uint32 types545 [] =
{
SK_BOOL,
};

static const uint16 attr_flags545 [] =
{0,};

static const EIF_TYPE_INDEX g_atype545_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes545 [] = {
g_atype545_0,
};

static const long offsets545 [] =
{
+ @CHROFF(0,0),
};

extern const char *names546[];
static const uint32 types546 [] =
{
SK_BOOL,
};

static const uint16 attr_flags546 [] =
{0,};

static const EIF_TYPE_INDEX g_atype546_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes546 [] = {
g_atype546_0,
};

static const long offsets546 [] =
{
+ @CHROFF(0,0),
};

extern const char *names547[];
static const uint32 types547 [] =
{
SK_BOOL,
};

static const uint16 attr_flags547 [] =
{0,};

static const EIF_TYPE_INDEX g_atype547_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes547 [] = {
g_atype547_0,
};

static const long offsets547 [] =
{
+ @CHROFF(0,0),
};

extern const char *names548[];
static const uint32 types548 [] =
{
SK_BOOL,
};

static const uint16 attr_flags548 [] =
{0,};

static const EIF_TYPE_INDEX g_atype548_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes548 [] = {
g_atype548_0,
};

static const long offsets548 [] =
{
+ @CHROFF(0,0),
};

extern const char *names549[];
static const uint32 types549 [] =
{
SK_BOOL,
};

static const uint16 attr_flags549 [] =
{0,};

static const EIF_TYPE_INDEX g_atype549_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes549 [] = {
g_atype549_0,
};

static const long offsets549 [] =
{
+ @CHROFF(0,0),
};

extern const char *names550[];
static const uint32 types550 [] =
{
SK_BOOL,
};

static const uint16 attr_flags550 [] =
{0,};

static const EIF_TYPE_INDEX g_atype550_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes550 [] = {
g_atype550_0,
};

static const long offsets550 [] =
{
+ @CHROFF(0,0),
};

extern const char *names551[];
static const uint32 types551 [] =
{
SK_BOOL,
};

static const uint16 attr_flags551 [] =
{0,};

static const EIF_TYPE_INDEX g_atype551_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes551 [] = {
g_atype551_0,
};

static const long offsets551 [] =
{
+ @CHROFF(0,0),
};

extern const char *names552[];
static const uint32 types552 [] =
{
SK_BOOL,
};

static const uint16 attr_flags552 [] =
{0,};

static const EIF_TYPE_INDEX g_atype552_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes552 [] = {
g_atype552_0,
};

static const long offsets552 [] =
{
+ @CHROFF(0,0),
};

extern const char *names553[];
static const uint32 types553 [] =
{
SK_BOOL,
};

static const uint16 attr_flags553 [] =
{0,};

static const EIF_TYPE_INDEX g_atype553_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes553 [] = {
g_atype553_0,
};

static const long offsets553 [] =
{
+ @CHROFF(0,0),
};

extern const char *names554[];
static const uint32 types554 [] =
{
SK_BOOL,
};

static const uint16 attr_flags554 [] =
{0,};

static const EIF_TYPE_INDEX g_atype554_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes554 [] = {
g_atype554_0,
};

static const long offsets554 [] =
{
+ @CHROFF(0,0),
};

extern const char *names555[];
static const uint32 types555 [] =
{
SK_BOOL,
};

static const uint16 attr_flags555 [] =
{0,};

static const EIF_TYPE_INDEX g_atype555_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes555 [] = {
g_atype555_0,
};

static const long offsets555 [] =
{
+ @CHROFF(0,0),
};

extern const char *names556[];
static const uint32 types556 [] =
{
SK_BOOL,
};

static const uint16 attr_flags556 [] =
{0,};

static const EIF_TYPE_INDEX g_atype556_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes556 [] = {
g_atype556_0,
};

static const long offsets556 [] =
{
+ @CHROFF(0,0),
};

extern const char *names557[];
static const uint32 types557 [] =
{
SK_BOOL,
};

static const uint16 attr_flags557 [] =
{0,};

static const EIF_TYPE_INDEX g_atype557_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes557 [] = {
g_atype557_0,
};

static const long offsets557 [] =
{
+ @CHROFF(0,0),
};

extern const char *names558[];
static const uint32 types558 [] =
{
SK_BOOL,
};

static const uint16 attr_flags558 [] =
{0,};

static const EIF_TYPE_INDEX g_atype558_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes558 [] = {
g_atype558_0,
};

static const long offsets558 [] =
{
+ @CHROFF(0,0),
};

extern const char *names559[];
static const uint32 types559 [] =
{
SK_BOOL,
};

static const uint16 attr_flags559 [] =
{0,};

static const EIF_TYPE_INDEX g_atype559_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes559 [] = {
g_atype559_0,
};

static const long offsets559 [] =
{
+ @CHROFF(0,0),
};

extern const char *names560[];
static const uint32 types560 [] =
{
SK_BOOL,
};

static const uint16 attr_flags560 [] =
{0,};

static const EIF_TYPE_INDEX g_atype560_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes560 [] = {
g_atype560_0,
};

static const long offsets560 [] =
{
+ @CHROFF(0,0),
};

extern const char *names561[];
static const uint32 types561 [] =
{
SK_BOOL,
};

static const uint16 attr_flags561 [] =
{0,};

static const EIF_TYPE_INDEX g_atype561_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes561 [] = {
g_atype561_0,
};

static const long offsets561 [] =
{
+ @CHROFF(0,0),
};

extern const char *names562[];
static const uint32 types562 [] =
{
SK_BOOL,
};

static const uint16 attr_flags562 [] =
{0,};

static const EIF_TYPE_INDEX g_atype562_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes562 [] = {
g_atype562_0,
};

static const long offsets562 [] =
{
+ @CHROFF(0,0),
};

extern const char *names563[];
static const uint32 types563 [] =
{
SK_BOOL,
};

static const uint16 attr_flags563 [] =
{0,};

static const EIF_TYPE_INDEX g_atype563_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes563 [] = {
g_atype563_0,
};

static const long offsets563 [] =
{
+ @CHROFF(0,0),
};

extern const char *names564[];
static const uint32 types564 [] =
{
SK_BOOL,
};

static const uint16 attr_flags564 [] =
{0,};

static const EIF_TYPE_INDEX g_atype564_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes564 [] = {
g_atype564_0,
};

static const long offsets564 [] =
{
+ @CHROFF(0,0),
};

extern const char *names565[];
static const uint32 types565 [] =
{
SK_BOOL,
};

static const uint16 attr_flags565 [] =
{0,};

static const EIF_TYPE_INDEX g_atype565_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes565 [] = {
g_atype565_0,
};

static const long offsets565 [] =
{
+ @CHROFF(0,0),
};

extern const char *names566[];
static const uint32 types566 [] =
{
SK_BOOL,
};

static const uint16 attr_flags566 [] =
{0,};

static const EIF_TYPE_INDEX g_atype566_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes566 [] = {
g_atype566_0,
};

static const long offsets566 [] =
{
+ @CHROFF(0,0),
};

extern const char *names567[];
static const uint32 types567 [] =
{
SK_BOOL,
};

static const uint16 attr_flags567 [] =
{0,};

static const EIF_TYPE_INDEX g_atype567_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes567 [] = {
g_atype567_0,
};

static const long offsets567 [] =
{
+ @CHROFF(0,0),
};

extern const char *names568[];
static const uint32 types568 [] =
{
SK_BOOL,
};

static const uint16 attr_flags568 [] =
{0,};

static const EIF_TYPE_INDEX g_atype568_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes568 [] = {
g_atype568_0,
};

static const long offsets568 [] =
{
+ @CHROFF(0,0),
};

extern const char *names569[];
static const uint32 types569 [] =
{
SK_BOOL,
};

static const uint16 attr_flags569 [] =
{0,};

static const EIF_TYPE_INDEX g_atype569_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes569 [] = {
g_atype569_0,
};

static const long offsets569 [] =
{
+ @CHROFF(0,0),
};

extern const char *names570[];
static const uint32 types570 [] =
{
SK_BOOL,
};

static const uint16 attr_flags570 [] =
{0,};

static const EIF_TYPE_INDEX g_atype570_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes570 [] = {
g_atype570_0,
};

static const long offsets570 [] =
{
+ @CHROFF(0,0),
};

extern const char *names571[];
static const uint32 types571 [] =
{
SK_BOOL,
};

static const uint16 attr_flags571 [] =
{0,};

static const EIF_TYPE_INDEX g_atype571_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes571 [] = {
g_atype571_0,
};

static const long offsets571 [] =
{
+ @CHROFF(0,0),
};

extern const char *names572[];
static const uint32 types572 [] =
{
SK_BOOL,
};

static const uint16 attr_flags572 [] =
{0,};

static const EIF_TYPE_INDEX g_atype572_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes572 [] = {
g_atype572_0,
};

static const long offsets572 [] =
{
+ @CHROFF(0,0),
};

extern const char *names573[];
static const uint32 types573 [] =
{
SK_BOOL,
};

static const uint16 attr_flags573 [] =
{0,};

static const EIF_TYPE_INDEX g_atype573_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes573 [] = {
g_atype573_0,
};

static const long offsets573 [] =
{
+ @CHROFF(0,0),
};

extern const char *names574[];
static const uint32 types574 [] =
{
SK_BOOL,
};

static const uint16 attr_flags574 [] =
{0,};

static const EIF_TYPE_INDEX g_atype574_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes574 [] = {
g_atype574_0,
};

static const long offsets574 [] =
{
+ @CHROFF(0,0),
};

extern const char *names575[];
static const uint32 types575 [] =
{
SK_BOOL,
};

static const uint16 attr_flags575 [] =
{0,};

static const EIF_TYPE_INDEX g_atype575_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes575 [] = {
g_atype575_0,
};

static const long offsets575 [] =
{
+ @CHROFF(0,0),
};

extern const char *names576[];
static const uint32 types576 [] =
{
SK_BOOL,
};

static const uint16 attr_flags576 [] =
{0,};

static const EIF_TYPE_INDEX g_atype576_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes576 [] = {
g_atype576_0,
};

static const long offsets576 [] =
{
+ @CHROFF(0,0),
};

extern const char *names577[];
static const uint32 types577 [] =
{
SK_BOOL,
};

static const uint16 attr_flags577 [] =
{0,};

static const EIF_TYPE_INDEX g_atype577_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes577 [] = {
g_atype577_0,
};

static const long offsets577 [] =
{
+ @CHROFF(0,0),
};

extern const char *names578[];
static const uint32 types578 [] =
{
SK_BOOL,
};

static const uint16 attr_flags578 [] =
{0,};

static const EIF_TYPE_INDEX g_atype578_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes578 [] = {
g_atype578_0,
};

static const long offsets578 [] =
{
+ @CHROFF(0,0),
};

extern const char *names579[];
static const uint32 types579 [] =
{
SK_BOOL,
};

static const uint16 attr_flags579 [] =
{0,};

static const EIF_TYPE_INDEX g_atype579_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes579 [] = {
g_atype579_0,
};

static const long offsets579 [] =
{
+ @CHROFF(0,0),
};

extern const char *names580[];
static const uint32 types580 [] =
{
SK_BOOL,
};

static const uint16 attr_flags580 [] =
{0,};

static const EIF_TYPE_INDEX g_atype580_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes580 [] = {
g_atype580_0,
};

static const long offsets580 [] =
{
+ @CHROFF(0,0),
};

extern const char *names581[];
static const uint32 types581 [] =
{
SK_BOOL,
};

static const uint16 attr_flags581 [] =
{0,};

static const EIF_TYPE_INDEX g_atype581_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes581 [] = {
g_atype581_0,
};

static const long offsets581 [] =
{
+ @CHROFF(0,0),
};

extern const char *names582[];
static const uint32 types582 [] =
{
SK_BOOL,
};

static const uint16 attr_flags582 [] =
{0,};

static const EIF_TYPE_INDEX g_atype582_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes582 [] = {
g_atype582_0,
};

static const long offsets582 [] =
{
+ @CHROFF(0,0),
};

extern const char *names583[];
static const uint32 types583 [] =
{
SK_BOOL,
};

static const uint16 attr_flags583 [] =
{0,};

static const EIF_TYPE_INDEX g_atype583_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes583 [] = {
g_atype583_0,
};

static const long offsets583 [] =
{
+ @CHROFF(0,0),
};

extern const char *names584[];
static const uint32 types584 [] =
{
SK_BOOL,
};

static const uint16 attr_flags584 [] =
{0,};

static const EIF_TYPE_INDEX g_atype584_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes584 [] = {
g_atype584_0,
};

static const long offsets584 [] =
{
+ @CHROFF(0,0),
};

extern const char *names585[];
static const uint32 types585 [] =
{
SK_BOOL,
};

static const uint16 attr_flags585 [] =
{0,};

static const EIF_TYPE_INDEX g_atype585_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes585 [] = {
g_atype585_0,
};

static const long offsets585 [] =
{
+ @CHROFF(0,0),
};

extern const char *names586[];
static const uint32 types586 [] =
{
SK_BOOL,
};

static const uint16 attr_flags586 [] =
{0,};

static const EIF_TYPE_INDEX g_atype586_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes586 [] = {
g_atype586_0,
};

static const long offsets586 [] =
{
+ @CHROFF(0,0),
};

extern const char *names587[];
static const uint32 types587 [] =
{
SK_BOOL,
};

static const uint16 attr_flags587 [] =
{0,};

static const EIF_TYPE_INDEX g_atype587_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes587 [] = {
g_atype587_0,
};

static const long offsets587 [] =
{
+ @CHROFF(0,0),
};

extern const char *names588[];
static const uint32 types588 [] =
{
SK_BOOL,
};

static const uint16 attr_flags588 [] =
{0,};

static const EIF_TYPE_INDEX g_atype588_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes588 [] = {
g_atype588_0,
};

static const long offsets588 [] =
{
+ @CHROFF(0,0),
};

extern const char *names589[];
static const uint32 types589 [] =
{
SK_BOOL,
};

static const uint16 attr_flags589 [] =
{0,};

static const EIF_TYPE_INDEX g_atype589_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes589 [] = {
g_atype589_0,
};

static const long offsets589 [] =
{
+ @CHROFF(0,0),
};

extern const char *names590[];
static const uint32 types590 [] =
{
SK_BOOL,
};

static const uint16 attr_flags590 [] =
{0,};

static const EIF_TYPE_INDEX g_atype590_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes590 [] = {
g_atype590_0,
};

static const long offsets590 [] =
{
+ @CHROFF(0,0),
};

extern const char *names591[];
static const uint32 types591 [] =
{
SK_BOOL,
};

static const uint16 attr_flags591 [] =
{0,};

static const EIF_TYPE_INDEX g_atype591_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes591 [] = {
g_atype591_0,
};

static const long offsets591 [] =
{
+ @CHROFF(0,0),
};

extern const char *names592[];
static const uint32 types592 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags592 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype592_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_1 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_4 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_7 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_8 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_9 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_10 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_11 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_15 [] = {810,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_16 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_17 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_18 [] = {825,0xFFFF};
static const EIF_TYPE_INDEX g_atype592_19 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes592 [] = {
g_atype592_0,
g_atype592_1,
g_atype592_2,
g_atype592_3,
g_atype592_4,
g_atype592_5,
g_atype592_6,
g_atype592_7,
g_atype592_8,
g_atype592_9,
g_atype592_10,
g_atype592_11,
g_atype592_12,
g_atype592_13,
g_atype592_14,
g_atype592_15,
g_atype592_16,
g_atype592_17,
g_atype592_18,
g_atype592_19,
};

static const long offsets592 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @I16OFF(3,6,0),
+ @I16OFF(3,6,1),
+ @LNGOFF(3,6,2,0),
+ @LNGOFF(3,6,2,1),
+ @LNGOFF(3,6,2,2),
+ @LNGOFF(3,6,2,3),
+ @R32OFF(3,6,2,4,0),
+ @PTROFF(3,6,2,4,1,0),
+ @I64OFF(3,6,2,4,1,1,0),
+ @I64OFF(3,6,2,4,1,1,1),
+ @R64OFF(3,6,2,4,1,1,2,0),
};

extern const char *names593[];
static const uint32 types593 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags593 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype593_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_1 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_3 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_4 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_5 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_8 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_9 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_10 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_11 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_12 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_16 [] = {810,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_17 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_18 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_19 [] = {825,0xFFFF};
static const EIF_TYPE_INDEX g_atype593_20 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes593 [] = {
g_atype593_0,
g_atype593_1,
g_atype593_2,
g_atype593_3,
g_atype593_4,
g_atype593_5,
g_atype593_6,
g_atype593_7,
g_atype593_8,
g_atype593_9,
g_atype593_10,
g_atype593_11,
g_atype593_12,
g_atype593_13,
g_atype593_14,
g_atype593_15,
g_atype593_16,
g_atype593_17,
g_atype593_18,
g_atype593_19,
g_atype593_20,
};

static const long offsets593 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @I16OFF(4,6,0),
+ @I16OFF(4,6,1),
+ @LNGOFF(4,6,2,0),
+ @LNGOFF(4,6,2,1),
+ @LNGOFF(4,6,2,2),
+ @LNGOFF(4,6,2,3),
+ @R32OFF(4,6,2,4,0),
+ @PTROFF(4,6,2,4,1,0),
+ @I64OFF(4,6,2,4,1,1,0),
+ @I64OFF(4,6,2,4,1,1,1),
+ @R64OFF(4,6,2,4,1,1,2,0),
};

extern const char *names594[];
static const uint32 types594 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags594 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype594_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_1 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_3 [] = {0xFF01,869,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_4 [] = {7,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_5 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_6 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_9 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_10 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_11 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_12 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_13 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_14 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_17 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_18 [] = {810,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_19 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_20 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_21 [] = {825,0xFFFF};
static const EIF_TYPE_INDEX g_atype594_22 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes594 [] = {
g_atype594_0,
g_atype594_1,
g_atype594_2,
g_atype594_3,
g_atype594_4,
g_atype594_5,
g_atype594_6,
g_atype594_7,
g_atype594_8,
g_atype594_9,
g_atype594_10,
g_atype594_11,
g_atype594_12,
g_atype594_13,
g_atype594_14,
g_atype594_15,
g_atype594_16,
g_atype594_17,
g_atype594_18,
g_atype594_19,
g_atype594_20,
g_atype594_21,
g_atype594_22,
};

static const long offsets594 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names619[];
static const uint32 types619 [] =
{
SK_BOOL,
};

static const uint16 attr_flags619 [] =
{0,};

static const EIF_TYPE_INDEX g_atype619_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes619 [] = {
g_atype619_0,
};

static const long offsets619 [] =
{
+ @CHROFF(0,0),
};

extern const char *names620[];
static const uint32 types620 [] =
{
SK_BOOL,
};

static const uint16 attr_flags620 [] =
{0,};

static const EIF_TYPE_INDEX g_atype620_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes620 [] = {
g_atype620_0,
};

static const long offsets620 [] =
{
+ @CHROFF(0,0),
};

extern const char *names621[];
static const uint32 types621 [] =
{
SK_BOOL,
};

static const uint16 attr_flags621 [] =
{0,};

static const EIF_TYPE_INDEX g_atype621_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes621 [] = {
g_atype621_0,
};

static const long offsets621 [] =
{
+ @CHROFF(0,0),
};

extern const char *names622[];
static const uint32 types622 [] =
{
SK_BOOL,
};

static const uint16 attr_flags622 [] =
{0,};

static const EIF_TYPE_INDEX g_atype622_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes622 [] = {
g_atype622_0,
};

static const long offsets622 [] =
{
+ @CHROFF(0,0),
};

extern const char *names623[];
static const uint32 types623 [] =
{
SK_BOOL,
};

static const uint16 attr_flags623 [] =
{0,};

static const EIF_TYPE_INDEX g_atype623_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes623 [] = {
g_atype623_0,
};

static const long offsets623 [] =
{
+ @CHROFF(0,0),
};

extern const char *names624[];
static const uint32 types624 [] =
{
SK_BOOL,
};

static const uint16 attr_flags624 [] =
{0,};

static const EIF_TYPE_INDEX g_atype624_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes624 [] = {
g_atype624_0,
};

static const long offsets624 [] =
{
+ @CHROFF(0,0),
};

extern const char *names625[];
static const uint32 types625 [] =
{
SK_BOOL,
};

static const uint16 attr_flags625 [] =
{0,};

static const EIF_TYPE_INDEX g_atype625_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes625 [] = {
g_atype625_0,
};

static const long offsets625 [] =
{
+ @CHROFF(0,0),
};

extern const char *names626[];
static const uint32 types626 [] =
{
SK_BOOL,
};

static const uint16 attr_flags626 [] =
{0,};

static const EIF_TYPE_INDEX g_atype626_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes626 [] = {
g_atype626_0,
};

static const long offsets626 [] =
{
+ @CHROFF(0,0),
};

extern const char *names627[];
static const uint32 types627 [] =
{
SK_BOOL,
};

static const uint16 attr_flags627 [] =
{0,};

static const EIF_TYPE_INDEX g_atype627_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes627 [] = {
g_atype627_0,
};

static const long offsets627 [] =
{
+ @CHROFF(0,0),
};

extern const char *names628[];
static const uint32 types628 [] =
{
SK_BOOL,
};

static const uint16 attr_flags628 [] =
{0,};

static const EIF_TYPE_INDEX g_atype628_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes628 [] = {
g_atype628_0,
};

static const long offsets628 [] =
{
+ @CHROFF(0,0),
};

extern const char *names629[];
static const uint32 types629 [] =
{
SK_BOOL,
};

static const uint16 attr_flags629 [] =
{0,};

static const EIF_TYPE_INDEX g_atype629_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes629 [] = {
g_atype629_0,
};

static const long offsets629 [] =
{
+ @CHROFF(0,0),
};

extern const char *names630[];
static const uint32 types630 [] =
{
SK_BOOL,
};

static const uint16 attr_flags630 [] =
{0,};

static const EIF_TYPE_INDEX g_atype630_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes630 [] = {
g_atype630_0,
};

static const long offsets630 [] =
{
+ @CHROFF(0,0),
};

extern const char *names631[];
static const uint32 types631 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags631 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype631_0 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype631_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype631_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes631 [] = {
g_atype631_0,
g_atype631_1,
g_atype631_2,
};

static const long offsets631 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
};

extern const char *names632[];
static const uint32 types632 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags632 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype632_0 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype632_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype632_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype632_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes632 [] = {
g_atype632_0,
g_atype632_1,
g_atype632_2,
g_atype632_3,
};

static const long offsets632 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names633[];
static const uint32 types633 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags633 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype633_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype633_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype633_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype633_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes633 [] = {
g_atype633_0,
g_atype633_1,
g_atype633_2,
g_atype633_3,
};

static const long offsets633 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names634[];
static const uint32 types634 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags634 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype634_0 [] = {0xFF01,608,798,0xFFFF};
static const EIF_TYPE_INDEX g_atype634_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype634_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype634_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes634 [] = {
g_atype634_0,
g_atype634_1,
g_atype634_2,
g_atype634_3,
};

static const long offsets634 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names635[];
static const uint32 types635 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags635 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype635_0 [] = {0xFF01,609,804,0xFFFF};
static const EIF_TYPE_INDEX g_atype635_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype635_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype635_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes635 [] = {
g_atype635_0,
g_atype635_1,
g_atype635_2,
g_atype635_3,
};

static const long offsets635 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names636[];
static const uint32 types636 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags636 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype636_0 [] = {0xFF01,610,807,0xFFFF};
static const EIF_TYPE_INDEX g_atype636_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype636_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype636_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes636 [] = {
g_atype636_0,
g_atype636_1,
g_atype636_2,
g_atype636_3,
};

static const long offsets636 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names637[];
static const uint32 types637 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags637 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype637_0 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype637_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype637_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype637_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes637 [] = {
g_atype637_0,
g_atype637_1,
g_atype637_2,
g_atype637_3,
};

static const long offsets637 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names638[];
static const uint32 types638 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags638 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype638_0 [] = {0xFF01,612,801,0xFFFF};
static const EIF_TYPE_INDEX g_atype638_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype638_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype638_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes638 [] = {
g_atype638_0,
g_atype638_1,
g_atype638_2,
g_atype638_3,
};

static const long offsets638 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names639[];
static const uint32 types639 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags639 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype639_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype639_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype639_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype639_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes639 [] = {
g_atype639_0,
g_atype639_1,
g_atype639_2,
g_atype639_3,
};

static const long offsets639 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names640[];
static const uint32 types640 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags640 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype640_0 [] = {0xFF01,614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype640_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype640_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype640_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes640 [] = {
g_atype640_0,
g_atype640_1,
g_atype640_2,
g_atype640_3,
};

static const long offsets640 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names641[];
static const uint32 types641 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags641 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype641_0 [] = {0xFF01,615,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype641_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype641_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype641_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes641 [] = {
g_atype641_0,
g_atype641_1,
g_atype641_2,
g_atype641_3,
};

static const long offsets641 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names642[];
static const uint32 types642 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags642 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype642_0 [] = {0xFF01,616,810,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes642 [] = {
g_atype642_0,
g_atype642_1,
g_atype642_2,
g_atype642_3,
};

static const long offsets642 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names643[];
static const uint32 types643 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags643 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype643_0 [] = {0xFF01,617,813,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes643 [] = {
g_atype643_0,
g_atype643_1,
g_atype643_2,
g_atype643_3,
};

static const long offsets643 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names644[];
static const uint32 types644 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags644 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype644_0 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes644 [] = {
g_atype644_0,
g_atype644_1,
g_atype644_2,
g_atype644_3,
};

static const long offsets644 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names645[];
static const uint32 types645 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags645 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype645_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype645_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype645_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype645_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes645 [] = {
g_atype645_0,
g_atype645_1,
g_atype645_2,
g_atype645_3,
};

static const long offsets645 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names646[];
static const uint32 types646 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags646 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype646_0 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype646_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype646_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype646_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes646 [] = {
g_atype646_0,
g_atype646_1,
g_atype646_2,
g_atype646_3,
};

static const long offsets646 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names647[];
static const uint32 types647 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags647 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype647_0 [] = {0xFF01,612,801,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes647 [] = {
g_atype647_0,
g_atype647_1,
g_atype647_2,
g_atype647_3,
};

static const long offsets647 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names648[];
static const uint32 types648 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags648 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype648_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes648 [] = {
g_atype648_0,
g_atype648_1,
g_atype648_2,
g_atype648_3,
};

static const long offsets648 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names649[];
static const uint32 types649 [] =
{
SK_BOOL,
};

static const uint16 attr_flags649 [] =
{0,};

static const EIF_TYPE_INDEX g_atype649_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes649 [] = {
g_atype649_0,
};

static const long offsets649 [] =
{
+ @CHROFF(0,0),
};

extern const char *names650[];
static const uint32 types650 [] =
{
SK_BOOL,
};

static const uint16 attr_flags650 [] =
{0,};

static const EIF_TYPE_INDEX g_atype650_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes650 [] = {
g_atype650_0,
};

static const long offsets650 [] =
{
+ @CHROFF(0,0),
};

extern const char *names651[];
static const uint32 types651 [] =
{
SK_BOOL,
};

static const uint16 attr_flags651 [] =
{0,};

static const EIF_TYPE_INDEX g_atype651_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes651 [] = {
g_atype651_0,
};

static const long offsets651 [] =
{
+ @CHROFF(0,0),
};

extern const char *names652[];
static const uint32 types652 [] =
{
SK_BOOL,
};

static const uint16 attr_flags652 [] =
{0,};

static const EIF_TYPE_INDEX g_atype652_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes652 [] = {
g_atype652_0,
};

static const long offsets652 [] =
{
+ @CHROFF(0,0),
};

extern const char *names653[];
static const uint32 types653 [] =
{
SK_BOOL,
};

static const uint16 attr_flags653 [] =
{0,};

static const EIF_TYPE_INDEX g_atype653_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes653 [] = {
g_atype653_0,
};

static const long offsets653 [] =
{
+ @CHROFF(0,0),
};

extern const char *names654[];
static const uint32 types654 [] =
{
SK_BOOL,
};

static const uint16 attr_flags654 [] =
{0,};

static const EIF_TYPE_INDEX g_atype654_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes654 [] = {
g_atype654_0,
};

static const long offsets654 [] =
{
+ @CHROFF(0,0),
};

extern const char *names655[];
static const uint32 types655 [] =
{
SK_BOOL,
};

static const uint16 attr_flags655 [] =
{0,};

static const EIF_TYPE_INDEX g_atype655_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes655 [] = {
g_atype655_0,
};

static const long offsets655 [] =
{
+ @CHROFF(0,0),
};

extern const char *names656[];
static const uint32 types656 [] =
{
SK_BOOL,
};

static const uint16 attr_flags656 [] =
{0,};

static const EIF_TYPE_INDEX g_atype656_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes656 [] = {
g_atype656_0,
};

static const long offsets656 [] =
{
+ @CHROFF(0,0),
};

extern const char *names657[];
static const uint32 types657 [] =
{
SK_BOOL,
};

static const uint16 attr_flags657 [] =
{0,};

static const EIF_TYPE_INDEX g_atype657_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes657 [] = {
g_atype657_0,
};

static const long offsets657 [] =
{
+ @CHROFF(0,0),
};

extern const char *names658[];
static const uint32 types658 [] =
{
SK_BOOL,
};

static const uint16 attr_flags658 [] =
{0,};

static const EIF_TYPE_INDEX g_atype658_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes658 [] = {
g_atype658_0,
};

static const long offsets658 [] =
{
+ @CHROFF(0,0),
};

extern const char *names659[];
static const uint32 types659 [] =
{
SK_BOOL,
};

static const uint16 attr_flags659 [] =
{0,};

static const EIF_TYPE_INDEX g_atype659_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes659 [] = {
g_atype659_0,
};

static const long offsets659 [] =
{
+ @CHROFF(0,0),
};

extern const char *names660[];
static const uint32 types660 [] =
{
SK_BOOL,
};

static const uint16 attr_flags660 [] =
{0,};

static const EIF_TYPE_INDEX g_atype660_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes660 [] = {
g_atype660_0,
};

static const long offsets660 [] =
{
+ @CHROFF(0,0),
};

extern const char *names661[];
static const uint32 types661 [] =
{
SK_BOOL,
};

static const uint16 attr_flags661 [] =
{0,};

static const EIF_TYPE_INDEX g_atype661_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes661 [] = {
g_atype661_0,
};

static const long offsets661 [] =
{
+ @CHROFF(0,0),
};

extern const char *names662[];
static const uint32 types662 [] =
{
SK_BOOL,
};

static const uint16 attr_flags662 [] =
{0,};

static const EIF_TYPE_INDEX g_atype662_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes662 [] = {
g_atype662_0,
};

static const long offsets662 [] =
{
+ @CHROFF(0,0),
};

extern const char *names663[];
static const uint32 types663 [] =
{
SK_BOOL,
};

static const uint16 attr_flags663 [] =
{0,};

static const EIF_TYPE_INDEX g_atype663_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes663 [] = {
g_atype663_0,
};

static const long offsets663 [] =
{
+ @CHROFF(0,0),
};

extern const char *names664[];
static const uint32 types664 [] =
{
SK_BOOL,
};

static const uint16 attr_flags664 [] =
{0,};

static const EIF_TYPE_INDEX g_atype664_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes664 [] = {
g_atype664_0,
};

static const long offsets664 [] =
{
+ @CHROFF(0,0),
};

extern const char *names665[];
static const uint32 types665 [] =
{
SK_BOOL,
};

static const uint16 attr_flags665 [] =
{0,};

static const EIF_TYPE_INDEX g_atype665_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes665 [] = {
g_atype665_0,
};

static const long offsets665 [] =
{
+ @CHROFF(0,0),
};

extern const char *names666[];
static const uint32 types666 [] =
{
SK_BOOL,
};

static const uint16 attr_flags666 [] =
{0,};

static const EIF_TYPE_INDEX g_atype666_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes666 [] = {
g_atype666_0,
};

static const long offsets666 [] =
{
+ @CHROFF(0,0),
};

extern const char *names667[];
static const uint32 types667 [] =
{
SK_BOOL,
};

static const uint16 attr_flags667 [] =
{0,};

static const EIF_TYPE_INDEX g_atype667_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes667 [] = {
g_atype667_0,
};

static const long offsets667 [] =
{
+ @CHROFF(0,0),
};

extern const char *names668[];
static const uint32 types668 [] =
{
SK_BOOL,
};

static const uint16 attr_flags668 [] =
{0,};

static const EIF_TYPE_INDEX g_atype668_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes668 [] = {
g_atype668_0,
};

static const long offsets668 [] =
{
+ @CHROFF(0,0),
};

extern const char *names669[];
static const uint32 types669 [] =
{
SK_BOOL,
};

static const uint16 attr_flags669 [] =
{0,};

static const EIF_TYPE_INDEX g_atype669_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes669 [] = {
g_atype669_0,
};

static const long offsets669 [] =
{
+ @CHROFF(0,0),
};

extern const char *names670[];
static const uint32 types670 [] =
{
SK_BOOL,
};

static const uint16 attr_flags670 [] =
{0,};

static const EIF_TYPE_INDEX g_atype670_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes670 [] = {
g_atype670_0,
};

static const long offsets670 [] =
{
+ @CHROFF(0,0),
};

extern const char *names671[];
static const uint32 types671 [] =
{
SK_BOOL,
};

static const uint16 attr_flags671 [] =
{0,};

static const EIF_TYPE_INDEX g_atype671_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes671 [] = {
g_atype671_0,
};

static const long offsets671 [] =
{
+ @CHROFF(0,0),
};

extern const char *names672[];
static const uint32 types672 [] =
{
SK_BOOL,
};

static const uint16 attr_flags672 [] =
{0,};

static const EIF_TYPE_INDEX g_atype672_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes672 [] = {
g_atype672_0,
};

static const long offsets672 [] =
{
+ @CHROFF(0,0),
};

extern const char *names673[];
static const uint32 types673 [] =
{
SK_BOOL,
};

static const uint16 attr_flags673 [] =
{0,};

static const EIF_TYPE_INDEX g_atype673_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes673 [] = {
g_atype673_0,
};

static const long offsets673 [] =
{
+ @CHROFF(0,0),
};

extern const char *names674[];
static const uint32 types674 [] =
{
SK_BOOL,
};

static const uint16 attr_flags674 [] =
{0,};

static const EIF_TYPE_INDEX g_atype674_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes674 [] = {
g_atype674_0,
};

static const long offsets674 [] =
{
+ @CHROFF(0,0),
};

extern const char *names675[];
static const uint32 types675 [] =
{
SK_BOOL,
};

static const uint16 attr_flags675 [] =
{0,};

static const EIF_TYPE_INDEX g_atype675_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes675 [] = {
g_atype675_0,
};

static const long offsets675 [] =
{
+ @CHROFF(0,0),
};

extern const char *names676[];
static const uint32 types676 [] =
{
SK_BOOL,
};

static const uint16 attr_flags676 [] =
{0,};

static const EIF_TYPE_INDEX g_atype676_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes676 [] = {
g_atype676_0,
};

static const long offsets676 [] =
{
+ @CHROFF(0,0),
};

extern const char *names677[];
static const uint32 types677 [] =
{
SK_BOOL,
};

static const uint16 attr_flags677 [] =
{0,};

static const EIF_TYPE_INDEX g_atype677_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes677 [] = {
g_atype677_0,
};

static const long offsets677 [] =
{
+ @CHROFF(0,0),
};

extern const char *names678[];
static const uint32 types678 [] =
{
SK_BOOL,
};

static const uint16 attr_flags678 [] =
{0,};

static const EIF_TYPE_INDEX g_atype678_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes678 [] = {
g_atype678_0,
};

static const long offsets678 [] =
{
+ @CHROFF(0,0),
};

extern const char *names679[];
static const uint32 types679 [] =
{
SK_BOOL,
};

static const uint16 attr_flags679 [] =
{0,};

static const EIF_TYPE_INDEX g_atype679_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes679 [] = {
g_atype679_0,
};

static const long offsets679 [] =
{
+ @CHROFF(0,0),
};

extern const char *names680[];
static const uint32 types680 [] =
{
SK_BOOL,
};

static const uint16 attr_flags680 [] =
{0,};

static const EIF_TYPE_INDEX g_atype680_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes680 [] = {
g_atype680_0,
};

static const long offsets680 [] =
{
+ @CHROFF(0,0),
};

extern const char *names681[];
static const uint32 types681 [] =
{
SK_BOOL,
};

static const uint16 attr_flags681 [] =
{0,};

static const EIF_TYPE_INDEX g_atype681_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes681 [] = {
g_atype681_0,
};

static const long offsets681 [] =
{
+ @CHROFF(0,0),
};

extern const char *names682[];
static const uint32 types682 [] =
{
SK_BOOL,
};

static const uint16 attr_flags682 [] =
{0,};

static const EIF_TYPE_INDEX g_atype682_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes682 [] = {
g_atype682_0,
};

static const long offsets682 [] =
{
+ @CHROFF(0,0),
};

extern const char *names683[];
static const uint32 types683 [] =
{
SK_BOOL,
};

static const uint16 attr_flags683 [] =
{0,};

static const EIF_TYPE_INDEX g_atype683_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes683 [] = {
g_atype683_0,
};

static const long offsets683 [] =
{
+ @CHROFF(0,0),
};

extern const char *names684[];
static const uint32 types684 [] =
{
SK_BOOL,
};

static const uint16 attr_flags684 [] =
{0,};

static const EIF_TYPE_INDEX g_atype684_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes684 [] = {
g_atype684_0,
};

static const long offsets684 [] =
{
+ @CHROFF(0,0),
};

extern const char *names685[];
static const uint32 types685 [] =
{
SK_BOOL,
};

static const uint16 attr_flags685 [] =
{0,};

static const EIF_TYPE_INDEX g_atype685_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes685 [] = {
g_atype685_0,
};

static const long offsets685 [] =
{
+ @CHROFF(0,0),
};

extern const char *names686[];
static const uint32 types686 [] =
{
SK_BOOL,
};

static const uint16 attr_flags686 [] =
{0,};

static const EIF_TYPE_INDEX g_atype686_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes686 [] = {
g_atype686_0,
};

static const long offsets686 [] =
{
+ @CHROFF(0,0),
};

extern const char *names687[];
static const uint32 types687 [] =
{
SK_BOOL,
};

static const uint16 attr_flags687 [] =
{0,};

static const EIF_TYPE_INDEX g_atype687_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes687 [] = {
g_atype687_0,
};

static const long offsets687 [] =
{
+ @CHROFF(0,0),
};

extern const char *names688[];
static const uint32 types688 [] =
{
SK_BOOL,
};

static const uint16 attr_flags688 [] =
{0,};

static const EIF_TYPE_INDEX g_atype688_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes688 [] = {
g_atype688_0,
};

static const long offsets688 [] =
{
+ @CHROFF(0,0),
};

extern const char *names689[];
static const uint32 types689 [] =
{
SK_BOOL,
};

static const uint16 attr_flags689 [] =
{0,};

static const EIF_TYPE_INDEX g_atype689_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes689 [] = {
g_atype689_0,
};

static const long offsets689 [] =
{
+ @CHROFF(0,0),
};

extern const char *names690[];
static const uint32 types690 [] =
{
SK_BOOL,
};

static const uint16 attr_flags690 [] =
{0,};

static const EIF_TYPE_INDEX g_atype690_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes690 [] = {
g_atype690_0,
};

static const long offsets690 [] =
{
+ @CHROFF(0,0),
};

extern const char *names691[];
static const uint32 types691 [] =
{
SK_BOOL,
};

static const uint16 attr_flags691 [] =
{0,};

static const EIF_TYPE_INDEX g_atype691_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes691 [] = {
g_atype691_0,
};

static const long offsets691 [] =
{
+ @CHROFF(0,0),
};

extern const char *names692[];
static const uint32 types692 [] =
{
SK_BOOL,
};

static const uint16 attr_flags692 [] =
{0,};

static const EIF_TYPE_INDEX g_atype692_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes692 [] = {
g_atype692_0,
};

static const long offsets692 [] =
{
+ @CHROFF(0,0),
};

extern const char *names693[];
static const uint32 types693 [] =
{
SK_BOOL,
};

static const uint16 attr_flags693 [] =
{0,};

static const EIF_TYPE_INDEX g_atype693_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes693 [] = {
g_atype693_0,
};

static const long offsets693 [] =
{
+ @CHROFF(0,0),
};

extern const char *names694[];
static const uint32 types694 [] =
{
SK_BOOL,
};

static const uint16 attr_flags694 [] =
{0,};

static const EIF_TYPE_INDEX g_atype694_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes694 [] = {
g_atype694_0,
};

static const long offsets694 [] =
{
+ @CHROFF(0,0),
};

extern const char *names695[];
static const uint32 types695 [] =
{
SK_BOOL,
};

static const uint16 attr_flags695 [] =
{0,};

static const EIF_TYPE_INDEX g_atype695_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes695 [] = {
g_atype695_0,
};

static const long offsets695 [] =
{
+ @CHROFF(0,0),
};

extern const char *names696[];
static const uint32 types696 [] =
{
SK_BOOL,
};

static const uint16 attr_flags696 [] =
{0,};

static const EIF_TYPE_INDEX g_atype696_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes696 [] = {
g_atype696_0,
};

static const long offsets696 [] =
{
+ @CHROFF(0,0),
};

extern const char *names697[];
static const uint32 types697 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags697 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype697_0 [] = {76,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype697_1 [] = {76,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype697_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype697_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype697_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype697_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes697 [] = {
g_atype697_0,
g_atype697_1,
g_atype697_2,
g_atype697_3,
g_atype697_4,
g_atype697_5,
};

static const long offsets697 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names698[];
static const uint32 types698 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags698 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype698_0 [] = {77,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_1 [] = {77,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_2 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes698 [] = {
g_atype698_0,
g_atype698_1,
g_atype698_2,
g_atype698_3,
g_atype698_4,
g_atype698_5,
};

static const long offsets698 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names701[];
static const uint32 types701 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags701 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype701_0 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype701_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype701_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype701_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes701 [] = {
g_atype701_0,
g_atype701_1,
g_atype701_2,
g_atype701_3,
};

static const long offsets701 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names702[];
static const uint32 types702 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags702 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype702_0 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype702_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype702_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes702 [] = {
g_atype702_0,
g_atype702_1,
g_atype702_2,
};

static const long offsets702 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names703[];
static const uint32 types703 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags703 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype703_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes703 [] = {
g_atype703_0,
g_atype703_1,
g_atype703_2,
};

static const long offsets703 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names704[];
static const uint32 types704 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags704 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype704_0 [] = {0xFF01,608,798,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes704 [] = {
g_atype704_0,
g_atype704_1,
g_atype704_2,
};

static const long offsets704 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names705[];
static const uint32 types705 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags705 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype705_0 [] = {0xFF01,609,804,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes705 [] = {
g_atype705_0,
g_atype705_1,
g_atype705_2,
};

static const long offsets705 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names706[];
static const uint32 types706 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags706 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype706_0 [] = {0xFF01,610,807,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes706 [] = {
g_atype706_0,
g_atype706_1,
g_atype706_2,
};

static const long offsets706 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names707[];
static const uint32 types707 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags707 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype707_0 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes707 [] = {
g_atype707_0,
g_atype707_1,
g_atype707_2,
};

static const long offsets707 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names708[];
static const uint32 types708 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags708 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype708_0 [] = {0xFF01,612,801,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes708 [] = {
g_atype708_0,
g_atype708_1,
g_atype708_2,
};

static const long offsets708 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names709[];
static const uint32 types709 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags709 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype709_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes709 [] = {
g_atype709_0,
g_atype709_1,
g_atype709_2,
};

static const long offsets709 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names710[];
static const uint32 types710 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags710 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype710_0 [] = {0xFF01,614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes710 [] = {
g_atype710_0,
g_atype710_1,
g_atype710_2,
};

static const long offsets710 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names711[];
static const uint32 types711 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags711 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype711_0 [] = {0xFF01,615,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes711 [] = {
g_atype711_0,
g_atype711_1,
g_atype711_2,
};

static const long offsets711 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names712[];
static const uint32 types712 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags712 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype712_0 [] = {0xFF01,616,810,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes712 [] = {
g_atype712_0,
g_atype712_1,
g_atype712_2,
};

static const long offsets712 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names713[];
static const uint32 types713 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags713 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype713_0 [] = {0xFF01,617,813,0xFFFF};
static const EIF_TYPE_INDEX g_atype713_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype713_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes713 [] = {
g_atype713_0,
g_atype713_1,
g_atype713_2,
};

static const long offsets713 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names714[];
static const uint32 types714 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags714 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype714_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_1 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_2 [] = {0xFF01,606,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_3 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_4 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_6 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_9 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_16 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes714 [] = {
g_atype714_0,
g_atype714_1,
g_atype714_2,
g_atype714_3,
g_atype714_4,
g_atype714_5,
g_atype714_6,
g_atype714_7,
g_atype714_8,
g_atype714_9,
g_atype714_10,
g_atype714_11,
g_atype714_12,
g_atype714_13,
g_atype714_14,
g_atype714_15,
g_atype714_16,
};

static const long offsets714 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
+ @LNGOFF(7,3,0,1),
+ @LNGOFF(7,3,0,2),
+ @LNGOFF(7,3,0,3),
+ @LNGOFF(7,3,0,4),
+ @LNGOFF(7,3,0,5),
+ @LNGOFF(7,3,0,6),
};

extern const char *names715[];
static const uint32 types715 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags715 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype715_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_1 [] = {0xFF01,606,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_2 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_3 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_16 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes715 [] = {
g_atype715_0,
g_atype715_1,
g_atype715_2,
g_atype715_3,
g_atype715_4,
g_atype715_5,
g_atype715_6,
g_atype715_7,
g_atype715_8,
g_atype715_9,
g_atype715_10,
g_atype715_11,
g_atype715_12,
g_atype715_13,
g_atype715_14,
g_atype715_15,
g_atype715_16,
};

static const long offsets715 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names716[];
static const uint32 types716 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags716 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype716_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_1 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_2 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_3 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_4 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_16 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes716 [] = {
g_atype716_0,
g_atype716_1,
g_atype716_2,
g_atype716_3,
g_atype716_4,
g_atype716_5,
g_atype716_6,
g_atype716_7,
g_atype716_8,
g_atype716_9,
g_atype716_10,
g_atype716_11,
g_atype716_12,
g_atype716_13,
g_atype716_14,
g_atype716_15,
g_atype716_16,
};

static const long offsets716 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
+ @LNGOFF(6,3,0,5),
+ @LNGOFF(6,3,0,6),
+ @LNGOFF(6,3,0,7),
};

extern const char *names717[];
static const uint32 types717 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags717 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype717_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_1 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_2 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_3 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_16 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes717 [] = {
g_atype717_0,
g_atype717_1,
g_atype717_2,
g_atype717_3,
g_atype717_4,
g_atype717_5,
g_atype717_6,
g_atype717_7,
g_atype717_8,
g_atype717_9,
g_atype717_10,
g_atype717_11,
g_atype717_12,
g_atype717_13,
g_atype717_14,
g_atype717_15,
g_atype717_16,
};

static const long offsets717 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @LNGOFF(4,3,0,3),
+ @LNGOFF(4,3,0,4),
+ @LNGOFF(4,3,0,5),
+ @LNGOFF(4,3,0,6),
+ @LNGOFF(4,3,0,7),
+ @LNGOFF(4,3,0,8),
+ @LNGOFF(4,3,0,9),
};

extern const char *names718[];
static const uint32 types718 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags718 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype718_0 [] = {0xFF01,615,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_1 [] = {0xFF01,606,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_2 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_3 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_15 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_16 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes718 [] = {
g_atype718_0,
g_atype718_1,
g_atype718_2,
g_atype718_3,
g_atype718_4,
g_atype718_5,
g_atype718_6,
g_atype718_7,
g_atype718_8,
g_atype718_9,
g_atype718_10,
g_atype718_11,
g_atype718_12,
g_atype718_13,
g_atype718_14,
g_atype718_15,
g_atype718_16,
};

static const long offsets718 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @PTROFF(5,3,0,7,0,0),
+ @PTROFF(5,3,0,7,0,1),
};

extern const char *names719[];
static const uint32 types719 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags719 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype719_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_1 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_2 [] = {0xFF01,606,0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_3 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_4 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_6 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_9 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_10 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_17 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes719 [] = {
g_atype719_0,
g_atype719_1,
g_atype719_2,
g_atype719_3,
g_atype719_4,
g_atype719_5,
g_atype719_6,
g_atype719_7,
g_atype719_8,
g_atype719_9,
g_atype719_10,
g_atype719_11,
g_atype719_12,
g_atype719_13,
g_atype719_14,
g_atype719_15,
g_atype719_16,
g_atype719_17,
};

static const long offsets719 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @LNGOFF(7,4,0,0),
+ @LNGOFF(7,4,0,1),
+ @LNGOFF(7,4,0,2),
+ @LNGOFF(7,4,0,3),
+ @LNGOFF(7,4,0,4),
+ @LNGOFF(7,4,0,5),
+ @LNGOFF(7,4,0,6),
};

extern const char *names720[];
static const uint32 types720 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags720 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype720_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_1 [] = {0xFF01,606,0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_2 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_3 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_4 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_17 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes720 [] = {
g_atype720_0,
g_atype720_1,
g_atype720_2,
g_atype720_3,
g_atype720_4,
g_atype720_5,
g_atype720_6,
g_atype720_7,
g_atype720_8,
g_atype720_9,
g_atype720_10,
g_atype720_11,
g_atype720_12,
g_atype720_13,
g_atype720_14,
g_atype720_15,
g_atype720_16,
g_atype720_17,
};

static const long offsets720 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names721[];
static const uint32 types721 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags721 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype721_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_1 [] = {0xFF01,606,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_2 [] = {0xFF01,606,0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_3 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_4 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_5 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_6 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_7 [] = {871,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_8 [] = {871,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_9 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_10 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_11 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_17 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_18 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes721 [] = {
g_atype721_0,
g_atype721_1,
g_atype721_2,
g_atype721_3,
g_atype721_4,
g_atype721_5,
g_atype721_6,
g_atype721_7,
g_atype721_8,
g_atype721_9,
g_atype721_10,
g_atype721_11,
g_atype721_12,
g_atype721_13,
g_atype721_14,
g_atype721_15,
g_atype721_16,
g_atype721_17,
g_atype721_18,
};

static const long offsets721 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @LNGOFF(9,3,0,0),
+ @LNGOFF(9,3,0,1),
+ @LNGOFF(9,3,0,2),
+ @LNGOFF(9,3,0,3),
+ @LNGOFF(9,3,0,4),
+ @LNGOFF(9,3,0,5),
+ @LNGOFF(9,3,0,6),
};

extern const char *names731[];
static const uint32 types731 [] =
{
SK_REF,
};

static const uint16 attr_flags731 [] =
{0,};

static const EIF_TYPE_INDEX g_atype731_0 [] = {0xFF01,872,0xFFFF};

static const EIF_TYPE_INDEX *gtypes731 [] = {
g_atype731_0,
};

static const long offsets731 [] =
{
0,
};

extern const char *names748[];
static const uint32 types748 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags748 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype748_0 [] = {55,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_1 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_2 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_3 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes748 [] = {
g_atype748_0,
g_atype748_1,
g_atype748_2,
g_atype748_3,
};

static const long offsets748 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
};

extern const char *names749[];
static const uint32 types749 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags749 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype749_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_1 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_2 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_3 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes749 [] = {
g_atype749_0,
g_atype749_1,
g_atype749_2,
g_atype749_3,
g_atype749_4,
};

static const long offsets749 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names754[];
static const uint32 types754 [] =
{
SK_INT32,
};

static const uint16 attr_flags754 [] =
{0,};

static const EIF_TYPE_INDEX g_atype754_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes754 [] = {
g_atype754_0,
};

static const long offsets754 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names755[];
static const uint32 types755 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags755 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype755_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_1 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_2 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes755 [] = {
g_atype755_0,
g_atype755_1,
g_atype755_2,
};

static const long offsets755 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names756[];
static const uint32 types756 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags756 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype756_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype756_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes756 [] = {
g_atype756_0,
g_atype756_1,
};

static const long offsets756 [] =
{
0,
 + @REFACS(1),
};

extern const char *names757[];
static const uint32 types757 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags757 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype757_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype757_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes757 [] = {
g_atype757_0,
g_atype757_1,
};

static const long offsets757 [] =
{
0,
 + @REFACS(1),
};

extern const char *names758[];
static const uint32 types758 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags758 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype758_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype758_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes758 [] = {
g_atype758_0,
g_atype758_1,
};

static const long offsets758 [] =
{
0,
 + @REFACS(1),
};

extern const char *names759[];
static const uint32 types759 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags759 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype759_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype759_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes759 [] = {
g_atype759_0,
g_atype759_1,
};

static const long offsets759 [] =
{
0,
 + @REFACS(1),
};

extern const char *names760[];
static const uint32 types760 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags760 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype760_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype760_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes760 [] = {
g_atype760_0,
g_atype760_1,
};

static const long offsets760 [] =
{
0,
 + @REFACS(1),
};

extern const char *names761[];
static const uint32 types761 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags761 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype761_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes761 [] = {
g_atype761_0,
g_atype761_1,
};

static const long offsets761 [] =
{
0,
 + @REFACS(1),
};

extern const char *names762[];
static const uint32 types762 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags762 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype762_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes762 [] = {
g_atype762_0,
g_atype762_1,
};

static const long offsets762 [] =
{
0,
 + @REFACS(1),
};

extern const char *names763[];
static const uint32 types763 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags763 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype763_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes763 [] = {
g_atype763_0,
g_atype763_1,
};

static const long offsets763 [] =
{
0,
 + @REFACS(1),
};

extern const char *names764[];
static const uint32 types764 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags764 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype764_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes764 [] = {
g_atype764_0,
g_atype764_1,
};

static const long offsets764 [] =
{
0,
 + @REFACS(1),
};

extern const char *names765[];
static const uint32 types765 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags765 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype765_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes765 [] = {
g_atype765_0,
g_atype765_1,
};

static const long offsets765 [] =
{
0,
 + @REFACS(1),
};

extern const char *names766[];
static const uint32 types766 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags766 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype766_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes766 [] = {
g_atype766_0,
g_atype766_1,
};

static const long offsets766 [] =
{
0,
 + @REFACS(1),
};

extern const char *names767[];
static const uint32 types767 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags767 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype767_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes767 [] = {
g_atype767_0,
g_atype767_1,
};

static const long offsets767 [] =
{
0,
 + @REFACS(1),
};

extern const char *names768[];
static const uint32 types768 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags768 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype768_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes768 [] = {
g_atype768_0,
g_atype768_1,
};

static const long offsets768 [] =
{
0,
 + @REFACS(1),
};

extern const char *names769[];
static const uint32 types769 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags769 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype769_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes769 [] = {
g_atype769_0,
g_atype769_1,
};

static const long offsets769 [] =
{
0,
 + @REFACS(1),
};

extern const char *names770[];
static const uint32 types770 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags770 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype770_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes770 [] = {
g_atype770_0,
g_atype770_1,
};

static const long offsets770 [] =
{
0,
 + @REFACS(1),
};

extern const char *names771[];
static const uint32 types771 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags771 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype771_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes771 [] = {
g_atype771_0,
g_atype771_1,
};

static const long offsets771 [] =
{
0,
 + @REFACS(1),
};

extern const char *names772[];
static const uint32 types772 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags772 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype772_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes772 [] = {
g_atype772_0,
g_atype772_1,
};

static const long offsets772 [] =
{
0,
 + @REFACS(1),
};

extern const char *names773[];
static const uint32 types773 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags773 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype773_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes773 [] = {
g_atype773_0,
g_atype773_1,
};

static const long offsets773 [] =
{
0,
 + @REFACS(1),
};

extern const char *names774[];
static const uint32 types774 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags774 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype774_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes774 [] = {
g_atype774_0,
g_atype774_1,
};

static const long offsets774 [] =
{
0,
 + @REFACS(1),
};

extern const char *names775[];
static const uint32 types775 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags775 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype775_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes775 [] = {
g_atype775_0,
g_atype775_1,
};

static const long offsets775 [] =
{
0,
 + @REFACS(1),
};

extern const char *names776[];
static const uint32 types776 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags776 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype776_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes776 [] = {
g_atype776_0,
g_atype776_1,
};

static const long offsets776 [] =
{
0,
 + @REFACS(1),
};

extern const char *names777[];
static const uint32 types777 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags777 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype777_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes777 [] = {
g_atype777_0,
g_atype777_1,
};

static const long offsets777 [] =
{
0,
 + @REFACS(1),
};

extern const char *names778[];
static const uint32 types778 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags778 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype778_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes778 [] = {
g_atype778_0,
g_atype778_1,
};

static const long offsets778 [] =
{
0,
 + @REFACS(1),
};

extern const char *names779[];
static const uint32 types779 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags779 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype779_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes779 [] = {
g_atype779_0,
g_atype779_1,
};

static const long offsets779 [] =
{
0,
 + @REFACS(1),
};

extern const char *names780[];
static const uint32 types780 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags780 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype780_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes780 [] = {
g_atype780_0,
g_atype780_1,
};

static const long offsets780 [] =
{
0,
 + @REFACS(1),
};

extern const char *names781[];
static const uint32 types781 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags781 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype781_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes781 [] = {
g_atype781_0,
g_atype781_1,
};

static const long offsets781 [] =
{
0,
 + @REFACS(1),
};

extern const char *names782[];
static const uint32 types782 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags782 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype782_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype782_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes782 [] = {
g_atype782_0,
g_atype782_1,
};

static const long offsets782 [] =
{
0,
 + @REFACS(1),
};

extern const char *names783[];
static const uint32 types783 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags783 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype783_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype783_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes783 [] = {
g_atype783_0,
g_atype783_1,
};

static const long offsets783 [] =
{
0,
 + @REFACS(1),
};

extern const char *names784[];
static const uint32 types784 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags784 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype784_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes784 [] = {
g_atype784_0,
g_atype784_1,
};

static const long offsets784 [] =
{
0,
 + @REFACS(1),
};

extern const char *names785[];
static const uint32 types785 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags785 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype785_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes785 [] = {
g_atype785_0,
g_atype785_1,
};

static const long offsets785 [] =
{
0,
 + @REFACS(1),
};

extern const char *names786[];
static const uint32 types786 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags786 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype786_0 [] = {868,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_1 [] = {871,0xFFFF};

static const EIF_TYPE_INDEX *gtypes786 [] = {
g_atype786_0,
g_atype786_1,
};

static const long offsets786 [] =
{
0,
 + @REFACS(1),
};

extern const char *names788[];
static const uint32 types788 [] =
{
SK_INT32,
};

static const uint16 attr_flags788 [] =
{0,};

static const EIF_TYPE_INDEX g_atype788_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes788 [] = {
g_atype788_0,
};

static const long offsets788 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names789[];
static const uint32 types789 [] =
{
SK_INT32,
};

static const uint16 attr_flags789 [] =
{0,};

static const EIF_TYPE_INDEX g_atype789_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes789 [] = {
g_atype789_0,
};

static const long offsets789 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names790[];
static const uint32 types790 [] =
{
SK_INT32,
};

static const uint16 attr_flags790 [] =
{0,};

static const EIF_TYPE_INDEX g_atype790_0 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes790 [] = {
g_atype790_0,
};

static const long offsets790 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names791[];
static const uint32 types791 [] =
{
SK_INT16,
};

static const uint16 attr_flags791 [] =
{0,};

static const EIF_TYPE_INDEX g_atype791_0 [] = {792,0xFFFF};

static const EIF_TYPE_INDEX *gtypes791 [] = {
g_atype791_0,
};

static const long offsets791 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names792[];
static const uint32 types792 [] =
{
SK_INT16,
};

static const uint16 attr_flags792 [] =
{0,};

static const EIF_TYPE_INDEX g_atype792_0 [] = {792,0xFFFF};

static const EIF_TYPE_INDEX *gtypes792 [] = {
g_atype792_0,
};

static const long offsets792 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names793[];
static const uint32 types793 [] =
{
SK_INT16,
};

static const uint16 attr_flags793 [] =
{0,};

static const EIF_TYPE_INDEX g_atype793_0 [] = {792,0xFFFF};

static const EIF_TYPE_INDEX *gtypes793 [] = {
g_atype793_0,
};

static const long offsets793 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names794[];
static const uint32 types794 [] =
{
SK_INT8,
};

static const uint16 attr_flags794 [] =
{0,};

static const EIF_TYPE_INDEX g_atype794_0 [] = {795,0xFFFF};

static const EIF_TYPE_INDEX *gtypes794 [] = {
g_atype794_0,
};

static const long offsets794 [] =
{
+ @CHROFF(0,0),
};

extern const char *names795[];
static const uint32 types795 [] =
{
SK_INT8,
};

static const uint16 attr_flags795 [] =
{0,};

static const EIF_TYPE_INDEX g_atype795_0 [] = {795,0xFFFF};

static const EIF_TYPE_INDEX *gtypes795 [] = {
g_atype795_0,
};

static const long offsets795 [] =
{
+ @CHROFF(0,0),
};

extern const char *names796[];
static const uint32 types796 [] =
{
SK_INT8,
};

static const uint16 attr_flags796 [] =
{0,};

static const EIF_TYPE_INDEX g_atype796_0 [] = {795,0xFFFF};

static const EIF_TYPE_INDEX *gtypes796 [] = {
g_atype796_0,
};

static const long offsets796 [] =
{
+ @CHROFF(0,0),
};

extern const char *names797[];
static const uint32 types797 [] =
{
SK_UINT64,
};

static const uint16 attr_flags797 [] =
{0,};

static const EIF_TYPE_INDEX g_atype797_0 [] = {798,0xFFFF};

static const EIF_TYPE_INDEX *gtypes797 [] = {
g_atype797_0,
};

static const long offsets797 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names798[];
static const uint32 types798 [] =
{
SK_UINT64,
};

static const uint16 attr_flags798 [] =
{0,};

static const EIF_TYPE_INDEX g_atype798_0 [] = {798,0xFFFF};

static const EIF_TYPE_INDEX *gtypes798 [] = {
g_atype798_0,
};

static const long offsets798 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names799[];
static const uint32 types799 [] =
{
SK_UINT64,
};

static const uint16 attr_flags799 [] =
{0,};

static const EIF_TYPE_INDEX g_atype799_0 [] = {798,0xFFFF};

static const EIF_TYPE_INDEX *gtypes799 [] = {
g_atype799_0,
};

static const long offsets799 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names800[];
static const uint32 types800 [] =
{
SK_UINT32,
};

static const uint16 attr_flags800 [] =
{0,};

static const EIF_TYPE_INDEX g_atype800_0 [] = {801,0xFFFF};

static const EIF_TYPE_INDEX *gtypes800 [] = {
g_atype800_0,
};

static const long offsets800 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names801[];
static const uint32 types801 [] =
{
SK_UINT32,
};

static const uint16 attr_flags801 [] =
{0,};

static const EIF_TYPE_INDEX g_atype801_0 [] = {801,0xFFFF};

static const EIF_TYPE_INDEX *gtypes801 [] = {
g_atype801_0,
};

static const long offsets801 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names802[];
static const uint32 types802 [] =
{
SK_UINT32,
};

static const uint16 attr_flags802 [] =
{0,};

static const EIF_TYPE_INDEX g_atype802_0 [] = {801,0xFFFF};

static const EIF_TYPE_INDEX *gtypes802 [] = {
g_atype802_0,
};

static const long offsets802 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names803[];
static const uint32 types803 [] =
{
SK_UINT16,
};

static const uint16 attr_flags803 [] =
{0,};

static const EIF_TYPE_INDEX g_atype803_0 [] = {804,0xFFFF};

static const EIF_TYPE_INDEX *gtypes803 [] = {
g_atype803_0,
};

static const long offsets803 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names804[];
static const uint32 types804 [] =
{
SK_UINT16,
};

static const uint16 attr_flags804 [] =
{0,};

static const EIF_TYPE_INDEX g_atype804_0 [] = {804,0xFFFF};

static const EIF_TYPE_INDEX *gtypes804 [] = {
g_atype804_0,
};

static const long offsets804 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names805[];
static const uint32 types805 [] =
{
SK_UINT16,
};

static const uint16 attr_flags805 [] =
{0,};

static const EIF_TYPE_INDEX g_atype805_0 [] = {804,0xFFFF};

static const EIF_TYPE_INDEX *gtypes805 [] = {
g_atype805_0,
};

static const long offsets805 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names806[];
static const uint32 types806 [] =
{
SK_UINT8,
};

static const uint16 attr_flags806 [] =
{0,};

static const EIF_TYPE_INDEX g_atype806_0 [] = {807,0xFFFF};

static const EIF_TYPE_INDEX *gtypes806 [] = {
g_atype806_0,
};

static const long offsets806 [] =
{
+ @CHROFF(0,0),
};

extern const char *names807[];
static const uint32 types807 [] =
{
SK_UINT8,
};

static const uint16 attr_flags807 [] =
{0,};

static const EIF_TYPE_INDEX g_atype807_0 [] = {807,0xFFFF};

static const EIF_TYPE_INDEX *gtypes807 [] = {
g_atype807_0,
};

static const long offsets807 [] =
{
+ @CHROFF(0,0),
};

extern const char *names808[];
static const uint32 types808 [] =
{
SK_UINT8,
};

static const uint16 attr_flags808 [] =
{0,};

static const EIF_TYPE_INDEX g_atype808_0 [] = {807,0xFFFF};

static const EIF_TYPE_INDEX *gtypes808 [] = {
g_atype808_0,
};

static const long offsets808 [] =
{
+ @CHROFF(0,0),
};

extern const char *names809[];
static const uint32 types809 [] =
{
SK_REAL32,
};

static const uint16 attr_flags809 [] =
{0,};

static const EIF_TYPE_INDEX g_atype809_0 [] = {810,0xFFFF};

static const EIF_TYPE_INDEX *gtypes809 [] = {
g_atype809_0,
};

static const long offsets809 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names810[];
static const uint32 types810 [] =
{
SK_REAL32,
};

static const uint16 attr_flags810 [] =
{0,};

static const EIF_TYPE_INDEX g_atype810_0 [] = {810,0xFFFF};

static const EIF_TYPE_INDEX *gtypes810 [] = {
g_atype810_0,
};

static const long offsets810 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names811[];
static const uint32 types811 [] =
{
SK_REAL32,
};

static const uint16 attr_flags811 [] =
{0,};

static const EIF_TYPE_INDEX g_atype811_0 [] = {810,0xFFFF};

static const EIF_TYPE_INDEX *gtypes811 [] = {
g_atype811_0,
};

static const long offsets811 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names812[];
static const uint32 types812 [] =
{
SK_REAL64,
};

static const uint16 attr_flags812 [] =
{0,};

static const EIF_TYPE_INDEX g_atype812_0 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes812 [] = {
g_atype812_0,
};

static const long offsets812 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names813[];
static const uint32 types813 [] =
{
SK_REAL64,
};

static const uint16 attr_flags813 [] =
{0,};

static const EIF_TYPE_INDEX g_atype813_0 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes813 [] = {
g_atype813_0,
};

static const long offsets813 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names814[];
static const uint32 types814 [] =
{
SK_REAL64,
};

static const uint16 attr_flags814 [] =
{0,};

static const EIF_TYPE_INDEX g_atype814_0 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes814 [] = {
g_atype814_0,
};

static const long offsets814 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names815[];
static const uint32 types815 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags815 [] =
{0,};

static const EIF_TYPE_INDEX g_atype815_0 [] = {816,0xFFFF};

static const EIF_TYPE_INDEX *gtypes815 [] = {
g_atype815_0,
};

static const long offsets815 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names816[];
static const uint32 types816 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags816 [] =
{0,};

static const EIF_TYPE_INDEX g_atype816_0 [] = {816,0xFFFF};

static const EIF_TYPE_INDEX *gtypes816 [] = {
g_atype816_0,
};

static const long offsets816 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names817[];
static const uint32 types817 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags817 [] =
{0,};

static const EIF_TYPE_INDEX g_atype817_0 [] = {816,0xFFFF};

static const EIF_TYPE_INDEX *gtypes817 [] = {
g_atype817_0,
};

static const long offsets817 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names818[];
static const uint32 types818 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags818 [] =
{0,};

static const EIF_TYPE_INDEX g_atype818_0 [] = {819,0xFFFF};

static const EIF_TYPE_INDEX *gtypes818 [] = {
g_atype818_0,
};

static const long offsets818 [] =
{
+ @CHROFF(0,0),
};

extern const char *names819[];
static const uint32 types819 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags819 [] =
{0,};

static const EIF_TYPE_INDEX g_atype819_0 [] = {819,0xFFFF};

static const EIF_TYPE_INDEX *gtypes819 [] = {
g_atype819_0,
};

static const long offsets819 [] =
{
+ @CHROFF(0,0),
};

extern const char *names820[];
static const uint32 types820 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags820 [] =
{0,};

static const EIF_TYPE_INDEX g_atype820_0 [] = {819,0xFFFF};

static const EIF_TYPE_INDEX *gtypes820 [] = {
g_atype820_0,
};

static const long offsets820 [] =
{
+ @CHROFF(0,0),
};

extern const char *names821[];
static const uint32 types821 [] =
{
SK_BOOL,
};

static const uint16 attr_flags821 [] =
{0,};

static const EIF_TYPE_INDEX g_atype821_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes821 [] = {
g_atype821_0,
};

static const long offsets821 [] =
{
+ @CHROFF(0,0),
};

extern const char *names822[];
static const uint32 types822 [] =
{
SK_BOOL,
};

static const uint16 attr_flags822 [] =
{0,};

static const EIF_TYPE_INDEX g_atype822_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes822 [] = {
g_atype822_0,
};

static const long offsets822 [] =
{
+ @CHROFF(0,0),
};

extern const char *names823[];
static const uint32 types823 [] =
{
SK_BOOL,
};

static const uint16 attr_flags823 [] =
{0,};

static const EIF_TYPE_INDEX g_atype823_0 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes823 [] = {
g_atype823_0,
};

static const long offsets823 [] =
{
+ @CHROFF(0,0),
};

extern const char *names824[];
static const uint32 types824 [] =
{
SK_INT64,
};

static const uint16 attr_flags824 [] =
{0,};

static const EIF_TYPE_INDEX g_atype824_0 [] = {825,0xFFFF};

static const EIF_TYPE_INDEX *gtypes824 [] = {
g_atype824_0,
};

static const long offsets824 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names825[];
static const uint32 types825 [] =
{
SK_INT64,
};

static const uint16 attr_flags825 [] =
{0,};

static const EIF_TYPE_INDEX g_atype825_0 [] = {825,0xFFFF};

static const EIF_TYPE_INDEX *gtypes825 [] = {
g_atype825_0,
};

static const long offsets825 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names826[];
static const uint32 types826 [] =
{
SK_INT64,
};

static const uint16 attr_flags826 [] =
{0,};

static const EIF_TYPE_INDEX g_atype826_0 [] = {825,0xFFFF};

static const EIF_TYPE_INDEX *gtypes826 [] = {
g_atype826_0,
};

static const long offsets826 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names827[];
static const uint32 types827 [] =
{
SK_POINTER,
};

static const uint16 attr_flags827 [] =
{0,};

static const EIF_TYPE_INDEX g_atype827_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes827 [] = {
g_atype827_0,
};

static const long offsets827 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names828[];
static const uint32 types828 [] =
{
SK_POINTER,
};

static const uint16 attr_flags828 [] =
{0,};

static const EIF_TYPE_INDEX g_atype828_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes828 [] = {
g_atype828_0,
};

static const long offsets828 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names829[];
static const uint32 types829 [] =
{
SK_POINTER,
};

static const uint16 attr_flags829 [] =
{0,};

static const EIF_TYPE_INDEX g_atype829_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes829 [] = {
g_atype829_0,
};

static const long offsets829 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names830[];
static const uint32 types830 [] =
{
SK_POINTER,
};

static const uint16 attr_flags830 [] =
{0,};

static const EIF_TYPE_INDEX g_atype830_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes830 [] = {
g_atype830_0,
};

static const long offsets830 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names831[];
static const uint32 types831 [] =
{
SK_POINTER,
};

static const uint16 attr_flags831 [] =
{0,};

static const EIF_TYPE_INDEX g_atype831_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes831 [] = {
g_atype831_0,
};

static const long offsets831 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names832[];
static const uint32 types832 [] =
{
SK_POINTER,
};

static const uint16 attr_flags832 [] =
{0,};

static const EIF_TYPE_INDEX g_atype832_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes832 [] = {
g_atype832_0,
};

static const long offsets832 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names833[];
static const uint32 types833 [] =
{
SK_POINTER,
};

static const uint16 attr_flags833 [] =
{0,};

static const EIF_TYPE_INDEX g_atype833_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes833 [] = {
g_atype833_0,
};

static const long offsets833 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names834[];
static const uint32 types834 [] =
{
SK_POINTER,
};

static const uint16 attr_flags834 [] =
{0,};

static const EIF_TYPE_INDEX g_atype834_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes834 [] = {
g_atype834_0,
};

static const long offsets834 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names835[];
static const uint32 types835 [] =
{
SK_POINTER,
};

static const uint16 attr_flags835 [] =
{0,};

static const EIF_TYPE_INDEX g_atype835_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes835 [] = {
g_atype835_0,
};

static const long offsets835 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names836[];
static const uint32 types836 [] =
{
SK_POINTER,
};

static const uint16 attr_flags836 [] =
{0,};

static const EIF_TYPE_INDEX g_atype836_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes836 [] = {
g_atype836_0,
};

static const long offsets836 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names837[];
static const uint32 types837 [] =
{
SK_POINTER,
};

static const uint16 attr_flags837 [] =
{0,};

static const EIF_TYPE_INDEX g_atype837_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes837 [] = {
g_atype837_0,
};

static const long offsets837 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names838[];
static const uint32 types838 [] =
{
SK_POINTER,
};

static const uint16 attr_flags838 [] =
{0,};

static const EIF_TYPE_INDEX g_atype838_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes838 [] = {
g_atype838_0,
};

static const long offsets838 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names839[];
static const uint32 types839 [] =
{
SK_POINTER,
};

static const uint16 attr_flags839 [] =
{0,};

static const EIF_TYPE_INDEX g_atype839_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes839 [] = {
g_atype839_0,
};

static const long offsets839 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names840[];
static const uint32 types840 [] =
{
SK_POINTER,
};

static const uint16 attr_flags840 [] =
{0,};

static const EIF_TYPE_INDEX g_atype840_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes840 [] = {
g_atype840_0,
};

static const long offsets840 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names841[];
static const uint32 types841 [] =
{
SK_POINTER,
};

static const uint16 attr_flags841 [] =
{0,};

static const EIF_TYPE_INDEX g_atype841_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes841 [] = {
g_atype841_0,
};

static const long offsets841 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names842[];
static const uint32 types842 [] =
{
SK_POINTER,
};

static const uint16 attr_flags842 [] =
{0,};

static const EIF_TYPE_INDEX g_atype842_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes842 [] = {
g_atype842_0,
};

static const long offsets842 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names843[];
static const uint32 types843 [] =
{
SK_POINTER,
};

static const uint16 attr_flags843 [] =
{0,};

static const EIF_TYPE_INDEX g_atype843_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes843 [] = {
g_atype843_0,
};

static const long offsets843 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names844[];
static const uint32 types844 [] =
{
SK_POINTER,
};

static const uint16 attr_flags844 [] =
{0,};

static const EIF_TYPE_INDEX g_atype844_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes844 [] = {
g_atype844_0,
};

static const long offsets844 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names845[];
static const uint32 types845 [] =
{
SK_POINTER,
};

static const uint16 attr_flags845 [] =
{0,};

static const EIF_TYPE_INDEX g_atype845_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes845 [] = {
g_atype845_0,
};

static const long offsets845 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names846[];
static const uint32 types846 [] =
{
SK_POINTER,
};

static const uint16 attr_flags846 [] =
{0,};

static const EIF_TYPE_INDEX g_atype846_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes846 [] = {
g_atype846_0,
};

static const long offsets846 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names847[];
static const uint32 types847 [] =
{
SK_POINTER,
};

static const uint16 attr_flags847 [] =
{0,};

static const EIF_TYPE_INDEX g_atype847_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes847 [] = {
g_atype847_0,
};

static const long offsets847 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names848[];
static const uint32 types848 [] =
{
SK_POINTER,
};

static const uint16 attr_flags848 [] =
{0,};

static const EIF_TYPE_INDEX g_atype848_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes848 [] = {
g_atype848_0,
};

static const long offsets848 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names849[];
static const uint32 types849 [] =
{
SK_POINTER,
};

static const uint16 attr_flags849 [] =
{0,};

static const EIF_TYPE_INDEX g_atype849_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes849 [] = {
g_atype849_0,
};

static const long offsets849 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names850[];
static const uint32 types850 [] =
{
SK_POINTER,
};

static const uint16 attr_flags850 [] =
{0,};

static const EIF_TYPE_INDEX g_atype850_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes850 [] = {
g_atype850_0,
};

static const long offsets850 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names851[];
static const uint32 types851 [] =
{
SK_POINTER,
};

static const uint16 attr_flags851 [] =
{0,};

static const EIF_TYPE_INDEX g_atype851_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes851 [] = {
g_atype851_0,
};

static const long offsets851 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names852[];
static const uint32 types852 [] =
{
SK_POINTER,
};

static const uint16 attr_flags852 [] =
{0,};

static const EIF_TYPE_INDEX g_atype852_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes852 [] = {
g_atype852_0,
};

static const long offsets852 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names853[];
static const uint32 types853 [] =
{
SK_POINTER,
};

static const uint16 attr_flags853 [] =
{0,};

static const EIF_TYPE_INDEX g_atype853_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes853 [] = {
g_atype853_0,
};

static const long offsets853 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names854[];
static const uint32 types854 [] =
{
SK_POINTER,
};

static const uint16 attr_flags854 [] =
{0,};

static const EIF_TYPE_INDEX g_atype854_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes854 [] = {
g_atype854_0,
};

static const long offsets854 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names855[];
static const uint32 types855 [] =
{
SK_POINTER,
};

static const uint16 attr_flags855 [] =
{0,};

static const EIF_TYPE_INDEX g_atype855_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes855 [] = {
g_atype855_0,
};

static const long offsets855 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names856[];
static const uint32 types856 [] =
{
SK_POINTER,
};

static const uint16 attr_flags856 [] =
{0,};

static const EIF_TYPE_INDEX g_atype856_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes856 [] = {
g_atype856_0,
};

static const long offsets856 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names857[];
static const uint32 types857 [] =
{
SK_POINTER,
};

static const uint16 attr_flags857 [] =
{0,};

static const EIF_TYPE_INDEX g_atype857_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes857 [] = {
g_atype857_0,
};

static const long offsets857 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names858[];
static const uint32 types858 [] =
{
SK_POINTER,
};

static const uint16 attr_flags858 [] =
{0,};

static const EIF_TYPE_INDEX g_atype858_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes858 [] = {
g_atype858_0,
};

static const long offsets858 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names859[];
static const uint32 types859 [] =
{
SK_POINTER,
};

static const uint16 attr_flags859 [] =
{0,};

static const EIF_TYPE_INDEX g_atype859_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes859 [] = {
g_atype859_0,
};

static const long offsets859 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names860[];
static const uint32 types860 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags860 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype860_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_1 [] = {0xFFF9,0,786,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_2 [] = {632,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_3 [] = {632,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_9 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_10 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_11 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes860 [] = {
g_atype860_0,
g_atype860_1,
g_atype860_2,
g_atype860_3,
g_atype860_4,
g_atype860_5,
g_atype860_6,
g_atype860_7,
g_atype860_8,
g_atype860_9,
g_atype860_10,
g_atype860_11,
};

static const long offsets860 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names861[];
static const uint32 types861 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags861 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype861_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_1 [] = {0xFFF9,0,786,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_2 [] = {632,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_3 [] = {632,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_9 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_10 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_11 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes861 [] = {
g_atype861_0,
g_atype861_1,
g_atype861_2,
g_atype861_3,
g_atype861_4,
g_atype861_5,
g_atype861_6,
g_atype861_7,
g_atype861_8,
g_atype861_9,
g_atype861_10,
g_atype861_11,
};

static const long offsets861 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names862[];
static const uint32 types862 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags862 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype862_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_1 [] = {0xFFF9,0,786,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_2 [] = {632,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_3 [] = {632,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_10 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_11 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_12 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes862 [] = {
g_atype862_0,
g_atype862_1,
g_atype862_2,
g_atype862_3,
g_atype862_4,
g_atype862_5,
g_atype862_6,
g_atype862_7,
g_atype862_8,
g_atype862_9,
g_atype862_10,
g_atype862_11,
g_atype862_12,
};

static const long offsets862 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @PTROFF(5,2,0,3,0,0),
+ @PTROFF(5,2,0,3,0,1),
+ @PTROFF(5,2,0,3,0,2),
};

extern const char *names863[];
static const uint32 types863 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags863 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype863_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_1 [] = {0xFFF9,0,786,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_2 [] = {632,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_3 [] = {632,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_10 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_11 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_12 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes863 [] = {
g_atype863_0,
g_atype863_1,
g_atype863_2,
g_atype863_3,
g_atype863_4,
g_atype863_5,
g_atype863_6,
g_atype863_7,
g_atype863_8,
g_atype863_9,
g_atype863_10,
g_atype863_11,
g_atype863_12,
};

static const long offsets863 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names864[];
static const uint32 types864 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags864 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype864_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_1 [] = {0xFFF9,0,786,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_2 [] = {632,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_3 [] = {632,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_10 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_11 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_12 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes864 [] = {
g_atype864_0,
g_atype864_1,
g_atype864_2,
g_atype864_3,
g_atype864_4,
g_atype864_5,
g_atype864_6,
g_atype864_7,
g_atype864_8,
g_atype864_9,
g_atype864_10,
g_atype864_11,
g_atype864_12,
};

static const long offsets864 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names865[];
static const uint32 types865 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags865 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype865_0 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_1 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes865 [] = {
g_atype865_0,
g_atype865_1,
};

static const long offsets865 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names866[];
static const uint32 types866 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags866 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype866_0 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype866_1 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes866 [] = {
g_atype866_0,
g_atype866_1,
};

static const long offsets866 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names867[];
static const uint32 types867 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags867 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype867_0 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype867_1 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes867 [] = {
g_atype867_0,
g_atype867_1,
};

static const long offsets867 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names868[];
static const uint32 types868 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags868 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype868_0 [] = {0xFF01,614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype868_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype868_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype868_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes868 [] = {
g_atype868_0,
g_atype868_1,
g_atype868_2,
g_atype868_3,
};

static const long offsets868 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names869[];
static const uint32 types869 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags869 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype869_0 [] = {0xFF01,614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype869_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype869_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype869_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype869_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes869 [] = {
g_atype869_0,
g_atype869_1,
g_atype869_2,
g_atype869_3,
g_atype869_4,
};

static const long offsets869 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names870[];
static const uint32 types870 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags870 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype870_0 [] = {0xFF01,614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype870_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype870_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype870_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype870_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes870 [] = {
g_atype870_0,
g_atype870_1,
g_atype870_2,
g_atype870_3,
g_atype870_4,
};

static const long offsets870 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names871[];
static const uint32 types871 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags871 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype871_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype871_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype871_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype871_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes871 [] = {
g_atype871_0,
g_atype871_1,
g_atype871_2,
g_atype871_3,
};

static const long offsets871 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names872[];
static const uint32 types872 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags872 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype872_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype872_1 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype872_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype872_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype872_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes872 [] = {
g_atype872_0,
g_atype872_1,
g_atype872_2,
g_atype872_3,
g_atype872_4,
};

static const long offsets872 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names873[];
static const uint32 types873 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags873 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype873_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype873_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype873_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype873_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype873_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes873 [] = {
g_atype873_0,
g_atype873_1,
g_atype873_2,
g_atype873_3,
g_atype873_4,
};

static const long offsets873 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names874[];
static const uint32 types874 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags874 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype874_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype874_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype874_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype874_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype874_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes874 [] = {
g_atype874_0,
g_atype874_1,
g_atype874_2,
g_atype874_3,
g_atype874_4,
};

static const long offsets874 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names880[];
static const uint32 types880 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags880 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype880_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_1 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_3 [] = {0xFF01,869,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_4 [] = {7,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_5 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_6 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_9 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_10 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_11 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_12 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_13 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_14 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_17 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_18 [] = {810,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_19 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_20 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_21 [] = {825,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_22 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes880 [] = {
g_atype880_0,
g_atype880_1,
g_atype880_2,
g_atype880_3,
g_atype880_4,
g_atype880_5,
g_atype880_6,
g_atype880_7,
g_atype880_8,
g_atype880_9,
g_atype880_10,
g_atype880_11,
g_atype880_12,
g_atype880_13,
g_atype880_14,
g_atype880_15,
g_atype880_16,
g_atype880_17,
g_atype880_18,
g_atype880_19,
g_atype880_20,
g_atype880_21,
g_atype880_22,
};

static const long offsets880 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names886[];
static const uint32 types886 [] =
{
SK_REF,
SK_CHAR8,
SK_CHAR32,
SK_INT32,
};

static const uint16 attr_flags886 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype886_0 [] = {0xFF01,114,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_1 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_2 [] = {816,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_3 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes886 [] = {
g_atype886_0,
g_atype886_1,
g_atype886_2,
g_atype886_3,
};

static const long offsets886 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names887[];
static const uint32 types887 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags887 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype887_0 [] = {0xFF01,114,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_1 [] = {0xFF01,63,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_2 [] = {613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_3 [] = {614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_4 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_5 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_7 [] = {816,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_17 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_18 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_19 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_20 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_21 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes887 [] = {
g_atype887_0,
g_atype887_1,
g_atype887_2,
g_atype887_3,
g_atype887_4,
g_atype887_5,
g_atype887_6,
g_atype887_7,
g_atype887_8,
g_atype887_9,
g_atype887_10,
g_atype887_11,
g_atype887_12,
g_atype887_13,
g_atype887_14,
g_atype887_15,
g_atype887_16,
g_atype887_17,
g_atype887_18,
g_atype887_19,
g_atype887_20,
g_atype887_21,
};

static const long offsets887 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @LNGOFF(5,2,0,3),
+ @LNGOFF(5,2,0,4),
+ @LNGOFF(5,2,0,5),
+ @LNGOFF(5,2,0,6),
+ @LNGOFF(5,2,0,7),
+ @LNGOFF(5,2,0,8),
+ @LNGOFF(5,2,0,9),
+ @LNGOFF(5,2,0,10),
+ @LNGOFF(5,2,0,11),
+ @LNGOFF(5,2,0,12),
+ @LNGOFF(5,2,0,13),
+ @LNGOFF(5,2,0,14),
};

extern const char *names888[];
static const uint32 types888 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags888 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype888_0 [] = {0xFF01,114,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_1 [] = {0xFF01,63,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_2 [] = {613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_3 [] = {614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_4 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_5 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_6 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_7 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_8 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_9 [] = {607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_10 [] = {607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_11 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_12 [] = {607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_13 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_14 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_15 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_16 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_17 [] = {816,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_18 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_19 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_20 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_21 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_22 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_23 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_24 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_25 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_26 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_27 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_28 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_29 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_30 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_31 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_32 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_33 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_34 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_35 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_36 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_37 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes888 [] = {
g_atype888_0,
g_atype888_1,
g_atype888_2,
g_atype888_3,
g_atype888_4,
g_atype888_5,
g_atype888_6,
g_atype888_7,
g_atype888_8,
g_atype888_9,
g_atype888_10,
g_atype888_11,
g_atype888_12,
g_atype888_13,
g_atype888_14,
g_atype888_15,
g_atype888_16,
g_atype888_17,
g_atype888_18,
g_atype888_19,
g_atype888_20,
g_atype888_21,
g_atype888_22,
g_atype888_23,
g_atype888_24,
g_atype888_25,
g_atype888_26,
g_atype888_27,
g_atype888_28,
g_atype888_29,
g_atype888_30,
g_atype888_31,
g_atype888_32,
g_atype888_33,
g_atype888_34,
g_atype888_35,
g_atype888_36,
g_atype888_37,
};

static const long offsets888 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @CHROFF(14,1),
+ @CHROFF(14,2),
+ @LNGOFF(14,3,0,0),
+ @LNGOFF(14,3,0,1),
+ @LNGOFF(14,3,0,2),
+ @LNGOFF(14,3,0,3),
+ @LNGOFF(14,3,0,4),
+ @LNGOFF(14,3,0,5),
+ @LNGOFF(14,3,0,6),
+ @LNGOFF(14,3,0,7),
+ @LNGOFF(14,3,0,8),
+ @LNGOFF(14,3,0,9),
+ @LNGOFF(14,3,0,10),
+ @LNGOFF(14,3,0,11),
+ @LNGOFF(14,3,0,12),
+ @LNGOFF(14,3,0,13),
+ @LNGOFF(14,3,0,14),
+ @LNGOFF(14,3,0,15),
+ @LNGOFF(14,3,0,16),
+ @LNGOFF(14,3,0,17),
+ @LNGOFF(14,3,0,18),
+ @LNGOFF(14,3,0,19),
+ @LNGOFF(14,3,0,20),
};

extern const char *names890[];
static const uint32 types890 [] =
{
SK_REF,
};

static const uint16 attr_flags890 [] =
{0,};

static const EIF_TYPE_INDEX g_atype890_0 [] = {889,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes890 [] = {
g_atype890_0,
};

static const long offsets890 [] =
{
0,
};

extern const char *names891[];
static const uint32 types891 [] =
{
SK_REF,
};

static const uint16 attr_flags891 [] =
{0,};

static const EIF_TYPE_INDEX g_atype891_0 [] = {890,789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes891 [] = {
g_atype891_0,
};

static const long offsets891 [] =
{
0,
};

extern const char *names892[];
static const uint32 types892 [] =
{
SK_REF,
};

static const uint16 attr_flags892 [] =
{0,};

static const EIF_TYPE_INDEX g_atype892_0 [] = {889,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes892 [] = {
g_atype892_0,
};

static const long offsets892 [] =
{
0,
};

extern const char *names893[];
static const uint32 types893 [] =
{
SK_REF,
};

static const uint16 attr_flags893 [] =
{0,};

static const EIF_TYPE_INDEX g_atype893_0 [] = {892,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes893 [] = {
g_atype893_0,
};

static const long offsets893 [] =
{
0,
};

extern const char *names894[];
static const uint32 types894 [] =
{
SK_REF,
};

static const uint16 attr_flags894 [] =
{0,};

static const EIF_TYPE_INDEX g_atype894_0 [] = {893,789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes894 [] = {
g_atype894_0,
};

static const long offsets894 [] =
{
0,
};

extern const char *names895[];
static const uint32 types895 [] =
{
SK_REF,
};

static const uint16 attr_flags895 [] =
{0,};

static const EIF_TYPE_INDEX g_atype895_0 [] = {894,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes895 [] = {
g_atype895_0,
};

static const long offsets895 [] =
{
0,
};

extern const char *names896[];
static const uint32 types896 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags896 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype896_0 [] = {895,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_1 [] = {0xFFF5,2,0xFF01,933,0xFFF8,1,0xFFF8,2,4576,4514,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_2 [] = {0xFF01,933,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes896 [] = {
g_atype896_0,
g_atype896_1,
g_atype896_2,
};

static const long offsets896 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names897[];
static const uint32 types897 [] =
{
SK_REF,
};

static const uint16 attr_flags897 [] =
{0,};

static const EIF_TYPE_INDEX g_atype897_0 [] = {896,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes897 [] = {
g_atype897_0,
};

static const long offsets897 [] =
{
0,
};

extern const char *names898[];
static const uint32 types898 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags898 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype898_0 [] = {897,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype898_1 [] = {0xFF01,939,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype898_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes898 [] = {
g_atype898_0,
g_atype898_1,
g_atype898_2,
};

static const long offsets898 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names899[];
static const uint32 types899 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags899 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype899_0 [] = {898,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype899_1 [] = {0xFF01,940,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype899_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes899 [] = {
g_atype899_0,
g_atype899_1,
g_atype899_2,
};

static const long offsets899 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names900[];
static const uint32 types900 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags900 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype900_0 [] = {899,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_1 [] = {0xFF01,941,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes900 [] = {
g_atype900_0,
g_atype900_1,
g_atype900_2,
};

static const long offsets900 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names901[];
static const uint32 types901 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags901 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype901_0 [] = {900,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_1 [] = {0xFF01,942,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_2 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes901 [] = {
g_atype901_0,
g_atype901_1,
g_atype901_2,
};

static const long offsets901 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names902[];
static const uint32 types902 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags902 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype902_0 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_2 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes902 [] = {
g_atype902_0,
g_atype902_1,
g_atype902_2,
};

static const long offsets902 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names903[];
static const uint32 types903 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags903 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype903_0 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_2 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes903 [] = {
g_atype903_0,
g_atype903_1,
g_atype903_2,
};

static const long offsets903 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names904[];
static const uint32 types904 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags904 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype904_0 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_2 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes904 [] = {
g_atype904_0,
g_atype904_1,
g_atype904_2,
};

static const long offsets904 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names906[];
static const uint32 types906 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags906 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype906_0 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_1 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_3 [] = {54,0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_4 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_5 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_9 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_10 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes906 [] = {
g_atype906_0,
g_atype906_1,
g_atype906_2,
g_atype906_3,
g_atype906_4,
g_atype906_5,
g_atype906_6,
g_atype906_7,
g_atype906_8,
g_atype906_9,
g_atype906_10,
};

static const long offsets906 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @PTROFF(6,2,0,1,0,0),
+ @PTROFF(6,2,0,1,0,1),
};

extern const char *names907[];
static const uint32 types907 [] =
{
SK_REF,
};

static const uint16 attr_flags907 [] =
{0,};

static const EIF_TYPE_INDEX g_atype907_0 [] = {0xFF01,872,0xFFFF};

static const EIF_TYPE_INDEX *gtypes907 [] = {
g_atype907_0,
};

static const long offsets907 [] =
{
0,
};

extern const char *names908[];
static const uint32 types908 [] =
{
SK_REF,
};

static const uint16 attr_flags908 [] =
{0,};

static const EIF_TYPE_INDEX g_atype908_0 [] = {0xFF01,872,0xFFFF};

static const EIF_TYPE_INDEX *gtypes908 [] = {
g_atype908_0,
};

static const long offsets908 [] =
{
0,
};

extern const char *names909[];
static const uint32 types909 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags909 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype909_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_1 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_3 [] = {0xFF01,869,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_4 [] = {7,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_5 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_6 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_7 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_9 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_10 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_11 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_12 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_13 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_14 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_15 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_17 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_18 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_19 [] = {810,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_20 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_21 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_22 [] = {825,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_23 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes909 [] = {
g_atype909_0,
g_atype909_1,
g_atype909_2,
g_atype909_3,
g_atype909_4,
g_atype909_5,
g_atype909_6,
g_atype909_7,
g_atype909_8,
g_atype909_9,
g_atype909_10,
g_atype909_11,
g_atype909_12,
g_atype909_13,
g_atype909_14,
g_atype909_15,
g_atype909_16,
g_atype909_17,
g_atype909_18,
g_atype909_19,
g_atype909_20,
g_atype909_21,
g_atype909_22,
g_atype909_23,
};

static const long offsets909 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names910[];
static const uint32 types910 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags910 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype910_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_1 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_3 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_4 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_5 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_6 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_9 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_10 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_11 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_12 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_13 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_17 [] = {810,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_18 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_19 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_20 [] = {825,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_21 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes910 [] = {
g_atype910_0,
g_atype910_1,
g_atype910_2,
g_atype910_3,
g_atype910_4,
g_atype910_5,
g_atype910_6,
g_atype910_7,
g_atype910_8,
g_atype910_9,
g_atype910_10,
g_atype910_11,
g_atype910_12,
g_atype910_13,
g_atype910_14,
g_atype910_15,
g_atype910_16,
g_atype910_17,
g_atype910_18,
g_atype910_19,
g_atype910_20,
g_atype910_21,
};

static const long offsets910 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names911[];
static const uint32 types911 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags911 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype911_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_1 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_3 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_4 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_5 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_6 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_9 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_10 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_11 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_12 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_13 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_17 [] = {810,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_18 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_19 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_20 [] = {825,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_21 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes911 [] = {
g_atype911_0,
g_atype911_1,
g_atype911_2,
g_atype911_3,
g_atype911_4,
g_atype911_5,
g_atype911_6,
g_atype911_7,
g_atype911_8,
g_atype911_9,
g_atype911_10,
g_atype911_11,
g_atype911_12,
g_atype911_13,
g_atype911_14,
g_atype911_15,
g_atype911_16,
g_atype911_17,
g_atype911_18,
g_atype911_19,
g_atype911_20,
g_atype911_21,
};

static const long offsets911 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names912[];
static const uint32 types912 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags912 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype912_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_1 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_3 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_4 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_5 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_6 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_9 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_10 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_11 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_12 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_13 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_17 [] = {810,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_18 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_19 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_20 [] = {825,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_21 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes912 [] = {
g_atype912_0,
g_atype912_1,
g_atype912_2,
g_atype912_3,
g_atype912_4,
g_atype912_5,
g_atype912_6,
g_atype912_7,
g_atype912_8,
g_atype912_9,
g_atype912_10,
g_atype912_11,
g_atype912_12,
g_atype912_13,
g_atype912_14,
g_atype912_15,
g_atype912_16,
g_atype912_17,
g_atype912_18,
g_atype912_19,
g_atype912_20,
g_atype912_21,
};

static const long offsets912 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names913[];
static const uint32 types913 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags913 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype913_0 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_1 [] = {55,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_2 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_4 [] = {822,0xFFFF};

static const EIF_TYPE_INDEX *gtypes913 [] = {
g_atype913_0,
g_atype913_1,
g_atype913_2,
g_atype913_3,
g_atype913_4,
};

static const long offsets913 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names914[];
static const uint32 types914 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags914 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype914_0 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_1 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_2 [] = {0xFF01,869,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_3 [] = {7,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_4 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_5 [] = {55,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_6 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_7 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_8 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_9 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_10 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_11 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_12 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_13 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_14 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_15 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_16 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_17 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_18 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_19 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_20 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_21 [] = {810,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_22 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_23 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_24 [] = {825,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_25 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes914 [] = {
g_atype914_0,
g_atype914_1,
g_atype914_2,
g_atype914_3,
g_atype914_4,
g_atype914_5,
g_atype914_6,
g_atype914_7,
g_atype914_8,
g_atype914_9,
g_atype914_10,
g_atype914_11,
g_atype914_12,
g_atype914_13,
g_atype914_14,
g_atype914_15,
g_atype914_16,
g_atype914_17,
g_atype914_18,
g_atype914_19,
g_atype914_20,
g_atype914_21,
g_atype914_22,
g_atype914_23,
g_atype914_24,
g_atype914_25,
};

static const long offsets914 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @I16OFF(7,8,0),
+ @I16OFF(7,8,1),
+ @LNGOFF(7,8,2,0),
+ @LNGOFF(7,8,2,1),
+ @LNGOFF(7,8,2,2),
+ @LNGOFF(7,8,2,3),
+ @R32OFF(7,8,2,4,0),
+ @PTROFF(7,8,2,4,1,0),
+ @I64OFF(7,8,2,4,1,1,0),
+ @I64OFF(7,8,2,4,1,1,1),
+ @R64OFF(7,8,2,4,1,1,2,0),
};

extern const char *names915[];
static const uint32 types915 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags915 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype915_0 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_1 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_3 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_4 [] = {55,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_5 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_6 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_7 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_9 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_10 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_11 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_12 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_13 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_14 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_15 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_17 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_18 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_19 [] = {810,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_20 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_21 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_22 [] = {825,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_23 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes915 [] = {
g_atype915_0,
g_atype915_1,
g_atype915_2,
g_atype915_3,
g_atype915_4,
g_atype915_5,
g_atype915_6,
g_atype915_7,
g_atype915_8,
g_atype915_9,
g_atype915_10,
g_atype915_11,
g_atype915_12,
g_atype915_13,
g_atype915_14,
g_atype915_15,
g_atype915_16,
g_atype915_17,
g_atype915_18,
g_atype915_19,
g_atype915_20,
g_atype915_21,
g_atype915_22,
g_atype915_23,
};

static const long offsets915 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names916[];
static const uint32 types916 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags916 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype916_0 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_1 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_3 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_4 [] = {55,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_5 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_6 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_7 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_9 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_10 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_11 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_12 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_13 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_14 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_15 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_17 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_18 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_19 [] = {810,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_20 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_21 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_22 [] = {825,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_23 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes916 [] = {
g_atype916_0,
g_atype916_1,
g_atype916_2,
g_atype916_3,
g_atype916_4,
g_atype916_5,
g_atype916_6,
g_atype916_7,
g_atype916_8,
g_atype916_9,
g_atype916_10,
g_atype916_11,
g_atype916_12,
g_atype916_13,
g_atype916_14,
g_atype916_15,
g_atype916_16,
g_atype916_17,
g_atype916_18,
g_atype916_19,
g_atype916_20,
g_atype916_21,
g_atype916_22,
g_atype916_23,
};

static const long offsets916 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names917[];
static const uint32 types917 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags917 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype917_0 [] = {0xFF01,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_1 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_2 [] = {167,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_3 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_4 [] = {55,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_5 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_6 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_7 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_9 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_10 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_11 [] = {807,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_12 [] = {795,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_13 [] = {804,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_14 [] = {792,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_15 [] = {801,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_17 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_18 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_19 [] = {810,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_20 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_21 [] = {798,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_22 [] = {825,0xFFFF};
static const EIF_TYPE_INDEX g_atype917_23 [] = {813,0xFFFF};

static const EIF_TYPE_INDEX *gtypes917 [] = {
g_atype917_0,
g_atype917_1,
g_atype917_2,
g_atype917_3,
g_atype917_4,
g_atype917_5,
g_atype917_6,
g_atype917_7,
g_atype917_8,
g_atype917_9,
g_atype917_10,
g_atype917_11,
g_atype917_12,
g_atype917_13,
g_atype917_14,
g_atype917_15,
g_atype917_16,
g_atype917_17,
g_atype917_18,
g_atype917_19,
g_atype917_20,
g_atype917_21,
g_atype917_22,
g_atype917_23,
};

static const long offsets917 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names923[];
static const uint32 types923 [] =
{
SK_REF,
};

static const uint16 attr_flags923 [] =
{0,};

static const EIF_TYPE_INDEX g_atype923_0 [] = {163,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes923 [] = {
g_atype923_0,
};

static const long offsets923 [] =
{
0,
};

extern const char *names924[];
static const uint32 types924 [] =
{
SK_REF,
};

static const uint16 attr_flags924 [] =
{0,};

static const EIF_TYPE_INDEX g_atype924_0 [] = {164,789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes924 [] = {
g_atype924_0,
};

static const long offsets924 [] =
{
0,
};

extern const char *names925[];
static const uint32 types925 [] =
{
SK_REF,
};

static const uint16 attr_flags925 [] =
{0,};

static const EIF_TYPE_INDEX g_atype925_0 [] = {163,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes925 [] = {
g_atype925_0,
};

static const long offsets925 [] =
{
0,
};

extern const char *names926[];
static const uint32 types926 [] =
{
SK_REF,
};

static const uint16 attr_flags926 [] =
{0,};

static const EIF_TYPE_INDEX g_atype926_0 [] = {164,789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes926 [] = {
g_atype926_0,
};

static const long offsets926 [] =
{
0,
};

extern const char *names927[];
static const uint32 types927 [] =
{
SK_REF,
};

static const uint16 attr_flags927 [] =
{0,};

static const EIF_TYPE_INDEX g_atype927_0 [] = {163,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes927 [] = {
g_atype927_0,
};

static const long offsets927 [] =
{
0,
};

extern const char *names928[];
static const uint32 types928 [] =
{
SK_REF,
};

static const uint16 attr_flags928 [] =
{0,};

static const EIF_TYPE_INDEX g_atype928_0 [] = {164,789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes928 [] = {
g_atype928_0,
};

static const long offsets928 [] =
{
0,
};

extern const char *names929[];
static const uint32 types929 [] =
{
SK_REF,
};

static const uint16 attr_flags929 [] =
{0,};

static const EIF_TYPE_INDEX g_atype929_0 [] = {163,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes929 [] = {
g_atype929_0,
};

static const long offsets929 [] =
{
0,
};

extern const char *names930[];
static const uint32 types930 [] =
{
SK_REF,
};

static const uint16 attr_flags930 [] =
{0,};

static const EIF_TYPE_INDEX g_atype930_0 [] = {164,789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes930 [] = {
g_atype930_0,
};

static const long offsets930 [] =
{
0,
};

extern const char *names931[];
static const uint32 types931 [] =
{
SK_REF,
};

static const uint16 attr_flags931 [] =
{0,};

static const EIF_TYPE_INDEX g_atype931_0 [] = {163,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes931 [] = {
g_atype931_0,
};

static const long offsets931 [] =
{
0,
};

extern const char *names932[];
static const uint32 types932 [] =
{
SK_REF,
};

static const uint16 attr_flags932 [] =
{0,};

static const EIF_TYPE_INDEX g_atype932_0 [] = {164,789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes932 [] = {
g_atype932_0,
};

static const long offsets932 [] =
{
0,
};

extern const char *names933[];
static const uint32 types933 [] =
{
SK_REF,
};

static const uint16 attr_flags933 [] =
{0,};

static const EIF_TYPE_INDEX g_atype933_0 [] = {163,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes933 [] = {
g_atype933_0,
};

static const long offsets933 [] =
{
0,
};

extern const char *names934[];
static const uint32 types934 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags934 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype934_0 [] = {163,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype934_1 [] = {0xFF01,940,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype934_2 [] = {0xFF01,895,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes934 [] = {
g_atype934_0,
g_atype934_1,
g_atype934_2,
};

static const long offsets934 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names935[];
static const uint32 types935 [] =
{
SK_REF,
};

static const uint16 attr_flags935 [] =
{0,};

static const EIF_TYPE_INDEX g_atype935_0 [] = {163,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes935 [] = {
g_atype935_0,
};

static const long offsets935 [] =
{
0,
};

extern const char *names938[];
static const uint32 types938 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags938 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype938_0 [] = {163,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_1 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_2 [] = {0xFF01,12,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes938 [] = {
g_atype938_0,
g_atype938_1,
g_atype938_2,
g_atype938_3,
g_atype938_4,
};

static const long offsets938 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names939[];
static const uint32 types939 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags939 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype939_0 [] = {164,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_1 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_2 [] = {0xFF01,13,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_4 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes939 [] = {
g_atype939_0,
g_atype939_1,
g_atype939_2,
g_atype939_3,
g_atype939_4,
};

static const long offsets939 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names940[];
static const uint32 types940 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags940 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype940_0 [] = {163,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_1 [] = {0xFF01,897,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_10 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes940 [] = {
g_atype940_0,
g_atype940_1,
g_atype940_2,
g_atype940_3,
g_atype940_4,
g_atype940_5,
g_atype940_6,
g_atype940_7,
g_atype940_8,
g_atype940_9,
g_atype940_10,
};

static const long offsets940 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names941[];
static const uint32 types941 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags941 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype941_0 [] = {163,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_1 [] = {0xFF01,898,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_2 [] = {933,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_3 [] = {163,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_7 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_8 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_12 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes941 [] = {
g_atype941_0,
g_atype941_1,
g_atype941_2,
g_atype941_3,
g_atype941_4,
g_atype941_5,
g_atype941_6,
g_atype941_7,
g_atype941_8,
g_atype941_9,
g_atype941_10,
g_atype941_11,
g_atype941_12,
};

static const long offsets941 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names942[];
static const uint32 types942 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags942 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype942_0 [] = {163,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_1 [] = {0xFF01,899,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_2 [] = {933,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_3 [] = {163,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_4 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_5 [] = {0xFF01,606,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_6 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_7 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_8 [] = {0xFF01,12,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_9 [] = {0xFF01,12,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_10 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_17 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_18 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes942 [] = {
g_atype942_0,
g_atype942_1,
g_atype942_2,
g_atype942_3,
g_atype942_4,
g_atype942_5,
g_atype942_6,
g_atype942_7,
g_atype942_8,
g_atype942_9,
g_atype942_10,
g_atype942_11,
g_atype942_12,
g_atype942_13,
g_atype942_14,
g_atype942_15,
g_atype942_16,
g_atype942_17,
g_atype942_18,
};

static const long offsets942 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names943[];
static const uint32 types943 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags943 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype943_0 [] = {163,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_1 [] = {0xFF01,900,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_2 [] = {933,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_3 [] = {163,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_4 [] = {0xFF01,606,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_5 [] = {0xFF01,606,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_6 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_7 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_8 [] = {0xFF01,12,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_9 [] = {0xFF01,12,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_10 [] = {5,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_11 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_17 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_18 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_19 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes943 [] = {
g_atype943_0,
g_atype943_1,
g_atype943_2,
g_atype943_3,
g_atype943_4,
g_atype943_5,
g_atype943_6,
g_atype943_7,
g_atype943_8,
g_atype943_9,
g_atype943_10,
g_atype943_11,
g_atype943_12,
g_atype943_13,
g_atype943_14,
g_atype943_15,
g_atype943_16,
g_atype943_17,
g_atype943_18,
g_atype943_19,
};

static const long offsets943 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names944[];
static const uint32 types944 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags944 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype944_0 [] = {202,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_1 [] = {202,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_2 [] = {202,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_3 [] = {696,0xFF01,0xFFF9,2,786,0xFF01,202,701,0xFF01,0xFFF9,2,786,0xFF01,204,0xFF01,204,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_5 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_6 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_7 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_8 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_9 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_10 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes944 [] = {
g_atype944_0,
g_atype944_1,
g_atype944_2,
g_atype944_3,
g_atype944_4,
g_atype944_5,
g_atype944_6,
g_atype944_7,
g_atype944_8,
g_atype944_9,
g_atype944_10,
};

static const long offsets944 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @LNGOFF(4,5,0,0),
+ @LNGOFF(4,5,0,1),
};

extern const char *names945[];
static const uint32 types945 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags945 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype945_0 [] = {0xFF01,727,0xFFFF};
static const EIF_TYPE_INDEX g_atype945_1 [] = {0xFF01,727,0xFFFF};
static const EIF_TYPE_INDEX g_atype945_2 [] = {0xFF01,727,0xFFFF};

static const EIF_TYPE_INDEX *gtypes945 [] = {
g_atype945_0,
g_atype945_1,
g_atype945_2,
};

static const long offsets945 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names953[];
static const uint32 types953 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags953 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype953_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype953_1 [] = {0xFF01,872,0xFFFF};

static const EIF_TYPE_INDEX *gtypes953 [] = {
g_atype953_0,
g_atype953_1,
};

static const long offsets953 [] =
{
0,
 + @REFACS(1),
};

extern const char *names954[];
static const uint32 types954 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags954 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype954_0 [] = {0xFF01,114,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_1 [] = {0xFF01,63,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_2 [] = {613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_3 [] = {614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_4 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_5 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_6 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_7 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_8 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_9 [] = {607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_10 [] = {607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_11 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_12 [] = {607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_13 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_15 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_16 [] = {0xFF01,727,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_17 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_18 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_19 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_20 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_21 [] = {816,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_22 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_23 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_24 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_25 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_26 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_27 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_28 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_29 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_30 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_31 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_32 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_33 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_34 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_35 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_36 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_37 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_38 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_39 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_40 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_41 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_42 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes954 [] = {
g_atype954_0,
g_atype954_1,
g_atype954_2,
g_atype954_3,
g_atype954_4,
g_atype954_5,
g_atype954_6,
g_atype954_7,
g_atype954_8,
g_atype954_9,
g_atype954_10,
g_atype954_11,
g_atype954_12,
g_atype954_13,
g_atype954_14,
g_atype954_15,
g_atype954_16,
g_atype954_17,
g_atype954_18,
g_atype954_19,
g_atype954_20,
g_atype954_21,
g_atype954_22,
g_atype954_23,
g_atype954_24,
g_atype954_25,
g_atype954_26,
g_atype954_27,
g_atype954_28,
g_atype954_29,
g_atype954_30,
g_atype954_31,
g_atype954_32,
g_atype954_33,
g_atype954_34,
g_atype954_35,
g_atype954_36,
g_atype954_37,
g_atype954_38,
g_atype954_39,
g_atype954_40,
g_atype954_41,
g_atype954_42,
};

static const long offsets954 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
+ @CHROFF(17,0),
+ @CHROFF(17,1),
+ @CHROFF(17,2),
+ @CHROFF(17,3),
+ @LNGOFF(17,4,0,0),
+ @LNGOFF(17,4,0,1),
+ @LNGOFF(17,4,0,2),
+ @LNGOFF(17,4,0,3),
+ @LNGOFF(17,4,0,4),
+ @LNGOFF(17,4,0,5),
+ @LNGOFF(17,4,0,6),
+ @LNGOFF(17,4,0,7),
+ @LNGOFF(17,4,0,8),
+ @LNGOFF(17,4,0,9),
+ @LNGOFF(17,4,0,10),
+ @LNGOFF(17,4,0,11),
+ @LNGOFF(17,4,0,12),
+ @LNGOFF(17,4,0,13),
+ @LNGOFF(17,4,0,14),
+ @LNGOFF(17,4,0,15),
+ @LNGOFF(17,4,0,16),
+ @LNGOFF(17,4,0,17),
+ @LNGOFF(17,4,0,18),
+ @LNGOFF(17,4,0,19),
+ @LNGOFF(17,4,0,20),
+ @LNGOFF(17,4,0,21),
};

extern const char *names955[];
static const uint32 types955 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags955 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype955_0 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_1 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_2 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_3 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_4 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_5 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_6 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_7 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_8 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_9 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_10 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_11 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_12 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_13 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_14 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_15 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_16 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_17 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_18 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_19 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_20 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_21 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype955_22 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes955 [] = {
g_atype955_0,
g_atype955_1,
g_atype955_2,
g_atype955_3,
g_atype955_4,
g_atype955_5,
g_atype955_6,
g_atype955_7,
g_atype955_8,
g_atype955_9,
g_atype955_10,
g_atype955_11,
g_atype955_12,
g_atype955_13,
g_atype955_14,
g_atype955_15,
g_atype955_16,
g_atype955_17,
g_atype955_18,
g_atype955_19,
g_atype955_20,
g_atype955_21,
g_atype955_22,
};

static const long offsets955 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @LNGOFF(11,1,0,0),
+ @LNGOFF(11,1,0,1),
+ @LNGOFF(11,1,0,2),
+ @LNGOFF(11,1,0,3),
+ @LNGOFF(11,1,0,4),
+ @LNGOFF(11,1,0,5),
+ @LNGOFF(11,1,0,6),
+ @LNGOFF(11,1,0,7),
+ @LNGOFF(11,1,0,8),
+ @LNGOFF(11,1,0,9),
+ @LNGOFF(11,1,0,10),
};

extern const char *names956[];
static const uint32 types956 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags956 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype956_0 [] = {0xFF01,114,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_1 [] = {0xFF01,63,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_2 [] = {613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_3 [] = {614,816,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_4 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_5 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_6 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_7 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_8 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_9 [] = {607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_10 [] = {607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_11 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_12 [] = {607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_13 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_15 [] = {0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_16 [] = {0xFF01,727,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_17 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_18 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_19 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_20 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_21 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_22 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_23 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_24 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_25 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_26 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_27 [] = {0xFF01,607,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_28 [] = {0xFF01,606,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_29 [] = {0xFF01,12,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_30 [] = {0xFF01,606,0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_31 [] = {0xFF01,12,0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_32 [] = {0xFF01,611,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_33 [] = {0xFF01,14,822,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_34 [] = {0xFF01,944,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_35 [] = {0xFF01,942,0xFF01,872,0xFF01,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_36 [] = {0xFF01,938,789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_37 [] = {0xFF01,937,0xFF01,114,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_38 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_39 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_40 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_41 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_42 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_43 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_44 [] = {816,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_45 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_46 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_47 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_48 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_49 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_50 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_51 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_52 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_53 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_54 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_55 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_56 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_57 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_58 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_59 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_60 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_61 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_62 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_63 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_64 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_65 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_66 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_67 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_68 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_69 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_70 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_71 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_72 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_73 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_74 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_75 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_76 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_77 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_78 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_79 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_80 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_81 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_82 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_83 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype956_84 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes956 [] = {
g_atype956_0,
g_atype956_1,
g_atype956_2,
g_atype956_3,
g_atype956_4,
g_atype956_5,
g_atype956_6,
g_atype956_7,
g_atype956_8,
g_atype956_9,
g_atype956_10,
g_atype956_11,
g_atype956_12,
g_atype956_13,
g_atype956_14,
g_atype956_15,
g_atype956_16,
g_atype956_17,
g_atype956_18,
g_atype956_19,
g_atype956_20,
g_atype956_21,
g_atype956_22,
g_atype956_23,
g_atype956_24,
g_atype956_25,
g_atype956_26,
g_atype956_27,
g_atype956_28,
g_atype956_29,
g_atype956_30,
g_atype956_31,
g_atype956_32,
g_atype956_33,
g_atype956_34,
g_atype956_35,
g_atype956_36,
g_atype956_37,
g_atype956_38,
g_atype956_39,
g_atype956_40,
g_atype956_41,
g_atype956_42,
g_atype956_43,
g_atype956_44,
g_atype956_45,
g_atype956_46,
g_atype956_47,
g_atype956_48,
g_atype956_49,
g_atype956_50,
g_atype956_51,
g_atype956_52,
g_atype956_53,
g_atype956_54,
g_atype956_55,
g_atype956_56,
g_atype956_57,
g_atype956_58,
g_atype956_59,
g_atype956_60,
g_atype956_61,
g_atype956_62,
g_atype956_63,
g_atype956_64,
g_atype956_65,
g_atype956_66,
g_atype956_67,
g_atype956_68,
g_atype956_69,
g_atype956_70,
g_atype956_71,
g_atype956_72,
g_atype956_73,
g_atype956_74,
g_atype956_75,
g_atype956_76,
g_atype956_77,
g_atype956_78,
g_atype956_79,
g_atype956_80,
g_atype956_81,
g_atype956_82,
g_atype956_83,
g_atype956_84,
};

static const long offsets956 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
+ @CHROFF(38,0),
+ @CHROFF(38,1),
+ @CHROFF(38,2),
+ @CHROFF(38,3),
+ @CHROFF(38,4),
+ @CHROFF(38,5),
+ @LNGOFF(38,6,0,0),
+ @LNGOFF(38,6,0,1),
+ @LNGOFF(38,6,0,2),
+ @LNGOFF(38,6,0,3),
+ @LNGOFF(38,6,0,4),
+ @LNGOFF(38,6,0,5),
+ @LNGOFF(38,6,0,6),
+ @LNGOFF(38,6,0,7),
+ @LNGOFF(38,6,0,8),
+ @LNGOFF(38,6,0,9),
+ @LNGOFF(38,6,0,10),
+ @LNGOFF(38,6,0,11),
+ @LNGOFF(38,6,0,12),
+ @LNGOFF(38,6,0,13),
+ @LNGOFF(38,6,0,14),
+ @LNGOFF(38,6,0,15),
+ @LNGOFF(38,6,0,16),
+ @LNGOFF(38,6,0,17),
+ @LNGOFF(38,6,0,18),
+ @LNGOFF(38,6,0,19),
+ @LNGOFF(38,6,0,20),
+ @LNGOFF(38,6,0,21),
+ @LNGOFF(38,6,0,22),
+ @LNGOFF(38,6,0,23),
+ @LNGOFF(38,6,0,24),
+ @LNGOFF(38,6,0,25),
+ @LNGOFF(38,6,0,26),
+ @LNGOFF(38,6,0,27),
+ @LNGOFF(38,6,0,28),
+ @LNGOFF(38,6,0,29),
+ @LNGOFF(38,6,0,30),
+ @LNGOFF(38,6,0,31),
+ @LNGOFF(38,6,0,32),
+ @LNGOFF(38,6,0,33),
+ @LNGOFF(38,6,0,34),
+ @LNGOFF(38,6,0,35),
+ @LNGOFF(38,6,0,36),
+ @LNGOFF(38,6,0,37),
+ @LNGOFF(38,6,0,38),
+ @LNGOFF(38,6,0,39),
+ @LNGOFF(38,6,0,40),
};

extern const char *names957[];
static const uint32 types957 [] =
{
SK_REF,
};

static const uint16 attr_flags957 [] =
{0,};

static const EIF_TYPE_INDEX g_atype957_0 [] = {0xFF01,631,0xFF01,872,0xFFFF};

static const EIF_TYPE_INDEX *gtypes957 [] = {
g_atype957_0,
};

static const long offsets957 [] =
{
0,
};

extern const char *names958[];
static const uint32 types958 [] =
{
SK_REF,
};

static const uint16 attr_flags958 [] =
{0,};

static const EIF_TYPE_INDEX g_atype958_0 [] = {0xFF01,631,0xFF01,872,0xFFFF};

static const EIF_TYPE_INDEX *gtypes958 [] = {
g_atype958_0,
};

static const long offsets958 [] =
{
0,
};

extern const char *names959[];
static const uint32 types959 [] =
{
SK_REF,
};

static const uint16 attr_flags959 [] =
{0,};

static const EIF_TYPE_INDEX g_atype959_0 [] = {0xFF01,631,0xFF01,872,0xFFFF};

static const EIF_TYPE_INDEX *gtypes959 [] = {
g_atype959_0,
};

static const long offsets959 [] =
{
0,
};

extern const char *names960[];
static const uint32 types960 [] =
{
SK_REF,
};

static const uint16 attr_flags960 [] =
{0,};

static const EIF_TYPE_INDEX g_atype960_0 [] = {0xFF01,631,0xFF01,872,0xFFFF};

static const EIF_TYPE_INDEX *gtypes960 [] = {
g_atype960_0,
};

static const long offsets960 [] =
{
0,
};

extern const char *names961[];
static const uint32 types961 [] =
{
SK_REF,
};

static const uint16 attr_flags961 [] =
{0,};

static const EIF_TYPE_INDEX g_atype961_0 [] = {0xFF01,631,0xFF01,872,0xFFFF};

static const EIF_TYPE_INDEX *gtypes961 [] = {
g_atype961_0,
};

static const long offsets961 [] =
{
0,
};

extern const char *names962[];
static const uint32 types962 [] =
{
SK_REF,
};

static const uint16 attr_flags962 [] =
{0,};

static const EIF_TYPE_INDEX g_atype962_0 [] = {0xFF01,631,0xFF01,872,0xFFFF};

static const EIF_TYPE_INDEX *gtypes962 [] = {
g_atype962_0,
};

static const long offsets962 [] =
{
0,
};

extern const char *names963[];
static const uint32 types963 [] =
{
SK_REF,
};

static const uint16 attr_flags963 [] =
{0,};

static const EIF_TYPE_INDEX g_atype963_0 [] = {0xFF01,631,0xFF01,872,0xFFFF};

static const EIF_TYPE_INDEX *gtypes963 [] = {
g_atype963_0,
};

static const long offsets963 [] =
{
0,
};

extern const char *names964[];
static const uint32 types964 [] =
{
SK_REF,
};

static const uint16 attr_flags964 [] =
{0,};

static const EIF_TYPE_INDEX g_atype964_0 [] = {0xFF01,631,0xFF01,872,0xFFFF};

static const EIF_TYPE_INDEX *gtypes964 [] = {
g_atype964_0,
};

static const long offsets964 [] =
{
0,
};

extern const char *names966[];
static const uint32 types966 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags966 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype966_0 [] = {0xFF01,631,872,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_1 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_2 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_3 [] = {872,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_4 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype966_5 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes966 [] = {
g_atype966_0,
g_atype966_1,
g_atype966_2,
g_atype966_3,
g_atype966_4,
g_atype966_5,
};

static const long offsets966 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
};

extern const char *names967[];
static const uint32 types967 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags967 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype967_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_7 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes967 [] = {
g_atype967_0,
g_atype967_1,
g_atype967_2,
g_atype967_3,
g_atype967_4,
g_atype967_5,
g_atype967_6,
g_atype967_7,
};

static const long offsets967 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

extern const char *names968[];
static const uint32 types968 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags968 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype968_0 [] = {0xFF01,613,819,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_1 [] = {822,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_2 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_3 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_4 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_5 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_6 [] = {789,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_7 [] = {789,0xFFFF};

static const EIF_TYPE_INDEX *gtypes968 [] = {
g_atype968_0,
g_atype968_1,
g_atype968_2,
g_atype968_3,
g_atype968_4,
g_atype968_5,
g_atype968_6,
g_atype968_7,
};

static const long offsets968 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

const struct cnode egc_fsystem_init[] = {
{
	(long) 0,
	(long) 0,
	"ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DESCRIPTOR_CACHE",
	names3,
	types3,
	attr_flags3,
	gtypes3,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets3,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 0,
	"VERSIONABLE",
	names5,
	types5,
	attr_flags5,
	gtypes5,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets5,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_HASH_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ENCODING",
	names8,
	types8,
	attr_flags8,
	gtypes8,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets8,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_PAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CHARACTER_PROPERTY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RT_DBG_EXECUTION_PARAMETERS",
	names19,
	types19,
	attr_flags19,
	gtypes19,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets19,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_RUNTIME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPERATING_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STD_FILES",
	names36,
	types36,
	attr_flags36,
	gtypes36,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets36,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_TRAVERSABLE",
	names49,
	types49,
	attr_flags49,
	gtypes49,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets49,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE",
	names50,
	types50,
	attr_flags50,
	gtypes50,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets50,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names53,
	types53,
	attr_flags53,
	gtypes53,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets53,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names54,
	types54,
	attr_flags54,
	gtypes54,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets54,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names55,
	types55,
	attr_flags55,
	gtypes55,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets55,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names56,
	types56,
	attr_flags56,
	gtypes56,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets56,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OBJECT_GRAPH_MARKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MATH_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DOUBLE_MATH",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFACTORING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_GOBO_VERSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"GEPP_VERSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_EXECUTION_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEP_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names73,
	types73,
	attr_flags73,
	gtypes73,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets73,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names74,
	types74,
	attr_flags74,
	gtypes74,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets74,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names75,
	types75,
	attr_flags75,
	gtypes75,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets75,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names76,
	types76,
	attr_flags76,
	gtypes76,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets76,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names77,
	types77,
	attr_flags77,
	gtypes77,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets77,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names78,
	types78,
	attr_flags78,
	gtypes78,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets78,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENCODING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_IMP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM_ENTRY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_GENERAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC_INFORMATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INTEGER_OVERFLOW_CHECKER",
	names94,
	types94,
	attr_flags94,
	gtypes94,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets94,
	NULL
},
{
	(long) 7,
	(long) 7,
	"STRING_TO_NUMERIC_CONVERTOR",
	names95,
	types95,
	attr_flags95,
	gtypes95,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets95,
	NULL
},
{
	(long) 11,
	(long) 11,
	"HEXADECIMAL_STRING_TO_INTEGER_CONVERTER",
	names96,
	types96,
	attr_flags96,
	gtypes96,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets96,
	NULL
},
{
	(long) 15,
	(long) 15,
	"STRING_TO_REAL_CONVERTOR",
	names97,
	types97,
	attr_flags97,
	gtypes97,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets97,
	NULL
},
{
	(long) 10,
	(long) 10,
	"STRING_TO_INTEGER_CONVERTOR",
	names98,
	types98,
	attr_flags98,
	gtypes98,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets98,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_SEARCHER",
	names99,
	types99,
	attr_flags99,
	gtypes99,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets99,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_32_SEARCHER",
	names100,
	types100,
	attr_flags100,
	gtypes100,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets100,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_8_SEARCHER",
	names101,
	types101,
	attr_flags101,
	gtypes101,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets101,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STREAMS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names111,
	types111,
	attr_flags111,
	gtypes111,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets111,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names112,
	types112,
	attr_flags112,
	gtypes112,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets112,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HASH_TABLE_CURSOR",
	names113,
	types113,
	attr_flags113,
	gtypes113,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets113,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ARRAYED_LIST_CURSOR",
	names114,
	types114,
	attr_flags114,
	gtypes114,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets114,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_BUFFER",
	names115,
	types115,
	attr_flags115,
	gtypes115,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets115,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UTF8_BUFFER",
	names116,
	types116,
	attr_flags116,
	gtypes116,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets116,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UNICODE_BUFFER",
	names117,
	types117,
	attr_flags117,
	gtypes117,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets117,
	NULL
},
{
	(long) 12,
	(long) 12,
	"YY_FILE_BUFFER",
	names118,
	types118,
	attr_flags118,
	gtypes118,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets118,
	NULL
},
{
	(long) 14,
	(long) 14,
	"YY_UTF8_FILE_BUFFER",
	names119,
	types119,
	attr_flags119,
	gtypes119,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets119,
	NULL
},
{
	(long) 15,
	(long) 15,
	"YY_UNICODE_FILE_BUFFER",
	names120,
	types120,
	attr_flags120,
	gtypes120,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets120,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION",
	names124,
	types124,
	attr_flags124,
	gtypes124,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets124,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DEVELOPER_EXCEPTION",
	names125,
	types125,
	attr_flags125,
	gtypes125,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets125,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONVERSION_FAILURE",
	names126,
	types126,
	attr_flags126,
	gtypes126,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets126,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MACHINE_EXCEPTION",
	names127,
	types127,
	attr_flags127,
	gtypes127,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets127,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HARDWARE_EXCEPTION",
	names128,
	types128,
	attr_flags128,
	gtypes128,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets128,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FLOATING_POINT_FAILURE",
	names129,
	types129,
	attr_flags129,
	gtypes129,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets129,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OPERATING_SYSTEM_EXCEPTION",
	names130,
	types130,
	attr_flags130,
	gtypes130,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets130,
	NULL
},
{
	(long) 10,
	(long) 10,
	"COM_FAILURE",
	names131,
	types131,
	attr_flags131,
	gtypes131,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets131,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_FAILURE",
	names132,
	types132,
	attr_flags132,
	gtypes132,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets132,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_SIGNAL_FAILURE",
	names133,
	types133,
	attr_flags133,
	gtypes133,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets133,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SYS_EXCEPTION",
	names134,
	types134,
	attr_flags134,
	gtypes134,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets134,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OLD_VIOLATION",
	names135,
	types135,
	attr_flags135,
	gtypes135,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets135,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EIFFEL_RUNTIME_PANIC",
	names136,
	types136,
	attr_flags136,
	gtypes136,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets136,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIF_EXCEPTION",
	names137,
	types137,
	attr_flags137,
	gtypes137,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets137,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFEL_RUNTIME_EXCEPTION",
	names138,
	types138,
	attr_flags138,
	gtypes138,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets138,
	NULL
},
{
	(long) 8,
	(long) 8,
	"NO_MORE_MEMORY",
	names139,
	types139,
	attr_flags139,
	gtypes139,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets139,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXTERNAL_FAILURE",
	names140,
	types140,
	attr_flags140,
	gtypes140,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets140,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATA_EXCEPTION",
	names141,
	types141,
	attr_flags141,
	gtypes141,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets141,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SERIALIZATION_FAILURE",
	names142,
	types142,
	attr_flags142,
	gtypes142,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets142,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MISMATCH_FAILURE",
	names143,
	types143,
	attr_flags143,
	gtypes143,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets143,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IO_FAILURE",
	names144,
	types144,
	attr_flags144,
	gtypes144,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets144,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LANGUAGE_EXCEPTION",
	names145,
	types145,
	attr_flags145,
	gtypes145,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets145,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_TARGET",
	names146,
	types146,
	attr_flags146,
	gtypes146,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets146,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_ASSIGNED_TO_EXPANDED",
	names147,
	types147,
	attr_flags147,
	gtypes147,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets147,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BAD_INSPECT_VALUE",
	names148,
	types148,
	attr_flags148,
	gtypes148,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets148,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ROUTINE_FAILURE",
	names149,
	types149,
	attr_flags149,
	gtypes149,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets149,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION",
	names150,
	types150,
	attr_flags150,
	gtypes150,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets150,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ADDRESS_APPLIED_TO_MELTED_FEATURE",
	names151,
	types151,
	attr_flags151,
	gtypes151,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets151,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CREATE_ON_DEFERRED",
	names152,
	types152,
	attr_flags152,
	gtypes152,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets152,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OBSOLETE_EXCEPTION",
	names153,
	types153,
	attr_flags153,
	gtypes153,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets153,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION_IN_SIGNAL_HANDLER_FAILURE",
	names154,
	types154,
	attr_flags154,
	gtypes154,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets154,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESCUE_FAILURE",
	names155,
	types155,
	attr_flags155,
	gtypes155,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets155,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESUMPTION_FAILURE",
	names156,
	types156,
	attr_flags156,
	gtypes156,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets156,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ASSERTION_VIOLATION",
	names157,
	types157,
	attr_flags157,
	gtypes157,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets157,
	NULL
},
{
	(long) 7,
	(long) 7,
	"POSTCONDITION_VIOLATION",
	names158,
	types158,
	attr_flags158,
	gtypes158,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets158,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PRECONDITION_VIOLATION",
	names159,
	types159,
	attr_flags159,
	gtypes159,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets159,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LOOP_INVARIANT_VIOLATION",
	names160,
	types160,
	attr_flags160,
	gtypes160,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets160,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VARIANT_VIOLATION",
	names161,
	types161,
	attr_flags161,
	gtypes161,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets161,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CHECK_VIOLATION",
	names162,
	types162,
	attr_flags162,
	gtypes162,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets162,
	NULL
},
{
	(long) 8,
	(long) 8,
	"INVARIANT_VIOLATION",
	names163,
	types163,
	attr_flags163,
	gtypes163,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets163,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DISPOSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 2,
	"MANAGED_POINTER",
	names168,
	types168,
	attr_flags168,
	gtypes168,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets168,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEPP",
	names170,
	types170,
	attr_flags170,
	gtypes170,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets170,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REFLECTED_OBJECT",
	names173,
	types173,
	attr_flags173,
	gtypes173,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets173,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REFLECTED_COPY_SEMANTICS_OBJECT",
	names177,
	types177,
	attr_flags177,
	gtypes177,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets177,
	NULL
},
{
	(long) 3,
	(long) 3,
	"REFLECTED_REFERENCE_OBJECT",
	names178,
	types178,
	attr_flags178,
	gtypes178,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets178,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names179,
	types179,
	attr_flags179,
	gtypes179,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets179,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names180,
	types180,
	attr_flags180,
	gtypes180,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets180,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names181,
	types181,
	attr_flags181,
	gtypes181,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets181,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names182,
	types182,
	attr_flags182,
	gtypes182,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets182,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names183,
	types183,
	attr_flags183,
	gtypes183,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets183,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names184,
	types184,
	attr_flags184,
	gtypes184,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets184,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names185,
	types185,
	attr_flags185,
	gtypes185,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets185,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names186,
	types186,
	attr_flags186,
	gtypes186,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets186,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names187,
	types187,
	attr_flags187,
	gtypes187,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets187,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names188,
	types188,
	attr_flags188,
	gtypes188,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets188,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names189,
	types189,
	attr_flags189,
	gtypes189,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets189,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names190,
	types190,
	attr_flags190,
	gtypes190,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets190,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"NATIVE_STRING",
	names192,
	types192,
	attr_flags192,
	gtypes192,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets192,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXECUTION_ENVIRONMENT",
	names193,
	types193,
	attr_flags193,
	gtypes193,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets193,
	NULL
},
{
	(long) 6,
	(long) 6,
	"DIRECTORY",
	names194,
	types194,
	attr_flags194,
	gtypes194,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets194,
	NULL
},
{
	(long) 5,
	(long) 5,
	"FILE_INFO",
	names195,
	types195,
	attr_flags195,
	gtypes195,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets195,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UNIX_FILE_INFO",
	names196,
	types196,
	attr_flags196,
	gtypes196,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets196,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_UNICODE_CHARACTER_BUFFER",
	names198,
	types198,
	attr_flags198,
	gtypes198,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets198,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_CHARACTER_BUFFER",
	names199,
	types199,
	attr_flags199,
	gtypes199,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets199,
	NULL
},
{
	(long) 2,
	(long) 2,
	"C_STRING",
	names200,
	types200,
	attr_flags200,
	gtypes200,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets200,
	NULL
},
{
	(long) 13,
	(long) 13,
	"IO_MEDIUM",
	names201,
	types201,
	attr_flags201,
	gtypes201,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets201,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DEBUG_OUTPUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 15,
	(long) 15,
	"RT_DBG_CALL_RECORD",
	names203,
	types203,
	attr_flags203,
	gtypes203,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets203,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSTRACT_SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"RT_DBG_VALUE_RECORD",
	names205,
	types205,
	attr_flags205,
	gtypes205,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets205,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names206,
	types206,
	attr_flags206,
	gtypes206,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets206,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names207,
	types207,
	attr_flags207,
	gtypes207,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets207,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names208,
	types208,
	attr_flags208,
	gtypes208,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets208,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names209,
	types209,
	attr_flags209,
	gtypes209,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets209,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names210,
	types210,
	attr_flags210,
	gtypes210,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets210,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names211,
	types211,
	attr_flags211,
	gtypes211,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets211,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names212,
	types212,
	attr_flags212,
	gtypes212,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets212,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names213,
	types213,
	attr_flags213,
	gtypes213,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets213,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names214,
	types214,
	attr_flags214,
	gtypes214,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets214,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names215,
	types215,
	attr_flags215,
	gtypes215,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets215,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names216,
	types216,
	attr_flags216,
	gtypes216,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets216,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names217,
	types217,
	attr_flags217,
	gtypes217,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets217,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names218,
	types218,
	attr_flags218,
	gtypes218,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets218,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names219,
	types219,
	attr_flags219,
	gtypes219,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets219,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names220,
	types220,
	attr_flags220,
	gtypes220,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets220,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names221,
	types221,
	attr_flags221,
	gtypes221,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets221,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names222,
	types222,
	attr_flags222,
	gtypes222,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets222,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names223,
	types223,
	attr_flags223,
	gtypes223,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets223,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names224,
	types224,
	attr_flags224,
	gtypes224,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets224,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names225,
	types225,
	attr_flags225,
	gtypes225,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets225,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names226,
	types226,
	attr_flags226,
	gtypes226,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets226,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names227,
	types227,
	attr_flags227,
	gtypes227,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets227,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names228,
	types228,
	attr_flags228,
	gtypes228,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets228,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names229,
	types229,
	attr_flags229,
	gtypes229,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets229,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names230,
	types230,
	attr_flags230,
	gtypes230,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets230,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names231,
	types231,
	attr_flags231,
	gtypes231,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets231,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names232,
	types232,
	attr_flags232,
	gtypes232,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets232,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names233,
	types233,
	attr_flags233,
	gtypes233,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets233,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names234,
	types234,
	attr_flags234,
	gtypes234,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets234,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names235,
	types235,
	attr_flags235,
	gtypes235,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets235,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names236,
	types236,
	attr_flags236,
	gtypes236,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets236,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names237,
	types237,
	attr_flags237,
	gtypes237,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets237,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names238,
	types238,
	attr_flags238,
	gtypes238,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets238,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names239,
	types239,
	attr_flags239,
	gtypes239,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets239,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names240,
	types240,
	attr_flags240,
	gtypes240,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets240,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names241,
	types241,
	attr_flags241,
	gtypes241,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets241,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names242,
	types242,
	attr_flags242,
	gtypes242,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets242,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names243,
	types243,
	attr_flags243,
	gtypes243,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets243,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names244,
	types244,
	attr_flags244,
	gtypes244,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets244,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names245,
	types245,
	attr_flags245,
	gtypes245,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets245,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names246,
	types246,
	attr_flags246,
	gtypes246,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets246,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names247,
	types247,
	attr_flags247,
	gtypes247,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets247,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names248,
	types248,
	attr_flags248,
	gtypes248,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets248,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names249,
	types249,
	attr_flags249,
	gtypes249,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets249,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names250,
	types250,
	attr_flags250,
	gtypes250,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets250,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_QUEUE_ITERATION_CURSOR",
	names264,
	types264,
	attr_flags264,
	gtypes264,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets264,
	NULL
},
{
	(long) 2,
	(long) 2,
	"FILE_ITERATION_CURSOR",
	names265,
	types265,
	attr_flags265,
	gtypes265,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets265,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_DIRECTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS_32",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"STRING_ITERATION_CURSOR",
	names286,
	types286,
	attr_flags286,
	gtypes286,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets286,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_ARGUMENTS",
	names288,
	types288,
	attr_flags288,
	gtypes288,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets288,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names318,
	types318,
	attr_flags318,
	gtypes318,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets318,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names319,
	types319,
	attr_flags319,
	gtypes319,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets319,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names320,
	types320,
	attr_flags320,
	gtypes320,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets320,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names321,
	types321,
	attr_flags321,
	gtypes321,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets321,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names322,
	types322,
	attr_flags322,
	gtypes322,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets322,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names323,
	types323,
	attr_flags323,
	gtypes323,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets323,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names324,
	types324,
	attr_flags324,
	gtypes324,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets324,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names325,
	types325,
	attr_flags325,
	gtypes325,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets325,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names326,
	types326,
	attr_flags326,
	gtypes326,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets326,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names327,
	types327,
	attr_flags327,
	gtypes327,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets327,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names328,
	types328,
	attr_flags328,
	gtypes328,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets328,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names329,
	types329,
	attr_flags329,
	gtypes329,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets329,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names330,
	types330,
	attr_flags330,
	gtypes330,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets330,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names331,
	types331,
	attr_flags331,
	gtypes331,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets331,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names332,
	types332,
	attr_flags332,
	gtypes332,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets332,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names333,
	types333,
	attr_flags333,
	gtypes333,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets333,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names334,
	types334,
	attr_flags334,
	gtypes334,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets334,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names335,
	types335,
	attr_flags335,
	gtypes335,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets335,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names336,
	types336,
	attr_flags336,
	gtypes336,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets336,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names337,
	types337,
	attr_flags337,
	gtypes337,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets337,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names338,
	types338,
	attr_flags338,
	gtypes338,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets338,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names339,
	types339,
	attr_flags339,
	gtypes339,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets339,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names340,
	types340,
	attr_flags340,
	gtypes340,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets340,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names341,
	types341,
	attr_flags341,
	gtypes341,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets341,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names342,
	types342,
	attr_flags342,
	gtypes342,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets342,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names343,
	types343,
	attr_flags343,
	gtypes343,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets343,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names344,
	types344,
	attr_flags344,
	gtypes344,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets344,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names345,
	types345,
	attr_flags345,
	gtypes345,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets345,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names346,
	types346,
	attr_flags346,
	gtypes346,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets346,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names347,
	types347,
	attr_flags347,
	gtypes347,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets347,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names348,
	types348,
	attr_flags348,
	gtypes348,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets348,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names349,
	types349,
	attr_flags349,
	gtypes349,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets349,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names350,
	types350,
	attr_flags350,
	gtypes350,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets350,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names351,
	types351,
	attr_flags351,
	gtypes351,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets351,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names352,
	types352,
	attr_flags352,
	gtypes352,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets352,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names353,
	types353,
	attr_flags353,
	gtypes353,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets353,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names354,
	types354,
	attr_flags354,
	gtypes354,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets354,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names355,
	types355,
	attr_flags355,
	gtypes355,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets355,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names356,
	types356,
	attr_flags356,
	gtypes356,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets356,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names357,
	types357,
	attr_flags357,
	gtypes357,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets357,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names358,
	types358,
	attr_flags358,
	gtypes358,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets358,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names359,
	types359,
	attr_flags359,
	gtypes359,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets359,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names360,
	types360,
	attr_flags360,
	gtypes360,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets360,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32_ITERATION_CURSOR",
	names361,
	types361,
	attr_flags361,
	gtypes361,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets361,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8_ITERATION_CURSOR",
	names362,
	types362,
	attr_flags362,
	gtypes362,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets362,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names363,
	types363,
	attr_flags363,
	gtypes363,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets363,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names364,
	types364,
	attr_flags364,
	gtypes364,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets364,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names365,
	types365,
	attr_flags365,
	gtypes365,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets365,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names366,
	types366,
	attr_flags366,
	gtypes366,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets366,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names367,
	types367,
	attr_flags367,
	gtypes367,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets367,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names368,
	types368,
	attr_flags368,
	gtypes368,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets368,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names369,
	types369,
	attr_flags369,
	gtypes369,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets369,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names370,
	types370,
	attr_flags370,
	gtypes370,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets370,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names371,
	types371,
	attr_flags371,
	gtypes371,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets371,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names372,
	types372,
	attr_flags372,
	gtypes372,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets372,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names373,
	types373,
	attr_flags373,
	gtypes373,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets373,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names374,
	types374,
	attr_flags374,
	gtypes374,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets374,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names375,
	types375,
	attr_flags375,
	gtypes375,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets375,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names376,
	types376,
	attr_flags376,
	gtypes376,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets376,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names377,
	types377,
	attr_flags377,
	gtypes377,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets377,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names378,
	types378,
	attr_flags378,
	gtypes378,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets378,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names379,
	types379,
	attr_flags379,
	gtypes379,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets379,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names380,
	types380,
	attr_flags380,
	gtypes380,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets380,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names381,
	types381,
	attr_flags381,
	gtypes381,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets381,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names382,
	types382,
	attr_flags382,
	gtypes382,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets382,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names383,
	types383,
	attr_flags383,
	gtypes383,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets383,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names384,
	types384,
	attr_flags384,
	gtypes384,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets384,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names385,
	types385,
	attr_flags385,
	gtypes385,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets385,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names386,
	types386,
	attr_flags386,
	gtypes386,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets386,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names387,
	types387,
	attr_flags387,
	gtypes387,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets387,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names388,
	types388,
	attr_flags388,
	gtypes388,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets388,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names389,
	types389,
	attr_flags389,
	gtypes389,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets389,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names390,
	types390,
	attr_flags390,
	gtypes390,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets390,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names391,
	types391,
	attr_flags391,
	gtypes391,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets391,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names392,
	types392,
	attr_flags392,
	gtypes392,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets392,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names393,
	types393,
	attr_flags393,
	gtypes393,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets393,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names394,
	types394,
	attr_flags394,
	gtypes394,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets394,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names395,
	types395,
	attr_flags395,
	gtypes395,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets395,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names396,
	types396,
	attr_flags396,
	gtypes396,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets396,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names397,
	types397,
	attr_flags397,
	gtypes397,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets397,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names398,
	types398,
	attr_flags398,
	gtypes398,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets398,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names399,
	types399,
	attr_flags399,
	gtypes399,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets399,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names400,
	types400,
	attr_flags400,
	gtypes400,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets400,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names401,
	types401,
	attr_flags401,
	gtypes401,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets401,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names402,
	types402,
	attr_flags402,
	gtypes402,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets402,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names403,
	types403,
	attr_flags403,
	gtypes403,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets403,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names404,
	types404,
	attr_flags404,
	gtypes404,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets404,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names405,
	types405,
	attr_flags405,
	gtypes405,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets405,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names406,
	types406,
	attr_flags406,
	gtypes406,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets406,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names407,
	types407,
	attr_flags407,
	gtypes407,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets407,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names408,
	types408,
	attr_flags408,
	gtypes408,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets408,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names409,
	types409,
	attr_flags409,
	gtypes409,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets409,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names410,
	types410,
	attr_flags410,
	gtypes410,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets410,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names411,
	types411,
	attr_flags411,
	gtypes411,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets411,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names412,
	types412,
	attr_flags412,
	gtypes412,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets412,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names413,
	types413,
	attr_flags413,
	gtypes413,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets413,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names414,
	types414,
	attr_flags414,
	gtypes414,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets414,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names415,
	types415,
	attr_flags415,
	gtypes415,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets415,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names416,
	types416,
	attr_flags416,
	gtypes416,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets416,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names417,
	types417,
	attr_flags417,
	gtypes417,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets417,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names418,
	types418,
	attr_flags418,
	gtypes418,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets418,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names419,
	types419,
	attr_flags419,
	gtypes419,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets419,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names420,
	types420,
	attr_flags420,
	gtypes420,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets420,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names421,
	types421,
	attr_flags421,
	gtypes421,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets421,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names422,
	types422,
	attr_flags422,
	gtypes422,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets422,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names423,
	types423,
	attr_flags423,
	gtypes423,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets423,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names424,
	types424,
	attr_flags424,
	gtypes424,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets424,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names425,
	types425,
	attr_flags425,
	gtypes425,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets425,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names426,
	types426,
	attr_flags426,
	gtypes426,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets426,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names427,
	types427,
	attr_flags427,
	gtypes427,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets427,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names428,
	types428,
	attr_flags428,
	gtypes428,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets428,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names429,
	types429,
	attr_flags429,
	gtypes429,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets429,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names430,
	types430,
	attr_flags430,
	gtypes430,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets430,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names431,
	types431,
	attr_flags431,
	gtypes431,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets431,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names432,
	types432,
	attr_flags432,
	gtypes432,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets432,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names433,
	types433,
	attr_flags433,
	gtypes433,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets433,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names434,
	types434,
	attr_flags434,
	gtypes434,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets434,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names435,
	types435,
	attr_flags435,
	gtypes435,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets435,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names436,
	types436,
	attr_flags436,
	gtypes436,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets436,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names437,
	types437,
	attr_flags437,
	gtypes437,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets437,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names438,
	types438,
	attr_flags438,
	gtypes438,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets438,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names439,
	types439,
	attr_flags439,
	gtypes439,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets439,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names440,
	types440,
	attr_flags440,
	gtypes440,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets440,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names441,
	types441,
	attr_flags441,
	gtypes441,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets441,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names442,
	types442,
	attr_flags442,
	gtypes442,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets442,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names443,
	types443,
	attr_flags443,
	gtypes443,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets443,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names444,
	types444,
	attr_flags444,
	gtypes444,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets444,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names445,
	types445,
	attr_flags445,
	gtypes445,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets445,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names446,
	types446,
	attr_flags446,
	gtypes446,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets446,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names447,
	types447,
	attr_flags447,
	gtypes447,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets447,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names448,
	types448,
	attr_flags448,
	gtypes448,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets448,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names449,
	types449,
	attr_flags449,
	gtypes449,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets449,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names450,
	types450,
	attr_flags450,
	gtypes450,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets450,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names451,
	types451,
	attr_flags451,
	gtypes451,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets451,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names452,
	types452,
	attr_flags452,
	gtypes452,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets452,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names453,
	types453,
	attr_flags453,
	gtypes453,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets453,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names454,
	types454,
	attr_flags454,
	gtypes454,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets454,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names455,
	types455,
	attr_flags455,
	gtypes455,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets455,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names456,
	types456,
	attr_flags456,
	gtypes456,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets456,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names457,
	types457,
	attr_flags457,
	gtypes457,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets457,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names458,
	types458,
	attr_flags458,
	gtypes458,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets458,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names459,
	types459,
	attr_flags459,
	gtypes459,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets459,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names460,
	types460,
	attr_flags460,
	gtypes460,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets460,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names461,
	types461,
	attr_flags461,
	gtypes461,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets461,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names462,
	types462,
	attr_flags462,
	gtypes462,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets462,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names463,
	types463,
	attr_flags463,
	gtypes463,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets463,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names464,
	types464,
	attr_flags464,
	gtypes464,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets464,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names465,
	types465,
	attr_flags465,
	gtypes465,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets465,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names466,
	types466,
	attr_flags466,
	gtypes466,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets466,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names467,
	types467,
	attr_flags467,
	gtypes467,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets467,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names468,
	types468,
	attr_flags468,
	gtypes468,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets468,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names469,
	types469,
	attr_flags469,
	gtypes469,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets469,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names470,
	types470,
	attr_flags470,
	gtypes470,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets470,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names471,
	types471,
	attr_flags471,
	gtypes471,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets471,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names472,
	types472,
	attr_flags472,
	gtypes472,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets472,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names473,
	types473,
	attr_flags473,
	gtypes473,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets473,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names474,
	types474,
	attr_flags474,
	gtypes474,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets474,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names475,
	types475,
	attr_flags475,
	gtypes475,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets475,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names476,
	types476,
	attr_flags476,
	gtypes476,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets476,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names477,
	types477,
	attr_flags477,
	gtypes477,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets477,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names478,
	types478,
	attr_flags478,
	gtypes478,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets478,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names479,
	types479,
	attr_flags479,
	gtypes479,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets479,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names480,
	types480,
	attr_flags480,
	gtypes480,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets480,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names481,
	types481,
	attr_flags481,
	gtypes481,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets481,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names482,
	types482,
	attr_flags482,
	gtypes482,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets482,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names483,
	types483,
	attr_flags483,
	gtypes483,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets483,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names484,
	types484,
	attr_flags484,
	gtypes484,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets484,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names485,
	types485,
	attr_flags485,
	gtypes485,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets485,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names486,
	types486,
	attr_flags486,
	gtypes486,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets486,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names487,
	types487,
	attr_flags487,
	gtypes487,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets487,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names488,
	types488,
	attr_flags488,
	gtypes488,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets488,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names489,
	types489,
	attr_flags489,
	gtypes489,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets489,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names490,
	types490,
	attr_flags490,
	gtypes490,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets490,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names491,
	types491,
	attr_flags491,
	gtypes491,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets491,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names492,
	types492,
	attr_flags492,
	gtypes492,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets492,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names493,
	types493,
	attr_flags493,
	gtypes493,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets493,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names494,
	types494,
	attr_flags494,
	gtypes494,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets494,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names495,
	types495,
	attr_flags495,
	gtypes495,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets495,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names496,
	types496,
	attr_flags496,
	gtypes496,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets496,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names497,
	types497,
	attr_flags497,
	gtypes497,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets497,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names498,
	types498,
	attr_flags498,
	gtypes498,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets498,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names499,
	types499,
	attr_flags499,
	gtypes499,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets499,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names500,
	types500,
	attr_flags500,
	gtypes500,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets500,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names501,
	types501,
	attr_flags501,
	gtypes501,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets501,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names502,
	types502,
	attr_flags502,
	gtypes502,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets502,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names503,
	types503,
	attr_flags503,
	gtypes503,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets503,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names504,
	types504,
	attr_flags504,
	gtypes504,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets504,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names505,
	types505,
	attr_flags505,
	gtypes505,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets505,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names506,
	types506,
	attr_flags506,
	gtypes506,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets506,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names507,
	types507,
	attr_flags507,
	gtypes507,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets507,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names508,
	types508,
	attr_flags508,
	gtypes508,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets508,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names509,
	types509,
	attr_flags509,
	gtypes509,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets509,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names510,
	types510,
	attr_flags510,
	gtypes510,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets510,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names511,
	types511,
	attr_flags511,
	gtypes511,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets511,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names512,
	types512,
	attr_flags512,
	gtypes512,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets512,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names513,
	types513,
	attr_flags513,
	gtypes513,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets513,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names514,
	types514,
	attr_flags514,
	gtypes514,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets514,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names515,
	types515,
	attr_flags515,
	gtypes515,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets515,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names516,
	types516,
	attr_flags516,
	gtypes516,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets516,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names517,
	types517,
	attr_flags517,
	gtypes517,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets517,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names518,
	types518,
	attr_flags518,
	gtypes518,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets518,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names519,
	types519,
	attr_flags519,
	gtypes519,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets519,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names520,
	types520,
	attr_flags520,
	gtypes520,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets520,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names521,
	types521,
	attr_flags521,
	gtypes521,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets521,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names522,
	types522,
	attr_flags522,
	gtypes522,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets522,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names523,
	types523,
	attr_flags523,
	gtypes523,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets523,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names524,
	types524,
	attr_flags524,
	gtypes524,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets524,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names525,
	types525,
	attr_flags525,
	gtypes525,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets525,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INFINITE",
	names526,
	types526,
	attr_flags526,
	gtypes526,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets526,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COUNTABLE",
	names527,
	types527,
	attr_flags527,
	gtypes527,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets527,
	NULL
},
{
	(long) 2,
	(long) 2,
	"COUNTABLE_SEQUENCE",
	names528,
	types528,
	attr_flags528,
	gtypes528,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets528,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PRIMES",
	names529,
	types529,
	attr_flags529,
	gtypes529,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets529,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names530,
	types530,
	attr_flags530,
	gtypes530,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets530,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names531,
	types531,
	attr_flags531,
	gtypes531,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets531,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names532,
	types532,
	attr_flags532,
	gtypes532,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets532,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names533,
	types533,
	attr_flags533,
	gtypes533,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets533,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names534,
	types534,
	attr_flags534,
	gtypes534,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets534,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names535,
	types535,
	attr_flags535,
	gtypes535,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets535,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names536,
	types536,
	attr_flags536,
	gtypes536,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets536,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names537,
	types537,
	attr_flags537,
	gtypes537,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets537,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names538,
	types538,
	attr_flags538,
	gtypes538,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets538,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names539,
	types539,
	attr_flags539,
	gtypes539,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets539,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names540,
	types540,
	attr_flags540,
	gtypes540,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets540,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names541,
	types541,
	attr_flags541,
	gtypes541,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets541,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names542,
	types542,
	attr_flags542,
	gtypes542,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets542,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUEUE",
	names543,
	types543,
	attr_flags543,
	gtypes543,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets543,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names544,
	types544,
	attr_flags544,
	gtypes544,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets544,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names545,
	types545,
	attr_flags545,
	gtypes545,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets545,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names546,
	types546,
	attr_flags546,
	gtypes546,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets546,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names547,
	types547,
	attr_flags547,
	gtypes547,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets547,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names548,
	types548,
	attr_flags548,
	gtypes548,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets548,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names549,
	types549,
	attr_flags549,
	gtypes549,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets549,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names550,
	types550,
	attr_flags550,
	gtypes550,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets550,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names551,
	types551,
	attr_flags551,
	gtypes551,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets551,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names552,
	types552,
	attr_flags552,
	gtypes552,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets552,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names553,
	types553,
	attr_flags553,
	gtypes553,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets553,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names554,
	types554,
	attr_flags554,
	gtypes554,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets554,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names555,
	types555,
	attr_flags555,
	gtypes555,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets555,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names556,
	types556,
	attr_flags556,
	gtypes556,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets556,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names557,
	types557,
	attr_flags557,
	gtypes557,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets557,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names558,
	types558,
	attr_flags558,
	gtypes558,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets558,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names559,
	types559,
	attr_flags559,
	gtypes559,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets559,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names560,
	types560,
	attr_flags560,
	gtypes560,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets560,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names561,
	types561,
	attr_flags561,
	gtypes561,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets561,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names562,
	types562,
	attr_flags562,
	gtypes562,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets562,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names563,
	types563,
	attr_flags563,
	gtypes563,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets563,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names564,
	types564,
	attr_flags564,
	gtypes564,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets564,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names565,
	types565,
	attr_flags565,
	gtypes565,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets565,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names566,
	types566,
	attr_flags566,
	gtypes566,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets566,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names567,
	types567,
	attr_flags567,
	gtypes567,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets567,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names568,
	types568,
	attr_flags568,
	gtypes568,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets568,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names569,
	types569,
	attr_flags569,
	gtypes569,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets569,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names570,
	types570,
	attr_flags570,
	gtypes570,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets570,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names571,
	types571,
	attr_flags571,
	gtypes571,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets571,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names572,
	types572,
	attr_flags572,
	gtypes572,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets572,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names573,
	types573,
	attr_flags573,
	gtypes573,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets573,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names574,
	types574,
	attr_flags574,
	gtypes574,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets574,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names575,
	types575,
	attr_flags575,
	gtypes575,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets575,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names576,
	types576,
	attr_flags576,
	gtypes576,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets576,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names577,
	types577,
	attr_flags577,
	gtypes577,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets577,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names578,
	types578,
	attr_flags578,
	gtypes578,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets578,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names579,
	types579,
	attr_flags579,
	gtypes579,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets579,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names580,
	types580,
	attr_flags580,
	gtypes580,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets580,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names581,
	types581,
	attr_flags581,
	gtypes581,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets581,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names582,
	types582,
	attr_flags582,
	gtypes582,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets582,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names583,
	types583,
	attr_flags583,
	gtypes583,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets583,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names584,
	types584,
	attr_flags584,
	gtypes584,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets584,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names585,
	types585,
	attr_flags585,
	gtypes585,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets585,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names586,
	types586,
	attr_flags586,
	gtypes586,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets586,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names587,
	types587,
	attr_flags587,
	gtypes587,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets587,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names588,
	types588,
	attr_flags588,
	gtypes588,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets588,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names589,
	types589,
	attr_flags589,
	gtypes589,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets589,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names590,
	types590,
	attr_flags590,
	gtypes590,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets590,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names591,
	types591,
	attr_flags591,
	gtypes591,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets591,
	NULL
},
{
	(long) 20,
	(long) 19,
	"FILE",
	names592,
	types592,
	attr_flags592,
	gtypes592,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets592,
	NULL
},
{
	(long) 21,
	(long) 20,
	"RAW_FILE",
	names593,
	types593,
	attr_flags593,
	gtypes593,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets593,
	NULL
},
{
	(long) 23,
	(long) 22,
	"PLAIN_TEXT_FILE",
	names594,
	types594,
	attr_flags594,
	gtypes594,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets594,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names619,
	types619,
	attr_flags619,
	gtypes619,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets619,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names620,
	types620,
	attr_flags620,
	gtypes620,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets620,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names621,
	types621,
	attr_flags621,
	gtypes621,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets621,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names622,
	types622,
	attr_flags622,
	gtypes622,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets622,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names623,
	types623,
	attr_flags623,
	gtypes623,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets623,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names624,
	types624,
	attr_flags624,
	gtypes624,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets624,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names625,
	types625,
	attr_flags625,
	gtypes625,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets625,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names626,
	types626,
	attr_flags626,
	gtypes626,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets626,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names627,
	types627,
	attr_flags627,
	gtypes627,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets627,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names628,
	types628,
	attr_flags628,
	gtypes628,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets628,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names629,
	types629,
	attr_flags629,
	gtypes629,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets629,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names630,
	types630,
	attr_flags630,
	gtypes630,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets630,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INTEGER_INTERVAL",
	names631,
	types631,
	attr_flags631,
	gtypes631,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets631,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names632,
	types632,
	attr_flags632,
	gtypes632,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets632,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names633,
	types633,
	attr_flags633,
	gtypes633,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets633,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names634,
	types634,
	attr_flags634,
	gtypes634,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets634,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names635,
	types635,
	attr_flags635,
	gtypes635,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets635,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names636,
	types636,
	attr_flags636,
	gtypes636,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets636,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names637,
	types637,
	attr_flags637,
	gtypes637,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets637,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names638,
	types638,
	attr_flags638,
	gtypes638,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets638,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names639,
	types639,
	attr_flags639,
	gtypes639,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets639,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names640,
	types640,
	attr_flags640,
	gtypes640,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets640,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names641,
	types641,
	attr_flags641,
	gtypes641,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets641,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names642,
	types642,
	attr_flags642,
	gtypes642,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets642,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names643,
	types643,
	attr_flags643,
	gtypes643,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets643,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names644,
	types644,
	attr_flags644,
	gtypes644,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets644,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names645,
	types645,
	attr_flags645,
	gtypes645,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets645,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names646,
	types646,
	attr_flags646,
	gtypes646,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets646,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names647,
	types647,
	attr_flags647,
	gtypes647,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets647,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names648,
	types648,
	attr_flags648,
	gtypes648,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets648,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names649,
	types649,
	attr_flags649,
	gtypes649,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets649,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names650,
	types650,
	attr_flags650,
	gtypes650,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets650,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names651,
	types651,
	attr_flags651,
	gtypes651,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets651,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names652,
	types652,
	attr_flags652,
	gtypes652,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets652,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names653,
	types653,
	attr_flags653,
	gtypes653,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets653,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names654,
	types654,
	attr_flags654,
	gtypes654,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets654,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names655,
	types655,
	attr_flags655,
	gtypes655,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets655,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names656,
	types656,
	attr_flags656,
	gtypes656,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets656,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names657,
	types657,
	attr_flags657,
	gtypes657,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets657,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names658,
	types658,
	attr_flags658,
	gtypes658,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets658,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names659,
	types659,
	attr_flags659,
	gtypes659,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets659,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names660,
	types660,
	attr_flags660,
	gtypes660,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets660,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names661,
	types661,
	attr_flags661,
	gtypes661,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets661,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names662,
	types662,
	attr_flags662,
	gtypes662,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets662,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names663,
	types663,
	attr_flags663,
	gtypes663,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets663,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names664,
	types664,
	attr_flags664,
	gtypes664,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets664,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names665,
	types665,
	attr_flags665,
	gtypes665,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets665,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names666,
	types666,
	attr_flags666,
	gtypes666,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets666,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names667,
	types667,
	attr_flags667,
	gtypes667,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets667,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names668,
	types668,
	attr_flags668,
	gtypes668,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets668,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names669,
	types669,
	attr_flags669,
	gtypes669,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets669,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names670,
	types670,
	attr_flags670,
	gtypes670,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets670,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names671,
	types671,
	attr_flags671,
	gtypes671,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets671,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names672,
	types672,
	attr_flags672,
	gtypes672,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets672,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names673,
	types673,
	attr_flags673,
	gtypes673,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets673,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names674,
	types674,
	attr_flags674,
	gtypes674,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets674,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names675,
	types675,
	attr_flags675,
	gtypes675,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets675,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names676,
	types676,
	attr_flags676,
	gtypes676,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets676,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names677,
	types677,
	attr_flags677,
	gtypes677,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets677,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names678,
	types678,
	attr_flags678,
	gtypes678,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets678,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names679,
	types679,
	attr_flags679,
	gtypes679,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets679,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names680,
	types680,
	attr_flags680,
	gtypes680,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets680,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names681,
	types681,
	attr_flags681,
	gtypes681,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets681,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names682,
	types682,
	attr_flags682,
	gtypes682,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets682,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names683,
	types683,
	attr_flags683,
	gtypes683,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets683,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names684,
	types684,
	attr_flags684,
	gtypes684,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets684,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names685,
	types685,
	attr_flags685,
	gtypes685,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets685,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names686,
	types686,
	attr_flags686,
	gtypes686,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets686,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names687,
	types687,
	attr_flags687,
	gtypes687,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets687,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names688,
	types688,
	attr_flags688,
	gtypes688,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets688,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names689,
	types689,
	attr_flags689,
	gtypes689,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets689,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names690,
	types690,
	attr_flags690,
	gtypes690,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets690,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names691,
	types691,
	attr_flags691,
	gtypes691,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets691,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names692,
	types692,
	attr_flags692,
	gtypes692,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets692,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names693,
	types693,
	attr_flags693,
	gtypes693,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets693,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names694,
	types694,
	attr_flags694,
	gtypes694,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets694,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names695,
	types695,
	attr_flags695,
	gtypes695,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets695,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names696,
	types696,
	attr_flags696,
	gtypes696,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets696,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names697,
	types697,
	attr_flags697,
	gtypes697,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets697,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names698,
	types698,
	attr_flags698,
	gtypes698,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets698,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MISMATCH_CORRECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_QUEUE",
	names701,
	types701,
	attr_flags701,
	gtypes701,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets701,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names702,
	types702,
	attr_flags702,
	gtypes702,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets702,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names703,
	types703,
	attr_flags703,
	gtypes703,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets703,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names704,
	types704,
	attr_flags704,
	gtypes704,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets704,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names705,
	types705,
	attr_flags705,
	gtypes705,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets705,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names706,
	types706,
	attr_flags706,
	gtypes706,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets706,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names707,
	types707,
	attr_flags707,
	gtypes707,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets707,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names708,
	types708,
	attr_flags708,
	gtypes708,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets708,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names709,
	types709,
	attr_flags709,
	gtypes709,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets709,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names710,
	types710,
	attr_flags710,
	gtypes710,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets710,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names711,
	types711,
	attr_flags711,
	gtypes711,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets711,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names712,
	types712,
	attr_flags712,
	gtypes712,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets712,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names713,
	types713,
	attr_flags713,
	gtypes713,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets713,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names714,
	types714,
	attr_flags714,
	gtypes714,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets714,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names715,
	types715,
	attr_flags715,
	gtypes715,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets715,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names716,
	types716,
	attr_flags716,
	gtypes716,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets716,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names717,
	types717,
	attr_flags717,
	gtypes717,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets717,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names718,
	types718,
	attr_flags718,
	gtypes718,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets718,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names719,
	types719,
	attr_flags719,
	gtypes719,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets719,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names720,
	types720,
	attr_flags720,
	gtypes720,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets720,
	NULL
},
{
	(long) 19,
	(long) 19,
	"MISMATCH_INFORMATION",
	names721,
	types721,
	attr_flags721,
	gtypes721,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets721,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CASE_INSENSITIVE_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDERR_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDOUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_NULL_TEXT_OUTPUT_STREAM",
	names731,
	types731,
	attr_flags731,
	gtypes731,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets731,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EXECUTION_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_STDIN_FILE",
	names748,
	types748,
	attr_flags748,
	gtypes748,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets748,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING_INPUT_STREAM",
	names749,
	types749,
	attr_flags749,
	gtypes749,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets749,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UC_CHARACTER",
	names754,
	types754,
	attr_flags754,
	gtypes754,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets754,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PATH",
	names755,
	types755,
	attr_flags755,
	gtypes755,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets755,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names756,
	types756,
	attr_flags756,
	gtypes756,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets756,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names757,
	types757,
	attr_flags757,
	gtypes757,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets757,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names758,
	types758,
	attr_flags758,
	gtypes758,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets758,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names759,
	types759,
	attr_flags759,
	gtypes759,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets759,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names760,
	types760,
	attr_flags760,
	gtypes760,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets760,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names761,
	types761,
	attr_flags761,
	gtypes761,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets761,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names762,
	types762,
	attr_flags762,
	gtypes762,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets762,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names763,
	types763,
	attr_flags763,
	gtypes763,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets763,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names764,
	types764,
	attr_flags764,
	gtypes764,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets764,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names765,
	types765,
	attr_flags765,
	gtypes765,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets765,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names766,
	types766,
	attr_flags766,
	gtypes766,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets766,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names767,
	types767,
	attr_flags767,
	gtypes767,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets767,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names768,
	types768,
	attr_flags768,
	gtypes768,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets768,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names769,
	types769,
	attr_flags769,
	gtypes769,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets769,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names770,
	types770,
	attr_flags770,
	gtypes770,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets770,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names771,
	types771,
	attr_flags771,
	gtypes771,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets771,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names772,
	types772,
	attr_flags772,
	gtypes772,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets772,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names773,
	types773,
	attr_flags773,
	gtypes773,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets773,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names774,
	types774,
	attr_flags774,
	gtypes774,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets774,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names775,
	types775,
	attr_flags775,
	gtypes775,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets775,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names776,
	types776,
	attr_flags776,
	gtypes776,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets776,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names777,
	types777,
	attr_flags777,
	gtypes777,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets777,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names778,
	types778,
	attr_flags778,
	gtypes778,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets778,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names779,
	types779,
	attr_flags779,
	gtypes779,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets779,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names780,
	types780,
	attr_flags780,
	gtypes780,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets780,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names781,
	types781,
	attr_flags781,
	gtypes781,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets781,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names782,
	types782,
	attr_flags782,
	gtypes782,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets782,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names783,
	types783,
	attr_flags783,
	gtypes783,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets783,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names784,
	types784,
	attr_flags784,
	gtypes784,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets784,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names785,
	types785,
	attr_flags785,
	gtypes785,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets785,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names786,
	types786,
	attr_flags786,
	gtypes786,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets786,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TUPLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32_REF",
	names788,
	types788,
	attr_flags788,
	gtypes788,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets788,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names789,
	types789,
	attr_flags789,
	gtypes789,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets789,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names790,
	types790,
	attr_flags790,
	gtypes790,
	(uint16) 0x2308,
	(void (*)()) 0,
	offsets790,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16_REF",
	names791,
	types791,
	attr_flags791,
	gtypes791,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets791,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names792,
	types792,
	attr_flags792,
	gtypes792,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets792,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names793,
	types793,
	attr_flags793,
	gtypes793,
	(uint16) 0x2307,
	(void (*)()) 0,
	offsets793,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8_REF",
	names794,
	types794,
	attr_flags794,
	gtypes794,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets794,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names795,
	types795,
	attr_flags795,
	gtypes795,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets795,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names796,
	types796,
	attr_flags796,
	gtypes796,
	(uint16) 0x2306,
	(void (*)()) 0,
	offsets796,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64_REF",
	names797,
	types797,
	attr_flags797,
	gtypes797,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets797,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names798,
	types798,
	attr_flags798,
	gtypes798,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets798,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names799,
	types799,
	attr_flags799,
	gtypes799,
	(uint16) 0x230D,
	(void (*)()) 0,
	offsets799,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32_REF",
	names800,
	types800,
	attr_flags800,
	gtypes800,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets800,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names801,
	types801,
	attr_flags801,
	gtypes801,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets801,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names802,
	types802,
	attr_flags802,
	gtypes802,
	(uint16) 0x230C,
	(void (*)()) 0,
	offsets802,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16_REF",
	names803,
	types803,
	attr_flags803,
	gtypes803,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets803,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names804,
	types804,
	attr_flags804,
	gtypes804,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets804,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names805,
	types805,
	attr_flags805,
	gtypes805,
	(uint16) 0x230B,
	(void (*)()) 0,
	offsets805,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8_REF",
	names806,
	types806,
	attr_flags806,
	gtypes806,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets806,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names807,
	types807,
	attr_flags807,
	gtypes807,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets807,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names808,
	types808,
	attr_flags808,
	gtypes808,
	(uint16) 0x230A,
	(void (*)()) 0,
	offsets808,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32_REF",
	names809,
	types809,
	attr_flags809,
	gtypes809,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets809,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names810,
	types810,
	attr_flags810,
	gtypes810,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets810,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names811,
	types811,
	attr_flags811,
	gtypes811,
	(uint16) 0x2304,
	(void (*)()) 0,
	offsets811,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64_REF",
	names812,
	types812,
	attr_flags812,
	gtypes812,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets812,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names813,
	types813,
	attr_flags813,
	gtypes813,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets813,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names814,
	types814,
	attr_flags814,
	gtypes814,
	(uint16) 0x2303,
	(void (*)()) 0,
	offsets814,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32_REF",
	names815,
	types815,
	attr_flags815,
	gtypes815,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets815,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names816,
	types816,
	attr_flags816,
	gtypes816,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets816,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names817,
	types817,
	attr_flags817,
	gtypes817,
	(uint16) 0x230E,
	(void (*)()) 0,
	offsets817,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8_REF",
	names818,
	types818,
	attr_flags818,
	gtypes818,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets818,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names819,
	types819,
	attr_flags819,
	gtypes819,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets819,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names820,
	types820,
	attr_flags820,
	gtypes820,
	(uint16) 0x2302,
	(void (*)()) 0,
	offsets820,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN_REF",
	names821,
	types821,
	attr_flags821,
	gtypes821,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets821,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names822,
	types822,
	attr_flags822,
	gtypes822,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets822,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names823,
	types823,
	attr_flags823,
	gtypes823,
	(uint16) 0x2301,
	(void (*)()) 0,
	offsets823,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64_REF",
	names824,
	types824,
	attr_flags824,
	gtypes824,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets824,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names825,
	types825,
	attr_flags825,
	gtypes825,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets825,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names826,
	types826,
	attr_flags826,
	gtypes826,
	(uint16) 0x2309,
	(void (*)()) 0,
	offsets826,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER_REF",
	names827,
	types827,
	attr_flags827,
	gtypes827,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets827,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names828,
	types828,
	attr_flags828,
	gtypes828,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets828,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names829,
	types829,
	attr_flags829,
	gtypes829,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets829,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names830,
	types830,
	attr_flags830,
	gtypes830,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets830,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names831,
	types831,
	attr_flags831,
	gtypes831,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets831,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names832,
	types832,
	attr_flags832,
	gtypes832,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets832,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names833,
	types833,
	attr_flags833,
	gtypes833,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets833,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names834,
	types834,
	attr_flags834,
	gtypes834,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets834,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names835,
	types835,
	attr_flags835,
	gtypes835,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets835,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names836,
	types836,
	attr_flags836,
	gtypes836,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets836,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names837,
	types837,
	attr_flags837,
	gtypes837,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets837,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names838,
	types838,
	attr_flags838,
	gtypes838,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets838,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names839,
	types839,
	attr_flags839,
	gtypes839,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets839,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names840,
	types840,
	attr_flags840,
	gtypes840,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets840,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names841,
	types841,
	attr_flags841,
	gtypes841,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets841,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names842,
	types842,
	attr_flags842,
	gtypes842,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets842,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names843,
	types843,
	attr_flags843,
	gtypes843,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets843,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names844,
	types844,
	attr_flags844,
	gtypes844,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets844,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names845,
	types845,
	attr_flags845,
	gtypes845,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets845,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names846,
	types846,
	attr_flags846,
	gtypes846,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets846,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names847,
	types847,
	attr_flags847,
	gtypes847,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets847,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names848,
	types848,
	attr_flags848,
	gtypes848,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets848,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names849,
	types849,
	attr_flags849,
	gtypes849,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets849,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names850,
	types850,
	attr_flags850,
	gtypes850,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets850,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names851,
	types851,
	attr_flags851,
	gtypes851,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets851,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names852,
	types852,
	attr_flags852,
	gtypes852,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets852,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names853,
	types853,
	attr_flags853,
	gtypes853,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets853,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names854,
	types854,
	attr_flags854,
	gtypes854,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets854,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names855,
	types855,
	attr_flags855,
	gtypes855,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets855,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names856,
	types856,
	attr_flags856,
	gtypes856,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets856,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names857,
	types857,
	attr_flags857,
	gtypes857,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets857,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names858,
	types858,
	attr_flags858,
	gtypes858,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets858,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names859,
	types859,
	attr_flags859,
	gtypes859,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets859,
	NULL
},
{
	(long) 12,
	(long) 12,
	"ROUTINE",
	names860,
	types860,
	attr_flags860,
	gtypes860,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets860,
	NULL
},
{
	(long) 12,
	(long) 12,
	"PROCEDURE",
	names861,
	types861,
	attr_flags861,
	gtypes861,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets861,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names862,
	types862,
	attr_flags862,
	gtypes862,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets862,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names863,
	types863,
	attr_flags863,
	gtypes863,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets863,
	NULL
},
{
	(long) 13,
	(long) 13,
	"PREDICATE",
	names864,
	types864,
	attr_flags864,
	gtypes864,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets864,
	NULL
},
{
	(long) 2,
	(long) 2,
	"READABLE_STRING_GENERAL",
	names865,
	types865,
	attr_flags865,
	gtypes865,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets865,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IMMUTABLE_STRING_GENERAL",
	names866,
	types866,
	attr_flags866,
	gtypes866,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets866,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_GENERAL",
	names867,
	types867,
	attr_flags867,
	gtypes867,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets867,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_32",
	names868,
	types868,
	attr_flags868,
	gtypes868,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets868,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_32",
	names869,
	types869,
	attr_flags869,
	gtypes869,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets869,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32",
	names870,
	types870,
	attr_flags870,
	gtypes870,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets870,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_8",
	names871,
	types871,
	attr_flags871,
	gtypes871,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets871,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_8",
	names872,
	types872,
	attr_flags872,
	gtypes872,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets872,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8",
	names873,
	types873,
	attr_flags873,
	gtypes873,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets873,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING",
	names874,
	types874,
	attr_flags874,
	gtypes874,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets874,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 23,
	(long) 22,
	"CONSOLE",
	names880,
	types880,
	attr_flags880,
	gtypes880,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets880,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_TITLECASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_UPPERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_LOWERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"YY_SCANNER",
	names886,
	types886,
	attr_flags886,
	gtypes886,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets886,
	NULL
},
{
	(long) 22,
	(long) 22,
	"YY_SCANNER_SKELETON",
	names887,
	types887,
	attr_flags887,
	gtypes887,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets887,
	NULL
},
{
	(long) 38,
	(long) 38,
	"YY_COMPRESSED_SCANNER_SKELETON",
	names888,
	types888,
	attr_flags888,
	gtypes888,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets888,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CLONABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names890,
	types890,
	attr_flags890,
	gtypes890,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets890,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names891,
	types891,
	attr_flags891,
	gtypes891,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets891,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names892,
	types892,
	attr_flags892,
	gtypes892,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets892,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names893,
	types893,
	attr_flags893,
	gtypes893,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets893,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names894,
	types894,
	attr_flags894,
	gtypes894,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets894,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names895,
	types895,
	attr_flags895,
	gtypes895,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets895,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names896,
	types896,
	attr_flags896,
	gtypes896,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets896,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names897,
	types897,
	attr_flags897,
	gtypes897,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets897,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names898,
	types898,
	attr_flags898,
	gtypes898,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets898,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names899,
	types899,
	attr_flags899,
	gtypes899,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets899,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names900,
	types900,
	attr_flags900,
	gtypes900,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets900,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names901,
	types901,
	attr_flags901,
	gtypes901,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets901,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"ENCODING_I",
	names902,
	types902,
	attr_flags902,
	gtypes902,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets902,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_IMP",
	names903,
	types903,
	attr_flags903,
	gtypes903,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets903,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UNICODE_CONVERSION",
	names904,
	types904,
	attr_flags904,
	gtypes904,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets904,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 11,
	(long) 11,
	"KL_DIRECTORY",
	names906,
	types906,
	attr_flags906,
	gtypes906,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets906,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_FILE",
	names907,
	types907,
	attr_flags907,
	gtypes907,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets907,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_OUTPUT_FILE",
	names908,
	types908,
	attr_flags908,
	gtypes908,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets908,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_TEXT_OUTPUT_FILE",
	names909,
	types909,
	attr_flags909,
	gtypes909,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets909,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_BINARY_OUTPUT_FILE",
	names910,
	types910,
	attr_flags910,
	gtypes910,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets910,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_UNIX_OUTPUT_FILE",
	names911,
	types911,
	attr_flags911,
	gtypes911,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets911,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_WINDOWS_OUTPUT_FILE",
	names912,
	types912,
	attr_flags912,
	gtypes912,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets912,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_INPUT_FILE",
	names913,
	types913,
	attr_flags913,
	gtypes913,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets913,
	NULL
},
{
	(long) 26,
	(long) 25,
	"KL_TEXT_INPUT_FILE",
	names914,
	types914,
	attr_flags914,
	gtypes914,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets914,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_BINARY_INPUT_FILE",
	names915,
	types915,
	attr_flags915,
	gtypes915,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets915,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_UNIX_INPUT_FILE",
	names916,
	types916,
	attr_flags916,
	gtypes916,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets916,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_WINDOWS_INPUT_FILE",
	names917,
	types917,
	attr_flags917,
	gtypes917,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets917,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names923,
	types923,
	attr_flags923,
	gtypes923,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets923,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names924,
	types924,
	attr_flags924,
	gtypes924,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets924,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names925,
	types925,
	attr_flags925,
	gtypes925,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets925,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names926,
	types926,
	attr_flags926,
	gtypes926,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets926,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DISPENSER",
	names927,
	types927,
	attr_flags927,
	gtypes927,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets927,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DISPENSER",
	names928,
	types928,
	attr_flags928,
	gtypes928,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets928,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_STACK",
	names929,
	types929,
	attr_flags929,
	gtypes929,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets929,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_STACK",
	names930,
	types930,
	attr_flags930,
	gtypes930,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets930,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names931,
	types931,
	attr_flags931,
	gtypes931,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets931,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names932,
	types932,
	attr_flags932,
	gtypes932,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets932,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names933,
	types933,
	attr_flags933,
	gtypes933,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets933,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names934,
	types934,
	attr_flags934,
	gtypes934,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets934,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names935,
	types935,
	attr_flags935,
	gtypes935,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets935,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_ARRAYED_STACK",
	names938,
	types938,
	attr_flags938,
	gtypes938,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets938,
	"20130823"
},
{
	(long) 5,
	(long) 5,
	"DS_ARRAYED_STACK",
	names939,
	types939,
	attr_flags939,
	gtypes939,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets939,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names940,
	types940,
	attr_flags940,
	gtypes940,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets940,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names941,
	types941,
	attr_flags941,
	gtypes941,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets941,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names942,
	types942,
	attr_flags942,
	gtypes942,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets942,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names943,
	types943,
	attr_flags943,
	gtypes943,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets943,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"RT_DBG_EXECUTION_RECORDER",
	names944,
	types944,
	attr_flags944,
	gtypes944,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets944,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UT_ERROR_HANDLER",
	names945,
	types945,
	attr_flags945,
	gtypes945,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets945,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_UNIX_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER_TOKENS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEPP_TOKENS",
	names953,
	types953,
	attr_flags953,
	gtypes953,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets953,
	NULL
},
{
	(long) 43,
	(long) 43,
	"GEPP_SCANNER",
	names954,
	types954,
	attr_flags954,
	gtypes954,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets954,
	NULL
},
{
	(long) 23,
	(long) 23,
	"YY_PARSER_SKELETON",
	names955,
	types955,
	attr_flags955,
	gtypes955,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets955,
	NULL
},
{
	(long) 85,
	(long) 85,
	"GEPP_PARSER",
	names956,
	types956,
	attr_flags956,
	gtypes956,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets956,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_ERROR",
	names957,
	types957,
	attr_flags957,
	gtypes957,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets957,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_SYNTAX_ERROR",
	names958,
	types958,
	attr_flags958,
	gtypes958,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets958,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_MESSAGE",
	names959,
	types959,
	attr_flags959,
	gtypes959,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets959,
	NULL
},
{
	(long) 1,
	(long) 1,
	"GEPP_TOO_MANY_INCLUDES_ERROR",
	names960,
	types960,
	attr_flags960,
	gtypes960,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets960,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_CANNOT_WRITE_TO_FILE_ERROR",
	names961,
	types961,
	attr_flags961,
	gtypes961,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets961,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_VERSION_NUMBER",
	names962,
	types962,
	attr_flags962,
	gtypes962,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets962,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_CANNOT_READ_FILE_ERROR",
	names963,
	types963,
	attr_flags963,
	gtypes963,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets963,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_USAGE_MESSAGE",
	names964,
	types964,
	attr_flags964,
	gtypes964,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets964,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PATHNAME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"KL_PATHNAME",
	names966,
	types966,
	attr_flags966,
	gtypes966,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets966,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_STRING",
	names967,
	types967,
	attr_flags967,
	gtypes967,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets967,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_UTF8_STRING",
	names968,
	types968,
	attr_flags968,
	gtypes968,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets968,
	NULL
},};


#ifdef __cplusplus
}
#endif
