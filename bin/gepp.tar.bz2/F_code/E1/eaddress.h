#include "eif_eiffel.h"
#include "eif_rout_obj.h"

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F534_2559(EIF_REFERENCE);
extern void F714_3335(EIF_REFERENCE);
extern void F721_3408(EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER);
extern void F721_3409(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);

#ifdef __cplusplus
}
#endif
