/*
 * Code for class KL_GOBO_VERSION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl42.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_GOBO_VERSION}.version_number */

EIF_REFERENCE F67_756 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (756,RTMS_EX_H("19.11.03.1",10,17908785));
}

void EIF_Minit42 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
