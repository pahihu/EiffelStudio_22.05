/*
 * Code for class KL_STANDARD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl11.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STANDARD_FILES}.input */
static EIF_REFERENCE F12_230_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (230);
#define Result RTOSR(230)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(747, 0x01).id, 747, _OBJSIZ_2_2_0_0_0_0_0_0_);
	F748_3644(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (230);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F12_230 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(230,F12_230_body,(Current));
}

/* {KL_STANDARD_FILES}.output */
static EIF_REFERENCE F12_231_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (231);
#define Result RTOSR(231)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(729, 0x01).id, 729, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (231);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F12_231 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(231,F12_231_body,(Current));
}

/* {KL_STANDARD_FILES}.error */
static EIF_REFERENCE F12_232_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (232);
#define Result RTOSR(232)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(728, 0x01).id, 728, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (232);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F12_232 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(232,F12_232_body,(Current));
}

void EIF_Minit11 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
