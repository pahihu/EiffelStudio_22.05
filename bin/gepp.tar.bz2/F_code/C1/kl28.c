/*
 * Code for class KL_SHARED_PLATFORM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl28.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_PLATFORM}.platform */
static EIF_REFERENCE F46_556_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (556);
#define Result RTOSR(556)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(106, 0x01).id, 106, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (556);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F46_556 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(556,F46_556_body,(Current));
}

void EIF_Minit28 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
