
#ifndef _C1_uc19_
#define _C1_uc19_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,522)
static EIF_REFERENCE F37_522_body(EIF_REFERENCE);
extern EIF_REFERENCE F37_522(EIF_REFERENCE);
extern void EIF_Minit19(void);

#ifdef __cplusplus
}
#endif

#endif
