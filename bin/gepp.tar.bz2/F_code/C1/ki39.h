
#ifndef _C1_ki39_
#define _C1_ki39_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F64_726(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F64_733(EIF_REFERENCE);
extern void F64_737(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit39(void);
extern void F199_1983(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_CHARACTER_8 F199_1973(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
