
#ifndef _C1_kl26_
#define _C1_kl26_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,555)
static EIF_REFERENCE F44_555_body(EIF_REFERENCE);
extern EIF_REFERENCE F44_555(EIF_REFERENCE);
extern void EIF_Minit26(void);

#ifdef __cplusplus
}
#endif

#endif
