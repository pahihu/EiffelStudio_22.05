
#ifndef _C1_kl42_
#define _C1_kl42_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 756)


extern EIF_REFERENCE F67_756(EIF_REFERENCE);
extern void EIF_Minit42(void);

#ifdef __cplusplus
}
#endif

#endif
