
#ifndef _C1_kl44_
#define _C1_kl44_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,757)
static EIF_REFERENCE F69_757_body(EIF_REFERENCE);
extern EIF_REFERENCE F69_757(EIF_REFERENCE);
extern void EIF_Minit44(void);

#ifdef __cplusplus
}
#endif

#endif
