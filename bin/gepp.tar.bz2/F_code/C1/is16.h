
#ifndef _C1_is16_
#define _C1_is16_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F22_326(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F22_331(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F22_333(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F22_341(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit16(void);

#ifdef __cplusplus
}
#endif

#endif
