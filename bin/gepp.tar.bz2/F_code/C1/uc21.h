
#ifndef _C1_uc21_
#define _C1_uc21_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,526)
static EIF_REFERENCE F39_526_body(EIF_REFERENCE);
extern EIF_REFERENCE F39_526(EIF_REFERENCE);
extern void EIF_Minit21(void);

#ifdef __cplusplus
}
#endif

#endif
