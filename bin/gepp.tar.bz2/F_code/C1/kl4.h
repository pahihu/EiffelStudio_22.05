
#ifndef _C1_kl4_
#define _C1_kl4_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F4_52(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit4(void);

#ifdef __cplusplus
}
#endif

#endif
