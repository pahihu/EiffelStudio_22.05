/*
 * Code for class KL_SHARED_EXECUTION_ENVIRONMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl44.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_EXECUTION_ENVIRONMENT}.execution_environment */
static EIF_REFERENCE F69_757_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (757);
#define Result RTOSR(757)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(744, 0x01).id, 744, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (757);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F69_757 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(757,F69_757_body,(Current));
}

void EIF_Minit44 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
