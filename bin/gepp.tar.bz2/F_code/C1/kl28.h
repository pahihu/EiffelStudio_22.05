
#ifndef _C1_kl28_
#define _C1_kl28_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,556)
static EIF_REFERENCE F46_556_body(EIF_REFERENCE);
extern EIF_REFERENCE F46_556(EIF_REFERENCE);
extern void EIF_Minit28(void);

#ifdef __cplusplus
}
#endif

#endif
