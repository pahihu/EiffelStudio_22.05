
#ifndef _C1_kl48_
#define _C1_kl48_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,835)
static EIF_REFERENCE F79_835_body(EIF_REFERENCE);
extern EIF_REFERENCE F79_835(EIF_REFERENCE);
extern void EIF_Minit48(void);

#ifdef __cplusplus
}
#endif

#endif
