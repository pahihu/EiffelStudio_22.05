
#ifndef _C1_do36_
#define _C1_do36_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F59_688(EIF_REFERENCE, EIF_REAL_64);
extern void EIF_Minit36(void);

#ifdef __cplusplus
}
#endif

#endif
