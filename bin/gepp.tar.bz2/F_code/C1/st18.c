/*
 * Code for class STD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st18.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STD_FILES}.input */
static EIF_REFERENCE F36_442_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (442);
#define Result RTOSR(442)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(879, 0x01).id, 879, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdin",5,1953620846);
	F880_5485(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (442);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F36_442 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(442,F36_442_body,(Current));
}

/* {STD_FILES}.output */
static EIF_REFERENCE F36_443_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (443);
#define Result RTOSR(443)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(879, 0x01).id, 879, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdout",6,1912016244);
	F880_5486(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (443);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F36_443 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(443,F36_443_body,(Current));
}

/* {STD_FILES}.error */
static EIF_REFERENCE F36_444_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (444);
#define Result RTOSR(444)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(879, 0x01).id, 879, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stderr",6,1911360114);
	F880_5487(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (444);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F36_444 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(444,F36_444_body,(Current));
}

/* {STD_FILES}.set_output_default */
void F36_470 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(443,F36_443, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit18 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
