/*
 * Code for class UT_USAGE_MESSAGE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut302.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_USAGE_MESSAGE}.make */
void F964_6849 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,631,0xFF01,872,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(6830,F957_6830, (Current));
	F632_3025(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	F632_3049(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {UT_USAGE_MESSAGE}.default_template */

EIF_REFERENCE F964_6850 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6850,RTMS_EX_H("usage: $0 $1",12,1389030705));
}

void EIF_Minit302 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
