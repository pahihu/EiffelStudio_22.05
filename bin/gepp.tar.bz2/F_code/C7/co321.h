
#ifndef _C7_co321_
#define _C7_co321_

#ifdef __cplusplus
extern "C" {
#endif

extern void F387_2461(EIF_REFERENCE);
extern void EIF_Minit321(void);
extern long O2178[];

#ifdef __cplusplus
}
#endif

#endif
