/*
 * Code for class KL_PATHNAME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl304.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_PATHNAME}.make */
void F966_6868 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,631,872,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F632_3025(RTCW(tr1), NULL, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {KL_PATHNAME}.is_relative */
EIF_BOOLEAN F966_6869 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_);
}


/* {KL_PATHNAME}.is_current */
EIF_BOOLEAN F966_6870 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = F966_6872(Current, arg1);
	tr2 = RTOSCF(6889,F966_6889, (Current));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == tr2);
	RTLE;
	return Result;
}

/* {KL_PATHNAME}.is_parent */
EIF_BOOLEAN F966_6871 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = F966_6872(Current, arg1);
	tr2 = RTOSCF(6890,F966_6890, (Current));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == tr2);
	RTLE;
	return Result;
}

/* {KL_PATHNAME}.item */
EIF_REFERENCE F966_6872 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = F632_3030(RTCW(tr1), arg1);
	RTCT0("s_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {KL_PATHNAME}.drive */
EIF_REFERENCE F966_6873 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {KL_PATHNAME}.hostname */
EIF_REFERENCE F966_6874 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {KL_PATHNAME}.sharename */
EIF_REFERENCE F966_6875 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {KL_PATHNAME}.count */
EIF_INTEGER_32 F966_6876 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_);
}


/* {KL_PATHNAME}.set_relative */
void F966_6877 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) arg1;
}

/* {KL_PATHNAME}.set_drive */
void F966_6878 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {KL_PATHNAME}.set_hostname */
void F966_6879 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {KL_PATHNAME}.set_sharename */
void F966_6880 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {KL_PATHNAME}.append_name */
void F966_6881 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_))++;
	tr1 = *(EIF_REFERENCE *)(Current);
	F632_3051(RTCW(tr1), arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_));
	RTLE;
}

/* {KL_PATHNAME}.append_current */
void F966_6883 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(6889,F966_6889, (Current));
	F966_6881(Current, tr1);
	RTLE;
}

/* {KL_PATHNAME}.append_parent */
void F966_6884 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(6890,F966_6890, (Current));
	F966_6881(Current, tr1);
	RTLE;
}

/* {KL_PATHNAME}.set_canonical */
void F966_6885 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_);
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 1L))) {
		tb2 = F966_6870(Current, ((EIF_INTEGER_32) 1L));
	}
	if (tb2) {
		tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_);
	}
	if (tb1) {
	} else {
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			if (F966_6870(Current, loc1)) {
			} else {
				if (F966_6871(Current, loc1)) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L))) {
						tb1 = F966_6871(Current, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
					}
					if (tb1) {
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tr2 = F966_6872(Current, loc1);
							F632_3049(RTCW(tr1), tr2, loc2);
							loc2++;
						}
					} else {
						loc2--;
					}
				} else {
					tr1 = *(EIF_REFERENCE *)(Current);
					tr2 = F966_6872(Current, loc1);
					F632_3049(RTCW(tr1), tr2, loc2);
					loc2++;
				}
			}
			loc1++;
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc2 > loc3)) break;
			tr1 = *(EIF_REFERENCE *)(Current);
			F632_3049(RTCW(tr1), NULL, loc2);
			loc2++;
		}
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_) == ((EIF_INTEGER_32) 0L)))) {
			F966_6883(Current);
		}
	}
	RTLE;
}

/* {KL_PATHNAME}.copy */
void F966_6886 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	eif_builtin_ANY_standard_copy__o_ (Current, arg1);
	tr1 = RTOSCF(2272,F271_2272, (Current));
	tr1 = F739_3627(RTCW(tr1), *(EIF_REFERENCE *)(Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {KL_PATHNAME}.current_directory */

EIF_REFERENCE F966_6889 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6889,RTMS_EX_H(".",1,46));
}

/* {KL_PATHNAME}.parent_directory */

EIF_REFERENCE F966_6890 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6890,RTMS_EX_H("..",2,11822));
}

void EIF_Minit304 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
