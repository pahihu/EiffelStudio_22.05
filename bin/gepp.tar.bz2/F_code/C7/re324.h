
#ifndef _C7_re324_
#define _C7_re324_

#ifdef __cplusplus
extern "C" {
#endif

extern void F318_2374(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F318_2376(EIF_REFERENCE);
extern EIF_INTEGER_32 F318_2377(EIF_REFERENCE);
extern EIF_INTEGER_32 F318_2378(EIF_REFERENCE);
extern EIF_INTEGER_32 F318_2379(EIF_REFERENCE);
extern EIF_BOOLEAN F318_2387(EIF_REFERENCE);
extern EIF_BOOLEAN F318_2388(EIF_REFERENCE);
extern void F318_2393(EIF_REFERENCE);
extern void EIF_Minit324(void);
extern char *(*R2451[])();
extern char *(*R2452[])();

#ifdef __cplusplus
}
#endif

#endif
