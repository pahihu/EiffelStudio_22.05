
#ifndef _C7_fi326_
#define _C7_fi326_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F530_2559(EIF_REFERENCE);
extern void EIF_Minit326(void);
extern char *(*R2240[])();

#ifdef __cplusplus
}
#endif

#endif
