/*
 * Code for class reference NATURAL_8
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "na224.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NATURAL_8}.is_less */
EIF_BOOLEAN F807_4567 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(807, 0x00).id, 807, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)tr1 = arg1;
	Result = F806_4507(Current, tr1);
	RTLE;
	return Result;
}

/* {NATURAL_8}.minus */
EIF_NATURAL_8 F807_4569 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(807, 0x00).id, 807, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)tr1 = arg1;
	tr1 = F806_4517(Current, tr1);
	Result = *(EIF_NATURAL_8 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_8}.integer_quotient */
EIF_NATURAL_8 F807_4573 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(807, 0x00).id, 807, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)tr1 = arg1;
	tr1 = F806_4522(Current, tr1);
	Result = *(EIF_NATURAL_8 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_8}.integer_remainder */
EIF_NATURAL_8 F807_4574 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(807, 0x00).id, 807, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)tr1 = arg1;
	tr1 = F806_4523(Current, tr1);
	Result = *(EIF_NATURAL_8 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_8}.as_natural_16 */
EIF_NATURAL_16 F807_4577 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_16) F806_4530(Current);
}

/* {NATURAL_8}.as_natural_32 */
EIF_NATURAL_32 F807_4578 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_32) F806_4531(Current);
}

/* {NATURAL_8}.as_natural_64 */
EIF_NATURAL_64 F807_4579 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_64) F806_4532(Current);
}

/* {NATURAL_8}.as_integer_8 */
EIF_INTEGER_8 F807_4580 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_8) F806_4533(Current);
}

/* {NATURAL_8}.as_integer_32 */
EIF_INTEGER_32 F807_4582 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F806_4535(Current);
}

/* {NATURAL_8}.to_character_32 */
EIF_CHARACTER_32 F807_4587 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_CHARACTER_32) F806_4555(Current);
}

/* {NATURAL_8}.bit_and */
EIF_NATURAL_8 F807_4588 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(807, 0x00).id, 807, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)tr1 = arg1;
	tr1 = F806_4556(Current, tr1);
	Result = *(EIF_NATURAL_8 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_8}.bit_or */
EIF_NATURAL_8 F807_4589 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(807, 0x00).id, 807, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)tr1 = arg1;
	tr1 = F806_4557(Current, tr1);
	Result = *(EIF_NATURAL_8 *)(tr1);
	RTLE;
	return Result;
}

/* {NATURAL_8}.bit_not */
EIF_NATURAL_8 F807_4591 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return *(EIF_NATURAL_8 *)F806_4559(Current);
}

/* {NATURAL_8}.bit_shift_left */
EIF_NATURAL_8 F807_4592 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return *(EIF_NATURAL_8 *)F806_4561(Current, arg1);
}

/* {NATURAL_8}.bit_shift_right */
EIF_NATURAL_8 F807_4593 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return *(EIF_NATURAL_8 *)F806_4562(Current, arg1);
}

void EIF_Minit224 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
