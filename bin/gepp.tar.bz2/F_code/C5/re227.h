
#ifndef _C5_re227_
#define _C5_re227_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F810_4636(EIF_REFERENCE, EIF_REAL_32);
extern EIF_INTEGER_32 F810_4640(EIF_REFERENCE);
extern void EIF_Minit227(void);
extern EIF_BOOLEAN F809_4606(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F809_4617(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
