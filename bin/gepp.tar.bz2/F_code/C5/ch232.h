
#ifndef _C5_ch232_
#define _C5_ch232_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F817_4763(EIF_REFERENCE);
extern EIF_NATURAL_32 F817_4764(EIF_REFERENCE);
extern EIF_CHARACTER_8 F817_4765(EIF_REFERENCE);
extern void EIF_Minit232(void);
extern EIF_CHARACTER_8 F815_4744(EIF_REFERENCE);
extern EIF_NATURAL_32 F815_4729(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
