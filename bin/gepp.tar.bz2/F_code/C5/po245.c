/*
 * Code for class reference POINTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po245.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {POINTER}.hash_code */
EIF_INTEGER_32 F858_4962 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F827_4936(Current);
}

/* {POINTER}.is_default_pointer */
EIF_BOOLEAN F858_4963 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F827_4941(Current);
}

/* {POINTER}.plus */
EIF_POINTER F858_4964 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_POINTER) F827_4942(Current, arg1);
}

void EIF_Minit245 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
