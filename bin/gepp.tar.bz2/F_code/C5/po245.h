
#ifndef _C5_po245_
#define _C5_po245_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F858_4962(EIF_REFERENCE);
extern EIF_BOOLEAN F858_4963(EIF_REFERENCE);
extern EIF_POINTER F858_4964(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit245(void);
extern EIF_POINTER F827_4942(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F827_4941(EIF_REFERENCE);
extern EIF_INTEGER_32 F827_4936(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
