
#ifndef _C5_re226_
#define _C5_re226_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F811_4636(EIF_REFERENCE, EIF_REAL_32);
extern EIF_INTEGER_32 F811_4640(EIF_REFERENCE);
extern void EIF_Minit226(void);
extern EIF_BOOLEAN F809_4606(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F809_4617(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
