
#ifndef _C5_re225_
#define _C5_re225_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F809_4595(EIF_REFERENCE);
extern EIF_BOOLEAN F809_4606(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F809_4607(EIF_REFERENCE, EIF_REFERENCE);
extern void F809_4608(EIF_REFERENCE, EIF_REAL_32);
extern EIF_INTEGER_32 F809_4617(EIF_REFERENCE);
extern void EIF_Minit225(void);
extern char *(*R3552[])();

#ifdef __cplusplus
}
#endif

#endif
