
#ifndef _C5_ch236_
#define _C5_ch236_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F819_4814(EIF_REFERENCE);
extern EIF_CHARACTER_32 F819_4815(EIF_REFERENCE);
extern void EIF_Minit236(void);
extern EIF_NATURAL_32 F818_4768(EIF_REFERENCE);
extern EIF_CHARACTER_32 F818_4785(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
