
#ifndef _C5_st248_
#define _C5_st248_

#ifdef __cplusplus
extern "C" {
#endif

extern void F867_5118(EIF_REFERENCE);
extern void F867_5120(EIF_REFERENCE, EIF_NATURAL_32);
extern void F867_5131(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit248(void);
extern char *(*R3819[])();
extern char *(*R3945[])();
extern char *(*R3912[])();
extern char *(*R3915[])();
extern char *(*R3916[])();
extern char *(*R3856[])();
extern char *(*R3857[])();
extern long O3909[];
extern long O3910[];

#ifdef __cplusplus
}
#endif

#endif
