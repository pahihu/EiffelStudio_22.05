/*
 * Code for class CONF_TARGET_SETTINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co337.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_TARGET_SETTINGS}.make */
void F386_4782 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,834,0xFF01,1055,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F826_6568(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {CONF_TARGET_SETTINGS}.options */
EIF_REFERENCE F386_4783 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		tr2 = F1072_8777(Current);
		tr1 = RTLNS(eif_new_type(955, 0x01).id, 955, _OBJSIZ_18_18_0_0_0_0_0_0_);
		Result = F955_7194(RTCW(tr1), tr2);
	}
	RTLE;
	return Result;
}

/* {CONF_TARGET_SETTINGS}.settings */
EIF_REFERENCE F386_4785 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_3_);
}

/* {CONF_TARGET_SETTINGS}.setting_boolean */
EIF_BOOLEAN F386_4787 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,arg2);
	RTLIU(6);
	
	RTGC;
	loc1 = F1072_8818(Current);
	tr1 = F826_6574(RTCW(loc1), arg1);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = RTOSCF(4615,F383_4615, (Current));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(arg1))-1])(arg1, tr1);
		if ((EIF_BOOLEAN) !tb1) {
			tb1 = F1049_8051(loc2);
			RTLE;
			return (EIF_BOOLEAN) tb1;
		}
	} else {
		RTLE;
		return (EIF_BOOLEAN) F384_4763(Current, arg1, arg2);
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {CONF_TARGET_SETTINGS}.setting_executable_name */
EIF_REFERENCE F386_4788 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = F1072_8818(Current);
	tr2 = RTOSCF(4631,F383_4631, (Current));
	tr1 = F826_6574(RTCW(tr1), tr2);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1049_8033(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1049_7974(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {CONF_TARGET_SETTINGS}.setting_platform */
EIF_REFERENCE F386_4796 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = F1072_8818(Current);
	tr2 = RTOSCF(4653,F383_4653, (Current));
	tr1 = F826_6574(RTCW(tr1), tr2);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6777[Dtype(loc1)-1052])(loc1);
		Result = F1049_8033(RTCW(tr1));
	} else {
		Result = RTMS32_EX_H("",0,0);
	}
	RTLE;
	return Result;
}

/* {CONF_TARGET_SETTINGS}.set_options */
void F386_4800 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {CONF_TARGET_SETTINGS}.merge_options */
void F386_4801 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F956_7328(loc1, arg1);
	} else {
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	}
	RTLE;
}

/* {CONF_TARGET_SETTINGS}.add_setting */
void F386_4803 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F826_6615(RTCW(tr1), arg2, arg1);
	RTLE;
}

/* {CONF_TARGET_SETTINGS}.changeable_internal_options */
EIF_REFERENCE F386_4807 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		tr2 = F1072_8777(Current);
		tr1 = RTLNSMART(eif_new_type(955, 1).id);
		Result = F955_7194(RTCW(tr1), tr2);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

void EIF_Minit337 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
