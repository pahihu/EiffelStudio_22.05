
#ifndef _C7_co312_
#define _C7_co312_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F361_4083(EIF_REFERENCE);
extern EIF_BOOLEAN F361_4100(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit312(void);
extern char *(*R3575[])();

#ifdef __cplusplus
}
#endif

#endif
