
#ifndef _C7_co301_
#define _C7_co301_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,3925)
static EIF_REFERENCE F349_3925_body(EIF_REFERENCE);
extern EIF_REFERENCE F349_3925(EIF_REFERENCE);
extern void EIF_Minit301(void);

#ifdef __cplusplus
}
#endif

#endif
