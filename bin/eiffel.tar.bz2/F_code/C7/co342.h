
#ifndef _C7_co342_
#define _C7_co342_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_BOOLEAN,4864)
static EIF_BOOLEAN F391_4864_body(EIF_REFERENCE);
extern EIF_BOOLEAN F391_4864(EIF_REFERENCE);
extern void EIF_Minit342(void);

#ifdef __cplusplus
}
#endif

#endif
