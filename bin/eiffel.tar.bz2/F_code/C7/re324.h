
#ifndef _C7_re324_
#define _C7_re324_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F373_4292(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit324(void);

#ifdef __cplusplus
}
#endif

#endif
