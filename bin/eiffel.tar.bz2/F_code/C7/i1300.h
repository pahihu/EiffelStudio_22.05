
#ifndef _C7_i1300_
#define _C7_i1300_

#ifdef __cplusplus
extern "C" {
#endif

extern void F348_3922(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit300(void);
extern EIF_REFERENCE F1282_12082(EIF_REFERENCE, EIF_REFERENCE);
extern void F1282_12081(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
