/*
 * Code for class CONF_NAMESPACE_TESTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co331.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_NAMESPACE_TESTER}.includes_this_or_before */
EIF_BOOLEAN F380_4531 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F378_4497(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1);
}

/* {CONF_NAMESPACE_TESTER}.includes_this_or_after */
EIF_BOOLEAN F380_4532 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F378_4498(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1);
}

void EIF_Minit331 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
