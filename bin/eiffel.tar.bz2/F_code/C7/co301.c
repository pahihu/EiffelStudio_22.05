/*
 * Code for class CONF_INTERFACE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co301.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_INTERFACE_CONSTANTS}.conf_interface_names */
static EIF_REFERENCE F349_3925_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3925);
#define Result RTOSR(3925)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1262, 0x01).id, 1262, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3925);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F349_3925 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3925,F349_3925_body,(Current));
}

void EIF_Minit301 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
