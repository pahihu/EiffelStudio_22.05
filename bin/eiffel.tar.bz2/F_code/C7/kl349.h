
#ifndef _C7_kl349_
#define _C7_kl349_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,4880)
static EIF_REFERENCE F410_4880_body(EIF_REFERENCE);
extern EIF_REFERENCE F410_4880(EIF_REFERENCE);
extern void EIF_Minit349(void);

#ifdef __cplusplus
}
#endif

#endif
