/*
 * Code for class CONF_LOAD_UUID_CALLBACKS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co333.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOAD_UUID_CALLBACKS}.make_with_file */
void F382_4549 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	{
		/* INLINED CODE (XML_CALLBACKS_NULL.make) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {CONF_LOAD_UUID_CALLBACKS}.on_start_tag */
void F382_4554 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_)) {
		F381_4544(Current, arg1);
		tr1 = RTMS_EX_H("system",6,16556653);
		tb1 = F1049_8016(RTCW(arg3), tr1);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_3_) = (EIF_BOOLEAN) tb1;
		tr1 = RTMS_EX_H("redirection",11,7276654);
		tb1 = F1049_8016(RTCW(arg3), tr1);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_4_) = (EIF_BOOLEAN) tb1;
	}
	RTLE;
}

/* {CONF_LOAD_UUID_CALLBACKS}.on_attribute */
void F382_4555 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,arg4);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_)) {
		tb1 = '\0';
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_3_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_7_4_))) {
			tr1 = RTMS_EX_H("uuid",4,1970628964);
			tb2 = F1049_8016(RTCW(arg3), tr1);
			tb1 = tb2;
		}
		if (tb1) {
			if (F381_4543(Current, arg4)) {
				tr1 = RTLNSMART(eif_new_type(1069, 0).id);
				F1070_8698(RTCW(tr1), arg4);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
			} else {
				tr1 = RTLNS(eif_new_type(996, 0x01).id, 996, _OBJSIZ_2_0_0_3_0_0_0_0_);
				F997_7631(RTCW(tr1));
				F381_4545(Current, tr1);
			}
		} else {
			tb1 = '\0';
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_4_)) {
				tr1 = RTMS_EX_H("location",8,59511406);
				tb2 = F1049_8016(RTCW(arg3), tr1);
				tb1 = tb2;
			}
			if (tb1) {
				RTAR(Current, arg4);
				*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg4;
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_UUID_CALLBACKS}.on_end_tag */
void F382_4556 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		*(EIF_BOOLEAN *)(Current+ _CHROFF_7_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

void EIF_Minit333 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
