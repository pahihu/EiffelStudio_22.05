/*
 * Code for class CONF_VALIDITY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co335.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_VALIDITY}.valid_platform */
EIF_BOOLEAN F384_4716 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(4739,F384_4739, (Current));
	Result = F827_6576(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.valid_build */
EIF_BOOLEAN F384_4717 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(4740,F384_4740, (Current));
	Result = F827_6576(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.valid_concurrency */
EIF_BOOLEAN F384_4718 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(4741,F384_4741, (Current));
	Result = F827_6576(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.valid_void_safety */
EIF_BOOLEAN F384_4719 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(4742,F384_4742, (Current));
	Result = F827_6576(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.valid_warning */
EIF_BOOLEAN F384_4721 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\01';
	tb4 = '\0';
	tr1 = RTOSCF(4489,F378_4489, (Current));
	if (F378_4498(Current, arg2, tr1)) {
		tr1 = RTOSCF(4754,F384_4754, (Current));
		tb5 = F828_6574(RTCW(tr1), arg1);
		tb4 = tb5;
	}
	if (!tb4) {
		tb4 = '\0';
		tr1 = RTOSCF(4483,F378_4483, (Current));
		tr2 = RTOSCF(4487,F378_4487, (Current));
		if (F378_4499(Current, arg2, tr1, tr2)) {
			tr1 = RTOSCF(4753,F384_4753, (Current));
			tb5 = F828_6574(RTCW(tr1), arg1);
			tb4 = tb5;
		}
		tb3 = tb4;
	}
	if (!tb3) {
		tb3 = '\0';
		tr1 = RTOSCF(4481,F378_4481, (Current));
		tr2 = RTOSCF(4481,F378_4481, (Current));
		if (F378_4499(Current, arg2, tr1, tr2)) {
			tr1 = RTOSCF(4752,F384_4752, (Current));
			tb4 = F828_6574(RTCW(tr1), arg1);
			tb3 = tb4;
		}
		tb2 = tb3;
	}
	if (!tb2) {
		tb2 = '\0';
		tr1 = RTOSCF(4467,F378_4467, (Current));
		tr2 = RTOSCF(4479,F378_4479, (Current));
		if (F378_4499(Current, arg2, tr1, tr2)) {
			tr1 = RTOSCF(4751,F384_4751, (Current));
			tb3 = F828_6574(RTCW(tr1), arg1);
			tb2 = tb3;
		}
		tb1 = tb2;
	}
	if (!tb1) {
		tb1 = '\0';
		tr1 = RTOSCF(4465,F378_4465, (Current));
		if (F378_4497(Current, arg2, tr1)) {
			tr1 = RTOSCF(4750,F384_4750, (Current));
			tb2 = F828_6574(RTCW(tr1), arg1);
			tb1 = tb2;
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.regexp_error */
EIF_REFERENCE F384_4723 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	struct eif_ex_61 sloc2;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) sloc2.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc2.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc2.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc2.overhead, eif_new_type(79, 0x00).id);
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLR(5,tr2);
	RTLR(6,Result);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_11_16_0_25_0_0_0_0_);
		F1293_12469(RTCW(loc1));
		tr1 = F80_1201(RTCW(loc2), arg1);
		F1293_12472(RTCW(loc1), tr1);
		tb1 = F1292_12390(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,999,0xFF01,1053,1190,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr1 = RTLNTS(typres0.id, 3, 0);
			}
			tr2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
			((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
			RTAR(tr1,tr2);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_11_16_0_14_);
			((EIF_TYPED_VALUE *)tr1+2)->it_i4 = ti4_1;
			Result = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.valid_setting */
EIF_BOOLEAN F384_4726 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6732[Dtype(RTCW(arg1))-1052])(arg1);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = F1049_8027(RTCW(arg1));
		Result = '\01';
		tb1 = '\01';
		tb2 = '\0';
		tr1 = RTOSCF(4483,F378_4483, (Current));
		if (F378_4498(Current, arg2, tr1)) {
			tr1 = RTOSCF(4759,F384_4759, (Current));
			tb3 = F1225_10464(RTCW(tr1), loc1);
			tb2 = tb3;
		}
		if (!tb2) {
			tb2 = '\0';
			tr1 = RTOSCF(4481,F378_4481, (Current));
			tr2 = RTOSCF(4481,F378_4481, (Current));
			if (F378_4499(Current, arg2, tr1, tr2)) {
				tr1 = RTOSCF(4758,F384_4758, (Current));
				tb3 = F1225_10464(RTCW(tr1), loc1);
				tb2 = tb3;
			}
			tb1 = tb2;
		}
		if (!tb1) {
			tb1 = '\0';
			tr1 = RTOSCF(4479,F378_4479, (Current));
			if (F378_4497(Current, arg2, tr1)) {
				tr1 = RTOSCF(4757,F384_4757, (Current));
				tb2 = F1225_10464(RTCW(tr1), loc1);
				tb1 = tb2;
			}
			Result = tb1;
		}
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.valid_version_type */
EIF_BOOLEAN F384_4727 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTOSCF(4755,F384_4755, (Current));
		tb1 = F828_6576(RTCW(tr1), arg1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.get_platform */
EIF_INTEGER_32 F384_4734 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		F827_6607(RTCV(RTOSCF(4739,F384_4739, (Current))));
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) {
				tb2 = F827_6602(RTCV(RTOSCF(4739,F384_4739, (Current))));
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = F827_6580(RTCV(RTOSCF(4739,F384_4739, (Current))));
			tb2 = F1049_8016(RTCW(arg1), tr1);
			if (tb2) {
				Result = F827_6581(RTCV(RTOSCF(4739,F384_4739, (Current))));
			}
			F827_6608(RTCV(RTOSCF(4739,F384_4739, (Current))));
		}
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.get_build */
EIF_INTEGER_32 F384_4735 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		F827_6607(RTCV(RTOSCF(4740,F384_4740, (Current))));
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) {
				tb2 = F827_6602(RTCV(RTOSCF(4740,F384_4740, (Current))));
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = F827_6580(RTCV(RTOSCF(4740,F384_4740, (Current))));
			tb2 = F1049_8016(RTCW(arg1), tr1);
			if (tb2) {
				Result = F827_6581(RTCV(RTOSCF(4740,F384_4740, (Current))));
			}
			F827_6608(RTCV(RTOSCF(4740,F384_4740, (Current))));
		}
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.get_concurrency */
EIF_INTEGER_32 F384_4736 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		F827_6607(RTCV(RTOSCF(4741,F384_4741, (Current))));
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) {
				tb2 = F827_6602(RTCV(RTOSCF(4741,F384_4741, (Current))));
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = F827_6580(RTCV(RTOSCF(4741,F384_4741, (Current))));
			tb2 = F1049_8016(RTCW(arg1), tr1);
			if (tb2) {
				Result = F827_6581(RTCV(RTOSCF(4741,F384_4741, (Current))));
			}
			F827_6608(RTCV(RTOSCF(4741,F384_4741, (Current))));
		}
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.get_void_safety */
EIF_INTEGER_32 F384_4737 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		F827_6607(RTCV(RTOSCF(4742,F384_4742, (Current))));
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) {
				tb2 = F827_6602(RTCV(RTOSCF(4742,F384_4742, (Current))));
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = F827_6580(RTCV(RTOSCF(4742,F384_4742, (Current))));
			tb2 = F1049_8016(RTCW(arg1), tr1);
			if (tb2) {
				Result = F827_6581(RTCV(RTOSCF(4742,F384_4742, (Current))));
			}
			F827_6608(RTCV(RTOSCF(4742,F384_4742, (Current))));
		}
	}
	RTLE;
	return Result;
}

/* {CONF_VALIDITY}.current_platform */
EIF_INTEGER_32 F384_4738 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
		} else {
			if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_vxworks__b) {
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
			} else {
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
			}
		}
	}
	return Result;
}

/* {CONF_VALIDITY}.platform_names */
static EIF_REFERENCE F384_4739_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4739);
#define Result RTOSR(4739)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,826,0xFF01,1053,1190,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 826, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F827_6568(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(4567,F383_4567, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L));
	tr1 = RTOSCF(4568,F383_4568, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 2L));
	tr1 = RTOSCF(4569,F383_4569, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 8L));
	tr1 = RTOSCF(4570,F383_4570, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 15L));
	RTOSE (4739);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4739 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4739,F384_4739_body,(Current));
}

/* {CONF_VALIDITY}.build_names */
static EIF_REFERENCE F384_4740_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4740);
#define Result RTOSR(4740)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,826,0xFF01,1053,1190,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 826, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F827_6568(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(4573,F383_4573, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 256L));
	tr1 = RTOSCF(4574,F383_4574, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 512L));
	RTOSE (4740);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4740 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4740,F384_4740_body,(Current));
}

/* {CONF_VALIDITY}.concurrency_names */
static EIF_REFERENCE F384_4741_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4741);
#define Result RTOSR(4741)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,826,0xFF01,1053,1190,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 826, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F827_6568(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(4578,F383_4578, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 2048L));
	tr1 = RTOSCF(4579,F383_4579, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 3840L));
	tr1 = RTOSCF(4580,F383_4580, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 4096L));
	RTOSE (4741);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4741 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4741,F384_4741_body,(Current));
}

/* {CONF_VALIDITY}.void_safety_names */
static EIF_REFERENCE F384_4742_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4742);
#define Result RTOSR(4742)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,826,0xFF01,1053,1190,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 826, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F827_6568(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(4586,F383_4586, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 4352L));
	tr1 = RTOSCF(4587,F383_4587, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 4608L));
	tr1 = RTOSCF(4588,F383_4588, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 4864L));
	tr1 = RTOSCF(4589,F383_4589, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 5120L));
	tr1 = RTOSCF(4590,F383_4590, (Current));
	F827_6615(RTCW(Result), tr1, ((EIF_INTEGER_32) 5376L));
	RTOSE (4742);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4742 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4742,F384_4742_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_default */
static EIF_REFERENCE F384_4750_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4750);
#define Result RTOSR(4750)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,835,1005,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 835, _OBJSIZ_5_6_0_7_0_0_0_0_);
	}
	F828_6568(RTCW(tr1), ((EIF_INTEGER_32) 13L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(4599,F383_4599, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4601,F383_4601, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4602,F383_4602, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4604,F383_4604, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4605,F383_4605, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4606,F383_4606, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4607,F383_4607, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4608,F383_4608, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4609,F383_4609, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4610,F383_4610, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4611,F383_4611, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4612,F383_4612, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4613,F383_4613, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (4750);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4750 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4750,F384_4750_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_1_10_0 */
static EIF_REFERENCE F384_4751_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4751);
#define Result RTOSR(4751)
	RTOC_NEW(Result);
	Result = F1_14(RTOSCF(4750,F384_4750, (Current)));
	tr1 = RTOSCF(4600,F383_4600, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (4751);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4751 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4751,F384_4751_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_1_17_0 */
static EIF_REFERENCE F384_4752_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4752);
#define Result RTOSR(4752)
	RTOC_NEW(Result);
	Result = F1_14(RTOSCF(4751,F384_4751, (Current)));
	tr1 = RTOSCF(4603,F383_4603, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (4752);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4752 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4752,F384_4752_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_1_18_0 */
static EIF_REFERENCE F384_4753_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4753);
#define Result RTOSR(4753)
	RTOC_NEW(Result);
	Result = F1_14(RTOSCF(4752,F384_4752, (Current)));
	tr1 = RTOSCF(4603,F383_4603, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 0, tr1);
	RTOSE (4753);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4753 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4753,F384_4753_body,(Current));
}

/* {CONF_VALIDITY}.valid_warnings_1_21_0 */
static EIF_REFERENCE F384_4754_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4754);
#define Result RTOSR(4754)
	RTOC_NEW(Result);
	Result = F1_14(RTOSCF(4753,F384_4753, (Current)));
	tr1 = RTOSCF(4602,F383_4602, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 0, tr1);
	RTOSE (4754);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4754 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4754,F384_4754_body,(Current));
}

/* {CONF_VALIDITY}.valid_version_types */
static EIF_REFERENCE F384_4755_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4755);
#define Result RTOSR(4755)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,835,1005,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 835, _OBJSIZ_5_6_0_7_0_0_0_0_);
	}
	F828_6568(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(4594,F383_4594, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTOSCF(4595,F383_4595, (Current));
	F828_6615(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (4755);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4755 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4755,F384_4755_body,(Current));
}

/* {CONF_VALIDITY}.valid_settings */
static EIF_REFERENCE F384_4757_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4757);
#define Result RTOSR(4757)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1224,0xFF01,1053,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1224, _OBJSIZ_4_1_0_5_0_0_0_0_);
	}
	F1225_10460(RTCW(tr1), ((EIF_INTEGER_32) 40L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(4614,F383_4614, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4615,F383_4615, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4616,F383_4616, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4618,F383_4618, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4619,F383_4619, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4620,F383_4620, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4621,F383_4621, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4622,F383_4622, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4623,F383_4623, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4625,F383_4625, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4626,F383_4626, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4627,F383_4627, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4628,F383_4628, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4629,F383_4629, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4630,F383_4630, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4631,F383_4631, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4633,F383_4633, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4634,F383_4634, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4635,F383_4635, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4636,F383_4636, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4637,F383_4637, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4638,F383_4638, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4639,F383_4639, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4641,F383_4641, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4642,F383_4642, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4643,F383_4643, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4644,F383_4644, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4645,F383_4645, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4646,F383_4646, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4647,F383_4647, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4648,F383_4648, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4649,F383_4649, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4650,F383_4650, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4651,F383_4651, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4653,F383_4653, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4632,F383_4632, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4654,F383_4654, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4655,F383_4655, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4656,F383_4656, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4657,F383_4657, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4652,F383_4652, (Current));
	F1225_10477(RTCW(Result), tr1);
	RTOSE (4757);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4757 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4757,F384_4757_body,(Current));
}

/* {CONF_VALIDITY}.valid_settings_1_17_0 */
static EIF_REFERENCE F384_4758_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4758);
#define Result RTOSR(4758)
	RTOC_NEW(Result);
	Result = F1_14(RTOSCF(4757,F384_4757, (Current)));
	tr1 = RTOSCF(4617,F383_4617, (Current));
	F1225_10477(RTCW(Result), tr1);
	RTOSE (4758);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4758 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4758,F384_4758_body,(Current));
}

/* {CONF_VALIDITY}.valid_settings_1_18_0 */
static EIF_REFERENCE F384_4759_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4759);
#define Result RTOSR(4759)
	RTOC_NEW(Result);
	Result = F1_14(RTOSCF(4758,F384_4758, (Current)));
	tr1 = RTOSCF(4642,F383_4642, (Current));
	F1225_10479(RTCW(Result), tr1);
	tr1 = RTOSCF(4640,F383_4640, (Current));
	F1225_10477(RTCW(Result), tr1);
	RTOSE (4759);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4759 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4759,F384_4759_body,(Current));
}

/* {CONF_VALIDITY}.true_boolean_settings_1_19_0_and_below */
static EIF_REFERENCE F384_4761_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4761);
#define Result RTOSR(4761)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1224,0xFF01,1051,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1224, _OBJSIZ_4_1_0_5_0_0_0_0_);
	}
	F1225_10460(RTCW(tr1), ((EIF_INTEGER_32) 9L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(4620,F383_4620, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4621,F383_4621, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4618,F383_4618, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4619,F383_4619, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4622,F383_4622, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4635,F383_4635, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4634,F383_4634, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4656,F383_4656, (Current));
	F1225_10477(RTCW(Result), tr1);
	tr1 = RTOSCF(4657,F383_4657, (Current));
	F1225_10477(RTCW(Result), tr1);
	RTOSE (4761);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4761 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4761,F384_4761_body,(Current));
}

/* {CONF_VALIDITY}.true_boolean_settings_1_20_0_and_above */
static EIF_REFERENCE F384_4762_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (4762);
#define Result RTOSR(4762)
	RTOC_NEW(Result);
	Result = F1_14(RTOSCF(4761,F384_4761, (Current)));
	tr1 = RTOSCF(4655,F383_4655, (Current));
	F1225_10477(RTCW(Result), tr1);
	RTOSE (4762);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F384_4762 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4762,F384_4762_body,(Current));
}

/* {CONF_VALIDITY}.is_boolean_setting_true */
EIF_BOOLEAN F384_4763 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(4485,F378_4485, (Current));
	if (F378_4497(Current, arg2, tr1)) {
		tr1 = RTOSCF(4761,F384_4761, (Current));
	} else {
		tr1 = RTOSCF(4762,F384_4762, (Current));
	}
	Result = F1225_10464(RTCV(tr1), arg1);
	RTLE;
	return Result;
}

void EIF_Minit335 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
