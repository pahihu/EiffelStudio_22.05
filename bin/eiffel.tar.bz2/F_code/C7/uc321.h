
#ifndef _C7_uc321_
#define _C7_uc321_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,4198)
static EIF_REFERENCE F370_4198_body(EIF_REFERENCE);
extern EIF_REFERENCE F370_4198(EIF_REFERENCE);
extern void EIF_Minit321(void);

#ifdef __cplusplus
}
#endif

#endif
