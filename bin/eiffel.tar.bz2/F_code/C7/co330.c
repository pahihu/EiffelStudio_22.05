/*
 * Code for class CONF_PARSE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co330.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_PARSE_FACTORY}.new_redirection_with_file_name */
EIF_REFERENCE F379_4501 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1249, 0x01).id, 1249, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1250_11036(RTCW(tr1), arg1, arg2, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_system_generate_uuid_with_file_name */
EIF_REFERENCE F379_4502 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	Result = RTLNS(eif_new_type(1250, 0x01).id, 1250, _OBJSIZ_16_4_0_2_0_0_0_0_);
	tr1 = F53_794(RTCV(RTOSCF(4529,F379_4529, (Current))));
	F1251_11045(RTCW(Result), arg1, arg2, tr1, arg3);
	F1251_11080(RTCW(Result), (EIF_BOOLEAN) 1);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_system_with_file_name */
EIF_REFERENCE F379_4503 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1250, 0x01).id, 1250, _OBJSIZ_16_4_0_2_0_0_0_0_);
	F1251_11045(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_target */
EIF_REFERENCE F379_4504 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1071, 0x01).id, 1071, _OBJSIZ_29_1_0_0_0_0_0_0_);
	F1072_8768(RTCW(tr1), arg1, arg2);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_location_from_path */
EIF_REFERENCE F379_4505 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1280, 0x01).id, 1280, _OBJSIZ_3_0_0_0_0_0_0_0_);
	F1281_12078(RTCW(tr1), arg1, arg2);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_file_location_from_path */
EIF_REFERENCE F379_4506 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1279, 0x01).id, 1279, _OBJSIZ_3_0_0_0_0_0_0_0_);
	F1280_12075(RTCW(tr1), arg1, arg2);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_location_from_full_path */
EIF_REFERENCE F379_4507 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1279, 0x01).id, 1279, _OBJSIZ_3_0_0_0_0_0_0_0_);
	F1280_12075(RTCW(tr1), arg1, arg2);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_root */
EIF_REFERENCE F379_4508 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(57, 0x01).id, 57, _OBJSIZ_3_1_0_0_0_0_0_0_);
	F58_947(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_version */
EIF_REFERENCE F379_4509 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1, EIF_NATURAL_16 arg2, EIF_NATURAL_16 arg3, EIF_NATURAL_16 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1227, 0x01).id, 1227, _OBJSIZ_4_5_4_0_0_0_0_0_);
	F1228_10517(RTCW(tr1), arg1, arg2, arg3, arg4);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_option */
EIF_REFERENCE F379_4510 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(954, 0x01).id, 954, _OBJSIZ_12_18_0_0_0_0_0_0_);
	Result = F955_7194(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_target_option */
EIF_REFERENCE F379_4511 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(955, 0x01).id, 955, _OBJSIZ_18_18_0_0_0_0_0_0_);
	Result = F955_7194(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_file_rule */
EIF_REFERENCE F379_4512 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(387, 0x01).id, 387, _OBJSIZ_7_0_0_0_0_0_0_0_);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_external_include */
EIF_REFERENCE F379_4513 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(390, 0x01).id, 390, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1049_8033(RTCW(arg1));
	F390_4848(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_cflag */
EIF_REFERENCE F379_4514 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(395, 0x01).id, 395, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1049_8033(RTCW(arg1));
	F390_4848(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_object */
EIF_REFERENCE F379_4515 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(396, 0x01).id, 396, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1049_8033(RTCW(arg1));
	F390_4848(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_library */
EIF_REFERENCE F379_4516 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(394, 0x01).id, 394, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1049_8033(RTCW(arg1));
	F390_4848(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_resource */
EIF_REFERENCE F379_4517 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(393, 0x01).id, 393, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1049_8033(RTCW(arg1));
	F390_4848(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_linker_flag */
EIF_REFERENCE F379_4518 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(392, 0x01).id, 392, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1049_8033(RTCW(arg1));
	F390_4848(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_external_make */
EIF_REFERENCE F379_4519 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(391, 0x01).id, 391, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F1049_8033(RTCW(arg1));
	F390_4848(RTCW(Result), tr1, arg2);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_action */
EIF_REFERENCE F379_4520 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(388, 0x01).id, 388, _OBJSIZ_4_1_0_0_0_0_0_0_);
	tr1 = F1049_8033(RTCW(arg1));
	F389_4839(RTCW(Result), tr1, arg2, arg3);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_assertions */
EIF_REFERENCE F379_4521 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(51, 0x01).id, 51, _OBJSIZ_0_0_0_1_0_0_0_0_);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_assembly */
EIF_REFERENCE F379_4522 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	tr1 = F1049_8033(RTCW(arg2));
	loc1 = F379_4507(Current, tr1, arg3);
	tr1 = RTLNS(eif_new_type(1127, 0x01).id, 1127, _OBJSIZ_23_4_0_1_0_0_0_0_);
	F1121_9056(RTCW(tr1), arg1, loc1, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_assembly_from_gac */
EIF_REFERENCE F379_4523 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,arg5);
	RTLR(6,arg6);
	RTLIU(7);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1127, 0x01).id, 1127, _OBJSIZ_23_4_0_1_0_0_0_0_);
	F1128_9194(RTCW(tr1), arg1, arg2, arg3, arg4, arg5, arg6);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_library */
EIF_REFERENCE F379_4524 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	Result = RTLNS(eif_new_type(1128, 0x01).id, 1128, _OBJSIZ_21_4_0_1_0_0_0_0_);
	tr1 = F1049_8033(RTCW(arg2));
	tr1 = F379_4507(Current, tr1, arg3);
	F1129_9222(RTCW(Result), arg1, tr1, arg3);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_precompile */
EIF_REFERENCE F379_4525 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	Result = RTLNS(eif_new_type(1129, 0x01).id, 1129, _OBJSIZ_22_4_0_1_0_0_0_0_);
	tr1 = F1049_8033(RTCW(arg2));
	tr1 = F379_4507(Current, tr1, arg3);
	F1130_9240(RTCW(Result), arg1, tr1, arg3);
	RTLE;
	return Result;
}

/* {CONF_PARSE_FACTORY}.new_cluster */
EIF_REFERENCE F379_4526 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1123, 0x01).id, 1123, _OBJSIZ_27_5_0_1_0_0_0_0_);
	F1124_9134(RTCW(tr1), arg1, arg2, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_test_cluster */
EIF_REFERENCE F379_4527 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1124, 0x01).id, 1124, _OBJSIZ_27_5_0_1_0_0_0_0_);
	F1124_9134(RTCW(tr1), arg1, arg2, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.new_override */
EIF_REFERENCE F379_4528 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1125, 0x01).id, 1125, _OBJSIZ_29_5_0_1_0_0_0_0_);
	F1124_9134(RTCW(tr1), arg1, arg2, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_PARSE_FACTORY}.uuid_generator */
static EIF_REFERENCE F379_4529_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (4529);
#define Result RTOSR(4529)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(52, 0x01).id, 52, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (4529);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F379_4529 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4529,F379_4529_body,(Current));
}

void EIF_Minit330 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
