
#ifndef _C7_co336_
#define _C7_co336_

#ifdef __cplusplus
extern "C" {
#endif

extern void F385_4773(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_BOOLEAN, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit336(void);

#ifdef __cplusplus
}
#endif

#endif
