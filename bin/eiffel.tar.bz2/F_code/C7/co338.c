/*
 * Code for class CONF_CONDITIONED
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co338.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_CONDITIONED}.is_enabled */
EIF_BOOLEAN F387_4812 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O4360[Dtype(Current)-386]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F923_6949(loc1);
		for (;;) {
			tb1 = '\01';
			if (!Result) {
				tb2 = F894_6837(loc1);
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = F923_6923(loc1);
			Result = F1265_11907(RTCW(tr1), arg1);
			F923_6951(loc1);
		}
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

/* {CONF_CONDITIONED}.add_condition */
void F387_4813 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + O4360[dtype-386]);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = RTLNSMART(eif_new_type(937, 0).id);
		F938_7006(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O4360[dtype-386]) = (EIF_REFERENCE) loc1;
	}
	F923_6958(RTCW(loc1), arg1);
	RTLE;
}

/* {CONF_CONDITIONED}.set_conditions */
void F387_4814 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = F736_6139(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		*(EIF_REFERENCE *)(Current + O4360[dtype-386]) = (EIF_REFERENCE) NULL;
	} else {
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O4360[dtype-386]) = (EIF_REFERENCE) arg1;
	}
	RTLE;
}

void EIF_Minit338 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
