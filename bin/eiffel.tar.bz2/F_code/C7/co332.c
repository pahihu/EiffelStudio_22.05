/*
 * Code for class CONF_LOAD_CALLBACKS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co332.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOAD_CALLBACKS}.on_error */
void F381_4539 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O4087[Dtype(Current)-380]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F381_4547(Current, arg1);
	RTLE;
}

/* {CONF_LOAD_CALLBACKS}.on_start */
void F381_4540 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
}

/* {CONF_LOAD_CALLBACKS}.on_finish */
void F381_4541 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
}

/* {CONF_LOAD_CALLBACKS}.set_internal_error */
void F381_4542 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(989, 0x01).id, 989, _OBJSIZ_2_0_0_3_0_0_0_0_);
	tr1 = F1263_11789(RTCV(RTOSCF(3925,F349_3925, (Current))));
	F990_7614(RTCW(loc1), tr1);
	F990_7611(RTCW(loc1));
	*(EIF_BOOLEAN *)(Current + O4085[Dtype(Current)-380]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {CONF_LOAD_CALLBACKS}.is_valid_uuid */
EIF_BOOLEAN F381_4543 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1069, 0x01).id, 1069, _OBJSIZ_0_0_3_1_0_0_1_0_);
	tb1 = F1070_8707(RTCW(loc1), arg1);
	RTLE;
	return (EIF_BOOLEAN) tb1;
}

/* {CONF_LOAD_CALLBACKS}.check_version */
void F381_4544 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		tr1 = RTLNS(eif_new_type(991, 0x01).id, 991, _OBJSIZ_2_0_0_3_0_0_0_0_);
		F992_7621(RTCW(tr1));
		F381_4545(Current, tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
			tr1 = F378_4496(Current, arg1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		} else {
			tb1 = F1056_8297(RTCW(arg1), loc1);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = RTLNS(eif_new_type(991, 0x01).id, 991, _OBJSIZ_2_0_0_3_0_0_0_0_);
				F992_7621(RTCW(tr1));
				F381_4545(Current, tr1);
			}
		}
	}
	RTLE;
}

/* {CONF_LOAD_CALLBACKS}.set_error */
void F381_4545 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O4085[Dtype(Current)-380]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	loc1 = RTLNS(eif_new_type(312, 0x01).id, 312, _OBJSIZ_5_1_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Parse error",11,62499698);
	F303_3805(RTCW(loc1), tr1);
	F303_3790(RTCW(loc1));
	RTLE;
}

/* {CONF_LOAD_CALLBACKS}.set_parse_error_message */
void F381_4547 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc1);
	RTLR(5,loc5);
	RTLR(6,loc3);
	RTLR(7,loc2);
	RTLIU(8);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O4087[dtype-380])) {
		tb2 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc4 = tr1;
		if (!((EIF_BOOLEAN) !EIF_TEST(loc4))) {
			tb2 = (EIF_BOOLEAN) !F378_4495(Current, loc4);
		}
		tb1 = tb2;
	}
	if (tb1) {
		F381_4548(Current, arg1);
	} else {
		loc1 = RTLNS(eif_new_type(989, 0x01).id, 989, _OBJSIZ_2_0_0_3_0_0_0_0_);
		F990_7614(RTCW(loc1), arg1);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			loc3 = F283_3558(loc5);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_0_0_2_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_0_0_1_);
			F990_7613(RTCW(loc1), tr1, ti4_1, ti4_2);
		}
		*(EIF_BOOLEAN *)(Current + O4085[dtype-380]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		loc2 = RTLNS(eif_new_type(312, 0x01).id, 312, _OBJSIZ_5_1_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("Parse error",11,62499698);
		F303_3805(RTCW(loc2), tr1);
		F303_3790(RTCW(loc2));
	}
	RTLE;
}

/* {CONF_LOAD_CALLBACKS}.set_parse_warning_message */
void F381_4548 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(989, 0x01).id, 989, _OBJSIZ_2_0_0_3_0_0_0_0_);
	F990_7614(RTCW(loc1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc2 = F283_3558(loc4);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_1_);
		F990_7613(RTCW(loc1), tr1, ti4_1, ti4_2);
	}
	*(EIF_BOOLEAN *)(Current + O4086[Dtype(Current)-380]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {922,0xFF01,975,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc3 = RTLNSMART(typres0.id);
		}
		F923_6918(RTCW(loc3), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc3;
	}
	F923_6958(RTCW(loc3), loc1);
	RTLE;
}

void EIF_Minit332 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
