
#ifndef _C7_co340_
#define _C7_co340_

#ifdef __cplusplus
extern "C" {
#endif

extern void F389_4839(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE);
extern void F389_4847(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit340(void);

#ifdef __cplusplus
}
#endif

#endif
