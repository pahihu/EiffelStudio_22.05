/*
 * Code for class CONF_FILE_RULE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co339.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_FILE_RULE}.make */
void F388_4816 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {CONF_FILE_RULE}.add_exclude */
void F388_4822 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1224,0xFF01,1057,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F1225_10460(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	}
	F1225_10476(RTCW(loc1), arg1);
	F388_4832(Current);
	RTLE;
}

/* {CONF_FILE_RULE}.add_include */
void F388_4823 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1224,0xFF01,1057,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F1225_10460(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	}
	F1225_10476(RTCW(loc1), arg1);
	F388_4832(Current);
	RTLE;
}

/* {CONF_FILE_RULE}.set_description */
void F388_4826 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {CONF_FILE_RULE}.is_equal */
EIF_BOOLEAN F388_4828 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	if (F1_10(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_), tr1)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		Result = F1_10(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), tr1);
	}
	RTLE;
	return Result;
}

/* {CONF_FILE_RULE}.compile */
void F388_4832 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	tr1 = F388_4833(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F388_4833(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) loc1;
	}
	RTLE;
}

/* {CONF_FILE_RULE}.compile_list */
EIF_REFERENCE F388_4833 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	struct eif_ex_61 sloc4;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) sloc4.data;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc4.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc4.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc4.overhead, eif_new_type(79, 0x00).id);
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,tr1);
	RTLR(7,Result);
	RTLIU(8);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = F1225_10466(RTCW(arg1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc1 = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1052_8104(RTCW(loc1), ((EIF_INTEGER_32) 50L));
		loc2 = RTMS_EX_H("(",1,40);
		loc3 = RTMS_EX_H(")|",2,10620);
		F1225_10507(RTCW(arg1));
		for (;;) {
			tb1 = F1225_10510(RTCW(arg1));
			if (tb1) break;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6902[Dtype(RTCW(loc1))-1053])(loc1, loc2);
			tr1 = F1225_10512(RTCW(arg1));
			F80_1202(RTCW(loc4), tr1, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6902[Dtype(RTCW(loc1))-1053])(loc1, loc3);
			F1225_10508(RTCW(arg1));
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6842[Dtype(RTCW(loc1))-1053])(loc1, ((EIF_INTEGER_32) 1L));
		Result = RTLNS(eif_new_type(1292, 0x01).id, 1292, _OBJSIZ_11_16_0_25_0_0_0_0_);
		F1293_12469(RTCW(Result));
		tb2 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b;
		F1292_12406(RTCW(Result), tb2);
		F1293_12472(RTCW(Result), loc1);
		tb2 = F1292_12390(RTCW(Result));
		if (tb2) {
			F1292_12421(RTCW(Result));
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_4_);
			tr1 = F1049_8033(RTCW(tr1));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
			RTLE;
			return (EIF_REFERENCE) NULL;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit339 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
