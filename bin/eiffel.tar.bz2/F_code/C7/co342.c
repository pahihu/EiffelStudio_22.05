/*
 * Code for class CONF_EXTERNAL_INCLUDE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co342.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_EXTERNAL_INCLUDE}.is_include */
static EIF_BOOLEAN F391_4864_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (4864);
#define Result RTOSR(4864)
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTOSE (4864);
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F391_4864 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(4864,F391_4864_body,(Current));
}

void EIF_Minit342 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
