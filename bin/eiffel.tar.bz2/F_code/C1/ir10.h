
#ifndef _C1_ir10_
#define _C1_ir10_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F15_136(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit10(void);
extern void F207_2611(EIF_REFERENCE, EIF_REFERENCE);
extern void F206_2598(EIF_REFERENCE, EIF_REFERENCE);
extern long O2499[];

#ifdef __cplusplus
}
#endif

#endif
