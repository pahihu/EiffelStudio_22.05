
#ifndef _C1_kl13_
#define _C1_kl13_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F18_152(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit13(void);

#ifdef __cplusplus
}
#endif

#endif
