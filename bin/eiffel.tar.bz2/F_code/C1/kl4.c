/*
 * Code for class KL_STANDARD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl4.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STANDARD_FILES}.error */
static EIF_REFERENCE F4_45_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (45);
#define Result RTOSR(45)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(945, 0x01).id, 945, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (45);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F4_45 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(45,F4_45_body,(Current));
}

void EIF_Minit4 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
