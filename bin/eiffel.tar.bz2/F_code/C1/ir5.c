/*
 * Code for class IRON_PACKAGE_INFO_FILE_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir5.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_INFO_FILE_PARSER}.make */
void F5_46 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1057, 1).id);
	F1049_7974(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.set_callbacks */
void F5_49 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.package_token */

EIF_REFERENCE F5_50 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (50,RTMS_EX_H("package",7,382506597));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.setup_token */

EIF_REFERENCE F5_51 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (51,RTMS_EX_H("setup",5,1703014256));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.project_token */

EIF_REFERENCE F5_52 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (52,RTMS_EX_H("project",7,399506036));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.note_token */

EIF_REFERENCE F5_53 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (53,RTMS_EX_H("note",4,1852798053));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.end_token */

EIF_REFERENCE F5_54 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (54,RTMS_EX_H("end",3,6647396));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse */
void F5_55 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(802, 0x01).id, 802, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F803_6431(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4894[Dtype(RTCW(loc1))-802])(loc1);
	if (tb2) {
		tb2 = F802_6240(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		F802_6272(RTCW(loc1));
		F5_56(Current, loc1);
		F802_6289(RTCW(loc1));
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_file */
void F5_56 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1052_8104(RTCW(loc2), ((EIF_INTEGER_32) 2046L));
	loc1 = F614_6004(RTCW(arg1));
	for (;;) {
		if (loc1) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4950[Dtype(RTCW(arg1))-802])(arg1, ((EIF_INTEGER_32) 2046L));
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O4878[Dtype(arg1)-430]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6904[Dtype(RTCW(loc2))-1053])(loc2, tr1);
		loc1 = '\01';
		tb1 = F614_6004(RTCW(arg1));
		if (!tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O4878[Dtype(arg1)-430]);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			loc1 = (EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 2046L));
		}
	}
	F5_57(Current, loc2);
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_text */
void F5_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	struct eif_ex_61 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(79, 0x00).id);
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1058_8414(RTCW(tr1));
	F80_1218(RTCW(loc1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	F5_58(Current);
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_buffer */
void F5_58 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F741_6139(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) tb1;
	for (;;) {
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
		loc1 = F5_71(Current);
		switch (loc1) {
			case (EIF_CHARACTER_8) '-':
				loc1 = F5_68(Current);
				F5_59(Current);
				break;
			case (EIF_CHARACTER_8) 'p':
				loc1 = F5_68(Current);
				loc2 = F5_74(Current);
				tr1 = F1049_8033(RTCV(RTOSCF(50,F5_50, (Current))));
				tb1 = F1056_8295(RTCW(loc2), tr1);
				if (tb1) {
					F5_60(Current);
				} else {
					tr1 = F1049_8033(RTCV(RTOSCF(52,F5_52, (Current))));
					tb1 = F1056_8295(RTCW(loc2), tr1);
					if (tb1) {
						F5_63(Current);
					} else {
						tr1 = F1049_8033(RTMS_EX_H("Unexpected character [p].",25,883275054));
						F5_67(Current, tr1);
					}
				}
				break;
			case (EIF_CHARACTER_8) 's':
				loc1 = F5_68(Current);
				loc2 = F5_74(Current);
				tr1 = RTOSCF(51,F5_51, (Current));
				tb1 = F1049_8016(RTCW(loc2), tr1);
				if (tb1) {
					F5_61(Current);
				} else {
					tr1 = F1049_8033(RTMS_EX_H("Unexpected character [s].",25,883471662));
					F5_67(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) 'n':
				loc1 = F5_68(Current);
				loc2 = F5_74(Current);
				tr1 = RTOSCF(53,F5_53, (Current));
				tb1 = F1049_8016(RTCW(loc2), tr1);
				if (tb1) {
					F5_65(Current);
				} else {
					tr1 = F1049_8033(RTMS_EX_H("Unexpected character [n].",25,883143982));
					F5_67(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) 'e':
				loc1 = F5_68(Current);
				loc2 = F5_74(Current);
				tr1 = F1049_8033(RTCV(RTOSCF(54,F5_54, (Current))));
				tb1 = F1056_8295(RTCW(loc2), tr1);
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = F1049_8033(RTMS_EX_H("Unexpected character [e].",25,882554158));
					F5_67(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) '\000':
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
					tr1 = F1049_8033(RTMS_EX_H("Unexpected null character.",26,830567726));
					F5_67(Current, tr1);
				}
				break;
			default:
				tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
				tr2 = F5_80(Current, loc1);
				tr1 = F1058_8404(tr1, tr2);
				tr2 = F1049_8033(RTMS_EX_H("].",2,23854));
				tr1 = F1058_8404(RTCW(tr1), tr2);
				F5_67(Current, tr1);
				break;
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_comment */
void F5_59 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = F5_69(Current);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	if ((EIF_BOOLEAN)(loc1 == tw1)) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			loc1 = F5_69(Current);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				loc2 = F5_73(Current);
				tr1 = *(EIF_REFERENCE *)(Current);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					{
						/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_comment) */
						(void) loc3;
						/* END INLINED CODE */
					}
					;
				}
			} else {
				tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
				tr2 = F5_80(Current, loc1);
				tr1 = F1058_8404(tr1, tr2);
				tr2 = F1049_8033(RTMS_EX_H("].",2,23854));
				tr1 = F1058_8404(RTCW(tr1), tr2);
				F5_67(Current, tr1);
			}
		}
	} else {
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F5_80(Current, loc1);
		tr1 = F1058_8404(tr1, tr2);
		tr2 = F1049_8033(RTMS_EX_H("].",2,23854));
		tr1 = F1058_8404(RTCW(tr1), tr2);
		F5_67(Current, tr1);
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_package_declaration */
void F5_60 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	loc2 = F5_71(Current);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc2 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		loc2 = F5_68(Current);
		loc1 = F5_76(Current);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6733[Dtype(RTCW(loc1))-1052])(loc1);
		if (tb1) {
			tr1 = F1049_8033(RTMS_EX_H("Invalid package name",20,1534212709));
			F5_67(Current, tr1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				F207_2615(loc3, loc1);
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_setup_declaration */
void F5_61 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc5 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc5 = F5_71(Current);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc5 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		loc5 = F5_68(Current);
		loc1 = F5_78(Current);
		loc5 = F5_68(Current);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6733[Dtype(RTCW(loc1))-1052])(loc1);
			if (tb1) {
				loc5 = F5_69(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc5 == tw1)) {
					loc5 = F5_68(Current);
					F5_59(Current);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						loc5 = F5_71(Current);
						loc5 = F5_68(Current);
						loc1 = F5_78(Current);
						loc5 = F5_68(Current);
					}
				} else {
					tr1 = F1049_8033(RTMS_EX_H("Invalid setup name",18,1945739621));
					F5_67(Current, tr1);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				tr1 = F1049_8033(RTCV(RTOSCF(52,F5_52, (Current))));
				tb1 = F1056_8295(RTCW(loc1), tr1);
				if (tb1) {
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = F1049_8033(RTCV(RTOSCF(53,F5_53, (Current))));
					tb1 = F1056_8295(RTCW(loc1), tr1);
					if (tb1) {
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = F1049_8033(RTCV(RTOSCF(54,F5_54, (Current))));
						tb1 = F1056_8295(RTCW(loc1), tr1);
						if (tb1) {
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							F5_62(Current, loc1);
							loc5 = F5_68(Current);
							loc5 = F5_71(Current);
							for (;;) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc5 != tw1)) break;
								loc5 = F5_68(Current);
								F5_59(Current);
								loc5 = F5_71(Current);
							}
							loc5 = F5_68(Current);
							loc1 = F5_78(Current);
							loc5 = F5_68(Current);
						}
					}
				}
			}
		}
		if (loc2) {
			F5_65(Current);
		} else {
			if (loc3) {
				F5_63(Current);
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_setup_item_declaration */
void F5_62 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc5);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	loc4 = F5_71(Current);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	if ((EIF_BOOLEAN)(loc4 == tw1)) {
		loc4 = F5_72(Current);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc4 == tw1)) {
			tr1 = F1049_8033(RTMS_EX_H("Syntax error in setup declaration",33,1339518062));
			F5_67(Current, tr1);
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc4 == tw1)) {
				loc4 = F5_69(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					loc1 = F5_73(Current);
					tb1 = F1049_7992(RTCW(loc1));
					if (tb1) {
						loc2 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F1049_7974(RTCW(loc2));
						for (;;) {
							if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3)) break;
							loc1 = F5_73(Current);
							F1058_8370(RTCW(loc1));
							tr1 = F1049_8033(RTMS_EX_H("]\"",2,23842));
							tb1 = F1056_8306(RTCW(loc1), tr1);
							if (tb1) {
								tb1 = '\01';
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
								if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
									tb2 = F1056_8303(RTCW(loc1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)));
									tb1 = tb2;
								}
								if (tb1) {
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									F1058_8385(RTCW(loc2), loc1);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
									F1058_8398(RTCW(loc2), tw1);
								}
							} else {
								F1058_8385(RTCW(loc2), loc1);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F1058_8398(RTCW(loc2), tw1);
							}
						}
						if (loc3) {
							F5_81(Current, loc2);
						}
					} else {
						F1058_8376(RTCW(loc1), loc4);
						F1058_8370(RTCW(loc1));
						tr1 = F1049_8033(RTMS_EX_H("\"",1,34));
						tb1 = F1056_8306(RTCW(loc1), tr1);
						if (tb1) {
							F1058_8409(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						} else {
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
							F1058_8376(RTCW(loc1), tw1);
						}
						loc2 = (EIF_REFERENCE) loc1;
					}
				} else {
					loc1 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1049_7974(RTCW(loc1));
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					F1058_8398(RTCW(loc1), tw1);
					F1058_8398(RTCW(loc1), loc4);
					tr1 = F5_73(Current);
					F1058_8385(RTCW(loc1), tr1);
					F1058_8369(RTCW(loc1));
					F1058_8370(RTCW(loc1));
					tb1 = '\0';
					tb2 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
						tw1 = F1058_8352(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tw1 = F1058_8352(RTCW(loc1), ti4_1);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb1 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb1) {
						F1058_8407(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						F1058_8409(RTCW(loc1), ((EIF_INTEGER_32) 1L));
					}
					loc2 = (EIF_REFERENCE) loc1;
					loc4 = F5_71(Current);
				}
			} else {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					loc1 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1049_7974(RTCW(loc1));
					loc2 = (EIF_REFERENCE) loc1;
				} else {
					loc4 = F5_68(Current);
					loc1 = F5_73(Current);
					F1058_8369(RTCW(loc1));
					F1058_8370(RTCW(loc1));
					loc2 = (EIF_REFERENCE) loc1;
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				loc2 = F1049_8033(RTMS_EX_H("",0,0));
			}
			F207_2616(loc5, arg1, loc2);
		}
	} else {
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F5_80(Current, loc4);
		tr1 = F1058_8404(tr1, tr2);
		tr2 = F1049_8033(RTMS_EX_H("].",2,23854));
		tr1 = F1058_8404(RTCW(tr1), tr2);
		F5_67(Current, tr1);
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_projects_declaration */
void F5_63 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc5 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc5 = F5_71(Current);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc5 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		loc5 = F5_68(Current);
		loc1 = F5_78(Current);
		loc5 = F5_68(Current);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6733[Dtype(RTCW(loc1))-1052])(loc1);
			if (tb1) {
				loc5 = F5_69(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc5 == tw1)) {
					loc5 = F5_68(Current);
					F5_59(Current);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						loc5 = F5_71(Current);
						loc5 = F5_68(Current);
						loc1 = F5_78(Current);
						loc5 = F5_68(Current);
					}
				} else {
					tr1 = F1049_8033(RTMS_EX_H("Invalid project name",20,415510117));
					F5_67(Current, tr1);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				tr1 = F1049_8033(RTCV(RTOSCF(51,F5_51, (Current))));
				tb1 = F1056_8295(RTCW(loc1), tr1);
				if (tb1) {
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = F1049_8033(RTCV(RTOSCF(53,F5_53, (Current))));
					tb1 = F1056_8295(RTCW(loc1), tr1);
					if (tb1) {
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = F1049_8033(RTCV(RTOSCF(54,F5_54, (Current))));
						tb1 = F1056_8295(RTCW(loc1), tr1);
						if (tb1) {
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							F5_64(Current, loc1);
							loc5 = F5_68(Current);
							loc5 = F5_71(Current);
							for (;;) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc5 != tw1)) break;
								loc5 = F5_68(Current);
								F5_59(Current);
								loc5 = F5_71(Current);
							}
							loc5 = F5_68(Current);
							loc1 = F5_78(Current);
							loc5 = F5_68(Current);
						}
					}
				}
			}
		}
		if (loc2) {
			F5_65(Current);
		} else {
			if (loc3) {
				F5_61(Current);
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_project_item_declaration */
void F5_64 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	loc2 = F5_71(Current);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	if ((EIF_BOOLEAN)(loc2 == tw1)) {
		loc2 = F5_71(Current);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc2 == tw1)) {
			tr1 = F1049_8033(RTMS_EX_H("Syntax error in project declaration",35,1660760430));
			F5_67(Current, tr1);
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc2 == tw1)) {
				loc1 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1049_7974(RTCW(loc1));
				loc2 = F5_69(Current);
				for (;;) {
					tb1 = '\01';
					if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb1 = (EIF_BOOLEAN)(loc2 == tw1);
					}
					if (tb1) break;
					F1058_8398(RTCW(loc1), loc2);
					loc2 = F5_69(Current);
				}
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					tr1 = *(EIF_REFERENCE *)(Current);
					loc3 = tr1;
					if (EIF_TEST(loc3)) {
						F207_2617(loc3, arg1, loc1);
					}
					loc2 = F5_71(Current);
				}
			} else {
				loc1 = F5_73(Current);
				F1058_8369(RTCW(loc1));
				F1058_8370(RTCW(loc1));
				tr1 = *(EIF_REFERENCE *)(Current);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					F207_2617(loc4, arg1, loc1);
				}
			}
		}
	} else {
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F5_80(Current, loc2);
		tr1 = F1058_8404(tr1, tr2);
		tr2 = F1049_8033(RTMS_EX_H("].",2,23854));
		tr1 = F1058_8404(RTCW(tr1), tr2);
		F5_67(Current, tr1);
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_notes_declaration */
void F5_65 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc2 = F5_71(Current);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc2 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		loc2 = F5_68(Current);
		loc1 = F5_79(Current);
		loc2 = F5_68(Current);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6733[Dtype(RTCW(loc1))-1052])(loc1);
			if (tb1) {
				loc2 = F5_69(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					loc2 = F5_68(Current);
					F5_59(Current);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						loc2 = F5_71(Current);
						loc2 = F5_68(Current);
						loc1 = F5_79(Current);
						loc2 = F5_68(Current);
					}
				} else {
					tr1 = F1049_8033(RTMS_EX_H("Invalid note name",17,17618021));
					F5_67(Current, tr1);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				tr1 = F1049_8033(RTCV(RTOSCF(50,F5_50, (Current))));
				tb1 = F1056_8295(RTCW(loc1), tr1);
				if (tb1) {
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = F1049_8033(RTCV(RTOSCF(51,F5_51, (Current))));
					tb1 = F1056_8295(RTCW(loc1), tr1);
					if (tb1) {
						loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = F1049_8033(RTCV(RTOSCF(54,F5_54, (Current))));
						tb1 = F1056_8295(RTCW(loc1), tr1);
						if (tb1) {
							loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							F5_66(Current, loc1);
							loc2 = F5_68(Current);
							loc2 = F5_71(Current);
							for (;;) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc2 != tw1)) break;
								loc2 = F5_68(Current);
								F5_59(Current);
								loc2 = F5_71(Current);
							}
							loc2 = F5_68(Current);
							loc1 = F5_79(Current);
							loc2 = F5_68(Current);
						}
					}
				}
			}
		}
		if (loc3) {
			tr1 = F1049_8033(RTCV(RTOSCF(50,F5_50, (Current))));
			tb1 = F1056_8295(RTCW(loc1), tr1);
			if (tb1) {
				F5_60(Current);
			} else {
				tr1 = F1049_8033(RTCV(RTOSCF(51,F5_51, (Current))));
				tb1 = F1056_8295(RTCW(loc1), tr1);
				if (tb1) {
					F5_61(Current);
				}
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_note_item_declaration */
void F5_66 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc5);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	loc4 = F5_71(Current);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	if ((EIF_BOOLEAN)(loc4 == tw1)) {
		loc4 = F5_72(Current);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc4 == tw1)) {
			tr1 = F1049_8033(RTMS_EX_H("Syntax error in note declaration",32,1224969838));
			F5_67(Current, tr1);
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc4 == tw1)) {
				loc4 = F5_69(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					loc1 = F5_73(Current);
					tb1 = F1049_7992(RTCW(loc1));
					if (tb1) {
						loc2 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F1049_7974(RTCW(loc2));
						for (;;) {
							if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3)) break;
							loc1 = F5_73(Current);
							F1058_8370(RTCW(loc1));
							tr1 = F1049_8033(RTMS_EX_H("]\"",2,23842));
							tb1 = F1056_8306(RTCW(loc1), tr1);
							if (tb1) {
								tb1 = '\01';
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
								if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
									tb2 = F1056_8303(RTCW(loc1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)));
									tb1 = tb2;
								}
								if (tb1) {
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									F1058_8385(RTCW(loc2), loc1);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
									F1058_8398(RTCW(loc2), tw1);
								}
							} else {
								F1058_8385(RTCW(loc2), loc1);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F1058_8398(RTCW(loc2), tw1);
							}
						}
						if (loc3) {
							F5_81(Current, loc2);
						}
					} else {
						F1058_8376(RTCW(loc1), loc4);
						F1058_8370(RTCW(loc1));
						tr1 = F1049_8033(RTMS_EX_H("\"",1,34));
						tb1 = F1056_8306(RTCW(loc1), tr1);
						if (tb1) {
							F1058_8409(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						} else {
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
							F1058_8376(RTCW(loc1), tw1);
						}
						loc2 = (EIF_REFERENCE) loc1;
					}
				} else {
					loc1 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1049_7974(RTCW(loc1));
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					F1058_8398(RTCW(loc1), tw1);
					F1058_8398(RTCW(loc1), loc4);
					tr1 = F5_73(Current);
					F1058_8385(RTCW(loc1), tr1);
					F1058_8369(RTCW(loc1));
					F1058_8370(RTCW(loc1));
					tb1 = '\0';
					tb2 = '\0';
					tb3 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
						tw1 = F1058_8352(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb3 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb3) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tw1 = F1058_8352(RTCW(loc1), ti4_1);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						ti4_1 = F1056_8282(RTCW(loc1), tw1, ((EIF_INTEGER_32) 2L));
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tb1 = (EIF_BOOLEAN)(ti4_1 == ti4_2);
					}
					if (tb1) {
						F1058_8407(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						F1058_8409(RTCW(loc1), ((EIF_INTEGER_32) 1L));
					}
					loc2 = (EIF_REFERENCE) loc1;
					loc4 = F5_71(Current);
				}
			} else {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					loc1 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1049_7974(RTCW(loc1));
					loc2 = (EIF_REFERENCE) loc1;
				} else {
					loc4 = F5_68(Current);
					loc1 = F5_73(Current);
					F1058_8369(RTCW(loc1));
					F1058_8370(RTCW(loc1));
					loc2 = (EIF_REFERENCE) loc1;
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				loc2 = F1049_8033(RTMS_EX_H("",0,0));
			}
			F207_2618(loc5, arg1, loc2);
		}
	} else {
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F5_80(Current, loc4);
		tr1 = F1058_8404(tr1, tr2);
		tr2 = F1049_8033(RTMS_EX_H("].",2,23854));
		tr1 = F1058_8404(RTCW(tr1), tr2);
		F5_67(Current, tr1);
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.report_error */
void F5_67 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_error) */
			(void) loc1;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.previous_character */
EIF_CHARACTER_32 F5_68 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) >= ((EIF_INTEGER_32) 1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))--;
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = F1058_8352(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
		} else {
			Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		}
		F5_70(Current);
	} else {
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		tr1 = F1049_8033(RTMS_EX_H("out of input",12,330662516));
		F5_67(Current, tr1);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_character */
EIF_CHARACTER_32 F5_69 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		tr1 = F1049_8033(RTMS_EX_H("out of input",12,330662516));
		F5_67(Current, tr1);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1058_8352(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
		F5_70(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.update_end_of_input */
void F5_70 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ti4_1);
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_non_whitespace_character */
EIF_CHARACTER_32 F5_71 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		tr1 = F1049_8033(RTMS_EX_H("out of input",12,330662516));
		F5_67(Current, tr1);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		Result = F5_69(Current);
		for (;;) {
			tb1 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
				tr1 = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = Result;
				tb2 = F1007_7881(RTCW(tr1));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) break;
			Result = F5_69(Current);
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_non_whitespace_character_until_eol */
EIF_CHARACTER_32 F5_72 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		tr1 = F1049_8033(RTMS_EX_H("out of input",12,330662516));
		F5_67(Current, tr1);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		Result = F5_69(Current);
		for (;;) {
			tb1 = '\01';
			tb2 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
				tr1 = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = Result;
				tb3 = F1007_7881(RTCW(tr1));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				tb1 = (EIF_BOOLEAN)(Result == tw1);
			}
			if (tb1) break;
			Result = F5_69(Current);
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_text_until_eol */
EIF_REFERENCE F5_73 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1049_7974(RTCW(Result));
	loc1 = F5_69(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
			tb1 = (EIF_BOOLEAN)(loc1 == tw1);
		}
		if (tb1) break;
		F1058_8398(RTCW(Result), loc1);
		loc1 = F5_69(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alphabetic */
EIF_REFERENCE F5_74 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1049_7974(RTCW(Result));
	loc1 = F5_69(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tr1 = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb2 = F1007_7875(RTCW(tr1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		F1058_8398(RTCW(Result), loc1);
		loc1 = F5_69(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_package_name */
EIF_REFERENCE F5_76 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1049_7974(RTCW(Result));
	loc1 = F5_69(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tb4 = '\01';
			tr1 = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb5 = F1007_7883(RTCW(tr1));
			if (!tb5) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb4 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '+';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		F1058_8398(RTCW(Result), loc1);
		loc1 = F5_69(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alpha_numeric_or_dash */
EIF_REFERENCE F5_78 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1049_7974(RTCW(Result));
	loc1 = F5_69(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tr1 = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb4 = F1007_7883(RTCW(tr1));
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		F1058_8398(RTCW(Result), loc1);
		loc1 = F5_69(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alpha_numeric_with_bracket */
EIF_REFERENCE F5_79 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1049_7974(RTCW(Result));
	loc1 = F5_69(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tb4 = '\01';
			tr1 = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb5 = F1007_7883(RTCW(tr1));
			if (!tb5) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb4 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		F1058_8398(RTCW(Result), loc1);
		loc1 = F5_69(Current);
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
			if ((EIF_BOOLEAN)(loc1 != tw1)) {
				loc2--;
			}
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				loc2++;
			}
		}
	}
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000e\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000 \000\000\000w\000\000\000i\000\000\000t\000\000\000h\000\000\000 \000\000\000b\000\000\000r\000\000\000a\000\000\000c\000\000\000k\000\000\000e\000\000\000t\000\000\000 \000\000\000\"\000\000\000",32,304418082);
		tr1 = F1058_8404(tr1, Result);
		tr2 = F1049_8033(RTMS_EX_H("\"",1,34));
		tr1 = F1058_8404(RTCW(tr1), tr2);
		F5_67(Current, tr1);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.character_to_string */
EIF_REFERENCE F5_80 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1056_8270(RTCW(Result), ((EIF_INTEGER_32) 1L));
	F1058_8398(RTCW(Result), arg1);
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.normalize_multiline */
void F5_81 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc6);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (EIF_INTEGER_32) loc1;
	loc5 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc5)) break;
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
		loc3 = F1056_8282(RTCW(arg1), tw1, loc1);
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			loc3 = (EIF_INTEGER_32) loc5;
		}
		if ((EIF_BOOLEAN)(loc3 == loc1)) {
		} else {
			if ((EIF_BOOLEAN)(loc6 == NULL)) {
				loc2 = (EIF_INTEGER_32) loc1;
				for (;;) {
					tw1 = F1058_8352(RTCW(arg1), loc2);
					tr1 = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tb1 = F1007_7881(RTCW(tr1));
					if ((EIF_BOOLEAN) !tb1) break;
					loc2++;
				}
				loc6 = F1058_8432(RTCW(arg1), loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			} else {
				loc2 = (EIF_INTEGER_32) loc1;
				loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					tb2 = '\01';
					tb3 = '\01';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
					if (!(EIF_BOOLEAN) (loc4 > ti4_1)) {
						tw1 = F1058_8352(RTCW(loc6), loc4);
						tw2 = F1058_8352(RTCW(arg1), loc2);
						tb3 = (EIF_BOOLEAN)(tw1 != tw2);
					}
					if (!tb3) {
						tb2 = (EIF_BOOLEAN) (loc2 > loc3);
					}
					if (tb2) break;
					loc4++;
					loc2++;
				}
				tb3 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (loc4 <= ti4_1)) {
					tw1 = F1058_8352(RTCW(loc6), loc4);
					tw2 = F1058_8352(RTCW(arg1), loc2);
					tb3 = (EIF_BOOLEAN)(tw1 != tw2);
				}
				if (tb3) {
					F1058_8367(RTCW(loc6), (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L)));
				}
			}
		}
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
	}
	tb3 = '\0';
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
		tb3 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb3) {
		tb3 = F1056_8305(RTCW(arg1), loc6);
		if (tb3) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
			F1058_8407(RTCW(arg1), ti4_1);
		}
		tr1 = RTMS32_EX_H("\012\000\000\000",1,10);
		tr1 = F1058_8404(tr1, loc6);
		tr2 = RTMS32_EX_H("\012\000\000\000",1,10);
		F1058_8362(RTCW(arg1), tr1, tr2);
	}
	RTLE;
}

void EIF_Minit5 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
