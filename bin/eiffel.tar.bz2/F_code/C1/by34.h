
#ifndef _C1_by34_
#define _C1_by34_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F38_604(EIF_REFERENCE);
extern void EIF_Minit34(void);

#ifdef __cplusplus
}
#endif

#endif
