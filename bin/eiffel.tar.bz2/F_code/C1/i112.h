
#ifndef _C1_i112_
#define _C1_i112_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F17_151(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit12(void);
extern void F137_1910(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
