/*
 * Code for class CONF_CONDITION_CUSTOM_ATTRIBUTES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co45.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_CONDITION_CUSTOM_ATTRIBUTES}.is_case_insensitive */
EIF_BOOLEAN F50_739 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_NATURAL_8 *)(Current+ _CHROFF_0_1_) == ((EIF_NATURAL_8) 2U));
}

/* {CONF_CONDITION_CUSTOM_ATTRIBUTES}.is_regular_expression */
EIF_BOOLEAN F50_740 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_NATURAL_8 *)(Current+ _CHROFF_0_1_) == ((EIF_NATURAL_8) 3U));
}

/* {CONF_CONDITION_CUSTOM_ATTRIBUTES}.is_wildcard */
EIF_BOOLEAN F50_741 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_NATURAL_8 *)(Current+ _CHROFF_0_1_) == ((EIF_NATURAL_8) 4U));
}

/* {CONF_CONDITION_CUSTOM_ATTRIBUTES}.set_inverted */
void F50_750 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_) = (EIF_BOOLEAN) arg1;
}

/* {CONF_CONDITION_CUSTOM_ATTRIBUTES}.set_match */
void F50_751 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	
	
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_0_1_) = (EIF_NATURAL_8) arg1;
}

void EIF_Minit45 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
