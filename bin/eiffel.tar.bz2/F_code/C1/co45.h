
#ifndef _C1_co45_
#define _C1_co45_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F50_739(EIF_REFERENCE);
extern EIF_BOOLEAN F50_740(EIF_REFERENCE);
extern EIF_BOOLEAN F50_741(EIF_REFERENCE);
extern void F50_750(EIF_REFERENCE, EIF_BOOLEAN);
extern void F50_751(EIF_REFERENCE, EIF_NATURAL_8);
extern void EIF_Minit45(void);

#ifdef __cplusplus
}
#endif

#endif
