/*
 * Code for class CODE_PAGE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co42.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_PAGE_CONSTANTS}.utf7 */

EIF_REFERENCE F47_669 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (669,RTMS_EX_H("UTF-7",5,1414538039));
}

/* {CODE_PAGE_CONSTANTS}.utf8 */

EIF_REFERENCE F47_670 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (670,RTMS_EX_H("UTF-8",5,1414538040));
}

/* {CODE_PAGE_CONSTANTS}.utf16 */

EIF_REFERENCE F47_671 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (671,RTMS_EX_H("UTF-16",6,1345128758));
}

/* {CODE_PAGE_CONSTANTS}.utf32 */

EIF_REFERENCE F47_672 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (672,RTMS_EX_H("UTF-32",6,1345129266));
}

/* {CODE_PAGE_CONSTANTS}.utf16_le */

EIF_REFERENCE F47_673 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (673,RTMS_EX_H("UTF-16LE",8,312185413));
}

/* {CODE_PAGE_CONSTANTS}.utf32_le */

EIF_REFERENCE F47_674 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (674,RTMS_EX_H("UTF-32LE",8,345477701));
}

/* {CODE_PAGE_CONSTANTS}.utf16_be */

EIF_REFERENCE F47_675 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (675,RTMS_EX_H("UTF-16BE",8,312182853));
}

/* {CODE_PAGE_CONSTANTS}.utf32_be */

EIF_REFERENCE F47_676 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (676,RTMS_EX_H("UTF-32BE",8,345475141));
}

void EIF_Minit42 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
