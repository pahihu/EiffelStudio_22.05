/*
 * Code for class IRON_REPOSITORY_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir9.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_REPOSITORY_FACTORY}.new_repository */
EIF_REFERENCE F14_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tb1 = '\01';
	tr1 = RTMS_EX_H("https://",8,441357103);
	tb2 = F1049_8021(RTCW(arg1), tr1);
	if (!tb2) {
		tr1 = RTMS_EX_H("http://",7,769736239);
		tb2 = F1049_8021(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = RTLNS(eif_new_type(1301, 0x01).id, 1301, _OBJSIZ_6_2_0_1_0_0_0_0_);
		F1302_12729(RTCW(loc1), arg1);
		Result = RTLNS(eif_new_type(1060, 0x01).id, 1060, _OBJSIZ_4_0_0_0_0_0_0_0_);
		tr1 = F1302_12747(RTCW(loc1));
		F1061_8476(RTCW(Result), tr1);
	} else {
		tr1 = RTMS_EX_H("file://",7,1704345391);
		tb1 = F1049_8021(RTCW(arg1), tr1);
		if (tb1) {
			loc1 = RTLNS(eif_new_type(1301, 0x01).id, 1301, _OBJSIZ_6_2_0_1_0_0_0_0_);
			F1302_12729(RTCW(loc1), arg1);
			Result = RTLNS(eif_new_type(1061, 0x01).id, 1061, _OBJSIZ_3_0_0_0_0_0_0_0_);
			tr1 = F1302_12747(RTCW(loc1));
			F1062_8489(RTCW(Result), tr1);
		} else {
			Result = RTLNS(eif_new_type(1061, 0x01).id, 1061, _OBJSIZ_3_0_0_0_0_0_0_0_);
			F1062_8487(RTCW(Result), arg1);
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit9 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
