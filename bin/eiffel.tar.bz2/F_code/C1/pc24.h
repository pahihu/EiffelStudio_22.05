
#ifndef _C1_pc24_
#define _C1_pc24_

#ifdef __cplusplus
extern "C" {
#endif

extern void F29_233(EIF_REFERENCE);
extern void F29_234(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F29_236(EIF_REFERENCE, EIF_INTEGER_32);
extern void F29_237(EIF_REFERENCE, EIF_REFERENCE);
extern void F29_238(EIF_REFERENCE, EIF_INTEGER_32);
extern void F29_239(EIF_REFERENCE, EIF_REFERENCE);
extern void F29_240(EIF_REFERENCE, EIF_REFERENCE);
extern void F29_241(EIF_REFERENCE);
extern void EIF_Minit24(void);
extern void F1110_9008(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern char *(*R6854[])();

#ifdef __cplusplus
}
#endif

#endif
