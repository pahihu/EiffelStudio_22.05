
#ifndef _C1_pr43_
#define _C1_pr43_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 677)


extern EIF_REFERENCE F48_677(EIF_REFERENCE);
extern void EIF_Minit43(void);

#ifdef __cplusplus
}
#endif

#endif
