/*
 * Code for class XML_NAMESPACE_RESOLVER_CONTEXT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm40.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.make */
void F45_651 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,917,0xFF01,825,0xFF01,1055,0xFF01,1057,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F918_6848(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.reset */
void F45_652 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F918_6884(RTCW(tr1));
	RTLE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.add_default */
void F45_653 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(665,F45_665, (Current));
	F45_654(Current, arg1, tr1);
	RTLE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.add */
void F45_654 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F918_6851(RTCW(tr1));
	tr2 = F45_662(Current, arg2);
	F826_6615(RTCW(tr1), arg1, tr2);
	RTLE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.shallow_has */
EIF_BOOLEAN F45_656 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_3_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F918_6851(RTCW(tr1));
		tr2 = F45_662(Current, arg1);
		tb1 = F826_6576(RTCW(tr1), tr2);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.has */
EIF_BOOLEAN F45_657 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = F45_662(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = F918_6855(RTCW(tr1));
	tb1 = EIF_FALSE;
	for (;;) {
		if (tb1) break;
		tb2 = F529_5914(loc2);
		if (tb2) break;
		tr1 = F529_5913(loc2);
		tb3 = F826_6576(RTCW(tr1), loc1);
		tb1 = tb3;
		F529_5916(loc2);
	}
	Result = (EIF_BOOLEAN) tb1;
	RTLE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.resolve_default */
EIF_REFERENCE F45_658 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(665,F45_665, (Current));
	Result = F45_659(Current, tr1);
	RTLE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.resolve */
EIF_REFERENCE F45_659 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLR(6,loc1);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTGC;
	Result = RTOSCF(666,F45_666, (Current));
	loc3 = F45_662(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = F918_6855(RTCW(tr1));
	for (;;) {
		tb1 = F529_5914(loc4);
		if (tb1) break;
		if (loc2) break;
		loc1 = F529_5913(loc4);
		tb2 = '\0';
		tb3 = F826_6576(RTCW(loc1), loc3);
		if (tb3) {
			tr1 = F826_6574(RTCW(loc1), loc3);
			loc5 = tr1;
			tb2 = EIF_TEST(loc5);
		}
		if (tb2) {
			Result = (EIF_REFERENCE) loc5;
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		F529_5916(loc4);
	}
	RTLE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.push */
void F45_660 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = F45_664(Current);
	F918_6874(RTCW(tr1), tr2);
	RTLE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.pop */
void F45_661 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_3_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		F918_6867(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5346[Dtype(RTCW(tr1))-774])(tr1);
	}
	RTLE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.to_context_key */
EIF_REFERENCE F45_662 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	
	
	tr1 = F1049_8034(RTCW(arg1));
	return (EIF_REFERENCE) tr1;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.new_string_string_table */
EIF_REFERENCE F45_664 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,825,0xFF01,1055,0xFF01,1057,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 825, _OBJSIZ_7_3_0_7_0_0_0_0_);
	}
	F826_6568(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.default_pseudo_prefix */

EIF_REFERENCE F45_665 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (665,RTMS32_EX_H("",0,0));
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.default_namespace */

EIF_REFERENCE F45_666 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (666,RTMS32_EX_H("",0,0));
}

void EIF_Minit40 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
