
#ifndef _C1_i16_
#define _C1_i16_

#ifdef __cplusplus
extern "C" {
#endif

extern void F11_95(EIF_REFERENCE, EIF_REFERENCE);
extern void F11_96(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit6(void);

#ifdef __cplusplus
}
#endif

#endif
