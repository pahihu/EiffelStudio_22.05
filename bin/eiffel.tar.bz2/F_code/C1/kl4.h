
#ifndef _C1_kl4_
#define _C1_kl4_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,45)
static EIF_REFERENCE F4_45_body(EIF_REFERENCE);
extern EIF_REFERENCE F4_45(EIF_REFERENCE);
extern void EIF_Minit4(void);

#ifdef __cplusplus
}
#endif

#endif
