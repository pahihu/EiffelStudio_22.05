
#ifndef _C1_co21_
#define _C1_co21_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F26_209(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit21(void);
extern void F464_5640(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
