/*
 * Code for class IRON_PACKAGE_INSTALLATION_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir11.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_INSTALLATION_INFO}.make_with_file */
void F16_139 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	F16_145(Current);
	RTLE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.load */
void F16_145 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	struct eif_ex_57 sloc7;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) sloc7.data;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	memset (&sloc7.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc7.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc7.overhead, eif_new_type(75, 0x00).id);
	RTLI(21);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc10);
	RTLR(3,loc1);
	RTLR(4,loc11);
	RTLR(5,loc12);
	RTLR(6,tr2);
	RTLR(7,loc13);
	RTLR(8,loc2);
	RTLR(9,loc3);
	RTLR(10,loc14);
	RTLR(11,loc5);
	RTLR(12,loc15);
	RTLR(13,loc6);
	RTLR(14,loc16);
	RTLR(15,loc17);
	RTLR(16,loc8);
	RTLR(17,loc9);
	RTLR(18,loc7);
	RTLR(19,loc4);
	RTLR(20,loc18);
	RTLIU(21);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1072, 1).id);
	F1073_8911(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = F16_150(Current, *(EIF_REFERENCE *)(Current));
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		loc1 = RTLNS(eif_new_type(1282, 0x01).id, 1282, _OBJSIZ_9_2_0_3_0_0_0_0_);
		F1283_12087(RTCW(loc1), loc10);
		F1283_12107(RTCW(loc1));
		tb1 = '\0';
		tb2 = F1283_12091(RTCW(loc1));
		if (tb2) {
			tr1 = F1283_12103(RTCW(loc1));
			loc11 = tr1;
			tb1 = EIF_TEST(loc11);
		}
		if (tb1) {
			tb1 = '\0';
			tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("repository",10,818164089);
			F1181_9358(RTCW(tr1), tr2);
			tr1 = F1214_10344(loc11, tr1);
			loc12 = tr1;
			loc12 = RTRV(eif_new_type(1213, 0x01),loc12);
			if (EIF_TEST(loc12)) {
				tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("uri",3,7697001);
				F1181_9358(RTCW(tr1), tr2);
				tr1 = F1214_10344(loc12, tr1);
				loc13 = tr1;
				loc13 = RTRV(eif_new_type(1180, 0x01),loc13);
				tb1 = EIF_TEST(loc13);
			}
			if (tb1) {
				loc2 = RTLNS(eif_new_type(13, 0x01).id, 13, _OBJSIZ_0_0_0_0_0_0_0_0_);
				tr1 = *(EIF_REFERENCE *)(loc13);
				tr1 = F1049_8033(RTCW(tr1));
				loc3 = F14_135(RTCW(loc2), tr1);
			}
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5288[Dtype(RTCW(loc3))-1060])(loc3);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
				tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("package-id",10,287790948);
				F1181_9358(RTCW(tr1), tr2);
				tr1 = F1214_10344(loc11, tr1);
				loc14 = tr1;
				loc14 = RTRV(eif_new_type(1180, 0x01),loc14);
				if (EIF_TEST(loc14)) {
					tr1 = *(EIF_REFERENCE *)(loc14);
					loc5 = F1049_8033(RTCW(tr1));
				}
				tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("package-name",12,1583611749);
				F1181_9358(RTCW(tr1), tr2);
				tr1 = F1214_10344(loc11, tr1);
				loc15 = tr1;
				loc15 = RTRV(eif_new_type(1180, 0x01),loc15);
				if (EIF_TEST(loc15)) {
					tr1 = *(EIF_REFERENCE *)(loc15);
					loc6 = F1049_8033(RTCW(tr1));
				}
				tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("local-path",10,315937896);
				F1181_9358(RTCW(tr1), tr2);
				tr1 = F1214_10344(loc11, tr1);
				loc16 = tr1;
				loc16 = RTRV(eif_new_type(1180, 0x01),loc16);
				if (EIF_TEST(loc16)) {
					loc17 = loc3;
					loc17 = RTRV(eif_new_type(1061, 0x01),loc17);
					if (EIF_TEST(loc17)) {
						tr1 = RTLNSMART(eif_new_type(1072, 1).id);
						tr2 = F1181_9371(loc16);
						F1073_8913(RTCW(tr1), tr2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
						if ((EIF_BOOLEAN)(loc6 != NULL)) {
							loc8 = RTLNS(eif_new_type(14, 0x01).id, 14, _OBJSIZ_0_0_0_0_0_0_0_0_);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							tr2 = RTMS_EX_H("package",7,382506597);
							tr1 = F1073_8940(RTCW(tr1), tr2);
							tr2 = RTMS_EX_H("iron",4,1769107310);
							loc9 = F1073_8943(RTCW(tr1), tr2);
							tb1 = F76_1174(RTCW(loc7), loc9);
							if ((EIF_BOOLEAN) !tb1) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								tr1 = F1073_8940(RTCW(tr1), loc6);
								tr2 = RTMS_EX_H("iron",4,1769107310);
								loc9 = F1073_8943(RTCW(tr1), tr2);
							}
							tb1 = F76_1174(RTCW(loc7), loc9);
							if ((EIF_BOOLEAN) !tb1) {
								loc9 = F16_148(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
							}
							tb1 = '\0';
							if ((EIF_BOOLEAN)(loc9 != NULL)) {
								tb2 = F76_1174(RTCW(loc7), loc9);
								tb1 = tb2;
							}
							if (tb1) {
								loc4 = F15_136(RTCW(loc8), loc9);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2508[Dtype(RTCW(loc4))-205])(loc4, loc17);
								RTAR(Current, tr1);
								*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
							}
						}
					} else {
						tr1 = RTLNSMART(eif_new_type(1072, 1).id);
						tr2 = F1181_9371(loc16);
						F1073_8913(RTCW(tr1), tr2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
						tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("package",7,382506597);
						F1181_9358(RTCW(tr1), tr2);
						tr1 = F1214_10344(loc11, tr1);
						loc18 = tr1;
						loc18 = RTRV(eif_new_type(1213, 0x01),loc18);
						if (EIF_TEST(loc18)) {
							tr1 = F16_147(Current, loc18, loc3);
							RTAR(Current, tr1);
							*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
						}
					}
				} else {
					tr1 = RTLNSMART(eif_new_type(1072, 1).id);
					F1073_8911(RTCW(tr1));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				}
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.json_object_to_package */
EIF_REFERENCE F16_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(27);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,arg2);
	RTLR(6,Result);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc6);
	RTLR(10,loc1);
	RTLR(11,loc7);
	RTLR(12,loc8);
	RTLR(13,loc9);
	RTLR(14,loc10);
	RTLR(15,loc11);
	RTLR(16,loc12);
	RTLR(17,loc13);
	RTLR(18,loc14);
	RTLR(19,loc15);
	RTLR(20,loc16);
	RTLR(21,loc17);
	RTLR(22,loc18);
	RTLR(23,tr3);
	RTLR(24,loc19);
	RTLR(25,loc20);
	RTLR(26,loc21);
	RTLIU(27);
	
	RTGC;
	tb1 = '\0';
	tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("id",2,26980);
	F1181_9358(RTCW(tr1), tr2);
	tr1 = F1214_10344(RTCW(arg1), tr1);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1180, 0x01),loc2);
	if (EIF_TEST(loc2)) {
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("name",4,1851878757);
		F1181_9358(RTCW(tr1), tr2);
		tr1 = F1214_10344(RTCW(arg1), tr1);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1180, 0x01),loc3);
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		Result = RTLNS(eif_new_type(1062, 0x01).id, 1062, _OBJSIZ_10_0_0_2_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(loc2);
		F1063_8504(RTCW(Result), tr1, arg2);
		tr1 = F1214_10352(RTCW(arg1));
		tr1 = F1049_8033(RTCW(tr1));
		F1063_8535(RTCW(Result), tr1);
		tr1 = *(EIF_REFERENCE *)(loc3);
		F1063_8539(RTCW(Result), tr1);
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("title",5,1770128485);
		F1181_9358(RTCW(tr1), tr2);
		tr1 = F1214_10344(RTCW(arg1), tr1);
		loc4 = tr1;
		loc4 = RTRV(eif_new_type(1180, 0x01),loc4);
		if (EIF_TEST(loc4)) {
			tr1 = F1181_9371(loc4);
			F1063_8540(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("description",11,801826414);
		F1181_9358(RTCW(tr1), tr2);
		tr1 = F1214_10344(RTCW(arg1), tr1);
		loc5 = tr1;
		loc5 = RTRV(eif_new_type(1180, 0x01),loc5);
		if (EIF_TEST(loc5)) {
			tr1 = F1181_9371(loc5);
			F1063_8541(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_revision",16,1455418222);
		F1181_9358(RTCW(tr1), tr2);
		tr1 = F1214_10344(RTCW(arg1), tr1);
		loc6 = tr1;
		loc6 = RTRV(eif_new_type(1179, 0x01),loc6);
		if (EIF_TEST(loc6)) {
			loc1 = *(EIF_REFERENCE *)(loc6);
			tb1 = F1049_8010(RTCW(loc1));
			if (tb1) {
				tu4_1 = F1049_8044(RTCW(loc1));
				F1063_8542(RTCW(Result), tu4_1);
			}
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive",7,1406298469);
		F1181_9358(RTCW(tr1), tr2);
		tr1 = F1214_10344(RTCW(arg1), tr1);
		loc7 = tr1;
		loc7 = RTRV(eif_new_type(1180, 0x01),loc7);
		if (EIF_TEST(loc7)) {
			tr1 = *(EIF_REFERENCE *)(loc7);
			F1063_8544(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_hash",12,1760719464);
		F1181_9358(RTCW(tr1), tr2);
		tr1 = F1214_10344(RTCW(arg1), tr1);
		loc8 = tr1;
		loc8 = RTRV(eif_new_type(1180, 0x01),loc8);
		if (EIF_TEST(loc8)) {
			tr1 = *(EIF_REFERENCE *)(loc8);
			F1063_8546(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_size",12,1945794917);
		F1181_9358(RTCW(tr1), tr2);
		tr1 = F1214_10344(RTCW(arg1), tr1);
		loc9 = tr1;
		loc9 = RTRV(eif_new_type(1179, 0x01),loc9);
		if (EIF_TEST(loc9)) {
			loc1 = *(EIF_REFERENCE *)(loc9);
			tb1 = F1049_8005(RTCW(loc1));
			if (tb1) {
				ti4_1 = F1049_8039(RTCW(loc1));
				F1063_8543(RTCW(Result), ti4_1);
			}
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("paths",5,1635879027);
		F1181_9358(RTCW(tr1), tr2);
		tr1 = F1214_10344(RTCW(arg1), tr1);
		loc10 = tr1;
		loc10 = RTRV(eif_new_type(1212, 0x01),loc10);
		if (EIF_TEST(loc10)) {
			tr1 = F1213_10321(loc10);
			loc11 = F923_6932(RTCW(tr1));
			for (;;) {
				tb1 = F531_5928(loc11);
				if (tb1) break;
				tr1 = F531_5919(loc11);
				loc12 = tr1;
				loc12 = RTRV(eif_new_type(1180, 0x01),loc12);
				if (EIF_TEST(loc12)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_5_);
					tr2 = *(EIF_REFERENCE *)(loc12);
					F923_6958(RTCW(tr1), tr2);
				}
				F531_5934(loc11);
			}
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("tags",4,1952540531);
		F1181_9358(RTCW(tr1), tr2);
		tr1 = F1214_10344(RTCW(arg1), tr1);
		loc13 = tr1;
		loc13 = RTRV(eif_new_type(1212, 0x01),loc13);
		if (EIF_TEST(loc13)) {
			tr1 = F1213_10321(loc13);
			loc14 = F923_6932(RTCW(tr1));
			for (;;) {
				tb2 = F531_5928(loc14);
				if (tb2) break;
				tr1 = F531_5919(loc14);
				loc15 = tr1;
				loc15 = RTRV(eif_new_type(1180, 0x01),loc15);
				if (EIF_TEST(loc15)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_6_);
					tr2 = F1181_9371(loc15);
					F923_6958(RTCW(tr1), tr2);
				}
				F531_5934(loc14);
			}
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("links",5,1769673587);
		F1181_9358(RTCW(tr1), tr2);
		tr1 = F1214_10344(RTCW(arg1), tr1);
		loc16 = tr1;
		loc16 = RTRV(eif_new_type(1213, 0x01),loc16);
		if (EIF_TEST(loc16)) {
			loc17 = F1214_10354(loc16);
			for (;;) {
				tb3 = F521_5910(loc17);
				if (tb3) break;
				tr1 = F521_5907(loc17);
				loc18 = tr1;
				loc18 = RTRV(eif_new_type(1180, 0x01),loc18);
				if (EIF_TEST(loc18)) {
					tr1 = F1181_9371(loc18);
					tr2 = RTMS32_EX_H("l\000\000\000i\000\000\000n\000\000\000k\000\000\000[\000\000\000",5,1769673563);
					tr3 = F521_5908(loc17);
					tr3 = F1181_9371(RTCW(tr3));
					tr2 = F1058_8404(tr2, tr3);
					tr3 = F1049_8033(RTMS_EX_H("]",1,93));
					tr2 = F1058_8404(RTCW(tr2), tr3);
					F1063_8538(RTCW(Result), tr1, tr2);
				}
				F521_5911(loc17);
			}
		}
		tr1 = RTLNS(eif_new_type(1180, 0x00).id, 1180, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("notes",5,1870743923);
		F1181_9358(RTCW(tr1), tr2);
		tr1 = F1214_10344(RTCW(arg1), tr1);
		loc19 = tr1;
		loc19 = RTRV(eif_new_type(1213, 0x01),loc19);
		if (EIF_TEST(loc19)) {
			loc20 = F1214_10354(loc19);
			for (;;) {
				tb4 = F521_5910(loc20);
				if (tb4) break;
				tr1 = F521_5907(loc20);
				loc21 = tr1;
				loc21 = RTRV(eif_new_type(1180, 0x01),loc21);
				if (EIF_TEST(loc21)) {
					tr1 = F1181_9371(loc21);
					tr2 = F521_5908(loc20);
					tr2 = F1181_9371(RTCW(tr2));
					F1063_8538(RTCW(Result), tr1, tr2);
				}
				F521_5911(loc20);
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.first_iron_file_path_from */
EIF_REFERENCE F16_148 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(419, 0x01).id, 419, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F420_5130(RTCW(loc1), arg1);
	tb1 = F420_5153(RTCW(loc1));
	if (tb1) {
		tr1 = F420_5144(RTCW(loc1));
		tr1 = F923_6932(RTCW(tr1));
		loc2 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = F531_5928(loc2);
			if (tb1) break;
			if ((EIF_BOOLEAN)(Result != NULL)) break;
			tb2 = '\01';
			tr1 = F531_5919(loc2);
			tb3 = F1073_8918(RTCW(tr1));
			if (!tb3) {
				tr1 = F531_5919(loc2);
				tb3 = F1073_8919(RTCW(tr1));
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				tb2 = '\0';
				tr1 = F531_5919(loc2);
				tr1 = F1073_8930(RTCW(tr1));
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					tr1 = RTMS_EX_H("iron",4,1769107310);
					tb3 = F1049_8016(loc3, tr1);
					tb2 = tb3;
				}
				if (tb2) {
					tr1 = F531_5919(loc2);
					Result = F1073_8941(RTCW(arg1), tr1);
				}
			}
			F531_5934(loc2);
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.file_content */
EIF_REFERENCE F16_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(803, 0x01).id, 803, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F802_6203(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = F802_6237(RTCW(loc1));
	if (tb2) {
		tb2 = F802_6256(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5478[Dtype(RTCW(loc1))-802])(loc1);
		Result = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1052_8104(RTCW(Result), ((EIF_INTEGER_32) 1024L));
		for (;;) {
			tb1 = F614_6004(RTCW(loc1));
			if (tb1) break;
			F802_6351(RTCW(loc1), ((EIF_INTEGER_32) 1024L));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O4878[Dtype(loc1)-430]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6902[Dtype(RTCW(Result))-1053])(Result, tr1);
		}
		F802_6289(RTCW(loc1));
	}
	RTLE;
	return Result;
}

void EIF_Minit11 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
