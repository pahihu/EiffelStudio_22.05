
#ifndef _C1_i120_
#define _C1_i120_

#ifdef __cplusplus
extern "C" {
#endif

extern void F25_204(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit20(void);
extern void F139_1936(EIF_REFERENCE, EIF_REFERENCE);
extern long O1756[];
extern long O1757[];

#ifdef __cplusplus
}
#endif

#endif
