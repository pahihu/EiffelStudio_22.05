/*
 * Code for class IRON_PACKAGE_FILE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir10.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_FILE_FACTORY}.new_package_file */
EIF_REFERENCE F15_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(206, 0x01).id, 206, _OBJSIZ_5_2_0_0_0_0_0_0_);
	F207_2611(RTCW(loc1), arg1);
	Result = (EIF_REFERENCE) loc1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(Result) + O2499[Dtype(Result)-204]);
	if (tb1) {
		Result = RTLNS(eif_new_type(205, 0x01).id, 205, _OBJSIZ_4_2_0_0_0_0_0_0_);
		F206_2598(RTCW(Result), arg1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(Result) + O2499[Dtype(Result)-204]);
		if (tb1) {
			RTLE;
			return (EIF_REFERENCE) loc1;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit10 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
