
#ifndef _C1_i13_
#define _C1_i13_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F3_37(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F3_41(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_CHARACTER_8);
extern void EIF_Minit3(void);
extern void F1058_8377(EIF_REFERENCE, EIF_REFERENCE);
extern void F1056_8271(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F1058_8346(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
