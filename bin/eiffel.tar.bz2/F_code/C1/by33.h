
#ifndef _C1_by33_
#define _C1_by33_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F39_604(EIF_REFERENCE);
extern void EIF_Minit33(void);

#ifdef __cplusplus
}
#endif

#endif
