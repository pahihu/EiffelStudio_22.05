
#ifndef _C1_pu15_
#define _C1_pu15_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F20_171(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_NATURAL_32 F20_180(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32, EIF_BOOLEAN);
extern EIF_CHARACTER_8 F20_181(EIF_REFERENCE, EIF_NATURAL_32);
extern EIF_NATURAL_32 F20_182(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32, EIF_REFERENCE);
extern EIF_NATURAL_32 F20_183(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_NATURAL_32 F20_186(EIF_REFERENCE);
extern void EIF_Minit15(void);
extern void F1052_8104(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R6815[])();
extern char *(*R6906[])();
extern char *(*R6755[])();
extern char *(*R6718[])();

#ifdef __cplusplus
}
#endif

#endif
