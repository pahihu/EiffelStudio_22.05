
#ifndef _C1_i119_
#define _C1_i119_

#ifdef __cplusplus
extern "C" {
#endif

extern void F24_197(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit19(void);
extern void F348_3922(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
