
#ifndef _C1_co47_
#define _C1_co47_

#ifdef __cplusplus
extern "C" {
#endif

extern void F52_775(EIF_REFERENCE);
extern void F52_776(EIF_REFERENCE);
extern void F52_777(EIF_REFERENCE);
extern void F52_778(EIF_REFERENCE);
extern void F52_779(EIF_REFERENCE);
extern void F52_780(EIF_REFERENCE);
extern void EIF_Minit47(void);

#ifdef __cplusplus
}
#endif

#endif
