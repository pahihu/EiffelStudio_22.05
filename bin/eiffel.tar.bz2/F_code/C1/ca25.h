
#ifndef _C1_ca25_
#define _C1_ca25_

#ifdef __cplusplus
extern "C" {
#endif

extern void F30_243(EIF_REFERENCE);
extern void F30_244(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F30_245(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F30_247(EIF_REFERENCE, EIF_INTEGER_32);
extern void F30_248(EIF_REFERENCE);
extern void F30_249(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit25(void);
extern void F1111_9008(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R5638[])();

#ifdef __cplusplus
}
#endif

#endif
