
#ifndef _C1_ir9_
#define _C1_ir9_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F14_135(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit9(void);
extern void F1062_8489(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1302_12747(EIF_REFERENCE);
extern void F1061_8476(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1049_8021(EIF_REFERENCE, EIF_REFERENCE);
extern void F1302_12729(EIF_REFERENCE, EIF_REFERENCE);
extern void F1062_8487(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
