
#ifndef _C1_ut2_
#define _C1_ut2_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F2_35(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit2(void);
extern EIF_REFERENCE F80_1215(EIF_REFERENCE, EIF_REFERENCE);
extern void F1049_7974(EIF_REFERENCE);
extern char *(*R4950[])();
extern long O4878[];

#ifdef __cplusplus
}
#endif

#endif
