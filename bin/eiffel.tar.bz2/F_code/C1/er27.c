/*
 * Code for class ERROR_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "er27.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ERROR_CONSTANTS}.err_msg_0 */

EIF_REFERENCE F32_278 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (278,RTMS_EX_H("compilation successfully",24,297046137));
}

/* {ERROR_CONSTANTS}.err_msg_1 */

EIF_REFERENCE F32_279 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (279,RTMS_EX_H("\\ at end of pattern",19,1082148462));
}

/* {ERROR_CONSTANTS}.err_msg_2 */

EIF_REFERENCE F32_280 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (280,RTMS_EX_H("\\c at end of pattern",20,586514030));
}

/* {ERROR_CONSTANTS}.err_msg_3 */

EIF_REFERENCE F32_281 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (281,RTMS_EX_H("unrecognized character follows \\",32,1794949212));
}

/* {ERROR_CONSTANTS}.err_msg_4 */

EIF_REFERENCE F32_282 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (282,RTMS_EX_H("numbers out of order in {} quantifier",37,1764177010));
}

/* {ERROR_CONSTANTS}.err_msg_5 */

EIF_REFERENCE F32_283 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (283,RTMS_EX_H("number too big in {} quantifier",31,236715890));
}

/* {ERROR_CONSTANTS}.err_msg_6 */

EIF_REFERENCE F32_284 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (284,RTMS_EX_H("missing terminating ] for character class",41,461852531));
}

/* {ERROR_CONSTANTS}.err_msg_7 */

EIF_REFERENCE F32_285 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (285,RTMS_EX_H("invalid escape sequence in character class",42,267449459));
}

/* {ERROR_CONSTANTS}.err_msg_8 */

EIF_REFERENCE F32_286 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (286,RTMS_EX_H("range out of order in character class",37,652901747));
}

/* {ERROR_CONSTANTS}.err_msg_9 */

EIF_REFERENCE F32_287 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (287,RTMS_EX_H("nothing to repeat",17,825052276));
}

/* {ERROR_CONSTANTS}.err_msg_11 */

EIF_REFERENCE F32_289 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (289,RTMS_EX_H("internal error: unexpected repeat",33,1855335540));
}

/* {ERROR_CONSTANTS}.err_msg_12 */

EIF_REFERENCE F32_290 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (290,RTMS_EX_H("unrecognized character after (\?",31,636561471));
}

/* {ERROR_CONSTANTS}.err_msg_13 */

EIF_REFERENCE F32_291 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (291,RTMS_EX_H("too many capturing parenthesized sub-patterns",45,1757158771));
}

/* {ERROR_CONSTANTS}.err_msg_14 */

EIF_REFERENCE F32_292 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (292,RTMS_EX_H("missing )",9,1989432361));
}

/* {ERROR_CONSTANTS}.err_msg_15 */

EIF_REFERENCE F32_293 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (293,RTMS_EX_H("back reference to non-existent subpattern",41,1930188142));
}

/* {ERROR_CONSTANTS}.err_msg_18 */

EIF_REFERENCE F32_296 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (296,RTMS_EX_H("missing ) after comment",23,1848893300));
}

/* {ERROR_CONSTANTS}.err_msg_22 */

EIF_REFERENCE F32_300 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (300,RTMS_EX_H("unmatched parentheses",21,366512243));
}

/* {ERROR_CONSTANTS}.err_msg_24 */

EIF_REFERENCE F32_302 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (302,RTMS_EX_H("unrecognized character after (\?<",32,1898751036));
}

/* {ERROR_CONSTANTS}.err_msg_25 */

EIF_REFERENCE F32_303 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (303,RTMS_EX_H("lookbehind assertion is not fixed length",40,831850344));
}

/* {ERROR_CONSTANTS}.err_msg_26 */

EIF_REFERENCE F32_304 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (304,RTMS_EX_H("malformed number after (\?(",26,217491240));
}

/* {ERROR_CONSTANTS}.err_msg_27 */

EIF_REFERENCE F32_305 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (305,RTMS_EX_H("conditional group contains more than two branches",49,572996467));
}

/* {ERROR_CONSTANTS}.err_msg_28 */

EIF_REFERENCE F32_306 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (306,RTMS_EX_H("assertion expected after (\?(",28,1018686248));
}

/* {ERROR_CONSTANTS}.err_msg_30 */

EIF_REFERENCE F32_308 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (308,RTMS_EX_H("unknown POSIX class name",24,1984937317));
}

/* {ERROR_CONSTANTS}.err_msg_31 */

EIF_REFERENCE F32_309 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (309,RTMS_EX_H("POSIX collating elements are not supported",42,1477603940));
}

/* {ERROR_CONSTANTS}.err_msg_35 */

EIF_REFERENCE F32_313 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (313,RTMS_EX_H("invalid condition (\?(0)",23,1170936617));
}

/* {ERROR_CONSTANTS}.err_msg_99 */

EIF_REFERENCE F32_315 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (315,RTMS_EX_H("no pattern compiled",19,1370646116));
}

void EIF_Minit27 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
