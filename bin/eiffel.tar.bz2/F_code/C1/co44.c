/*
 * Code for class COMPILER_PROFILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co44.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COMPILER_PROFILE}.initialize_from_arguments */
void F49_678 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	F49_718(Current);
	loc1 = RTLNS(eif_new_type(466, 0x01).id, 466, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(679,F49_679, (Current));
	ti4_1 = F466_5682(RTCW(loc1), tr1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		F49_705(Current);
	} else {
		tr1 = RTOSCF(680,F49_680, (Current));
		ti4_1 = F466_5682(RTCW(loc1), tr1);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			F49_706(Current);
		}
	}
	tr1 = RTOSCF(681,F49_681, (Current));
	ti4_1 = F466_5682(RTCW(loc1), tr1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		F49_707(Current);
	}
	tr1 = RTOSCF(682,F49_682, (Current));
	ti4_1 = F466_5682(RTCW(loc1), tr1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		F49_708(Current);
	}
	tr1 = RTOSCF(683,F49_683, (Current));
	loc3 = F466_5682(RTCW(loc1), tr1);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F466_5685(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)) <= ti4_1);
	}
	if (tb1) {
		loc2 = F466_5680(RTCW(loc1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
		if (F49_696(Current, loc2)) {
			F49_709(Current, loc2);
		}
	}
	tr1 = RTOSCF(684,F49_684, (Current));
	loc3 = F466_5682(RTCW(loc1), tr1);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F466_5685(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)) <= ti4_1);
	}
	if (tb1) {
		loc2 = F466_5680(RTCW(loc1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
		if (F49_701(Current, loc2)) {
			F49_710(Current, loc2);
		}
	}
	RTLE;
}

/* {COMPILER_PROFILE}.compat_option_name */

EIF_REFERENCE F49_679 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (679,RTMS_EX_H("compat",6,2031575924));
}

/* {COMPILER_PROFILE}.experiment_option_name */

EIF_REFERENCE F49_680 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (680,RTMS_EX_H("experiment",10,207796852));
}

/* {COMPILER_PROFILE}.full_option_name */

EIF_REFERENCE F49_681 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (681,RTMS_EX_H("full",4,1718971500));
}

/* {COMPILER_PROFILE}.safe_option_name */

EIF_REFERENCE F49_682 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (682,RTMS_EX_H("safe",4,1935763045));
}

/* {COMPILER_PROFILE}.platform_option_name */

EIF_REFERENCE F49_683 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (683,RTMS_EX_H("platform",8,459690093));
}

/* {COMPILER_PROFILE}.capabilty_option_name */

EIF_REFERENCE F49_684 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (684,RTMS_EX_H("capability",10,950653049));
}

/* {COMPILER_PROFILE}.is_compatible_mode */
EIF_BOOLEAN F49_689 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 1U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 1U));
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_experimental_mode */
EIF_BOOLEAN F49_691 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 2U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 2U));
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_platform_set */
EIF_BOOLEAN F49_695 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 240U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 != (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_platform_valid */
EIF_BOOLEAN F49_696 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tb2 = '\01';
	tr1 = RTMS_EX_H("windows",7,1657536371);
	tb3 = F1049_8016(RTCW(arg1), tr1);
	if (!tb3) {
		tr1 = RTMS_EX_H("unix",4,1970170232);
		tb3 = F1049_8016(RTCW(arg1), tr1);
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = RTMS_EX_H("macintosh",9,458551400);
		tb2 = F1049_8016(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (!tb1) {
		tr1 = RTMS_EX_H("vxworks",7,1368523123);
		tb1 = F1049_8016(RTCW(arg1), tr1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_unix_platform */
EIF_BOOLEAN F49_697 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 240U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 16U));
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_windows_platform */
EIF_BOOLEAN F49_698 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 240U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 32U));
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_mac_platform */
EIF_BOOLEAN F49_699 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 240U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 48U));
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_vxworks_platform */
EIF_BOOLEAN F49_700 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 240U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 64U));
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_capability_valid */
EIF_BOOLEAN F49_701 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tr1 = RTOSCF(730,F49_730, (Current));
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6761[Dtype(RTCW(arg1))-1052])(arg1, tr1);
	if (!tb2) {
		tr1 = RTOSCF(731,F49_731, (Current));
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6761[Dtype(RTCW(arg1))-1052])(arg1, tr1);
		tb1 = tb2;
	}
	if (!tb1) {
		tr1 = RTOSCF(732,F49_732, (Current));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6761[Dtype(RTCW(arg1))-1052])(arg1, tr1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.set_compatible_mode */
void F49_705 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 1U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_experimental_mode */
void F49_706 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 2U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_full_class_checking_mode */
void F49_707 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 4U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_safe_mode */
void F49_708 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 8U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_platform */
void F49_709 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("windows",7,1657536371);
	tb1 = F1049_8016(RTCW(arg1), tr1);
	if (tb1) {
		F49_711(Current);
	} else {
		tr1 = RTMS_EX_H("unix",4,1970170232);
		tb1 = F1049_8016(RTCW(arg1), tr1);
		if (tb1) {
			F49_712(Current);
		} else {
			tr1 = RTMS_EX_H("macintosh",9,458551400);
			tb1 = F1049_8016(RTCW(arg1), tr1);
			if (tb1) {
				F49_713(Current);
			} else {
				tr1 = RTMS_EX_H("vxworks",7,1368523123);
				tb1 = F1049_8016(RTCW(arg1), tr1);
				if (tb1) {
					F49_714(Current);
				}
			}
		}
	}
	RTLE;
}

/* {COMPILER_PROFILE}.set_capability */
void F49_710 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(730,F49_730, (Current));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6761[Dtype(RTCW(arg1))-1052])(arg1, tr1);
	if (tb1) {
		F49_715(Current);
	} else {
		tr1 = RTOSCF(731,F49_731, (Current));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6761[Dtype(RTCW(arg1))-1052])(arg1, tr1);
		if (tb1) {
			F49_716(Current);
		} else {
			tr1 = RTOSCF(732,F49_732, (Current));
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6761[Dtype(RTCW(arg1))-1052])(arg1, tr1);
			if (tb1) {
				F49_717(Current);
			}
		}
	}
	RTLE;
}

/* {COMPILER_PROFILE}.set_is_windows_platform */
void F49_711 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 32U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_is_unix_platform */
void F49_712 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 16U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_is_mac_platform */
void F49_713 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 48U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_is_vxworks_platform */
void F49_714 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 64U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_capability_warning */
void F49_715 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 512U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 256U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_capability_error */
void F49_716 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 256U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 512U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_capability_strict */
void F49_717 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 1024U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.reset */
void F49_718 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
}

/* {COMPILER_PROFILE}.capability_value_warning */

EIF_REFERENCE F49_730 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (730,RTMS_EX_H("warning",7,1809215079));
}

/* {COMPILER_PROFILE}.capability_value_error */

EIF_REFERENCE F49_731 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (731,RTMS_EX_H("error",5,1920877938));
}

/* {COMPILER_PROFILE}.capability_value_strict */

EIF_REFERENCE F49_732 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (732,RTMS_EX_H("strict",6,2146499444));
}

void EIF_Minit44 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
