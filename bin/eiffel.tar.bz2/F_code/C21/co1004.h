
#ifndef _C21_co1004_
#define _C21_co1004_

#ifdef __cplusplus
extern "C" {
#endif

extern void F589_5987(EIF_REFERENCE);
extern void EIF_Minit1004(void);
extern long O5300[];

#ifdef __cplusplus
}
#endif

#endif
