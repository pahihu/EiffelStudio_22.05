
#ifndef _C21_re1026_
#define _C21_re1026_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F822_6563(EIF_REFERENCE);
extern void EIF_Minit1026(void);
extern void F517_5885(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5253[])();
extern EIF_TYPE_INDEX Y5189[];
extern EIF_TYPE_INDEX *Y5189_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
