
#ifndef _C21_ty1028_
#define _C21_ty1028_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F505_5879(EIF_REFERENCE);
extern void EIF_Minit1028(void);
extern char *(*R5254[])();
extern char *(*R5241[])();
extern char *(*R5638[])();

#ifdef __cplusplus
}
#endif

#endif
