
#ifndef _C21_ar1009_
#define _C21_ar1009_

#ifdef __cplusplus
extern "C" {
#endif

extern void F564_5957(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F564_5958(EIF_REFERENCE);
extern EIF_REFERENCE F564_5959(EIF_REFERENCE);
extern EIF_REFERENCE F564_5961(EIF_REFERENCE);
extern EIF_INTEGER_32 F564_5962(EIF_REFERENCE);
extern void EIF_Minit1009(void);
extern EIF_TYPE_INDEX Y4983[];
extern EIF_TYPE_INDEX *Y4983_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
