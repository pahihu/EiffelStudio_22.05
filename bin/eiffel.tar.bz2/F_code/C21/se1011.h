
#ifndef _C21_se1011_
#define _C21_se1011_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F785_6194(EIF_REFERENCE);
extern void F785_6196(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit1011(void);
extern void F930_6959(EIF_REFERENCE, EIF_NATURAL_64);
extern EIF_BOOLEAN F877_6813(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
