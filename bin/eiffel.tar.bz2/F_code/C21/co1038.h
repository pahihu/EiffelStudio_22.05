
#ifndef _C21_co1038_
#define _C21_co1038_

#ifdef __cplusplus
extern "C" {
#endif

extern void F638_6023(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1038(void);
extern char *(*R5328[])();
extern char *(*R5304[])();
extern char *(*R5306[])();
extern char *(*R5307[])();
extern char *(*R5308[])();
extern char *(*R5321[])();
extern char *(*R5324[])();

#ifdef __cplusplus
}
#endif

#endif
