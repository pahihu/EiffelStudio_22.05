
#ifndef _C21_sp1043_
#define _C21_sp1043_

#ifdef __cplusplus
extern "C" {
#endif

extern void F577_5963(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F577_5964(EIF_REFERENCE);
extern EIF_REFERENCE F577_5965(EIF_REFERENCE);
extern EIF_INTEGER_32 F577_5966(EIF_REFERENCE);
extern void EIF_Minit1043(void);
extern EIF_INTEGER_32 F1117_9019(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4983[];
extern EIF_TYPE_INDEX *Y4983_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
