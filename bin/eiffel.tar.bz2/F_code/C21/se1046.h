
#ifndef _C21_se1046_
#define _C21_se1046_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F786_6194(EIF_REFERENCE);
extern void F786_6196(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit1046(void);
extern char *(*R5328[])();
extern char *(*R5307[])();

#ifdef __cplusplus
}
#endif

#endif
