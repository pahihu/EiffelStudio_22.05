/*
 * Code for class LINEAR [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li1000.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.has */
EIF_BOOLEAN F613_5998 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F930_6949(Current);
	if ((EIF_BOOLEAN) !F877_6813(Current)) {
		F930_6955(Current, arg1);
	}
	Result = F613_6004(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {LINEAR}.search */
void F613_6000 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O5300[Dtype(Current)-581])) {
		for (;;) {
			tb1 = '\01';
			if (!F613_6004(Current)) {
				tb1 = (arg1 == F930_6923(Current));
			}
			if (tb1) break;
			F930_6951(Current);
		}
	} else {
		for (;;) {
			tb2 = '\01';
			if (!F613_6004(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == F930_6923(Current));
			}
			if (tb2) break;
			F930_6951(Current);
		}
	}
	RTLE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F613_6004 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F877_6813(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F613_6006 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F743_6139(Current)) {
		Result = F901_6837(Current);
	}
	RTLE;
	return Result;
}

/* {LINEAR}.linear_representation */
EIF_REFERENCE F613_6013 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

void EIF_Minit1000 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
