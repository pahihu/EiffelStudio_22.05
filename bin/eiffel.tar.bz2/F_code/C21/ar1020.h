
#ifndef _C21_ar1020_
#define _C21_ar1020_

#ifdef __cplusplus
extern "C" {
#endif

extern void F552_5951(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F552_5952(EIF_REFERENCE);
extern EIF_REFERENCE F552_5953(EIF_REFERENCE);
extern EIF_REFERENCE F552_5955(EIF_REFERENCE);
extern EIF_INTEGER_32 F552_5956(EIF_REFERENCE);
extern void EIF_Minit1020(void);
extern EIF_REFERENCE F930_6922(EIF_REFERENCE);
extern EIF_INTEGER_32 F930_6941(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4983[];
extern EIF_TYPE_INDEX *Y4983_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
