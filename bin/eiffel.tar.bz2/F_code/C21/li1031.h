
#ifndef _C21_li1031_
#define _C21_li1031_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F614_5998(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F614_6000(EIF_REFERENCE, EIF_CHARACTER_8);
extern EIF_BOOLEAN F614_6004(EIF_REFERENCE);
extern EIF_BOOLEAN F614_6006(EIF_REFERENCE);
extern EIF_REFERENCE F614_6013(EIF_REFERENCE);
extern void EIF_Minit1031(void);
extern char *(*R5298[])();
extern char *(*R5306[])();
extern char *(*R5307[])();
extern char *(*R5308[])();
extern char *(*R5314[])();
extern char *(*R5319[])();
extern char *(*R5321[])();
extern long O5300[];

#ifdef __cplusplus
}
#endif

#endif
