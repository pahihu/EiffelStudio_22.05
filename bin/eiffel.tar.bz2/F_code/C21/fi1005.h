
#ifndef _C21_fi1005_
#define _C21_fi1005_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F743_6139(EIF_REFERENCE);
extern void EIF_Minit1005(void);
extern char *(*R5404[])();

#ifdef __cplusplus
}
#endif

#endif
