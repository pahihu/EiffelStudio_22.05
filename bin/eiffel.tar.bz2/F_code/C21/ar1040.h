
#ifndef _C21_ar1040_
#define _C21_ar1040_

#ifdef __cplusplus
extern "C" {
#endif

extern void F565_5957(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F565_5958(EIF_REFERENCE);
extern EIF_REFERENCE F565_5959(EIF_REFERENCE);
extern EIF_REFERENCE F565_5961(EIF_REFERENCE);
extern EIF_INTEGER_32 F565_5962(EIF_REFERENCE);
extern void EIF_Minit1040(void);
extern EIF_TYPE_INDEX Y4983[];
extern EIF_TYPE_INDEX *Y4983_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
