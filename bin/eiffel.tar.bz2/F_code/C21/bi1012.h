
#ifndef _C21_bi1012_
#define _C21_bi1012_

#ifdef __cplusplus
extern "C" {
#endif

extern void F625_6017(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit1012(void);
extern void F930_6951(EIF_REFERENCE);
extern EIF_BOOLEAN F743_6139(EIF_REFERENCE);
extern void F613_6000(EIF_REFERENCE, EIF_NATURAL_64);
extern EIF_BOOLEAN F901_6838(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
