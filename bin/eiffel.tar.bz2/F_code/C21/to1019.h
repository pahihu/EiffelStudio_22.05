
#ifndef _C21_to1019_
#define _C21_to1019_

#ifdef __cplusplus
extern "C" {
#endif

extern void F405_4871(EIF_REFERENCE, EIF_INTEGER_32);
extern void F405_4872(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern void F405_4878(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1019(void);
extern void F1116_9008(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4408[];
extern EIF_TYPE_INDEX *Y4408_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
