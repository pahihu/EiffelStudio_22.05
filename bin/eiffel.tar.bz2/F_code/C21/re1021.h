
#ifndef _C21_re1021_
#define _C21_re1021_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F767_6145(EIF_REFERENCE);
extern void F767_6147(EIF_REFERENCE);
extern void EIF_Minit1021(void);
extern char *(*R5405[])();
extern char *(*R5411[])();

#ifdef __cplusplus
}
#endif

#endif
