
#ifndef _C21_bi1047_
#define _C21_bi1047_

#ifdef __cplusplus
extern "C" {
#endif

extern void F626_6017(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit1047(void);
extern void F614_6000(EIF_REFERENCE, EIF_CHARACTER_8);
extern char *(*R5298[])();
extern char *(*R5321[])();
extern char *(*R5322[])();

#ifdef __cplusplus
}
#endif

#endif
