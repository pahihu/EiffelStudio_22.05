
#ifndef _C21_ge1041_
#define _C21_ge1041_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F539_5919(EIF_REFERENCE);
extern EIF_INTEGER_32 F539_5921(EIF_REFERENCE);
extern EIF_BOOLEAN F539_5928(EIF_REFERENCE);
extern void F539_5933(EIF_REFERENCE);
extern void F539_5934(EIF_REFERENCE);
extern EIF_REFERENCE F539_5935(EIF_REFERENCE);
extern void EIF_Minit1041(void);
extern char *(*R5269[])();
extern char *(*R5242[])();
extern long O5268[];
extern long O5270[];

#ifdef __cplusplus
}
#endif

#endif
