
#ifndef _C21_fi1036_
#define _C21_fi1036_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F744_6139(EIF_REFERENCE);
extern void EIF_Minit1036(void);
extern char *(*R5404[])();

#ifdef __cplusplus
}
#endif

#endif
