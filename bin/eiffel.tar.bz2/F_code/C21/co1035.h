
#ifndef _C21_co1035_
#define _C21_co1035_

#ifdef __cplusplus
extern "C" {
#endif

extern void F590_5987(EIF_REFERENCE);
extern void EIF_Minit1035(void);
extern long O5300[];

#ifdef __cplusplus
}
#endif

#endif
