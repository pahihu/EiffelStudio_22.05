
#ifndef _C21_co1007_
#define _C21_co1007_

#ifdef __cplusplus
extern "C" {
#endif

extern void F637_6023(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1007(void);
extern void F930_6951(EIF_REFERENCE);
extern void F930_6949(EIF_REFERENCE);
extern EIF_BOOLEAN F877_6813(EIF_REFERENCE);
extern EIF_NATURAL_64 F930_6923(EIF_REFERENCE);
extern char *(*R5328[])();
extern char *(*R5304[])();
extern char *(*R5324[])();

#ifdef __cplusplus
}
#endif

#endif
