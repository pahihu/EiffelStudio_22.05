
#ifndef _C15_co740_
#define _C15_co740_

#ifdef __cplusplus
extern "C" {
#endif

extern void F631_6023(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit740(void);
extern EIF_BOOLEAN F871_6813(EIF_REFERENCE);
extern void F924_6951(EIF_REFERENCE);
extern void F924_6949(EIF_REFERENCE);
extern EIF_BOOLEAN F924_6923(EIF_REFERENCE);
extern char *(*R5328[])();
extern char *(*R5304[])();
extern char *(*R5324[])();

#ifdef __cplusplus
}
#endif

#endif
