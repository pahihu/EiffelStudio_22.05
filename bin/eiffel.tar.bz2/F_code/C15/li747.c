/*
 * Code for class LIST [BOOLEAN]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li747.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIST}.is_equal */
EIF_BOOLEAN F895_6836 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		Result = '\0';
		tb1 = '\0';
		tb2 = F737_6139(RTCW(arg1));
		if ((EIF_BOOLEAN)(F737_6139(Current) == tb2)) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O5300[Dtype(arg1)-581]);
			tb1 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O5300[dtype-581]) == tb2);
		}
		if (tb1) {
			ti4_1 = F924_6939(RTCW(arg1));
			Result = (EIF_BOOLEAN)(F924_6939(Current) == ti4_1);
		}
		tb1 = '\0';
		if (Result) {
			tb1 = (EIF_BOOLEAN) !F737_6139(Current);
		}
		if (tb1) {
			tb1 = '\0';
			tr1 = F924_6929(Current);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				tr1 = F924_6929(RTCW(arg1));
				loc2 = tr1;
				tb1 = EIF_TEST(loc2);
			}
			if (tb1) {
				F924_6949(Current);
				F924_6949(RTCW(arg1));
				for (;;) {
					tb1 = '\01';
					if (!F895_6837(Current)) {
						tb1 = (EIF_BOOLEAN) !Result;
					}
					if (tb1) break;
					if (*(EIF_BOOLEAN *)(Current + O5300[dtype-581])) {
						Result = F924_6923(Current);
						tb2 = F924_6923(RTCW(arg1));
						Result = (EIF_BOOLEAN) (Result == tb2);
					} else {
						Result = F924_6923(Current);
						tb2 = F924_6923(RTCW(arg1));
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(Result == tb2);
					}
					F924_6951(Current);
					F924_6951(RTCW(arg1));
				}
				F924_6954(Current, loc1);
				F924_6954(RTCW(arg1), loc2);
			} else {
			}
		} else {
			tb2 = '\0';
			tb3 = '\0';
			if (F737_6139(Current)) {
				tb4 = F737_6139(RTCW(arg1));
				tb3 = tb4;
			}
			if (tb3) {
				tb3 = *(EIF_BOOLEAN *)(RTCW(arg1) + O5300[Dtype(arg1)-581]);
				tb2 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O5300[dtype-581]) == tb3);
			}
			if (tb2) {
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTLE;
	return Result;
}

/* {LIST}.after */
EIF_BOOLEAN F895_6837 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
	ti4_2 = F924_6939(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
	RTLE;
	return Result;
}

/* {LIST}.before */
EIF_BOOLEAN F895_6838 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) == ((EIF_INTEGER_32) 0L));
}

void EIF_Minit747 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
