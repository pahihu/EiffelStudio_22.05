/*
 * Code for class CELL [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ce713.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CELL}.item */
EIF_INTEGER_32 F179_2354 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O2286[Dtype(Current)-177]);
}


/* {CELL}.put */
void F179_2355 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O2286[Dtype(Current)-177]) = (EIF_INTEGER_32) arg1;
}

/* {CELL}.replace */
void F179_2356 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O2286[Dtype(Current)-177]) = (EIF_INTEGER_32) arg1;
}

void EIF_Minit713 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
