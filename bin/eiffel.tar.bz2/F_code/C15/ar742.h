
#ifndef _C15_ar742_
#define _C15_ar742_

#ifdef __cplusplus
extern "C" {
#endif

extern void F558_5957(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F558_5958(EIF_REFERENCE);
extern EIF_REFERENCE F558_5959(EIF_REFERENCE);
extern EIF_REFERENCE F558_5961(EIF_REFERENCE);
extern EIF_INTEGER_32 F558_5962(EIF_REFERENCE);
extern void EIF_Minit742(void);
extern EIF_TYPE_INDEX Y4983[];
extern EIF_TYPE_INDEX *Y4983_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
