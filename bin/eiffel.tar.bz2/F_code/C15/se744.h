
#ifndef _C15_se744_
#define _C15_se744_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F779_6194(EIF_REFERENCE);
extern void F779_6196(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit744(void);
extern EIF_BOOLEAN F871_6813(EIF_REFERENCE);
extern void F924_6959(EIF_REFERENCE, EIF_BOOLEAN);

#ifdef __cplusplus
}
#endif

#endif
