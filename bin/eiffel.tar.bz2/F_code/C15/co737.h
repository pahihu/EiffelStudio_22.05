
#ifndef _C15_co737_
#define _C15_co737_

#ifdef __cplusplus
extern "C" {
#endif

extern void F583_5987(EIF_REFERENCE);
extern void EIF_Minit737(void);
extern long O5300[];

#ifdef __cplusplus
}
#endif

#endif
