
#ifndef _C15_ty725_
#define _C15_ty725_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F498_5879(EIF_REFERENCE);
extern void EIF_Minit725(void);
extern char *(*R5254[])();
extern char *(*R5241[])();
extern char *(*R5638[])();

#ifdef __cplusplus
}
#endif

#endif
