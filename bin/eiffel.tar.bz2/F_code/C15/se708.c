/*
 * Code for class SEARCH_TABLE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "se708.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SEARCH_TABLE}.make */
void F1225_10460 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) R8389[Dtype(Current)-1224])(Current, arg1, NULL);
}

/* {SEARCH_TABLE}.make_map */
void F1225_10461 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) R8389[dtype-1224])(Current, arg1, NULL);
	*(EIF_BOOLEAN *)(Current + O8427[dtype-1224]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {SEARCH_TABLE}.make_with_key_tester */
void F1225_10462 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + O8398[dtype-1224]) = (EIF_REFERENCE) arg2;
	tr1 = RTLNS(eif_new_type(734, 0x01).id, 734, _OBJSIZ_0_1_0_1_0_0_0_0_);
	ti4_1 = F735_6129(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * arg1) / ((EIF_INTEGER_32) 2L)));
	*(EIF_INTEGER_32 *)(Current + O8428[dtype-1224]) = (EIF_INTEGER_32) ti4_1;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O8428[dtype-1224]) < ((EIF_INTEGER_32) 5L))) {
		*(EIF_INTEGER_32 *)(Current + O8428[dtype-1224]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	}
	tr2 = RTCCL(loc1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O8428[dtype-1224]);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1108,0xFF02,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y5189,Y5189_gen_type,dftype,469);
			typarr0[3] = l_type.annotations | 0xFF00;
			typarr0[4] = l_type.id;
		}
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNSP2(typres0.id,EO_REF,ti4_1,sizeof(EIF_REFERENCE), EIF_FALSE);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R7513[Dtype(RTCW(tr1))-1108])(tr1, tr2, ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8430[dtype-1224]) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1109,1005,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSP2(typres0.id,0,*(EIF_INTEGER_32 *)(Current + O8428[dtype-1224]),sizeof(EIF_BOOLEAN), EIF_TRUE);
	}
	F1110_9008(RTCW(tr1), (EIF_BOOLEAN) 0, *(EIF_INTEGER_32 *)(Current + O8428[dtype-1224]));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8429[dtype-1224]) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current + O8410[dtype-1224]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current + O8420[dtype-1224]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current + O8413[dtype-1224]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current + O8439[dtype-1224]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_BOOLEAN *)(Current + O8427[dtype-1224]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = RTCCL(loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8396[dtype-1224]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {SEARCH_TABLE}.has */
EIF_BOOLEAN F1225_10464 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O8410[dtype-1224]) > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8414[dtype-1224])(Current, tr1);
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8420[dtype-1224]) == ((EIF_INTEGER_32) 2L));
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {SEARCH_TABLE}.is_empty */
EIF_BOOLEAN F1225_10466 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8410[Dtype(Current)-1224]) == ((EIF_INTEGER_32) 0L));
}

/* {SEARCH_TABLE}.found_item */
EIF_REFERENCE F1225_10469 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O8396[Dtype(Current)-1224]);
}


/* {SEARCH_TABLE}.new_cursor */
EIF_REFERENCE F1225_10472 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,446,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y5189,Y5189_gen_type,Dftype(Current),469);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 446, _OBJSIZ_1_0_0_1_0_0_0_0_);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4993[Dtype(RTCW(tr1))-446])(tr1, Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {SEARCH_TABLE}.is_equal */
EIF_BOOLEAN F1225_10473 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8410[Dtype(arg1)-1224]);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8410[dtype-1224]) == ti4_1)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8398[Dtype(arg1)-1224]);
			tb1 = RTEQ(*(EIF_REFERENCE *)(Current + O8398[dtype-1224]), tr1);
		}
		if (tb1) {
			loc4 = *(EIF_REFERENCE *)(Current + O8430[dtype-1224]);
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7509[Dtype(RTCW(loc4))-1108])(loc4);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 >= loc2) || (EIF_BOOLEAN) !Result)) break;
				loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5638[Dtype(RTCW(loc4))-825])(loc4, loc1);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					tr1 = RTCCL(loc3);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8418[dtype-1224])(Current, tr1);
				}
				if (tb1) {
					tr1 = RTCCL(loc3);
					Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8391[Dtype(RTCW(arg1))-1224])(arg1, tr1);
				}
				loc1++;
			}
		}
	}
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.same_keys */
EIF_BOOLEAN F1225_10475 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8398[Dtype(Current)-1224]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = RTCCL(arg1);
		tr2 = RTCCL(arg2);
		Result = F237_3023(loc1, tr1, tr2);
	} else {
		RTLE;
		return (EIF_BOOLEAN) RTEQ(arg1, arg2);
	}
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.put */
void F1225_10476 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8414[dtype-1224])(Current, tr1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8420[dtype-1224]) == ((EIF_INTEGER_32) 2L))) {
		*(EIF_INTEGER_32 *)(Current + O8420[dtype-1224]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	} else {
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8417[dtype-1224])(Current)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R8415[dtype-1224])(Current);
			tr1 = RTCCL(arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8414[dtype-1224])(Current, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O8430[dtype-1224]);
		tr2 = RTCCL(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O8413[dtype-1224]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R7523[Dtype(RTCW(tr1))-1108])(tr1, tr2, ti4_1);
		(*(EIF_INTEGER_32 *)(Current + O8410[dtype-1224]))++;
		*(EIF_INTEGER_32 *)(Current + O8420[dtype-1224]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {SEARCH_TABLE}.force */
void F1225_10477 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8414[dtype-1224])(Current, tr1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8420[dtype-1224]) != ((EIF_INTEGER_32) 2L))) {
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8417[dtype-1224])(Current)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R8415[dtype-1224])(Current);
			tr1 = RTCCL(arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8414[dtype-1224])(Current, tr1);
		}
		(*(EIF_INTEGER_32 *)(Current + O8410[dtype-1224]))++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O8430[dtype-1224]);
	tr2 = RTCCL(arg1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O8413[dtype-1224]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R7523[Dtype(RTCW(tr1))-1108])(tr1, tr2, ti4_1);
	*(EIF_INTEGER_32 *)(Current + O8420[dtype-1224]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {SEARCH_TABLE}.remove */
void F1225_10479 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8414[dtype-1224])(Current, tr1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8420[dtype-1224]) == ((EIF_INTEGER_32) 2L))) {
		tr1 = *(EIF_REFERENCE *)(Current + O8430[dtype-1224]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7528[Dtype(RTCW(tr1))-1108])(tr1, *(EIF_INTEGER_32 *)(Current + O8413[dtype-1224]), *(EIF_INTEGER_32 *)(Current + O8413[dtype-1224]));
		tr1 = *(EIF_REFERENCE *)(Current + O8429[dtype-1224]);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_BOOLEAN *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current + O8413[dtype-1224]))) = (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
		;
		(*(EIF_INTEGER_32 *)(Current + O8410[dtype-1224]))--;
	}
	RTLE;
}

/* {SEARCH_TABLE}.merge */
void F1225_10483 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,loc3);
	RTLR(5,loc7);
	RTLR(6,tr1);
	RTLIU(7);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O8410[Dtype(arg1)-1224]);
	if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8430[Dtype(arg1)-1224]);
		loc2 = *(EIF_REFERENCE *)(Current + O8430[dtype-1224]);
		loc6 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7509[Dtype(RTCW(loc1))-1108])(loc1);
		loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7509[Dtype(RTCW(loc2))-1108])(loc2);
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc6) * ((EIF_INTEGER_32) 80L)) <= (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * *(EIF_INTEGER_32 *)(Current + O8410[dtype-1224])))) {
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R8411[dtype-1224])(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O8428[dtype-1224]) + loc6)) / ((EIF_INTEGER_32) 2L)));
			for (;;) {
				if ((EIF_BOOLEAN) (loc4 >= loc5)) break;
				loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5638[Dtype(RTCW(loc2))-825])(loc2, loc4);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc7 != NULL)) {
					tr1 = RTCCL(loc7);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8418[dtype-1224])(Current, tr1);
				}
				if (tb1) {
					tr1 = RTCCL(loc7);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8401[Dtype(RTCW(loc3))-1224])(loc3, tr1);
				}
				loc4++;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + O8430[Dtype(loc3)-1224]);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O8430[dtype-1224]) = (EIF_REFERENCE) tr1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + O8429[Dtype(loc3)-1224]);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O8429[dtype-1224]) = (EIF_REFERENCE) tr1;
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O8428[Dtype(loc3)-1224]);
			*(EIF_INTEGER_32 *)(Current + O8428[dtype-1224]) = (EIF_INTEGER_32) ti4_1;
		}
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc4 >= loc6)) break;
			loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5638[Dtype(RTCW(loc1))-825])(loc1, loc4);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc7 != NULL)) {
				tr1 = RTCCL(loc7);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8418[dtype-1224])(Current, tr1);
			}
			if (tb1) {
				tr1 = RTCCL(loc7);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8401[dtype-1224])(Current, tr1);
			}
			loc4++;
		}
	}
	RTLE;
}

/* {SEARCH_TABLE}.resize */
void F1225_10484 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLR(4,loc5);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8430[dtype-1224]);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7509[Dtype(RTCW(tr1))-1108])(tr1);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 80L)) <= (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * arg1))) {
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R8411[dtype-1224])(Current, arg1);
		loc4 = *(EIF_REFERENCE *)(Current + O8430[dtype-1224]);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7509[Dtype(RTCW(loc4))-1108])(loc4);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 >= loc2)) break;
			tb1 = '\0';
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5638[Dtype(RTCW(loc4))-825])(loc4, loc1);
			loc5 = RTCCL(tr1);
			if (EIF_TEST(loc5)) {
				tr1 = RTCCL(loc5);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8418[dtype-1224])(Current, tr1);
			}
			if (tb1) {
				tr1 = RTCCL(loc5);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8401[Dtype(RTCW(loc3))-1224])(loc3, tr1);
			}
			loc1++;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + O8430[Dtype(loc3)-1224]);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O8430[dtype-1224]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + O8429[Dtype(loc3)-1224]);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O8429[dtype-1224]) = (EIF_REFERENCE) tr1;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O8428[Dtype(loc3)-1224]);
		*(EIF_INTEGER_32 *)(Current + O8428[dtype-1224]) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {SEARCH_TABLE}.copy */
void F1225_10486 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	eif_builtin_ANY_standard_copy__o_ (Current, arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8430[Dtype(arg1)-1224]);
	tr1 = F1_14(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8430[dtype-1224]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8429[Dtype(arg1)-1224]);
	tr1 = F1_14(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8429[dtype-1224]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {SEARCH_TABLE}.empty_duplicate */
EIF_REFERENCE F1225_10487 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(Dftype(Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) R8389[Dtype(RTCW(tr1))-1224])(tr1, arg1, *(EIF_REFERENCE *)(Current + O8398[Dtype(Current)-1224]));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {SEARCH_TABLE}.internal_search */
void F1225_10490 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc10);
	RTLR(1,Current);
	RTLR(2,loc11);
	RTLR(3,arg1);
	RTLR(4,loc7);
	RTLR(5,loc8);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTGC;
	loc10 = *(EIF_REFERENCE *)(Current + O8430[dtype-1224]);
	loc11 = *(EIF_REFERENCE *)(Current + O8429[dtype-1224]);
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc3 = *(EIF_INTEGER_32 *)(Current + O8428[dtype-1224]);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6423[Dtype(RTCW(arg1))-999])(arg1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) (loc2 % (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L))));
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 % loc3) - loc1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc9 || (EIF_BOOLEAN) (loc6 >= loc3))) break;
		loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + loc1) % loc3);
		loc6++;
		loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5638[Dtype(RTCW(loc10))-825])(loc10, loc4);
		if ((EIF_BOOLEAN) (RTCEQ(loc7, loc8) || (EIF_BOOLEAN)(loc7 == NULL))) {
			/* INLINED CODE (SPECIAL.item) */
			tb2 = *((EIF_BOOLEAN *)RTCW(loc11) + (loc4));
			/* END INLINED CODE */
			tb1 = tb2;
			if ((EIF_BOOLEAN) !tb1) {
				*(EIF_INTEGER_32 *)(Current + O8420[dtype-1224]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
				loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				if ((EIF_BOOLEAN) (loc5 >= ((EIF_INTEGER_32) 0L))) {
					loc4 = (EIF_INTEGER_32) loc5;
				}
			} else {
				if ((EIF_BOOLEAN) (loc5 < ((EIF_INTEGER_32) 0L))) {
					loc5 = (EIF_INTEGER_32) loc4;
				}
			}
		} else {
			if (*(EIF_BOOLEAN *)(Current + O8427[dtype-1224])) {
				if (RTCEQ(arg1, loc7)) {
					*(EIF_INTEGER_32 *)(Current + O8420[dtype-1224]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				tr1 = RTCCL(arg1);
				tr2 = RTCCL(loc7);
				if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R8400[dtype-1224])(Current, tr1, tr2)) {
					*(EIF_INTEGER_32 *)(Current + O8420[dtype-1224]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			}
		}
	}
	if ((EIF_BOOLEAN) !loc9) {
		*(EIF_INTEGER_32 *)(Current + O8420[dtype-1224]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
		if ((EIF_BOOLEAN) (loc5 >= ((EIF_INTEGER_32) 0L))) {
			loc4 = (EIF_INTEGER_32) loc5;
		}
	}
	*(EIF_INTEGER_32 *)(Current + O8413[dtype-1224]) = (EIF_INTEGER_32) loc4;
	RTLE;
}

/* {SEARCH_TABLE}.add_space */
void F1225_10491 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R8409[dtype-1224])(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * *(EIF_INTEGER_32 *)(Current + O8428[dtype-1224])) / ((EIF_INTEGER_32) 2L)));
}

/* {SEARCH_TABLE}.soon_full */
EIF_BOOLEAN F1225_10493 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8430[dtype-1224]);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7509[Dtype(RTCW(tr1))-1108])(tr1);
	ti4_2 = *(EIF_INTEGER_32 *)(Current + O8410[dtype-1224]);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 80L)) <= (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * ti4_2));
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.valid_key */
EIF_BOOLEAN F1225_10494 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	
	
	return (EIF_BOOLEAN) !RTCEQ(arg1, loc1);
}

/* {SEARCH_TABLE}.start */
void F1225_10507 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O8439[dtype-1224]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8432[dtype-1224])(Current);
	RTLE;
}

/* {SEARCH_TABLE}.forth */
void F1225_10508 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8433[dtype-1224])(Current, *(EIF_INTEGER_32 *)(Current + O8439[dtype-1224]));
	*(EIF_INTEGER_32 *)(Current + O8439[dtype-1224]) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {SEARCH_TABLE}.next_iteration_position */
EIF_INTEGER_32 F1225_10509 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + O8430[dtype-1224]);
	Result = (EIF_INTEGER_32) arg1;
	loc3 = *(EIF_INTEGER_32 *)(Current + O8428[dtype-1224]);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if (loc1) break;
		Result++;
		loc1 = '\01';
		if (!(EIF_BOOLEAN) (Result > loc3)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5638[Dtype(RTCW(loc2))-825])(loc2, Result);
			tr2 = RTCCL(tr1);
			loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8418[dtype-1224])(Current, tr2);
		}
	}
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.after */
EIF_BOOLEAN F1225_10510 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O8439[dtype-1224]) > (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O8428[dtype-1224]) - ((EIF_INTEGER_32) 1L)));
}

/* {SEARCH_TABLE}.item_for_iteration */
EIF_REFERENCE F1225_10512 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("attached content.item (iteration_position) as l_item", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + O8430[dtype-1224]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5638[Dtype(RTCW(tr1))-825])(tr1, *(EIF_INTEGER_32 *)(Current + O8439[dtype-1224]));
	loc1 = RTCCL(tr1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) RTCCL(loc1);
	RTLE;
	return Result;
}

void EIF_Minit708 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
