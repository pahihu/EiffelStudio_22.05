/*
 * Code for class BILINEAR [BOOLEAN]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi745.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BILINEAR}.search */
void F619_6017 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if (F895_6838(Current)) {
		tb1 = (EIF_BOOLEAN) !F737_6139(Current);
	}
	if (tb1) {
		F924_6951(Current);
	}
	F607_6000(Current, arg1);
	RTLE;
}

void EIF_Minit745 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
