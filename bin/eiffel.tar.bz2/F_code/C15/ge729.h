
#ifndef _C15_ge729_
#define _C15_ge729_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F532_5919(EIF_REFERENCE);
extern EIF_INTEGER_32 F532_5921(EIF_REFERENCE);
extern EIF_BOOLEAN F532_5928(EIF_REFERENCE);
extern void F532_5933(EIF_REFERENCE);
extern void F532_5934(EIF_REFERENCE);
extern EIF_REFERENCE F532_5935(EIF_REFERENCE);
extern void EIF_Minit729(void);
extern char *(*R5269[])();
extern char *(*R5242[])();
extern long O5268[];
extern long O5270[];

#ifdef __cplusplus
}
#endif

#endif
