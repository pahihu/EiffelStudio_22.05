/*
 * Code for class TYPE [TYPED_POINTER [POINTER]]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ty719.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TYPE}.name_32 */
EIF_REFERENCE F1094_8973 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		Result = RTLNS(eif_new_type(1056, 0x01).id, 1056, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr1 = F1094_9002(Current);
		F1057_8323(RTCW(Result), tr1);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {TYPE}.name */
EIF_REFERENCE F1094_8974 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		loc1 = F1094_9002(Current);
		Result = RTLNS(eif_new_type(1052, 0x01).id, 1052, _OBJSIZ_1_0_0_4_0_0_0_0_);
		loc2 = loc1;
		if (EIF_TEST(loc2)) {
			tr1 = loc2;
		} else {
			tr2 = RTLNS(eif_new_type(79, 0x00).id, 79, _OBJSIZ_0_0_0_0_0_0_0_0_);
			tr1 = F80_1201(RTCW(tr2), loc1);
		}
		F1052_8106(RTCW(Result), tr1);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {TYPE}.generic_parameter_type */
EIF_REFERENCE F1094_8975 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("generic_parameter_type", 1093, Current, 0, 1, 13566);
	Result = (EIF_REFERENCE) eif_builtin_TYPE_generic_parameter_type__i4_t (Current, arg1);
	if (!Result) {RTEC(EN_FAIL);}
	RTLE;
	RTEE;
	return Result;
}

/* {TYPE}.type_id */
EIF_INTEGER_32 F1094_8976 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (Current);
	return Result;
}

/* {TYPE}.hash_code */
EIF_INTEGER_32 F1094_8977 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (Current);
}

/* {TYPE}.is_attached */
EIF_BOOLEAN F1094_8982 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) eif_builtin_TYPE_is_attached__b (Current);
	return Result;
}

/* {TYPE}.is_equal */
EIF_BOOLEAN F1094_8983 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (Current);
	ti4_2 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (arg1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

/* {TYPE}.default */
EIF_POINTER* F1094_8990 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER* loc1 = (EIF_POINTER*) 0;
	
	
	RTGC;
	return (EIF_POINTER*) 0;
}

/* {TYPE}.out */
EIF_REFERENCE F1094_8991 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = F1094_8973(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1051, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1052_8106(RTCW(tr1), loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = F1094_8974(Current);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1052_8106(RTCW(tr1), loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTCT0("known_string_type", EX_CHECK);
				RTCF0;
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {TYPE}.runtime_name */
EIF_REFERENCE F1094_9002 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("runtime_name", 1093, Current, 0, 0, 13593);
	Result = (EIF_REFERENCE) eif_builtin_TYPE_runtime_name__s1 (Current);
	if (!Result) {RTEC(EN_FAIL);}
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit719 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
