
#ifndef _C15_bi745_
#define _C15_bi745_

#ifdef __cplusplus
extern "C" {
#endif

extern void F619_6017(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit745(void);
extern void F607_6000(EIF_REFERENCE, EIF_BOOLEAN);
extern void F924_6951(EIF_REFERENCE);
extern EIF_BOOLEAN F895_6838(EIF_REFERENCE);
extern EIF_BOOLEAN F737_6139(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
