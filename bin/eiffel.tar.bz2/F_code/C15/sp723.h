
#ifndef _C15_sp723_
#define _C15_sp723_

#ifdef __cplusplus
extern "C" {
#endif

extern void F570_5963(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F570_5964(EIF_REFERENCE);
extern EIF_REFERENCE F570_5965(EIF_REFERENCE);
extern EIF_INTEGER_32 F570_5966(EIF_REFERENCE);
extern void EIF_Minit723(void);
extern EIF_INTEGER_32 F1110_9019(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4983[];
extern EIF_TYPE_INDEX *Y4983_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
