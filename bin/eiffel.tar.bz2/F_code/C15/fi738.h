
#ifndef _C15_fi738_
#define _C15_fi738_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F737_6139(EIF_REFERENCE);
extern void EIF_Minit738(void);
extern char *(*R5404[])();

#ifdef __cplusplus
}
#endif

#endif
