
#ifndef _C15_re728_
#define _C15_re728_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F815_6563(EIF_REFERENCE);
extern void EIF_Minit728(void);
extern void F510_5885(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5253[])();
extern EIF_TYPE_INDEX Y5189[];
extern EIF_TYPE_INDEX *Y5189_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
