
#ifndef _C15_se708_
#define _C15_se708_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1225_10460(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1225_10461(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1225_10462(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern EIF_BOOLEAN F1225_10464(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1225_10466(EIF_REFERENCE);
extern EIF_REFERENCE F1225_10469(EIF_REFERENCE);
extern EIF_REFERENCE F1225_10472(EIF_REFERENCE);
extern EIF_BOOLEAN F1225_10473(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1225_10475(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1225_10476(EIF_REFERENCE, EIF_REFERENCE);
extern void F1225_10477(EIF_REFERENCE, EIF_REFERENCE);
extern void F1225_10479(EIF_REFERENCE, EIF_REFERENCE);
extern void F1225_10483(EIF_REFERENCE, EIF_REFERENCE);
extern void F1225_10484(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1225_10486(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1225_10487(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1225_10490(EIF_REFERENCE, EIF_REFERENCE);
extern void F1225_10491(EIF_REFERENCE);
extern EIF_BOOLEAN F1225_10493(EIF_REFERENCE);
extern EIF_BOOLEAN F1225_10494(EIF_REFERENCE, EIF_REFERENCE);
extern void F1225_10507(EIF_REFERENCE);
extern void F1225_10508(EIF_REFERENCE);
extern EIF_INTEGER_32 F1225_10509(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F1225_10510(EIF_REFERENCE);
extern EIF_REFERENCE F1225_10512(EIF_REFERENCE);
extern void EIF_Minit708(void);
extern EIF_INTEGER_32 F735_6129(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F237_3023(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1110_9008(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R8391[])();
extern char *(*R8432[])();
extern char *(*R4993[])();
extern char *(*R7509[])();
extern char *(*R6423[])();
extern char *(*R8400[])();
extern char *(*R8401[])();
extern char *(*R7513[])();
extern char *(*R8433[])();
extern char *(*R7528[])();
extern char *(*R8409[])();
extern char *(*R8411[])();
extern char *(*R7523[])();
extern char *(*R8414[])();
extern char *(*R8415[])();
extern char *(*R8417[])();
extern char *(*R8418[])();
extern char *(*R8389[])();
extern char *(*R5638[])();
extern long O8410[];
extern long O8413[];
extern long O8420[];
extern long O8427[];
extern long O8428[];
extern long O8429[];
extern long O8396[];
extern long O8398[];
extern long O8430[];
extern long O8439[];
extern EIF_TYPE_INDEX Y5189[];
extern EIF_TYPE_INDEX *Y5189_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
