
#ifndef _C17_ar834_
#define _C17_ar834_

#ifdef __cplusplus
extern "C" {
#endif

extern void F560_5957(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F560_5958(EIF_REFERENCE);
extern EIF_REFERENCE F560_5959(EIF_REFERENCE);
extern EIF_REFERENCE F560_5961(EIF_REFERENCE);
extern EIF_INTEGER_32 F560_5962(EIF_REFERENCE);
extern void EIF_Minit834(void);
extern EIF_TYPE_INDEX Y4983[];
extern EIF_TYPE_INDEX *Y4983_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
