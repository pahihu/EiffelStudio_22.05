
#ifndef _C17_fi830_
#define _C17_fi830_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F739_6139(EIF_REFERENCE);
extern void EIF_Minit830(void);
extern char *(*R5404[])();

#ifdef __cplusplus
}
#endif

#endif
