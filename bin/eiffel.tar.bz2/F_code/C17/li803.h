
#ifndef _C17_li803_
#define _C17_li803_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F530_5913(EIF_REFERENCE);
extern EIF_BOOLEAN F530_5914(EIF_REFERENCE);
extern void F530_5915(EIF_REFERENCE);
extern void F530_5916(EIF_REFERENCE);
extern EIF_REFERENCE F530_5917(EIF_REFERENCE);
extern void EIF_Minit803(void);
extern void F511_5905(EIF_REFERENCE);
extern EIF_BOOLEAN F511_5897(EIF_REFERENCE);
extern void F511_5904(EIF_REFERENCE);
extern EIF_INTEGER_32 F499_5879(EIF_REFERENCE);
extern EIF_BOOLEAN F511_5899(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
