/*
 * Code for class LINEAR [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li825.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.has */
EIF_BOOLEAN F609_5998 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F926_6949(Current);
	if ((EIF_BOOLEAN) !F873_6813(Current)) {
		F926_6955(Current, arg1);
	}
	Result = F609_6004(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {LINEAR}.search */
void F609_6000 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O5300[Dtype(Current)-581])) {
		for (;;) {
			tb1 = '\01';
			if (!F609_6004(Current)) {
				tb1 = (arg1 == F926_6923(Current));
			}
			if (tb1) break;
			F926_6951(Current);
		}
	} else {
		for (;;) {
			tb2 = '\01';
			if (!F609_6004(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == F926_6923(Current));
			}
			if (tb2) break;
			F926_6951(Current);
		}
	}
	RTLE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F609_6004 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F873_6813(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F609_6006 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F739_6139(Current)) {
		Result = F897_6837(Current);
	}
	RTLE;
	return Result;
}

/* {LINEAR}.linear_representation */
EIF_REFERENCE F609_6013 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

void EIF_Minit825 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
