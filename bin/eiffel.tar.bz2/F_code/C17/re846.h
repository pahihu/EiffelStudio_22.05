
#ifndef _C17_re846_
#define _C17_re846_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F763_6145(EIF_REFERENCE);
extern void F763_6147(EIF_REFERENCE);
extern void EIF_Minit846(void);
extern char *(*R5405[])();
extern char *(*R5411[])();

#ifdef __cplusplus
}
#endif

#endif
