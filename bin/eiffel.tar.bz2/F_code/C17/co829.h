
#ifndef _C17_co829_
#define _C17_co829_

#ifdef __cplusplus
extern "C" {
#endif

extern void F585_5987(EIF_REFERENCE);
extern void EIF_Minit829(void);
extern long O5300[];

#ifdef __cplusplus
}
#endif

#endif
