
#ifndef _C17_ge821_
#define _C17_ge821_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F534_5919(EIF_REFERENCE);
extern EIF_INTEGER_32 F534_5921(EIF_REFERENCE);
extern EIF_BOOLEAN F534_5928(EIF_REFERENCE);
extern void F534_5933(EIF_REFERENCE);
extern void F534_5934(EIF_REFERENCE);
extern EIF_REFERENCE F534_5935(EIF_REFERENCE);
extern void EIF_Minit821(void);
extern char *(*R5269[])();
extern char *(*R5242[])();
extern long O5268[];
extern long O5270[];

#ifdef __cplusplus
}
#endif

#endif
