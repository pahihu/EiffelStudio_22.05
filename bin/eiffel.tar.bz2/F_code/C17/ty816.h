
#ifndef _C17_ty816_
#define _C17_ty816_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F500_5879(EIF_REFERENCE);
extern void EIF_Minit816(void);
extern char *(*R5254[])();
extern char *(*R5241[])();
extern char *(*R5638[])();

#ifdef __cplusplus
}
#endif

#endif
