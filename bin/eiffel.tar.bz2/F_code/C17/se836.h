
#ifndef _C17_se836_
#define _C17_se836_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F781_6194(EIF_REFERENCE);
extern void F781_6196(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit836(void);
extern EIF_BOOLEAN F873_6813(EIF_REFERENCE);
extern void F926_6959(EIF_REFERENCE, EIF_NATURAL_32);

#ifdef __cplusplus
}
#endif

#endif
