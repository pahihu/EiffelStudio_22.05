
#ifndef _C17_ar845_
#define _C17_ar845_

#ifdef __cplusplus
extern "C" {
#endif

extern void F548_5951(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F548_5952(EIF_REFERENCE);
extern EIF_REFERENCE F548_5953(EIF_REFERENCE);
extern EIF_REFERENCE F548_5955(EIF_REFERENCE);
extern EIF_INTEGER_32 F548_5956(EIF_REFERENCE);
extern void EIF_Minit845(void);
extern EIF_INTEGER_32 F926_6941(EIF_REFERENCE);
extern EIF_REFERENCE F926_6922(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4983[];
extern EIF_TYPE_INDEX *Y4983_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
