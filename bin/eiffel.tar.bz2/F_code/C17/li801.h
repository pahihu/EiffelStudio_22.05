
#ifndef _C17_li801_
#define _C17_li801_

#ifdef __cplusplus
extern "C" {
#endif

extern void F300_3759(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN);
extern void EIF_Minit801(void);

#ifdef __cplusplus
}
#endif

#endif
