
#ifndef _C17_dy841_
#define _C17_dy841_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F885_6822(EIF_REFERENCE);
extern void EIF_Minit841(void);

#ifdef __cplusplus
}
#endif

#endif
