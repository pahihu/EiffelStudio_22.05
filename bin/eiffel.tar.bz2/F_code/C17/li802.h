
#ifndef _C17_li802_
#define _C17_li802_

#ifdef __cplusplus
extern "C" {
#endif

extern void F184_2358(EIF_REFERENCE, EIF_REFERENCE);
extern void F184_2359(EIF_REFERENCE);
extern void EIF_Minit802(void);

#ifdef __cplusplus
}
#endif

#endif
