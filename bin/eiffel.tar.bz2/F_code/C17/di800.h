
#ifndef _C17_di800_
#define _C17_di800_

#ifdef __cplusplus
extern "C" {
#endif

extern void F773_6152(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit800(void);
extern void F777_6193(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
