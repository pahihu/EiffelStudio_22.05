
#ifndef _C17_co832_
#define _C17_co832_

#ifdef __cplusplus
extern "C" {
#endif

extern void F633_6023(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit832(void);
extern EIF_NATURAL_32 F926_6923(EIF_REFERENCE);
extern void F926_6949(EIF_REFERENCE);
extern EIF_BOOLEAN F873_6813(EIF_REFERENCE);
extern void F926_6951(EIF_REFERENCE);
extern char *(*R5328[])();
extern char *(*R5304[])();
extern char *(*R5324[])();

#ifdef __cplusplus
}
#endif

#endif
