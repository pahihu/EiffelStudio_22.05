
#ifndef _C17_sp814_
#define _C17_sp814_

#ifdef __cplusplus
extern "C" {
#endif

extern void F572_5963(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F572_5964(EIF_REFERENCE);
extern EIF_REFERENCE F572_5965(EIF_REFERENCE);
extern EIF_INTEGER_32 F572_5966(EIF_REFERENCE);
extern void EIF_Minit814(void);
extern EIF_INTEGER_32 F1112_9019(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4983[];
extern EIF_TYPE_INDEX *Y4983_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
