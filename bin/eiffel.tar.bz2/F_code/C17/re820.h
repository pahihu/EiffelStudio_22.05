
#ifndef _C17_re820_
#define _C17_re820_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F817_6563(EIF_REFERENCE);
extern void EIF_Minit820(void);
extern void F512_5885(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5253[])();
extern EIF_TYPE_INDEX Y5189[];
extern EIF_TYPE_INDEX *Y5189_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
