/*
 * Code for class READABLE_INDEXABLE [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re820.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {READABLE_INDEXABLE}.new_cursor */
EIF_REFERENCE F817_6563 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,511,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y5189,Y5189_gen_type,Dftype(Current),469);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		Result = RTLNS(typres0.id, 511, _OBJSIZ_1_1_0_5_0_0_0_0_);
	}
	F512_5885(RTCW(Result), Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5253[Dtype(RTCW(Result))-508])(Result);
	RTLE;
	return Result;
}

void EIF_Minit820 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
