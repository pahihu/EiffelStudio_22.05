
#ifndef _C17_to844_
#define _C17_to844_

#ifdef __cplusplus
extern "C" {
#endif

extern void F401_4871(EIF_REFERENCE, EIF_INTEGER_32);
extern void F401_4872(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern void F401_4878(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit844(void);
extern void F1112_9008(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4408[];
extern EIF_TYPE_INDEX *Y4408_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
