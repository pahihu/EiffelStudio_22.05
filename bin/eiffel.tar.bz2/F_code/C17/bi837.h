
#ifndef _C17_bi837_
#define _C17_bi837_

#ifdef __cplusplus
extern "C" {
#endif

extern void F621_6017(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit837(void);
extern void F609_6000(EIF_REFERENCE, EIF_NATURAL_32);
extern EIF_BOOLEAN F897_6838(EIF_REFERENCE);
extern EIF_BOOLEAN F739_6139(EIF_REFERENCE);
extern void F926_6951(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
