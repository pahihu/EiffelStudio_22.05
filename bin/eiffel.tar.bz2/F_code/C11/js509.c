/*
 * Code for class JSON_NULL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js509.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_NULL}.hash_code */
EIF_INTEGER_32 F1179_9327 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(9331,F1179_9331, (Current));
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6423[Dtype(RTCW(tr1))-999])(tr1);
	RTLE;
	return Result;
}

/* {JSON_NULL}.representation */
EIF_REFERENCE F1179_9328 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTMS_EX_H("null",4,1853189228);
	RTLE;
	return Result;
}

/* {JSON_NULL}.null_value */

EIF_REFERENCE F1179_9331 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9331,RTMS_EX_H("null",4,1853189228));
}

void EIF_Minit509 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
