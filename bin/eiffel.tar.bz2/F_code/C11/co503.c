/*
 * Code for class CONF_ASSEMBLY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co503.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_ASSEMBLY}.make_from_gac */
void F1128_9194 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg6);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLR(6,arg4);
	RTLR(7,arg5);
	RTLR(8,tr2);
	RTLIU(9);
	
	RTGC;
	RTAR(Current, arg6);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg6;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_23_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6777[Dtype(RTCW(arg1))-1052])(arg1);
	F1121_9097(Current, tr1);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) arg3;
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) arg4;
	RTAR(Current, arg5);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg5;
	tr1 = RTLNSMART(eif_final_id(Y7570,Y7570_gen_type,Dftype(Current),1120).id);
	tr2 = RTMS32_EX_H("",0,0);
	F1280_12075(RTCW(tr1), tr2, arg6);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_23_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {CONF_ASSEMBLY}.classes_set */
EIF_BOOLEAN F1128_9195 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_8_) != NULL);
}

/* {CONF_ASSEMBLY}.accessible_groups */
EIF_REFERENCE F1128_9206 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (RTNA((loc1)), ((EIF_REFERENCE) 0));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1224,0xFF01,1120,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNS(typres0.id, 1224, _OBJSIZ_4_1_0_5_0_0_0_0_);
		}
		F1225_10461(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {CONF_ASSEMBLY}.class_by_name */
EIF_REFERENCE F1128_9208 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	Result = F1121_9087(Current, arg1, arg2);
	if (arg2) {
		loc2 = F1225_10472(RTCV(F1128_9206(Current)));
		for (;;) {
			tb1 = F447_5584(loc2);
			if (tb1) break;
			loc1 = F447_5583(loc2);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7556[Dtype(RTCW(loc1))-1123])(loc1);
			if (tb2) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R7583[Dtype(RTCW(loc1))-1123])(loc1, arg1, (EIF_BOOLEAN) 0);
				F870_6817(RTCW(Result), tr1);
			}
			F447_5585(loc2);
		}
	}
	RTLE;
	return Result;
}

/* {CONF_ASSEMBLY}.name_by_class */
EIF_REFERENCE F1128_9209 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	Result = F1121_9088(Current, arg1, arg2);
	if (arg2) {
		loc2 = F1128_9206(Current);
		F1225_10507(RTCW(loc2));
		for (;;) {
			tb1 = F1225_10510(RTCW(loc2));
			if (tb1) break;
			loc1 = F1225_10512(RTCW(loc2));
			F1225_10508(RTCW(loc2));
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7556[Dtype(RTCW(loc1))-1123])(loc1);
			if (tb2) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R7584[Dtype(RTCW(loc1))-1123])(loc1, arg1, (EIF_BOOLEAN) 0);
				F870_6817(RTCW(Result), tr1);
			}
		}
	}
	RTLE;
	return Result;
}

/* {CONF_ASSEMBLY}.process */
void F1128_9221 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1121_9112(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8951[Dtype(RTCW(arg1))-1254])(arg1, Current);
	RTLE;
}

void EIF_Minit503 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
