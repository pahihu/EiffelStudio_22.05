
#ifndef _C11_co502_
#define _C11_co502_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1127_9191(EIF_REFERENCE, EIF_REFERENCE);
extern void F1127_9193(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit502(void);
extern void F1056_8272(EIF_REFERENCE, EIF_REFERENCE);
extern void F1058_8427(EIF_REFERENCE);
extern void F826_6569(EIF_REFERENCE, EIF_INTEGER_32);
extern void F826_6615(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern long O7659[];
extern long O7660[];

#ifdef __cplusplus
}
#endif

#endif
