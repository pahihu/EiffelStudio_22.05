/*
 * Code for class CONF_LIBRARY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co504.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LIBRARY}.make */
void F1129_9222 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	F1121_9056(Current, arg1, arg2, arg3);
	*(EIF_BOOLEAN *)(Current + O7619[Dtype(Current)-1120]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {CONF_LIBRARY}.is_readonly */
EIF_BOOLEAN F1129_9224 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O7605[dtype-1120])) {
		RTLE;
		return (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current + O7619[dtype-1120]);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_8_);
			Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_16_3_);
		} else {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTLE;
	return Result;
}

/* {CONF_LIBRARY}.mapping */
EIF_REFERENCE F1129_9227 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1072_8829(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,834,0xFF01,1055,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNS(typres0.id, 834, _OBJSIZ_7_4_0_7_0_0_0_0_);
		}
		F826_6569(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {CONF_LIBRARY}.class_by_name */
EIF_REFERENCE F1129_9229 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLR(6,Result);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLIU(9);
	
	RTGC;
	loc2 = F1129_9227(Current);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = F826_6574(RTCW(loc2), arg1);
		loc3 = tr1;
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		loc1 = (EIF_REFERENCE) loc3;
	} else {
		loc1 = (EIF_REFERENCE) arg1;
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,921,0xFF01,1070,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 921, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F918_6848(RTCW(Result));
	tb1 = '\0';
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = F826_6574(loc4, loc1);
		loc5 = tr1;
		tb2 = EIF_TEST(loc5);
	}
	if (tb2) {
		tb2 = F1071_8731(loc5);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F922_6910(RTCW(Result), loc5);
	}
	RTLE;
	return Result;
}

/* {CONF_LIBRARY}.path */
EIF_REFERENCE F1129_9234 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(9239,F1129_9239, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = F1279_12062(RTCW(tr2));
	tr2 = F1073_8952(RTCW(tr2));
	Result = F171_2241(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {CONF_LIBRARY}.set_use_application_options */
void F1129_9235 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O7676[Dtype(Current)-1128]) = (EIF_BOOLEAN) arg1;
}

/* {CONF_LIBRARY}.set_library_target */
void F1129_9236 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	F1251_11069(RTCW(tr1), Current);
	RTLE;
}

/* {CONF_LIBRARY}.process */
void F1129_9237 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1121_9112(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8953[Dtype(RTCW(arg1))-1254])(arg1, Current);
	RTLE;
}

/* {CONF_LIBRARY}.resolver */
static EIF_REFERENCE F1129_9239_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (9239);
#define Result RTOSR(9239)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(170, 0x01).id, 170, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9239);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1129_9239 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9239,F1129_9239_body,(Current));
}

void EIF_Minit504 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
