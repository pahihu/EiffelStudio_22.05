
#ifndef _C11_co500_
#define _C11_co500_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1125_9178(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit500(void);
extern void F1124_9169(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R8956[])();

#ifdef __cplusplus
}
#endif

#endif
