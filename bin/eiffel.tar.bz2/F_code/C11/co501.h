
#ifndef _C11_co501_
#define _C11_co501_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_BOOLEAN,9179)
static EIF_BOOLEAN F1126_9179_body(EIF_REFERENCE);
extern EIF_BOOLEAN F1126_9179(EIF_REFERENCE);
extern void F1126_9182(EIF_REFERENCE, EIF_REFERENCE);
extern void F1126_9183(EIF_REFERENCE, EIF_REFERENCE);
extern void F1126_9184(EIF_REFERENCE, EIF_REFERENCE);
extern void F1126_9185(EIF_REFERENCE);
extern void F1126_9187(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit501(void);
extern EIF_BOOLEAN F736_6139(EIF_REFERENCE);
extern void F923_6918(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R5328[])();
extern char *(*R8950[])();
extern char *(*R8957[])();

#ifdef __cplusplus
}
#endif

#endif
