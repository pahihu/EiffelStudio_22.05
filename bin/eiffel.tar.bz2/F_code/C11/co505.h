
#ifndef _C11_co505_
#define _C11_co505_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1130_9240(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
RTOSHF (EIF_BOOLEAN,9241)
static EIF_BOOLEAN F1130_9241_body(EIF_REFERENCE);
extern EIF_BOOLEAN F1130_9241(EIF_REFERENCE);
extern void F1130_9243(EIF_REFERENCE, EIF_REFERENCE);
extern void F1130_9244(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit505(void);
extern void F1121_9099(EIF_REFERENCE, EIF_REFERENCE);
extern void F1121_9097(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R6777[])();
extern char *(*R8950[])();
extern char *(*R8954[])();

#ifdef __cplusplus
}
#endif

#endif
