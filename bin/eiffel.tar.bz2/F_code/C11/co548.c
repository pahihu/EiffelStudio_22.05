/*
 * Code for class CONF_SETTING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co548.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_SETTING}.make */
void F1223_10389 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(42, 1).id);
	F43_642(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {CONF_SETTING}.initialize */
void F1223_10391 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		F1223_10395(Current);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
	}
	RTLE;
}

/* {CONF_SETTING}.initialize_conf_location_mapper */
void F1223_10395 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_)) {
		F1223_10397(Current);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_);
	}
	RTLE;
}

/* {CONF_SETTING}.initialize_iron */
void F1223_10397 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_)) {
		if (F426_5293(Current)) {
			loc2 = RTLNS(eif_new_type(461, 0x01).id, 461, _OBJSIZ_2_0_0_0_0_0_0_0_);
			tr1 = F1305_12801(RTCV(F426_5295(Current)));
			tr2 = F1305_12800(RTCV(F426_5295(Current)));
			F462_5612(RTCW(loc2), tr1, tr2);
			loc1 = RTLNS(eif_new_type(155, 0x01).id, 155, _OBJSIZ_3_0_0_0_0_0_0_0_);
			tr1 = RTLNS(eif_new_type(35, 0x01).id, 35, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F156_2103(RTCW(loc1), loc2, tr1);
			tr1 = *(EIF_REFERENCE *)(Current);
			F43_647(RTCW(tr1), loc1);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTLE;
}

void EIF_Minit548 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
