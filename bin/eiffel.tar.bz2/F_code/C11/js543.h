
#ifndef _C11_js543_
#define _C11_js543_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1213_10303(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1213_10309(EIF_REFERENCE);
extern EIF_REFERENCE F1213_10311(EIF_REFERENCE);
extern void F1213_10316(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1213_10320(EIF_REFERENCE);
extern EIF_REFERENCE F1213_10321(EIF_REFERENCE);
extern void EIF_Minit543(void);
extern EIF_BOOLEAN F531_5928(EIF_REFERENCE);
extern EIF_REFERENCE F531_5919(EIF_REFERENCE);
extern void F531_5934(EIF_REFERENCE);
extern EIF_REFERENCE F923_6932(EIF_REFERENCE);
extern void F923_6918(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F923_6939(EIF_REFERENCE);
extern char *(*R5328[])();
extern char *(*R7730[])();
extern char *(*R6423[])();
extern char *(*R6902[])();
extern char *(*R6906[])();

#ifdef __cplusplus
}
#endif

#endif
