/*
 * Code for class I18N_LOCALE_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1547.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_LOCALE_MANAGER}.make */
void F1222_10379 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(1896,F134_1896, (Current));
	tr1 = F17_151(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(1247, 0x01).id, 1247, _OBJSIZ_1_2_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_LOCALE_MANAGER}.locale */
EIF_REFERENCE F1222_10380 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	if (F1222_10383(Current, arg1)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = F137_1911(RTCW(tr1), arg1);
	} else {
		loc2 = RTLNS(eif_new_type(217, 0x01).id, 217, _OBJSIZ_1_0_0_2_0_0_0_0_);
		F216_2694(RTCW(loc2), ((EIF_INTEGER_32) 0L));
	}
	if (F1222_10385(Current, arg1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = F1248_10984(RTCW(tr1), arg1);
	} else {
		loc1 = RTLNS(eif_new_type(123, 0x01).id, 123, _OBJSIZ_35_0_0_5_0_0_0_0_);
		F124_1818(RTCW(loc1));
	}
	tr1 = RTLNS(eif_new_type(32, 0x01).id, 32, _OBJSIZ_6_0_0_0_0_0_0_0_);
	F33_316(RTCW(tr1), loc2, loc1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {I18N_LOCALE_MANAGER}.has_translations */
EIF_BOOLEAN F1222_10383 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\01';
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = F136_1907(RTCW(tr1), arg1);
	if (!tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = F1221_10374(RTCW(arg1));
		tb1 = F136_1908(RTCW(tr1), tr2);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {I18N_LOCALE_MANAGER}.has_formatting_info */
EIF_BOOLEAN F1222_10385 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1248_10985(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

void EIF_Minit547 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
