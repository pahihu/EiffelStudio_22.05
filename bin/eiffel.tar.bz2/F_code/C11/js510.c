/*
 * Code for class JSON_NUMBER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js510.h"
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_NUMBER}.make_integer */
void F1180_9332 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = eif_out__i8_s1(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {JSON_NUMBER}.make_real */
void F1180_9334 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = eif_is_nan_real_64 (arg1);
	if (tb1) {
		tr1 = RTOSCF(9336,F1180_9336, (Current));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		tb1 = eif_is_negative_infinity_real_64 (arg1);
		if (tb1) {
			tr1 = RTOSCF(9337,F1180_9337, (Current));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		} else {
			tb1 = eif_is_positive_infinity_real_64 (arg1);
			if (tb1) {
				tr1 = RTOSCF(9338,F1180_9338, (Current));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
			} else {
				tr1 = eif_out__r8_s1(arg1);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
			}
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTLE;
}

/* {JSON_NUMBER}.nan_real_value */
static EIF_REFERENCE F1180_9336_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9336);
#define Result RTOSR(9336)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1052, 0x01).id, 1052, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("NaN",3,5136718);
	F1052_8106(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9336);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1180_9336 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9336,F1180_9336_body,(Current));
}

/* {JSON_NUMBER}.negative_infinity_real_value */
static EIF_REFERENCE F1180_9337_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9337);
#define Result RTOSR(9337)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1052, 0x01).id, 1052, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("-Infinity",9,2107636601);
	F1052_8106(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9337);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1180_9337 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9337,F1180_9337_body,(Current));
}

/* {JSON_NUMBER}.positive_infinity_real_value */
static EIF_REFERENCE F1180_9338_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9338);
#define Result RTOSR(9338)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1052, 0x01).id, 1052, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS_EX_H("Infinity",8,1600908409);
	F1052_8106(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9338);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1180_9338 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9338,F1180_9338_body,(Current));
}

/* {JSON_NUMBER}.hash_code */
EIF_INTEGER_32 F1180_9341 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6423[Dtype(RTCW(tr1))-999])(tr1);
	RTLE;
	return Result;
}

/* {JSON_NUMBER}.representation */
EIF_REFERENCE F1180_9342 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	tb1 = '\0';
	if (F1180_9350(Current)) {
		tb2 = '\01';
		tb3 = '\01';
		if (!(EIF_BOOLEAN)(loc1 == RTOSCF(9336,F1180_9336, (Current)))) {
			tb3 = (EIF_BOOLEAN)(loc1 == RTOSCF(9337,F1180_9337, (Current)));
		}
		if (!tb3) {
			tb2 = (EIF_BOOLEAN)(loc1 == RTOSCF(9338,F1180_9338, (Current)));
		}
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(1178, 0x01).id, 1178, _OBJSIZ_0_0_0_0_0_0_0_0_);
		RTLE;
		return (EIF_REFERENCE) F1179_9328(RTCW(tr1));
	} else {
		tr1 = F1049_8027(RTCW(loc1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {JSON_NUMBER}.is_real */
EIF_BOOLEAN F1180_9350 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) == ((EIF_INTEGER_32) 2L));
}

/* {JSON_NUMBER}.is_equal */
EIF_BOOLEAN F1180_9352 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-1])(tr1, tr2);
	RTLE;
	return Result;
}

void EIF_Minit510 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
