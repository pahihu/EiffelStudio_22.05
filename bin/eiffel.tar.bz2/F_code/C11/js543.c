/*
 * Code for class JSON_ARRAY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js543.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_ARRAY}.make */
void F1213_10303 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,922,0xFF01,1176,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F923_6918(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {JSON_ARRAY}.representation */
EIF_REFERENCE F1213_10309 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = RTMS_EX_H("[",1,91);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = F923_6932(RTCW(tr1));
	for (;;) {
		tb1 = F531_5928(loc1);
		if (tb1) break;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6906[Dtype(RTCW(Result))-1053])(Result, (EIF_CHARACTER_8) ',');
		}
		tr1 = F531_5919(loc1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7730[Dtype(RTCW(tr1))-1177])(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6902[Dtype(RTCW(Result))-1053])(Result, tr1);
		F531_5934(loc1);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6906[Dtype(RTCW(Result))-1053])(Result, (EIF_CHARACTER_8) ']');
	RTLE;
	return Result;
}

/* {JSON_ARRAY}.new_cursor */
EIF_REFERENCE F1213_10311 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F923_6932(RTCW(tr1));
	RTLE;
	return Result;
}

/* {JSON_ARRAY}.add */
void F1213_10316 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5328[Dtype(RTCW(tr1))-733])(tr1, arg1);
	RTLE;
}

/* {JSON_ARRAY}.hash_code */
EIF_INTEGER_32 F1213_10320 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = F923_6932(RTCW(tr1));
	for (;;) {
		tb1 = F531_5928(loc2);
		if (tb1) break;
		if (loc1) {
			ti4_1 = eif_bit_shift_left((EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 8388593L)),((EIF_INTEGER_32) 8L));
			tr1 = F531_5919(loc2);
			ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6423[Dtype(RTCW(tr1))-999])(tr1);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ti4_2);
		} else {
			tr1 = F531_5919(loc2);
			Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6423[Dtype(RTCW(tr1))-999])(tr1);
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		F531_5934(loc2);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = F923_6939(RTCW(tr1));
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ti4_1);
	RTLE;
	return Result;
}

/* {JSON_ARRAY}.array_representation */
EIF_REFERENCE F1213_10321 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
}

void EIF_Minit543 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
