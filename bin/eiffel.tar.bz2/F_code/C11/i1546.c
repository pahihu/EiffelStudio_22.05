/*
 * Code for class I18N_LOCALE_ID
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1546.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_LOCALE_ID}.make_from_string */
void F1221_10368 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1058_8346(RTCW(loc1), arg1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '@';
	loc2 = F1056_8282(RTCW(loc1), tw1, ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		tr1 = F1058_8432(RTCW(loc1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), ti4_1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
		F1058_8367(RTCW(loc1), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
	}
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
	loc2 = F1056_8282(RTCW(loc1), tw1, ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		tr1 = F1058_8432(RTCW(loc1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), ti4_1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
		F1058_8367(RTCW(loc1), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
	}
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
	loc2 = F1056_8282(RTCW(loc1), tw1, ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		tr1 = F1058_8432(RTCW(loc1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		tr1 = F1058_8432(RTCW(loc1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), ti4_1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	} else {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
		loc3 = F1049_8052(RTCW(loc1), tw1);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5404[Dtype(RTCW(loc3))-774])(loc3);
		switch (ti4_1) {
			case 1L:
				ti4_1 = ((EIF_INTEGER_32) 1L);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5334[Dtype(RTCW(loc3))-851])(loc3, (EIF_REFERENCE) &ti4_1);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
				tr1 = RTLNSMART(eif_new_type(1057, 1).id);
				F1049_7974(RTCW(tr1));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
				break;
			case 2L:
				ti4_1 = ((EIF_INTEGER_32) 1L);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5334[Dtype(RTCW(loc3))-851])(loc3, (EIF_REFERENCE) &ti4_1);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
				ti4_1 = ((EIF_INTEGER_32) 2L);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5334[Dtype(RTCW(loc3))-851])(loc3, (EIF_REFERENCE) &ti4_1);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
				break;
			case 3L:
				ti4_1 = ((EIF_INTEGER_32) 1L);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5334[Dtype(RTCW(loc3))-851])(loc3, (EIF_REFERENCE) &ti4_1);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
				ti4_1 = ((EIF_INTEGER_32) 2L);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5334[Dtype(RTCW(loc3))-851])(loc3, (EIF_REFERENCE) &ti4_1);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
				ti4_1 = ((EIF_INTEGER_32) 3L);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5334[Dtype(RTCW(loc3))-851])(loc3, (EIF_REFERENCE) &ti4_1);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
				break;
			default:
				tr1 = RTLNSMART(eif_new_type(1057, 1).id);
				F1049_7974(RTCW(tr1));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
				tr1 = RTLNSMART(eif_new_type(1057, 1).id);
				F1049_7974(RTCW(tr1));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
				break;
		}
	}
	F1221_10378(Current);
	RTLE;
}

/* {I18N_LOCALE_ID}.language_id */
EIF_REFERENCE F1221_10374 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1219, 0x01).id, 1219, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1220_10363(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {I18N_LOCALE_ID}.hash_code */
EIF_INTEGER_32 F1221_10375 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1049_7983(RTCW(tr1));
	RTLE;
	return Result;
}

/* {I18N_LOCALE_ID}.is_equal */
EIF_BOOLEAN F1221_10376 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	tb2 = F1056_8294(RTCW(tr1), tr2);
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		tb2 = F1056_8294(RTCW(tr1), tr2);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
		Result = F1_10(Current, *(EIF_REFERENCE *)(Current + _REFACS_4_), tr1);
	}
	RTLE;
	return Result;
}

/* {I18N_LOCALE_ID}.set_name */
void F1221_10378 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1_14(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1_14(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F741_6139(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
		F1058_8398(RTCW(tr1), tw1);
		tr1 = *(EIF_REFERENCE *)(Current);
		F1058_8385(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
		F1058_8398(RTCW(tr1), tw1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1058_8385(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1058_8398(RTCW(tr1), tw1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1058_8387(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '@';
		F1058_8398(RTCW(tr1), tw1);
		tr1 = *(EIF_REFERENCE *)(Current);
		F1058_8387(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '@';
		F1058_8398(RTCW(tr1), tw1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1058_8387(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	}
	RTLE;
}

void EIF_Minit546 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
