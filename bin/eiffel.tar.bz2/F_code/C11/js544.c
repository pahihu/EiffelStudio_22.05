/*
 * Code for class JSON_OBJECT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js544.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_OBJECT}.make_with_capacity */
void F1214_10324 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,825,0xFF01,1176,0xFF01,1180,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F826_6568(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {JSON_OBJECT}.put */
void F1214_10328 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTLNS(eif_new_type(1178, 0x01).id, 1178, _OBJSIZ_0_0_0_0_0_0_0_0_);
		F826_6616(RTCW(tr1), tr2, arg2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		F826_6616(RTCW(tr1), arg1, arg2);
	}
	RTLE;
}

/* {JSON_OBJECT}.has_key */
EIF_BOOLEAN F1214_10342 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F826_6576(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {JSON_OBJECT}.item */
EIF_REFERENCE F1214_10344 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F826_6574(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {JSON_OBJECT}.representation */
EIF_REFERENCE F1214_10352 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1052_8104(RTCW(Result), ((EIF_INTEGER_32) 2L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6906[Dtype(RTCW(Result))-1053])(Result, (EIF_CHARACTER_8) '{');
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = F826_6583(RTCW(tr1));
	for (;;) {
		tb1 = F521_5910(loc1);
		if (tb1) break;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6906[Dtype(RTCW(Result))-1053])(Result, (EIF_CHARACTER_8) ',');
		}
		tr1 = F521_5908(loc1);
		tr1 = F1181_9372(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6902[Dtype(RTCW(Result))-1053])(Result, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6906[Dtype(RTCW(Result))-1053])(Result, (EIF_CHARACTER_8) ':');
		tr1 = F521_5907(loc1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7730[Dtype(RTCW(tr1))-1177])(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6902[Dtype(RTCW(Result))-1053])(Result, tr1);
		F521_5911(loc1);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6906[Dtype(RTCW(Result))-1053])(Result, (EIF_CHARACTER_8) '}');
	RTLE;
	return Result;
}

/* {JSON_OBJECT}.new_cursor */
EIF_REFERENCE F1214_10354 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F826_6583(RTCW(tr1));
	RTLE;
	return Result;
}

/* {JSON_OBJECT}.hash_code */
EIF_INTEGER_32 F1214_10358 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F826_6607(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F1_25(RTCW(tr1));
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6423[Dtype(RTCW(tr1))-999])(tr1);
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tb1 = F826_6603(RTCW(tr1));
		if (tb1) break;
		ti4_1 = eif_bit_shift_left((EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 8388593L)),((EIF_INTEGER_32) 8L));
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F826_6580(RTCW(tr1));
		ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6423[Dtype(RTCW(tr1))-999])(tr1);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ti4_2);
		tr1 = *(EIF_REFERENCE *)(Current);
		F826_6608(RTCW(tr1));
	}
	ti4_1 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (Result)));
	RTLE;
	return (EIF_INTEGER_32) ti4_1;
}

void EIF_Minit544 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
