
#ifndef _C11_js508_
#define _C11_js508_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1178_9317(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1178_9318(EIF_REFERENCE);
extern void F1178_9319(EIF_REFERENCE);
extern EIF_INTEGER_32 F1178_9322(EIF_REFERENCE);
extern EIF_REFERENCE F1178_9323(EIF_REFERENCE);
extern void EIF_Minit508(void);

#ifdef __cplusplus
}
#endif

#endif
