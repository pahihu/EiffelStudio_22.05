
#ifndef _C11_js509_
#define _C11_js509_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1179_9327(EIF_REFERENCE);
extern EIF_REFERENCE F1179_9328(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 9331)


extern EIF_REFERENCE F1179_9331(EIF_REFERENCE);
extern void EIF_Minit509(void);
extern char *(*R6423[])();

#ifdef __cplusplus
}
#endif

#endif
