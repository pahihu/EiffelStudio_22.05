
#ifndef _C11_re537_
#define _C11_re537_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1207_10172(EIF_REFERENCE);
extern EIF_BOOLEAN F1207_10183(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1207_10184(EIF_REFERENCE, EIF_REFERENCE);
extern void F1207_10185(EIF_REFERENCE, EIF_REAL_32);
extern EIF_INTEGER_32 F1207_10194(EIF_REFERENCE);
extern EIF_REFERENCE F1207_10211(EIF_REFERENCE);
extern void EIF_Minit537(void);
extern char *(*R8238[])();

#ifdef __cplusplus
}
#endif

#endif
