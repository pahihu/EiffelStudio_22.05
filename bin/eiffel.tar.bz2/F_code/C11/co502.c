/*
 * Code for class CONF_VIRTUAL_GROUP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co502.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_VIRTUAL_GROUP}.set_name_prefix */
void F1127_9191 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1056_8272(RTCW(loc1), arg1);
		F1058_8427(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O7660[dtype-1126]) = (EIF_REFERENCE) loc1;
	} else {
		*(EIF_REFERENCE *)(Current + O7660[dtype-1126]) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {CONF_VIRTUAL_GROUP}.add_renaming */
void F1127_9193 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + O7659[dtype-1126]);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {834,0xFF01,1055,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F826_6569(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O7659[dtype-1126]) = (EIF_REFERENCE) loc1;
	}
	F826_6615(RTCW(loc1), arg2, arg1);
	RTLE;
}

void EIF_Minit502 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
