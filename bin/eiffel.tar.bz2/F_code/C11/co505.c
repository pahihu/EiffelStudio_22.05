/*
 * Code for class CONF_PRECOMPILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co505.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_PRECOMPILE}.make */
void F1130_9240 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg3;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_22_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_22_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6777[Dtype(RTCW(arg1))-1052])(arg1);
	F1121_9097(Current, tr1);
	F1121_9099(Current, arg2);
	RTLE;
}

/* {CONF_PRECOMPILE}.is_precompile */
static EIF_BOOLEAN F1130_9241_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (9241);
#define Result RTOSR(9241)
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTOSE (9241);
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F1130_9241 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9241,F1130_9241_body,(Current));
}

/* {CONF_PRECOMPILE}.set_eifgens_location */
void F1130_9243 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg1;
}

/* {CONF_PRECOMPILE}.process */
void F1130_9244 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8950[Dtype(RTCW(arg1))-1254])(arg1, Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8954[Dtype(RTCW(arg1))-1254])(arg1, Current);
	RTLE;
}

void EIF_Minit505 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
