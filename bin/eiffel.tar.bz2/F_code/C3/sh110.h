
#ifndef _C3_sh110_
#define _C3_sh110_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1896)
static EIF_REFERENCE F134_1896_body(EIF_REFERENCE);
extern EIF_REFERENCE F134_1896(EIF_REFERENCE);
extern void EIF_Minit110(void);

#ifdef __cplusplus
}
#endif

#endif
