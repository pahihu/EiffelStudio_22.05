
#ifndef _C3_xm142_
#define _C3_xm142_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 2216)


extern EIF_REFERENCE F168_2216(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 2217)


extern EIF_REFERENCE F168_2217(EIF_REFERENCE);
extern void EIF_Minit142(void);

#ifdef __cplusplus
}
#endif

#endif
