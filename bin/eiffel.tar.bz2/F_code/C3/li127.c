/*
 * Code for class LIBRARY_EIFFEL_CLASS_SCANNER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li127.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIBRARY_EIFFEL_CLASS_SCANNER}.make */
void F151_2059 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,922,0xFF01,1072,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F923_6918(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {LIBRARY_EIFFEL_CLASS_SCANNER}.process_file */
void F151_2063 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F923_6958(RTCW(tr1), arg1);
	RTLE;
}

/* {LIBRARY_EIFFEL_CLASS_SCANNER}.directory_excluded */
EIF_BOOLEAN F151_2064 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	Result = F147_2028(Current, arg1);
	if ((EIF_BOOLEAN) !Result) {
		tr1 = F1073_8929(RTCW(arg1));
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			loc1 = F1073_8952(loc2);
		} else {
			loc1 = F1073_8952(RTCW(arg1));
		}
		Result = '\01';
		tr1 = RTMS_EX_H(".",1,46);
		tb1 = F1049_8021(RTCW(loc1), tr1);
		if (!tb1) {
			tr1 = RTMS_EX_H("EIFGENs",7,1708946035);
			tb1 = F1049_8019(RTCW(loc1), tr1);
			Result = tb1;
		}
	}
	RTLE;
	return Result;
}

/* {LIBRARY_EIFFEL_CLASS_SCANNER}.file_excluded */
EIF_BOOLEAN F151_2065 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = F1073_8930(RTCW(arg1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = RTMS_EX_H("e",1,101);
		Result = F1049_8016(loc1, tr1);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	}
	RTLE;
	return Result;
}

void EIF_Minit127 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
