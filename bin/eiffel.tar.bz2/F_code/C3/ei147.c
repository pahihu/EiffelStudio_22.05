/*
 * Code for class EIFFEL_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei147.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_CONSTANTS}.ise_eiffel_env */

EIF_REFERENCE F173_2259 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2259,RTMS_EX_H("ISE_EIFFEL",10,960687436));
}

/* {EIFFEL_CONSTANTS}.ise_library_env */

EIF_REFERENCE F173_2260 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2260,RTMS_EX_H("ISE_LIBRARY",11,552576601));
}

/* {EIFFEL_CONSTANTS}.eiffel_library_env */

EIF_REFERENCE F173_2261 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2261,RTMS_EX_H("EIFFEL_LIBRARY",14,1735641689));
}

/* {EIFFEL_CONSTANTS}.ise_iron_path_env */

EIF_REFERENCE F173_2262 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2262,RTMS_EX_H("ISE_IRON_PATH",13,591182408));
}

/* {EIFFEL_CONSTANTS}.iron_path_env */

EIF_REFERENCE F173_2263 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2263,RTMS_EX_H("IRON_PATH",9,490076488));
}

/* {EIFFEL_CONSTANTS}.ise_precomp_env */

EIF_REFERENCE F173_2264 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2264,RTMS_EX_H("ISE_PRECOMP",11,185338448));
}

/* {EIFFEL_CONSTANTS}.ise_platform_env */

EIF_REFERENCE F173_2265 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2265,RTMS_EX_H("ISE_PLATFORM",12,1318550605));
}

/* {EIFFEL_CONSTANTS}.ise_c_compiler_env */

EIF_REFERENCE F173_2266 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2266,RTMS_EX_H("ISE_C_COMPILER",14,1981921618));
}

/* {EIFFEL_CONSTANTS}.ise_user_files_env */

EIF_REFERENCE F173_2269 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2269,RTMS_EX_H("ISE_USER_FILES",14,1880819283));
}

/* {EIFFEL_CONSTANTS}.ise_app_data_env */

EIF_REFERENCE F173_2270 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2270,RTMS_EX_H("ISE_APP_DATA",12,1175984961));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_major_version */
static EIF_REFERENCE F173_2277_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2277);
#define Result RTOSR(2277)
	RTOC_NEW(Result);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 22U);
	Result = F173_2279(Current, ti4_1);
	RTOSE (2277);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F173_2277 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2277,F173_2277_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_minor_version */
static EIF_REFERENCE F173_2278_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2278);
#define Result RTOSR(2278)
	RTOC_NEW(Result);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 5U);
	Result = F173_2279(Current, ti4_1);
	RTOSE (2278);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F173_2278 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2278,F173_2278_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_string */
EIF_REFERENCE F173_2279 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1052_8104(RTCW(Result), ((EIF_INTEGER_32) 2L));
	if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 10L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6906[Dtype(RTCW(Result))-1053])(Result, (EIF_CHARACTER_8) '0');
	}
	F1054_8220(RTCW(Result), arg1);
	RTLE;
	return Result;
}

void EIF_Minit147 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
