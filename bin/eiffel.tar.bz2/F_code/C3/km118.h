
#ifndef _C3_km118_
#define _C3_km118_

#ifdef __cplusplus
extern "C" {
#endif

extern void F142_1950(EIF_REFERENCE);
extern void F142_1955(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F142_1958(EIF_REFERENCE);
extern void F142_1960(EIF_REFERENCE);
extern void EIF_Minit118(void);
extern void F141_1940(EIF_REFERENCE);
extern EIF_REFERENCE F1058_8420(EIF_REFERENCE);
extern void F1111_9008(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F1049_8033(EIF_REFERENCE);
extern EIF_REFERENCE F1111_9043(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern long O1915[];
extern long O1920[];
extern long O1924[];

#ifdef __cplusplus
}
#endif

#endif
