/*
 * Code for class URI_PERCENT_ENCODER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ur105.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {URI_PERCENT_ENCODER}.append_percent_encoded_string_to */
void F127_1825 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6755[Dtype(RTCW(arg1))-1052])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6718[Dtype(RTCW(arg1))-1052])(arg1, loc1);
		F127_1830(Current, tu4_1, arg2);
		loc1++;
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_path_segment_encoded_string_to */
void F127_1828 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6755[Dtype(RTCW(arg1))-1052])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6718[Dtype(RTCW(arg1))-1052])(arg1, loc1);
		F127_1833(Current, tu4_1, arg2);
		loc1++;
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_www_form_url_encoded_string_to */
void F127_1829 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6755[Dtype(RTCW(arg1))-1052])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6718[Dtype(RTCW(arg1))-1052])(arg1, loc1);
		switch (tu4_1) {
			case 32U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6815[Dtype(RTCW(arg2))-1053])(arg2, (EIF_NATURAL_32) ((EIF_INTEGER_32) 43L));
				break;
			default:
				tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6718[Dtype(RTCW(arg1))-1052])(arg1, loc1);
				F127_1830(Current, tu4_1, arg2);
				break;
		}
		loc1++;
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_encoded_character_code_to */
void F127_1830 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 48L) <= arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 57L))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 65L) <= arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 90L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 97L) <= arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 122L))))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6815[Dtype(RTCW(arg2))-1053])(arg2, arg1);
	} else {
		switch (arg1) {
			case 45U:
			case 46U:
			case 95U:
			case 126U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6815[Dtype(RTCW(arg2))-1053])(arg2, arg1);
				break;
			case 33U:
			case 36U:
			case 37U:
			case 38U:
			case 39U:
			case 40U:
			case 41U:
			case 42U:
			case 43U:
			case 44U:
			case 58U:
			case 59U:
			case 61U:
			case 64U:
				F127_1834(Current, arg1, arg2);
				break;
			default:
				F127_1834(Current, arg1, arg2);
				break;
		}
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_path_segment_encoded_character_code_to */
void F127_1833 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F127_1830(Current, arg1, arg2);
}

/* {URI_PERCENT_ENCODER}.append_percent_encoded_character_code_to */
void F127_1834 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L))) {
		F127_1836(Current, arg1, arg2);
	} else {
		if ((EIF_BOOLEAN) (arg1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
			F127_1836(Current, arg1, arg2);
		} else {
			F127_1835(Current, arg1, arg2);
		}
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_percent_encoded_ascii_character_code_to */
void F127_1835 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 255L))) {
		F127_1836(Current, arg1, arg2);
	} else {
		loc1 = (EIF_INTEGER_32) arg1;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6815[Dtype(RTCW(arg2))-1053])(arg2, (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L));
		tr1 = RTOSCF(1848,F127_1848, (Current));
		ti4_1 = eif_bit_shift_right(loc1,((EIF_INTEGER_32) 4L));
		/* INLINED CODE (SPECIAL.item) */
		tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1));
		/* END INLINED CODE */
		tu4_1 = tu4_2;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6815[Dtype(RTCW(arg2))-1053])(arg2, tu4_1);
		tr1 = RTOSCF(1848,F127_1848, (Current));
		ti4_1 = eif_bit_and(loc1,((EIF_INTEGER_32) 15L));
		/* INLINED CODE (SPECIAL.item) */
		tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1));
		/* END INLINED CODE */
		tu4_1 = tu4_2;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6815[Dtype(RTCW(arg2))-1053])(arg2, tu4_1);
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_percent_encoded_unicode_character_code_to */
void F127_1836 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
		F127_1835(Current, arg1, arg2);
	} else {
		if ((EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 2047L))) {
			tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 6L));
			tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 192L));
			F127_1835(Current, tu4_1, arg2);
			tu4_1 = eif_bit_and(arg1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
			tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
			F127_1835(Current, tu4_1, arg2);
		} else {
			if ((EIF_BOOLEAN) (arg1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 65535L))) {
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 12L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 224L));
				F127_1835(Current, tu4_1, arg2);
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 6L));
				tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F127_1835(Current, tu4_1, arg2);
				tu4_1 = eif_bit_and(arg1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F127_1835(Current, tu4_1, arg2);
			} else {
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 18L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 240L));
				F127_1835(Current, tu4_1, arg2);
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 12L));
				tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F127_1835(Current, tu4_1, arg2);
				tu4_1 = eif_bit_shift_right(arg1,((EIF_INTEGER_32) 6L));
				tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F127_1835(Current, tu4_1, arg2);
				tu4_1 = eif_bit_and(arg1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 128L));
				F127_1835(Current, tu4_1, arg2);
			}
		}
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.append_percent_decoded_string_to */
void F127_1837 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc6);
	RTLR(1,arg2);
	RTLR(2,loc4);
	RTLR(3,Current);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	loc6 = arg2;
	loc6 = RTRV(eif_new_type(1057, 0x01),loc6);
	loc5 = (EIF_BOOLEAN) EIF_TEST(loc6);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,178,1190,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc4 = RTLNS(typres0.id, 178, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	F179_2355(RTCW(loc4), loc1);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6755[Dtype(RTCW(arg1))-1052])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6718[Dtype(RTCW(arg1))-1052])(arg1, loc1);
		switch (loc3) {
			case 43U:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6815[Dtype(RTCW(arg2))-1053])(arg2, (EIF_NATURAL_32) ((EIF_INTEGER_32) 32L));
				break;
			case 37U:
				if ((EIF_BOOLEAN)(loc1 == loc2)) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6815[Dtype(RTCW(arg2))-1053])(arg2, loc3);
				} else {
					if (loc5) {
						F179_2356(RTCW(loc4), loc1);
						loc3 = F127_1839(Current, arg1, loc4);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6815[Dtype(RTCW(arg2))-1053])(arg2, loc3);
						loc1 = *(EIF_INTEGER_32 *)(RTCW(loc4) + O2286[Dtype(loc4)-177]);
					} else {
						F179_2356(RTCW(loc4), loc1);
						loc3 = F127_1838(Current, arg1, loc4);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6815[Dtype(RTCW(arg2))-1053])(arg2, loc3);
						loc1 = *(EIF_INTEGER_32 *)(RTCW(loc4) + O2286[Dtype(loc4)-177]);
					}
				}
				break;
			default:
				if ((EIF_BOOLEAN) (loc3 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6815[Dtype(RTCW(arg2))-1053])(arg2, loc3);
				} else {
					if (loc5) {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6815[Dtype(RTCW(arg2))-1053])(arg2, loc3);
					} else {
						F127_1834(Current, loc3, arg2);
					}
				}
				break;
		}
		loc1++;
	}
	RTLE;
}

/* {URI_PERCENT_ENCODER}.next_percent_decoded_character_code */
EIF_NATURAL_32 F127_1838 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc6 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc7 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O2286[Dtype(arg2)-177]);
	loc1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6718[Dtype(RTCW(arg1))-1052])(arg1, (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L)));
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 85L)) || (EIF_BOOLEAN)(loc1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 117L)))) {
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 2L));
		loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6755[Dtype(RTCW(arg1))-1052])(arg1);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 > loc3) || loc4)) break;
			loc1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6718[Dtype(RTCW(arg1))-1052])(arg1, loc2);
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 48L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 57L)));
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc8 || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 97L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 102L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 65L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 70L))))) {
				loc6 *= (EIF_NATURAL_32) ((EIF_INTEGER_32) 16L);
				if (loc8) {
					loc6 += (EIF_NATURAL_32) (loc1 - (EIF_NATURAL_32) ((EIF_INTEGER_32) 48L));
				} else {
					if ((EIF_BOOLEAN) (loc1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 70L))) {
						loc6 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) (loc6 + (EIF_NATURAL_32) (loc1 - (EIF_NATURAL_32) ((EIF_INTEGER_32) 97L))) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 10L));
					} else {
						loc6 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) (loc6 + (EIF_NATURAL_32) (loc1 - (EIF_NATURAL_32) ((EIF_INTEGER_32) 65L))) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 10L));
					}
				}
				loc2++;
			} else {
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc2--;
			}
		}
		F179_2356(RTCW(arg2), loc2);
		RTLE;
		return (EIF_NATURAL_32) loc6;
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6796[Dtype(RTCW(arg1))-1052])(arg1, (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 2L)));
		loc5 = F127_1850(Current, tr1);
		Result = (EIF_NATURAL_32) loc5;
		F179_2356(RTCW(arg2), (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 2L)));
	}
	RTLE;
	return Result;
}

/* {URI_PERCENT_ENCODER}.next_percent_decoded_unicode_character_code */
EIF_NATURAL_32 F127_1839 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc6 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc7 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc8);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,178,1190,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc8 = RTLNS(typres0.id, 178, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O2286[Dtype(arg2)-177]);
	F179_2355(RTCW(loc8), ti4_1);
	loc4 = F127_1838(Current, arg1, loc8);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2286[Dtype(loc8)-177]);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6755[Dtype(RTCW(arg1))-1052])(arg1);
	Result = (EIF_NATURAL_32) loc4;
	F179_2356(RTCW(arg2), loc2);
	if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
		RTLE;
		return (EIF_NATURAL_32) loc4;
	} else {
		if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 223L))) {
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) <= loc1)) {
				loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6718[Dtype(RTCW(arg1))-1052])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L))) {
					F179_2356(RTCW(loc8), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					loc5 = F127_1838(Current, arg1, loc8);
					loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2286[Dtype(loc8)-177]);
					tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 31L));
					tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 6L));
					tu4_2 = eif_bit_and(loc5,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
					Result = eif_bit_or(tu4_1,tu4_2);
					F179_2356(RTCW(arg2), loc2);
				}
			}
		} else {
			if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 239L))) {
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) <= loc1)) {
					loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6718[Dtype(RTCW(arg1))-1052])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L))) {
						F179_2356(RTCW(loc8), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
						loc5 = F127_1838(Current, arg1, loc8);
						loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2286[Dtype(loc8)-177]);
						if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) <= loc1)) {
							loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6718[Dtype(RTCW(arg1))-1052])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
							if ((EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L))) {
								F179_2356(RTCW(loc8), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
								loc6 = F127_1838(Current, arg1, loc8);
								loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2286[Dtype(loc8)-177]);
								tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 15L));
								tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 12L));
								tu4_2 = eif_bit_and(loc5,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
								tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 6L));
								tu4_1 = eif_bit_or(tu4_1,tu4_2);
								tu4_2 = eif_bit_and(loc6,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
								Result = eif_bit_or(tu4_1,tu4_2);
								F179_2356(RTCW(arg2), loc2);
							}
						}
					}
				}
			} else {
				if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 247L))) {
					if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) <= loc1)) {
						loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6718[Dtype(RTCW(arg1))-1052])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
						if ((EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L))) {
							F179_2356(RTCW(loc8), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
							loc5 = F127_1838(Current, arg1, loc8);
							loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2286[Dtype(loc8)-177]);
							if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) <= loc1)) {
								loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6718[Dtype(RTCW(arg1))-1052])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
								if ((EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L))) {
									F179_2356(RTCW(loc8), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
									loc6 = F127_1838(Current, arg1, loc8);
									loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2286[Dtype(loc8)-177]);
									if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)) <= loc1)) {
										loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6718[Dtype(RTCW(arg1))-1052])(arg1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
										if ((EIF_BOOLEAN)(loc3 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 37L))) {
											F179_2356(RTCW(loc8), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
											loc7 = F127_1838(Current, arg1, loc8);
											loc2 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O2286[Dtype(loc8)-177]);
											F179_2356(RTCW(arg2), loc2);
											tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 7L));
											tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 18L));
											tu4_2 = eif_bit_and(loc5,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
											tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 12L));
											tu4_1 = eif_bit_or(tu4_1,tu4_2);
											tu4_2 = eif_bit_and(loc6,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
											tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 6L));
											tu4_1 = eif_bit_or(tu4_1,tu4_2);
											tu4_2 = eif_bit_and(loc7,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
											Result = eif_bit_or(tu4_1,tu4_2);
										}
									}
								}
							}
						}
					}
				} else {
					RTLE;
					return (EIF_NATURAL_32) loc4;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {URI_PERCENT_ENCODER}.is_hexa_decimal_character */
EIF_BOOLEAN F127_1840 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tb2 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'a';
	if ((EIF_BOOLEAN) (tw1 <= arg1)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'f';
		tb2 = (EIF_BOOLEAN) (arg1 <= tw1);
	}
	if (!tb2) {
		tb2 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'A';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'F';
			tb2 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		tb1 = tb2;
	}
	if (!tb1) {
		tb1 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '0';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '9';
			tb1 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		Result = tb1;
	}
	return Result;
}

/* {URI_PERCENT_ENCODER}.is_alpha_or_digit_character */
EIF_BOOLEAN F127_1841 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tb2 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'a';
	if ((EIF_BOOLEAN) (tw1 <= arg1)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'z';
		tb2 = (EIF_BOOLEAN) (arg1 <= tw1);
	}
	if (!tb2) {
		tb2 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'A';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Z';
			tb2 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		tb1 = tb2;
	}
	if (!tb1) {
		tb1 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '0';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '9';
			tb1 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		Result = tb1;
	}
	return Result;
}

/* {URI_PERCENT_ENCODER}.is_alpha_character */
EIF_BOOLEAN F127_1842 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	Result = '\01';
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'a';
	if ((EIF_BOOLEAN) (tw1 <= arg1)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'z';
		tb1 = (EIF_BOOLEAN) (arg1 <= tw1);
	}
	if (!tb1) {
		tb1 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'A';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Z';
			tb1 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		Result = tb1;
	}
	return Result;
}

/* {URI_PERCENT_ENCODER}.is_unreserved_character */
EIF_BOOLEAN F127_1844 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'a';
	if ((EIF_BOOLEAN) (tw1 <= arg1)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'z';
		tb3 = (EIF_BOOLEAN) (arg1 <= tw1);
	}
	if (!tb3) {
		tb3 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'A';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Z';
			tb3 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		tb2 = tb3;
	}
	if (!tb2) {
		tb2 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '0';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '9';
			tb2 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		tb1 = tb2;
	}
	if (tb1) {
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		switch (arg1) {
			case (EIF_CHARACTER_8) '-':
			case (EIF_CHARACTER_8) '.':
			case (EIF_CHARACTER_8) '_':
			case (EIF_CHARACTER_8) '~':
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
	}
	return Result;
}

/* {URI_PERCENT_ENCODER}.is_sub_delims_character */
EIF_BOOLEAN F127_1847 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	switch (arg1) {
		case (EIF_CHARACTER_8) '!':
		case (EIF_CHARACTER_8) '$':
		case (EIF_CHARACTER_8) '&':
		case (EIF_CHARACTER_8) '\'':
		case (EIF_CHARACTER_8) '(':
		case (EIF_CHARACTER_8) ')':
		case (EIF_CHARACTER_8) '*':
		case (EIF_CHARACTER_8) '+':
		case (EIF_CHARACTER_8) ',':
		case (EIF_CHARACTER_8) ';':
		case (EIF_CHARACTER_8) '=':
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			break;
	}
	return Result;
}

/* {URI_PERCENT_ENCODER}.hex_digit */
static EIF_REFERENCE F127_1848_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1848);
#define Result RTOSR(1848)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1111,1199,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 16L),sizeof(EIF_NATURAL_32), EIF_TRUE);
	}
	F1112_9008(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 16L));
	Result = (EIF_REFERENCE) tr1;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 0L))) = ((EIF_NATURAL_32) 48U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 1L))) = ((EIF_NATURAL_32) 49U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 2L))) = ((EIF_NATURAL_32) 50U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 3L))) = ((EIF_NATURAL_32) 51U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 4L))) = ((EIF_NATURAL_32) 52U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 5L))) = ((EIF_NATURAL_32) 53U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 6L))) = ((EIF_NATURAL_32) 54U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 7L))) = ((EIF_NATURAL_32) 55U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 8L))) = ((EIF_NATURAL_32) 56U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 9L))) = ((EIF_NATURAL_32) 57U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 10L))) = ((EIF_NATURAL_32) 65U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 11L))) = ((EIF_NATURAL_32) 66U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 12L))) = ((EIF_NATURAL_32) 67U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 13L))) = ((EIF_NATURAL_32) 68U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 14L))) = ((EIF_NATURAL_32) 69U);
	/* END INLINED CODE */
	;
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(Result) + (((EIF_INTEGER_32) 15L))) = ((EIF_NATURAL_32) 70U);
	/* END INLINED CODE */
	;
	RTOSE (1848);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_1848 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1848,F127_1848_body,(Current));
}

/* {URI_PERCENT_ENCODER}.hexadecimal_string_to_natural_32 */
EIF_NATURAL_32 F127_1850 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTOSCF(1851,F127_1851, (Current));
	F261_3255(RTCW(loc1), arg1, ((EIF_INTEGER_32) 0L));
	tu4_1 = F261_3267(RTCW(loc1));
	RTLE;
	return (EIF_NATURAL_32) tu4_1;
}

/* {URI_PERCENT_ENCODER}.ctoi_convertor */
static EIF_REFERENCE F127_1851_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1851);
#define Result RTOSR(1851)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(260, 0x01).id, 260, _OBJSIZ_2_4_0_3_0_0_2_0_);
	F261_3249(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F258_3194(RTCW(Result), (EIF_BOOLEAN) 0);
	F258_3193(RTCW(Result), (EIF_BOOLEAN) 0);
	RTOSE (1851);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F127_1851 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1851,F127_1851_body,(Current));
}

void EIF_Minit105 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
