
#ifndef _C3_re148_
#define _C3_re148_

#ifdef __cplusplus
extern "C" {
#endif

extern void F174_2280(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit148(void);

#ifdef __cplusplus
}
#endif

#endif
