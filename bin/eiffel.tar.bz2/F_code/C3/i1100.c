/*
 * Code for class I18N_NUMERIC_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1100.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_NUMERIC_INFO}.make */
void F122_1748 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(1756,F122_1756, (Current));
	F122_1763(Current, tr1);
	F122_1764(Current, ((EIF_INTEGER_32) 2L));
	tr1 = RTOSCF(1758,F122_1758, (Current));
	F122_1765(Current, tr1);
	tr1 = RTOSCF(1759,F122_1759, (Current));
	F122_1766(Current, tr1);
	tr1 = RTOSCF(1762,F122_1762, (Current));
	F122_1769(Current, tr1);
	tr1 = RTOSCF(1760,F122_1760, (Current));
	F122_1767(Current, tr1);
	tr1 = RTOSCF(1761,F122_1761, (Current));
	F122_1768(Current, tr1);
	RTLE;
}

/* {I18N_NUMERIC_INFO}.default_value_decimal_separator */
static EIF_REFERENCE F122_1756_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1756);
#define Result RTOSR(1756)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H(".\000\000\000",1,46);
	RTOSE (1756);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F122_1756 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1756,F122_1756_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_group_separator */
static EIF_REFERENCE F122_1758_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1758);
#define Result RTOSR(1758)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H(",\000\000\000",1,44);
	RTOSE (1758);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F122_1758 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1758,F122_1758_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_number_list_separator */
static EIF_REFERENCE F122_1759_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1759);
#define Result RTOSR(1759)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H(";\000\000\000",1,59);
	RTOSE (1759);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F122_1759 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1759,F122_1759_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_positive_sign */
static EIF_REFERENCE F122_1760_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1760);
#define Result RTOSR(1760)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("",0,0);
	RTOSE (1760);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F122_1760 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1760,F122_1760_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_negative_sign */
static EIF_REFERENCE F122_1761_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1761);
#define Result RTOSR(1761)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("-\000\000\000",1,45);
	RTOSE (1761);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F122_1761 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1761,F122_1761_body,(Current));
}

/* {I18N_NUMERIC_INFO}.default_value_grouping */
static EIF_REFERENCE F122_1762_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (1762);
#define Result RTOSR(1762)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1110,1190,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 3L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 3L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1111_9016)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1762);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F122_1762 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1762,F122_1762_body,(Current));
}

/* {I18N_NUMERIC_INFO}.set_value_decimal_separator */
void F122_1763 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8033(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_numbers_after_decimal_separator */
void F122_1764 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_35_0_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {I18N_NUMERIC_INFO}.set_value_group_separator */
void F122_1765 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8033(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_number_list_separator */
void F122_1766 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8033(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_positive_sign */
void F122_1767 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8033(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_negative_sign */
void F122_1768 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8033(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_NUMERIC_INFO}.set_value_grouping */
void F122_1769 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit100 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
