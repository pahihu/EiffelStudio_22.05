
#ifndef _C3_pa109_
#define _C3_pa109_

#ifdef __cplusplus
extern "C" {
#endif

extern void F133_1892(EIF_REFERENCE);
extern void EIF_Minit109(void);

#ifdef __cplusplus
}
#endif

#endif
