/*
 * Code for class IRON_FS_PACKAGE_INFO_DIRECTORY_ITERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir124.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_FS_PACKAGE_INFO_DIRECTORY_ITERATOR}.make */
void F148_2030 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {IRON_FS_PACKAGE_INFO_DIRECTORY_ITERATOR}.scan_folder */
void F148_2034 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	struct eif_ex_57 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_BOOLEAN tb1;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(75, 0x00).id);
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tb1 = F76_1163(RTCW(loc1), arg1);
	if (tb1) {
		F148_2035(Current, arg1);
	}
	RTLE;
}

/* {IRON_FS_PACKAGE_INFO_DIRECTORY_ITERATOR}.process_directory */
void F148_2035 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_))++;
	F147_2025(Current, arg1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_))--;
	RTLE;
}

/* {IRON_FS_PACKAGE_INFO_DIRECTORY_ITERATOR}.process_file */
void F148_2036 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5425[Dtype(RTCW(tr1))-802])(tr1, arg1);
	RTLE;
}

/* {IRON_FS_PACKAGE_INFO_DIRECTORY_ITERATOR}.path_excluded */
EIF_BOOLEAN F148_2037 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = '\01';
	if (!F147_2027(Current, arg1)) {
		Result = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) > ((EIF_INTEGER_32) 2L));
	}
	RTLE;
	return Result;
}

/* {IRON_FS_PACKAGE_INFO_DIRECTORY_ITERATOR}.file_excluded */
EIF_BOOLEAN F148_2038 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = F1073_8952(RTCW(arg1));
	tr2 = F1049_8033(RTMS_EX_H(".info",5,1769196143));
	Result = F1056_8306(RTCW(tr1), tr2);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

void EIF_Minit124 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
