/*
 * Code for class SHARED_CHARACTER_SETS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sh120.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SHARED_CHARACTER_SETS}.default_character_case_mapping */
static EIF_REFERENCE F144_1979_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (1979);
#define Result RTOSR(1979)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(29, 0x01).id, 29, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,680947802);
	tr3 = RTMS_EX_H("abcdefghijklmnopqrstuvwxyz",26,1741663354);
	F30_244(RTCW(tr1), tr2, tr3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1979);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1979 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1979,F144_1979_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.default_word_set */
static EIF_REFERENCE F144_1980_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1980);
#define Result RTOSR(1980)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_",63,1064094303);
	F29_234(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1980);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1980 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1980,F144_1980_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.upper_set */
static EIF_REFERENCE F144_1981_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1981);
#define Result RTOSR(1981)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,680947802);
	F29_234(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1981);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1981 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1981,F144_1981_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.lower_set */
static EIF_REFERENCE F144_1982_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1982);
#define Result RTOSR(1982)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("abcdefghijklmnopqrstuvwxyz",26,1741663354);
	F29_234(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1982);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1982 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1982,F144_1982_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.alpha_set */
static EIF_REFERENCE F144_1983_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1983);
#define Result RTOSR(1983)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F29_233(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(1982,F144_1982, (Current));
	F29_239(RTCW(Result), tr1);
	tr1 = RTOSCF(1981,F144_1981, (Current));
	F29_239(RTCW(Result), tr1);
	RTOSE (1983);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1983 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1983,F144_1983_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.digit_set */
static EIF_REFERENCE F144_1984_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1984);
#define Result RTOSR(1984)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("0123456789",10,593348409);
	F29_234(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1984);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1984 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1984,F144_1984_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.alnum_set */
static EIF_REFERENCE F144_1985_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1985);
#define Result RTOSR(1985)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F29_233(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(1983,F144_1983, (Current));
	F29_239(RTCW(Result), tr1);
	tr1 = RTOSCF(1984,F144_1984, (Current));
	F29_239(RTCW(Result), tr1);
	RTOSE (1985);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1985 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1985,F144_1985_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.xdigit_set */
static EIF_REFERENCE F144_1986_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1986);
#define Result RTOSR(1986)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("0123456789abcdefABCDEF",22,1983803462);
	F29_234(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1986);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1986 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1986,F144_1986_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.cntrl_set */
static EIF_REFERENCE F144_1987_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1987);
#define Result RTOSR(1987)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F29_233(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 31L))) break;
		F29_238(RTCW(Result), loc1);
		loc1++;
	}
	F29_238(RTCW(Result), ((EIF_INTEGER_32) 127L));
	RTOSE (1987);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1987 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1987,F144_1987_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.graph_set */
static EIF_REFERENCE F144_1988_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1988);
#define Result RTOSR(1988)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("!\"#$%&\'()*+,-./0123456789:;<=>\?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",94,554150526);
	F29_234(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1988);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1988 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1988,F144_1988_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.print_set */
static EIF_REFERENCE F144_1989_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1989);
#define Result RTOSR(1989)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H(" !\"#$%&\'()*+,-./0123456789:;<=>\?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",95,1652388478);
	F29_234(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1989);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1989 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1989,F144_1989_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.punct_set */
static EIF_REFERENCE F144_1990_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1990);
#define Result RTOSR(1990)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("!\"#$%&\'()*+,-./:;<=>\?@[\\]^_`{|}~",32,391924606);
	F29_234(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1990);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1990 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1990,F144_1990_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.ascii_set */
static EIF_REFERENCE F144_1991_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1991);
#define Result RTOSR(1991)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F29_233(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 127L))) break;
		F29_238(RTCW(Result), loc1);
		loc1++;
	}
	RTOSE (1991);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1991 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1991,F144_1991_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.space_set */
static EIF_REFERENCE F144_1992_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1992);
#define Result RTOSR(1992)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("\011\012\014\015\013 ",6,219952928);
	F29_234(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1992);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1992 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1992,F144_1992_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.meta_set */
static EIF_REFERENCE F144_1993_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1993);
#define Result RTOSR(1993)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(28, 0x01).id, 28, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("*+\?{^.$|()[",11,572368475);
	F29_234(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1993);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1993 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1993,F144_1993_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.class_names */
static EIF_REFERENCE F144_1994_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (1994);
#define Result RTOSR(1994)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1108,0xFF01,1053,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 13L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 13L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS_EX_H("alpha",5,1820051041);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("lower",5,1870925170);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("upper",5,1887312754);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("alnum",5,1819923309);
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("ascii",5,1936639849);
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("cntrl",5,1853885548);
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("digit",5,1769152884);
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("graph",5,1919779432);
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("print",5,1920372340);
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("punct",5,1971028852);
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("space",5,1886313829);
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("word",4,2003792484);
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("xdigit",6,2005082484);
	*((EIF_REFERENCE *)tr2+12) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1109_9016)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1994);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1994 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1994,F144_1994_body,(Current));
}

/* {SHARED_CHARACTER_SETS}.class_sets */
static EIF_REFERENCE F144_1995_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (1995);
#define Result RTOSR(1995)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1108,0xFF01,28,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 13L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 13L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTOSCF(1983,F144_1983, (Current));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1982,F144_1982, (Current));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1981,F144_1981, (Current));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1985,F144_1985, (Current));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1991,F144_1991, (Current));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1987,F144_1987, (Current));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1984,F144_1984, (Current));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1988,F144_1988, (Current));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1989,F144_1989, (Current));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1990,F144_1990, (Current));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1992,F144_1992, (Current));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1980,F144_1980, (Current));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(1986,F144_1986, (Current));
	*((EIF_REFERENCE *)tr2+12) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1109_9016)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1995);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F144_1995 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1995,F144_1995_body,(Current));
}

void EIF_Minit120 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
