/*
 * Code for class SHARED_I18N_URI_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sh110.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SHARED_I18N_URI_PARSER}.parser */
static EIF_REFERENCE F134_1896_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (1896);
#define Result RTOSR(1896)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(16, 0x01).id, 16, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1896);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F134_1896 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1896,F134_1896_body,(Current));
}

void EIF_Minit110 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
