/*
 * Code for class I18N_FILE_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1113.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_FILE_MANAGER}.make */
void F137_1910 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F136_1903(Current, arg1);
	tr1 = RTLNS(eif_new_type(96, 0x01).id, 96, _OBJSIZ_2_1_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(419, 1).id);
	F420_5128(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	F137_1920(Current);
	RTLE;
}

/* {I18N_FILE_MANAGER}.dictionary */
EIF_REFERENCE F137_1911 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	tb1 = '\0';
	tr1 = F137_1912(Current);
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5297[Dtype(RTCW(tr1))-733])(tr1, arg1);
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F826_6574(RTCW(tr1), arg1);
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc1 = F96_1370(RTCW(tr1), loc2);
	} else {
		tb1 = '\0';
		tr1 = F137_1913(Current);
		tr2 = F1221_10374(RTCW(arg1));
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5297[Dtype(RTCW(tr1))-733])(tr1, tr2);
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = F1221_10374(RTCW(arg1));
			tr1 = F826_6574(RTCW(tr1), tr2);
			loc3 = tr1;
			tb1 = EIF_TEST(loc3);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			loc1 = F96_1370(RTCW(tr1), loc3);
		}
	}
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = RTLNS(eif_new_type(217, 0x01).id, 217, _OBJSIZ_1_0_0_2_0_0_0_0_);
		F216_2694(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {I18N_FILE_MANAGER}.available_locales */
EIF_REFERENCE F137_1912 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_2_);
}

/* {I18N_FILE_MANAGER}.available_languages */
EIF_REFERENCE F137_1913 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_4_);
}

/* {I18N_FILE_MANAGER}.populate_file_lists */
void F137_1920 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc4);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLIU(8);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,825,0xFF01,1048,0xFF01,1220,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F826_6568(RTCW(tr1), ((EIF_INTEGER_32) 16L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,922,0xFF01,1220,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F923_6918(RTCW(tr1), ((EIF_INTEGER_32) 16L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,825,0xFF01,1048,0xFF01,1219,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F826_6568(RTCW(tr1), ((EIF_INTEGER_32) 16L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,922,0xFF01,1219,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F923_6918(RTCW(tr1), ((EIF_INTEGER_32) 16L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F582_5987(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F582_5987(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F582_5987(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F582_5987(RTCW(tr1));
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tb2 = F420_5153(RTCW(tr1));
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tb2 = F420_5154(RTCW(tr1));
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F420_5138(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = F420_5144(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc4 = F420_5134(RTCW(tr1));
		F923_6949(RTCW(loc1));
		for (;;) {
			tb1 = F894_6837(RTCW(loc1));
			if (tb1) break;
			tb2 = '\0';
			tr1 = F923_6923(RTCW(loc1));
			tb3 = F1073_8919(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb3) {
				tr1 = F923_6923(RTCW(loc1));
				tb3 = F1073_8918(RTCW(tr1));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				tr1 = F923_6923(RTCW(loc1));
				tr1 = F1073_8941(RTCW(loc4), tr1);
				loc3 = F1073_8952(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				loc2 = F96_1368(RTCW(tr1), loc3);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
					loc5 = tr1;
					if (EIF_TEST(loc5)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						F826_6614(RTCW(tr1), loc3, loc5);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						tb2 = F826_6597(RTCW(tr1));
						if (tb2) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5328[Dtype(RTCW(tr1))-733])(tr1, loc5);
						}
					} else {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
						loc6 = tr1;
						if (EIF_TEST(loc6)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
							F826_6614(RTCW(tr1), loc3, loc6);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
							tb2 = F826_6597(RTCW(tr1));
							if (tb2) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5328[Dtype(RTCW(tr1))-733])(tr1, loc6);
							}
						}
					}
				}
			}
			F923_6951(RTCW(loc1));
		}
	}
	RTLE;
}

void EIF_Minit113 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
