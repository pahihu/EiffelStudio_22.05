/*
 * Code for class SHARED_CLASSNAME_FINDER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sh144.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SHARED_CLASSNAME_FINDER}.classname_finder */
static EIF_REFERENCE F170_2237_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2237);
#define Result RTOSR(2237)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1238, 0x01).id, 1238, _OBJSIZ_16_4_0_22_0_0_0_0_);
	F1238_10852(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2237);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F170_2237 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2237,F170_2237_body,(Current));
}

void EIF_Minit144 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
