
#ifndef _C3_pa108_
#define _C3_pa108_

#ifdef __cplusplus
extern "C" {
#endif

extern void F132_1886(EIF_REFERENCE, EIF_REFERENCE);
extern void F132_1887(EIF_REFERENCE, EIF_REFERENCE);
extern void F132_1888(EIF_REFERENCE, EIF_REFERENCE);
extern void F132_1889(EIF_REFERENCE, EIF_REFERENCE);
extern void F132_1891(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit108(void);

#ifdef __cplusplus
}
#endif

#endif
