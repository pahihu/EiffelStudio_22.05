/*
 * Code for class KMP_WILD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "km119.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KMP_WILD}.make_empty */
void F143_1962 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_0_) = (EIF_CHARACTER_32) tw1;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '*';
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_) = (EIF_CHARACTER_32) tw1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,917,0xFF01,1057,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F918_6848(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	F142_1950(Current);
	RTLE;
}

/* {KMP_WILD}.found_pattern_length */
EIF_INTEGER_32 F143_1963 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_4_);
}


/* {KMP_WILD}.set_pattern */
void F143_1965 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8033(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {KMP_WILD}.found_at */
EIF_INTEGER_32 F143_1968 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_3_);
}


/* {KMP_WILD}.pattern_matches */
EIF_BOOLEAN F143_1972 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc6 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc5);
	RTLR(3,loc4);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	if (F143_1973(Current)) {
		tb2 = '\01';
		if (!(EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_3_) == ((EIF_INTEGER_32) 1L))) {
			tr1 = *(EIF_REFERENCE *)(Current);
			tw1 = F1058_8352(RTCW(tr1), ((EIF_INTEGER_32) 1L));
			tb2 = (EIF_BOOLEAN)(tw1 == *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_));
		}
		tb1 = tb2;
	}
	if (tb1) {
		loc5 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc4 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F918_6868(RTCW(loc4));
		loc3 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		for (;;) {
			tb1 = '\01';
			tb2 = '\01';
			tb3 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_2_1_);
			if (!tb3) {
				tb2 = loc2;
			}
			if (!tb2) {
				tb1 = (EIF_BOOLEAN) !Result;
			}
			if (tb1) break;
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5341[Dtype(RTCW(loc4))-733])(loc4);
			loc6 = F1058_8352(RTCW(loc1), ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN)(loc6 == *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_))) {
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				if ((EIF_BOOLEAN)(loc6 == *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_0_))) {
					loc3--;
				} else {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					Result = F143_1978(Current, loc5, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - ti4_1) + ((EIF_INTEGER_32) 1L)), loc3, loc1);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					loc3 -= ti4_1;
				}
			}
			F918_6870(RTCW(loc4));
		}
		if ((EIF_BOOLEAN) !loc2) {
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_4_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
		}
	}
	RTLE;
	return Result;
}

/* {KMP_WILD}.search_for_pattern */
EIF_BOOLEAN F143_1973 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(10);
	RTLR(0,loc15);
	RTLR(1,Current);
	RTLR(2,loc14);
	RTLR(3,tr1);
	RTLR(4,loc9);
	RTLR(5,loc10);
	RTLR(6,loc11);
	RTLR(7,loc12);
	RTLR(8,loc1);
	RTLR(9,loc2);
	RTLIU(10);
	
	RTGC;
	loc15 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc14 = *(EIF_REFERENCE *)(Current);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F1058_8420(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F1058_8420(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	F143_1976(Current);
	loc9 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1056_8270(RTCW(loc9), ((EIF_INTEGER_32) 1L));
	F1058_8399(RTCW(loc9), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_));
	loc10 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1056_8270(RTCW(loc10), ((EIF_INTEGER_32) 1L));
	F1058_8399(RTCW(loc10), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_0_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - loc6);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) -1L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tw1 = F1058_8352(RTCW(tr1), loc6);
		tb1 = (EIF_BOOLEAN)(tw1 == *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_));
	}
	if (tb1) {
		Result = F143_1978(Current, *(EIF_REFERENCE *)(Current), ((EIF_INTEGER_32) 1L), loc5, *(EIF_REFERENCE *)(Current + _REFACS_1_));
		if (Result) {
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	}
	loc11 = RTLNS(eif_new_type(141, 0x01).id, 141, _OBJSIZ_4_2_0_1_0_0_0_0_);
	F141_1939(RTCW(loc11), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc12 = F1_14(tr1);
	F1058_8411(RTCW(loc12), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_1_0_2_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 > ti4_2)) {
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		loc8 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_2_);
		loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (Result || (EIF_BOOLEAN) (loc8 >= loc5))) break;
			loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
			loc8 = (EIF_INTEGER_32) loc4;
			loc1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			F918_6867(RTCW(loc1));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN) !Result) {
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_2_2_);
					tb1 = tb2;
				}
				if (tb1) break;
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5341[Dtype(RTCW(loc1))-733])(loc1);
				tb2 = F1056_8294(RTCW(loc2), loc9);
				if (tb2) {
					F918_6869(RTCW(loc1));
					loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tb2 = F1056_8294(RTCW(loc2), loc10);
					if (tb2) {
						if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
							loc3 = (EIF_INTEGER_32) loc4;
						}
						loc4++;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_2_) = (EIF_INTEGER_32) loc4;
						F918_6869(RTCW(loc1));
					} else {
						if ((EIF_BOOLEAN) (loc4 > loc5)) {
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						} else {
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1913[Dtype(RTCW(loc11))-141])(loc11, loc2);
							F141_1941(RTCW(loc11), loc4);
							Result = '\0';
							tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1919[Dtype(RTCW(loc11))-141])(loc11);
							if (tb2) {
								tb2 = '\01';
								if ((EIF_BOOLEAN) !loc13) {
									ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1916[Dtype(RTCW(loc11))-141])(loc11);
									tb2 = (EIF_BOOLEAN)(ti4_1 == loc4);
								}
								Result = tb2;
							}
							if (Result) {
								loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1916[Dtype(RTCW(loc11))-141])(loc11);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
								loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ti4_1);
								if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
									loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1916[Dtype(RTCW(loc11))-141])(loc11);
								}
							}
						}
						loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						F918_6869(RTCW(loc1));
					}
				}
				tb2 = '\0';
				if (Result) {
					tb3 = '\01';
					if (!(EIF_BOOLEAN) (loc4 <= (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L)))) {
						tb4 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_2_2_);
						tb3 = tb4;
					}
					tb2 = tb3;
				}
				Result = (EIF_BOOLEAN) tb2;
			}
		}
	}
	if (Result) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_4_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - loc3);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_3_) = (EIF_INTEGER_32) loc3;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_2_) = (EIF_INTEGER_32) loc4;
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) Result;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
		RTAR(Current, loc15);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc15;
		RTAR(Current, loc14);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc14;
	}
	RTLE;
	return Result;
}

/* {KMP_WILD}.init_list */
void F143_1976 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc8 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc6);
	RTLR(4,loc7);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLIU(7);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,917,0xFF01,1057,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNSMART(typres0.id);
	}
	F918_6848(RTCW(loc1));
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) loc1;
	loc2 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1056_8270(RTCW(loc2), ((EIF_INTEGER_32) 0L));
	loc6 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1056_8270(RTCW(loc6), ((EIF_INTEGER_32) 1L));
	F1058_8399(RTCW(loc6), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_));
	loc7 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1056_8270(RTCW(loc7), ((EIF_INTEGER_32) 1L));
	F1058_8399(RTCW(loc7), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_0_));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc5 = *(EIF_REFERENCE *)(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc3 == loc4)) break;
		/* INLINED CODE (SPECIAL.item) */
		tw2 = *((EIF_CHARACTER_32 *)RTCW(loc5) + (loc3));
		/* END INLINED CODE */
		loc8 = tw2;
		if ((EIF_BOOLEAN)(loc8 == *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_1_))) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5328[Dtype(RTCW(loc1))-733])(loc1, loc2);
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5328[Dtype(RTCW(loc1))-733])(loc1, loc6);
			loc2 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1056_8270(RTCW(loc2), ((EIF_INTEGER_32) 0L));
		} else {
			if ((EIF_BOOLEAN)(loc8 == *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_6_2_0_0_))) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5328[Dtype(RTCW(loc1))-733])(loc1, loc2);
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5328[Dtype(RTCW(loc1))-733])(loc1, loc7);
				loc2 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1056_8270(RTCW(loc2), ((EIF_INTEGER_32) 0L));
			} else {
				/* INLINED CODE (SPECIAL.item) */
				tw2 = *((EIF_CHARACTER_32 *)RTCW(loc5) + (loc3));
				/* END INLINED CODE */
				tw1 = tw2;
				F1058_8399(RTCW(loc2), tw1);
			}
		}
		loc3++;
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5328[Dtype(RTCW(loc1))-733])(loc1, loc2);
	}
	RTLE;
}

/* {KMP_WILD}.imp_same_substring */
EIF_BOOLEAN F143_1978 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg4);
	RTLIU(2);
	
	RTGC;
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg4)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (loc3 >= loc4)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) <= arg2) && (EIF_BOOLEAN) (arg2 <= arg3)) && (EIF_BOOLEAN) (arg3 <= loc3))) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc2 = (EIF_INTEGER_32) arg2;
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)) == loc4);
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc4)) || (EIF_BOOLEAN) (loc2 > arg3))) break;
				tw1 = F1058_8352(RTCW(arg1), loc2);
				tw2 = F1058_8352(RTCW(arg4), loc1);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tw1 == tw2);
				loc1++;
				loc2++;
			}
		} else {
			Result = F741_6139(RTCW(arg4));
			RTLE;
			return (EIF_BOOLEAN) Result;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit119 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
