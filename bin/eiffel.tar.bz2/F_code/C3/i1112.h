
#ifndef _C3_i1112_
#define _C3_i1112_

#ifdef __cplusplus
extern "C" {
#endif

extern void F136_1903(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F136_1907(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F136_1908(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit112(void);
extern EIF_REFERENCE F137_1912(EIF_REFERENCE);
extern EIF_REFERENCE F137_1913(EIF_REFERENCE);
extern void F1058_8346(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5297[])();

#ifdef __cplusplus
}
#endif

#endif
