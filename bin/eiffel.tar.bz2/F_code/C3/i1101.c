/*
 * Code for class I18N_CURRENCY_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1101.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_CURRENCY_INFO}.make */
void F123_1770 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(1793,F123_1793, (Current));
	F123_1802(Current, tr1);
	F123_1803(Current, ((EIF_INTEGER_32) 0L));
	tr1 = RTOSCF(1794,F123_1794, (Current));
	F123_1804(Current, tr1);
	F123_1805(Current, ((EIF_INTEGER_32) 2L));
	tr1 = RTOSCF(1797,F123_1797, (Current));
	F123_1806(Current, tr1);
	tr1 = RTOSCF(1798,F123_1798, (Current));
	F123_1807(Current, tr1);
	tr1 = RTOSCF(1799,F123_1799, (Current));
	F123_1808(Current, tr1);
	tr1 = RTOSCF(1800,F123_1800, (Current));
	F123_1809(Current, tr1);
	tr1 = RTOSCF(1801,F123_1801, (Current));
	F123_1810(Current, tr1);
	tr1 = RTOSCF(1793,F123_1793, (Current));
	F123_1811(Current, tr1);
	F123_1812(Current, ((EIF_INTEGER_32) 0L));
	tr1 = RTOSCF(1794,F123_1794, (Current));
	F123_1813(Current, tr1);
	F123_1814(Current, ((EIF_INTEGER_32) 2L));
	tr1 = RTOSCF(1797,F123_1797, (Current));
	F123_1815(Current, tr1);
	tr1 = RTOSCF(1798,F123_1798, (Current));
	F123_1816(Current, tr1);
	tr1 = RTOSCF(1801,F123_1801, (Current));
	F123_1817(Current, tr1);
	RTLE;
}

/* {I18N_CURRENCY_INFO}.default_currency_symbol */
static EIF_REFERENCE F123_1793_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1793);
#define Result RTOSR(1793)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("",0,0);
	RTOSE (1793);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F123_1793 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1793,F123_1793_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_decimal_separator */
static EIF_REFERENCE F123_1794_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1794);
#define Result RTOSR(1794)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H(".\000\000\000",1,46);
	RTOSE (1794);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F123_1794 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1794,F123_1794_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_group_separator */
static EIF_REFERENCE F123_1797_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1797);
#define Result RTOSR(1797)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H(",\000\000\000",1,44);
	RTOSE (1797);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F123_1797 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1797,F123_1797_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_number_list_separator */
static EIF_REFERENCE F123_1798_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1798);
#define Result RTOSR(1798)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H(";\000\000\000",1,59);
	RTOSE (1798);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F123_1798 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1798,F123_1798_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_positive_sign */
static EIF_REFERENCE F123_1799_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1799);
#define Result RTOSR(1799)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("",0,0);
	RTOSE (1799);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F123_1799 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1799,F123_1799_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_negative_sign */
static EIF_REFERENCE F123_1800_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (1800);
#define Result RTOSR(1800)
	RTOC_NEW(Result);
	Result = RTMS32_EX_H("-\000\000\000",1,45);
	RTOSE (1800);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F123_1800 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1800,F123_1800_body,(Current));
}

/* {I18N_CURRENCY_INFO}.default_currency_grouping */
static EIF_REFERENCE F123_1801_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (1801);
#define Result RTOSR(1801)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1110,1190,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 3L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 3L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1111_9016)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1801);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F123_1801 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1801,F123_1801_body,(Current));
}

/* {I18N_CURRENCY_INFO}.set_currency_symbol */
void F123_1802 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8033(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1756[Dtype(Current)-122]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_symbol_location */
void F123_1803 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O1757[Dtype(Current)-122]) = (EIF_INTEGER_32) arg1;
}

/* {I18N_CURRENCY_INFO}.set_currency_decimal_separator */
void F123_1804 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8034(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1761[Dtype(Current)-122]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_numbers_after_decimal_separator */
void F123_1805 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O1762[Dtype(Current)-122]) = (EIF_INTEGER_32) arg1;
}

/* {I18N_CURRENCY_INFO}.set_currency_group_separator */
void F123_1806 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8034(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1763[Dtype(Current)-122]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_number_list_separator */
void F123_1807 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8034(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1764[Dtype(Current)-122]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_positive_sign */
void F123_1808 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8034(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1765[Dtype(Current)-122]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_negative_sign */
void F123_1809 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8034(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1766[Dtype(Current)-122]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_currency_grouping */
void F123_1810 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O1767[Dtype(Current)-122]) = (EIF_REFERENCE) arg1;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_symbol */
void F123_1811 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8033(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1768[Dtype(Current)-122]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_symbol_location */
void F123_1812 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O1769[Dtype(Current)-122]) = (EIF_INTEGER_32) arg1;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_decimal_separator */
void F123_1813 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8034(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1773[Dtype(Current)-122]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_numbers_after_decimal_separator */
void F123_1814 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O1774[Dtype(Current)-122]) = (EIF_INTEGER_32) arg1;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_group_separator */
void F123_1815 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8034(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1775[Dtype(Current)-122]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_number_list_separator */
void F123_1816 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8034(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O1776[Dtype(Current)-122]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_CURRENCY_INFO}.set_international_currency_grouping */
void F123_1817 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O1777[Dtype(Current)-122]) = (EIF_REFERENCE) arg1;
}

void EIF_Minit101 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
