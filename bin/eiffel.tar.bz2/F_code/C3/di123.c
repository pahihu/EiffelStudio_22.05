/*
 * Code for class DIRECTORY_ITERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "di123.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DIRECTORY_ITERATOR}.process_directory */
void F147_2025 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	struct eif_ex_57 sloc4;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) sloc4.data;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	memset (&sloc4.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc4.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc4.overhead, eif_new_type(75, 0x00).id);
	RTLI(12);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,loc6);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc5);
	RTLR(6,loc7);
	RTLR(7,loc2);
	RTLR(8,loc1);
	RTLR(9,loc4);
	RTLR(10,loc8);
	RTLR(11,tr2);
	RTLIU(12);
	
	RTGC;
	loc3 = RTLNS(eif_new_type(419, 0x01).id, 419, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F420_5130(RTCW(loc3), arg1);
	tb1 = '\0';
	tb2 = F420_5154(RTCW(loc3));
	if (tb2) {
		tr1 = F420_5144(RTCW(loc3));
		loc6 = tr1;
		tb1 = EIF_TEST(loc6);
	}
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,922,0xFF01,1072,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc5 = RTLNS(typres0.id, 922, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		ti4_1 = F923_6939(loc6);
		F923_6918(RTCW(loc5), ti4_1);
		loc7 = F923_6932(loc6);
		for (;;) {
			tb1 = F531_5928(loc7);
			if (tb1) break;
			loc2 = F531_5919(loc7);
			if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R1989[dtype-147])(Current, loc2)) {
				if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R1990[dtype-147])(Current, loc2)) {
					tr1 = F420_5134(RTCW(loc3));
					loc1 = F1073_8941(RTCW(tr1), loc2);
					tb2 = F76_1163(RTCW(loc4), loc1);
					if (tb2) {
						F923_6958(RTCW(loc5), loc2);
					}
				}
				if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R1991[dtype-147])(Current, loc2)) {
					tr1 = F420_5134(RTCW(loc3));
					loc1 = F1073_8941(RTCW(tr1), loc2);
					tb2 = F76_1174(RTCW(loc4), loc1);
					if (tb2) {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1988[dtype-147])(Current, loc1);
					}
				}
			}
			F531_5934(loc7);
		}
		loc8 = F923_6932(RTCW(loc5));
		for (;;) {
			tb2 = F531_5928(loc8);
			if (tb2) break;
			tr1 = F420_5134(RTCW(loc3));
			tr2 = F531_5919(loc8);
			tr1 = F1073_8941(RTCW(tr1), tr2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1987[dtype-147])(Current, tr1);
			F531_5934(loc8);
		}
	}
	RTLE;
}

/* {DIRECTORY_ITERATOR}.path_excluded */
EIF_BOOLEAN F147_2027 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = F1073_8918(RTCW(arg1));
	if (!tb1) {
		tb1 = F1073_8919(RTCW(arg1));
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {DIRECTORY_ITERATOR}.directory_excluded */
EIF_BOOLEAN F147_2028 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

void EIF_Minit123 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
