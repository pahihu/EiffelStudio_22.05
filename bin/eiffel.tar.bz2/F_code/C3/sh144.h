
#ifndef _C3_sh144_
#define _C3_sh144_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2237)
static EIF_REFERENCE F170_2237_body(EIF_REFERENCE);
extern EIF_REFERENCE F170_2237(EIF_REFERENCE);
extern void EIF_Minit144(void);
extern void F1238_10852(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
