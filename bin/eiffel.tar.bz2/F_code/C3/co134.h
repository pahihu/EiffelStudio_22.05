
#ifndef _C3_co134_
#define _C3_co134_

#ifdef __cplusplus
extern "C" {
#endif

extern void F158_2120(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit134(void);

#ifdef __cplusplus
}
#endif

#endif
