
#ifndef _C3_ma117_
#define _C3_ma117_

#ifdef __cplusplus
extern "C" {
#endif

extern void F141_1939(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F141_1940(EIF_REFERENCE);
extern void F141_1941(EIF_REFERENCE, EIF_INTEGER_32);
extern void F141_1943(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F141_1945(EIF_REFERENCE);
extern void EIF_Minit117(void);
extern EIF_REFERENCE F1049_8033(EIF_REFERENCE);
extern void F1049_7974(EIF_REFERENCE);
extern char *(*R1911[])();
extern char *(*R1913[])();
extern long O1920[];

#ifdef __cplusplus
}
#endif

#endif
