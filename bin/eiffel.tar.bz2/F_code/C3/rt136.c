/*
 * Code for class RT_DEBUGGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rt136.h"
#include "eif_main.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F162_2162
static void inline_F162_2162 (EIF_BOOLEAN arg1)
{
	#ifdef WORKBENCH
	set_debug_mode (arg1 ? 1 : 0);
#endif
	;
}
#define INLINE_F162_2162
#endif
#ifndef INLINE_F162_2163
static int inline_F162_2163 (void)
{
	#ifdef WORKBENCH
	return EIF_TEST(is_debug_mode());
#else
	return EIF_FALSE;
#endif
	;
}
#define INLINE_F162_2163
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RT_DEBUGGER}.disable_debug */
void F162_2161 (EIF_REFERENCE Current)
{
	GTCX
	
	
	inline_F162_2162((EIF_BOOLEAN) 0);
}

/* {RT_DEBUGGER}.set_debug_state */
void F162_2162 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	inline_F162_2162 ((EIF_BOOLEAN) arg1);
}

/* {RT_DEBUGGER}.debug_state */
EIF_BOOLEAN F162_2163 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F162_2163 ());
	return Result;
}

void EIF_Minit136 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
