
#ifndef _C3_pa135_
#define _C3_pa135_

#ifdef __cplusplus
extern "C" {
#endif

extern void F161_2139(EIF_REFERENCE);
extern EIF_BOOLEAN F161_2142(EIF_REFERENCE);
extern EIF_BOOLEAN F161_2145(EIF_REFERENCE, EIF_REFERENCE);
extern void F161_2156(EIF_REFERENCE, EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 2159)


extern EIF_REFERENCE F161_2159(EIF_REFERENCE);
extern void EIF_Minit135(void);
extern void F1293_12475(EIF_REFERENCE, EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32);
extern long O6878[];

#ifdef __cplusplus
}
#endif

#endif
