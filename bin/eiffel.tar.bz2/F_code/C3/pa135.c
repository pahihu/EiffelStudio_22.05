/*
 * Code for class PATTERN_MATCHER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa135.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PATTERN_MATCHER}.wipe_out */
void F161_2139 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_2_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_1_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTOSCF(2159,F161_2159, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {PATTERN_MATCHER}.has_matched */
EIF_BOOLEAN F161_2142 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_11_16_0_2_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu4_1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
	return Result;
}

/* {PATTERN_MATCHER}.matches */
EIF_BOOLEAN F161_2145 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F161_2156(Current, arg1);
	RTLE;
	return (EIF_BOOLEAN) F161_2142(Current);
}

/* {PATTERN_MATCHER}.match */
void F161_2156 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O6878[Dtype(arg1)-1051]);
	tu4_1 = (EIF_NATURAL_32) ti4_1;
	F1293_12475(Current, arg1, (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L), tu4_1);
	RTLE;
}

/* {PATTERN_MATCHER}.no_subject */

EIF_REFERENCE F161_2159 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2159,RTMS_EX_H("",0,0));
}

void EIF_Minit135 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
