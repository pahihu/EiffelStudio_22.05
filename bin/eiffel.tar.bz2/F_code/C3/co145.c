/*
 * Code for class CONF_PARSER_CONTROLLER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co145.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_PARSER_CONTROLLER}.is_ignore_bad_libraries */
EIF_BOOLEAN F171_2238 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = *(EIF_BOOLEAN *)(RTCV(RTOSCF(2244,F171_2244, (Current)))+ _CHROFF_0_0_);
	RTLE;
	return Result;
}

/* {CONF_PARSER_CONTROLLER}.is_safe_preferred */
EIF_BOOLEAN F171_2239 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = *(EIF_BOOLEAN *)(RTCV(RTOSCF(2245,F171_2245, (Current)))+ _CHROFF_0_0_);
	RTLE;
	return Result;
}

/* {CONF_PARSER_CONTROLLER}.resolved_location_path */
EIF_REFERENCE F171_2240 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	if (F171_2239(Current)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O6953[Dtype(arg1)-1055]);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 4L));
	}
	if (tb1) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O6953[Dtype(arg1)-1055]);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O6953[Dtype(arg1)-1055]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6796[Dtype(RTCW(arg1))-1052])(arg1, (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 3L)), ti4_2);
		loc1 = F1049_8033(RTCW(tr1));
		tr1 = RTMS_EX_H(".ecf",4,778396518);
		tb1 = F1049_8016(RTCW(loc1), tr1);
		if (tb1) {
			loc2 = RTLNS(eif_new_type(803, 0x01).id, 803, _OBJSIZ_4_6_2_4_1_1_2_1_);
			F802_6202(RTCW(loc2), arg1);
			tb1 = '\0';
			tb2 = F802_6237(RTCW(loc2));
			if (tb2) {
				tb2 = F802_6240(RTCW(loc2));
				tb1 = tb2;
			}
			if (tb1) {
				loc3 = RTLNS(eif_new_type(1057, 0x01).id, 1057, _OBJSIZ_1_1_0_3_0_0_0_0_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O6953[Dtype(arg1)-1055]);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6796[Dtype(RTCW(arg1))-1052])(arg1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 4L)));
				F1056_8272(RTCW(loc3), tr1);
				tr1 = RTMS_EX_H("-safe",5,1936108645);
				F1058_8384(RTCW(loc3), tr1);
				F1058_8387(RTCW(loc3), loc1);
				F802_6336(RTCW(loc2), loc3);
				tb1 = '\01';
				tb2 = F802_6237(RTCW(loc2));
				if (!(EIF_BOOLEAN) !tb2) {
					tb2 = F802_6240(RTCW(loc2));
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					loc3 = (EIF_REFERENCE) NULL;
				}
			}
		}
	}
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		RTLE;
		return (EIF_REFERENCE) arg1;
	} else {
		RTLE;
		return (EIF_REFERENCE) loc3;
	}/* NOTREACHED */
	
}

/* {CONF_PARSER_CONTROLLER}.resolved_library_path */
EIF_REFERENCE F171_2241 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F171_2240(Current, arg1);
}

/* {CONF_PARSER_CONTROLLER}.is_ignore_bad_libraries_cell */
static EIF_REFERENCE F171_2244_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2244);
#define Result RTOSR(2244)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,179,1005,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 179, _OBJSIZ_0_1_0_0_0_0_0_0_);
	}
	F180_2355(RTCW(tr1), (EIF_BOOLEAN) 0);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2244);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F171_2244 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2244,F171_2244_body,(Current));
}

/* {CONF_PARSER_CONTROLLER}.is_safe_preferred_cell */
static EIF_REFERENCE F171_2245_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2245);
#define Result RTOSR(2245)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,179,1005,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 179, _OBJSIZ_0_1_0_0_0_0_0_0_);
	}
	F180_2355(RTCW(tr1), (EIF_BOOLEAN) 0);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2245);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F171_2245 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2245,F171_2245_body,(Current));
}

void EIF_Minit145 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
