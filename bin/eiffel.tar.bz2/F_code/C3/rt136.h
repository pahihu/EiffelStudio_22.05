
#ifndef _C3_rt136_
#define _C3_rt136_

#ifdef __cplusplus
extern "C" {
#endif

extern void F162_2161(EIF_REFERENCE);
extern void F162_2162(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F162_2163(EIF_REFERENCE);
extern void EIF_Minit136(void);

#ifdef __cplusplus
}
#endif

#endif
