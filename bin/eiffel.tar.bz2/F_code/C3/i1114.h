
#ifndef _C3_i1114_
#define _C3_i1114_

#ifdef __cplusplus
extern "C" {
#endif

extern void F138_1921(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit114(void);

#ifdef __cplusplus
}
#endif

#endif
