
#ifndef _C3_do139_
#define _C3_do139_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F165_2184(EIF_REFERENCE, EIF_REAL_64);
extern EIF_REAL_64 F165_2186(EIF_REFERENCE, EIF_REAL_64);
extern void EIF_Minit139(void);

#ifdef __cplusplus
}
#endif

#endif
