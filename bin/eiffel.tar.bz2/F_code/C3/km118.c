/*
 * Code for class KMP_MATCHER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "km118.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KMP_MATCHER}.make_empty */
void F142_1950 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1110,1190,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 0L),sizeof(EIF_INTEGER_32), EIF_TRUE);
	}
	F1111_9008(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	F141_1940(Current);
	RTLE;
}

/* {KMP_MATCHER}.set_pattern */
void F142_1955 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1049_8033(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {KMP_MATCHER}.search_for_pattern */
EIF_BOOLEAN F142_1958 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_CHARACTER_32 tw3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc7);
	RTLR(5,loc8);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTGC;
	loc5 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc4 = *(EIF_REFERENCE *)(Current);
	if (*(EIF_BOOLEAN *)(Current + O1924[dtype-141])) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F1058_8420(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F1058_8420(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	F142_1960(Current);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc7 = *(EIF_REFERENCE *)(RTCW(tr1));
	loc8 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc6 = *(EIF_REFERENCE *)(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	loc3 = *(EIF_INTEGER_32 *)(Current + O1920[dtype-140]);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
	loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (Result || (EIF_BOOLEAN) (loc3 >= loc1))) break;
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc9 == ((EIF_INTEGER_32) -1L))) {
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)RTCW(loc7) + (loc9));
			/* END INLINED CODE */
			tw1 = tw2;
			/* INLINED CODE (SPECIAL.item) */
			tw3 = *((EIF_CHARACTER_32 *)RTCW(loc6) + (loc3));
			/* END INLINED CODE */
			tw2 = tw3;
			tb1 = (EIF_BOOLEAN)(tw1 == tw2);
		}
		if (tb1) {
			loc3++;
			loc9++;
			if ((EIF_BOOLEAN) (loc9 >= loc2)) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				*(EIF_INTEGER_32 *)(Current + O1920[dtype-140]) = (EIF_INTEGER_32) loc3;
			}
		} else {
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(loc8) + (loc9));
			/* END INLINED CODE */
			ti4_1 = ti4_2;
			loc9 = (EIF_INTEGER_32) ti4_1;
		}
	}
	*(EIF_BOOLEAN *)(Current + O1915[dtype-140]) = (EIF_BOOLEAN) Result;
	if (*(EIF_BOOLEAN *)(Current + O1924[dtype-141])) {
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc5;
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc4;
	}
	RTLE;
	return Result;
}

/* {KMP_MATCHER}.init_arrays */
void F142_1960 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_CHARACTER_32 tw3;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_REFERENCE *)(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1111_9043(RTCW(tr1), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_INTEGER_32 *)RTCW(loc1) + (((EIF_INTEGER_32) 0L))) = ((EIF_INTEGER_32) -1L);
	/* END INLINED CODE */
	;
	for (;;) {
		if ((EIF_BOOLEAN) (loc4 >= loc3)) break;
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) -1L))) {
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)RTCW(loc2) + (loc4));
			/* END INLINED CODE */
			tw1 = tw2;
			/* INLINED CODE (SPECIAL.item) */
			tw3 = *((EIF_CHARACTER_32 *)RTCW(loc2) + (loc5));
			/* END INLINED CODE */
			tw2 = tw3;
			tb1 = (EIF_BOOLEAN)(tw1 == tw2);
		}
		if (tb1) {
			loc4++;
			loc5++;
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)RTCW(loc2) + (loc5));
			/* END INLINED CODE */
			tw1 = tw2;
			/* INLINED CODE (SPECIAL.item) */
			tw3 = *((EIF_CHARACTER_32 *)RTCW(loc2) + (loc4));
			/* END INLINED CODE */
			tw2 = tw3;
			if ((EIF_BOOLEAN)(tw1 == tw2)) {
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(loc1) + (loc5));
				/* END INLINED CODE */
				ti4_1 = ti4_2;
				/* INLINED CODE (SPECIAL.put) */
				*((EIF_INTEGER_32 *)RTCW(loc1) + (loc4)) = ti4_1;
				/* END INLINED CODE */
				;
			} else {
				/* INLINED CODE (SPECIAL.put) */
				*((EIF_INTEGER_32 *)RTCW(loc1) + (loc4)) = loc5;
				/* END INLINED CODE */
				;
			}
		} else {
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(loc1) + (loc5));
			/* END INLINED CODE */
			ti4_1 = ti4_2;
			loc5 = (EIF_INTEGER_32) ti4_1;
		}
	}
	RTLE;
}

void EIF_Minit118 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
