
#ifndef _C3_i1115_
#define _C3_i1115_

#ifdef __cplusplus
extern "C" {
#endif

extern void F139_1936(EIF_REFERENCE, EIF_REFERENCE);
extern void F139_1937(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit115(void);
extern long O1761[];
extern long O1762[];
extern long O1763[];
extern long O1765[];
extern long O1766[];
extern long O1767[];

#ifdef __cplusplus
}
#endif

#endif
