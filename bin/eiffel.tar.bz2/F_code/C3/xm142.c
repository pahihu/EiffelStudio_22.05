/*
 * Code for class XML_MARKUP_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm142.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_MARKUP_CONSTANTS}.lt_entity */

EIF_REFERENCE F168_2216 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2216,RTMS32_EX_H("&\000\000\000l\000\000\000t\000\000\000;\000\000\000",4,644641851));
}

/* {XML_MARKUP_CONSTANTS}.gt_entity */

EIF_REFERENCE F168_2217 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2217,RTMS32_EX_H("&\000\000\000g\000\000\000t\000\000\000;\000\000\000",4,644314171));
}

void EIF_Minit142 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
