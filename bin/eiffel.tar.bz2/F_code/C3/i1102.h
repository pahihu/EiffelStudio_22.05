
#ifndef _C3_i1102_
#define _C3_i1102_

#ifdef __cplusplus
extern "C" {
#endif

extern void F124_1818(EIF_REFERENCE);
extern void F124_1820(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit102(void);
extern void F123_1770(EIF_REFERENCE);
extern void F1221_10368(EIF_REFERENCE, EIF_REFERENCE);
extern void F121_1708(EIF_REFERENCE);
extern void F122_1748(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
