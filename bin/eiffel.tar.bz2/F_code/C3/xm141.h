
#ifndef _C3_xm141_
#define _C3_xm141_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 2194)


extern EIF_REFERENCE F167_2194(EIF_REFERENCE);
extern void EIF_Minit141(void);

#ifdef __cplusplus
}
#endif

#endif
