/*
 * Code for class XML_XMLNS_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm141.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_XMLNS_CONSTANTS}.default_namespace */

EIF_REFERENCE F167_2194 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2194,RTMS32_EX_H("",0,0));
}

void EIF_Minit141 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
