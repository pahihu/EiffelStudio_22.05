#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O5300[730];
void O5300_init () {
	{long i; for (i = 0; i < 193; i++) O5300[i] = + _CHROFF_0_0_;}
	O5300[193] = + _CHROFF_1_0_;
	{long i; for (i = 194; i < 220; i++) O5300[i] = + _CHROFF_0_0_;}
	O5300[220] = + _CHROFF_3_2_;
	O5300[221] = + _CHROFF_5_2_;
	O5300[222] = + _CHROFF_4_2_;
	O5300[244] = + _CHROFF_7_0_;
	O5300[245] = + _CHROFF_6_0_;
	{long i; for (i = 246; i < 248; i++) O5300[i] = + _CHROFF_5_0_;}
	O5300[248] = + _CHROFF_4_0_;
	{long i; for (i = 249; i < 252; i++) O5300[i] = + _CHROFF_5_0_;}
	O5300[252] = + _CHROFF_9_0_;
	O5300[253] = + _CHROFF_7_0_;
	{long i; for (i = 254; i < 258; i++) O5300[i] = + _CHROFF_5_0_;}
	{long i; for (i = 258; i < 271; i++) O5300[i] = + _CHROFF_0_0_;}
	{long i; for (i = 271; i < 288; i++) O5300[i] = + _CHROFF_1_0_;}
	{long i; for (i = 288; i < 336; i++) O5300[i] = + _CHROFF_0_0_;}
	{long i; for (i = 336; i < 341; i++) O5300[i] = + _CHROFF_2_0_;}
	{long i; for (i = 341; i < 355; i++) O5300[i] = + _CHROFF_1_0_;}
	O5300[355] = + _CHROFF_5_0_;
	O5300[356] = + _CHROFF_1_0_;
	{long i; for (i = 472; i < 474; i++) O5300[i] = + _CHROFF_1_0_;}
	O5300[476] = + _CHROFF_1_0_;
	O5300[642] = + _CHROFF_5_2_;
	{long i; for (i = 688; i < 691; i++) O5300[i] = + _CHROFF_5_2_;}
	O5300[692] = + _CHROFF_7_2_;
	{long i; for (i = 693; i < 697; i++) O5300[i] = + _CHROFF_6_2_;}
	{long i; for (i = 728; i < 730; i++) O5300[i] = + _CHROFF_1_0_;}
}

EIF_TYPE_INDEX *Y5424_gen_type [1];
EIF_TYPE_INDEX Y5424 [1];
void Y5424_init (void)
{
	egc_routines_types [5424] = Y5424;
	egc_routines_gen_types [5424] = Y5424_gen_type;
	egc_routines_offset [5424] = 774;
	Y5424[0] = 1190;
}

long O5441[477];
void O5441_init () {
	O5441[0] = + _PTROFF_3_6_2_4_1_0_;
	O5441[1] = + _PTROFF_5_7_2_4_1_0_;
	O5441[2] = + _PTROFF_4_6_2_4_1_0_;
	O5441[422] = + _PTROFF_5_7_2_4_1_0_;
	{long i; for (i = 468; i < 471; i++) O5441[i] = + _PTROFF_5_6_2_4_1_0_;}
	O5441[472] = + _PTROFF_7_8_2_4_1_0_;
	{long i; for (i = 473; i < 477; i++) O5441[i] = + _PTROFF_6_7_2_4_1_0_;}
}

long O5524[477];
void O5524_init () {
	{long i; for (i = 0; i < 3; i++) O5524[i] =  + _REFACS_1_;}
	O5524[422] =  + _REFACS_1_;
	{long i; for (i = 468; i < 471; i++) O5524[i] =  + _REFACS_1_;}
	{long i; for (i = 472; i < 477; i++) O5524[i] = 0;}
}

long O5526[477];
void O5526_init () {
	{long i; for (i = 0; i < 3; i++) O5526[i] =  + _REFACS_2_;}
	O5526[422] =  + _REFACS_2_;
	{long i; for (i = 468; i < 471; i++) O5526[i] =  + _REFACS_2_;}
	{long i; for (i = 472; i < 477; i++) O5526[i] =  + _REFACS_1_;}
}

long O5580[477];
void O5580_init () {
	O5580[0] = + _LNGOFF_3_6_2_3_;
	O5580[1] = + _LNGOFF_5_7_2_3_;
	O5580[2] = + _LNGOFF_4_6_2_3_;
	O5580[422] = + _LNGOFF_5_7_2_3_;
	{long i; for (i = 468; i < 471; i++) O5580[i] = + _LNGOFF_5_6_2_3_;}
	O5580[472] = + _LNGOFF_7_8_2_3_;
	{long i; for (i = 473; i < 477; i++) O5580[i] = + _LNGOFF_6_7_2_3_;}
}

long O5589[477];
void O5589_init () {
	O5589[0] = + _CHROFF_3_3_;
	O5589[1] = + _CHROFF_5_3_;
	O5589[2] = + _CHROFF_4_3_;
	O5589[422] = + _CHROFF_5_3_;
	{long i; for (i = 468; i < 471; i++) O5589[i] = + _CHROFF_5_3_;}
	O5589[472] = + _CHROFF_7_3_;
	{long i; for (i = 473; i < 477; i++) O5589[i] = + _CHROFF_6_3_;}
}

long O5617[475];
void O5617_init () {
	O5617[0] =  + _REFACS_3_;
	{long i; for (i = 466; i < 469; i++) O5617[i] =  + _REFACS_3_;}
	{long i; for (i = 471; i < 475; i++) O5617[i] =  + _REFACS_2_;}
}

long O5647[14];
void O5647_init () {
	{long i; for (i = 0; i < 2; i++) O5647[i] = 0;}
	O5647[2] = + _CHROFF_5_1_;
	O5647[3] = + _LNGOFF_5_3_0_0_;
	O5647[4] = + _LNGOFF_4_3_0_0_;
	O5647[5] = + _LNGOFF_5_3_0_0_;
	O5647[6] = + _CHROFF_5_3_;
	O5647[7] = + _PTROFF_5_3_0_7_0_0_;
	{long i; for (i = 8; i < 10; i++) O5647[i] = 0;}
	O5647[10] = + _CHROFF_5_1_;
	{long i; for (i = 11; i < 13; i++) O5647[i] = + _LNGOFF_5_4_0_0_;}
	O5647[13] = + _CHROFF_5_4_;
}

long O5656[14];
void O5656_init () {
	O5656[0] = + _LNGOFF_7_3_0_0_;
	O5656[1] = + _LNGOFF_6_3_0_0_;
	O5656[2] = + _LNGOFF_5_5_0_0_;
	O5656[3] = + _LNGOFF_5_3_0_1_;
	O5656[4] = + _LNGOFF_4_3_0_1_;
	O5656[5] = + _LNGOFF_5_3_0_2_;
	O5656[6] = + _LNGOFF_5_5_0_0_;
	O5656[7] = + _LNGOFF_5_3_0_0_;
	O5656[8] = + _LNGOFF_9_3_0_0_;
	O5656[9] = + _LNGOFF_7_4_0_0_;
	O5656[10] = + _LNGOFF_5_6_0_0_;
	O5656[11] = + _LNGOFF_5_4_0_1_;
	O5656[12] = + _LNGOFF_5_4_0_2_;
	O5656[13] = + _LNGOFF_5_6_0_0_;
}

long O5683[14];
void O5683_init () {
	{long i; for (i = 0; i < 2; i++) O5683[i] =  + _REFACS_1_;}
	{long i; for (i = 2; i < 8; i++) O5683[i] = 0;}
	{long i; for (i = 8; i < 10; i++) O5683[i] =  + _REFACS_1_;}
	{long i; for (i = 10; i < 14; i++) O5683[i] = 0;}
}

static EIF_TYPE_INDEX Y5683_pgtype0[] = {0xFF01,1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5683_pgtype1[] = {0xFF01,1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5683_pgtype2[] = {0xFF01,1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5683_pgtype3[] = {0xFF01,1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5683_pgtype4[] = {0xFF01,1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5683_pgtype5[] = {0xFF01,1111,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5683_pgtype6[] = {0xFF01,1117,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5683_pgtype7[] = {0xFF01,1118,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5683_pgtype8[] = {0xFF01,1108,0,0xFFFF};
static EIF_TYPE_INDEX Y5683_pgtype9[] = {0xFF01,1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5683_pgtype10[] = {0xFF01,1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5683_pgtype11[] = {0xFF01,1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5683_pgtype12[] = {0xFF01,1111,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5683_pgtype13[] = {0xFF01,1117,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5683_gen_type [14];
EIF_TYPE_INDEX Y5683 [14];
void Y5683_init (void)
{
	egc_routines_types [5683] = Y5683;
	egc_routines_gen_types [5683] = Y5683_gen_type;
	egc_routines_offset [5683] = 825;
	Y5683_gen_type [0] = Y5683_pgtype0;
	Y5683_gen_type [1] = Y5683_pgtype1;
	Y5683_gen_type [2] = Y5683_pgtype2;
	Y5683_gen_type [3] = Y5683_pgtype3;
	Y5683_gen_type [4] = Y5683_pgtype4;
	Y5683_gen_type [5] = Y5683_pgtype5;
	Y5683_gen_type [6] = Y5683_pgtype6;
	Y5683_gen_type [7] = Y5683_pgtype7;
	Y5683_gen_type [8] = Y5683_pgtype8;
	Y5683_gen_type [9] = Y5683_pgtype9;
	Y5683_gen_type [10] = Y5683_pgtype10;
	Y5683_gen_type [11] = Y5683_pgtype11;
	Y5683_gen_type [12] = Y5683_pgtype12;
	Y5683_gen_type [13] = Y5683_pgtype13;
	{long i; for (i = 0; i < 2; i++) Y5683[i] = 1108;};
	Y5683[2] = 1109;
	{long i; for (i = 3; i < 5; i++) Y5683[i] = 1110;};
	Y5683[5] = 1111;
	Y5683[6] = 1117;
	Y5683[7] = 1118;
	{long i; for (i = 8; i < 10; i++) Y5683[i] = 1108;};
	Y5683[10] = 1109;
	Y5683[11] = 1110;
	Y5683[12] = 1111;
	Y5683[13] = 1117;
}

long O5684[14];
void O5684_init () {
	{long i; for (i = 0; i < 2; i++) O5684[i] =  + _REFACS_2_;}
	{long i; for (i = 2; i < 8; i++) O5684[i] =  + _REFACS_1_;}
	{long i; for (i = 8; i < 10; i++) O5684[i] =  + _REFACS_2_;}
	{long i; for (i = 10; i < 14; i++) O5684[i] =  + _REFACS_1_;}
}

static EIF_TYPE_INDEX Y5684_pgtype0[] = {0xFF01,1108,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5684_pgtype1[] = {0xFF01,1110,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5684_pgtype2[] = {0xFF01,1108,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5684_pgtype3[] = {0xFF01,1108,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5684_pgtype4[] = {0xFF01,1110,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5684_pgtype5[] = {0xFF01,1108,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5684_pgtype6[] = {0xFF01,1108,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5684_pgtype7[] = {0xFF01,1108,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5684_pgtype8[] = {0xFF01,1108,0xFF01,1053,0xFFFF};
static EIF_TYPE_INDEX Y5684_pgtype9[] = {0xFF01,1108,0xFF01,1048,0xFFFF};
static EIF_TYPE_INDEX Y5684_pgtype10[] = {0xFF01,1108,0xFF01,1048,0xFFFF};
static EIF_TYPE_INDEX Y5684_pgtype11[] = {0xFF01,1108,0xFF01,1048,0xFFFF};
static EIF_TYPE_INDEX Y5684_pgtype12[] = {0xFF01,1108,0xFF01,1048,0xFFFF};
static EIF_TYPE_INDEX Y5684_pgtype13[] = {0xFF01,1108,0xFF01,1048,0xFFFF};
EIF_TYPE_INDEX *Y5684_gen_type [14];
EIF_TYPE_INDEX Y5684 [14];
void Y5684_init (void)
{
	egc_routines_types [5684] = Y5684;
	egc_routines_gen_types [5684] = Y5684_gen_type;
	egc_routines_offset [5684] = 825;
	Y5684_gen_type [0] = Y5684_pgtype0;
	Y5684_gen_type [1] = Y5684_pgtype1;
	Y5684_gen_type [2] = Y5684_pgtype2;
	Y5684_gen_type [3] = Y5684_pgtype3;
	Y5684_gen_type [4] = Y5684_pgtype4;
	Y5684_gen_type [5] = Y5684_pgtype5;
	Y5684_gen_type [6] = Y5684_pgtype6;
	Y5684_gen_type [7] = Y5684_pgtype7;
	Y5684_gen_type [8] = Y5684_pgtype8;
	Y5684_gen_type [9] = Y5684_pgtype9;
	Y5684_gen_type [10] = Y5684_pgtype10;
	Y5684_gen_type [11] = Y5684_pgtype11;
	Y5684_gen_type [12] = Y5684_pgtype12;
	Y5684_gen_type [13] = Y5684_pgtype13;
	Y5684[0] = 1108;
	Y5684[1] = 1110;
	{long i; for (i = 2; i < 4; i++) Y5684[i] = 1108;};
	Y5684[4] = 1110;
	{long i; for (i = 5; i < 14; i++) Y5684[i] = 1108;};
}

long O5685[14];
void O5685_init () {
	{long i; for (i = 0; i < 2; i++) O5685[i] =  + _REFACS_3_;}
	{long i; for (i = 2; i < 8; i++) O5685[i] =  + _REFACS_2_;}
	{long i; for (i = 8; i < 10; i++) O5685[i] =  + _REFACS_3_;}
	{long i; for (i = 10; i < 14; i++) O5685[i] =  + _REFACS_2_;}
}

long O5686[14];
void O5686_init () {
	{long i; for (i = 0; i < 2; i++) O5686[i] =  + _REFACS_4_;}
	{long i; for (i = 2; i < 8; i++) O5686[i] =  + _REFACS_3_;}
	{long i; for (i = 8; i < 10; i++) O5686[i] =  + _REFACS_4_;}
	{long i; for (i = 10; i < 14; i++) O5686[i] =  + _REFACS_3_;}
}

long O5687[14];
void O5687_init () {
	O5687[0] = + _LNGOFF_7_3_0_1_;
	O5687[1] = + _LNGOFF_6_3_0_1_;
	O5687[2] = + _LNGOFF_5_5_0_1_;
	O5687[3] = + _LNGOFF_5_3_0_2_;
	O5687[4] = + _LNGOFF_4_3_0_2_;
	O5687[5] = + _LNGOFF_5_3_0_3_;
	O5687[6] = + _LNGOFF_5_5_0_1_;
	O5687[7] = + _LNGOFF_5_3_0_1_;
	O5687[8] = + _LNGOFF_9_3_0_1_;
	O5687[9] = + _LNGOFF_7_4_0_1_;
	O5687[10] = + _LNGOFF_5_6_0_1_;
	O5687[11] = + _LNGOFF_5_4_0_2_;
	O5687[12] = + _LNGOFF_5_4_0_3_;
	O5687[13] = + _LNGOFF_5_6_0_1_;
}

long O5688[14];
void O5688_init () {
	O5688[0] = + _CHROFF_7_2_;
	O5688[1] = + _CHROFF_6_2_;
	O5688[2] = + _CHROFF_5_3_;
	O5688[3] = + _CHROFF_5_2_;
	O5688[4] = + _CHROFF_4_2_;
	{long i; for (i = 5; i < 8; i++) O5688[i] = + _CHROFF_5_2_;}
	O5688[8] = + _CHROFF_9_2_;
	O5688[9] = + _CHROFF_7_2_;
	O5688[10] = + _CHROFF_5_3_;
	{long i; for (i = 11; i < 14; i++) O5688[i] = + _CHROFF_5_2_;}
}

long O5689[14];
void O5689_init () {
	O5689[0] = + _LNGOFF_7_3_0_2_;
	O5689[1] = + _LNGOFF_6_3_0_2_;
	O5689[2] = + _LNGOFF_5_5_0_2_;
	O5689[3] = + _LNGOFF_5_3_0_3_;
	O5689[4] = + _LNGOFF_4_3_0_3_;
	O5689[5] = + _LNGOFF_5_3_0_4_;
	O5689[6] = + _LNGOFF_5_5_0_2_;
	O5689[7] = + _LNGOFF_5_3_0_2_;
	O5689[8] = + _LNGOFF_9_3_0_2_;
	O5689[9] = + _LNGOFF_7_4_0_2_;
	O5689[10] = + _LNGOFF_5_6_0_2_;
	O5689[11] = + _LNGOFF_5_4_0_3_;
	O5689[12] = + _LNGOFF_5_4_0_4_;
	O5689[13] = + _LNGOFF_5_6_0_2_;
}

long O5692[14];
void O5692_init () {
	O5692[0] = + _LNGOFF_7_3_0_3_;
	O5692[1] = + _LNGOFF_6_3_0_3_;
	O5692[2] = + _LNGOFF_5_5_0_3_;
	O5692[3] = + _LNGOFF_5_3_0_4_;
	O5692[4] = + _LNGOFF_4_3_0_4_;
	O5692[5] = + _LNGOFF_5_3_0_5_;
	O5692[6] = + _LNGOFF_5_5_0_3_;
	O5692[7] = + _LNGOFF_5_3_0_3_;
	O5692[8] = + _LNGOFF_9_3_0_3_;
	O5692[9] = + _LNGOFF_7_4_0_3_;
	O5692[10] = + _LNGOFF_5_6_0_3_;
	O5692[11] = + _LNGOFF_5_4_0_4_;
	O5692[12] = + _LNGOFF_5_4_0_5_;
	O5692[13] = + _LNGOFF_5_6_0_3_;
}

long O5693[14];
void O5693_init () {
	O5693[0] = + _LNGOFF_7_3_0_4_;
	O5693[1] = + _LNGOFF_6_3_0_4_;
	O5693[2] = + _LNGOFF_5_5_0_4_;
	O5693[3] = + _LNGOFF_5_3_0_5_;
	O5693[4] = + _LNGOFF_4_3_0_5_;
	O5693[5] = + _LNGOFF_5_3_0_6_;
	O5693[6] = + _LNGOFF_5_5_0_4_;
	O5693[7] = + _LNGOFF_5_3_0_4_;
	O5693[8] = + _LNGOFF_9_3_0_4_;
	O5693[9] = + _LNGOFF_7_4_0_4_;
	O5693[10] = + _LNGOFF_5_6_0_4_;
	O5693[11] = + _LNGOFF_5_4_0_5_;
	O5693[12] = + _LNGOFF_5_4_0_6_;
	O5693[13] = + _LNGOFF_5_6_0_4_;
}

long O5697[14];
void O5697_init () {
	O5697[0] = + _LNGOFF_7_3_0_5_;
	O5697[1] = + _LNGOFF_6_3_0_5_;
	O5697[2] = + _LNGOFF_5_5_0_5_;
	O5697[3] = + _LNGOFF_5_3_0_6_;
	O5697[4] = + _LNGOFF_4_3_0_6_;
	O5697[5] = + _LNGOFF_5_3_0_7_;
	O5697[6] = + _LNGOFF_5_5_0_5_;
	O5697[7] = + _LNGOFF_5_3_0_5_;
	O5697[8] = + _LNGOFF_9_3_0_5_;
	O5697[9] = + _LNGOFF_7_4_0_5_;
	O5697[10] = + _LNGOFF_5_6_0_5_;
	O5697[11] = + _LNGOFF_5_4_0_6_;
	O5697[12] = + _LNGOFF_5_4_0_7_;
	O5697[13] = + _LNGOFF_5_6_0_5_;
}

long O5698[14];
void O5698_init () {
	{long i; for (i = 0; i < 2; i++) O5698[i] =  + _REFACS_5_;}
	O5698[2] = + _CHROFF_5_4_;
	O5698[3] = + _LNGOFF_5_3_0_7_;
	O5698[4] = + _LNGOFF_4_3_0_7_;
	O5698[5] = + _LNGOFF_5_3_0_1_;
	O5698[6] = + _CHROFF_5_4_;
	O5698[7] = + _PTROFF_5_3_0_7_0_1_;
	{long i; for (i = 8; i < 10; i++) O5698[i] =  + _REFACS_5_;}
	O5698[10] = + _CHROFF_5_4_;
	O5698[11] = + _LNGOFF_5_4_0_7_;
	O5698[12] = + _LNGOFF_5_4_0_1_;
	O5698[13] = + _CHROFF_5_5_;
}

long O5699[14];
void O5699_init () {
	O5699[0] =  + _REFACS_6_;
	O5699[1] = + _LNGOFF_6_3_0_6_;
	{long i; for (i = 2; i < 4; i++) O5699[i] =  + _REFACS_4_;}
	O5699[4] = + _LNGOFF_4_3_0_8_;
	{long i; for (i = 5; i < 8; i++) O5699[i] =  + _REFACS_4_;}
	{long i; for (i = 8; i < 10; i++) O5699[i] =  + _REFACS_6_;}
	{long i; for (i = 10; i < 14; i++) O5699[i] =  + _REFACS_4_;}
}

long O5733[14];
void O5733_init () {
	O5733[0] = + _LNGOFF_7_3_0_6_;
	O5733[1] = + _LNGOFF_6_3_0_7_;
	O5733[2] = + _LNGOFF_5_5_0_6_;
	O5733[3] = + _LNGOFF_5_3_0_8_;
	O5733[4] = + _LNGOFF_4_3_0_9_;
	O5733[5] = + _LNGOFF_5_3_0_8_;
	O5733[6] = + _LNGOFF_5_5_0_6_;
	O5733[7] = + _LNGOFF_5_3_0_6_;
	O5733[8] = + _LNGOFF_9_3_0_6_;
	O5733[9] = + _LNGOFF_7_4_0_6_;
	O5733[10] = + _LNGOFF_5_6_0_6_;
	{long i; for (i = 11; i < 13; i++) O5733[i] = + _LNGOFF_5_4_0_8_;}
	O5733[13] = + _LNGOFF_5_6_0_6_;
}

long O5746[5];
void O5746_init () {
	O5746[0] = + _CHROFF_7_3_;
	O5746[1] = + _CHROFF_5_5_;
	{long i; for (i = 2; i < 5; i++) O5746[i] = + _CHROFF_5_3_;}
}

long O5856[16];
void O5856_init () {
	{long i; for (i = 0; i < 14; i++) O5856[i] = + _LNGOFF_1_1_0_0_;}
	O5856[14] = + _LNGOFF_5_1_0_0_;
	O5856[15] = + _LNGOFF_1_1_0_0_;
}

long O6043[2];
void O6043_init () {
	O6043[0] = + _CHROFF_12_0_;
	O6043[1] = + _CHROFF_18_0_;
}

long O6044[2];
void O6044_init () {
	O6044[0] = + _CHROFF_12_1_;
	O6044[1] = + _CHROFF_18_1_;
}

long O6045[2];
void O6045_init () {
	O6045[0] = + _CHROFF_12_2_;
	O6045[1] = + _CHROFF_18_2_;
}

long O6046[2];
void O6046_init () {
	O6046[0] = + _CHROFF_12_3_;
	O6046[1] = + _CHROFF_18_3_;
}

long O6047[2];
void O6047_init () {
	O6047[0] = + _CHROFF_12_4_;
	O6047[1] = + _CHROFF_18_4_;
}

long O6048[2];
void O6048_init () {
	O6048[0] = + _CHROFF_12_5_;
	O6048[1] = + _CHROFF_18_5_;
}

long O6049[2];
void O6049_init () {
	O6049[0] = + _CHROFF_12_6_;
	O6049[1] = + _CHROFF_18_6_;
}

long O6050[2];
void O6050_init () {
	O6050[0] = + _CHROFF_12_7_;
	O6050[1] = + _CHROFF_18_7_;
}

long O6051[2];
void O6051_init () {
	O6051[0] = + _CHROFF_12_8_;
	O6051[1] = + _CHROFF_18_8_;
}

long O6066[2];
void O6066_init () {
	O6066[0] = + _CHROFF_12_9_;
	O6066[1] = + _CHROFF_18_9_;
}

long O6067[2];
void O6067_init () {
	O6067[0] = + _CHROFF_12_10_;
	O6067[1] = + _CHROFF_18_10_;
}

long O6068[2];
void O6068_init () {
	O6068[0] = + _CHROFF_12_11_;
	O6068[1] = + _CHROFF_18_11_;
}

long O6069[2];
void O6069_init () {
	O6069[0] = + _CHROFF_12_12_;
	O6069[1] = + _CHROFF_18_12_;
}

long O6070[2];
void O6070_init () {
	O6070[0] = + _CHROFF_12_13_;
	O6070[1] = + _CHROFF_18_13_;
}

long O6071[2];
void O6071_init () {
	O6071[0] = + _CHROFF_12_14_;
	O6071[1] = + _CHROFF_18_14_;
}

long O6072[2];
void O6072_init () {
	O6072[0] = + _CHROFF_12_15_;
	O6072[1] = + _CHROFF_18_15_;
}

long O6073[2];
void O6073_init () {
	O6073[0] = + _CHROFF_12_16_;
	O6073[1] = + _CHROFF_18_16_;
}

long O6074[2];
void O6074_init () {
	O6074[0] = + _CHROFF_12_17_;
	O6074[1] = + _CHROFF_18_17_;
}

long O6405[8];
void O6405_init () {
	O6405[0] = + _LNGOFF_2_0_0_0_;
	O6405[1] = + _LNGOFF_3_0_0_0_;
	{long i; for (i = 2; i < 5; i++) O6405[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 5; i < 7; i++) O6405[i] = + _LNGOFF_3_0_0_0_;}
	O6405[7] = + _LNGOFF_2_0_0_0_;
}

long O6406[8];
void O6406_init () {
	O6406[0] = + _LNGOFF_2_0_0_1_;
	O6406[1] = + _LNGOFF_3_0_0_1_;
	{long i; for (i = 2; i < 5; i++) O6406[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 5; i < 7; i++) O6406[i] = + _LNGOFF_3_0_0_1_;}
	O6406[7] = + _LNGOFF_2_0_0_1_;
}

long O6407[8];
void O6407_init () {
	O6407[0] = + _LNGOFF_2_0_0_2_;
	O6407[1] = + _LNGOFF_3_0_0_2_;
	{long i; for (i = 2; i < 5; i++) O6407[i] = + _LNGOFF_2_0_0_2_;}
	{long i; for (i = 5; i < 7; i++) O6407[i] = + _LNGOFF_3_0_0_2_;}
	O6407[7] = + _LNGOFF_2_0_0_2_;
}

long O6681[6];
void O6681_init () {
	{long i; for (i = 0; i < 2; i++) O6681[i] = + _CHROFF_4_0_;}
	O6681[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 6; i++) O6681[i] = + _CHROFF_4_0_;}
}

long O6682[6];
void O6682_init () {
	{long i; for (i = 0; i < 2; i++) O6682[i] = + _LNGOFF_4_2_0_0_;}
	O6682[2] = + _LNGOFF_5_2_0_0_;
	O6682[3] = + _LNGOFF_4_3_0_0_;
	O6682[4] = + _LNGOFF_4_2_0_0_;
	O6682[5] = + _LNGOFF_4_3_0_0_;
}

long O6690[6];
void O6690_init () {
	{long i; for (i = 0; i < 2; i++) O6690[i] = + _PTROFF_4_2_0_3_0_0_;}
	O6690[2] = + _PTROFF_5_2_0_3_0_0_;
	O6690[3] = + _PTROFF_4_3_0_3_0_0_;
	O6690[4] = + _PTROFF_4_2_0_4_0_0_;
	O6690[5] = + _PTROFF_4_3_0_3_0_0_;
}

long O6691[6];
void O6691_init () {
	{long i; for (i = 0; i < 2; i++) O6691[i] = + _PTROFF_4_2_0_3_0_1_;}
	O6691[2] = + _PTROFF_5_2_0_3_0_1_;
	O6691[3] = + _PTROFF_4_3_0_3_0_1_;
	O6691[4] = + _PTROFF_4_2_0_4_0_1_;
	O6691[5] = + _PTROFF_4_3_0_3_0_1_;
}

long O6693[6];
void O6693_init () {
	{long i; for (i = 0; i < 2; i++) O6693[i] = + _PTROFF_4_2_0_3_0_2_;}
	O6693[2] = + _PTROFF_5_2_0_3_0_2_;
	O6693[3] = + _PTROFF_4_3_0_3_0_2_;
	O6693[4] = + _PTROFF_4_2_0_4_0_2_;
	O6693[5] = + _PTROFF_4_3_0_3_0_2_;
}

long O6694[6];
void O6694_init () {
	{long i; for (i = 0; i < 2; i++) O6694[i] = + _LNGOFF_4_2_0_1_;}
	O6694[2] = + _LNGOFF_5_2_0_1_;
	O6694[3] = + _LNGOFF_4_3_0_1_;
	O6694[4] = + _LNGOFF_4_2_0_1_;
	O6694[5] = + _LNGOFF_4_3_0_1_;
}

long O6695[6];
void O6695_init () {
	{long i; for (i = 0; i < 2; i++) O6695[i] = + _CHROFF_4_1_;}
	O6695[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 6; i++) O6695[i] = + _CHROFF_4_1_;}
}

long O6696[6];
void O6696_init () {
	{long i; for (i = 0; i < 2; i++) O6696[i] = + _LNGOFF_4_2_0_2_;}
	O6696[2] = + _LNGOFF_5_2_0_2_;
	O6696[3] = + _LNGOFF_4_3_0_2_;
	O6696[4] = + _LNGOFF_4_2_0_2_;
	O6696[5] = + _LNGOFF_4_3_0_2_;
}

long O6709[4];
void O6709_init () {
	O6709[0] =  + _REFACS_4_;
	O6709[1] = + _CHROFF_4_2_;
	O6709[2] = + _LNGOFF_4_2_0_3_;
	O6709[3] = + _CHROFF_4_2_;
}

long O6808[263];
void O6808_init () {
	{long i; for (i = 0; i < 3; i++) O6808[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O6808[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 5; i < 7; i++) O6808[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 7; i < 9; i++) O6808[i] = + _LNGOFF_1_0_0_0_;}
	O6808[9] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 261; i < 263; i++) O6808[i] = + _LNGOFF_1_1_0_0_;}
}

long O6809[263];
void O6809_init () {
	{long i; for (i = 0; i < 3; i++) O6809[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O6809[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 5; i < 7; i++) O6809[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 7; i < 9; i++) O6809[i] = + _LNGOFF_1_0_0_1_;}
	O6809[9] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 261; i < 263; i++) O6809[i] = + _LNGOFF_1_1_0_1_;}
}

long O6878[260];
void O6878_init () {
	{long i; for (i = 0; i < 2; i++) O6878[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O6878[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 258; i < 260; i++) O6878[i] = + _LNGOFF_1_1_0_2_;}
}

long O6953[3];
void O6953_init () {
	{long i; for (i = 0; i < 2; i++) O6953[i] = + _LNGOFF_1_0_0_2_;}
	O6953[2] = + _LNGOFF_1_1_0_2_;
}

long O7557[10];
void O7557_init () {
	{long i; for (i = 0; i < 2; i++) O7557[i] = + _CHROFF_16_0_;}
	O7557[2] = + _CHROFF_18_0_;
	{long i; for (i = 3; i < 5; i++) O7557[i] = + _CHROFF_27_0_;}
	O7557[5] = + _CHROFF_29_0_;
	O7557[6] = + _CHROFF_18_0_;
	O7557[7] = + _CHROFF_23_0_;
	O7557[8] = + _CHROFF_21_0_;
	O7557[9] = + _CHROFF_22_0_;
}

long O7568[10];
void O7568_init () {
	{long i; for (i = 0; i < 3; i++) O7568[i] =  + _REFACS_3_;}
	{long i; for (i = 3; i < 6; i++) O7568[i] =  + _REFACS_5_;}
	{long i; for (i = 6; i < 8; i++) O7568[i] =  + _REFACS_3_;}
	{long i; for (i = 8; i < 10; i++) O7568[i] =  + _REFACS_5_;}
}

static EIF_TYPE_INDEX Y7568_pgtype0[] = {0xFF01,1055,0xFFFF};
static EIF_TYPE_INDEX Y7568_pgtype1[] = {0xFF01,1055,0xFFFF};
static EIF_TYPE_INDEX Y7568_pgtype2[] = {0xFF01,1055,0xFFFF};
static EIF_TYPE_INDEX Y7568_pgtype3[] = {0xFF01,1055,0xFFFF};
static EIF_TYPE_INDEX Y7568_pgtype4[] = {0xFF01,1055,0xFFFF};
static EIF_TYPE_INDEX Y7568_pgtype5[] = {0xFF01,1055,0xFFFF};
static EIF_TYPE_INDEX Y7568_pgtype6[] = {0xFF01,1055,0xFFFF};
static EIF_TYPE_INDEX Y7568_pgtype7[] = {0xFF01,1055,0xFFFF};
static EIF_TYPE_INDEX Y7568_pgtype8[] = {0xFF01,1055,0xFFFF};
static EIF_TYPE_INDEX Y7568_pgtype9[] = {0xFF01,1055,0xFFFF};
EIF_TYPE_INDEX *Y7568_gen_type [10];
EIF_TYPE_INDEX Y7568 [10];
void Y7568_init (void)
{
	egc_routines_types [7568] = Y7568;
	egc_routines_gen_types [7568] = Y7568_gen_type;
	egc_routines_offset [7568] = 1120;
	Y7568_gen_type [0] = Y7568_pgtype0;
	Y7568_gen_type [1] = Y7568_pgtype1;
	Y7568_gen_type [2] = Y7568_pgtype2;
	Y7568_gen_type [3] = Y7568_pgtype3;
	Y7568_gen_type [4] = Y7568_pgtype4;
	Y7568_gen_type [5] = Y7568_pgtype5;
	Y7568_gen_type [6] = Y7568_pgtype6;
	Y7568_gen_type [7] = Y7568_pgtype7;
	Y7568_gen_type [8] = Y7568_pgtype8;
	Y7568_gen_type [9] = Y7568_pgtype9;
	{long i; for (i = 0; i < 10; i++) Y7568[i] = 1055;};
}

long O7569[10];
void O7569_init () {
	{long i; for (i = 0; i < 3; i++) O7569[i] =  + _REFACS_4_;}
	{long i; for (i = 3; i < 6; i++) O7569[i] =  + _REFACS_6_;}
	{long i; for (i = 6; i < 8; i++) O7569[i] =  + _REFACS_4_;}
	{long i; for (i = 8; i < 10; i++) O7569[i] =  + _REFACS_6_;}
}

long O7570[10];
void O7570_init () {
	{long i; for (i = 0; i < 3; i++) O7570[i] =  + _REFACS_5_;}
	{long i; for (i = 3; i < 6; i++) O7570[i] =  + _REFACS_7_;}
	{long i; for (i = 6; i < 8; i++) O7570[i] =  + _REFACS_5_;}
	{long i; for (i = 8; i < 10; i++) O7570[i] =  + _REFACS_7_;}
}

static EIF_TYPE_INDEX Y7570_pgtype0[] = {0xFF01,1278,0xFFFF};
static EIF_TYPE_INDEX Y7570_pgtype1[] = {0xFF01,1278,0xFFFF};
static EIF_TYPE_INDEX Y7570_pgtype2[] = {0xFF01,1278,0xFFFF};
static EIF_TYPE_INDEX Y7570_pgtype3[] = {0xFF01,1280,0xFFFF};
static EIF_TYPE_INDEX Y7570_pgtype4[] = {0xFF01,1280,0xFFFF};
static EIF_TYPE_INDEX Y7570_pgtype5[] = {0xFF01,1280,0xFFFF};
static EIF_TYPE_INDEX Y7570_pgtype6[] = {0xFF01,1278,0xFFFF};
static EIF_TYPE_INDEX Y7570_pgtype7[] = {0xFF01,1279,0xFFFF};
static EIF_TYPE_INDEX Y7570_pgtype8[] = {0xFF01,1278,0xFFFF};
static EIF_TYPE_INDEX Y7570_pgtype9[] = {0xFF01,1278,0xFFFF};
EIF_TYPE_INDEX *Y7570_gen_type [10];
EIF_TYPE_INDEX Y7570 [10];
void Y7570_init (void)
{
	egc_routines_types [7570] = Y7570;
	egc_routines_gen_types [7570] = Y7570_gen_type;
	egc_routines_offset [7570] = 1120;
	Y7570_gen_type [0] = Y7570_pgtype0;
	Y7570_gen_type [1] = Y7570_pgtype1;
	Y7570_gen_type [2] = Y7570_pgtype2;
	Y7570_gen_type [3] = Y7570_pgtype3;
	Y7570_gen_type [4] = Y7570_pgtype4;
	Y7570_gen_type [5] = Y7570_pgtype5;
	Y7570_gen_type [6] = Y7570_pgtype6;
	Y7570_gen_type [7] = Y7570_pgtype7;
	Y7570_gen_type [8] = Y7570_pgtype8;
	Y7570_gen_type [9] = Y7570_pgtype9;
	{long i; for (i = 0; i < 3; i++) Y7570[i] = 1278;};
	{long i; for (i = 3; i < 6; i++) Y7570[i] = 1280;};
	Y7570[6] = 1278;
	Y7570[7] = 1279;
	{long i; for (i = 8; i < 10; i++) Y7570[i] = 1278;};
}

long O7572[10];
void O7572_init () {
	{long i; for (i = 0; i < 3; i++) O7572[i] =  + _REFACS_6_;}
	{long i; for (i = 3; i < 6; i++) O7572[i] =  + _REFACS_8_;}
	{long i; for (i = 6; i < 8; i++) O7572[i] =  + _REFACS_6_;}
	{long i; for (i = 8; i < 10; i++) O7572[i] =  + _REFACS_8_;}
}

long O7574[10];
void O7574_init () {
	{long i; for (i = 0; i < 3; i++) O7574[i] =  + _REFACS_8_;}
	{long i; for (i = 3; i < 6; i++) O7574[i] =  + _REFACS_10_;}
	{long i; for (i = 6; i < 8; i++) O7574[i] =  + _REFACS_8_;}
	{long i; for (i = 8; i < 10; i++) O7574[i] =  + _REFACS_10_;}
}

long O7605[10];
void O7605_init () {
	{long i; for (i = 0; i < 2; i++) O7605[i] = + _CHROFF_16_1_;}
	O7605[2] = + _CHROFF_18_1_;
	{long i; for (i = 3; i < 5; i++) O7605[i] = + _CHROFF_27_1_;}
	O7605[5] = + _CHROFF_29_1_;
	O7605[6] = + _CHROFF_18_1_;
	O7605[7] = + _CHROFF_23_1_;
	O7605[8] = + _CHROFF_21_1_;
	O7605[9] = + _CHROFF_22_1_;
}

long O7606[10];
void O7606_init () {
	{long i; for (i = 0; i < 3; i++) O7606[i] =  + _REFACS_9_;}
	{long i; for (i = 3; i < 6; i++) O7606[i] =  + _REFACS_11_;}
	{long i; for (i = 6; i < 8; i++) O7606[i] =  + _REFACS_9_;}
	{long i; for (i = 8; i < 10; i++) O7606[i] =  + _REFACS_11_;}
}

long O7608[10];
void O7608_init () {
	{long i; for (i = 0; i < 3; i++) O7608[i] =  + _REFACS_11_;}
	{long i; for (i = 3; i < 6; i++) O7608[i] =  + _REFACS_13_;}
	{long i; for (i = 6; i < 8; i++) O7608[i] =  + _REFACS_11_;}
	{long i; for (i = 8; i < 10; i++) O7608[i] =  + _REFACS_13_;}
}

long O7616[10];
void O7616_init () {
	{long i; for (i = 0; i < 2; i++) O7616[i] = + _LNGOFF_16_3_0_0_;}
	O7616[2] = + _LNGOFF_18_3_0_0_;
	{long i; for (i = 3; i < 5; i++) O7616[i] = + _LNGOFF_27_5_0_0_;}
	O7616[5] = + _LNGOFF_29_5_0_0_;
	O7616[6] = + _LNGOFF_18_3_0_0_;
	O7616[7] = + _LNGOFF_23_4_0_0_;
	O7616[8] = + _LNGOFF_21_4_0_0_;
	O7616[9] = + _LNGOFF_22_4_0_0_;
}

long O7617[10];
void O7617_init () {
	{long i; for (i = 0; i < 3; i++) O7617[i] =  + _REFACS_14_;}
	{long i; for (i = 3; i < 6; i++) O7617[i] =  + _REFACS_16_;}
	{long i; for (i = 6; i < 8; i++) O7617[i] =  + _REFACS_14_;}
	{long i; for (i = 8; i < 10; i++) O7617[i] =  + _REFACS_16_;}
}

long O7619[10];
void O7619_init () {
	{long i; for (i = 0; i < 2; i++) O7619[i] = + _CHROFF_16_2_;}
	O7619[2] = + _CHROFF_18_2_;
	{long i; for (i = 3; i < 5; i++) O7619[i] = + _CHROFF_27_2_;}
	O7619[5] = + _CHROFF_29_2_;
	O7619[6] = + _CHROFF_18_2_;
	O7619[7] = + _CHROFF_23_2_;
	O7619[8] = + _CHROFF_21_2_;
	O7619[9] = + _CHROFF_22_2_;
}

long O7624[3];
void O7624_init () {
	{long i; for (i = 0; i < 2; i++) O7624[i] = + _CHROFF_27_3_;}
	O7624[2] = + _CHROFF_29_3_;
}

long O7625[3];
void O7625_init () {
	{long i; for (i = 0; i < 2; i++) O7625[i] = + _CHROFF_27_4_;}
	O7625[2] = + _CHROFF_29_4_;
}

static EIF_TYPE_INDEX Y7627_pgtype0[] = {922,0xFF01,1123,0xFFFF};
static EIF_TYPE_INDEX Y7627_pgtype1[] = {922,0xFF01,1124,0xFFFF};
static EIF_TYPE_INDEX Y7627_pgtype2[] = {922,0xFF01,1125,0xFFFF};
EIF_TYPE_INDEX *Y7627_gen_type [3];
EIF_TYPE_INDEX Y7627 [3];
void Y7627_init (void)
{
	egc_routines_types [7627] = Y7627;
	egc_routines_gen_types [7627] = Y7627_gen_type;
	egc_routines_offset [7627] = 1123;
	Y7627_gen_type [0] = Y7627_pgtype0;
	Y7627_gen_type [1] = Y7627_pgtype1;
	Y7627_gen_type [2] = Y7627_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y7627[i] = 922;};
}

long O7659[4];
void O7659_init () {
	{long i; for (i = 0; i < 2; i++) O7659[i] =  + _REFACS_16_;}
	{long i; for (i = 2; i < 4; i++) O7659[i] =  + _REFACS_18_;}
}

long O7660[4];
void O7660_init () {
	{long i; for (i = 0; i < 2; i++) O7660[i] =  + _REFACS_17_;}
	{long i; for (i = 2; i < 4; i++) O7660[i] =  + _REFACS_19_;}
}

long O7676[2];
void O7676_init () {
	O7676[0] = + _CHROFF_21_3_;
	O7676[1] = + _CHROFF_22_3_;
}

long O8396[3];
void O8396_init () {
	O8396[0] = 0;
	{long i; for (i = 1; i < 3; i++) O8396[i] = + _LNGOFF_3_1_0_0_;}
}

long O8398[3];
void O8398_init () {
	O8398[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O8398[i] = 0;}
}

long O8410[3];
void O8410_init () {
	O8410[0] = + _LNGOFF_4_1_0_0_;
	{long i; for (i = 1; i < 3; i++) O8410[i] = + _LNGOFF_3_1_0_1_;}
}

long O8413[3];
void O8413_init () {
	O8413[0] = + _LNGOFF_4_1_0_1_;
	{long i; for (i = 1; i < 3; i++) O8413[i] = + _LNGOFF_3_1_0_2_;}
}

long O8420[3];
void O8420_init () {
	O8420[0] = + _LNGOFF_4_1_0_2_;
	{long i; for (i = 1; i < 3; i++) O8420[i] = + _LNGOFF_3_1_0_3_;}
}

long O8427[3];
void O8427_init () {
	O8427[0] = + _CHROFF_4_0_;
	{long i; for (i = 1; i < 3; i++) O8427[i] = + _CHROFF_3_0_;}
}

long O8428[3];
void O8428_init () {
	O8428[0] = + _LNGOFF_4_1_0_3_;
	{long i; for (i = 1; i < 3; i++) O8428[i] = + _LNGOFF_3_1_0_4_;}
}

long O8429[3];
void O8429_init () {
	O8429[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 3; i++) O8429[i] =  + _REFACS_1_;}
}

long O8430[3];
void O8430_init () {
	O8430[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 3; i++) O8430[i] =  + _REFACS_2_;}
}

long O8439[3];
void O8439_init () {
	O8439[0] = + _LNGOFF_4_1_0_4_;
	{long i; for (i = 1; i < 3; i++) O8439[i] = + _LNGOFF_3_1_0_5_;}
}

long O8877[3];
void O8877_init () {
	O8877[0] = + _CHROFF_2_1_;
	O8877[1] = + _CHROFF_5_1_;
	O8877[2] = + _CHROFF_16_1_;
}

long O8879[3];
void O8879_init () {
	{long i; for (i = 0; i < 2; i++) O8879[i] = 0;}
	O8879[2] =  + _REFACS_1_;
}

long O8880[3];
void O8880_init () {
	{long i; for (i = 0; i < 2; i++) O8880[i] =  + _REFACS_1_;}
	O8880[2] =  + _REFACS_2_;
}

long O8882[3];
void O8882_init () {
	O8882[0] = + _LNGOFF_2_2_0_0_;
	O8882[1] = + _LNGOFF_5_2_0_0_;
	O8882[2] = + _LNGOFF_16_4_0_1_;
}

long O8945[56];
void O8945_init () {
	{long i; for (i = 0; i < 2; i++) O8945[i] = 0;}
	O8945[2] =  + _REFACS_1_;
	{long i; for (i = 3; i < 5; i++) O8945[i] = 0;}
	O8945[5] =  + _REFACS_1_;
	{long i; for (i = 6; i < 8; i++) O8945[i] = 0;}
	O8945[55] = 0;
}

long O8946[56];
void O8946_init () {
	{long i; for (i = 0; i < 2; i++) O8946[i] =  + _REFACS_1_;}
	O8946[2] =  + _REFACS_2_;
	{long i; for (i = 3; i < 5; i++) O8946[i] =  + _REFACS_1_;}
	O8946[5] =  + _REFACS_2_;
	{long i; for (i = 6; i < 8; i++) O8946[i] =  + _REFACS_1_;}
	O8946[55] =  + _REFACS_1_;
}

long O10280[3];
void O10280_init () {
	{long i; for (i = 0; i < 2; i++) O10280[i] = + _CHROFF_6_0_;}
	O10280[2] = + _CHROFF_7_0_;
}

long O10281[3];
void O10281_init () {
	{long i; for (i = 0; i < 2; i++) O10281[i] = + _CHROFF_6_1_;}
	O10281[2] = + _CHROFF_7_1_;
}

long O10291[3];
void O10291_init () {
	{long i; for (i = 0; i < 2; i++) O10291[i] = + _LNGOFF_6_2_0_0_;}
	O10291[2] = + _LNGOFF_7_3_0_0_;
}


#ifdef __cplusplus
}
#endif
