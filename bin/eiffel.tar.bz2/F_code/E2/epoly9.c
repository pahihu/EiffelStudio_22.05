#include "epoly9.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R6814[257])();
void R6814_init () {
	R6814[0] = (char *(*)()) F1054_8205;
	R6814[4] = (char *(*)()) F1058_8373;
	R6814[256] = (char *(*)()) F1310_13127;
}

char *(*R6815[257])();
void R6815_init () {
	R6815[0] = (char *(*)()) F1051_8074;
	R6815[4] = (char *(*)()) F1051_8074;
	R6815[256] = (char *(*)()) F1310_13128;
}

char *(*R6826[257])();
void R6826_init () {
	R6826[0] = (char *(*)()) F1054_8216;
	R6826[4] = (char *(*)()) F1058_8384;
	R6826[256] = (char *(*)()) F1310_13050;
}

char *(*R6834[257])();
void R6834_init () {
	R6834[0] = (char *(*)()) F1054_8199;
	R6834[4] = (char *(*)()) F1058_8367;
	R6834[256] = (char *(*)()) F1310_13074;
}

char *(*R6835[257])();
void R6835_init () {
	R6835[0] = (char *(*)()) F1054_8200;
	R6835[4] = (char *(*)()) F1058_8368;
	R6835[256] = (char *(*)()) F1310_13075;
}

char *(*R6836[257])();
void R6836_init () {
	R6836[0] = (char *(*)()) F1054_8201;
	R6836[4] = (char *(*)()) F1058_8369;
	R6836[256] = (char *(*)()) F1310_13123;
}

char *(*R6837[257])();
void R6837_init () {
	R6837[0] = (char *(*)()) F1054_8202;
	R6837[4] = (char *(*)()) F1058_8370;
	R6837[256] = (char *(*)()) F1310_13124;
}

char *(*R6840[257])();
void R6840_init () {
	R6840[0] = (char *(*)()) F1054_8239;
	R6840[4] = (char *(*)()) F1058_8407;
	R6840[256] = (char *(*)()) F1310_13076;
}

char *(*R6842[257])();
void R6842_init () {
	R6842[0] = (char *(*)()) F1054_8241;
	R6842[4] = (char *(*)()) F1058_8409;
	R6842[256] = (char *(*)()) F1310_13077;
}

char *(*R6843[257])();
void R6843_init () {
	R6843[0] = (char *(*)()) F1054_8246;
	R6843[4] = (char *(*)()) F1058_8414;
	R6843[256] = (char *(*)()) F1310_13121;
}

char *(*R6844[257])();
void R6844_init () {
	R6844[0] = (char *(*)()) F1054_8249;
	R6844[4] = (char *(*)()) F1058_8417;
	R6844[256] = (char *(*)()) F1054_8249;
}

char *(*R6854[257])();
void R6854_init () {
	R6854[0] = (char *(*)()) F1054_8187;
	R6854[256] = (char *(*)()) F1310_13011;
}

char *(*R6856[258])();
void R6856_init () {
	{long i; for (i = 0; i < 2; i++) R6856[i] = (char *(*)()) F1052_8117;}
	R6856[257] = (char *(*)()) F1310_13022;
}

char *(*R6858[258])();
void R6858_init () {
	{long i; for (i = 0; i < 2; i++) R6858[i] = (char *(*)()) F1052_8120;}
	R6858[257] = (char *(*)()) F1310_13017;
}

char *(*R6863[258])();
void R6863_init () {
	{long i; for (i = 0; i < 2; i++) R6863[i] = (char *(*)()) F1052_8132;}
	R6863[257] = (char *(*)()) F1310_13040;
}

char *(*R6868[258])();
void R6868_init () {
	R6868[0] = (char *(*)()) F1053_8166;
	R6868[1] = (char *(*)()) F1054_8236;
	R6868[257] = (char *(*)()) F1310_13018;
}

char *(*R6876[258])();
void R6876_init () {
	R6876[0] = (char *(*)()) F1053_8177;
	R6876[1] = (char *(*)()) F1052_8156;
	R6876[257] = (char *(*)()) F1052_8156;
}

char *(*R6891[257])();
void R6891_init () {
	R6891[0] = (char *(*)()) F1054_8194;
	R6891[256] = (char *(*)()) F1310_13073;
}

char *(*R6899[257])();
void R6899_init () {
	R6899[0] = (char *(*)()) F1054_8209;
	R6899[256] = (char *(*)()) F1310_13048;
}

char *(*R6902[257])();
void R6902_init () {
	R6902[0] = (char *(*)()) F1054_8217;
	R6902[256] = (char *(*)()) F1310_13056;
}

char *(*R6904[257])();
void R6904_init () {
	R6904[0] = (char *(*)()) F1054_8219;
	R6904[256] = (char *(*)()) F1310_13054;
}

char *(*R6906[257])();
void R6906_init () {
	R6906[0] = (char *(*)()) F1054_8230;
	R6906[256] = (char *(*)()) F1310_13053;
}

char *(*R6908[257])();
void R6908_init () {
	R6908[0] = (char *(*)()) F1054_8234;
	R6908[256] = (char *(*)()) F1310_13070;
}

char *(*R6918[257])();
void R6918_init () {
	R6918[0] = (char *(*)()) F1054_8258;
	R6918[256] = (char *(*)()) F1310_13087;
}

char *(*R6919[257])();
void R6919_init () {
	R6919[0] = (char *(*)()) F1054_8259;
	R6919[256] = (char *(*)()) F1310_13088;
}

char *(*R6943[2])();
void R6943_init () {
	R6943[0] = (char *(*)()) F1057_8333;
	R6943[1] = (char *(*)()) F1058_8404;
}

char *(*R6951[2])();
void R6951_init () {
	R6951[0] = (char *(*)()) F1057_8344;
	R6951[1] = (char *(*)()) F1056_8321;
}

char *(*R7484[34])();
void R7484_init () {
	R7484[0] = (char *(*)()) F1074_8973;
	R7484[1] = (char *(*)()) F1075_8973;
	R7484[2] = (char *(*)()) F1076_8973;
	R7484[3] = (char *(*)()) F1077_8973;
	R7484[4] = (char *(*)()) F1078_8973;
	R7484[5] = (char *(*)()) F1079_8973;
	R7484[6] = (char *(*)()) F1080_8973;
	R7484[7] = (char *(*)()) F1081_8973;
	R7484[8] = (char *(*)()) F1082_8973;
	R7484[9] = (char *(*)()) F1083_8973;
	R7484[10] = (char *(*)()) F1084_8973;
	R7484[11] = (char *(*)()) F1085_8973;
	R7484[12] = (char *(*)()) F1086_8973;
	R7484[13] = (char *(*)()) F1087_8973;
	R7484[14] = (char *(*)()) F1088_8973;
	R7484[15] = (char *(*)()) F1089_8973;
	R7484[16] = (char *(*)()) F1090_8973;
	R7484[17] = (char *(*)()) F1091_8973;
	R7484[18] = (char *(*)()) F1092_8973;
	R7484[19] = (char *(*)()) F1093_8973;
	R7484[20] = (char *(*)()) F1094_8973;
	R7484[21] = (char *(*)()) F1095_8973;
	R7484[22] = (char *(*)()) F1096_8973;
	R7484[23] = (char *(*)()) F1097_8973;
	R7484[24] = (char *(*)()) F1098_8973;
	R7484[25] = (char *(*)()) F1099_8973;
	R7484[26] = (char *(*)()) F1100_8973;
	R7484[27] = (char *(*)()) F1101_8973;
	R7484[28] = (char *(*)()) F1102_8973;
	R7484[29] = (char *(*)()) F1103_8973;
	R7484[30] = (char *(*)()) F1104_8973;
	R7484[31] = (char *(*)()) F1105_8973;
	R7484[32] = (char *(*)()) F1106_8973;
	R7484[33] = (char *(*)()) F1107_8973;
}

char *(*R7485[34])();
void R7485_init () {
	R7485[0] = (char *(*)()) F1074_8974;
	R7485[1] = (char *(*)()) F1075_8974;
	R7485[2] = (char *(*)()) F1076_8974;
	R7485[3] = (char *(*)()) F1077_8974;
	R7485[4] = (char *(*)()) F1078_8974;
	R7485[5] = (char *(*)()) F1079_8974;
	R7485[6] = (char *(*)()) F1080_8974;
	R7485[7] = (char *(*)()) F1081_8974;
	R7485[8] = (char *(*)()) F1082_8974;
	R7485[9] = (char *(*)()) F1083_8974;
	R7485[10] = (char *(*)()) F1084_8974;
	R7485[11] = (char *(*)()) F1085_8974;
	R7485[12] = (char *(*)()) F1086_8974;
	R7485[13] = (char *(*)()) F1087_8974;
	R7485[14] = (char *(*)()) F1088_8974;
	R7485[15] = (char *(*)()) F1089_8974;
	R7485[16] = (char *(*)()) F1090_8974;
	R7485[17] = (char *(*)()) F1091_8974;
	R7485[18] = (char *(*)()) F1092_8974;
	R7485[19] = (char *(*)()) F1093_8974;
	R7485[20] = (char *(*)()) F1094_8974;
	R7485[21] = (char *(*)()) F1095_8974;
	R7485[22] = (char *(*)()) F1096_8974;
	R7485[23] = (char *(*)()) F1097_8974;
	R7485[24] = (char *(*)()) F1098_8974;
	R7485[25] = (char *(*)()) F1099_8974;
	R7485[26] = (char *(*)()) F1100_8974;
	R7485[27] = (char *(*)()) F1101_8974;
	R7485[28] = (char *(*)()) F1102_8974;
	R7485[29] = (char *(*)()) F1103_8974;
	R7485[30] = (char *(*)()) F1104_8974;
	R7485[31] = (char *(*)()) F1105_8974;
	R7485[32] = (char *(*)()) F1106_8974;
	R7485[33] = (char *(*)()) F1107_8974;
}

char *(*R7487[34])();
void R7487_init () {
	R7487[0] = (char *(*)()) F1074_8976;
	R7487[1] = (char *(*)()) F1075_8976;
	R7487[2] = (char *(*)()) F1076_8976;
	R7487[3] = (char *(*)()) F1077_8976;
	R7487[4] = (char *(*)()) F1078_8976;
	R7487[5] = (char *(*)()) F1079_8976;
	R7487[6] = (char *(*)()) F1080_8976;
	R7487[7] = (char *(*)()) F1081_8976;
	R7487[8] = (char *(*)()) F1082_8976;
	R7487[9] = (char *(*)()) F1083_8976;
	R7487[10] = (char *(*)()) F1084_8976;
	R7487[11] = (char *(*)()) F1085_8976;
	R7487[12] = (char *(*)()) F1086_8976;
	R7487[13] = (char *(*)()) F1087_8976;
	R7487[14] = (char *(*)()) F1088_8976;
	R7487[15] = (char *(*)()) F1089_8976;
	R7487[16] = (char *(*)()) F1090_8976;
	R7487[17] = (char *(*)()) F1091_8976;
	R7487[18] = (char *(*)()) F1092_8976;
	R7487[19] = (char *(*)()) F1093_8976;
	R7487[20] = (char *(*)()) F1094_8976;
	R7487[21] = (char *(*)()) F1095_8976;
	R7487[22] = (char *(*)()) F1096_8976;
	R7487[23] = (char *(*)()) F1097_8976;
	R7487[24] = (char *(*)()) F1098_8976;
	R7487[25] = (char *(*)()) F1099_8976;
	R7487[26] = (char *(*)()) F1100_8976;
	R7487[27] = (char *(*)()) F1101_8976;
	R7487[28] = (char *(*)()) F1102_8976;
	R7487[29] = (char *(*)()) F1103_8976;
	R7487[30] = (char *(*)()) F1104_8976;
	R7487[31] = (char *(*)()) F1105_8976;
	R7487[32] = (char *(*)()) F1106_8976;
	R7487[33] = (char *(*)()) F1107_8976;
}

char *(*R7492[34])();
void R7492_init () {
	R7492[0] = (char *(*)()) F1074_8982;
	R7492[1] = (char *(*)()) F1075_8982;
	R7492[2] = (char *(*)()) F1076_8982;
	R7492[3] = (char *(*)()) F1077_8982;
	R7492[4] = (char *(*)()) F1078_8982;
	R7492[5] = (char *(*)()) F1079_8982;
	R7492[6] = (char *(*)()) F1080_8982;
	R7492[7] = (char *(*)()) F1081_8982;
	R7492[8] = (char *(*)()) F1082_8982;
	R7492[9] = (char *(*)()) F1083_8982;
	R7492[10] = (char *(*)()) F1084_8982;
	R7492[11] = (char *(*)()) F1085_8982;
	R7492[12] = (char *(*)()) F1086_8982;
	R7492[13] = (char *(*)()) F1087_8982;
	R7492[14] = (char *(*)()) F1088_8982;
	R7492[15] = (char *(*)()) F1089_8982;
	R7492[16] = (char *(*)()) F1090_8982;
	R7492[17] = (char *(*)()) F1091_8982;
	R7492[18] = (char *(*)()) F1092_8982;
	R7492[19] = (char *(*)()) F1093_8982;
	R7492[20] = (char *(*)()) F1094_8982;
	R7492[21] = (char *(*)()) F1095_8982;
	R7492[22] = (char *(*)()) F1096_8982;
	R7492[23] = (char *(*)()) F1097_8982;
	R7492[24] = (char *(*)()) F1098_8982;
	R7492[25] = (char *(*)()) F1099_8982;
	R7492[26] = (char *(*)()) F1100_8982;
	R7492[27] = (char *(*)()) F1101_8982;
	R7492[28] = (char *(*)()) F1102_8982;
	R7492[29] = (char *(*)()) F1103_8982;
	R7492[30] = (char *(*)()) F1104_8982;
	R7492[31] = (char *(*)()) F1105_8982;
	R7492[32] = (char *(*)()) F1106_8982;
	R7492[33] = (char *(*)()) F1107_8982;
}

char *(*R7497[34])();
void R7497_init () {
	R7497[0] = (char *(*)()) F1074_8990;
	R7497[1] = (char *(*)()) F1075_8990_7497_1;
	R7497[2] = (char *(*)()) F1076_8990_7497_1;
	R7497[3] = (char *(*)()) F1077_8990_7497_1;
	R7497[4] = (char *(*)()) F1078_8990_7497_1;
	R7497[5] = (char *(*)()) F1079_8990_7497_1;
	R7497[6] = (char *(*)()) F1080_8990_7497_1;
	R7497[7] = (char *(*)()) F1081_8990_7497_1;
	R7497[8] = (char *(*)()) F1082_8990_7497_1;
	R7497[9] = (char *(*)()) F1083_8990_7497_1;
	R7497[10] = (char *(*)()) F1084_8990_7497_1;
	R7497[11] = (char *(*)()) F1085_8990_7497_1;
	R7497[12] = (char *(*)()) F1086_8990_7497_1;
	R7497[13] = (char *(*)()) F1087_8990_7497_1;
	R7497[14] = (char *(*)()) F1088_8990_7497_1;
	R7497[15] = (char *(*)()) F1089_8990_7497_1;
	R7497[16] = (char *(*)()) F1090_8990_7497_1;
	R7497[17] = (char *(*)()) F1091_8990_7497_1;
	R7497[18] = (char *(*)()) F1092_8990;
	R7497[19] = (char *(*)()) F1093_8990;
	R7497[20] = (char *(*)()) F1094_8990_7497_1;
	R7497[21] = (char *(*)()) F1095_8990_7497_1;
	R7497[22] = (char *(*)()) F1096_8990_7497_1;
	R7497[23] = (char *(*)()) F1097_8990_7497_1;
	R7497[24] = (char *(*)()) F1098_8990_7497_1;
	R7497[25] = (char *(*)()) F1099_8990_7497_1;
	R7497[26] = (char *(*)()) F1100_8990_7497_1;
	R7497[27] = (char *(*)()) F1101_8990_7497_1;
	R7497[28] = (char *(*)()) F1102_8990_7497_1;
	R7497[29] = (char *(*)()) F1103_8990_7497_1;
	R7497[30] = (char *(*)()) F1104_8990_7497_1;
	R7497[31] = (char *(*)()) F1105_8990;
	R7497[32] = (char *(*)()) F1106_8990;
	R7497[33] = (char *(*)()) F1107_8990_7497_1;
}
static EIF_REFERENCE F1075_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F1075_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1011,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1011, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1076_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F1076_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1013,1190,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1013, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1077_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1077_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1078_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F1078_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1015,1187,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1015, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1079_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1079_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1080_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1080_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1081_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1081_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1082_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1082_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1083_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1083_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1084_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1084_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1184, 0x00).id, 1184, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1085_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1085_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1196, 0x00).id, 1196, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1086_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1086_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1193, 0x00).id, 1193, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1087_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1087_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1088_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1088_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1187, 0x00).id, 1187, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1089_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1089_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1090_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1090_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1091_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1091_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1094_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F1094_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1017,1041,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1017, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1095_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F1095_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1019,1184,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1019, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1096_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F1096_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1021,1193,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1021, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1097_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F1097_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1023,1008,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1023, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1098_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F1098_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1025,1002,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1099_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F1099_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1027,1202,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1027, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1100_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F1100_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1029,1005,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1029, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1101_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F1101_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1031,1199,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1031, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1102_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F1102_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1033,1205,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1033, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1103_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F1103_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1035,1211,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1035, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1104_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F1104_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1037,1208,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1037, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1107_8990_7497_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F1107_8990(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1039,1196,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1039, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}

char *(*R7507[34])();
void R7507_init () {
	R7507[0] = (char *(*)()) F1074_9002;
	R7507[1] = (char *(*)()) F1075_9002;
	R7507[2] = (char *(*)()) F1076_9002;
	R7507[3] = (char *(*)()) F1077_9002;
	R7507[4] = (char *(*)()) F1078_9002;
	R7507[5] = (char *(*)()) F1079_9002;
	R7507[6] = (char *(*)()) F1080_9002;
	R7507[7] = (char *(*)()) F1081_9002;
	R7507[8] = (char *(*)()) F1082_9002;
	R7507[9] = (char *(*)()) F1083_9002;
	R7507[10] = (char *(*)()) F1084_9002;
	R7507[11] = (char *(*)()) F1085_9002;
	R7507[12] = (char *(*)()) F1086_9002;
	R7507[13] = (char *(*)()) F1087_9002;
	R7507[14] = (char *(*)()) F1088_9002;
	R7507[15] = (char *(*)()) F1089_9002;
	R7507[16] = (char *(*)()) F1090_9002;
	R7507[17] = (char *(*)()) F1091_9002;
	R7507[18] = (char *(*)()) F1092_9002;
	R7507[19] = (char *(*)()) F1093_9002;
	R7507[20] = (char *(*)()) F1094_9002;
	R7507[21] = (char *(*)()) F1095_9002;
	R7507[22] = (char *(*)()) F1096_9002;
	R7507[23] = (char *(*)()) F1097_9002;
	R7507[24] = (char *(*)()) F1098_9002;
	R7507[25] = (char *(*)()) F1099_9002;
	R7507[26] = (char *(*)()) F1100_9002;
	R7507[27] = (char *(*)()) F1101_9002;
	R7507[28] = (char *(*)()) F1102_9002;
	R7507[29] = (char *(*)()) F1103_9002;
	R7507[30] = (char *(*)()) F1104_9002;
	R7507[31] = (char *(*)()) F1105_9002;
	R7507[32] = (char *(*)()) F1106_9002;
	R7507[33] = (char *(*)()) F1107_9002;
}

char *(*R7509[12])();
void R7509_init () {
	R7509[0] = (char *(*)()) F1109_9020;
	R7509[1] = (char *(*)()) F1110_9020;
	R7509[2] = (char *(*)()) F1111_9020;
	R7509[3] = (char *(*)()) F1112_9020;
	R7509[4] = (char *(*)()) F1113_9020;
	R7509[5] = (char *(*)()) F1114_9020;
	R7509[6] = (char *(*)()) F1115_9020;
	R7509[7] = (char *(*)()) F1116_9020;
	R7509[8] = (char *(*)()) F1117_9020;
	R7509[9] = (char *(*)()) F1118_9020;
	R7509[10] = (char *(*)()) F1119_9020;
	R7509[11] = (char *(*)()) F1120_9020;
}

char *(*R7510[12])();
void R7510_init () {
	R7510[0] = (char *(*)()) F1109_9021;
	R7510[1] = (char *(*)()) F1110_9021;
	R7510[2] = (char *(*)()) F1111_9021;
	R7510[3] = (char *(*)()) F1112_9021;
	R7510[4] = (char *(*)()) F1113_9021;
	R7510[5] = (char *(*)()) F1114_9021;
	R7510[6] = (char *(*)()) F1115_9021;
	R7510[7] = (char *(*)()) F1116_9021;
	R7510[8] = (char *(*)()) F1117_9021;
	R7510[9] = (char *(*)()) F1118_9021;
	R7510[10] = (char *(*)()) F1119_9021;
	R7510[11] = (char *(*)()) F1120_9021;
}

char *(*R7512[12])();
void R7512_init () {
	R7512[0] = (char *(*)()) F1109_9007;
	R7512[1] = (char *(*)()) F1110_9007;
	R7512[2] = (char *(*)()) F1111_9007;
	R7512[3] = (char *(*)()) F1112_9007;
	R7512[4] = (char *(*)()) F1113_9007;
	R7512[5] = (char *(*)()) F1114_9007;
	R7512[6] = (char *(*)()) F1115_9007;
	R7512[7] = (char *(*)()) F1116_9007;
	R7512[8] = (char *(*)()) F1117_9007;
	R7512[9] = (char *(*)()) F1118_9007;
	R7512[10] = (char *(*)()) F1119_9007;
	R7512[11] = (char *(*)()) F1120_9007;
}

char *(*R7513[12])();
void R7513_init () {
	R7513[0] = (char *(*)()) F1109_9008;
	R7513[1] = (char *(*)()) F1110_9008_7513_147;
	R7513[2] = (char *(*)()) F1111_9008_7513_147;
	R7513[3] = (char *(*)()) F1112_9008_7513_147;
	R7513[4] = (char *(*)()) F1113_9008_7513_147;
	R7513[5] = (char *(*)()) F1114_9008_7513_147;
	R7513[6] = (char *(*)()) F1115_9008_7513_147;
	R7513[7] = (char *(*)()) F1116_9008_7513_147;
	R7513[8] = (char *(*)()) F1117_9008_7513_147;
	R7513[9] = (char *(*)()) F1118_9008_7513_147;
	R7513[10] = (char *(*)()) F1119_9008_7513_147;
	R7513[11] = (char *(*)()) F1120_9008_7513_147;
}
static void F1110_9008_7513_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1110_9008(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1111_9008_7513_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1111_9008(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1112_9008_7513_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1112_9008(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1113_9008_7513_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1113_9008(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1114_9008_7513_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1114_9008(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1115_9008_7513_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1115_9008(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1116_9008_7513_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1116_9008(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1117_9008_7513_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1117_9008(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1118_9008_7513_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1118_9008(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1119_9008_7513_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1119_9008(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1120_9008_7513_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1120_9008(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7522[12])();
void R7522_init () {
	R7522[0] = (char *(*)()) F1109_9023;
	R7522[1] = (char *(*)()) F1110_9023;
	R7522[2] = (char *(*)()) F1111_9023;
	R7522[3] = (char *(*)()) F1112_9023;
	R7522[4] = (char *(*)()) F1113_9023;
	R7522[5] = (char *(*)()) F1114_9023;
	R7522[6] = (char *(*)()) F1115_9023;
	R7522[7] = (char *(*)()) F1116_9023;
	R7522[8] = (char *(*)()) F1117_9023;
	R7522[9] = (char *(*)()) F1118_9023;
	R7522[10] = (char *(*)()) F1119_9023;
	R7522[11] = (char *(*)()) F1120_9023;
}

char *(*R7523[12])();
void R7523_init () {
	R7523[0] = (char *(*)()) F1109_9025;
	R7523[1] = (char *(*)()) F1110_9025_7523_147;
	R7523[2] = (char *(*)()) F1111_9025_7523_147;
	R7523[3] = (char *(*)()) F1112_9025_7523_147;
	R7523[4] = (char *(*)()) F1113_9025_7523_147;
	R7523[5] = (char *(*)()) F1114_9025_7523_147;
	R7523[6] = (char *(*)()) F1115_9025_7523_147;
	R7523[7] = (char *(*)()) F1116_9025_7523_147;
	R7523[8] = (char *(*)()) F1117_9025_7523_147;
	R7523[9] = (char *(*)()) F1118_9025_7523_147;
	R7523[10] = (char *(*)()) F1119_9025_7523_147;
	R7523[11] = (char *(*)()) F1120_9025_7523_147;
}
static void F1110_9025_7523_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1110_9025(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1111_9025_7523_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1111_9025(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1112_9025_7523_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1112_9025(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1113_9025_7523_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1113_9025(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1114_9025_7523_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1114_9025(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1115_9025_7523_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1115_9025(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1116_9025_7523_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1116_9025(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1117_9025_7523_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1117_9025(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1118_9025_7523_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1118_9025(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1119_9025_7523_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1119_9025(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1120_9025_7523_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1120_9025(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7524[12])();
void R7524_init () {
	R7524[0] = (char *(*)()) F1109_9026;
	R7524[1] = (char *(*)()) F1110_9026_7524_147;
	R7524[2] = (char *(*)()) F1111_9026_7524_147;
	R7524[3] = (char *(*)()) F1112_9026_7524_147;
	R7524[4] = (char *(*)()) F1113_9026_7524_147;
	R7524[5] = (char *(*)()) F1114_9026_7524_147;
	R7524[6] = (char *(*)()) F1115_9026_7524_147;
	R7524[7] = (char *(*)()) F1116_9026_7524_147;
	R7524[8] = (char *(*)()) F1117_9026_7524_147;
	R7524[9] = (char *(*)()) F1118_9026_7524_147;
	R7524[10] = (char *(*)()) F1119_9026_7524_147;
	R7524[11] = (char *(*)()) F1120_9026_7524_147;
}
static void F1110_9026_7524_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1110_9026(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1111_9026_7524_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1111_9026(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1112_9026_7524_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1112_9026(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1113_9026_7524_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1113_9026(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1114_9026_7524_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1114_9026(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1115_9026_7524_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1115_9026(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1116_9026_7524_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1116_9026(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1117_9026_7524_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1117_9026(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1118_9026_7524_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1118_9026(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1119_9026_7524_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1119_9026(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1120_9026_7524_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1120_9026(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7525[12])();
void R7525_init () {
	R7525[0] = (char *(*)()) F1109_9027;
	R7525[1] = (char *(*)()) F1110_9027_7525_4;
	R7525[2] = (char *(*)()) F1111_9027_7525_4;
	R7525[3] = (char *(*)()) F1112_9027_7525_4;
	R7525[4] = (char *(*)()) F1113_9027_7525_4;
	R7525[5] = (char *(*)()) F1114_9027_7525_4;
	R7525[6] = (char *(*)()) F1115_9027_7525_4;
	R7525[7] = (char *(*)()) F1116_9027_7525_4;
	R7525[8] = (char *(*)()) F1117_9027_7525_4;
	R7525[9] = (char *(*)()) F1118_9027_7525_4;
	R7525[10] = (char *(*)()) F1119_9027_7525_4;
	R7525[11] = (char *(*)()) F1120_9027_7525_4;
}
static void F1110_9027_7525_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1110_9027(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1111_9027_7525_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1111_9027(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1112_9027_7525_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1112_9027(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1113_9027_7525_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1113_9027(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F1114_9027_7525_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1114_9027(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1115_9027_7525_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1115_9027(Current, *(EIF_REAL_32 *)arg1);
}
static void F1116_9027_7525_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1116_9027(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F1117_9027_7525_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1117_9027(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1118_9027_7525_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1118_9027(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F1119_9027_7525_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1119_9027(Current, *(EIF_POINTER *)arg1);
}
static void F1120_9027_7525_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1120_9027(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R7527[12])();
void R7527_init () {
	R7527[0] = (char *(*)()) F1109_9029;
	R7527[1] = (char *(*)()) F1110_9029_7527_25;
	R7527[2] = (char *(*)()) F1111_9029_7527_25;
	R7527[3] = (char *(*)()) F1112_9029_7527_25;
	R7527[4] = (char *(*)()) F1113_9029_7527_25;
	R7527[5] = (char *(*)()) F1114_9029_7527_25;
	R7527[6] = (char *(*)()) F1115_9029_7527_25;
	R7527[7] = (char *(*)()) F1116_9029_7527_25;
	R7527[8] = (char *(*)()) F1117_9029_7527_25;
	R7527[9] = (char *(*)()) F1118_9029_7527_25;
	R7527[10] = (char *(*)()) F1119_9029_7527_25;
	R7527[11] = (char *(*)()) F1120_9029_7527_25;
}
static void F1110_9029_7527_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1110_9029(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F1111_9029_7527_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1111_9029(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F1112_9029_7527_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1112_9029(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F1113_9029_7527_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1113_9029(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F1114_9029_7527_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1114_9029(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F1115_9029_7527_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1115_9029(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F1116_9029_7527_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1116_9029(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F1117_9029_7527_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1117_9029(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F1118_9029_7527_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1118_9029(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F1119_9029_7527_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1119_9029(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F1120_9029_7527_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1120_9029(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R7528[12])();
void R7528_init () {
	R7528[0] = (char *(*)()) F1109_9030;
	R7528[1] = (char *(*)()) F1110_9030;
	R7528[2] = (char *(*)()) F1111_9030;
	R7528[3] = (char *(*)()) F1112_9030;
	R7528[4] = (char *(*)()) F1113_9030;
	R7528[5] = (char *(*)()) F1114_9030;
	R7528[6] = (char *(*)()) F1115_9030;
	R7528[7] = (char *(*)()) F1116_9030;
	R7528[8] = (char *(*)()) F1117_9030;
	R7528[9] = (char *(*)()) F1118_9030;
	R7528[10] = (char *(*)()) F1119_9030;
	R7528[11] = (char *(*)()) F1120_9030;
}

char *(*R7530[12])();
void R7530_init () {
	R7530[0] = (char *(*)()) F1109_9032;
	R7530[1] = (char *(*)()) F1110_9032;
	R7530[2] = (char *(*)()) F1111_9032;
	R7530[3] = (char *(*)()) F1112_9032;
	R7530[4] = (char *(*)()) F1113_9032;
	R7530[5] = (char *(*)()) F1114_9032;
	R7530[6] = (char *(*)()) F1115_9032;
	R7530[7] = (char *(*)()) F1116_9032;
	R7530[8] = (char *(*)()) F1117_9032;
	R7530[9] = (char *(*)()) F1118_9032;
	R7530[10] = (char *(*)()) F1119_9032;
	R7530[11] = (char *(*)()) F1120_9032;
}

char *(*R7531[12])();
void R7531_init () {
	R7531[0] = (char *(*)()) F1109_9033;
	R7531[1] = (char *(*)()) F1110_9033;
	R7531[2] = (char *(*)()) F1111_9033;
	R7531[3] = (char *(*)()) F1112_9033;
	R7531[4] = (char *(*)()) F1113_9033;
	R7531[5] = (char *(*)()) F1114_9033;
	R7531[6] = (char *(*)()) F1115_9033;
	R7531[7] = (char *(*)()) F1116_9033;
	R7531[8] = (char *(*)()) F1117_9033;
	R7531[9] = (char *(*)()) F1118_9033;
	R7531[10] = (char *(*)()) F1119_9033;
	R7531[11] = (char *(*)()) F1120_9033;
}

char *(*R7532[12])();
void R7532_init () {
	R7532[0] = (char *(*)()) F1109_9034;
	R7532[1] = (char *(*)()) F1110_9034;
	R7532[2] = (char *(*)()) F1111_9034;
	R7532[3] = (char *(*)()) F1112_9034;
	R7532[4] = (char *(*)()) F1113_9034;
	R7532[5] = (char *(*)()) F1114_9034;
	R7532[6] = (char *(*)()) F1115_9034;
	R7532[7] = (char *(*)()) F1116_9034;
	R7532[8] = (char *(*)()) F1117_9034;
	R7532[9] = (char *(*)()) F1118_9034;
	R7532[10] = (char *(*)()) F1119_9034;
	R7532[11] = (char *(*)()) F1120_9034;
}

char *(*R7533[12])();
void R7533_init () {
	R7533[0] = (char *(*)()) F1109_9035;
	R7533[1] = (char *(*)()) F1110_9035;
	R7533[2] = (char *(*)()) F1111_9035;
	R7533[3] = (char *(*)()) F1112_9035;
	R7533[4] = (char *(*)()) F1113_9035;
	R7533[5] = (char *(*)()) F1114_9035;
	R7533[6] = (char *(*)()) F1115_9035;
	R7533[7] = (char *(*)()) F1116_9035;
	R7533[8] = (char *(*)()) F1117_9035;
	R7533[9] = (char *(*)()) F1118_9035;
	R7533[10] = (char *(*)()) F1119_9035;
	R7533[11] = (char *(*)()) F1120_9035;
}

char *(*R7534[12])();
void R7534_init () {
	R7534[0] = (char *(*)()) F1109_9036;
	R7534[1] = (char *(*)()) F1110_9036;
	R7534[2] = (char *(*)()) F1111_9036;
	R7534[3] = (char *(*)()) F1112_9036;
	R7534[4] = (char *(*)()) F1113_9036;
	R7534[5] = (char *(*)()) F1114_9036;
	R7534[6] = (char *(*)()) F1115_9036;
	R7534[7] = (char *(*)()) F1116_9036;
	R7534[8] = (char *(*)()) F1117_9036;
	R7534[9] = (char *(*)()) F1118_9036;
	R7534[10] = (char *(*)()) F1119_9036;
	R7534[11] = (char *(*)()) F1120_9036;
}

char *(*R7537[12])();
void R7537_init () {
	R7537[0] = (char *(*)()) F1109_9039;
	R7537[1] = (char *(*)()) F1110_9039;
	R7537[2] = (char *(*)()) F1111_9039;
	R7537[3] = (char *(*)()) F1112_9039;
	R7537[4] = (char *(*)()) F1113_9039;
	R7537[5] = (char *(*)()) F1114_9039;
	R7537[6] = (char *(*)()) F1115_9039;
	R7537[7] = (char *(*)()) F1116_9039;
	R7537[8] = (char *(*)()) F1117_9039;
	R7537[9] = (char *(*)()) F1118_9039;
	R7537[10] = (char *(*)()) F1119_9039;
	R7537[11] = (char *(*)()) F1120_9039;
}

char *(*R7540[12])();
void R7540_init () {
	R7540[0] = (char *(*)()) F1109_9042;
	R7540[1] = (char *(*)()) F1110_9042;
	R7540[2] = (char *(*)()) F1111_9042;
	R7540[3] = (char *(*)()) F1112_9042;
	R7540[4] = (char *(*)()) F1113_9042;
	R7540[5] = (char *(*)()) F1114_9042;
	R7540[6] = (char *(*)()) F1115_9042;
	R7540[7] = (char *(*)()) F1116_9042;
	R7540[8] = (char *(*)()) F1117_9042;
	R7540[9] = (char *(*)()) F1118_9042;
	R7540[10] = (char *(*)()) F1119_9042;
	R7540[11] = (char *(*)()) F1120_9042;
}

char *(*R7541[12])();
void R7541_init () {
	R7541[0] = (char *(*)()) F1109_9043;
	R7541[1] = (char *(*)()) F1110_9043_7541_8;
	R7541[2] = (char *(*)()) F1111_9043_7541_8;
	R7541[3] = (char *(*)()) F1112_9043_7541_8;
	R7541[4] = (char *(*)()) F1113_9043_7541_8;
	R7541[5] = (char *(*)()) F1114_9043_7541_8;
	R7541[6] = (char *(*)()) F1115_9043_7541_8;
	R7541[7] = (char *(*)()) F1116_9043_7541_8;
	R7541[8] = (char *(*)()) F1117_9043_7541_8;
	R7541[9] = (char *(*)()) F1118_9043_7541_8;
	R7541[10] = (char *(*)()) F1119_9043_7541_8;
	R7541[11] = (char *(*)()) F1120_9043_7541_8;
}
static EIF_REFERENCE F1110_9043_7541_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1110_9043(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F1111_9043_7541_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1111_9043(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F1112_9043_7541_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1112_9043(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F1113_9043_7541_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1113_9043(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F1114_9043_7541_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1114_9043(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F1115_9043_7541_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1115_9043(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F1116_9043_7541_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1116_9043(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F1117_9043_7541_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1117_9043(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F1118_9043_7541_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1118_9043(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F1119_9043_7541_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1119_9043(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F1120_9043_7541_8 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1120_9043(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7543[12])();
void R7543_init () {
	R7543[0] = (char *(*)()) F1109_9045;
	R7543[1] = (char *(*)()) F1110_9045;
	R7543[2] = (char *(*)()) F1111_9045;
	R7543[3] = (char *(*)()) F1112_9045;
	R7543[4] = (char *(*)()) F1113_9045;
	R7543[5] = (char *(*)()) F1114_9045;
	R7543[6] = (char *(*)()) F1115_9045;
	R7543[7] = (char *(*)()) F1116_9045;
	R7543[8] = (char *(*)()) F1117_9045;
	R7543[9] = (char *(*)()) F1118_9045;
	R7543[10] = (char *(*)()) F1119_9045;
	R7543[11] = (char *(*)()) F1120_9045;
}

char *(*R7545[12])();
void R7545_init () {
	R7545[0] = (char *(*)()) F1109_9047;
	R7545[1] = (char *(*)()) F1110_9047;
	R7545[2] = (char *(*)()) F1111_9047;
	R7545[3] = (char *(*)()) F1112_9047;
	R7545[4] = (char *(*)()) F1113_9047;
	R7545[5] = (char *(*)()) F1114_9047;
	R7545[6] = (char *(*)()) F1115_9047;
	R7545[7] = (char *(*)()) F1116_9047;
	R7545[8] = (char *(*)()) F1117_9047;
	R7545[9] = (char *(*)()) F1118_9047;
	R7545[10] = (char *(*)()) F1119_9047;
	R7545[11] = (char *(*)()) F1120_9047;
}

char *(*R7552[12])();
void R7552_init () {
	R7552[0] = (char *(*)()) F1109_9055;
	R7552[1] = (char *(*)()) F1110_9055;
	R7552[2] = (char *(*)()) F1111_9055;
	R7552[3] = (char *(*)()) F1112_9055;
	R7552[4] = (char *(*)()) F1113_9055;
	R7552[5] = (char *(*)()) F1114_9055;
	R7552[6] = (char *(*)()) F1115_9055;
	R7552[7] = (char *(*)()) F1116_9055;
	R7552[8] = (char *(*)()) F1117_9055;
	R7552[9] = (char *(*)()) F1118_9055;
	R7552[10] = (char *(*)()) F1119_9055;
	R7552[11] = (char *(*)()) F1120_9055;
}

char *(*R7556[7])();
void R7556_init () {
	{long i; for (i = 0; i < 3; i++) R7556[i] = (char *(*)()) F1121_9059;}
	R7556[4] = (char *(*)()) F1128_9195;
	{long i; for (i = 5; i < 7; i++) R7556[i] = (char *(*)()) F1121_9059;}
}

char *(*R7559[7])();
void R7559_init () {
	{long i; for (i = 0; i < 3; i++) R7559[i] = (char *(*)()) F1121_9062;}
	{long i; for (i = 4; i < 6; i++) R7559[i] = (char *(*)()) F1121_9062;}
	R7559[6] = (char *(*)()) F1130_9241;
}

char *(*R7564[7])();
void R7564_init () {
	{long i; for (i = 0; i < 2; i++) R7564[i] = (char *(*)()) F1121_9067;}
	R7564[2] = (char *(*)()) F1126_9179;
	{long i; for (i = 4; i < 7; i++) R7564[i] = (char *(*)()) F1121_9067;}
}

char *(*R7583[7])();
void R7583_init () {
	{long i; for (i = 0; i < 3; i++) R7583[i] = (char *(*)()) F1124_9149;}
	R7583[4] = (char *(*)()) F1128_9208;
	{long i; for (i = 5; i < 7; i++) R7583[i] = (char *(*)()) F1129_9229;}
}

char *(*R7584[7])();
void R7584_init () {
	{long i; for (i = 0; i < 3; i++) R7584[i] = (char *(*)()) F1124_9150;}
	R7584[4] = (char *(*)()) F1128_9209;
	{long i; for (i = 5; i < 7; i++) R7584[i] = (char *(*)()) F1121_9088;}
}

char *(*R7730[37])();
void R7730_init () {
	R7730[0] = (char *(*)()) F1178_9323;
	R7730[1] = (char *(*)()) F1179_9328;
	R7730[2] = (char *(*)()) F1180_9342;
	R7730[3] = (char *(*)()) F1181_9372;
	R7730[35] = (char *(*)()) F1213_10309;
	R7730[36] = (char *(*)()) F1214_10352;
}

char *(*R7811[2])();
void R7811_init () {
	R7811[0] = (char *(*)()) F1184_9480;
	R7811[1] = (char *(*)()) F1185_9480;
}

char *(*R7860[2])();
void R7860_init () {
	R7860[0] = (char *(*)()) F1187_9574;
	R7860[1] = (char *(*)()) F1188_9574;
}

char *(*R7861[2])();
void R7861_init () {
	R7861[0] = (char *(*)()) F1187_9575;
	R7861[1] = (char *(*)()) F1188_9575;
}

char *(*R7864[2])();
void R7864_init () {
	R7864[0] = (char *(*)()) F1187_9578;
	R7864[1] = (char *(*)()) F1188_9578;
}

char *(*R7914[2])();
void R7914_init () {
	R7914[0] = (char *(*)()) F1190_9671;
	R7914[1] = (char *(*)()) F1191_9671;
}

char *(*R7916[2])();
void R7916_init () {
	R7916[0] = (char *(*)()) F1190_9673;
	R7916[1] = (char *(*)()) F1191_9673;
}

char *(*R7917[2])();
void R7917_init () {
	R7917[0] = (char *(*)()) F1190_9674;
	R7917[1] = (char *(*)()) F1191_9674;
}

char *(*R7921[2])();
void R7921_init () {
	R7921[0] = (char *(*)()) F1190_9678;
	R7921[1] = (char *(*)()) F1191_9678;
}

char *(*R7973[2])();
void R7973_init () {
	R7973[0] = (char *(*)()) F1193_9773;
	R7973[1] = (char *(*)()) F1194_9773;
}

char *(*R7976[2])();
void R7976_init () {
	R7976[0] = (char *(*)()) F1193_9776;
	R7976[1] = (char *(*)()) F1194_9776;
}

char *(*R8026[2])();
void R8026_init () {
	R8026[0] = (char *(*)()) F1196_9869;
	R8026[1] = (char *(*)()) F1197_9869;
}

char *(*R8029[2])();
void R8029_init () {
	R8029[0] = (char *(*)()) F1196_9872;
	R8029[1] = (char *(*)()) F1197_9872;
}

char *(*R8032[2])();
void R8032_init () {
	R8032[0] = (char *(*)()) F1196_9875;
	R8032[1] = (char *(*)()) F1197_9875;
}

char *(*R8080[2])();
void R8080_init () {
	R8080[0] = (char *(*)()) F1199_9963;
	R8080[1] = (char *(*)()) F1200_9963;
}

char *(*R8081[2])();
void R8081_init () {
	R8081[0] = (char *(*)()) F1199_9964;
	R8081[1] = (char *(*)()) F1200_9964;
}

char *(*R8083[2])();
void R8083_init () {
	R8083[0] = (char *(*)()) F1199_9966;
	R8083[1] = (char *(*)()) F1200_9966;
}

char *(*R8086[2])();
void R8086_init () {
	R8086[0] = (char *(*)()) F1199_9969;
	R8086[1] = (char *(*)()) F1200_9969;
}

char *(*R8087[2])();
void R8087_init () {
	R8087[0] = (char *(*)()) F1199_9970;
	R8087[1] = (char *(*)()) F1200_9970;
}

char *(*R8135[2])();
void R8135_init () {
	R8135[0] = (char *(*)()) F1202_10060;
	R8135[1] = (char *(*)()) F1203_10060;
}

char *(*R8136[2])();
void R8136_init () {
	R8136[0] = (char *(*)()) F1202_10061;
	R8136[1] = (char *(*)()) F1203_10061;
}

char *(*R8139[2])();
void R8139_init () {
	R8139[0] = (char *(*)()) F1202_10064;
	R8139[1] = (char *(*)()) F1203_10064;
}

char *(*R8187[2])();
void R8187_init () {
	R8187[0] = (char *(*)()) F1205_10154;
	R8187[1] = (char *(*)()) F1206_10154;
}

char *(*R8188[2])();
void R8188_init () {
	R8188[0] = (char *(*)()) F1205_10155;
	R8188[1] = (char *(*)()) F1206_10155;
}

char *(*R8189[2])();
void R8189_init () {
	R8189[0] = (char *(*)()) F1205_10156;
	R8189[1] = (char *(*)()) F1206_10156;
}

char *(*R8190[2])();
void R8190_init () {
	R8190[0] = (char *(*)()) F1205_10157;
	R8190[1] = (char *(*)()) F1206_10157;
}

char *(*R8192[2])();
void R8192_init () {
	R8192[0] = (char *(*)()) F1205_10159;
	R8192[1] = (char *(*)()) F1206_10159;
}

char *(*R8238[2])();
void R8238_init () {
	R8238[0] = (char *(*)()) F1208_10217;
	R8238[1] = (char *(*)()) F1209_10217;
}

char *(*R8272[2])();
void R8272_init () {
	R8272[0] = (char *(*)()) F1211_10283;
	R8272[1] = (char *(*)()) F1212_10283;
}

char *(*R8389[3])();
void R8389_init () {
	R8389[0] = (char *(*)()) F1225_10462;
	R8389[1] = (char *(*)()) F1226_10462;
	R8389[2] = (char *(*)()) F1227_10462;
}

char *(*R8391[3])();
void R8391_init () {
	R8391[0] = (char *(*)()) F1225_10464;
	R8391[1] = (char *(*)()) F1226_10464_8391_2;
	R8391[2] = (char *(*)()) F1227_10464_8391_2;
}
static EIF_BOOLEAN F1226_10464_8391_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1226_10464(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1227_10464_8391_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1227_10464(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R8396[3])();
void R8396_init () {
	R8396[0] = (char *(*)()) F1225_10469;
	R8396[1] = (char *(*)()) F1226_10469_8396_1;
	R8396[2] = (char *(*)()) F1227_10469_8396_1;
}
static EIF_REFERENCE F1226_10469_8396_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1226_10469(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1227_10469_8396_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1227_10469(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R8400[3])();
void R8400_init () {
	R8400[0] = (char *(*)()) F1225_10475;
	R8400[1] = (char *(*)()) F1226_10475_8400_3;
	R8400[2] = (char *(*)()) F1227_10475_8400_3;
}
static EIF_BOOLEAN F1226_10475_8400_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F1226_10475(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F1227_10475_8400_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F1227_10475(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_CHARACTER_32 *)arg2);
}

char *(*R8401[3])();
void R8401_init () {
	R8401[0] = (char *(*)()) F1225_10476;
	R8401[1] = (char *(*)()) F1226_10476_8401_4;
	R8401[2] = (char *(*)()) F1227_10476_8401_4;
}
static void F1226_10476_8401_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1226_10476(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1227_10476_8401_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1227_10476(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R8409[3])();
void R8409_init () {
	R8409[0] = (char *(*)()) F1225_10484;
	R8409[1] = (char *(*)()) F1226_10484;
	R8409[2] = (char *(*)()) F1227_10484;
}

char *(*R8411[3])();
void R8411_init () {
	R8411[0] = (char *(*)()) F1225_10487;
	R8411[1] = (char *(*)()) F1226_10487;
	R8411[2] = (char *(*)()) F1227_10487;
}

char *(*R8414[3])();
void R8414_init () {
	R8414[0] = (char *(*)()) F1225_10490;
	R8414[1] = (char *(*)()) F1226_10490_8414_4;
	R8414[2] = (char *(*)()) F1227_10490_8414_4;
}
static void F1226_10490_8414_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1226_10490(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1227_10490_8414_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1227_10490(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R8415[3])();
void R8415_init () {
	R8415[0] = (char *(*)()) F1225_10491;
	R8415[1] = (char *(*)()) F1226_10491;
	R8415[2] = (char *(*)()) F1227_10491;
}

char *(*R8417[3])();
void R8417_init () {
	R8417[0] = (char *(*)()) F1225_10493;
	R8417[1] = (char *(*)()) F1226_10493;
	R8417[2] = (char *(*)()) F1227_10493;
}

char *(*R8418[3])();
void R8418_init () {
	R8418[0] = (char *(*)()) F1225_10494;
	R8418[1] = (char *(*)()) F1226_10494_8418_2;
	R8418[2] = (char *(*)()) F1227_10494_8418_2;
}
static EIF_BOOLEAN F1226_10494_8418_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1226_10494(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1227_10494_8418_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1227_10494(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R8432[3])();
void R8432_init () {
	R8432[0] = (char *(*)()) F1225_10508;
	R8432[1] = (char *(*)()) F1226_10508;
	R8432[2] = (char *(*)()) F1227_10508;
}

char *(*R8433[3])();
void R8433_init () {
	R8433[0] = (char *(*)()) F1225_10509;
	R8433[1] = (char *(*)()) F1226_10509;
	R8433[2] = (char *(*)()) F1227_10509;
}

char *(*R8802[3])();
void R8802_init () {
	R8802[0] = (char *(*)()) F1246_10947;
	{long i; for (i = 1; i < 3; i++) R8802[i] = (char *(*)()) F1247_10975;}
}

char *(*R8807[3])();
void R8807_init () {
	R8807[0] = (char *(*)()) F1246_10948;
	{long i; for (i = 1; i < 3; i++) R8807[i] = (char *(*)()) F1247_10970;}
}

char *(*R8809[3])();
void R8809_init () {
	R8809[0] = (char *(*)()) F1246_10949;
	{long i; for (i = 1; i < 3; i++) R8809[i] = (char *(*)()) F1247_10971;}
}

char *(*R8949[53])();
void R8949_init () {
	R8949[0] = (char *(*)()) F1255_11195;
	R8949[2] = (char *(*)()) F1256_11247;
	R8949[4] = (char *(*)()) F1259_11272;
	R8949[52] = (char *(*)()) F1307_12952;
}

char *(*R8950[53])();
void R8950_init () {
	R8950[0] = (char *(*)()) F1255_11196;
	R8950[2] = (char *(*)()) F1253_11119;
	R8950[4] = (char *(*)()) F1253_11119;
	R8950[52] = (char *(*)()) F1307_12956;
}

char *(*R8951[53])();
void R8951_init () {
	R8951[0] = (char *(*)()) F1255_11197;
	R8951[2] = (char *(*)()) F1253_11120;
	R8951[4] = (char *(*)()) F1253_11120;
	R8951[52] = (char *(*)()) F1253_11120;
}

char *(*R8953[53])();
void R8953_init () {
	R8953[0] = (char *(*)()) F1255_11199;
	R8953[2] = (char *(*)()) F1256_11248;
	R8953[4] = (char *(*)()) F1259_11273;
	R8953[52] = (char *(*)()) F1307_12953;
}

char *(*R8954[53])();
void R8954_init () {
	R8954[0] = (char *(*)()) F1255_11201;
	R8954[2] = (char *(*)()) F1253_11123;
	R8954[4] = (char *(*)()) F1259_11274;
	R8954[52] = (char *(*)()) F1253_11123;
}

char *(*R8955[53])();
void R8955_init () {
	R8955[0] = (char *(*)()) F1255_11198;
	R8955[2] = (char *(*)()) F1256_11249;
	R8955[4] = (char *(*)()) F1253_11124;
	R8955[52] = (char *(*)()) F1307_12954;
}

char *(*R8956[53])();
void R8956_init () {
	R8956[0] = (char *(*)()) F1253_11125;
	R8956[2] = (char *(*)()) F1256_11250;
	R8956[4] = (char *(*)()) F1253_11125;
	R8956[52] = (char *(*)()) F1253_11125;
}

char *(*R8957[53])();
void R8957_init () {
	R8957[0] = (char *(*)()) F1255_11200;
	R8957[2] = (char *(*)()) F1256_11251;
	R8957[4] = (char *(*)()) F1253_11126;
	R8957[52] = (char *(*)()) F1307_12955;
}

char *(*R9795[2])();
void R9795_init () {
	R9795[0] = (char *(*)()) F1280_12076;
	R9795[1] = (char *(*)()) F1281_12079;
}

char *(*R10304[3])();
void R10304_init () {
	{long i; for (i = 0; i < 2; i++) R10304[i] = (char *(*)()) F1301_12691;}
	R10304[2] = (char *(*)()) F1303_12759;
}
char *(*R2[1311])();
void R2_init () {}
char *(*R6[1311])();
void R6_init () {}

char *(*R3[1311])();
void R3_init () {
	R3[412] = (char *(*)()) F413_4994;
	R3[419] = (char *(*)()) F420_5162;
	R3[424] = (char *(*)()) F415_5036;
	R3[431] = (char *(*)()) F432_5478;
	R3[445] = (char *(*)()) F446_5580;
	{long i; for (i = 802; i < 804; i++) R3[i] = (char *(*)()) F431_5415;}
	R3[1223] = (char *(*)()) F1224_10406;
	R3[1277] = (char *(*)()) F431_5415;
}

char *(*R4[1311])();
void R4_init () {
	{long i; for (i = 1; i < 11; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 12; i < 26; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 27; i < 34; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 35; i < 40; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 41; i < 43; i++) R4[i] = (char *(*)()) F1_15;}
	R4[44] = (char *(*)()) F1_15;
	{long i; for (i = 46; i < 56; i++) R4[i] = (char *(*)()) F1_15;}
	R4[57] = (char *(*)()) F1_15;
	R4[60] = (char *(*)()) F1_15;
	{long i; for (i = 73; i < 80; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 82; i < 86; i++) R4[i] = (char *(*)()) F1_15;}
	R4[96] = (char *(*)()) F1_15;
	{long i; for (i = 103; i < 105; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 122; i < 124; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 136; i < 139; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 141; i < 143; i++) R4[i] = (char *(*)()) F1_15;}
	R4[147] = (char *(*)()) F1_15;
	R4[150] = (char *(*)()) F1_15;
	R4[155] = (char *(*)()) F1_15;
	R4[164] = (char *(*)()) F1_15;
	{long i; for (i = 166; i < 168; i++) R4[i] = (char *(*)()) F1_15;}
	R4[170] = (char *(*)()) F1_15;
	{long i; for (i = 172; i < 174; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 175; i < 184; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 185; i < 190; i++) R4[i] = (char *(*)()) F1_15;}
	R4[195] = (char *(*)()) F1_15;
	{long i; for (i = 202; i < 204; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 205; i < 207; i++) R4[i] = (char *(*)()) F1_15;}
	R4[214] = (char *(*)()) F1_15;
	{long i; for (i = 216; i < 218; i++) R4[i] = (char *(*)()) F1_15;}
	R4[223] = (char *(*)()) F1_15;
	R4[225] = (char *(*)()) F1_15;
	R4[231] = (char *(*)()) F1_15;
	R4[236] = (char *(*)()) F1_15;
	{long i; for (i = 247; i < 249; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 250; i < 252; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 255; i < 257; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 258; i < 264; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 266; i < 268; i++) R4[i] = (char *(*)()) F1_15;}
	R4[270] = (char *(*)()) F1_15;
	R4[273] = (char *(*)()) F1_15;
	R4[278] = (char *(*)()) F1_15;
	R4[283] = (char *(*)()) F1_15;
	{long i; for (i = 285; i < 287; i++) R4[i] = (char *(*)()) F1_15;}
	R4[290] = (char *(*)()) F1_15;
	R4[293] = (char *(*)()) F1_15;
	{long i; for (i = 297; i < 300; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 301; i < 303; i++) R4[i] = (char *(*)()) F1_15;}
	R4[305] = (char *(*)()) F1_15;
	{long i; for (i = 307; i < 313; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 314; i < 317; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 318; i < 320; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 322; i < 324; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 325; i < 328; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 329; i < 333; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 334; i < 336; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 337; i < 343; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 344; i < 348; i++) R4[i] = (char *(*)()) F1_15;}
	R4[357] = (char *(*)()) F1_15;
	{long i; for (i = 361; i < 364; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 365; i < 369; i++) R4[i] = (char *(*)()) F1_15;}
	R4[372] = (char *(*)()) F1_15;
	R4[378] = (char *(*)()) F1_15;
	{long i; for (i = 381; i < 383; i++) R4[i] = (char *(*)()) F1_15;}
	R4[384] = (char *(*)()) F1_15;
	{long i; for (i = 387; i < 389; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 390; i < 397; i++) R4[i] = (char *(*)()) F1_15;}
	R4[412] = (char *(*)()) F413_4913;
	R4[416] = (char *(*)()) F1_15;
	R4[417] = (char *(*)()) F418_5112;
	{long i; for (i = 419; i < 422; i++) R4[i] = (char *(*)()) F1_15;}
	R4[424] = (char *(*)()) F1_15;
	{long i; for (i = 428; i < 430; i++) R4[i] = (char *(*)()) F1_15;}
	R4[431] = (char *(*)()) F1_15;
	{long i; for (i = 444; i < 449; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 461; i < 463; i++) R4[i] = (char *(*)()) F1_15;}
	R4[464] = (char *(*)()) F1_15;
	R4[466] = (char *(*)()) F1_15;
	R4[468] = (char *(*)()) F1_15;
	R4[482] = (char *(*)()) F1_15;
	{long i; for (i = 508; i < 530; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 542; i < 580; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 733; i < 735; i++) R4[i] = (char *(*)()) F1_15;}
	R4[774] = (char *(*)()) F775_6174;
	{long i; for (i = 802; i < 804; i++) R4[i] = (char *(*)()) F1_15;}
	R4[812] = (char *(*)()) F1_15;
	R4[825] = (char *(*)()) F826_6625;
	R4[826] = (char *(*)()) F827_6625;
	R4[827] = (char *(*)()) F828_6625;
	R4[828] = (char *(*)()) F829_6625;
	R4[829] = (char *(*)()) F830_6625;
	R4[830] = (char *(*)()) F831_6625;
	R4[831] = (char *(*)()) F832_6625;
	R4[832] = (char *(*)()) F833_6625;
	{long i; for (i = 833; i < 835; i++) R4[i] = (char *(*)()) F826_6625;}
	R4[835] = (char *(*)()) F828_6625;
	R4[836] = (char *(*)()) F829_6625;
	R4[837] = (char *(*)()) F831_6625;
	R4[838] = (char *(*)()) F832_6625;
	R4[851] = (char *(*)()) F852_6727;
	R4[852] = (char *(*)()) F853_6792;
	R4[853] = (char *(*)()) F854_6792;
	R4[854] = (char *(*)()) F855_6792;
	R4[855] = (char *(*)()) F856_6792;
	R4[856] = (char *(*)()) F857_6792;
	R4[857] = (char *(*)()) F858_6792;
	R4[858] = (char *(*)()) F859_6792;
	R4[859] = (char *(*)()) F860_6792;
	R4[860] = (char *(*)()) F861_6792;
	R4[861] = (char *(*)()) F862_6792;
	R4[862] = (char *(*)()) F863_6792;
	R4[863] = (char *(*)()) F864_6792;
	R4[917] = (char *(*)()) F918_6885;
	R4[918] = (char *(*)()) F919_6885;
	R4[919] = (char *(*)()) F918_6885;
	R4[920] = (char *(*)()) F919_6885;
	R4[921] = (char *(*)()) F918_6885;
	R4[922] = (char *(*)()) F923_6969;
	R4[923] = (char *(*)()) F924_6969;
	R4[924] = (char *(*)()) F925_6969;
	R4[925] = (char *(*)()) F926_6969;
	R4[926] = (char *(*)()) F927_6969;
	R4[927] = (char *(*)()) F928_6969;
	R4[928] = (char *(*)()) F929_6969;
	R4[929] = (char *(*)()) F930_6969;
	R4[930] = (char *(*)()) F931_6969;
	R4[931] = (char *(*)()) F932_6969;
	R4[932] = (char *(*)()) F933_6969;
	R4[933] = (char *(*)()) F934_6969;
	R4[934] = (char *(*)()) F923_6969;
	R4[935] = (char *(*)()) F925_6969;
	{long i; for (i = 936; i < 938; i++) R4[i] = (char *(*)()) F923_6969;}
	R4[945] = (char *(*)()) F1_15;
	{long i; for (i = 950; i < 954; i++) R4[i] = (char *(*)()) F1_15;}
	R4[954] = (char *(*)()) F955_7293;
	R4[955] = (char *(*)()) F956_7329;
	{long i; for (i = 960; i < 968; i++) R4[i] = (char *(*)()) F1_15;}
	R4[971] = (char *(*)()) F1_15;
	R4[977] = (char *(*)()) F1_15;
	{long i; for (i = 982; i < 997; i++) R4[i] = (char *(*)()) F1_15;}
	R4[999] = (char *(*)()) F1_15;
	{long i; for (i = 1001; i < 1003; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1004; i < 1006; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1007; i < 1009; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1010; i < 1042; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1043] = (char *(*)()) F1043_7936;
	R4[1044] = (char *(*)()) F1045_7968;
	R4[1045] = (char *(*)()) F1046_7968;
	R4[1046] = (char *(*)()) F1047_7968;
	R4[1047] = (char *(*)()) F1046_7968;
	R4[1052] = (char *(*)()) F1053_8160;
	R4[1053] = (char *(*)()) F1052_8144;
	R4[1056] = (char *(*)()) F1057_8328;
	R4[1057] = (char *(*)()) F1056_8309;
	{long i; for (i = 1060; i < 1067; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1068; i < 1072; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1072] = (char *(*)()) F1073_8949;
	{long i; for (i = 1073; i < 1107; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1108; i < 1120; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1123; i < 1126; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1127; i < 1130; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1177; i < 1181; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1183; i < 1185; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1186; i < 1188; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1189; i < 1191; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1192; i < 1194; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1195; i < 1197; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1198; i < 1200; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1201; i < 1203; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1204; i < 1206; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1207; i < 1209; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1210; i < 1224; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1224] = (char *(*)()) F1225_10486;
	R4[1225] = (char *(*)()) F1226_10486;
	R4[1226] = (char *(*)()) F1227_10486;
	R4[1227] = (char *(*)()) F1_15;
	R4[1238] = (char *(*)()) F1_15;
	{long i; for (i = 1245; i < 1248; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1249; i < 1251; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1254] = (char *(*)()) F1_15;
	R4[1256] = (char *(*)()) F1_15;
	R4[1258] = (char *(*)()) F1_15;
	R4[1260] = (char *(*)()) F1_15;
	{long i; for (i = 1262; i < 1265; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1277] = (char *(*)()) F1_15;
	{long i; for (i = 1279; i < 1283; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1292] = (char *(*)()) F1_15;
	{long i; for (i = 1300; i < 1304; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1305; i < 1307; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1309] = (char *(*)()) F1310_13081;
}

char *(*R5[1311])();
void R5_init () {
	{long i; for (i = 1; i < 11; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 12; i < 26; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 27; i < 34; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 35; i < 40; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 41; i < 43; i++) R5[i] = (char *(*)()) F1_8;}
	R5[44] = (char *(*)()) F1_8;
	{long i; for (i = 46; i < 56; i++) R5[i] = (char *(*)()) F1_8;}
	R5[57] = (char *(*)()) F58_948;
	R5[60] = (char *(*)()) F1_8;
	{long i; for (i = 73; i < 80; i++) R5[i] = (char *(*)()) F1_8;}
	R5[82] = (char *(*)()) F83_1285;
	{long i; for (i = 83; i < 86; i++) R5[i] = (char *(*)()) F1_8;}
	R5[96] = (char *(*)()) F1_8;
	{long i; for (i = 103; i < 105; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 122; i < 124; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 136; i < 139; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 141; i < 143; i++) R5[i] = (char *(*)()) F1_8;}
	R5[147] = (char *(*)()) F1_8;
	R5[150] = (char *(*)()) F1_8;
	R5[155] = (char *(*)()) F1_8;
	R5[164] = (char *(*)()) F1_8;
	{long i; for (i = 166; i < 168; i++) R5[i] = (char *(*)()) F1_8;}
	R5[170] = (char *(*)()) F1_8;
	{long i; for (i = 172; i < 174; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 175; i < 184; i++) R5[i] = (char *(*)()) F1_8;}
	R5[185] = (char *(*)()) F186_2382;
	{long i; for (i = 186; i < 190; i++) R5[i] = (char *(*)()) F1_8;}
	R5[195] = (char *(*)()) F1_8;
	{long i; for (i = 202; i < 204; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 205; i < 207; i++) R5[i] = (char *(*)()) F1_8;}
	R5[214] = (char *(*)()) F1_8;
	{long i; for (i = 216; i < 218; i++) R5[i] = (char *(*)()) F1_8;}
	R5[223] = (char *(*)()) F1_8;
	R5[225] = (char *(*)()) F1_8;
	R5[231] = (char *(*)()) F1_8;
	R5[236] = (char *(*)()) F1_8;
	{long i; for (i = 247; i < 249; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 250; i < 252; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 255; i < 257; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 258; i < 264; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 266; i < 268; i++) R5[i] = (char *(*)()) F1_8;}
	R5[270] = (char *(*)()) F1_8;
	R5[273] = (char *(*)()) F1_8;
	R5[278] = (char *(*)()) F1_8;
	R5[283] = (char *(*)()) F1_8;
	{long i; for (i = 285; i < 287; i++) R5[i] = (char *(*)()) F1_8;}
	R5[290] = (char *(*)()) F1_8;
	R5[293] = (char *(*)()) F1_8;
	{long i; for (i = 297; i < 300; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 301; i < 303; i++) R5[i] = (char *(*)()) F1_8;}
	R5[305] = (char *(*)()) F1_8;
	{long i; for (i = 307; i < 313; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 314; i < 317; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 318; i < 320; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 322; i < 324; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 325; i < 328; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 329; i < 333; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 334; i < 336; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 337; i < 343; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 344; i < 348; i++) R5[i] = (char *(*)()) F1_8;}
	R5[357] = (char *(*)()) F357_4061;
	{long i; for (i = 361; i < 364; i++) R5[i] = (char *(*)()) F357_4061;}
	{long i; for (i = 365; i < 369; i++) R5[i] = (char *(*)()) F357_4061;}
	R5[372] = (char *(*)()) F1_8;
	R5[378] = (char *(*)()) F1_8;
	{long i; for (i = 381; i < 383; i++) R5[i] = (char *(*)()) F1_8;}
	R5[384] = (char *(*)()) F1_8;
	R5[387] = (char *(*)()) F388_4828;
	R5[388] = (char *(*)()) F1_8;
	{long i; for (i = 390; i < 397; i++) R5[i] = (char *(*)()) F1_8;}
	R5[412] = (char *(*)()) F413_4912;
	R5[416] = (char *(*)()) F417_5062;
	R5[417] = (char *(*)()) F418_5111;
	{long i; for (i = 419; i < 422; i++) R5[i] = (char *(*)()) F1_8;}
	R5[424] = (char *(*)()) F1_8;
	{long i; for (i = 428; i < 430; i++) R5[i] = (char *(*)()) F1_8;}
	R5[431] = (char *(*)()) F1_8;
	{long i; for (i = 444; i < 449; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 461; i < 463; i++) R5[i] = (char *(*)()) F1_8;}
	R5[464] = (char *(*)()) F1_8;
	R5[466] = (char *(*)()) F1_8;
	R5[468] = (char *(*)()) F1_8;
	R5[482] = (char *(*)()) F1_8;
	{long i; for (i = 508; i < 530; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 542; i < 580; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 733; i < 735; i++) R5[i] = (char *(*)()) F1_8;}
	R5[774] = (char *(*)()) F775_6161;
	{long i; for (i = 802; i < 804; i++) R5[i] = (char *(*)()) F1_8;}
	R5[812] = (char *(*)()) F1_8;
	R5[825] = (char *(*)()) F826_6591;
	R5[826] = (char *(*)()) F827_6591;
	R5[827] = (char *(*)()) F828_6591;
	R5[828] = (char *(*)()) F829_6591;
	R5[829] = (char *(*)()) F830_6591;
	R5[830] = (char *(*)()) F831_6591;
	R5[831] = (char *(*)()) F832_6591;
	R5[832] = (char *(*)()) F833_6591;
	R5[833] = (char *(*)()) F826_6591;
	R5[834] = (char *(*)()) F835_6697;
	R5[835] = (char *(*)()) F836_6697;
	R5[836] = (char *(*)()) F837_6697;
	R5[837] = (char *(*)()) F838_6697;
	R5[838] = (char *(*)()) F839_6697;
	R5[851] = (char *(*)()) F852_6713;
	R5[852] = (char *(*)()) F853_6754;
	R5[853] = (char *(*)()) F854_6754;
	R5[854] = (char *(*)()) F855_6754;
	R5[855] = (char *(*)()) F856_6754;
	R5[856] = (char *(*)()) F857_6754;
	R5[857] = (char *(*)()) F858_6754;
	R5[858] = (char *(*)()) F859_6754;
	R5[859] = (char *(*)()) F860_6754;
	R5[860] = (char *(*)()) F861_6754;
	R5[861] = (char *(*)()) F862_6754;
	R5[862] = (char *(*)()) F863_6754;
	R5[863] = (char *(*)()) F864_6754;
	R5[917] = (char *(*)()) F894_6836;
	R5[918] = (char *(*)()) F896_6836;
	R5[919] = (char *(*)()) F894_6836;
	R5[920] = (char *(*)()) F896_6836;
	R5[921] = (char *(*)()) F894_6836;
	R5[922] = (char *(*)()) F923_6942;
	R5[923] = (char *(*)()) F924_6942;
	R5[924] = (char *(*)()) F925_6942;
	R5[925] = (char *(*)()) F926_6942;
	R5[926] = (char *(*)()) F927_6942;
	R5[927] = (char *(*)()) F928_6942;
	R5[928] = (char *(*)()) F929_6942;
	R5[929] = (char *(*)()) F930_6942;
	R5[930] = (char *(*)()) F931_6942;
	R5[931] = (char *(*)()) F932_6942;
	R5[932] = (char *(*)()) F933_6942;
	R5[933] = (char *(*)()) F934_6942;
	R5[934] = (char *(*)()) F923_6942;
	R5[935] = (char *(*)()) F925_6942;
	{long i; for (i = 936; i < 938; i++) R5[i] = (char *(*)()) F923_6942;}
	R5[945] = (char *(*)()) F1_8;
	{long i; for (i = 950; i < 954; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 954; i < 956; i++) R5[i] = (char *(*)()) F955_7294;}
	{long i; for (i = 960; i < 968; i++) R5[i] = (char *(*)()) F1_8;}
	R5[971] = (char *(*)()) F1_8;
	R5[977] = (char *(*)()) F1_8;
	{long i; for (i = 982; i < 997; i++) R5[i] = (char *(*)()) F1_8;}
	R5[999] = (char *(*)()) F1000_7669;
	{long i; for (i = 1001; i < 1003; i++) R5[i] = (char *(*)()) F1001_7786;}
	{long i; for (i = 1004; i < 1006; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1007; i < 1009; i++) R5[i] = (char *(*)()) F1007_7857;}
	{long i; for (i = 1010; i < 1042; i++) R5[i] = (char *(*)()) F1010_7892;}
	R5[1043] = (char *(*)()) F1043_7929;
	R5[1044] = (char *(*)()) F1045_7967;
	R5[1045] = (char *(*)()) F1046_7967;
	R5[1046] = (char *(*)()) F1047_7967;
	R5[1047] = (char *(*)()) F1046_7967;
	{long i; for (i = 1052; i < 1054; i++) R5[i] = (char *(*)()) F1052_8129;}
	{long i; for (i = 1056; i < 1058; i++) R5[i] = (char *(*)()) F1056_8294;}
	{long i; for (i = 1060; i < 1062; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1062] = (char *(*)()) F1063_8510;
	{long i; for (i = 1063; i < 1066; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1066] = (char *(*)()) F1067_8617;
	{long i; for (i = 1068; i < 1072; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1072] = (char *(*)()) F1073_8946;
	R5[1073] = (char *(*)()) F1074_8983;
	R5[1074] = (char *(*)()) F1075_8983;
	R5[1075] = (char *(*)()) F1076_8983;
	R5[1076] = (char *(*)()) F1077_8983;
	R5[1077] = (char *(*)()) F1078_8983;
	R5[1078] = (char *(*)()) F1079_8983;
	R5[1079] = (char *(*)()) F1080_8983;
	R5[1080] = (char *(*)()) F1081_8983;
	R5[1081] = (char *(*)()) F1082_8983;
	R5[1082] = (char *(*)()) F1083_8983;
	R5[1083] = (char *(*)()) F1084_8983;
	R5[1084] = (char *(*)()) F1085_8983;
	R5[1085] = (char *(*)()) F1086_8983;
	R5[1086] = (char *(*)()) F1087_8983;
	R5[1087] = (char *(*)()) F1088_8983;
	R5[1088] = (char *(*)()) F1089_8983;
	R5[1089] = (char *(*)()) F1090_8983;
	R5[1090] = (char *(*)()) F1091_8983;
	R5[1091] = (char *(*)()) F1092_8983;
	R5[1092] = (char *(*)()) F1093_8983;
	R5[1093] = (char *(*)()) F1094_8983;
	R5[1094] = (char *(*)()) F1095_8983;
	R5[1095] = (char *(*)()) F1096_8983;
	R5[1096] = (char *(*)()) F1097_8983;
	R5[1097] = (char *(*)()) F1098_8983;
	R5[1098] = (char *(*)()) F1099_8983;
	R5[1099] = (char *(*)()) F1100_8983;
	R5[1100] = (char *(*)()) F1101_8983;
	R5[1101] = (char *(*)()) F1102_8983;
	R5[1102] = (char *(*)()) F1103_8983;
	R5[1103] = (char *(*)()) F1104_8983;
	R5[1104] = (char *(*)()) F1105_8983;
	R5[1105] = (char *(*)()) F1106_8983;
	R5[1106] = (char *(*)()) F1107_8983;
	{long i; for (i = 1108; i < 1120; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1123; i < 1126; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1127; i < 1130; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1177; i < 1179; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1179] = (char *(*)()) F1180_9352;
	R5[1180] = (char *(*)()) F1181_9376;
	{long i; for (i = 1183; i < 1185; i++) R5[i] = (char *(*)()) F1183_9407;}
	{long i; for (i = 1186; i < 1188; i++) R5[i] = (char *(*)()) F1186_9501;}
	{long i; for (i = 1189; i < 1191; i++) R5[i] = (char *(*)()) F1189_9599;}
	{long i; for (i = 1192; i < 1194; i++) R5[i] = (char *(*)()) F1192_9698;}
	{long i; for (i = 1195; i < 1197; i++) R5[i] = (char *(*)()) F1195_9797;}
	{long i; for (i = 1198; i < 1200; i++) R5[i] = (char *(*)()) F1198_9896;}
	{long i; for (i = 1201; i < 1203; i++) R5[i] = (char *(*)()) F1201_9990;}
	{long i; for (i = 1204; i < 1206; i++) R5[i] = (char *(*)()) F1204_10085;}
	{long i; for (i = 1207; i < 1209; i++) R5[i] = (char *(*)()) F1207_10184;}
	{long i; for (i = 1210; i < 1212; i++) R5[i] = (char *(*)()) F1210_10250;}
	{long i; for (i = 1212; i < 1219; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1219] = (char *(*)()) F1220_10365;
	R5[1220] = (char *(*)()) F1221_10376;
	{long i; for (i = 1221; i < 1224; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1224] = (char *(*)()) F1225_10473;
	R5[1225] = (char *(*)()) F1226_10473;
	R5[1226] = (char *(*)()) F1227_10473;
	R5[1227] = (char *(*)()) F1_8;
	R5[1238] = (char *(*)()) F1_8;
	{long i; for (i = 1245; i < 1248; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1249; i < 1251; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1254] = (char *(*)()) F1_8;
	R5[1256] = (char *(*)()) F1_8;
	R5[1258] = (char *(*)()) F1_8;
	R5[1260] = (char *(*)()) F1_8;
	{long i; for (i = 1262; i < 1264; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1264] = (char *(*)()) F1265_11932;
	R5[1277] = (char *(*)()) F1_8;
	{long i; for (i = 1279; i < 1281; i++) R5[i] = (char *(*)()) F1279_12070;}
	{long i; for (i = 1281; i < 1283; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1292] = (char *(*)()) F1_8;
	{long i; for (i = 1300; i < 1304; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1305; i < 1307; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1309] = (char *(*)()) F1310_13038;
}


#ifdef __cplusplus
}
#endif
