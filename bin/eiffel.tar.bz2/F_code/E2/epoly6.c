#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5337[485])();
void R5337_init () {
	R5337[0] = (char *(*)()) F826_6614;
	R5337[1] = (char *(*)()) F827_6614_5337_9;
	R5337[2] = (char *(*)()) F828_6614_5337_9;
	R5337[3] = (char *(*)()) F829_6614_5337_9;
	R5337[4] = (char *(*)()) F830_6614_5337_9;
	R5337[5] = (char *(*)()) F831_6614_5337_9;
	R5337[6] = (char *(*)()) F832_6614_5337_9;
	R5337[7] = (char *(*)()) F833_6614_5337_9;
	{long i; for (i = 8; i < 10; i++) R5337[i] = (char *(*)()) F826_6614;}
	R5337[10] = (char *(*)()) F828_6614_5337_9;
	R5337[11] = (char *(*)()) F829_6614_5337_9;
	R5337[12] = (char *(*)()) F831_6614_5337_9;
	R5337[13] = (char *(*)()) F832_6614_5337_9;
	R5337[27] = (char *(*)()) F853_6763_5337_9;
	R5337[28] = (char *(*)()) F854_6763_5337_9;
	R5337[29] = (char *(*)()) F855_6763_5337_9;
	R5337[30] = (char *(*)()) F856_6763_5337_9;
	R5337[31] = (char *(*)()) F857_6763_5337_9;
	R5337[32] = (char *(*)()) F858_6763_5337_9;
	R5337[33] = (char *(*)()) F859_6763_5337_9;
	R5337[34] = (char *(*)()) F860_6763_5337_9;
	R5337[35] = (char *(*)()) F861_6763_5337_9;
	R5337[36] = (char *(*)()) F862_6763_5337_9;
	R5337[37] = (char *(*)()) F863_6763_5337_9;
	R5337[38] = (char *(*)()) F864_6763_5337_9;
	R5337[228] = (char *(*)()) F1054_8204_5337_9;
	R5337[232] = (char *(*)()) F1058_8372_5337_9;
	R5337[484] = (char *(*)()) F1310_13047_5337_9;
}
static void F827_6614_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F827_6614(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F828_6614_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F828_6614(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F829_6614_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F829_6614(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F830_6614_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F830_6614(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F831_6614_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F831_6614(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F832_6614_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F832_6614(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F833_6614_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F833_6614(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F853_6763_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F853_6763(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F854_6763_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F854_6763(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F855_6763_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F855_6763(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F856_6763_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F856_6763(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F857_6763_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F857_6763(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F858_6763_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F858_6763(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F859_6763_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F859_6763(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F860_6763_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F860_6763(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F861_6763_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F861_6763(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F862_6763_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F862_6763(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F863_6763_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F863_6763(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F864_6763_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F864_6763(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1054_8204_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1054_8204(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1058_8372_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1058_8372(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1310_13047_5337_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1310_13047(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R5338[485])();
void R5338_init () {
	R5338[0] = (char *(*)()) F826_6615;
	R5338[1] = (char *(*)()) F827_6615_5338_9;
	R5338[2] = (char *(*)()) F828_6615_5338_9;
	R5338[3] = (char *(*)()) F829_6615_5338_9;
	R5338[4] = (char *(*)()) F830_6615_5338_9;
	R5338[5] = (char *(*)()) F831_6615_5338_9;
	R5338[6] = (char *(*)()) F832_6615_5338_9;
	R5338[7] = (char *(*)()) F833_6615_5338_9;
	{long i; for (i = 8; i < 10; i++) R5338[i] = (char *(*)()) F826_6615;}
	R5338[10] = (char *(*)()) F828_6615_5338_9;
	R5338[11] = (char *(*)()) F829_6615_5338_9;
	R5338[12] = (char *(*)()) F831_6615_5338_9;
	R5338[13] = (char *(*)()) F832_6615_5338_9;
	R5338[27] = (char *(*)()) F853_6763_5338_9;
	R5338[28] = (char *(*)()) F854_6763_5338_9;
	R5338[29] = (char *(*)()) F855_6763_5338_9;
	R5338[30] = (char *(*)()) F856_6763_5338_9;
	R5338[31] = (char *(*)()) F857_6763_5338_9;
	R5338[32] = (char *(*)()) F858_6763_5338_9;
	R5338[33] = (char *(*)()) F859_6763_5338_9;
	R5338[34] = (char *(*)()) F860_6763_5338_9;
	R5338[35] = (char *(*)()) F861_6763_5338_9;
	R5338[36] = (char *(*)()) F862_6763_5338_9;
	R5338[37] = (char *(*)()) F863_6763_5338_9;
	R5338[38] = (char *(*)()) F864_6763_5338_9;
	R5338[228] = (char *(*)()) F1054_8204_5338_9;
	R5338[232] = (char *(*)()) F1058_8372_5338_9;
	R5338[484] = (char *(*)()) F1310_13047_5338_9;
}
static void F827_6615_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F827_6615(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F828_6615_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F828_6615(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F829_6615_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F829_6615(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F830_6615_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F830_6615(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F831_6615_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F831_6615(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F832_6615_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F832_6615(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F833_6615_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F833_6615(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F853_6763_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F853_6763(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F854_6763_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F854_6763(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F855_6763_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F855_6763(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F856_6763_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F856_6763(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F857_6763_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F857_6763(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F858_6763_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F858_6763(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F859_6763_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F859_6763(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F860_6763_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F860_6763(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F861_6763_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F861_6763(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F862_6763_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F862_6763(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F863_6763_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F863_6763(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F864_6763_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F864_6763(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1054_8204_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1054_8204(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1058_8372_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1058_8372(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1310_13047_5338_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1310_13047(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y5339_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype32[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype33[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype34[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype35[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype36[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype37[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype38[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype39[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype40[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype41[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype42[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype43[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype44[] = {0xFF01,1053,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype45[] = {0xFF01,1048,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype46[] = {0xFF01,1048,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype47[] = {0xFF01,1048,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype48[] = {0xFF01,1048,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype49[] = {0xFF01,1048,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype50[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype51[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype52[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype53[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype54[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype55[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype56[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype57[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype58[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype59[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype60[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype61[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype62[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype63[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype64[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype65[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype66[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype67[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype68[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype69[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype70[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype71[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype72[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype73[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype74[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype75[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype76[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype77[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype78[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype79[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype80[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype81[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype82[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype83[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype84[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype85[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype86[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype87[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype88[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype89[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype90[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype91[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype92[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype93[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype94[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype95[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype96[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype97[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype98[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype99[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype100[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype101[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype102[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype103[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype104[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype105[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype106[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype107[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype108[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype109[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype110[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype111[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype112[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype113[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype114[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype115[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype116[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype117[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype118[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype119[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype120[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype121[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype122[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype123[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype124[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype125[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype126[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype127[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype128[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype129[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype130[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype131[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype132[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype133[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype134[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype135[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype136[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype137[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype138[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype139[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype140[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype141[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype142[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype143[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype144[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype145[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype146[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype147[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype148[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype149[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype150[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype151[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype152[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5339_pgtype153[] = {1190,0xFFFF};
EIF_TYPE_INDEX *Y5339_gen_type [658];
EIF_TYPE_INDEX Y5339 [658];
void Y5339_init (void)
{
	egc_routines_types [5339] = Y5339;
	egc_routines_gen_types [5339] = Y5339_gen_type;
	egc_routines_offset [5339] = 653;
	Y5339_gen_type [0] = Y5339_pgtype0;
	Y5339_gen_type [1] = Y5339_pgtype1;
	Y5339_gen_type [2] = Y5339_pgtype2;
	Y5339_gen_type [3] = Y5339_pgtype3;
	Y5339_gen_type [4] = Y5339_pgtype4;
	Y5339_gen_type [5] = Y5339_pgtype5;
	Y5339_gen_type [6] = Y5339_pgtype6;
	Y5339_gen_type [7] = Y5339_pgtype7;
	Y5339_gen_type [8] = Y5339_pgtype8;
	Y5339_gen_type [9] = Y5339_pgtype9;
	Y5339_gen_type [10] = Y5339_pgtype10;
	Y5339_gen_type [11] = Y5339_pgtype11;
	Y5339_gen_type [12] = Y5339_pgtype12;
	Y5339_gen_type [13] = Y5339_pgtype13;
	Y5339_gen_type [14] = Y5339_pgtype14;
	Y5339_gen_type [15] = Y5339_pgtype15;
	Y5339_gen_type [16] = Y5339_pgtype16;
	Y5339_gen_type [17] = Y5339_pgtype17;
	Y5339_gen_type [18] = Y5339_pgtype18;
	Y5339_gen_type [19] = Y5339_pgtype19;
	Y5339_gen_type [20] = Y5339_pgtype20;
	Y5339_gen_type [21] = Y5339_pgtype21;
	Y5339_gen_type [22] = Y5339_pgtype22;
	Y5339_gen_type [23] = Y5339_pgtype23;
	Y5339_gen_type [24] = Y5339_pgtype24;
	Y5339_gen_type [25] = Y5339_pgtype25;
	Y5339_gen_type [26] = Y5339_pgtype26;
	Y5339_gen_type [27] = Y5339_pgtype27;
	Y5339_gen_type [28] = Y5339_pgtype28;
	Y5339_gen_type [29] = Y5339_pgtype29;
	Y5339_gen_type [30] = Y5339_pgtype30;
	Y5339_gen_type [31] = Y5339_pgtype31;
	Y5339_gen_type [32] = Y5339_pgtype32;
	Y5339_gen_type [33] = Y5339_pgtype33;
	Y5339_gen_type [34] = Y5339_pgtype34;
	Y5339_gen_type [35] = Y5339_pgtype35;
	Y5339_gen_type [172] = Y5339_pgtype36;
	Y5339_gen_type [173] = Y5339_pgtype37;
	Y5339_gen_type [174] = Y5339_pgtype38;
	Y5339_gen_type [175] = Y5339_pgtype39;
	Y5339_gen_type [176] = Y5339_pgtype40;
	Y5339_gen_type [177] = Y5339_pgtype41;
	Y5339_gen_type [178] = Y5339_pgtype42;
	Y5339_gen_type [179] = Y5339_pgtype43;
	Y5339_gen_type [180] = Y5339_pgtype44;
	Y5339_gen_type [181] = Y5339_pgtype45;
	Y5339_gen_type [182] = Y5339_pgtype46;
	Y5339_gen_type [183] = Y5339_pgtype47;
	Y5339_gen_type [184] = Y5339_pgtype48;
	Y5339_gen_type [185] = Y5339_pgtype49;
	Y5339_gen_type [186] = Y5339_pgtype50;
	Y5339_gen_type [187] = Y5339_pgtype51;
	Y5339_gen_type [188] = Y5339_pgtype52;
	Y5339_gen_type [189] = Y5339_pgtype53;
	Y5339_gen_type [190] = Y5339_pgtype54;
	Y5339_gen_type [191] = Y5339_pgtype55;
	Y5339_gen_type [192] = Y5339_pgtype56;
	Y5339_gen_type [193] = Y5339_pgtype57;
	Y5339_gen_type [194] = Y5339_pgtype58;
	Y5339_gen_type [195] = Y5339_pgtype59;
	Y5339_gen_type [196] = Y5339_pgtype60;
	Y5339_gen_type [197] = Y5339_pgtype61;
	Y5339_gen_type [198] = Y5339_pgtype62;
	Y5339_gen_type [199] = Y5339_pgtype63;
	Y5339_gen_type [200] = Y5339_pgtype64;
	Y5339_gen_type [201] = Y5339_pgtype65;
	Y5339_gen_type [202] = Y5339_pgtype66;
	Y5339_gen_type [203] = Y5339_pgtype67;
	Y5339_gen_type [204] = Y5339_pgtype68;
	Y5339_gen_type [205] = Y5339_pgtype69;
	Y5339_gen_type [206] = Y5339_pgtype70;
	Y5339_gen_type [207] = Y5339_pgtype71;
	Y5339_gen_type [208] = Y5339_pgtype72;
	Y5339_gen_type [209] = Y5339_pgtype73;
	Y5339_gen_type [210] = Y5339_pgtype74;
	Y5339_gen_type [211] = Y5339_pgtype75;
	Y5339_gen_type [212] = Y5339_pgtype76;
	Y5339_gen_type [213] = Y5339_pgtype77;
	Y5339_gen_type [214] = Y5339_pgtype78;
	Y5339_gen_type [215] = Y5339_pgtype79;
	Y5339_gen_type [216] = Y5339_pgtype80;
	Y5339_gen_type [217] = Y5339_pgtype81;
	Y5339_gen_type [218] = Y5339_pgtype82;
	Y5339_gen_type [219] = Y5339_pgtype83;
	Y5339_gen_type [220] = Y5339_pgtype84;
	Y5339_gen_type [221] = Y5339_pgtype85;
	Y5339_gen_type [222] = Y5339_pgtype86;
	Y5339_gen_type [223] = Y5339_pgtype87;
	Y5339_gen_type [224] = Y5339_pgtype88;
	Y5339_gen_type [225] = Y5339_pgtype89;
	Y5339_gen_type [226] = Y5339_pgtype90;
	Y5339_gen_type [227] = Y5339_pgtype91;
	Y5339_gen_type [228] = Y5339_pgtype92;
	Y5339_gen_type [229] = Y5339_pgtype93;
	Y5339_gen_type [230] = Y5339_pgtype94;
	Y5339_gen_type [231] = Y5339_pgtype95;
	Y5339_gen_type [232] = Y5339_pgtype96;
	Y5339_gen_type [233] = Y5339_pgtype97;
	Y5339_gen_type [234] = Y5339_pgtype98;
	Y5339_gen_type [235] = Y5339_pgtype99;
	Y5339_gen_type [236] = Y5339_pgtype100;
	Y5339_gen_type [237] = Y5339_pgtype101;
	Y5339_gen_type [238] = Y5339_pgtype102;
	Y5339_gen_type [239] = Y5339_pgtype103;
	Y5339_gen_type [240] = Y5339_pgtype104;
	Y5339_gen_type [241] = Y5339_pgtype105;
	Y5339_gen_type [242] = Y5339_pgtype106;
	Y5339_gen_type [243] = Y5339_pgtype107;
	Y5339_gen_type [244] = Y5339_pgtype108;
	Y5339_gen_type [245] = Y5339_pgtype109;
	Y5339_gen_type [246] = Y5339_pgtype110;
	Y5339_gen_type [247] = Y5339_pgtype111;
	Y5339_gen_type [248] = Y5339_pgtype112;
	Y5339_gen_type [249] = Y5339_pgtype113;
	Y5339_gen_type [250] = Y5339_pgtype114;
	Y5339_gen_type [251] = Y5339_pgtype115;
	Y5339_gen_type [252] = Y5339_pgtype116;
	Y5339_gen_type [253] = Y5339_pgtype117;
	Y5339_gen_type [254] = Y5339_pgtype118;
	Y5339_gen_type [255] = Y5339_pgtype119;
	Y5339_gen_type [256] = Y5339_pgtype120;
	Y5339_gen_type [257] = Y5339_pgtype121;
	Y5339_gen_type [258] = Y5339_pgtype122;
	Y5339_gen_type [259] = Y5339_pgtype123;
	Y5339_gen_type [260] = Y5339_pgtype124;
	Y5339_gen_type [261] = Y5339_pgtype125;
	Y5339_gen_type [262] = Y5339_pgtype126;
	Y5339_gen_type [263] = Y5339_pgtype127;
	Y5339_gen_type [264] = Y5339_pgtype128;
	Y5339_gen_type [265] = Y5339_pgtype129;
	Y5339_gen_type [266] = Y5339_pgtype130;
	Y5339_gen_type [267] = Y5339_pgtype131;
	Y5339_gen_type [268] = Y5339_pgtype132;
	Y5339_gen_type [269] = Y5339_pgtype133;
	Y5339_gen_type [270] = Y5339_pgtype134;
	Y5339_gen_type [271] = Y5339_pgtype135;
	Y5339_gen_type [272] = Y5339_pgtype136;
	Y5339_gen_type [273] = Y5339_pgtype137;
	Y5339_gen_type [274] = Y5339_pgtype138;
	Y5339_gen_type [275] = Y5339_pgtype139;
	Y5339_gen_type [276] = Y5339_pgtype140;
	Y5339_gen_type [277] = Y5339_pgtype141;
	Y5339_gen_type [278] = Y5339_pgtype142;
	Y5339_gen_type [279] = Y5339_pgtype143;
	Y5339_gen_type [280] = Y5339_pgtype144;
	Y5339_gen_type [281] = Y5339_pgtype145;
	Y5339_gen_type [282] = Y5339_pgtype146;
	Y5339_gen_type [283] = Y5339_pgtype147;
	Y5339_gen_type [284] = Y5339_pgtype148;
	Y5339_gen_type [400] = Y5339_pgtype149;
	Y5339_gen_type [401] = Y5339_pgtype150;
	Y5339_gen_type [404] = Y5339_pgtype151;
	Y5339_gen_type [656] = Y5339_pgtype152;
	Y5339_gen_type [657] = Y5339_pgtype153;
	Y5339[180] = 1053;
	{long i; for (i = 181; i < 186; i++) Y5339[i] = 1048;};
	{long i; for (i = 186; i < 285; i++) Y5339[i] = 1190;};
	{long i; for (i = 400; i < 402; i++) Y5339[i] = 1190;};
	Y5339[404] = 1190;
	{long i; for (i = 656; i < 658; i++) Y5339[i] = 1190;};
}

char *(*R5341[545])();
void R5341_init () {
	{long i; for (i = 0; i < 2; i++) R5341[i] = (char *(*)()) F733_6088_5341_1;}
	R5341[41] = (char *(*)()) F775_6158;
	{long i; for (i = 69; i < 71; i++) R5341[i] = (char *(*)()) F802_6214_5341_1;}
	R5341[184] = (char *(*)()) F918_6850;
	R5341[185] = (char *(*)()) F919_6850_5341_1;
	R5341[186] = (char *(*)()) F920_6895;
	R5341[187] = (char *(*)()) F921_6895_5341_1;
	R5341[188] = (char *(*)()) F918_6850;
	R5341[189] = (char *(*)()) F923_6923;
	R5341[190] = (char *(*)()) F924_6923_5341_1;
	R5341[191] = (char *(*)()) F925_6923_5341_1;
	R5341[192] = (char *(*)()) F926_6923_5341_1;
	R5341[193] = (char *(*)()) F927_6923_5341_1;
	R5341[194] = (char *(*)()) F928_6923_5341_1;
	R5341[195] = (char *(*)()) F929_6923_5341_1;
	R5341[196] = (char *(*)()) F930_6923_5341_1;
	R5341[197] = (char *(*)()) F931_6923_5341_1;
	R5341[198] = (char *(*)()) F932_6923_5341_1;
	R5341[199] = (char *(*)()) F933_6923_5341_1;
	R5341[200] = (char *(*)()) F934_6923_5341_1;
	R5341[201] = (char *(*)()) F923_6923;
	R5341[202] = (char *(*)()) F925_6923_5341_1;
	{long i; for (i = 203; i < 205; i++) R5341[i] = (char *(*)()) F923_6923;}
	R5341[490] = (char *(*)()) F802_6214_5341_1;
	R5341[544] = (char *(*)()) F802_6214_5341_1;
}
static EIF_REFERENCE F733_6088_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F733_6088(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_6214_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F802_6214(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F919_6850_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F919_6850(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F921_6895_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F921_6895(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F924_6923_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F924_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F925_6923_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F925_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F926_6923_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F926_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F927_6923_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F927_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F928_6923_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F928_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F929_6923_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F929_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F930_6923_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F930_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1184, 0x00).id, 1184, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F931_6923_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F931_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F932_6923_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F932_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F933_6923_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F933_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F934_6923_5341_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F934_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y5341_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype110[] = {0xFF01,936,0xFFFF};
static EIF_TYPE_INDEX Y5341_pgtype111[] = {0xFF01,1264,0xFFFF};
EIF_TYPE_INDEX *Y5341_gen_type [589];
EIF_TYPE_INDEX Y5341 [589];
void Y5341_init (void)
{
	egc_routines_types [5341] = Y5341;
	egc_routines_gen_types [5341] = Y5341_gen_type;
	egc_routines_offset [5341] = 689;
	Y5341_gen_type [0] = Y5341_pgtype0;
	Y5341_gen_type [1] = Y5341_pgtype1;
	Y5341_gen_type [2] = Y5341_pgtype2;
	Y5341_gen_type [3] = Y5341_pgtype3;
	Y5341_gen_type [4] = Y5341_pgtype4;
	Y5341_gen_type [5] = Y5341_pgtype5;
	Y5341_gen_type [6] = Y5341_pgtype6;
	Y5341_gen_type [7] = Y5341_pgtype7;
	Y5341_gen_type [8] = Y5341_pgtype8;
	Y5341_gen_type [9] = Y5341_pgtype9;
	Y5341_gen_type [10] = Y5341_pgtype10;
	Y5341_gen_type [11] = Y5341_pgtype11;
	Y5341_gen_type [12] = Y5341_pgtype12;
	Y5341_gen_type [13] = Y5341_pgtype13;
	Y5341_gen_type [14] = Y5341_pgtype14;
	Y5341_gen_type [15] = Y5341_pgtype15;
	Y5341_gen_type [16] = Y5341_pgtype16;
	Y5341_gen_type [17] = Y5341_pgtype17;
	Y5341_gen_type [18] = Y5341_pgtype18;
	Y5341_gen_type [19] = Y5341_pgtype19;
	Y5341_gen_type [20] = Y5341_pgtype20;
	Y5341_gen_type [21] = Y5341_pgtype21;
	Y5341_gen_type [22] = Y5341_pgtype22;
	Y5341_gen_type [23] = Y5341_pgtype23;
	Y5341_gen_type [43] = Y5341_pgtype24;
	Y5341_gen_type [82] = Y5341_pgtype25;
	Y5341_gen_type [83] = Y5341_pgtype26;
	Y5341_gen_type [84] = Y5341_pgtype27;
	Y5341_gen_type [85] = Y5341_pgtype28;
	Y5341_gen_type [86] = Y5341_pgtype29;
	Y5341_gen_type [87] = Y5341_pgtype30;
	Y5341_gen_type [88] = Y5341_pgtype31;
	Y5341_gen_type [89] = Y5341_pgtype32;
	Y5341_gen_type [90] = Y5341_pgtype33;
	Y5341_gen_type [91] = Y5341_pgtype34;
	Y5341_gen_type [92] = Y5341_pgtype35;
	Y5341_gen_type [93] = Y5341_pgtype36;
	Y5341_gen_type [94] = Y5341_pgtype37;
	Y5341_gen_type [95] = Y5341_pgtype38;
	Y5341_gen_type [96] = Y5341_pgtype39;
	Y5341_gen_type [97] = Y5341_pgtype40;
	Y5341_gen_type [98] = Y5341_pgtype41;
	Y5341_gen_type [99] = Y5341_pgtype42;
	Y5341_gen_type [180] = Y5341_pgtype43;
	Y5341_gen_type [181] = Y5341_pgtype44;
	Y5341_gen_type [182] = Y5341_pgtype45;
	Y5341_gen_type [183] = Y5341_pgtype46;
	Y5341_gen_type [184] = Y5341_pgtype47;
	Y5341_gen_type [185] = Y5341_pgtype48;
	Y5341_gen_type [186] = Y5341_pgtype49;
	Y5341_gen_type [187] = Y5341_pgtype50;
	Y5341_gen_type [188] = Y5341_pgtype51;
	Y5341_gen_type [189] = Y5341_pgtype52;
	Y5341_gen_type [190] = Y5341_pgtype53;
	Y5341_gen_type [191] = Y5341_pgtype54;
	Y5341_gen_type [192] = Y5341_pgtype55;
	Y5341_gen_type [193] = Y5341_pgtype56;
	Y5341_gen_type [194] = Y5341_pgtype57;
	Y5341_gen_type [195] = Y5341_pgtype58;
	Y5341_gen_type [196] = Y5341_pgtype59;
	Y5341_gen_type [197] = Y5341_pgtype60;
	Y5341_gen_type [198] = Y5341_pgtype61;
	Y5341_gen_type [199] = Y5341_pgtype62;
	Y5341_gen_type [200] = Y5341_pgtype63;
	Y5341_gen_type [201] = Y5341_pgtype64;
	Y5341_gen_type [202] = Y5341_pgtype65;
	Y5341_gen_type [203] = Y5341_pgtype66;
	Y5341_gen_type [204] = Y5341_pgtype67;
	Y5341_gen_type [205] = Y5341_pgtype68;
	Y5341_gen_type [206] = Y5341_pgtype69;
	Y5341_gen_type [207] = Y5341_pgtype70;
	Y5341_gen_type [208] = Y5341_pgtype71;
	Y5341_gen_type [209] = Y5341_pgtype72;
	Y5341_gen_type [210] = Y5341_pgtype73;
	Y5341_gen_type [211] = Y5341_pgtype74;
	Y5341_gen_type [212] = Y5341_pgtype75;
	Y5341_gen_type [213] = Y5341_pgtype76;
	Y5341_gen_type [214] = Y5341_pgtype77;
	Y5341_gen_type [215] = Y5341_pgtype78;
	Y5341_gen_type [216] = Y5341_pgtype79;
	Y5341_gen_type [217] = Y5341_pgtype80;
	Y5341_gen_type [218] = Y5341_pgtype81;
	Y5341_gen_type [219] = Y5341_pgtype82;
	Y5341_gen_type [220] = Y5341_pgtype83;
	Y5341_gen_type [221] = Y5341_pgtype84;
	Y5341_gen_type [222] = Y5341_pgtype85;
	Y5341_gen_type [223] = Y5341_pgtype86;
	Y5341_gen_type [224] = Y5341_pgtype87;
	Y5341_gen_type [225] = Y5341_pgtype88;
	Y5341_gen_type [226] = Y5341_pgtype89;
	Y5341_gen_type [227] = Y5341_pgtype90;
	Y5341_gen_type [228] = Y5341_pgtype91;
	Y5341_gen_type [229] = Y5341_pgtype92;
	Y5341_gen_type [230] = Y5341_pgtype93;
	Y5341_gen_type [231] = Y5341_pgtype94;
	Y5341_gen_type [232] = Y5341_pgtype95;
	Y5341_gen_type [233] = Y5341_pgtype96;
	Y5341_gen_type [234] = Y5341_pgtype97;
	Y5341_gen_type [235] = Y5341_pgtype98;
	Y5341_gen_type [236] = Y5341_pgtype99;
	Y5341_gen_type [237] = Y5341_pgtype100;
	Y5341_gen_type [238] = Y5341_pgtype101;
	Y5341_gen_type [239] = Y5341_pgtype102;
	Y5341_gen_type [240] = Y5341_pgtype103;
	Y5341_gen_type [241] = Y5341_pgtype104;
	Y5341_gen_type [242] = Y5341_pgtype105;
	Y5341_gen_type [243] = Y5341_pgtype106;
	Y5341_gen_type [244] = Y5341_pgtype107;
	Y5341_gen_type [245] = Y5341_pgtype108;
	Y5341_gen_type [246] = Y5341_pgtype109;
	Y5341_gen_type [247] = Y5341_pgtype110;
	Y5341_gen_type [248] = Y5341_pgtype111;
	{long i; for (i = 44; i < 46; i++) Y5341[i] = 1190;};
	{long i; for (i = 112; i < 115; i++) Y5341[i] = 1002;};
	Y5341[247] = 936;
	Y5341[248] = 1264;
	Y5341[534] = 1002;
	{long i; for (i = 580; i < 583; i++) Y5341[i] = 1002;};
	{long i; for (i = 584; i < 589; i++) Y5341[i] = 1002;};
}

char *(*R5346[164])();
void R5346_init () {
	R5346[0] = (char *(*)()) F775_6175;
	R5346[143] = (char *(*)()) F918_6881;
	R5346[144] = (char *(*)()) F919_6881;
	R5346[145] = (char *(*)()) F920_6899;
	R5346[146] = (char *(*)()) F921_6899;
	R5346[147] = (char *(*)()) F918_6881;
	R5346[148] = (char *(*)()) F923_6972;
	R5346[149] = (char *(*)()) F924_6972;
	R5346[150] = (char *(*)()) F925_6972;
	R5346[151] = (char *(*)()) F926_6972;
	R5346[152] = (char *(*)()) F927_6972;
	R5346[153] = (char *(*)()) F928_6972;
	R5346[154] = (char *(*)()) F929_6972;
	R5346[155] = (char *(*)()) F930_6972;
	R5346[156] = (char *(*)()) F931_6972;
	R5346[157] = (char *(*)()) F932_6972;
	R5346[158] = (char *(*)()) F933_6972;
	R5346[159] = (char *(*)()) F934_6972;
	R5346[160] = (char *(*)()) F935_6988;
	R5346[161] = (char *(*)()) F936_6988;
	{long i; for (i = 162; i < 164; i++) R5346[i] = (char *(*)()) F923_6972;}
}

char *(*R5347[21])();
void R5347_init () {
	R5347[0] = (char *(*)()) F918_6854;
	R5347[1] = (char *(*)()) F919_6854;
	R5347[2] = (char *(*)()) F918_6854;
	R5347[3] = (char *(*)()) F919_6854;
	R5347[4] = (char *(*)()) F918_6854;
	R5347[5] = (char *(*)()) F923_6929;
	R5347[6] = (char *(*)()) F924_6929;
	R5347[7] = (char *(*)()) F925_6929;
	R5347[8] = (char *(*)()) F926_6929;
	R5347[9] = (char *(*)()) F927_6929;
	R5347[10] = (char *(*)()) F928_6929;
	R5347[11] = (char *(*)()) F929_6929;
	R5347[12] = (char *(*)()) F930_6929;
	R5347[13] = (char *(*)()) F931_6929;
	R5347[14] = (char *(*)()) F932_6929;
	R5347[15] = (char *(*)()) F933_6929;
	R5347[16] = (char *(*)()) F934_6929;
	R5347[17] = (char *(*)()) F923_6929;
	R5347[18] = (char *(*)()) F925_6929;
	{long i; for (i = 19; i < 21; i++) R5347[i] = (char *(*)()) F923_6929;}
}

static EIF_TYPE_INDEX Y5347_pgtype0[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype1[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype2[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype3[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype4[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype5[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype6[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype7[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype8[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype9[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype10[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype11[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype12[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype13[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype14[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype15[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype16[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype17[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype18[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype19[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype20[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype21[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype22[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype23[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype24[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype25[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype26[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype27[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype28[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype29[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype30[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype31[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype32[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype33[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype34[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype35[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype36[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype37[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype38[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype39[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype40[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype41[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype42[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype43[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype44[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype45[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype46[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype47[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype48[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype49[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype50[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype51[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype52[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype53[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype54[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype55[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype56[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype57[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype58[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype59[] = {0xFF01,295,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype60[] = {0xFF01,298,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype61[] = {0xFF01,299,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype62[] = {0xFF01,298,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype63[] = {0xFF01,299,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype64[] = {0xFF01,298,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype65[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype66[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype67[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype68[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype69[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype70[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype71[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype72[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype73[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype74[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype75[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype76[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype77[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype78[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype79[] = {0xFF01,297,0xFFFF};
static EIF_TYPE_INDEX Y5347_pgtype80[] = {0xFF01,297,0xFFFF};
EIF_TYPE_INDEX *Y5347_gen_type [237];
EIF_TYPE_INDEX Y5347 [237];
void Y5347_init (void)
{
	egc_routines_types [5347] = Y5347;
	egc_routines_gen_types [5347] = Y5347_gen_type;
	egc_routines_offset [5347] = 701;
	Y5347_gen_type [0] = Y5347_pgtype0;
	Y5347_gen_type [1] = Y5347_pgtype1;
	Y5347_gen_type [2] = Y5347_pgtype2;
	Y5347_gen_type [3] = Y5347_pgtype3;
	Y5347_gen_type [4] = Y5347_pgtype4;
	Y5347_gen_type [5] = Y5347_pgtype5;
	Y5347_gen_type [6] = Y5347_pgtype6;
	Y5347_gen_type [7] = Y5347_pgtype7;
	Y5347_gen_type [8] = Y5347_pgtype8;
	Y5347_gen_type [9] = Y5347_pgtype9;
	Y5347_gen_type [10] = Y5347_pgtype10;
	Y5347_gen_type [11] = Y5347_pgtype11;
	Y5347_gen_type [168] = Y5347_pgtype12;
	Y5347_gen_type [169] = Y5347_pgtype13;
	Y5347_gen_type [170] = Y5347_pgtype14;
	Y5347_gen_type [171] = Y5347_pgtype15;
	Y5347_gen_type [172] = Y5347_pgtype16;
	Y5347_gen_type [173] = Y5347_pgtype17;
	Y5347_gen_type [174] = Y5347_pgtype18;
	Y5347_gen_type [175] = Y5347_pgtype19;
	Y5347_gen_type [176] = Y5347_pgtype20;
	Y5347_gen_type [177] = Y5347_pgtype21;
	Y5347_gen_type [178] = Y5347_pgtype22;
	Y5347_gen_type [179] = Y5347_pgtype23;
	Y5347_gen_type [180] = Y5347_pgtype24;
	Y5347_gen_type [181] = Y5347_pgtype25;
	Y5347_gen_type [182] = Y5347_pgtype26;
	Y5347_gen_type [183] = Y5347_pgtype27;
	Y5347_gen_type [184] = Y5347_pgtype28;
	Y5347_gen_type [185] = Y5347_pgtype29;
	Y5347_gen_type [186] = Y5347_pgtype30;
	Y5347_gen_type [187] = Y5347_pgtype31;
	Y5347_gen_type [188] = Y5347_pgtype32;
	Y5347_gen_type [189] = Y5347_pgtype33;
	Y5347_gen_type [190] = Y5347_pgtype34;
	Y5347_gen_type [191] = Y5347_pgtype35;
	Y5347_gen_type [192] = Y5347_pgtype36;
	Y5347_gen_type [193] = Y5347_pgtype37;
	Y5347_gen_type [194] = Y5347_pgtype38;
	Y5347_gen_type [195] = Y5347_pgtype39;
	Y5347_gen_type [196] = Y5347_pgtype40;
	Y5347_gen_type [197] = Y5347_pgtype41;
	Y5347_gen_type [198] = Y5347_pgtype42;
	Y5347_gen_type [199] = Y5347_pgtype43;
	Y5347_gen_type [200] = Y5347_pgtype44;
	Y5347_gen_type [201] = Y5347_pgtype45;
	Y5347_gen_type [202] = Y5347_pgtype46;
	Y5347_gen_type [203] = Y5347_pgtype47;
	Y5347_gen_type [204] = Y5347_pgtype48;
	Y5347_gen_type [205] = Y5347_pgtype49;
	Y5347_gen_type [206] = Y5347_pgtype50;
	Y5347_gen_type [207] = Y5347_pgtype51;
	Y5347_gen_type [208] = Y5347_pgtype52;
	Y5347_gen_type [209] = Y5347_pgtype53;
	Y5347_gen_type [210] = Y5347_pgtype54;
	Y5347_gen_type [211] = Y5347_pgtype55;
	Y5347_gen_type [212] = Y5347_pgtype56;
	Y5347_gen_type [213] = Y5347_pgtype57;
	Y5347_gen_type [214] = Y5347_pgtype58;
	Y5347_gen_type [215] = Y5347_pgtype59;
	Y5347_gen_type [216] = Y5347_pgtype60;
	Y5347_gen_type [217] = Y5347_pgtype61;
	Y5347_gen_type [218] = Y5347_pgtype62;
	Y5347_gen_type [219] = Y5347_pgtype63;
	Y5347_gen_type [220] = Y5347_pgtype64;
	Y5347_gen_type [221] = Y5347_pgtype65;
	Y5347_gen_type [222] = Y5347_pgtype66;
	Y5347_gen_type [223] = Y5347_pgtype67;
	Y5347_gen_type [224] = Y5347_pgtype68;
	Y5347_gen_type [225] = Y5347_pgtype69;
	Y5347_gen_type [226] = Y5347_pgtype70;
	Y5347_gen_type [227] = Y5347_pgtype71;
	Y5347_gen_type [228] = Y5347_pgtype72;
	Y5347_gen_type [229] = Y5347_pgtype73;
	Y5347_gen_type [230] = Y5347_pgtype74;
	Y5347_gen_type [231] = Y5347_pgtype75;
	Y5347_gen_type [232] = Y5347_pgtype76;
	Y5347_gen_type [233] = Y5347_pgtype77;
	Y5347_gen_type [234] = Y5347_pgtype78;
	Y5347_gen_type [235] = Y5347_pgtype79;
	Y5347_gen_type [236] = Y5347_pgtype80;
	{long i; for (i = 0; i < 12; i++) Y5347[i] = 295;};
	{long i; for (i = 168; i < 216; i++) Y5347[i] = 295;};
	Y5347[216] = 298;
	Y5347[217] = 299;
	Y5347[218] = 298;
	Y5347[219] = 299;
	Y5347[220] = 298;
	{long i; for (i = 221; i < 237; i++) Y5347[i] = 297;};
}

char *(*R5349[21])();
void R5349_init () {
	R5349[0] = (char *(*)()) F918_6873;
	R5349[1] = (char *(*)()) F919_6873;
	R5349[2] = (char *(*)()) F918_6873;
	R5349[3] = (char *(*)()) F919_6873;
	R5349[4] = (char *(*)()) F918_6873;
	R5349[5] = (char *(*)()) F923_6954;
	R5349[6] = (char *(*)()) F924_6954;
	R5349[7] = (char *(*)()) F925_6954;
	R5349[8] = (char *(*)()) F926_6954;
	R5349[9] = (char *(*)()) F927_6954;
	R5349[10] = (char *(*)()) F928_6954;
	R5349[11] = (char *(*)()) F929_6954;
	R5349[12] = (char *(*)()) F930_6954;
	R5349[13] = (char *(*)()) F931_6954;
	R5349[14] = (char *(*)()) F932_6954;
	R5349[15] = (char *(*)()) F933_6954;
	R5349[16] = (char *(*)()) F934_6954;
	R5349[17] = (char *(*)()) F923_6954;
	R5349[18] = (char *(*)()) F925_6954;
	{long i; for (i = 19; i < 21; i++) R5349[i] = (char *(*)()) F923_6954;}
}

char *(*R5375[2])();
void R5375_init () {
	R5375[0] = (char *(*)()) F734_6114;
	R5375[1] = (char *(*)()) F735_6133;
}

char *(*R5404[536])();
void R5404_init () {
	R5404[0] = (char *(*)()) F775_6162;
	{long i; for (i = 28; i < 30; i++) R5404[i] = (char *(*)()) F802_6232;}
	R5404[51] = (char *(*)()) F826_6586;
	R5404[52] = (char *(*)()) F827_6586;
	R5404[53] = (char *(*)()) F828_6586;
	R5404[54] = (char *(*)()) F829_6586;
	R5404[55] = (char *(*)()) F830_6586;
	R5404[56] = (char *(*)()) F831_6586;
	R5404[57] = (char *(*)()) F832_6586;
	R5404[58] = (char *(*)()) F833_6586;
	{long i; for (i = 59; i < 61; i++) R5404[i] = (char *(*)()) F826_6586;}
	R5404[61] = (char *(*)()) F828_6586;
	R5404[62] = (char *(*)()) F829_6586;
	R5404[63] = (char *(*)()) F831_6586;
	R5404[64] = (char *(*)()) F832_6586;
	R5404[77] = (char *(*)()) F852_6711;
	R5404[78] = (char *(*)()) F853_6751;
	R5404[79] = (char *(*)()) F854_6751;
	R5404[80] = (char *(*)()) F855_6751;
	R5404[81] = (char *(*)()) F856_6751;
	R5404[82] = (char *(*)()) F857_6751;
	R5404[83] = (char *(*)()) F858_6751;
	R5404[84] = (char *(*)()) F859_6751;
	R5404[85] = (char *(*)()) F860_6751;
	R5404[86] = (char *(*)()) F861_6751;
	R5404[87] = (char *(*)()) F862_6751;
	R5404[88] = (char *(*)()) F863_6751;
	R5404[89] = (char *(*)()) F864_6751;
	R5404[143] = (char *(*)()) F918_6857;
	R5404[144] = (char *(*)()) F919_6857;
	R5404[145] = (char *(*)()) F918_6857;
	R5404[146] = (char *(*)()) F919_6857;
	R5404[147] = (char *(*)()) F918_6857;
	R5404[148] = (char *(*)()) F923_6939;
	R5404[149] = (char *(*)()) F924_6939;
	R5404[150] = (char *(*)()) F925_6939;
	R5404[151] = (char *(*)()) F926_6939;
	R5404[152] = (char *(*)()) F927_6939;
	R5404[153] = (char *(*)()) F928_6939;
	R5404[154] = (char *(*)()) F929_6939;
	R5404[155] = (char *(*)()) F930_6939;
	R5404[156] = (char *(*)()) F931_6939;
	R5404[157] = (char *(*)()) F932_6939;
	R5404[158] = (char *(*)()) F933_6939;
	R5404[159] = (char *(*)()) F934_6939;
	R5404[160] = (char *(*)()) F923_6939;
	R5404[161] = (char *(*)()) F925_6939;
	{long i; for (i = 162; i < 164; i++) R5404[i] = (char *(*)()) F923_6939;}
	R5404[279] = (char *(*)()) F1052_8126;
	R5404[283] = (char *(*)()) F1056_8291;
	R5404[449] = (char *(*)()) F1224_10405;
	R5404[503] = (char *(*)()) F802_6232;
	R5404[535] = (char *(*)()) F1310_13028;
}

char *(*R5405[536])();
void R5405_init () {
	R5405[0] = (char *(*)()) F775_6163;
	R5405[77] = (char *(*)()) F852_6710;
	R5405[78] = (char *(*)()) F853_6752;
	R5405[79] = (char *(*)()) F854_6752;
	R5405[80] = (char *(*)()) F855_6752;
	R5405[81] = (char *(*)()) F856_6752;
	R5405[82] = (char *(*)()) F857_6752;
	R5405[83] = (char *(*)()) F858_6752;
	R5405[84] = (char *(*)()) F859_6752;
	R5405[85] = (char *(*)()) F860_6752;
	R5405[86] = (char *(*)()) F861_6752;
	R5405[87] = (char *(*)()) F862_6752;
	R5405[88] = (char *(*)()) F863_6752;
	R5405[89] = (char *(*)()) F864_6752;
	R5405[148] = (char *(*)()) F923_6940;
	R5405[149] = (char *(*)()) F924_6940;
	R5405[150] = (char *(*)()) F925_6940;
	R5405[151] = (char *(*)()) F926_6940;
	R5405[152] = (char *(*)()) F927_6940;
	R5405[153] = (char *(*)()) F928_6940;
	R5405[154] = (char *(*)()) F929_6940;
	R5405[155] = (char *(*)()) F930_6940;
	R5405[156] = (char *(*)()) F931_6940;
	R5405[157] = (char *(*)()) F932_6940;
	R5405[158] = (char *(*)()) F933_6940;
	R5405[159] = (char *(*)()) F934_6940;
	R5405[160] = (char *(*)()) F923_6940;
	R5405[161] = (char *(*)()) F925_6940;
	{long i; for (i = 162; i < 164; i++) R5405[i] = (char *(*)()) F923_6940;}
	R5405[279] = (char *(*)()) F1052_8125;
	R5405[283] = (char *(*)()) F1056_8290;
	R5405[535] = (char *(*)()) F1310_13030;
}

char *(*R5409[536])();
void R5409_init () {
	R5409[0] = (char *(*)()) F760_6145;
	R5409[77] = (char *(*)()) F762_6145;
	R5409[78] = (char *(*)()) F760_6145;
	R5409[79] = (char *(*)()) F761_6145;
	R5409[80] = (char *(*)()) F762_6145;
	R5409[81] = (char *(*)()) F763_6145;
	R5409[82] = (char *(*)()) F764_6145;
	R5409[83] = (char *(*)()) F765_6145;
	R5409[84] = (char *(*)()) F766_6145;
	R5409[85] = (char *(*)()) F767_6145;
	R5409[86] = (char *(*)()) F768_6145;
	R5409[87] = (char *(*)()) F769_6145;
	R5409[88] = (char *(*)()) F770_6145;
	R5409[89] = (char *(*)()) F771_6145;
	R5409[148] = (char *(*)()) F760_6145;
	R5409[149] = (char *(*)()) F761_6145;
	R5409[150] = (char *(*)()) F762_6145;
	R5409[151] = (char *(*)()) F763_6145;
	R5409[152] = (char *(*)()) F764_6145;
	R5409[153] = (char *(*)()) F765_6145;
	R5409[154] = (char *(*)()) F766_6145;
	R5409[155] = (char *(*)()) F767_6145;
	R5409[156] = (char *(*)()) F768_6145;
	R5409[157] = (char *(*)()) F769_6145;
	R5409[158] = (char *(*)()) F770_6145;
	R5409[159] = (char *(*)()) F771_6145;
	R5409[160] = (char *(*)()) F760_6145;
	R5409[161] = (char *(*)()) F762_6145;
	{long i; for (i = 162; i < 164; i++) R5409[i] = (char *(*)()) F760_6145;}
	R5409[279] = (char *(*)()) F768_6145;
	R5409[283] = (char *(*)()) F765_6145;
	R5409[535] = (char *(*)()) F768_6145;
}

char *(*R5411[536])();
void R5411_init () {
	R5411[0] = (char *(*)()) F775_6185;
	R5411[77] = (char *(*)()) F852_6721;
	R5411[78] = (char *(*)()) F853_6782;
	R5411[79] = (char *(*)()) F854_6782;
	R5411[80] = (char *(*)()) F855_6782;
	R5411[81] = (char *(*)()) F856_6782;
	R5411[82] = (char *(*)()) F857_6782;
	R5411[83] = (char *(*)()) F858_6782;
	R5411[84] = (char *(*)()) F859_6782;
	R5411[85] = (char *(*)()) F860_6782;
	R5411[86] = (char *(*)()) F861_6782;
	R5411[87] = (char *(*)()) F862_6782;
	R5411[88] = (char *(*)()) F863_6782;
	R5411[89] = (char *(*)()) F864_6782;
	R5411[148] = (char *(*)()) F923_6966;
	R5411[149] = (char *(*)()) F924_6966;
	R5411[150] = (char *(*)()) F925_6966;
	R5411[151] = (char *(*)()) F926_6966;
	R5411[152] = (char *(*)()) F927_6966;
	R5411[153] = (char *(*)()) F928_6966;
	R5411[154] = (char *(*)()) F929_6966;
	R5411[155] = (char *(*)()) F930_6966;
	R5411[156] = (char *(*)()) F931_6966;
	R5411[157] = (char *(*)()) F932_6966;
	R5411[158] = (char *(*)()) F933_6966;
	R5411[159] = (char *(*)()) F934_6966;
	R5411[160] = (char *(*)()) F923_6966;
	R5411[161] = (char *(*)()) F925_6966;
	{long i; for (i = 162; i < 164; i++) R5411[i] = (char *(*)()) F923_6966;}
	R5411[279] = (char *(*)()) F1054_8250;
	R5411[283] = (char *(*)()) F1058_8418;
	R5411[535] = (char *(*)()) F1054_8250;
}

char *(*R5425[476])();
void R5425_init () {
	{long i; for (i = 0; i < 2; i++) R5425[i] = (char *(*)()) F786_6196_5425_4;}
	R5425[115] = (char *(*)()) F778_6196;
	R5425[116] = (char *(*)()) F780_6196_5425_4;
	R5425[117] = (char *(*)()) F920_6896;
	R5425[118] = (char *(*)()) F921_6896_5425_4;
	R5425[119] = (char *(*)()) F778_6196;
	R5425[120] = (char *(*)()) F923_6958;
	R5425[121] = (char *(*)()) F924_6958_5425_4;
	R5425[122] = (char *(*)()) F925_6958_5425_4;
	R5425[123] = (char *(*)()) F926_6958_5425_4;
	R5425[124] = (char *(*)()) F927_6958_5425_4;
	R5425[125] = (char *(*)()) F928_6958_5425_4;
	R5425[126] = (char *(*)()) F929_6958_5425_4;
	R5425[127] = (char *(*)()) F930_6958_5425_4;
	R5425[128] = (char *(*)()) F931_6958_5425_4;
	R5425[129] = (char *(*)()) F932_6958_5425_4;
	R5425[130] = (char *(*)()) F933_6958_5425_4;
	R5425[131] = (char *(*)()) F934_6958_5425_4;
	R5425[132] = (char *(*)()) F923_6958;
	R5425[133] = (char *(*)()) F925_6958_5425_4;
	{long i; for (i = 134; i < 136; i++) R5425[i] = (char *(*)()) F923_6958;}
	R5425[421] = (char *(*)()) F786_6196_5425_4;
	R5425[475] = (char *(*)()) F786_6196_5425_4;
}
static void F786_6196_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F786_6196(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F780_6196_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F780_6196(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F921_6896_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F921_6896(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F924_6958_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F924_6958(Current, *(EIF_BOOLEAN *)arg1);
}
static void F925_6958_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F925_6958(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F926_6958_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F926_6958(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F927_6958_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F927_6958(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F928_6958_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F928_6958(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F929_6958_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F929_6958(Current, *(EIF_REAL_32 *)arg1);
}
static void F930_6958_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F930_6958(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F931_6958_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F931_6958(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F932_6958_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F932_6958(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F933_6958_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F933_6958(Current, *(EIF_POINTER *)arg1);
}
static void F934_6958_5425_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F934_6958(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R5426[21])();
void R5426_init () {
	R5426[0] = (char *(*)()) F870_6817;
	R5426[1] = (char *(*)()) F872_6817;
	R5426[2] = (char *(*)()) F772_6152;
	R5426[3] = (char *(*)()) F773_6152;
	R5426[4] = (char *(*)()) F870_6817;
	R5426[5] = (char *(*)()) F923_6965;
	R5426[6] = (char *(*)()) F924_6965;
	R5426[7] = (char *(*)()) F925_6965;
	R5426[8] = (char *(*)()) F926_6965;
	R5426[9] = (char *(*)()) F927_6965;
	R5426[10] = (char *(*)()) F928_6965;
	R5426[11] = (char *(*)()) F929_6965;
	R5426[12] = (char *(*)()) F930_6965;
	R5426[13] = (char *(*)()) F931_6965;
	R5426[14] = (char *(*)()) F932_6965;
	R5426[15] = (char *(*)()) F933_6965;
	R5426[16] = (char *(*)()) F934_6965;
	R5426[17] = (char *(*)()) F772_6152;
	R5426[18] = (char *(*)()) F773_6152;
	{long i; for (i = 19; i < 21; i++) R5426[i] = (char *(*)()) F923_6965;}
}

char *(*R5428[476])();
void R5428_init () {
	R5428[0] = (char *(*)()) F803_6430;
	R5428[1] = (char *(*)()) F802_6202;
	R5428[421] = (char *(*)()) F803_6430;
	R5428[475] = (char *(*)()) F1278_12058;
}

char *(*R5429[476])();
void R5429_init () {
	R5429[0] = (char *(*)()) F803_6431;
	R5429[1] = (char *(*)()) F802_6203;
	R5429[421] = (char *(*)()) F803_6431;
	R5429[475] = (char *(*)()) F1278_12059;
}

char *(*R5453[476])();
void R5453_init () {
	{long i; for (i = 0; i < 2; i++) R5453[i] = (char *(*)()) F802_6236;}
	R5453[421] = (char *(*)()) F1224_10403;
	R5453[475] = (char *(*)()) F802_6236;
}

char *(*R5473[476])();
void R5473_init () {
	{long i; for (i = 0; i < 2; i++) R5473[i] = (char *(*)()) F802_6260;}
	R5473[421] = (char *(*)()) F802_6260;
	R5473[475] = (char *(*)()) F1273_12034;
}

char *(*R5478[476])();
void R5478_init () {
	{long i; for (i = 0; i < 2; i++) R5478[i] = (char *(*)()) F802_6272;}
	R5478[421] = (char *(*)()) F802_6272;
	R5478[475] = (char *(*)()) F1275_12051;
}

char *(*R5522[476])();
void R5522_init () {
	R5522[0] = (char *(*)()) F802_6360;
	R5522[1] = (char *(*)()) F804_6541;
	R5522[421] = (char *(*)()) F802_6360;
	R5522[475] = (char *(*)()) F804_6541;
}

char *(*R5523[476])();
void R5523_init () {
	{long i; for (i = 0; i < 2; i++) R5523[i] = (char *(*)()) F802_6361;}
	R5523[421] = (char *(*)()) F1224_10459;
	R5523[475] = (char *(*)()) F802_6361;
}

char *(*R5595[422])();
void R5595_init () {
	R5595[0] = (char *(*)()) F803_6476;
	R5595[421] = (char *(*)()) F1224_10401;
}

char *(*R5601[422])();
void R5601_init () {
	R5601[0] = (char *(*)()) F803_6482;
	R5601[421] = (char *(*)()) F1224_10439;
}


#ifdef __cplusplus
}
#endif
