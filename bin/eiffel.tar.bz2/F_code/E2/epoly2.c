#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R3264[675])();
void R3264_init () {
	R3264[0] = (char *(*)()) F279_3508;
	R3264[7] = (char *(*)()) F286_3651;
	R3264[8] = (char *(*)()) F287_3674;
	R3264[103] = (char *(*)()) F382_4556;
	R3264[674] = (char *(*)()) F953_7085;
}

char *(*R3265[675])();
void R3265_init () {
	R3265[0] = (char *(*)()) F279_3509;
	R3265[7] = (char *(*)()) F286_3652;
	R3265[8] = (char *(*)()) F281_3524;
	R3265[103] = (char *(*)()) F279_3509;
	R3265[674] = (char *(*)()) F953_7086;
}

char *(*R3422[775])();
void R3422_init () {
	R3422[0] = (char *(*)()) F290_3726;
	R3422[773] = (char *(*)()) F1064_8552;
	R3422[774] = (char *(*)()) F1065_8580;
}

char *(*R3423[775])();
void R3423_init () {
	R3423[0] = (char *(*)()) F290_3727;
	R3423[773] = (char *(*)()) F1064_8556;
	R3423[774] = (char *(*)()) F1065_8582;
}

char *(*R3425[775])();
void R3425_init () {
	R3425[0] = (char *(*)()) F290_3729;
	R3425[773] = (char *(*)()) F1064_8558;
	R3425[774] = (char *(*)()) F1065_8584;
}

char *(*R3426[775])();
void R3426_init () {
	R3426[0] = (char *(*)()) F290_3730;
	R3426[773] = (char *(*)()) F1064_8559;
	R3426[774] = (char *(*)()) F1065_8585;
}

char *(*R3427[775])();
void R3427_init () {
	R3427[0] = (char *(*)()) F290_3731;
	R3427[773] = (char *(*)()) F1064_8560;
	R3427[774] = (char *(*)()) F1065_8586;
}

char *(*R3428[775])();
void R3428_init () {
	R3428[0] = (char *(*)()) F291_3735;
	{long i; for (i = 773; i < 775; i++) R3428[i] = (char *(*)()) F292_3738;}
}

char *(*R3429[775])();
void R3429_init () {
	R3429[0] = (char *(*)()) F291_3736;
	{long i; for (i = 773; i < 775; i++) R3429[i] = (char *(*)()) F292_3740;}
}

char *(*R3447[2])();
void R3447_init () {
	R3447[0] = (char *(*)()) F1064_8561;
	R3447[1] = (char *(*)()) F1065_8587;
}

char *(*R3448[2])();
void R3448_init () {
	R3448[0] = (char *(*)()) F1064_8567;
	R3448[1] = (char *(*)()) F1065_8589;
}

char *(*R3466[2])();
void R3466_init () {
	R3466[0] = (char *(*)()) F299_3759;
	R3466[1] = (char *(*)()) F300_3759;
}

char *(*R3505[41])();
void R3505_init () {
	R3505[0] = (char *(*)()) F303_3797;
	R3505[3] = (char *(*)()) F306_3821;
	R3505[5] = (char *(*)()) F308_3825;
	R3505[6] = (char *(*)()) F309_3842;
	R3505[7] = (char *(*)()) F310_3846;
	{long i; for (i = 8; i < 11; i++) R3505[i] = (char *(*)()) F311_3850;}
	R3505[12] = (char *(*)()) F315_3854;
	R3505[13] = (char *(*)()) F316_3856;
	R3505[14] = (char *(*)()) F317_3858;
	R3505[16] = (char *(*)()) F319_3860;
	R3505[17] = (char *(*)()) F320_3862;
	R3505[20] = (char *(*)()) F323_3866;
	R3505[21] = (char *(*)()) F324_3870;
	R3505[23] = (char *(*)()) F326_3872;
	R3505[24] = (char *(*)()) F327_3874;
	R3505[25] = (char *(*)()) F328_3876;
	R3505[27] = (char *(*)()) F330_3882;
	R3505[28] = (char *(*)()) F331_3884;
	R3505[29] = (char *(*)()) F332_3888;
	R3505[30] = (char *(*)()) F333_3892;
	R3505[32] = (char *(*)()) F335_3894;
	R3505[33] = (char *(*)()) F336_3896;
	R3505[35] = (char *(*)()) F338_3898;
	R3505[36] = (char *(*)()) F339_3900;
	R3505[37] = (char *(*)()) F340_3902;
	R3505[38] = (char *(*)()) F341_3904;
	R3505[39] = (char *(*)()) F342_3906;
	R3505[40] = (char *(*)()) F343_3908;
}

char *(*R3574[180])();
void R3574_init () {
	R3574[0] = (char *(*)()) F1072_8889;
	R3574[52] = (char *(*)()) F1124_9169;
	R3574[53] = (char *(*)()) F1125_9178;
	R3574[54] = (char *(*)()) F1126_9187;
	R3574[56] = (char *(*)()) F1128_9221;
	R3574[57] = (char *(*)()) F1129_9237;
	R3574[58] = (char *(*)()) F1130_9244;
	R3574[179] = (char *(*)()) F1251_11090;
}

char *(*R3575[953])();
void R3575_init () {
	R3575[0] = (char *(*)()) F358_4075;
	{long i; for (i = 4; i < 7; i++) R3575[i] = (char *(*)()) F361_4100;}
	{long i; for (i = 8; i < 12; i++) R3575[i] = (char *(*)()) F361_4100;}
	{long i; for (i = 644; i < 646; i++) R3575[i] = (char *(*)()) F1001_7785;}
	{long i; for (i = 650; i < 652; i++) R3575[i] = (char *(*)()) F1007_7856;}
	{long i; for (i = 695; i < 697; i++) R3575[i] = (char *(*)()) F1052_8134;}
	{long i; for (i = 699; i < 701; i++) R3575[i] = (char *(*)()) F1056_8299;}
	R3575[712] = (char *(*)()) F1070_8708;
	R3575[713] = (char *(*)()) F1071_8761;
	R3575[715] = (char *(*)()) F1073_8945;
	{long i; for (i = 766; i < 769; i++) R3575[i] = (char *(*)()) F1121_9094;}
	{long i; for (i = 770; i < 773; i++) R3575[i] = (char *(*)()) F1121_9094;}
	R3575[826] = (char *(*)()) F1184_9465_3575_2;
	R3575[827] = (char *(*)()) F1185_9465_3575_2;
	R3575[829] = (char *(*)()) F1187_9562_3575_2;
	R3575[830] = (char *(*)()) F1188_9562_3575_2;
	R3575[832] = (char *(*)()) F1190_9661_3575_2;
	R3575[833] = (char *(*)()) F1191_9661_3575_2;
	R3575[835] = (char *(*)()) F1193_9760_3575_2;
	R3575[836] = (char *(*)()) F1194_9760_3575_2;
	R3575[838] = (char *(*)()) F1196_9859_3575_2;
	R3575[839] = (char *(*)()) F1197_9859_3575_2;
	R3575[841] = (char *(*)()) F1199_9954_3575_2;
	R3575[842] = (char *(*)()) F1200_9954_3575_2;
	R3575[844] = (char *(*)()) F1202_10049_3575_2;
	R3575[845] = (char *(*)()) F1203_10049_3575_2;
	R3575[847] = (char *(*)()) F1205_10144_3575_2;
	R3575[848] = (char *(*)()) F1206_10144_3575_2;
	R3575[850] = (char *(*)()) F1208_10213_3575_2;
	R3575[851] = (char *(*)()) F1209_10213_3575_2;
	R3575[853] = (char *(*)()) F1211_10279_3575_2;
	R3575[854] = (char *(*)()) F1212_10279_3575_2;
	R3575[870] = (char *(*)()) F1228_10553;
	R3575[952] = (char *(*)()) F1310_13039;
}
static EIF_BOOLEAN F1184_9465_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1184_9465(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1185_9465_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1185_9465(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1187_9562_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1187_9562(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1188_9562_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1188_9562(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1190_9661_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1190_9661(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1191_9661_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1191_9661(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1193_9760_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1193_9760(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1194_9760_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1194_9760(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1196_9859_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1196_9859(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1197_9859_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1197_9859(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1199_9954_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1199_9954(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1200_9954_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1200_9954(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1202_10049_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1202_10049(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1203_10049_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1203_10049(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1205_10144_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1205_10144(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1206_10144_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1206_10144(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1208_10213_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1208_10213(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1209_10213_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1209_10213(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1211_10279_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1211_10279(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1212_10279_3575_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1212_10279(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R4393[7])();
void R4393_init () {
	R4393[0] = (char *(*)()) F391_4864;
	{long i; for (i = 1; i < 7; i++) R4393[i] = (char *(*)()) F390_4849;}
}

char *(*R4406[893])();
void R4406_init () {
	R4406[0] = (char *(*)()) F407_4871;
	R4406[435] = (char *(*)()) F398_4871;
	R4406[436] = (char *(*)()) F399_4871;
	R4406[437] = (char *(*)()) F400_4871;
	R4406[438] = (char *(*)()) F401_4871;
	R4406[439] = (char *(*)()) F402_4871;
	R4406[440] = (char *(*)()) F403_4871;
	R4406[441] = (char *(*)()) F404_4871;
	R4406[442] = (char *(*)()) F405_4871;
	R4406[443] = (char *(*)()) F406_4871;
	R4406[444] = (char *(*)()) F407_4871;
	R4406[445] = (char *(*)()) F408_4871;
	R4406[446] = (char *(*)()) F409_4871;
	R4406[505] = (char *(*)()) F398_4871;
	R4406[506] = (char *(*)()) F399_4871;
	R4406[507] = (char *(*)()) F400_4871;
	R4406[508] = (char *(*)()) F401_4871;
	R4406[509] = (char *(*)()) F402_4871;
	R4406[510] = (char *(*)()) F403_4871;
	R4406[511] = (char *(*)()) F404_4871;
	R4406[512] = (char *(*)()) F405_4871;
	R4406[513] = (char *(*)()) F406_4871;
	R4406[514] = (char *(*)()) F407_4871;
	R4406[515] = (char *(*)()) F408_4871;
	R4406[516] = (char *(*)()) F409_4871;
	R4406[517] = (char *(*)()) F398_4871;
	R4406[518] = (char *(*)()) F400_4871;
	{long i; for (i = 519; i < 521; i++) R4406[i] = (char *(*)()) F398_4871;}
	R4406[636] = (char *(*)()) F406_4871;
	R4406[640] = (char *(*)()) F403_4871;
	R4406[892] = (char *(*)()) F406_4871;
}

char *(*R4407[893])();
void R4407_init () {
	R4407[0] = (char *(*)()) F407_4872_4407_147;
	R4407[435] = (char *(*)()) F398_4872;
	R4407[436] = (char *(*)()) F399_4872_4407_147;
	R4407[437] = (char *(*)()) F400_4872_4407_147;
	R4407[438] = (char *(*)()) F401_4872_4407_147;
	R4407[439] = (char *(*)()) F402_4872_4407_147;
	R4407[440] = (char *(*)()) F403_4872_4407_147;
	R4407[441] = (char *(*)()) F404_4872_4407_147;
	R4407[442] = (char *(*)()) F405_4872_4407_147;
	R4407[443] = (char *(*)()) F406_4872_4407_147;
	R4407[444] = (char *(*)()) F407_4872_4407_147;
	R4407[445] = (char *(*)()) F408_4872_4407_147;
	R4407[446] = (char *(*)()) F409_4872_4407_147;
	R4407[505] = (char *(*)()) F398_4872;
	R4407[506] = (char *(*)()) F399_4872_4407_147;
	R4407[507] = (char *(*)()) F400_4872_4407_147;
	R4407[508] = (char *(*)()) F401_4872_4407_147;
	R4407[509] = (char *(*)()) F402_4872_4407_147;
	R4407[510] = (char *(*)()) F403_4872_4407_147;
	R4407[511] = (char *(*)()) F404_4872_4407_147;
	R4407[512] = (char *(*)()) F405_4872_4407_147;
	R4407[513] = (char *(*)()) F406_4872_4407_147;
	R4407[514] = (char *(*)()) F407_4872_4407_147;
	R4407[515] = (char *(*)()) F408_4872_4407_147;
	R4407[516] = (char *(*)()) F409_4872_4407_147;
	R4407[517] = (char *(*)()) F398_4872;
	R4407[518] = (char *(*)()) F400_4872_4407_147;
	{long i; for (i = 519; i < 521; i++) R4407[i] = (char *(*)()) F398_4872;}
	R4407[636] = (char *(*)()) F406_4872_4407_147;
	R4407[640] = (char *(*)()) F403_4872_4407_147;
	R4407[892] = (char *(*)()) F406_4872_4407_147;
}
static void F407_4872_4407_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F407_4872(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F399_4872_4407_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F399_4872(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F400_4872_4407_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F400_4872(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F401_4872_4407_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F401_4872(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F402_4872_4407_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F402_4872(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F403_4872_4407_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F403_4872(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F404_4872_4407_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F404_4872(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F405_4872_4407_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F405_4872(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F406_4872_4407_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F406_4872(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F408_4872_4407_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F408_4872(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F409_4872_4407_147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F409_4872(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4413[893])();
void R4413_init () {
	R4413[0] = (char *(*)()) F407_4878;
	R4413[435] = (char *(*)()) F398_4878;
	R4413[436] = (char *(*)()) F399_4878;
	R4413[437] = (char *(*)()) F400_4878;
	R4413[438] = (char *(*)()) F401_4878;
	R4413[439] = (char *(*)()) F402_4878;
	R4413[440] = (char *(*)()) F403_4878;
	R4413[441] = (char *(*)()) F404_4878;
	R4413[442] = (char *(*)()) F405_4878;
	R4413[443] = (char *(*)()) F406_4878;
	R4413[444] = (char *(*)()) F407_4878;
	R4413[445] = (char *(*)()) F408_4878;
	R4413[446] = (char *(*)()) F409_4878;
	R4413[505] = (char *(*)()) F398_4878;
	R4413[506] = (char *(*)()) F399_4878;
	R4413[507] = (char *(*)()) F400_4878;
	R4413[508] = (char *(*)()) F401_4878;
	R4413[509] = (char *(*)()) F402_4878;
	R4413[510] = (char *(*)()) F403_4878;
	R4413[511] = (char *(*)()) F404_4878;
	R4413[512] = (char *(*)()) F405_4878;
	R4413[513] = (char *(*)()) F406_4878;
	R4413[514] = (char *(*)()) F407_4878;
	R4413[515] = (char *(*)()) F408_4878;
	R4413[516] = (char *(*)()) F409_4878;
	R4413[517] = (char *(*)()) F398_4878;
	R4413[518] = (char *(*)()) F400_4878;
	{long i; for (i = 519; i < 521; i++) R4413[i] = (char *(*)()) F398_4878;}
	R4413[636] = (char *(*)()) F406_4878;
	R4413[640] = (char *(*)()) F403_4878;
	R4413[892] = (char *(*)()) F406_4878;
}


#ifdef __cplusplus
}
#endif
