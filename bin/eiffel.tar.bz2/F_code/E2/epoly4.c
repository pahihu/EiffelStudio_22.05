#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

EIF_TYPE_INDEX *Y1366_gen_type [2];
EIF_TYPE_INDEX Y1366 [2];
void Y1366_init (void)
{
	egc_routines_types [1366] = Y1366;
	egc_routines_gen_types [1366] = Y1366_gen_type;
	egc_routines_offset [1366] = 95;
	Y1366[0] = 213;
	Y1366[1] = 214;
}

long O1756[2];
void O1756_init () {
	O1756[0] = 0;
	O1756[1] =  + _REFACS_22_;
}

long O1757[2];
void O1757_init () {
	O1757[0] = + _LNGOFF_12_0_0_0_;
	O1757[1] = + _LNGOFF_35_0_0_1_;
}

long O1761[2];
void O1761_init () {
	O1761[0] =  + _REFACS_1_;
	O1761[1] =  + _REFACS_23_;
}

long O1762[2];
void O1762_init () {
	O1762[0] = + _LNGOFF_12_0_0_1_;
	O1762[1] = + _LNGOFF_35_0_0_2_;
}

long O1763[2];
void O1763_init () {
	O1763[0] =  + _REFACS_2_;
	O1763[1] =  + _REFACS_24_;
}

long O1764[2];
void O1764_init () {
	O1764[0] =  + _REFACS_3_;
	O1764[1] =  + _REFACS_25_;
}

long O1765[2];
void O1765_init () {
	O1765[0] =  + _REFACS_4_;
	O1765[1] =  + _REFACS_26_;
}

long O1766[2];
void O1766_init () {
	O1766[0] =  + _REFACS_5_;
	O1766[1] =  + _REFACS_27_;
}

long O1767[2];
void O1767_init () {
	O1767[0] =  + _REFACS_6_;
	O1767[1] =  + _REFACS_28_;
}

long O1768[2];
void O1768_init () {
	O1768[0] =  + _REFACS_7_;
	O1768[1] =  + _REFACS_29_;
}

long O1769[2];
void O1769_init () {
	O1769[0] = + _LNGOFF_12_0_0_2_;
	O1769[1] = + _LNGOFF_35_0_0_3_;
}

long O1773[2];
void O1773_init () {
	O1773[0] =  + _REFACS_8_;
	O1773[1] =  + _REFACS_30_;
}

long O1774[2];
void O1774_init () {
	O1774[0] = + _LNGOFF_12_0_0_3_;
	O1774[1] = + _LNGOFF_35_0_0_4_;
}

long O1775[2];
void O1775_init () {
	O1775[0] =  + _REFACS_9_;
	O1775[1] =  + _REFACS_31_;
}

long O1776[2];
void O1776_init () {
	O1776[0] =  + _REFACS_10_;
	O1776[1] =  + _REFACS_32_;
}

long O1777[2];
void O1777_init () {
	O1777[0] =  + _REFACS_11_;
	O1777[1] =  + _REFACS_33_;
}

long O1915[3];
void O1915_init () {
	O1915[0] = + _CHROFF_2_0_;
	O1915[1] = + _CHROFF_4_0_;
	O1915[2] = + _CHROFF_6_0_;
}

long O1920[3];
void O1920_init () {
	O1920[0] = + _LNGOFF_2_1_0_0_;
	O1920[1] = + _LNGOFF_4_2_0_0_;
	O1920[2] = + _LNGOFF_6_2_0_2_;
}

long O1924[2];
void O1924_init () {
	O1924[0] = + _CHROFF_4_1_;
	O1924[1] = + _CHROFF_6_1_;
}

long O2286[7];
void O2286_init () {
	O2286[0] = 0;
	O2286[1] = + _LNGOFF_0_0_0_0_;
	O2286[2] = + _CHROFF_0_0_;
	O2286[3] = + _LNGOFF_0_0_0_0_;
	O2286[4] = + _I64OFF_0_0_0_0_0_0_0_;
	O2286[5] = 0;
	O2286[6] = + _LNGOFF_1_0_0_0_;
}

long O2290[2];
void O2290_init () {
	O2290[0] =  + _REFACS_1_;
	O2290[1] = 0;
}

long O2324[2];
void O2324_init () {
	O2324[0] = + _LNGOFF_1_0_0_0_;
	O2324[1] = + _LNGOFF_2_0_0_0_;
}

long O2499[3];
void O2499_init () {
	O2499[0] = + _CHROFF_3_0_;
	O2499[1] = + _CHROFF_4_0_;
	O2499[2] = + _CHROFF_5_0_;
}

long O2591[3];
void O2591_init () {
	O2591[0] = + _LNGOFF_1_0_0_0_;
	O2591[1] = + _LNGOFF_2_0_0_0_;
	O2591[2] = + _LNGOFF_1_0_0_0_;
}

long O2595[3];
void O2595_init () {
	O2595[0] = + _LNGOFF_1_0_0_1_;
	O2595[1] = + _LNGOFF_2_0_0_1_;
	O2595[2] = + _LNGOFF_1_0_0_1_;
}

long O3022[4];
void O3022_init () {
	{long i; for (i = 0; i < 3; i++) O3022[i] = + _CHROFF_2_0_;}
	O3022[3] = + _CHROFF_2_1_;
}

long O3023[4];
void O3023_init () {
	{long i; for (i = 0; i < 3; i++) O3023[i] = + _CHROFF_2_1_;}
	O3023[3] = + _CHROFF_2_2_;
}

long O3167[3];
void O3167_init () {
	O3167[0] = + _CHROFF_1_0_;
	O3167[1] = + _CHROFF_4_0_;
	O3167[2] = + _CHROFF_5_0_;
}

long O3168[3];
void O3168_init () {
	O3168[0] = + _CHROFF_1_1_;
	O3168[1] = + _CHROFF_4_1_;
	O3168[2] = + _CHROFF_5_1_;
}

long O3169[3];
void O3169_init () {
	O3169[0] = + _CHROFF_1_2_;
	O3169[1] = + _CHROFF_4_2_;
	O3169[2] = + _CHROFF_5_2_;
}

long O3199[6];
void O3199_init () {
	{long i; for (i = 0; i < 3; i++) O3199[i] = + _LNGOFF_1_3_0_0_;}
	O3199[3] = + _LNGOFF_2_4_0_0_;
	O3199[4] = + _LNGOFF_2_5_0_0_;
	O3199[5] = + _LNGOFF_2_4_0_0_;
}

long O3200[6];
void O3200_init () {
	{long i; for (i = 0; i < 3; i++) O3200[i] = + _LNGOFF_1_3_0_1_;}
	O3200[3] = + _LNGOFF_2_4_0_1_;
	O3200[4] = + _LNGOFF_2_5_0_1_;
	O3200[5] = + _LNGOFF_2_4_0_1_;
}

long O3201[6];
void O3201_init () {
	{long i; for (i = 0; i < 3; i++) O3201[i] = + _LNGOFF_1_3_0_2_;}
	O3201[3] = + _LNGOFF_2_4_0_2_;
	O3201[4] = + _LNGOFF_2_5_0_2_;
	O3201[5] = + _LNGOFF_2_4_0_2_;
}

long O3202[6];
void O3202_init () {
	{long i; for (i = 0; i < 3; i++) O3202[i] = + _LNGOFF_1_3_0_3_;}
	O3202[3] = + _LNGOFF_2_4_0_3_;
	O3202[4] = + _LNGOFF_2_5_0_3_;
	O3202[5] = + _LNGOFF_2_4_0_3_;
}

long O3203[6];
void O3203_init () {
	{long i; for (i = 0; i < 3; i++) O3203[i] = + _LNGOFF_1_3_0_4_;}
	O3203[3] = + _LNGOFF_2_4_0_4_;
	O3203[4] = + _LNGOFF_2_5_0_4_;
	O3203[5] = + _LNGOFF_2_4_0_4_;
}

long O3204[6];
void O3204_init () {
	{long i; for (i = 0; i < 3; i++) O3204[i] = + _LNGOFF_1_3_0_5_;}
	O3204[3] = + _LNGOFF_2_4_0_5_;
	O3204[4] = + _LNGOFF_2_5_0_5_;
	O3204[5] = + _LNGOFF_2_4_0_5_;
}

long O3205[6];
void O3205_init () {
	{long i; for (i = 0; i < 3; i++) O3205[i] = + _CHROFF_1_0_;}
	{long i; for (i = 3; i < 6; i++) O3205[i] = + _CHROFF_2_0_;}
}

long O3210[6];
void O3210_init () {
	{long i; for (i = 0; i < 3; i++) O3210[i] = + _CHROFF_1_1_;}
	{long i; for (i = 3; i < 6; i++) O3210[i] = + _CHROFF_2_1_;}
}

long O4085[573];
void O4085_init () {
	O4085[0] = + _CHROFF_4_0_;
	O4085[1] = + _CHROFF_7_0_;
	O4085[572] = + _CHROFF_26_0_;
}

long O4086[573];
void O4086_init () {
	O4086[0] = + _CHROFF_4_1_;
	O4086[1] = + _CHROFF_7_1_;
	O4086[572] = + _CHROFF_26_1_;
}

long O4087[573];
void O4087_init () {
	O4087[0] = + _CHROFF_4_2_;
	O4087[1] = + _CHROFF_7_2_;
	O4087[572] = + _CHROFF_26_2_;
}

long O4360[744];
void O4360_init () {
	{long i; for (i = 0; i < 11; i++) O4360[i] = 0;}
	{long i; for (i = 734; i < 744; i++) O4360[i] =  + _REFACS_1_;}
}

static EIF_TYPE_INDEX Y4408_pgtype0[] = {0xFF01,1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype1[] = {0xFF01,1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype2[] = {0xFF01,1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype3[] = {0xFF01,1111,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype4[] = {0xFF01,1112,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype5[] = {0xFF01,1113,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype6[] = {0xFF01,1114,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype7[] = {0xFF01,1115,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype8[] = {0xFF01,1116,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype9[] = {0xFF01,1117,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype10[] = {0xFF01,1118,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype11[] = {0xFF01,1119,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype12[] = {0xFF01,1117,1205,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype13[] = {0xFF01,1117,1205,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype14[] = {0xFF01,1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype15[] = {0xFF01,1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype16[] = {0xFF01,1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype17[] = {0xFF01,1111,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype18[] = {0xFF01,1112,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype19[] = {0xFF01,1113,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype20[] = {0xFF01,1114,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype21[] = {0xFF01,1115,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype22[] = {0xFF01,1116,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype23[] = {0xFF01,1117,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype24[] = {0xFF01,1118,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype25[] = {0xFF01,1119,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype26[] = {0xFF01,1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype27[] = {0xFF01,1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype28[] = {0xFF01,1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype29[] = {0xFF01,1111,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype30[] = {0xFF01,1116,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype31[] = {0xFF01,1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype32[] = {0xFF01,1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype33[] = {0xFF01,1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype34[] = {0xFF01,1111,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype35[] = {0xFF01,1112,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype36[] = {0xFF01,1113,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype37[] = {0xFF01,1114,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype38[] = {0xFF01,1115,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype39[] = {0xFF01,1116,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype40[] = {0xFF01,1117,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype41[] = {0xFF01,1118,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype42[] = {0xFF01,1119,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype43[] = {0xFF01,1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype44[] = {0xFF01,1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype45[] = {0xFF01,1108,0xFF01,936,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype46[] = {0xFF01,1108,0xFF01,1264,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype47[] = {0xFF01,1116,1002,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype48[] = {0xFF01,1116,1002,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype49[] = {0xFF01,1113,1008,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype50[] = {0xFF01,1116,1002,0xFFFF};
static EIF_TYPE_INDEX Y4408_pgtype51[] = {0xFF01,1116,1002,0xFFFF};
EIF_TYPE_INDEX *Y4408_gen_type [914];
EIF_TYPE_INDEX Y4408 [914];
void Y4408_init (void)
{
	egc_routines_types [4408] = Y4408;
	egc_routines_gen_types [4408] = Y4408_gen_type;
	egc_routines_offset [4408] = 397;
	Y4408_gen_type [0] = Y4408_pgtype0;
	Y4408_gen_type [1] = Y4408_pgtype1;
	Y4408_gen_type [2] = Y4408_pgtype2;
	Y4408_gen_type [3] = Y4408_pgtype3;
	Y4408_gen_type [4] = Y4408_pgtype4;
	Y4408_gen_type [5] = Y4408_pgtype5;
	Y4408_gen_type [6] = Y4408_pgtype6;
	Y4408_gen_type [7] = Y4408_pgtype7;
	Y4408_gen_type [8] = Y4408_pgtype8;
	Y4408_gen_type [9] = Y4408_pgtype9;
	Y4408_gen_type [10] = Y4408_pgtype10;
	Y4408_gen_type [11] = Y4408_pgtype11;
	Y4408_gen_type [20] = Y4408_pgtype12;
	Y4408_gen_type [21] = Y4408_pgtype13;
	Y4408_gen_type [455] = Y4408_pgtype14;
	Y4408_gen_type [456] = Y4408_pgtype15;
	Y4408_gen_type [457] = Y4408_pgtype16;
	Y4408_gen_type [458] = Y4408_pgtype17;
	Y4408_gen_type [459] = Y4408_pgtype18;
	Y4408_gen_type [460] = Y4408_pgtype19;
	Y4408_gen_type [461] = Y4408_pgtype20;
	Y4408_gen_type [462] = Y4408_pgtype21;
	Y4408_gen_type [463] = Y4408_pgtype22;
	Y4408_gen_type [464] = Y4408_pgtype23;
	Y4408_gen_type [465] = Y4408_pgtype24;
	Y4408_gen_type [466] = Y4408_pgtype25;
	Y4408_gen_type [467] = Y4408_pgtype26;
	Y4408_gen_type [468] = Y4408_pgtype27;
	Y4408_gen_type [469] = Y4408_pgtype28;
	Y4408_gen_type [470] = Y4408_pgtype29;
	Y4408_gen_type [471] = Y4408_pgtype30;
	Y4408_gen_type [525] = Y4408_pgtype31;
	Y4408_gen_type [526] = Y4408_pgtype32;
	Y4408_gen_type [527] = Y4408_pgtype33;
	Y4408_gen_type [528] = Y4408_pgtype34;
	Y4408_gen_type [529] = Y4408_pgtype35;
	Y4408_gen_type [530] = Y4408_pgtype36;
	Y4408_gen_type [531] = Y4408_pgtype37;
	Y4408_gen_type [532] = Y4408_pgtype38;
	Y4408_gen_type [533] = Y4408_pgtype39;
	Y4408_gen_type [534] = Y4408_pgtype40;
	Y4408_gen_type [535] = Y4408_pgtype41;
	Y4408_gen_type [536] = Y4408_pgtype42;
	Y4408_gen_type [537] = Y4408_pgtype43;
	Y4408_gen_type [538] = Y4408_pgtype44;
	Y4408_gen_type [539] = Y4408_pgtype45;
	Y4408_gen_type [540] = Y4408_pgtype46;
	Y4408_gen_type [656] = Y4408_pgtype47;
	Y4408_gen_type [657] = Y4408_pgtype48;
	Y4408_gen_type [660] = Y4408_pgtype49;
	Y4408_gen_type [912] = Y4408_pgtype50;
	Y4408_gen_type [913] = Y4408_pgtype51;
	Y4408[0] = 1108;
	Y4408[1] = 1109;
	Y4408[2] = 1110;
	Y4408[3] = 1111;
	Y4408[4] = 1112;
	Y4408[5] = 1113;
	Y4408[6] = 1114;
	Y4408[7] = 1115;
	Y4408[8] = 1116;
	Y4408[9] = 1117;
	Y4408[10] = 1118;
	Y4408[11] = 1119;
	{long i; for (i = 20; i < 22; i++) Y4408[i] = 1117;};
	Y4408[455] = 1108;
	Y4408[456] = 1109;
	Y4408[457] = 1110;
	Y4408[458] = 1111;
	Y4408[459] = 1112;
	Y4408[460] = 1113;
	Y4408[461] = 1114;
	Y4408[462] = 1115;
	Y4408[463] = 1116;
	Y4408[464] = 1117;
	Y4408[465] = 1118;
	Y4408[466] = 1119;
	Y4408[467] = 1108;
	Y4408[468] = 1109;
	Y4408[469] = 1110;
	Y4408[470] = 1111;
	Y4408[471] = 1116;
	Y4408[525] = 1108;
	Y4408[526] = 1109;
	Y4408[527] = 1110;
	Y4408[528] = 1111;
	Y4408[529] = 1112;
	Y4408[530] = 1113;
	Y4408[531] = 1114;
	Y4408[532] = 1115;
	Y4408[533] = 1116;
	Y4408[534] = 1117;
	Y4408[535] = 1118;
	Y4408[536] = 1119;
	Y4408[537] = 1108;
	Y4408[538] = 1110;
	{long i; for (i = 539; i < 541; i++) Y4408[i] = 1108;};
	{long i; for (i = 656; i < 658; i++) Y4408[i] = 1116;};
	Y4408[660] = 1113;
	{long i; for (i = 912; i < 914; i++) Y4408[i] = 1116;};
}

long O4726[49];
void O4726_init () {
	{long i; for (i = 0; i < 4; i++) O4726[i] = + _LNGOFF_0_0_0_0_;}
	O4726[4] = + _LNGOFF_15_11_0_0_;
	O4726[48] = + _LNGOFF_13_16_0_0_;
}

long O4877[848];
void O4877_init () {
	O4877[0] = + _CHROFF_1_0_;
	O4877[1] = + _CHROFF_2_0_;
	O4877[371] = + _CHROFF_3_0_;
	O4877[372] = + _CHROFF_5_0_;
	O4877[373] = + _CHROFF_4_0_;
	O4877[793] = + _CHROFF_5_0_;
	{long i; for (i = 839; i < 842; i++) O4877[i] = + _CHROFF_5_0_;}
	O4877[843] = + _CHROFF_7_1_;
	{long i; for (i = 844; i < 848; i++) O4877[i] = + _CHROFF_6_1_;}
}

long O4878[848];
void O4878_init () {
	{long i; for (i = 0; i < 2; i++) O4878[i] = 0;}
	{long i; for (i = 371; i < 374; i++) O4878[i] = 0;}
	O4878[793] = 0;
	{long i; for (i = 839; i < 842; i++) O4878[i] = 0;}
	O4878[843] =  + _REFACS_6_;
	{long i; for (i = 844; i < 848; i++) O4878[i] =  + _REFACS_5_;}
}

long O4879[848];
void O4879_init () {
	O4879[0] = + _LNGOFF_1_3_2_1_;
	O4879[1] = + _LNGOFF_2_7_2_3_;
	O4879[371] = + _LNGOFF_3_6_2_1_;
	O4879[372] = + _LNGOFF_5_7_2_1_;
	O4879[373] = + _LNGOFF_4_6_2_1_;
	O4879[793] = + _LNGOFF_5_7_2_1_;
	{long i; for (i = 839; i < 842; i++) O4879[i] = + _LNGOFF_5_6_2_1_;}
	O4879[843] = + _LNGOFF_7_8_2_1_;
	{long i; for (i = 844; i < 848; i++) O4879[i] = + _LNGOFF_6_7_2_1_;}
}

long O4888[848];
void O4888_init () {
	O4888[0] = + _CHROFF_1_1_;
	O4888[1] = + _CHROFF_2_5_;
	O4888[371] = + _CHROFF_3_4_;
	O4888[372] = + _CHROFF_5_5_;
	O4888[373] = + _CHROFF_4_4_;
	O4888[793] = + _CHROFF_5_5_;
	{long i; for (i = 839; i < 842; i++) O4888[i] = + _CHROFF_5_4_;}
	O4888[843] = + _CHROFF_7_6_;
	{long i; for (i = 844; i < 848; i++) O4888[i] = + _CHROFF_6_5_;}
}

long O4889[848];
void O4889_init () {
	O4889[0] = + _R32OFF_1_3_2_3_0_;
	O4889[1] = + _R32OFF_2_7_2_5_0_;
	O4889[371] = + _R32OFF_3_6_2_4_0_;
	O4889[372] = + _R32OFF_5_7_2_4_0_;
	O4889[373] = + _R32OFF_4_6_2_4_0_;
	O4889[793] = + _R32OFF_5_7_2_4_0_;
	{long i; for (i = 839; i < 842; i++) O4889[i] = + _R32OFF_5_6_2_4_0_;}
	O4889[843] = + _R32OFF_7_8_2_4_0_;
	{long i; for (i = 844; i < 848; i++) O4889[i] = + _R32OFF_6_7_2_4_0_;}
}

long O4891[848];
void O4891_init () {
	O4891[0] = + _R64OFF_1_3_2_3_1_0_2_0_;
	O4891[1] = + _R64OFF_2_7_2_5_1_0_2_0_;
	O4891[371] = + _R64OFF_3_6_2_4_1_1_2_0_;
	O4891[372] = + _R64OFF_5_7_2_4_1_1_2_0_;
	O4891[373] = + _R64OFF_4_6_2_4_1_1_2_0_;
	O4891[793] = + _R64OFF_5_7_2_4_1_1_2_0_;
	{long i; for (i = 839; i < 842; i++) O4891[i] = + _R64OFF_5_6_2_4_1_1_2_0_;}
	O4891[843] = + _R64OFF_7_8_2_4_1_1_2_0_;
	{long i; for (i = 844; i < 848; i++) O4891[i] = + _R64OFF_6_7_2_4_1_1_2_0_;}
}

long O4893[848];
void O4893_init () {
	O4893[0] = + _LNGOFF_1_3_2_2_;
	O4893[1] = + _LNGOFF_2_7_2_4_;
	O4893[371] = + _LNGOFF_3_6_2_2_;
	O4893[372] = + _LNGOFF_5_7_2_2_;
	O4893[373] = + _LNGOFF_4_6_2_2_;
	O4893[793] = + _LNGOFF_5_7_2_2_;
	{long i; for (i = 839; i < 842; i++) O4893[i] = + _LNGOFF_5_6_2_2_;}
	O4893[843] = + _LNGOFF_7_8_2_2_;
	{long i; for (i = 844; i < 848; i++) O4893[i] = + _LNGOFF_6_7_2_2_;}
}

long O5257[22];
void O5257_init () {
	{long i; for (i = 0; i < 20; i++) O5257[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 20; i < 22; i++) O5257[i] = + _LNGOFF_2_1_0_0_;}
}

long O5261[22];
void O5261_init () {
	{long i; for (i = 0; i < 20; i++) O5261[i] = + _CHROFF_1_0_;}
	{long i; for (i = 20; i < 22; i++) O5261[i] = + _CHROFF_2_0_;}
}

long O5262[22];
void O5262_init () {
	{long i; for (i = 0; i < 20; i++) O5262[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 20; i < 22; i++) O5262[i] = + _LNGOFF_2_1_0_1_;}
}

long O5263[22];
void O5263_init () {
	{long i; for (i = 0; i < 20; i++) O5263[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 20; i < 22; i++) O5263[i] = + _LNGOFF_2_1_0_2_;}
}

long O5264[22];
void O5264_init () {
	{long i; for (i = 0; i < 20; i++) O5264[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 20; i < 22; i++) O5264[i] = + _LNGOFF_2_1_0_3_;}
}

long O5265[22];
void O5265_init () {
	{long i; for (i = 0; i < 20; i++) O5265[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 20; i < 22; i++) O5265[i] = + _LNGOFF_2_1_0_4_;}
}

long O5268[50];
void O5268_init () {
	{long i; for (i = 0; i < 12; i++) O5268[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 12; i < 38; i++) O5268[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 38; i < 50; i++) O5268[i] = + _LNGOFF_1_0_0_0_;}
}

long O5270[50];
void O5270_init () {
	{long i; for (i = 0; i < 12; i++) O5270[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 12; i < 38; i++) O5270[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 38; i < 50; i++) O5270[i] = + _LNGOFF_1_0_0_1_;}
}

static EIF_TYPE_INDEX Y5286_pgtype0[] = {0xFF01,469,0xFF01,1062,0xFFFF};
static EIF_TYPE_INDEX Y5286_pgtype1[] = {0xFF01,922,0xFF01,1062,0xFFFF};
static EIF_TYPE_INDEX Y5286_pgtype2[] = {0xFF01,922,0xFF01,1062,0xFFFF};
EIF_TYPE_INDEX *Y5286_gen_type [482];
EIF_TYPE_INDEX Y5286 [482];
void Y5286_init (void)
{
	egc_routines_types [5286] = Y5286;
	egc_routines_gen_types [5286] = Y5286_gen_type;
	egc_routines_offset [5286] = 580;
	Y5286_gen_type [0] = Y5286_pgtype0;
	Y5286_gen_type [480] = Y5286_pgtype1;
	Y5286_gen_type [481] = Y5286_pgtype2;
	Y5286[0] = 469;
	{long i; for (i = 480; i < 482; i++) Y5286[i] = 922;};
}


#ifdef __cplusplus
}
#endif
