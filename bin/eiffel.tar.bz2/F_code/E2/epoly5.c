#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5241[72])();
void R5241_init () {
	R5241[0] = (char *(*)()) F509_5887;
	R5241[1] = (char *(*)()) F510_5887;
	R5241[2] = (char *(*)()) F511_5887;
	R5241[3] = (char *(*)()) F512_5887;
	R5241[4] = (char *(*)()) F513_5887;
	R5241[5] = (char *(*)()) F514_5887;
	R5241[6] = (char *(*)()) F515_5887;
	R5241[7] = (char *(*)()) F516_5887;
	R5241[8] = (char *(*)()) F517_5887;
	R5241[9] = (char *(*)()) F518_5887;
	R5241[10] = (char *(*)()) F519_5887;
	R5241[11] = (char *(*)()) F520_5887;
	{long i; for (i = 12; i < 14; i++) R5241[i] = (char *(*)()) F509_5887;}
	R5241[14] = (char *(*)()) F510_5887;
	{long i; for (i = 15; i < 17; i++) R5241[i] = (char *(*)()) F511_5887;}
	R5241[17] = (char *(*)()) F512_5887;
	R5241[18] = (char *(*)()) F518_5887;
	R5241[19] = (char *(*)()) F519_5887;
	R5241[20] = (char *(*)()) F509_5887;
	R5241[21] = (char *(*)()) F511_5887;
	R5241[34] = (char *(*)()) F539_5921;
	R5241[35] = (char *(*)()) F536_5921;
	R5241[36] = (char *(*)()) F531_5921;
	R5241[37] = (char *(*)()) F532_5921;
	R5241[38] = (char *(*)()) F533_5921;
	R5241[39] = (char *(*)()) F534_5921;
	R5241[40] = (char *(*)()) F535_5921;
	R5241[41] = (char *(*)()) F536_5921;
	R5241[42] = (char *(*)()) F537_5921;
	R5241[43] = (char *(*)()) F538_5921;
	R5241[44] = (char *(*)()) F539_5921;
	R5241[45] = (char *(*)()) F540_5921;
	R5241[46] = (char *(*)()) F541_5921;
	R5241[47] = (char *(*)()) F542_5921;
	R5241[48] = (char *(*)()) F531_5921;
	R5241[49] = (char *(*)()) F532_5921;
	R5241[50] = (char *(*)()) F533_5921;
	R5241[51] = (char *(*)()) F534_5921;
	R5241[52] = (char *(*)()) F535_5921;
	R5241[53] = (char *(*)()) F536_5921;
	R5241[54] = (char *(*)()) F537_5921;
	R5241[55] = (char *(*)()) F538_5921;
	R5241[56] = (char *(*)()) F539_5921;
	R5241[57] = (char *(*)()) F540_5921;
	R5241[58] = (char *(*)()) F541_5921;
	R5241[59] = (char *(*)()) F542_5921;
	R5241[60] = (char *(*)()) F531_5921;
	R5241[61] = (char *(*)()) F532_5921;
	R5241[62] = (char *(*)()) F533_5921;
	R5241[63] = (char *(*)()) F534_5921;
	R5241[64] = (char *(*)()) F535_5921;
	R5241[65] = (char *(*)()) F536_5921;
	R5241[66] = (char *(*)()) F537_5921;
	R5241[67] = (char *(*)()) F538_5921;
	R5241[68] = (char *(*)()) F539_5921;
	R5241[69] = (char *(*)()) F540_5921;
	R5241[70] = (char *(*)()) F541_5921;
	R5241[71] = (char *(*)()) F542_5921;
}

char *(*R5242[72])();
void R5242_init () {
	R5242[0] = (char *(*)()) F509_5888;
	R5242[1] = (char *(*)()) F510_5888;
	R5242[2] = (char *(*)()) F511_5888;
	R5242[3] = (char *(*)()) F512_5888;
	R5242[4] = (char *(*)()) F513_5888;
	R5242[5] = (char *(*)()) F514_5888;
	R5242[6] = (char *(*)()) F515_5888;
	R5242[7] = (char *(*)()) F516_5888;
	R5242[8] = (char *(*)()) F517_5888;
	R5242[9] = (char *(*)()) F518_5888;
	R5242[10] = (char *(*)()) F519_5888;
	R5242[11] = (char *(*)()) F520_5888;
	{long i; for (i = 12; i < 14; i++) R5242[i] = (char *(*)()) F509_5888;}
	R5242[14] = (char *(*)()) F510_5888;
	{long i; for (i = 15; i < 17; i++) R5242[i] = (char *(*)()) F511_5888;}
	R5242[17] = (char *(*)()) F512_5888;
	R5242[18] = (char *(*)()) F518_5888;
	R5242[19] = (char *(*)()) F519_5888;
	R5242[20] = (char *(*)()) F509_5888;
	R5242[21] = (char *(*)()) F511_5888;
	R5242[34] = (char *(*)()) F543_5940;
	R5242[35] = (char *(*)()) F544_5946;
	R5242[36] = (char *(*)()) F545_5952;
	R5242[37] = (char *(*)()) F546_5952;
	R5242[38] = (char *(*)()) F547_5952;
	R5242[39] = (char *(*)()) F548_5952;
	R5242[40] = (char *(*)()) F549_5952;
	R5242[41] = (char *(*)()) F550_5952;
	R5242[42] = (char *(*)()) F551_5952;
	R5242[43] = (char *(*)()) F552_5952;
	R5242[44] = (char *(*)()) F553_5952;
	R5242[45] = (char *(*)()) F554_5952;
	R5242[46] = (char *(*)()) F555_5952;
	R5242[47] = (char *(*)()) F556_5952;
	R5242[48] = (char *(*)()) F557_5958;
	R5242[49] = (char *(*)()) F558_5958;
	R5242[50] = (char *(*)()) F559_5958;
	R5242[51] = (char *(*)()) F560_5958;
	R5242[52] = (char *(*)()) F561_5958;
	R5242[53] = (char *(*)()) F562_5958;
	R5242[54] = (char *(*)()) F563_5958;
	R5242[55] = (char *(*)()) F564_5958;
	R5242[56] = (char *(*)()) F565_5958;
	R5242[57] = (char *(*)()) F566_5958;
	R5242[58] = (char *(*)()) F567_5958;
	R5242[59] = (char *(*)()) F568_5958;
	R5242[60] = (char *(*)()) F569_5964;
	R5242[61] = (char *(*)()) F570_5964;
	R5242[62] = (char *(*)()) F571_5964;
	R5242[63] = (char *(*)()) F572_5964;
	R5242[64] = (char *(*)()) F573_5964;
	R5242[65] = (char *(*)()) F574_5964;
	R5242[66] = (char *(*)()) F575_5964;
	R5242[67] = (char *(*)()) F576_5964;
	R5242[68] = (char *(*)()) F577_5964;
	R5242[69] = (char *(*)()) F578_5964;
	R5242[70] = (char *(*)()) F579_5964;
	R5242[71] = (char *(*)()) F580_5964;
}

char *(*R5250[22])();
void R5250_init () {
	R5250[0] = (char *(*)()) F509_5899;
	R5250[1] = (char *(*)()) F510_5899;
	R5250[2] = (char *(*)()) F511_5899;
	R5250[3] = (char *(*)()) F512_5899;
	R5250[4] = (char *(*)()) F513_5899;
	R5250[5] = (char *(*)()) F514_5899;
	R5250[6] = (char *(*)()) F515_5899;
	R5250[7] = (char *(*)()) F516_5899;
	R5250[8] = (char *(*)()) F517_5899;
	R5250[9] = (char *(*)()) F518_5899;
	R5250[10] = (char *(*)()) F519_5899;
	R5250[11] = (char *(*)()) F520_5899;
	{long i; for (i = 12; i < 14; i++) R5250[i] = (char *(*)()) F509_5899;}
	R5250[14] = (char *(*)()) F510_5899;
	{long i; for (i = 15; i < 17; i++) R5250[i] = (char *(*)()) F511_5899;}
	R5250[17] = (char *(*)()) F512_5899;
	R5250[18] = (char *(*)()) F518_5899;
	R5250[19] = (char *(*)()) F519_5899;
	R5250[20] = (char *(*)()) F509_5899;
	R5250[21] = (char *(*)()) F511_5899;
}

char *(*R5253[72])();
void R5253_init () {
	R5253[0] = (char *(*)()) F509_5904;
	R5253[1] = (char *(*)()) F510_5904;
	R5253[2] = (char *(*)()) F511_5904;
	R5253[3] = (char *(*)()) F512_5904;
	R5253[4] = (char *(*)()) F513_5904;
	R5253[5] = (char *(*)()) F514_5904;
	R5253[6] = (char *(*)()) F515_5904;
	R5253[7] = (char *(*)()) F516_5904;
	R5253[8] = (char *(*)()) F517_5904;
	R5253[9] = (char *(*)()) F518_5904;
	R5253[10] = (char *(*)()) F519_5904;
	R5253[11] = (char *(*)()) F520_5904;
	{long i; for (i = 12; i < 14; i++) R5253[i] = (char *(*)()) F509_5904;}
	R5253[14] = (char *(*)()) F510_5904;
	{long i; for (i = 15; i < 17; i++) R5253[i] = (char *(*)()) F511_5904;}
	R5253[17] = (char *(*)()) F512_5904;
	R5253[18] = (char *(*)()) F518_5904;
	R5253[19] = (char *(*)()) F519_5904;
	R5253[20] = (char *(*)()) F529_5915;
	R5253[21] = (char *(*)()) F530_5915;
	R5253[34] = (char *(*)()) F539_5933;
	R5253[35] = (char *(*)()) F536_5933;
	R5253[36] = (char *(*)()) F531_5933;
	R5253[37] = (char *(*)()) F532_5933;
	R5253[38] = (char *(*)()) F533_5933;
	R5253[39] = (char *(*)()) F534_5933;
	R5253[40] = (char *(*)()) F535_5933;
	R5253[41] = (char *(*)()) F536_5933;
	R5253[42] = (char *(*)()) F537_5933;
	R5253[43] = (char *(*)()) F538_5933;
	R5253[44] = (char *(*)()) F539_5933;
	R5253[45] = (char *(*)()) F540_5933;
	R5253[46] = (char *(*)()) F541_5933;
	R5253[47] = (char *(*)()) F542_5933;
	R5253[48] = (char *(*)()) F531_5933;
	R5253[49] = (char *(*)()) F532_5933;
	R5253[50] = (char *(*)()) F533_5933;
	R5253[51] = (char *(*)()) F534_5933;
	R5253[52] = (char *(*)()) F535_5933;
	R5253[53] = (char *(*)()) F536_5933;
	R5253[54] = (char *(*)()) F537_5933;
	R5253[55] = (char *(*)()) F538_5933;
	R5253[56] = (char *(*)()) F539_5933;
	R5253[57] = (char *(*)()) F540_5933;
	R5253[58] = (char *(*)()) F541_5933;
	R5253[59] = (char *(*)()) F542_5933;
	R5253[60] = (char *(*)()) F531_5933;
	R5253[61] = (char *(*)()) F532_5933;
	R5253[62] = (char *(*)()) F533_5933;
	R5253[63] = (char *(*)()) F534_5933;
	R5253[64] = (char *(*)()) F535_5933;
	R5253[65] = (char *(*)()) F536_5933;
	R5253[66] = (char *(*)()) F537_5933;
	R5253[67] = (char *(*)()) F538_5933;
	R5253[68] = (char *(*)()) F539_5933;
	R5253[69] = (char *(*)()) F540_5933;
	R5253[70] = (char *(*)()) F541_5933;
	R5253[71] = (char *(*)()) F542_5933;
}

char *(*R5254[72])();
void R5254_init () {
	R5254[0] = (char *(*)()) F509_5906;
	R5254[1] = (char *(*)()) F510_5906;
	R5254[2] = (char *(*)()) F511_5906;
	R5254[3] = (char *(*)()) F512_5906;
	R5254[4] = (char *(*)()) F513_5906;
	R5254[5] = (char *(*)()) F514_5906;
	R5254[6] = (char *(*)()) F515_5906;
	R5254[7] = (char *(*)()) F516_5906;
	R5254[8] = (char *(*)()) F517_5906;
	R5254[9] = (char *(*)()) F518_5906;
	R5254[10] = (char *(*)()) F519_5906;
	R5254[11] = (char *(*)()) F520_5906;
	R5254[12] = (char *(*)()) F521_5912;
	R5254[13] = (char *(*)()) F522_5912;
	R5254[14] = (char *(*)()) F523_5912;
	R5254[15] = (char *(*)()) F524_5912;
	R5254[16] = (char *(*)()) F525_5912;
	R5254[17] = (char *(*)()) F526_5912;
	R5254[18] = (char *(*)()) F527_5912;
	R5254[19] = (char *(*)()) F528_5912;
	R5254[20] = (char *(*)()) F529_5917;
	R5254[21] = (char *(*)()) F530_5917;
	R5254[34] = (char *(*)()) F543_5943;
	R5254[35] = (char *(*)()) F544_5949;
	R5254[36] = (char *(*)()) F545_5955;
	R5254[37] = (char *(*)()) F546_5955;
	R5254[38] = (char *(*)()) F547_5955;
	R5254[39] = (char *(*)()) F548_5955;
	R5254[40] = (char *(*)()) F549_5955;
	R5254[41] = (char *(*)()) F550_5955;
	R5254[42] = (char *(*)()) F551_5955;
	R5254[43] = (char *(*)()) F552_5955;
	R5254[44] = (char *(*)()) F553_5955;
	R5254[45] = (char *(*)()) F554_5955;
	R5254[46] = (char *(*)()) F555_5955;
	R5254[47] = (char *(*)()) F556_5955;
	R5254[48] = (char *(*)()) F557_5961;
	R5254[49] = (char *(*)()) F558_5961;
	R5254[50] = (char *(*)()) F559_5961;
	R5254[51] = (char *(*)()) F560_5961;
	R5254[52] = (char *(*)()) F561_5961;
	R5254[53] = (char *(*)()) F562_5961;
	R5254[54] = (char *(*)()) F563_5961;
	R5254[55] = (char *(*)()) F564_5961;
	R5254[56] = (char *(*)()) F565_5961;
	R5254[57] = (char *(*)()) F566_5961;
	R5254[58] = (char *(*)()) F567_5961;
	R5254[59] = (char *(*)()) F568_5961;
	R5254[60] = (char *(*)()) F531_5935;
	R5254[61] = (char *(*)()) F532_5935;
	R5254[62] = (char *(*)()) F533_5935;
	R5254[63] = (char *(*)()) F534_5935;
	R5254[64] = (char *(*)()) F535_5935;
	R5254[65] = (char *(*)()) F536_5935;
	R5254[66] = (char *(*)()) F537_5935;
	R5254[67] = (char *(*)()) F538_5935;
	R5254[68] = (char *(*)()) F539_5935;
	R5254[69] = (char *(*)()) F540_5935;
	R5254[70] = (char *(*)()) F541_5935;
	R5254[71] = (char *(*)()) F542_5935;
}

char *(*R5256[22])();
void R5256_init () {
	R5256[0] = (char *(*)()) F509_5885;
	R5256[1] = (char *(*)()) F510_5885;
	R5256[2] = (char *(*)()) F511_5885;
	R5256[3] = (char *(*)()) F512_5885;
	R5256[4] = (char *(*)()) F513_5885;
	R5256[5] = (char *(*)()) F514_5885;
	R5256[6] = (char *(*)()) F515_5885;
	R5256[7] = (char *(*)()) F516_5885;
	R5256[8] = (char *(*)()) F517_5885;
	R5256[9] = (char *(*)()) F518_5885;
	R5256[10] = (char *(*)()) F519_5885;
	R5256[11] = (char *(*)()) F520_5885;
	{long i; for (i = 12; i < 14; i++) R5256[i] = (char *(*)()) F509_5885;}
	R5256[14] = (char *(*)()) F510_5885;
	{long i; for (i = 15; i < 17; i++) R5256[i] = (char *(*)()) F511_5885;}
	R5256[17] = (char *(*)()) F512_5885;
	R5256[18] = (char *(*)()) F518_5885;
	R5256[19] = (char *(*)()) F519_5885;
	R5256[20] = (char *(*)()) F509_5885;
	R5256[21] = (char *(*)()) F511_5885;
}

char *(*R5269[38])();
void R5269_init () {
	R5269[0] = (char *(*)()) F543_5944;
	R5269[1] = (char *(*)()) F544_5950;
	R5269[2] = (char *(*)()) F545_5956;
	R5269[3] = (char *(*)()) F546_5956;
	R5269[4] = (char *(*)()) F547_5956;
	R5269[5] = (char *(*)()) F548_5956;
	R5269[6] = (char *(*)()) F549_5956;
	R5269[7] = (char *(*)()) F550_5956;
	R5269[8] = (char *(*)()) F551_5956;
	R5269[9] = (char *(*)()) F552_5956;
	R5269[10] = (char *(*)()) F553_5956;
	R5269[11] = (char *(*)()) F554_5956;
	R5269[12] = (char *(*)()) F555_5956;
	R5269[13] = (char *(*)()) F556_5956;
	R5269[14] = (char *(*)()) F557_5962;
	R5269[15] = (char *(*)()) F558_5962;
	R5269[16] = (char *(*)()) F559_5962;
	R5269[17] = (char *(*)()) F560_5962;
	R5269[18] = (char *(*)()) F561_5962;
	R5269[19] = (char *(*)()) F562_5962;
	R5269[20] = (char *(*)()) F563_5962;
	R5269[21] = (char *(*)()) F564_5962;
	R5269[22] = (char *(*)()) F565_5962;
	R5269[23] = (char *(*)()) F566_5962;
	R5269[24] = (char *(*)()) F567_5962;
	R5269[25] = (char *(*)()) F568_5962;
	R5269[26] = (char *(*)()) F569_5966;
	R5269[27] = (char *(*)()) F570_5966;
	R5269[28] = (char *(*)()) F571_5966;
	R5269[29] = (char *(*)()) F572_5966;
	R5269[30] = (char *(*)()) F573_5966;
	R5269[31] = (char *(*)()) F574_5966;
	R5269[32] = (char *(*)()) F575_5966;
	R5269[33] = (char *(*)()) F576_5966;
	R5269[34] = (char *(*)()) F577_5966;
	R5269[35] = (char *(*)()) F578_5966;
	R5269[36] = (char *(*)()) F579_5966;
	R5269[37] = (char *(*)()) F580_5966;
}

char *(*R5277[12])();
void R5277_init () {
	R5277[0] = (char *(*)()) F545_5951;
	R5277[1] = (char *(*)()) F546_5951;
	R5277[2] = (char *(*)()) F547_5951;
	R5277[3] = (char *(*)()) F548_5951;
	R5277[4] = (char *(*)()) F549_5951;
	R5277[5] = (char *(*)()) F550_5951;
	R5277[6] = (char *(*)()) F551_5951;
	R5277[7] = (char *(*)()) F552_5951;
	R5277[8] = (char *(*)()) F553_5951;
	R5277[9] = (char *(*)()) F554_5951;
	R5277[10] = (char *(*)()) F555_5951;
	R5277[11] = (char *(*)()) F556_5951;
}

char *(*R5279[12])();
void R5279_init () {
	R5279[0] = (char *(*)()) F557_5957;
	R5279[1] = (char *(*)()) F558_5957;
	R5279[2] = (char *(*)()) F559_5957;
	R5279[3] = (char *(*)()) F560_5957;
	R5279[4] = (char *(*)()) F561_5957;
	R5279[5] = (char *(*)()) F562_5957;
	R5279[6] = (char *(*)()) F563_5957;
	R5279[7] = (char *(*)()) F564_5957;
	R5279[8] = (char *(*)()) F565_5957;
	R5279[9] = (char *(*)()) F566_5957;
	R5279[10] = (char *(*)()) F567_5957;
	R5279[11] = (char *(*)()) F568_5957;
}

char *(*R5282[12])();
void R5282_init () {
	R5282[0] = (char *(*)()) F569_5963;
	R5282[1] = (char *(*)()) F570_5963;
	R5282[2] = (char *(*)()) F571_5963;
	R5282[3] = (char *(*)()) F572_5963;
	R5282[4] = (char *(*)()) F573_5963;
	R5282[5] = (char *(*)()) F574_5963;
	R5282[6] = (char *(*)()) F575_5963;
	R5282[7] = (char *(*)()) F576_5963;
	R5282[8] = (char *(*)()) F577_5963;
	R5282[9] = (char *(*)()) F578_5963;
	R5282[10] = (char *(*)()) F579_5963;
	R5282[11] = (char *(*)()) F580_5963;
}

char *(*R5284[2])();
void R5284_init () {
	R5284[0] = (char *(*)()) F1061_8477;
	R5284[1] = (char *(*)()) F1062_8490;
}

char *(*R5288[2])();
void R5288_init () {
	R5288[0] = (char *(*)()) F1061_8478;
	R5288[1] = (char *(*)()) F1062_8492;
}

char *(*R5293[2])();
void R5293_init () {
	R5293[0] = (char *(*)()) F1061_8483;
	R5293[1] = (char *(*)()) F1062_8495;
}

char *(*R5297[577])();
void R5297_init () {
	R5297[0] = (char *(*)()) F734_6113_5297_2;
	R5297[1] = (char *(*)()) F735_6132_5297_2;
	{long i; for (i = 69; i < 71; i++) R5297[i] = (char *(*)()) F614_5998_5297_2;}
	R5297[119] = (char *(*)()) F853_6747;
	R5297[120] = (char *(*)()) F854_6747_5297_2;
	R5297[121] = (char *(*)()) F855_6747_5297_2;
	R5297[122] = (char *(*)()) F856_6747_5297_2;
	R5297[123] = (char *(*)()) F857_6747_5297_2;
	R5297[124] = (char *(*)()) F858_6747_5297_2;
	R5297[125] = (char *(*)()) F859_6747_5297_2;
	R5297[126] = (char *(*)()) F860_6747_5297_2;
	R5297[127] = (char *(*)()) F861_6747_5297_2;
	R5297[128] = (char *(*)()) F862_6747_5297_2;
	R5297[129] = (char *(*)()) F863_6747_5297_2;
	R5297[130] = (char *(*)()) F864_6747_5297_2;
	R5297[184] = (char *(*)()) F870_6800;
	R5297[185] = (char *(*)()) F872_6800_5297_2;
	R5297[186] = (char *(*)()) F870_6800;
	R5297[187] = (char *(*)()) F872_6800_5297_2;
	R5297[188] = (char *(*)()) F870_6800;
	R5297[189] = (char *(*)()) F923_6930;
	R5297[190] = (char *(*)()) F924_6930_5297_2;
	R5297[191] = (char *(*)()) F925_6930_5297_2;
	R5297[192] = (char *(*)()) F926_6930_5297_2;
	R5297[193] = (char *(*)()) F927_6930_5297_2;
	R5297[194] = (char *(*)()) F928_6930_5297_2;
	R5297[195] = (char *(*)()) F929_6930_5297_2;
	R5297[196] = (char *(*)()) F930_6930_5297_2;
	R5297[197] = (char *(*)()) F931_6930_5297_2;
	R5297[198] = (char *(*)()) F932_6930_5297_2;
	R5297[199] = (char *(*)()) F933_6930_5297_2;
	R5297[200] = (char *(*)()) F934_6930_5297_2;
	R5297[201] = (char *(*)()) F923_6930;
	R5297[202] = (char *(*)()) F925_6930_5297_2;
	{long i; for (i = 203; i < 205; i++) R5297[i] = (char *(*)()) F923_6930;}
	R5297[320] = (char *(*)()) F1052_8139_5297_2;
	R5297[324] = (char *(*)()) F1056_8304_5297_2;
	R5297[490] = (char *(*)()) F614_5998_5297_2;
	R5297[544] = (char *(*)()) F614_5998_5297_2;
	R5297[576] = (char *(*)()) F1310_13033_5297_2;
}
static EIF_BOOLEAN F734_6113_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F734_6113(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F735_6132_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F735_6132(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F614_5998_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F614_5998(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F854_6747_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F854_6747(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F855_6747_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F855_6747(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F856_6747_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F856_6747(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F857_6747_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F857_6747(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F858_6747_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F858_6747(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F859_6747_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F859_6747(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F860_6747_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F860_6747(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F861_6747_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F861_6747(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F862_6747_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F862_6747(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F863_6747_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F863_6747(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F864_6747_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F864_6747(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F872_6800_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F872_6800(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F924_6930_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F924_6930(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F925_6930_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F925_6930(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F926_6930_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F926_6930(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F927_6930_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F927_6930(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F928_6930_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F928_6930(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F929_6930_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F929_6930(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F930_6930_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F930_6930(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F931_6930_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F931_6930(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F932_6930_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F932_6930(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F933_6930_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F933_6930(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F934_6930_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F934_6930(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1052_8139_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1052_8139(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1056_8304_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1056_8304(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1310_13033_5297_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1310_13033(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R5298[577])();
void R5298_init () {
	{long i; for (i = 0; i < 2; i++) R5298[i] = (char *(*)()) F731_6084;}
	R5298[41] = (char *(*)()) F775_6166;
	{long i; for (i = 69; i < 71; i++) R5298[i] = (char *(*)()) F744_6139;}
	{long i; for (i = 92; i < 94; i++) R5298[i] = (char *(*)()) F736_6139;}
	R5298[94] = (char *(*)()) F737_6139;
	{long i; for (i = 95; i < 97; i++) R5298[i] = (char *(*)()) F738_6139;}
	R5298[97] = (char *(*)()) F739_6139;
	R5298[98] = (char *(*)()) F745_6139;
	R5298[99] = (char *(*)()) F746_6139;
	{long i; for (i = 100; i < 102; i++) R5298[i] = (char *(*)()) F736_6139;}
	R5298[102] = (char *(*)()) F737_6139;
	R5298[103] = (char *(*)()) F738_6139;
	R5298[104] = (char *(*)()) F739_6139;
	R5298[105] = (char *(*)()) F745_6139;
	R5298[118] = (char *(*)()) F738_6139;
	R5298[119] = (char *(*)()) F736_6139;
	R5298[120] = (char *(*)()) F737_6139;
	R5298[121] = (char *(*)()) F738_6139;
	R5298[122] = (char *(*)()) F739_6139;
	R5298[123] = (char *(*)()) F740_6139;
	R5298[124] = (char *(*)()) F741_6139;
	R5298[125] = (char *(*)()) F742_6139;
	R5298[126] = (char *(*)()) F743_6139;
	R5298[127] = (char *(*)()) F744_6139;
	R5298[128] = (char *(*)()) F745_6139;
	R5298[129] = (char *(*)()) F746_6139;
	R5298[130] = (char *(*)()) F747_6139;
	R5298[184] = (char *(*)()) F736_6139;
	R5298[185] = (char *(*)()) F738_6139;
	R5298[186] = (char *(*)()) F736_6139;
	R5298[187] = (char *(*)()) F738_6139;
	{long i; for (i = 188; i < 190; i++) R5298[i] = (char *(*)()) F736_6139;}
	R5298[190] = (char *(*)()) F737_6139;
	R5298[191] = (char *(*)()) F738_6139;
	R5298[192] = (char *(*)()) F739_6139;
	R5298[193] = (char *(*)()) F740_6139;
	R5298[194] = (char *(*)()) F741_6139;
	R5298[195] = (char *(*)()) F742_6139;
	R5298[196] = (char *(*)()) F743_6139;
	R5298[197] = (char *(*)()) F744_6139;
	R5298[198] = (char *(*)()) F745_6139;
	R5298[199] = (char *(*)()) F746_6139;
	R5298[200] = (char *(*)()) F747_6139;
	R5298[201] = (char *(*)()) F736_6139;
	R5298[202] = (char *(*)()) F738_6139;
	{long i; for (i = 203; i < 205; i++) R5298[i] = (char *(*)()) F736_6139;}
	R5298[320] = (char *(*)()) F744_6139;
	R5298[324] = (char *(*)()) F741_6139;
	R5298[490] = (char *(*)()) F1224_10437;
	R5298[544] = (char *(*)()) F744_6139;
	R5298[576] = (char *(*)()) F744_6139;
}

char *(*R5302[577])();
void R5302_init () {
	{long i; for (i = 0; i < 2; i++) R5302[i] = (char *(*)()) F584_5987;}
	R5302[41] = (char *(*)()) F582_5987;
	{long i; for (i = 69; i < 71; i++) R5302[i] = (char *(*)()) F590_5987;}
	{long i; for (i = 92; i < 94; i++) R5302[i] = (char *(*)()) F582_5987;}
	R5302[94] = (char *(*)()) F583_5987;
	{long i; for (i = 95; i < 97; i++) R5302[i] = (char *(*)()) F584_5987;}
	R5302[97] = (char *(*)()) F585_5987;
	R5302[98] = (char *(*)()) F591_5987;
	R5302[99] = (char *(*)()) F592_5987;
	{long i; for (i = 100; i < 102; i++) R5302[i] = (char *(*)()) F582_5987;}
	R5302[102] = (char *(*)()) F583_5987;
	R5302[103] = (char *(*)()) F584_5987;
	R5302[104] = (char *(*)()) F585_5987;
	R5302[105] = (char *(*)()) F591_5987;
	R5302[118] = (char *(*)()) F584_5987;
	R5302[119] = (char *(*)()) F582_5987;
	R5302[120] = (char *(*)()) F583_5987;
	R5302[121] = (char *(*)()) F584_5987;
	R5302[122] = (char *(*)()) F585_5987;
	R5302[123] = (char *(*)()) F586_5987;
	R5302[124] = (char *(*)()) F587_5987;
	R5302[125] = (char *(*)()) F588_5987;
	R5302[126] = (char *(*)()) F589_5987;
	R5302[127] = (char *(*)()) F590_5987;
	R5302[128] = (char *(*)()) F591_5987;
	R5302[129] = (char *(*)()) F592_5987;
	R5302[130] = (char *(*)()) F593_5987;
	R5302[184] = (char *(*)()) F582_5987;
	R5302[185] = (char *(*)()) F584_5987;
	R5302[186] = (char *(*)()) F582_5987;
	R5302[187] = (char *(*)()) F584_5987;
	{long i; for (i = 188; i < 190; i++) R5302[i] = (char *(*)()) F582_5987;}
	R5302[190] = (char *(*)()) F583_5987;
	R5302[191] = (char *(*)()) F584_5987;
	R5302[192] = (char *(*)()) F585_5987;
	R5302[193] = (char *(*)()) F586_5987;
	R5302[194] = (char *(*)()) F587_5987;
	R5302[195] = (char *(*)()) F588_5987;
	R5302[196] = (char *(*)()) F589_5987;
	R5302[197] = (char *(*)()) F590_5987;
	R5302[198] = (char *(*)()) F591_5987;
	R5302[199] = (char *(*)()) F592_5987;
	R5302[200] = (char *(*)()) F593_5987;
	R5302[201] = (char *(*)()) F582_5987;
	R5302[202] = (char *(*)()) F584_5987;
	{long i; for (i = 203; i < 205; i++) R5302[i] = (char *(*)()) F582_5987;}
	R5302[320] = (char *(*)()) F590_5987;
	R5302[324] = (char *(*)()) F587_5987;
	R5302[490] = (char *(*)()) F590_5987;
	R5302[544] = (char *(*)()) F590_5987;
	R5302[576] = (char *(*)()) F590_5987;
}

char *(*R5304[577])();
void R5304_init () {
	{long i; for (i = 0; i < 2; i++) R5304[i] = (char *(*)()) F733_6099;}
	R5304[41] = (char *(*)()) F775_6180;
	{long i; for (i = 69; i < 71; i++) R5304[i] = (char *(*)()) F614_6013;}
	R5304[92] = (char *(*)()) F826_6624;
	R5304[93] = (char *(*)()) F827_6624;
	R5304[94] = (char *(*)()) F828_6624;
	R5304[95] = (char *(*)()) F829_6624;
	R5304[96] = (char *(*)()) F830_6624;
	R5304[97] = (char *(*)()) F831_6624;
	R5304[98] = (char *(*)()) F832_6624;
	R5304[99] = (char *(*)()) F833_6624;
	{long i; for (i = 100; i < 102; i++) R5304[i] = (char *(*)()) F826_6624;}
	R5304[102] = (char *(*)()) F828_6624;
	R5304[103] = (char *(*)()) F829_6624;
	R5304[104] = (char *(*)()) F831_6624;
	R5304[105] = (char *(*)()) F832_6624;
	R5304[118] = (char *(*)()) F852_6726;
	R5304[119] = (char *(*)()) F853_6791;
	R5304[120] = (char *(*)()) F854_6791;
	R5304[121] = (char *(*)()) F855_6791;
	R5304[122] = (char *(*)()) F856_6791;
	R5304[123] = (char *(*)()) F857_6791;
	R5304[124] = (char *(*)()) F858_6791;
	R5304[125] = (char *(*)()) F859_6791;
	R5304[126] = (char *(*)()) F860_6791;
	R5304[127] = (char *(*)()) F861_6791;
	R5304[128] = (char *(*)()) F862_6791;
	R5304[129] = (char *(*)()) F863_6791;
	R5304[130] = (char *(*)()) F864_6791;
	R5304[184] = (char *(*)()) F606_6013;
	R5304[185] = (char *(*)()) F608_6013;
	R5304[186] = (char *(*)()) F920_6900;
	R5304[187] = (char *(*)()) F921_6900;
	{long i; for (i = 188; i < 190; i++) R5304[i] = (char *(*)()) F606_6013;}
	R5304[190] = (char *(*)()) F607_6013;
	R5304[191] = (char *(*)()) F608_6013;
	R5304[192] = (char *(*)()) F609_6013;
	R5304[193] = (char *(*)()) F610_6013;
	R5304[194] = (char *(*)()) F611_6013;
	R5304[195] = (char *(*)()) F612_6013;
	R5304[196] = (char *(*)()) F613_6013;
	R5304[197] = (char *(*)()) F614_6013;
	R5304[198] = (char *(*)()) F615_6013;
	R5304[199] = (char *(*)()) F616_6013;
	R5304[200] = (char *(*)()) F617_6013;
	R5304[201] = (char *(*)()) F935_6989;
	R5304[202] = (char *(*)()) F936_6989;
	{long i; for (i = 203; i < 205; i++) R5304[i] = (char *(*)()) F606_6013;}
	R5304[320] = (char *(*)()) F1054_8260;
	R5304[324] = (char *(*)()) F1058_8428;
	R5304[490] = (char *(*)()) F614_6013;
	R5304[544] = (char *(*)()) F614_6013;
	R5304[576] = (char *(*)()) F1054_8260;
}

char *(*R5306[545])();
void R5306_init () {
	{long i; for (i = 0; i < 2; i++) R5306[i] = (char *(*)()) F733_6088_5306_1;}
	{long i; for (i = 69; i < 71; i++) R5306[i] = (char *(*)()) F802_6214_5306_1;}
	R5306[184] = (char *(*)()) F918_6850;
	R5306[185] = (char *(*)()) F919_6850_5306_1;
	R5306[186] = (char *(*)()) F918_6850;
	R5306[187] = (char *(*)()) F919_6850_5306_1;
	R5306[188] = (char *(*)()) F918_6850;
	R5306[189] = (char *(*)()) F923_6923;
	R5306[190] = (char *(*)()) F924_6923_5306_1;
	R5306[191] = (char *(*)()) F925_6923_5306_1;
	R5306[192] = (char *(*)()) F926_6923_5306_1;
	R5306[193] = (char *(*)()) F927_6923_5306_1;
	R5306[194] = (char *(*)()) F928_6923_5306_1;
	R5306[195] = (char *(*)()) F929_6923_5306_1;
	R5306[196] = (char *(*)()) F930_6923_5306_1;
	R5306[197] = (char *(*)()) F931_6923_5306_1;
	R5306[198] = (char *(*)()) F932_6923_5306_1;
	R5306[199] = (char *(*)()) F933_6923_5306_1;
	R5306[200] = (char *(*)()) F934_6923_5306_1;
	R5306[201] = (char *(*)()) F923_6923;
	R5306[202] = (char *(*)()) F925_6923_5306_1;
	{long i; for (i = 203; i < 205; i++) R5306[i] = (char *(*)()) F923_6923;}
	R5306[490] = (char *(*)()) F802_6214_5306_1;
	R5306[544] = (char *(*)()) F802_6214_5306_1;
}
static EIF_REFERENCE F733_6088_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F733_6088(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_6214_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F802_6214(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F919_6850_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F919_6850(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F924_6923_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F924_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F925_6923_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F925_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F926_6923_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F926_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F927_6923_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F927_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F928_6923_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F928_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F929_6923_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F929_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F930_6923_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F930_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1184, 0x00).id, 1184, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F931_6923_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F931_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F932_6923_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F932_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F933_6923_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F933_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F934_6923_5306_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F934_6923(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5307[545])();
void R5307_init () {
	{long i; for (i = 0; i < 2; i++) R5307[i] = (char *(*)()) F608_6006;}
	{long i; for (i = 69; i < 71; i++) R5307[i] = (char *(*)()) F802_6235;}
	R5307[184] = (char *(*)()) F918_6861;
	R5307[185] = (char *(*)()) F919_6861;
	R5307[186] = (char *(*)()) F918_6861;
	R5307[187] = (char *(*)()) F919_6861;
	R5307[188] = (char *(*)()) F918_6861;
	R5307[189] = (char *(*)()) F870_6813;
	R5307[190] = (char *(*)()) F871_6813;
	R5307[191] = (char *(*)()) F872_6813;
	R5307[192] = (char *(*)()) F873_6813;
	R5307[193] = (char *(*)()) F874_6813;
	R5307[194] = (char *(*)()) F875_6813;
	R5307[195] = (char *(*)()) F876_6813;
	R5307[196] = (char *(*)()) F877_6813;
	R5307[197] = (char *(*)()) F878_6813;
	R5307[198] = (char *(*)()) F879_6813;
	R5307[199] = (char *(*)()) F880_6813;
	R5307[200] = (char *(*)()) F881_6813;
	R5307[201] = (char *(*)()) F870_6813;
	R5307[202] = (char *(*)()) F872_6813;
	{long i; for (i = 203; i < 205; i++) R5307[i] = (char *(*)()) F870_6813;}
	R5307[490] = (char *(*)()) F802_6235;
	R5307[544] = (char *(*)()) F802_6235;
}

char *(*R5308[545])();
void R5308_init () {
	{long i; for (i = 0; i < 2; i++) R5308[i] = (char *(*)()) F733_6096;}
	{long i; for (i = 69; i < 71; i++) R5308[i] = (char *(*)()) F802_6290;}
	R5308[184] = (char *(*)()) F918_6867;
	R5308[185] = (char *(*)()) F919_6867;
	R5308[186] = (char *(*)()) F918_6867;
	R5308[187] = (char *(*)()) F919_6867;
	R5308[188] = (char *(*)()) F918_6867;
	R5308[189] = (char *(*)()) F923_6949;
	R5308[190] = (char *(*)()) F924_6949;
	R5308[191] = (char *(*)()) F925_6949;
	R5308[192] = (char *(*)()) F926_6949;
	R5308[193] = (char *(*)()) F927_6949;
	R5308[194] = (char *(*)()) F928_6949;
	R5308[195] = (char *(*)()) F929_6949;
	R5308[196] = (char *(*)()) F930_6949;
	R5308[197] = (char *(*)()) F931_6949;
	R5308[198] = (char *(*)()) F932_6949;
	R5308[199] = (char *(*)()) F933_6949;
	R5308[200] = (char *(*)()) F934_6949;
	R5308[201] = (char *(*)()) F923_6949;
	R5308[202] = (char *(*)()) F925_6949;
	{long i; for (i = 203; i < 205; i++) R5308[i] = (char *(*)()) F923_6949;}
	R5308[490] = (char *(*)()) F802_6290;
	R5308[544] = (char *(*)()) F802_6290;
}

char *(*R5314[545])();
void R5314_init () {
	{long i; for (i = 0; i < 2; i++) R5314[i] = (char *(*)()) F608_6000_5314_4;}
	{long i; for (i = 69; i < 71; i++) R5314[i] = (char *(*)()) F626_6017_5314_4;}
	R5314[184] = (char *(*)()) F618_6017;
	R5314[185] = (char *(*)()) F620_6017_5314_4;
	R5314[186] = (char *(*)()) F618_6017;
	R5314[187] = (char *(*)()) F620_6017_5314_4;
	R5314[188] = (char *(*)()) F618_6017;
	R5314[189] = (char *(*)()) F923_6955;
	R5314[190] = (char *(*)()) F924_6955_5314_4;
	R5314[191] = (char *(*)()) F925_6955_5314_4;
	R5314[192] = (char *(*)()) F926_6955_5314_4;
	R5314[193] = (char *(*)()) F927_6955_5314_4;
	R5314[194] = (char *(*)()) F928_6955_5314_4;
	R5314[195] = (char *(*)()) F929_6955_5314_4;
	R5314[196] = (char *(*)()) F930_6955_5314_4;
	R5314[197] = (char *(*)()) F931_6955_5314_4;
	R5314[198] = (char *(*)()) F932_6955_5314_4;
	R5314[199] = (char *(*)()) F933_6955_5314_4;
	R5314[200] = (char *(*)()) F934_6955_5314_4;
	R5314[201] = (char *(*)()) F923_6955;
	R5314[202] = (char *(*)()) F925_6955_5314_4;
	{long i; for (i = 203; i < 205; i++) R5314[i] = (char *(*)()) F923_6955;}
	R5314[490] = (char *(*)()) F626_6017_5314_4;
	R5314[544] = (char *(*)()) F626_6017_5314_4;
}
static void F608_6000_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F608_6000(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F626_6017_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F626_6017(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F620_6017_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F620_6017(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F924_6955_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F924_6955(Current, *(EIF_BOOLEAN *)arg1);
}
static void F925_6955_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F925_6955(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F926_6955_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F926_6955(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F927_6955_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F927_6955(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F928_6955_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F928_6955(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F929_6955_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F929_6955(Current, *(EIF_REAL_32 *)arg1);
}
static void F930_6955_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F930_6955(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F931_6955_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F931_6955(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F932_6955_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F932_6955(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F933_6955_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F933_6955(Current, *(EIF_POINTER *)arg1);
}
static void F934_6955_5314_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F934_6955(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R5315[545])();
void R5315_init () {
	{long i; for (i = 0; i < 2; i++) R5315[i] = (char *(*)()) F733_6087;}
	{long i; for (i = 69; i < 71; i++) R5315[i] = (char *(*)()) F802_6215;}
	R5315[184] = (char *(*)()) F918_6853;
	R5315[185] = (char *(*)()) F919_6853;
	R5315[186] = (char *(*)()) F918_6853;
	R5315[187] = (char *(*)()) F919_6853;
	R5315[188] = (char *(*)()) F918_6853;
	R5315[189] = (char *(*)()) F923_6928;
	R5315[190] = (char *(*)()) F924_6928;
	R5315[191] = (char *(*)()) F925_6928;
	R5315[192] = (char *(*)()) F926_6928;
	R5315[193] = (char *(*)()) F927_6928;
	R5315[194] = (char *(*)()) F928_6928;
	R5315[195] = (char *(*)()) F929_6928;
	R5315[196] = (char *(*)()) F930_6928;
	R5315[197] = (char *(*)()) F931_6928;
	R5315[198] = (char *(*)()) F932_6928;
	R5315[199] = (char *(*)()) F933_6928;
	R5315[200] = (char *(*)()) F934_6928;
	R5315[201] = (char *(*)()) F923_6928;
	R5315[202] = (char *(*)()) F925_6928;
	{long i; for (i = 203; i < 205; i++) R5315[i] = (char *(*)()) F923_6928;}
	R5315[490] = (char *(*)()) F802_6215;
	R5315[544] = (char *(*)()) F802_6215;
}

char *(*R5318[545])();
void R5318_init () {
	{long i; for (i = 0; i < 2; i++) R5318[i] = (char *(*)()) F608_6004;}
	{long i; for (i = 69; i < 71; i++) R5318[i] = (char *(*)()) F614_6004;}
	R5318[184] = (char *(*)()) F606_6004;
	R5318[185] = (char *(*)()) F608_6004;
	R5318[186] = (char *(*)()) F606_6004;
	R5318[187] = (char *(*)()) F608_6004;
	{long i; for (i = 188; i < 190; i++) R5318[i] = (char *(*)()) F606_6004;}
	R5318[190] = (char *(*)()) F607_6004;
	R5318[191] = (char *(*)()) F608_6004;
	R5318[192] = (char *(*)()) F609_6004;
	R5318[193] = (char *(*)()) F610_6004;
	R5318[194] = (char *(*)()) F611_6004;
	R5318[195] = (char *(*)()) F612_6004;
	R5318[196] = (char *(*)()) F613_6004;
	R5318[197] = (char *(*)()) F614_6004;
	R5318[198] = (char *(*)()) F615_6004;
	R5318[199] = (char *(*)()) F616_6004;
	R5318[200] = (char *(*)()) F617_6004;
	R5318[201] = (char *(*)()) F606_6004;
	R5318[202] = (char *(*)()) F608_6004;
	{long i; for (i = 203; i < 205; i++) R5318[i] = (char *(*)()) F606_6004;}
	R5318[490] = (char *(*)()) F614_6004;
	R5318[544] = (char *(*)()) F614_6004;
}

char *(*R5319[545])();
void R5319_init () {
	{long i; for (i = 0; i < 2; i++) R5319[i] = (char *(*)()) F733_6089;}
	{long i; for (i = 69; i < 71; i++) R5319[i] = (char *(*)()) F802_6233;}
	R5319[184] = (char *(*)()) F918_6859;
	R5319[185] = (char *(*)()) F919_6859;
	R5319[186] = (char *(*)()) F918_6859;
	R5319[187] = (char *(*)()) F919_6859;
	R5319[188] = (char *(*)()) F918_6859;
	R5319[189] = (char *(*)()) F894_6837;
	R5319[190] = (char *(*)()) F895_6837;
	R5319[191] = (char *(*)()) F896_6837;
	R5319[192] = (char *(*)()) F897_6837;
	R5319[193] = (char *(*)()) F898_6837;
	R5319[194] = (char *(*)()) F899_6837;
	R5319[195] = (char *(*)()) F900_6837;
	R5319[196] = (char *(*)()) F901_6837;
	R5319[197] = (char *(*)()) F902_6837;
	R5319[198] = (char *(*)()) F903_6837;
	R5319[199] = (char *(*)()) F904_6837;
	R5319[200] = (char *(*)()) F905_6837;
	R5319[201] = (char *(*)()) F894_6837;
	R5319[202] = (char *(*)()) F896_6837;
	{long i; for (i = 203; i < 205; i++) R5319[i] = (char *(*)()) F894_6837;}
	R5319[490] = (char *(*)()) F802_6233;
	R5319[544] = (char *(*)()) F802_6233;
}

char *(*R5320[21])();
void R5320_init () {
	R5320[0] = (char *(*)()) F918_6868;
	R5320[1] = (char *(*)()) F919_6868;
	R5320[2] = (char *(*)()) F918_6868;
	R5320[3] = (char *(*)()) F919_6868;
	R5320[4] = (char *(*)()) F918_6868;
	R5320[5] = (char *(*)()) F923_6950;
	R5320[6] = (char *(*)()) F924_6950;
	R5320[7] = (char *(*)()) F925_6950;
	R5320[8] = (char *(*)()) F926_6950;
	R5320[9] = (char *(*)()) F927_6950;
	R5320[10] = (char *(*)()) F928_6950;
	R5320[11] = (char *(*)()) F929_6950;
	R5320[12] = (char *(*)()) F930_6950;
	R5320[13] = (char *(*)()) F931_6950;
	R5320[14] = (char *(*)()) F932_6950;
	R5320[15] = (char *(*)()) F933_6950;
	R5320[16] = (char *(*)()) F934_6950;
	R5320[17] = (char *(*)()) F923_6950;
	R5320[18] = (char *(*)()) F925_6950;
	{long i; for (i = 19; i < 21; i++) R5320[i] = (char *(*)()) F923_6950;}
}

char *(*R5321[545])();
void R5321_init () {
	{long i; for (i = 0; i < 2; i++) R5321[i] = (char *(*)()) F733_6095;}
	{long i; for (i = 69; i < 71; i++) R5321[i] = (char *(*)()) F802_6292;}
	R5321[184] = (char *(*)()) F918_6869;
	R5321[185] = (char *(*)()) F919_6869;
	R5321[186] = (char *(*)()) F918_6869;
	R5321[187] = (char *(*)()) F919_6869;
	R5321[188] = (char *(*)()) F918_6869;
	R5321[189] = (char *(*)()) F923_6951;
	R5321[190] = (char *(*)()) F924_6951;
	R5321[191] = (char *(*)()) F925_6951;
	R5321[192] = (char *(*)()) F926_6951;
	R5321[193] = (char *(*)()) F927_6951;
	R5321[194] = (char *(*)()) F928_6951;
	R5321[195] = (char *(*)()) F929_6951;
	R5321[196] = (char *(*)()) F930_6951;
	R5321[197] = (char *(*)()) F931_6951;
	R5321[198] = (char *(*)()) F932_6951;
	R5321[199] = (char *(*)()) F933_6951;
	R5321[200] = (char *(*)()) F934_6951;
	R5321[201] = (char *(*)()) F923_6951;
	R5321[202] = (char *(*)()) F925_6951;
	{long i; for (i = 203; i < 205; i++) R5321[i] = (char *(*)()) F923_6951;}
	R5321[490] = (char *(*)()) F802_6292;
	R5321[544] = (char *(*)()) F802_6292;
}

char *(*R5322[476])();
void R5322_init () {
	{long i; for (i = 0; i < 2; i++) R5322[i] = (char *(*)()) F802_6234;}
	R5322[115] = (char *(*)()) F918_6860;
	R5322[116] = (char *(*)()) F919_6860;
	R5322[117] = (char *(*)()) F918_6860;
	R5322[118] = (char *(*)()) F919_6860;
	R5322[119] = (char *(*)()) F918_6860;
	R5322[120] = (char *(*)()) F894_6838;
	R5322[121] = (char *(*)()) F895_6838;
	R5322[122] = (char *(*)()) F896_6838;
	R5322[123] = (char *(*)()) F897_6838;
	R5322[124] = (char *(*)()) F898_6838;
	R5322[125] = (char *(*)()) F899_6838;
	R5322[126] = (char *(*)()) F900_6838;
	R5322[127] = (char *(*)()) F901_6838;
	R5322[128] = (char *(*)()) F902_6838;
	R5322[129] = (char *(*)()) F903_6838;
	R5322[130] = (char *(*)()) F904_6838;
	R5322[131] = (char *(*)()) F905_6838;
	R5322[132] = (char *(*)()) F894_6838;
	R5322[133] = (char *(*)()) F896_6838;
	{long i; for (i = 134; i < 136; i++) R5322[i] = (char *(*)()) F894_6838;}
	R5322[421] = (char *(*)()) F802_6234;
	R5322[475] = (char *(*)()) F802_6234;
}

char *(*R5323[476])();
void R5323_init () {
	{long i; for (i = 0; i < 2; i++) R5323[i] = (char *(*)()) F802_6293;}
	R5323[115] = (char *(*)()) F918_6870;
	R5323[116] = (char *(*)()) F919_6870;
	R5323[117] = (char *(*)()) F918_6870;
	R5323[118] = (char *(*)()) F919_6870;
	R5323[119] = (char *(*)()) F918_6870;
	R5323[120] = (char *(*)()) F923_6952;
	R5323[121] = (char *(*)()) F924_6952;
	R5323[122] = (char *(*)()) F925_6952;
	R5323[123] = (char *(*)()) F926_6952;
	R5323[124] = (char *(*)()) F927_6952;
	R5323[125] = (char *(*)()) F928_6952;
	R5323[126] = (char *(*)()) F929_6952;
	R5323[127] = (char *(*)()) F930_6952;
	R5323[128] = (char *(*)()) F931_6952;
	R5323[129] = (char *(*)()) F932_6952;
	R5323[130] = (char *(*)()) F933_6952;
	R5323[131] = (char *(*)()) F934_6952;
	R5323[132] = (char *(*)()) F923_6952;
	R5323[133] = (char *(*)()) F925_6952;
	{long i; for (i = 134; i < 136; i++) R5323[i] = (char *(*)()) F923_6952;}
	R5323[421] = (char *(*)()) F1224_10407;
	R5323[475] = (char *(*)()) F802_6293;
}

char *(*R5324[577])();
void R5324_init () {
	{long i; for (i = 0; i < 2; i++) R5324[i] = (char *(*)()) F733_6090;}
	R5324[41] = (char *(*)()) F775_6168;
	{long i; for (i = 69; i < 71; i++) R5324[i] = (char *(*)()) F802_6266;}
	R5324[92] = (char *(*)()) F826_6595;
	R5324[93] = (char *(*)()) F827_6595;
	R5324[94] = (char *(*)()) F828_6595;
	R5324[95] = (char *(*)()) F829_6595;
	R5324[96] = (char *(*)()) F830_6595;
	R5324[97] = (char *(*)()) F831_6595;
	R5324[98] = (char *(*)()) F832_6595;
	R5324[99] = (char *(*)()) F833_6595;
	{long i; for (i = 100; i < 102; i++) R5324[i] = (char *(*)()) F826_6595;}
	R5324[102] = (char *(*)()) F828_6595;
	R5324[103] = (char *(*)()) F829_6595;
	R5324[104] = (char *(*)()) F831_6595;
	R5324[105] = (char *(*)()) F832_6595;
	R5324[118] = (char *(*)()) F852_6715;
	R5324[119] = (char *(*)()) F853_6760;
	R5324[120] = (char *(*)()) F854_6760;
	R5324[121] = (char *(*)()) F855_6760;
	R5324[122] = (char *(*)()) F856_6760;
	R5324[123] = (char *(*)()) F857_6760;
	R5324[124] = (char *(*)()) F858_6760;
	R5324[125] = (char *(*)()) F859_6760;
	R5324[126] = (char *(*)()) F860_6760;
	R5324[127] = (char *(*)()) F861_6760;
	R5324[128] = (char *(*)()) F862_6760;
	R5324[129] = (char *(*)()) F863_6760;
	R5324[130] = (char *(*)()) F864_6760;
	R5324[184] = (char *(*)()) F882_6822;
	R5324[185] = (char *(*)()) F884_6822;
	R5324[186] = (char *(*)()) F882_6822;
	R5324[187] = (char *(*)()) F884_6822;
	{long i; for (i = 188; i < 190; i++) R5324[i] = (char *(*)()) F882_6822;}
	R5324[190] = (char *(*)()) F883_6822;
	R5324[191] = (char *(*)()) F884_6822;
	R5324[192] = (char *(*)()) F885_6822;
	R5324[193] = (char *(*)()) F886_6822;
	R5324[194] = (char *(*)()) F887_6822;
	R5324[195] = (char *(*)()) F888_6822;
	R5324[196] = (char *(*)()) F889_6822;
	R5324[197] = (char *(*)()) F890_6822;
	R5324[198] = (char *(*)()) F891_6822;
	R5324[199] = (char *(*)()) F892_6822;
	R5324[200] = (char *(*)()) F893_6822;
	R5324[201] = (char *(*)()) F882_6822;
	R5324[202] = (char *(*)()) F884_6822;
	{long i; for (i = 203; i < 205; i++) R5324[i] = (char *(*)()) F882_6822;}
	R5324[320] = (char *(*)()) F1054_8189;
	R5324[324] = (char *(*)()) F1058_8357;
	R5324[490] = (char *(*)()) F802_6266;
	R5324[544] = (char *(*)()) F802_6266;
	R5324[576] = (char *(*)()) F1054_8189;
}

char *(*R5328[577])();
void R5328_init () {
	{long i; for (i = 0; i < 2; i++) R5328[i] = (char *(*)()) F733_6097_5328_4;}
	R5328[41] = (char *(*)()) F775_6170;
	{long i; for (i = 69; i < 71; i++) R5328[i] = (char *(*)()) F802_6299_5328_4;}
	R5328[92] = (char *(*)()) F826_6679;
	R5328[93] = (char *(*)()) F827_6679;
	R5328[94] = (char *(*)()) F828_6679_5328_4;
	R5328[95] = (char *(*)()) F829_6679_5328_4;
	R5328[96] = (char *(*)()) F830_6679_5328_4;
	R5328[97] = (char *(*)()) F831_6679_5328_4;
	R5328[98] = (char *(*)()) F832_6679_5328_4;
	R5328[99] = (char *(*)()) F833_6679_5328_4;
	{long i; for (i = 100; i < 102; i++) R5328[i] = (char *(*)()) F826_6679;}
	R5328[102] = (char *(*)()) F828_6679_5328_4;
	R5328[103] = (char *(*)()) F829_6679_5328_4;
	R5328[104] = (char *(*)()) F831_6679_5328_4;
	R5328[105] = (char *(*)()) F832_6679_5328_4;
	R5328[118] = (char *(*)()) F852_6717_5328_4;
	R5328[119] = (char *(*)()) F853_6795;
	R5328[120] = (char *(*)()) F854_6795_5328_4;
	R5328[121] = (char *(*)()) F855_6795_5328_4;
	R5328[122] = (char *(*)()) F856_6795_5328_4;
	R5328[123] = (char *(*)()) F857_6795_5328_4;
	R5328[124] = (char *(*)()) F858_6795_5328_4;
	R5328[125] = (char *(*)()) F859_6795_5328_4;
	R5328[126] = (char *(*)()) F860_6795_5328_4;
	R5328[127] = (char *(*)()) F861_6795_5328_4;
	R5328[128] = (char *(*)()) F862_6795_5328_4;
	R5328[129] = (char *(*)()) F863_6795_5328_4;
	R5328[130] = (char *(*)()) F864_6795_5328_4;
	R5328[184] = (char *(*)()) F918_6875;
	R5328[185] = (char *(*)()) F919_6875_5328_4;
	R5328[186] = (char *(*)()) F920_6897;
	R5328[187] = (char *(*)()) F921_6897_5328_4;
	R5328[188] = (char *(*)()) F922_6910;
	R5328[189] = (char *(*)()) F923_6959;
	R5328[190] = (char *(*)()) F924_6959_5328_4;
	R5328[191] = (char *(*)()) F925_6959_5328_4;
	R5328[192] = (char *(*)()) F926_6959_5328_4;
	R5328[193] = (char *(*)()) F927_6959_5328_4;
	R5328[194] = (char *(*)()) F928_6959_5328_4;
	R5328[195] = (char *(*)()) F929_6959_5328_4;
	R5328[196] = (char *(*)()) F930_6959_5328_4;
	R5328[197] = (char *(*)()) F931_6959_5328_4;
	R5328[198] = (char *(*)()) F932_6959_5328_4;
	R5328[199] = (char *(*)()) F933_6959_5328_4;
	R5328[200] = (char *(*)()) F934_6959_5328_4;
	R5328[201] = (char *(*)()) F935_6985;
	R5328[202] = (char *(*)()) F936_6985_5328_4;
	{long i; for (i = 203; i < 205; i++) R5328[i] = (char *(*)()) F923_6959;}
	R5328[320] = (char *(*)()) F1054_8231_5328_4;
	R5328[324] = (char *(*)()) F1058_8399_5328_4;
	R5328[490] = (char *(*)()) F802_6299_5328_4;
	R5328[544] = (char *(*)()) F802_6299_5328_4;
	R5328[576] = (char *(*)()) F1054_8231_5328_4;
}
static void F733_6097_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F733_6097(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F802_6299_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F802_6299(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F828_6679_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F828_6679(Current, *(EIF_BOOLEAN *)arg1);
}
static void F829_6679_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F829_6679(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F830_6679_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F830_6679(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F831_6679_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F831_6679(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F832_6679_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F832_6679(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F833_6679_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F833_6679(Current, *(EIF_POINTER *)arg1);
}
static void F852_6717_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F852_6717(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F854_6795_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F854_6795(Current, *(EIF_BOOLEAN *)arg1);
}
static void F855_6795_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F855_6795(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F856_6795_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F856_6795(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F857_6795_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_6795(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F858_6795_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F858_6795(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F859_6795_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F859_6795(Current, *(EIF_REAL_32 *)arg1);
}
static void F860_6795_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F860_6795(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F861_6795_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F861_6795(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F862_6795_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F862_6795(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F863_6795_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F863_6795(Current, *(EIF_POINTER *)arg1);
}
static void F864_6795_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F864_6795(Current, *(EIF_REAL_64 *)arg1);
}
static void F919_6875_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F919_6875(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F921_6897_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F921_6897(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F924_6959_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F924_6959(Current, *(EIF_BOOLEAN *)arg1);
}
static void F925_6959_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F925_6959(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F926_6959_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F926_6959(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F927_6959_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F927_6959(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F928_6959_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F928_6959(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F929_6959_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F929_6959(Current, *(EIF_REAL_32 *)arg1);
}
static void F930_6959_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F930_6959(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F931_6959_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F931_6959(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F932_6959_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F932_6959(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F933_6959_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F933_6959(Current, *(EIF_POINTER *)arg1);
}
static void F934_6959_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F934_6959(Current, *(EIF_REAL_64 *)arg1);
}
static void F936_6985_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F936_6985(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1054_8231_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1054_8231(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1058_8399_5328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1058_8399(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R5329[577])();
void R5329_init () {
	{long i; for (i = 0; i < 2; i++) R5329[i] = (char *(*)()) F632_6023;}
	R5329[41] = (char *(*)()) F630_6023;
	{long i; for (i = 69; i < 71; i++) R5329[i] = (char *(*)()) F638_6023;}
	{long i; for (i = 92; i < 94; i++) R5329[i] = (char *(*)()) F630_6023;}
	R5329[94] = (char *(*)()) F631_6023;
	{long i; for (i = 95; i < 97; i++) R5329[i] = (char *(*)()) F632_6023;}
	R5329[97] = (char *(*)()) F633_6023;
	R5329[98] = (char *(*)()) F639_6023;
	R5329[99] = (char *(*)()) F640_6023;
	{long i; for (i = 100; i < 102; i++) R5329[i] = (char *(*)()) F630_6023;}
	R5329[102] = (char *(*)()) F631_6023;
	R5329[103] = (char *(*)()) F632_6023;
	R5329[104] = (char *(*)()) F633_6023;
	R5329[105] = (char *(*)()) F639_6023;
	R5329[118] = (char *(*)()) F632_6023;
	R5329[119] = (char *(*)()) F630_6023;
	R5329[120] = (char *(*)()) F631_6023;
	R5329[121] = (char *(*)()) F632_6023;
	R5329[122] = (char *(*)()) F633_6023;
	R5329[123] = (char *(*)()) F634_6023;
	R5329[124] = (char *(*)()) F635_6023;
	R5329[125] = (char *(*)()) F636_6023;
	R5329[126] = (char *(*)()) F637_6023;
	R5329[127] = (char *(*)()) F638_6023;
	R5329[128] = (char *(*)()) F639_6023;
	R5329[129] = (char *(*)()) F640_6023;
	R5329[130] = (char *(*)()) F641_6023;
	R5329[186] = (char *(*)()) F776_6193;
	R5329[187] = (char *(*)()) F777_6193;
	R5329[201] = (char *(*)()) F776_6193;
	R5329[202] = (char *(*)()) F777_6193;
	R5329[320] = (char *(*)()) F638_6023;
	R5329[324] = (char *(*)()) F635_6023;
	R5329[490] = (char *(*)()) F638_6023;
	R5329[544] = (char *(*)()) F638_6023;
	R5329[576] = (char *(*)()) F638_6023;
}

char *(*R5334[459])();
void R5334_init () {
	R5334[0] = (char *(*)()) F852_6705_5334_5;
	R5334[1] = (char *(*)()) F853_6744_5334_5;
	R5334[2] = (char *(*)()) F854_6744_5334_5;
	R5334[3] = (char *(*)()) F855_6744_5334_5;
	R5334[4] = (char *(*)()) F856_6744_5334_5;
	R5334[5] = (char *(*)()) F857_6744_5334_5;
	R5334[6] = (char *(*)()) F858_6744_5334_5;
	R5334[7] = (char *(*)()) F859_6744_5334_5;
	R5334[8] = (char *(*)()) F860_6744_5334_5;
	R5334[9] = (char *(*)()) F861_6744_5334_5;
	R5334[10] = (char *(*)()) F862_6744_5334_5;
	R5334[11] = (char *(*)()) F863_6744_5334_5;
	R5334[12] = (char *(*)()) F864_6744_5334_5;
	R5334[66] = (char *(*)()) F870_6802_5334_5;
	R5334[67] = (char *(*)()) F872_6802_5334_5;
	R5334[68] = (char *(*)()) F870_6802_5334_5;
	R5334[69] = (char *(*)()) F872_6802_5334_5;
	R5334[70] = (char *(*)()) F870_6802_5334_5;
	R5334[71] = (char *(*)()) F923_6924_5334_5;
	R5334[72] = (char *(*)()) F924_6924_5334_5;
	R5334[73] = (char *(*)()) F925_6924_5334_5;
	R5334[74] = (char *(*)()) F926_6924_5334_5;
	R5334[75] = (char *(*)()) F927_6924_5334_5;
	R5334[76] = (char *(*)()) F928_6924_5334_5;
	R5334[77] = (char *(*)()) F929_6924_5334_5;
	R5334[78] = (char *(*)()) F930_6924_5334_5;
	R5334[79] = (char *(*)()) F931_6924_5334_5;
	R5334[80] = (char *(*)()) F932_6924_5334_5;
	R5334[81] = (char *(*)()) F933_6924_5334_5;
	R5334[82] = (char *(*)()) F934_6924_5334_5;
	R5334[83] = (char *(*)()) F923_6924_5334_5;
	R5334[84] = (char *(*)()) F925_6924_5334_5;
	{long i; for (i = 85; i < 87; i++) R5334[i] = (char *(*)()) F923_6924_5334_5;}
	R5334[202] = (char *(*)()) F1054_8183_5334_5;
	R5334[206] = (char *(*)()) F1058_8352_5334_5;
	R5334[458] = (char *(*)()) F1310_13012_5334_5;
}
static EIF_REFERENCE F852_6705_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F852_6705(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_6744_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F853_6744(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F854_6744_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F854_6744(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_6744_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F855_6744(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_6744_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F856_6744(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6744_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F857_6744(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_6744_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F858_6744(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_6744_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F859_6744(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F860_6744_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F860_6744(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1184, 0x00).id, 1184, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F861_6744_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F861_6744(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F862_6744_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F862_6744(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F863_6744_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F863_6744(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F864_6744_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F864_6744(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F870_6802_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F870_6802(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F872_6802_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F872_6802(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F923_6924_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F923_6924(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F924_6924_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F924_6924(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F925_6924_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F925_6924(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F926_6924_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F926_6924(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F927_6924_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F927_6924(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F928_6924_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F928_6924(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F929_6924_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F929_6924(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F930_6924_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F930_6924(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1184, 0x00).id, 1184, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F931_6924_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F931_6924(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F932_6924_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F932_6924(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F933_6924_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F933_6924(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F934_6924_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F934_6924(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1054_8183_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1054_8183(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1058_8352_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1058_8352(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1310_13012_5334_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1310_13012(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}


#ifdef __cplusplus
}
#endif
