#include "epoly3.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

static EIF_TYPE_INDEX Y4414_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype12[] = {1205,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype13[] = {1205,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype45[] = {0xFF01,936,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype46[] = {0xFF01,1264,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype47[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype48[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype49[] = {1008,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype50[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y4414_pgtype51[] = {1002,0xFFFF};
EIF_TYPE_INDEX *Y4414_gen_type [914];
EIF_TYPE_INDEX Y4414 [914];
void Y4414_init (void)
{
	egc_routines_types [4414] = Y4414;
	egc_routines_gen_types [4414] = Y4414_gen_type;
	egc_routines_offset [4414] = 397;
	Y4414_gen_type [0] = Y4414_pgtype0;
	Y4414_gen_type [1] = Y4414_pgtype1;
	Y4414_gen_type [2] = Y4414_pgtype2;
	Y4414_gen_type [3] = Y4414_pgtype3;
	Y4414_gen_type [4] = Y4414_pgtype4;
	Y4414_gen_type [5] = Y4414_pgtype5;
	Y4414_gen_type [6] = Y4414_pgtype6;
	Y4414_gen_type [7] = Y4414_pgtype7;
	Y4414_gen_type [8] = Y4414_pgtype8;
	Y4414_gen_type [9] = Y4414_pgtype9;
	Y4414_gen_type [10] = Y4414_pgtype10;
	Y4414_gen_type [11] = Y4414_pgtype11;
	Y4414_gen_type [20] = Y4414_pgtype12;
	Y4414_gen_type [21] = Y4414_pgtype13;
	Y4414_gen_type [455] = Y4414_pgtype14;
	Y4414_gen_type [456] = Y4414_pgtype15;
	Y4414_gen_type [457] = Y4414_pgtype16;
	Y4414_gen_type [458] = Y4414_pgtype17;
	Y4414_gen_type [459] = Y4414_pgtype18;
	Y4414_gen_type [460] = Y4414_pgtype19;
	Y4414_gen_type [461] = Y4414_pgtype20;
	Y4414_gen_type [462] = Y4414_pgtype21;
	Y4414_gen_type [463] = Y4414_pgtype22;
	Y4414_gen_type [464] = Y4414_pgtype23;
	Y4414_gen_type [465] = Y4414_pgtype24;
	Y4414_gen_type [466] = Y4414_pgtype25;
	Y4414_gen_type [467] = Y4414_pgtype26;
	Y4414_gen_type [468] = Y4414_pgtype27;
	Y4414_gen_type [469] = Y4414_pgtype28;
	Y4414_gen_type [470] = Y4414_pgtype29;
	Y4414_gen_type [471] = Y4414_pgtype30;
	Y4414_gen_type [525] = Y4414_pgtype31;
	Y4414_gen_type [526] = Y4414_pgtype32;
	Y4414_gen_type [527] = Y4414_pgtype33;
	Y4414_gen_type [528] = Y4414_pgtype34;
	Y4414_gen_type [529] = Y4414_pgtype35;
	Y4414_gen_type [530] = Y4414_pgtype36;
	Y4414_gen_type [531] = Y4414_pgtype37;
	Y4414_gen_type [532] = Y4414_pgtype38;
	Y4414_gen_type [533] = Y4414_pgtype39;
	Y4414_gen_type [534] = Y4414_pgtype40;
	Y4414_gen_type [535] = Y4414_pgtype41;
	Y4414_gen_type [536] = Y4414_pgtype42;
	Y4414_gen_type [537] = Y4414_pgtype43;
	Y4414_gen_type [538] = Y4414_pgtype44;
	Y4414_gen_type [539] = Y4414_pgtype45;
	Y4414_gen_type [540] = Y4414_pgtype46;
	Y4414_gen_type [656] = Y4414_pgtype47;
	Y4414_gen_type [657] = Y4414_pgtype48;
	Y4414_gen_type [660] = Y4414_pgtype49;
	Y4414_gen_type [912] = Y4414_pgtype50;
	Y4414_gen_type [913] = Y4414_pgtype51;
	{long i; for (i = 20; i < 22; i++) Y4414[i] = 1205;};
	Y4414[539] = 936;
	Y4414[540] = 1264;
	{long i; for (i = 656; i < 658; i++) Y4414[i] = 1002;};
	Y4414[660] = 1008;
	{long i; for (i = 912; i < 914; i++) Y4414[i] = 1002;};
}

char *(*R4894[476])();
void R4894_init () {
	{long i; for (i = 0; i < 2; i++) R4894[i] = (char *(*)()) F802_6237;}
	R4894[421] = (char *(*)()) F1224_10404;
	R4894[475] = (char *(*)()) F802_6237;
}

char *(*R4902[847])();
void R4902_init () {
	R4902[0] = (char *(*)()) F432_5480;
	{long i; for (i = 371; i < 373; i++) R4902[i] = (char *(*)()) F802_6261;}
	R4902[792] = (char *(*)()) F802_6261;
	R4902[846] = (char *(*)()) F802_6261;
}

char *(*R4904[847])();
void R4904_init () {
	R4904[0] = (char *(*)()) F432_5479;
	{long i; for (i = 371; i < 373; i++) R4904[i] = (char *(*)()) F802_6289;}
	R4904[792] = (char *(*)()) F802_6289;
	R4904[846] = (char *(*)()) F802_6289;
}

char *(*R4905[476])();
void R4905_init () {
	{long i; for (i = 0; i < 2; i++) R4905[i] = (char *(*)()) F802_6316;}
	R4905[421] = (char *(*)()) F1224_10435;
	R4905[475] = (char *(*)()) F802_6316;
}

char *(*R4907[476])();
void R4907_init () {
	{long i; for (i = 0; i < 2; i++) R4907[i] = (char *(*)()) F802_6311;}
	R4907[421] = (char *(*)()) F1224_10427;
	R4907[475] = (char *(*)()) F802_6311;
}

char *(*R4909[476])();
void R4909_init () {
	{long i; for (i = 0; i < 2; i++) R4909[i] = (char *(*)()) F802_6314;}
	R4909[421] = (char *(*)()) F1224_10425;
	R4909[475] = (char *(*)()) F802_6314;
}

char *(*R4937[476])();
void R4937_init () {
	{long i; for (i = 0; i < 2; i++) R4937[i] = (char *(*)()) F802_6344;}
	R4937[421] = (char *(*)()) F1224_10422;
	R4937[475] = (char *(*)()) F802_6344;
}

char *(*R4939[476])();
void R4939_init () {
	R4939[0] = (char *(*)()) F803_6456;
	R4939[1] = (char *(*)()) F804_6515;
	R4939[421] = (char *(*)()) F803_6456;
	R4939[475] = (char *(*)()) F804_6515;
}

char *(*R4945[476])();
void R4945_init () {
	R4945[0] = (char *(*)()) F803_6465;
	R4945[1] = (char *(*)()) F804_6521;
	R4945[421] = (char *(*)()) F803_6465;
	R4945[475] = (char *(*)()) F804_6521;
}

char *(*R4950[476])();
void R4950_init () {
	{long i; for (i = 0; i < 2; i++) R4950[i] = (char *(*)()) F802_6351;}
	R4950[421] = (char *(*)()) F1224_10416;
	R4950[475] = (char *(*)()) F802_6351;
}

char *(*R4953[476])();
void R4953_init () {
	{long i; for (i = 0; i < 2; i++) R4953[i] = (char *(*)()) F802_6348;}
	R4953[421] = (char *(*)()) F1224_10413;
	R4953[475] = (char *(*)()) F802_6348;
}

char *(*R4980[291])();
void R4980_init () {
	R4980[0] = (char *(*)()) F445_5567;
	R4980[1] = (char *(*)()) F446_5576_4980_1;
	R4980[2] = (char *(*)()) F447_5583;
	R4980[3] = (char *(*)()) F448_5583_4980_1;
	R4980[4] = (char *(*)()) F449_5583_4980_1;
	R4980[64] = (char *(*)()) F497_5879;
	R4980[65] = (char *(*)()) F498_5879_4980_1;
	R4980[66] = (char *(*)()) F499_5879_4980_1;
	R4980[67] = (char *(*)()) F500_5879_4980_1;
	R4980[68] = (char *(*)()) F501_5879_4980_1;
	R4980[69] = (char *(*)()) F502_5879_4980_1;
	R4980[70] = (char *(*)()) F503_5879_4980_1;
	R4980[71] = (char *(*)()) F504_5879_4980_1;
	R4980[72] = (char *(*)()) F505_5879_4980_1;
	R4980[73] = (char *(*)()) F506_5879_4980_1;
	R4980[74] = (char *(*)()) F507_5879_4980_1;
	R4980[75] = (char *(*)()) F508_5879_4980_1;
	R4980[76] = (char *(*)()) F521_5907;
	R4980[77] = (char *(*)()) F522_5907;
	R4980[78] = (char *(*)()) F523_5907_4980_1;
	R4980[79] = (char *(*)()) F524_5907_4980_1;
	R4980[80] = (char *(*)()) F525_5907_4980_1;
	R4980[81] = (char *(*)()) F526_5907_4980_1;
	R4980[82] = (char *(*)()) F527_5907_4980_1;
	R4980[83] = (char *(*)()) F528_5907_4980_1;
	R4980[84] = (char *(*)()) F529_5913;
	R4980[85] = (char *(*)()) F530_5913_4980_1;
	R4980[98] = (char *(*)()) F539_5919_4980_1;
	R4980[99] = (char *(*)()) F536_5919_4980_1;
	R4980[100] = (char *(*)()) F531_5919;
	R4980[101] = (char *(*)()) F532_5919_4980_1;
	R4980[102] = (char *(*)()) F533_5919_4980_1;
	R4980[103] = (char *(*)()) F534_5919_4980_1;
	R4980[104] = (char *(*)()) F535_5919_4980_1;
	R4980[105] = (char *(*)()) F536_5919_4980_1;
	R4980[106] = (char *(*)()) F537_5919_4980_1;
	R4980[107] = (char *(*)()) F538_5919_4980_1;
	R4980[108] = (char *(*)()) F539_5919_4980_1;
	R4980[109] = (char *(*)()) F540_5919_4980_1;
	R4980[110] = (char *(*)()) F541_5919_4980_1;
	R4980[111] = (char *(*)()) F542_5919_4980_1;
	R4980[112] = (char *(*)()) F531_5919;
	R4980[113] = (char *(*)()) F532_5919_4980_1;
	R4980[114] = (char *(*)()) F533_5919_4980_1;
	R4980[115] = (char *(*)()) F534_5919_4980_1;
	R4980[116] = (char *(*)()) F535_5919_4980_1;
	R4980[117] = (char *(*)()) F536_5919_4980_1;
	R4980[118] = (char *(*)()) F537_5919_4980_1;
	R4980[119] = (char *(*)()) F538_5919_4980_1;
	R4980[120] = (char *(*)()) F539_5919_4980_1;
	R4980[121] = (char *(*)()) F540_5919_4980_1;
	R4980[122] = (char *(*)()) F541_5919_4980_1;
	R4980[123] = (char *(*)()) F542_5919_4980_1;
	R4980[124] = (char *(*)()) F531_5919;
	R4980[125] = (char *(*)()) F532_5919_4980_1;
	R4980[126] = (char *(*)()) F533_5919_4980_1;
	R4980[127] = (char *(*)()) F534_5919_4980_1;
	R4980[128] = (char *(*)()) F535_5919_4980_1;
	R4980[129] = (char *(*)()) F536_5919_4980_1;
	R4980[130] = (char *(*)()) F537_5919_4980_1;
	R4980[131] = (char *(*)()) F538_5919_4980_1;
	R4980[132] = (char *(*)()) F539_5919_4980_1;
	R4980[133] = (char *(*)()) F540_5919_4980_1;
	R4980[134] = (char *(*)()) F541_5919_4980_1;
	R4980[135] = (char *(*)()) F542_5919_4980_1;
	{long i; for (i = 289; i < 291; i++) R4980[i] = (char *(*)()) F733_6088_4980_1;}
}
static EIF_REFERENCE F446_5576_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F446_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F448_5583_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F448_5583(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F449_5583_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F449_5583(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F498_5879_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F498_5879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F499_5879_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F499_5879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F500_5879_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F500_5879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F501_5879_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F501_5879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F502_5879_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F502_5879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F503_5879_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F503_5879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F504_5879_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F504_5879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1184, 0x00).id, 1184, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F505_5879_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F505_5879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F506_5879_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F506_5879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F507_5879_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F507_5879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F508_5879_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F508_5879(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F523_5907_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F523_5907(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F524_5907_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F524_5907(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F525_5907_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F525_5907(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F526_5907_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F526_5907(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F527_5907_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F527_5907(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F528_5907_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F528_5907(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F530_5913_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F530_5913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F539_5919_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F539_5919(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F536_5919_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F536_5919(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F532_5919_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F532_5919(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F533_5919_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F533_5919(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F534_5919_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F534_5919(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F535_5919_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F535_5919(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F537_5919_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F537_5919(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F538_5919_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F538_5919(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1184, 0x00).id, 1184, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F540_5919_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F540_5919(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F541_5919_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F541_5919(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F542_5919_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F542_5919(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F733_6088_4980_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F733_6088(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4981[291])();
void R4981_init () {
	R4981[0] = (char *(*)()) F445_5568;
	R4981[1] = (char *(*)()) F446_5578;
	R4981[2] = (char *(*)()) F447_5584;
	R4981[3] = (char *(*)()) F448_5584;
	R4981[4] = (char *(*)()) F449_5584;
	R4981[64] = (char *(*)()) F509_5897;
	R4981[65] = (char *(*)()) F510_5897;
	R4981[66] = (char *(*)()) F511_5897;
	R4981[67] = (char *(*)()) F512_5897;
	R4981[68] = (char *(*)()) F513_5897;
	R4981[69] = (char *(*)()) F514_5897;
	R4981[70] = (char *(*)()) F515_5897;
	R4981[71] = (char *(*)()) F516_5897;
	R4981[72] = (char *(*)()) F517_5897;
	R4981[73] = (char *(*)()) F518_5897;
	R4981[74] = (char *(*)()) F519_5897;
	R4981[75] = (char *(*)()) F520_5897;
	R4981[76] = (char *(*)()) F521_5910;
	R4981[77] = (char *(*)()) F522_5910;
	R4981[78] = (char *(*)()) F523_5910;
	R4981[79] = (char *(*)()) F524_5910;
	R4981[80] = (char *(*)()) F525_5910;
	R4981[81] = (char *(*)()) F526_5910;
	R4981[82] = (char *(*)()) F527_5910;
	R4981[83] = (char *(*)()) F528_5910;
	R4981[84] = (char *(*)()) F529_5914;
	R4981[85] = (char *(*)()) F530_5914;
	R4981[98] = (char *(*)()) F539_5928;
	R4981[99] = (char *(*)()) F536_5928;
	R4981[100] = (char *(*)()) F531_5928;
	R4981[101] = (char *(*)()) F532_5928;
	R4981[102] = (char *(*)()) F533_5928;
	R4981[103] = (char *(*)()) F534_5928;
	R4981[104] = (char *(*)()) F535_5928;
	R4981[105] = (char *(*)()) F536_5928;
	R4981[106] = (char *(*)()) F537_5928;
	R4981[107] = (char *(*)()) F538_5928;
	R4981[108] = (char *(*)()) F539_5928;
	R4981[109] = (char *(*)()) F540_5928;
	R4981[110] = (char *(*)()) F541_5928;
	R4981[111] = (char *(*)()) F542_5928;
	R4981[112] = (char *(*)()) F531_5928;
	R4981[113] = (char *(*)()) F532_5928;
	R4981[114] = (char *(*)()) F533_5928;
	R4981[115] = (char *(*)()) F534_5928;
	R4981[116] = (char *(*)()) F535_5928;
	R4981[117] = (char *(*)()) F536_5928;
	R4981[118] = (char *(*)()) F537_5928;
	R4981[119] = (char *(*)()) F538_5928;
	R4981[120] = (char *(*)()) F539_5928;
	R4981[121] = (char *(*)()) F540_5928;
	R4981[122] = (char *(*)()) F541_5928;
	R4981[123] = (char *(*)()) F542_5928;
	R4981[124] = (char *(*)()) F531_5928;
	R4981[125] = (char *(*)()) F532_5928;
	R4981[126] = (char *(*)()) F533_5928;
	R4981[127] = (char *(*)()) F534_5928;
	R4981[128] = (char *(*)()) F535_5928;
	R4981[129] = (char *(*)()) F536_5928;
	R4981[130] = (char *(*)()) F537_5928;
	R4981[131] = (char *(*)()) F538_5928;
	R4981[132] = (char *(*)()) F539_5928;
	R4981[133] = (char *(*)()) F540_5928;
	R4981[134] = (char *(*)()) F541_5928;
	R4981[135] = (char *(*)()) F542_5928;
	{long i; for (i = 289; i < 291; i++) R4981[i] = (char *(*)()) F733_6089;}
}

char *(*R4982[291])();
void R4982_init () {
	R4982[0] = (char *(*)()) F445_5569;
	R4982[1] = (char *(*)()) F446_5579;
	R4982[2] = (char *(*)()) F447_5585;
	R4982[3] = (char *(*)()) F448_5585;
	R4982[4] = (char *(*)()) F449_5585;
	R4982[64] = (char *(*)()) F509_5905;
	R4982[65] = (char *(*)()) F510_5905;
	R4982[66] = (char *(*)()) F511_5905;
	R4982[67] = (char *(*)()) F512_5905;
	R4982[68] = (char *(*)()) F513_5905;
	R4982[69] = (char *(*)()) F514_5905;
	R4982[70] = (char *(*)()) F515_5905;
	R4982[71] = (char *(*)()) F516_5905;
	R4982[72] = (char *(*)()) F517_5905;
	R4982[73] = (char *(*)()) F518_5905;
	R4982[74] = (char *(*)()) F519_5905;
	R4982[75] = (char *(*)()) F520_5905;
	R4982[76] = (char *(*)()) F521_5911;
	R4982[77] = (char *(*)()) F522_5911;
	R4982[78] = (char *(*)()) F523_5911;
	R4982[79] = (char *(*)()) F524_5911;
	R4982[80] = (char *(*)()) F525_5911;
	R4982[81] = (char *(*)()) F526_5911;
	R4982[82] = (char *(*)()) F527_5911;
	R4982[83] = (char *(*)()) F528_5911;
	R4982[84] = (char *(*)()) F529_5916;
	R4982[85] = (char *(*)()) F530_5916;
	R4982[98] = (char *(*)()) F539_5934;
	R4982[99] = (char *(*)()) F536_5934;
	R4982[100] = (char *(*)()) F531_5934;
	R4982[101] = (char *(*)()) F532_5934;
	R4982[102] = (char *(*)()) F533_5934;
	R4982[103] = (char *(*)()) F534_5934;
	R4982[104] = (char *(*)()) F535_5934;
	R4982[105] = (char *(*)()) F536_5934;
	R4982[106] = (char *(*)()) F537_5934;
	R4982[107] = (char *(*)()) F538_5934;
	R4982[108] = (char *(*)()) F539_5934;
	R4982[109] = (char *(*)()) F540_5934;
	R4982[110] = (char *(*)()) F541_5934;
	R4982[111] = (char *(*)()) F542_5934;
	R4982[112] = (char *(*)()) F531_5934;
	R4982[113] = (char *(*)()) F532_5934;
	R4982[114] = (char *(*)()) F533_5934;
	R4982[115] = (char *(*)()) F534_5934;
	R4982[116] = (char *(*)()) F535_5934;
	R4982[117] = (char *(*)()) F536_5934;
	R4982[118] = (char *(*)()) F537_5934;
	R4982[119] = (char *(*)()) F538_5934;
	R4982[120] = (char *(*)()) F539_5934;
	R4982[121] = (char *(*)()) F540_5934;
	R4982[122] = (char *(*)()) F541_5934;
	R4982[123] = (char *(*)()) F542_5934;
	R4982[124] = (char *(*)()) F531_5934;
	R4982[125] = (char *(*)()) F532_5934;
	R4982[126] = (char *(*)()) F533_5934;
	R4982[127] = (char *(*)()) F534_5934;
	R4982[128] = (char *(*)()) F535_5934;
	R4982[129] = (char *(*)()) F536_5934;
	R4982[130] = (char *(*)()) F537_5934;
	R4982[131] = (char *(*)()) F538_5934;
	R4982[132] = (char *(*)()) F539_5934;
	R4982[133] = (char *(*)()) F540_5934;
	R4982[134] = (char *(*)()) F541_5934;
	R4982[135] = (char *(*)()) F542_5934;
	{long i; for (i = 289; i < 291; i++) R4982[i] = (char *(*)()) F733_6095;}
}

static EIF_TYPE_INDEX Y4983_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype13[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype25[] = {1008,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype84[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype85[] = {1008,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype122[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y4983_pgtype123[] = {1190,0xFFFF};
EIF_TYPE_INDEX *Y4983_gen_type [303];
EIF_TYPE_INDEX Y4983 [303];
void Y4983_init (void)
{
	egc_routines_types [4983] = Y4983;
	egc_routines_gen_types [4983] = Y4983_gen_type;
	egc_routines_offset [4983] = 432;
	Y4983_gen_type [0] = Y4983_pgtype0;
	Y4983_gen_type [1] = Y4983_pgtype1;
	Y4983_gen_type [2] = Y4983_pgtype2;
	Y4983_gen_type [3] = Y4983_pgtype3;
	Y4983_gen_type [4] = Y4983_pgtype4;
	Y4983_gen_type [5] = Y4983_pgtype5;
	Y4983_gen_type [6] = Y4983_pgtype6;
	Y4983_gen_type [7] = Y4983_pgtype7;
	Y4983_gen_type [8] = Y4983_pgtype8;
	Y4983_gen_type [9] = Y4983_pgtype9;
	Y4983_gen_type [10] = Y4983_pgtype10;
	Y4983_gen_type [11] = Y4983_pgtype11;
	Y4983_gen_type [12] = Y4983_pgtype12;
	Y4983_gen_type [13] = Y4983_pgtype13;
	Y4983_gen_type [14] = Y4983_pgtype14;
	Y4983_gen_type [15] = Y4983_pgtype15;
	Y4983_gen_type [16] = Y4983_pgtype16;
	Y4983_gen_type [17] = Y4983_pgtype17;
	Y4983_gen_type [18] = Y4983_pgtype18;
	Y4983_gen_type [19] = Y4983_pgtype19;
	Y4983_gen_type [20] = Y4983_pgtype20;
	Y4983_gen_type [21] = Y4983_pgtype21;
	Y4983_gen_type [22] = Y4983_pgtype22;
	Y4983_gen_type [23] = Y4983_pgtype23;
	Y4983_gen_type [24] = Y4983_pgtype24;
	Y4983_gen_type [51] = Y4983_pgtype25;
	Y4983_gen_type [52] = Y4983_pgtype26;
	Y4983_gen_type [53] = Y4983_pgtype27;
	Y4983_gen_type [54] = Y4983_pgtype28;
	Y4983_gen_type [55] = Y4983_pgtype29;
	Y4983_gen_type [56] = Y4983_pgtype30;
	Y4983_gen_type [57] = Y4983_pgtype31;
	Y4983_gen_type [58] = Y4983_pgtype32;
	Y4983_gen_type [59] = Y4983_pgtype33;
	Y4983_gen_type [60] = Y4983_pgtype34;
	Y4983_gen_type [61] = Y4983_pgtype35;
	Y4983_gen_type [62] = Y4983_pgtype36;
	Y4983_gen_type [63] = Y4983_pgtype37;
	Y4983_gen_type [64] = Y4983_pgtype38;
	Y4983_gen_type [65] = Y4983_pgtype39;
	Y4983_gen_type [66] = Y4983_pgtype40;
	Y4983_gen_type [67] = Y4983_pgtype41;
	Y4983_gen_type [68] = Y4983_pgtype42;
	Y4983_gen_type [69] = Y4983_pgtype43;
	Y4983_gen_type [70] = Y4983_pgtype44;
	Y4983_gen_type [71] = Y4983_pgtype45;
	Y4983_gen_type [72] = Y4983_pgtype46;
	Y4983_gen_type [73] = Y4983_pgtype47;
	Y4983_gen_type [74] = Y4983_pgtype48;
	Y4983_gen_type [75] = Y4983_pgtype49;
	Y4983_gen_type [76] = Y4983_pgtype50;
	Y4983_gen_type [77] = Y4983_pgtype51;
	Y4983_gen_type [78] = Y4983_pgtype52;
	Y4983_gen_type [79] = Y4983_pgtype53;
	Y4983_gen_type [80] = Y4983_pgtype54;
	Y4983_gen_type [81] = Y4983_pgtype55;
	Y4983_gen_type [82] = Y4983_pgtype56;
	Y4983_gen_type [83] = Y4983_pgtype57;
	Y4983_gen_type [84] = Y4983_pgtype58;
	Y4983_gen_type [85] = Y4983_pgtype59;
	Y4983_gen_type [86] = Y4983_pgtype60;
	Y4983_gen_type [87] = Y4983_pgtype61;
	Y4983_gen_type [88] = Y4983_pgtype62;
	Y4983_gen_type [89] = Y4983_pgtype63;
	Y4983_gen_type [90] = Y4983_pgtype64;
	Y4983_gen_type [91] = Y4983_pgtype65;
	Y4983_gen_type [92] = Y4983_pgtype66;
	Y4983_gen_type [93] = Y4983_pgtype67;
	Y4983_gen_type [94] = Y4983_pgtype68;
	Y4983_gen_type [95] = Y4983_pgtype69;
	Y4983_gen_type [96] = Y4983_pgtype70;
	Y4983_gen_type [97] = Y4983_pgtype71;
	Y4983_gen_type [98] = Y4983_pgtype72;
	Y4983_gen_type [99] = Y4983_pgtype73;
	Y4983_gen_type [100] = Y4983_pgtype74;
	Y4983_gen_type [101] = Y4983_pgtype75;
	Y4983_gen_type [102] = Y4983_pgtype76;
	Y4983_gen_type [103] = Y4983_pgtype77;
	Y4983_gen_type [104] = Y4983_pgtype78;
	Y4983_gen_type [105] = Y4983_pgtype79;
	Y4983_gen_type [106] = Y4983_pgtype80;
	Y4983_gen_type [107] = Y4983_pgtype81;
	Y4983_gen_type [108] = Y4983_pgtype82;
	Y4983_gen_type [109] = Y4983_pgtype83;
	Y4983_gen_type [110] = Y4983_pgtype84;
	Y4983_gen_type [111] = Y4983_pgtype85;
	Y4983_gen_type [112] = Y4983_pgtype86;
	Y4983_gen_type [113] = Y4983_pgtype87;
	Y4983_gen_type [114] = Y4983_pgtype88;
	Y4983_gen_type [115] = Y4983_pgtype89;
	Y4983_gen_type [116] = Y4983_pgtype90;
	Y4983_gen_type [117] = Y4983_pgtype91;
	Y4983_gen_type [118] = Y4983_pgtype92;
	Y4983_gen_type [119] = Y4983_pgtype93;
	Y4983_gen_type [120] = Y4983_pgtype94;
	Y4983_gen_type [121] = Y4983_pgtype95;
	Y4983_gen_type [122] = Y4983_pgtype96;
	Y4983_gen_type [123] = Y4983_pgtype97;
	Y4983_gen_type [124] = Y4983_pgtype98;
	Y4983_gen_type [125] = Y4983_pgtype99;
	Y4983_gen_type [126] = Y4983_pgtype100;
	Y4983_gen_type [127] = Y4983_pgtype101;
	Y4983_gen_type [128] = Y4983_pgtype102;
	Y4983_gen_type [129] = Y4983_pgtype103;
	Y4983_gen_type [130] = Y4983_pgtype104;
	Y4983_gen_type [131] = Y4983_pgtype105;
	Y4983_gen_type [132] = Y4983_pgtype106;
	Y4983_gen_type [133] = Y4983_pgtype107;
	Y4983_gen_type [134] = Y4983_pgtype108;
	Y4983_gen_type [135] = Y4983_pgtype109;
	Y4983_gen_type [136] = Y4983_pgtype110;
	Y4983_gen_type [137] = Y4983_pgtype111;
	Y4983_gen_type [138] = Y4983_pgtype112;
	Y4983_gen_type [139] = Y4983_pgtype113;
	Y4983_gen_type [140] = Y4983_pgtype114;
	Y4983_gen_type [141] = Y4983_pgtype115;
	Y4983_gen_type [142] = Y4983_pgtype116;
	Y4983_gen_type [143] = Y4983_pgtype117;
	Y4983_gen_type [144] = Y4983_pgtype118;
	Y4983_gen_type [145] = Y4983_pgtype119;
	Y4983_gen_type [146] = Y4983_pgtype120;
	Y4983_gen_type [147] = Y4983_pgtype121;
	Y4983_gen_type [301] = Y4983_pgtype122;
	Y4983_gen_type [302] = Y4983_pgtype123;
	Y4983[13] = 1002;
	Y4983[51] = 1008;
	Y4983[110] = 1002;
	Y4983[111] = 1008;
	{long i; for (i = 301; i < 303; i++) Y4983[i] = 1190;};
}

char *(*R4993[3])();
void R4993_init () {
	R4993[0] = (char *(*)()) F447_5582;
	R4993[1] = (char *(*)()) F448_5582;
	R4993[2] = (char *(*)()) F449_5582;
}

char *(*R4996[8])();
void R4996_init () {
	R4996[0] = (char *(*)()) F521_5908;
	R4996[1] = (char *(*)()) F522_5908_4996_1;
	R4996[2] = (char *(*)()) F523_5908;
	R4996[3] = (char *(*)()) F524_5908;
	R4996[4] = (char *(*)()) F525_5908_4996_1;
	R4996[5] = (char *(*)()) F526_5908;
	R4996[6] = (char *(*)()) F527_5908;
	R4996[7] = (char *(*)()) F528_5908;
}
static EIF_REFERENCE F522_5908_4996_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F522_5908(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F525_5908_4996_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F525_5908(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4999[536])();
void R4999_init () {
	R4999[0] = (char *(*)()) F775_6181;
	R4999[51] = (char *(*)()) F826_6627;
	R4999[52] = (char *(*)()) F827_6627;
	R4999[53] = (char *(*)()) F828_6627;
	R4999[54] = (char *(*)()) F829_6627;
	R4999[55] = (char *(*)()) F830_6627;
	R4999[56] = (char *(*)()) F831_6627;
	R4999[57] = (char *(*)()) F832_6627;
	R4999[58] = (char *(*)()) F833_6627;
	{long i; for (i = 59; i < 61; i++) R4999[i] = (char *(*)()) F826_6627;}
	R4999[61] = (char *(*)()) F828_6627;
	R4999[62] = (char *(*)()) F829_6627;
	R4999[63] = (char *(*)()) F831_6627;
	R4999[64] = (char *(*)()) F832_6627;
	R4999[148] = (char *(*)()) F923_6979;
	R4999[149] = (char *(*)()) F924_6979;
	R4999[150] = (char *(*)()) F925_6979;
	R4999[151] = (char *(*)()) F926_6979;
	R4999[152] = (char *(*)()) F927_6979;
	R4999[153] = (char *(*)()) F928_6979;
	R4999[154] = (char *(*)()) F929_6979;
	R4999[155] = (char *(*)()) F930_6979;
	R4999[156] = (char *(*)()) F931_6979;
	R4999[157] = (char *(*)()) F932_6979;
	R4999[158] = (char *(*)()) F933_6979;
	R4999[159] = (char *(*)()) F934_6979;
	R4999[160] = (char *(*)()) F923_6979;
	R4999[161] = (char *(*)()) F925_6979;
	{long i; for (i = 162; i < 164; i++) R4999[i] = (char *(*)()) F923_6979;}
	R4999[225] = (char *(*)()) F1000_7754;
	{long i; for (i = 269; i < 274; i++) R4999[i] = (char *(*)()) F1043_7940;}
	R4999[279] = (char *(*)()) F1054_8267;
	R4999[282] = (char *(*)()) F1057_8345;
	R4999[283] = (char *(*)()) F1058_8436;
	R4999[535] = (char *(*)()) F1054_8267;
}

char *(*R5188[828])();
void R5188_init () {
	R5188[0] = (char *(*)()) F483_5835;
	R5188[26] = (char *(*)()) F509_5891;
	R5188[27] = (char *(*)()) F510_5891;
	R5188[28] = (char *(*)()) F511_5891;
	R5188[29] = (char *(*)()) F512_5891;
	R5188[30] = (char *(*)()) F513_5891;
	R5188[31] = (char *(*)()) F514_5891;
	R5188[32] = (char *(*)()) F515_5891;
	R5188[33] = (char *(*)()) F516_5891;
	R5188[34] = (char *(*)()) F517_5891;
	R5188[35] = (char *(*)()) F518_5891;
	R5188[36] = (char *(*)()) F519_5891;
	R5188[37] = (char *(*)()) F520_5891;
	{long i; for (i = 38; i < 40; i++) R5188[i] = (char *(*)()) F509_5891;}
	R5188[40] = (char *(*)()) F510_5891;
	{long i; for (i = 41; i < 43; i++) R5188[i] = (char *(*)()) F511_5891;}
	R5188[43] = (char *(*)()) F512_5891;
	R5188[44] = (char *(*)()) F518_5891;
	R5188[45] = (char *(*)()) F519_5891;
	R5188[46] = (char *(*)()) F509_5891;
	R5188[47] = (char *(*)()) F511_5891;
	R5188[60] = (char *(*)()) F543_5941;
	R5188[61] = (char *(*)()) F544_5947;
	R5188[62] = (char *(*)()) F545_5953;
	R5188[63] = (char *(*)()) F546_5953;
	R5188[64] = (char *(*)()) F547_5953;
	R5188[65] = (char *(*)()) F548_5953;
	R5188[66] = (char *(*)()) F549_5953;
	R5188[67] = (char *(*)()) F550_5953;
	R5188[68] = (char *(*)()) F551_5953;
	R5188[69] = (char *(*)()) F552_5953;
	R5188[70] = (char *(*)()) F553_5953;
	R5188[71] = (char *(*)()) F554_5953;
	R5188[72] = (char *(*)()) F555_5953;
	R5188[73] = (char *(*)()) F556_5953;
	R5188[74] = (char *(*)()) F557_5959;
	R5188[75] = (char *(*)()) F558_5959;
	R5188[76] = (char *(*)()) F559_5959;
	R5188[77] = (char *(*)()) F560_5959;
	R5188[78] = (char *(*)()) F561_5959;
	R5188[79] = (char *(*)()) F562_5959;
	R5188[80] = (char *(*)()) F563_5959;
	R5188[81] = (char *(*)()) F564_5959;
	R5188[82] = (char *(*)()) F565_5959;
	R5188[83] = (char *(*)()) F566_5959;
	R5188[84] = (char *(*)()) F567_5959;
	R5188[85] = (char *(*)()) F568_5959;
	R5188[86] = (char *(*)()) F569_5965;
	R5188[87] = (char *(*)()) F570_5965;
	R5188[88] = (char *(*)()) F571_5965;
	R5188[89] = (char *(*)()) F572_5965;
	R5188[90] = (char *(*)()) F573_5965;
	R5188[91] = (char *(*)()) F574_5965;
	R5188[92] = (char *(*)()) F575_5965;
	R5188[93] = (char *(*)()) F576_5965;
	R5188[94] = (char *(*)()) F577_5965;
	R5188[95] = (char *(*)()) F578_5965;
	R5188[96] = (char *(*)()) F579_5965;
	R5188[97] = (char *(*)()) F580_5965;
	R5188[251] = (char *(*)()) F734_6119;
	R5188[252] = (char *(*)()) F735_6134;
	R5188[292] = (char *(*)()) F775_6160;
	{long i; for (i = 320; i < 322; i++) R5188[i] = (char *(*)()) F802_6298;}
	R5188[330] = (char *(*)()) F813_6554;
	R5188[343] = (char *(*)()) F826_6583;
	R5188[344] = (char *(*)()) F827_6583;
	R5188[345] = (char *(*)()) F828_6583;
	R5188[346] = (char *(*)()) F829_6583;
	R5188[347] = (char *(*)()) F830_6583;
	R5188[348] = (char *(*)()) F831_6583;
	R5188[349] = (char *(*)()) F832_6583;
	R5188[350] = (char *(*)()) F833_6583;
	{long i; for (i = 351; i < 353; i++) R5188[i] = (char *(*)()) F826_6583;}
	R5188[353] = (char *(*)()) F828_6583;
	R5188[354] = (char *(*)()) F829_6583;
	R5188[355] = (char *(*)()) F831_6583;
	R5188[356] = (char *(*)()) F832_6583;
	R5188[369] = (char *(*)()) F816_6563;
	R5188[370] = (char *(*)()) F853_6748;
	R5188[371] = (char *(*)()) F854_6748;
	R5188[372] = (char *(*)()) F855_6748;
	R5188[373] = (char *(*)()) F856_6748;
	R5188[374] = (char *(*)()) F857_6748;
	R5188[375] = (char *(*)()) F858_6748;
	R5188[376] = (char *(*)()) F859_6748;
	R5188[377] = (char *(*)()) F860_6748;
	R5188[378] = (char *(*)()) F861_6748;
	R5188[379] = (char *(*)()) F862_6748;
	R5188[380] = (char *(*)()) F863_6748;
	R5188[381] = (char *(*)()) F864_6748;
	R5188[435] = (char *(*)()) F918_6855;
	R5188[436] = (char *(*)()) F919_6855;
	R5188[437] = (char *(*)()) F918_6855;
	R5188[438] = (char *(*)()) F919_6855;
	R5188[439] = (char *(*)()) F918_6855;
	R5188[440] = (char *(*)()) F923_6932;
	R5188[441] = (char *(*)()) F924_6932;
	R5188[442] = (char *(*)()) F925_6932;
	R5188[443] = (char *(*)()) F926_6932;
	R5188[444] = (char *(*)()) F927_6932;
	R5188[445] = (char *(*)()) F928_6932;
	R5188[446] = (char *(*)()) F929_6932;
	R5188[447] = (char *(*)()) F930_6932;
	R5188[448] = (char *(*)()) F931_6932;
	R5188[449] = (char *(*)()) F932_6932;
	R5188[450] = (char *(*)()) F933_6932;
	R5188[451] = (char *(*)()) F934_6932;
	R5188[452] = (char *(*)()) F923_6932;
	R5188[453] = (char *(*)()) F925_6932;
	{long i; for (i = 454; i < 456; i++) R5188[i] = (char *(*)()) F923_6932;}
	R5188[517] = (char *(*)()) F814_6563;
	{long i; for (i = 570; i < 572; i++) R5188[i] = (char *(*)()) F1052_8124;}
	{long i; for (i = 574; i < 576; i++) R5188[i] = (char *(*)()) F1056_8289;}
	{long i; for (i = 578; i < 580; i++) R5188[i] = (char *(*)()) F581_5973;}
	R5188[626] = (char *(*)()) F1109_9017;
	R5188[627] = (char *(*)()) F1110_9017;
	R5188[628] = (char *(*)()) F1111_9017;
	R5188[629] = (char *(*)()) F1112_9017;
	R5188[630] = (char *(*)()) F1113_9017;
	R5188[631] = (char *(*)()) F1114_9017;
	R5188[632] = (char *(*)()) F1115_9017;
	R5188[633] = (char *(*)()) F1116_9017;
	R5188[634] = (char *(*)()) F1117_9017;
	R5188[635] = (char *(*)()) F1118_9017;
	R5188[636] = (char *(*)()) F1119_9017;
	R5188[637] = (char *(*)()) F1120_9017;
	R5188[730] = (char *(*)()) F1213_10311;
	R5188[731] = (char *(*)()) F1214_10354;
	R5188[741] = (char *(*)()) F1224_10408;
	R5188[742] = (char *(*)()) F1225_10472;
	R5188[743] = (char *(*)()) F1226_10472;
	R5188[744] = (char *(*)()) F1227_10472;
	R5188[795] = (char *(*)()) F802_6298;
	R5188[827] = (char *(*)()) F1052_8124;
}

static EIF_TYPE_INDEX Y5189_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype12[] = {0xFF01,1053,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype13[] = {0xFF01,1056,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype14[] = {1008,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype73[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype74[] = {1008,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype111[] = {0xFF01,1062,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype264[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype265[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype332[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype333[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype334[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype343[] = {1055,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype364[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype365[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype382[] = {1190,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype451[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype452[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype453[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype454[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype455[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype456[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype457[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype466[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype467[] = {0xFF01,936,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype468[] = {0xFF01,1264,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype469[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype470[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype471[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype472[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype473[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype474[] = {1008,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype475[] = {1008,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype476[] = {1008,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype477[] = {0xFF01,1062,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype478[] = {0xFF01,1062,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype479[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype480[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype481[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype482[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype483[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype484[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype485[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype486[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype487[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype488[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype489[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype490[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype491[] = {0xFF01,1176,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype492[] = {0xFF01,1176,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype493[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype494[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype495[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype496[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype497[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype498[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype499[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype500[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype501[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype502[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype503[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype504[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype505[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y5189_pgtype506[] = {1002,0xFFFF};
EIF_TYPE_INDEX *Y5189_gen_type [842];
EIF_TYPE_INDEX Y5189 [842];
void Y5189_init (void)
{
	egc_routines_types [5189] = Y5189;
	egc_routines_gen_types [5189] = Y5189_gen_type;
	egc_routines_offset [5189] = 469;
	Y5189_gen_type [0] = Y5189_pgtype0;
	Y5189_gen_type [1] = Y5189_pgtype1;
	Y5189_gen_type [2] = Y5189_pgtype2;
	Y5189_gen_type [3] = Y5189_pgtype3;
	Y5189_gen_type [4] = Y5189_pgtype4;
	Y5189_gen_type [5] = Y5189_pgtype5;
	Y5189_gen_type [6] = Y5189_pgtype6;
	Y5189_gen_type [7] = Y5189_pgtype7;
	Y5189_gen_type [8] = Y5189_pgtype8;
	Y5189_gen_type [9] = Y5189_pgtype9;
	Y5189_gen_type [10] = Y5189_pgtype10;
	Y5189_gen_type [11] = Y5189_pgtype11;
	Y5189_gen_type [12] = Y5189_pgtype12;
	Y5189_gen_type [13] = Y5189_pgtype13;
	Y5189_gen_type [14] = Y5189_pgtype14;
	Y5189_gen_type [15] = Y5189_pgtype15;
	Y5189_gen_type [16] = Y5189_pgtype16;
	Y5189_gen_type [17] = Y5189_pgtype17;
	Y5189_gen_type [18] = Y5189_pgtype18;
	Y5189_gen_type [19] = Y5189_pgtype19;
	Y5189_gen_type [20] = Y5189_pgtype20;
	Y5189_gen_type [21] = Y5189_pgtype21;
	Y5189_gen_type [22] = Y5189_pgtype22;
	Y5189_gen_type [23] = Y5189_pgtype23;
	Y5189_gen_type [24] = Y5189_pgtype24;
	Y5189_gen_type [25] = Y5189_pgtype25;
	Y5189_gen_type [26] = Y5189_pgtype26;
	Y5189_gen_type [27] = Y5189_pgtype27;
	Y5189_gen_type [28] = Y5189_pgtype28;
	Y5189_gen_type [29] = Y5189_pgtype29;
	Y5189_gen_type [30] = Y5189_pgtype30;
	Y5189_gen_type [31] = Y5189_pgtype31;
	Y5189_gen_type [32] = Y5189_pgtype32;
	Y5189_gen_type [33] = Y5189_pgtype33;
	Y5189_gen_type [34] = Y5189_pgtype34;
	Y5189_gen_type [35] = Y5189_pgtype35;
	Y5189_gen_type [36] = Y5189_pgtype36;
	Y5189_gen_type [37] = Y5189_pgtype37;
	Y5189_gen_type [38] = Y5189_pgtype38;
	Y5189_gen_type [39] = Y5189_pgtype39;
	Y5189_gen_type [40] = Y5189_pgtype40;
	Y5189_gen_type [41] = Y5189_pgtype41;
	Y5189_gen_type [42] = Y5189_pgtype42;
	Y5189_gen_type [43] = Y5189_pgtype43;
	Y5189_gen_type [44] = Y5189_pgtype44;
	Y5189_gen_type [45] = Y5189_pgtype45;
	Y5189_gen_type [46] = Y5189_pgtype46;
	Y5189_gen_type [47] = Y5189_pgtype47;
	Y5189_gen_type [48] = Y5189_pgtype48;
	Y5189_gen_type [49] = Y5189_pgtype49;
	Y5189_gen_type [50] = Y5189_pgtype50;
	Y5189_gen_type [51] = Y5189_pgtype51;
	Y5189_gen_type [52] = Y5189_pgtype52;
	Y5189_gen_type [53] = Y5189_pgtype53;
	Y5189_gen_type [54] = Y5189_pgtype54;
	Y5189_gen_type [55] = Y5189_pgtype55;
	Y5189_gen_type [56] = Y5189_pgtype56;
	Y5189_gen_type [57] = Y5189_pgtype57;
	Y5189_gen_type [58] = Y5189_pgtype58;
	Y5189_gen_type [59] = Y5189_pgtype59;
	Y5189_gen_type [60] = Y5189_pgtype60;
	Y5189_gen_type [61] = Y5189_pgtype61;
	Y5189_gen_type [62] = Y5189_pgtype62;
	Y5189_gen_type [63] = Y5189_pgtype63;
	Y5189_gen_type [64] = Y5189_pgtype64;
	Y5189_gen_type [65] = Y5189_pgtype65;
	Y5189_gen_type [66] = Y5189_pgtype66;
	Y5189_gen_type [67] = Y5189_pgtype67;
	Y5189_gen_type [68] = Y5189_pgtype68;
	Y5189_gen_type [69] = Y5189_pgtype69;
	Y5189_gen_type [70] = Y5189_pgtype70;
	Y5189_gen_type [71] = Y5189_pgtype71;
	Y5189_gen_type [72] = Y5189_pgtype72;
	Y5189_gen_type [73] = Y5189_pgtype73;
	Y5189_gen_type [74] = Y5189_pgtype74;
	Y5189_gen_type [75] = Y5189_pgtype75;
	Y5189_gen_type [76] = Y5189_pgtype76;
	Y5189_gen_type [77] = Y5189_pgtype77;
	Y5189_gen_type [78] = Y5189_pgtype78;
	Y5189_gen_type [79] = Y5189_pgtype79;
	Y5189_gen_type [80] = Y5189_pgtype80;
	Y5189_gen_type [81] = Y5189_pgtype81;
	Y5189_gen_type [82] = Y5189_pgtype82;
	Y5189_gen_type [83] = Y5189_pgtype83;
	Y5189_gen_type [84] = Y5189_pgtype84;
	Y5189_gen_type [85] = Y5189_pgtype85;
	Y5189_gen_type [86] = Y5189_pgtype86;
	Y5189_gen_type [87] = Y5189_pgtype87;
	Y5189_gen_type [88] = Y5189_pgtype88;
	Y5189_gen_type [89] = Y5189_pgtype89;
	Y5189_gen_type [90] = Y5189_pgtype90;
	Y5189_gen_type [91] = Y5189_pgtype91;
	Y5189_gen_type [92] = Y5189_pgtype92;
	Y5189_gen_type [93] = Y5189_pgtype93;
	Y5189_gen_type [94] = Y5189_pgtype94;
	Y5189_gen_type [95] = Y5189_pgtype95;
	Y5189_gen_type [96] = Y5189_pgtype96;
	Y5189_gen_type [97] = Y5189_pgtype97;
	Y5189_gen_type [98] = Y5189_pgtype98;
	Y5189_gen_type [99] = Y5189_pgtype99;
	Y5189_gen_type [100] = Y5189_pgtype100;
	Y5189_gen_type [101] = Y5189_pgtype101;
	Y5189_gen_type [102] = Y5189_pgtype102;
	Y5189_gen_type [103] = Y5189_pgtype103;
	Y5189_gen_type [104] = Y5189_pgtype104;
	Y5189_gen_type [105] = Y5189_pgtype105;
	Y5189_gen_type [106] = Y5189_pgtype106;
	Y5189_gen_type [107] = Y5189_pgtype107;
	Y5189_gen_type [108] = Y5189_pgtype108;
	Y5189_gen_type [109] = Y5189_pgtype109;
	Y5189_gen_type [110] = Y5189_pgtype110;
	Y5189_gen_type [111] = Y5189_pgtype111;
	Y5189_gen_type [112] = Y5189_pgtype112;
	Y5189_gen_type [113] = Y5189_pgtype113;
	Y5189_gen_type [114] = Y5189_pgtype114;
	Y5189_gen_type [115] = Y5189_pgtype115;
	Y5189_gen_type [116] = Y5189_pgtype116;
	Y5189_gen_type [117] = Y5189_pgtype117;
	Y5189_gen_type [118] = Y5189_pgtype118;
	Y5189_gen_type [119] = Y5189_pgtype119;
	Y5189_gen_type [120] = Y5189_pgtype120;
	Y5189_gen_type [121] = Y5189_pgtype121;
	Y5189_gen_type [122] = Y5189_pgtype122;
	Y5189_gen_type [123] = Y5189_pgtype123;
	Y5189_gen_type [124] = Y5189_pgtype124;
	Y5189_gen_type [125] = Y5189_pgtype125;
	Y5189_gen_type [126] = Y5189_pgtype126;
	Y5189_gen_type [127] = Y5189_pgtype127;
	Y5189_gen_type [128] = Y5189_pgtype128;
	Y5189_gen_type [129] = Y5189_pgtype129;
	Y5189_gen_type [130] = Y5189_pgtype130;
	Y5189_gen_type [131] = Y5189_pgtype131;
	Y5189_gen_type [132] = Y5189_pgtype132;
	Y5189_gen_type [133] = Y5189_pgtype133;
	Y5189_gen_type [134] = Y5189_pgtype134;
	Y5189_gen_type [135] = Y5189_pgtype135;
	Y5189_gen_type [136] = Y5189_pgtype136;
	Y5189_gen_type [137] = Y5189_pgtype137;
	Y5189_gen_type [138] = Y5189_pgtype138;
	Y5189_gen_type [139] = Y5189_pgtype139;
	Y5189_gen_type [140] = Y5189_pgtype140;
	Y5189_gen_type [141] = Y5189_pgtype141;
	Y5189_gen_type [142] = Y5189_pgtype142;
	Y5189_gen_type [143] = Y5189_pgtype143;
	Y5189_gen_type [144] = Y5189_pgtype144;
	Y5189_gen_type [145] = Y5189_pgtype145;
	Y5189_gen_type [146] = Y5189_pgtype146;
	Y5189_gen_type [147] = Y5189_pgtype147;
	Y5189_gen_type [148] = Y5189_pgtype148;
	Y5189_gen_type [149] = Y5189_pgtype149;
	Y5189_gen_type [150] = Y5189_pgtype150;
	Y5189_gen_type [151] = Y5189_pgtype151;
	Y5189_gen_type [152] = Y5189_pgtype152;
	Y5189_gen_type [153] = Y5189_pgtype153;
	Y5189_gen_type [154] = Y5189_pgtype154;
	Y5189_gen_type [155] = Y5189_pgtype155;
	Y5189_gen_type [156] = Y5189_pgtype156;
	Y5189_gen_type [157] = Y5189_pgtype157;
	Y5189_gen_type [158] = Y5189_pgtype158;
	Y5189_gen_type [159] = Y5189_pgtype159;
	Y5189_gen_type [160] = Y5189_pgtype160;
	Y5189_gen_type [161] = Y5189_pgtype161;
	Y5189_gen_type [162] = Y5189_pgtype162;
	Y5189_gen_type [163] = Y5189_pgtype163;
	Y5189_gen_type [164] = Y5189_pgtype164;
	Y5189_gen_type [165] = Y5189_pgtype165;
	Y5189_gen_type [166] = Y5189_pgtype166;
	Y5189_gen_type [167] = Y5189_pgtype167;
	Y5189_gen_type [168] = Y5189_pgtype168;
	Y5189_gen_type [169] = Y5189_pgtype169;
	Y5189_gen_type [170] = Y5189_pgtype170;
	Y5189_gen_type [171] = Y5189_pgtype171;
	Y5189_gen_type [172] = Y5189_pgtype172;
	Y5189_gen_type [173] = Y5189_pgtype173;
	Y5189_gen_type [174] = Y5189_pgtype174;
	Y5189_gen_type [175] = Y5189_pgtype175;
	Y5189_gen_type [176] = Y5189_pgtype176;
	Y5189_gen_type [177] = Y5189_pgtype177;
	Y5189_gen_type [178] = Y5189_pgtype178;
	Y5189_gen_type [179] = Y5189_pgtype179;
	Y5189_gen_type [180] = Y5189_pgtype180;
	Y5189_gen_type [181] = Y5189_pgtype181;
	Y5189_gen_type [182] = Y5189_pgtype182;
	Y5189_gen_type [183] = Y5189_pgtype183;
	Y5189_gen_type [184] = Y5189_pgtype184;
	Y5189_gen_type [185] = Y5189_pgtype185;
	Y5189_gen_type [186] = Y5189_pgtype186;
	Y5189_gen_type [187] = Y5189_pgtype187;
	Y5189_gen_type [188] = Y5189_pgtype188;
	Y5189_gen_type [189] = Y5189_pgtype189;
	Y5189_gen_type [190] = Y5189_pgtype190;
	Y5189_gen_type [191] = Y5189_pgtype191;
	Y5189_gen_type [192] = Y5189_pgtype192;
	Y5189_gen_type [193] = Y5189_pgtype193;
	Y5189_gen_type [194] = Y5189_pgtype194;
	Y5189_gen_type [195] = Y5189_pgtype195;
	Y5189_gen_type [196] = Y5189_pgtype196;
	Y5189_gen_type [197] = Y5189_pgtype197;
	Y5189_gen_type [198] = Y5189_pgtype198;
	Y5189_gen_type [199] = Y5189_pgtype199;
	Y5189_gen_type [200] = Y5189_pgtype200;
	Y5189_gen_type [201] = Y5189_pgtype201;
	Y5189_gen_type [202] = Y5189_pgtype202;
	Y5189_gen_type [203] = Y5189_pgtype203;
	Y5189_gen_type [204] = Y5189_pgtype204;
	Y5189_gen_type [205] = Y5189_pgtype205;
	Y5189_gen_type [206] = Y5189_pgtype206;
	Y5189_gen_type [207] = Y5189_pgtype207;
	Y5189_gen_type [208] = Y5189_pgtype208;
	Y5189_gen_type [209] = Y5189_pgtype209;
	Y5189_gen_type [210] = Y5189_pgtype210;
	Y5189_gen_type [211] = Y5189_pgtype211;
	Y5189_gen_type [212] = Y5189_pgtype212;
	Y5189_gen_type [213] = Y5189_pgtype213;
	Y5189_gen_type [214] = Y5189_pgtype214;
	Y5189_gen_type [215] = Y5189_pgtype215;
	Y5189_gen_type [216] = Y5189_pgtype216;
	Y5189_gen_type [217] = Y5189_pgtype217;
	Y5189_gen_type [218] = Y5189_pgtype218;
	Y5189_gen_type [219] = Y5189_pgtype219;
	Y5189_gen_type [220] = Y5189_pgtype220;
	Y5189_gen_type [221] = Y5189_pgtype221;
	Y5189_gen_type [222] = Y5189_pgtype222;
	Y5189_gen_type [223] = Y5189_pgtype223;
	Y5189_gen_type [224] = Y5189_pgtype224;
	Y5189_gen_type [225] = Y5189_pgtype225;
	Y5189_gen_type [226] = Y5189_pgtype226;
	Y5189_gen_type [227] = Y5189_pgtype227;
	Y5189_gen_type [228] = Y5189_pgtype228;
	Y5189_gen_type [229] = Y5189_pgtype229;
	Y5189_gen_type [230] = Y5189_pgtype230;
	Y5189_gen_type [231] = Y5189_pgtype231;
	Y5189_gen_type [232] = Y5189_pgtype232;
	Y5189_gen_type [233] = Y5189_pgtype233;
	Y5189_gen_type [234] = Y5189_pgtype234;
	Y5189_gen_type [235] = Y5189_pgtype235;
	Y5189_gen_type [236] = Y5189_pgtype236;
	Y5189_gen_type [237] = Y5189_pgtype237;
	Y5189_gen_type [238] = Y5189_pgtype238;
	Y5189_gen_type [239] = Y5189_pgtype239;
	Y5189_gen_type [240] = Y5189_pgtype240;
	Y5189_gen_type [241] = Y5189_pgtype241;
	Y5189_gen_type [242] = Y5189_pgtype242;
	Y5189_gen_type [243] = Y5189_pgtype243;
	Y5189_gen_type [244] = Y5189_pgtype244;
	Y5189_gen_type [245] = Y5189_pgtype245;
	Y5189_gen_type [246] = Y5189_pgtype246;
	Y5189_gen_type [247] = Y5189_pgtype247;
	Y5189_gen_type [248] = Y5189_pgtype248;
	Y5189_gen_type [249] = Y5189_pgtype249;
	Y5189_gen_type [250] = Y5189_pgtype250;
	Y5189_gen_type [251] = Y5189_pgtype251;
	Y5189_gen_type [252] = Y5189_pgtype252;
	Y5189_gen_type [253] = Y5189_pgtype253;
	Y5189_gen_type [254] = Y5189_pgtype254;
	Y5189_gen_type [255] = Y5189_pgtype255;
	Y5189_gen_type [256] = Y5189_pgtype256;
	Y5189_gen_type [257] = Y5189_pgtype257;
	Y5189_gen_type [258] = Y5189_pgtype258;
	Y5189_gen_type [259] = Y5189_pgtype259;
	Y5189_gen_type [260] = Y5189_pgtype260;
	Y5189_gen_type [261] = Y5189_pgtype261;
	Y5189_gen_type [262] = Y5189_pgtype262;
	Y5189_gen_type [263] = Y5189_pgtype263;
	Y5189_gen_type [264] = Y5189_pgtype264;
	Y5189_gen_type [265] = Y5189_pgtype265;
	Y5189_gen_type [266] = Y5189_pgtype266;
	Y5189_gen_type [267] = Y5189_pgtype267;
	Y5189_gen_type [268] = Y5189_pgtype268;
	Y5189_gen_type [269] = Y5189_pgtype269;
	Y5189_gen_type [270] = Y5189_pgtype270;
	Y5189_gen_type [271] = Y5189_pgtype271;
	Y5189_gen_type [272] = Y5189_pgtype272;
	Y5189_gen_type [273] = Y5189_pgtype273;
	Y5189_gen_type [274] = Y5189_pgtype274;
	Y5189_gen_type [275] = Y5189_pgtype275;
	Y5189_gen_type [276] = Y5189_pgtype276;
	Y5189_gen_type [277] = Y5189_pgtype277;
	Y5189_gen_type [278] = Y5189_pgtype278;
	Y5189_gen_type [279] = Y5189_pgtype279;
	Y5189_gen_type [280] = Y5189_pgtype280;
	Y5189_gen_type [281] = Y5189_pgtype281;
	Y5189_gen_type [282] = Y5189_pgtype282;
	Y5189_gen_type [283] = Y5189_pgtype283;
	Y5189_gen_type [284] = Y5189_pgtype284;
	Y5189_gen_type [285] = Y5189_pgtype285;
	Y5189_gen_type [286] = Y5189_pgtype286;
	Y5189_gen_type [287] = Y5189_pgtype287;
	Y5189_gen_type [288] = Y5189_pgtype288;
	Y5189_gen_type [289] = Y5189_pgtype289;
	Y5189_gen_type [290] = Y5189_pgtype290;
	Y5189_gen_type [291] = Y5189_pgtype291;
	Y5189_gen_type [292] = Y5189_pgtype292;
	Y5189_gen_type [293] = Y5189_pgtype293;
	Y5189_gen_type [294] = Y5189_pgtype294;
	Y5189_gen_type [295] = Y5189_pgtype295;
	Y5189_gen_type [296] = Y5189_pgtype296;
	Y5189_gen_type [297] = Y5189_pgtype297;
	Y5189_gen_type [298] = Y5189_pgtype298;
	Y5189_gen_type [299] = Y5189_pgtype299;
	Y5189_gen_type [300] = Y5189_pgtype300;
	Y5189_gen_type [301] = Y5189_pgtype301;
	Y5189_gen_type [302] = Y5189_pgtype302;
	Y5189_gen_type [303] = Y5189_pgtype303;
	Y5189_gen_type [304] = Y5189_pgtype304;
	Y5189_gen_type [305] = Y5189_pgtype305;
	Y5189_gen_type [306] = Y5189_pgtype306;
	Y5189_gen_type [307] = Y5189_pgtype307;
	Y5189_gen_type [308] = Y5189_pgtype308;
	Y5189_gen_type [309] = Y5189_pgtype309;
	Y5189_gen_type [310] = Y5189_pgtype310;
	Y5189_gen_type [311] = Y5189_pgtype311;
	Y5189_gen_type [312] = Y5189_pgtype312;
	Y5189_gen_type [313] = Y5189_pgtype313;
	Y5189_gen_type [314] = Y5189_pgtype314;
	Y5189_gen_type [315] = Y5189_pgtype315;
	Y5189_gen_type [316] = Y5189_pgtype316;
	Y5189_gen_type [317] = Y5189_pgtype317;
	Y5189_gen_type [318] = Y5189_pgtype318;
	Y5189_gen_type [319] = Y5189_pgtype319;
	Y5189_gen_type [320] = Y5189_pgtype320;
	Y5189_gen_type [321] = Y5189_pgtype321;
	Y5189_gen_type [322] = Y5189_pgtype322;
	Y5189_gen_type [323] = Y5189_pgtype323;
	Y5189_gen_type [324] = Y5189_pgtype324;
	Y5189_gen_type [325] = Y5189_pgtype325;
	Y5189_gen_type [326] = Y5189_pgtype326;
	Y5189_gen_type [327] = Y5189_pgtype327;
	Y5189_gen_type [328] = Y5189_pgtype328;
	Y5189_gen_type [329] = Y5189_pgtype329;
	Y5189_gen_type [330] = Y5189_pgtype330;
	Y5189_gen_type [331] = Y5189_pgtype331;
	Y5189_gen_type [332] = Y5189_pgtype332;
	Y5189_gen_type [333] = Y5189_pgtype333;
	Y5189_gen_type [334] = Y5189_pgtype334;
	Y5189_gen_type [335] = Y5189_pgtype335;
	Y5189_gen_type [336] = Y5189_pgtype336;
	Y5189_gen_type [337] = Y5189_pgtype337;
	Y5189_gen_type [338] = Y5189_pgtype338;
	Y5189_gen_type [339] = Y5189_pgtype339;
	Y5189_gen_type [340] = Y5189_pgtype340;
	Y5189_gen_type [341] = Y5189_pgtype341;
	Y5189_gen_type [342] = Y5189_pgtype342;
	Y5189_gen_type [343] = Y5189_pgtype343;
	Y5189_gen_type [344] = Y5189_pgtype344;
	Y5189_gen_type [345] = Y5189_pgtype345;
	Y5189_gen_type [346] = Y5189_pgtype346;
	Y5189_gen_type [347] = Y5189_pgtype347;
	Y5189_gen_type [348] = Y5189_pgtype348;
	Y5189_gen_type [349] = Y5189_pgtype349;
	Y5189_gen_type [350] = Y5189_pgtype350;
	Y5189_gen_type [351] = Y5189_pgtype351;
	Y5189_gen_type [352] = Y5189_pgtype352;
	Y5189_gen_type [353] = Y5189_pgtype353;
	Y5189_gen_type [354] = Y5189_pgtype354;
	Y5189_gen_type [355] = Y5189_pgtype355;
	Y5189_gen_type [356] = Y5189_pgtype356;
	Y5189_gen_type [357] = Y5189_pgtype357;
	Y5189_gen_type [358] = Y5189_pgtype358;
	Y5189_gen_type [359] = Y5189_pgtype359;
	Y5189_gen_type [360] = Y5189_pgtype360;
	Y5189_gen_type [361] = Y5189_pgtype361;
	Y5189_gen_type [362] = Y5189_pgtype362;
	Y5189_gen_type [363] = Y5189_pgtype363;
	Y5189_gen_type [364] = Y5189_pgtype364;
	Y5189_gen_type [365] = Y5189_pgtype365;
	Y5189_gen_type [366] = Y5189_pgtype366;
	Y5189_gen_type [367] = Y5189_pgtype367;
	Y5189_gen_type [368] = Y5189_pgtype368;
	Y5189_gen_type [369] = Y5189_pgtype369;
	Y5189_gen_type [370] = Y5189_pgtype370;
	Y5189_gen_type [371] = Y5189_pgtype371;
	Y5189_gen_type [372] = Y5189_pgtype372;
	Y5189_gen_type [373] = Y5189_pgtype373;
	Y5189_gen_type [374] = Y5189_pgtype374;
	Y5189_gen_type [375] = Y5189_pgtype375;
	Y5189_gen_type [376] = Y5189_pgtype376;
	Y5189_gen_type [377] = Y5189_pgtype377;
	Y5189_gen_type [378] = Y5189_pgtype378;
	Y5189_gen_type [379] = Y5189_pgtype379;
	Y5189_gen_type [380] = Y5189_pgtype380;
	Y5189_gen_type [381] = Y5189_pgtype381;
	Y5189_gen_type [382] = Y5189_pgtype382;
	Y5189_gen_type [383] = Y5189_pgtype383;
	Y5189_gen_type [384] = Y5189_pgtype384;
	Y5189_gen_type [385] = Y5189_pgtype385;
	Y5189_gen_type [386] = Y5189_pgtype386;
	Y5189_gen_type [387] = Y5189_pgtype387;
	Y5189_gen_type [388] = Y5189_pgtype388;
	Y5189_gen_type [389] = Y5189_pgtype389;
	Y5189_gen_type [390] = Y5189_pgtype390;
	Y5189_gen_type [391] = Y5189_pgtype391;
	Y5189_gen_type [392] = Y5189_pgtype392;
	Y5189_gen_type [393] = Y5189_pgtype393;
	Y5189_gen_type [394] = Y5189_pgtype394;
	Y5189_gen_type [395] = Y5189_pgtype395;
	Y5189_gen_type [396] = Y5189_pgtype396;
	Y5189_gen_type [397] = Y5189_pgtype397;
	Y5189_gen_type [398] = Y5189_pgtype398;
	Y5189_gen_type [399] = Y5189_pgtype399;
	Y5189_gen_type [400] = Y5189_pgtype400;
	Y5189_gen_type [401] = Y5189_pgtype401;
	Y5189_gen_type [402] = Y5189_pgtype402;
	Y5189_gen_type [403] = Y5189_pgtype403;
	Y5189_gen_type [404] = Y5189_pgtype404;
	Y5189_gen_type [405] = Y5189_pgtype405;
	Y5189_gen_type [406] = Y5189_pgtype406;
	Y5189_gen_type [407] = Y5189_pgtype407;
	Y5189_gen_type [408] = Y5189_pgtype408;
	Y5189_gen_type [409] = Y5189_pgtype409;
	Y5189_gen_type [410] = Y5189_pgtype410;
	Y5189_gen_type [411] = Y5189_pgtype411;
	Y5189_gen_type [412] = Y5189_pgtype412;
	Y5189_gen_type [413] = Y5189_pgtype413;
	Y5189_gen_type [414] = Y5189_pgtype414;
	Y5189_gen_type [415] = Y5189_pgtype415;
	Y5189_gen_type [416] = Y5189_pgtype416;
	Y5189_gen_type [417] = Y5189_pgtype417;
	Y5189_gen_type [418] = Y5189_pgtype418;
	Y5189_gen_type [419] = Y5189_pgtype419;
	Y5189_gen_type [420] = Y5189_pgtype420;
	Y5189_gen_type [421] = Y5189_pgtype421;
	Y5189_gen_type [422] = Y5189_pgtype422;
	Y5189_gen_type [423] = Y5189_pgtype423;
	Y5189_gen_type [424] = Y5189_pgtype424;
	Y5189_gen_type [425] = Y5189_pgtype425;
	Y5189_gen_type [426] = Y5189_pgtype426;
	Y5189_gen_type [427] = Y5189_pgtype427;
	Y5189_gen_type [428] = Y5189_pgtype428;
	Y5189_gen_type [429] = Y5189_pgtype429;
	Y5189_gen_type [430] = Y5189_pgtype430;
	Y5189_gen_type [431] = Y5189_pgtype431;
	Y5189_gen_type [432] = Y5189_pgtype432;
	Y5189_gen_type [433] = Y5189_pgtype433;
	Y5189_gen_type [434] = Y5189_pgtype434;
	Y5189_gen_type [435] = Y5189_pgtype435;
	Y5189_gen_type [436] = Y5189_pgtype436;
	Y5189_gen_type [437] = Y5189_pgtype437;
	Y5189_gen_type [438] = Y5189_pgtype438;
	Y5189_gen_type [439] = Y5189_pgtype439;
	Y5189_gen_type [440] = Y5189_pgtype440;
	Y5189_gen_type [441] = Y5189_pgtype441;
	Y5189_gen_type [442] = Y5189_pgtype442;
	Y5189_gen_type [443] = Y5189_pgtype443;
	Y5189_gen_type [444] = Y5189_pgtype444;
	Y5189_gen_type [445] = Y5189_pgtype445;
	Y5189_gen_type [446] = Y5189_pgtype446;
	Y5189_gen_type [447] = Y5189_pgtype447;
	Y5189_gen_type [448] = Y5189_pgtype448;
	Y5189_gen_type [449] = Y5189_pgtype449;
	Y5189_gen_type [450] = Y5189_pgtype450;
	Y5189_gen_type [451] = Y5189_pgtype451;
	Y5189_gen_type [452] = Y5189_pgtype452;
	Y5189_gen_type [453] = Y5189_pgtype453;
	Y5189_gen_type [454] = Y5189_pgtype454;
	Y5189_gen_type [455] = Y5189_pgtype455;
	Y5189_gen_type [456] = Y5189_pgtype456;
	Y5189_gen_type [457] = Y5189_pgtype457;
	Y5189_gen_type [458] = Y5189_pgtype458;
	Y5189_gen_type [459] = Y5189_pgtype459;
	Y5189_gen_type [460] = Y5189_pgtype460;
	Y5189_gen_type [461] = Y5189_pgtype461;
	Y5189_gen_type [462] = Y5189_pgtype462;
	Y5189_gen_type [463] = Y5189_pgtype463;
	Y5189_gen_type [464] = Y5189_pgtype464;
	Y5189_gen_type [465] = Y5189_pgtype465;
	Y5189_gen_type [466] = Y5189_pgtype466;
	Y5189_gen_type [467] = Y5189_pgtype467;
	Y5189_gen_type [468] = Y5189_pgtype468;
	Y5189_gen_type [530] = Y5189_pgtype469;
	Y5189_gen_type [582] = Y5189_pgtype470;
	Y5189_gen_type [583] = Y5189_pgtype471;
	Y5189_gen_type [584] = Y5189_pgtype472;
	Y5189_gen_type [585] = Y5189_pgtype473;
	Y5189_gen_type [586] = Y5189_pgtype474;
	Y5189_gen_type [587] = Y5189_pgtype475;
	Y5189_gen_type [588] = Y5189_pgtype476;
	Y5189_gen_type [591] = Y5189_pgtype477;
	Y5189_gen_type [592] = Y5189_pgtype478;
	Y5189_gen_type [639] = Y5189_pgtype479;
	Y5189_gen_type [640] = Y5189_pgtype480;
	Y5189_gen_type [641] = Y5189_pgtype481;
	Y5189_gen_type [642] = Y5189_pgtype482;
	Y5189_gen_type [643] = Y5189_pgtype483;
	Y5189_gen_type [644] = Y5189_pgtype484;
	Y5189_gen_type [645] = Y5189_pgtype485;
	Y5189_gen_type [646] = Y5189_pgtype486;
	Y5189_gen_type [647] = Y5189_pgtype487;
	Y5189_gen_type [648] = Y5189_pgtype488;
	Y5189_gen_type [649] = Y5189_pgtype489;
	Y5189_gen_type [650] = Y5189_pgtype490;
	Y5189_gen_type [743] = Y5189_pgtype491;
	Y5189_gen_type [744] = Y5189_pgtype492;
	Y5189_gen_type [754] = Y5189_pgtype493;
	Y5189_gen_type [755] = Y5189_pgtype494;
	Y5189_gen_type [756] = Y5189_pgtype495;
	Y5189_gen_type [757] = Y5189_pgtype496;
	Y5189_gen_type [800] = Y5189_pgtype497;
	Y5189_gen_type [801] = Y5189_pgtype498;
	Y5189_gen_type [802] = Y5189_pgtype499;
	Y5189_gen_type [804] = Y5189_pgtype500;
	Y5189_gen_type [805] = Y5189_pgtype501;
	Y5189_gen_type [806] = Y5189_pgtype502;
	Y5189_gen_type [807] = Y5189_pgtype503;
	Y5189_gen_type [808] = Y5189_pgtype504;
	Y5189_gen_type [840] = Y5189_pgtype505;
	Y5189_gen_type [841] = Y5189_pgtype506;
	Y5189[12] = 1053;
	Y5189[13] = 1056;
	Y5189[14] = 1008;
	Y5189[73] = 1002;
	Y5189[74] = 1008;
	Y5189[111] = 1062;
	{long i; for (i = 264; i < 266; i++) Y5189[i] = 1190;};
	{long i; for (i = 332; i < 335; i++) Y5189[i] = 1002;};
	Y5189[343] = 1055;
	Y5189[364] = 0;
	Y5189[382] = 1190;
	Y5189[467] = 936;
	Y5189[468] = 1264;
	Y5189[530] = 0;
	{long i; for (i = 582; i < 586; i++) Y5189[i] = 1002;};
	{long i; for (i = 586; i < 589; i++) Y5189[i] = 1008;};
	{long i; for (i = 591; i < 593; i++) Y5189[i] = 1062;};
	{long i; for (i = 743; i < 745; i++) Y5189[i] = 1176;};
	Y5189[754] = 1002;
	{long i; for (i = 800; i < 803; i++) Y5189[i] = 1002;};
	{long i; for (i = 804; i < 809; i++) Y5189[i] = 1002;};
	{long i; for (i = 840; i < 842; i++) Y5189[i] = 1002;};
}


#ifdef __cplusplus
}
#endif
