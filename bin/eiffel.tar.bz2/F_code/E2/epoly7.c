#include "epoly7.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5605[422])();
void R5605_init () {
	R5605[0] = (char *(*)()) F803_6486;
	R5605[421] = (char *(*)()) F1224_10440;
}

char *(*R5638[485])();
void R5638_init () {
	R5638[0] = (char *(*)()) F826_6584;
	R5638[1] = (char *(*)()) F827_6584;
	R5638[2] = (char *(*)()) F828_6584_5638_16;
	R5638[3] = (char *(*)()) F829_6584_5638_16;
	R5638[4] = (char *(*)()) F830_6584_5638_16;
	R5638[5] = (char *(*)()) F831_6584_5638_16;
	R5638[6] = (char *(*)()) F832_6584_5638_16;
	R5638[7] = (char *(*)()) F833_6584_5638_16;
	{long i; for (i = 8; i < 10; i++) R5638[i] = (char *(*)()) F826_6584;}
	R5638[10] = (char *(*)()) F828_6584_5638_16;
	R5638[11] = (char *(*)()) F829_6584_5638_16;
	R5638[12] = (char *(*)()) F831_6584_5638_16;
	R5638[13] = (char *(*)()) F832_6584_5638_16;
	R5638[26] = (char *(*)()) F852_6705_5638_16;
	R5638[27] = (char *(*)()) F853_6744;
	R5638[28] = (char *(*)()) F854_6744_5638_16;
	R5638[29] = (char *(*)()) F855_6744_5638_16;
	R5638[30] = (char *(*)()) F856_6744_5638_16;
	R5638[31] = (char *(*)()) F857_6744_5638_16;
	R5638[32] = (char *(*)()) F858_6744_5638_16;
	R5638[33] = (char *(*)()) F859_6744_5638_16;
	R5638[34] = (char *(*)()) F860_6744_5638_16;
	R5638[35] = (char *(*)()) F861_6744_5638_16;
	R5638[36] = (char *(*)()) F862_6744_5638_16;
	R5638[37] = (char *(*)()) F863_6744_5638_16;
	R5638[38] = (char *(*)()) F864_6744_5638_16;
	R5638[92] = (char *(*)()) F870_6802;
	R5638[93] = (char *(*)()) F872_6802_5638_16;
	R5638[94] = (char *(*)()) F870_6802;
	R5638[95] = (char *(*)()) F872_6802_5638_16;
	R5638[96] = (char *(*)()) F870_6802;
	R5638[97] = (char *(*)()) F923_6924;
	R5638[98] = (char *(*)()) F924_6924_5638_16;
	R5638[99] = (char *(*)()) F925_6924_5638_16;
	R5638[100] = (char *(*)()) F926_6924_5638_16;
	R5638[101] = (char *(*)()) F927_6924_5638_16;
	R5638[102] = (char *(*)()) F928_6924_5638_16;
	R5638[103] = (char *(*)()) F929_6924_5638_16;
	R5638[104] = (char *(*)()) F930_6924_5638_16;
	R5638[105] = (char *(*)()) F931_6924_5638_16;
	R5638[106] = (char *(*)()) F932_6924_5638_16;
	R5638[107] = (char *(*)()) F933_6924_5638_16;
	R5638[108] = (char *(*)()) F934_6924_5638_16;
	R5638[109] = (char *(*)()) F923_6924;
	R5638[110] = (char *(*)()) F925_6924_5638_16;
	{long i; for (i = 111; i < 113; i++) R5638[i] = (char *(*)()) F923_6924;}
	R5638[174] = (char *(*)()) F1000_7646;
	R5638[227] = (char *(*)()) F1053_8161_5638_16;
	R5638[228] = (char *(*)()) F1054_8183_5638_16;
	R5638[231] = (char *(*)()) F1057_8329_5638_16;
	R5638[232] = (char *(*)()) F1058_8352_5638_16;
	R5638[283] = (char *(*)()) F1109_9010;
	R5638[284] = (char *(*)()) F1110_9010_5638_16;
	R5638[285] = (char *(*)()) F1111_9010_5638_16;
	R5638[286] = (char *(*)()) F1112_9010_5638_16;
	R5638[287] = (char *(*)()) F1113_9010_5638_16;
	R5638[288] = (char *(*)()) F1114_9010_5638_16;
	R5638[289] = (char *(*)()) F1115_9010_5638_16;
	R5638[290] = (char *(*)()) F1116_9010_5638_16;
	R5638[291] = (char *(*)()) F1117_9010_5638_16;
	R5638[292] = (char *(*)()) F1118_9010_5638_16;
	R5638[293] = (char *(*)()) F1119_9010_5638_16;
	R5638[294] = (char *(*)()) F1120_9010_5638_16;
	R5638[484] = (char *(*)()) F1310_13012_5638_16;
}
static EIF_REFERENCE F828_6584_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F828_6584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F829_6584_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F829_6584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F830_6584_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F830_6584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F831_6584_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F831_6584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F832_6584_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F832_6584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F833_6584_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F833_6584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_6705_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F852_6705(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F854_6744_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F854_6744(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_6744_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F855_6744(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_6744_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F856_6744(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6744_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F857_6744(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_6744_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F858_6744(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_6744_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F859_6744(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F860_6744_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F860_6744(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1184, 0x00).id, 1184, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F861_6744_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F861_6744(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F862_6744_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F862_6744(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F863_6744_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F863_6744(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F864_6744_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F864_6744(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F872_6802_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F872_6802(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F924_6924_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F924_6924(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F925_6924_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F925_6924(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F926_6924_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F926_6924(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F927_6924_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F927_6924(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F928_6924_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F928_6924(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F929_6924_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F929_6924(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F930_6924_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F930_6924(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1184, 0x00).id, 1184, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F931_6924_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F931_6924(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F932_6924_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F932_6924(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F933_6924_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F933_6924(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F934_6924_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F934_6924(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1053_8161_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1053_8161(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1054_8183_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1054_8183(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1057_8329_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1057_8329(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1058_8352_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1058_8352(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1110_9010_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1110_9010(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1111_9010_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1111_9010(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1112_9010_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1112_9010(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1113_9010_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1113_9010(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1114_9010_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1114_9010(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1115_9010_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1115_9010(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1116_9010_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1116_9010(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1184, 0x00).id, 1184, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1117_9010_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1117_9010(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1118_9010_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1118_9010(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1119_9010_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1119_9010(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1120_9010_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1120_9010(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1310_13012_5638_16 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1310_13012(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R5639[485])();
void R5639_init () {
	R5639[0] = (char *(*)()) F826_6589;
	R5639[1] = (char *(*)()) F827_6589;
	R5639[2] = (char *(*)()) F828_6589;
	R5639[3] = (char *(*)()) F829_6589;
	R5639[4] = (char *(*)()) F830_6589;
	R5639[5] = (char *(*)()) F831_6589;
	R5639[6] = (char *(*)()) F832_6589;
	R5639[7] = (char *(*)()) F833_6589;
	{long i; for (i = 8; i < 10; i++) R5639[i] = (char *(*)()) F826_6589;}
	R5639[10] = (char *(*)()) F828_6589;
	R5639[11] = (char *(*)()) F829_6589;
	R5639[12] = (char *(*)()) F831_6589;
	R5639[13] = (char *(*)()) F832_6589;
	R5639[26] = (char *(*)()) F852_6702;
	R5639[27] = (char *(*)()) F853_6749;
	R5639[28] = (char *(*)()) F854_6749;
	R5639[29] = (char *(*)()) F855_6749;
	R5639[30] = (char *(*)()) F856_6749;
	R5639[31] = (char *(*)()) F857_6749;
	R5639[32] = (char *(*)()) F858_6749;
	R5639[33] = (char *(*)()) F859_6749;
	R5639[34] = (char *(*)()) F860_6749;
	R5639[35] = (char *(*)()) F861_6749;
	R5639[36] = (char *(*)()) F862_6749;
	R5639[37] = (char *(*)()) F863_6749;
	R5639[38] = (char *(*)()) F864_6749;
	R5639[92] = (char *(*)()) F870_6805;
	R5639[93] = (char *(*)()) F872_6805;
	R5639[94] = (char *(*)()) F870_6805;
	R5639[95] = (char *(*)()) F872_6805;
	{long i; for (i = 96; i < 98; i++) R5639[i] = (char *(*)()) F870_6805;}
	R5639[98] = (char *(*)()) F871_6805;
	R5639[99] = (char *(*)()) F872_6805;
	R5639[100] = (char *(*)()) F873_6805;
	R5639[101] = (char *(*)()) F874_6805;
	R5639[102] = (char *(*)()) F875_6805;
	R5639[103] = (char *(*)()) F876_6805;
	R5639[104] = (char *(*)()) F877_6805;
	R5639[105] = (char *(*)()) F878_6805;
	R5639[106] = (char *(*)()) F879_6805;
	R5639[107] = (char *(*)()) F880_6805;
	R5639[108] = (char *(*)()) F881_6805;
	R5639[109] = (char *(*)()) F870_6805;
	R5639[110] = (char *(*)()) F872_6805;
	{long i; for (i = 111; i < 113; i++) R5639[i] = (char *(*)()) F870_6805;}
	R5639[174] = (char *(*)()) F1000_7676;
	{long i; for (i = 227; i < 229; i++) R5639[i] = (char *(*)()) F1052_8128;}
	{long i; for (i = 231; i < 233; i++) R5639[i] = (char *(*)()) F1056_8293;}
	R5639[283] = (char *(*)()) F1109_9018;
	R5639[284] = (char *(*)()) F1110_9018;
	R5639[285] = (char *(*)()) F1111_9018;
	R5639[286] = (char *(*)()) F1112_9018;
	R5639[287] = (char *(*)()) F1113_9018;
	R5639[288] = (char *(*)()) F1114_9018;
	R5639[289] = (char *(*)()) F1115_9018;
	R5639[290] = (char *(*)()) F1116_9018;
	R5639[291] = (char *(*)()) F1117_9018;
	R5639[292] = (char *(*)()) F1118_9018;
	R5639[293] = (char *(*)()) F1119_9018;
	R5639[294] = (char *(*)()) F1120_9018;
	R5639[484] = (char *(*)()) F1052_8128;
}

EIF_TYPE_INDEX *Y5639_gen_type [498];
EIF_TYPE_INDEX Y5639 [498];
void Y5639_init (void)
{
	egc_routines_types [5639] = Y5639;
	egc_routines_gen_types [5639] = Y5639_gen_type;
	egc_routines_offset [5639] = 813;
	{long i; for (i = 0; i < 125; i++) Y5639[i] = 1190;};
	Y5639[186] = 1190;
	{long i; for (i = 238; i < 245; i++) Y5639[i] = 1190;};
	{long i; for (i = 295; i < 307; i++) Y5639[i] = 1190;};
	{long i; for (i = 496; i < 498; i++) Y5639[i] = 1190;};
}

char *(*R5640[485])();
void R5640_init () {
	R5640[0] = (char *(*)()) F826_6590;
	R5640[1] = (char *(*)()) F827_6590;
	R5640[2] = (char *(*)()) F828_6590;
	R5640[3] = (char *(*)()) F829_6590;
	R5640[4] = (char *(*)()) F830_6590;
	R5640[5] = (char *(*)()) F831_6590;
	R5640[6] = (char *(*)()) F832_6590;
	R5640[7] = (char *(*)()) F833_6590;
	{long i; for (i = 8; i < 10; i++) R5640[i] = (char *(*)()) F826_6590;}
	R5640[10] = (char *(*)()) F828_6590;
	R5640[11] = (char *(*)()) F829_6590;
	R5640[12] = (char *(*)()) F831_6590;
	R5640[13] = (char *(*)()) F832_6590;
	R5640[26] = (char *(*)()) F852_6704;
	R5640[27] = (char *(*)()) F853_6750;
	R5640[28] = (char *(*)()) F854_6750;
	R5640[29] = (char *(*)()) F855_6750;
	R5640[30] = (char *(*)()) F856_6750;
	R5640[31] = (char *(*)()) F857_6750;
	R5640[32] = (char *(*)()) F858_6750;
	R5640[33] = (char *(*)()) F859_6750;
	R5640[34] = (char *(*)()) F860_6750;
	R5640[35] = (char *(*)()) F861_6750;
	R5640[36] = (char *(*)()) F862_6750;
	R5640[37] = (char *(*)()) F863_6750;
	R5640[38] = (char *(*)()) F864_6750;
	R5640[92] = (char *(*)()) F918_6857;
	R5640[93] = (char *(*)()) F919_6857;
	R5640[94] = (char *(*)()) F918_6857;
	R5640[95] = (char *(*)()) F919_6857;
	R5640[96] = (char *(*)()) F918_6857;
	R5640[97] = (char *(*)()) F923_6939;
	R5640[98] = (char *(*)()) F924_6939;
	R5640[99] = (char *(*)()) F925_6939;
	R5640[100] = (char *(*)()) F926_6939;
	R5640[101] = (char *(*)()) F927_6939;
	R5640[102] = (char *(*)()) F928_6939;
	R5640[103] = (char *(*)()) F929_6939;
	R5640[104] = (char *(*)()) F930_6939;
	R5640[105] = (char *(*)()) F931_6939;
	R5640[106] = (char *(*)()) F932_6939;
	R5640[107] = (char *(*)()) F933_6939;
	R5640[108] = (char *(*)()) F934_6939;
	R5640[109] = (char *(*)()) F923_6939;
	R5640[110] = (char *(*)()) F925_6939;
	{long i; for (i = 111; i < 113; i++) R5640[i] = (char *(*)()) F923_6939;}
	R5640[174] = (char *(*)()) F1000_7675;
	{long i; for (i = 227; i < 229; i++) R5640[i] = (char *(*)()) F1052_8126;}
	{long i; for (i = 231; i < 233; i++) R5640[i] = (char *(*)()) F1056_8291;}
	R5640[283] = (char *(*)()) F1109_9019;
	R5640[284] = (char *(*)()) F1110_9019;
	R5640[285] = (char *(*)()) F1111_9019;
	R5640[286] = (char *(*)()) F1112_9019;
	R5640[287] = (char *(*)()) F1113_9019;
	R5640[288] = (char *(*)()) F1114_9019;
	R5640[289] = (char *(*)()) F1115_9019;
	R5640[290] = (char *(*)()) F1116_9019;
	R5640[291] = (char *(*)()) F1117_9019;
	R5640[292] = (char *(*)()) F1118_9019;
	R5640[293] = (char *(*)()) F1119_9019;
	R5640[294] = (char *(*)()) F1120_9019;
	R5640[484] = (char *(*)()) F1310_13028;
}

char *(*R5642[485])();
void R5642_init () {
	R5642[0] = (char *(*)()) F826_6606;
	R5642[1] = (char *(*)()) F827_6606;
	R5642[2] = (char *(*)()) F828_6606;
	R5642[3] = (char *(*)()) F829_6606;
	R5642[4] = (char *(*)()) F830_6606;
	R5642[5] = (char *(*)()) F831_6606;
	R5642[6] = (char *(*)()) F832_6606;
	R5642[7] = (char *(*)()) F833_6606;
	{long i; for (i = 8; i < 10; i++) R5642[i] = (char *(*)()) F826_6606;}
	R5642[10] = (char *(*)()) F828_6606;
	R5642[11] = (char *(*)()) F829_6606;
	R5642[12] = (char *(*)()) F831_6606;
	R5642[13] = (char *(*)()) F832_6606;
	R5642[26] = (char *(*)()) F852_6708;
	R5642[27] = (char *(*)()) F853_6759;
	R5642[28] = (char *(*)()) F854_6759;
	R5642[29] = (char *(*)()) F855_6759;
	R5642[30] = (char *(*)()) F856_6759;
	R5642[31] = (char *(*)()) F857_6759;
	R5642[32] = (char *(*)()) F858_6759;
	R5642[33] = (char *(*)()) F859_6759;
	R5642[34] = (char *(*)()) F860_6759;
	R5642[35] = (char *(*)()) F861_6759;
	R5642[36] = (char *(*)()) F862_6759;
	R5642[37] = (char *(*)()) F863_6759;
	R5642[38] = (char *(*)()) F864_6759;
	R5642[92] = (char *(*)()) F870_6810;
	R5642[93] = (char *(*)()) F872_6810;
	R5642[94] = (char *(*)()) F870_6810;
	R5642[95] = (char *(*)()) F872_6810;
	R5642[96] = (char *(*)()) F870_6810;
	R5642[97] = (char *(*)()) F923_6945;
	R5642[98] = (char *(*)()) F924_6945;
	R5642[99] = (char *(*)()) F925_6945;
	R5642[100] = (char *(*)()) F926_6945;
	R5642[101] = (char *(*)()) F927_6945;
	R5642[102] = (char *(*)()) F928_6945;
	R5642[103] = (char *(*)()) F929_6945;
	R5642[104] = (char *(*)()) F930_6945;
	R5642[105] = (char *(*)()) F931_6945;
	R5642[106] = (char *(*)()) F932_6945;
	R5642[107] = (char *(*)()) F933_6945;
	R5642[108] = (char *(*)()) F934_6945;
	R5642[109] = (char *(*)()) F923_6945;
	R5642[110] = (char *(*)()) F925_6945;
	{long i; for (i = 111; i < 113; i++) R5642[i] = (char *(*)()) F923_6945;}
	R5642[174] = (char *(*)()) F1000_7673;
	{long i; for (i = 227; i < 229; i++) R5642[i] = (char *(*)()) F1049_7986;}
	{long i; for (i = 231; i < 233; i++) R5642[i] = (char *(*)()) F1049_7986;}
	R5642[283] = (char *(*)()) F1109_9024;
	R5642[284] = (char *(*)()) F1110_9024;
	R5642[285] = (char *(*)()) F1111_9024;
	R5642[286] = (char *(*)()) F1112_9024;
	R5642[287] = (char *(*)()) F1113_9024;
	R5642[288] = (char *(*)()) F1114_9024;
	R5642[289] = (char *(*)()) F1115_9024;
	R5642[290] = (char *(*)()) F1116_9024;
	R5642[291] = (char *(*)()) F1117_9024;
	R5642[292] = (char *(*)()) F1118_9024;
	R5642[293] = (char *(*)()) F1119_9024;
	R5642[294] = (char *(*)()) F1120_9024;
	R5642[484] = (char *(*)()) F1049_7986;
}

char *(*R5643[14])();
void R5643_init () {
	R5643[0] = (char *(*)()) F826_6568;
	R5643[1] = (char *(*)()) F827_6568;
	R5643[2] = (char *(*)()) F828_6568;
	R5643[3] = (char *(*)()) F829_6568;
	R5643[4] = (char *(*)()) F830_6568;
	R5643[5] = (char *(*)()) F831_6568;
	R5643[6] = (char *(*)()) F832_6568;
	R5643[7] = (char *(*)()) F833_6568;
	{long i; for (i = 8; i < 10; i++) R5643[i] = (char *(*)()) F826_6568;}
	R5643[10] = (char *(*)()) F828_6568;
	R5643[11] = (char *(*)()) F829_6568;
	R5643[12] = (char *(*)()) F831_6568;
	R5643[13] = (char *(*)()) F832_6568;
}

char *(*R5644[14])();
void R5644_init () {
	R5644[0] = (char *(*)()) F826_6569;
	R5644[1] = (char *(*)()) F827_6569;
	R5644[2] = (char *(*)()) F828_6569;
	R5644[3] = (char *(*)()) F829_6569;
	R5644[4] = (char *(*)()) F830_6569;
	R5644[5] = (char *(*)()) F831_6569;
	R5644[6] = (char *(*)()) F832_6569;
	R5644[7] = (char *(*)()) F833_6569;
	{long i; for (i = 8; i < 10; i++) R5644[i] = (char *(*)()) F826_6569;}
	R5644[10] = (char *(*)()) F828_6569;
	R5644[11] = (char *(*)()) F829_6569;
	R5644[12] = (char *(*)()) F831_6569;
	R5644[13] = (char *(*)()) F832_6569;
}

char *(*R5646[14])();
void R5646_init () {
	R5646[0] = (char *(*)()) F826_6571;
	R5646[1] = (char *(*)()) F827_6571;
	R5646[2] = (char *(*)()) F828_6571;
	R5646[3] = (char *(*)()) F829_6571;
	R5646[4] = (char *(*)()) F830_6571;
	R5646[5] = (char *(*)()) F831_6571;
	R5646[6] = (char *(*)()) F832_6571;
	R5646[7] = (char *(*)()) F833_6571;
	{long i; for (i = 8; i < 10; i++) R5646[i] = (char *(*)()) F826_6571;}
	R5646[10] = (char *(*)()) F828_6571;
	R5646[11] = (char *(*)()) F829_6571;
	R5646[12] = (char *(*)()) F831_6571;
	R5646[13] = (char *(*)()) F832_6571;
}

char *(*R5647[14])();
void R5647_init () {
	R5647[0] = (char *(*)()) F826_6572;
	R5647[1] = (char *(*)()) F827_6572;
	R5647[2] = (char *(*)()) F828_6572_5647_1;
	R5647[3] = (char *(*)()) F829_6572_5647_1;
	R5647[4] = (char *(*)()) F830_6572_5647_1;
	R5647[5] = (char *(*)()) F831_6572_5647_1;
	R5647[6] = (char *(*)()) F832_6572_5647_1;
	R5647[7] = (char *(*)()) F833_6572_5647_1;
	{long i; for (i = 8; i < 10; i++) R5647[i] = (char *(*)()) F826_6572;}
	R5647[10] = (char *(*)()) F828_6572_5647_1;
	R5647[11] = (char *(*)()) F829_6572_5647_1;
	R5647[12] = (char *(*)()) F831_6572_5647_1;
	R5647[13] = (char *(*)()) F832_6572_5647_1;
}
static EIF_REFERENCE F828_6572_5647_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F828_6572(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F829_6572_5647_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F829_6572(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F830_6572_5647_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F830_6572(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F831_6572_5647_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F831_6572(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F832_6572_5647_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F832_6572(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F833_6572_5647_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F833_6572(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y5648_pgtype0[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5648_pgtype1[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5648_pgtype2[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5648_pgtype3[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5648_pgtype4[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5648_pgtype5[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5648_pgtype6[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5648_pgtype7[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5648_pgtype8[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5648_pgtype9[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5648_pgtype10[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5648_pgtype11[] = {0xFF02,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5648_pgtype12[] = {0xFF02,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5648_gen_type [14];
EIF_TYPE_INDEX Y5648 [14];
void Y5648_init (void)
{
	egc_routines_types [5648] = Y5648;
	egc_routines_gen_types [5648] = Y5648_gen_type;
	egc_routines_offset [5648] = 825;
	Y5648_gen_type [0] = Y5648_pgtype0;
	Y5648_gen_type [1] = Y5648_pgtype1;
	Y5648_gen_type [2] = Y5648_pgtype2;
	Y5648_gen_type [3] = Y5648_pgtype3;
	Y5648_gen_type [4] = Y5648_pgtype4;
	Y5648_gen_type [5] = Y5648_pgtype5;
	Y5648_gen_type [6] = Y5648_pgtype6;
	Y5648_gen_type [7] = Y5648_pgtype7;
	Y5648_gen_type [9] = Y5648_pgtype8;
	Y5648_gen_type [10] = Y5648_pgtype9;
	Y5648_gen_type [11] = Y5648_pgtype10;
	Y5648_gen_type [12] = Y5648_pgtype11;
	Y5648_gen_type [13] = Y5648_pgtype12;
	Y5648[8] = 0;
}

char *(*R5652[14])();
void R5652_init () {
	R5652[0] = (char *(*)()) F826_6580;
	R5652[1] = (char *(*)()) F827_6580;
	R5652[2] = (char *(*)()) F828_6580_5652_1;
	R5652[3] = (char *(*)()) F829_6580_5652_1;
	R5652[4] = (char *(*)()) F830_6580_5652_1;
	R5652[5] = (char *(*)()) F831_6580_5652_1;
	R5652[6] = (char *(*)()) F832_6580_5652_1;
	R5652[7] = (char *(*)()) F833_6580_5652_1;
	{long i; for (i = 8; i < 10; i++) R5652[i] = (char *(*)()) F826_6580;}
	R5652[10] = (char *(*)()) F828_6580_5652_1;
	R5652[11] = (char *(*)()) F829_6580_5652_1;
	R5652[12] = (char *(*)()) F831_6580_5652_1;
	R5652[13] = (char *(*)()) F832_6580_5652_1;
}
static EIF_REFERENCE F828_6580_5652_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F828_6580(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F829_6580_5652_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F829_6580(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F830_6580_5652_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F830_6580(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F831_6580_5652_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F831_6580(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F832_6580_5652_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F832_6580(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F833_6580_5652_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F833_6580(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y5652_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5652_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5652_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5652_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5652_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5652_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5652_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5652_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5652_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5652_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5652_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5652_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5652_pgtype12[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5652_gen_type [14];
EIF_TYPE_INDEX Y5652 [14];
void Y5652_init (void)
{
	egc_routines_types [5652] = Y5652;
	egc_routines_gen_types [5652] = Y5652_gen_type;
	egc_routines_offset [5652] = 825;
	Y5652_gen_type [0] = Y5652_pgtype0;
	Y5652_gen_type [1] = Y5652_pgtype1;
	Y5652_gen_type [2] = Y5652_pgtype2;
	Y5652_gen_type [3] = Y5652_pgtype3;
	Y5652_gen_type [4] = Y5652_pgtype4;
	Y5652_gen_type [5] = Y5652_pgtype5;
	Y5652_gen_type [6] = Y5652_pgtype6;
	Y5652_gen_type [7] = Y5652_pgtype7;
	Y5652_gen_type [9] = Y5652_pgtype8;
	Y5652_gen_type [10] = Y5652_pgtype9;
	Y5652_gen_type [11] = Y5652_pgtype10;
	Y5652_gen_type [12] = Y5652_pgtype11;
	Y5652_gen_type [13] = Y5652_pgtype12;
	Y5652[8] = 0;
}

char *(*R5655[14])();
void R5655_init () {
	R5655[0] = (char *(*)()) F826_6585;
	R5655[1] = (char *(*)()) F827_6585_5655_47;
	R5655[2] = (char *(*)()) F828_6585;
	R5655[3] = (char *(*)()) F829_6585;
	R5655[4] = (char *(*)()) F830_6585_5655_47;
	R5655[5] = (char *(*)()) F831_6585;
	R5655[6] = (char *(*)()) F832_6585;
	R5655[7] = (char *(*)()) F833_6585;
	R5655[8] = (char *(*)()) F826_6585;
	R5655[9] = (char *(*)()) F835_6694;
	R5655[10] = (char *(*)()) F836_6694;
	R5655[11] = (char *(*)()) F837_6694;
	R5655[12] = (char *(*)()) F838_6694;
	R5655[13] = (char *(*)()) F839_6694;
}
static EIF_INTEGER_32 F827_6585_5655_47 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F827_6585(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F830_6585_5655_47 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F830_6585(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5657[14])();
void R5657_init () {
	R5657[0] = (char *(*)()) F826_6592;
	R5657[1] = (char *(*)()) F827_6592_5657_3;
	R5657[2] = (char *(*)()) F828_6592;
	R5657[3] = (char *(*)()) F829_6592;
	R5657[4] = (char *(*)()) F830_6592_5657_3;
	R5657[5] = (char *(*)()) F831_6592;
	R5657[6] = (char *(*)()) F832_6592;
	R5657[7] = (char *(*)()) F833_6592;
	R5657[8] = (char *(*)()) F826_6592;
	R5657[9] = (char *(*)()) F835_6696;
	R5657[10] = (char *(*)()) F836_6696;
	R5657[11] = (char *(*)()) F837_6696;
	R5657[12] = (char *(*)()) F838_6696;
	R5657[13] = (char *(*)()) F839_6696;
}
static EIF_BOOLEAN F827_6592_5657_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F827_6592(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F830_6592_5657_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F830_6592(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R5663[14])();
void R5663_init () {
	R5663[0] = (char *(*)()) F826_6600;
	R5663[1] = (char *(*)()) F827_6600;
	R5663[2] = (char *(*)()) F828_6600;
	R5663[3] = (char *(*)()) F829_6600;
	R5663[4] = (char *(*)()) F830_6600;
	R5663[5] = (char *(*)()) F831_6600;
	R5663[6] = (char *(*)()) F832_6600;
	R5663[7] = (char *(*)()) F833_6600;
	{long i; for (i = 8; i < 10; i++) R5663[i] = (char *(*)()) F826_6600;}
	R5663[10] = (char *(*)()) F828_6600;
	R5663[11] = (char *(*)()) F829_6600;
	R5663[12] = (char *(*)()) F831_6600;
	R5663[13] = (char *(*)()) F832_6600;
}

char *(*R5664[14])();
void R5664_init () {
	R5664[0] = (char *(*)()) F826_6601;
	R5664[1] = (char *(*)()) F827_6601;
	R5664[2] = (char *(*)()) F828_6601;
	R5664[3] = (char *(*)()) F829_6601;
	R5664[4] = (char *(*)()) F830_6601;
	R5664[5] = (char *(*)()) F831_6601;
	R5664[6] = (char *(*)()) F832_6601;
	R5664[7] = (char *(*)()) F833_6601;
	{long i; for (i = 8; i < 10; i++) R5664[i] = (char *(*)()) F826_6601;}
	R5664[10] = (char *(*)()) F828_6601;
	R5664[11] = (char *(*)()) F829_6601;
	R5664[12] = (char *(*)()) F831_6601;
	R5664[13] = (char *(*)()) F832_6601;
}

char *(*R5666[14])();
void R5666_init () {
	R5666[0] = (char *(*)()) F826_6603;
	R5666[1] = (char *(*)()) F827_6603;
	R5666[2] = (char *(*)()) F828_6603;
	R5666[3] = (char *(*)()) F829_6603;
	R5666[4] = (char *(*)()) F830_6603;
	R5666[5] = (char *(*)()) F831_6603;
	R5666[6] = (char *(*)()) F832_6603;
	R5666[7] = (char *(*)()) F833_6603;
	{long i; for (i = 8; i < 10; i++) R5666[i] = (char *(*)()) F826_6603;}
	R5666[10] = (char *(*)()) F828_6603;
	R5666[11] = (char *(*)()) F829_6603;
	R5666[12] = (char *(*)()) F831_6603;
	R5666[13] = (char *(*)()) F832_6603;
}

char *(*R5669[14])();
void R5669_init () {
	R5669[0] = (char *(*)()) F826_6607;
	R5669[1] = (char *(*)()) F827_6607;
	R5669[2] = (char *(*)()) F828_6607;
	R5669[3] = (char *(*)()) F829_6607;
	R5669[4] = (char *(*)()) F830_6607;
	R5669[5] = (char *(*)()) F831_6607;
	R5669[6] = (char *(*)()) F832_6607;
	R5669[7] = (char *(*)()) F833_6607;
	{long i; for (i = 8; i < 10; i++) R5669[i] = (char *(*)()) F826_6607;}
	R5669[10] = (char *(*)()) F828_6607;
	R5669[11] = (char *(*)()) F829_6607;
	R5669[12] = (char *(*)()) F831_6607;
	R5669[13] = (char *(*)()) F832_6607;
}

char *(*R5670[14])();
void R5670_init () {
	R5670[0] = (char *(*)()) F826_6608;
	R5670[1] = (char *(*)()) F827_6608;
	R5670[2] = (char *(*)()) F828_6608;
	R5670[3] = (char *(*)()) F829_6608;
	R5670[4] = (char *(*)()) F830_6608;
	R5670[5] = (char *(*)()) F831_6608;
	R5670[6] = (char *(*)()) F832_6608;
	R5670[7] = (char *(*)()) F833_6608;
	{long i; for (i = 8; i < 10; i++) R5670[i] = (char *(*)()) F826_6608;}
	R5670[10] = (char *(*)()) F828_6608;
	R5670[11] = (char *(*)()) F829_6608;
	R5670[12] = (char *(*)()) F831_6608;
	R5670[13] = (char *(*)()) F832_6608;
}

char *(*R5672[14])();
void R5672_init () {
	R5672[0] = (char *(*)()) F826_6610;
	R5672[1] = (char *(*)()) F827_6610_5672_4;
	R5672[2] = (char *(*)()) F828_6610;
	R5672[3] = (char *(*)()) F829_6610;
	R5672[4] = (char *(*)()) F830_6610_5672_4;
	R5672[5] = (char *(*)()) F831_6610;
	R5672[6] = (char *(*)()) F832_6610;
	R5672[7] = (char *(*)()) F833_6610;
	{long i; for (i = 8; i < 10; i++) R5672[i] = (char *(*)()) F826_6610;}
	R5672[10] = (char *(*)()) F828_6610;
	R5672[11] = (char *(*)()) F829_6610;
	R5672[12] = (char *(*)()) F831_6610;
	R5672[13] = (char *(*)()) F832_6610;
}
static void F827_6610_5672_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F827_6610(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F830_6610_5672_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F830_6610(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5674[14])();
void R5674_init () {
	R5674[0] = (char *(*)()) F826_6612;
	R5674[1] = (char *(*)()) F827_6612;
	R5674[2] = (char *(*)()) F828_6612;
	R5674[3] = (char *(*)()) F829_6612;
	R5674[4] = (char *(*)()) F830_6612;
	R5674[5] = (char *(*)()) F831_6612;
	R5674[6] = (char *(*)()) F832_6612;
	R5674[7] = (char *(*)()) F833_6612;
	{long i; for (i = 8; i < 10; i++) R5674[i] = (char *(*)()) F826_6612;}
	R5674[10] = (char *(*)()) F828_6612;
	R5674[11] = (char *(*)()) F829_6612;
	R5674[12] = (char *(*)()) F831_6612;
	R5674[13] = (char *(*)()) F832_6612;
}

char *(*R5675[14])();
void R5675_init () {
	R5675[0] = (char *(*)()) F826_6613;
	R5675[1] = (char *(*)()) F827_6613;
	R5675[2] = (char *(*)()) F828_6613;
	R5675[3] = (char *(*)()) F829_6613;
	R5675[4] = (char *(*)()) F830_6613;
	R5675[5] = (char *(*)()) F831_6613;
	R5675[6] = (char *(*)()) F832_6613;
	R5675[7] = (char *(*)()) F833_6613;
	{long i; for (i = 8; i < 10; i++) R5675[i] = (char *(*)()) F826_6613;}
	R5675[10] = (char *(*)()) F828_6613;
	R5675[11] = (char *(*)()) F829_6613;
	R5675[12] = (char *(*)()) F831_6613;
	R5675[13] = (char *(*)()) F832_6613;
}

char *(*R5681[14])();
void R5681_init () {
	R5681[0] = (char *(*)()) F826_6626;
	R5681[1] = (char *(*)()) F827_6626;
	R5681[2] = (char *(*)()) F828_6626;
	R5681[3] = (char *(*)()) F829_6626;
	R5681[4] = (char *(*)()) F830_6626;
	R5681[5] = (char *(*)()) F831_6626;
	R5681[6] = (char *(*)()) F832_6626;
	R5681[7] = (char *(*)()) F833_6626;
	R5681[8] = (char *(*)()) F826_6626;
	R5681[9] = (char *(*)()) F835_6698;
	R5681[10] = (char *(*)()) F836_6698;
	R5681[11] = (char *(*)()) F837_6698;
	R5681[12] = (char *(*)()) F838_6698;
	R5681[13] = (char *(*)()) F839_6698;
}

char *(*R5690[14])();
void R5690_init () {
	R5690[0] = (char *(*)()) F826_6636;
	R5690[1] = (char *(*)()) F827_6636;
	R5690[2] = (char *(*)()) F828_6636;
	R5690[3] = (char *(*)()) F829_6636;
	R5690[4] = (char *(*)()) F830_6636;
	R5690[5] = (char *(*)()) F831_6636;
	R5690[6] = (char *(*)()) F832_6636;
	R5690[7] = (char *(*)()) F833_6636;
	{long i; for (i = 8; i < 10; i++) R5690[i] = (char *(*)()) F826_6636;}
	R5690[10] = (char *(*)()) F828_6636;
	R5690[11] = (char *(*)()) F829_6636;
	R5690[12] = (char *(*)()) F831_6636;
	R5690[13] = (char *(*)()) F832_6636;
}

char *(*R5691[14])();
void R5691_init () {
	R5691[0] = (char *(*)()) F826_6637;
	R5691[1] = (char *(*)()) F827_6637;
	R5691[2] = (char *(*)()) F828_6637;
	R5691[3] = (char *(*)()) F829_6637;
	R5691[4] = (char *(*)()) F830_6637;
	R5691[5] = (char *(*)()) F831_6637;
	R5691[6] = (char *(*)()) F832_6637;
	R5691[7] = (char *(*)()) F833_6637;
	{long i; for (i = 8; i < 10; i++) R5691[i] = (char *(*)()) F826_6637;}
	R5691[10] = (char *(*)()) F828_6637;
	R5691[11] = (char *(*)()) F829_6637;
	R5691[12] = (char *(*)()) F831_6637;
	R5691[13] = (char *(*)()) F832_6637;
}

char *(*R5698[14])();
void R5698_init () {
	R5698[0] = (char *(*)()) F826_6644;
	R5698[1] = (char *(*)()) F827_6644;
	R5698[2] = (char *(*)()) F828_6644_5698_1;
	R5698[3] = (char *(*)()) F829_6644_5698_1;
	R5698[4] = (char *(*)()) F830_6644_5698_1;
	R5698[5] = (char *(*)()) F831_6644_5698_1;
	R5698[6] = (char *(*)()) F832_6644_5698_1;
	R5698[7] = (char *(*)()) F833_6644_5698_1;
	{long i; for (i = 8; i < 10; i++) R5698[i] = (char *(*)()) F826_6644;}
	R5698[10] = (char *(*)()) F828_6644_5698_1;
	R5698[11] = (char *(*)()) F829_6644_5698_1;
	R5698[12] = (char *(*)()) F831_6644_5698_1;
	R5698[13] = (char *(*)()) F832_6644_5698_1;
}
static EIF_REFERENCE F828_6644_5698_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F828_6644(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F829_6644_5698_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F829_6644(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F830_6644_5698_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F830_6644(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F831_6644_5698_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F831_6644(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F832_6644_5698_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F832_6644(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F833_6644_5698_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F833_6644(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5699[14])();
void R5699_init () {
	R5699[0] = (char *(*)()) F826_6645;
	R5699[1] = (char *(*)()) F827_6645_5699_1;
	R5699[2] = (char *(*)()) F828_6645;
	R5699[3] = (char *(*)()) F829_6645;
	R5699[4] = (char *(*)()) F830_6645_5699_1;
	R5699[5] = (char *(*)()) F831_6645;
	R5699[6] = (char *(*)()) F832_6645;
	R5699[7] = (char *(*)()) F833_6645;
	{long i; for (i = 8; i < 10; i++) R5699[i] = (char *(*)()) F826_6645;}
	R5699[10] = (char *(*)()) F828_6645;
	R5699[11] = (char *(*)()) F829_6645;
	R5699[12] = (char *(*)()) F831_6645;
	R5699[13] = (char *(*)()) F832_6645;
}
static EIF_REFERENCE F827_6645_5699_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F827_6645(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F830_6645_5699_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F830_6645(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5700[14])();
void R5700_init () {
	R5700[0] = (char *(*)()) F826_6646;
	R5700[1] = (char *(*)()) F827_6646;
	R5700[2] = (char *(*)()) F828_6646;
	R5700[3] = (char *(*)()) F829_6646;
	R5700[4] = (char *(*)()) F830_6646;
	R5700[5] = (char *(*)()) F831_6646;
	R5700[6] = (char *(*)()) F832_6646;
	R5700[7] = (char *(*)()) F833_6646;
	{long i; for (i = 8; i < 10; i++) R5700[i] = (char *(*)()) F826_6646;}
	R5700[10] = (char *(*)()) F828_6646;
	R5700[11] = (char *(*)()) F829_6646;
	R5700[12] = (char *(*)()) F831_6646;
	R5700[13] = (char *(*)()) F832_6646;
}

char *(*R5701[14])();
void R5701_init () {
	R5701[0] = (char *(*)()) F826_6647;
	R5701[1] = (char *(*)()) F827_6647;
	R5701[2] = (char *(*)()) F828_6647;
	R5701[3] = (char *(*)()) F829_6647;
	R5701[4] = (char *(*)()) F830_6647;
	R5701[5] = (char *(*)()) F831_6647;
	R5701[6] = (char *(*)()) F832_6647;
	R5701[7] = (char *(*)()) F833_6647;
	{long i; for (i = 8; i < 10; i++) R5701[i] = (char *(*)()) F826_6647;}
	R5701[10] = (char *(*)()) F828_6647;
	R5701[11] = (char *(*)()) F829_6647;
	R5701[12] = (char *(*)()) F831_6647;
	R5701[13] = (char *(*)()) F832_6647;
}

char *(*R5702[14])();
void R5702_init () {
	R5702[0] = (char *(*)()) F826_6648;
	R5702[1] = (char *(*)()) F827_6648;
	R5702[2] = (char *(*)()) F828_6648;
	R5702[3] = (char *(*)()) F829_6648;
	R5702[4] = (char *(*)()) F830_6648;
	R5702[5] = (char *(*)()) F831_6648;
	R5702[6] = (char *(*)()) F832_6648;
	R5702[7] = (char *(*)()) F833_6648;
	{long i; for (i = 8; i < 10; i++) R5702[i] = (char *(*)()) F826_6648;}
	R5702[10] = (char *(*)()) F828_6648;
	R5702[11] = (char *(*)()) F829_6648;
	R5702[12] = (char *(*)()) F831_6648;
	R5702[13] = (char *(*)()) F832_6648;
}

char *(*R5703[14])();
void R5703_init () {
	R5703[0] = (char *(*)()) F826_6649;
	R5703[1] = (char *(*)()) F827_6649;
	R5703[2] = (char *(*)()) F828_6649;
	R5703[3] = (char *(*)()) F829_6649;
	R5703[4] = (char *(*)()) F830_6649;
	R5703[5] = (char *(*)()) F831_6649;
	R5703[6] = (char *(*)()) F832_6649;
	R5703[7] = (char *(*)()) F833_6649;
	{long i; for (i = 8; i < 10; i++) R5703[i] = (char *(*)()) F826_6649;}
	R5703[10] = (char *(*)()) F828_6649;
	R5703[11] = (char *(*)()) F829_6649;
	R5703[12] = (char *(*)()) F831_6649;
	R5703[13] = (char *(*)()) F832_6649;
}

char *(*R5704[14])();
void R5704_init () {
	R5704[0] = (char *(*)()) F826_6650;
	R5704[1] = (char *(*)()) F827_6650;
	R5704[2] = (char *(*)()) F828_6650;
	R5704[3] = (char *(*)()) F829_6650;
	R5704[4] = (char *(*)()) F830_6650;
	R5704[5] = (char *(*)()) F831_6650;
	R5704[6] = (char *(*)()) F832_6650;
	R5704[7] = (char *(*)()) F833_6650;
	{long i; for (i = 8; i < 10; i++) R5704[i] = (char *(*)()) F826_6650;}
	R5704[10] = (char *(*)()) F828_6650;
	R5704[11] = (char *(*)()) F829_6650;
	R5704[12] = (char *(*)()) F831_6650;
	R5704[13] = (char *(*)()) F832_6650;
}

char *(*R5706[14])();
void R5706_init () {
	R5706[0] = (char *(*)()) F826_6652;
	R5706[1] = (char *(*)()) F827_6652;
	R5706[2] = (char *(*)()) F828_6652;
	R5706[3] = (char *(*)()) F829_6652;
	R5706[4] = (char *(*)()) F830_6652;
	R5706[5] = (char *(*)()) F831_6652;
	R5706[6] = (char *(*)()) F832_6652;
	R5706[7] = (char *(*)()) F833_6652;
	{long i; for (i = 8; i < 10; i++) R5706[i] = (char *(*)()) F826_6652;}
	R5706[10] = (char *(*)()) F828_6652;
	R5706[11] = (char *(*)()) F829_6652;
	R5706[12] = (char *(*)()) F831_6652;
	R5706[13] = (char *(*)()) F832_6652;
}

char *(*R5707[14])();
void R5707_init () {
	R5707[0] = (char *(*)()) F826_6653;
	R5707[1] = (char *(*)()) F827_6653;
	R5707[2] = (char *(*)()) F828_6653;
	R5707[3] = (char *(*)()) F829_6653;
	R5707[4] = (char *(*)()) F830_6653;
	R5707[5] = (char *(*)()) F831_6653;
	R5707[6] = (char *(*)()) F832_6653;
	R5707[7] = (char *(*)()) F833_6653;
	{long i; for (i = 8; i < 10; i++) R5707[i] = (char *(*)()) F826_6653;}
	R5707[10] = (char *(*)()) F828_6653;
	R5707[11] = (char *(*)()) F829_6653;
	R5707[12] = (char *(*)()) F831_6653;
	R5707[13] = (char *(*)()) F832_6653;
}

char *(*R5708[14])();
void R5708_init () {
	R5708[0] = (char *(*)()) F826_6654;
	R5708[1] = (char *(*)()) F827_6654;
	R5708[2] = (char *(*)()) F828_6654;
	R5708[3] = (char *(*)()) F829_6654;
	R5708[4] = (char *(*)()) F830_6654;
	R5708[5] = (char *(*)()) F831_6654;
	R5708[6] = (char *(*)()) F832_6654;
	R5708[7] = (char *(*)()) F833_6654;
	{long i; for (i = 8; i < 10; i++) R5708[i] = (char *(*)()) F826_6654;}
	R5708[10] = (char *(*)()) F828_6654;
	R5708[11] = (char *(*)()) F829_6654;
	R5708[12] = (char *(*)()) F831_6654;
	R5708[13] = (char *(*)()) F832_6654;
}

char *(*R5712[14])();
void R5712_init () {
	R5712[0] = (char *(*)()) F826_6658;
	R5712[1] = (char *(*)()) F827_6658_5712_4;
	R5712[2] = (char *(*)()) F828_6658;
	R5712[3] = (char *(*)()) F829_6658;
	R5712[4] = (char *(*)()) F830_6658_5712_4;
	R5712[5] = (char *(*)()) F831_6658;
	R5712[6] = (char *(*)()) F832_6658;
	R5712[7] = (char *(*)()) F833_6658;
	{long i; for (i = 8; i < 10; i++) R5712[i] = (char *(*)()) F826_6658;}
	R5712[10] = (char *(*)()) F828_6658;
	R5712[11] = (char *(*)()) F829_6658;
	R5712[12] = (char *(*)()) F831_6658;
	R5712[13] = (char *(*)()) F832_6658;
}
static void F827_6658_5712_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F827_6658(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F830_6658_5712_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F830_6658(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5713[14])();
void R5713_init () {
	R5713[0] = (char *(*)()) F826_6659;
	R5713[1] = (char *(*)()) F827_6659_5713_4;
	R5713[2] = (char *(*)()) F828_6659;
	R5713[3] = (char *(*)()) F829_6659;
	R5713[4] = (char *(*)()) F830_6659_5713_4;
	R5713[5] = (char *(*)()) F831_6659;
	R5713[6] = (char *(*)()) F832_6659;
	R5713[7] = (char *(*)()) F833_6659;
	{long i; for (i = 8; i < 10; i++) R5713[i] = (char *(*)()) F826_6659;}
	R5713[10] = (char *(*)()) F828_6659;
	R5713[11] = (char *(*)()) F829_6659;
	R5713[12] = (char *(*)()) F831_6659;
	R5713[13] = (char *(*)()) F832_6659;
}
static void F827_6659_5713_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F827_6659(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F830_6659_5713_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F830_6659(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5718[14])();
void R5718_init () {
	R5718[0] = (char *(*)()) F826_6664;
	R5718[1] = (char *(*)()) F827_6664;
	R5718[2] = (char *(*)()) F828_6664;
	R5718[3] = (char *(*)()) F829_6664;
	R5718[4] = (char *(*)()) F830_6664;
	R5718[5] = (char *(*)()) F831_6664;
	R5718[6] = (char *(*)()) F832_6664;
	R5718[7] = (char *(*)()) F833_6664;
	{long i; for (i = 8; i < 10; i++) R5718[i] = (char *(*)()) F826_6664;}
	R5718[10] = (char *(*)()) F828_6664;
	R5718[11] = (char *(*)()) F829_6664;
	R5718[12] = (char *(*)()) F831_6664;
	R5718[13] = (char *(*)()) F832_6664;
}

char *(*R5731[14])();
void R5731_init () {
	R5731[0] = (char *(*)()) F826_6677;
	R5731[1] = (char *(*)()) F827_6677;
	R5731[2] = (char *(*)()) F828_6677;
	R5731[3] = (char *(*)()) F829_6677;
	R5731[4] = (char *(*)()) F830_6677;
	R5731[5] = (char *(*)()) F831_6677;
	R5731[6] = (char *(*)()) F832_6677;
	R5731[7] = (char *(*)()) F833_6677;
	{long i; for (i = 8; i < 10; i++) R5731[i] = (char *(*)()) F826_6677;}
	R5731[10] = (char *(*)()) F828_6677;
	R5731[11] = (char *(*)()) F829_6677;
	R5731[12] = (char *(*)()) F831_6677;
	R5731[13] = (char *(*)()) F832_6677;
}

char *(*R5744[5])();
void R5744_init () {
	R5744[0] = (char *(*)()) F835_6692;
	R5744[1] = (char *(*)()) F836_6692;
	R5744[2] = (char *(*)()) F837_6692;
	R5744[3] = (char *(*)()) F838_6692;
	R5744[4] = (char *(*)()) F839_6692;
}

char *(*R5766[12])();
void R5766_init () {
	R5766[0] = (char *(*)()) F853_6738;
	R5766[1] = (char *(*)()) F854_6738;
	R5766[2] = (char *(*)()) F855_6738;
	R5766[3] = (char *(*)()) F856_6738;
	R5766[4] = (char *(*)()) F857_6738;
	R5766[5] = (char *(*)()) F858_6738;
	R5766[6] = (char *(*)()) F859_6738;
	R5766[7] = (char *(*)()) F860_6738;
	R5766[8] = (char *(*)()) F861_6738;
	R5766[9] = (char *(*)()) F862_6738;
	R5766[10] = (char *(*)()) F863_6738;
	R5766[11] = (char *(*)()) F864_6738;
}

char *(*R5767[12])();
void R5767_init () {
	R5767[0] = (char *(*)()) F853_6739;
	R5767[1] = (char *(*)()) F854_6739_5767_25;
	R5767[2] = (char *(*)()) F855_6739_5767_25;
	R5767[3] = (char *(*)()) F856_6739_5767_25;
	R5767[4] = (char *(*)()) F857_6739_5767_25;
	R5767[5] = (char *(*)()) F858_6739_5767_25;
	R5767[6] = (char *(*)()) F859_6739_5767_25;
	R5767[7] = (char *(*)()) F860_6739_5767_25;
	R5767[8] = (char *(*)()) F861_6739_5767_25;
	R5767[9] = (char *(*)()) F862_6739_5767_25;
	R5767[10] = (char *(*)()) F863_6739_5767_25;
	R5767[11] = (char *(*)()) F864_6739_5767_25;
}
static void F854_6739_5767_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F854_6739(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F855_6739_5767_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F855_6739(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F856_6739_5767_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F856_6739(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F857_6739_5767_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F857_6739(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F858_6739_5767_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F858_6739(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F859_6739_5767_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F859_6739(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F860_6739_5767_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F860_6739(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F861_6739_5767_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F861_6739(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F862_6739_5767_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F862_6739(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F863_6739_5767_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F863_6739(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F864_6739_5767_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F864_6739(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R5770[12])();
void R5770_init () {
	R5770[0] = (char *(*)()) F853_6742;
	R5770[1] = (char *(*)()) F854_6742;
	R5770[2] = (char *(*)()) F855_6742;
	R5770[3] = (char *(*)()) F856_6742;
	R5770[4] = (char *(*)()) F857_6742;
	R5770[5] = (char *(*)()) F858_6742;
	R5770[6] = (char *(*)()) F859_6742;
	R5770[7] = (char *(*)()) F860_6742;
	R5770[8] = (char *(*)()) F861_6742;
	R5770[9] = (char *(*)()) F862_6742;
	R5770[10] = (char *(*)()) F863_6742;
	R5770[11] = (char *(*)()) F864_6742;
}

char *(*R5780[12])();
void R5780_init () {
	R5780[0] = (char *(*)()) F853_6768;
	R5780[1] = (char *(*)()) F854_6768;
	R5780[2] = (char *(*)()) F855_6768;
	R5780[3] = (char *(*)()) F856_6768;
	R5780[4] = (char *(*)()) F857_6768;
	R5780[5] = (char *(*)()) F858_6768;
	R5780[6] = (char *(*)()) F859_6768;
	R5780[7] = (char *(*)()) F860_6768;
	R5780[8] = (char *(*)()) F861_6768;
	R5780[9] = (char *(*)()) F862_6768;
	R5780[10] = (char *(*)()) F863_6768;
	R5780[11] = (char *(*)()) F864_6768;
}

char *(*R5794[12])();
void R5794_init () {
	R5794[0] = (char *(*)()) F853_6784;
	R5794[1] = (char *(*)()) F854_6784_5794_25;
	R5794[2] = (char *(*)()) F855_6784_5794_25;
	R5794[3] = (char *(*)()) F856_6784_5794_25;
	R5794[4] = (char *(*)()) F857_6784_5794_25;
	R5794[5] = (char *(*)()) F858_6784_5794_25;
	R5794[6] = (char *(*)()) F859_6784_5794_25;
	R5794[7] = (char *(*)()) F860_6784_5794_25;
	R5794[8] = (char *(*)()) F861_6784_5794_25;
	R5794[9] = (char *(*)()) F862_6784_5794_25;
	R5794[10] = (char *(*)()) F863_6784_5794_25;
	R5794[11] = (char *(*)()) F864_6784_5794_25;
}
static void F854_6784_5794_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F854_6784(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F855_6784_5794_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F855_6784(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F856_6784_5794_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F856_6784(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F857_6784_5794_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F857_6784(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F858_6784_5794_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F858_6784(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F859_6784_5794_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F859_6784(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F860_6784_5794_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F860_6784(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F861_6784_5794_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F861_6784(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F862_6784_5794_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F862_6784(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F863_6784_5794_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F863_6784(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F864_6784_5794_25 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F864_6784(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R5796[12])();
void R5796_init () {
	R5796[0] = (char *(*)()) F853_6787;
	R5796[1] = (char *(*)()) F854_6787;
	R5796[2] = (char *(*)()) F855_6787;
	R5796[3] = (char *(*)()) F856_6787;
	R5796[4] = (char *(*)()) F857_6787;
	R5796[5] = (char *(*)()) F858_6787;
	R5796[6] = (char *(*)()) F859_6787;
	R5796[7] = (char *(*)()) F860_6787;
	R5796[8] = (char *(*)()) F861_6787;
	R5796[9] = (char *(*)()) F862_6787;
	R5796[10] = (char *(*)()) F863_6787;
	R5796[11] = (char *(*)()) F864_6787;
}

char *(*R5801[12])();
void R5801_init () {
	R5801[0] = (char *(*)()) F853_6796;
	R5801[1] = (char *(*)()) F854_6796;
	R5801[2] = (char *(*)()) F855_6796;
	R5801[3] = (char *(*)()) F856_6796;
	R5801[4] = (char *(*)()) F857_6796;
	R5801[5] = (char *(*)()) F858_6796;
	R5801[6] = (char *(*)()) F859_6796;
	R5801[7] = (char *(*)()) F860_6796;
	R5801[8] = (char *(*)()) F861_6796;
	R5801[9] = (char *(*)()) F862_6796;
	R5801[10] = (char *(*)()) F863_6796;
	R5801[11] = (char *(*)()) F864_6796;
}

char *(*R5805[21])();
void R5805_init () {
	R5805[0] = (char *(*)()) F918_6851;
	R5805[1] = (char *(*)()) F919_6851_5805_1;
	R5805[2] = (char *(*)()) F918_6851;
	R5805[3] = (char *(*)()) F919_6851_5805_1;
	R5805[4] = (char *(*)()) F918_6851;
	R5805[5] = (char *(*)()) F923_6926;
	R5805[6] = (char *(*)()) F924_6926_5805_1;
	R5805[7] = (char *(*)()) F925_6926_5805_1;
	R5805[8] = (char *(*)()) F926_6926_5805_1;
	R5805[9] = (char *(*)()) F927_6926_5805_1;
	R5805[10] = (char *(*)()) F928_6926_5805_1;
	R5805[11] = (char *(*)()) F929_6926_5805_1;
	R5805[12] = (char *(*)()) F930_6926_5805_1;
	R5805[13] = (char *(*)()) F931_6926_5805_1;
	R5805[14] = (char *(*)()) F932_6926_5805_1;
	R5805[15] = (char *(*)()) F933_6926_5805_1;
	R5805[16] = (char *(*)()) F934_6926_5805_1;
	R5805[17] = (char *(*)()) F923_6926;
	R5805[18] = (char *(*)()) F925_6926_5805_1;
	{long i; for (i = 19; i < 21; i++) R5805[i] = (char *(*)()) F923_6926;}
}
static EIF_REFERENCE F919_6851_5805_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F919_6851(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F924_6926_5805_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F924_6926(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F925_6926_5805_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F925_6926(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F926_6926_5805_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F926_6926(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F927_6926_5805_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F927_6926(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F928_6926_5805_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F928_6926(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F929_6926_5805_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F929_6926(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F930_6926_5805_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F930_6926(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1184, 0x00).id, 1184, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F931_6926_5805_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F931_6926(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F932_6926_5805_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F932_6926(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F933_6926_5805_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F933_6926(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F934_6926_5805_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F934_6926(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5806[21])();
void R5806_init () {
	R5806[0] = (char *(*)()) F918_6852;
	R5806[1] = (char *(*)()) F919_6852_5806_1;
	R5806[2] = (char *(*)()) F918_6852;
	R5806[3] = (char *(*)()) F919_6852_5806_1;
	R5806[4] = (char *(*)()) F918_6852;
	R5806[5] = (char *(*)()) F923_6927;
	R5806[6] = (char *(*)()) F924_6927_5806_1;
	R5806[7] = (char *(*)()) F925_6927_5806_1;
	R5806[8] = (char *(*)()) F926_6927_5806_1;
	R5806[9] = (char *(*)()) F927_6927_5806_1;
	R5806[10] = (char *(*)()) F928_6927_5806_1;
	R5806[11] = (char *(*)()) F929_6927_5806_1;
	R5806[12] = (char *(*)()) F930_6927_5806_1;
	R5806[13] = (char *(*)()) F931_6927_5806_1;
	R5806[14] = (char *(*)()) F932_6927_5806_1;
	R5806[15] = (char *(*)()) F933_6927_5806_1;
	R5806[16] = (char *(*)()) F934_6927_5806_1;
	R5806[17] = (char *(*)()) F923_6927;
	R5806[18] = (char *(*)()) F925_6927_5806_1;
	{long i; for (i = 19; i < 21; i++) R5806[i] = (char *(*)()) F923_6927;}
}
static EIF_REFERENCE F919_6852_5806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F919_6852(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F924_6927_5806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F924_6927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F925_6927_5806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F925_6927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F926_6927_5806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F926_6927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1199, 0x00).id, 1199, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F927_6927_5806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F927_6927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1202, 0x00).id, 1202, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F928_6927_5806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F928_6927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1008, 0x00).id, 1008, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F929_6927_5806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F929_6927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F930_6927_5806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F930_6927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1184, 0x00).id, 1184, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F931_6927_5806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F931_6927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F932_6927_5806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F932_6927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F933_6927_5806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F933_6927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1041, 0x00).id, 1041, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F934_6927_5806_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F934_6927(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5807[5])();
void R5807_init () {
	R5807[0] = (char *(*)()) F918_6871;
	R5807[1] = (char *(*)()) F919_6871;
	R5807[2] = (char *(*)()) F918_6871;
	R5807[3] = (char *(*)()) F919_6871;
	R5807[4] = (char *(*)()) F918_6871;
}

char *(*R5808[21])();
void R5808_init () {
	R5808[0] = (char *(*)()) F918_6872;
	R5808[1] = (char *(*)()) F919_6872;
	R5808[2] = (char *(*)()) F918_6872;
	R5808[3] = (char *(*)()) F919_6872;
	R5808[4] = (char *(*)()) F918_6872;
	R5808[5] = (char *(*)()) F923_6953;
	R5808[6] = (char *(*)()) F924_6953;
	R5808[7] = (char *(*)()) F925_6953;
	R5808[8] = (char *(*)()) F926_6953;
	R5808[9] = (char *(*)()) F927_6953;
	R5808[10] = (char *(*)()) F928_6953;
	R5808[11] = (char *(*)()) F929_6953;
	R5808[12] = (char *(*)()) F930_6953;
	R5808[13] = (char *(*)()) F931_6953;
	R5808[14] = (char *(*)()) F932_6953;
	R5808[15] = (char *(*)()) F933_6953;
	R5808[16] = (char *(*)()) F934_6953;
	R5808[17] = (char *(*)()) F923_6953;
	R5808[18] = (char *(*)()) F925_6953;
	{long i; for (i = 19; i < 21; i++) R5808[i] = (char *(*)()) F923_6953;}
}

char *(*R5809[21])();
void R5809_init () {
	R5809[0] = (char *(*)()) F918_6862;
	R5809[1] = (char *(*)()) F919_6862;
	R5809[2] = (char *(*)()) F918_6862;
	R5809[3] = (char *(*)()) F919_6862;
	R5809[4] = (char *(*)()) F918_6862;
	R5809[5] = (char *(*)()) F870_6811;
	R5809[6] = (char *(*)()) F871_6811;
	R5809[7] = (char *(*)()) F872_6811;
	R5809[8] = (char *(*)()) F873_6811;
	R5809[9] = (char *(*)()) F874_6811;
	R5809[10] = (char *(*)()) F875_6811;
	R5809[11] = (char *(*)()) F876_6811;
	R5809[12] = (char *(*)()) F877_6811;
	R5809[13] = (char *(*)()) F878_6811;
	R5809[14] = (char *(*)()) F879_6811;
	R5809[15] = (char *(*)()) F880_6811;
	R5809[16] = (char *(*)()) F881_6811;
	R5809[17] = (char *(*)()) F870_6811;
	R5809[18] = (char *(*)()) F872_6811;
	{long i; for (i = 19; i < 21; i++) R5809[i] = (char *(*)()) F870_6811;}
}

char *(*R5810[21])();
void R5810_init () {
	R5810[0] = (char *(*)()) F918_6863;
	R5810[1] = (char *(*)()) F919_6863;
	R5810[2] = (char *(*)()) F918_6863;
	R5810[3] = (char *(*)()) F919_6863;
	R5810[4] = (char *(*)()) F918_6863;
	R5810[5] = (char *(*)()) F870_6812;
	R5810[6] = (char *(*)()) F871_6812;
	R5810[7] = (char *(*)()) F872_6812;
	R5810[8] = (char *(*)()) F873_6812;
	R5810[9] = (char *(*)()) F874_6812;
	R5810[10] = (char *(*)()) F875_6812;
	R5810[11] = (char *(*)()) F876_6812;
	R5810[12] = (char *(*)()) F877_6812;
	R5810[13] = (char *(*)()) F878_6812;
	R5810[14] = (char *(*)()) F879_6812;
	R5810[15] = (char *(*)()) F880_6812;
	R5810[16] = (char *(*)()) F881_6812;
	R5810[17] = (char *(*)()) F870_6812;
	R5810[18] = (char *(*)()) F872_6812;
	{long i; for (i = 19; i < 21; i++) R5810[i] = (char *(*)()) F870_6812;}
}

char *(*R5815[5])();
void R5815_init () {
	R5815[0] = (char *(*)()) F918_6874;
	R5815[1] = (char *(*)()) F919_6874_5815_4;
	R5815[2] = (char *(*)()) F918_6874;
	R5815[3] = (char *(*)()) F919_6874_5815_4;
	R5815[4] = (char *(*)()) F918_6874;
}
static void F919_6874_5815_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F919_6874(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5826[5])();
void R5826_init () {
	R5826[0] = (char *(*)()) F918_6887;
	R5826[1] = (char *(*)()) F919_6887_5826_5;
	R5826[2] = (char *(*)()) F918_6887;
	R5826[3] = (char *(*)()) F919_6887_5826_5;
	R5826[4] = (char *(*)()) F918_6887;
}
static EIF_REFERENCE F919_6887_5826_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F919_6887(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5827[5])();
void R5827_init () {
	R5827[0] = (char *(*)()) F918_6888;
	R5827[1] = (char *(*)()) F919_6888;
	R5827[2] = (char *(*)()) F918_6888;
	R5827[3] = (char *(*)()) F919_6888;
	R5827[4] = (char *(*)()) F918_6888;
}

char *(*R5830[5])();
void R5830_init () {
	R5830[0] = (char *(*)()) F918_6891;
	R5830[1] = (char *(*)()) F919_6891;
	R5830[2] = (char *(*)()) F918_6891;
	R5830[3] = (char *(*)()) F919_6891;
	R5830[4] = (char *(*)()) F918_6891;
}

char *(*R5831[5])();
void R5831_init () {
	R5831[0] = (char *(*)()) F918_6892;
	R5831[1] = (char *(*)()) F919_6892;
	R5831[2] = (char *(*)()) F918_6892;
	R5831[3] = (char *(*)()) F919_6892;
	R5831[4] = (char *(*)()) F918_6892;
}

char *(*R5832[5])();
void R5832_init () {
	R5832[0] = (char *(*)()) F918_6893;
	R5832[1] = (char *(*)()) F919_6893;
	R5832[2] = (char *(*)()) F918_6893;
	R5832[3] = (char *(*)()) F919_6893;
	R5832[4] = (char *(*)()) F918_6893;
}

char *(*R5837[2])();
void R5837_init () {
	R5837[0] = (char *(*)()) F918_6850;
	R5837[1] = (char *(*)()) F919_6850_5837_1;
}
static EIF_REFERENCE F919_6850_5837_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F919_6850(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5838[2])();
void R5838_init () {
	R5838[0] = (char *(*)()) F918_6881;
	R5838[1] = (char *(*)()) F919_6881;
}

char *(*R5842[16])();
void R5842_init () {
	R5842[0] = (char *(*)()) F923_6918;
	R5842[1] = (char *(*)()) F924_6918;
	R5842[2] = (char *(*)()) F925_6918;
	R5842[3] = (char *(*)()) F926_6918;
	R5842[4] = (char *(*)()) F927_6918;
	R5842[5] = (char *(*)()) F928_6918;
	R5842[6] = (char *(*)()) F929_6918;
	R5842[7] = (char *(*)()) F930_6918;
	R5842[8] = (char *(*)()) F931_6918;
	R5842[9] = (char *(*)()) F932_6918;
	R5842[10] = (char *(*)()) F933_6918;
	R5842[11] = (char *(*)()) F934_6918;
	R5842[12] = (char *(*)()) F923_6918;
	R5842[13] = (char *(*)()) F925_6918;
	R5842[14] = (char *(*)()) F937_6997;
	R5842[15] = (char *(*)()) F938_7006;
}

char *(*R5846[16])();
void R5846_init () {
	R5846[0] = (char *(*)()) F923_6922;
	R5846[1] = (char *(*)()) F924_6922;
	R5846[2] = (char *(*)()) F925_6922;
	R5846[3] = (char *(*)()) F926_6922;
	R5846[4] = (char *(*)()) F927_6922;
	R5846[5] = (char *(*)()) F928_6922;
	R5846[6] = (char *(*)()) F929_6922;
	R5846[7] = (char *(*)()) F930_6922;
	R5846[8] = (char *(*)()) F931_6922;
	R5846[9] = (char *(*)()) F932_6922;
	R5846[10] = (char *(*)()) F933_6922;
	R5846[11] = (char *(*)()) F934_6922;
	R5846[12] = (char *(*)()) F923_6922;
	R5846[13] = (char *(*)()) F925_6922;
	{long i; for (i = 14; i < 16; i++) R5846[i] = (char *(*)()) F923_6922;}
}

char *(*R5850[16])();
void R5850_init () {
	R5850[0] = (char *(*)()) F923_6941;
	R5850[1] = (char *(*)()) F924_6941;
	R5850[2] = (char *(*)()) F925_6941;
	R5850[3] = (char *(*)()) F926_6941;
	R5850[4] = (char *(*)()) F927_6941;
	R5850[5] = (char *(*)()) F928_6941;
	R5850[6] = (char *(*)()) F929_6941;
	R5850[7] = (char *(*)()) F930_6941;
	R5850[8] = (char *(*)()) F931_6941;
	R5850[9] = (char *(*)()) F932_6941;
	R5850[10] = (char *(*)()) F933_6941;
	R5850[11] = (char *(*)()) F934_6941;
	R5850[12] = (char *(*)()) F923_6941;
	R5850[13] = (char *(*)()) F925_6941;
	{long i; for (i = 14; i < 16; i++) R5850[i] = (char *(*)()) F923_6941;}
}

char *(*R5858[2])();
void R5858_init () {
	R5858[0] = (char *(*)()) F923_6959;
	R5858[1] = (char *(*)()) F925_6959_5858_4;
}
static void F925_6959_5858_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F925_6959(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5859[2])();
void R5859_init () {
	R5859[0] = (char *(*)()) F923_6972;
	R5859[1] = (char *(*)()) F925_6972;
}

char *(*R5871[365])();
void R5871_init () {
	R5871[0] = (char *(*)()) F946_7038;
	R5871[364] = (char *(*)()) F1310_13055;
}

char *(*R5891[365])();
void R5891_init () {
	R5891[0] = (char *(*)()) F946_7035;
	R5891[364] = (char *(*)()) F1310_13096;
}

char *(*R6032[2])();
void R6032_init () {
	R6032[0] = (char *(*)()) F955_7196;
	R6032[1] = (char *(*)()) F956_7301;
}

char *(*R6038[2])();
void R6038_init () {
	R6038[0] = (char *(*)()) F955_7202;
	R6038[1] = (char *(*)()) F956_7302;
}

char *(*R6040[2])();
void R6040_init () {
	R6040[0] = (char *(*)()) F955_7204;
	R6040[1] = (char *(*)()) F956_7303;
}

char *(*R6133[2])();
void R6133_init () {
	R6133[0] = (char *(*)()) F955_7299;
	R6133[1] = (char *(*)()) F956_7328;
}

char *(*R6342[307])();
void R6342_init () {
	R6342[0] = (char *(*)()) F969_7513;
	R6342[306] = (char *(*)()) F1273_12029;
}

char *(*R6361[287])();
void R6361_init () {
	R6361[0] = (char *(*)()) F978_7563;
	R6361[5] = (char *(*)()) F983_7575;
	R6361[6] = (char *(*)()) F984_7577;
	R6361[7] = (char *(*)()) F985_7579;
	R6361[8] = (char *(*)()) F986_7585;
	R6361[9] = (char *(*)()) F987_7591;
	R6361[10] = (char *(*)()) F988_7595;
	R6361[11] = (char *(*)()) F989_7600;
	R6361[12] = (char *(*)()) F990_7609;
	R6361[13] = (char *(*)()) F991_7618;
	{long i; for (i = 14; i < 17; i++) R6361[i] = (char *(*)()) F990_7609;}
	R6361[17] = (char *(*)()) F995_7625;
	R6361[18] = (char *(*)()) F996_7628;
	R6361[19] = (char *(*)()) F990_7609;
	R6361[286] = (char *(*)()) F1264_11895;
}

char *(*R6423[311])();
void R6423_init () {
	R6423[0] = (char *(*)()) F1000_7672;
	{long i; for (i = 2; i < 4; i++) R6423[i] = (char *(*)()) F1001_7781;}
	{long i; for (i = 5; i < 7; i++) R6423[i] = (char *(*)()) F1004_7829;}
	{long i; for (i = 8; i < 10; i++) R6423[i] = (char *(*)()) F1007_7851;}
	{long i; for (i = 11; i < 41; i++) R6423[i] = (char *(*)()) F1010_7890;}
	R6423[41] = (char *(*)()) F1041_7916;
	R6423[42] = (char *(*)()) F1042_7916;
	{long i; for (i = 44; i < 49; i++) R6423[i] = (char *(*)()) F1043_7924;}
	{long i; for (i = 53; i < 55; i++) R6423[i] = (char *(*)()) F1049_7983;}
	{long i; for (i = 57; i < 59; i++) R6423[i] = (char *(*)()) F1049_7983;}
	R6423[70] = (char *(*)()) F1070_8705;
	R6423[71] = (char *(*)()) F1071_8746;
	R6423[72] = (char *(*)()) F1072_8888;
	R6423[73] = (char *(*)()) F1073_8935;
	R6423[74] = (char *(*)()) F1074_8977;
	R6423[75] = (char *(*)()) F1075_8977;
	R6423[76] = (char *(*)()) F1076_8977;
	R6423[77] = (char *(*)()) F1077_8977;
	R6423[78] = (char *(*)()) F1078_8977;
	R6423[79] = (char *(*)()) F1079_8977;
	R6423[80] = (char *(*)()) F1080_8977;
	R6423[81] = (char *(*)()) F1081_8977;
	R6423[82] = (char *(*)()) F1082_8977;
	R6423[83] = (char *(*)()) F1083_8977;
	R6423[84] = (char *(*)()) F1084_8977;
	R6423[85] = (char *(*)()) F1085_8977;
	R6423[86] = (char *(*)()) F1086_8977;
	R6423[87] = (char *(*)()) F1087_8977;
	R6423[88] = (char *(*)()) F1088_8977;
	R6423[89] = (char *(*)()) F1089_8977;
	R6423[90] = (char *(*)()) F1090_8977;
	R6423[91] = (char *(*)()) F1091_8977;
	R6423[92] = (char *(*)()) F1092_8977;
	R6423[93] = (char *(*)()) F1093_8977;
	R6423[94] = (char *(*)()) F1094_8977;
	R6423[95] = (char *(*)()) F1095_8977;
	R6423[96] = (char *(*)()) F1096_8977;
	R6423[97] = (char *(*)()) F1097_8977;
	R6423[98] = (char *(*)()) F1098_8977;
	R6423[99] = (char *(*)()) F1099_8977;
	R6423[100] = (char *(*)()) F1100_8977;
	R6423[101] = (char *(*)()) F1101_8977;
	R6423[102] = (char *(*)()) F1102_8977;
	R6423[103] = (char *(*)()) F1103_8977;
	R6423[104] = (char *(*)()) F1104_8977;
	R6423[105] = (char *(*)()) F1105_8977;
	R6423[106] = (char *(*)()) F1106_8977;
	R6423[107] = (char *(*)()) F1107_8977;
	{long i; for (i = 124; i < 127; i++) R6423[i] = (char *(*)()) F1121_9078;}
	{long i; for (i = 128; i < 131; i++) R6423[i] = (char *(*)()) F1121_9078;}
	R6423[178] = (char *(*)()) F1178_9322;
	R6423[179] = (char *(*)()) F1179_9327;
	R6423[180] = (char *(*)()) F1180_9341;
	R6423[181] = (char *(*)()) F1181_9382;
	{long i; for (i = 184; i < 186; i++) R6423[i] = (char *(*)()) F1183_9399;}
	{long i; for (i = 187; i < 189; i++) R6423[i] = (char *(*)()) F1186_9493;}
	{long i; for (i = 190; i < 192; i++) R6423[i] = (char *(*)()) F1189_9591;}
	{long i; for (i = 193; i < 195; i++) R6423[i] = (char *(*)()) F1192_9690;}
	{long i; for (i = 196; i < 198; i++) R6423[i] = (char *(*)()) F1195_9789;}
	{long i; for (i = 199; i < 201; i++) R6423[i] = (char *(*)()) F1198_9888;}
	{long i; for (i = 202; i < 204; i++) R6423[i] = (char *(*)()) F1201_9982;}
	{long i; for (i = 205; i < 207; i++) R6423[i] = (char *(*)()) F1204_10077;}
	{long i; for (i = 208; i < 210; i++) R6423[i] = (char *(*)()) F1207_10172;}
	{long i; for (i = 211; i < 213; i++) R6423[i] = (char *(*)()) F1210_10238;}
	R6423[213] = (char *(*)()) F1213_10320;
	R6423[214] = (char *(*)()) F1214_10358;
	R6423[220] = (char *(*)()) F1220_10366;
	R6423[221] = (char *(*)()) F1221_10375;
	R6423[310] = (char *(*)()) F1310_13023;
}

char *(*R6617[2])();
void R6617_init () {
	R6617[0] = (char *(*)()) F1008_7887;
	R6617[1] = (char *(*)()) F1009_7887;
}

char *(*R6685[5])();
void R6685_init () {
	R6685[0] = (char *(*)()) F1044_7961;
	R6685[1] = (char *(*)()) F1045_7964;
	R6685[2] = (char *(*)()) F1046_7964;
	R6685[3] = (char *(*)()) F1047_7964;
	R6685[4] = (char *(*)()) F1046_7964;
}

char *(*R6709[4])();
void R6709_init () {
	R6709[0] = (char *(*)()) F1045_7963;
	R6709[1] = (char *(*)()) F1046_7963_6709_1;
	R6709[2] = (char *(*)()) F1047_7963_6709_1;
	R6709[3] = (char *(*)()) F1046_7963_6709_1;
}
static EIF_REFERENCE F1046_7963_6709_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1046_7963(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1047_7963_6709_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1047_7963(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6710[4])();
void R6710_init () {
	R6710[0] = (char *(*)()) F1045_7965;
	R6710[1] = (char *(*)()) F1046_7965_6710_5;
	R6710[2] = (char *(*)()) F1047_7965_6710_5;
	R6710[3] = (char *(*)()) F1046_7965_6710_5;
}
static EIF_REFERENCE F1046_7965_6710_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1046_7965(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1047_7965_6710_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1047_7965(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6714[4])();
void R6714_init () {
	R6714[0] = (char *(*)()) F1045_7972;
	R6714[1] = (char *(*)()) F1046_7972_6714_386;
	R6714[2] = (char *(*)()) F1047_7972_6714_386;
	R6714[3] = (char *(*)()) F1046_7972_6714_386;
}
static EIF_REFERENCE F1046_7972_6714_386 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1046_7972(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1047_7972_6714_386 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1047_7972(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1190, 0x00).id, 1190, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y6715_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6715_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6715_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6715_pgtype3[] = {1005,0xFFFF};
EIF_TYPE_INDEX *Y6715_gen_type [4];
EIF_TYPE_INDEX Y6715 [4];
void Y6715_init (void)
{
	egc_routines_types [6715] = Y6715;
	egc_routines_gen_types [6715] = Y6715_gen_type;
	egc_routines_offset [6715] = 1044;
	Y6715_gen_type [0] = Y6715_pgtype0;
	Y6715_gen_type [1] = Y6715_pgtype1;
	Y6715_gen_type [2] = Y6715_pgtype2;
	Y6715_gen_type [3] = Y6715_pgtype3;
	Y6715[3] = 1005;
}

char *(*R6716[258])();
void R6716_init () {
	{long i; for (i = 0; i < 2; i++) R6716[i] = (char *(*)()) F1052_8104;}
	{long i; for (i = 4; i < 6; i++) R6716[i] = (char *(*)()) F1056_8270;}
	R6716[257] = (char *(*)()) F1310_12997;
}

char *(*R6718[258])();
void R6718_init () {
	R6718[0] = (char *(*)()) F1053_8164;
	R6718[1] = (char *(*)()) F1054_8186;
	R6718[4] = (char *(*)()) F1057_8331;
	R6718[5] = (char *(*)()) F1058_8354;
	R6718[257] = (char *(*)()) F1310_13125;
}

char *(*R6719[258])();
void R6719_init () {
	R6719[0] = (char *(*)()) F1053_8163;
	R6719[1] = (char *(*)()) F1054_8185;
	R6719[4] = (char *(*)()) F1057_8329;
	R6719[5] = (char *(*)()) F1058_8352;
	R6719[257] = (char *(*)()) F1054_8185;
}

char *(*R6720[258])();
void R6720_init () {
	{long i; for (i = 0; i < 2; i++) R6720[i] = (char *(*)()) F1049_7977;}
	{long i; for (i = 4; i < 6; i++) R6720[i] = (char *(*)()) F1056_8282;}
	R6720[257] = (char *(*)()) F1049_7977;
}

char *(*R6730[258])();
void R6730_init () {
	{long i; for (i = 0; i < 2; i++) R6730[i] = (char *(*)()) F1052_8135;}
	{long i; for (i = 4; i < 6; i++) R6730[i] = (char *(*)()) F1056_8300;}
	R6730[257] = (char *(*)()) F1052_8135;
}

char *(*R6732[258])();
void R6732_init () {
	{long i; for (i = 0; i < 2; i++) R6732[i] = (char *(*)()) F1052_8137;}
	{long i; for (i = 4; i < 6; i++) R6732[i] = (char *(*)()) F1056_8302;}
	R6732[257] = (char *(*)()) F1052_8137;
}

char *(*R6733[258])();
void R6733_init () {
	R6733[0] = (char *(*)()) F1053_8173;
	R6733[1] = (char *(*)()) F744_6139;
	R6733[4] = (char *(*)()) F1057_8341;
	R6733[5] = (char *(*)()) F741_6139;
	R6733[257] = (char *(*)()) F744_6139;
}

char *(*R6735[258])();
void R6735_init () {
	{long i; for (i = 0; i < 2; i++) R6735[i] = (char *(*)()) F1052_8138;}
	{long i; for (i = 4; i < 6; i++) R6735[i] = (char *(*)()) F1056_8303;}
	R6735[257] = (char *(*)()) F1052_8138;
}

char *(*R6736[258])();
void R6736_init () {
	{long i; for (i = 0; i < 2; i++) R6736[i] = (char *(*)()) F1049_7994;}
	{long i; for (i = 4; i < 6; i++) R6736[i] = (char *(*)()) F1056_8304;}
	R6736[257] = (char *(*)()) F1049_7994;
}

char *(*R6755[258])();
void R6755_init () {
	{long i; for (i = 0; i < 2; i++) R6755[i] = (char *(*)()) F1052_8126;}
	{long i; for (i = 4; i < 6; i++) R6755[i] = (char *(*)()) F1056_8291;}
	R6755[257] = (char *(*)()) F1310_13028;
}

char *(*R6756[258])();
void R6756_init () {
	{long i; for (i = 0; i < 2; i++) R6756[i] = (char *(*)()) F1052_8125;}
	{long i; for (i = 4; i < 6; i++) R6756[i] = (char *(*)()) F1056_8290;}
	R6756[257] = (char *(*)()) F1310_13030;
}

char *(*R6760[258])();
void R6760_init () {
	{long i; for (i = 0; i < 2; i++) R6760[i] = (char *(*)()) F1049_8018;}
	{long i; for (i = 4; i < 6; i++) R6760[i] = (char *(*)()) F1049_8018;}
	R6760[257] = (char *(*)()) F1310_13035;
}

char *(*R6761[258])();
void R6761_init () {
	{long i; for (i = 0; i < 2; i++) R6761[i] = (char *(*)()) F1049_8019;}
	{long i; for (i = 4; i < 6; i++) R6761[i] = (char *(*)()) F1049_8019;}
	R6761[257] = (char *(*)()) F1310_13041;
}

char *(*R6766[258])();
void R6766_init () {
	{long i; for (i = 0; i < 2; i++) R6766[i] = (char *(*)()) F1052_8122;}
	{long i; for (i = 4; i < 6; i++) R6766[i] = (char *(*)()) F1056_8287;}
	R6766[257] = (char *(*)()) F1310_13016;
}

char *(*R6777[258])();
void R6777_init () {
	R6777[0] = (char *(*)()) F1053_8169;
	R6777[1] = (char *(*)()) F1054_8252;
	R6777[4] = (char *(*)()) F1057_8336;
	R6777[5] = (char *(*)()) F1058_8420;
	R6777[257] = (char *(*)()) F1310_13085;
}

char *(*R6778[258])();
void R6778_init () {
	R6778[0] = (char *(*)()) F1053_8170;
	R6778[1] = (char *(*)()) F1054_8253;
	R6778[4] = (char *(*)()) F1057_8337;
	R6778[5] = (char *(*)()) F1058_8421;
	R6778[257] = (char *(*)()) F1310_13086;
}

char *(*R6796[258])();
void R6796_init () {
	R6796[0] = (char *(*)()) F1053_8171;
	R6796[1] = (char *(*)()) F1054_8264;
	R6796[4] = (char *(*)()) F1057_8338;
	R6796[5] = (char *(*)()) F1058_8432;
	R6796[257] = (char *(*)()) F1310_13014;
}

char *(*R6800[258])();
void R6800_init () {
	R6800[0] = (char *(*)()) F1053_8175;
	R6800[1] = (char *(*)()) F1054_8268;
	R6800[4] = (char *(*)()) F1057_8342;
	R6800[5] = (char *(*)()) F1058_8435;
	R6800[257] = (char *(*)()) F1054_8268;
}

char *(*R6811[257])();
void R6811_init () {
	R6811[0] = (char *(*)()) F1054_8266;
	R6811[4] = (char *(*)()) F1058_8434;
	R6811[256] = (char *(*)()) F1054_8266;
}


#ifdef __cplusplus
}
#endif
