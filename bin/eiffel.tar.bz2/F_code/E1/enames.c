

#ifdef __cplusplus
extern "C" {
#endif

char *names5 [] =
{
"callbacks",
"buffer",
"error_occurred",
"end_of_input",
"buffer_index",
};

char *names11 [] =
{
"locale",
"language",
};

char *names16 [] =
{
"path",
"installation_path",
"repository_location",
"package",
};

char *names19 [] =
{
"layout",
};

char *names23 [] =
{
"escape_character",
};

char *names24 [] =
{
"long_date_format",
"long_time_format",
"date_time_format",
};

char *names25 [] =
{
"currency_symbol",
"currency_value_formatter",
"currency_symbol_location",
};

char *names29 [] =
{
"set",
};

char *names30 [] =
{
"lower_table",
"flip_table",
};

char *names31 [] =
{
"byte_code",
"character_sets",
"count",
"capacity",
"character_sets_count",
"character_sets_capacity",
};

char *names33 [] =
{
"info",
"date_formatter",
"value_formatter",
"currency_formatter",
"string_formatter",
"dictionary",
};

char *names34 [] =
{
"cache",
"converted_pair",
};

char *names35 [] =
{
"mapping",
"location",
"action",
"parameters",
};

char *names41 [] =
{
"version",
};

char *names42 [] =
{
"internal_item",
"is_utc",
"microseconds_now",
};

char *names43 [] =
{
"mappings",
};

char *names45 [] =
{
"context",
};

char *names49 [] =
{
"flags",
};

char *names50 [] =
{
"inverted",
"match_kind",
};

char *names51 [] =
{
"code_page",
"encoding_i",
};

char *names52 [] =
{
"level",
};

char *names55 [] =
{
"redirections",
};

char *names58 [] =
{
"cluster_name",
"class_type_name",
"feature_name",
"is_all_root",
};

char *names60 [] =
{
"flatten_when_closing",
"keep_calls_records",
"recording_values",
"maximum_record_count",
};

char *names74 [] =
{
"default_output",
};

char *names77 [] =
{
"items",
"tmp_file",
};

char *names83 [] =
{
"d",
"e",
"t",
};

char *names84 [] =
{
"internal_assemblies",
"is_dirty",
};

char *names85 [] =
{
"eiffel_names",
"dotnet_names",
"flags",
"positions",
"count",
"index",
};

char *names86 [] =
{
"assemblies",
};

char *names96 [] =
{
"next",
"file",
"handled",
};

char *names97 [] =
{
"next",
"file",
"handled",
};

char *names99 [] =
{
"representation",
"index",
};

char *names108 [] =
{
"byte_count",
};

char *names109 [] =
{
"buffer",
"schedule",
"a",
"b",
"c",
"d",
"e",
"h1",
"h2",
"h3",
"h4",
"h5",
"buffer_offset",
"byte_count",
};

char *names113 [] =
{
"item",
};

char *names114 [] =
{
"item",
};

char *names115 [] =
{
"item",
"right",
};

char *names116 [] =
{
"right",
"item",
};

char *names120 [] =
{
"ansi_code_page",
"oem_code_page",
"mac_code_page",
};

char *names121 [] =
{
"date_time_format",
"long_date_format",
"short_date_format",
"long_time_format",
"short_time_format",
"am_suffix",
"pm_suffix",
"time_separator",
"date_separator",
"day_names",
"month_names",
"abbreviated_day_names",
"abbreviated_month_names",
};

char *names122 [] =
{
"value_decimal_separator",
"value_group_separator",
"value_number_list_separator",
"value_positive_sign",
"value_negative_sign",
"value_grouping",
"value_numbers_after_decimal_separator",
};

char *names123 [] =
{
"currency_symbol",
"currency_decimal_separator",
"currency_group_separator",
"currency_number_list_separator",
"currency_positive_sign",
"currency_negative_sign",
"currency_grouping",
"currency_international_symbol",
"currency_international_decimal_separator",
"currency_international_group_separator",
"currency_international_number_list_separator",
"currency_international_grouping",
"currency_symbol_location",
"currency_numbers_after_decimal_separator",
"currency_international_symbol_location",
"currency_international_numbers_after_decimal_separator",
};

char *names124 [] =
{
"ansi_code_page",
"oem_code_page",
"mac_code_page",
"date_time_format",
"long_date_format",
"short_date_format",
"long_time_format",
"short_time_format",
"am_suffix",
"pm_suffix",
"time_separator",
"date_separator",
"day_names",
"month_names",
"abbreviated_day_names",
"abbreviated_month_names",
"value_decimal_separator",
"value_group_separator",
"value_number_list_separator",
"value_positive_sign",
"value_negative_sign",
"value_grouping",
"currency_symbol",
"currency_decimal_separator",
"currency_group_separator",
"currency_number_list_separator",
"currency_positive_sign",
"currency_negative_sign",
"currency_grouping",
"currency_international_symbol",
"currency_international_decimal_separator",
"currency_international_group_separator",
"currency_international_number_list_separator",
"currency_international_grouping",
"id",
"value_numbers_after_decimal_separator",
"currency_symbol_location",
"currency_numbers_after_decimal_separator",
"currency_international_symbol_location",
"currency_international_numbers_after_decimal_separator",
};

char *names136 [] =
{
"uri",
};

char *names137 [] =
{
"uri",
"locale_file_list",
"locale_list",
"language_file_list",
"language_list",
"directory",
"chain",
};

char *names138 [] =
{
"decimal_separator",
"group_separator",
"positive_sign",
"negative_sign",
"grouping",
"numbers_after_decimal_separator",
};

char *names139 [] =
{
"decimal_separator",
"group_separator",
"positive_sign",
"negative_sign",
"grouping",
"numbers_after_decimal_separator",
};

char *names141 [] =
{
"pattern",
"text",
"found",
"index",
};

char *names142 [] =
{
"pattern",
"text",
"matching_indices",
"table",
"found",
"is_not_case_sensitive",
"index",
};

char *names143 [] =
{
"pattern",
"text",
"matching_indices",
"table",
"string_list",
"lengths",
"found",
"is_not_case_sensitive",
"character_representation",
"string_representation",
"index",
"found_at",
"found_pattern_length",
};

char *names148 [] =
{
"list",
"depth",
};

char *names149 [] =
{
"items",
"max_depth",
"depth",
};

char *names150 [] =
{
"items",
"max_depth",
"depth",
};

char *names151 [] =
{
"items",
"depth",
};

char *names152 [] =
{
"root_object",
"on_processing_object_action",
"on_processing_reference_action",
"object_action",
"visited_objects",
"visited_types",
"has_failed",
"has_reference_with_copy_semantics",
"is_skip_transient",
"is_skip_copy_semantics_reference",
"is_exception_on_copy_suppressed",
"is_exception_propagated",
};

char *names153 [] =
{
"root_object",
"on_processing_object_action",
"on_processing_reference_action",
"object_action",
"visited_objects",
"visited_types",
"has_failed",
"has_reference_with_copy_semantics",
"is_skip_transient",
"is_skip_copy_semantics_reference",
"is_exception_on_copy_suppressed",
"is_exception_propagated",
};

char *names156 [] =
{
"iron_layout",
"iron_urls",
"internal_iron_api",
};

char *names158 [] =
{
"is_set",
};

char *names159 [] =
{
"comparator",
};

char *names160 [] =
{
"comparator",
};

char *names161 [] =
{
"subject",
"subject_start",
"subject_end",
"match_count",
};

char *names178 [] =
{
"item",
};

char *names179 [] =
{
"item",
};

char *names180 [] =
{
"item",
};

char *names181 [] =
{
"item",
};

char *names182 [] =
{
"item",
};

char *names183 [] =
{
"item",
"right",
};

char *names184 [] =
{
"right",
"item",
};

char *names186 [] =
{
"unique_id",
"folder_name",
"name",
"version",
"culture",
"key",
"location",
"gac_path",
"is_consumed",
"is_in_gac",
"has_info_only",
};

char *names187 [] =
{
"n",
"i",
};

char *names188 [] =
{
"n",
"e",
"i",
};

char *names189 [] =
{
"dotnet_name",
"parent",
"eiffel_name",
"constructors",
"fields",
"interfaces",
"properties",
"events",
"internal_procedures",
"internal_functions",
"internal_associated_reference_type",
"internal_flags",
};

char *names190 [] =
{
"dotnet_name",
"parent",
"eiffel_name",
"constructors",
"fields",
"interfaces",
"properties",
"events",
"internal_procedures",
"internal_functions",
"internal_associated_reference_type",
"enclosing_type",
"internal_flags",
};

char *names195 [] =
{
"compact_time",
"fractional_second",
};

char *names198 [] =
{
"time",
"date",
};

char *names203 [] =
{
"path",
"repositories",
};

char *names205 [] =
{
"path",
"projects",
"setup_operations",
"has_error",
"is_assistant_enabled",
};

char *names206 [] =
{
"path",
"projects",
"setup_operations",
"ini",
"has_error",
"is_assistant_enabled",
};

char *names207 [] =
{
"path",
"projects",
"setup_operations",
"notes",
"package_name",
"has_error",
"is_assistant_enabled",
};

char *names214 [] =
{
"file",
"opened",
"plural_form",
"entry_count",
};

char *names215 [] =
{
"file",
"last_original",
"last_translated",
"opened",
"is_big_endian_file",
"is_little_endian_file",
"is_big_endian_machine",
"is_little_endian_machine",
"plural_form",
"entry_count",
"version",
"original_table_offset",
"translated_table_offset",
"hash_table_size",
"hash_table_offset",
};

char *names216 [] =
{
"reduction_agent",
"plural_form",
"nplural_max",
};

char *names217 [] =
{
"reduction_agent",
"array",
"plural_form",
"nplural_max",
"current_index",
};

char *names218 [] =
{
"reduction_agent",
"plural_form",
"nplural_max",
};

char *names219 [] =
{
"managed_pointer",
"shared",
"internal_item",
};

char *names226 [] =
{
"current_parsed_string",
"current_character",
"current_position_in_input",
"current_token",
};

char *names229 [] =
{
"comparator",
};

char *names237 [] =
{
"is_case_insensitive",
};

char *names240 [] =
{
"is_case_insensitive",
};

char *names247 [] =
{
"deltas",
"deltas_array",
};

char *names248 [] =
{
"deltas",
"deltas_array",
};

char *names249 [] =
{
"deltas",
"deltas_array",
};

char *names251 [] =
{
"name",
"associated_error",
};

char *names252 [] =
{
"name",
"location",
"associated_error",
"is_readonly",
};

char *names254 [] =
{
"observers",
};

char *names257 [] =
{
"integer_overflow_state1",
"integer_overflow_state2",
"natural_overflow_state1",
"natural_overflow_state2",
};

char *names258 [] =
{
"leading_separators",
"trailing_separators",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"conversion_type",
"last_state",
"sign",
};

char *names259 [] =
{
"leading_separators",
"trailing_separators",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"internal_overflowed",
"conversion_type",
"last_state",
"sign",
"part1",
"part2",
};

char *names260 [] =
{
"leading_separators",
"trailing_separators",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"is_negative",
"has_negative_exponent",
"has_fractional_part",
"needs_digit",
"conversion_type",
"last_state",
"sign",
"exponent",
"natural_part",
"fractional_part",
"fractional_divider",
};

char *names261 [] =
{
"leading_separators",
"trailing_separators",
"internal_lookahead",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"internal_overflowed",
"conversion_type",
"last_state",
"sign",
"part1",
"part2",
};

char *names265 [] =
{
"version",
};

char *names266 [] =
{
"error_message",
"is_verbose",
"is_help",
"has_error",
};

char *names267 [] =
{
"error_message",
"ecf_location",
"ecf_target",
"args",
"is_verbose",
"is_help",
"has_error",
"is_build_forced",
"check_level",
};

char *names268 [] =
{
"error_message",
"ecf_location",
"ecf_target",
"executable_path",
"resources",
"is_verbose",
"is_help",
"has_error",
};

char *names271 [] =
{
"content",
"beginning_of_line",
"filled",
"interactive",
"count",
"capacity",
"position",
"line",
"column",
"index",
};

char *names272 [] =
{
"content",
"beginning_of_line",
"filled",
"interactive",
"count",
"capacity",
"position",
"line",
"column",
"index",
};

char *names273 [] =
{
"content",
"beginning_of_line",
"filled",
"interactive",
"count",
"capacity",
"position",
"line",
"column",
"index",
};

char *names274 [] =
{
"content",
"file",
"beginning_of_line",
"filled",
"interactive",
"end_of_file",
"count",
"capacity",
"position",
"line",
"column",
"index",
};

char *names275 [] =
{
"content",
"file",
"beginning_of_line",
"filled",
"interactive",
"end_of_file",
"has_utf8_bom",
"count",
"capacity",
"position",
"line",
"column",
"index",
"default_encoding",
"encoding",
};

char *names276 [] =
{
"content",
"file",
"beginning_of_line",
"filled",
"interactive",
"end_of_file",
"count",
"capacity",
"position",
"line",
"column",
"index",
"default_encoding",
"encoding",
};

char *names278 [] =
{
"associated_parser",
};

char *names279 [] =
{
"associated_parser",
};

char *names281 [] =
{
"associated_parser",
"callbacks",
};

char *names283 [] =
{
"callbacks",
"warning_message",
"buffer",
"error_position",
"error_message",
"parsing_stopped",
"end_of_input",
"truncation_reported",
"last_character",
"rewinded_character",
};

char *names284 [] =
{
"callbacks",
"warning_message",
"buffer",
"error_position",
"error_message",
"parsing_stopped",
"end_of_input",
"truncation_reported",
"error_ignored",
"stop_requested",
"last_character",
"rewinded_character",
"checkpoint_position_line",
"checkpoint_position_column",
"checkpoint_position_byte_index",
};

char *names285 [] =
{
"associated_parser",
"next",
};

char *names286 [] =
{
"associated_parser",
"next",
"prefixes",
"local_parts",
};

char *names287 [] =
{
"associated_parser",
"next",
"context",
"element_prefix",
"element_local_part",
"attributes_prefix",
"attributes_local_part",
"attributes_value",
"forward_xmlns",
};

char *names289 [] =
{
"source",
"end_of_input",
"last_character",
"count",
"source_index",
"column",
"line",
};

char *names290 [] =
{
"source",
};

char *names291 [] =
{
"source",
"last_character_code",
};

char *names295 [] =
{
"note_node",
};

char *names297 [] =
{
"position",
};

char *names298 [] =
{
"index",
};

char *names299 [] =
{
"active",
"after",
"before",
};

char *names300 [] =
{
"active",
"after",
"before",
};

char *names303 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names304 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names305 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names306 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names307 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names308 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"exception_information",
"internal_is_ignorable",
"line_number",
"hresult",
"hresult_code",
};

char *names309 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"error_code",
};

char *names310 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"signal_code",
};

char *names311 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names312 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names313 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names314 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names315 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names316 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names317 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names318 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names319 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names320 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"internal_code",
};

char *names321 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names322 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names323 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"internal_code",
};

char *names324 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names325 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names326 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names327 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names328 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"error_code",
"internal_code",
};

char *names329 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names330 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names331 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names332 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"routine_name",
"class_name",
"internal_is_ignorable",
"line_number",
};

char *names333 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names334 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names335 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names336 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names337 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names338 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names339 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names340 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names341 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names342 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names343 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"is_entry",
"line_number",
};

char *names345 [] =
{
"date_action",
};

char *names346 [] =
{
"user_string",
};

char *names347 [] =
{
"time_action",
};

char *names348 [] =
{
"elements_list",
};

char *names352 [] =
{
"start_bound",
"end_bound",
};

char *names354 [] =
{
"origin_date_time",
"time",
"date",
};

char *names355 [] =
{
"minute",
"hour",
"fine_second",
};

char *names356 [] =
{
"origin_date",
"year",
"month",
"day",
};

char *names358 [] =
{
"original_singular",
"original_plural",
"singular_translation",
"plural_translations",
"context",
"cached_identifier",
};

char *names361 [] =
{
"n",
"e",
"d",
};

char *names362 [] =
{
"n",
"e",
"d",
"g",
"s",
"p",
"t",
};

char *names363 [] =
{
"n",
"e",
"d",
"a",
"p",
};

char *names364 [] =
{
"n",
"e",
"d",
"a",
"r",
"i",
"p",
};

char *names365 [] =
{
"n",
"e",
"d",
"f",
};

char *names366 [] =
{
"n",
"e",
"d",
"a",
"q",
"f",
};

char *names367 [] =
{
"n",
"e",
"d",
"a",
"q",
"r",
"f",
};

char *names368 [] =
{
"n",
"e",
"d",
"r",
"s",
"f",
};

char *names369 [] =
{
"n",
"e",
"d",
"r",
"s",
"v",
"f",
};

char *names372 [] =
{
"dynamic_type",
};

char *names376 [] =
{
"referring_object",
"dynamic_type",
"physical_offset",
"referring_physical_offset",
};

char *names377 [] =
{
"enclosing_object",
"dynamic_type",
"physical_offset",
};

char *names380 [] =
{
"namespace",
};

char *names381 [] =
{
"associated_parser",
"current_namespace",
"last_error",
"last_warning",
"is_error",
"is_warning",
"is_invalid_xml",
};

char *names382 [] =
{
"associated_parser",
"current_namespace",
"last_error",
"last_warning",
"file_name",
"last_uuid",
"last_redirected_location",
"is_error",
"is_warning",
"is_invalid_xml",
"is_system",
"is_redirection",
};

char *names385 [] =
{
"version",
"custom_variables",
"is_dotnet",
"is_dynamic_runtime",
"platform",
"build",
"concurrency",
"void_safety",
};

char *names386 [] =
{
"internal_options",
"forced_options",
"internal_settings",
};

char *names387 [] =
{
"internal_conditions",
};

char *names388 [] =
{
"internal_conditions",
"exclude",
"include",
"description",
"error",
"exclude_regexp",
"include_regexp",
};

char *names389 [] =
{
"internal_conditions",
"command",
"working_directory",
"description",
"must_succeed",
};

char *names390 [] =
{
"internal_conditions",
"description",
"target",
"internal_location",
};

char *names391 [] =
{
"internal_conditions",
"description",
"target",
"internal_location",
};

char *names392 [] =
{
"internal_conditions",
"description",
"target",
"internal_location",
};

char *names393 [] =
{
"internal_conditions",
"description",
"target",
"internal_location",
};

char *names394 [] =
{
"internal_conditions",
"description",
"target",
"internal_location",
};

char *names395 [] =
{
"internal_conditions",
"description",
"target",
"internal_location",
};

char *names396 [] =
{
"internal_conditions",
"description",
"target",
"internal_location",
};

char *names397 [] =
{
"internal_conditions",
"description",
"target",
"internal_location",
};

char *names398 [] =
{
"area",
};

char *names399 [] =
{
"area",
};

char *names400 [] =
{
"area",
};

char *names401 [] =
{
"area",
};

char *names402 [] =
{
"area",
};

char *names403 [] =
{
"area",
};

char *names404 [] =
{
"area",
};

char *names405 [] =
{
"area",
};

char *names406 [] =
{
"area",
};

char *names407 [] =
{
"area",
};

char *names408 [] =
{
"area",
};

char *names409 [] =
{
"area",
};

char *names413 [] =
{
"is_shared",
"count",
"item",
"counter",
};

char *names414 [] =
{
"read_descriptor",
"write_descriptor",
};

char *names417 [] =
{
"managed_data",
"unit_count",
};

char *names418 [] =
{
"buffered_file_info",
"internal_file_name",
"internal_name_pointer",
"exists",
"is_following_symlinks",
};

char *names419 [] =
{
"buffered_file_info",
"internal_file_name",
"internal_name_pointer",
"exists",
"is_following_symlinks",
};

char *names420 [] =
{
"lastentry",
"internal_name",
"internal_detachable_name_pointer",
"mode",
"directory_pointer",
"last_entry_pointer",
};

char *names421 [] =
{
"return_code",
};

char *names422 [] =
{
"return_code",
};

char *names423 [] =
{
"return_code",
};

char *names424 [] =
{
"return_code",
};

char *names425 [] =
{
"working_directory",
"arguments_for_exec",
"last_output",
"last_error",
"program_file_name",
"arguments",
"input_file_name",
"output_file_name",
"error_file_name",
"in_file",
"out_file",
"err_file",
"shared_input_unnamed_pipe",
"shared_output_unnamed_pipe",
"shared_error_unnamed_pipe",
"is_last_wait_successful",
"is_executing",
"is_status_available",
"has_write_error",
"has_output_stream_error",
"has_error_stream_error",
"close_nonstandard_files",
"input_piped",
"output_piped",
"error_piped",
"error_same_as_output",
"return_code",
"process_id",
"status",
};

char *names428 [] =
{
"area",
"unicode_area",
"as_unicode_special",
"invalid_character",
"invalid_unicode_character",
};

char *names429 [] =
{
"area",
"as_special",
};

char *names430 [] =
{
"managed_data",
"count",
};

char *names431 [] =
{
"last_string",
"last_character",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"last_real",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names432 [] =
{
"last_string",
"shared_mptr",
"last_character",
"last_read_successful",
"last_write_successful",
"is_read_descriptor_open",
"is_write_descriptor_open",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"read_descriptor",
"write_descriptor",
"last_integer",
"bytes_read",
"last_real",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names445 [] =
{
"area",
"area_index",
"remaining_count",
};

char *names446 [] =
{
"byte",
"file_pointer",
};

char *names447 [] =
{
"target",
"iteration_position",
};

char *names448 [] =
{
"target",
"iteration_position",
};

char *names449 [] =
{
"target",
"iteration_position",
};

char *names460 [] =
{
"ordered_compact_date",
};

char *names462 [] =
{
"path",
"installation_path",
};

char *names464 [] =
{
"layout",
"urls",
};

char *names465 [] =
{
"layout",
"urls",
"db",
"internal_installed_packages",
"internal_available_packages",
"db_revision",
};

char *names466 [] =
{
"internal_environment_arguments",
};

char *names467 [] =
{
"internal_environment_arguments",
};

char *names468 [] =
{
"command_line",
"working_directory",
"input_file_name",
"output_file_name",
"error_file_name",
"environment_variable_table",
"on_start_handler",
"on_exit_handler",
"on_terminate_handler",
"on_fail_launch_handler",
"on_successful_launch_handler",
"arguments",
"has_input_error",
"has_output_stream_error",
"has_output_stream_closed",
"has_error_stream_error",
"has_error_stream_closed",
"has_process_exited",
"launched",
"has_exited",
"abort_termination_when_failed",
"force_terminated",
"last_termination_successful",
"hidden",
"separate_console",
"detached_console",
"is_terminal_control_enabled",
"is_launched_in_new_process_group",
"id",
"input_direction",
"output_direction",
"error_direction",
};

char *names469 [] =
{
"command_line",
"working_directory",
"input_file_name",
"output_file_name",
"error_file_name",
"environment_variable_table",
"on_start_handler",
"on_exit_handler",
"on_terminate_handler",
"on_fail_launch_handler",
"on_successful_launch_handler",
"arguments",
"child_process",
"has_input_error",
"has_output_stream_error",
"has_output_stream_closed",
"has_error_stream_error",
"has_error_stream_closed",
"has_process_exited",
"launched",
"has_exited",
"abort_termination_when_failed",
"force_terminated",
"last_termination_successful",
"hidden",
"separate_console",
"detached_console",
"is_terminal_control_enabled",
"is_launched_in_new_process_group",
"return_code",
"id",
"input_direction",
"output_direction",
"error_direction",
};

char *names484 [] =
{
"target",
"target_index",
"start_index",
"end_index",
};

char *names509 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names510 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names511 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names512 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names513 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names514 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names515 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names516 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names517 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names518 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names519 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names520 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names521 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names522 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names523 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names524 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names525 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names526 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names527 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names528 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names529 [] =
{
"target",
"active",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names530 [] =
{
"target",
"active",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names531 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names532 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names533 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names534 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names535 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names536 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names537 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names538 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names539 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names540 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names541 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names542 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names543 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"area_first_index",
};

char *names544 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"area_first_index",
};

char *names545 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names546 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names547 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names548 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names549 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names550 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names551 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names552 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names553 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names554 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names555 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names556 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names557 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names558 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names559 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names560 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names561 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names562 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names563 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names564 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names565 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names566 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names567 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names568 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names569 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names570 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names571 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names572 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names573 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names574 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names575 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names576 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names577 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names578 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names579 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names580 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names581 [] =
{
"available_packages",
};

char *names582 [] =
{
"object_comparison",
};

char *names583 [] =
{
"object_comparison",
};

char *names584 [] =
{
"object_comparison",
};

char *names585 [] =
{
"object_comparison",
};

char *names586 [] =
{
"object_comparison",
};

char *names587 [] =
{
"object_comparison",
};

char *names588 [] =
{
"object_comparison",
};

char *names589 [] =
{
"object_comparison",
};

char *names590 [] =
{
"object_comparison",
};

char *names591 [] =
{
"object_comparison",
};

char *names592 [] =
{
"object_comparison",
};

char *names593 [] =
{
"object_comparison",
};

char *names594 [] =
{
"object_comparison",
};

char *names595 [] =
{
"object_comparison",
};

char *names596 [] =
{
"object_comparison",
};

char *names597 [] =
{
"object_comparison",
};

char *names598 [] =
{
"object_comparison",
};

char *names599 [] =
{
"object_comparison",
};

char *names600 [] =
{
"object_comparison",
};

char *names601 [] =
{
"object_comparison",
};

char *names602 [] =
{
"object_comparison",
};

char *names603 [] =
{
"object_comparison",
};

char *names604 [] =
{
"object_comparison",
};

char *names605 [] =
{
"object_comparison",
};

char *names606 [] =
{
"object_comparison",
};

char *names607 [] =
{
"object_comparison",
};

char *names608 [] =
{
"object_comparison",
};

char *names609 [] =
{
"object_comparison",
};

char *names610 [] =
{
"object_comparison",
};

char *names611 [] =
{
"object_comparison",
};

char *names612 [] =
{
"object_comparison",
};

char *names613 [] =
{
"object_comparison",
};

char *names614 [] =
{
"object_comparison",
};

char *names615 [] =
{
"object_comparison",
};

char *names616 [] =
{
"object_comparison",
};

char *names617 [] =
{
"object_comparison",
};

char *names618 [] =
{
"object_comparison",
};

char *names619 [] =
{
"object_comparison",
};

char *names620 [] =
{
"object_comparison",
};

char *names621 [] =
{
"object_comparison",
};

char *names622 [] =
{
"object_comparison",
};

char *names623 [] =
{
"object_comparison",
};

char *names624 [] =
{
"object_comparison",
};

char *names625 [] =
{
"object_comparison",
};

char *names626 [] =
{
"object_comparison",
};

char *names627 [] =
{
"object_comparison",
};

char *names628 [] =
{
"object_comparison",
};

char *names629 [] =
{
"object_comparison",
};

char *names630 [] =
{
"object_comparison",
};

char *names631 [] =
{
"object_comparison",
};

char *names632 [] =
{
"object_comparison",
};

char *names633 [] =
{
"object_comparison",
};

char *names634 [] =
{
"object_comparison",
};

char *names635 [] =
{
"object_comparison",
};

char *names636 [] =
{
"object_comparison",
};

char *names637 [] =
{
"object_comparison",
};

char *names638 [] =
{
"object_comparison",
};

char *names639 [] =
{
"object_comparison",
};

char *names640 [] =
{
"object_comparison",
};

char *names641 [] =
{
"object_comparison",
};

char *names642 [] =
{
"object_comparison",
};

char *names643 [] =
{
"object_comparison",
};

char *names644 [] =
{
"object_comparison",
};

char *names645 [] =
{
"object_comparison",
};

char *names646 [] =
{
"object_comparison",
};

char *names647 [] =
{
"object_comparison",
};

char *names648 [] =
{
"object_comparison",
};

char *names649 [] =
{
"object_comparison",
};

char *names650 [] =
{
"object_comparison",
};

char *names651 [] =
{
"object_comparison",
};

char *names652 [] =
{
"object_comparison",
};

char *names653 [] =
{
"object_comparison",
};

char *names654 [] =
{
"object_comparison",
};

char *names655 [] =
{
"object_comparison",
};

char *names656 [] =
{
"object_comparison",
};

char *names657 [] =
{
"object_comparison",
};

char *names658 [] =
{
"object_comparison",
};

char *names659 [] =
{
"object_comparison",
};

char *names660 [] =
{
"object_comparison",
};

char *names661 [] =
{
"object_comparison",
};

char *names662 [] =
{
"object_comparison",
};

char *names663 [] =
{
"object_comparison",
};

char *names664 [] =
{
"object_comparison",
};

char *names665 [] =
{
"object_comparison",
};

char *names666 [] =
{
"object_comparison",
};

char *names667 [] =
{
"object_comparison",
};

char *names668 [] =
{
"object_comparison",
};

char *names669 [] =
{
"object_comparison",
};

char *names670 [] =
{
"object_comparison",
};

char *names671 [] =
{
"object_comparison",
};

char *names672 [] =
{
"object_comparison",
};

char *names673 [] =
{
"object_comparison",
};

char *names674 [] =
{
"object_comparison",
};

char *names675 [] =
{
"object_comparison",
};

char *names676 [] =
{
"object_comparison",
};

char *names677 [] =
{
"object_comparison",
};

char *names678 [] =
{
"object_comparison",
};

char *names679 [] =
{
"object_comparison",
};

char *names680 [] =
{
"object_comparison",
};

char *names681 [] =
{
"object_comparison",
};

char *names682 [] =
{
"object_comparison",
};

char *names683 [] =
{
"object_comparison",
};

char *names684 [] =
{
"object_comparison",
};

char *names685 [] =
{
"object_comparison",
};

char *names686 [] =
{
"object_comparison",
};

char *names687 [] =
{
"object_comparison",
};

char *names688 [] =
{
"object_comparison",
};

char *names689 [] =
{
"object_comparison",
};

char *names690 [] =
{
"object_comparison",
};

char *names691 [] =
{
"object_comparison",
};

char *names692 [] =
{
"object_comparison",
};

char *names693 [] =
{
"object_comparison",
};

char *names694 [] =
{
"object_comparison",
};

char *names695 [] =
{
"object_comparison",
};

char *names696 [] =
{
"object_comparison",
};

char *names697 [] =
{
"object_comparison",
};

char *names698 [] =
{
"object_comparison",
};

char *names699 [] =
{
"object_comparison",
};

char *names700 [] =
{
"object_comparison",
};

char *names701 [] =
{
"object_comparison",
};

char *names702 [] =
{
"object_comparison",
};

char *names703 [] =
{
"object_comparison",
};

char *names704 [] =
{
"object_comparison",
};

char *names705 [] =
{
"object_comparison",
};

char *names706 [] =
{
"object_comparison",
};

char *names707 [] =
{
"object_comparison",
};

char *names708 [] =
{
"object_comparison",
};

char *names709 [] =
{
"object_comparison",
};

char *names710 [] =
{
"object_comparison",
};

char *names711 [] =
{
"object_comparison",
};

char *names712 [] =
{
"object_comparison",
};

char *names713 [] =
{
"object_comparison",
};

char *names714 [] =
{
"object_comparison",
};

char *names715 [] =
{
"object_comparison",
};

char *names716 [] =
{
"object_comparison",
};

char *names717 [] =
{
"object_comparison",
};

char *names718 [] =
{
"object_comparison",
};

char *names719 [] =
{
"object_comparison",
};

char *names720 [] =
{
"object_comparison",
};

char *names721 [] =
{
"object_comparison",
};

char *names722 [] =
{
"object_comparison",
};

char *names723 [] =
{
"object_comparison",
};

char *names724 [] =
{
"object_comparison",
};

char *names725 [] =
{
"object_comparison",
};

char *names726 [] =
{
"object_comparison",
};

char *names727 [] =
{
"object_comparison",
};

char *names728 [] =
{
"object_comparison",
};

char *names729 [] =
{
"object_comparison",
};

char *names730 [] =
{
"object_comparison",
};

char *names731 [] =
{
"object_comparison",
};

char *names732 [] =
{
"object_comparison",
};

char *names733 [] =
{
"object_comparison",
"index",
};

char *names734 [] =
{
"object_comparison",
"index",
"seed",
"last_item",
"last_result",
};

char *names735 [] =
{
"object_comparison",
"index",
};

char *names736 [] =
{
"object_comparison",
};

char *names737 [] =
{
"object_comparison",
};

char *names738 [] =
{
"object_comparison",
};

char *names739 [] =
{
"object_comparison",
};

char *names740 [] =
{
"object_comparison",
};

char *names741 [] =
{
"object_comparison",
};

char *names742 [] =
{
"object_comparison",
};

char *names743 [] =
{
"object_comparison",
};

char *names744 [] =
{
"object_comparison",
};

char *names745 [] =
{
"object_comparison",
};

char *names746 [] =
{
"object_comparison",
};

char *names747 [] =
{
"object_comparison",
};

char *names748 [] =
{
"object_comparison",
};

char *names749 [] =
{
"object_comparison",
};

char *names750 [] =
{
"object_comparison",
};

char *names751 [] =
{
"object_comparison",
};

char *names752 [] =
{
"object_comparison",
};

char *names753 [] =
{
"object_comparison",
};

char *names754 [] =
{
"object_comparison",
};

char *names755 [] =
{
"object_comparison",
};

char *names756 [] =
{
"object_comparison",
};

char *names757 [] =
{
"object_comparison",
};

char *names758 [] =
{
"object_comparison",
};

char *names759 [] =
{
"object_comparison",
};

char *names760 [] =
{
"object_comparison",
};

char *names761 [] =
{
"object_comparison",
};

char *names762 [] =
{
"object_comparison",
};

char *names763 [] =
{
"object_comparison",
};

char *names764 [] =
{
"object_comparison",
};

char *names765 [] =
{
"object_comparison",
};

char *names766 [] =
{
"object_comparison",
};

char *names767 [] =
{
"object_comparison",
};

char *names768 [] =
{
"object_comparison",
};

char *names769 [] =
{
"object_comparison",
};

char *names770 [] =
{
"object_comparison",
};

char *names771 [] =
{
"object_comparison",
};

char *names772 [] =
{
"object_comparison",
};

char *names773 [] =
{
"object_comparison",
};

char *names774 [] =
{
"object_comparison",
};

char *names775 [] =
{
"area",
"object_comparison",
"out_index",
"count",
};

char *names776 [] =
{
"object_comparison",
};

char *names777 [] =
{
"object_comparison",
};

char *names778 [] =
{
"object_comparison",
};

char *names779 [] =
{
"object_comparison",
};

char *names780 [] =
{
"object_comparison",
};

char *names781 [] =
{
"object_comparison",
};

char *names782 [] =
{
"object_comparison",
};

char *names783 [] =
{
"object_comparison",
};

char *names784 [] =
{
"object_comparison",
};

char *names785 [] =
{
"object_comparison",
};

char *names786 [] =
{
"object_comparison",
};

char *names787 [] =
{
"object_comparison",
};

char *names788 [] =
{
"object_comparison",
};

char *names789 [] =
{
"object_comparison",
};

char *names790 [] =
{
"object_comparison",
};

char *names791 [] =
{
"object_comparison",
};

char *names792 [] =
{
"object_comparison",
};

char *names793 [] =
{
"object_comparison",
};

char *names794 [] =
{
"object_comparison",
};

char *names795 [] =
{
"object_comparison",
};

char *names796 [] =
{
"object_comparison",
};

char *names797 [] =
{
"object_comparison",
};

char *names798 [] =
{
"object_comparison",
};

char *names799 [] =
{
"object_comparison",
};

char *names800 [] =
{
"object_comparison",
};

char *names801 [] =
{
"object_comparison",
};

char *names802 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names803 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"last_string_32",
"internal_encoding",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"is_sequence_an_expected_numeric",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names804 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names813 [] =
{
"data",
"is_valid",
};

char *names826 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names827 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_key",
"count",
};

char *names828 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"found_item",
"hash_table_version_64",
"has_default",
"ht_deleted_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names829 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"found_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_item",
"count",
};

char *names830 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"object_comparison",
"hash_table_version_64",
"has_default",
"found_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_item",
"ht_deleted_key",
"count",
};

char *names831 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"found_item",
"ht_deleted_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names832 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"found_item",
"ht_deleted_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names833 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
"found_item",
"ht_deleted_item",
};

char *names834 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"ht_deleted_key",
"stored_version",
"current_version",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names835 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"is_case_insensitive",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names836 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"found_item",
"hash_table_version_64",
"has_default",
"ht_deleted_item",
"is_case_insensitive",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names837 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"is_case_insensitive",
"found_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_item",
"count",
};

char *names838 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"is_case_insensitive",
"found_item",
"ht_deleted_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names839 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"is_case_insensitive",
"found_item",
"ht_deleted_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names840 [] =
{
"object_comparison",
};

char *names841 [] =
{
"object_comparison",
};

char *names842 [] =
{
"object_comparison",
};

char *names843 [] =
{
"object_comparison",
};

char *names844 [] =
{
"object_comparison",
};

char *names845 [] =
{
"object_comparison",
};

char *names846 [] =
{
"object_comparison",
};

char *names847 [] =
{
"object_comparison",
};

char *names848 [] =
{
"object_comparison",
};

char *names849 [] =
{
"object_comparison",
};

char *names850 [] =
{
"object_comparison",
};

char *names851 [] =
{
"object_comparison",
};

char *names852 [] =
{
"object_comparison",
"upper",
"lower",
};

char *names853 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names854 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names855 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names856 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names857 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names858 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names859 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names860 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names861 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names862 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names863 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names864 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names865 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names866 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names867 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names868 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names869 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names870 [] =
{
"object_comparison",
};

char *names871 [] =
{
"object_comparison",
};

char *names872 [] =
{
"object_comparison",
};

char *names873 [] =
{
"object_comparison",
};

char *names874 [] =
{
"object_comparison",
};

char *names875 [] =
{
"object_comparison",
};

char *names876 [] =
{
"object_comparison",
};

char *names877 [] =
{
"object_comparison",
};

char *names878 [] =
{
"object_comparison",
};

char *names879 [] =
{
"object_comparison",
};

char *names880 [] =
{
"object_comparison",
};

char *names881 [] =
{
"object_comparison",
};

char *names882 [] =
{
"object_comparison",
};

char *names883 [] =
{
"object_comparison",
};

char *names884 [] =
{
"object_comparison",
};

char *names885 [] =
{
"object_comparison",
};

char *names886 [] =
{
"object_comparison",
};

char *names887 [] =
{
"object_comparison",
};

char *names888 [] =
{
"object_comparison",
};

char *names889 [] =
{
"object_comparison",
};

char *names890 [] =
{
"object_comparison",
};

char *names891 [] =
{
"object_comparison",
};

char *names892 [] =
{
"object_comparison",
};

char *names893 [] =
{
"object_comparison",
};

char *names894 [] =
{
"object_comparison",
};

char *names895 [] =
{
"object_comparison",
};

char *names896 [] =
{
"object_comparison",
};

char *names897 [] =
{
"object_comparison",
};

char *names898 [] =
{
"object_comparison",
};

char *names899 [] =
{
"object_comparison",
};

char *names900 [] =
{
"object_comparison",
};

char *names901 [] =
{
"object_comparison",
};

char *names902 [] =
{
"object_comparison",
};

char *names903 [] =
{
"object_comparison",
};

char *names904 [] =
{
"object_comparison",
};

char *names905 [] =
{
"object_comparison",
};

char *names906 [] =
{
"object_comparison",
};

char *names907 [] =
{
"object_comparison",
};

char *names908 [] =
{
"object_comparison",
};

char *names909 [] =
{
"object_comparison",
};

char *names910 [] =
{
"object_comparison",
};

char *names911 [] =
{
"object_comparison",
};

char *names912 [] =
{
"object_comparison",
};

char *names913 [] =
{
"object_comparison",
};

char *names914 [] =
{
"object_comparison",
};

char *names915 [] =
{
"object_comparison",
};

char *names916 [] =
{
"object_comparison",
};

char *names917 [] =
{
"object_comparison",
};

char *names918 [] =
{
"first_element",
"active",
"object_comparison",
"before",
"after",
"count",
};

char *names919 [] =
{
"first_element",
"active",
"object_comparison",
"before",
"after",
"count",
};

char *names920 [] =
{
"first_element",
"active",
"object_comparison",
"before",
"after",
"count",
};

char *names921 [] =
{
"first_element",
"active",
"object_comparison",
"before",
"after",
"count",
};

char *names922 [] =
{
"first_element",
"active",
"object_comparison",
"before",
"after",
"count",
};

char *names923 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names924 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names925 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names926 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names927 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names928 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names929 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names930 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names931 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names932 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names933 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names934 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names935 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names936 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names937 [] =
{
"area_v2",
"element_name",
"attributes",
"content",
"parent",
"object_comparison",
"index",
};

char *names938 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names948 [] =
{
"name",
};

char *names952 [] =
{
"factory",
"observer",
"last_error",
"last_cycle_error",
"targets",
"error_reported_as_warning",
};

char *names953 [] =
{
"associated_parser",
"current_namespace",
"last_error",
"last_warning",
"file_name",
"last_system",
"last_redirection",
"factory",
"current_library_target",
"current_target",
"current_cluster",
"current_override",
"current_library",
"current_assembly",
"current_group",
"current_file_rule",
"current_option",
"current_external",
"current_action",
"current_content",
"current_condition",
"current_tag",
"current_attributes",
"current_attributes_undefined",
"current_element_under_note",
"tags_undefined",
"is_error",
"is_warning",
"is_invalid_xml",
"last_undefined_tag_number",
};

char *names954 [] =
{
"last_error",
"last_warnings",
"last_system",
"last_redirection",
"last_redirected_location",
"last_uuid",
"parent_target",
"factory",
"is_error",
"is_warning",
"is_invalid_xml",
"is_following_redirection",
};

char *names955 [] =
{
"assertions",
"namespace",
"local_namespace",
"description",
"syntax",
"array",
"warning",
"warnings",
"warning_obsolete_call",
"catcall_detection",
"void_safety",
"debugs",
"is_profile_configured",
"is_trace_configured",
"is_optimize_configured",
"is_debug_configured",
"is_msil_application_optimize_configured",
"is_full_class_checking_configured",
"is_attached_by_default_configured",
"is_obsolete_routine_type_configured",
"is_obsolete_iteration_configured",
"is_profile",
"is_trace",
"is_optimize",
"is_debug",
"is_msil_application_optimize",
"is_full_class_checking",
"is_attached_by_default",
"is_obsolete_iteration",
"is_obsolete_routine_type",
};

char *names956 [] =
{
"assertions",
"namespace",
"local_namespace",
"description",
"syntax",
"array",
"warning",
"warnings",
"warning_obsolete_call",
"catcall_detection",
"void_safety",
"debugs",
"void_safety_capability",
"catcall_safety_capability",
"concurrency_capability",
"concurrency",
"array_override",
"dead_code",
"is_profile_configured",
"is_trace_configured",
"is_optimize_configured",
"is_debug_configured",
"is_msil_application_optimize_configured",
"is_full_class_checking_configured",
"is_attached_by_default_configured",
"is_obsolete_routine_type_configured",
"is_obsolete_iteration_configured",
"is_profile",
"is_trace",
"is_optimize",
"is_debug",
"is_msil_application_optimize",
"is_full_class_checking",
"is_attached_by_default",
"is_obsolete_iteration",
"is_obsolete_routine_type",
};

char *names957 [] =
{
"last_warnings",
"visible",
};

char *names971 [] =
{
"character_buffer",
"last_string",
"last_character",
"end_of_file",
};

char *names972 [] =
{
"string",
"last_string",
"last_character",
"end_of_input",
"location",
};

char *names977 [] =
{
"text",
};

char *names978 [] =
{
"target",
"targets",
};

char *names979 [] =
{
"text",
};

char *names980 [] =
{
"text",
};

char *names981 [] =
{
"text",
};

char *names982 [] =
{
"text",
};

char *names983 [] =
{
"text",
};

char *names984 [] =
{
"text",
};

char *names985 [] =
{
"text",
};

char *names986 [] =
{
"file",
"orig_file",
"config",
};

char *names987 [] =
{
"file",
"files_associated_with_cycle",
};

char *names988 [] =
{
"redirection_file",
"destination_file",
"message",
};

char *names989 [] =
{
"file",
"redirected_file",
"file_uuid",
"redirected_file_uuid",
};

char *names990 [] =
{
"message",
"file",
"row",
"column",
"parse_mode",
};

char *names991 [] =
{
"message",
"file",
"group",
"row",
"column",
"parse_mode",
};

char *names992 [] =
{
"message",
"file",
"row",
"column",
"parse_mode",
};

char *names993 [] =
{
"message",
"file",
"row",
"column",
"parse_mode",
};

char *names994 [] =
{
"message",
"file",
"row",
"column",
"parse_mode",
};

char *names995 [] =
{
"message",
"file",
"regexp",
"row",
"column",
"parse_mode",
"position",
};

char *names996 [] =
{
"message",
"file",
"group",
"row",
"column",
"parse_mode",
};

char *names997 [] =
{
"message",
"file",
"row",
"column",
"parse_mode",
};

char *names999 [] =
{
"code",
};

char *names1001 [] =
{
"item",
};

char *names1002 [] =
{
"item",
};

char *names1003 [] =
{
"item",
};

char *names1004 [] =
{
"item",
};

char *names1005 [] =
{
"item",
};

char *names1006 [] =
{
"item",
};

char *names1007 [] =
{
"item",
};

char *names1008 [] =
{
"item",
};

char *names1009 [] =
{
"item",
};

char *names1010 [] =
{
"item",
};

char *names1011 [] =
{
"to_pointer",
};

char *names1012 [] =
{
"to_pointer",
};

char *names1013 [] =
{
"to_pointer",
};

char *names1014 [] =
{
"to_pointer",
};

char *names1015 [] =
{
"to_pointer",
};

char *names1016 [] =
{
"to_pointer",
};

char *names1017 [] =
{
"to_pointer",
};

char *names1018 [] =
{
"to_pointer",
};

char *names1019 [] =
{
"to_pointer",
};

char *names1020 [] =
{
"to_pointer",
};

char *names1021 [] =
{
"to_pointer",
};

char *names1022 [] =
{
"to_pointer",
};

char *names1023 [] =
{
"to_pointer",
};

char *names1024 [] =
{
"to_pointer",
};

char *names1025 [] =
{
"to_pointer",
};

char *names1026 [] =
{
"to_pointer",
};

char *names1027 [] =
{
"to_pointer",
};

char *names1028 [] =
{
"to_pointer",
};

char *names1029 [] =
{
"to_pointer",
};

char *names1030 [] =
{
"to_pointer",
};

char *names1031 [] =
{
"to_pointer",
};

char *names1032 [] =
{
"to_pointer",
};

char *names1033 [] =
{
"to_pointer",
};

char *names1034 [] =
{
"to_pointer",
};

char *names1035 [] =
{
"to_pointer",
};

char *names1036 [] =
{
"to_pointer",
};

char *names1037 [] =
{
"to_pointer",
};

char *names1038 [] =
{
"to_pointer",
};

char *names1039 [] =
{
"to_pointer",
};

char *names1040 [] =
{
"to_pointer",
};

char *names1041 [] =
{
"item",
};

char *names1042 [] =
{
"item",
};

char *names1043 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names1044 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names1045 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"last_result",
"is_target_closed",
"is_basic",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names1046 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"last_result",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names1047 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"last_result",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names1048 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"last_result",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names1049 [] =
{
"internal_hash_code",
"internal_case_insensitive_hash_code",
};

char *names1050 [] =
{
"internal_hash_code",
"internal_case_insensitive_hash_code",
};

char *names1051 [] =
{
"internal_hash_code",
"internal_case_insensitive_hash_code",
};

char *names1052 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names1053 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
"area_lower",
};

char *names1054 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names1055 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names1056 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names1057 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
"area_lower",
};

char *names1058 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names1060 [] =
{
"value",
"name",
"is_text",
"is_numeric",
"count_max",
"count_min",
"value_max",
"value_min",
"type",
};

char *names1061 [] =
{
"available_packages",
"server_uri",
"version",
"location",
};

char *names1062 [] =
{
"available_packages",
"path",
"location",
};

char *names1063 [] =
{
"repository",
"id",
"name",
"title",
"description",
"associated_paths",
"tags",
"archive_uri",
"archive_hash",
"items",
"archive_revision",
"archive_size",
};

char *names1064 [] =
{
"current_chunk",
"source",
"name",
"last_character",
"is_started",
"is_inner_source",
"count",
"chunk_size",
"chunk_source_lower",
"chunk_source_upper",
"column",
"line",
"index",
};

char *names1065 [] =
{
"source",
"name",
"last_character",
"end_of_input",
"count",
"source_index",
"column",
"line",
};

char *names1066 [] =
{
"value",
"custom_root_index",
};

char *names1067 [] =
{
"content",
"is_set",
"default_index",
"index",
};

char *names1068 [] =
{
"recorder",
"object",
"breakable_info",
"parent",
"steps",
"call_records",
"value_records",
"last_position",
"rt_information_available",
"is_expanded",
"is_flat",
"is_closed",
"class_type_id",
"feature_rout_id",
"depth",
};

char *names1069 [] =
{
"source_name",
"byte_index",
"column",
"line",
};

char *names1070 [] =
{
"data_2",
"data_3",
"data_4",
"data_1",
"data_5",
};

char *names1071 [] =
{
"last_error",
"name",
"visible",
"group",
"file_name",
"path",
"overriden_by",
"overrides",
"last_class_name",
"factory",
"old_overriden_by",
"is_valid",
"is_partial",
"is_modified",
"is_removed",
"is_renamed",
"is_class_name_confirmed",
"date",
"internal_hash_code",
};

char *names1072 [] =
{
"note_node",
"internal_options",
"forced_options",
"internal_settings",
"name",
"description",
"extends",
"parent_reference",
"system",
"environ_variables",
"internal_root",
"internal_version",
"internal_precompile",
"internal_libraries",
"internal_overrides",
"internal_clusters",
"internal_assemblies",
"internal_file_rule",
"internal_mapping",
"internal_external_include",
"internal_external_cflag",
"internal_external_object",
"internal_external_library",
"internal_external_resource",
"internal_external_linker_flag",
"internal_external_make",
"internal_pre_compile_action",
"internal_post_compile_action",
"internal_variables",
"is_abstract",
};

char *names1073 [] =
{
"storage",
"internal_name",
"is_normalized",
};

char *names1074 [] =
{
"internal_name_32",
"internal_name",
};

char *names1075 [] =
{
"internal_name_32",
"internal_name",
};

char *names1076 [] =
{
"internal_name_32",
"internal_name",
};

char *names1077 [] =
{
"internal_name_32",
"internal_name",
};

char *names1078 [] =
{
"internal_name_32",
"internal_name",
};

char *names1079 [] =
{
"internal_name_32",
"internal_name",
};

char *names1080 [] =
{
"internal_name_32",
"internal_name",
};

char *names1081 [] =
{
"internal_name_32",
"internal_name",
};

char *names1082 [] =
{
"internal_name_32",
"internal_name",
};

char *names1083 [] =
{
"internal_name_32",
"internal_name",
};

char *names1084 [] =
{
"internal_name_32",
"internal_name",
};

char *names1085 [] =
{
"internal_name_32",
"internal_name",
};

char *names1086 [] =
{
"internal_name_32",
"internal_name",
};

char *names1087 [] =
{
"internal_name_32",
"internal_name",
};

char *names1088 [] =
{
"internal_name_32",
"internal_name",
};

char *names1089 [] =
{
"internal_name_32",
"internal_name",
};

char *names1090 [] =
{
"internal_name_32",
"internal_name",
};

char *names1091 [] =
{
"internal_name_32",
"internal_name",
};

char *names1092 [] =
{
"internal_name_32",
"internal_name",
};

char *names1093 [] =
{
"internal_name_32",
"internal_name",
};

char *names1094 [] =
{
"internal_name_32",
"internal_name",
};

char *names1095 [] =
{
"internal_name_32",
"internal_name",
};

char *names1096 [] =
{
"internal_name_32",
"internal_name",
};

char *names1097 [] =
{
"internal_name_32",
"internal_name",
};

char *names1098 [] =
{
"internal_name_32",
"internal_name",
};

char *names1099 [] =
{
"internal_name_32",
"internal_name",
};

char *names1100 [] =
{
"internal_name_32",
"internal_name",
};

char *names1101 [] =
{
"internal_name_32",
"internal_name",
};

char *names1102 [] =
{
"internal_name_32",
"internal_name",
};

char *names1103 [] =
{
"internal_name_32",
"internal_name",
};

char *names1104 [] =
{
"internal_name_32",
"internal_name",
};

char *names1105 [] =
{
"internal_name_32",
"internal_name",
};

char *names1106 [] =
{
"internal_name_32",
"internal_name",
};

char *names1107 [] =
{
"internal_name_32",
"internal_name",
};

char *names1121 [] =
{
"note_node",
"internal_conditions",
"last_error",
"name",
"description",
"location",
"target",
"overriders",
"classes",
"internal_options",
"forced_options",
"internal_class_options",
"forced_class_options",
"classes_by_filename",
"reverse_classes_cache",
"accessible_groups_cache",
"is_valid",
"is_readonly_set",
"internal_read_only",
"internal_hash_code",
};

char *names1122 [] =
{
"note_node",
"internal_conditions",
"last_error",
"name",
"description",
"location",
"target",
"overriders",
"classes",
"internal_options",
"forced_options",
"internal_class_options",
"forced_class_options",
"classes_by_filename",
"reverse_classes_cache",
"accessible_groups_cache",
"is_valid",
"is_readonly_set",
"internal_read_only",
"internal_hash_code",
};

char *names1123 [] =
{
"note_node",
"internal_conditions",
"last_error",
"name",
"description",
"location",
"target",
"overriders",
"classes",
"internal_options",
"forced_options",
"internal_class_options",
"forced_class_options",
"classes_by_filename",
"reverse_classes_cache",
"accessible_groups_cache",
"assemblies",
"dependencies",
"is_valid",
"is_readonly_set",
"internal_read_only",
"internal_hash_code",
};

char *names1124 [] =
{
"note_node",
"internal_conditions",
"last_warnings",
"visible",
"last_error",
"name",
"description",
"location",
"target",
"overriders",
"classes",
"internal_options",
"forced_options",
"internal_class_options",
"forced_class_options",
"classes_by_filename",
"reverse_classes_cache",
"accessible_groups_cache",
"parent",
"children",
"internal_dependencies",
"dependency_names",
"internal_file_rule",
"internal_mapping",
"class_by_name_cache",
"name_by_class_cache",
"cached_mapping",
"is_valid",
"is_readonly_set",
"internal_read_only",
"is_recursive",
"is_hidden",
"internal_hash_code",
};

char *names1125 [] =
{
"note_node",
"internal_conditions",
"last_warnings",
"visible",
"last_error",
"name",
"description",
"location",
"target",
"overriders",
"classes",
"internal_options",
"forced_options",
"internal_class_options",
"forced_class_options",
"classes_by_filename",
"reverse_classes_cache",
"accessible_groups_cache",
"parent",
"children",
"internal_dependencies",
"dependency_names",
"internal_file_rule",
"internal_mapping",
"class_by_name_cache",
"name_by_class_cache",
"cached_mapping",
"is_valid",
"is_readonly_set",
"internal_read_only",
"is_recursive",
"is_hidden",
"internal_hash_code",
};

char *names1126 [] =
{
"note_node",
"internal_conditions",
"last_warnings",
"visible",
"last_error",
"name",
"description",
"location",
"target",
"overriders",
"classes",
"internal_options",
"forced_options",
"internal_class_options",
"forced_class_options",
"classes_by_filename",
"reverse_classes_cache",
"accessible_groups_cache",
"parent",
"children",
"internal_dependencies",
"dependency_names",
"internal_file_rule",
"internal_mapping",
"class_by_name_cache",
"name_by_class_cache",
"cached_mapping",
"override",
"override_group_names",
"is_valid",
"is_readonly_set",
"internal_read_only",
"is_recursive",
"is_hidden",
"internal_hash_code",
};

char *names1127 [] =
{
"note_node",
"internal_conditions",
"last_error",
"name",
"description",
"location",
"target",
"overriders",
"classes",
"internal_options",
"forced_options",
"internal_class_options",
"forced_class_options",
"classes_by_filename",
"reverse_classes_cache",
"accessible_groups_cache",
"renaming",
"name_prefix",
"is_valid",
"is_readonly_set",
"internal_read_only",
"internal_hash_code",
};

char *names1128 [] =
{
"note_node",
"internal_conditions",
"last_error",
"name",
"description",
"location",
"target",
"overriders",
"classes",
"internal_options",
"forced_options",
"internal_class_options",
"forced_class_options",
"classes_by_filename",
"reverse_classes_cache",
"accessible_groups_cache",
"renaming",
"name_prefix",
"assembly_name",
"assembly_version",
"assembly_culture",
"assembly_public_key_token",
"physical_assembly",
"is_valid",
"is_readonly_set",
"internal_read_only",
"is_non_local_assembly",
"internal_hash_code",
};

char *names1129 [] =
{
"note_node",
"internal_conditions",
"last_warnings",
"visible",
"last_error",
"name",
"description",
"location",
"target",
"overriders",
"classes",
"internal_options",
"forced_options",
"internal_class_options",
"forced_class_options",
"classes_by_filename",
"reverse_classes_cache",
"accessible_groups_cache",
"renaming",
"name_prefix",
"library_target",
"is_valid",
"is_readonly_set",
"internal_read_only",
"use_application_options",
"internal_hash_code",
};

char *names1130 [] =
{
"note_node",
"internal_conditions",
"last_warnings",
"visible",
"last_error",
"name",
"description",
"location",
"target",
"overriders",
"classes",
"internal_options",
"forced_options",
"internal_class_options",
"forced_class_options",
"classes_by_filename",
"reverse_classes_cache",
"accessible_groups_cache",
"renaming",
"name_prefix",
"library_target",
"eifgens_location",
"is_valid",
"is_readonly_set",
"internal_read_only",
"use_application_options",
"internal_hash_code",
};

char *names1131 [] =
{
"breakable_info",
"position",
"type",
};

char *names1132 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names1133 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names1134 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names1135 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names1136 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names1137 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names1138 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names1139 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names1140 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names1141 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names1142 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names1143 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names1144 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names1145 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names1146 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names1147 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names1148 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names1149 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names1150 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names1151 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names1152 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names1153 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names1154 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names1155 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names1156 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names1157 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names1158 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names1159 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names1160 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names1161 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names1162 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names1163 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names1164 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names1165 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names1166 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names1167 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names1168 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names1169 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names1170 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names1171 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names1172 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names1173 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names1174 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"value",
"callstack_depth",
};

char *names1175 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names1176 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names1178 [] =
{
"item",
};

char *names1180 [] =
{
"item",
"numeric_type",
};

char *names1181 [] =
{
"item",
};

char *names1183 [] =
{
"item",
};

char *names1184 [] =
{
"item",
};

char *names1185 [] =
{
"item",
};

char *names1186 [] =
{
"item",
};

char *names1187 [] =
{
"item",
};

char *names1188 [] =
{
"item",
};

char *names1189 [] =
{
"item",
};

char *names1190 [] =
{
"item",
};

char *names1191 [] =
{
"item",
};

char *names1192 [] =
{
"item",
};

char *names1193 [] =
{
"item",
};

char *names1194 [] =
{
"item",
};

char *names1195 [] =
{
"item",
};

char *names1196 [] =
{
"item",
};

char *names1197 [] =
{
"item",
};

char *names1198 [] =
{
"item",
};

char *names1199 [] =
{
"item",
};

char *names1200 [] =
{
"item",
};

char *names1201 [] =
{
"item",
};

char *names1202 [] =
{
"item",
};

char *names1203 [] =
{
"item",
};

char *names1204 [] =
{
"item",
};

char *names1205 [] =
{
"item",
};

char *names1206 [] =
{
"item",
};

char *names1207 [] =
{
"item",
};

char *names1208 [] =
{
"item",
};

char *names1209 [] =
{
"item",
};

char *names1210 [] =
{
"item",
};

char *names1211 [] =
{
"item",
};

char *names1212 [] =
{
"item",
};

char *names1213 [] =
{
"items",
};

char *names1214 [] =
{
"items",
};

char *names1220 [] =
{
"name",
};

char *names1221 [] =
{
"name",
"full_name",
"language",
"region",
"script",
"encoding",
};

char *names1222 [] =
{
"datasource_manager",
"host_locale",
};

char *names1223 [] =
{
"conf_location_mapper",
"is_initialized",
"conf_location_mapper_initialized",
"iron_initialized",
};

char *names1224 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"last_string_32",
"internal_encoding",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"is_sequence_an_expected_numeric",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1225 [] =
{
"found_item",
"key_tester",
"deleted_marks",
"content",
"is_map",
"count",
"position",
"control",
"capacity",
"iteration_position",
};

char *names1226 [] =
{
"key_tester",
"deleted_marks",
"content",
"is_map",
"found_item",
"count",
"position",
"control",
"capacity",
"iteration_position",
};

char *names1227 [] =
{
"key_tester",
"deleted_marks",
"content",
"is_map",
"found_item",
"count",
"position",
"control",
"capacity",
"iteration_position",
};

char *names1228 [] =
{
"company",
"product",
"trademark",
"copyright",
"is_error",
"minimum_length_for_major",
"minimum_length_for_minor",
"minimum_length_for_release",
"minimum_length_for_build",
"major",
"minor",
"release",
"build",
};

char *names1235 [] =
{
"input_buffer",
"last_character",
"last_unicode_character",
"last_token",
};

char *names1236 [] =
{
"input_buffer",
"yy_content",
"yy_content_area",
"yy_unicode_content_area",
"yy_pushed_start_conditions",
"last_character",
"yy_more_flag",
"last_unicode_character",
"last_token",
"yy_start_state",
"yy_end",
"yy_start",
"yy_line",
"yy_column",
"yy_position",
"yy_more_len",
"yy_last_accepting_state",
"yy_last_accepting_cpos",
"pushed_start_condition_count",
"position",
"column",
"line",
};

char *names1237 [] =
{
"input_buffer",
"yy_content",
"yy_content_area",
"yy_unicode_content_area",
"yy_pushed_start_conditions",
"yy_nxt",
"yy_chk",
"yy_base",
"yy_def",
"yy_ec",
"yy_meta",
"yy_accept",
"yy_acclist",
"yy_state_stack",
"last_character",
"yy_more_flag",
"yy_rejected",
"last_unicode_character",
"last_token",
"yy_start_state",
"yy_end",
"yy_start",
"yy_line",
"yy_column",
"yy_position",
"yy_more_len",
"yy_last_accepting_state",
"yy_last_accepting_cpos",
"pushed_start_condition_count",
"position",
"column",
"line",
"yy_state_count",
"yy_full_match",
"yy_lp",
"yy_looking_for_trail_begin",
"yy_full_lp",
"yy_full_state",
};

char *names1238 [] =
{
"input_buffer",
"yy_content",
"yy_content_area",
"yy_unicode_content_area",
"yy_pushed_start_conditions",
"yy_nxt",
"yy_chk",
"yy_base",
"yy_def",
"yy_ec",
"yy_meta",
"yy_accept",
"yy_acclist",
"yy_state_stack",
"classname",
"verbatim_marker",
"last_character",
"yy_more_flag",
"yy_rejected",
"is_partial_class",
"last_unicode_character",
"last_token",
"yy_start_state",
"yy_end",
"yy_start",
"yy_line",
"yy_column",
"yy_position",
"yy_more_len",
"yy_last_accepting_state",
"yy_last_accepting_cpos",
"pushed_start_condition_count",
"position",
"column",
"line",
"yy_state_count",
"yy_full_match",
"yy_lp",
"yy_looking_for_trail_begin",
"yy_full_lp",
"yy_full_state",
"last_start_condition",
};

char *names1239 [] =
{
"input_buffer",
"yy_content",
"yy_content_area",
"yy_unicode_content_area",
"yy_pushed_start_conditions",
"yy_nxt",
"yy_chk",
"yy_base",
"yy_def",
"yy_ec",
"yy_meta",
"yy_accept",
"yy_acclist",
"yy_state_stack",
"classname",
"verbatim_marker",
"last_character",
"yy_more_flag",
"yy_rejected",
"is_partial_class",
"last_unicode_character",
"last_token",
"yy_start_state",
"yy_end",
"yy_start",
"yy_line",
"yy_column",
"yy_position",
"yy_more_len",
"yy_last_accepting_state",
"yy_last_accepting_cpos",
"pushed_start_condition_count",
"position",
"column",
"line",
"yy_state_count",
"yy_full_match",
"yy_lp",
"yy_looking_for_trail_begin",
"yy_full_lp",
"yy_full_state",
"last_start_condition",
};

char *names1241 [] =
{
"last_detection_successful",
};

char *names1242 [] =
{
"last_bom",
"detected_encoding",
"last_detection_successful",
"last_bom_count",
};

char *names1244 [] =
{
"value",
"days",
"months",
"internal_parser",
"separators_used",
"right_day_text",
"base_century",
};

char *names1245 [] =
{
"last_converted_string",
"last_conversion_successful",
"last_was_wide_string",
};

char *names1246 [] =
{
"last_converted_string",
"last_conversion_successful",
"last_was_wide_string",
};

char *names1247 [] =
{
"last_converted_string",
"last_conversion_successful",
"last_was_wide_string",
};

char *names1248 [] =
{
"last_converted_string",
"last_conversion_successful",
"last_was_wide_string",
};

char *names1249 [] =
{
"directory",
"file_name",
"store_successful",
"is_location_set",
"file_date",
};

char *names1250 [] =
{
"directory",
"file_name",
"redirection_location",
"uuid",
"message",
"store_successful",
"is_location_set",
"file_date",
};

char *names1251 [] =
{
"note_node",
"directory",
"file_name",
"name",
"description",
"uuid",
"namespace",
"targets",
"library_target",
"application_target",
"all_libraries",
"all_assemblies",
"used_in_libraries",
"lowest_used_in_library",
"application_target_library",
"target_order",
"store_successful",
"is_location_set",
"is_generated_uuid",
"is_readonly",
"level",
"file_date",
};

char *names1252 [] =
{
"last_errors",
"last_warnings",
};

char *names1253 [] =
{
"last_errors",
"last_warnings",
};

char *names1254 [] =
{
"namespace",
"last_errors",
"last_warnings",
"text",
"schema",
"current_target",
"current_is_subcluster",
"indent",
"last_count",
};

char *names1255 [] =
{
"last_errors",
"last_warnings",
"current_library",
"current_group",
"current_target",
"dependency_list",
"overrides_list",
"group_list",
"observer",
"error_reported_as_warning",
};

char *names1256 [] =
{
"last_errors",
"last_warnings",
"visited_library_locations",
"last_target",
"last_state",
"is_any_setting",
"is_platform_set",
"is_il_generation",
"has_dynamic_runtime",
"is_stopping_at_library",
"is_stopping_at_readonly_library",
"is_indexing_class",
"is_ignoring_redirection",
"is_visiting_same_ecf_library_once",
"is_first_visited_target",
"platform",
"build",
"concurrency",
"void_safety",
};

char *names1257 [] =
{
"observers",
"last_errors",
"last_warnings",
"visited_library_locations",
"last_target",
"last_state",
"is_any_setting",
"is_platform_set",
"is_il_generation",
"has_dynamic_runtime",
"is_stopping_at_library",
"is_stopping_at_readonly_library",
"is_indexing_class",
"is_ignoring_redirection",
"is_visiting_same_ecf_library_once",
"is_first_visited_target",
"platform",
"build",
"concurrency",
"void_safety",
};

char *names1258 [] =
{
"last_errors",
"last_warnings",
"state",
};

char *names1259 [] =
{
"last_errors",
"last_warnings",
"state",
"processed_targets",
"factory",
"application_target",
"libraries",
"level",
};

char *names1261 [] =
{
"appcache_location",
"appcomp_location",
"is_verbose",
"has_error",
"is_build_forced",
"check_level",
};

char *names1264 [] =
{
"text",
};

char *names1265 [] =
{
"platform",
"build",
"concurrency",
"void_safety",
"dotnet",
"dynamic_runtime",
"version",
"custom",
"target",
};

char *names1267 [] =
{
"lastentry",
"internal_name",
"internal_detachable_name_pointer",
"entry_buffer",
"last_entry",
"name",
"old_end_of_input",
"end_of_input",
"mode",
"directory_pointer",
"last_entry_pointer",
};

char *names1268 [] =
{
"name",
};

char *names1269 [] =
{
"name",
};

char *names1270 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"name",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1271 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"name",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1272 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"name",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1273 [] =
{
"name",
"character_buffer",
"last_string",
"last_character",
"end_of_file",
};

char *names1274 [] =
{
"internal_name",
"internal_detachable_name_pointer",
"last_string_32",
"internal_encoding",
"name",
"character_buffer",
"last_string",
"separator",
"last_character",
"object_comparison",
"descriptor_available",
"is_sequence_an_expected_numeric",
"end_of_file",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1275 [] =
{
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"name",
"character_buffer",
"last_string",
"separator",
"last_character",
"object_comparison",
"descriptor_available",
"end_of_file",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1276 [] =
{
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"name",
"character_buffer",
"last_string",
"separator",
"last_character",
"object_comparison",
"descriptor_available",
"end_of_file",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1277 [] =
{
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"name",
"character_buffer",
"last_string",
"separator",
"last_character",
"object_comparison",
"descriptor_available",
"end_of_file",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1278 [] =
{
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"name",
"character_buffer",
"last_string",
"separator",
"last_character",
"object_comparison",
"descriptor_available",
"end_of_file",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names1279 [] =
{
"original_path",
"parent",
"target",
};

char *names1280 [] =
{
"original_path",
"parent",
"target",
};

char *names1281 [] =
{
"original_path",
"parent",
"target",
};

char *names1282 [] =
{
"locale_info",
};

char *names1283 [] =
{
"representation",
"errors",
"parsed_json_value",
"false_value",
"true_value",
"null_value",
"buffer_json_string",
"buffer_json_number",
"buffer_is_number",
"is_parsed",
"has_error",
"index",
"default_array_size",
"default_object_size",
};

char *names1284 [] =
{
"managed_pointer",
"shared",
"type",
"internal_item",
};

char *names1285 [] =
{
"managed_pointer",
"shared",
"type",
"internal_item",
};

char *names1286 [] =
{
"top_callstack_record",
"bottom_callstack_record",
"replayed_call",
"replay_stack",
"flatten_when_closing",
"keep_calls_records",
"recording_values",
"is_replaying",
"last_replay_operation_failed",
"record_count",
"maximum_record_count",
};

char *names1292 [] =
{
"byte_code",
"character_case_mapping",
"word_set",
"error_message",
"pattern",
"internal_start_bits",
"start_bits",
"is_caseless",
"is_extended",
"is_greedy",
"is_multiline",
"is_dotall",
"is_empty_allowed",
"is_dollar_endonly",
"is_bol",
"is_eol",
"is_anchored",
"is_strict",
"is_startline",
"is_ichanged",
"subexpression_count",
"maxbackrefs",
"error_code",
"error_position",
"optchanged",
"code_index",
"pattern_position",
"pattern_count",
"first_character",
"required_character",
"regexp_countlits",
};

char *names1293 [] =
{
"subject",
"byte_code",
"character_case_mapping",
"word_set",
"error_message",
"pattern",
"internal_start_bits",
"start_bits",
"offset_vector",
"brastart_vector",
"eptr_vector",
"is_caseless",
"is_extended",
"is_greedy",
"is_multiline",
"is_dotall",
"is_empty_allowed",
"is_dollar_endonly",
"is_bol",
"is_eol",
"is_anchored",
"is_strict",
"is_startline",
"is_ichanged",
"is_matching_caseless",
"is_matching_multiline",
"is_matching_dotall",
"subject_start",
"subject_end",
"match_count",
"subexpression_count",
"maxbackrefs",
"subject_next_start",
"first_matched_index",
"offset_vector_count",
"offset_top",
"brastart_lower",
"brastart_count",
"brastart_capacity",
"eptr_capacity",
"error_code",
"error_position",
"optchanged",
"code_index",
"pattern_position",
"pattern_count",
"first_character",
"required_character",
"regexp_countlits",
"eptr",
"eptr_lower",
"eptr_upper",
};

char *names1294 [] =
{
"compact_time",
"fractional_second",
};

char *names1295 [] =
{
"compact_time",
"fractional_second",
};

char *names1296 [] =
{
"ordered_compact_date",
};

char *names1297 [] =
{
"ordered_compact_date",
};

char *names1298 [] =
{
"compact_time",
"ordered_compact_date",
"fractional_second",
};

char *names1299 [] =
{
"source_string",
"day_text_val",
"code",
"months",
"days",
"parsed",
"compact_time",
"ordered_compact_date",
"year_val",
"month_val",
"day_val",
"hour_val",
"minute_val",
"base_century",
"fractional_second",
"fine_second_val",
};

char *names1300 [] =
{
"time",
"date",
"compact_time",
"ordered_compact_date",
"fractional_second",
};

char *names1301 [] =
{
"scheme",
"userinfo",
"host",
"path",
"query",
"fragment",
"is_valid",
"is_corrected",
"port",
};

char *names1302 [] =
{
"scheme",
"uri_userinfo",
"host",
"uri_path",
"uri_query",
"uri_fragment",
"is_valid",
"is_corrected",
"port",
};

char *names1303 [] =
{
"scheme",
"userinfo",
"host",
"path",
"query",
"fragment",
"file_path",
"is_valid",
"is_corrected",
"is_absolute",
"port",
};

char *names1305 [] =
{
"is_valid_environment",
"is_hidden_files_path_available",
"is_unix_layout",
};

char *names1306 [] =
{
"is_valid_environment",
"is_hidden_files_path_available",
"is_unix_layout",
};

char *names1307 [] =
{
"last_errors",
"last_warnings",
"compilation_index",
};

char *names1309 [] =
{
"components",
"sharename",
"hostname",
"drive",
"is_relative",
"count",
};

char *names1310 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
"byte_count",
"last_byte_index_input",
"last_byte_index_result",
};

char *names1311 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
"byte_count",
"last_byte_index_input",
"last_byte_index_result",
};



#ifdef __cplusplus
}
#endif
