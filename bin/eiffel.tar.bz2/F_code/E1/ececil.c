#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* I18N_PLURAL_TOOLS reduce_one_plural_form */
EIF_INTEGER_32 _A8_50_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_one_plural_form */
EIF_INTEGER_32 __A8_50_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 _A8_51_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 __A8_51_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 _A8_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 __A8_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 _A8_53_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 __A8_53_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 _A8_54_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 __A8_54_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 _A8_55_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 __A8_55_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 _A8_56_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 __A8_56_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 _A8_57_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 __A8_57_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 _A8_58_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 __A8_58_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DESCRIPTOR_CACHE c_iconv_close */
void _A29_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_p);
}

	/* DESCRIPTOR_CACHE c_iconv_close */
void __A29_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* MISMATCH_INFORMATION wipe_out */
void A397_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F826_6622)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A397_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F834_6688)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A397_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F834_6689)(Current, arg1, arg2);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_cflag */
void _A415_562_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_cflag */
void __A415_562_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_linker_flag */
void _A415_563_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_linker_flag */
void __A415_563_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#13258#222#406# of on_start_tag_finish */
EIF_REFERENCE _A415_639_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F953_13258)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#13258#222#406# of on_start_tag_finish */
EIF_REFERENCE __A415_639_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F953_13258)(closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#13259#222#407# of on_start_tag_finish */
EIF_REFERENCE _A415_640_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F953_13259)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#13259#222#407# of on_start_tag_finish */
EIF_REFERENCE __A415_640_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F953_13259)(closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#13260#222#405# of on_start_tag_finish */
EIF_REFERENCE _A415_641_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F953_13260)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#13260#222#405# of on_start_tag_finish */
EIF_REFERENCE __A415_641_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F953_13260)(closed [1].it_r, op_2);
}

	/* EXECUTION_ENVIRONMENT item */
EIF_REFERENCE _A360_40_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EXECUTION_ENVIRONMENT item */
EIF_REFERENCE __A360_40_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LIBRARY process */
void _A504_400_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3574[Dtype(open [1].it_r) - 1071])(open [1].it_r, closed [1].it_r);
}

	/* CONF_LIBRARY process */
void __A504_400_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3574[Dtype(op_1) - 1071])(op_1, closed [1].it_r);
}

	/* CONF_LIBRARY is_enabled */
EIF_BOOLEAN _A504_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F387_4812)(open [1].it_r, closed [1].it_r);
}

	/* CONF_LIBRARY is_enabled */
EIF_BOOLEAN __A504_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F387_4812)(op_1, closed [1].it_r);
}

	/* CONF_ASSEMBLY process */
void _A503_408_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1128_9221)(open [1].it_r, closed [1].it_r);
}

	/* CONF_ASSEMBLY process */
void __A503_408_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1128_9221)(op_1, closed [1].it_r);
}

	/* CONF_ASSEMBLY is_enabled */
EIF_BOOLEAN _A503_385_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* CONF_ASSEMBLY is_enabled */
EIF_BOOLEAN __A503_385_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* CONF_CLUSTER process */
void _A499_416_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3574[Dtype(open [1].it_r) - 1071])(open [1].it_r, closed [1].it_r);
}

	/* CONF_CLUSTER process */
void __A499_416_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3574[Dtype(op_1) - 1071])(op_1, closed [1].it_r);
}

	/* CONF_CLUSTER is_enabled */
EIF_BOOLEAN _A499_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F387_4812)(open [1].it_r, closed [1].it_r);
}

	/* CONF_CLUSTER is_enabled */
EIF_BOOLEAN __A499_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F387_4812)(op_1, closed [1].it_r);
}

	/* CONF_OVERRIDE process */
void _A501_425_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1126_9187)(open [1].it_r, closed [1].it_r);
}

	/* CONF_OVERRIDE process */
void __A501_425_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1126_9187)(op_1, closed [1].it_r);
}

	/* CONF_OVERRIDE is_enabled */
EIF_BOOLEAN _A501_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F387_4812)(open [1].it_r, closed [1].it_r);
}

	/* CONF_OVERRIDE is_enabled */
EIF_BOOLEAN __A501_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F387_4812)(op_1, closed [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_action */
EIF_REFERENCE _A604_113_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_action */
EIF_REFERENCE __A604_113_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_padded_action */
EIF_REFERENCE _A604_114_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_padded_action */
EIF_REFERENCE __A604_114_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER month_action */
EIF_REFERENCE _A604_120_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_action */
EIF_REFERENCE __A604_120_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_name_action */
EIF_REFERENCE _A604_116_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_name_action */
EIF_REFERENCE __A604_116_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_sunday_as_first_action */
EIF_REFERENCE _A604_126_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_sunday_as_first_action */
EIF_REFERENCE __A604_126_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_4_action */
EIF_REFERENCE _A604_132_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_4_action */
EIF_REFERENCE __A604_132_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_day_name_action */
EIF_REFERENCE _A604_115_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_day_name_action */
EIF_REFERENCE __A604_115_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_year_action */
EIF_REFERENCE _A604_117_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_year_action */
EIF_REFERENCE __A604_117_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_action */
EIF_REFERENCE _A604_118_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_action */
EIF_REFERENCE __A604_118_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_0_action */
EIF_REFERENCE _A604_119_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_0_action */
EIF_REFERENCE __A604_119_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER month_padded_action */
EIF_REFERENCE _A604_121_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_padded_action */
EIF_REFERENCE __A604_121_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_month_name_action */
EIF_REFERENCE _A604_122_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_month_name_action */
EIF_REFERENCE __A604_122_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_name_action */
EIF_REFERENCE _A604_123_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_name_action */
EIF_REFERENCE __A604_123_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER century_number_action */
EIF_REFERENCE _A604_124_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER century_number_action */
EIF_REFERENCE __A604_124_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_with_century_action */
EIF_REFERENCE _A604_128_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_with_century_action */
EIF_REFERENCE __A604_128_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_without_century_action */
EIF_REFERENCE _A604_129_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_without_century_action */
EIF_REFERENCE __A604_129_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER week_number_iso_action */
EIF_REFERENCE _A604_125_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_iso_action */
EIF_REFERENCE __A604_125_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER week_number_monday_as_first_action */
EIF_REFERENCE _A604_127_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_monday_as_first_action */
EIF_REFERENCE __A604_127_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_1_action */
EIF_REFERENCE _A604_130_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_1_action */
EIF_REFERENCE __A604_130_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_2_action */
EIF_REFERENCE _A604_131_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_2_action */
EIF_REFERENCE __A604_131_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_padded_action */
EIF_REFERENCE _A604_102_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_padded_action */
EIF_REFERENCE __A604_102_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_action */
EIF_REFERENCE _A604_103_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_action */
EIF_REFERENCE __A604_103_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_24_action */
EIF_REFERENCE _A604_104_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_24_action */
EIF_REFERENCE __A604_104_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER minutes_action */
EIF_REFERENCE _A604_106_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER minutes_action */
EIF_REFERENCE __A604_106_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER minutes_padded_action */
EIF_REFERENCE _A604_107_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER minutes_padded_action */
EIF_REFERENCE __A604_107_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER seconds_action */
EIF_REFERENCE _A604_108_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER seconds_action */
EIF_REFERENCE __A604_108_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER seconds_padded_action */
EIF_REFERENCE _A604_109_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER seconds_padded_action */
EIF_REFERENCE __A604_109_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_1_action */
EIF_REFERENCE _A604_110_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_1_action */
EIF_REFERENCE __A604_110_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_lowercase_action */
EIF_REFERENCE _A604_111_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_lowercase_action */
EIF_REFERENCE __A604_111_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_uppercase_action */
EIF_REFERENCE _A604_112_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_uppercase_action */
EIF_REFERENCE __A604_112_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EIFFEL_ENV safe_create_dir */
void _A627_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EIFFEL_ENV safe_create_dir */
void __A627_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN _A475_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F744_6139)(open [1].it_r);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN __A475_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F744_6139)(op_1);
}


#ifdef __cplusplus
}
#endif
