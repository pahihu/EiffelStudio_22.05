
#ifndef _C1_kl14_
#define _C1_kl14_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F14_181(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit14(void);

#ifdef __cplusplus
}
#endif

#endif
