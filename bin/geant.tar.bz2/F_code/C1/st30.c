/*
 * Code for class STD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st30.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STD_FILES}.input */
static EIF_REFERENCE F51_581_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (581);
#define Result RTOSR(581)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1011, 0x01).id, 1011, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdin",5,1953620846);
	F1012_6803(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (581);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F51_581 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(581,F51_581_body,(Current));
}

/* {STD_FILES}.output */
static EIF_REFERENCE F51_582_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (582);
#define Result RTOSR(582)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1011, 0x01).id, 1011, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdout",6,1912016244);
	F1012_6804(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (582);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F51_582 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(582,F51_582_body,(Current));
}

/* {STD_FILES}.error */
static EIF_REFERENCE F51_583_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (583);
#define Result RTOSR(583)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1011, 0x01).id, 1011, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stderr",6,1911360114);
	F1012_6805(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (583);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F51_583 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(583,F51_583_body,(Current));
}

/* {STD_FILES}.set_output_default */
void F51_609 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(582,F51_582, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit30 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
