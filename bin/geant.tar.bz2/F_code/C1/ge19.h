
#ifndef _C1_ge19_
#define _C1_ge19_

#ifdef __cplusplus
extern "C" {
#endif

extern void F22_219(EIF_REFERENCE);
extern EIF_BOOLEAN F22_220(EIF_REFERENCE);
extern void F22_222(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit19(void);

#ifdef __cplusplus
}
#endif

#endif
