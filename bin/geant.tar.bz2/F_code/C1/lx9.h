
#ifndef _C1_lx9_
#define _C1_lx9_

#ifdef __cplusplus
extern "C" {
#endif

extern void F9_81(EIF_REFERENCE);
extern void F9_111(EIF_REFERENCE, EIF_BOOLEAN);
extern void F9_112(EIF_REFERENCE, EIF_INTEGER_32);
extern void F9_115(EIF_REFERENCE, EIF_BOOLEAN);
extern void F9_116(EIF_REFERENCE, EIF_BOOLEAN);
extern void F9_117(EIF_REFERENCE, EIF_BOOLEAN);
extern void F9_144(EIF_REFERENCE, EIF_REFERENCE);
extern void F9_145(EIF_REFERENCE, EIF_BOOLEAN);
extern void F9_146(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit9(void);
extern void F1211_8222(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1209_8141(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
