
#ifndef _C1_is28_
#define _C1_is28_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F37_465(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F37_470(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F37_472(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F37_480(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit28(void);

#ifdef __cplusplus
}
#endif

#endif
