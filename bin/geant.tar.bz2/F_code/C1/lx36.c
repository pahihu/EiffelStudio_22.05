/*
 * Code for class LX_EQUIVALENCE_CLASSES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx36.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_EQUIVALENCE_CLASSES}.make */
void F57_819 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,139,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 139, _OBJSIZ_2_0_0_1_0_0_0_0_);
	}
	F132_1565(RTCW(loc1), arg1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,737,0xFF01,139,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F738_4058(RTCW(tr1), loc1, arg1, arg2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > arg2)) break;
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,139,873,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 139, _OBJSIZ_2_0_0_1_0_0_0_0_);
		}
		F132_1565(RTCW(loc1), loc2);
		tr1 = *(EIF_REFERENCE *)(Current);
		F738_4082(RTCW(tr1), loc1, loc2);
		loc2++;
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R826[Dtype(Current)-56])(Current);
	RTLE;
}

/* {LX_EQUIVALENCE_CLASSES}.initialize */
void F57_820 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLIU(3);
	
	RTGC;
	loc2 = F57_826(Current);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = F57_825(Current);
	tr1 = F738_4063(RTCW(tr1), ti4_1);
	ti4_1 = F57_825(Current);
	F132_1564(RTCW(tr1), ti4_1);
	loc1 = F57_825(Current);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc3 = F738_4063(RTCW(tr1), loc1);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F738_4063(RTCW(tr1), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
		F140_1575(RTCW(loc3), tr1);
		F132_1564(RTCW(loc3), loc1);
		loc1++;
	}
	ti4_1 = F57_827(Current);
	*(EIF_INTEGER_32 *)(Current + O834[Dtype(Current)-56]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {LX_EQUIVALENCE_CLASSES}.equivalence_class */
EIF_INTEGER_32 F57_821 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F738_4063(RTCW(tr1), arg1);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
	RTLE;
	return Result;
}

/* {LX_EQUIVALENCE_CLASSES}.previous_symbol */
EIF_INTEGER_32 F57_822 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTCT0("not_representative", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F738_4063(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_0_0_0_);
	RTLE;
	return Result;
}

/* {LX_EQUIVALENCE_CLASSES}.capacity */
EIF_INTEGER_32 F57_824 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F738_4070(RTCW(tr1));
	RTLE;
	return Result;
}

/* {LX_EQUIVALENCE_CLASSES}.lower */
EIF_INTEGER_32 F57_825 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
	RTLE;
	return Result;
}

/* {LX_EQUIVALENCE_CLASSES}.upper */
EIF_INTEGER_32 F57_826 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
	RTLE;
	return Result;
}

/* {LX_EQUIVALENCE_CLASSES}.new_lower */
EIF_INTEGER_32 F57_827 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F57_825(Current);
}

/* {LX_EQUIVALENCE_CLASSES}.is_representative */
EIF_BOOLEAN F57_829 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F738_4063(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
	RTLE;
	return Result;
}

/* {LX_EQUIVALENCE_CLASSES}.built */
EIF_BOOLEAN F57_832 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O834[Dtype(Current)-56]);
	ti4_2 = F57_827(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 >= ti4_2);
	RTLE;
	return Result;
}

/* {LX_EQUIVALENCE_CLASSES}.build */
void F57_833 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLIU(4);
	
	RTGC;
	loc3 = F57_826(Current);
	loc1 = F57_825(Current);
	loc2 = F57_825(Current);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc3)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc4 = F738_4063(RTCW(tr1), loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			F132_1564(RTCW(loc4), loc2);
			loc5 = *(EIF_REFERENCE *)(RTCW(loc4));
			for (;;) {
				if ((EIF_BOOLEAN)(loc5 == NULL)) break;
				F132_1564(RTCW(loc5), loc2);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc5));
				loc5 = (EIF_REFERENCE) tr1;
			}
			loc2++;
		}
		loc1++;
	}
	*(EIF_INTEGER_32 *)(Current + O834[Dtype(Current)-56]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {LX_EQUIVALENCE_CLASSES}.put */
void F57_834 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = F738_4063(RTCW(tr1), arg1);
	loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	loc3 = *(EIF_REFERENCE *)(RTCW(loc1));
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != NULL) && (EIF_BOOLEAN)(loc3 != NULL))) {
		F140_1574(RTCW(loc2), loc3);
		F138_1572(RTCW(loc1));
		F140_1576(RTCW(loc1));
	} else {
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			F140_1576(RTCW(loc3));
			F138_1572(RTCW(loc1));
		} else {
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				F138_1572(RTCW(loc2));
				F140_1576(RTCW(loc1));
			}
		}
	}
	RTLE;
}

/* {LX_EQUIVALENCE_CLASSES}.add */
void F57_835 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,loc12);
	RTLR(2,Current);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
	if ((EIF_BOOLEAN) !tb1) {
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_2_0_0_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_2_0_1_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1221,873,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc12 = RTLNS(typres0.id, 1221, _OBJSIZ_7_0_0_9_0_0_0_0_);
		}
		ti4_1 = eif_min_int32 ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - loc1) + ((EIF_INTEGER_32) 1L)),((EIF_INTEGER_32) 512L));
		F1214_8231(RTCW(loc12), ti4_1);
		loc10 = (EIF_INTEGER_32) loc1;
		for (;;) {
			if ((EIF_BOOLEAN) (loc10 > loc2)) break;
			tb1 = '\0';
			tb2 = F832_4477(RTCW(arg1), loc10);
			if (tb2) {
				tb2 = F1218_8327(RTCW(loc12), loc10);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current);
				loc3 = F738_4063(RTCW(tr1), loc10);
				loc5 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
				loc6 = (EIF_REFERENCE) loc3;
				loc11 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc10 + ((EIF_INTEGER_32) 1L));
				loc4 = *(EIF_REFERENCE *)(RTCW(loc3));
				for (;;) {
					if ((EIF_BOOLEAN)(loc4 == NULL)) break;
					loc7 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_2_0_0_0_);
					loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					for (;;) {
						if ((EIF_BOOLEAN) (loc8 || (EIF_BOOLEAN) (loc11 > loc2))) break;
						tb1 = F832_4477(RTCW(arg1), loc11);
						if ((EIF_BOOLEAN) !tb1) {
							loc11++;
						} else {
							if ((EIF_BOOLEAN) (loc11 > loc7)) {
								loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								tb1 = '\0';
								if ((EIF_BOOLEAN)(loc11 == loc7)) {
									tb2 = F1218_8327(RTCW(loc12), loc11);
									tb1 = (EIF_BOOLEAN) !tb2;
								}
								if (tb1) {
									F140_1574(RTCW(loc6), loc4);
									loc6 = (EIF_REFERENCE) loc4;
									F1218_8336(RTCW(loc12), loc11);
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									loc11++;
								}
							}
						}
					}
					if ((EIF_BOOLEAN) !loc9) {
						if ((EIF_BOOLEAN)(loc5 == NULL)) {
							F140_1576(RTCW(loc4));
						} else {
							F140_1574(RTCW(loc5), loc4);
						}
						loc5 = (EIF_REFERENCE) loc4;
					} else {
						loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
					tr1 = *(EIF_REFERENCE *)(RTCW(loc4));
					loc4 = (EIF_REFERENCE) tr1;
				}
				tb1 = '\01';
				tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
				if (!(EIF_BOOLEAN)(tr1 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
					tb1 = (EIF_BOOLEAN)(loc5 != tr1);
				}
				if (tb1) {
					F140_1576(RTCW(loc3));
					if ((EIF_BOOLEAN)(loc5 != NULL)) {
						F138_1572(RTCW(loc5));
					}
				}
				F138_1572(RTCW(loc6));
				loc10++;
			} else {
				loc10++;
			}
		}
	}
	RTLE;
}

/* {LX_EQUIVALENCE_CLASSES}.to_array */
EIF_REFERENCE F57_837 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,739,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 739, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F740_4058(RTCW(Result), ((EIF_INTEGER_32) 0L), arg1, arg2);
	ti4_1 = F57_826(Current);
	loc2 = eif_min_int32 (ti4_1,arg2);
	ti4_1 = F57_825(Current);
	loc1 = eif_max_int32 (ti4_1,arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F738_4063(RTCW(tr1), loc1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_0_0_0_);
		F740_4082(RTCW(Result), ti4_1, loc1);
		loc1++;
	}
	RTLE;
	return Result;
}

void EIF_Minit36 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
