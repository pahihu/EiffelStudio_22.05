/*
 * Code for class RX_CHARACTER_SET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rx8.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RX_CHARACTER_SET}.make_empty */
void F8_62 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {RX_CHARACTER_SET}.make */
void F8_63 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F8_62(Current);
	F8_69(Current, arg1);
	RTLE;
}

/* {RX_CHARACTER_SET}.has */
EIF_BOOLEAN F8_66 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_64 tu8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		Result = '\0';
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_)) {
			tr1 = RTLNS(eif_new_type(1295, 0x01).id, 1295, _OBJSIZ_0_0_0_0_0_0_0_0_);
			Result = F1296_9295(RTCW(tr1), arg1);
		}
	} else {
		if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L))) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_);
			tr1 = RTOSCF(80,F8_80, (Current));
			ti4_1 = (EIF_INTEGER_32) arg1;
			/* INLINED CODE (SPECIAL.item) */
			tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
			/* END INLINED CODE */
			tu8_2 = tu8_3;
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
		} else {
			if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L))) {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_);
				tr1 = RTOSCF(80,F8_80, (Current));
				ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
				/* INLINED CODE (SPECIAL.item) */
				tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
				/* END INLINED CODE */
				tu8_2 = tu8_3;
				tu8_1 = eif_bit_and(tu8_1,tu8_2);
				Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
			} else {
				if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 192L))) {
					tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_);
					tr1 = RTOSCF(80,F8_80, (Current));
					ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
					/* INLINED CODE (SPECIAL.item) */
					tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
					/* END INLINED CODE */
					tu8_2 = tu8_3;
					tu8_1 = eif_bit_and(tu8_1,tu8_2);
					Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
				} else {
					if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 256L))) {
						tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_);
						tr1 = RTOSCF(80,F8_80, (Current));
						ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
						/* INLINED CODE (SPECIAL.item) */
						tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
						/* END INLINED CODE */
						tu8_2 = tu8_3;
						tu8_1 = eif_bit_and(tu8_1,tu8_2);
						Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
					} else {
						loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) (arg1 / (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L));
						tb1 = '\0';
						tr1 = *(EIF_REFERENCE *)(Current);
						loc2 = tr1;
						if (EIF_TEST(loc2)) {
							tb2 = F1226_8402(loc2, loc1);
							tb1 = tb2;
						}
						if (tb1) {
							tu8_1 = F1226_8394(loc2, loc1);
							tr1 = RTOSCF(80,F8_80, (Current));
							ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
							/* INLINED CODE (SPECIAL.item) */
							tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
							/* END INLINED CODE */
							tu8_2 = tu8_3;
							tu8_1 = eif_bit_and(tu8_1,tu8_2);
							Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
						} else {
							Result = '\0';
							if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) != *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_))) {
								tr1 = RTLNS(eif_new_type(1295, 0x01).id, 1295, _OBJSIZ_0_0_0_0_0_0_0_0_);
								Result = F1296_9295(RTCW(tr1), arg1);
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {RX_CHARACTER_SET}.set_negated */
void F8_68 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) arg1;
}

/* {RX_CHARACTER_SET}.add_string */
void F8_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4575[Dtype(RTCW(arg1))-946])(arg1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4538[Dtype(RTCW(arg1))-946])(arg1, loc1);
		F8_70(Current, tu4_1);
		loc1++;
	}
	RTLE;
}

/* {RX_CHARACTER_SET}.add_character */
void F8_70 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_64 tu8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L))) {
		tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_);
		tr1 = RTOSCF(80,F8_80, (Current));
		ti4_1 = (EIF_INTEGER_32) arg1;
		/* INLINED CODE (SPECIAL.item) */
		tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
		/* END INLINED CODE */
		tu8_2 = tu8_3;
		tu8_1 = eif_bit_or(tu8_1,tu8_2);
		*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_) = (EIF_NATURAL_64) tu8_1;
	} else {
		if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L))) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_);
			tr1 = RTOSCF(80,F8_80, (Current));
			ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
			/* INLINED CODE (SPECIAL.item) */
			tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
			/* END INLINED CODE */
			tu8_2 = tu8_3;
			tu8_1 = eif_bit_or(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_) = (EIF_NATURAL_64) tu8_1;
		} else {
			if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 192L))) {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_);
				tr1 = RTOSCF(80,F8_80, (Current));
				ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
				/* INLINED CODE (SPECIAL.item) */
				tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
				/* END INLINED CODE */
				tu8_2 = tu8_3;
				tu8_1 = eif_bit_or(tu8_1,tu8_2);
				*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_) = (EIF_NATURAL_64) tu8_1;
			} else {
				if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 256L))) {
					tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_);
					tr1 = RTOSCF(80,F8_80, (Current));
					ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
					/* INLINED CODE (SPECIAL.item) */
					tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
					/* END INLINED CODE */
					tu8_2 = tu8_3;
					tu8_1 = eif_bit_or(tu8_1,tu8_2);
					*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_) = (EIF_NATURAL_64) tu8_1;
				} else {
					loc2 = (EIF_NATURAL_32) (EIF_NATURAL_32) (arg1 / (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L));
					loc1 = *(EIF_REFERENCE *)(Current);
					if ((EIF_BOOLEAN)(loc1 == NULL)) {
						if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_)) {
							{
								static EIF_TYPE_INDEX typarr0[] = {1235,879,882,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
								loc1 = RTLNSMART(typres0.id);
							}
							F1226_8389(RTCW(loc1), ((EIF_INTEGER_32) 50L));
							RTAR(Current, loc1);
							*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
						}
					} else {
						tb1 = '\0';
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_)) {
							tb2 = F1226_8402(RTCW(loc1), loc2);
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) {
							loc1 = (EIF_REFERENCE) NULL;
						}
					}
					if ((EIF_BOOLEAN)(loc1 != NULL)) {
						tu8_1 = F1226_8395(RTCW(loc1), loc2);
						tr1 = RTOSCF(80,F8_80, (Current));
						ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
						/* INLINED CODE (SPECIAL.item) */
						tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
						/* END INLINED CODE */
						tu8_2 = tu8_3;
						tu8_1 = eif_bit_or(tu8_1,tu8_2);
						F1226_8414(RTCW(loc1), tu8_1, loc2);
					}
				}
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {RX_CHARACTER_SET}.add_set */
void F8_71 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTGC;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_0_);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_1_);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_2_);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_3_);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_) = (EIF_NATURAL_64) tu8_1;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tb2 = F1129_7674(loc4);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc2 = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_);
		loc3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_2_);
		loc1 = *(EIF_REFERENCE *)(Current);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			if ((EIF_BOOLEAN) !loc2) {
				tr1 = F1_14(loc4);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) loc3;
			}
		} else {
			tb1 = F1129_7674(RTCW(loc1));
			if (tb1) {
				if ((EIF_BOOLEAN) !loc2) {
					F1226_8418(RTCW(loc1), loc4);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) loc3;
				}
			} else {
				if (loc3) {
					F1156_7734(RTCW(loc1));
					for (;;) {
						tb1 = F1156_7731(RTCW(loc1));
						if (tb1) break;
						tu4_1 = F1226_8398(RTCW(loc1));
						tb2 = F1226_8402(loc4, tu4_1);
						if ((EIF_BOOLEAN) !tb2) {
							tu4_1 = F1226_8398(RTCW(loc1));
							F1216_8252(RTCW(loc1), tu4_1);
						} else {
							F1156_7735(RTCW(loc1));
						}
					}
				}
				loc5 = F1156_7729(loc4);
				for (;;) {
					tb2 = F1081_7423(loc5);
					if (tb2) break;
					tu4_1 = F1091_7442(loc5);
					F1226_8405(RTCW(loc1), tu4_1);
					tb3 = F1216_8240(RTCW(loc1));
					if (tb3) {
						tu8_1 = F1216_8232(RTCW(loc1));
						tu8_2 = F1043_7375(loc5);
						tu8_1 = eif_bit_or(tu8_1,tu8_2);
						F1226_8409(RTCW(loc1), tu8_1);
					} else {
						if ((EIF_BOOLEAN) !loc2) {
							tu8_1 = F1043_7375(loc5);
							tu4_1 = F1091_7442(loc5);
							F1226_8415(RTCW(loc1), tu8_1, tu4_1);
						}
					}
					F1058_7396(loc5);
				}
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || loc3);
			}
		}
	} else {
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_2_);
		if (tb3) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = *(EIF_REFERENCE *)(Current);
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				F1216_8254(loc6);
			}
		}
	}
	tb3 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		tb4 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
		tb3 = tb4;
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) tb3;
	RTLE;
}

/* {RX_CHARACTER_SET}.add_negated_set */
void F8_72 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,loc8);
	RTLIU(9);
	
	RTGC;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_0_);
	tu8_2 = eif_bit_not(tu8_2);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_1_);
	tu8_2 = eif_bit_not(tu8_2);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_2_);
	tu8_2 = eif_bit_not(tu8_2);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_3_);
	tu8_2 = eif_bit_not(tu8_2);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_) = (EIF_NATURAL_64) tu8_1;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tb2 = F1129_7674(loc4);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc2 = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_);
		loc3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_2_);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc3;
		loc1 = *(EIF_REFERENCE *)(Current);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			if ((EIF_BOOLEAN) !loc2) {
				loc1 = F1_14(loc4);
				F1156_7734(RTCW(loc1));
				for (;;) {
					tb1 = F1156_7731(RTCW(loc1));
					if (tb1) break;
					tu8_1 = F1143_7705(RTCW(loc1));
					tu8_1 = eif_bit_not(tu8_1);
					tu4_1 = F1226_8398(RTCW(loc1));
					F1226_8408(RTCW(loc1), tu8_1, tu4_1);
					F1156_7735(RTCW(loc1));
				}
				RTAR(Current, loc1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) loc3;
			}
		} else {
			tb2 = F1129_7674(RTCW(loc1));
			if (tb2) {
				if ((EIF_BOOLEAN) !loc2) {
					F1226_8418(RTCW(loc1), loc4);
					F1156_7734(RTCW(loc1));
					for (;;) {
						tb2 = F1156_7731(RTCW(loc1));
						if (tb2) break;
						tu8_1 = F1143_7705(RTCW(loc1));
						tu8_1 = eif_bit_not(tu8_1);
						tu4_1 = F1226_8398(RTCW(loc1));
						F1226_8408(RTCW(loc1), tu8_1, tu4_1);
						F1156_7735(RTCW(loc1));
					}
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) loc3;
				}
			} else {
				if (loc3) {
					F1156_7734(RTCW(loc1));
					for (;;) {
						tb3 = F1156_7731(RTCW(loc1));
						if (tb3) break;
						tu4_1 = F1226_8398(RTCW(loc1));
						tb4 = F1226_8402(loc4, tu4_1);
						if ((EIF_BOOLEAN) !tb4) {
							tu4_1 = F1226_8398(RTCW(loc1));
							F1216_8252(RTCW(loc1), tu4_1);
						} else {
							F1156_7735(RTCW(loc1));
						}
					}
				}
				loc5 = F1156_7729(loc4);
				for (;;) {
					tb4 = F1081_7423(loc5);
					if (tb4) break;
					tu4_1 = F1091_7442(loc5);
					F1226_8405(RTCW(loc1), tu4_1);
					tb5 = F1216_8240(RTCW(loc1));
					if (tb5) {
						tu8_1 = F1216_8232(RTCW(loc1));
						tu8_2 = F1043_7375(loc5);
						tu8_2 = eif_bit_not(tu8_2);
						tu8_1 = eif_bit_or(tu8_1,tu8_2);
						F1226_8409(RTCW(loc1), tu8_1);
					} else {
						if ((EIF_BOOLEAN) !loc2) {
							tu8_1 = F1043_7375(loc5);
							tu8_1 = eif_bit_not(tu8_1);
							tu4_1 = F1091_7442(loc5);
							F1226_8415(RTCW(loc1), tu8_1, tu4_1);
						}
					}
					F1058_7396(loc5);
				}
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || loc3);
			}
		}
	} else {
		tb5 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_2_);
		if ((EIF_BOOLEAN) !tb5) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = *(EIF_REFERENCE *)(Current);
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				F1216_8254(loc6);
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_) != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_) != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L))) || (EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_) != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L))) || (EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_) != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)))) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			tb5 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				tb6 = F1129_7674(loc7);
				tb5 = (EIF_BOOLEAN) !tb6;
			}
			if (tb5) {
				tb5 = '\01';
				if (!(EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_)) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_11_0_0_8_);
					tb5 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 17372L));
				}
				if (tb5) {
					loc8 = F1156_7729(loc7);
					tb5 = EIF_TRUE;
					for (;;) {
						if (!tb5) break;
						tb6 = F1081_7423(loc8);
						if (tb6) break;
						tu8_1 = F1043_7375(loc8);
						tb5 = (EIF_BOOLEAN)(tu8_1 == (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
						F1058_7396(loc8);
					}
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) tb5;
				} else {
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_);
			}
		}
	}
	RTLE;
}

/* {RX_CHARACTER_SET}.masks */
static EIF_REFERENCE F8_80_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 loc2 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (80);
#define Result RTOSR(80)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,715,879,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 64L),sizeof(EIF_NATURAL_64), EIF_TRUE);
	}
	F716_3970(RTCW(tr1), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 64L));
	Result = (EIF_REFERENCE) tr1;
	loc2 = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_INTEGER_32) 1L);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_64 *)RTCW(Result) + (((EIF_INTEGER_32) 0L))) = loc2;
	/* END INLINED CODE */
	;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 64L))) break;
		tu8_1 = eif_bit_shift_left(loc2,((EIF_INTEGER_32) 1L));
		loc2 = (EIF_NATURAL_64) tu8_1;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_64 *)RTCW(Result) + (loc1)) = loc2;
		/* END INLINED CODE */
		;
		loc1++;
	}
	RTOSE (80);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F8_80 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(80,F8_80_body,(Current));
}

void EIF_Minit8 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
