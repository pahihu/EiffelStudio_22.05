/*
 * Code for class RX_PCRE_BYTE_CODE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rx35.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RX_PCRE_BYTE_CODE_CONSTANTS}.op_name */
EIF_REFERENCE F56_818 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	switch (arg1) {
		case 0U:
			Result = RTMS_EX_H("End",3,4550244);
			break;
		case 1U:
			Result = RTMS_EX_H("\\A",2,23617);
			break;
		case 2U:
			Result = RTMS_EX_H("\\B",2,23618);
			break;
		case 3U:
			Result = RTMS_EX_H("\\b",2,23650);
			break;
		case 4U:
			Result = RTMS_EX_H("\\D",2,23620);
			break;
		case 5U:
			Result = RTMS_EX_H("\\d",2,23652);
			break;
		case 6U:
			Result = RTMS_EX_H("\\S",2,23635);
			break;
		case 7U:
			Result = RTMS_EX_H("\\s",2,23667);
			break;
		case 8U:
			Result = RTMS_EX_H("\\W",2,23639);
			break;
		case 9U:
			Result = RTMS_EX_H("\\w",2,23671);
			break;
		case 10U:
			Result = RTMS_EX_H("\\Z",2,23642);
			break;
		case 11U:
			Result = RTMS_EX_H("\\z",2,23674);
			break;
		case 12U:
			Result = RTMS_EX_H("Opt",3,5206132);
			break;
		case 13U:
			Result = RTMS_EX_H("^",1,94);
			break;
		case 14U:
			Result = RTMS_EX_H("$",1,36);
			break;
		case 15U:
			Result = RTMS_EX_H("Any",3,4288121);
			break;
		case 16U:
			Result = RTMS_EX_H("chars",5,1751977075);
			break;
		case 17U:
			Result = RTMS_EX_H("not",3,7237492);
			break;
		case 18U:
		case 27U:
		case 36U:
		case 45U:
			Result = RTMS_EX_H("*",1,42);
			break;
		case 19U:
		case 28U:
		case 37U:
		case 46U:
			Result = RTMS_EX_H("*\?",2,10815);
			break;
		case 20U:
		case 29U:
		case 38U:
		case 47U:
			Result = RTMS_EX_H("+",1,43);
			break;
		case 21U:
		case 30U:
		case 39U:
		case 48U:
			Result = RTMS_EX_H("+\?",2,11071);
			break;
		case 22U:
		case 31U:
		case 40U:
		case 49U:
			Result = RTMS_EX_H("\?",1,63);
			break;
		case 23U:
		case 32U:
		case 41U:
		case 50U:
			Result = RTMS_EX_H("\?\?",2,16191);
			break;
		case 24U:
		case 25U:
		case 26U:
		case 33U:
		case 34U:
		case 35U:
		case 42U:
		case 43U:
		case 44U:
		case 51U:
		case 52U:
			Result = RTMS_EX_H("{",1,123);
			break;
		case 53U:
			Result = RTMS_EX_H("class",5,1819086195);
			break;
		case 54U:
			Result = RTMS_EX_H("Ref",3,5399910);
			break;
		case 55U:
			Result = RTMS_EX_H("Recurse",7,492124517);
			break;
		case 56U:
			Result = RTMS_EX_H("Alt",3,4287604);
			break;
		case 57U:
			Result = RTMS_EX_H("Ket",3,4941172);
			break;
		case 58U:
			Result = RTMS_EX_H("KetRmax",7,676464504);
			break;
		case 59U:
			Result = RTMS_EX_H("KetRmin",7,676466542);
			break;
		case 60U:
			Result = RTMS_EX_H("Assert",6,2064706676);
			break;
		case 61U:
			Result = RTMS_EX_H("Assert not",10,500477812);
			break;
		case 62U:
			Result = RTMS_EX_H("AssertB",7,284876354);
			break;
		case 63U:
			Result = RTMS_EX_H("AssertB not",11,112582772);
			break;
		case 64U:
			Result = RTMS_EX_H("Reverse",7,223834981);
			break;
		case 65U:
			Result = RTMS_EX_H("Once",4,1332634469);
			break;
		case 66U:
			Result = RTMS_EX_H("Cond",4,1131376228);
			break;
		case 67U:
			Result = RTMS_EX_H("Cref",4,1131570534);
			break;
		case 68U:
			Result = RTMS_EX_H("Brazero",7,1137557615);
			break;
		case 69U:
			Result = RTMS_EX_H("Braminzero",10,1727675759);
			break;
		case 70U:
			Result = RTMS_EX_H("Bra",3,4354657);
			break;
		default:
			if ((EIF_BOOLEAN) (arg1 > ((EIF_NATURAL_32) 70U))) {
				tr1 = RTMS_EX_H("Bra",3,4354657);
				tr2 = eif_out__u4_s1((EIF_NATURAL_32) (arg1 - ((EIF_NATURAL_32) 70U)));
				Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4764[Dtype(tr1)-950])(tr1, tr2);
			} else {
				Result = RTMS_EX_H("unknown opcode",14,242085221);
			}
			break;
	}
	RTLE;
	return Result;
}

void EIF_Minit35 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
