
#ifndef _C1_xm23_
#define _C1_xm23_

#ifdef __cplusplus
extern "C" {
#endif

extern void F32_377(EIF_REFERENCE);
extern EIF_BOOLEAN F32_378(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F32_379(EIF_REFERENCE, EIF_REFERENCE);
extern void F32_380(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit23(void);
extern EIF_REFERENCE F1108_7483(EIF_REFERENCE);
extern void F1185_7905(EIF_REFERENCE);
extern void F1053_7396(EIF_REFERENCE);
extern void F1053_7398(EIF_REFERENCE);
extern void F134_1566(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1053_7395(EIF_REFERENCE);
extern char *(*R6020[])();
extern char *(*R5961[])();

#ifdef __cplusplus
}
#endif

#endif
