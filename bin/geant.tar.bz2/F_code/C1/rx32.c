/*
 * Code for class RX_PCRE_SHARED_CHARACTER_SETS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rx32.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RX_PCRE_SHARED_CHARACTER_SETS}.default_character_case_mapping */
static EIF_REFERENCE F53_670_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (670);
#define Result RTOSR(670)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1256, 0x01).id, 1256, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,680947802);
	tr3 = RTMS_EX_H("abcdefghijklmnopqrstuvwxyz",26,1741663354);
	F1257_8659(RTCW(tr1), tr2, tr3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (670);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_670 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(670,F53_670_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.default_word_set */
static EIF_REFERENCE F53_671_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (671);
#define Result RTOSR(671)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	tr2 = RTMS_EX_H("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_",63,1064094303);
	F8_63(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (671);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_671 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(671,F53_671_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.upper_set */
static EIF_REFERENCE F53_672_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (672);
#define Result RTOSR(672)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	tr2 = RTMS_EX_H("ABCDEFGHIJKLMNOPQRSTUVWXYZ",26,680947802);
	F8_63(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (672);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_672 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(672,F53_672_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.lower_set */
static EIF_REFERENCE F53_673_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (673);
#define Result RTOSR(673)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	tr2 = RTMS_EX_H("abcdefghijklmnopqrstuvwxyz",26,1741663354);
	F8_63(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (673);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_673 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(673,F53_673_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.alpha_set */
static EIF_REFERENCE F53_674_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (674);
#define Result RTOSR(674)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	F8_62(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(673,F53_673, (Current));
	F8_71(RTCW(Result), tr1);
	tr1 = RTOSCF(672,F53_672, (Current));
	F8_71(RTCW(Result), tr1);
	RTOSE (674);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_674 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(674,F53_674_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.digit_set */
static EIF_REFERENCE F53_675_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (675);
#define Result RTOSR(675)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	tr2 = RTMS_EX_H("0123456789",10,593348409);
	F8_63(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (675);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_675 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(675,F53_675_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.alnum_set */
static EIF_REFERENCE F53_676_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (676);
#define Result RTOSR(676)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	F8_62(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(674,F53_674, (Current));
	F8_71(RTCW(Result), tr1);
	tr1 = RTOSCF(675,F53_675, (Current));
	F8_71(RTCW(Result), tr1);
	RTOSE (676);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_676 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(676,F53_676_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.xdigit_set */
static EIF_REFERENCE F53_677_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (677);
#define Result RTOSR(677)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	tr2 = RTMS_EX_H("0123456789abcdefABCDEF",22,1983803462);
	F8_63(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (677);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_677 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(677,F53_677_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.cntrl_set */
static EIF_REFERENCE F53_678_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (678);
#define Result RTOSR(678)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	F8_62(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 31L))) break;
		F8_70(RTCW(Result), loc1);
		loc1 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	}
	F8_70(RTCW(Result), (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L));
	RTOSE (678);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_678 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(678,F53_678_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.graph_set */
static EIF_REFERENCE F53_679_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (679);
#define Result RTOSR(679)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	tr2 = RTMS_EX_H("!\"#$%&\'()*+,-./0123456789:;<=>\?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",94,554150526);
	F8_63(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (679);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_679 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(679,F53_679_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.print_set */
static EIF_REFERENCE F53_680_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (680);
#define Result RTOSR(680)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	tr2 = RTMS_EX_H(" !\"#$%&\'()*+,-./0123456789:;<=>\?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",95,1652388478);
	F8_63(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (680);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_680 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(680,F53_680_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.punct_set */
static EIF_REFERENCE F53_681_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (681);
#define Result RTOSR(681)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	tr2 = RTMS_EX_H("!\"#$%&\'()*+,-./:;<=>\?@[\\]^_`{|}~",32,391924606);
	F8_63(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (681);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_681 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(681,F53_681_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.ascii_set */
static EIF_REFERENCE F53_682_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (682);
#define Result RTOSR(682)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	F8_62(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) break;
		F8_70(RTCW(Result), loc1);
		loc1 += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	}
	RTOSE (682);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_682 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(682,F53_682_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.space_set */
static EIF_REFERENCE F53_683_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (683);
#define Result RTOSR(683)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	tr2 = RTMS_EX_H("\011\012\014\015\013 ",6,219952928);
	F8_63(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (683);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_683 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(683,F53_683_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.meta_set */
static EIF_REFERENCE F53_684_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (684);
#define Result RTOSR(684)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_1_3_0_0_0_0_4_0_);
	tr2 = RTMS_EX_H("*+\?{^.$|()[",11,572368475);
	F8_63(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (684);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_684 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(684,F53_684_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.class_names */
static EIF_REFERENCE F53_685_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (685);
#define Result RTOSR(685)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 13L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 13L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS_EX_H("alpha",5,1820051041);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("lower",5,1870925170);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("upper",5,1887312754);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("alnum",5,1819923309);
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("ascii",5,1936639849);
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("cntrl",5,1853885548);
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("digit",5,1769152884);
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("graph",5,1919779432);
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("print",5,1920372340);
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("punct",5,1971028852);
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("space",5,1886313829);
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("word",4,2003792484);
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("xdigit",6,2005082484);
	*((EIF_REFERENCE *)tr2+12) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (685);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_685 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(685,F53_685_body,(Current));
}

/* {RX_PCRE_SHARED_CHARACTER_SETS}.class_sets */
static EIF_REFERENCE F53_686_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (686);
#define Result RTOSR(686)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,7,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 13L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 13L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTOSCF(674,F53_674, (Current));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(673,F53_673, (Current));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(672,F53_672, (Current));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(676,F53_676, (Current));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(682,F53_682, (Current));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(678,F53_678, (Current));
	*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(675,F53_675, (Current));
	*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(679,F53_679, (Current));
	*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(680,F53_680, (Current));
	*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(681,F53_681, (Current));
	*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(683,F53_683, (Current));
	*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(671,F53_671, (Current));
	*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(677,F53_677, (Current));
	*((EIF_REFERENCE *)tr2+12) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (686);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F53_686 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(686,F53_686_body,(Current));
}

void EIF_Minit32 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
