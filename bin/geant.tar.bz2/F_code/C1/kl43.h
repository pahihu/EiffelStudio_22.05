
#ifndef _C1_kl43_
#define _C1_kl43_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,894)
static EIF_REFERENCE F64_894_body(EIF_REFERENCE);
extern EIF_REFERENCE F64_894(EIF_REFERENCE);
extern void EIF_Minit43(void);

#ifdef __cplusplus
}
#endif

#endif
