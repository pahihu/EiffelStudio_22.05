
#ifndef _C1_op29_
#define _C1_op29_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F50_578(EIF_REFERENCE);
extern void EIF_Minit29(void);

#ifdef __cplusplus
}
#endif

#endif
