
#ifndef _C1_lx5_
#define _C1_lx5_

#ifdef __cplusplus
extern "C" {
#endif

extern void F5_48(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN);
extern void F5_56(EIF_REFERENCE, EIF_REFERENCE);
extern void F5_57(EIF_REFERENCE, EIF_REFERENCE);
extern void F5_58(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit5(void);
extern void F1209_8165(EIF_REFERENCE, EIF_REFERENCE);
extern void F1209_8141(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
