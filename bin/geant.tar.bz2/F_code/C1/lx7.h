
#ifndef _C1_lx7_
#define _C1_lx7_

#ifdef __cplusplus
extern "C" {
#endif

extern void F7_60(EIF_REFERENCE);
extern void EIF_Minit7(void);

#ifdef __cplusplus
}
#endif

#endif
