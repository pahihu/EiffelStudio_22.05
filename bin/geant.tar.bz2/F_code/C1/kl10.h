
#ifndef _C1_kl10_
#define _C1_kl10_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F10_152(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit10(void);
extern EIF_BOOLEAN F747_4063(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
