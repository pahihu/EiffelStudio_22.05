/*
 * Code for class RX_PCRE_ERROR_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rx34.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_0 */

EIF_REFERENCE F55_714 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (714,RTMS_EX_H("compilation successfully",24,297046137));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_1 */

EIF_REFERENCE F55_715 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (715,RTMS_EX_H("\\ at end of pattern",19,1082148462));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_2 */

EIF_REFERENCE F55_716 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (716,RTMS_EX_H("\\c at end of pattern",20,586514030));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_3 */

EIF_REFERENCE F55_717 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (717,RTMS_EX_H("unrecognized character follows \\",32,1794949212));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_4 */

EIF_REFERENCE F55_718 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (718,RTMS_EX_H("numbers out of order in {} quantifier",37,1764177010));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_5 */

EIF_REFERENCE F55_719 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (719,RTMS_EX_H("number too big in {} quantifier",31,236715890));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_6 */

EIF_REFERENCE F55_720 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (720,RTMS_EX_H("missing terminating ] for character class",41,461852531));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_7 */

EIF_REFERENCE F55_721 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (721,RTMS_EX_H("invalid escape sequence in character class",42,267449459));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_8 */

EIF_REFERENCE F55_722 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (722,RTMS_EX_H("range out of order in character class",37,652901747));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_9 */

EIF_REFERENCE F55_723 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (723,RTMS_EX_H("nothing to repeat",17,825052276));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_11 */

EIF_REFERENCE F55_724 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (724,RTMS_EX_H("internal error: unexpected repeat",33,1855335540));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_12 */

EIF_REFERENCE F55_725 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (725,RTMS_EX_H("unrecognized character after (\?",31,636561471));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_13 */

EIF_REFERENCE F55_726 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (726,RTMS_EX_H("too many capturing parenthesized sub-patterns",45,1757158771));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_14 */

EIF_REFERENCE F55_727 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (727,RTMS_EX_H("missing )",9,1989432361));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_15 */

EIF_REFERENCE F55_728 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (728,RTMS_EX_H("back reference to non-existent subpattern",41,1930188142));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_18 */

EIF_REFERENCE F55_729 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (729,RTMS_EX_H("missing ) after comment",23,1848893300));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_22 */

EIF_REFERENCE F55_730 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (730,RTMS_EX_H("unmatched parentheses",21,366512243));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_24 */

EIF_REFERENCE F55_731 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (731,RTMS_EX_H("unrecognized character after (\?<",32,1898751036));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_25 */

EIF_REFERENCE F55_732 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (732,RTMS_EX_H("lookbehind assertion is not fixed length",40,831850344));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_26 */

EIF_REFERENCE F55_733 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (733,RTMS_EX_H("malformed number after (\?(",26,217491240));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_27 */

EIF_REFERENCE F55_734 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (734,RTMS_EX_H("conditional group contains more than two branches",49,572996467));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_28 */

EIF_REFERENCE F55_735 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (735,RTMS_EX_H("assertion expected after (\?(",28,1018686248));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_30 */

EIF_REFERENCE F55_736 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (736,RTMS_EX_H("unknown POSIX class name",24,1984937317));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_31 */

EIF_REFERENCE F55_737 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (737,RTMS_EX_H("POSIX collating elements are not supported",42,1477603940));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_35 */

EIF_REFERENCE F55_738 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (738,RTMS_EX_H("invalid condition (\?(0)",23,1170936617));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_61 */

EIF_REFERENCE F55_739 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (739,RTMS_EX_H("invalid or surrogate Unicode character",38,1608683122));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_62 */

EIF_REFERENCE F55_740 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (740,RTMS_EX_H("invalid control character ater \\c",33,1382078307));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_63 */

EIF_REFERENCE F55_741 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (741,RTMS_EX_H("missing } in \\x{...}",20,834800765));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_64 */

EIF_REFERENCE F55_742 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (742,RTMS_EX_H("missing } in \\u{...}",20,828902525));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_65 */

EIF_REFERENCE F55_743 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (743,RTMS_EX_H("decimal value too large",23,1239741797));
}

/* {RX_PCRE_ERROR_CONSTANTS}.err_msg_99 */

EIF_REFERENCE F55_744 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (744,RTMS_EX_H("no pattern compiled",19,1370646116));
}

void EIF_Minit34 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
