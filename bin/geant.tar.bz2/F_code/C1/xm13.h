
#ifndef _C1_xm13_
#define _C1_xm13_

#ifdef __cplusplus
extern "C" {
#endif

extern void F13_170(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 171)


extern EIF_REFERENCE F13_171(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 172)


extern EIF_REFERENCE F13_172(EIF_REFERENCE);
extern void F13_177(EIF_REFERENCE, EIF_REFERENCE);
extern void F13_178(EIF_REFERENCE, EIF_REFERENCE);
extern void F13_179(EIF_REFERENCE, EIF_BOOLEAN);
extern void F13_180(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit13(void);
extern char *(*R1969[])();

#ifdef __cplusplus
}
#endif

#endif
