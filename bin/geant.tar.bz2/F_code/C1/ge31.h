
#ifndef _C1_ge31_
#define _C1_ge31_

#ifdef __cplusplus
extern "C" {
#endif

extern void F52_661(EIF_REFERENCE);
extern void F52_666(EIF_REFERENCE, EIF_BOOLEAN);
extern void F52_667(EIF_REFERENCE, EIF_BOOLEAN);
extern void F52_668(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit31(void);

#ifdef __cplusplus
}
#endif

#endif
