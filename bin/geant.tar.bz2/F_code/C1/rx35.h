
#ifndef _C1_rx35_
#define _C1_rx35_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F56_818(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit35(void);
extern char *(*R4764[])();

#ifdef __cplusplus
}
#endif

#endif
