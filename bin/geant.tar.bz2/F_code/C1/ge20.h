
#ifndef _C1_ge20_
#define _C1_ge20_

#ifdef __cplusplus
extern "C" {
#endif

extern void F23_223(EIF_REFERENCE);
extern EIF_BOOLEAN F23_224(EIF_REFERENCE);
extern void F23_226(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit20(void);

#ifdef __cplusplus
}
#endif

#endif
