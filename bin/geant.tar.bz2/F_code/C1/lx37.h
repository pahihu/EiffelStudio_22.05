
#ifndef _C1_lx37_
#define _C1_lx37_

#ifdef __cplusplus
extern "C" {
#endif

extern void F58_839(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F58_840(EIF_REFERENCE);
extern void F58_843(EIF_REFERENCE, EIF_INTEGER_32);
extern void F58_844(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit37(void);
extern void F1214_8231(EIF_REFERENCE, EIF_INTEGER_32);
extern void F57_819(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1218_8336(EIF_REFERENCE, EIF_INTEGER_32);
extern void F57_834(EIF_REFERENCE, EIF_INTEGER_32);
extern void F57_820(EIF_REFERENCE);
extern void F57_835(EIF_REFERENCE, EIF_REFERENCE);
extern void F1214_8254(EIF_REFERENCE);
extern EIF_BOOLEAN F832_4476(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
