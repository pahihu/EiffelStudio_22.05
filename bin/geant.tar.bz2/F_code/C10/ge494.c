/*
 * Code for class GEANT_SHARED_PROPERTIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge494.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_SHARED_PROPERTIES}.commandline_variables */
static EIF_REFERENCE F1349_10199_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10199);
#define Result RTOSR(10199)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1237, 0x01).id, 1237, _OBJSIZ_11_0_0_9_0_0_0_0_);
	F1238_8470(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10199);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1349_10199 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10199,F1349_10199_body,(Current));
}

/* {GEANT_SHARED_PROPERTIES}.commandline_arguments */
static EIF_REFERENCE F1349_10200_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10200);
#define Result RTOSR(10200)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1238, 0x01).id, 1238, _OBJSIZ_11_0_0_9_0_0_0_0_);
	F1238_8470(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10200);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1349_10200 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10200,F1349_10200_body,(Current));
}

/* {GEANT_SHARED_PROPERTIES}.empty_variables */
static EIF_REFERENCE F1349_10201_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10201);
#define Result RTOSR(10201)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1237, 0x01).id, 1237, _OBJSIZ_11_0_0_9_0_0_0_0_);
	F1238_8470(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10201);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1349_10201 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10201,F1349_10201_body,(Current));
}

/* {GEANT_SHARED_PROPERTIES}.empty_argument_variables */
static EIF_REFERENCE F1349_10202_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10202);
#define Result RTOSR(10202)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1238, 0x01).id, 1238, _OBJSIZ_11_0_0_9_0_0_0_0_);
	F1238_8470(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10202);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1349_10202 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10202,F1349_10202_body,(Current));
}

/* {GEANT_SHARED_PROPERTIES}.default_builtin_variables */
static EIF_REFERENCE F1349_10203_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (10203);
#define Result RTOSR(10203)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1237, 0x01).id, 1237, _OBJSIZ_11_0_0_9_0_0_0_0_);
	F1238_8470(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tb1 = RTOSCF(164,F12_164, (RTCV(RTOSCF(1601,F148_1601, (Current)))));
	if (tb1) {
		tr1 = RTMS_EX_H("GOBO_OS",7,715786835);
		tr2 = RTMS_EX_H("windows",7,1657536371);
		F1238_8472(RTCW(Result), tr1, tr2);
		tr1 = RTMS_EX_H("is_windows",10,479294835);
		tr2 = RTMS_EX_H("true",4,1953658213);
		F1238_8472(RTCW(Result), tr1, tr2);
		tr1 = RTMS_EX_H("path_separator",14,2028772978);
		tr2 = RTMS_EX_H("\\",1,92);
		F1238_8472(RTCW(Result), tr1, tr2);
	} else {
		tr1 = RTMS_EX_H("GOBO_OS",7,715786835);
		tr2 = RTMS_EX_H("unix",4,1970170232);
		F1238_8472(RTCW(Result), tr1, tr2);
		tr1 = RTMS_EX_H("is_unix",7,1358234232);
		tr2 = RTMS_EX_H("true",4,1953658213);
		F1238_8472(RTCW(Result), tr1, tr2);
		tr1 = RTMS_EX_H("path_separator",14,2028772978);
		tr2 = RTMS_EX_H("/",1,47);
		F1238_8472(RTCW(Result), tr1, tr2);
	}
	tr1 = RTMS_EX_H("exe",3,6649957);
	tr2 = RTOSCF(8474,F1240_8474, (Current));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6659[Dtype(RTCW(tr2))-1270])(tr2);
	F1238_8472(RTCW(Result), tr1, tr2);
	RTOSE (10203);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1349_10203 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10203,F1349_10203_body,(Current));
}

/* {GEANT_SHARED_PROPERTIES}.arguments_string_splitter */
static EIF_REFERENCE F1349_10204_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10204);
#define Result RTOSR(10204)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1012, 0x01).id, 1012, _OBJSIZ_2_2_0_0_0_0_0_0_);
	F1013_6865(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H(",\011",2,11273);
	F1013_6871(RTCW(Result), tr1);
	RTOSE (10204);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1349_10204 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10204,F1349_10204_body,(Current));
}

/* {GEANT_SHARED_PROPERTIES}.project_variables_resolver */
static EIF_REFERENCE F1349_10206_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10206);
#define Result RTOSR(10206)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1350, 0x01).id, 1350, _OBJSIZ_1_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10206);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1349_10206 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10206,F1349_10206_body,(Current));
}

/* {GEANT_SHARED_PROPERTIES}.validation_messages */
static EIF_REFERENCE F1349_10207_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (10207);
#define Result RTOSR(10207)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1208,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1208, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1209_8141(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10207);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1349_10207 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10207,F1349_10207_body,(Current));
}

/* {GEANT_SHARED_PROPERTIES}.target_arguments_stack */
static EIF_REFERENCE F1349_10208_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	

	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (10208);
#define Result RTOSR(10208)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1205,0xFF01,1238,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 1205, _OBJSIZ_3_0_0_2_0_0_0_0_);
	}
	F1206_8109(RTCW(loc1), ((EIF_INTEGER_32) 10L));
	Result = (EIF_REFERENCE) loc1;
	RTOSE (10208);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1349_10208 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10208,F1349_10208_body,(Current));
}

/* {GEANT_SHARED_PROPERTIES}.target_locals_stack */
static EIF_REFERENCE F1349_10209_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	

	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (10209);
#define Result RTOSR(10209)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1205,0xFF01,1237,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 1205, _OBJSIZ_3_0_0_2_0_0_0_0_);
	}
	F1206_8109(RTCW(loc1), ((EIF_INTEGER_32) 10L));
	Result = (EIF_REFERENCE) loc1;
	RTOSE (10209);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1349_10209 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10209,F1349_10209_body,(Current));
}

/* {GEANT_SHARED_PROPERTIES}.exit_application */
void F1349_10210 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	F1349_10215(Current, arg2);
	if ((EIF_BOOLEAN)(arg1 != ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		F998_6741(RTCW(tr1));
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		tr2 = RTMS_EX_H("BUILD FAILED!",13,1034668321);
		F998_6740(RTCW(tr1), tr2);
	}
	tr1 = RTOSCF(2938,F299_2938, (Current));
	F210_2234(RTCW(tr1), arg1);
	RTLE;
}

/* {GEANT_SHARED_PROPERTIES}.string_tokens */
EIF_REFERENCE F1349_10211 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,Result);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc8 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc6 > loc8) || loc9)) break;
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg1))-712])(arg1, loc6));
		switch (tc1) {
			case (EIF_CHARACTER_8) '\011':
			case (EIF_CHARACTER_8) '\012':
			case (EIF_CHARACTER_8) '\015':
			case (EIF_CHARACTER_8) ' ':
				loc6++;
				break;
			default:
				loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
	}
	if ((EIF_BOOLEAN) !loc9) {
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = RTMS_EX_H("",0,0);
		loc1 = F958_6416(RTCW(tr1), tr2);
	} else {
		loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc7 = (EIF_INTEGER_32) loc8;
		for (;;) {
			if (loc9) break;
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg1))-712])(arg1, loc7));
			switch (tc1) {
				case (EIF_CHARACTER_8) '\011':
				case (EIF_CHARACTER_8) '\012':
				case (EIF_CHARACTER_8) '\015':
				case (EIF_CHARACTER_8) ' ':
					loc7--;
					break;
				default:
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					break;
			}
		}
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(RTCW(arg1))-946])(arg1, loc6, loc7);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1208,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1208, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1209_8141(RTCW(Result), ((EIF_INTEGER_32) 5L));
	for (;;) {
		if (loc5) break;
		loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(loc1))-712])(loc1, ((EIF_INTEGER_32) 1L)));
			if ((EIF_BOOLEAN)(tc1 == arg2)) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4655[Dtype(RTCW(loc1))-950])(loc1, (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(loc1))-712])(loc1, ti4_1));
			if ((EIF_BOOLEAN)(tc1 == arg2)) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4654[Dtype(RTCW(loc1))-950])(loc1, (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
		}
	}
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R4752[Dtype(RTCW(loc1))-949])(loc1, arg2, loc3);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (loc3 > ti4_1);
		}
		if (tb1) break;
		loc6 = (EIF_INTEGER_32) loc3;
		loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L));
		loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc6 > loc8) || loc9)) break;
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(loc1))-712])(loc1, loc6));
			switch (tc1) {
				case (EIF_CHARACTER_8) '\011':
				case (EIF_CHARACTER_8) '\012':
				case (EIF_CHARACTER_8) '\015':
				case (EIF_CHARACTER_8) ' ':
					loc6++;
					break;
				default:
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					break;
			}
		}
		if ((EIF_BOOLEAN) !loc9) {
			loc2 = RTMS_EX_H("",0,0);
		} else {
			loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc7 = (EIF_INTEGER_32) loc8;
			for (;;) {
				if (loc9) break;
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(loc1))-712])(loc1, loc7));
				switch (tc1) {
					case (EIF_CHARACTER_8) '\011':
					case (EIF_CHARACTER_8) '\012':
					case (EIF_CHARACTER_8) '\015':
					case (EIF_CHARACTER_8) ' ':
						loc7--;
						break;
					default:
						loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						break;
				}
			}
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(RTCW(loc1))-946])(loc1, loc6, loc7);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			F1209_8165(RTCW(Result), loc2);
		}
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc3 <= ti4_1)) {
			loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R4752[Dtype(RTCW(loc1))-949])(loc1, arg2, loc3);
		}
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (loc3 <= ti4_1)) {
		loc6 = (EIF_INTEGER_32) loc3;
		loc8 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc6 > loc8) || loc9)) break;
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(loc1))-712])(loc1, loc6));
			switch (tc1) {
				case (EIF_CHARACTER_8) '\011':
				case (EIF_CHARACTER_8) '\012':
				case (EIF_CHARACTER_8) '\015':
				case (EIF_CHARACTER_8) ' ':
					loc6++;
					break;
				default:
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					break;
			}
		}
		if ((EIF_BOOLEAN) !loc9) {
			loc2 = RTMS_EX_H("",0,0);
		} else {
			loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc7 = (EIF_INTEGER_32) loc8;
			for (;;) {
				if (loc9) break;
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(loc1))-712])(loc1, loc7));
				switch (tc1) {
					case (EIF_CHARACTER_8) '\011':
					case (EIF_CHARACTER_8) '\012':
					case (EIF_CHARACTER_8) '\015':
					case (EIF_CHARACTER_8) ' ':
						loc7--;
						break;
					default:
						loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						break;
				}
			}
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(RTCW(loc1))-946])(loc1, loc6, loc7);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			F1209_8165(RTCW(Result), loc2);
		}
	}
	RTLE;
	return Result;
}

/* {GEANT_SHARED_PROPERTIES}.glob_prefix */
EIF_REFERENCE F1349_10212 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R4752[Dtype(RTCW(arg1))-949])(arg1, (EIF_CHARACTER_8) '*', ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOSCF(6466,F971_6466, (Current));
		Result = F958_6416(RTCW(tr1), arg1);
	} else {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L))) {
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(RTCW(arg1))-946])(arg1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			Result = F958_6400(RTCW(tr1), arg1, ((EIF_INTEGER_32) 0L));
		}
	}
	RTLE;
	return Result;
}

/* {GEANT_SHARED_PROPERTIES}.glob_postfix */
EIF_REFERENCE F1349_10213 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R4752[Dtype(RTCW(arg1))-949])(arg1, (EIF_CHARACTER_8) '*', ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOSCF(6466,F971_6466, (Current));
		Result = F958_6416(RTCW(tr1), arg1);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(loc1 == ti4_1)) {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			Result = F958_6400(RTCW(tr1), arg1, ((EIF_INTEGER_32) 0L));
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(RTCW(arg1))-946])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), ti4_1);
		}
	}
	RTLE;
	return Result;
}

/* {GEANT_SHARED_PROPERTIES}.log_messages */
void F1349_10215 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_1_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			tr2 = F738_4063(RTCW(arg1), loc1);
			F999_6748(RTCW(tr1), tr2);
			loc1++;
		}
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		F998_6741(RTCW(tr1));
	}
	RTLE;
}

void EIF_Minit494 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
