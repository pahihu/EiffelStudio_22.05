
#ifndef _C10_ut458_
#define _C10_ut458_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1313_10041(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_CHARACTER_8);
extern void EIF_Minit458(void);
extern EIF_REFERENCE F958_6423(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F971_6466(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,6466)
extern char *(*R5171[])();
extern char *(*R1077[])();

#ifdef __cplusplus
}
#endif

#endif
