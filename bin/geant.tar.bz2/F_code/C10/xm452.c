/*
 * Code for class XM_EIFFEL_PE_ENTITY_DEF
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm452.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_PE_ENTITY_DEF}.read_token */
void F1307_9637 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_27_4_)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_27_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_27_6_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 263L);
		tr1 = RTOSCF(9520,F1303_9520, (Current));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
	} else {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_27_5_)) {
			F1015_6930(Current);
		} else {
			F1306_9635(Current);
			tb1 = '\0';
			if (F1015_6915(Current)) {
				tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_27_5_);
			}
			if (tb1) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_27_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_27_6_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 263L);
				tr1 = RTOSCF(9520,F1303_9520, (Current));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
			}
		}
	}
	RTLE;
}

/* {XM_EIFFEL_PE_ENTITY_DEF}.reset */
void F1307_9638 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1306_9636(Current);
	F1307_9639(Current);
	RTLE;
}

/* {XM_EIFFEL_PE_ENTITY_DEF}.reset_sent */
void F1307_9639 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_27_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_27_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

void EIF_Minit452 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
