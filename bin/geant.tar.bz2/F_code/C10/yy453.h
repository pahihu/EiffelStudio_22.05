
#ifndef _C10_yy453_
#define _C10_yy453_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1308_9642(EIF_REFERENCE);
extern void F1308_9643(EIF_REFERENCE);
extern EIF_INTEGER_32 F1308_9646(EIF_REFERENCE);
extern void F1308_9647(EIF_REFERENCE);
extern void F1308_9648(EIF_REFERENCE);
extern void F1308_9649(EIF_REFERENCE);
extern void F1308_9650(EIF_REFERENCE);
extern void F1308_9655(EIF_REFERENCE);
extern EIF_REFERENCE F1308_9686(EIF_REFERENCE, EIF_REFERENCE);
extern void F1308_9687(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1308_9693(EIF_REFERENCE);
extern void EIF_Minit453(void);
extern EIF_REFERENCE F25_235(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F25_227(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F25_230(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F301_2947(EIF_REFERENCE);
extern void F960_6441(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F25_232(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F806_4214(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,2947)
RTOSHF(EIF_REFERENCE,4214)
extern char *(*R7241[])();
extern char *(*R7237[])();
extern char *(*R7238[])();
extern char *(*R7239[])();
extern char *(*R880[])();
extern char *(*R883[])();
extern char *(*R7240[])();
extern char *(*R884[])();
extern char *(*R7242[])();
extern char *(*R7206[])();
extern char *(*R7207[])();
extern char *(*R7208[])();
extern char *(*R7209[])();
extern char *(*R7210[])();
extern char *(*R7211[])();
extern char *(*R7212[])();
extern char *(*R7213[])();
extern char *(*R7214[])();
extern long O7217[];
extern long O7218[];
extern long O7219[];
extern long O7189[];
extern long O7220[];
extern long O7221[];
extern long O7190[];
extern long O7191[];
extern long O7192[];
extern long O7193[];
extern long O7194[];
extern long O7195[];
extern long O7196[];
extern long O7199[];
extern long O7246[];
extern long O7200[];
extern long O7201[];
extern long O7202[];
extern long O7203[];
extern long O7204[];
extern long O7205[];

#ifdef __cplusplus
}
#endif

#endif
