
#ifndef _C10_lx480_
#define _C10_lx480_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1335_10140(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 10141)


extern EIF_REFERENCE F1335_10141(EIF_REFERENCE);
extern void EIF_Minit480(void);
extern EIF_REFERENCE F1315_10082(EIF_REFERENCE);
extern void F738_4058(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
RTOSHF(EIF_REFERENCE,10082)

#ifdef __cplusplus
}
#endif

#endif
