/*
 * Code for class XM_EIFFEL_SCANNER_DTD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm450.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_SCANNER_DTD}.make_scanner */
void F1305_9617 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1303_9492(Current);
	F1016_6981(Current, ((EIF_INTEGER_32) 10L));
	RTLE;
}

/* {XM_EIFFEL_SCANNER_DTD}.read_token */
void F1305_9620 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_23_3_)) {
		F1015_6918(Current, ((EIF_INTEGER_32) 289L));
		*(EIF_BOOLEAN *)(Current+ _CHROFF_23_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_23_4_)) {
			F1015_6930(Current);
		} else {
			F1018_7057(Current);
			if (F1015_6915(Current)) {
				F1015_6918(Current, ((EIF_INTEGER_32) 290L));
				*(EIF_BOOLEAN *)(Current+ _CHROFF_23_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTLE;
}

void EIF_Minit450 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
