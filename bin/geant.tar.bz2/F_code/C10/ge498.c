/*
 * Code for class GEANT_PARENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge498.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_PARENT}.make */
void F1353_10253 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	loc1 = RTLNS(eif_new_type(989, 0x01).id, 989, _OBJSIZ_0_0_0_0_0_0_0_0_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1232,0xFF01,985,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1223_8390(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1223_8407(RTCW(tr1), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1232,0xFF01,22,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1223_8390(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1223_8407(RTCW(tr1), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1232,0xFF01,21,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1223_8390(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1223_8407(RTCW(tr1), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1232,0xFF01,1429,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1223_8389(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1223_8407(RTCW(tr1), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1232,0xFF01,1429,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1223_8389(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1223_8407(RTCW(tr1), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1232,0xFF01,1429,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1223_8389(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1223_8407(RTCW(tr1), loc1);
	RTLE;
}

/* {GEANT_PARENT}.is_executable */
EIF_BOOLEAN F1353_10262 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL);
}

/* {GEANT_PARENT}.set_parent_project */
void F1353_10266 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_PARENT}.prepare_project */
void F1353_10267 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	RTCT0("precondition", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr3) = 5L;
		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
	}
	tr4 = RTMS_EX_H("Project \'",9,213807399);
	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr4 = *(EIF_REFERENCE *)(Current);
	tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
	*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr4 = RTMS_EX_H("\': --> preparing parent \'",25,424864295);
	*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr4 = *(EIF_REFERENCE *)(loc1);
	*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr4 = RTMS_EX_H("\' for inheritance:",18,1094666298);
	*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
	F1356_10325(RTCW(tr1), tr2);
	F1353_10268(Current);
	F1353_10269(Current);
	F1353_10270(Current);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_13_1_);
	if (tb1) {
		F1353_10271(Current);
	}
	F1353_10272(Current);
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr3) = 5L;
		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
	}
	tr4 = RTMS_EX_H("Project \'",9,213807399);
	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr4 = *(EIF_REFERENCE *)(Current);
	tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
	*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr4 = RTMS_EX_H("\': <-- preparation of \'",23,1972004391);
	*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr4 = *(EIF_REFERENCE *)(loc1);
	*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr4 = RTMS_EX_H("\' for inheritance done.",23,1218229806);
	*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
	F1356_10325(RTCW(tr1), tr2);
	RTLE;
}

/* {GEANT_PARENT}.apply_renames */
void F1353_10268 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc3);
	RTLR(11,tr4);
	RTLIU(12);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_5_);
		loc5 = tr1;
		tb1 = EIF_TEST(loc5);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1233_8466(RTCW(tr1));
		F1061_7406(RTCW(loc1));
		for (;;) {
			tb1 = F1077_7424(RTCW(loc1));
			if (tb1) break;
			loc2 = F1039_7375(RTCW(loc1));
			tb2 = F986_6675(RTCW(loc2));
			if ((EIF_BOOLEAN) !tb2) {
				{
					static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr2) = 1L;
					memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
				}
				tr3 = RTMS_EX_H("invalid rename clause.",22,1035435566);
				*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
				F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
			} else {
				RTCT0("postcondition_of_geant_rename_is_executable_1", EX_CHECK);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
				loc6 = tr1;
				if (EIF_TEST(loc6)) {
					RTCK0;
				} else {
					RTCF0;
				}
				RTCT0("postcondition_of_geant_rename_is_executable_2", EX_CHECK);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
				loc7 = tr1;
				if (EIF_TEST(loc7)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tb2 = F1223_8402(loc5, loc6);
				if ((EIF_BOOLEAN) !tb2) {
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 9L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr2) = 9L;
						memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
					}
					tr3 = RTMS_EX_H("\012LOAD ERROR:\012",13,54494730);
					*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("  Project \'",11,435855399);
					*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = *(EIF_REFERENCE *)(Current);
					tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
					*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\': VHRC-1: Inheritance clause contains inheritance operator",59,2143118194);
					*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H(" \'rename\'\012for a feature `",25,712777824);
					*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) loc6;
					RTAR(tr2,loc6);
					tr3 = RTMS_EX_H("\' which does not exist in parent \'",34,592059943);
					*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = *(EIF_REFERENCE *)(loc4);
					*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\'.",2,10030);
					*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
					F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
				}
				tb2 = F1223_8402(loc5, loc7);
				if (tb2) {
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 8L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr2) = 8L;
						memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
					}
					tr3 = RTMS_EX_H("\012LOAD ERROR:\012",13,54494730);
					*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("  Project \'",11,435855399);
					*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = *(EIF_REFERENCE *)(loc4);
					*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\': cannot rename target: `",26,1033838432);
					*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) loc6;
					RTAR(tr2,loc6);
					tr3 = RTMS_EX_H(" to `",5,1953685600);
					*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) loc7;
					RTAR(tr2,loc7);
					tr3 = RTMS_EX_H("\' since it already exists.",26,1554635310);
					*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
					F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
				}
				loc3 = F1223_8394(loc5, loc6);
				tr1 = *(EIF_REFERENCE *)(Current);
				{
					static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 9L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr3) = 9L;
					memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
				}
				tr4 = RTMS_EX_H("Project \'",9,213807399);
				*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				tr4 = *(EIF_REFERENCE *)(Current);
				tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
				*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				tr4 = RTMS_EX_H("\': renaming target: `",21,581388640);
				*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				tr4 = F1430_11111(RTCW(loc3));
				*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				tr4 = RTMS_EX_H("\' named `",9,1583151968);
				*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) loc6;
				RTAR(tr3,loc6);
				tr4 = RTMS_EX_H("\' as: `",7,151393376);
				*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) loc7;
				RTAR(tr3,loc7);
				tr4 = RTMS_EX_H("\'",1,39);
				*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
				F1356_10325(RTCW(tr1), tr2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				F1223_8416(RTCW(tr1), loc3, loc7);
			}
			F1061_7407(RTCW(loc1));
		}
	}
	RTLE;
}

/* {GEANT_PARENT}.apply_redefines */
void F1353_10269 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc6);
	RTLR(9,loc3);
	RTLR(10,tr4);
	RTLIU(11);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_5_);
		loc5 = tr1;
		tb1 = EIF_TEST(loc5);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc1 = F1233_8466(RTCW(tr1));
		F1053_7395(RTCW(loc1));
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2921[Dtype(RTCW(loc1))-437])(loc1);
			if (tb1) break;
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2920[Dtype(RTCW(loc1))-437])(loc1);
			tb2 = F23_224(RTCW(loc2));
			if ((EIF_BOOLEAN) !tb2) {
				{
					static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr2) = 1L;
					memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
				}
				tr3 = RTMS_EX_H("invalid redefine clause.",24,313659438);
				*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
				F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
			} else {
				RTCT0("postcondition_of_geant_redefine_is_executable", EX_CHECK);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
				loc6 = tr1;
				if (EIF_TEST(loc6)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tb2 = F1223_8402(RTCW(tr1), loc6);
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					loc3 = F1223_8394(RTCW(tr1), loc6);
				} else {
					tb2 = F1223_8402(loc5, loc6);
					if (tb2) {
						loc3 = F1223_8394(loc5, loc6);
					}
				}
				if ((EIF_BOOLEAN)(loc3 == NULL)) {
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 6L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr2) = 6L;
						memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
					}
					tr3 = RTMS_EX_H("\012LOAD ERROR:\012",13,54494730);
					*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("  Project \'",11,435855399);
					*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = *(EIF_REFERENCE *)(Current);
					tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
					*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\': cannot redefine target: `",28,1772533088);
					*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) loc6;
					RTAR(tr2,loc6);
					tr3 = RTMS_EX_H("\' since it does not exist.",26,182726446);
					*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
					F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
					F1223_8416(RTCW(tr1), loc3, loc6);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					tb2 = F1223_8402(RTCW(tr1), loc6);
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current);
						{
							static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
							RT_SPECIAL_COUNT(tr3) = 5L;
							memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
						}
						tr4 = RTMS_EX_H("Project \'",9,213807399);
						*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = RTMS_EX_H("\': moving target \'",18,731438375);
						*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) loc6;
						RTAR(tr3,loc6);
						tr4 = RTMS_EX_H("\' from list of renamed targets to list of redefined targets.",60,2133232686);
						*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
						F1356_10325(RTCW(tr1), tr2);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						F1212_8252(RTCW(tr1), loc6);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current);
						{
							static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
							RT_SPECIAL_COUNT(tr3) = 5L;
							memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
						}
						tr4 = RTMS_EX_H("Project \'",9,213807399);
						*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = RTMS_EX_H("\': adding target \'",18,1643396135);
						*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) loc6;
						RTAR(tr3,loc6);
						tr4 = RTMS_EX_H("\' to list of redefined targets.",31,2008802606);
						*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
						F1356_10325(RTCW(tr1), tr2);
					}
				}
			}
			F1053_7396(RTCW(loc1));
		}
	}
	RTLE;
}

/* {GEANT_PARENT}.apply_unchangeds */
void F1353_10270 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_5_);
		loc5 = tr1;
		tb1 = EIF_TEST(loc5);
	}
	if (tb1) {
		loc1 = F1233_8466(loc5);
		F1061_7406(RTCW(loc1));
		for (;;) {
			tb1 = F1077_7424(RTCW(loc1));
			if (tb1) break;
			loc2 = F1039_7375(RTCW(loc1));
			loc3 = F1088_7442(RTCW(loc1));
			tb2 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tb3 = F1212_8239(RTCW(tr1), loc2);
			if ((EIF_BOOLEAN) !tb3) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tb3 = F1212_8239(RTCW(tr1), loc2);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				F1223_8416(RTCW(tr1), loc2, loc3);
			}
			F1061_7407(RTCW(loc1));
		}
	}
	RTLE;
}

/* {GEANT_PARENT}.apply_undeclared_redefines */
void F1353_10271 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,tr4);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc1 = F1233_8466(loc4);
		F1053_7395(RTCW(loc1));
		for (;;) {
			tb1 = F1077_7423(RTCW(loc1));
			if (tb1) break;
			loc2 = F1039_7375(RTCW(loc1));
			loc3 = F1088_7442(RTCW(loc1));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tb2 = F1223_8402(RTCW(tr1), loc3);
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(Current);
				{
					static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr3) = 5L;
					memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
				}
				tr4 = RTMS_EX_H("Project \'",9,213807399);
				*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				tr4 = *(EIF_REFERENCE *)(Current);
				tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
				*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				tr4 = RTMS_EX_H("\': WARNING: Applying implicit redefinition for target `",55,1648590688);
				*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) loc3;
				RTAR(tr3,loc3);
				tr4 = RTMS_EX_H("\' due to old inheritance format.",32,1495364910);
				*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
				F1356_10323(RTCW(tr1), tr2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				tr2 = F1223_8394(RTCW(tr2), loc3);
				F1223_8416(RTCW(tr1), tr2, loc3);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				F1212_8252(RTCW(tr1), loc3);
			}
			F1053_7396(RTCW(loc1));
		}
	}
	RTLE;
}

/* {GEANT_PARENT}.apply_selects */
void F1353_10272 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,loc5);
	RTLR(8,loc3);
	RTLR(9,tr4);
	RTLIU(10);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = F1233_8466(RTCW(tr1));
		F1053_7395(RTCW(loc1));
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2921[Dtype(RTCW(loc1))-437])(loc1);
			if (tb1) break;
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2920[Dtype(RTCW(loc1))-437])(loc1);
			tb2 = F22_220(RTCW(loc2));
			if ((EIF_BOOLEAN) !tb2) {
				{
					static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr2) = 1L;
					memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
				}
				tr3 = RTMS_EX_H("invalid select clause.",22,92357934);
				*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
				F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
			} else {
				RTCT0("poscondition_of_geant_select_is_executable", EX_CHECK);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
				loc5 = tr1;
				if (EIF_TEST(loc5)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tb2 = F1223_8402(RTCW(tr1), loc5);
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
					loc3 = F1223_8394(RTCW(tr1), loc5);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					tb2 = F1223_8402(RTCW(tr1), loc5);
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						loc3 = F1223_8394(RTCW(tr1), loc5);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						tb2 = F1223_8402(RTCW(tr1), loc5);
						if (tb2) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
							loc3 = F1223_8394(RTCW(tr1), loc5);
						}
					}
				}
				if ((EIF_BOOLEAN)(loc3 == NULL)) {
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 6L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr2) = 6L;
						memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
					}
					tr3 = RTMS_EX_H("\012LOAD ERROR:\012",13,54494730);
					*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("  Project \'",11,435855399);
					*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = *(EIF_REFERENCE *)(Current);
					tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
					*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\': selected target: `",21,814571872);
					*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) loc5;
					RTAR(tr2,loc5);
					tr3 = RTMS_EX_H("\' does not exist.",17,1043567662);
					*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
					F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current);
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr3) = 5L;
						memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
					}
					tr4 = RTMS_EX_H("Project \'",9,213807399);
					*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr4 = *(EIF_REFERENCE *)(Current);
					tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
					*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr4 = RTMS_EX_H("\': moving target \'",18,731438375);
					*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) loc5;
					RTAR(tr3,loc5);
					tr4 = RTMS_EX_H("\' to list of selected targets.",30,2067646254);
					*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
					F1356_10325(RTCW(tr1), tr2);
					tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_6_);
					F1223_8416(RTCW(tr1), loc3, loc5);
				}
			}
			F1053_7396(RTCW(loc1));
		}
	}
	RTLE;
}

void EIF_Minit498 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
