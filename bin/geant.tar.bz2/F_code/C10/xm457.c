/*
 * Code for class XM_EIFFEL_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm457.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_PARSER}.yy_build_parser_tables */
void F1312_9942 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(9952,F1312_9952, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9955,F1312_9955, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9958,F1312_9958, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9962,F1312_9962, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9963,F1312_9963, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9967,F1312_9967, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9968,F1312_9968, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9972,F1312_9972, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9973,F1312_9973, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9978,F1312_9978, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yy_create_value_stacks */
void F1312_9943 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,23,0,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R231[Dtype(RTCW(tr1))-23])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,23,0xFF01,981,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
	tr1 = F24_227(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,23,0xFF01,1220,0xFF01,981,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_28_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_17_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	tr1 = F24_227(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_17_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_27_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,23,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_30_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
	tr1 = F24_227(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_19_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_29_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,23,0xFF01,1259,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_32_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_21_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
	tr1 = F24_227(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_21_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,23,0xFF01,1313,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_34_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
	tr1 = F24_227(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,23,0xFF01,1187,0xFF01,1296,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_36_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_25_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_36_);
	tr1 = F24_227(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_25_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_35_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,23,0xFF01,1296,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_38_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
	tr1 = F24_227(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,23,0xFF01,1187,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_40_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_29_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
	tr1 = F24_227(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_29_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_39_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,25,903,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_42_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
	tr1 = F26_227(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_41_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,23,0xFF01,12,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_44_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	tr1 = F24_227(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_43_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yy_init_value_stacks */
void F1312_9944 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_18_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_26_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_30_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yy_clear_value_stacks */
void F1312_9945 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R3382[Dtype(RTCW(tr1))-712])(tr1, ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
	F713_3998(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	F713_3998(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
	F713_3998(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
	F713_3998(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
	F713_3998(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_35_);
	F713_3998(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
	F713_3998(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
	F713_3998(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_41_);
	F722_3998(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
	F713_3998(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yy_push_last_value */
void F1312_9946 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (arg1));
	/* END INLINED CODE */
	ti4_1 = ti4_2;
	switch (ti4_1) {
		case 1L:
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr4 = RTCCL(tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr4, ti4_1);
			break;
		case 4L:
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))++;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_19_))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_19_)) += ((EIF_INTEGER_32) 10L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_19_));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_29_) = (EIF_REFERENCE) tr1;
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
			F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), *(EIF_REFERENCE *)(Current + _REFACS_5_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			break;
		default:
			F1308_9648(Current);
			break;
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yy_push_error_value */
void F1312_9947 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
	tr3 = RTCCL(loc1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yy_pop_last_value */
void F1312_9948 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (arg1));
	/* END INLINED CODE */
	loc1 = ti4_2;
	switch (loc1) {
		case 1L:
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
			break;
		case 2L:
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_))--;
			break;
		case 3L:
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_18_))--;
			break;
		case 4L:
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
			break;
		case 5L:
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_))--;
			break;
		case 6L:
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_))--;
			break;
		case 7L:
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_26_))--;
			break;
		case 8L:
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))--;
			break;
		case 9L:
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_30_))--;
			break;
		case 10L:
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_))--;
			break;
		case 11L:
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_))--;
			break;
		default:
			F1308_9648(Current);
			break;
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yy_do_action */
void F1312_9950 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(23);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,tr3);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLR(7,tr4);
	RTLR(8,tr5);
	RTLR(9,loc4);
	RTLR(10,loc5);
	RTLR(11,loc7);
	RTLR(12,loc8);
	RTLR(13,loc12);
	RTLR(14,loc13);
	RTLR(15,loc14);
	RTLR(16,loc15);
	RTLR(17,loc16);
	RTLR(18,loc17);
	RTLR(19,loc18);
	RTLR(20,loc9);
	RTLR(21,loc10);
	RTLR(22,loc11);
	RTLIU(23);
	
	RTGC;
	switch (arg1) {
		case 1L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 2L:
			loc2 = F1311_9906(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1311_9883(Current, loc2, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_));
			}
			break;
		case 3L:
			loc2 = F1311_9906(Current);
			tr1 = F1311_9939(Current);
			F1311_9883(Current, loc2, tr1);
			tr1 = F1311_9939(Current);
			F1311_9883(Current, loc2, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_));
			}
			break;
		case 4L:
			loc2 = F1311_9906(Current);
			tr1 = F1311_9939(Current);
			F1311_9883(Current, loc2, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1311_9883(Current, loc2, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_));
			}
			break;
		case 5L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			loc2 = tr3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1311_9883(Current, loc2, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_));
			}
			break;
		case 6L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			loc2 = tr3;
			tr1 = F1311_9939(Current);
			F1311_9883(Current, loc2, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_));
			}
			break;
		case 7L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 8L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 9L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9936(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 10L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9937(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 11L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9936(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 12L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9937(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 13L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9936(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 14L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9937(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 15L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 16L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9936(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 17L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9937(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 18L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9936(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 19L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9937(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 20L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9936(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 21L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9937(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 22L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9936(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 23L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9937(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 24L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9936(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 25L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9937(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 26L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9936(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 27L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9937(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 28L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 29L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 30L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 31L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 32L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 33L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 34L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 35L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 36L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 37L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 38L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 39L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 40L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 41L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 42L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 43L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 0L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 44L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 45L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 46L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 47L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 48L:
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_45_2_)) {
				tr1 = RTOSCF(1537,F125_1537, (Current));
				F1311_9901(Current, tr1);
			}
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 49L:
			loc3 = F1311_9939(Current);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 50L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 51L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 52L:
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr3 = tr5;
			loc3 = F958_6407(RTCW(tr1), tr2, tr3);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 53L:
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr3 = tr5;
			loc3 = F958_6417(RTCW(tr1), tr2, tr3);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 54L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 55L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 56L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc3 = F1311_9922(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 57L:
			loc3 = F1311_9939(Current);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 58L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 59L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 60L:
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr3 = tr5;
			loc3 = F958_6407(RTCW(tr1), tr2, tr3);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 61L:
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr3 = tr5;
			loc3 = F958_6417(RTCW(tr1), tr2, tr3);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 62L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 63L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 64L:
			tr1 = RTOSCF(1499,F125_1499, (Current));
			F1311_9901(Current, tr1);
			loc3 = RTMS_EX_H("",0,0);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 65L:
			loc3 = F1311_9939(Current);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 66L:
			loc3 = F1311_9939(Current);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 67L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			F196_2152(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 68L:
			tr1 = F1311_9939(Current);
			F196_2152(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 69L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			F129_1560(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 70L:
			tr1 = F1311_9939(Current);
			F129_1560(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 71L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 72L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 73L:
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr3 = tr5;
			loc3 = F958_6407(RTCW(tr1), tr2, tr3);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 74L:
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr3 = tr5;
			loc3 = F958_6417(RTCW(tr1), tr2, tr3);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 75L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 76L:
			tr1 = RTOSCF(1497,F125_1497, (Current));
			F1311_9901(Current, tr1);
			loc3 = RTMS_EX_H("",0,0);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 77L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 2L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			F196_2151(Current, tr1, tr2);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 4L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 78L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = F1311_9939(Current);
			F196_2151(Current, tr1, tr2);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 4L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 79L:
			tr1 = RTOSCF(1538,F125_1538, (Current));
			F1311_9901(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 80L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 2L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			F129_1559(Current, tr1, tr2);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 4L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 81L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = F1311_9939(Current);
			F129_1559(Current, tr1, tr2);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 4L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 82L:
			tr1 = RTOSCF(1538,F125_1538, (Current));
			F1311_9901(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 83L:
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr3 = tr5;
			loc3 = F958_6407(RTCW(tr1), tr2, tr3);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 84L:
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr3 = tr5;
			loc3 = F958_6407(RTCW(tr1), tr2, tr3);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 85L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 86L:
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr3 = tr5;
			loc3 = F958_6407(RTCW(tr1), tr2, tr3);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 87L:
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr3 = tr5;
			loc3 = F958_6417(RTCW(tr1), tr2, tr3);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 88L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 89L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 90L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 91L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 92L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 93L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 94L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 95L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 96L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 97L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F196_2157(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 98L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_)));
			/* END INLINED CODE */
			tr1 = tr3;
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			F1311_9911(Current, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F13_180(RTCW(tr1), Current);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 99L:
			loc4 = RTLNS(eif_new_type(12, 0x01).id, 12, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F13_170(RTCW(loc4));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_43_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), loc4, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_));
			}
			break;
		case 100L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_)));
			/* END INLINED CODE */
			loc4 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), loc4, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_));
			}
			break;
		case 101L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_)));
			/* END INLINED CODE */
			loc4 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), loc4, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_));
			}
			break;
		case 102L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 0L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 103L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 104L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 105L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 0L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 106L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 107L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 108L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 109L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_)));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			F13_177(RTCW(tr1), tr2);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_)));
			/* END INLINED CODE */
			loc4 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 4L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), loc4, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_));
			}
			break;
		case 110L:
			tr1 = RTOSCF(1510,F125_1510, (Current));
			F1311_9901(Current, tr1);
			loc4 = RTLNS(eif_new_type(12, 0x01).id, 12, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F13_170(RTCW(loc4));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_43_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), loc4, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_));
			}
			break;
		case 111L:
			loc4 = RTLNS(eif_new_type(12, 0x01).id, 12, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F13_170(RTCW(loc4));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_43_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), loc4, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_));
			}
			break;
		case 112L:
			loc4 = RTLNS(eif_new_type(12, 0x01).id, 12, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F13_170(RTCW(loc4));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_41_);
			/* INLINED CODE (SPECIAL.item) */
			tb2 = *((EIF_BOOLEAN *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_)));
			/* END INLINED CODE */
			tb1 = tb2;
			F13_179(RTCW(loc4), tb1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_43_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), loc4, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_));
			}
			break;
		case 113L:
			loc4 = RTLNS(eif_new_type(12, 0x01).id, 12, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F13_170(RTCW(loc4));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F13_178(RTCW(loc4), tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1311_9911(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_43_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), loc4, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_));
			}
			break;
		case 114L:
			loc4 = RTLNS(eif_new_type(12, 0x01).id, 12, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F13_170(RTCW(loc4));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F13_178(RTCW(loc4), tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_41_);
			/* INLINED CODE (SPECIAL.item) */
			tb2 = *((EIF_BOOLEAN *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_)));
			/* END INLINED CODE */
			tb1 = tb2;
			F13_179(RTCW(loc4), tb1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1311_9911(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_33_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_43_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_43_), loc4, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_34_));
			}
			break;
		case 115L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 116L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 117L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 118L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 119L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 4L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 120L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 4L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 121L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 122L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 123L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 124L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 125L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 126L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F129_1554(Current, tr1, NULL, (EIF_BOOLEAN) 1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 127L:
			F129_1561(Current);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 128L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_)));
			/* END INLINED CODE */
			tr2 = tr4;
			F129_1554(Current, tr1, tr2, (EIF_BOOLEAN) 0);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_)));
			/* END INLINED CODE */
			loc5 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 4L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_31_), loc5, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_));
			}
			break;
		case 129L:
			*(EIF_BOOLEAN *)(Current+ _CHROFF_45_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1311_9926(Current, tr1);
			F129_1561(Current);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 130L:
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_45_2_)) {
				tr1 = RTOSCF(1509,F125_1509, (Current));
				F1311_9901(Current, tr1);
			}
			*(EIF_BOOLEAN *)(Current+ _CHROFF_45_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 4L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 131L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 0L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 132L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 133L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 134L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 135L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 136L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 137L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 0L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 138L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 139L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 4L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 140L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 141L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 142L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 143L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 144L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 145L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 146L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 147L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 148L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 149L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 150L:
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 5L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
					tr1 = F26_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_41_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_41_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
				F26_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_41_), loc6, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_));
			}
			break;
		case 151L:
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 5L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
					tr1 = F26_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_41_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_41_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
				F26_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_41_), loc6, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_));
			}
			break;
		case 152L:
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 5L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
					tr1 = F26_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_41_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_41_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
				F26_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_41_), loc6, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_));
			}
			break;
		case 153L:
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 5L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
					tr1 = F26_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_41_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_31_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_41_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
				F26_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_41_), loc6, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_32_));
			}
			break;
		case 154L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 155L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr2 = tr4;
			tb1 = F982_6643(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = RTOSCF(1520,F125_1520, (Current));
				F1311_9901(Current, tr1);
			}
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)) -= ((EIF_INTEGER_32) 2L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 156L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr2 = tr4;
			tb1 = F982_6643(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = RTOSCF(1520,F125_1520, (Current));
				F1311_9901(Current, tr1);
			}
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 157L:
			tr1 = RTOSCF(1514,F125_1514, (Current));
			F1311_9901(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 158L:
			tr1 = RTOSCF(1513,F125_1513, (Current));
			F1311_9901(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 159L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			loc2 = tr3;
			F196_2155(Current);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_));
			}
			break;
		case 160L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			loc2 = tr3;
			F196_2155(Current);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_18_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_));
			}
			break;
		case 161L:
			tr1 = RTOSCF(1512,F125_1512, (Current));
			F1311_9901(Current, tr1);
			loc2 = RTLNS(eif_new_type(981, 0x01).id, 981, _OBJSIZ_3_1_0_1_0_0_0_0_);
			F982_6625(RTCW(loc2));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_));
			}
			break;
		case 162L:
			F196_2155(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr1 = tr3;
			tr1 = F982_6633(RTCW(tr1));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr2 = tr4;
			tr2 = F982_6634(RTCW(tr2));
			F196_2156(Current, NULL, tr1, tr2);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 163L:
			F196_2155(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr1 = tr3;
			tr1 = F982_6633(RTCW(tr1));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr2 = tr4;
			tr2 = F982_6634(RTCW(tr2));
			F196_2156(Current, NULL, tr1, tr2);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_18_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 164L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			loc2 = tr3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr1 = tr3;
			tr1 = F982_6633(RTCW(tr1));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr2 = tr4;
			tr2 = F982_6634(RTCW(tr2));
			F196_2153(Current, NULL, tr1, tr2);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_));
			}
			break;
		case 165L:
			loc7 = F1311_9907(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1217_8337(RTCW(loc7), tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_18_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_18_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_17_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_17_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_27_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_17_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_27_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_27_), loc7, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_18_));
			}
			break;
		case 166L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_18_)));
			/* END INLINED CODE */
			loc7 = tr3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr1 = tr3;
			tb1 = F1217_8327(RTCW(loc7), tr1);
			if (tb1) {
				tr1 = RTOSCF(1518,F125_1518, (Current));
				F1311_9901(Current, tr1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
				/* INLINED CODE (SPECIAL.item) */
				tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
				/* END INLINED CODE */
				tr1 = tr3;
				F1217_8337(RTCW(loc7), tr1);
			}
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_27_), loc7, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_18_));
			}
			break;
		case 167L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			loc2 = tr3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr1 = tr3;
			tr1 = F982_6633(RTCW(tr1));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr2 = tr4;
			tr2 = F982_6634(RTCW(tr2));
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr3 = tr5;
			F196_2154(Current, NULL, tr1, tr2, tr3);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_));
			}
			break;
		case 168L:
			tr1 = RTOSCF(1517,F125_1517, (Current));
			F1311_9901(Current, tr1);
			loc2 = RTLNS(eif_new_type(981, 0x01).id, 981, _OBJSIZ_3_1_0_1_0_0_0_0_);
			F982_6625(RTCW(loc2));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_));
			}
			break;
		case 169L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			loc2 = tr3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr1 = tr3;
			tr1 = F982_6633(RTCW(tr1));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_)));
			/* END INLINED CODE */
			tr2 = tr4;
			tr2 = F982_6634(RTCW(tr2));
			F196_2156(Current, NULL, tr1, tr2);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_));
			}
			break;
		case 170L:
			tr1 = RTOSCF(1519,F125_1519, (Current));
			F1311_9901(Current, tr1);
			loc2 = RTLNS(eif_new_type(981, 0x01).id, 981, _OBJSIZ_3_1_0_1_0_0_0_0_);
			F982_6625(RTCW(loc2));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_15_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_25_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_16_));
			}
			break;
		case 171L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 172L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 173L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F196_2157(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 174L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 175L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 176L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 177L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 178L:
			tr1 = RTOSCF(1496,F125_1496, (Current));
			F1311_9901(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 179L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 180L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 181L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 182L:
			tr1 = RTOSCF(1522,F125_1522, (Current));
			F1311_9901(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 183L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 184L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 185L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			tr2 = tr4;
			F129_1555(Current, tr1, tr2);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 6L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 186L:
			tr1 = RTOSCF(1531,F125_1531, (Current));
			F1311_9901(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 187L:
			loc8 = RTLNS(eif_new_type(1313, 0x01).id, 1313, _OBJSIZ_2_3_0_0_0_0_0_0_);
			F1314_10045(RTCW(loc8));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 188L:
			loc8 = RTLNS(eif_new_type(1313, 0x01).id, 1313, _OBJSIZ_2_3_0_0_0_0_0_0_);
			F1314_10046(RTCW(loc8));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 189L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 190L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 191L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 192L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1311_9912(Current, loc8, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 193L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 194L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1311_9912(Current, loc8, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 195L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			loc8 = F1311_9916(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 196L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			loc8 = F1311_9916(Current, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1311_9912(Current, loc8, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 197L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 198L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1311_9912(Current, loc8, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 199L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 200L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1311_9912(Current, loc8, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 201L:
			loc3 = RTOSCF(9915,F1311_9915, (Current));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 202L:
			loc3 = RTOSCF(9913,F1311_9913, (Current));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 203L:
			loc3 = RTOSCF(9914,F1311_9914, (Current));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 204L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			RTCT0("attached yyval6.items as l_items", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_1_);
			loc12 = tr1;
			if (EIF_TEST(loc12)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6050[Dtype(loc12)-1184])(loc12, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 3L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 205L:
			loc8 = RTLNS(eif_new_type(1313, 0x01).id, 1313, _OBJSIZ_2_3_0_0_0_0_0_0_);
			F1314_10047(RTCW(loc8));
			RTCT0("attached yyval6.items as l_items", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_1_);
			loc13 = tr1;
			if (EIF_TEST(loc13)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			tr1 = tr3;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(loc13)-1184])(loc13, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 206L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			loc8 = tr3;
			RTCT0("attached yyval6.items as l_items", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_1_);
			loc14 = tr1;
			if (EIF_TEST(loc14)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			tr1 = tr3;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(loc14)-1184])(loc14, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 207L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 208L:
			loc8 = RTLNS(eif_new_type(1313, 0x01).id, 1313, _OBJSIZ_2_3_0_0_0_0_0_0_);
			F1314_10048(RTCW(loc8));
			RTCT0("attached yyval6.items as l_items", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_1_);
			loc15 = tr1;
			if (EIF_TEST(loc15)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			tr1 = tr3;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(loc15)-1184])(loc15, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 209L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			loc8 = tr3;
			RTCT0("attached yyval6.items as l_items", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_1_);
			loc16 = tr1;
			if (EIF_TEST(loc16)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			tr1 = tr3;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(loc16)-1184])(loc16, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 210L:
			loc8 = RTLNS(eif_new_type(1313, 0x01).id, 1313, _OBJSIZ_2_3_0_0_0_0_0_0_);
			F1314_10049(RTCW(loc8));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 3L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 211L:
			loc8 = RTLNS(eif_new_type(1313, 0x01).id, 1313, _OBJSIZ_2_3_0_0_0_0_0_0_);
			F1314_10049(RTCW(loc8));
			F1314_10063(RTCW(loc8));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 4L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 212L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			F1314_10063(RTCW(loc8));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 6L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 4L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 213L:
			loc8 = RTLNS(eif_new_type(1313, 0x01).id, 1313, _OBJSIZ_2_3_0_0_0_0_0_0_);
			F1314_10049(RTCW(loc8));
			RTCT0("attached yyval6.items as l_items", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_1_);
			loc17 = tr1;
			if (EIF_TEST(loc17)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			tr1 = F1311_9916(Current, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(loc17)-1184])(loc17, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_23_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 214L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_)));
			/* END INLINED CODE */
			loc8 = tr3;
			RTCT0("attached yyval6.items as l_items", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_1_);
			loc18 = tr1;
			if (EIF_TEST(loc18)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			tr1 = F1311_9916(Current, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(loc18)-1184])(loc18, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_33_), loc8, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_24_));
			}
			break;
		case 215L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 216L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 217L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 218L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 219L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 220L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 221L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 222L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_35_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_26_)));
			/* END INLINED CODE */
			tr2 = tr4;
			F1311_9917(Current, tr1, tr2);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 6L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_26_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 223L:
			tr1 = RTOSCF(1532,F125_1532, (Current));
			F1311_9901(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 224L:
			loc9 = F1311_9909(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1185_7932(RTCW(loc9), tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_26_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_26_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_25_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_25_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_36_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_35_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_25_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_35_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_36_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_35_), loc9, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_26_));
			}
			break;
		case 225L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_35_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_26_)));
			/* END INLINED CODE */
			loc9 = tr3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1185_7932(RTCW(loc9), tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_36_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_35_), loc9, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_26_));
			}
			break;
		case 226L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			loc10 = tr3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1297_9303(RTCW(loc10), tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1297_9309(RTCW(loc10), tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 6L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 227L:
			tr1 = RTOSCF(1533,F125_1533, (Current));
			F1311_9901(Current, tr1);
			loc10 = RTLNS(eif_new_type(1296, 0x01).id, 1296, _OBJSIZ_3_3_0_0_0_0_0_0_);
			F1297_9300(RTCW(loc10));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 228L:
			loc10 = F1311_9908(Current);
			F1297_9317(RTCW(loc10));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 229L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_)));
			/* END INLINED CODE */
			loc10 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 230L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_)));
			/* END INLINED CODE */
			loc10 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 231L:
			loc10 = F1311_9908(Current);
			F1297_9323(RTCW(loc10));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 232L:
			loc10 = F1311_9908(Current);
			F1297_9325(RTCW(loc10));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 233L:
			loc10 = F1311_9908(Current);
			F1297_9325(RTCW(loc10));
			F1297_9331(RTCW(loc10));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 234L:
			loc10 = F1311_9908(Current);
			F1297_9327(RTCW(loc10));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 235L:
			loc10 = F1311_9908(Current);
			F1297_9327(RTCW(loc10));
			F1297_9331(RTCW(loc10));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 236L:
			loc10 = F1311_9908(Current);
			F1297_9329(RTCW(loc10));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 237L:
			loc10 = F1311_9908(Current);
			F1297_9329(RTCW(loc10));
			F1297_9331(RTCW(loc10));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 238L:
			loc10 = F1311_9908(Current);
			F1297_9319(RTCW(loc10));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 239L:
			loc10 = F1311_9908(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_30_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1297_9333(RTCW(loc10), tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_30_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 240L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 241L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 242L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 243L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_30_)));
			/* END INLINED CODE */
			loc11 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_39_), loc11, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_30_));
			}
			break;
		case 244L:
			loc11 = F269_2473(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1185_7932(RTCW(loc11), tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_30_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_30_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_29_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_29_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_39_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_29_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_39_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_39_), loc11, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_30_));
			}
			break;
		case 245L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_30_)));
			/* END INLINED CODE */
			loc11 = tr3;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1185_7932(RTCW(loc11), tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 4L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_39_), loc11, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_30_));
			}
			break;
		case 246L:
			loc10 = F1311_9908(Current);
			F1297_9311(RTCW(loc10));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 247L:
			loc10 = F1311_9908(Current);
			F1297_9313(RTCW(loc10));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 248L:
			loc10 = F1311_9908(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1297_9315(RTCW(loc10), tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 249L:
			loc10 = F1311_9908(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1297_9307(RTCW(loc10), tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_27_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_37_), loc10, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_28_));
			}
			break;
		case 250L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 251L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 252L:
			tr1 = RTOSCF(1536,F125_1536, (Current));
			F1311_9901(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 253L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 254L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 255L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 256L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 257L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
			F1303_9494(RTCW(tr1));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 258L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 0L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 259L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 260L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 261L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 262L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 263L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 264L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 265L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 266L:
			tr1 = RTOSCF(1534,F125_1534, (Current));
			F1311_9901(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 267L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 2L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 2L))));
			/* END INLINED CODE */
			tr2 = tr4;
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr3 = tr5;
			tr2 = F1311_9918(Current, tr2, tr3);
			F1311_9920(Current, tr1, tr2);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 2L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			F129_1557(Current, tr1, (EIF_BOOLEAN) 0, tr2, NULL, NULL);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 7L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 4L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 268L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_)));
			/* END INLINED CODE */
			tr2 = tr4;
			tr2 = F1311_9919(Current, tr2);
			F1311_9920(Current, tr1, tr2);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_)));
			/* END INLINED CODE */
			tr2 = tr4;
			F129_1557(Current, tr1, (EIF_BOOLEAN) 0, NULL, tr2, NULL);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 7L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 269L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 2L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_)));
			/* END INLINED CODE */
			tr2 = tr4;
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr3 = tr5;
			F129_1557(Current, tr1, (EIF_BOOLEAN) 0, NULL, tr2, tr3);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 8L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 4L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 270L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 2L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 2L))));
			/* END INLINED CODE */
			tr2 = tr4;
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr5 = *((EIF_REFERENCE *)RTCW(tr3) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr3 = tr5;
			tr2 = F1311_9918(Current, tr2, tr3);
			F1311_9921(Current, tr1, tr2);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 2L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr2 = tr4;
			F129_1557(Current, tr1, (EIF_BOOLEAN) 1, tr2, NULL, NULL);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 9L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 5L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 271L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_)));
			/* END INLINED CODE */
			tr2 = tr4;
			tr2 = F1311_9919(Current, tr2);
			F1311_9921(Current, tr1, tr2);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_)));
			/* END INLINED CODE */
			tr2 = tr4;
			F129_1557(Current, tr1, (EIF_BOOLEAN) 1, NULL, tr2, NULL);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 9L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 4L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 272L:
			loc5 = F1311_9910(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1260_8760(RTCW(loc5), tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_21_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_21_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_31_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_21_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_31_), loc5, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_));
			}
			break;
		case 273L:
			loc5 = F1311_9910(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			F1260_8761(RTCW(loc5), tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1260_8760(RTCW(loc5), tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 2L);
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_21_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_21_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_31_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_21_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_31_), loc5, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_));
			}
			break;
		case 274L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 4L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 275L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 0L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))++;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_23_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_13_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 276L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 4L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 277L:
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 6L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 4L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 278L:
			tr1 = RTOSCF(1510,F125_1510, (Current));
			F1311_9901(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 279L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 4L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 280L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			loc3 = tr3;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 5L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 4L);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_29_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_));
			}
			break;
		case 281L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_)));
			/* END INLINED CODE */
			tr2 = tr4;
			F129_1558(Current, tr1, tr2);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 7L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 282L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_) - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tr1 = tr3;
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
			/* INLINED CODE (SPECIAL.item) */
			tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_)));
			/* END INLINED CODE */
			tr2 = tr4;
			F129_1558(Current, tr1, tr2);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 7L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)) -= ((EIF_INTEGER_32) 3L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 283L:
			tr1 = RTOSCF(1535,F125_1535, (Current));
			F1311_9901(Current, tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_)) -= ((EIF_INTEGER_32) 2L);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr3 = RTCCL(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_14_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, ti4_1);
			}
			break;
		case 284L:
			loc5 = F1311_9910(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_)));
			/* END INLINED CODE */
			tr1 = tr3;
			F1260_8760(RTCW(loc5), tr1);
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_10_) >= ((EIF_INTEGER_32) 104L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_8_))--;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_))++;
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_20_))--;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_) >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_21_))) {
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_21_)) += ((EIF_INTEGER_32) 10L);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
					tr1 = F24_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_31_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_21_));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
				F24_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_31_), loc5, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_22_));
			}
			break;
		default:
			F1308_9648(Current);
			break;
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yy_do_error_action */
void F1312_9951 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	switch (arg1) {
		case 465L:
			F1308_9655(Current);
			break;
		default:
			tr1 = RTMS_EX_H("parse error",11,283683698);
			F1311_9900(Current, tr1);
			break;
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yytranslate_template */
static EIF_REFERENCE F1312_9952_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	

	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9952);
#define Result RTOSR(9952)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,739,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 739, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F740_4058(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 349L));
	F1312_9953(Current, loc1);
	F1312_9954(Current, loc1);
	Result = F1308_9686(Current, loc1);
	RTOSE (9952);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1312_9952 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9952,F1312_9952_body,(Current));
}

/* {XM_EIFFEL_PARSER}.yytranslate_template_1 */
void F1312_9953 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yytranslate_template_2 */
void F1312_9954 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 151L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 151L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 14L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 17L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 18L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 19L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 21L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 24L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 25L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 26L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 27L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 28L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 29L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 30L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 31L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 34L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 35L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 36L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 37L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 38L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 39L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 40L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 41L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 45L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 46L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 47L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 48L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 49L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 51L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 52L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 53L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 54L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 55L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 57L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 58L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 64L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 65L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 68L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 69L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 71L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 72L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 73L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 74L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 75L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 76L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 77L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 78L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 79L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 80L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 81L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 82L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 83L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 84L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 85L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 86L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 87L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 88L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 89L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 90L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 91L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 92L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 93L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 150L), ((EIF_INTEGER_32) 200L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yyr1_template */
static EIF_REFERENCE F1312_9955_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	

	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9955);
#define Result RTOSR(9955)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,739,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 739, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F740_4058(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 284L));
	F1312_9956(Current, loc1);
	F1312_9957(Current, loc1);
	Result = F1308_9686(Current, loc1);
	RTOSE (9955);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1312_9955 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9955,F1312_9955_body,(Current));
}

/* {XM_EIFFEL_PARSER}.yyr1_template_1 */
void F1312_9956 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 158L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 95L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 95L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 95L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 95L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 95L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 101L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 101L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 105L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 105L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 106L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 106L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 107L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 107L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 102L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 102L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 102L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 108L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 108L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 109L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 109L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 110L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 110L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 111L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 111L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 162L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 162L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 163L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 163L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 164L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 164L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 112L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 112L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 112L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 113L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 113L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 114L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 114L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 119L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 116L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 116L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 117L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 117L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 117L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 118L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 118L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 165L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 165L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 166L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 166L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 120L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 120L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 121L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 121L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 122L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 122L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 167L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 167L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 167L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 168L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 168L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 168L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 123L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 123L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 123L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 125L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 125L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 126L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 126L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 126L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 124L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 124L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 169L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 169L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 170L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 170L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 171L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 159L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 157L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 157L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 157L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 172L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 172L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 172L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 161L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 161L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 173L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 173L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 155L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 155L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 156L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 156L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 156L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 156L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 153L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 153L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 153L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 153L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 151L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 151L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 175L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 175L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 175L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 174L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 174L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 179L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 176L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 130L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 177L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 178L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 182L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 182L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 183L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 183L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 184L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 184L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 180L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 180L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 180L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 187L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 187L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 185L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 185L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 185L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 185L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 185L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 185L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 185L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 185L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 154L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 154L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 154L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 154L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 160L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 160L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 160L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 160L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 160L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 97L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 97L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 97L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 192L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 192L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 96L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 99L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 99L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 98L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 98L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 193L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 193L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 194L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 194L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 194L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 194L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 194L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 194L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 194L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 195L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 195L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 195L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 127L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 127L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 188L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 188L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 133L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 133L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 133L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 133L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 134L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 134L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 134L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 134L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 135L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 135L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 135L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 135L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 135L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yyr1_template_2 */
void F1312_9957 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 86L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 86L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 135L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 142L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 142L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 142L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 136L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 137L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 137L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 138L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 139L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 139L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 140L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 140L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 140L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 141L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 141L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 132L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 196L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 197L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 199L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 198L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 200L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 189L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 189L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 189L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 143L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 143L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 144L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 144L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 145L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 145L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 145L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 146L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 146L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 146L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 146L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 146L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 146L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 146L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 147L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 147L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 201L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 202L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 202L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 149L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 150L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 150L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 148L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 148L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 148L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 148L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 186L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 186L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 186L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 203L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 203L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 205L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 204L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 206L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 207L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 207L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 208L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 208L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 209L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 209L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 190L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 190L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 190L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 210L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 210L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 210L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 211L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 211L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 128L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 128L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 131L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 181L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 181L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 181L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 181L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 152L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 152L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 191L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 191L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 191L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 129L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 85L), ((EIF_INTEGER_32) 200L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yytypes1_template */
static EIF_REFERENCE F1312_9958_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	

	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9958);
#define Result RTOSR(9958)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,739,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 739, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F740_4058(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 467L));
	F1312_9959(Current, loc1);
	F1312_9960(Current, loc1);
	F1312_9961(Current, loc1);
	Result = F1308_9686(Current, loc1);
	RTOSE (9958);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1312_9958 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9958,F1312_9958_body,(Current));
}

/* {XM_EIFFEL_PARSER}.yytypes1_template_1 */
void F1312_9959 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yytypes1_template_2 */
void F1312_9960 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 200L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yytypes1_template_3 */
void F1312_9961 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 69L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 69L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 68L), ((EIF_INTEGER_32) 400L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yytypes2_template */
static EIF_REFERENCE F1312_9962_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (9962);
#define Result RTOSR(9962)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 96L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 96L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	Result = F1308_9686(Current, tr1);
	RTOSE (9962);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1312_9962 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9962,F1312_9962_body,(Current));
}

/* {XM_EIFFEL_PARSER}.yydefact_template */
static EIF_REFERENCE F1312_9963_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	

	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9963);
#define Result RTOSR(9963)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,739,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 739, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F740_4058(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 467L));
	F1312_9964(Current, loc1);
	F1312_9965(Current, loc1);
	F1312_9966(Current, loc1);
	Result = F1308_9686(Current, loc1);
	RTOSE (9963);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1312_9963 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9963,F1312_9963_body,(Current));
}

/* {XM_EIFFEL_PARSER}.yydefact_template_1 */
void F1312_9964 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 105L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 79L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 123L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 102L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 99L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 121L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 122L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 106L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 107L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 110L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 21L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 76L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 68L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 75L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 72L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 71L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 101L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 98L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 124L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 105L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 154L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 108L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 47L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 48L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 111L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 45L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 74L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 73L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 275L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 125L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 161L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 164L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 178L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 181L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 180L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 182L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 184L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 158L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 155L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 183L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 173L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 175L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 177L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 176L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 174L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 171L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 179L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 116L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 117L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 109L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 46L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 78L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 91L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 92L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 85L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 41L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 40L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 37L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 36L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 35L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 34L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 31L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 30L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 29L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 39L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 38L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 19L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 18L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 28L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 137L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 137L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 131L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 14L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 159L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 162L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 170L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 93L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 97L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 95L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 157L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 156L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 172L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 118L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 113L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 112L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 77L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 90L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 88L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 89L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 84L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 83L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 126L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 278L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 82L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 148L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 149L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 147L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 146L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 132L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 133L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 135L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 136L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 142L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 143L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 144L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 145L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 250L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 251L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 258L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 264L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 265L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 165L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 169L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 96L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 120L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 119L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yydefact_template_2 */
void F1312_9965 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 87L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 86L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 27L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 26L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 272L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 140L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 129L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 127L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 252L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 283L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 266L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 186L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 130L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 134L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 253L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 258L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 262L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 259L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 260L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 168L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 160L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 163L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 114L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 273L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 128L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 138L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 141L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 276L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 69L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 254L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 256L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 261L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 167L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 166L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 280L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 279L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 153L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 151L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 152L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 150L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 139L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 224L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 81L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 263L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 64L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 65L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 57L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 277L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 257L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 284L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 225L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 221L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 190L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 80L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 58L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 49L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 25L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 24L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 54L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 55L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 222L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 227L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 216L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 188L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 187L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 185L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 192L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 191L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 194L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 193L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 189L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 195L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 208L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 281L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 282L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 51L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 53L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 52L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 267L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 268L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 237L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 236L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 235L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 234L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 233L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 232L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 231L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 228L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 229L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 230L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 239L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 238L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 202L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 200L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yydefact_template_3 */
void F1312_9966 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 69L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 69L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 201L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 203L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 220L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 196L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 215L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 198L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 197L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 200L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 199L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 219L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 207L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 210L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 269L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 17L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 217L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 205L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 218L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 209L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 213L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 211L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 270L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 271L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 274L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 247L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 246L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 249L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 226L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 244L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 243L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 204L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 241L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 206L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 214L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 212L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 240L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 248L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 245L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 242L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 68L), ((EIF_INTEGER_32) 400L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yydefgoto_template */
static EIF_REFERENCE F1312_9967_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (9967);
#define Result RTOSR(9967)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 118L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 118L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 191L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 64L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 35L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 74L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 192L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 193L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 124L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 425L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 364L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 209L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 24L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 65L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 126L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 117L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 152L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 45L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 340L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 313L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 341L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 342L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 274L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 302L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 303L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 304L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 343L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 25L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 26L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 27L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 98L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 99L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 153L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 154L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 76L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 210L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 310L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 118L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 345L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 365L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 322L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 323L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 366L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 367L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 430L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 368L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 369L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 326L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 435L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 358L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 289L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 290L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 393L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 394L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 395L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 445L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 396L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 427L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 92L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 41L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 93L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 46L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 465L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 77L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 404L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 148L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 49L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 173L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 174L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 80L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 135L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 136L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 30L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 31L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 58L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 119L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 158L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 121L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 175L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 176L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 177L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 178L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 179L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 213L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 180L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 181L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 182L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 183L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 37L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 81L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 82L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 83L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 370L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 406L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 413L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 414L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 371L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 398L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 454L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 184L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 185L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 186L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 187L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 237L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 238L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 239L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 188L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 189L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	Result = F1308_9686(Current, tr1);
	RTOSE (9967);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1312_9967 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9967,F1312_9967_body,(Current));
}

/* {XM_EIFFEL_PARSER}.yypact_template */
static EIF_REFERENCE F1312_9968_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	

	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9968);
#define Result RTOSR(9968)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,739,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 739, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F740_4058(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 467L));
	F1312_9969(Current, loc1);
	F1312_9970(Current, loc1);
	F1312_9971(Current, loc1);
	Result = F1308_9686(Current, loc1);
	RTOSE (9968);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1312_9968 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9968,F1312_9968_body,(Current));
}

/* {XM_EIFFEL_PARSER}.yypact_template_1 */
void F1312_9969 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 511L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 155L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 317L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 585L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 474L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 524L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 479L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 474L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 348L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 536L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 247L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 247L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 474L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 474L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 512L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 54L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 112L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 474L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 529L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 525L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 396L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 504L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 371L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 501L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 517L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 444L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 474L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 491L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 414L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 423L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 220L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 28L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 319L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 14L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 478L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 469L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 435L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 348L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 348L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 437L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 663L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 449L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 449L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 179L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 638L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 414L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 131L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -49L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 194L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 422L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 399L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 382L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 375L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 49L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 663L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 663L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 688L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 709L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 383L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 381L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 246L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 352L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 337L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 310L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 229L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 317L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 443L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 367L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 638L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 627L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 34L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 202L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 369L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yypact_template_2 */
void F1312_9970 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 365L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 254L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 200L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 152L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 675L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 425L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 356L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 150L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 444L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 407L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 444L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 444L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 366L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 590L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 34L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 291L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 34L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 268L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 131L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 315L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 333L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 313L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 309L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 279L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 263L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 251L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 517L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 190L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 74L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 235L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 226L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 221L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 586L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 444L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 270L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 209L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 444L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 409L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 215L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 71L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 53L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 152L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 362L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 199L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 55L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 196L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 316L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 316L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 481L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 185L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 176L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 270L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 280L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 106L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 149L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 146L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 505L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 316L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 128L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 316L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 316L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 86L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 518L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 105L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 364L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 200L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yypact_template_3 */
void F1312_9971 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 69L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 69L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 518L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 518L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 555L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 88L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 79L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 25L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 444L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 346L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 169L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 555L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 364L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 518L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 555L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 26L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -4L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 555L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 47L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 35L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 68L), ((EIF_INTEGER_32) 400L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yypgoto_template */
static EIF_REFERENCE F1312_9972_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (9972);
#define Result RTOSR(9972)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 118L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 118L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -18L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 552L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 388L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 507L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 177L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -54L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -199L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -27L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -46L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -115L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 288L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 207L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -389L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 283L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 452L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 462L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 341L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 296L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -267L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -392L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -230L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 328L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 327L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -175L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 320L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 487L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -110L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 351L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 459L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 596L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 566L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -16L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -12L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 40L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -21L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 458L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 129L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 476L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 415L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -138L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -108L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 506L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -288L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -360L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -156L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 338L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 332L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	Result = F1308_9686(Current, tr1);
	RTOSE (9972);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1312_9972 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9972,F1312_9972_body,(Current));
}

/* {XM_EIFFEL_PARSER}.yytable_template */
static EIF_REFERENCE F1312_9973_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	

	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9973);
#define Result RTOSR(9973)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,739,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 739, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F740_4058(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 776L));
	F1312_9974(Current, loc1);
	F1312_9975(Current, loc1);
	F1312_9976(Current, loc1);
	F1312_9977(Current, loc1);
	Result = F1308_9686(Current, loc1);
	RTOSE (9973);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1312_9973 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9973,F1312_9973_body,(Current));
}

/* {XM_EIFFEL_PARSER}.yytable_template_1 */
void F1312_9974 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 47L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 116L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 19L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 48L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 327L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 172L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 51L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 75L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 252L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 162L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 415L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 241L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 125L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 79L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 137L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 55L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 240L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 309L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 314L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 72L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 434L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 96L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 28L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 131L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 194L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 444L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 467L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 71L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 127L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 232L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 460L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 405L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 78L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 172L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 134L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 466L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 453L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 212L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 97L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 132L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 130L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 75L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 349L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 438L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 458L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 79L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 172L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 397L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 462L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 447L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 375L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 464L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 449L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 172L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 151L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 459L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 91L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 451L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 145L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 147L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 146L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 125L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 383L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 78L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 34L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 69L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 461L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 232L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 127L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 172L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 273L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 155L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 68L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 156L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 256L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 257L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 235L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 134L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 252L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 437L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 73L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 172L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 72L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 151L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 151L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 412L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 331L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 411L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 440L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 71L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 436L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 419L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 38L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 299L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 298L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 297L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 217L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 219L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 329L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 216L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 360L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 300L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 221L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 225L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 227L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 38L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 412L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 405L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 236L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 299L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 298L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 297L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 299L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 298L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 297L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 261L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 228L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 263L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 264L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 405L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 265L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 338L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 337L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 429L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 14L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 382L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 160L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 244L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 380L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 378L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 432L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 38L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 251L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 403L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 34L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 69L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 407L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 409L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 253L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 254L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 68L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yytable_template_2 */
void F1312_9975 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 14L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 207L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 206L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 90L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 236L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 373L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 236L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 266L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 416L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 267L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 372L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 457L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 260L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 259L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 443L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 442L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 441L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 195L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 250L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 249L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 354L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 226L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 348L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 311L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 328L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 318L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 282L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 96L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 283L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 317L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 284L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 285L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 273L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 301L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 218L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 291L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 286L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 287L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 288L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 292L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 293L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 307L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 305L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 306L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 296L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 97L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 294L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 448L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 281L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 316L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 450L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 301L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 301L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 292L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 452L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 248L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 247L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 243L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 242L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 339L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 280L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 333L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 334L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 344L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 346L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 335L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 129L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 128L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 347L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 351L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 352L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 353L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 350L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 359L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 361L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 362L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 224L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 339L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 339L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -43L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -43L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 279L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 208L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 207L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 206L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 278L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 276L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 381L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 18L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 17L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 222L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 399L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 400L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 401L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 277L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 426L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 273L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 312L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 402L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 338L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 337L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 133L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 408L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 410L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 220L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 40L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 39L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 376L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 417L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 418L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 433L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 357L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 356L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 355L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 271L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 439L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 114L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 424L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 423L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 420L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 421L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 258L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 268L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 422L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 202L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 201L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 433L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 319L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 428L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 200L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 199L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 426L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 246L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 431L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 91L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 433L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 245L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 90L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 200L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yytable_template_3 */
void F1312_9976 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 113L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 112L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 231L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 88L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 87L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 433L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 198L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 446L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 114L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 215L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 214L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 111L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 110L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 109L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 108L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 107L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 106L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 105L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 455L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 338L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 337L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 197L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 102L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 101L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 336L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 463L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 143L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 144L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 113L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 112L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 321L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 320L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 114L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 204L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 205L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 319L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 90L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 149L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 229L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 142L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 111L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 110L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 109L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 108L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 107L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 106L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 105L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 262L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 102L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 101L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 113L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 112L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 157L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 114L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 140L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 53L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 54L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 141L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 94L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 123L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 122L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 111L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 110L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 109L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 108L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 107L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 106L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 105L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 127L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 120L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 102L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 101L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 113L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 112L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 95L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 114L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 319L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 89L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 363L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 86L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 18L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 17L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 85L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 111L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 110L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 109L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 108L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 107L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 106L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 105L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 57L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 319L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 377L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 379L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 52L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 102L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 101L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 113L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 112L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 29L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 34L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 115L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 114L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 319L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 392L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 391L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 390L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 389L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 388L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 387L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 386L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 385L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 384L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 272L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 270L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 111L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 110L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 109L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 108L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 107L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 106L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 105L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 330L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 332L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 139L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 102L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 101L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 113L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 112L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 196L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 159L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 171L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 21L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 400L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yytable_template_4 */
void F1312_9977 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 178L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 178L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 234L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 84L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 170L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 36L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 203L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 169L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 161L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 295L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 315L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 168L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 111L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 110L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 109L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 108L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 107L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 106L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 105L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 325L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 324L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 230L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 374L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 456L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 102L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 101L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 167L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 166L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 165L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 164L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 275L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 138L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 190L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 171L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 308L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 207L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 206L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 170L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 169L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 171L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 168L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 170L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 169L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 168L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 163L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 269L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 167L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 166L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 165L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 164L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 150L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 167L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 166L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 165L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 164L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 18L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 17L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 171L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 170L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 169L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 168L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 163L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 233L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 163L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 167L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 166L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 165L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 164L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 171L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 170L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 169L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 168L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 208L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 207L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 206L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 211L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 167L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 166L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 165L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 164L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 177L), ((EIF_INTEGER_32) 600L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yycheck_template */
static EIF_REFERENCE F1312_9978_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	

	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9978);
#define Result RTOSR(9978)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,739,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 739, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F740_4058(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 776L));
	F1312_9979(Current, loc1);
	F1312_9980(Current, loc1);
	F1312_9981(Current, loc1);
	F1312_9982(Current, loc1);
	Result = F1308_9686(Current, loc1);
	RTOSE (9978);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1312_9978 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9978,F1312_9978_body,(Current));
}

/* {XM_EIFFEL_PARSER}.yycheck_template_1 */
void F1312_9979 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 55L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 19L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 293L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 121L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 19L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 35L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 208L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 120L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 371L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 35L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 34L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 29L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 286L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 288L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 415L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 51L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 81L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 422L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 86L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 176L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 35L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 157L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 30L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 440L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 157L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 51L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 69L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 64L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 31L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 81L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 451L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 81L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 176L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 350L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 455L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 427L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 335L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 461L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 430L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 186L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 99L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 47L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 25L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 435L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 92L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 93L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 92L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 127L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 72L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 81L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 48L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 51L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 78L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 79L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 454L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 55L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 234L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 86L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 213L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 76L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 116L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 87L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 88L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 89L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 116L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 213L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 216L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 73L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 135L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 308L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 82L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 83L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 86L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 234L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 153L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 154L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 77L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 45L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 421L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 47L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 82L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 83L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 86L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 30L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 90L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 91L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 92L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 162L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 163L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 77L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 161L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 325L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 77L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 164L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 165L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 166L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 167L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 28L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 43L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 187L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 90L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 91L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 92L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 90L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 91L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 92L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 221L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 169L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 130L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 225L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 44L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 227L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 68L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 69L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 406L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 193L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 77L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 414L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 146L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 203L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 148L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 364L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 78L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 79L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 367L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 368L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 210L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 211L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 156L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 87L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yycheck_template_2 */
void F1312_9980 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 88L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 89L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 23L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 51L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 52L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 28L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 235L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 238L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 228L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 82L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 83L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 371L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 228L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 86L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 449L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 71L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 53L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 54L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 55L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 31L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 26L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 27L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 287L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 19L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 292L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 267L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 257L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 259L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 260L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 76L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 273L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 264L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 261L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 262L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 263L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 264L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 265L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 34L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 216L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 34L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 221L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 223L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 74L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 225L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 267L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 227L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 19L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 427L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 289L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 430L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 302L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 303L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 289L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 435L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 26L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 27L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 80L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 81L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 244L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 312L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 309L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 310L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 313L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 314L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 311L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 80L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 81L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 314L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 319L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 320L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 321L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 318L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 267L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 324L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 325L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 326L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 341L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 342L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 71L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 51L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 52L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 286L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 287L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 288L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 345L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 292L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 293L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 17L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 18L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 355L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 356L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 357L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 397L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 76L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 76L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 363L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 68L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 69L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 31L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 367L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 368L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 77L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 374L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 375L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 415L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 46L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 47L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 48L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 74L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 420L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 383L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 384L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 335L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 14L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 393L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 440L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 347L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 405L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 350L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 447L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 29L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 411L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 25L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 451L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 29L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 28L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 200L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yycheck_template_3 */
void F1312_9981 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 201L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 201L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 36L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 37L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 35L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 461L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 425L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 33L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 57L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 58L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 64L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 441L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 68L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 69L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 71L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 72L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 77L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 456L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 90L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 91L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 36L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 37L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 36L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 37L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 153L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 154L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 28L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 19L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 14L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 24L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 420L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 421L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 422L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 57L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 58L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 64L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 65L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 71L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 72L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 36L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 37L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 34L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 26L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 27L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 24L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 455L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 82L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 83L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 84L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 85L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 57L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 58L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 64L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 86L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 21L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 71L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 72L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 36L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 37L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 19L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 22L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 49L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 21L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 17L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 18L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 57L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 58L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 64L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 34L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 341L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 342L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 14L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 71L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 72L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 36L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 37L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 78L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 42L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 57L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 58L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 64L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 238L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 235L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 57L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 58L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	*((EIF_INTEGER_32 *)tr2+178) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	*((EIF_INTEGER_32 *)tr2+179) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
	*((EIF_INTEGER_32 *)tr2+180) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
	*((EIF_INTEGER_32 *)tr2+181) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
	*((EIF_INTEGER_32 *)tr2+182) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 64L);
	*((EIF_INTEGER_32 *)tr2+183) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+184) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+185) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 302L);
	*((EIF_INTEGER_32 *)tr2+186) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 303L);
	*((EIF_INTEGER_32 *)tr2+187) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 81L);
	*((EIF_INTEGER_32 *)tr2+188) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
	*((EIF_INTEGER_32 *)tr2+189) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 71L);
	*((EIF_INTEGER_32 *)tr2+190) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 72L);
	*((EIF_INTEGER_32 *)tr2+191) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 36L);
	*((EIF_INTEGER_32 *)tr2+192) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 37L);
	*((EIF_INTEGER_32 *)tr2+193) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 135L);
	*((EIF_INTEGER_32 *)tr2+194) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+195) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 119L);
	*((EIF_INTEGER_32 *)tr2+196) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+197) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+198) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+199) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 14L);
	*((EIF_INTEGER_32 *)tr2+200) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 400L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yycheck_template_4 */
void F1312_9982 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 178L),sizeof(EIF_INTEGER_32), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 178L;
	}
	*((EIF_INTEGER_32 *)tr2+0) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
	*((EIF_INTEGER_32 *)tr2+1) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 186L);
	*((EIF_INTEGER_32 *)tr2+2) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 36L);
	*((EIF_INTEGER_32 *)tr2+3) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	*((EIF_INTEGER_32 *)tr2+4) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+5) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 146L);
	*((EIF_INTEGER_32 *)tr2+6) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+7) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 120L);
	*((EIF_INTEGER_32 *)tr2+8) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 267L);
	*((EIF_INTEGER_32 *)tr2+9) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 289L);
	*((EIF_INTEGER_32 *)tr2+10) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+11) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 56L);
	*((EIF_INTEGER_32 *)tr2+12) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 57L);
	*((EIF_INTEGER_32 *)tr2+13) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 58L);
	*((EIF_INTEGER_32 *)tr2+14) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	*((EIF_INTEGER_32 *)tr2+15) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	*((EIF_INTEGER_32 *)tr2+16) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 61L);
	*((EIF_INTEGER_32 *)tr2+17) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 62L);
	*((EIF_INTEGER_32 *)tr2+18) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
	*((EIF_INTEGER_32 *)tr2+19) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 64L);
	*((EIF_INTEGER_32 *)tr2+20) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 293L);
	*((EIF_INTEGER_32 *)tr2+21) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 293L);
	*((EIF_INTEGER_32 *)tr2+22) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 170L);
	*((EIF_INTEGER_32 *)tr2+23) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 335L);
	*((EIF_INTEGER_32 *)tr2+24) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 447L);
	*((EIF_INTEGER_32 *)tr2+25) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 70L);
	*((EIF_INTEGER_32 *)tr2+26) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 71L);
	*((EIF_INTEGER_32 *)tr2+27) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 72L);
	*((EIF_INTEGER_32 *)tr2+28) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 38L);
	*((EIF_INTEGER_32 *)tr2+29) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 39L);
	*((EIF_INTEGER_32 *)tr2+30) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 40L);
	*((EIF_INTEGER_32 *)tr2+31) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 41L);
	*((EIF_INTEGER_32 *)tr2+32) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 244L);
	*((EIF_INTEGER_32 *)tr2+33) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 81L);
	*((EIF_INTEGER_32 *)tr2+34) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 127L);
	*((EIF_INTEGER_32 *)tr2+35) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+36) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	*((EIF_INTEGER_32 *)tr2+37) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 51L);
	*((EIF_INTEGER_32 *)tr2+38) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 52L);
	*((EIF_INTEGER_32 *)tr2+39) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+40) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	*((EIF_INTEGER_32 *)tr2+41) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+42) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+43) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+44) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+45) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+46) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+47) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+48) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+49) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+50) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+51) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	*((EIF_INTEGER_32 *)tr2+52) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+53) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+54) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+55) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+56) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+57) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+58) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+59) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+60) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+61) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+62) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+63) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 73L);
	*((EIF_INTEGER_32 *)tr2+64) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 74L);
	*((EIF_INTEGER_32 *)tr2+65) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 38L);
	*((EIF_INTEGER_32 *)tr2+66) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 39L);
	*((EIF_INTEGER_32 *)tr2+67) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 40L);
	*((EIF_INTEGER_32 *)tr2+68) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 41L);
	*((EIF_INTEGER_32 *)tr2+69) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+70) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+71) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+72) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+73) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+74) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 11L);
	*((EIF_INTEGER_32 *)tr2+75) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
	*((EIF_INTEGER_32 *)tr2+76) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 38L);
	*((EIF_INTEGER_32 *)tr2+77) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 39L);
	*((EIF_INTEGER_32 *)tr2+78) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 40L);
	*((EIF_INTEGER_32 *)tr2+79) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 41L);
	*((EIF_INTEGER_32 *)tr2+80) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 17L);
	*((EIF_INTEGER_32 *)tr2+81) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 18L);
	*((EIF_INTEGER_32 *)tr2+82) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+83) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+84) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+85) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+86) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+87) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+88) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	*((EIF_INTEGER_32 *)tr2+89) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+90) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+91) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+92) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+93) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+94) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+95) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+96) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+97) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+98) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+99) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+100) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 73L);
	*((EIF_INTEGER_32 *)tr2+101) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 74L);
	*((EIF_INTEGER_32 *)tr2+102) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+103) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+104) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+105) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+106) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+107) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+108) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+109) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+110) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 35L);
	*((EIF_INTEGER_32 *)tr2+111) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 73L);
	*((EIF_INTEGER_32 *)tr2+112) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+113) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 38L);
	*((EIF_INTEGER_32 *)tr2+114) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 39L);
	*((EIF_INTEGER_32 *)tr2+115) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 40L);
	*((EIF_INTEGER_32 *)tr2+116) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 41L);
	*((EIF_INTEGER_32 *)tr2+117) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
	*((EIF_INTEGER_32 *)tr2+118) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+119) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+120) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+121) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+122) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	*((EIF_INTEGER_32 *)tr2+123) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+124) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+125) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	*((EIF_INTEGER_32 *)tr2+126) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+127) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+128) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+129) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*((EIF_INTEGER_32 *)tr2+130) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+131) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+132) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+133) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+134) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+135) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+136) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+137) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+138) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	*((EIF_INTEGER_32 *)tr2+139) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 51L);
	*((EIF_INTEGER_32 *)tr2+140) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 52L);
	*((EIF_INTEGER_32 *)tr2+141) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+142) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+143) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+144) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 35L);
	*((EIF_INTEGER_32 *)tr2+145) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+146) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+147) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 38L);
	*((EIF_INTEGER_32 *)tr2+148) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 39L);
	*((EIF_INTEGER_32 *)tr2+149) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 40L);
	*((EIF_INTEGER_32 *)tr2+150) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 41L);
	*((EIF_INTEGER_32 *)tr2+151) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+152) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+153) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+154) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+155) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+156) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+157) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+158) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+159) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+160) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+161) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+162) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+163) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+164) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+165) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+166) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+167) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+168) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+169) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+170) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+171) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+172) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+173) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+174) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*((EIF_INTEGER_32 *)tr2+175) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 66L);
	*((EIF_INTEGER_32 *)tr2+176) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 67L);
	*((EIF_INTEGER_32 *)tr2+177) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F715_3978)(tr2);
	F1308_9687(Current, arg1, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 177L), ((EIF_INTEGER_32) 600L));
	RTLE;
}

/* {XM_EIFFEL_PARSER}.yyfinal */
EIF_INTEGER_32 F1312_10027 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 467L);
}

/* {XM_EIFFEL_PARSER}.yyflag */
EIF_INTEGER_32 F1312_10028 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) -32768L);
}

/* {XM_EIFFEL_PARSER}.yyntbase */
EIF_INTEGER_32 F1312_10029 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 95L);
}

/* {XM_EIFFEL_PARSER}.yylast */
EIF_INTEGER_32 F1312_10030 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 776L);
}

/* {XM_EIFFEL_PARSER}.yymax_token */
EIF_INTEGER_32 F1312_10031 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 349L);
}

/* {XM_EIFFEL_PARSER}.yynsyms */
EIF_INTEGER_32 F1312_10032 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 212L);
}

void EIF_Minit457 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
