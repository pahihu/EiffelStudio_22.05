/*
 * Code for class GEANT_INHERIT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge497.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_INHERIT}.make */
void F1352_10241 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1208,0xFF01,1352,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1209_8141(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_INHERIT}.apply_selects */
void F1352_10245 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr3) = 3L;
		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
	}
	tr4 = RTMS_EX_H("\012Project \'",10,885164839);
	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr4 = *(EIF_REFERENCE *)(Current);
	tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
	*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr4 = RTMS_EX_H("\': --> application of select clause:",36,116762426);
	*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
	F1356_10325(RTCW(tr1), tr2);
	F1352_10246(Current);
	F1352_10247(Current);
	F1352_10248(Current);
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr3) = 3L;
		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
	}
	tr4 = RTMS_EX_H("Project \'",9,213807399);
	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr4 = *(EIF_REFERENCE *)(Current);
	tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
	*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr4 = RTMS_EX_H("\': <-- application of select clause done.",41,1993166382);
	*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
	F1356_10325(RTCW(tr1), tr2);
	RTLE;
}

/* {GEANT_INHERIT}.validate_parent_selects */
void F1352_10246 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTCFDT;
	RTLD;
	
	RTLI(17);
	RTLR(0,loc10);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,loc1);
	RTLR(7,loc2);
	RTLR(8,loc11);
	RTLR(9,loc5);
	RTLR(10,loc6);
	RTLR(11,loc9);
	RTLR(12,loc3);
	RTLR(13,loc4);
	RTLR(14,loc12);
	RTLR(15,loc7);
	RTLR(16,loc8);
	RTLIU(17);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_7_);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("Project \'",9,213807399);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = *(EIF_REFERENCE *)(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = RTMS_EX_H("\': making sure there are no conflicting selects",47,2091698291);
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10325(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(loc10 + _REFACS_1_);
		loc1 = F1209_8150(RTCW(tr1));
		F1053_7395(RTCW(loc1));
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2921[Dtype(RTCW(loc1))-437])(loc1);
			if (tb1) break;
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2920[Dtype(RTCW(loc1))-437])(loc1);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
			loc11 = tr1;
			if (EIF_TEST(loc11)) {
				tr1 = *(EIF_REFERENCE *)(loc11 + _REFACS_6_);
				loc5 = F1233_8466(RTCW(tr1));
				F1053_7395(RTCW(loc5));
				for (;;) {
					tb2 = F1077_7423(RTCW(loc5));
					if (tb2) break;
					loc6 = F1039_7375(RTCW(loc5));
					loc9 = F1088_7442(RTCW(loc5));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc3 = F1209_8150(RTCW(tr1));
					F1053_7395(RTCW(loc3));
					for (;;) {
						tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2921[Dtype(RTCW(loc3))-437])(loc3);
						if (tb3) break;
						loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2920[Dtype(RTCW(loc3))-437])(loc3);
						tb4 = '\0';
						if ((EIF_BOOLEAN)(loc2 != loc4)) {
							tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
							loc12 = tr1;
							tb4 = EIF_TEST(loc12);
						}
						if (tb4) {
							tr1 = *(EIF_REFERENCE *)(loc12 + _REFACS_6_);
							loc7 = F1233_8466(RTCW(tr1));
							F1053_7395(RTCW(loc7));
							for (;;) {
								tb4 = F1077_7423(RTCW(loc7));
								if (tb4) break;
								loc8 = F1039_7375(RTCW(loc7));
								tb5 = F1430_11127(RTCW(loc6), loc8);
								if (tb5) {
									{
										static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
										EIF_TYPE typres0;
										static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
										
										typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
										tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
										RT_SPECIAL_COUNT(tr2) = 7L;
										memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
									}
									tr3 = RTMS_EX_H("Project \'",9,213807399);
									*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
									RTAR(tr2,tr3);
									tr3 = *(EIF_REFERENCE *)(Current);
									tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
									*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
									RTAR(tr2,tr3);
									tr3 = RTMS_EX_H("\': conflicting selects: `",25,1565626464);
									*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
									RTAR(tr2,tr3);
									tr3 = F1430_11111(RTCW(loc6));
									*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
									RTAR(tr2,tr3);
									tr3 = RTMS_EX_H("\' and `",7,70259808);
									*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
									RTAR(tr2,tr3);
									tr3 = F1430_11111(RTCW(loc8));
									*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
									RTAR(tr2,tr3);
									tr3 = RTMS_EX_H("\'.",2,10030);
									*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
									RTAR(tr2,tr3);
									tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
									F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
								}
								F1053_7396(RTCW(loc7));
							}
						}
						F1053_7396(RTCW(loc3));
					}
					F1053_7396(RTCW(loc5));
				}
			}
			F1053_7396(RTCW(loc1));
		}
	}
	RTLE;
}

/* {GEANT_INHERIT}.sort_out_selected_targets */
void F1352_10247 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(17);
	RTLR(0,loc11);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc12);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,loc1);
	RTLR(8,loc2);
	RTLR(9,loc13);
	RTLR(10,loc3);
	RTLR(11,loc5);
	RTLR(12,loc4);
	RTLR(13,loc6);
	RTLR(14,loc7);
	RTLR(15,loc8);
	RTLR(16,loc14);
	RTLIU(17);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_7_);
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
		loc12 = tr1;
		tb1 = EIF_TEST(loc12);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("Project \'",9,213807399);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = *(EIF_REFERENCE *)(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = RTMS_EX_H("\': removing targets conflicting with selected targets",53,1595321203);
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10325(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(loc11 + _REFACS_1_);
		loc1 = F1209_8150(RTCW(tr1));
		F1053_7395(RTCW(loc1));
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2921[Dtype(RTCW(loc1))-437])(loc1);
			if (tb1) break;
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2920[Dtype(RTCW(loc1))-437])(loc1);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
			loc13 = tr1;
			if (EIF_TEST(loc13)) {
				tr1 = *(EIF_REFERENCE *)(loc13 + _REFACS_6_);
				loc3 = F1233_8466(RTCW(tr1));
				F1053_7395(RTCW(loc3));
				for (;;) {
					tb2 = F1077_7423(RTCW(loc3));
					if (tb2) break;
					loc5 = F1088_7442(RTCW(loc3));
					tb3 = F1223_8402(loc12, loc5);
					if ((EIF_BOOLEAN) !tb3) {
						{
							static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 6L),sizeof(EIF_REFERENCE), EIF_FALSE);
							RT_SPECIAL_COUNT(tr2) = 6L;
							memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
						}
						tr3 = RTMS_EX_H("\012LOAD ERROR:\012",13,54494730);
						*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						tr3 = RTMS_EX_H("  project \'",11,175812391);
						*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						tr3 = *(EIF_REFERENCE *)(Current);
						tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
						*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						tr3 = RTMS_EX_H("\' selected target `",19,1588737120);
						*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) loc5;
						RTAR(tr2,loc5);
						tr3 = RTMS_EX_H("\' does not exist.",17,1043567662);
						*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
						F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
					}
					loc4 = F1223_8394(loc12, loc5);
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					for (;;) {
						if ((EIF_BOOLEAN)(loc9 == (EIF_BOOLEAN) 0)) break;
						loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc6 = F1233_8466(loc12);
						F1061_7406(RTCW(loc6));
						for (;;) {
							tb3 = F1077_7424(RTCW(loc6));
							if (tb3) break;
							loc7 = F1039_7375(RTCW(loc6));
							tr1 = *(EIF_REFERENCE *)(Current);
							loc8 = F1356_10300(RTCW(tr1), loc7);
							if ((EIF_BOOLEAN)(loc7 != loc4)) {
								tb4 = F1430_11127(RTCW(loc4), loc7);
								if (tb4) {
									tr1 = *(EIF_REFERENCE *)(Current);
									{
										static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
										EIF_TYPE typres0;
										static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
										
										typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
										tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
										RT_SPECIAL_COUNT(tr3) = 7L;
										memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
									}
									tr4 = RTMS_EX_H("Project \'",9,213807399);
									*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = RTMS_EX_H("\': conflict found! Replacing target `(",38,1882659624);
									*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = F1430_11111(RTCW(loc7));
									*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = RTMS_EX_H(")\' with selected target `(",26,603844904);
									*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = F1430_11111(RTCW(loc4));
									*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = RTMS_EX_H(")\'.",3,2697006);
									*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
									F1356_10325(RTCW(tr1), tr2);
									tr1 = *(EIF_REFERENCE *)(Current);
									{
										static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
										EIF_TYPE typres0;
										static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
										
										typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
										tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
										RT_SPECIAL_COUNT(tr3) = 1L;
										memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
									}
									tr4 = RTMS_EX_H("a_target: ",10,614045728);
									*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
									F1356_10325(RTCW(tr1), tr2);
									F1430_11138(RTCW(loc7));
									tr1 = *(EIF_REFERENCE *)(Current);
									{
										static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
										EIF_TYPE typres0;
										static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
										
										typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
										tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
										RT_SPECIAL_COUNT(tr3) = 1L;
										memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
									}
									tr4 = RTMS_EX_H("a_selected_target: ",19,221589280);
									*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
									F1356_10325(RTCW(tr1), tr2);
									F1430_11138(RTCW(loc4));
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									loc10++;
									tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_8_);
									loc14 = tr1;
									if (EIF_TEST(loc14)) {
										F1430_11137(loc14, loc4);
									}
									F1212_8252(loc12, loc8);
								}
							}
							F1061_7407(RTCW(loc6));
						}
					}
					if ((EIF_BOOLEAN)(loc10 == ((EIF_INTEGER_32) 0L))) {
						{
							static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
							RT_SPECIAL_COUNT(tr2) = 5L;
							memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
						}
						tr3 = RTMS_EX_H("Project \'",9,213807399);
						*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						tr3 = *(EIF_REFERENCE *)(Current);
						tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
						*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						tr3 = RTMS_EX_H("\': There is no need to select target `",38,51165024);
						*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) loc5;
						RTAR(tr2,loc5);
						tr3 = RTMS_EX_H("\' since there are no other conflicting targets.",47,852013870);
						*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
						F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
					}
					F1053_7396(RTCW(loc3));
				}
			}
			F1053_7396(RTCW(loc1));
		}
	}
	RTLE;
}

/* {GEANT_INHERIT}.check_targets_for_conflicts */
void F1352_10248 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,tr2);
	RTLR(10,tr3);
	RTLIU(11);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		loc1 = F1233_8466(loc7);
		F1061_7406(RTCW(loc1));
		for (;;) {
			tb1 = F1077_7424(RTCW(loc1));
			if (tb1) break;
			loc2 = F1039_7375(RTCW(loc1));
			loc3 = F1088_7442(RTCW(loc1));
			loc4 = F1233_8466(loc7);
			F1061_7406(RTCW(loc4));
			for (;;) {
				tb2 = F1077_7424(RTCW(loc4));
				if (tb2) break;
				loc5 = F1039_7375(RTCW(loc4));
				loc6 = F1088_7442(RTCW(loc4));
				if ((EIF_BOOLEAN)(loc5 != loc2)) {
					tb3 = F1430_11127(RTCW(loc5), loc2);
					if (tb3) {
						{
							static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 8L),sizeof(EIF_REFERENCE), EIF_FALSE);
							RT_SPECIAL_COUNT(tr2) = 8L;
							memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
						}
						tr3 = RTMS_EX_H("\012LOAD ERROR:\012",13,54494730);
						*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						tr3 = RTMS_EX_H("Project \'",9,213807399);
						*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						tr3 = *(EIF_REFERENCE *)(Current);
						tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
						*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						tr3 = RTMS_EX_H("\' contains target `",19,428833632);
						*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) loc3;
						RTAR(tr2,loc3);
						tr3 = RTMS_EX_H("\' which conflicts with target `",31,377806688);
						*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) loc6;
						RTAR(tr2,loc6);
						tr3 = RTMS_EX_H("\'.\012Use a select clause to resolve the conflict.",47,1591918126);
						*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
						F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
					}
				}
				F1061_7407(RTCW(loc4));
			}
			F1061_7407(RTCW(loc1));
		}
	}
	RTLE;
}

/* {GEANT_INHERIT}.merge_in_parent_project */
void F1352_10249 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 5L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("\012Project \'",10,885164839);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = *(EIF_REFERENCE *)(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = RTMS_EX_H("\': --> merging in parent \'",26,1600509735);
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = *(EIF_REFERENCE *)(loc1);
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = RTMS_EX_H("\':",2,10042);
		*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10325(RTCW(tr1), tr2);
		F1352_10251(Current, arg1);
		F1352_10250(Current, arg1);
		F1352_10252(Current, arg1);
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 5L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("Project \'",9,213807399);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = *(EIF_REFERENCE *)(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = RTMS_EX_H("\': <-- merging in of parent `",29,1582259808);
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = *(EIF_REFERENCE *)(loc1);
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = RTMS_EX_H("\' done.\012",8,984859658);
		*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10325(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {GEANT_INHERIT}.merge_in_renamed_targets */
void F1352_10250 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc5);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,Current);
	RTLR(5,loc1);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,tr4);
	RTLR(11,loc2);
	RTLIU(12);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
		loc6 = tr1;
		tb1 = EIF_TEST(loc6);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		loc1 = F1233_8466(RTCW(tr1));
		F1061_7406(RTCW(loc1));
		for (;;) {
			tb1 = F1077_7424(RTCW(loc1));
			if (tb1) break;
			loc3 = F1039_7375(RTCW(loc1));
			loc4 = F1088_7442(RTCW(loc1));
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 7L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("Project \'",9,213807399);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = *(EIF_REFERENCE *)(Current);
			tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
			*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = RTMS_EX_H("\': merging in renamed target `",30,257563488);
			*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) loc4;
			RTAR(tr3,loc4);
			tr4 = RTMS_EX_H("\' (",3,2564136);
			*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = F1430_11111(RTCW(loc3));
			*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = RTMS_EX_H(")",1,41);
			*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10325(RTCW(tr1), tr2);
			F1223_8405(loc6, loc4);
			tb2 = F1212_8240(loc6);
			if (tb2) {
				loc2 = F1212_8232(loc6);
				tr1 = RTOSCF(6466,F971_6466, (Current));
				tr2 = F1430_11111(RTCW(loc2));
				tr3 = F1430_11111(RTCW(loc3));
				tb2 = F958_6409(RTCW(tr1), tr2, tr3);
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current);
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr3) = 7L;
						memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
					}
					tr4 = RTMS_EX_H("Project \'",9,213807399);
					*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr4 = *(EIF_REFERENCE *)(Current);
					tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
					*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr4 = RTMS_EX_H("\': sharing target `",19,254973024);
					*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) loc4;
					RTAR(tr3,loc4);
					tr4 = RTMS_EX_H("\' since name and full_name (\'",29,305731111);
					*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr4 = F1430_11111(RTCW(loc3));
					*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr4 = RTMS_EX_H("\') is equal to the existing target.",35,544064558);
					*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
					F1356_10325(RTCW(tr1), tr2);
				} else {
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 15L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr2) = 15L;
						memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
					}
					tr3 = RTMS_EX_H("\012LOAD ERROR:\012",13,54494730);
					*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("Project \'",9,213807399);
					*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = *(EIF_REFERENCE *)(Current);
					tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
					*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\': contains target `",20,311275616);
					*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = F1430_11111(RTCW(loc2));
					*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\' named `",9,1583151968);
					*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) loc4;
					RTAR(tr2,loc4);
					tr3 = RTMS_EX_H("\' which causes a name clash with\012  target `",43,1536947040);
					*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = F1430_11111(RTCW(loc3));
					*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\' named `",9,1583151968);
					*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) loc4;
					RTAR(tr2,loc4);
					tr3 = RTMS_EX_H("\' inherited from project \'",26,1857001255);
					*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = *(EIF_REFERENCE *)(loc5);
					*((EIF_REFERENCE *)tr2+12) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\'.\012",3,2567690);
					*((EIF_REFERENCE *)tr2+13) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("  Use a rename or redefine clause to resolve the name clash.",60,1952347438);
					*((EIF_REFERENCE *)tr2+14) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
					F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
				}
			} else {
				F1223_8417(loc6, loc3, loc4);
			}
			F1061_7407(RTCW(loc1));
		}
	}
	RTLE;
}

/* {GEANT_INHERIT}.merge_in_redefined_targets */
void F1352_10251 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc5);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,Current);
	RTLR(5,loc1);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,tr4);
	RTLR(11,loc2);
	RTLIU(12);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
		loc6 = tr1;
		tb1 = EIF_TEST(loc6);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		loc1 = F1233_8466(RTCW(tr1));
		F1061_7406(RTCW(loc1));
		for (;;) {
			tb1 = F1077_7424(RTCW(loc1));
			if (tb1) break;
			loc3 = F1039_7375(RTCW(loc1));
			loc4 = F1088_7442(RTCW(loc1));
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 9L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 9L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("Project \'",9,213807399);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = *(EIF_REFERENCE *)(Current);
			tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
			*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = RTMS_EX_H("\': merging in redefined target `",32,299246688);
			*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) loc4;
			RTAR(tr3,loc4);
			tr4 = RTMS_EX_H("\' (",3,2564136);
			*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = F1430_11111(RTCW(loc3));
			*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = RTMS_EX_H(") from parent \'",15,1149162791);
			*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = *(EIF_REFERENCE *)(loc5);
			*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = RTMS_EX_H("\'",1,39);
			*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10325(RTCW(tr1), tr2);
			tb2 = F1223_8402(loc6, loc4);
			if ((EIF_BOOLEAN) !tb2) {
				{
					static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 6L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr2) = 6L;
					memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
				}
				tr3 = RTMS_EX_H("\012LOAD ERROR:\012",13,54494730);
				*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = RTMS_EX_H("Project \'",9,213807399);
				*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = *(EIF_REFERENCE *)(Current);
				tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
				*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = RTMS_EX_H("\' does not redefine parent target `",35,1623732064);
				*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) loc4;
				RTAR(tr2,loc4);
				tr3 = RTMS_EX_H("\' as declared.",14,59400238);
				*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
				F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
			}
			loc2 = F1223_8394(loc6, loc4);
			tb2 = F1430_11128(RTCW(loc2), loc3);
			if ((EIF_BOOLEAN) !tb2) {
				{
					static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 6L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr2) = 6L;
					memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
				}
				tr3 = RTMS_EX_H("\012LOAD ERROR:\012",13,54494730);
				*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = RTMS_EX_H("Target \'",8,1376049959);
				*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = F1430_11111(RTCW(loc2));
				*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = RTMS_EX_H("\'s arguments do not match it\'s parent\'s (`",42,119004000);
				*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = F1430_11111(RTCW(loc3));
				*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = RTMS_EX_H("\'s) arguments.",14,144651310);
				*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
				F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
			}
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 7L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("Project \'",9,213807399);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = *(EIF_REFERENCE *)(Current);
			tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
			*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = RTMS_EX_H("\': connecting target `",22,1003199072);
			*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = F1430_11111(RTCW(loc2));
			*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = RTMS_EX_H("\' and target `",14,1518274912);
			*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = F1430_11111(RTCW(loc3));
			*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = RTMS_EX_H("\'",1,39);
			*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10325(RTCW(tr1), tr2);
			F1430_11137(RTCW(loc3), loc2);
			F1430_11136(RTCW(loc2), loc3);
			F1061_7407(RTCW(loc1));
		}
	}
	RTLE;
}

/* {GEANT_INHERIT}.merge_in_unchanged_targets */
void F1352_10252 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc5);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,Current);
	RTLR(5,loc1);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,tr4);
	RTLR(11,loc2);
	RTLIU(12);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
		loc6 = tr1;
		tb1 = EIF_TEST(loc6);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
		loc1 = F1233_8466(RTCW(tr1));
		F1053_7395(RTCW(loc1));
		for (;;) {
			tb1 = F1077_7423(RTCW(loc1));
			if (tb1) break;
			loc3 = F1039_7375(RTCW(loc1));
			loc4 = F1088_7442(RTCW(loc1));
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 9L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 9L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("Project \'",9,213807399);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = *(EIF_REFERENCE *)(Current);
			tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
			*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = RTMS_EX_H("\': merging in unchanged parent target `",39,320608352);
			*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) loc4;
			RTAR(tr3,loc4);
			tr4 = RTMS_EX_H("\' (",3,2564136);
			*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = F1430_11111(RTCW(loc3));
			*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = RTMS_EX_H(") from parent \'",15,1149162791);
			*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = *(EIF_REFERENCE *)(loc5);
			*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = RTMS_EX_H("\'",1,39);
			*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10325(RTCW(tr1), tr2);
			F1223_8405(loc6, loc4);
			tb2 = F1212_8240(loc6);
			if (tb2) {
				loc2 = F1212_8232(loc6);
				tr1 = RTOSCF(6466,F971_6466, (Current));
				tr2 = F1430_11111(RTCW(loc2));
				tr3 = F1430_11111(RTCW(loc3));
				tb2 = F958_6409(RTCW(tr1), tr2, tr3);
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current);
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 7L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr3) = 7L;
						memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
					}
					tr4 = RTMS_EX_H("Project \'",9,213807399);
					*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr4 = *(EIF_REFERENCE *)(Current);
					tr4 = *(EIF_REFERENCE *)(RTCW(tr4));
					*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr4 = RTMS_EX_H("\': sharing target `",19,254973024);
					*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) loc4;
					RTAR(tr3,loc4);
					tr4 = RTMS_EX_H("\' since name and full_name (\'",29,305731111);
					*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr4 = F1430_11111(RTCW(loc3));
					*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr4 = RTMS_EX_H("\') is equal to the existing target.",35,544064558);
					*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
					F1356_10325(RTCW(tr1), tr2);
				} else {
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 16L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr2) = 16L;
						memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
					}
					tr3 = RTMS_EX_H("\012LOAD ERROR:\012",13,54494730);
					*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("Project \'",9,213807399);
					*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = *(EIF_REFERENCE *)(Current);
					tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
					*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\' contains target\012    `",23,1850979168);
					*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = F1223_8394(loc6, loc4);
					tr3 = F1430_11111(RTCW(tr3));
					*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\' named `",9,1583151968);
					*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) loc4;
					RTAR(tr2,loc4);
					tr3 = RTMS_EX_H("\'\012  which causes a name clash with target ",42,1232190752);
					*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\012    `",6,558882912);
					*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = F1430_11111(RTCW(loc3));
					*((EIF_REFERENCE *)tr2+9) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\' named `",9,1583151968);
					*((EIF_REFERENCE *)tr2+10) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					*((EIF_REFERENCE *)tr2+11) = (EIF_REFERENCE) loc4;
					RTAR(tr2,loc4);
					tr3 = RTMS_EX_H("\'\012  inherited from project \'",28,2072022823);
					*((EIF_REFERENCE *)tr2+12) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = *(EIF_REFERENCE *)(loc5);
					*((EIF_REFERENCE *)tr2+13) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\'.\012",3,2567690);
					*((EIF_REFERENCE *)tr2+14) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("  Use a rename or redefine clause to resolve the name clash.",60,1952347438);
					*((EIF_REFERENCE *)tr2+15) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
					F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
				}
			}
			F1223_8417(loc6, loc3, loc4);
			F1053_7396(RTCW(loc1));
		}
	}
	RTLE;
}

void EIF_Minit497 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
