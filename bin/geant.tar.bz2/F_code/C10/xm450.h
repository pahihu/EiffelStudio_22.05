
#ifndef _C10_xm450_
#define _C10_xm450_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1305_9617(EIF_REFERENCE);
extern void F1305_9620(EIF_REFERENCE);
extern void EIF_Minit450(void);
extern void F1016_6981(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1303_9492(EIF_REFERENCE);
extern void F1015_6930(EIF_REFERENCE);
extern EIF_BOOLEAN F1015_6915(EIF_REFERENCE);
extern void F1018_7057(EIF_REFERENCE);
extern void F1015_6918(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
