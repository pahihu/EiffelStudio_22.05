/*
 * Code for class XM_DTD_ELEMENT_CONTENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm459.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_DTD_ELEMENT_CONTENT}.make_name */
void F1314_10042 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	F1314_10044(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.make_list */
void F1314_10043 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1187,0xFF01,1313,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1187, _OBJSIZ_4_0_0_1_0_0_0_0_);
	}
	F1185_7905(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F1314_10044(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.set_default */
void F1314_10044 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1314_10069(Current);
	F1314_10060(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.make_empty */
void F1314_10045 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1314_10043(Current);
	F1314_10073(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.make_any */
void F1314_10046 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1314_10043(Current);
	F1314_10072(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.make_choice */
void F1314_10047 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1314_10043(Current);
	F1314_10068(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.make_sequence */
void F1314_10048 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1314_10043(Current);
	F1314_10069(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.make_mixed */
void F1314_10049 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1314_10043(Current);
	F1314_10075(Current);
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.set_one */
void F1314_10060 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_1_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) ' ';
}

/* {XM_DTD_ELEMENT_CONTENT}.set_one_or_more */
void F1314_10061 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_1_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '+';
}

/* {XM_DTD_ELEMENT_CONTENT}.set_zero_or_one */
void F1314_10062 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_1_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\?';
}

/* {XM_DTD_ELEMENT_CONTENT}.set_zero_or_more */
void F1314_10063 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_1_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '*';
}

/* {XM_DTD_ELEMENT_CONTENT}.set_choice */
void F1314_10068 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '|';
}

/* {XM_DTD_ELEMENT_CONTENT}.set_sequence */
void F1314_10069 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) ',';
}

/* {XM_DTD_ELEMENT_CONTENT}.set_content_any */
void F1314_10072 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\?';
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_DTD_ELEMENT_CONTENT}.set_content_empty */
void F1314_10073 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '0';
}

/* {XM_DTD_ELEMENT_CONTENT}.set_content_mixed */
void F1314_10075 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1314_10068(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

void EIF_Minit459 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
