/*
 * Code for class AP_ERROR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ap492.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {AP_ERROR}.make_invalid_parameter_error */
void F1347_10176 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,737,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(10082,F1315_10082, (Current));
	F738_4058(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 2L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = F154_1684(RTCW(arg1));
	F738_4082(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current);
	F738_4082(RTCW(tr1), arg2, ((EIF_INTEGER_32) 2L));
	tr1 = RTOSCF(10183,F1347_10183, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(10190,F1347_10190, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {AP_ERROR}.make_missing_option_error */
void F1347_10177 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,737,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(10082,F1315_10082, (Current));
	F738_4058(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = F154_1684(RTCW(arg1));
	F738_4082(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L));
	tr1 = RTOSCF(10184,F1347_10184, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(10191,F1347_10191, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {AP_ERROR}.make_missing_parameter_error */
void F1347_10178 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,737,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(10082,F1315_10082, (Current));
	F738_4058(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = F154_1684(RTCW(arg1));
	F738_4082(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L));
	tr1 = RTOSCF(10185,F1347_10185, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(10192,F1347_10192, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {AP_ERROR}.make_surplus_option_error */
void F1347_10179 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,737,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(10082,F1315_10082, (Current));
	F738_4058(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = F154_1684(RTCW(arg1));
	F738_4082(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L));
	tr1 = RTOSCF(10186,F1347_10186, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(10193,F1347_10193, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {AP_ERROR}.make_unknown_option_error */
void F1347_10180 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,737,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(10082,F1315_10082, (Current));
	F738_4058(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	F738_4082(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L));
	tr1 = RTOSCF(10187,F1347_10187, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(10194,F1347_10194, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {AP_ERROR}.make_unnecessary_parameter_error */
void F1347_10181 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,737,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(10082,F1315_10082, (Current));
	F738_4058(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 2L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = F154_1684(RTCW(arg1));
	F738_4082(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current);
	F738_4082(RTCW(tr1), arg2, ((EIF_INTEGER_32) 2L));
	tr1 = RTOSCF(10188,F1347_10188, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(10195,F1347_10195, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {AP_ERROR}.default_template */
EIF_REFERENCE F1347_10182 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {AP_ERROR}.invalid_parameter_error_template */

EIF_REFERENCE F1347_10183 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10183,RTMS_EX_H("The value \'$2\' is not valid for the option \'$1\'.",48,1973879598));
}

/* {AP_ERROR}.missing_option_error_template */

EIF_REFERENCE F1347_10184 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10184,RTMS_EX_H("The mandatory option \'$1\' is missing.",37,963672366));
}

/* {AP_ERROR}.missing_parameter_error_template */

EIF_REFERENCE F1347_10185 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10185,RTMS_EX_H("The option \'$1\' is missing a parameter.",39,78868526));
}

/* {AP_ERROR}.surplus_option_error_template */

EIF_REFERENCE F1347_10186 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10186,RTMS_EX_H("Too many occurrences of option \'$1\'.",36,35400750));
}

/* {AP_ERROR}.unknown_option_error_template */

EIF_REFERENCE F1347_10187 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10187,RTMS_EX_H("Unknown option \'$1\'.",20,2145194030));
}

/* {AP_ERROR}.unnecessary_parameter_error_template */

EIF_REFERENCE F1347_10188 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10188,RTMS_EX_H("The flag \'$1\' was given the parameter \'$2\'.",43,699502894));
}

/* {AP_ERROR}.code */
EIF_REFERENCE F1347_10189 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {AP_ERROR}.invalid_parameter_error_code */

EIF_REFERENCE F1347_10190 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10190,RTMS_EX_H("APIPAR",6,1358405970));
}

/* {AP_ERROR}.missing_option_error_code */

EIF_REFERENCE F1347_10191 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10191,RTMS_EX_H("APMOPT",6,1425453140));
}

/* {AP_ERROR}.missing_parameter_error_code */

EIF_REFERENCE F1347_10192 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10192,RTMS_EX_H("APMPAR",6,1425514834));
}

/* {AP_ERROR}.surplus_option_error_code */

EIF_REFERENCE F1347_10193 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10193,RTMS_EX_H("APSOPT",6,1526116436));
}

/* {AP_ERROR}.unknown_option_error_code */

EIF_REFERENCE F1347_10194 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10194,RTMS_EX_H("APUOPT",6,1559670868));
}

/* {AP_ERROR}.unnecessary_parameter_error_code */

EIF_REFERENCE F1347_10195 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10195,RTMS_EX_H("APUPAR",6,1559732562));
}

void EIF_Minit492 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
