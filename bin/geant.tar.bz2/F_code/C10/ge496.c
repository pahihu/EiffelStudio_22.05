/*
 * Code for class GEANT_PROJECT_VARIABLE_RESOLVER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge496.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_PROJECT_VARIABLE_RESOLVER}.make */
void F1351_10233 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {GEANT_PROJECT_VARIABLE_RESOLVER}.value */
EIF_REFERENCE F1351_10234 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(6466,F971_6466, (Current));
	tr2 = RTMS_EX_H("cwd",3,6518628);
	tb1 = F958_6409(RTCW(tr1), arg1, tr2);
	if (tb1) {
		Result = F1270_8975(RTCV(RTOSCF(8474,F1240_8474, (Current))));
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = RTOSCF(10208,F1349_10208, (Current));
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5929[Dtype(RTCW(tr1))-1184])(tr1);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = RTOSCF(10208,F1349_10208, (Current));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr1))-1195])(tr1);
			F1223_8405(RTCW(tr1), arg1);
			tr1 = RTOSCF(10208,F1349_10208, (Current));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr1))-1195])(tr1);
			tb1 = F1212_8240(RTCW(tr1));
			if (tb1) {
				tr1 = RTOSCF(10208,F1349_10208, (Current));
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr1))-1195])(tr1);
				Result = F1212_8232(RTCW(tr1));
			}
		}
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = RTOSCF(10199,F1349_10199, (Current));
		F1223_8405(RTCW(tr1), arg1);
		tb1 = F1212_8240(RTCV(RTOSCF(10199,F1349_10199, (Current))));
		if (tb1) {
			Result = F1212_8232(RTCV(RTOSCF(10199,F1349_10199, (Current))));
		}
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = RTOSCF(10209,F1349_10209, (Current));
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5929[Dtype(RTCW(tr1))-1184])(tr1);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = RTOSCF(10209,F1349_10209, (Current));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr1))-1195])(tr1);
			F1223_8405(RTCW(tr1), arg1);
			tr1 = RTOSCF(10209,F1349_10209, (Current));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr1))-1195])(tr1);
			tb1 = F1212_8240(RTCW(tr1));
			if (tb1) {
				tr1 = RTOSCF(10209,F1349_10209, (Current));
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr1))-1195])(tr1);
				Result = F1212_8232(RTCW(tr1));
			}
		}
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			F1223_8405(loc1, arg1);
			tb1 = F1212_8240(loc1);
			if (tb1) {
				Result = F1212_8232(loc1);
			}
		}
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = RTOSCF(2207,F207_2207, (Current));
		tr1 = F994_6717(RTCW(tr1), arg1);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = RTOSCF(2207,F207_2207, (Current));
			Result = F994_6717(RTCW(tr1), arg1);
		}
	}
	RTLE;
	return Result;
}

/* {GEANT_PROJECT_VARIABLE_RESOLVER}.boolean_condition_value */
EIF_BOOLEAN F1351_10235 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc4);
	RTLR(1,tr1);
	RTLR(2,loc5);
	RTLR(3,arg1);
	RTLR(4,loc1);
	RTLR(5,Current);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc3);
	RTLR(9,loc2);
	RTLIU(10);
	
	RTGC;
	loc4 = RTLNS(eif_new_type(1012, 0x01).id, 1012, _OBJSIZ_2_2_0_0_0_0_0_0_);
	tr1 = RTMS_EX_H("=",1,61);
	F1013_6866(RTCW(loc4), tr1);
	loc5 = F1013_6876(RTCW(loc4), arg1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5929[Dtype(RTCW(loc5))-1184])(loc5);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6045[Dtype(RTCW(loc5))-1184])(loc5, ((EIF_INTEGER_32) 1L));
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = RTOSCF(10240,F1351_10240, (Current));
		tb1 = F958_6410(RTCW(tr1), loc1, tr2);
		if (tb1) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = RTOSCF(10239,F1351_10239, (Current));
			tb1 = F958_6410(RTCW(tr1), loc1, tr2);
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tb1 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 3L))) {
					tb2 = '\0';
					tb3 = '\0';
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(loc1))-712])(loc1, ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '$')) {
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(loc1))-712])(loc1, ((EIF_INTEGER_32) 2L)));
						tb3 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '{');
					}
					if (tb3) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(loc1))-712])(loc1, ti4_1));
						tb2 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '}');
					}
					tb1 = tb2;
				}
				if (tb1) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(RTCW(loc1))-946])(loc1, ((EIF_INTEGER_32) 3L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
					loc1 = (EIF_REFERENCE) tr1;
					Result = F1351_10237(Current, loc1);
				} else {
					tb1 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
						tb2 = '\0';
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(loc1))-712])(loc1, ((EIF_INTEGER_32) 1L)));
						if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '$')) {
							tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(loc1))-712])(loc1, ((EIF_INTEGER_32) 2L)));
							tb2 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '{');
						}
						tb1 = tb2;
					}
					if (tb1) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(RTCW(loc1))-946])(loc1, ((EIF_INTEGER_32) 2L), ti4_1);
						loc1 = (EIF_REFERENCE) tr1;
						Result = F1351_10237(Current, loc1);
						RTLE;
						return (EIF_BOOLEAN) Result;
					} else {
						{
							static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
							RT_SPECIAL_COUNT(tr2) = 3L;
							memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
						}
						tr3 = RTMS_EX_H("geant: incorrect conditional: \'",31,1260470823);
						*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) arg1;
						RTAR(tr2,arg1);
						tr3 = RTMS_EX_H("\'",1,39);
						*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
						RTAR(tr2,tr3);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
						F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
					}
				}
			}
		}
	} else {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5929[Dtype(RTCW(loc5))-1184])(loc5);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
			loc3 = RTLNS(eif_new_type(1297, 0x01).id, 1297, _OBJSIZ_2_0_0_0_0_0_0_0_);
			F1298_9342(RTCW(loc3), Current);
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6045[Dtype(RTCW(loc5))-1184])(loc5, ((EIF_INTEGER_32) 1L));
			tr1 = F1298_9340(RTCW(loc3), loc1);
			loc1 = (EIF_REFERENCE) tr1;
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6045[Dtype(RTCW(loc5))-1184])(loc5, ((EIF_INTEGER_32) 2L));
			tr1 = F1298_9340(RTCW(loc3), loc2);
			loc2 = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(6466,F971_6466, (Current));
			Result = F958_6409(RTCW(tr1), loc1, loc2);
		} else {
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr2) = 3L;
				memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
			}
			tr3 = RTMS_EX_H("geant: incorrect conditional: \'",31,1260470823);
			*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) arg1;
			RTAR(tr2,arg1);
			tr3 = RTMS_EX_H("\'",1,39);
			*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
			F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
		}
	}
	RTLE;
	return Result;
}

/* {GEANT_PROJECT_VARIABLE_RESOLVER}.has */
EIF_BOOLEAN F1351_10237 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(6466,F971_6466, (Current));
	tr2 = RTMS_EX_H("cwd",3,6518628);
	Result = F958_6409(RTCW(tr1), arg1, tr2);
	if ((EIF_BOOLEAN) !Result) {
		tr1 = RTOSCF(10208,F1349_10208, (Current));
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5929[Dtype(RTCW(tr1))-1184])(tr1);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = RTOSCF(10208,F1349_10208, (Current));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr1))-1195])(tr1);
			F1223_8405(RTCW(tr1), arg1);
			tr1 = RTOSCF(10208,F1349_10208, (Current));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr1))-1195])(tr1);
			Result = F1212_8240(RTCW(tr1));
		}
	}
	if ((EIF_BOOLEAN) !Result) {
		tr1 = RTOSCF(10199,F1349_10199, (Current));
		F1223_8405(RTCW(tr1), arg1);
		Result = F1212_8240(RTCV(RTOSCF(10199,F1349_10199, (Current))));
	}
	if ((EIF_BOOLEAN) !Result) {
		tr1 = RTOSCF(10209,F1349_10209, (Current));
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5929[Dtype(RTCW(tr1))-1184])(tr1);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = RTOSCF(10209,F1349_10209, (Current));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr1))-1195])(tr1);
			F1223_8405(RTCW(tr1), arg1);
			tr1 = RTOSCF(10209,F1349_10209, (Current));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr1))-1195])(tr1);
			Result = F1212_8240(RTCW(tr1));
		}
	}
	if ((EIF_BOOLEAN) !Result) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F1223_8405(loc2, arg1);
			Result = F1212_8240(loc2);
		}
	}
	if ((EIF_BOOLEAN) !Result) {
		tr1 = RTOSCF(2207,F207_2207, (Current));
		loc1 = F994_6717(RTCW(tr1), arg1);
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN)(loc1 != NULL);
	}
	RTLE;
	return Result;
}

/* {GEANT_PROJECT_VARIABLE_RESOLVER}.set_variables */
void F1351_10238 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {GEANT_PROJECT_VARIABLE_RESOLVER}.true_attribute_value */
static EIF_REFERENCE F1351_10239_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10239);
#define Result RTOSR(10239)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("true",4,1953658213);
	RTOSE (10239);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1351_10239 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10239,F1351_10239_body,(Current));
}

/* {GEANT_PROJECT_VARIABLE_RESOLVER}.false_attribute_value */
static EIF_REFERENCE F1351_10240_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10240);
#define Result RTOSR(10240)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("false",5,1635280741);
	RTOSE (10240);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1351_10240 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10240,F1351_10240_body,(Current));
}

void EIF_Minit496 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
