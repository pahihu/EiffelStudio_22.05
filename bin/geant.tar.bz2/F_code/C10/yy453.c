/*
 * Code for class YY_PARSER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy453.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_PARSER_SKELETON}.make */
void F1308_9642 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(2947,F301_2947, (Current));
	tr1 = F25_227(RTCW(tr1), ((EIF_INTEGER_32) 200L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O7217[dtype-1307]) = (EIF_REFERENCE) tr1;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7209[dtype-1309])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7208[dtype-1309])(Current);
	RTLE;
}

/* {YY_PARSER_SKELETON}.parse */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1308_9643 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_INTEGER_32 EIF_VOLATILE loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_INTEGER_32  EIF_VOLATILE ti4_2;
	EIF_INTEGER_32  EIF_VOLATILE ti4_3;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	RTCDT;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7221[dtype-1307]) == ((EIF_INTEGER_32) 105L))) {
		loc1 = *(EIF_INTEGER_32 *)(Current + O7199[dtype-1307]);
		loc2 = *(EIF_INTEGER_32 *)(Current + O7200[dtype-1307]);
		loc3 = *(EIF_INTEGER_32 *)(Current + O7201[dtype-1307]);
		loc4 = *(EIF_INTEGER_32 *)(Current + O7202[dtype-1307]);
		loc5 = *(EIF_INTEGER_32 *)(Current + O7203[dtype-1307]);
		loc6 = *(EIF_INTEGER_32 *)(Current + O7204[dtype-1307]);
		loc7 = *(EIF_INTEGER_32 *)(Current + O7205[dtype-1307]);
		*(EIF_INTEGER_32 *)(Current + O7221[dtype-1307]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
		if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 3L))) {
			tr1 = *(EIF_REFERENCE *)(Current + O7190[dtype-1307]);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
			/* END INLINED CODE */
			ti4_1 = ti4_2;
			loc3 = (EIF_INTEGER_32) ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + O7217[dtype-1307]);
			/* INLINED CODE (SPECIAL.item) */
			ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current + O7218[dtype-1307])));
			/* END INLINED CODE */
			loc6 = ti4_3;
			loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7239[dtype-1309])(Current);
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - loc5);
			tr1 = *(EIF_REFERENCE *)(Current + O7194[dtype-1307]);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
			/* END INLINED CODE */
			loc2 = ti4_2;
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + loc6);
			tb1 = '\0';
			tb2 = '\0';
			if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 0L))) {
				tb2 = (EIF_BOOLEAN) (loc2 <= (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7240[dtype-1309])(Current));
			}
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(Current + O7196[dtype-1307]);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				ti4_1 = ti4_2;
				tb1 = (EIF_BOOLEAN)(ti4_1 == loc6);
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + O7195[dtype-1307]);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				ti4_1 = ti4_2;
				loc2 = (EIF_INTEGER_32) ti4_1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O7192[dtype-1307]);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
				/* END INLINED CODE */
				loc2 = ti4_2;
			}
			loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	} else {
		*(EIF_INTEGER_32 *)(Current + O7246[dtype-1307]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		*(EIF_BOOLEAN *)(Current + O7219[dtype-1307]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		*(EIF_INTEGER_32 *)(Current + O7220[dtype-1307]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7210[dtype-1309])(Current);
		*(EIF_INTEGER_32 *)(Current + O7218[dtype-1307]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		tr1 = *(EIF_REFERENCE *)(Current + O7217[dtype-1307]);
		loc1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
		*(EIF_INTEGER_32 *)(Current + O7221[dtype-1307]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
		loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	for (;;) {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7221[dtype-1307]) != ((EIF_INTEGER_32) 104L))) break;
		switch (loc7) {
			case 1L:
				(*(EIF_INTEGER_32 *)(Current + O7218[dtype-1307]))++;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O7218[dtype-1307]) >= loc1)) {
					loc1 += ((EIF_INTEGER_32) 200L);
					tr1 = RTOSCF(2947,F301_2947, (Current));
					tr1 = F25_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + O7217[dtype-1307]), loc1);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + O7217[dtype-1307]) = (EIF_REFERENCE) tr1;
				}
				tr1 = RTOSCF(2947,F301_2947, (Current));
				F25_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + O7217[dtype-1307]), loc2, *(EIF_INTEGER_32 *)(Current + O7218[dtype-1307]));
				tr1 = *(EIF_REFERENCE *)(Current + O7193[dtype-1307]);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				loc3 = ti4_2;
				if ((EIF_BOOLEAN)(loc3 == (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7238[dtype-1309])(Current))) {
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
				} else {
					if (*(EIF_BOOLEAN *)(Current + O7219[dtype-1307])) {
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R883[dtype-1309])(Current);
						*(EIF_BOOLEAN *)(Current + O7219[dtype-1307]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
					if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R884[dtype-1309])(Current) > ((EIF_INTEGER_32) 0L))) {
						if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R884[dtype-1309])(Current) <= (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7241[dtype-1309])(Current))) {
							tr1 = *(EIF_REFERENCE *)(Current + O7189[dtype-1307]);
							ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R884[dtype-1309])(Current);
							/* INLINED CODE (SPECIAL.item) */
							ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (ti4_1));
							/* END INLINED CODE */
							loc4 = ti4_3;
						} else {
							loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7242[dtype-1309])(Current);
						}
						loc3 += loc4;
					} else {
						if ((EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R884[dtype-1309])(Current) == ((EIF_INTEGER_32) 0L))) {
							loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						} else {
							(*(EIF_INTEGER_32 *)(Current + O7246[dtype-1307]))++;
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R7207[dtype-1309])(Current, loc2);
							F1308_9648(Current);
							loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						}
					}
					tb1 = '\01';
					tb2 = '\01';
					if (!(EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
						tb2 = (EIF_BOOLEAN) (loc3 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7240[dtype-1309])(Current));
					}
					if (!tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + O7196[dtype-1307]);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						tb1 = (EIF_BOOLEAN)(ti4_1 != loc4);
					}
					if (tb1) {
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O7195[dtype-1307]);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						loc3 = (EIF_INTEGER_32) ti4_1;
						if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
							if ((EIF_BOOLEAN)(loc3 == (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7238[dtype-1309])(Current))) {
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
							} else {
								loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) -loc3;
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
							}
						} else {
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
							} else {
								if ((EIF_BOOLEAN)(loc3 == (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7237[dtype-1309])(Current))) {
									F1308_9647(Current);
								} else {
									if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R884[dtype-1309])(Current) > ((EIF_INTEGER_32) 0L))) {
										*(EIF_BOOLEAN *)(Current + O7219[dtype-1307]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									}
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R7212[dtype-1309])(Current, loc4);
									if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7220[dtype-1307]) != ((EIF_INTEGER_32) 0L))) {
										(*(EIF_INTEGER_32 *)(Current + O7220[dtype-1307]))--;
									}
									loc2 = (EIF_INTEGER_32) loc3;
								}
							}
						}
					}
				}
				break;
			case 2L:
				tr1 = *(EIF_REFERENCE *)(Current + O7191[dtype-1307]);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				loc3 = ti4_2;
				if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
				} else {
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
				}
				break;
			case 3L:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R7206[dtype-1309])(Current, loc3);
				switch (*(EIF_INTEGER_32 *)(Current + O7221[dtype-1307])) {
					case 104L:
						tr1 = *(EIF_REFERENCE *)(Current + O7190[dtype-1307]);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						loc3 = (EIF_INTEGER_32) ti4_1;
						tr1 = *(EIF_REFERENCE *)(Current + O7217[dtype-1307]);
						/* INLINED CODE (SPECIAL.item) */
						ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current + O7218[dtype-1307])));
						/* END INLINED CODE */
						loc6 = ti4_3;
						loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7239[dtype-1309])(Current);
						loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - loc5);
						tr1 = *(EIF_REFERENCE *)(Current + O7194[dtype-1307]);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
						/* END INLINED CODE */
						loc2 = ti4_2;
						loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + loc6);
						tb1 = '\0';
						tb2 = '\0';
						if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 0L))) {
							tb2 = (EIF_BOOLEAN) (loc2 <= (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7240[dtype-1309])(Current));
						}
						if (tb2) {
							tr1 = *(EIF_REFERENCE *)(Current + O7196[dtype-1307]);
							/* INLINED CODE (SPECIAL.item) */
							ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
							/* END INLINED CODE */
							ti4_1 = ti4_2;
							tb1 = (EIF_BOOLEAN)(ti4_1 == loc6);
						}
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + O7195[dtype-1307]);
							/* INLINED CODE (SPECIAL.item) */
							ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
							/* END INLINED CODE */
							ti4_1 = ti4_2;
							loc2 = (EIF_INTEGER_32) ti4_1;
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + O7192[dtype-1307]);
							/* INLINED CODE (SPECIAL.item) */
							ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
							/* END INLINED CODE */
							loc2 = ti4_2;
						}
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						break;
					case 105L:
						*(EIF_INTEGER_32 *)(Current + O7199[dtype-1307]) = (EIF_INTEGER_32) loc1;
						*(EIF_INTEGER_32 *)(Current + O7200[dtype-1307]) = (EIF_INTEGER_32) loc2;
						*(EIF_INTEGER_32 *)(Current + O7201[dtype-1307]) = (EIF_INTEGER_32) loc3;
						*(EIF_INTEGER_32 *)(Current + O7202[dtype-1307]) = (EIF_INTEGER_32) loc4;
						*(EIF_INTEGER_32 *)(Current + O7203[dtype-1307]) = (EIF_INTEGER_32) loc5;
						*(EIF_INTEGER_32 *)(Current + O7204[dtype-1307]) = (EIF_INTEGER_32) loc6;
						*(EIF_INTEGER_32 *)(Current + O7205[dtype-1307]) = (EIF_INTEGER_32) loc7;
						break;
					case 103L:
						*(EIF_INTEGER_32 *)(Current + O7221[dtype-1307]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
						break;
				}
				break;
			case 4L:
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7220[dtype-1307]) == ((EIF_INTEGER_32) 3L))) {
					if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R884[dtype-1309])(Current) <= ((EIF_INTEGER_32) 0L))) {
						F1308_9648(Current);
					} else {
						*(EIF_BOOLEAN *)(Current + O7219[dtype-1307]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
					}
				} else {
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7220[dtype-1307]) == ((EIF_INTEGER_32) 0L))) {
						(*(EIF_INTEGER_32 *)(Current + O7246[dtype-1307]))++;
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R7207[dtype-1309])(Current, loc2);
					}
					*(EIF_INTEGER_32 *)(Current + O7220[dtype-1307]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				}
				break;
			case 5L:
				tr1 = *(EIF_REFERENCE *)(Current + O7193[dtype-1307]);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				loc3 = ti4_2;
				if ((EIF_BOOLEAN)(loc3 == (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7238[dtype-1309])(Current))) {
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
				} else {
					loc3 += ((EIF_INTEGER_32) 1L);
					tb1 = '\01';
					tb2 = '\01';
					if (!(EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
						tb2 = (EIF_BOOLEAN) (loc3 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7240[dtype-1309])(Current));
					}
					if (!tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + O7196[dtype-1307]);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 1L));
					}
					if (tb1) {
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O7195[dtype-1307]);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						loc3 = (EIF_INTEGER_32) ti4_1;
						if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
							if ((EIF_BOOLEAN)(loc3 == (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7238[dtype-1309])(Current))) {
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
							} else {
								loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) -loc3;
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
							}
						} else {
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
							} else {
								if ((EIF_BOOLEAN)(loc3 == (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7237[dtype-1309])(Current))) {
									F1308_9647(Current);
								} else {
									(FUNCTION_CAST(void, (EIF_REFERENCE)) R7213[dtype-1309])(Current);
									loc2 = (EIF_INTEGER_32) loc3;
									loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								}
							}
						}
					}
				}
				break;
			case 6L:
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7218[dtype-1307]) == ((EIF_INTEGER_32) 0L))) {
					F1308_9648(Current);
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R7214[dtype-1309])(Current, loc2);
					(*(EIF_INTEGER_32 *)(Current + O7218[dtype-1307]))--;
					tr1 = *(EIF_REFERENCE *)(Current + O7217[dtype-1307]);
					/* INLINED CODE (SPECIAL.item) */
					ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current + O7218[dtype-1307])));
					/* END INLINED CODE */
					loc2 = ti4_3;
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				}
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7221[dtype-1307]) != ((EIF_INTEGER_32) 105L))) {
		F1308_9693(Current);
	}
	RTE_E
	RTXSC;
	F1308_9648(Current);
	F1308_9693(Current);
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {YY_PARSER_SKELETON}.error_count */
EIF_INTEGER_32 F1308_9646 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O7246[Dtype(Current)-1307]);
}


/* {YY_PARSER_SKELETON}.accept */
void F1308_9647 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O7221[Dtype(Current)-1307]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 101L);
}

/* {YY_PARSER_SKELETON}.abort */
void F1308_9648 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O7221[Dtype(Current)-1307]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 102L);
}

/* {YY_PARSER_SKELETON}.clear_all */
void F1308_9649 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1308_9650(Current);
}

/* {YY_PARSER_SKELETON}.clear_stacks */
void F1308_9650 (EIF_REFERENCE Current)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7211[Dtype(Current)-1309])(Current);
}

/* {YY_PARSER_SKELETON}.report_eof_expected_error */
void F1308_9655 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTMS_EX_H("parse error",11,283683698);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R880[Dtype(Current)-1309])(Current, tr1);
	RTLE;
}

/* {YY_PARSER_SKELETON}.yyfixed_array */
EIF_REFERENCE F1308_9686 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(2947,F301_2947, (Current));
	Result = F25_230(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {YY_PARSER_SKELETON}.yyarray_subcopy */
void F1308_9687 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(4214,F806_4214, (Current));
	F960_6441(RTCW(tr1), arg1, arg2, arg3, arg4, arg5);
	RTLE;
}

/* {YY_PARSER_SKELETON}.yy_clear_all */
void F1308_9693 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1308_9649(Current);
}

void EIF_Minit453 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
