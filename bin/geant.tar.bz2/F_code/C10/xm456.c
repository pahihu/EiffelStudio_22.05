/*
 * Code for class XM_EIFFEL_PARSER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm456.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_PARSER_SKELETON}.make */
void F1311_9871 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1311_9872(Current);
	F1311_9927(Current);
	F1308_9642(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_45_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = RTLNS(eif_new_type(194, 0x01).id, 194, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = F272_2501(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	tr1 = F272_2501(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9873,F1311_9873, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(9873,F1311_9873, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_45_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.initialize */
void F1311_9872 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F191_2108(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = F128_1551(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.null_resolver */
static EIF_REFERENCE F1311_9873_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (9873);
#define Result RTOSR(9873)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(87, 0x01).id, 87, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9873);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1311_9873 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9873,F1311_9873_body,(Current));
}

/* {XM_EIFFEL_PARSER_SKELETON}.reset */
void F1311_9874 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1311_9927(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_45_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	F1212_8254(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	F1212_8254(RTCW(tr1));
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.parse_from_stream */
void F1311_9875 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	F1311_9874(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	F1303_9496(RTCW(tr1), arg1);
	F1311_9880(Current);
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.parse_with_events */
void F1311_9880 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1311_9895(Current);
	F196_2147(Current);
	F1308_9643(Current);
	F196_2148(Current);
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.namespace_force_last */
void F1311_9883 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tb1 = F982_6640(RTCW(arg1), arg2);
	if (tb1) {
		F982_6641(RTCW(arg1), arg2);
	} else {
		tr1 = RTOSCF(1540,F125_1540, (Current));
		F1311_9901(Current, tr1);
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.is_correct */
EIF_BOOLEAN F1311_9884 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_17_) == NULL);
}

/* {XM_EIFFEL_PARSER_SKELETON}.last_error_description */
EIF_REFERENCE F1311_9886 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("is_correct", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_SKELETON}.position */
EIF_REFERENCE F1311_9891 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if (F1311_9884(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		Result = F1303_9512(RTCW(tr1));
	} else {
		tr1 = F1311_9892(Current);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5982[Dtype(RTCW(tr1))-1184])(tr1);
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_SKELETON}.positions */
EIF_REFERENCE F1311_9892 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTLE;
		return (EIF_REFERENCE) F1311_9897(Current);
	}/* NOTREACHED */
	
}

/* {XM_EIFFEL_PARSER_SKELETON}.reset_error_state */
void F1311_9895 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.setup_error_state */
void F1311_9896 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) arg1;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_18_) == NULL)) {
		tr1 = F1311_9897(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		F1303_9498(RTCW(tr1));
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tb1 = F1125_7674(RTCW(tr1));
			if (tb1) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F1201_8082(RTCW(tr1));
			F1303_9498(RTCW(tr1));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			F1201_8092(RTCW(tr1));
		}
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.new_positions */
EIF_REFERENCE F1311_9897 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1200,0xFF01,1303,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNSMART(typres0.id);
	}
	F1201_8085(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_22_));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1187,0xFF01,1031,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 1187, _OBJSIZ_4_0_0_1_0_0_0_0_);
	}
	F1185_7905(RTCW(Result));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	tr1 = F1303_9512(RTCW(tr1));
	F1185_7932(RTCW(Result), tr1);
	for (;;) {
		tb1 = F1125_7674(RTCW(loc1));
		if (tb1) break;
		tr1 = F1201_8082(RTCW(loc1));
		tr1 = F1303_9512(RTCW(tr1));
		F1185_7932(RTCW(Result), tr1);
		F1201_8092(RTCW(loc1));
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_SKELETON}.report_error */
void F1311_9900 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1311_9896(Current, arg1);
	tr1 = F1027_7278(Current);
	F196_2150(Current, tr1);
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.force_error */
void F1311_9901 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1311_9900(Current, arg1);
	F1308_9648(Current);
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.new_namespace_name */
EIF_REFERENCE F1311_9906 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_45_1_)) {
		tr1 = RTLNS(eif_new_type(981, 0x01).id, 981, _OBJSIZ_3_1_0_1_0_0_0_0_);
		F982_6624(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(981, 0x01).id, 981, _OBJSIZ_3_1_0_1_0_0_0_0_);
		F982_6625(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {XM_EIFFEL_PARSER_SKELETON}.new_name_set */
EIF_REFERENCE F1311_9907 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1220,0xFF01,981,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1220, _OBJSIZ_7_0_0_9_0_0_0_0_);
	}
	F1217_8322(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_EIFFEL_PARSER_SKELETON}.new_dtd_attribute_content */
EIF_REFERENCE F1311_9908 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1296, 0x01).id, 1296, _OBJSIZ_3_3_0_0_0_0_0_0_);
	F1297_9300(RTCW(tr1));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_EIFFEL_PARSER_SKELETON}.new_dtd_attribute_content_list */
EIF_REFERENCE F1311_9909 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1187,0xFF01,1296,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1187, _OBJSIZ_4_0_0_1_0_0_0_0_);
	}
	F1185_7905(RTCW(tr1));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_EIFFEL_PARSER_SKELETON}.new_dtd_external_id */
EIF_REFERENCE F1311_9910 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1259, 0x01).id, 1259, _OBJSIZ_3_0_0_0_0_0_0_0_);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_EIFFEL_PARSER_SKELETON}.apply_encoding */
void F1311_9911 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	tb1 = F1303_9502(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		F1303_9503(RTCW(tr1), arg1);
	} else {
		tr1 = RTOSCF(1502,F125_1502, (Current));
		F1311_9901(Current, tr1);
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.set_element_repetition */
void F1311_9912 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	F1314_10060(RTCW(arg1));
	if ((EIF_BOOLEAN)(arg2 == RTOSCF(9913,F1311_9913, (Current)))) {
		F1314_10061(RTCW(arg1));
	} else {
		if ((EIF_BOOLEAN)(arg2 == RTOSCF(9914,F1311_9914, (Current)))) {
			F1314_10062(RTCW(arg1));
		} else {
			if ((EIF_BOOLEAN)(arg2 == RTOSCF(9915,F1311_9915, (Current)))) {
				F1314_10063(RTCW(arg1));
			}
		}
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.one_or_more_repetition */

EIF_REFERENCE F1311_9913 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9913,RTMS_EX_H("+",1,43));
}

/* {XM_EIFFEL_PARSER_SKELETON}.zero_or_one_repetition */

EIF_REFERENCE F1311_9914 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9914,RTMS_EX_H("\?",1,63));
}

/* {XM_EIFFEL_PARSER_SKELETON}.zero_or_more_repetition */

EIF_REFERENCE F1311_9915 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9915,RTMS_EX_H("*",1,42));
}

/* {XM_EIFFEL_PARSER_SKELETON}.element_name */
EIF_REFERENCE F1311_9916 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1313, 0x01).id, 1313, _OBJSIZ_2_3_0_0_0_0_0_0_);
	F1314_10042(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_EIFFEL_PARSER_SKELETON}.on_attribute_declarations */
void F1311_9917 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,Current);
	RTLIU(6);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[Dtype(RTCW(arg2))-1184])(arg2);
	F1053_7395(RTCW(loc1));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2921[Dtype(RTCW(loc1))-437])(loc1);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2920[Dtype(RTCW(loc1))-437])(loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2920[Dtype(RTCW(loc1))-437])(loc1);
		F129_1556(Current, arg1, tr1, tr2);
		F1053_7396(RTCW(loc1));
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.new_literal_entity */
EIF_REFERENCE F1311_9918 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1305, 0x01).id, 1305, _OBJSIZ_27_4_0_21_0_0_0_0_);
	F1306_9621(RTCW(tr1), arg1, arg2);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_EIFFEL_PARSER_SKELETON}.new_external_entity */
EIF_REFERENCE F1311_9919 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1305, 0x01).id, 1305, _OBJSIZ_27_4_0_21_0_0_0_0_);
	F1306_9622(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_EIFFEL_PARSER_SKELETON}.when_entity_declared */
void F1311_9920 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
		tb1 = F1223_8402(RTCW(tr1), arg1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
			F1223_8415(RTCW(tr1), arg2, arg1);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.when_pe_entity_declared */
void F1311_9921 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		loc1 = RTLNS(eif_new_type(1306, 0x01).id, 1306, _OBJSIZ_27_6_0_21_0_0_0_0_);
		F1306_9623(RTCW(loc1), arg2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
		tb1 = F1223_8402(RTCW(tr1), arg1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
			F1223_8415(RTCW(tr1), loc1, arg1);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.entity_referenced_in_entity_value */
EIF_REFERENCE F1311_9922 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_45_2_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
		tb1 = F1223_8402(RTCW(tr1), arg1);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
			tr1 = F1223_8394(RTCW(tr1), arg1);
			Result = F1311_9923(Current, tr1);
		} else {
			tr1 = RTOSCF(1525,F125_1525, (Current));
			F1311_9901(Current, tr1);
			Result = RTMS_EX_H("",0,0);
		}
	} else {
		tr1 = RTOSCF(1537,F125_1537, (Current));
		F1311_9901(Current, tr1);
		Result = RTMS_EX_H("",0,0);
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_SKELETON}.defined_entity_referenced */
EIF_REFERENCE F1311_9923 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_25_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTCT0("is_external", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_26_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = F1311_9925(Current, loc2);
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_SKELETON}.resolve_external_id */
void F1311_9924 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	RTCT0("is_system_id", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		F87_1045(RTCW(arg1), loc2, loc1);
	} else {
		{
			/* INLINED CODE (XM_EXTERNAL_RESOLVER.resolve) */
			(void) RTCW(arg1);
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.external_entity_to_string */
EIF_REFERENCE F1311_9925 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLR(7,loc1);
	RTLIU(8);
	
	RTGC;
	F1311_9924(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F88_1052(RTCW(tr1));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		F1311_9901(Current, loc3);
		Result = RTMS_EX_H("",0,0);
	} else {
		RTCT0("attached entity_resolver.last_stream as l_last_stream", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		{
			/* INLINED CODE (XM_EXTERNAL_RESOLVER.last_stream) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc1 = RTLNS(eif_new_type(980, 0x01).id, 980, _OBJSIZ_3_0_0_1_0_0_0_0_);
		F981_6589(RTCW(loc1), loc4);
		tr1 = RTOSCF(894,F64_894, (RTCV(RTOSCF(4466,F830_4466, (Current)))));
		ti4_1 = RTOSCF(2022,F177_2022, (RTCW(tr1)));
		F981_6598(RTCW(loc1), ti4_1);
		Result = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1542[Dtype(loc4)-980])(loc4);
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R1549[Dtype(loc4)-980])(loc4);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		{
			/* INLINED CODE (XM_EXTERNAL_RESOLVER.resolve_finish) */
			(void) RTCW(tr1);
			/* END INLINED CODE */
		}
		;
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (loc2 >= ti4_1)) break;
			tb1 = '\0';
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(Result))-712])(Result, loc2));
			if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\015')) {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(Result))-712])(Result, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L))));
				tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\012');
			}
			if (tb1) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4659[Dtype(RTCW(Result))-950])(Result, loc2);
			}
			loc2++;
		}
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (loc2 > ti4_2)) break;
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(Result))-712])(Result, loc2));
			if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\015')) {
				tc1 = (EIF_CHARACTER_8) '\012';
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3121[Dtype(RTCW(Result))-737])(Result, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc2);
			}
			loc2++;
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_SKELETON}.when_external_dtd */
void F1311_9926 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	F1311_9924(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F88_1052(RTCW(tr1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		if ((EIF_BOOLEAN)(tr1 == RTOSCF(9873,F1311_9873, (Current)))) {
			tr1 = RTOSCF(1529,F125_1529, (Current));
			F1311_9901(Current, tr1);
		} else {
			F1311_9901(Current, loc1);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		F1201_8088(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_21_));
		tr1 = RTLNS(eif_new_type(1304, 0x01).id, 1304, _OBJSIZ_23_5_0_21_0_0_0_0_);
		F1305_9617(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		F1303_9497(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.make_scanner */
void F1311_9927 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1303, 1).id);
	F1303_9492(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1200,0xFF01,1303,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.last_token */
EIF_INTEGER_32 F1311_9930 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_12_);
}


/* {XM_EIFFEL_PARSER_SKELETON}.read_token */
void F1311_9931 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5313[Dtype(RTCW(tr1))-1303])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O5290[Dtype(tr1)-1014]);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_12_) = (EIF_INTEGER_32) ti4_1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_21_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	tb1 = F1015_6915(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		F1303_9498(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tb1 = F1125_7674(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F1201_8082(RTCW(tr1));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			F1201_8092(RTCW(tr1));
			F1311_9931(Current);
		}
	}
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_12_) == ((EIF_INTEGER_32) 321L))) {
		tr1 = F1311_9936(Current, loc1);
		F1311_9932(Current, tr1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_12_) == ((EIF_INTEGER_32) 322L))) {
			tr1 = F1311_9937(Current, loc1);
			F1311_9932(Current, tr1);
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_12_) == ((EIF_INTEGER_32) 342L))) {
				tr1 = F1311_9936(Current, loc1);
				F1311_9933(Current, tr1);
			} else {
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_12_) == ((EIF_INTEGER_32) 343L))) {
					tr1 = F1311_9937(Current, loc1);
					F1311_9933(Current, tr1);
				} else {
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_12_) == ((EIF_INTEGER_32) 345L))) {
						tr1 = F1311_9936(Current, loc1);
						F1311_9934(Current, tr1);
					} else {
						if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_45_3_0_12_) == ((EIF_INTEGER_32) 346L))) {
							tr1 = F1311_9937(Current, loc1);
							F1311_9934(Current, tr1);
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.process_pe_entity */
void F1311_9932 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	tb1 = F1223_8402(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
		tr1 = F1223_8394(RTCW(tr1), arg1);
		F1311_9935(Current, tr1);
	} else {
		tr1 = RTOSCF(1530,F125_1530, (Current));
		F1311_9901(Current, tr1);
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.process_entity */
void F1311_9933 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	tb1 = F1223_8402(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
		tr1 = F1223_8394(RTCW(tr1), arg1);
		F1311_9935(Current, tr1);
	} else {
		tr1 = RTOSCF(1524,F125_1524, (Current));
		F1311_9901(Current, tr1);
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.process_attribute_entity */
void F1311_9934 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	tb1 = F1223_8402(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
		tr1 = F1223_8394(RTCW(tr1), arg1);
		tb1 = F1306_9626(RTCW(tr1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
			tr1 = F1223_8394(RTCW(tr1), arg1);
			F1311_9935(Current, tr1);
		} else {
			tr1 = RTOSCF(1523,F125_1523, (Current));
			F1311_9901(Current, tr1);
		}
	} else {
		tr1 = RTOSCF(1524,F125_1524, (Current));
		F1311_9901(Current, tr1);
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.process_entity_scanner */
void F1311_9935 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	F1306_9631(RTCW(arg1));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_19_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1311_9901(Current, loc1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		ti4_1 = F1016_6975(RTCW(tr1));
		F1016_6981(RTCW(arg1), ti4_1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		F1201_8088(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_21_));
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) arg1;
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_SKELETON}.onstring_ascii */
EIF_REFERENCE F1311_9936 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if (F1026_7246(Current)) {
		RTLE;
		return (EIF_REFERENCE) F970_6457(Current, arg1);
	} else {
		RTLE;
		return (EIF_REFERENCE) arg1;
	}/* NOTREACHED */
	
}

/* {XM_EIFFEL_PARSER_SKELETON}.onstring_utf8 */
EIF_REFERENCE F1311_9937 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	if (F1026_7243(Current)) {
		tr1 = RTOSCF(1545,F125_1545, (Current));
		F1311_9901(Current, tr1);
		Result = RTMS_EX_H("",0,0);
	} else {
		tr1 = RTOSCF(2759,F292_2759, (Current));
		tb1 = F957_6333(RTCW(tr1), arg1);
		if (tb1) {
			Result = F970_6457(Current, arg1);
			if (F1026_7244(Current)) {
				if ((EIF_BOOLEAN) (F1311_9938(Current, Result) > ((EIF_INTEGER_32) 255L))) {
					tr1 = RTOSCF(1546,F125_1546, (Current));
					F1311_9901(Current, tr1);
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4754[Dtype(RTCW(Result))-949])(Result);
					RTLE;
					return (EIF_REFERENCE) tr1;
				}
			}
		} else {
			tr1 = RTOSCF(1547,F125_1547, (Current));
			F1311_9901(Current, tr1);
			Result = RTMS_EX_H("",0,0);
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_SKELETON}.maximum_item_code */
EIF_INTEGER_32 F1311_9938 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(arg1))-950])(arg1, loc1);
		if ((EIF_BOOLEAN) (loc3 > Result)) {
			Result = (EIF_INTEGER_32) loc3;
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_SKELETON}.shared_empty_string */
EIF_REFERENCE F1311_9939 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (F1026_7246(Current)) {
		RTLE;
		return (EIF_REFERENCE) RTOSCF(9941,F1311_9941, (Current));
	} else {
		RTLE;
		return (EIF_REFERENCE) RTOSCF(9940,F1311_9940, (Current));
	}/* NOTREACHED */
	
}

/* {XM_EIFFEL_PARSER_SKELETON}.shared_empty_string_string */
static EIF_REFERENCE F1311_9940_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (9940);
#define Result RTOSR(9940)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F943_5827(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9940);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1311_9940 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9940,F1311_9940_body,(Current));
}

/* {XM_EIFFEL_PARSER_SKELETON}.shared_empty_string_uc */
static EIF_REFERENCE F1311_9941_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (9941);
#define Result RTOSR(9941)
	RTOC_NEW(Result);
	Result = F970_6460(Current);
	RTOSE (9941);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1311_9941 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9941,F1311_9941_body,(Current));
}

void EIF_Minit456 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
