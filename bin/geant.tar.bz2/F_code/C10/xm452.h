
#ifndef _C10_xm452_
#define _C10_xm452_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1307_9637(EIF_REFERENCE);
extern void F1307_9638(EIF_REFERENCE);
extern void F1307_9639(EIF_REFERENCE);
extern void EIF_Minit452(void);
extern void F1306_9636(EIF_REFERENCE);
extern void F1306_9635(EIF_REFERENCE);
extern void F1015_6930(EIF_REFERENCE);
extern EIF_BOOLEAN F1015_6915(EIF_REFERENCE);
extern EIF_REFERENCE F1303_9520(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,9520)

#ifdef __cplusplus
}
#endif

#endif
