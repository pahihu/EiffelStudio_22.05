/*
 * Code for class XM_EIFFEL_ENTITY_DEF
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm451.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_ENTITY_DEF}.make_literal */
void F1306_9621 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) arg2;
	F1303_9492(Current);
	tr1 = RTLNS(eif_new_type(87, 0x01).id, 87, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_EIFFEL_ENTITY_DEF}.make_external */
void F1306_9622 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) arg2;
	F1303_9492(Current);
	RTLE;
}

/* {XM_EIFFEL_ENTITY_DEF}.make_def */
void F1306_9623 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_26_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_23_);
		F1306_9622(Current, tr1, loc1);
	} else {
		RTCT0("is_literal", EX_CHECK);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_24_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_25_);
			loc3 = tr1;
			tb1 = EIF_TEST(loc3);
		}
		if (tb1) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1306_9621(Current, loc2, loc3);
	}
	RTLE;
}

/* {XM_EIFFEL_ENTITY_DEF}.is_external */
EIF_BOOLEAN F1306_9625 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_26_) != NULL);
}

/* {XM_EIFFEL_ENTITY_DEF}.is_literal */
EIF_BOOLEAN F1306_9626 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1306_9625(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {XM_EIFFEL_ENTITY_DEF}.hash_code */
EIF_INTEGER_32 F1306_9630 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R3640[Dtype(loc1)-831])(loc1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			ti4_1 = F1260_8758(loc2);
			RTLE;
			return (EIF_INTEGER_32) ti4_1;
		}
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {XM_EIFFEL_ENTITY_DEF}.apply_input_buffer */
void F1306_9631 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLIU(9);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_27_3_)) {
		tr1 = RTOSCF(1526,F125_1526, (Current));
		F1303_9510(Current, tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
		loc2 = tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
		loc3 = tr1;
		if ((EIF_BOOLEAN) (EIF_TEST(loc2) && EIF_TEST(loc3))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5286[dtype-1303])(Current);
			loc1 = RTLNS(eif_new_type(988, 0x01).id, 988, _OBJSIZ_2_2_0_1_0_0_0_0_);
			tr1 = RTOSCF(2759,F292_2759, (Current));
			tr1 = F957_6364(RTCW(tr1), loc3);
			F989_6693(RTCW(loc1), tr1);
			F1303_9496(Current, loc1);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) loc2;
		} else {
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_1_);
				loc5 = tr1;
				tb1 = EIF_TEST(loc5);
			}
			if (tb1) {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5286[dtype-1303])(Current);
				tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_2_);
				loc6 = tr1;
				if (EIF_TEST(loc6)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
					F87_1045(RTCW(tr1), loc6, loc5);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
					{
						/* INLINED CODE (XM_EXTERNAL_RESOLVER.resolve) */
						(void) RTCW(tr1);
						/* END INLINED CODE */
					}
					;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
				tr1 = F88_1052(RTCW(tr1));
				loc7 = tr1;
				if (EIF_TEST(loc7)) {
					F1303_9510(Current, loc7);
				} else {
					F1303_9497(Current, *(EIF_REFERENCE *)(Current + _REFACS_23_));
				}
			} else {
				tr1 = RTMS_EX_H("Internal error",14,2047764850);
				F1303_9510(Current, tr1);
			}
		}
	}
	RTLE;
}

/* {XM_EIFFEL_ENTITY_DEF}.normalized_newline */
EIF_REFERENCE F1306_9632 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (F1306_9626(Current)) {
		RTLE;
		return (EIF_REFERENCE) F1016_6967(Current);
	} else {
		RTLE;
		return (EIF_REFERENCE) RTOSCF(9518,F1303_9518, (Current));
	}/* NOTREACHED */
	
}

/* {XM_EIFFEL_ENTITY_DEF}.has_normalized_newline */
EIF_BOOLEAN F1306_9633 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F1306_9626(Current);
}

/* {XM_EIFFEL_ENTITY_DEF}.read_token */
void F1306_9635 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1018_7057(Current);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_27_3_)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_27_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tb1 = '\0';
		if (F1306_9625(Current)) {
			tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5290[dtype-1014]) == ((EIF_INTEGER_32) 276L));
		}
		if (tb1) {
			for (;;) {
				tb1 = '\01';
				if (!F1015_6915(Current)) {
					tb1 = loc1;
				}
				if (tb1) break;
				F1018_7057(Current);
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5290[dtype-1014]) == ((EIF_INTEGER_32) 283L))) {
					loc2++;
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5290[dtype-1014]) == ((EIF_INTEGER_32) 278L))) {
						loc3++;
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5290[dtype-1014]) == ((EIF_INTEGER_32) 262L))) {
							loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc4;
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						} else {
							if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5290[dtype-1014]) == ((EIF_INTEGER_32) 263L))) {
							} else {
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5290[dtype-1014]) == ((EIF_INTEGER_32) 264L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5290[dtype-1014]) == ((EIF_INTEGER_32) 265L))) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5290[dtype-1014]) == ((EIF_INTEGER_32) 284L))) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5290[dtype-1014]) == ((EIF_INTEGER_32) 279L)))) {
									loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								} else {
									if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5290[dtype-1014]) == ((EIF_INTEGER_32) 277L))) {
										if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN) (loc3 <= ((EIF_INTEGER_32) 1L)))) {
											F1018_7057(Current);
										}
										loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									} else {
										loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	if (F1015_6915(Current)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_27_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {XM_EIFFEL_ENTITY_DEF}.reset */
void F1306_9636 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1303_9493(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_27_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

void EIF_Minit451 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
