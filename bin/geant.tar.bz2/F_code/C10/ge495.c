/*
 * Code for class GEANT_MAP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge495.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_MAP}.make */
void F1350_10216 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	tr1 = RTOSCF(10228,F1350_10228, (Current));
	F1350_10224(Current, tr1);
	RTLE;
}

/* {GEANT_MAP}.is_executable */
EIF_BOOLEAN F1350_10218 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
		tb1 = '\01';
		tb2 = '\01';
		tb3 = '\01';
		tb4 = '\01';
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr3 = RTOSCF(10228,F1350_10228, (Current));
		tb5 = F958_6409(RTCW(tr1), tr2, tr3);
		if (!tb5) {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr3 = RTOSCF(10229,F1350_10229, (Current));
			tb5 = F958_6409(RTCW(tr1), tr2, tr3);
			tb4 = tb5;
		}
		if (!tb4) {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr3 = RTOSCF(10230,F1350_10230, (Current));
			tb4 = F958_6409(RTCW(tr1), tr2, tr3);
			tb3 = tb4;
		}
		if (!tb3) {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr3 = RTOSCF(10232,F1350_10232, (Current));
			tb3 = F958_6409(RTCW(tr1), tr2, tr3);
			tb2 = tb3;
		}
		if (!tb2) {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr3 = RTOSCF(10231,F1350_10231, (Current));
			tb2 = F958_6409(RTCW(tr1), tr2, tr3);
			tb1 = tb2;
		}
		Result = tb1;
	}
	if ((EIF_BOOLEAN) !Result) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("  [map] error: value of attribute \'type\' incorrect. Valid: {\'flat\', \'glob\', \'regexp\', \'identity\', \'merge\'}",106,1822020477);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10324(RTCW(tr1), tr2);
	}
	if (Result) {
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr3 = RTOSCF(10228,F1350_10228, (Current));
		tb1 = F958_6409(RTCW(tr1), tr2, tr3);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
			if ((EIF_BOOLEAN) !Result) {
				tr1 = *(EIF_REFERENCE *)(Current);
				{
					static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr3) = 1L;
					memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
				}
				tr4 = RTMS_EX_H("  [map] error: attribute \'from\' must not be set when \'type\' is \'identity\'",73,1100825639);
				*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
				F1356_10324(RTCW(tr1), tr2);
			}
			if (Result) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
				if ((EIF_BOOLEAN) !Result) {
					tr1 = *(EIF_REFERENCE *)(Current);
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr3) = 1L;
						memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
					}
					tr4 = RTMS_EX_H("  [map] error: attribute \'to\' must not be set when \'type\' is \'identity\'",71,160518951);
					*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
					F1356_10324(RTCW(tr1), tr2);
				}
			}
		}
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr3 = RTOSCF(10231,F1350_10231, (Current));
		tb1 = F958_6409(RTCW(tr1), tr2, tr3);
		if (tb1) {
			Result = '\0';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R4752[Dtype(loc1)-949])(loc1, (EIF_CHARACTER_8) '*', ((EIF_INTEGER_32) 1L));
				Result = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
			}
			if ((EIF_BOOLEAN) !Result) {
				tr1 = *(EIF_REFERENCE *)(Current);
				{
					static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr3) = 1L;
					memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
				}
				tr4 = RTMS_EX_H("  [map] error: in mode \'glob\' attribute \'from\' must be set and contain a \'*\' character",86,1238027378);
				*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
				F1356_10324(RTCW(tr1), tr2);
			}
			if (Result) {
				Result = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				loc2 = tr1;
				if (EIF_TEST(loc2)) {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R4752[Dtype(loc2)-949])(loc2, (EIF_CHARACTER_8) '*', ((EIF_INTEGER_32) 1L));
					Result = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
				}
				if ((EIF_BOOLEAN) !Result) {
					tr1 = *(EIF_REFERENCE *)(Current);
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr3) = 1L;
						memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
					}
					tr4 = RTMS_EX_H("  [map] error: in mode \'glob\' attribute \'to\' must be set and contain a \'*\' character",84,189581682);
					*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
					F1356_10324(RTCW(tr1), tr2);
				}
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc3 = tr1;
	if ((EIF_BOOLEAN) (Result && EIF_TEST(loc3))) {
		Result = F1350_10218(loc3);
		if ((EIF_BOOLEAN) !Result) {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 1L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("  [map] error: nested element \'map\' is not defined correctly",60,1911960953);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10324(RTCW(tr1), tr2);
		}
	}
	RTLE;
	return Result;
}

/* {GEANT_MAP}.mapped_filename */
EIF_REFERENCE F1350_10223 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(22);
	RTLR(0,loc10);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLR(8,Result);
	RTLR(9,loc11);
	RTLR(10,loc12);
	RTLR(11,loc13);
	RTLR(12,loc9);
	RTLR(13,loc14);
	RTLR(14,loc15);
	RTLR(15,loc3);
	RTLR(16,loc4);
	RTLR(17,loc7);
	RTLR(18,loc8);
	RTLR(19,loc5);
	RTLR(20,loc6);
	RTLR(21,loc1);
	RTLIU(22);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		tb1 = F1350_10218(loc10);
		if (tb1) {
			loc2 = F1350_10223(loc10, arg1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 1L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("  [map] error: map definition wrong",35,1424788583);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10324(RTCW(tr1), tr2);
		}
	} else {
		loc2 = (EIF_REFERENCE) arg1;
	}
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr3 = RTOSCF(10228,F1350_10228, (Current));
		tb1 = F958_6409(RTCW(tr1), tr2, tr3);
		if (tb1) {
			Result = (EIF_REFERENCE) loc2;
		} else {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr3 = RTOSCF(10229,F1350_10229, (Current));
			tb1 = F958_6409(RTCW(tr1), tr2, tr3);
			if (tb1) {
				tr1 = RTOSCF(8477,F1240_8477, (Current));
				Result = F1271_8993(RTCW(tr1), loc2);
			} else {
				tr1 = RTOSCF(6466,F971_6466, (Current));
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr3 = RTOSCF(10230,F1350_10230, (Current));
				tb1 = F958_6409(RTCW(tr1), tr2, tr3);
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					loc11 = tr1;
					if (EIF_TEST(loc11)) {
						Result = (EIF_REFERENCE) loc11;
					} else {
						Result = RTMS_EX_H("",0,0);
					}
				} else {
					tr1 = RTOSCF(6466,F971_6466, (Current));
					tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tr3 = RTOSCF(10232,F1350_10232, (Current));
					tb1 = F958_6409(RTCW(tr1), tr2, tr3);
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						loc12 = tr1;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						loc13 = tr1;
						if ((EIF_BOOLEAN) (EIF_TEST(loc12) && EIF_TEST(loc13))) {
							loc9 = RTLNS(eif_new_type(1434, 0x01).id, 1434, _OBJSIZ_12_16_0_23_0_0_2_0_);
							F1434_11279(RTCW(loc9));
							F1434_11282(RTCW(loc9), loc12);
							tb1 = F1433_11192(RTCW(loc9));
							if (tb1) {
								F1288_9220(RTCW(loc9), loc2);
								tb1 = F1288_9204(RTCW(loc9));
								if (tb1) {
									Result = F1289_9233(RTCW(loc9), loc13);
								} else {
									tr1 = *(EIF_REFERENCE *)(Current);
									{
										static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
										EIF_TYPE typres0;
										static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
										
										typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
										tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
										RT_SPECIAL_COUNT(tr3) = 3L;
										memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
									}
									tr4 = RTMS_EX_H("  [*map] no match for \'",23,1302954791);
									*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc2;
									RTAR(tr3,loc2);
									tr4 = RTMS_EX_H("\'",1,39);
									*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
									F1356_10325(RTCW(tr1), tr2);
									Result = (EIF_REFERENCE) loc2;
								}
							} else {
								Result = (EIF_REFERENCE) loc2;
								tr1 = *(EIF_REFERENCE *)(Current);
								{
									static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
									EIF_TYPE typres0;
									static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
									
									typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
									tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
									RT_SPECIAL_COUNT(tr3) = 3L;
									memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
								}
								tr4 = RTMS_EX_H("regexp ",7,1297880864);
								*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc12;
								RTAR(tr3,loc12);
								tr4 = RTMS_EX_H(" could not be compiled",22,1198828388);
								*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
								F1356_10324(RTCW(tr1), tr2);
							}
						} else {
							Result = (EIF_REFERENCE) loc2;
							tr1 = *(EIF_REFERENCE *)(Current);
							{
								static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
								RT_SPECIAL_COUNT(tr3) = 3L;
								memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
							}
							tr4 = RTMS_EX_H("  [*map] no match for \'",23,1302954791);
							*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc2;
							RTAR(tr3,loc2);
							tr4 = RTMS_EX_H("\'",1,39);
							*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
							F1356_10325(RTCW(tr1), tr2);
						}
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						loc14 = tr1;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						loc15 = tr1;
						if ((EIF_BOOLEAN) (EIF_TEST(loc14) && EIF_TEST(loc15))) {
							loc3 = F1349_10212(Current, loc14);
							loc4 = F1349_10213(Current, loc14);
							loc7 = F1349_10212(Current, loc15);
							loc8 = F1349_10213(Current, loc15);
							tr1 = RTOSCF(6466,F971_6466, (Current));
							loc5 = F958_6416(RTCW(tr1), loc2);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4654[Dtype(RTCW(loc5))-950])(loc5, ti4_1);
							tr1 = RTOSCF(6466,F971_6466, (Current));
							loc6 = F958_6416(RTCW(tr1), loc2);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4655[Dtype(RTCW(loc6))-950])(loc6, ti4_1);
							tb1 = '\0';
							tr1 = RTOSCF(6466,F971_6466, (Current));
							tb2 = F958_6409(RTCW(tr1), loc5, loc3);
							if (tb2) {
								tr1 = RTOSCF(6466,F971_6466, (Current));
								tb2 = F958_6409(RTCW(tr1), loc6, loc4);
								tb1 = tb2;
							}
							if (tb1) {
								tr1 = RTOSCF(6466,F971_6466, (Current));
								loc1 = F958_6416(RTCW(tr1), loc2);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4660[Dtype(RTCW(loc1))-950])(loc1, ti4_1);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4662[Dtype(RTCW(loc1))-950])(loc1, ti4_1);
								tr1 = RTOSCF(6466,F971_6466, (Current));
								Result = F958_6416(RTCW(tr1), loc7);
								tr1 = RTOSCF(6466,F971_6466, (Current));
								tr1 = F958_6417(RTCW(tr1), Result, loc1);
								Result = (EIF_REFERENCE) tr1;
								tr1 = RTOSCF(6466,F971_6466, (Current));
								tr1 = F958_6417(RTCW(tr1), Result, loc8);
								Result = (EIF_REFERENCE) tr1;
							} else {
								tr1 = *(EIF_REFERENCE *)(Current);
								{
									static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
									EIF_TYPE typres0;
									static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
									
									typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
									tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
									RT_SPECIAL_COUNT(tr3) = 3L;
									memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
								}
								tr4 = RTMS_EX_H("  [*map] no match for \'",23,1302954791);
								*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc2;
								RTAR(tr3,loc2);
								tr4 = RTMS_EX_H("\'",1,39);
								*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
								F1356_10325(RTCW(tr1), tr2);
								Result = (EIF_REFERENCE) loc2;
							}
						} else {
							Result = RTMS_EX_H("",0,0);
						}
					}
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 5L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("  [*map] mapping \'",18,272516391);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc2;
		RTAR(tr3,loc2);
		tr4 = RTMS_EX_H("\' to \'",6,2030362663);
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) Result;
		RTAR(tr3,Result);
		tr4 = RTMS_EX_H("\'",1,39);
		*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10325(RTCW(tr1), tr2);
	} else {
		Result = RTMS_EX_H("",0,0);
	}
	RTLE;
	return Result;
}

/* {GEANT_MAP}.set_type */
void F1350_10224 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_MAP}.set_source_pattern */
void F1350_10225 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_MAP}.set_target_pattern */
void F1350_10226 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_MAP}.set_map */
void F1350_10227 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_MAP}.type_attribute_value_identity */
static EIF_REFERENCE F1350_10228_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10228);
#define Result RTOSR(10228)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("identity",8,968811641);
	RTOSE (10228);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1350_10228 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10228,F1350_10228_body,(Current));
}

/* {GEANT_MAP}.type_attribute_value_flat */
static EIF_REFERENCE F1350_10229_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10229);
#define Result RTOSR(10229)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("flat",4,1718378868);
	RTOSE (10229);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1350_10229 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10229,F1350_10229_body,(Current));
}

/* {GEANT_MAP}.type_attribute_value_merge */
static EIF_REFERENCE F1350_10230_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10230);
#define Result RTOSR(10230)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("merge",5,1702833509);
	RTOSE (10230);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1350_10230 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10230,F1350_10230_body,(Current));
}

/* {GEANT_MAP}.type_attribute_value_glob */
static EIF_REFERENCE F1350_10231_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10231);
#define Result RTOSR(10231)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("glob",4,1735159650);
	RTOSE (10231);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1350_10231 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10231,F1350_10231_body,(Current));
}

/* {GEANT_MAP}.type_attribute_value_regexp */
static EIF_REFERENCE F1350_10232_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10232);
#define Result RTOSR(10232)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("regexp",6,1959612016);
	RTOSE (10232);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1350_10232 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10232,F1350_10232_body,(Current));
}

void EIF_Minit495 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
