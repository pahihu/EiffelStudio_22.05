/*
 * Code for class LX_LEX_PARSER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx454.h"
#include "eif_helpers.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_LEX_PARSER_SKELETON}.make_from_description */
void F1309_9718 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	F1019_7093(Current, arg1, arg2);
	F1308_9642(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1208,0xFF01,174,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1209_8141(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_39_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1210, 1).id);
	F1209_8141(RTCW(tr1), ((EIF_INTEGER_32) 40L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_40_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(6, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_41_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1207,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1208_8109(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_44_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1207,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1208_8109(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_45_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1207,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1208_8109(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_46_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1207,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1208_8109(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_47_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1207,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1208_8109(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_48_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1207,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1208_8109(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_49_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1232,0xFF01,1208,0xFF01,1208,0xFF01,831,0xFF01,831,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1223_8386(RTCW(tr1), ((EIF_INTEGER_32) 101L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_50_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(950, 1).id);
	F949_6124(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_51_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
	RTLE;
}

/* {LX_LEX_PARSER_SKELETON}.parse_string */
void F1309_9721 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1015_6946(Current, arg1);
	F1016_6995(Current, tr1);
	F1308_9643(Current);
	RTLE;
}

/* {LX_LEX_PARSER_SKELETON}.new_symbol_nfa */
EIF_REFERENCE F1309_9767 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_9_4_);
	if (tb1) {
		loc1 = RTLNS(eif_new_type(947, 0x01).id, 947, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F946_5957(RTCW(loc1), ((EIF_INTEGER_32) 10L));
		F948_6075(RTCW(loc1), arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		F1223_8405(RTCW(tr1), loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		tb1 = F1212_8240(RTCW(tr1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
			loc2 = F1212_8232(RTCW(tr1));
		} else {
			loc2 = F1309_9770(Current);
			F832_4481(RTCW(loc2), arg1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
			F1217_8331(RTCW(tr1), loc2);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
			tb1 = F1212_8240(RTCW(tr1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
				loc2 = F1212_8232(RTCW(tr1));
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
				F1217_8337(RTCW(tr1), loc2);
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
			F1223_8415(RTCW(tr1), loc2, loc1);
		}
		RTLE;
		return (EIF_REFERENCE) F1309_9769(Current, loc2);
	} else {
		tr1 = RTLNS(eif_new_type(1116, 0x01).id, 1116, _OBJSIZ_1_1_0_0_0_0_0_0_);
		F1117_7555(RTCW(tr1), arg1, *(EIF_BOOLEAN *)(Current+ _CHROFF_62_5_));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {LX_LEX_PARSER_SKELETON}.new_epsilon_nfa */
EIF_REFERENCE F1309_9768 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1116, 0x01).id, 1116, _OBJSIZ_1_1_0_0_0_0_0_0_);
	F1117_7556(RTCW(tr1), *(EIF_BOOLEAN *)(Current+ _CHROFF_62_5_));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {LX_LEX_PARSER_SKELETON}.new_symbol_class_nfa */
EIF_REFERENCE F1309_9769 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	F1217_8336(RTCW(tr1), arg1);
	tr1 = RTLNS(eif_new_type(1116, 0x01).id, 1116, _OBJSIZ_1_1_0_0_0_0_0_0_);
	F1117_7557(RTCW(tr1), arg1, *(EIF_BOOLEAN *)(Current+ _CHROFF_62_5_));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {LX_LEX_PARSER_SKELETON}.new_character_class */
EIF_REFERENCE F1309_9770 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(831, 0x01).id, 831, _OBJSIZ_1_2_0_2_0_0_4_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	ti4_1 = ((EIF_INTEGER_32) 0L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_9_22_0_1_);
	F832_4469(RTCW(Result), ti4_1, ti4_2);
	RTLE;
	return Result;
}

/* {LX_LEX_PARSER_SKELETON}.new_nfa_from_character */
EIF_REFERENCE F1309_9771 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_9_1_);
	if (tb1) {
		switch (arg1) {
			case 65L:
			case 66L:
			case 67L:
			case 68L:
			case 69L:
			case 70L:
			case 71L:
			case 72L:
			case 73L:
			case 74L:
			case 75L:
			case 76L:
			case 77L:
			case 78L:
			case 79L:
			case 80L:
			case 81L:
			case 82L:
			case 83L:
			case 84L:
			case 85L:
			case 86L:
			case 87L:
			case 88L:
			case 89L:
			case 90L:
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 32L));
				loc2 = RTLNS(eif_new_type(947, 0x01).id, 947, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F946_5957(RTCW(loc2), ((EIF_INTEGER_32) 2L));
				F948_6075(RTCW(loc2), loc1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
				F1223_8405(RTCW(tr1), loc2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
				tb1 = F1212_8240(RTCW(tr1));
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
					loc3 = F1212_8232(RTCW(tr1));
				} else {
					loc3 = F1309_9770(Current);
					F832_4481(RTCW(loc3), arg1);
					F832_4481(RTCW(loc3), loc1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
					F1217_8331(RTCW(tr1), loc3);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
					tb1 = F1212_8240(RTCW(tr1));
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
						loc3 = F1212_8232(RTCW(tr1));
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
					F1223_8415(RTCW(tr1), loc3, loc2);
				}
				Result = F1309_9769(Current, loc3);
				break;
			case 97L:
			case 98L:
			case 99L:
			case 100L:
			case 101L:
			case 102L:
			case 103L:
			case 104L:
			case 105L:
			case 106L:
			case 107L:
			case 108L:
			case 109L:
			case 110L:
			case 111L:
			case 112L:
			case 113L:
			case 114L:
			case 115L:
			case 116L:
			case 117L:
			case 118L:
			case 119L:
			case 120L:
			case 121L:
			case 122L:
				loc2 = RTLNS(eif_new_type(947, 0x01).id, 947, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F946_5957(RTCW(loc2), ((EIF_INTEGER_32) 2L));
				F948_6075(RTCW(loc2), arg1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
				F1223_8405(RTCW(tr1), loc2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
				tb1 = F1212_8240(RTCW(tr1));
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
					loc3 = F1212_8232(RTCW(tr1));
				} else {
					loc3 = F1309_9770(Current);
					F832_4481(RTCW(loc3), (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 32L)));
					F832_4481(RTCW(loc3), arg1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
					F1217_8331(RTCW(tr1), loc3);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
					tb1 = F1212_8240(RTCW(tr1));
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
						loc3 = F1212_8232(RTCW(tr1));
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
					F1223_8415(RTCW(tr1), loc3, loc2);
				}
				Result = F1309_9769(Current, loc3);
				break;
			default:
				Result = F1309_9767(Current, arg1);
				break;
		}
	} else {
		Result = F1309_9767(Current, arg1);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_);
	ti4_1 = eif_max_int32 (ti4_1,arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
	return Result;
}

/* {LX_LEX_PARSER_SKELETON}.new_nfa_from_character_class */
EIF_REFERENCE F1309_9772 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	tb1 = F1207_8114(RTCW(tr1));
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) F1309_9773(Current, arg1);
	} else {
		RTLE;
		return (EIF_REFERENCE) F1309_9769(Current, arg1);
	}/* NOTREACHED */
	
}

/* {LX_LEX_PARSER_SKELETON}.new_nfa_from_utf8_character_class */
EIF_REFERENCE F1309_9773 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc10);
	RTLR(4,loc4);
	RTLR(5,loc11);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_50_);
	F1223_8405(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_50_);
	tb1 = F1212_8240(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_50_);
		loc10 = F1212_8232(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1208,0xFF01,1208,0xFF01,831,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc10 = RTLNS(typres0.id, 1208, _OBJSIZ_4_0_0_2_0_0_0_0_);
		}
		F1209_8141(RTCW(loc10), ((EIF_INTEGER_32) 20L));
		loc4 = F1309_9770(Current);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_2_0_1_);
		loc2 = eif_min_int32 (((EIF_INTEGER_32) 127L),ti4_1);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tb1 = F832_4476(RTCW(arg1), loc1);
			if (tb1) {
				F832_4481(RTCW(loc4), loc1);
			}
			loc1++;
		}
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_1_0_);
		if ((EIF_BOOLEAN) !tb1) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1208,0xFF01,831,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc11 = RTLNS(typres0.id, 1208, _OBJSIZ_4_0_0_2_0_0_0_0_);
			}
			F1209_8141(RTCW(loc11), ((EIF_INTEGER_32) 1L));
			F1209_8160(RTCW(loc11), loc4);
			F1209_8165(RTCW(loc10), loc11);
		}
		loc4 = (EIF_REFERENCE) NULL;
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,737,831,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc5 = RTLNS(typres0.id, 737, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		F738_4058(RTCW(loc5), NULL, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 255L));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_2_0_1_);
		loc2 = eif_min_int32 (((EIF_INTEGER_32) 2047L),ti4_1);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tb1 = F832_4476(RTCW(arg1), loc1);
			if (tb1) {
				loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R4663[Dtype(RTCW(tr1))-947])(tr1);
				tr1 = RTLNS(eif_new_type(956, 0x01).id, 956, _OBJSIZ_0_0_0_0_0_0_0_0_);
				F957_6367(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_51_), loc1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 1L));
				loc4 = F738_4063(RTCW(loc5), ti4_1);
				if ((EIF_BOOLEAN)(loc4 == NULL)) {
					loc4 = F1309_9770(Current);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 1L));
					F738_4082(RTCW(loc5), loc4, ti4_1);
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 2L));
				F832_4481(RTCW(loc4), ti4_1);
			}
			loc1++;
		}
		loc4 = (EIF_REFERENCE) NULL;
		if (loc9) {
			F1309_9788(Current, loc5, NULL, NULL, loc10);
			loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		loc5 = (EIF_REFERENCE) NULL;
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,737,1221,873,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc6 = RTLNS(typres0.id, 737, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		F738_4058(RTCW(loc6), NULL, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 255L));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_2_0_1_);
		loc2 = eif_min_int32 ((EIF_INTEGER_32) (((EIF_INTEGER_32) 55296L) - ((EIF_INTEGER_32) 1L)),ti4_1);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tb1 = F832_4476(RTCW(arg1), loc1);
			if (tb1) {
				loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R4663[Dtype(RTCW(tr1))-947])(tr1);
				tr1 = RTLNS(eif_new_type(956, 0x01).id, 956, _OBJSIZ_0_0_0_0_0_0_0_0_);
				F957_6367(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_51_), loc1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 1L));
				loc7 = F738_4063(RTCW(loc6), ti4_1);
				if ((EIF_BOOLEAN)(loc7 == NULL)) {
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1221,873,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						loc7 = RTLNS(typres0.id, 1221, _OBJSIZ_7_0_0_9_0_0_0_0_);
					}
					F1214_8231(RTCW(loc7), ((EIF_INTEGER_32) 255L));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 1L));
					F738_4082(RTCW(loc6), loc7, ti4_1);
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 3L));
				ti4_1 = eif_bit_shift_left(ti4_1,((EIF_INTEGER_32) 8L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 2L));
				loc8 = eif_bit_or(ti4_1,ti4_2);
				F1218_8336(RTCW(loc7), loc8);
			}
			loc1++;
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_2_0_1_);
		loc2 = eif_min_int32 ((EIF_INTEGER_32) (((EIF_INTEGER_32) 65535L) - ((EIF_INTEGER_32) 2048L)),ti4_1);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tb1 = F832_4476(RTCW(arg1), loc1);
			if (tb1) {
				loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2048L));
				loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R4663[Dtype(RTCW(tr1))-947])(tr1);
				tr1 = RTLNS(eif_new_type(956, 0x01).id, 956, _OBJSIZ_0_0_0_0_0_0_0_0_);
				F957_6367(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_51_), loc3);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 1L));
				loc7 = F738_4063(RTCW(loc6), ti4_1);
				if ((EIF_BOOLEAN)(loc7 == NULL)) {
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1221,873,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						loc7 = RTLNS(typres0.id, 1221, _OBJSIZ_7_0_0_9_0_0_0_0_);
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_9_22_0_1_);
					F1214_8231(RTCW(loc7), ti4_1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 1L));
					F738_4082(RTCW(loc6), loc7, ti4_1);
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 3L));
				ti4_1 = eif_bit_shift_left(ti4_1,((EIF_INTEGER_32) 8L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 2L));
				loc8 = eif_bit_or(ti4_1,ti4_2);
				F1218_8336(RTCW(loc7), loc8);
			}
			loc1++;
		}
		loc7 = (EIF_REFERENCE) NULL;
		if (loc9) {
			F1309_9789(Current, loc6, ((EIF_INTEGER_32) 3L), NULL, loc10);
			loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_2_0_1_);
		loc2 = eif_min_int32 ((EIF_INTEGER_32) (((EIF_INTEGER_32) 1114111L) - ((EIF_INTEGER_32) 2048L)),ti4_1);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tb1 = F832_4476(RTCW(arg1), loc1);
			if (tb1) {
				loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2048L));
				loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R4663[Dtype(RTCW(tr1))-947])(tr1);
				tr1 = RTLNS(eif_new_type(956, 0x01).id, 956, _OBJSIZ_0_0_0_0_0_0_0_0_);
				F957_6367(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_51_), loc3);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 1L));
				loc7 = F738_4063(RTCW(loc6), ti4_1);
				if ((EIF_BOOLEAN)(loc7 == NULL)) {
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1221,873,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						loc7 = RTLNS(typres0.id, 1221, _OBJSIZ_7_0_0_9_0_0_0_0_);
					}
					F1214_8231(RTCW(loc7), ((EIF_INTEGER_32) 255L));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 1L));
					F738_4082(RTCW(loc6), loc7, ti4_1);
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 4L));
				ti4_1 = eif_bit_shift_left(ti4_1,((EIF_INTEGER_32) 8L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 3L));
				ti4_1 = eif_bit_or(ti4_1,ti4_2);
				ti4_1 = eif_bit_shift_left(ti4_1,((EIF_INTEGER_32) 8L));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_51_);
				ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(tr1))-950])(tr1, ((EIF_INTEGER_32) 2L));
				loc8 = eif_bit_or(ti4_1,ti4_2);
				F1218_8336(RTCW(loc7), loc8);
			}
			loc1++;
		}
		loc7 = (EIF_REFERENCE) NULL;
		if (loc9) {
			F1309_9789(Current, loc6, ((EIF_INTEGER_32) 4L), NULL, loc10);
		}
		tb1 = F1125_7674(RTCW(loc10));
		if (tb1) {
			loc4 = F1309_9770(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1208,0xFF01,831,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc11 = RTLNS(typres0.id, 1208, _OBJSIZ_4_0_0_2_0_0_0_0_);
			}
			F1209_8141(RTCW(loc11), ((EIF_INTEGER_32) 1L));
			F1209_8160(RTCW(loc11), loc4);
			F1209_8165(RTCW(loc10), loc11);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_50_);
		F1223_8415(RTCW(tr1), loc10, arg1);
	}
	RTLE;
	return (EIF_REFERENCE) F1309_9774(Current, loc10);
}

/* {LX_LEX_PARSER_SKELETON}.new_nfa_from_unions_of_concatenations_of_symbol_classes */
EIF_REFERENCE F1309_9774 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc5);
	RTLR(2,loc6);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc5 = F1209_8147(RTCW(arg1), loc1);
		tr1 = F1209_8148(RTCW(loc5));
		loc6 = F1309_9769(Current, tr1);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		loc4 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_4_0_0_1_);
		for (;;) {
			if ((EIF_BOOLEAN) (loc3 > loc4)) break;
			tr1 = F1209_8147(RTCW(loc5), loc3);
			tr1 = F1309_9769(Current, tr1);
			F1117_7567(RTCW(loc6), tr1);
			loc3++;
		}
		if ((EIF_BOOLEAN)(Result == NULL)) {
			Result = (EIF_REFERENCE) loc6;
		} else {
			F1117_7568(RTCW(Result), loc6);
		}
		loc1++;
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		Result = F1309_9768(Current);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {LX_LEX_PARSER_SKELETON}.process_rule */
void F1309_9779 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	RTCT0("precondition", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1117_7565(RTCW(arg1), loc1);
	F175_1944(loc1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	F1209_8165(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_39_);
	F1209_8165(RTCW(tr1), loc1);
	F175_1946(loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_23_));
	F175_1948(loc1, *(EIF_BOOLEAN *)(Current+ _CHROFF_62_6_));
	F175_1949(loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_50_));
	F175_1950(loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_51_));
	F175_1951(loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_48_));
	F175_1952(loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_49_));
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_62_6_) && (EIF_BOOLEAN) !(EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_50_) >= ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_51_) >= ((EIF_INTEGER_32) 0L))))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		F9_146(RTCW(tr1), (EIF_BOOLEAN) 1);
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_62_7_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		F9_145(RTCW(tr1), (EIF_BOOLEAN) 1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
	tb1 = F1125_7674(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		F1211_8230(RTCW(tr1), arg1, *(EIF_BOOLEAN *)(Current+ _CHROFF_62_7_));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_40_);
		F1211_8229(RTCW(tr1), arg1, *(EIF_BOOLEAN *)(Current+ _CHROFF_62_7_));
	}
	RTLE;
}

/* {LX_LEX_PARSER_SKELETON}.append_character_to_string */
EIF_REFERENCE F1309_9783 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg2);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	Result = (EIF_REFERENCE) arg2;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_9_1_);
	if (tb1) {
		switch (arg1) {
			case 65L:
			case 66L:
			case 67L:
			case 68L:
			case 69L:
			case 70L:
			case 71L:
			case 72L:
			case 73L:
			case 74L:
			case 75L:
			case 76L:
			case 77L:
			case 78L:
			case 79L:
			case 80L:
			case 81L:
			case 82L:
			case 83L:
			case 84L:
			case 85L:
			case 86L:
			case 87L:
			case 88L:
			case 89L:
			case 90L:
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 32L));
				loc1 = RTLNS(eif_new_type(947, 0x01).id, 947, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F946_5957(RTCW(loc1), ((EIF_INTEGER_32) 2L));
				F948_6075(RTCW(loc1), loc2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
				F1223_8405(RTCW(tr1), loc1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
				tb1 = F1212_8240(RTCW(tr1));
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
					loc3 = F1212_8232(RTCW(tr1));
				} else {
					loc3 = F1309_9770(Current);
					F832_4481(RTCW(loc3), arg1);
					F832_4481(RTCW(loc3), loc2);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
					F1217_8331(RTCW(tr1), loc3);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
					tb1 = F1212_8240(RTCW(tr1));
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
						loc3 = F1212_8232(RTCW(tr1));
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
						F1217_8337(RTCW(tr1), loc3);
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
					F1223_8415(RTCW(tr1), loc3, loc1);
				}
				tr1 = F1309_9769(Current, loc3);
				F1117_7567(RTCW(Result), tr1);
				break;
			case 97L:
			case 98L:
			case 99L:
			case 100L:
			case 101L:
			case 102L:
			case 103L:
			case 104L:
			case 105L:
			case 106L:
			case 107L:
			case 108L:
			case 109L:
			case 110L:
			case 111L:
			case 112L:
			case 113L:
			case 114L:
			case 115L:
			case 116L:
			case 117L:
			case 118L:
			case 119L:
			case 120L:
			case 121L:
			case 122L:
				loc1 = RTLNS(eif_new_type(947, 0x01).id, 947, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F946_5957(RTCW(loc1), ((EIF_INTEGER_32) 2L));
				F948_6075(RTCW(loc1), arg1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
				F1223_8405(RTCW(tr1), loc1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
				tb1 = F1212_8240(RTCW(tr1));
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
					loc3 = F1212_8232(RTCW(tr1));
				} else {
					loc3 = F1309_9770(Current);
					F832_4481(RTCW(loc3), (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 32L)));
					F832_4481(RTCW(loc3), arg1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
					F1217_8331(RTCW(tr1), loc3);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
					tb1 = F1212_8240(RTCW(tr1));
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
						loc3 = F1212_8232(RTCW(tr1));
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
						F1217_8337(RTCW(tr1), loc3);
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
					F1223_8415(RTCW(tr1), loc3, loc1);
				}
				tr1 = F1309_9769(Current, loc3);
				F1117_7567(RTCW(Result), tr1);
				break;
			default:
				tr1 = F1309_9767(Current, arg1);
				F1117_7567(RTCW(Result), tr1);
				break;
		}
	} else {
		tr1 = F1309_9767(Current, arg1);
		F1117_7567(RTCW(Result), tr1);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_);
	ti4_1 = eif_max_int32 (ti4_1,arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
	return Result;
}

/* {LX_LEX_PARSER_SKELETON}.append_character_to_character_class */
EIF_REFERENCE F1309_9784 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = (EIF_REFERENCE) arg2;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_9_1_);
	if (tb1) {
		switch (arg1) {
			case 65L:
			case 66L:
			case 67L:
			case 68L:
			case 69L:
			case 70L:
			case 71L:
			case 72L:
			case 73L:
			case 74L:
			case 75L:
			case 76L:
			case 77L:
			case 78L:
			case 79L:
			case 80L:
			case 81L:
			case 82L:
			case 83L:
			case 84L:
			case 85L:
			case 86L:
			case 87L:
			case 88L:
			case 89L:
			case 90L:
				F832_4481(RTCW(arg2), arg1);
				F832_4481(RTCW(arg2), (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 32L)));
				break;
			case 97L:
			case 98L:
			case 99L:
			case 100L:
			case 101L:
			case 102L:
			case 103L:
			case 104L:
			case 105L:
			case 106L:
			case 107L:
			case 108L:
			case 109L:
			case 110L:
			case 111L:
			case 112L:
			case 113L:
			case 114L:
			case 115L:
			case 116L:
			case 117L:
			case 118L:
			case 119L:
			case 120L:
			case 121L:
			case 122L:
				F832_4481(RTCW(arg2), (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 32L)));
				F832_4481(RTCW(arg2), arg1);
				break;
			default:
				F832_4481(RTCW(arg2), arg1);
				break;
		}
	} else {
		F832_4481(RTCW(arg2), arg1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_9_2_);
	if (tb1) {
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_);
		ti4_1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 255L));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_) = (EIF_INTEGER_32) ti4_1;
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_);
		ti4_1 = eif_max_int32 (ti4_1,arg1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return Result;
}

/* {LX_LEX_PARSER_SKELETON}.append_character_set_to_character_class */
EIF_REFERENCE F1309_9785 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg3);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = (EIF_REFERENCE) arg3;
	if ((EIF_BOOLEAN) (arg1 > arg2)) {
		F1309_9806(Current);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_9_1_);
		if (tb1) {
			loc1 = (EIF_INTEGER_32) arg1;
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > arg2)) break;
				switch (loc1) {
					case 65L:
					case 66L:
					case 67L:
					case 68L:
					case 69L:
					case 70L:
					case 71L:
					case 72L:
					case 73L:
					case 74L:
					case 75L:
					case 76L:
					case 77L:
					case 78L:
					case 79L:
					case 80L:
					case 81L:
					case 82L:
					case 83L:
					case 84L:
					case 85L:
					case 86L:
					case 87L:
					case 88L:
					case 89L:
					case 90L:
						F832_4481(RTCW(arg3), loc1);
						F832_4481(RTCW(arg3), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 32L)));
						break;
					case 97L:
					case 98L:
					case 99L:
					case 100L:
					case 101L:
					case 102L:
					case 103L:
					case 104L:
					case 105L:
					case 106L:
					case 107L:
					case 108L:
					case 109L:
					case 110L:
					case 111L:
					case 112L:
					case 113L:
					case 114L:
					case 115L:
					case 116L:
					case 117L:
					case 118L:
					case 119L:
					case 120L:
					case 121L:
					case 122L:
						F832_4481(RTCW(arg3), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 32L)));
						F832_4481(RTCW(arg3), loc1);
						break;
					default:
						F832_4481(RTCW(arg3), loc1);
						break;
				}
				loc1++;
			}
		} else {
			loc1 = (EIF_INTEGER_32) arg1;
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > arg2)) break;
				F832_4481(RTCW(arg3), loc1);
				loc1++;
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_9_2_);
	if (tb1) {
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_);
		ti4_1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 255L));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_) = (EIF_INTEGER_32) ti4_1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_9_22_0_1_);
		if ((EIF_BOOLEAN) (arg2 >= ti4_1)) {
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_);
			ti4_1 = eif_max_int32 (ti4_1,(EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_) = (EIF_INTEGER_32) ti4_1;
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_);
			ti4_1 = eif_max_int32 (ti4_1,arg2);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_) = (EIF_INTEGER_32) ti4_1;
		}
	}
	RTLE;
	return Result;
}

/* {LX_LEX_PARSER_SKELETON}.unions_of_concatenations_of_symbol_classes */
EIF_REFERENCE F1309_9787 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	RTCT0("anchor", EX_CHECK);
		RTCF0;
	return (EIF_REFERENCE) 0;
}

/* {LX_LEX_PARSER_SKELETON}.append_concatenations_of_symbol_classes_from_utf8_2_byte_character_class */
void F1309_9788 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,arg1);
	RTLR(1,loc8);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc4);
	RTLR(5,Current);
	RTLR(6,loc6);
	RTLR(7,arg2);
	RTLR(8,arg3);
	RTLR(9,arg4);
	RTLIU(10);
	
	RTGC;
	for (;;) {
		if (loc1) break;
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_1_);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
		for (;;) {
			if ((EIF_BOOLEAN) (loc2 > loc3)) break;
			tr1 = F738_4063(RTCW(arg1), loc2);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 == NULL) || (EIF_BOOLEAN)(loc4 == NULL))) {
					loc5 = (EIF_REFERENCE) loc8;
					loc4 = F1309_9770(Current);
					F832_4481(RTCW(loc4), loc2);
					F738_4082(RTCW(arg1), NULL, loc2);
				} else {
					tb1 = F832_4478(RTCW(loc5), loc8);
					if (tb1) {
						F832_4481(RTCW(loc4), loc2);
						F738_4082(RTCW(arg1), NULL, loc2);
					}
				}
			}
			loc2++;
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != NULL) && (EIF_BOOLEAN)(loc5 != NULL))) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1208,0xFF01,831,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				loc6 = RTLNS(typres0.id, 1208, _OBJSIZ_4_0_0_2_0_0_0_0_);
			}
			F1209_8141(RTCW(loc6), ((EIF_INTEGER_32) 4L));
			if ((EIF_BOOLEAN)(arg2 != NULL)) {
				F1209_8160(RTCW(loc6), arg2);
			}
			if ((EIF_BOOLEAN)(arg3 != NULL)) {
				F1209_8160(RTCW(loc6), arg3);
			}
			F1209_8160(RTCW(loc6), loc4);
			F1209_8160(RTCW(loc6), loc5);
			F1209_8165(RTCW(arg4), loc6);
			loc4 = (EIF_REFERENCE) NULL;
			loc5 = (EIF_REFERENCE) NULL;
		}
	}
	RTLE;
}

/* {LX_LEX_PARSER_SKELETON}.append_concatenations_of_symbol_classes_from_utf8_n_byte_character_class */
void F1309_9789 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,arg1);
	RTLR(1,loc12);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc5);
	RTLR(5,loc4);
	RTLR(6,loc6);
	RTLR(7,loc13);
	RTLR(8,loc9);
	RTLR(9,arg3);
	RTLR(10,arg4);
	RTLR(11,loc7);
	RTLR(12,loc14);
	RTLR(13,loc10);
	RTLIU(14);
	
	RTGC;
	for (;;) {
		if (loc1) break;
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_1_);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
		for (;;) {
			if ((EIF_BOOLEAN) (loc2 > loc3)) break;
			tr1 = F738_4063(RTCW(arg1), loc2);
			loc12 = tr1;
			if (EIF_TEST(loc12)) {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 == NULL) || (EIF_BOOLEAN)(loc4 == NULL))) {
					loc5 = (EIF_REFERENCE) loc12;
					loc4 = F1309_9770(Current);
					F832_4481(RTCW(loc4), loc2);
					F738_4082(RTCW(arg1), NULL, loc2);
				} else {
					tb1 = F1218_8332(RTCW(loc5), loc12);
					if (tb1) {
						F832_4481(RTCW(loc4), loc2);
						F738_4082(RTCW(arg1), NULL, loc2);
					}
				}
			}
			loc2++;
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != NULL) && (EIF_BOOLEAN)(loc5 != NULL))) {
			if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 3L))) {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,737,831,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					loc6 = RTLNS(typres0.id, 737, _OBJSIZ_1_1_0_2_0_0_0_0_);
				}
				F738_4058(RTCW(loc6), NULL, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 255L));
				loc13 = F1152_7729(RTCW(loc5));
				for (;;) {
					tb1 = F1079_7423(loc13);
					if (tb1) break;
					ti4_1 = F1040_7375(loc13);
					loc8 = eif_bit_and(ti4_1,((EIF_INTEGER_32) 255L));
					loc9 = F738_4063(RTCW(loc6), loc8);
					if ((EIF_BOOLEAN)(loc9 == NULL)) {
						loc9 = F1309_9770(Current);
						F738_4082(RTCW(loc6), loc9, loc8);
					}
					ti4_1 = F1040_7375(loc13);
					ti4_1 = eif_bit_shift_right(ti4_1,((EIF_INTEGER_32) 8L));
					F832_4481(RTCW(loc9), ti4_1);
					F1054_7396(loc13);
				}
				loc9 = (EIF_REFERENCE) NULL;
				F1309_9788(Current, loc6, arg3, loc4, arg4);
			} else {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,737,1221,873,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					loc7 = RTLNS(typres0.id, 737, _OBJSIZ_1_1_0_2_0_0_0_0_);
				}
				F738_4058(RTCW(loc7), NULL, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 255L));
				loc14 = F1152_7729(RTCW(loc5));
				for (;;) {
					tb2 = F1079_7423(loc14);
					if (tb2) break;
					ti4_1 = F1040_7375(loc14);
					loc8 = eif_bit_and(ti4_1,((EIF_INTEGER_32) 255L));
					loc10 = F738_4063(RTCW(loc7), loc8);
					if ((EIF_BOOLEAN)(loc10 == NULL)) {
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFF01,1221,873,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							loc10 = RTLNS(typres0.id, 1221, _OBJSIZ_7_0_0_9_0_0_0_0_);
						}
						F1214_8231(RTCW(loc10), ((EIF_INTEGER_32) 255L));
						F738_4082(RTCW(loc7), loc10, loc8);
					}
					ti4_1 = F1040_7375(loc14);
					ti4_1 = eif_bit_shift_right(ti4_1,((EIF_INTEGER_32) 8L));
					F1218_8336(RTCW(loc10), ti4_1);
					F1054_7396(loc14);
				}
				loc10 = (EIF_REFERENCE) NULL;
				F1309_9789(Current, loc7, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)), loc4, arg4);
			}
			loc4 = (EIF_REFERENCE) NULL;
			loc5 = (EIF_REFERENCE) NULL;
		}
	}
	RTLE;
}

/* {LX_LEX_PARSER_SKELETON}.set_maximum_symbol_equivalence_class */
void F1309_9794 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_38_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_9_22_0_1_);
	if ((EIF_BOOLEAN) (loc1 < ti4_1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		F9_112(RTCW(tr1), loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
		loc2 = F1221_8382(RTCW(tr1));
		F1053_7395(RTCW(loc2));
		for (;;) {
			tb1 = F1077_7423(RTCW(loc2));
			if (tb1) break;
			tr1 = F1039_7375(RTCW(loc2));
			F832_4486(RTCW(tr1), loc1);
			F1053_7396(RTCW(loc2));
		}
	}
	RTLE;
}

/* {LX_LEX_PARSER_SKELETON}.build_equiv_classes */
void F1309_9795 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(56, 0x01).id, 56, _OBJSIZ_1_0_0_2_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	ti4_1 = ((EIF_INTEGER_32) 0L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_9_22_0_1_);
	F57_819(RTCW(loc2), ti4_1, ti4_2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = F1221_8382(RTCW(tr1));
	F1053_7395(RTCW(loc1));
	for (;;) {
		tb1 = F1077_7423(RTCW(loc1));
		if (tb1) break;
		tr1 = F1039_7375(RTCW(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R841[Dtype(RTCW(loc2))-56])(loc2, tr1);
		F1053_7396(RTCW(loc1));
	}
	F57_833(RTCW(loc2));
	F1053_7395(RTCW(loc1));
	for (;;) {
		tb2 = F1077_7423(RTCW(loc1));
		if (tb2) break;
		tr1 = F1039_7375(RTCW(loc1));
		F832_4485(RTCW(tr1), loc2);
		F1053_7396(RTCW(loc1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	F9_144(RTCW(tr1), loc2);
	RTLE;
}

/* {LX_LEX_PARSER_SKELETON}.check_options */
void F1309_9796 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_9_6_);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_9_5_);
		if (tb1) {
			F1309_9811(Current);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_9_11_);
		if (tb1) {
			F1309_9812(Current);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_9_20_);
			if (tb1) {
				F1309_9813(Current);
			}
		}
	}
	RTLE;
}

/* {LX_LEX_PARSER_SKELETON}.report_error */
void F1309_9800 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1345, 0x01).id, 1345, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1019_7100(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_22_);
	F1346_10173(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1274_9044(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_62_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_PARSER_SKELETON}.report_negative_range_in_character_class_error */
void F1309_9806 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1337, 0x01).id, 1337, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1019_7100(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_22_);
	F1338_10149(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1274_9044(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_62_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_PARSER_SKELETON}.report_unrecognized_rule_error */
void F1309_9810 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1338, 0x01).id, 1338, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F1019_7100(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_62_8_0_22_);
	F1339_10152(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1274_9044(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_62_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_PARSER_SKELETON}.report_full_and_meta_equiv_classes_error */
void F1309_9811 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1335, 0x01).id, 1335, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1336_10143(RTCW(loc1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1274_9044(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_62_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_PARSER_SKELETON}.report_full_and_reject_error */
void F1309_9812 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1334, 0x01).id, 1334, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1335_10140(RTCW(loc1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1274_9044(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_62_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_PARSER_SKELETON}.report_full_and_variable_trailing_context_error */
void F1309_9813 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1336, 0x01).id, 1336, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1337_10146(RTCW(loc1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1274_9044(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_62_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

void EIF_Minit454 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
