/*
 * Code for class LX_BAD_CHARACTER_ERROR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx473.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_BAD_CHARACTER_ERROR}.make */
void F1328_10119 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,737,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = RTOSCF(10082,F1315_10082, (Current));
	F738_4058(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	F738_4082(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = eif_out__i4_s1(arg2);
	F738_4082(RTCW(tr1), tr2, ((EIF_INTEGER_32) 2L));
	tr1 = *(EIF_REFERENCE *)(Current);
	F738_4082(RTCW(tr1), arg3, ((EIF_INTEGER_32) 3L));
	RTLE;
}

/* {LX_BAD_CHARACTER_ERROR}.default_template */

EIF_REFERENCE F1328_10120 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10120,RTMS_EX_H("\"$1\", line $2: bad character: $3",32,1824107571));
}

void EIF_Minit473 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
