/*
 * Code for class GEANT_PROJECT_VARIABLES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge499.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_PROJECT_VARIABLES}.make */
void F1354_10273 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	F1238_8470(Current);
	tr1 = RTOSCF(10206,F1349_10206, (Current));
	F1351_10238(RTCW(tr1), Current);
	loc1 = RTOSCF(10275,F1354_10275, (Current));
	tr1 = RTOSCF(10206,F1349_10206, (Current));
	tb1 = F1351_10237(RTCW(tr1), loc1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(10203,F1349_10203, (Current));
		loc2 = F1223_8395(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			F1238_8472(Current, loc1, loc2);
		}
	}
	loc1 = RTOSCF(10276,F1354_10276, (Current));
	tr1 = RTOSCF(10206,F1349_10206, (Current));
	tb1 = F1351_10237(RTCW(tr1), loc1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(10203,F1349_10203, (Current));
		loc2 = F1223_8395(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			F1238_8472(Current, loc1, loc2);
		}
	}
	loc1 = RTOSCF(10277,F1354_10277, (Current));
	tr1 = RTOSCF(10206,F1349_10206, (Current));
	tb1 = F1351_10237(RTCW(tr1), loc1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(10203,F1349_10203, (Current));
		loc2 = F1223_8395(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			F1238_8472(Current, loc1, loc2);
		}
	}
	loc1 = RTOSCF(10278,F1354_10278, (Current));
	tr1 = RTOSCF(10206,F1349_10206, (Current));
	tb1 = F1351_10237(RTCW(tr1), loc1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(10203,F1349_10203, (Current));
		loc2 = F1223_8395(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			F1238_8472(Current, loc1, loc2);
		}
	}
	loc1 = RTOSCF(10279,F1354_10279, (Current));
	tr1 = RTOSCF(10206,F1349_10206, (Current));
	tr2 = RTOSCF(10279,F1354_10279, (Current));
	tb1 = F1351_10237(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(10203,F1349_10203, (Current));
		loc2 = F1223_8395(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			F1238_8472(Current, loc1, loc2);
		}
	}
	loc1 = RTOSCF(10280,F1354_10280, (Current));
	tb1 = '\0';
	tr1 = RTOSCF(10206,F1349_10206, (Current));
	tb2 = F1351_10237(RTCW(tr1), loc1);
	if ((EIF_BOOLEAN) !tb2) {
		tr1 = RTOSCF(10203,F1349_10203, (Current));
		tb2 = F1223_8402(RTCW(tr1), loc1);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTOSCF(10203,F1349_10203, (Current));
		tr1 = F1223_8394(RTCW(tr1), loc1);
		F1238_8472(Current, loc1, tr1);
	}
	RTLE;
}

/* {GEANT_PROJECT_VARIABLES}.gobo_os_name */
static EIF_REFERENCE F1354_10275_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10275);
#define Result RTOSR(10275)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("GOBO_OS",7,715786835);
	RTOSE (10275);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1354_10275 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10275,F1354_10275_body,(Current));
}

/* {GEANT_PROJECT_VARIABLES}.is_windows_name */
static EIF_REFERENCE F1354_10276_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10276);
#define Result RTOSR(10276)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("is_windows",10,479294835);
	RTOSE (10276);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1354_10276 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10276,F1354_10276_body,(Current));
}

/* {GEANT_PROJECT_VARIABLES}.is_unix_name */
static EIF_REFERENCE F1354_10277_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10277);
#define Result RTOSR(10277)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("is_unix",7,1358234232);
	RTOSE (10277);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1354_10277 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10277,F1354_10277_body,(Current));
}

/* {GEANT_PROJECT_VARIABLES}.path_separator_name */
static EIF_REFERENCE F1354_10278_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10278);
#define Result RTOSR(10278)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("path_separator",14,2028772978);
	RTOSE (10278);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1354_10278 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10278,F1354_10278_body,(Current));
}

/* {GEANT_PROJECT_VARIABLES}.exe_name */
static EIF_REFERENCE F1354_10279_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10279);
#define Result RTOSR(10279)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("exe",3,6649957);
	RTOSE (10279);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1354_10279 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10279,F1354_10279_body,(Current));
}

/* {GEANT_PROJECT_VARIABLES}.verbose_name */
static EIF_REFERENCE F1354_10280_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10280);
#define Result RTOSR(10280)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("verbose",7,1112830821);
	RTOSE (10280);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1354_10280 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10280,F1354_10280_body,(Current));
}

void EIF_Minit499 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
